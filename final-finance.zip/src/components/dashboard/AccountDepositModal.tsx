import React, { useState } from 'react';
import { 
  X, 
  ArrowDownLeft, 
  Building2, 
  CreditCard, 
  Coins, 
  ShieldCheck, 
  Binary, 
  CheckCircle2,
  Lock,
  Sparkles,
  Info
} from 'lucide-react';
import { UserWalletData, LinkedBankAccountItem, LinkedCardItem } from '../../types/wallet';

interface AccountDepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBalance: number;
  walletData: UserWalletData;
  onConfirmDeposit: (amount: number, sourceLabel: string, methodType: string) => void;
}

export const AccountDepositModal: React.FC<AccountDepositModalProps> = ({
  isOpen,
  onClose,
  currentBalance,
  walletData,
  onConfirmDeposit,
}) => {
  const [depositAmount, setDepositAmount] = useState<string>('1000');
  const [selectedMethodId, setSelectedMethodId] = useState<string>('bank-primary');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [note, setNote] = useState<string>('Account liquidity top-up');

  if (!isOpen) return null;

  const parsedAmount = parseFloat(depositAmount) || 0;
  const newProjectedBalance = currentBalance + parsedAmount;

  const presetAmounts = [250, 500, 1000, 5000, 25000, 100000];

  // Available linked methods from walletData
  const linkedBanks = walletData.linkedBankAccounts || [];
  const linkedCards = walletData.linkedCards || [];
  const linkedCryptos = walletData.linkedCryptoWallets || [];

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parsedAmount <= 0) return;

    setIsProcessing(true);
    setTimeout(() => {
      let sourceLabel = 'Linked Bank Wire';
      let methodType = 'bank';

      if (selectedMethodId.startsWith('bank-')) {
        const found = linkedBanks.find(b => b.id === selectedMethodId.replace('bank-', ''));
        sourceLabel = found ? `${found.bankName} (•••• ${found.accountNumberLast4})` : 'JPMorgan Chase (•••• 8920)';
        methodType = 'bank';
      } else if (selectedMethodId.startsWith('card-')) {
        const found = linkedCards.find(c => c.id === selectedMethodId.replace('card-', ''));
        sourceLabel = found ? `${found.brand.toUpperCase()} (•••• ${found.cardNumberLast4})` : 'Visa Signature (•••• 4242)';
        methodType = 'card';
      } else if (selectedMethodId === 'fnl-treasury') {
        sourceLabel = 'Final Coin (AFNL) Treasury Conversion';
        methodType = 'crypto';
      } else if (selectedMethodId === 'usdc-instant') {
        sourceLabel = 'USDC Instant Settlement';
        methodType = 'crypto';
      }

      onConfirmDeposit(parsedAmount, sourceLabel, methodType);
      setIsProcessing(false);
      onClose();
    }, 600);
  };

  return (
    <div 
      id="account-deposit-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="account-deposit-modal-container"
        className="relative w-full max-w-lg rounded-3xl bg-white border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in zoom-in-95 duration-200"
      >
        {/* Top Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-700">
              <ArrowDownLeft className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900 leading-tight">
                Deposit Funds to Account
              </h2>
              <p className="text-xs text-slate-500">
                Instant clearing via institutional settlement rails
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleDepositSubmit} className="p-6 space-y-6">
          {/* Current Balance & Projection Banner */}
          <div className="p-4 rounded-2xl bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-mono uppercase text-slate-400 block tracking-wider">
                Current Cash Balance
              </span>
              <span className={`text-xl font-bold font-mono ${currentBalance < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {currentBalance < 0 ? `-$${Math.abs(currentBalance).toLocaleString(undefined, { minimumFractionDigits: 2 })}` : `$${currentBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
              </span>
            </div>
            <div className="sm:text-right border-t sm:border-t-0 sm:border-l border-slate-800 pt-2 sm:pt-0 sm:pl-4">
              <span className="text-[10px] font-mono uppercase text-amber-400/90 block tracking-wider">
                New Projected Balance
              </span>
              <span className="text-xl font-bold font-mono text-white">
                ${newProjectedBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* Amount Input & Preset Chips */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-900 flex items-center justify-between">
              <span>Deposit Amount (USD)</span>
              <span className="text-[11px] font-mono text-amber-700 font-semibold">Zero Fee Clearing</span>
            </label>

            <div className="relative">
              <span className="absolute left-4 top-3 text-lg font-bold text-slate-400 font-mono">$</span>
              <input
                id="input-deposit-amount"
                type="number"
                min="1"
                step="any"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                placeholder="0.00"
                className="w-full pl-9 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xl font-bold font-mono text-slate-900 placeholder:text-slate-300 focus:outline-none focus:border-amber-500 focus:bg-white transition-all"
                required
              />
            </div>

            {/* Quick Preset Amount Buttons */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 pt-1">
              {presetAmounts.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setDepositAmount(amt.toString())}
                  className={`py-1.5 px-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer border ${
                    depositAmount === amt.toString()
                      ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-2xs'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  +${amt >= 1000 ? `${amt / 1000}k` : amt}
                </button>
              ))}
            </div>
          </div>

          {/* Deposit Source Selection */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-900 block">
              Funding Source &amp; Settlement Rail
            </label>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {/* Linked Bank Accounts */}
              {linkedBanks.map((bank) => (
                <label
                  key={bank.id}
                  className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedMethodId === `bank-${bank.id}`
                      ? 'border-amber-500 bg-amber-50/50 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="depositSource"
                      value={`bank-${bank.id}`}
                      checked={selectedMethodId === `bank-${bank.id}`}
                      onChange={() => setSelectedMethodId(`bank-${bank.id}`)}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <div className="p-2 rounded-xl bg-blue-50 border border-blue-200 text-blue-700">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        {bank.bankName}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        {bank.accountType} •••• {bank.accountNumberLast4}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Instant Wire
                  </span>
                </label>
              ))}

              {/* Linked Cards */}
              {linkedCards.map((card) => (
                <label
                  key={card.id}
                  className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedMethodId === `card-${card.id}`
                      ? 'border-amber-500 bg-amber-50/50 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="depositSource"
                      value={`card-${card.id}`}
                      checked={selectedMethodId === `card-${card.id}`}
                      onChange={() => setSelectedMethodId(`card-${card.id}`)}
                      className="text-amber-500 focus:ring-amber-500"
                    />
                    <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-700">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 block capitalize">
                        {card.brand} {card.cardType}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        •••• {card.cardNumberLast4} (Exp {card.expiryMonth}/{card.expiryYear})
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                    Instant
                  </span>
                </label>
              ))}

              {/* Stablecoin USDC option */}
              <label
                className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                  selectedMethodId === 'usdc-instant'
                    ? 'border-amber-500 bg-amber-50/50 shadow-2xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="depositSource"
                    value="usdc-instant"
                    checked={selectedMethodId === 'usdc-instant'}
                    onChange={() => setSelectedMethodId('usdc-instant')}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      USD Coin (USDC)
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      1:1 Regulated Fiat Stablecoin Clearing
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  1:1 Par
                </span>
              </label>
            </div>
          </div>

          {/* Security Guarantee */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-2.5 text-xs text-slate-600">
            <Lock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              Deposited funds are held in sovereign reserve escrow under Federal Reserve Fedwire &amp; Swiss Depository custody. Instant funds availability.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-2xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing || parsedAmount <= 0}
              className="flex-2 py-3 px-4 rounded-2xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              {isProcessing ? (
                <>
                  <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                  <span>Clearing Deposit...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirm Deposit of ${parsedAmount.toLocaleString()}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
