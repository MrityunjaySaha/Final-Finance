export type TransactionType = 
  | 'stock_buy'
  | 'stock_sell'
  | 'deposit'
  | 'bank_withdraw'
  | 'p2p_transfer'
  | 'payment_settlement'
  | 'dividend'
  | 'staking_reward'
  | 'barter_swap'
  | 'loan_issued'
  | 'loan_received'
  | 'loan_repaid'
  | 'loan_defaulted'
  | 'loan_written_off'
  | 'product_purchase'
  | 'service_payment'
  | 'marketplace_sale'
  | 'grant_claim'
  | 'campaign_donation'
  | 'vault_swap'
  | 'vault_deposit'
  | 'vault_withdrawal'
  | 'card_topup'
  | 'crypto_deposit'
  | 'grant_subsidy'
  | 'charity_donation'
  | 'trade'
  | 'ipo'
  | 'correction';

export type TransactionCategory = 
  | 'stock_trade'
  | 'personal_stock'
  | 'business_stock'
  | 'trade'
  | 'transfer'
  | 'money_inflow'
  | 'money_outflow'
  | 'income_yield'
  | 'barter'
  | 'loan'
  | 'product_service'
  | 'grant_subsidy'
  | 'charity_donation'
  | 'adjustment';

export type TransactionMode = 
  | 'final_coin'
  | 'fiat'
  | 'fiat_currency'
  | 'stable_coin'
  | 'crypto'
  | 'gold_bullion';

export type TaxFormMapping = 
  | 'Form 8949 / Schedule D'
  | 'Form 1099-DIV'
  | 'Form 1099-B'
  | 'Form 1099-MISC'
  | 'Non-Taxable Transfer'
  | 'Schedule C / Business Expense'
  | 'Sovereign Grant'
  | 'Regulatory Fee'
  | 'Securities Issuance'
  | 'Securities Transaction'
  | 'Administrative Adjustment'
  | 'Internal Allocation';

export interface TaxClassification {
  formMapping: TaxFormMapping;
  taxableEvent: boolean;
  taxableAmountUSD: number;
  holdingPeriod?: 'Short-Term' | 'Long-Term' | 'N/A';
  taxDeductible?: boolean;
  irsCategoryNote: string;
}

export interface UniversalLedgerItem {
  id: string;
  receiptNumber: string;
  taxYear: number;
  timestamp: string;
  dateIso: string;
  type: TransactionType;
  category: TransactionCategory;
  mode: TransactionMode;
  title: string;
  description: string;
  amountUSD: number;
  feeUSD: number;
  netAmountUSD: number;
  sourceOrDestination: string;
  counterpartyOrIssuer: string;
  issuerHandle?: string;
  isPersonalStock?: boolean;
  isBusinessStock?: boolean;
  stockTicker?: string;
  stockName?: string;
  shares?: number;
  unitPriceUSD?: number;
  costBasisUSD?: number;
  realizedGainLossUSD?: number;
  realizedGainLossPercent?: number;
  buyPriceUSD?: number;
  paymentCoinSymbol?: string;
  paymentCoinAmount?: number;
  loanId?: string;
  taxClassification: TaxClassification;
  status: 'Settled' | 'Confirmed' | 'Audited' | 'Reversed' | 'Pending Open';
  clearingNode: string;
  cryptographicHash: string;
  signature: string;
}
