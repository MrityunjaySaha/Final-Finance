import { MarketplaceListing, ListingStatus, ListingVisibility, AuctionBid, AuctionConfig } from '../types/marketplace';
import { isUserInAnyGroup } from './friendGroupService';
import {
  areUsersBlockedEitherWay,
  getIdentityAliases,
  isAdminAccount,
  isCurrentSessionAdmin,
} from './socialService';

const MARKETPLACE_STORAGE_KEY = 'final_finance_marketplace_listings_v5';
const AUCTION_BIDS_STORAGE_KEY = 'final_finance_auction_bids_v1';
const AUCTIONS_SEED_FLAG_KEY = 'ff_seeded_auctions_v1';
const CATALOG_SYNC_FLAG_KEY = 'ff_seeded_initial_catalog_v3';

const futureIso = (hours: number) => new Date(Date.now() + hours * 3600 * 1000).toISOString();

const INITIAL_MARKETPLACE_LISTINGS: MarketplaceListing[] = [
  {
    id: 'mkt-gold-1',
    userId: 'user-lord_sterling',
    creatorName: 'Lord Sterling',
    creatorHandle: 'sterling_vault',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 288000,
    title: '100oz 24K Imperial Gold Ingot (999.9 Purity)',
    category: 'Precious Metals & Bullion',
    description: 'Directly allocated LBMA-certified physical gold bullion stored in Zurich Freeport vault with cryptographic serial matrix #AFNL-9981.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'USD', 'BTC'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: '50% Physical Horology + 50% AFNL Coins or USDC',
      customExchangeOffers: 'Seeking Geneva tourbillon timepieces, fine silver ingots, or legal escrow credits.'
    },
    barterTerms: {
      desiredTrades: 'Geneva Tourbillon Timepieces, Enterprise AI GPU Servers, or Real Estate Title Deeds',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 288000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 14400 },
    stableCoinsPricing: { symbol: 'USDC', amount: 288000, network: 'Polygon & Ethereum' },
    fiatPricing: { currencyCode: 'USD', amount: 288000 },
    cryptoPricing: { symbol: 'BTC', amount: 3.04, network: 'Bitcoin' },
    quantity: 4,
    unitLabel: 'bars',
    condition: 'Brand New',
    location: 'Zurich Freeport Vault 1',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    tags: ['Gold', 'Bullion', 'LBMA', 'Zurich', 'Vault1'],
    likes: 42,
    views: 1284,
    createdAt: '2024-03-01T12:00:00.000Z'
  },
  {
    id: 'mkt-sec-audit',
    userId: 'demo-vip-alex',
    creatorName: 'Alex Morgan',
    creatorHandle: 'alex_morgan',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 15000,
    title: 'Smart Contract Formal Verification & Zero-Day Audit',
    category: 'Cybersecurity & Auditing',
    description: 'Comprehensive static analysis, symbolic execution bytecode proof, and multi-sig security audit by senior cryptographers.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'crypto'],
    acceptedCurrencyList: ['USDC', 'AFNL', 'ETH'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: 'Open to barter trade for physical bullion or GPU compute hours',
      customExchangeOffers: 'Accepting gold bullion, platinum watches, or AFNL'
    },
    barterTerms: {
      desiredTrades: 'Physical Gold Bullion, High-Density GPU Hardware, or Swiss Freeport Storage Credits',
      desiredExchangeType: 'any',
      openToOffers: true,
      estimatedValueUSD: 15000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 750 },
    stableCoinsPricing: { symbol: 'USDC', amount: 15000, network: 'Polygon' },
    cryptoPricing: { symbol: 'ETH', amount: 5.32, network: 'Ethereum' },
    availableUnits: 20,
    unitType: 'Hours',
    turnaroundTime: '2-3 Business Days',
    deliverables: 'Formal Verification Audit PDF Report + Remediation Review',
    skills: ['EVM', 'Formal Verification', 'Solidity', 'Rust', 'Security Proofs'],
    imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
    tags: ['Audit', 'Security', 'SmartContract', 'Verification'],
    likes: 54,
    views: 1120,
    createdAt: '2024-03-05T15:30:00.000Z'
  },
  {
    id: 'mkt-private-bullion-alex',
    userId: 'demo-vip-alex',
    creatorName: 'Alex Morgan',
    creatorHandle: 'alex_morgan',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'barter',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 120000,
    title: 'Private Syndicate 50oz Swiss Vault Ingot Allocation',
    category: 'Precious Metals & Bullion',
    description: 'Direct allocated bullion available strictly to Swiss Bullion Syndicate partners & verified friends.',
    status: 'uploaded',
    visibility: 'custom_group',
    allowedGroupIds: ['grp-bullion-syndicate'],
    allowedGroupNames: ['Swiss Bullion Syndicate'],
    acceptedSettlements: ['barter', 'final_coins'],
    acceptedCurrencyList: ['AFNL'],
    barterTerms: {
      desiredTrades: 'Geneva Tourbillon or Enterprise AI GPUs',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 120000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 6000 },
    quantity: 1,
    unitLabel: 'bars',
    condition: 'Brand New',
    location: 'Zurich Vault Private Cell',
    imageUrl: 'https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?auto=format&fit=crop&w=800&q=80',
    tags: ['Syndicate', 'Bullion', 'Gold', 'Private'],
    likes: 19,
    views: 318,
    createdAt: '2024-03-06T10:00:00.000Z'
  },
  {
    id: 'mkt-buy-gpu',
    userId: 'user-kaelen_reserve',
    creatorName: 'Kaelen Vance',
    creatorHandle: 'kaelen_reserve',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'buy',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USD',
    primaryPriceUSD: 85000,
    title: '[WANTED / BUYING] 8x NVIDIA H100 SXM5 80GB GPU Server Rigs',
    category: 'Hardware & Compute',
    description: 'Looking to purchase or barter for verified enterprise HGX H100 8-GPU clustered server nodes. Immediate settlement in USD, USDC, or AFNL.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['fiat', 'stable_coins', 'final_coins', 'barter'],
    acceptedCurrencyList: ['USD', 'USDC', 'AFNL'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: 'Can offer USD wire or barter tokenized sovereign gold certificates',
      customExchangeOffers: 'Accepting hardware delivery in Zurich or Northern Virginia datacenters'
    },
    barterTerms: {
      desiredTrades: 'Offering Zurich LBMA Gold Ingots or Staked ETH Validator Bonds in Exchange',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 85000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 4250 },
    stableCoinsPricing: { symbol: 'USDC', amount: 85000, network: 'Ethereum' },
    fiatPricing: { currencyCode: 'USD', amount: 85000 },
    quantity: 2,
    unitLabel: 'nodes',
    condition: 'Brand New',
    location: 'Zurich / US East',
    imageUrl: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=800&q=80',
    tags: ['GPU', 'H100', 'Compute', 'AI', 'Wanted'],
    likes: 38,
    views: 865,
    createdAt: '2024-03-07T18:00:00.000Z'
  },
  {
    id: 'mkt-watch-1',
    userId: 'user-elena_rostova',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena_rostova',
    creatorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'barter',
    primaryPriceUSD: 145000,
    title: 'Geneva Celestial Tourbillon Platinum Horology (#07/20)',
    category: 'Luxury Goods & Watches',
    description: 'Rare platinum astronomical timepiece featuring celestial star-chart complications and sapphire crystal tourbillon cage.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'EUR'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: 'Open to 50% Gold Ingot trade + 50% AFNL native coins',
      customExchangeOffers: 'Seeking physical precious metals or sovereign charter deed credits.'
    },
    barterTerms: {
      desiredTrades: '100oz Gold Bullion or Sovereign Superyacht Charter Deed',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 145000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 7250 },
    stableCoinsPricing: { symbol: 'USDC', amount: 145000, network: 'Ethereum' },
    fiatPricing: { currencyCode: 'EUR', amount: 133000 },
    quantity: 1,
    unitLabel: 'timepiece',
    condition: 'Certified Rare',
    location: 'Geneva Freeport Custody',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    tags: ['Horology', 'Platinum', 'Luxury', 'Geneva'],
    likes: 64,
    views: 1490,
    createdAt: '2024-03-08T10:00:00.000Z'
  },
  {
    id: 'mkt-demo-gholu-1',
    userId: 'user-gholu653',
    creatorName: 'Gholu',
    creatorHandle: 'gholu653',
    creatorAvatar: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 54000,
    title: 'Certified 1kg Fine Silver Bullion Bar (99.99%)',
    category: 'Precious Metals & Bullion',
    description: 'Vault-stored physical silver bar with serial attestation, ready for instant atomic barter transfer.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['final_coins', 'stable_coins', 'barter'],
    acceptedCurrencyList: ['AFNL', 'USDC'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 2700 },
    stableCoinsPricing: { symbol: 'USDC', amount: 54000, network: 'Polygon' },
    quantity: 1,
    unitLabel: 'bar',
    condition: 'Brand New',
    location: 'Zurich Vault Depository',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    tags: ['Silver', 'Bullion', 'Zurich', 'Physical'],
    likes: 31,
    views: 740,
    createdAt: '2024-03-09T14:00:00.000Z'
  },
  {
    id: 'mkt-demo-gholu-2',
    userId: 'user-gholu653',
    creatorName: 'Gholu',
    creatorHandle: 'gholu653',
    creatorAvatar: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'barter',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 95000,
    title: 'Private Vault Sovereign Allocation Certificate',
    category: 'Precious Metals & Bullion',
    description: 'Private allocation deed shared strictly with close partners & confirmed friends in my trade network.',
    status: 'uploaded',
    visibility: 'friends',
    acceptedSettlements: ['barter', 'final_coins'],
    acceptedCurrencyList: ['AFNL'],
    barterTerms: {
      desiredTrades: 'Precious metals, Horology, or High-grade GPUs',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 95000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 4750 },
    quantity: 1,
    unitLabel: 'certificate',
    condition: 'Mint',
    location: 'Private Vault Storage',
    imageUrl: 'https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?auto=format&fit=crop&w=800&q=80',
    tags: ['FriendsOnly', 'Certificate', 'Private'],
    likes: 14,
    views: 295,
    createdAt: '2024-03-10T11:00:00.000Z'
  },
  {
    id: 'mkt-auc-1',
    userId: 'user-lord_sterling',
    creatorName: 'Lord Sterling',
    creatorHandle: 'sterling_vault',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'auction',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 12500,
    title: '10oz Sovereign Platinum Reserve Ingot (Swiss Sealed)',
    category: 'Precious Metals & Bullion',
    description: 'Timed sovereign auction for 10oz PAMP Suisse sealed platinum ingot stored at Zurich Freeport. Bids accepted across all 5 settlement modes: Final Coins, Stablecoins, Fiat, Crypto, or Direct Barter.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'USD', 'ETH'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 625 },
    stableCoinsPricing: { symbol: 'USDC', amount: 12500, network: 'Polygon' },
    fiatPricing: { currencyCode: 'USD', amount: 12500 },
    cryptoPricing: { symbol: 'ETH', amount: 3.45, network: 'Ethereum' },
    barterTerms: {
      desiredTrades: 'Silver Bullion Bars, Fine Watches, or Formal Audit Services',
      desiredExchangeType: 'any',
      openToOffers: true,
      estimatedValueUSD: 12500
    },
    auctionConfig: {
      startingBidUSD: 11500,
      minIncrementUSD: 500,
      reservePriceUSD: 13000,
      buyNowPriceUSD: 18500,
      endTimeIso: futureIso(120),
      durationHours: 120,
      allowAutoExtend: true,
      highestBidUSD: 12500,
      highestBidderId: 'demo-vip-alex',
      highestBidderName: 'Alex Morgan',
      highestBidderHandle: 'alex_morgan',
      highestBidMode: 'final_coins',
      bidCount: 2,
      status: 'live'
    },
    quantity: 1,
    unitLabel: 'ingot',
    condition: 'Mint',
    location: 'Zurich Freeport Vault 2',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    tags: ['Auction', 'Platinum', 'Bullion', 'Swiss'],
    likes: 34,
    views: 612,
    createdAt: new Date().toISOString()
  },
  {
    id: 'mkt-auc-2',
    userId: 'user-elena_rostova',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena_rostova',
    creatorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'auction',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 6500,
    title: 'Executive Treasury & Cross-Chain Structuring Retainer (40 Hours)',
    category: 'Financial Advisory & Legal',
    description: '40-hour bespoke advisory block covering cross-jurisdictional treasury custody, smart contract escrow structuring, and multi-asset tax planning. Accepting bids in all 5 transaction modes.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'],
    acceptedCurrencyList: ['USDC', 'AFNL', 'USD', 'BTC'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 325 },
    stableCoinsPricing: { symbol: 'USDC', amount: 6500, network: 'Arbitrum' },
    fiatPricing: { currencyCode: 'USD', amount: 6500 },
    cryptoPricing: { symbol: 'BTC', amount: 0.068, network: 'Bitcoin' },
    barterTerms: {
      desiredTrades: 'Precious metals allocation, GPU compute hours, or security audit exchange',
      desiredExchangeType: 'any',
      openToOffers: true,
      estimatedValueUSD: 6500
    },
    auctionConfig: {
      startingBidUSD: 6000,
      minIncrementUSD: 250,
      reservePriceUSD: 6500,
      buyNowPriceUSD: 12000,
      endTimeIso: futureIso(72),
      durationHours: 72,
      allowAutoExtend: true,
      highestBidUSD: 6500,
      highestBidderId: 'user-kaelen_reserve',
      highestBidderName: 'Kaelen Vance',
      highestBidderHandle: 'kaelen_reserve',
      highestBidMode: 'stable_coins',
      bidCount: 1,
      status: 'live'
    },
    availableUnits: 40,
    unitType: 'Hours',
    turnaroundTime: '3-5 Business Days',
    deliverables: 'Full Legal Structuring Blueprint + Multi-Sig Custody Playbook',
    skills: ['Treasury', 'Escrow', 'Cross-Chain', 'Tax Structuring'],
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80',
    tags: ['Auction', 'Advisory', 'Treasury', 'Service'],
    likes: 28,
    views: 498,
    createdAt: new Date().toISOString()
  },
  // Jordan Belfort — Done & Rated, Done & Transacted, Active Sell, Active Auction
  {
    id: 'mkt-h100-cluster',
    userId: 'demo-jordan-belfort',
    sellerId: 'jordan_belfort',
    creatorName: 'Jordan Belfort',
    creatorHandle: 'jordan_belfort',
    sellerHandle: '@jordan_belfort',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 285000,
    title: 'Enterprise 8x NVIDIA H100 SXM5 80GB GPU Clustered Server Rig',
    category: 'Hardware & Compute',
    description: 'Flagship HGX H100 8-GPU liquid-cooled compute node delivered to Northern Virginia Tier-4 facility with full InfiniBand interconnect and SLA telemetry.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['stable_coins', 'final_coins', 'fiat'],
    acceptedCurrencyList: ['USDC', 'AFNL', 'USD'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 14250 },
    stableCoinsPricing: { symbol: 'USDC', amount: 285000, network: 'Ethereum' },
    fiatPricing: { currencyCode: 'USD', amount: 285000 },
    quantity: 1,
    unitLabel: 'cluster',
    condition: 'Brand New',
    location: 'Northern Virginia Datacenter',
    imageUrl: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=800&q=80',
    tags: ['H100', 'GPU', 'Compute', 'Settled'],
    likes: 76,
    views: 1640,
    createdAt: '2024-03-11T09:00:00.000Z'
  },
  {
    id: 'mkt-transacted-belfort-horology',
    userId: 'demo-jordan-belfort',
    sellerId: 'jordan_belfort',
    creatorName: 'Jordan Belfort',
    creatorHandle: 'jordan_belfort',
    sellerHandle: '@jordan_belfort',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 72000,
    title: 'Audemars Piguet Royal Oak Chronograph Rose Gold',
    category: 'Fine Watches & Horology',
    description: 'Certified authentic luxury timepiece transacted via bilateral escrow settlement with full provenance paperwork.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['stable_coins', 'final_coins'],
    acceptedCurrencyList: ['USDC', 'AFNL'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 3600 },
    stableCoinsPricing: { symbol: 'USDC', amount: 72000, network: 'Polygon' },
    quantity: 1,
    unitLabel: 'timepiece',
    condition: 'Mint',
    location: 'New York Reserve Vault',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    tags: ['Horology', 'Luxury', 'AP', 'Transacted'],
    likes: 51,
    views: 750,
    createdAt: '2024-03-12T10:30:00.000Z'
  },
  {
    id: 'mkt-belfort-active-bullion',
    userId: 'demo-jordan-belfort',
    sellerId: 'jordan_belfort',
    creatorName: 'Jordan Belfort',
    creatorHandle: 'jordan_belfort',
    sellerHandle: '@jordan_belfort',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 650000,
    title: 'Zurich Vault 250oz Allocated Gold Reserve Note',
    category: 'Precious Metals & Bullion',
    description: 'Direct institutional tranche of 250oz LBMA 999.9 gold bars held in segregated Zurich custody. Available for immediate AFNL, USDC, or split barter settlement.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['final_coins', 'stable_coins', 'barter', 'fiat'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'USD'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 32500 },
    stableCoinsPricing: { symbol: 'USDC', amount: 650000, network: 'Ethereum' },
    fiatPricing: { currencyCode: 'USD', amount: 650000 },
    quantity: 1,
    unitLabel: 'tranche',
    condition: 'Mint',
    location: 'Zurich Freeport Vault 3',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    tags: ['Gold', 'Reserve', 'Institutional', 'Zurich'],
    likes: 43,
    views: 980,
    createdAt: new Date(Date.now() - 18 * 3600 * 1000).toISOString()
  },
  {
    id: 'mkt-belfort-active-auction',
    userId: 'demo-jordan-belfort',
    sellerId: 'jordan_belfort',
    creatorName: 'Jordan Belfort',
    creatorHandle: 'jordan_belfort',
    sellerHandle: '@jordan_belfort',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'auction',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 22000,
    title: 'Institutional Reserve Liquidity Structuring & Syndication Desk',
    category: 'Financial Advisory & Legal',
    description: 'Live reserve auction for a dedicated 30-day sovereign liquidity structuring mandate and cross-vault counterparty syndication sprint.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['final_coins', 'stable_coins', 'fiat', 'barter'],
    acceptedCurrencyList: ['USDC', 'AFNL', 'USD'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 1100 },
    stableCoinsPricing: { symbol: 'USDC', amount: 22000, network: 'Ethereum' },
    auctionConfig: {
      startingBidUSD: 18000,
      minIncrementUSD: 500,
      reservePriceUSD: 20000,
      buyNowPriceUSD: 35000,
      endTimeIso: futureIso(54),
      durationHours: 72,
      allowAutoExtend: true,
      highestBidUSD: 22000,
      highestBidderId: 'demo-vip-alex',
      highestBidderName: 'Alex Morgan',
      highestBidderHandle: 'alex_morgan',
      highestBidMode: 'stable_coins',
      bidCount: 2,
      status: 'live'
    },
    availableUnits: 1,
    unitType: 'Deliverables',
    turnaroundTime: '30-Day Retainer',
    deliverables: 'Reserve Syndication Architecture + Counterparty Onboarding',
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80',
    tags: ['Auction', 'Liquidity', 'Syndication', 'Advisory'],
    likes: 37,
    views: 745,
    createdAt: new Date(Date.now() - 8 * 3600 * 1000).toISOString()
  },
  // Satoshi Nakamoto
  {
    id: 'mkt-sample-uploaded',
    userId: 'demo-satoshi-nakamoto',
    sellerId: 'satoshi',
    creatorName: 'Satoshi Nakamoto',
    creatorHandle: 'satoshi_nakamoto',
    sellerHandle: '@satoshi_nakamoto',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 25000,
    title: 'Quantum Cryptographic Security & Zero-Day Audit',
    category: 'Cybersecurity & Auditing',
    description: 'Full-stack lattice cryptography assessment, symbolic execution, and zero-knowledge circuit formal verification completed for sovereign treasury.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins'],
    acceptedCurrencyList: ['AFNL', 'USDC'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 1250 },
    stableCoinsPricing: { symbol: 'USDC', amount: 25000, network: 'Polygon' },
    availableUnits: 1,
    unitType: 'Deliverables',
    imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
    tags: ['Security', 'Quantum', 'Audit', 'Crypto'],
    likes: 94,
    views: 2150,
    createdAt: '2024-03-04T09:00:00.000Z'
  },
  {
    id: 'mkt-satoshi-active-protocol',
    userId: 'demo-satoshi-nakamoto',
    sellerId: 'satoshi_nakamoto',
    creatorName: 'Satoshi Nakamoto',
    creatorHandle: 'satoshi_nakamoto',
    sellerHandle: '@satoshi_nakamoto',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 35000,
    title: 'Zero-Knowledge Consensus Protocol Architecture Review',
    category: 'Cybersecurity & Auditing',
    description: 'Bespoke protocol specification review, deterministic finality proofs, and peer-to-peer cryptographic gossip security blueprint.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['final_coins', 'stable_coins', 'crypto'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'BTC'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 1750 },
    stableCoinsPricing: { symbol: 'USDC', amount: 35000, network: 'Ethereum' },
    availableUnits: 3,
    unitType: 'Deliverables',
    imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
    tags: ['Consensus', 'Protocol', 'Zero-Knowledge'],
    likes: 82,
    views: 1720,
    createdAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString()
  },
  // Marcus Vance
  {
    id: 'mkt-drone-4',
    userId: 'user-marcus_vance',
    sellerId: 'vance_capital',
    creatorName: 'Marcus Vance',
    creatorHandle: 'marcus_vance',
    sellerHandle: '@marcus_vance',
    creatorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USD',
    primaryPriceUSD: 14500,
    title: 'Sovereign Autonomous AI Drone Rig (MK-IV)',
    category: 'Hardware & Compute',
    description: 'Equipped with thermal imaging lidar, encrypted frequency hopper telemetry, and carbon-fiber rotor system.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['fiat', 'stable_coins', 'crypto'],
    acceptedCurrencyList: ['USD', 'USDC'],
    quantity: 1,
    unitLabel: 'rig',
    condition: 'Brand New',
    location: 'Zurich Tech Lab',
    imageUrl: 'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?auto=format&fit=crop&w=800&q=80',
    tags: ['Drone', 'Hardware', 'AI', 'Transacted'],
    likes: 33,
    views: 580,
    createdAt: '2024-03-09T09:00:00.000Z'
  },
  {
    id: 'mkt-vance-active-arb',
    userId: 'user-marcus_vance',
    sellerId: 'marcus_vance',
    creatorName: 'Marcus Vance',
    creatorHandle: 'marcus_vance',
    sellerHandle: '@marcus_vance',
    creatorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 18000,
    title: 'Cross-Exchange Cold-Storage Arbitrage Execution Mandate',
    category: 'Financial Advisory & Legal',
    description: 'Turnkey delta-neutral quantitative arbitrage routing setup with cold-vault multi-sig settlement rails.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['stable_coins', 'final_coins', 'crypto'],
    acceptedCurrencyList: ['USDC', 'AFNL', 'BTC'],
    stableCoinsPricing: { symbol: 'USDC', amount: 18000, network: 'Arbitrum' },
    availableUnits: 2,
    unitType: 'Deliverables',
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
    tags: ['Arbitrage', 'Quant', 'Treasury'],
    likes: 25,
    views: 460,
    createdAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
  },
  // Elena Rostova (done/rated listings)
  {
    id: 'mkt-patek-5711',
    userId: 'user-elena_rostova',
    sellerId: 'elena',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena_rostova',
    sellerHandle: '@elena_rostova',
    creatorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 165000,
    title: 'Patek Philippe Nautilus Ref. 5711/1R Rose Gold (Mint Box & Papers)',
    category: 'Luxury Goods & Watches',
    description: 'Collector-grade rose gold Nautilus complete with Geneva archive extract, settled via AFNL native escrow.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['final_coins', 'stable_coins', 'barter'],
    acceptedCurrencyList: ['AFNL', 'USDC'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 8250 },
    quantity: 1,
    unitLabel: 'timepiece',
    condition: 'Mint',
    location: 'Geneva Freeport Custody',
    imageUrl: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=800&q=80',
    tags: ['Horology', 'Patek', 'RoseGold', 'Sold'],
    likes: 71,
    views: 1340,
    createdAt: '2024-03-02T14:00:00.000Z'
  },
  // Alex Morgan (done/rated listing)
  {
    id: 'mkt-sample-sold',
    userId: 'demo-vip-alex',
    sellerId: 'alex_morgan',
    creatorName: 'Alex Morgan',
    creatorHandle: 'alex_morgan',
    sellerHandle: '@alex_morgan',
    creatorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USD',
    primaryPriceUSD: 85000,
    title: 'Allocated 100oz 24K Gold Bullion Ingot (LBMA Certified)',
    category: 'Precious Metals & Bullion',
    description: 'Successfully settled physical bullion transfer stored in Zurich Freeport repository.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'USD'],
    fiatPricing: { currencyCode: 'USD', amount: 85000 },
    quantity: 1,
    unitLabel: 'bar',
    condition: 'Mint',
    location: 'Zurich Freeport Vault 1',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    tags: ['Gold', 'Bullion', 'Sold', 'Zurich'],
    likes: 49,
    views: 920,
    createdAt: '2024-03-03T11:00:00.000Z'
  },
  // Alex Chen
  {
    id: 'mkt-alexchen-active-zk',
    userId: 'user-alex_chen',
    sellerId: 'alex_chen',
    creatorName: 'Alex Chen',
    creatorHandle: 'alex_chen',
    sellerHandle: '@alex_chen',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    listingIntent: 'sell',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 19500,
    title: 'High-Frequency ZK Rollup Prover Node Cluster Lease',
    category: 'Software & Infrastructure',
    description: 'Low-latency GPU + FPGA zero-knowledge proof generation cluster with automated verifiable proof batching.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['stable_coins', 'final_coins'],
    acceptedCurrencyList: ['USDC', 'AFNL'],
    stableCoinsPricing: { symbol: 'USDC', amount: 19500, network: 'Arbitrum' },
    availableUnits: 4,
    unitType: 'Deliverables',
    imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    tags: ['ZK', 'Prover', 'Infrastructure'],
    likes: 29,
    views: 512,
    createdAt: new Date(Date.now() - 10 * 3600 * 1000).toISOString()
  },
  {
    id: 'mkt-alexchen-done-fpga',
    userId: 'user-alex_chen',
    sellerId: 'alex_chen',
    creatorName: 'Alex Chen',
    creatorHandle: 'alex_chen',
    sellerHandle: '@alex_chen',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 42000,
    title: 'Custom FPGA Cryptographic Acceleration Chassis',
    category: 'Hardware & Compute',
    description: 'Hardware-accelerated cryptographic prover appliance delivered and bench-tested for institutional settlement.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['stable_coins', 'final_coins'],
    acceptedCurrencyList: ['USDC', 'AFNL'],
    stableCoinsPricing: { symbol: 'USDC', amount: 42000, network: 'Ethereum' },
    quantity: 1,
    unitLabel: 'chassis',
    condition: 'Brand New',
    location: 'Singapore Vault Lab',
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
    tags: ['FPGA', 'Cryptography', 'Hardware', 'Done'],
    likes: 34,
    views: 615,
    createdAt: '2024-03-13T16:00:00.000Z'
  },
  {
    id: 'mkt-transacted-auction-patek',
    userId: 'user-lord_sterling',
    sellerId: 'sterling_vault',
    creatorName: 'Lord Sterling',
    creatorHandle: 'sterling_vault',
    sellerHandle: '@sterling_vault',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'auction',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 94500,
    title: '1998 Patek Philippe Perpetual Calendar Ref. 3940J',
    category: 'Fine Watches & Horology',
    description: 'Settled sovereign reserve auction with Geneva seal extract, solid 18k yellow gold deployment buckle, and armored courier transfer.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['final_coins', 'stable_coins', 'barter'],
    acceptedCurrencyList: ['AFNL', 'USDC'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 4725 },
    auctionConfig: {
      startingBidUSD: 80000,
      minIncrementUSD: 1000,
      highestBidUSD: 94500,
      bidCount: 7,
      endTimeIso: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
      status: 'settled'
    },
    quantity: 1,
    unitLabel: 'timepiece',
    condition: 'Mint',
    location: 'London Vault',
    imageUrl: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=800&q=80',
    tags: ['Auction', 'Horology', 'Settled', 'Escrow'],
    likes: 88,
    views: 1120,
    createdAt: new Date(Date.now() - 160 * 3600 * 1000).toISOString()
  },
  {
    id: 'mkt-transacted-auction-node',
    userId: 'user-elena_rostova',
    sellerId: 'elena',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena_rostova',
    sellerHandle: '@elena_rostova',
    creatorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'auction',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 38000,
    title: 'Allocated Zurich Sovereign Compute & Cold Vault Node (12 Mo)',
    category: 'Hardware & Compute',
    description: 'Settled auction for 12-month dedicated bare-metal air-gapped node cluster inside Zurich Tier-4 sovereign vault facility.',
    status: 'sold',
    visibility: 'public',
    acceptedSettlements: ['stable_coins', 'final_coins'],
    acceptedCurrencyList: ['USDC', 'AFNL'],
    stableCoinsPricing: { symbol: 'USDC', amount: 38000, network: 'Arbitrum' },
    auctionConfig: {
      startingBidUSD: 30000,
      minIncrementUSD: 500,
      highestBidUSD: 38000,
      bidCount: 5,
      endTimeIso: new Date(Date.now() - 72 * 3600 * 1000).toISOString(),
      status: 'settled'
    },
    availableUnits: 1,
    unitType: 'Deliverables',
    location: 'Zurich Tier-4 Facility',
    imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    tags: ['Auction', 'Compute', 'Zurich', 'Settled'],
    likes: 61,
    views: 840,
    createdAt: new Date(Date.now() - 210 * 3600 * 1000).toISOString()
  }
];

function hydrateListingDefaults(listings: MarketplaceListing[]): MarketplaceListing[] {
  const initialMap = new Map(INITIAL_MARKETPLACE_LISTINGS.map(item => [item.id, item]));
  return listings.map((item) => {
    const seed = initialMap.get(item.id);
    return {
      ...item,
      likes: typeof item.likes === 'number' ? item.likes : (seed?.likes ?? 0),
      views: typeof item.views === 'number' ? item.views : (seed?.views ?? 120),
    };
  });
}

function seedInitialAuctionBidsIfNeeded() {
  try {
    if (localStorage.getItem(AUCTION_BIDS_STORAGE_KEY)) return;
    const initialBids: Record<string, AuctionBid[]> = {
      'mkt-auc-1': [
        {
          id: 'bid-auc-1-b',
          listingId: 'mkt-auc-1',
          bidderId: 'demo-vip-alex',
          bidderUid: 'demo-vip-alex',
          bidderName: 'Alex Morgan',
          bidderHandle: 'alex_morgan',
          bidderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
          amountUSD: 12500,
          mode: 'final_coins',
          currencySymbol: 'AFNL',
          nativeAmount: 625,
          createdAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
          status: 'active'
        },
        {
          id: 'bid-auc-1-a',
          listingId: 'mkt-auc-1',
          bidderId: 'user-kaelen_reserve',
          bidderUid: 'user-kaelen_reserve',
          bidderName: 'Kaelen Vance',
          bidderHandle: 'kaelen_reserve',
          bidderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
          amountUSD: 11800,
          mode: 'barter',
          barterOfferDescription: '500oz Fine Silver Reserve Bar + 40 USDC Sweetener',
          createdAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
          status: 'outbid'
        }
      ],
      'mkt-auc-2': [
        {
          id: 'bid-auc-2-a',
          listingId: 'mkt-auc-2',
          bidderId: 'user-kaelen_reserve',
          bidderUid: 'user-kaelen_reserve',
          bidderName: 'Kaelen Vance',
          bidderHandle: 'kaelen_reserve',
          bidderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
          amountUSD: 6500,
          mode: 'stable_coins',
          currencySymbol: 'USDC',
          nativeAmount: 6500,
          createdAt: new Date(Date.now() - 90 * 60 * 1000).toISOString(),
          status: 'active'
        }
      ]
    };
    localStorage.setItem(AUCTION_BIDS_STORAGE_KEY, JSON.stringify(initialBids));
  } catch (e) {
    console.warn('Error seeding auction bids:', e);
  }
}

let memoryStoreOverride: MarketplaceListing[] | null = null;

function loadMarketplaceStore(): MarketplaceListing[] {
  seedInitialAuctionBidsIfNeeded();
  try {
    const raw = localStorage.getItem(MARKETPLACE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        let hydrated = hydrateListingDefaults(parsed);
        let mutated = false;

        if (!localStorage.getItem(AUCTIONS_SEED_FLAG_KEY)) {
          const existingIds = new Set(hydrated.map(l => l.id));
          const missingAuctions = INITIAL_MARKETPLACE_LISTINGS.filter(
            l => l.listingIntent === 'auction' && !existingIds.has(l.id)
          );
          if (missingAuctions.length > 0) {
            hydrated = [...missingAuctions, ...hydrated];
            mutated = true;
          }
          localStorage.setItem(AUCTIONS_SEED_FLAG_KEY, '1');
        }

        if (!localStorage.getItem(CATALOG_SYNC_FLAG_KEY)) {
          const existingIds = new Set(hydrated.map(l => l.id));
          const missingCatalog = INITIAL_MARKETPLACE_LISTINGS.filter(l => !existingIds.has(l.id));
          if (missingCatalog.length > 0) {
            hydrated = [...hydrated, ...missingCatalog];
            mutated = true;
          }
          localStorage.setItem(CATALOG_SYNC_FLAG_KEY, '1');
        }

        if (mutated) {
          try {
            localStorage.setItem(MARKETPLACE_STORAGE_KEY, JSON.stringify(hydrated));
          } catch {}
        }
        memoryStoreOverride = hydrated;
        return hydrated;
      }
    }
  } catch (e) {
    console.warn('Error reading marketplace store from localStorage:', e);
    if (memoryStoreOverride) return memoryStoreOverride;
  }
  if (memoryStoreOverride) return memoryStoreOverride;
  // Initialize
  try {
    localStorage.setItem(AUCTIONS_SEED_FLAG_KEY, '1');
    localStorage.setItem(CATALOG_SYNC_FLAG_KEY, '1');
  } catch {}
  saveMarketplaceStore(INITIAL_MARKETPLACE_LISTINGS);
  return INITIAL_MARKETPLACE_LISTINGS;
}

function saveMarketplaceStore(listings: MarketplaceListing[]) {
  memoryStoreOverride = listings;
  try {
    localStorage.setItem(MARKETPLACE_STORAGE_KEY, JSON.stringify(listings));
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('final_finance_listings_updated'));
      }, 0);
    }
  } catch (e) {
    console.error('Error saving marketplace store:', e);
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('final_finance_listings_updated'));
      }, 0);
    }
  }
}

let marketplaceStore: MarketplaceListing[] = loadMarketplaceStore();

export function getAllMarketplaceListings(currentUserId?: string): MarketplaceListing[] {
  marketplaceStore = loadMarketplaceStore();
  if (!currentUserId || isAdminAccount(currentUserId) || isCurrentSessionAdmin()) {
    return marketplaceStore;
  }

  const cleanViewerUid = currentUserId.toLowerCase().replace(/^@/, '').replace(/^user-/, '');
  const viewerUid = currentUserId.startsWith('user-') ? currentUserId : `user-${cleanViewerUid}`;

  return marketplaceStore.filter(l => {
    const lUid = l.userId.startsWith('user-') ? l.userId : `user-${l.userId.toLowerCase().replace(/^@/, '')}`;
    if (areUsersBlockedEitherWay(viewerUid, lUid) || areUsersBlockedEitherWay(currentUserId, l.userId)) {
      return false;
    }
    return true;
  });
}

function normalizeUserKey(s?: string): string {
  if (!s) return '';
  return s.trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '').split('@')[0].replace(/[_\-\s]/g, '');
}

export function getUserListings(
  targetUserIdOrHandle: string,
  viewerUidOrHandle?: string,
  isFriendWithTarget: boolean = false,
  viewerHandle?: string
): MarketplaceListing[] {
  marketplaceStore = loadMarketplaceStore();
  if (!targetUserIdOrHandle) return [];

  const cleanTarget = targetUserIdOrHandle.trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '');
  const cleanTargetNorm = normalizeUserKey(targetUserIdOrHandle);
  const targetAliases = new Set(
    [targetUserIdOrHandle, cleanTarget, ...getIdentityAliases(targetUserIdOrHandle)].map(a => a.toLowerCase().replace(/^@/, ''))
  );
  const targetNorms = new Set(
    [cleanTargetNorm, ...Array.from(targetAliases).map(a => normalizeUserKey(a))].filter(Boolean)
  );

  const userListings = marketplaceStore.filter(l => {
    const candidates = [l.userId, l.sellerId, l.creatorHandle, l.sellerHandle].filter(Boolean) as string[];
    return candidates.some((c) => {
      const lower = c.trim().toLowerCase().replace(/^@/, '');
      const stripped = lower.replace(/^user-/, '');
      const norm = normalizeUserKey(c);
      return targetAliases.has(lower) || targetAliases.has(stripped) || (norm && targetNorms.has(norm));
    });
  });

  // Check if viewer is the owner of these listings
  const cleanViewerUid = viewerUidOrHandle ? viewerUidOrHandle.toLowerCase().replace(/^@/, '').replace(/^user-/, '') : '';
  const cleanViewerHandle = viewerHandle ? viewerHandle.toLowerCase().replace(/^@/, '').replace(/^user-/, '') : '';
  const cleanViewerNorm = normalizeUserKey(viewerUidOrHandle);
  const cleanViewerHandleNorm = normalizeUserKey(viewerHandle);
  const viewerAliases = new Set([
    ...(viewerUidOrHandle ? getIdentityAliases(viewerUidOrHandle) : []),
    ...(viewerHandle ? getIdentityAliases(viewerHandle) : []),
  ].map(a => a.toLowerCase().replace(/^@/, '')));

  // If viewer is omitted (e.g. called to get user's own listings in management UI) or matches target:
  const isOwner = Boolean(
    !viewerUidOrHandle ||
    viewerUidOrHandle === targetUserIdOrHandle ||
    (cleanViewerNorm && targetNorms.has(cleanViewerNorm)) ||
    (cleanViewerHandleNorm && targetNorms.has(cleanViewerHandleNorm)) ||
    (cleanViewerUid && (targetAliases.has(cleanViewerUid) || targetNorms.has(cleanViewerUid.replace(/[_\-\s]/g, '')))) ||
    (cleanViewerHandle && (targetAliases.has(cleanViewerHandle) || targetNorms.has(cleanViewerHandle.replace(/[_\-\s]/g, '')))) ||
    Array.from(viewerAliases).some(va => targetAliases.has(va))
  );

  // If viewer is the owner, return all their listings (public, friends, custom group, only_me, and drafts)
  if (isOwner) {
    if (userListings.length === 0) {
      const sampleDraft: MarketplaceListing = {
        id: `mkt-sample-draft-${Date.now()}`,
        userId: targetUserIdOrHandle,
        creatorName: targetUserIdOrHandle,
        creatorHandle: cleanTarget,
        listingIntent: 'sell',
        itemType: 'good',
        primaryTradeMode: 'currency',
        primaryCurrency: 'USD',
        primaryPriceUSD: 14500,
        title: '[DRAFT] Sovereign Autonomous AI Drone Rig (MK-IV)',
        category: 'Hardware & Compute',
        description: 'Unpublished draft listing featuring thermal imaging camera, autonomous lidar mapping, and encrypted telemetry.',
        status: 'draft',
        visibility: 'only_me',
        acceptedSettlements: ['fiat', 'stable_coins', 'crypto'],
        acceptedCurrencyList: ['USD', 'USDC'],
        fiatPricing: { currencyCode: 'USD', amount: 14500 },
        quantity: 1,
        unitLabel: 'unit',
        condition: 'Brand New',
        location: 'Zurich Vault Lab',
        imageUrl: 'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?auto=format&fit=crop&w=800&q=80',
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-drone-flying-over-a-forest-34282-large.mp4',
        tags: ['Draft', 'Drone', 'AI', 'Hardware'],
        likes: 0,
        views: 1,
        createdAt: new Date().toISOString()
      };

      const sampleUploaded: MarketplaceListing = {
        id: `mkt-sample-uploaded-${Date.now() + 1}`,
        userId: targetUserIdOrHandle,
        creatorName: targetUserIdOrHandle,
        creatorHandle: cleanTarget,
        listingIntent: 'sell',
        itemType: 'service',
        primaryTradeMode: 'currency',
        primaryCurrency: 'AFNL',
        primaryPriceUSD: 7500,
        title: 'Quantum Cryptographic Security & Zero-Day Audit',
        category: 'Cybersecurity & Auditing',
        description: 'Full-stack lattice cryptography assessment, symbolic execution, and zero-knowledge circuit verification.',
        status: 'uploaded',
        visibility: 'public',
        acceptedSettlements: ['barter', 'final_coins', 'stable_coins'],
        acceptedCurrencyList: ['AFNL', 'USDC'],
        finalCoinsPricing: { symbol: 'AFNL', amount: 375 },
        quantity: 10,
        unitLabel: 'audits',
        condition: 'Brand New',
        location: 'Global Remote',
        imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-with-code-31938-large.mp4',
        tags: ['Security', 'Quantum', 'Audit', 'Crypto'],
        likes: 27,
        views: 485,
        createdAt: new Date().toISOString()
      };

      const sampleSold: MarketplaceListing = {
        id: `mkt-sample-sold-${Date.now() + 2}`,
        userId: targetUserIdOrHandle,
        creatorName: targetUserIdOrHandle,
        creatorHandle: cleanTarget,
        listingIntent: 'sell',
        itemType: 'good',
        primaryTradeMode: 'currency',
        primaryCurrency: 'USD',
        primaryPriceUSD: 85000,
        title: 'Allocated 100oz 24K Gold Bullion Ingot (LBMA Certified)',
        category: 'Precious Metals & Bullion',
        description: 'Successfully settled physical bullion transfer stored in Zurich Freeport repository.',
        status: 'sold',
        visibility: 'public',
        acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat'],
        acceptedCurrencyList: ['AFNL', 'USDC', 'USD'],
        fiatPricing: { currencyCode: 'USD', amount: 85000 },
        quantity: 1,
        unitLabel: 'bar',
        condition: 'Mint',
        location: 'Zurich Freeport Vault 1',
        imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-gold-bar-42938-large.mp4',
        tags: ['Gold', 'Bullion', 'Sold', 'Zurich'],
        likes: 49,
        views: 920,
        createdAt: new Date().toISOString()
      };

      marketplaceStore = [sampleDraft, sampleUploaded, sampleSold, ...marketplaceStore];
      saveMarketplaceStore(marketplaceStore);
      return [sampleDraft, sampleUploaded, sampleSold];
    }
    return userListings;
  }

  // Admins can view all user contents (public, friends, custom group, only_me, and drafts) regardless of blocks
  const viewerIsAdmin =
    isAdminAccount(viewerUidOrHandle) ||
    isAdminAccount(viewerHandle) ||
    isCurrentSessionAdmin();
  if (viewerIsAdmin) {
    return userListings;
  }

  // If viewer is someone else, check if either party has blocked the other:
  const targetUid = targetUserIdOrHandle.startsWith('user-') ? targetUserIdOrHandle : `user-${cleanTarget}`;
  const viewerUid = (viewerUidOrHandle || '').startsWith('user-') ? viewerUidOrHandle! : `user-${cleanViewerUid}`;

  if (viewerUidOrHandle && (areUsersBlockedEitherWay(viewerUid, targetUid) || areUsersBlockedEitherWay(viewerUidOrHandle, targetUserIdOrHandle))) {
    return [];
  }

  // If viewer is someone else, ONLY return listings that the viewer has permission to view:
  return userListings.filter(l => {
    // Hide drafts and inactive status from public/visitor profiles
    if (l.status === 'draft') return false;

    const visibility = l.visibility || 'public';

    // 1. Public listings: visible to everyone
    if (visibility === 'public') {
      return true;
    }

    // 2. Only Me: strictly private, never visible to other users
    if (visibility === 'only_me') {
      return false;
    }

    // 3. Friends Only: visible strictly to confirmed friends
    if (visibility === 'friends') {
      return Boolean(isFriendWithTarget);
    }

    // 4. Custom Friend Group: visible strictly to members of the specific groups
    if (visibility === 'custom_group') {
      if (!l.allowedGroupIds || l.allowedGroupIds.length === 0) return false;
      const idsToCheck = [viewerUidOrHandle, viewerHandle, cleanViewerUid, cleanViewerHandle, cleanViewerNorm].filter(Boolean) as string[];
      return idsToCheck.some(id => isUserInAnyGroup(id, l.allowedGroupIds!));
    }

    return true;
  });
}

export function updateListingVisibility(
  listingId: string,
  visibility: ListingVisibility,
  allowedGroupIds?: string[],
  allowedGroupNames?: string[]
): MarketplaceListing | null {
  marketplaceStore = loadMarketplaceStore();
  const index = marketplaceStore.findIndex(l => l.id === listingId);
  if (index === -1) return null;

  const updated: MarketplaceListing = {
    ...marketplaceStore[index],
    visibility,
    allowedGroupIds: visibility === 'custom_group' ? (allowedGroupIds || []) : [],
    allowedGroupNames: visibility === 'custom_group' ? (allowedGroupNames || []) : []
  };

  marketplaceStore[index] = updated;
  saveMarketplaceStore(marketplaceStore);
  return updated;
}

export function createOrUpdateListing(
  userId: string,
  payload: Partial<MarketplaceListing> & { title: string; itemType: any; status: ListingStatus }
): MarketplaceListing {
  marketplaceStore = loadMarketplaceStore();
  const existingIndex = marketplaceStore.findIndex(l => l.id === payload.id);
  
  if (existingIndex > -1) {
    const updated = {
      ...marketplaceStore[existingIndex],
      ...payload,
      updatedAt: new Date().toISOString()
    } as MarketplaceListing;
    marketplaceStore[existingIndex] = updated;
    saveMarketplaceStore(marketplaceStore);
    return updated;
  }

  const newListing: MarketplaceListing = {
    id: payload.id || `mkt-${Date.now()}`,
    userId,
    creatorName: payload.creatorName || 'You',
    creatorHandle: payload.creatorHandle || userId,
    creatorAvatar: payload.creatorAvatar,
    listingIntent: payload.listingIntent || 'sell',
    itemType: payload.itemType,
    primaryTradeMode: payload.primaryTradeMode || 'currency',
    primaryCurrency: payload.primaryCurrency || 'USD',
    primaryPriceUSD: payload.primaryPriceUSD || 1000,
    title: payload.title,
    category: payload.category || 'General',
    description: payload.description || '',
    status: payload.status || 'draft',
    visibility: payload.visibility || 'public',
    allowedGroupIds: payload.allowedGroupIds || [],
    allowedGroupNames: payload.allowedGroupNames || [],
    acceptedSettlements: payload.acceptedSettlements || ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'],
    acceptedCurrencyList: payload.acceptedCurrencyList || ['USD', 'AFNL', 'USDC'],
    auctionConfig: payload.listingIntent === 'auction' ? payload.auctionConfig : undefined,
    crossTransactionalTerms: payload.crossTransactionalTerms,
    barterTerms: payload.barterTerms,
    finalCoinsPricing: payload.finalCoinsPricing,
    stableCoinsPricing: payload.stableCoinsPricing,
    fiatPricing: payload.fiatPricing,
    cryptoPricing: payload.cryptoPricing,
    quantity: payload.quantity,
    unitLabel: payload.unitLabel,
    condition: payload.condition,
    location: payload.location,
    availableUnits: payload.availableUnits,
    unitType: payload.unitType,
    turnaroundTime: payload.turnaroundTime,
    deliverables: payload.deliverables,
    skills: payload.skills,
    imageUrl: payload.imageUrl,
    videoUrl: payload.videoUrl,
    mediaList: payload.mediaList,
    tags: payload.tags || [],
    likes: payload.likes ?? 0,
    views: payload.views ?? 1,
    createdAt: new Date().toISOString()
  };

  marketplaceStore = [newListing, ...marketplaceStore];
  saveMarketplaceStore(marketplaceStore);
  return newListing;
}

export function updateListingStatus(
  userId: string,
  listingId: string,
  status: ListingStatus,
  buyerInfo?: { buyerId?: string; buyerUid?: string; buyerName?: string; buyerHandle?: string }
): MarketplaceListing | null {
  marketplaceStore = loadMarketplaceStore();
  const item = marketplaceStore.find(l => l.id === listingId);
  if (item) {
    item.status = status;
    if (status === 'sold' && buyerInfo) {
      if (buyerInfo.buyerId) item.buyerId = buyerInfo.buyerId;
      if (buyerInfo.buyerUid) item.buyerUid = buyerInfo.buyerUid;
      if (buyerInfo.buyerName) item.buyerName = buyerInfo.buyerName;
      if (buyerInfo.buyerHandle) item.buyerHandle = buyerInfo.buyerHandle;
    }
    saveMarketplaceStore(marketplaceStore);
    return item;
  }
  return null;
}

export function deleteListing(userId: string, listingId: string): boolean {
  marketplaceStore = loadMarketplaceStore();
  const initialLen = marketplaceStore.length;
  marketplaceStore = marketplaceStore.filter(l => l.id !== listingId);
  if (marketplaceStore.length < initialLen) {
    saveMarketplaceStore(marketplaceStore);
    return true;
  }
  return false;
}

export function incrementMarketplaceListingViews(listingId: string): number {
  marketplaceStore = loadMarketplaceStore();
  const idx = marketplaceStore.findIndex(l => l.id === listingId);
  if (idx === -1) return 0;
  const nextViews = (marketplaceStore[idx].views ?? 0) + 1;
  marketplaceStore[idx] = {
    ...marketplaceStore[idx],
    views: nextViews
  };
  saveMarketplaceStore(marketplaceStore);
  return nextViews;
}

export function submitBarterTradeProposal(proposalData: {
  listingId: string;
  listingTitle: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  offeredItemsDescription: string;
  offeredSweetenerUSD?: number;
  offeredSweetenerToken?: { symbol: string; amount: number };
}): { success: boolean; proposalId: string } {
  const proposalId = `PROP-${Date.now()}`;
  return { success: true, proposalId };
}

// ==================== AUCTION BID STORE & HELPERS ====================

function loadAllAuctionBidsMap(): Record<string, AuctionBid[]> {
  seedInitialAuctionBidsIfNeeded();
  try {
    const raw = localStorage.getItem(AUCTION_BIDS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    }
  } catch (e) {
    console.warn('Failed loading auction bids map:', e);
  }
  return {};
}

function saveAllAuctionBidsMap(map: Record<string, AuctionBid[]>) {
  try {
    localStorage.setItem(AUCTION_BIDS_STORAGE_KEY, JSON.stringify(map));
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('final_finance_listings_updated'));
      }, 0);
    }
  } catch (e) {
    console.error('Failed saving auction bids map:', e);
  }
}

export function getAuctionBids(listingId: string): AuctionBid[] {
  if (!listingId) return [];
  const map = loadAllAuctionBidsMap();
  const list = Array.isArray(map[listingId]) ? map[listingId] : [];
  return [...list].sort((a, b) => {
    if (b.amountUSD !== a.amountUSD) return b.amountUSD - a.amountUSD;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
}

export function saveAuctionBidsForListing(listingId: string, bids: AuctionBid[]) {
  const map = loadAllAuctionBidsMap();
  map[listingId] = bids;
  saveAllAuctionBidsMap(map);
}

export function getAuctionRemainingLabel(endTimeIso?: string): {
  text: string;
  isEnded: boolean;
  msRemaining: number;
} {
  if (!endTimeIso) return { text: 'No Expiry', isEnded: false, msRemaining: 999999999 };
  const endMs = new Date(endTimeIso).getTime();
  if (!Number.isFinite(endMs)) return { text: 'Open Auction', isEnded: false, msRemaining: 999999999 };
  const diff = endMs - Date.now();
  if (diff <= 0) return { text: 'Ended', isEnded: true, msRemaining: 0 };

  const totalMinutes = Math.floor(diff / 60000);
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const mins = totalMinutes % 60;

  if (days > 0) return { text: `${days}d ${hours}h left`, isEnded: false, msRemaining: diff };
  if (hours > 0) return { text: `${hours}h ${mins}m left`, isEnded: false, msRemaining: diff };
  if (mins > 0) return { text: `${mins}m left`, isEnded: false, msRemaining: diff };
  const secs = Math.max(1, Math.floor(diff / 1000));
  return { text: `${secs}s left`, isEnded: false, msRemaining: diff };
}

export function getCurrentAuctionPriceUSD(
  listing?: { auctionConfig?: AuctionConfig; priceUSD?: number; primaryPriceUSD?: number } | null
): number {
  if (!listing) return 0;
  const cfg = listing.auctionConfig;
  if (!cfg) return Number(listing.priceUSD ?? listing.primaryPriceUSD ?? 0) || 0;
  if (typeof cfg.highestBidUSD === 'number' && cfg.highestBidUSD > 0) return cfg.highestBidUSD;
  return Number(cfg.startingBidUSD ?? listing.priceUSD ?? listing.primaryPriceUSD ?? 0) || 0;
}

export function getMinimumNextBidUSD(
  listing?: { auctionConfig?: AuctionConfig; priceUSD?: number; primaryPriceUSD?: number } | null
): number {
  if (!listing) return 1;
  const cfg = listing.auctionConfig;
  if (!cfg) return Math.max(1, Number(listing.priceUSD ?? listing.primaryPriceUSD ?? 100));
  const inc = Math.max(1, Number(cfg.minIncrementUSD || 50));
  if (typeof cfg.highestBidUSD === 'number' && cfg.highestBidUSD > 0 && cfg.bidCount > 0) {
    return cfg.highestBidUSD + inc;
  }
  return Math.max(1, Number(cfg.startingBidUSD || listing.priceUSD || listing.primaryPriceUSD || 100));
}

export function updateListingAuctionState(
  listingId: string,
  updater: (listing: MarketplaceListing) => MarketplaceListing
): MarketplaceListing | null {
  marketplaceStore = loadMarketplaceStore();
  const idx = marketplaceStore.findIndex((l) => l.id === listingId);
  if (idx === -1) return null;
  const updated = updater(marketplaceStore[idx]);
  marketplaceStore[idx] = updated;
  saveMarketplaceStore(marketplaceStore);
  return updated;
}

export function ensureSampleAuctionsForUser(
  userIdOrHandle: string,
  userUid?: string,
  userName?: string
): void {
  if (!userIdOrHandle || typeof window === 'undefined') return;
  const cleanHandle = userIdOrHandle.trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '');
  const cleanUid = (userUid || userIdOrHandle).trim();
  const displayName = userName || userIdOrHandle;
  const seedFlagKey = `ff_user_sample_auctions_v4_${cleanHandle}`;
  const deletedFlagKey = `ff_user_deleted_sample_auction_${cleanHandle}`;

  marketplaceStore = loadMarketplaceStore();
  const bidsMap = loadAllAuctionBidsMap();
  let storeChanged = false;
  let bidsChanged = false;

  const ownerAliases = new Set(
    [
      cleanHandle,
      userIdOrHandle,
      cleanUid,
      ...getIdentityAliases(userIdOrHandle),
      ...(userUid ? getIdentityAliases(userUid) : []),
    ].map(a => a.toLowerCase().replace(/^@/, ''))
  );
  const ownerNorms = new Set(Array.from(ownerAliases).map(a => normalizeUserKey(a)).filter(Boolean));

  // 1. Ensure user has initiated auction examples in "My Auctions" (both active and done)
  const existingOwnedAuctions = marketplaceStore.filter((l) => {
    if (l.listingIntent !== 'auction') return false;
    const candidates = [l.userId, l.sellerId, l.creatorHandle].filter(Boolean) as string[];
    return candidates.some((c) => {
      const lower = c.toLowerCase().replace(/^@/, '');
      const stripped = lower.replace(/^user-/, '');
      const norm = normalizeUserKey(c);
      return ownerAliases.has(lower) || ownerAliases.has(stripped) || (norm && ownerNorms.has(norm));
    });
  });
  const existingActiveOwned = existingOwnedAuctions.filter(
    (l) => l.status !== 'sold' && l.auctionConfig?.status !== 'settled' && l.auctionConfig?.status !== 'ended'
  );
  const existingDoneOwned = existingOwnedAuctions.filter(
    (l) => l.status === 'sold' || l.auctionConfig?.status === 'settled' || l.auctionConfig?.status === 'ended'
  );

  let alreadySeededV4 = false;
  let userDeletedSamples = false;
  try {
    alreadySeededV4 = Boolean(localStorage.getItem(seedFlagKey));
    userDeletedSamples = Boolean(localStorage.getItem(deletedFlagKey));
  } catch {}

  if (alreadySeededV4 && (existingOwnedAuctions.length > 0 || userDeletedSamples)) {
    return;
  }

  if (existingActiveOwned.length === 0) {
    const myAuction1Id = `mkt-my-auc-1-${cleanHandle}`;
    const myAuction2Id = `mkt-my-auc-2-${cleanHandle}`;

    const myAuction1: MarketplaceListing = {
      id: myAuction1Id,
      userId: userIdOrHandle,
      creatorName: displayName,
      creatorHandle: cleanHandle,
      listingIntent: 'auction',
      itemType: 'good',
      primaryTradeMode: 'currency',
      primaryCurrency: 'AFNL',
      primaryPriceUSD: 18500,
      title: '1st Edition Sovereign Gold Coin Set (5x 1oz Proof)',
      category: 'Precious Metals & Bullion',
      description:
        'Timed sovereign reserve auction initiated from your vault custody desk. Sealed 24K proof set eligible for instant escrow transfer or AFNL/USDC settlement.',
      status: 'uploaded',
      visibility: 'public',
      acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'],
      acceptedCurrencyList: ['AFNL', 'USDC', 'USD', 'BTC'],
      finalCoinsPricing: { symbol: 'AFNL', amount: 925 },
      stableCoinsPricing: { symbol: 'USDC', amount: 18500, network: 'Polygon' },
      fiatPricing: { currencyCode: 'USD', amount: 18500 },
      auctionConfig: {
        startingBidUSD: 15000,
        minIncrementUSD: 500,
        reservePriceUSD: 17500,
        buyNowPriceUSD: 24000,
        endTimeIso: futureIso(36),
        durationHours: 48,
        allowAutoExtend: true,
        highestBidUSD: 18500,
        highestBidderId: 'demo-vip-alex',
        highestBidderName: 'Alex Morgan',
        highestBidderHandle: 'alex_morgan',
        highestBidMode: 'final_coins',
        bidCount: 2,
        status: 'live',
      },
      quantity: 1,
      unitLabel: 'proof set',
      condition: 'Mint',
      location: 'Zurich Freeport Vault',
      imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
      tags: ['Auction', 'Gold', 'ProofSet', 'Reserve'],
      likes: 19,
      views: 342,
      createdAt: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
    };

    const myAuction2: MarketplaceListing = {
      id: myAuction2Id,
      userId: userIdOrHandle,
      creatorName: displayName,
      creatorHandle: cleanHandle,
      listingIntent: 'auction',
      itemType: 'service',
      primaryTradeMode: 'currency',
      primaryCurrency: 'USDC',
      primaryPriceUSD: 9200,
      title: 'Algorithmic Arbitrage & Custody Node Deployment (1-Yr)',
      category: 'Software & Infrastructure',
      description:
        'Live auction for turnkey multi-exchange liquidity routing node & cryptographic audit onboarding. Accepting currency and barter bids.',
      status: 'uploaded',
      visibility: 'public',
      acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'crypto'],
      acceptedCurrencyList: ['USDC', 'AFNL', 'ETH'],
      finalCoinsPricing: { symbol: 'AFNL', amount: 460 },
      stableCoinsPricing: { symbol: 'USDC', amount: 9200, network: 'Arbitrum' },
      auctionConfig: {
        startingBidUSD: 7500,
        minIncrementUSD: 250,
        reservePriceUSD: 9000,
        buyNowPriceUSD: 14500,
        endTimeIso: futureIso(64),
        durationHours: 72,
        allowAutoExtend: true,
        highestBidUSD: 9200,
        highestBidderId: 'user-kaelen_reserve',
        highestBidderName: 'Kaelen Vance',
        highestBidderHandle: 'kaelen_reserve',
        highestBidMode: 'stable_coins',
        bidCount: 1,
        status: 'live',
      },
      availableUnits: 1,
      unitType: 'Deliverables',
      turnaroundTime: '48 Hours Setup',
      deliverables: 'Dedicated Custody Node + Live Telemetry Dashboard',
      imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
      tags: ['Auction', 'Infrastructure', 'Arbitrage', 'Service'],
      likes: 12,
      views: 215,
      createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
    };

    const toPrepend = [myAuction1, myAuction2].filter(a => !marketplaceStore.some(l => l.id === a.id));
    if (toPrepend.length > 0) {
      marketplaceStore = [...toPrepend, ...marketplaceStore];
      storeChanged = true;
    }

    if (!bidsMap[myAuction1Id]) {
      bidsMap[myAuction1Id] = [
        {
          id: `bid-myauc-1-a-${cleanHandle}`,
          listingId: myAuction1Id,
          bidderId: 'demo-vip-alex',
          bidderUid: 'demo-vip-alex',
          bidderName: 'Alex Morgan',
          bidderHandle: 'alex_morgan',
          bidderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
          amountUSD: 18500,
          mode: 'final_coins',
          currencySymbol: 'AFNL',
          nativeAmount: 925,
          createdAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
          status: 'active',
        },
        {
          id: `bid-myauc-1-b-${cleanHandle}`,
          listingId: myAuction1Id,
          bidderId: 'user-elena_rostova',
          bidderUid: 'user-elena_rostova',
          bidderName: 'Elena Rostova',
          bidderHandle: 'elena_rostova',
          bidderAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
          amountUSD: 16500,
          mode: 'stable_coins',
          currencySymbol: 'USDC',
          nativeAmount: 16500,
          createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
          status: 'outbid',
        },
      ];
      bidsChanged = true;
    }
    if (!bidsMap[myAuction2Id]) {
      bidsMap[myAuction2Id] = [
        {
          id: `bid-myauc-2-a-${cleanHandle}`,
          listingId: myAuction2Id,
          bidderId: 'user-kaelen_reserve',
          bidderUid: 'user-kaelen_reserve',
          bidderName: 'Kaelen Vance',
          bidderHandle: 'kaelen_reserve',
          bidderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
          amountUSD: 9200,
          mode: 'stable_coins',
          currencySymbol: 'USDC',
          nativeAmount: 9200,
          createdAt: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
          status: 'active',
        },
      ];
      bidsChanged = true;
    }
  }

  if (existingDoneOwned.length === 0) {
    const myAuctionDoneId = `mkt-my-auc-done-${cleanHandle}`;
    const myAuctionDone2Id = `mkt-my-auc-done-2-${cleanHandle}`;

    if (!marketplaceStore.some((l) => l.id === myAuctionDoneId)) {
      const endedIso = new Date(Date.now() - 8 * 3600 * 1000).toISOString();
      const myDoneAuction: MarketplaceListing = {
        id: myAuctionDoneId,
        userId: userIdOrHandle,
        creatorName: displayName,
        creatorHandle: cleanHandle,
        listingIntent: 'auction',
        itemType: 'good',
        primaryTradeMode: 'currency',
        primaryCurrency: 'USDC',
        primaryPriceUSD: 14800,
        title: 'Sovereign Obsidian Hardware Custody Vault (Batch #04)',
        category: 'Hardware & Cold Storage',
        description:
          'Completed timed reserve auction settled directly to winning bidder. Tamper-evident HSM vault unit with air-gapped key shard ceremonies.',
        status: 'sold',
        visibility: 'public',
        acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat'],
        acceptedCurrencyList: ['USDC', 'AFNL', 'USD'],
        finalCoinsPricing: { symbol: 'AFNL', amount: 740 },
        stableCoinsPricing: { symbol: 'USDC', amount: 14800, network: 'Base' },
        fiatPricing: { currencyCode: 'USD', amount: 14800 },
        auctionConfig: {
          startingBidUSD: 11000,
          minIncrementUSD: 400,
          reservePriceUSD: 13500,
          buyNowPriceUSD: 17500,
          endTimeIso: endedIso,
          durationHours: 48,
          allowAutoExtend: false,
          highestBidUSD: 14800,
          highestBidderId: 'user-elena_rostova',
          highestBidderName: 'Elena Rostova',
          highestBidderHandle: 'elena_rostova',
          highestBidMode: 'stable_coins',
          bidCount: 2,
          status: 'settled',
          winningBidId: `bid-myauc-done-1-${cleanHandle}`,
        },
        quantity: 1,
        unitLabel: 'vault unit',
        condition: 'Brand New',
        location: 'Singapore Vault Annex',
        imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
        tags: ['Auction', 'Settled', 'ColdStorage', 'Hardware'],
        likes: 27,
        views: 488,
        createdAt: new Date(Date.now() - 56 * 3600 * 1000).toISOString(),
      };

      marketplaceStore = [myDoneAuction, ...marketplaceStore];
      storeChanged = true;

      bidsMap[myAuctionDoneId] = [
        {
          id: `bid-myauc-done-1-${cleanHandle}`,
          listingId: myAuctionDoneId,
          bidderId: 'user-elena_rostova',
          bidderUid: 'user-elena_rostova',
          bidderName: 'Elena Rostova',
          bidderHandle: 'elena_rostova',
          bidderAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
          amountUSD: 14800,
          mode: 'stable_coins',
          currencySymbol: 'USDC',
          nativeAmount: 14800,
          createdAt: new Date(Date.now() - 9 * 3600 * 1000).toISOString(),
          status: 'won',
        },
        {
          id: `bid-myauc-done-2-${cleanHandle}`,
          listingId: myAuctionDoneId,
          bidderId: 'demo-vip-alex',
          bidderUid: 'demo-vip-alex',
          bidderName: 'Alex Morgan',
          bidderHandle: 'alex_morgan',
          bidderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
          amountUSD: 13600,
          mode: 'final_coins',
          currencySymbol: 'AFNL',
          nativeAmount: 680,
          createdAt: new Date(Date.now() - 14 * 3600 * 1000).toISOString(),
          status: 'outbid',
        },
      ];
      bidsChanged = true;
    }

    if (!marketplaceStore.some((l) => l.id === myAuctionDone2Id)) {
      const endedIso2 = new Date(Date.now() - 26 * 3600 * 1000).toISOString();
      const myDoneAuction2: MarketplaceListing = {
        id: myAuctionDone2Id,
        userId: userIdOrHandle,
        creatorName: displayName,
        creatorHandle: cleanHandle,
        listingIntent: 'auction',
        itemType: 'service',
        primaryTradeMode: 'currency',
        primaryCurrency: 'AFNL',
        primaryPriceUSD: 11400,
        title: 'Private Cross-Border Swiss Escrow & Tax Protocol Audit',
        category: 'Financial Advisory & Legal',
        description:
          'Completed service auction awarded to highest bidder. Included multi-jurisdictional vault compliance attestation and cryptographic settlement memo.',
        status: 'sold',
        visibility: 'public',
        acceptedSettlements: ['final_coins', 'stable_coins', 'fiat'],
        acceptedCurrencyList: ['AFNL', 'USDC', 'USD'],
        finalCoinsPricing: { symbol: 'AFNL', amount: 570 },
        stableCoinsPricing: { symbol: 'USDC', amount: 11400, network: 'Polygon' },
        auctionConfig: {
          startingBidUSD: 8500,
          minIncrementUSD: 300,
          reservePriceUSD: 10000,
          buyNowPriceUSD: 15000,
          endTimeIso: endedIso2,
          durationHours: 72,
          allowAutoExtend: false,
          highestBidUSD: 11400,
          highestBidderId: 'demo-vip-alex',
          highestBidderName: 'Alex Morgan',
          highestBidderHandle: 'alex_morgan',
          highestBidMode: 'final_coins',
          bidCount: 2,
          status: 'settled',
          winningBidId: `bid-myauc-done2-1-${cleanHandle}`,
        },
        availableUnits: 1,
        unitType: 'Deliverables',
        turnaroundTime: 'Completed & Delivered',
        deliverables: 'Swiss Escrow Audit Memo + Compliance Sign-Off',
        imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80',
        tags: ['Auction', 'Settled', 'Escrow', 'Advisory'],
        likes: 21,
        views: 365,
        createdAt: new Date(Date.now() - 96 * 3600 * 1000).toISOString(),
      };

      marketplaceStore = [myDoneAuction2, ...marketplaceStore];
      storeChanged = true;

      bidsMap[myAuctionDone2Id] = [
        {
          id: `bid-myauc-done2-1-${cleanHandle}`,
          listingId: myAuctionDone2Id,
          bidderId: 'demo-vip-alex',
          bidderUid: 'demo-vip-alex',
          bidderName: 'Alex Morgan',
          bidderHandle: 'alex_morgan',
          bidderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
          amountUSD: 11400,
          mode: 'final_coins',
          currencySymbol: 'AFNL',
          nativeAmount: 570,
          createdAt: new Date(Date.now() - 28 * 3600 * 1000).toISOString(),
          status: 'won',
        },
        {
          id: `bid-myauc-done2-2-${cleanHandle}`,
          listingId: myAuctionDone2Id,
          bidderId: 'user-marcus_vance',
          bidderUid: 'user-marcus_vance',
          bidderName: 'Marcus Vance',
          bidderHandle: 'marcus_vance',
          bidderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
          amountUSD: 10200,
          mode: 'stable_coins',
          currencySymbol: 'USDC',
          nativeAmount: 10200,
          createdAt: new Date(Date.now() - 34 * 3600 * 1000).toISOString(),
          status: 'outbid',
        },
      ];
      bidsChanged = true;
    }
  }

  // 2. Ensure user is participating in sample "Live Auctions" initiated by other members
  const externalAuctionIds = ['mkt-auc-1', 'mkt-auc-2'];
  const alreadyParticipating = marketplaceStore.some((item) => {
    if (item.listingIntent !== 'auction') return false;
    const itemBids = bidsMap[item.id] || [];
    return itemBids.some(
      (b) =>
        b.bidderId === cleanUid ||
        b.bidderId === userIdOrHandle ||
        b.bidderHandle?.toLowerCase().replace(/^@/, '') === cleanHandle
    );
  });

  if (!alreadyParticipating) {
    externalAuctionIds.forEach((aucId, idx) => {
      const targetIdx = marketplaceStore.findIndex((l) => l.id === aucId);
      if (targetIdx === -1) return;
      const aucListing = marketplaceStore[targetIdx];
      const ownerHandle = (aucListing.creatorHandle || aucListing.userId || '').toLowerCase().replace(/^@/, '');
      if (ownerHandle === cleanHandle) return;

      const existingList = Array.isArray(bidsMap[aucId]) ? [...bidsMap[aucId]] : [];
      const currentHigh = aucListing.auctionConfig?.highestBidUSD || aucListing.primaryPriceUSD || 10000;
      const isLeadingExample = idx === 0;
      const bidAmount = isLeadingExample ? currentHigh + 500 : Math.max(1000, currentHigh - 250);

      if (isLeadingExample) {
        existingList.forEach((b) => {
          b.status = 'outbid';
        });
      }

      const newBid: AuctionBid = {
        id: `bid-live-${aucId}-${cleanHandle}`,
        listingId: aucId,
        bidderId: cleanUid,
        bidderUid: cleanUid,
        bidderName: displayName,
        bidderHandle: cleanHandle,
        amountUSD: bidAmount,
        mode: isLeadingExample ? 'final_coins' : 'stable_coins',
        currencySymbol: isLeadingExample ? 'AFNL' : 'USDC',
        nativeAmount: isLeadingExample ? Math.round(bidAmount / 20) : bidAmount,
        createdAt: new Date(Date.now() - (idx === 0 ? 18 : 75) * 60 * 1000).toISOString(),
        status: isLeadingExample ? 'active' : 'outbid',
      };

      bidsMap[aucId] = [newBid, ...existingList];
      bidsChanged = true;

      if (isLeadingExample && aucListing.auctionConfig) {
        marketplaceStore[targetIdx] = {
          ...aucListing,
          primaryPriceUSD: bidAmount,
          auctionConfig: {
            ...aucListing.auctionConfig,
            highestBidUSD: bidAmount,
            highestBidderId: cleanUid,
            highestBidderName: displayName,
            highestBidderHandle: cleanHandle,
            highestBidMode: 'final_coins',
            bidCount: (aucListing.auctionConfig.bidCount || existingList.length) + 1,
          },
        };
        storeChanged = true;
      }
    });
  }

  if (bidsChanged) {
    saveAllAuctionBidsMap(bidsMap);
  }
  if (storeChanged) {
    saveMarketplaceStore(marketplaceStore);
  }

  try {
    localStorage.setItem(seedFlagKey, '1');
  } catch {}
}

