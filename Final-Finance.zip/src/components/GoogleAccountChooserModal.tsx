import React, { useState, useEffect } from 'react';
import {
  X,
  Loader2,
  Eye,
  EyeOff,
  AlertCircle,
  ShieldCheck,
  KeyRound,
  Sparkles,
  BookmarkCheck,
  Trash2,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import {
  signInWithGoogle,
  getRegisteredUsers,
  RegisteredAccount,
  getRememberedAccounts,
  forgetRememberedAccount,
  signInWithRememberedAccount,
  RememberedAccount,
} from '../services/firebaseAuth';
import { isProtectedOwnerEmail } from '../utils/privacyShield';

interface GoogleAccountChooserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAccount: (user: AuthSession) => void;
  initialAccount?: RegisteredAccount | null;
}

export const GoogleAccountChooserModal: React.FC<GoogleAccountChooserModalProps> = ({
  isOpen,
  onClose,
  onSelectAccount,
}) => {
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberOnDevice, setRememberOnDevice] = useState(true);
  const [rememberedAccounts, setRememberedAccounts] = useState<RememberedAccount[]>([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const registeredUsers = getRegisteredUsers();
  const normalizedInputEmail = emailInput.trim()
    ? (emailInput.trim().includes('@') ? emailInput.trim().toLowerCase() : `${emailInput.trim().toLowerCase()}@gmail.com`)
    : '';
  const isNewSignupAccount = Boolean(
    normalizedInputEmail &&
      !registeredUsers[normalizedInputEmail] &&
      !isProtectedOwnerEmail(normalizedInputEmail)
  );

  useEffect(() => {
    if (isOpen) {
      setRememberedAccounts(getRememberedAccounts());
      setErrorMessage('');
    }
  }, [isOpen]);

  // Only autofill non-protected demo accounts; never prefill protected owner accounts
  useEffect(() => {
    const trimmed = emailInput.trim().toLowerCase();
    const normalized = trimmed.includes('@') ? trimmed : `${trimmed}@gmail.com`;
    const users = getRegisteredUsers();
    if (trimmed && !isProtectedOwnerEmail(normalized) && users[normalized]) {
      const acc = users[normalized];
      if (acc.passwordHash && !acc.passwordHash.startsWith('sha256:') && !passwordInput) {
        setPasswordInput(acc.passwordHash);
      }
    }
  }, [emailInput, passwordInput]);

  if (!isOpen) return null;

  const handleRememberedSignIn = async (email: string) => {
    setIsLoading(true);
    setErrorMessage('');
    try {
      const res = await signInWithRememberedAccount(email);
      if (res.success && res.user) {
        onSelectAccount(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Could not restore saved session. Please enter your password.');
      }
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Authentication error.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgetAccount = (e: React.MouseEvent, email: string) => {
    e.stopPropagation();
    forgetRememberedAccount(email);
    setRememberedAccounts(getRememberedAccounts());
  };

  const handleSignInSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawEmail = emailInput.trim();
    if (!rawEmail) {
      setErrorMessage('Please enter your Google / Gmail email address.');
      return;
    }
    if (!passwordInput) {
      setErrorMessage('Please enter your password.');
      return;
    }

    const email = rawEmail.includes('@') ? rawEmail.toLowerCase() : `${rawEmail.toLowerCase()}@gmail.com`;
    const isExisting = Boolean(registeredUsers[email] || isProtectedOwnerEmail(email));
    if (!isExisting && !agreedToTerms) {
      setErrorMessage('Agreement required: Unless you check and agree to the non-commercialization & no-data-selling agreement below, you cannot sign up for a new account.');
      return;
    }
    setIsLoading(true);
    setErrorMessage('');

    try {
      const res = await signInWithGoogle(email, passwordInput, !isExisting, { rememberOnDevice });
      if (res.success && res.user) {
        onSelectAccount(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Password mismatch. Try again or check your saved password.');
      }
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Authentication error.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAutofillGholu = () => {
    setEmailInput('gholu653@gmail.com');
    setPasswordInput('gholu123');
    setErrorMessage('');
  };

  const handleAutofillCurrentPassword = () => {
    const trimmed = emailInput.trim().toLowerCase();
    const normalized = trimmed.includes('@') ? trimmed : `${trimmed}@gmail.com`;
    if (isProtectedOwnerEmail(normalized)) {
      setErrorMessage('Autofill is disabled for private owner accounts. Please enter your password manually.');
      return;
    }
    if (trimmed && registeredUsers[normalized] && !registeredUsers[normalized].passwordHash.startsWith('sha256:')) {
      setPasswordInput(registeredUsers[normalized].passwordHash);
    } else {
      setPasswordInput('gholu123');
    }
    setErrorMessage('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="w-full max-w-[440px] bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 text-center relative overflow-y-auto max-h-[92dvh] font-sans animate-in fade-in zoom-in-95 duration-200 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 min-h-[38px] min-w-[38px] flex items-center justify-center rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Google Header */}
        <div className="space-y-2 mb-5 flex flex-col items-center text-center">
          <svg className="w-7 h-7 mx-auto" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
            />
          </svg>

          <div className="text-center">
            <h2 className="text-xl sm:text-2xl font-normal text-slate-900 tracking-tight text-center">
              Sign in with Google
            </h2>
            <p className="text-xs text-slate-600 mt-1 text-center">
              Enter your Gmail address and password to continue
            </p>
          </div>
        </div>

        {/* Saved Accounts on This Browser (only populated after user logs into them on this browser) */}
        {rememberedAccounts.length > 0 && (
          <div className="mb-4 space-y-2 text-center">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center justify-center gap-1.5">
              <BookmarkCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Saved on This Browser</span>
            </p>
            <div className="space-y-1.5 max-h-40 overflow-y-auto">
              {rememberedAccounts.map((acc) => (
                <div
                  key={acc.email}
                  className="p-2 rounded-xl bg-slate-50 border border-slate-200 hover:border-blue-300 flex items-center justify-between gap-2 transition-colors text-left"
                >
                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={() => handleRememberedSignIn(acc.email)}
                    className="flex items-center gap-2 min-w-0 flex-1 text-left cursor-pointer"
                  >
                    {acc.avatarUrl ? (
                      <img
                        src={acc.avatarUrl}
                        alt={acc.name}
                        className="w-7 h-7 rounded-full object-cover border border-slate-200 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                        {(acc.name || acc.email).charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-900 truncate">{acc.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{acc.email}</p>
                    </div>
                  </button>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      disabled={isLoading}
                      onClick={() => handleRememberedSignIn(acc.email)}
                      className="px-2.5 py-1 rounded-lg bg-[#1a73e8] hover:bg-[#1557b0] text-white text-[10px] font-bold cursor-pointer"
                    >
                      Use
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleForgetAccount(e, acc.email)}
                      className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                      title="Forget from this browser"
                      aria-label={`Remove ${acc.email}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick Demo Account Helper */}
        <div className="mb-4 space-y-2 flex flex-col items-center text-center w-full">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider text-center">
            Quick Select Demo Account
          </p>
          <div className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center gap-2 text-center">
            <div className="flex items-center justify-center gap-2 min-w-0 max-w-full">
              <KeyRound className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <p className="text-xs font-medium text-slate-800 truncate text-center">gholu653@gmail.com</p>
            </div>
            <button
              type="button"
              onClick={handleAutofillGholu}
              className="px-3.5 py-1 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-[10px] font-bold transition-all shrink-0 cursor-pointer"
            >
              Select
            </button>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-4 p-3 text-xs text-red-600 bg-red-50 rounded-xl border border-red-200 flex flex-col items-center justify-center gap-1.5 text-center">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
            <span className="text-center">{errorMessage}</span>
          </div>
        )}

        {/* Standard Form with Password Manager Autofill attributes */}
        <form onSubmit={handleSignInSubmit} method="POST" action="#" autoComplete="on" className="space-y-4 w-full text-center flex flex-col items-center">
          <div className="w-full text-center">
            <div className="flex flex-col items-center justify-center gap-0.5 mb-1.5 text-center">
              <label htmlFor="google_account_email" className="block text-xs font-medium text-slate-700 text-center">
                Gmail / Google Account
              </label>
              <span className="text-[11px] text-slate-400 text-center">username / email</span>
            </div>
            <input
              type="text"
              id="google_account_email"
              name="username"
              autoComplete="username email webauthn"
              inputMode="email"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              placeholder="yourname@gmail.com"
              className="w-full px-4 py-3 text-base sm:text-sm text-center rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 outline-none transition-all text-slate-900 placeholder:text-slate-400 bg-white"
              required
            />
          </div>

          <div className="w-full text-center">
            <div className="flex flex-col items-center justify-center gap-1 mb-1.5 text-center">
              <label htmlFor="google_account_password" className="text-xs font-medium text-slate-700 text-center">
                Password
              </label>
              <button
                type="button"
                onClick={handleAutofillCurrentPassword}
                className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center justify-center gap-1 cursor-pointer mx-auto"
              >
                <Sparkles className="w-3 h-3 text-blue-600" />
                <span>Autofill demo password</span>
              </button>
            </div>
            <div className="relative w-full">
              <input
                type={showPassword ? 'text' : 'password'}
                id="google_account_password"
                name="password"
                autoComplete="current-password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter password"
                className="w-full px-11 py-3 text-base sm:text-sm text-center rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 outline-none transition-all text-slate-900 placeholder:text-slate-400 bg-white"
                required
              />
              <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1.5 rounded text-slate-400 hover:text-slate-700 cursor-pointer"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          <label className="flex items-center justify-center gap-2 pt-1 text-xs text-slate-600 cursor-pointer select-none text-center">
            <input
              type="checkbox"
              checked={rememberOnDevice}
              onChange={(e) => setRememberOnDevice(e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-600 cursor-pointer"
            />
            <span>Save account on this browser after sign-in</span>
          </label>

          <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 text-center">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Browser password manager &amp; saved sessions enabled.</span>
          </div>

          {isNewSignupAccount && (
            <div className="p-3.5 rounded-2xl bg-amber-50/90 border border-amber-200/90 text-center space-y-2 flex flex-col items-center justify-center">
              <div className="flex items-center justify-center gap-1.5 text-amber-900 font-bold text-xs text-center">
                <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                <span>First-Time Sign Up Agreement</span>
              </div>
              <label className="flex flex-col items-center justify-center gap-2 cursor-pointer select-none text-center">
                <input
                  type="checkbox"
                  checked={agreedToTerms}
                  onChange={(e) => {
                    setAgreedToTerms(e.target.checked);
                    if (e.target.checked && errorMessage.includes('Agreement')) {
                      setErrorMessage('');
                    }
                  }}
                  className="w-4 h-4 rounded text-amber-600 border-amber-300 focus:ring-amber-500 cursor-pointer shrink-0"
                  required
                />
                <span className="text-xs text-slate-700 leading-relaxed text-center">
                  I understand and agree: <strong>We right now have no plans to commercializing our application the traditional way. I have no real plans of selling the data of our users to anyone right now to help support our application.</strong>
                </span>
              </label>
              {!agreedToTerms && (
                <p className="text-[11px] text-amber-800 font-medium text-center">
                  * Unless you agree, you cannot sign up.
                </p>
              )}
            </div>
          )}

          <div className="pt-3 w-full flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] px-4 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading || !emailInput.trim() || !passwordInput}
              className="min-h-[42px] px-6 py-2.5 rounded-full bg-[#1a73e8] hover:bg-[#1557b0] active:bg-[#174ea6] text-white text-sm font-medium transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-40 disabled:cursor-not-allowed min-w-[96px]"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin text-white" /> : 'Continue'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
