import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Crown, Search, ShieldAlert, ShieldCheck, Lock, Unlock, Trash2, UserCheck, Mail, AtSign, MessageSquare, AlertCircle, FolderHeart, Users, Coins, Image, Video, Clock } from 'lucide-react';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { getAdminEscalations, updateEscalationStatus, AdminEscalation } from '../services/feedbackService';
import { getAdminGroups, AdminGroup, AdminMember, DEFAULT_ADMIN_MEMBERS, getAdminMembers, updateAdminMemberTitle, setAdminMemberStatus } from '../services/adminGroupService';
import { getAdminSelfGrants, AdminSelfGrantRecord, ADMIN_SELF_GRANTS_UPDATED_EVENT } from '../services/adminSelfGrantService';
import { ACCOUNT_STATUS_UPDATED_EVENT, DeletedAccountRecord, getDeletedAccounts } from '../utils/accountStatusStorage';
import { AdminGroupsTab } from './admin/AdminGroupsTab';
import { AdminGroupAssignModal } from './admin/AdminGroupAssignModal';
import { AdminLockConfirmModal } from './admin/AdminLockConfirmModal';
import { AdminJobTitleModal } from './admin/AdminJobTitleModal';
import { AdminEscalationConfirmModal } from './admin/AdminEscalationConfirmModal';

import { maskProtectedEmailForViewer, isEmailSearchableForViewer } from '../utils/privacyShield';
import {
  clearProfileReturnAnchor,
  getProfileReturnAnchor,
  setPendingProfileReturnAnchor,
} from '../utils/profileReturnState';
import { PresenceAvatarDot, PresenceStatusBadge } from './common/PresenceBadge';

interface SuperAdminPageProps {
  currentUser: AuthSession;
  onNavigateToAdmin?: () => void;
  onNavigateToVaults?: () => void;
  onNavigateToMarketplace?: () => void;
  onViewProfile?: (userId: string) => void;
}

export const SuperAdminPage: React.FC<SuperAdminPageProps> = ({
  currentUser,
  onViewProfile,
}) => {
  const { addToast, addNotification } = useApp();
  const initialAnchor = useMemo(() => {
    const a = getProfileReturnAnchor();
    if (a && a.superadminTab && a.restoreActive) {
      return a;
    }
    return null;
  }, []);

  const [searchQuery, setSearchQuery] = useState(initialAnchor?.superadminSearchTerm || '');
  const [adminTab, setAdminTab] = useState<'active' | 'locked' | 'deactivated' | 'deleted' | 'groups' | 'escalations' | 'grants_subsidies'>(() => {
    if (initialAnchor?.superadminTab) {
      return initialAnchor.superadminTab;
    }
    try {
      if (sessionStorage.getItem('final_finance_open_superadmin_grants') === '1') {
        sessionStorage.removeItem('final_finance_open_superadmin_grants');
        return 'grants_subsidies';
      }
    } catch {}
    return 'active';
  });
  const [adminSelfGrants, setAdminSelfGrants] = useState<AdminSelfGrantRecord[]>(() => getAdminSelfGrants());
  const [deletedAdmins, setDeletedAdmins] = useState<DeletedAccountRecord[]>(() => getDeletedAccounts('admin'));
  const pendingAnchorRef = useRef<string | null>(initialAnchor?.listingId || null);
  const savedScrollYRef = useRef<number | null>(
    typeof initialAnchor?.scrollY === 'number' ? initialAnchor.scrollY : null
  );
  const [highlightedAnchorId, setHighlightedAnchorId] = useState<string | null>(null);
  const [failedAvatars, setFailedAvatars] = useState<Record<string, boolean>>({});

  const resolveAdminAvatar = (admin: {
    id?: string;
    avatarUrl?: string;
    email?: string;
    handle?: string;
    userId?: string;
  }): string | undefined => {
    if (admin.avatarUrl) return admin.avatarUrl;
    const cleanEmail = (admin.email || '').trim().toLowerCase();
    const cleanHandle = (admin.handle || admin.userId || '').trim().toLowerCase().replace(/^@/, '');
    const defMatch = DEFAULT_ADMIN_MEMBERS.find(
      (d) =>
        (admin.id && d.id === admin.id) ||
        (cleanEmail && d.email.toLowerCase() === cleanEmail) ||
        (cleanHandle && d.handle.toLowerCase().replace(/^@/, '') === cleanHandle)
    );
    return defMatch?.avatarUrl;
  };

  const handleInspectAdminProfile = (targetHandleOrId: string, anchorId: string) => {
    if (!onViewProfile || !targetHandleOrId) return;
    const cleanTarget = targetHandleOrId.trim().replace(/^@/, '');
    setPendingProfileReturnAnchor({
      sourceLabel: 'Back to Superadmin',
      superadminTab: adminTab,
      superadminSearchTerm: searchQuery,
      listingId: anchorId,
      restoreActive: true,
      scrollY: window.scrollY,
    });
    onViewProfile(cleanTarget);
  };

  useEffect(() => {
    const syncGrants = () => setAdminSelfGrants(getAdminSelfGrants());
    const syncAccountStatuses = () => {
      setAdmins(getAdminMembers());
      setDeletedAdmins(getDeletedAccounts('admin'));
    };
    const openGrantsTab = () => {
      try { sessionStorage.removeItem('final_finance_open_superadmin_grants'); } catch {}
      setAdminTab('grants_subsidies');
      syncGrants();
    };
    window.addEventListener(ADMIN_SELF_GRANTS_UPDATED_EVENT, syncGrants);
    window.addEventListener(ACCOUNT_STATUS_UPDATED_EVENT, syncAccountStatuses);
    window.addEventListener('storage', syncGrants);
    window.addEventListener('storage', syncAccountStatuses);
    window.addEventListener('final_finance_open_superadmin_grants', openGrantsTab);
    return () => {
      window.removeEventListener(ADMIN_SELF_GRANTS_UPDATED_EVENT, syncGrants);
      window.removeEventListener(ACCOUNT_STATUS_UPDATED_EVENT, syncAccountStatuses);
      window.removeEventListener('storage', syncGrants);
      window.removeEventListener('storage', syncAccountStatuses);
      window.removeEventListener('final_finance_open_superadmin_grants', openGrantsTab);
    };
  }, []);
  
  const [adminGroups, setAdminGroupsList] = useState<AdminGroup[]>(() => getAdminGroups());
  const [selectedAdminForGrouping, setSelectedAdminForGrouping] = useState<AdminMember | null>(null);

  const [adminToLock, setAdminToLock] = useState<AdminMember | null>(null);
  const [adminForTitleEdit, setAdminForTitleEdit] = useState<AdminMember | null>(null);

  const refreshGroups = () => {
    setAdminGroupsList(getAdminGroups());
  };

  const [escalations, setEscalations] = useState<AdminEscalation[]>(() => getAdminEscalations());
  const [replyTexts, setReplyTexts] = useState<{[id: string]: string}>({});
  const [escalationActionConfirm, setEscalationActionConfirm] = useState<{
    escalation: AdminEscalation;
    targetStatus: 'investigating' | 'resolved';
  } | null>(null);

  const handleConfirmEscalationAction = () => {
    if (!escalationActionConfirm) return;
    const { escalation, targetStatus } = escalationActionConfirm;
    handleResolveEscalation(escalation.id, targetStatus);
    setEscalationActionConfirm(null);
  };

  const handleResolveEscalation = (id: string, status: AdminEscalation['status']) => {
    const reply = replyTexts[id] || '';
    const success = updateEscalationStatus(id, status, reply.trim() ? reply.trim() : undefined);
    if (success) {
      setEscalations(getAdminEscalations());
      addToast({
        type: 'success',
        title: 'Escalation Updated',
        message: `Escalation report status updated to ${status}.`,
      });
      // Register global system notification
      const targetEsc = escalations.find(e => e.id === id);
      const subjectLabel = targetEsc ? targetEsc.subject : 'System advisory';
      addNotification({
        title: `Advisory Status: ${status.toUpperCase()}`,
        description: `"${subjectLabel}" updated to [${status.toUpperCase()}] by Super Admin.`,
        type: 'system',
        targetTab: 'admin' // Redirect to Admin/SuperAdmin Page
      });
    }
  };

  const [admins, setAdmins] = useState<AdminMember[]>(() => getAdminMembers());

  // Restore exact tab scroll position & highlighted admin card when returning from a profile page
  useEffect(() => {
    const anchorId = pendingAnchorRef.current;
    if (!anchorId) return;
    let cancelled = false;
    const restoreExactFrame = (finalize: boolean) => {
      if (cancelled) return;
      const selector = `[data-superadmin-anchor="${anchorId.replace(/"/g, '\\"')}"]`;
      const el = document.querySelector(selector) as HTMLElement | null;
      const headerEl = document.querySelector('header');
      const headerHeight = headerEl ? headerEl.getBoundingClientRect().height : 65;

      if (savedScrollYRef.current !== null) {
        window.scrollTo({ top: savedScrollYRef.current, behavior: 'instant' as ScrollBehavior });
      }

      if (el) {
        const rect = el.getBoundingClientRect();
        const isOutsideViewport = rect.bottom < headerHeight + 8 || rect.top > window.innerHeight - 8;
        if (savedScrollYRef.current === null || isOutsideViewport) {
          const targetTop = Math.max(0, window.scrollY + rect.top - (headerHeight + 24));
          window.scrollTo({ top: targetTop, behavior: 'instant' as ScrollBehavior });
        }
        setHighlightedAnchorId(anchorId);
        if (finalize) {
          pendingAnchorRef.current = null;
          savedScrollYRef.current = null;
          clearProfileReturnAnchor();
          setTimeout(() => setHighlightedAnchorId(null), 1800);
        }
      }
    };
    const raf = requestAnimationFrame(() => restoreExactFrame(false));
    const t1 = window.setTimeout(() => restoreExactFrame(true), 90);
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      window.clearTimeout(t1);
    };
  }, [adminTab, admins, deletedAdmins, adminGroups, escalations, adminSelfGrants]);

  const handleInitiateLock = (admin: AdminMember) => {
    setAdminToLock(admin);
  };

  const handleConfirmLock = () => {
    if (!adminToLock) return;
    const updated = setAdminMemberStatus(adminToLock.id, 'locked');
    setAdmins(updated);
    addToast({
      type: 'error',
      title: 'Admin Locked',
      message: `Account for ${adminToLock.name} has been locked.`,
    });
    setAdminToLock(null);
  };

  const handleUnlock = (admin: AdminMember) => {
    const updated = setAdminMemberStatus(admin.id, 'active');
    setAdmins(updated);
    addToast({
      type: 'success',
      title: 'Admin Unlocked',
      message: `Account for ${admin.name} has been unlocked.`,
    });
  };

  const handleReactivate = (admin: AdminMember) => {
    const updated = setAdminMemberStatus(admin.id, 'active');
    setAdmins(updated);
    addToast({
      type: 'success',
      title: 'Admin Reactivated',
      message: `Account for ${admin.name} has been successfully reactivated.`,
    });
  };

  const handleSaveJobTitle = (title: string) => {
    if (!adminForTitleEdit) return;
    const updated = updateAdminMemberTitle(adminForTitleEdit.id, title);
    setAdmins(updated);
    addToast({
      type: 'success',
      title: 'Job Title Updated',
      message: `Job title for ${adminForTitleEdit.name} set to "${title}".`,
    });
    setAdminForTitleEdit(null);
  };

  const filteredAdmins = admins.filter(
    (adm) =>
      adm.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      adm.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (isEmailSearchableForViewer(adm.email, currentUser?.email) &&
        adm.email.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const activeAdmins = filteredAdmins.filter((a) => a.status === 'active');
  const lockedAdmins = filteredAdmins.filter((a) => a.status === 'locked');
  const deactivatedAdmins = filteredAdmins.filter((a) => a.status === 'deactivated');
  const filteredDeletedAdmins = deletedAdmins.filter((adm) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      adm.name.toLowerCase().includes(q) ||
      adm.userId.toLowerCase().includes(q) ||
      (adm.email &&
        isEmailSearchableForViewer(adm.email, currentUser?.email) &&
        adm.email.toLowerCase().includes(q)) ||
      (adm.jobTitle && adm.jobTitle.toLowerCase().includes(q))
    );
  });

  const activeCount = admins.filter((a) => a.status === 'active').length;
  const deactivatedCount = admins.filter((a) => a.status === 'deactivated').length;
  const filteredAdminSelfGrants = adminSelfGrants
    .filter((g) => {
      const q = searchQuery.trim().toLowerCase();
      if (!q) return true;
      return (
        g.adminName.toLowerCase().includes(q) ||
        g.adminHandle.toLowerCase().includes(q) ||
        (isEmailSearchableForViewer(g.adminEmail, currentUser?.email) &&
          g.adminEmail.toLowerCase().includes(q)) ||
        g.grantName.toLowerCase().includes(q) ||
        g.description.toLowerCase().includes(q)
      );
    })
    .sort((a, b) => new Date(b.timestampIso || b.date).getTime() - new Date(a.timestampIso || a.date).getTime());

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-16 font-sans">
      {/* Header Banner - Compact & Clean */}
      <div className="border-b border-slate-200 bg-white shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 sm:py-4">
          <div className="flex flex-col items-center justify-center gap-1.5 text-center">
            {/* Centered Title */}
            <div className="flex items-center justify-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 shadow-xs shrink-0">
                <Crown className="w-5 h-5 stroke-[2.2]" />
              </div>
              <h1 className="font-serif text-lg sm:text-xl font-bold text-slate-900 tracking-tight text-center">
                Super Admin Control
              </h1>
            </div>

            {/* Centered Email Directly Beneath Title */}
            <p className="text-xs font-mono text-amber-600 font-semibold text-center break-all">
              {currentUser?.email || 'Super Admin Session'}
            </p>
          </div>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 sm:mt-5 space-y-4">
        {/* Search & Tabs Bar (Compact & Centered) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3 sm:p-4 flex flex-col items-center justify-center gap-2.5 shadow-xs text-center">
          <div className="relative w-full max-w-md mx-auto">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                adminTab === 'grants_subsidies'
                  ? 'Search self-granted subsidies by admin or title...'
                  : adminTab === 'groups'
                  ? 'Search in admin directory...'
                  : 'Search admins by name, email, or handle...'
              }
              className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-center text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 transition-colors"
            />
          </div>

          {/* Compact Centered Tabs */}
          <div className="inline-flex flex-wrap items-center justify-center gap-1 p-1 rounded-xl bg-slate-100/80 border border-slate-200/80 max-w-full">
            <button
              type="button"
              onClick={() => setAdminTab('active')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                adminTab === 'active'
                  ? 'bg-emerald-50 text-emerald-900 border border-emerald-300 shadow-2xs'
                  : 'text-slate-700 border border-transparent hover:bg-white/80'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
              <span>Active</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold tabular-nums ${
                adminTab === 'active' ? 'bg-emerald-200/80 text-emerald-900' : 'bg-slate-200/70 text-slate-700'
              }`}>
                {activeAdmins.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('locked')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                adminTab === 'locked'
                  ? 'bg-amber-50 text-amber-900 border border-amber-300 shadow-2xs'
                  : 'text-slate-700 border border-transparent hover:bg-white/80'
              }`}
            >
              <Lock className="w-3 h-3 text-amber-600 shrink-0" />
              <span>Lock</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold tabular-nums ${
                adminTab === 'locked' ? 'bg-amber-200/80 text-amber-900' : 'bg-slate-200/70 text-slate-700'
              }`}>
                {lockedAdmins.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('deactivated')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                adminTab === 'deactivated'
                  ? 'bg-rose-50 text-rose-900 border border-rose-300 shadow-2xs'
                  : 'text-slate-700 border border-transparent hover:bg-white/80'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
              <span>Deactivated</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold tabular-nums ${
                adminTab === 'deactivated' ? 'bg-rose-200/80 text-rose-900' : 'bg-slate-200/70 text-slate-700'
              }`}>
                {deactivatedAdmins.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('deleted')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                adminTab === 'deleted'
                  ? 'bg-red-50 text-red-900 border border-red-300 shadow-2xs'
                  : 'text-slate-700 border border-transparent hover:bg-white/80'
              }`}
            >
              <Trash2 className="w-3 h-3 text-red-600 shrink-0" />
              <span>Delete</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold tabular-nums ${
                adminTab === 'deleted' ? 'bg-red-200/80 text-red-900' : 'bg-slate-200/70 text-slate-700'
              }`}>
                {filteredDeletedAdmins.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('groups')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                adminTab === 'groups'
                  ? 'bg-indigo-50 text-indigo-950 border border-indigo-300 shadow-2xs'
                  : 'text-slate-700 border border-transparent hover:bg-white/80'
              }`}
            >
              <FolderHeart className="w-3 h-3 text-indigo-600 shrink-0" />
              <span>Groups</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold tabular-nums ${
                adminTab === 'groups' ? 'bg-indigo-200/80 text-indigo-900' : 'bg-slate-200/70 text-slate-700'
              }`}>
                {adminGroups.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('escalations')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                adminTab === 'escalations'
                  ? 'bg-amber-50 text-amber-950 border border-amber-300 shadow-2xs'
                  : 'text-slate-700 border border-transparent hover:bg-white/80'
              }`}
            >
              <Crown className="w-3 h-3 text-amber-500 shrink-0" />
              <span>Advisories</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold tabular-nums ${
                adminTab === 'escalations' ? 'bg-amber-200/80 text-amber-950' : 'bg-slate-200/70 text-slate-700'
              }`}>
                {escalations.filter(e => e.status === 'pending').length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('grants_subsidies')}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                adminTab === 'grants_subsidies'
                  ? 'bg-emerald-50 text-emerald-950 border border-emerald-300 shadow-2xs'
                  : 'text-slate-700 border border-transparent hover:bg-white/80'
              }`}
            >
              <Coins className="w-3 h-3 text-amber-600 shrink-0" />
              <span>Grants &amp; Subsidies</span>
              <span className={`px-1.5 py-0.2 rounded text-[11px] font-mono font-bold tabular-nums ${
                adminTab === 'grants_subsidies' ? 'bg-emerald-200/80 text-emerald-950' : 'bg-slate-200/70 text-slate-700'
              }`}>
                {adminSelfGrants.length}
              </span>
            </button>
          </div>
        </div>

        {/* Active Tab Content */}
        {adminTab === 'active' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-4 sm:px-6 py-4 border-b border-slate-200 flex flex-col items-center justify-center gap-2 bg-emerald-50/40 text-center">
              <div className="flex items-center justify-center gap-2 max-w-full flex-wrap">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                <h2 className="font-serif text-base font-bold text-slate-900 text-center">Active Administrators</h2>
              </div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-100/80 px-2.5 py-1 rounded-full border border-emerald-200">
                {activeAdmins.length} {activeAdmins.length === 1 ? 'Member' : 'Members'}
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {activeAdmins.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  No active admin members found matching "{searchQuery}"
                </div>
              ) : (
                activeAdmins.map((admin) => {
                  const anchorId = `sa-active-${admin.id}`;
                  const isHighlighted = highlightedAnchorId === anchorId;
                  const avatarSrc = resolveAdminAvatar(admin);
                  const showImg = Boolean(avatarSrc && !failedAvatars[`active-${admin.id}`]);
                  const profileKey = admin.handle || admin.email || admin.id;

                  return (
                  <div
                    key={admin.id}
                    data-superadmin-anchor={anchorId}
                    className={`p-4 sm:p-6 flex flex-col items-center justify-center text-center gap-4 transition-all ${
                      isHighlighted
                        ? 'bg-blue-50/40 ring-4 ring-blue-500 ring-inset'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    <div className="flex flex-col items-center justify-center text-center gap-3">
                      <button
                        type="button"
                        onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                        className={`relative rounded-2xl focus:outline-none group/avatar shrink-0 ${
                          onViewProfile ? 'cursor-pointer' : 'cursor-default'
                        }`}
                        title={onViewProfile ? `View ${admin.name}'s profile` : admin.name}
                      >
                        {showImg ? (
                          <img
                            src={avatarSrc}
                            alt={admin.name}
                            referrerPolicy="no-referrer"
                            onError={() =>
                              setFailedAvatars((prev) => ({ ...prev, [`active-${admin.id}`]: true }))
                            }
                            className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-200 shadow-xs group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 group-hover/avatar:scale-105 transition-all"
                          />
                        ) : (
                          <div className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold font-serif text-base border shrink-0 bg-amber-50 text-amber-700 border-amber-200 group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 transition-all">
                            {admin.name.charAt(0)}
                          </div>
                        )}
                        <PresenceAvatarDot
                          identifiers={[admin.id, admin.handle, admin.email]}
                          forceOffline={admin.status !== 'active'}
                          size="md"
                        />
                      </button>

                      <div className="space-y-1.5 flex flex-col items-center justify-center text-center">
                        <div className="flex items-center justify-center gap-2 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                            className={`inline-flex items-center gap-2 flex-wrap justify-center ${
                              onViewProfile ? 'cursor-pointer hover:opacity-80' : 'cursor-default'
                            }`}
                            title={onViewProfile ? `Open ${admin.name}'s profile page` : undefined}
                          >
                            <span className="font-bold text-sm text-slate-900 hover:text-amber-700 transition-colors">{admin.name}</span>
                            <span className="font-mono text-xs text-amber-600">{admin.handle}</span>
                          </button>
                          
                          {/* System Role + Status kept together on the same line */}
                          <span className="inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 flex-nowrap">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border whitespace-nowrap ${
                              admin.role === 'super_admin'
                                ? 'bg-amber-50 text-amber-800 border-amber-200'
                                : 'bg-blue-50 text-blue-700 border-blue-200'
                            }`}>
                              {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                            </span>

                            {admin.status === 'locked' ? (
                              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-200 inline-flex items-center gap-1 whitespace-nowrap">
                                <Lock className="w-2.5 h-2.5" />
                                <span>Locked</span>
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 whitespace-nowrap">
                                Active
                              </span>
                            )}
                          </span>

                          <PresenceStatusBadge
                            identifiers={[admin.id, admin.handle, admin.email]}
                            forceOffline={admin.status !== 'active'}
                            size="xs"
                          />
                        </div>

                        <div className="flex items-center justify-center gap-2 text-xs text-slate-500 flex-wrap text-center">
                          <span className="flex items-center justify-center gap-1">
                            <Mail className="w-3.5 h-3.5 text-slate-400" />
                            {maskProtectedEmailForViewer(admin.email, currentUser?.email)}
                          </span>
                          <span>•</span>
                          <span>Last Active: {admin.lastActive}</span>
                        </div>

                        {/* Assigned Admin Groups */}
                        {(() => {
                          const assigned = adminGroups.filter((g) => g.adminIds.includes(admin.id));
                          if (assigned.length === 0) return null;
                          return (
                            <div className="flex items-center justify-center gap-1.5 flex-wrap pt-1">
                              <span className="text-[10px] font-mono text-slate-400">Groups:</span>
                              {assigned.map((g) => {
                                const secondaryTitle = g.memberSecondaryTitles?.[admin.id];
                                return (
                                  <span
                                    key={g.id}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border"
                                    style={{
                                      backgroundColor: `${g.color}15`,
                                      borderColor: `${g.color}40`,
                                      color: g.color,
                                    }}
                                  >
                                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: g.color }} />
                                    <span>{g.name}</span>
                                    {secondaryTitle && (
                                      <span className="font-medium opacity-90 text-[9px] border-l pl-1 border-current ml-0.5">
                                        {secondaryTitle}
                                      </span>
                                    )}
                                  </span>
                                );
                              })}
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    {/* Actions: Group and Deactivate side-by-side, centered */}
                    <div className="flex items-center justify-center gap-2 shrink-0">
                      {/* Group Assignment Button */}
                      <button
                        type="button"
                        onClick={() => setSelectedAdminForGrouping(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 hover:border-indigo-200 shrink-0"
                        title="Assign to groups (can belong to multiple groups)"
                      >
                        <FolderHeart className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Group</span>
                        {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length > 0 && (
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-mono font-bold leading-none">
                            {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length}
                          </span>
                        )}
                      </button>

                      {admin.role === 'super_admin' ? (
                        <span className="text-[11px] text-amber-700 font-semibold italic px-3 py-1.5 bg-amber-50 rounded-xl border border-amber-200 shrink-0 flex items-center justify-center text-center">
                          Root Authority Protected
                        </span>
                      ) : admin.status === 'locked' ? (
                        <button
                          type="button"
                          onClick={() => handleUnlock(admin)}
                          className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-600 shrink-0"
                          title="Unlock admin account and restore access"
                        >
                          <Unlock className="w-3.5 h-3.5" />
                          <span>Unlock</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleInitiateLock(admin)}
                          className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 shrink-0"
                          title="Lock admin account (requires confirmation)"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Lock</span>
                        </button>
                      )}
                    </div>
                  </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Lock Tab Content */}
        {adminTab === 'locked' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-4 sm:px-6 py-4 border-b border-slate-200 flex flex-col items-center justify-center gap-2 bg-amber-50/40 text-center">
              <div className="flex items-center justify-center gap-2 max-w-full flex-wrap">
                <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                <h2 className="font-serif text-base font-bold text-slate-900 text-center">Locked Administrators</h2>
              </div>
              <span className="text-xs font-bold text-amber-800 bg-amber-100/80 px-2.5 py-1 rounded-full border border-amber-200">
                {lockedAdmins.length} {lockedAdmins.length === 1 ? 'Member' : 'Members'}
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {lockedAdmins.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  {admins.filter((a) => a.status === 'locked').length === 0
                    ? 'No administrators have been locked by the Super Admin.'
                    : `No locked admin accounts found matching "${searchQuery}"`}
                </div>
              ) : (
                lockedAdmins.map((admin) => {
                  const anchorId = `sa-locked-${admin.id}`;
                  const isHighlighted = highlightedAnchorId === anchorId;
                  const avatarSrc = resolveAdminAvatar(admin);
                  const showImg = Boolean(avatarSrc && !failedAvatars[`locked-${admin.id}`]);
                  const profileKey = admin.handle || admin.email || admin.id;

                  return (
                  <div
                    key={admin.id}
                    data-superadmin-anchor={anchorId}
                    className={`p-4 sm:p-6 flex flex-col items-center justify-center text-center gap-4 transition-all ${
                      isHighlighted
                        ? 'bg-blue-50/40 ring-4 ring-blue-500 ring-inset'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    <div className="flex flex-col items-center justify-center text-center gap-3">
                      <button
                        type="button"
                        onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                        className={`relative rounded-2xl focus:outline-none group/avatar shrink-0 ${
                          onViewProfile ? 'cursor-pointer' : 'cursor-default'
                        }`}
                        title={onViewProfile ? `View ${admin.name}'s profile` : admin.name}
                      >
                        {showImg ? (
                          <img
                            src={avatarSrc}
                            alt={admin.name}
                            referrerPolicy="no-referrer"
                            onError={() =>
                              setFailedAvatars((prev) => ({ ...prev, [`locked-${admin.id}`]: true }))
                            }
                            className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-200 shadow-xs group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 group-hover/avatar:scale-105 transition-all"
                          />
                        ) : (
                          <div className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold font-serif text-base border shrink-0 bg-amber-50 text-amber-700 border-amber-200 group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 transition-all">
                            {admin.name.charAt(0)}
                          </div>
                        )}
                        <PresenceAvatarDot
                          identifiers={[admin.id, admin.handle, admin.email]}
                          forceOffline
                          size="md"
                        />
                      </button>

                      <div className="space-y-1.5 flex flex-col items-center justify-center text-center">
                        <div className="flex items-center justify-center gap-2 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                            className={`inline-flex items-center gap-2 flex-wrap justify-center ${
                              onViewProfile ? 'cursor-pointer hover:opacity-80' : 'cursor-default'
                            }`}
                            title={onViewProfile ? `Open ${admin.name}'s profile page` : undefined}
                          >
                            <span className="font-bold text-sm text-slate-900 hover:text-amber-700 transition-colors">{admin.name}</span>
                            <span className="font-mono text-xs text-amber-600">{admin.handle}</span>
                          </button>
                          <span className="inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 flex-nowrap">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border whitespace-nowrap ${
                              admin.role === 'super_admin'
                                ? 'bg-amber-50 text-amber-800 border-amber-200'
                                : 'bg-blue-50 text-blue-700 border-blue-200'
                            }`}>
                              {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                            </span>
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-200 inline-flex items-center gap-1 whitespace-nowrap">
                              <Lock className="w-2.5 h-2.5" />
                              <span>Locked</span>
                            </span>
                          </span>
                          <PresenceStatusBadge
                            identifiers={[admin.id, admin.handle, admin.email]}
                            forceOffline
                            size="xs"
                          />
                        </div>

                        <div className="flex items-center justify-center gap-2 text-xs text-slate-500 flex-wrap text-center">
                          <span className="flex items-center justify-center gap-1">
                            <Mail className="w-3.5 h-3.5 text-slate-400" />
                            {maskProtectedEmailForViewer(admin.email, currentUser?.email)}
                          </span>
                          <span>•</span>
                          <span>Last Active: {admin.lastActive}</span>
                        </div>

                        {(() => {
                          const assigned = adminGroups.filter((g) => g.adminIds.includes(admin.id));
                          if (assigned.length === 0) return null;
                          return (
                            <div className="flex items-center justify-center gap-1.5 flex-wrap pt-1">
                              <span className="text-[10px] font-mono text-slate-400">Groups:</span>
                              {assigned.map((g) => {
                                const secondaryTitle = g.memberSecondaryTitles?.[admin.id];
                                return (
                                  <span
                                    key={g.id}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border"
                                    style={{
                                      backgroundColor: `${g.color}15`,
                                      borderColor: `${g.color}40`,
                                      color: g.color,
                                    }}
                                  >
                                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: g.color }} />
                                    <span>{g.name}</span>
                                    {secondaryTitle && (
                                      <span className="font-medium opacity-90 text-[9px] border-l pl-1 border-current ml-0.5">
                                        {secondaryTitle}
                                      </span>
                                    )}
                                  </span>
                                );
                              })}
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setSelectedAdminForGrouping(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 hover:border-indigo-200 shrink-0"
                        title="Assign to groups (can belong to multiple groups)"
                      >
                        <FolderHeart className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Group</span>
                        {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length > 0 && (
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-mono font-bold leading-none">
                            {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length}
                          </span>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleUnlock(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-600 shrink-0"
                        title="Unlock admin account and restore access"
                      >
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Unlock</span>
                      </button>
                    </div>
                  </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Deactivated Tab Content */}
        {adminTab === 'deactivated' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-4 sm:px-6 py-4 border-b border-slate-200 flex flex-col items-center justify-center gap-2 bg-rose-50/40 text-center">
              <div className="flex items-center justify-center gap-2 max-w-full flex-wrap">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
                <h2 className="font-serif text-base font-bold text-slate-900 text-center">Self-Deactivated Administrators (From Settings)</h2>
              </div>
              <span className="text-xs font-bold text-rose-700 bg-rose-100/80 px-2.5 py-1 rounded-full border border-rose-200">
                {deactivatedAdmins.length} {deactivatedAdmins.length === 1 ? 'Member' : 'Members'}
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {deactivatedAdmins.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  {admins.filter((a) => a.status === 'deactivated').length === 0
                    ? 'No administrators have deactivated their account from Settings.'
                    : `No deactivated admin accounts found matching "${searchQuery}"`}
                </div>
              ) : (
                deactivatedAdmins.map((admin) => {
                  const anchorId = `sa-deactivated-${admin.id}`;
                  const isHighlighted = highlightedAnchorId === anchorId;
                  const avatarSrc = resolveAdminAvatar(admin);
                  const showImg = Boolean(avatarSrc && !failedAvatars[`deac-${admin.id}`]);
                  const profileKey = admin.handle || admin.email || admin.id;

                  return (
                  <div
                    key={admin.id}
                    data-superadmin-anchor={anchorId}
                    className={`p-4 sm:p-6 flex flex-col items-center justify-center text-center gap-4 transition-all opacity-95 ${
                      isHighlighted
                        ? 'bg-blue-50/40 ring-4 ring-blue-500 ring-inset'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    <div className="flex flex-col items-center justify-center text-center gap-3">
                      <button
                        type="button"
                        onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                        className={`relative rounded-2xl focus:outline-none group/avatar shrink-0 ${
                          onViewProfile ? 'cursor-pointer' : 'cursor-default'
                        }`}
                        title={onViewProfile ? `View ${admin.name}'s profile` : admin.name}
                      >
                        {showImg ? (
                          <img
                            src={avatarSrc}
                            alt={admin.name}
                            referrerPolicy="no-referrer"
                            onError={() =>
                              setFailedAvatars((prev) => ({ ...prev, [`deac-${admin.id}`]: true }))
                            }
                            className="w-14 h-14 rounded-2xl object-cover border border-slate-200 opacity-85 group-hover/avatar:opacity-100 group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 group-hover/avatar:scale-105 transition-all"
                          />
                        ) : (
                          <div className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold font-serif text-base border shrink-0 bg-slate-100 text-slate-400 border-slate-200 group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 transition-all">
                            {admin.name.charAt(0)}
                          </div>
                        )}
                        <PresenceAvatarDot
                          identifiers={[admin.id, admin.handle, admin.email]}
                          forceOffline
                          size="md"
                        />
                      </button>

                      <div className="space-y-1.5 flex flex-col items-center justify-center text-center">
                        <div className="flex items-center justify-center gap-2 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                            className={`inline-flex items-center gap-2 flex-wrap justify-center ${
                              onViewProfile ? 'cursor-pointer hover:opacity-80' : 'cursor-default'
                            }`}
                            title={onViewProfile ? `Open ${admin.name}'s profile page` : undefined}
                          >
                            <span className="font-bold text-sm text-slate-900 hover:text-amber-700 transition-colors">{admin.name}</span>
                            <span className="font-mono text-xs text-slate-500">{admin.handle}</span>
                          </button>
                          <span className="inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 flex-nowrap">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border whitespace-nowrap ${
                              admin.role === 'super_admin'
                                ? 'bg-amber-50 text-amber-800 border-amber-200'
                                : 'bg-slate-100 text-slate-600 border-slate-200'
                            }`}>
                              {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                            </span>

                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-200 whitespace-nowrap">
                              Deactivated
                            </span>
                          </span>
                          <PresenceStatusBadge
                            identifiers={[admin.id, admin.handle, admin.email]}
                            forceOffline
                            size="xs"
                          />
                        </div>

                        <div className="flex items-center justify-center gap-2 text-xs text-slate-500 flex-wrap text-center">
                          <span className="flex items-center justify-center gap-1">
                            <Mail className="w-3.5 h-3.5 text-slate-400" />
                            {maskProtectedEmailForViewer(admin.email, currentUser?.email)}
                          </span>
                          <span>•</span>
                          <span>Last Active: {admin.lastActive}</span>
                        </div>

                        {/* Assigned Admin Groups */}
                        {(() => {
                          const assigned = adminGroups.filter((g) => g.adminIds.includes(admin.id));
                          if (assigned.length === 0) return null;
                          return (
                            <div className="flex items-center justify-center gap-1.5 flex-wrap pt-1">
                              <span className="text-[10px] font-mono text-slate-400">Groups:</span>
                              {assigned.map((g) => {
                                const secondaryTitle = g.memberSecondaryTitles?.[admin.id];
                                return (
                                  <span
                                    key={g.id}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border"
                                    style={{
                                      backgroundColor: `${g.color}15`,
                                      borderColor: `${g.color}40`,
                                      color: g.color,
                                    }}
                                  >
                                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: g.color }} />
                                    <span>{g.name}</span>
                                    {secondaryTitle && (
                                      <span className="font-medium opacity-90 text-[9px] border-l pl-1 border-current ml-0.5">
                                        {secondaryTitle}
                                      </span>
                                    )}
                                  </span>
                                );
                              })}
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    {/* Actions: Group and Reactivate side-by-side, centered */}
                    <div className="flex items-center justify-center gap-2 shrink-0">
                      {/* Group Assignment Button */}
                      <button
                        type="button"
                        onClick={() => setSelectedAdminForGrouping(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 hover:border-indigo-200 shrink-0"
                        title="Assign to groups (can belong to multiple groups)"
                      >
                        <FolderHeart className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Group</span>
                        {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length > 0 && (
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-mono font-bold leading-none">
                            {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length}
                          </span>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleReactivate(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 shrink-0"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Reactivate</span>
                      </button>
                    </div>
                  </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Delete Tab Content: Self-Deleted Admins from Settings */}
        {adminTab === 'deleted' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-4 sm:px-6 py-4 border-b border-slate-200 flex flex-col items-center justify-center gap-2 bg-red-50/40 text-center">
              <div className="flex items-center justify-center gap-2 max-w-full flex-wrap">
                <Trash2 className="w-4 h-4 text-red-600 shrink-0" />
                <h2 className="font-serif text-base font-bold text-slate-900 text-center">Deleted Administrator Profiles (From Settings)</h2>
              </div>
              <span className="text-xs font-bold text-red-700 bg-red-100/80 px-2.5 py-1 rounded-full border border-red-200">
                {filteredDeletedAdmins.length} {filteredDeletedAdmins.length === 1 ? 'Profile' : 'Profiles'}
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {filteredDeletedAdmins.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  {deletedAdmins.length === 0
                    ? 'No administrator profiles have been deleted from Settings.'
                    : `No deleted admin profiles found matching "${searchQuery}"`}
                </div>
              ) : (
                filteredDeletedAdmins.map((admin) => {
                  const anchorId = `sa-deleted-${admin.id}`;
                  const isHighlighted = highlightedAnchorId === anchorId;
                  const avatarSrc = resolveAdminAvatar(admin);
                  const showImg = Boolean(avatarSrc && !failedAvatars[`del-${admin.id}`]);
                  const profileKey = admin.userId || admin.email || admin.id;

                  return (
                  <div
                    key={admin.id}
                    data-superadmin-anchor={anchorId}
                    className={`p-4 sm:p-6 flex flex-col items-center justify-center text-center gap-3 transition-all ${
                      isHighlighted
                        ? 'bg-blue-50/40 ring-4 ring-blue-500 ring-inset'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                      className={`relative rounded-2xl focus:outline-none group/avatar shrink-0 ${
                        onViewProfile ? 'cursor-pointer' : 'cursor-default'
                      }`}
                      title={onViewProfile ? `View ${admin.name}'s profile` : admin.name}
                    >
                      {showImg ? (
                        <img
                          src={avatarSrc}
                          alt={admin.name}
                          referrerPolicy="no-referrer"
                          onError={() =>
                            setFailedAvatars((prev) => ({ ...prev, [`del-${admin.id}`]: true }))
                          }
                          className="w-14 h-14 rounded-2xl object-cover border border-slate-200 opacity-85 group-hover/avatar:opacity-100 group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 group-hover/avatar:scale-105 transition-all"
                        />
                      ) : (
                        <div className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold font-serif text-base border shrink-0 bg-slate-100 text-slate-400 border-slate-200 group-hover/avatar:ring-4 group-hover/avatar:ring-amber-400/40 transition-all">
                          {admin.name.charAt(0)}
                        </div>
                      )}
                      <PresenceAvatarDot
                        identifiers={[admin.id, admin.userId, admin.email]}
                        forceOffline
                        size="md"
                      />
                    </button>

                    <div className="space-y-1.5 flex flex-col items-center justify-center text-center">
                      <div className="flex items-center justify-center gap-2 flex-wrap">
                        <button
                          type="button"
                          onClick={() => handleInspectAdminProfile(profileKey, anchorId)}
                          className={`inline-flex items-center gap-2 flex-wrap justify-center ${
                            onViewProfile ? 'cursor-pointer hover:opacity-80' : 'cursor-default'
                          }`}
                          title={onViewProfile ? `Open ${admin.name}'s profile page` : undefined}
                        >
                          <span className="font-bold text-sm text-slate-900 hover:text-amber-700 transition-colors">{admin.name}</span>
                          <span className="font-mono text-xs text-slate-500">@{admin.userId}</span>
                        </button>
                        <span className="inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 flex-nowrap">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border whitespace-nowrap ${
                            admin.role === 'super_admin'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}>
                            {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-red-50 text-red-700 border border-red-200 inline-flex items-center gap-1 whitespace-nowrap">
                            <Trash2 className="w-2.5 h-2.5" />
                            <span>Deleted in Settings</span>
                          </span>
                        </span>
                        <PresenceStatusBadge
                          identifiers={[admin.id, admin.userId, admin.email]}
                          forceOffline
                          size="xs"
                        />
                      </div>

                      <div className="flex items-center justify-center gap-3 text-xs text-slate-500 flex-wrap text-center">
                        {admin.email && (
                          <span className="flex items-center justify-center gap-1">
                            <Mail className="w-3.5 h-3.5 text-slate-400" />
                            {maskProtectedEmailForViewer(admin.email, currentUser?.email)}
                          </span>
                        )}
                        {admin.jobTitle && (
                          <>
                            <span>•</span>
                            <span>{admin.jobTitle}</span>
                          </>
                        )}
                        <span>•</span>
                        <span className="flex items-center justify-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          Deleted: {new Date(admin.deletedAt).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Tab: Groups (under deactivated, but before advisories) */}
        {adminTab === 'groups' && (
          <AdminGroupsTab
            groups={adminGroups}
            allAdmins={admins}
            onRefresh={refreshGroups}
            onToast={addToast}
            onViewAdminProfile={handleInspectAdminProfile}
            highlightedAnchorId={highlightedAnchorId}
          />
        )}

        {/* Tab: Escalation Reports (Centered) */}
        {adminTab === 'escalations' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs text-center">
            <div className="px-6 py-4 border-b border-slate-200 flex flex-col items-center justify-center gap-2 bg-amber-50/40 text-center">
              <div className="flex items-center justify-center gap-2">
                <Crown className="w-5 h-5 text-amber-500" />
                <h2 className="font-serif text-base font-bold text-slate-900 text-center">Priority Admin Escalations</h2>
              </div>
              <span className="text-xs font-bold text-amber-700 bg-amber-100/80 px-2.5 py-1 rounded-full border border-amber-200">
                {escalations.length} Active Bulletins
              </span>
            </div>

            <div className="p-6 space-y-6 bg-slate-50/30 flex flex-col items-center">
              {escalations.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No active admin escalations logged.
                </div>
              ) : (
                escalations.map((esc) => {
                  const anchorId = `sa-escalations-${esc.id}`;
                  const isHighlighted = highlightedAnchorId === anchorId;
                  return (
                  <div
                    key={esc.id}
                    data-superadmin-anchor={anchorId}
                    className={`w-full max-w-3xl mx-auto p-5 sm:p-6 rounded-2xl border bg-white transition-all space-y-4 text-center ${
                      isHighlighted ? 'border-blue-400 ring-4 ring-blue-500' : 'border-slate-200 hover:shadow-2xs'
                    }`}
                  >
                    <div className="flex flex-col items-center justify-center gap-2 text-center">
                      <div className="flex items-center justify-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900">{esc.subject}</span>
                        <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                          esc.severity === 'critical' ? 'bg-red-100 text-red-800' :
                          esc.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                          esc.severity === 'medium' ? 'bg-amber-100 text-amber-800' :
                          'bg-slate-100 text-slate-800'
                        }`}>
                          {esc.severity}
                        </span>
                        <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                          esc.status === 'resolved' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                          esc.status === 'investigating' ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' :
                          'bg-amber-100 text-amber-800 border border-amber-200'
                        }`}>
                          {esc.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 text-center">
                        Escalated by{' '}
                        <button
                          type="button"
                          onClick={() => handleInspectAdminProfile(esc.adminEmail || esc.adminName, anchorId)}
                          className={`font-semibold text-slate-700 hover:text-amber-700 underline-offset-2 ${
                            onViewProfile ? 'hover:underline cursor-pointer' : 'cursor-default'
                          }`}
                        >
                          {esc.adminName}
                        </button>{' '}
                        ({maskProtectedEmailForViewer(esc.adminEmail, currentUser?.email)}) • {new Date(esc.timestamp).toLocaleString()}
                      </p>
                      <span className="text-xs font-mono text-slate-500 font-bold bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 inline-block">
                        {esc.id}
                      </span>
                    </div>

                    <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl text-center">
                      <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap font-sans text-center">{esc.message}</p>
                    </div>

                    {/* Action Panel for Super Admin to respond */}
                    <div className="pt-3 border-t border-slate-100 space-y-3 text-center">
                      <div>
                        {esc.status === 'resolved' ? (
                          <div className="space-y-3 text-center">
                            {(esc.investigatingNotes || esc.resolvedNotes || esc.superAdminNotes) ? (
                              <>
                                {esc.investigatingNotes && (
                                  <div className="space-y-1 text-center">
                                    <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider text-center">Investigating Response</label>
                                    <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl text-center">
                                      <p className="text-xs text-slate-700 italic text-center">"{esc.investigatingNotes}"</p>
                                    </div>
                                  </div>
                                )}
                                {esc.resolvedNotes && (
                                  <div className="space-y-1 text-center">
                                    <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider text-center">Resolution Notes</label>
                                    <div className="p-3 bg-emerald-50/50 border border-emerald-100 rounded-xl text-center">
                                      <p className="text-xs text-slate-700 italic text-center">"{esc.resolvedNotes}"</p>
                                    </div>
                                  </div>
                                )}
                                {esc.superAdminNotes && !esc.investigatingNotes && !esc.resolvedNotes && (
                                  <div className="space-y-1 text-center">
                                    <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider text-center">Super Admin Response</label>
                                    <div className="p-3 bg-amber-50/50 border border-amber-100 rounded-xl text-center">
                                      <p className="text-xs text-slate-700 italic text-center">"{esc.superAdminNotes}"</p>
                                    </div>
                                  </div>
                                )}
                              </>
                            ) : (
                              <div className="space-y-1 text-center">
                                <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider text-center">Cryptographic Response / Resolving Notes</label>
                                <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-center">
                                  <p className="text-xs text-slate-400 italic text-center">No notes added.</p>
                                </div>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="space-y-4 text-center">
                            {esc.investigatingNotes && (
                              <div className="space-y-1 text-center">
                                <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider text-center">Investigating Response Sent</label>
                                <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl text-center">
                                  <p className="text-xs text-slate-700 italic text-center">"{esc.investigatingNotes}"</p>
                                </div>
                              </div>
                            )}

                            {/* "Mark as Investigating" centered above the written response box */}
                            {esc.status !== 'investigating' && (
                              <div className="flex justify-center">
                                <button
                                  type="button"
                                  onClick={() => setEscalationActionConfirm({ escalation: esc, targetStatus: 'investigating' })}
                                  className="px-5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
                                >
                                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-ping"></span>
                                  <span>Mark as Investigating</span>
                                </button>
                              </div>
                            )}

                            {/* Written Response Input Box (Centered) */}
                            <div className="space-y-1.5 text-center">
                              <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider text-center">Resolving Response / Notes (Saved automatically on status transition)</label>
                              <input
                                type="text"
                                value={replyTexts[esc.id] || ''}
                                onChange={(e) => setReplyTexts(prev => ({ ...prev, [esc.id]: e.target.value }))}
                                placeholder="Write instructions, authorization codes, Swiss sweep overrides, or resolution details..."
                                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs text-center focus:outline-hidden focus:ring-1 focus:ring-amber-500 bg-white"
                              />
                            </div>

                            {/* "Resolve Advisory & Close" centered under the written response box */}
                            <div className="flex justify-center">
                              <button
                                type="button"
                                onClick={() => setEscalationActionConfirm({ escalation: esc, targetStatus: 'resolved' })}
                                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
                              >
                                <span>Resolve Advisory &amp; Close</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Tab: Admin Self-Granted Grants & Subsidies */}
        {adminTab === 'grants_subsidies' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs text-center">
            <div className="px-6 py-4 border-b border-slate-200 flex flex-col items-center justify-center gap-2 bg-emerald-50/40 text-center">
              <div className="flex items-center justify-center gap-2">
                <Coins className="w-5 h-5 text-amber-600" />
                <h2 className="font-serif text-base font-bold text-slate-900 text-center">
                  Admin Self-Granted Grants &amp; Subsidies
                </h2>
              </div>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-bold text-amber-800 bg-amber-100/80 px-2.5 py-1 rounded-full border border-amber-200">
                  Total: {filteredAdminSelfGrants.reduce((sum, g) => sum + g.amountAFNL, 0).toLocaleString()} AFNL
                </span>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100/80 px-2.5 py-1 rounded-full border border-emerald-200">
                  {filteredAdminSelfGrants.length} {filteredAdminSelfGrants.length === 1 ? 'Grant' : 'Grants'}
                </span>
              </div>
            </div>

            <div className="p-6 space-y-4 bg-slate-50/30 flex flex-col items-center">
              {filteredAdminSelfGrants.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  {adminSelfGrants.length === 0
                    ? 'No grants or subsidies have been self-granted by Admins yet.'
                    : `No self-granted subsidies found matching "${searchQuery}".`}
                </div>
              ) : (
                <div className="w-full max-w-3xl space-y-3">
                  {filteredAdminSelfGrants.map((grant) => {
                    const anchorId = `sa-grants_subsidies-${grant.id}`;
                    const isHighlighted = highlightedAnchorId === anchorId;
                    return (
                    <div
                      key={grant.id}
                      data-superadmin-anchor={anchorId}
                      className={`p-5 rounded-2xl border bg-white transition-all flex flex-col items-center justify-center text-center gap-3 ${
                        isHighlighted ? 'border-blue-400 ring-4 ring-blue-500' : 'border-slate-200 hover:shadow-2xs'
                      }`}
                    >
                      <div className="space-y-1.5 flex flex-col items-center">
                        <div className="flex items-center justify-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-slate-900">{grant.grantName}</span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">
                            {grant.status} · Granted to Self
                          </span>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${
                            grant.adminRole === 'super_admin'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-blue-50 text-blue-700 border-blue-200'
                          }`}>
                            {grant.adminRole === 'super_admin' ? 'Super Admin' : 'Admin'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 text-center">
                          Issued to self by{' '}
                          <button
                            type="button"
                            onClick={() =>
                              handleInspectAdminProfile(
                                grant.adminHandle || grant.adminEmail || grant.adminName,
                                anchorId
                              )
                            }
                            className={`inline-flex items-center gap-1 underline-offset-2 ${
                              onViewProfile ? 'hover:underline cursor-pointer' : 'cursor-default'
                            }`}
                          >
                            <span className="font-bold text-slate-900 hover:text-amber-700">{grant.adminName}</span>{' '}
                            <span className="font-mono text-amber-700">{grant.adminHandle}</span>
                          </button>
                          {grant.adminEmail ? ` (${maskProtectedEmailForViewer(grant.adminEmail, currentUser?.email)})` : ''} •{' '}
                          <span>{new Date(grant.timestampIso || grant.date).toLocaleString()}</span>
                        </p>
                      </div>

                      <div className="text-center">
                        <div className="text-sm font-mono font-bold text-amber-700 bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200 inline-block">
                          +{grant.amountAFNL.toLocaleString()} AFNL
                        </div>
                      </div>

                      <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl w-full max-w-lg">
                        <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap text-center">
                          {grant.description}
                        </p>
                      </div>

                      {grant.mediaAttachments && grant.mediaAttachments.length > 0 && (
                        <div className="flex items-center justify-center gap-2 flex-wrap pt-1">
                          {grant.mediaAttachments.map((m, idx) => (
                            <div
                              key={idx}
                              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 text-[11px] font-medium text-slate-700"
                            >
                              {m.type === 'image' ? (
                                <Image className="w-3.5 h-3.5 text-amber-600" />
                              ) : (
                                <Video className="w-3.5 h-3.5 text-blue-600" />
                              )}
                              <span className="truncate max-w-[160px]">{m.name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modal: Group Assignment for an individual admin */}
      {selectedAdminForGrouping && (
        <AdminGroupAssignModal
          admin={selectedAdminForGrouping}
          allGroups={adminGroups}
          onClose={() => setSelectedAdminForGrouping(null)}
          onGroupsUpdated={refreshGroups}
          onToast={addToast}
        />
      )}



      {/* Modal: Job Title Assignment */}
      {adminForTitleEdit && (
        <AdminJobTitleModal
          admin={adminForTitleEdit}
          onClose={() => setAdminForTitleEdit(null)}
          onSave={handleSaveJobTitle}
        />
      )}

      {/* Modal: Confirm Admin Lock */}
      {adminToLock && (
        <AdminLockConfirmModal
          admin={adminToLock}
          onClose={() => setAdminToLock(null)}
          onConfirm={handleConfirmLock}
        />
      )}

      {/* Modal: Confirm Escalation Action (Mark Investigating / Resolve & Close) */}
      {escalationActionConfirm && (
        <AdminEscalationConfirmModal
          escalation={escalationActionConfirm.escalation}
          targetStatus={escalationActionConfirm.targetStatus}
          notes={replyTexts[escalationActionConfirm.escalation.id]}
          onClose={() => setEscalationActionConfirm(null)}
          onConfirm={handleConfirmEscalationAction}
        />
      )}
    </div>
  );
};


