import React from 'react';
import { AuthSession } from '../../types/auth';
import { CurrenciesDirectoryAndWalletView } from './CurrenciesDirectoryAndWalletView';

interface CustomCoinLaunchpadProps {
  currentUser: AuthSession | null;
  onOpenReleaseModalDirectly?: () => void;
  onOpenExchange?: (payload: any) => void;
}

export const CustomCoinLaunchpad: React.FC<CustomCoinLaunchpadProps> = ({
  currentUser,
  onOpenExchange
}) => {
  return (
    <CurrenciesDirectoryAndWalletView
      currentUser={currentUser}
      onOpenExchange={onOpenExchange}
    />
  );
};
