export const PROTECTED_OWNER_EMAILS = [
  'ranmaanimaker@gmail.com',
  'awesomedbz@gmail.com',
] as const;

export function isProtectedOwnerEmail(email?: string | null): boolean {
  if (!email) return false;
  return PROTECTED_OWNER_EMAILS.includes(email.trim().toLowerCase() as any);
}

function getActiveViewerEmail(): string {
  try {
    if (typeof window === 'undefined') return '';
    const raw = window.localStorage.getItem('final_finance_auth_session');
    if (!raw) return '';
    const parsed = JSON.parse(raw);
    return typeof parsed?.email === 'string' ? parsed.email.trim().toLowerCase() : '';
  } catch {
    return '';
  }
}

/**
 * Ensures the platform owner's personal emails are never displayed to other users.
 * Only the owner of that specific email (or the root superadmin owner) sees it unmasked.
 */
export function maskProtectedEmailForViewer(
  targetEmail?: string | null,
  viewerEmail?: string | null
): string {
  if (!targetEmail) return '';
  if (!isProtectedOwnerEmail(targetEmail)) return targetEmail;
  const cleanTarget = targetEmail.trim().toLowerCase();
  const cleanViewer = (viewerEmail ?? getActiveViewerEmail()).trim().toLowerCase();
  if (cleanViewer && (cleanViewer === cleanTarget || cleanViewer === 'ranmaanimaker@gmail.com')) {
    return targetEmail;
  }
  return 'Private Account';
}

export function isEmailSearchableForViewer(
  targetEmail?: string | null,
  viewerEmail?: string | null
): boolean {
  if (!targetEmail) return false;
  if (!isProtectedOwnerEmail(targetEmail)) return true;
  const cleanTarget = targetEmail.trim().toLowerCase();
  const cleanViewer = (viewerEmail ?? getActiveViewerEmail()).trim().toLowerCase();
  return Boolean(cleanViewer && (cleanViewer === cleanTarget || cleanViewer === 'ranmaanimaker@gmail.com'));
}
