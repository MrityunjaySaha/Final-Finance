export interface MarketHoursInfo {
  isOpen: boolean;
  statusText: string;
  nextOpeningText: string;
  formattedLocalTime: string;
  timeZone: string;
  dayOfWeek: string;
}

export function getLocalStockMarketStatus(): MarketHoursInfo {
  const now = new Date();
  const day = now.getDay(); // 0 = Sunday, 1 = Mon, ..., 6 = Sat
  const hour = now.getHours();
  const minute = now.getMinutes();
  const currentMinuteOfDay = hour * 60 + minute;

  const openMinute = 9 * 60 + 30; // 9:30 AM = 570
  const closeMinute = 16 * 60;    // 4:00 PM = 960

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayName = daysOfWeek[day];

  let timeZone = 'Local Time';
  try {
    timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local Time';
  } catch {
    timeZone = 'Local Time';
  }

  const formattedLocalTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const isWeekday = day >= 1 && day <= 5;
  const isDuringHours = currentMinuteOfDay >= openMinute && currentMinuteOfDay < closeMinute;

  const isOpen = isWeekday && isDuringHours;

  let statusText = '';
  let nextOpeningText = '';

  if (isOpen) {
    statusText = 'Market Open';
    nextOpeningText = 'Closes at 4:00 PM local time (Mon–Fri 9:30 AM–4:00 PM)';
  } else {
    statusText = 'Market Closed';
    if (isWeekday && currentMinuteOfDay < openMinute) {
      nextOpeningText = 'Opens today at 9:30 AM local time';
    } else if (isWeekday && currentMinuteOfDay >= closeMinute) {
      if (day === 5) { // Friday after 4 PM
        nextOpeningText = 'Opens Monday at 9:30 AM local time';
      } else {
        nextOpeningText = 'Opens tomorrow at 9:30 AM local time';
      }
    } else {
      // Weekend
      nextOpeningText = 'Opens Monday at 9:30 AM local time';
    }
  }

  return {
    isOpen,
    statusText,
    nextOpeningText,
    formattedLocalTime,
    timeZone,
    dayOfWeek: dayName,
  };
}
