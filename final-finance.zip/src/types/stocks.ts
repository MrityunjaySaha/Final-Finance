export type StockMarketWay = 'final' | 'stable' | 'fiat' | 'crypto' | 'global';
export type StockMarketType = 'all' | 'final' | 'stable' | 'fiat' | 'crypto' | 'global';

export type StockSector = 
  | 'All'
  | 'Technology & AI'
  | 'Semiconductors'
  | 'Gold & Commodities'
  | 'Banking & Finance'
  | 'Energy & Aerospace'
  | 'ETFs & Indices'
  | 'Treasuries & Yield'
  | 'Consumer Staples & Defensive'
  | 'Crypto Treasuries & Mining'
  | 'Sovereign Reserves';

export interface StockPricePoint {
  time: string;
  price: number;
  volume: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
}

export interface StockItem {
  ticker: string;
  name: string;
  price: number;
  changeUSD: number;
  changePercent: number;
  marketType: StockMarketWay;
  settlementMethod?: string;
  high24h: number;
  low24h: number;
  openPrice: number;
  prevClose: number;
  volume: string;
  avgVolume: string;
  marketCap: string;
  peRatio: number;
  eps: number;
  dividendYield: string;
  beta: number;
  fiftyTwoWeekHigh: number;
  fiftyTwoWeekLow: number;
  sector: StockSector;
  subSector?: string;
  description: string;
  exchange: 'NASDAQ' | 'NYSE' | 'AMEX' | 'SOVEREIGN_NODE' | 'CRYPTO_EQUITY';
  analystRating: 'Strong Buy' | 'Buy' | 'Hold' | 'Sell';
  analystTargetUSD: number;
  analystCount: number;
  sparkline: number[];
  history: {
    '1D': StockPricePoint[];
    '1W': StockPricePoint[];
    '1M': StockPricePoint[];
    '1Y': StockPricePoint[];
    '5Y': StockPricePoint[];
  };
  ceo?: string;
  headquarters?: string;
  foundedYear?: number;
  employeesCount?: string;
  nextEarningsDate?: string;
  consensusEps?: string;
  lastQuarterSurprise?: string;
  revenueTTM?: string;
  profitMargin?: string;
  debtToEquity?: string;
  freeCashFlow?: string;
  forwardPe?: number;
  exDividendDate?: string;
  issuanceType?: 'personal' | 'business' | 'corporate' | 'sovereign' | 'public';
  assetCategory?: 'personal' | 'business' | 'corporate' | 'index' | 'commodity' | 'etf';
  issuanceCoinSymbol?: string;
  issuanceCoinName?: string;
  issuanceCoinType?: string;
  issuerName?: string;
  issuerHandle?: string;
  issuerAvatar?: string;
  ipoRefId?: string;
}

export type StockPaymentSourceType = 
  | 'bank_account'
  | 'card'
  | 'wallet_fiat'
  | 'wallet_stable'
  | 'wallet_final'
  | 'wallet_gold'
  | 'wallet_crypto'
  | 'crypto_wallet';

export interface StockPaymentSource {
  id: string;
  type: StockPaymentSourceType;
  label: string;
  subtitle: string;
  balanceUSD: number;
  iconType: 'bank' | 'card' | 'wallet' | 'crypto' | 'gold';
  last4?: string;
  bankName?: string;
  brand?: string;
  walletAddress?: string;
  walletName?: string;
  network?: string;
  isDefault?: boolean;
}

export type DerivativeType = 'spot' | 'call_option' | 'put_option' | 'futures_long' | 'futures_short';

export interface StockOrder {
  id: string;
  ticker: string;
  stockName: string;
  side: 'buy' | 'sell';
  orderType: 'market' | 'limit' | 'stop' | 'recurring';
  derivativeType?: DerivativeType;
  strikePrice?: number;
  expiryDate?: string;
  leverage?: number;
  premiumUSD?: number;
  shares: number;
  price: number;
  limitPrice?: number;
  totalUSD: number;
  costBasisUSD?: number;
  realizedGainLossUSD?: number;
  realizedGainLossPercent?: number;
  buyPriceUSD?: number;
  isPersonalStock?: boolean;
  isBusinessStock?: boolean;
  settlementVault?: 'fiat' | 'stable_coins' | 'final_coins' | 'barter';
  paymentSource: StockPaymentSource;
  status: 'filled' | 'open' | 'cancelled';
  timestamp: string;
  dateIso?: string;
  sector?: StockSector;
  tradeSlipId?: string;
}

export interface StockPosition {
  ticker: string;
  name: string;
  shares: number;
  avgCostUSD: number;
  currentPriceUSD: number;
  totalValueUSD: number;
  totalGainUSD: number;
  totalGainPercent: number;
  dailyGainUSD: number;
  marketType?: StockMarketWay;
  settlementMethod?: string;
  sector: StockSector;
  dividendYield?: string;
  initialBoughtDate?: string;
  lastPurchasedDate?: string;
  primaryFundingSourceLabel?: string;
  assetCategory?: 'personal' | 'business' | 'spot';
  isSpotStock?: boolean;
  isEquity?: boolean;
}

export interface StockNewsItem {
  id: string;
  title: string;
  source: string;
  time: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  tickers: string[];
  summary: string;
  readTime: string;
  category?: 'All' | 'Tech & AI' | 'Semiconductors' | 'Gold & Commodities' | 'Banking & Macro' | 'Energy & Defense' | 'ETFs & Indices' | 'Earnings' | 'Energy & Aerospace' | 'Sovereign Reserves' | 'Technology & AI' | 'Treasuries & Yield' | string;
  impact?: 'High Impact' | 'Medium Impact' | 'Macro Trend';
  keyTakeaway?: string;
  url?: string;
}

export interface MarketIndex {
  symbol: string;
  name: string;
  value: number;
  change: number;
  changePercent: number;
  sparkline: number[];
}

export type PublicDisclosureType = 'SEC Form 13F' | 'SEC Form 4' | 'STOCK Act PTR' | 'On-Chain Proof of Reserve' | 'Peer Portfolio Allocation';
export type DisclosureAssetClass = 'Stock' | 'Option (Call)' | 'Option (Put)' | 'Fixed Income' | 'Digital Asset' | 'Sovereign Equity';

export interface PublicTradeAlertJSON {
  timestamp: string;
  filer_name: string;
  disclosure_type: PublicDisclosureType;
  ticker: string;
  action: 'BUY' | 'SELL';
  share_quantity_or_value: string;
  asset_class: DisclosureAssetClass;
  source_document_url: string;
  cik_or_member_id?: string;
}

export interface SocialStockTrade {
  id: string;
  traderType: 'friend' | 'famous';
  user: {
    uid: string;
    name: string;
    handle: string;
    avatarUrl: string;
    title: string;
    verified: boolean;
    isFriend?: boolean;
    friendsCount?: number;
    winRate?: string;
  };
  ticker: string;
  stockName: string;
  marketType: StockMarketWay;
  assetCategory?: 'personal' | 'business';
  side: 'buy' | 'sell';
  shares: number;
  priceUSD: number;
  totalValueUSD: number;
  timestamp: string;
  timestampAgo: string;
  commentary: string;
  settlementMethod: string;
  gainLossPercent?: number;
  isRealTimeNew?: boolean;
  disclosureType?: PublicDisclosureType;
  executionDate?: string;
  filingDate?: string;
  shareQuantityOrValue?: string;
  assetClass?: DisclosureAssetClass;
  sourceDocumentUrl?: string;
  cikOrMemberId?: string;
}

export type IPOType = 'personal' | 'business';
export type IPOStatus = 
  | 'pending_admin_approval' 
  | 'active' 
  | 'delist_pending_admin_approval' 
  | 'delisted' 
  | 'rejected';

export interface IPOMediaItem {
  id: string;
  type: 'photo' | 'video';
  url: string;
  title?: string;
  description?: string;
  uploadedAt: string;
  isCover?: boolean;
}

export interface FiveModeNetWorth {
  fiatUSD: number; // 1. Fiat USD & Bank Reserves
  sovereignGoldBarter: number; // 2. Sovereign Gold Bullion & Vault Barter Assets
  finalCoins: number; // 3. Final Coins Valuation
  stableCoins: number; // 4. Stablecoins Portfolio
  cryptoAssets: number; // 5. Multi-Chain Cryptocurrency Holdings
  totalNetWorthUSD: number;
}

export interface BusinessDetails {
  companyName: string;
  legalStructure: string; // e.g. 'C-Corp', 'LLC', 'Sovereign DAO', 'AG', 'Public Enterprise'
  sector: StockSector;
  industry: string;
  registrationNumber: string; // EIN / Corporate CRN
  jurisdiction: string; // e.g. 'Delaware, USA', 'Zug, Switzerland', 'Singapore'
  foundedYear: number;
  headquarters: string;
  employeeCount: string;
  website?: string;
  businessModel: string;
  valueProposition: string;
  annualRevenueUSD: number;
  netProfitMarginPercent: number;
  projectedGrowthPercent: number;
  executives: {
    ceo: string;
    cto?: string;
    cfo?: string;
  };
  backingCoinId: string;
  backingCoinSymbol: string;
  backingCoinType: 'final_coin' | 'stable_coin' | 'crypto' | 'fiat';
  backingCoinName: string;
  useOfProceeds: string;
  mediaGallery?: IPOMediaItem[];
}

export interface PersonalDetails {
  fullName: string;
  handle: string;
  profession: string;
  personaProfile: string;
  personalityTraits: string[];
  keyAchievements: string;
  backingFinalCoinId: string; // STRICT: Personal IPO uses ONE of their Final Coins ONLY
  backingFinalCoinSymbol: string;
  backingFinalCoinName: string;
  fiveModeNetWorth: FiveModeNetWorth;
  valuationRationale: string;
  personalMission: string;
  mediaGallery?: IPOMediaItem[];
}

export interface IPORequest {
  id: string;
  ipoType: IPOType;
  ticker: string; // e.g. '$ALEX', '$NEUR'
  equityName: string;
  issuerId: string;
  issuerName: string;
  issuerHandle: string;
  issuerAvatar?: string;
  marketWay: StockMarketWay; // 'final' for personal, or 'final' | 'stable' | 'crypto' for business
  status: IPOStatus;
  sharesOffered: number;
  offeringPriceUSD: number;
  targetValuationUSD: number;
  circulatingFloat: number;
  currentLivePriceUSD?: number;
  currentLiveValuationUSD?: number;
  priceChangePercent24h?: number;
  submittedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  adminNotes?: string;
  delistReason?: string;
  delistRequestedAt?: string;
  delistReviewedAt?: string;
  delistReviewedBy?: string;
  businessDetails?: BusinessDetails;
  personalDetails?: PersonalDetails;
  mediaGallery?: IPOMediaItem[];
  stockItemRef?: StockItem;
}
