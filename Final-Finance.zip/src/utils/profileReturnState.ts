export interface PortfolioTabSnapshot {
  dashboardTab?: string;
  portfolioPrimaryTab?: string;
  portfolioEquitySubTab?: string;
  alpacaStockType?: string;
  alpacaSubTab?: string;
  currenciesMainTab?: string;
}

export interface ProfileReturnAnchor {
  sourceLabel?: string;
  scrollY: number;
  finalCoinId?: string;
  openFinalCoinModal?: boolean;
  listingId?: string;
  restoreActive?: boolean;
  adminTab?:
    | 'escrow'
    | 'kyc'
    | 'ipos'
    | 'audits'
    | 'listings'
    | 'requests'
    | 'transactions'
    | 'accounting'
    | 'locked'
    | 'deactivated'
    | 'deleted'
    | 'feedback';
  accountingMainTab?: 'people' | 'stocks' | 'currencies';
  accountingExpandedUserId?: string | null;
  feedbackSubView?: 'user_feedback' | 'super_admin_feedback';
  feedbackCategoryFilter?: string;
  adminSearchTerm?: string;
  superadminTab?:
    | 'active'
    | 'locked'
    | 'deactivated'
    | 'deleted'
    | 'groups'
    | 'escalations'
    | 'grants_subsidies';
  superadminSearchTerm?: string;
  subsidiesSubTab?: 'ubi' | 'grants' | 'banking';
  bankingView?:
    | 'taken_ongoing'
    | 'loan_offers'
    | 'lent_to_others'
    | 'portfolio_transactions'
    | 'transactions'
    | 'portfolio';
  portfolioTab?: 'ongoing' | 'concluded';
  loanType?: 'given' | 'received';
  tab?: string;
  targetProfileUserId?: string | null;
  posMainTab?: 'directory' | 'retail' | 'restaurant';
  posViewingLocationId?: string | null;
  posCustomerSubTab?: 'restaurants' | 'retail' | 'in_person_receipts' | 'history';
  posExplorerSectionView?: 'browse' | 'checkout' | 'online_orders' | 'delivery_address';
  posExplorerRetailChannelTab?: 'instore' | 'online';
  posExplorerRestaurantChannelTab?: 'inhouse' | 'online';
  posRetailSubTab?: 'checkout' | 'add_item' | 'inventory_dir' | 'online_store' | 'online_orders' | 'history';
  posRestaurantSubTab?: 'checkout' | 'add_item' | 'restaurant_menu' | 'online_menu' | 'takeout_orders' | 'history';
  posElementId?: string;
  marketplaceTab?: 'all' | 'my_listings';
  rideShareTab?: string;
  rideShareSubTab?: string;
  capturedAt?: number;
}

export type PageReturnScope = 'ride_share' | 'messages' | 'call';

const PORTFOLIO_TABS_KEY = 'ff_portfolio_tab_snapshot_v1';
const PROFILE_ANCHOR_KEY = 'ff_profile_return_anchor_v1';
const PAGE_ANCHOR_PREFIX = 'ff_page_return_anchor_v1_';

export function updatePortfolioTabSnapshot(patch: Partial<PortfolioTabSnapshot>): void {
  try {
    const raw = sessionStorage.getItem(PORTFOLIO_TABS_KEY);
    const current: PortfolioTabSnapshot = raw ? JSON.parse(raw) : {};
    sessionStorage.setItem(PORTFOLIO_TABS_KEY, JSON.stringify({ ...current, ...patch }));
  } catch {
    // Ignore storage errors
  }
}

export function getPortfolioTabSnapshot(): PortfolioTabSnapshot {
  try {
    const raw = sessionStorage.getItem(PORTFOLIO_TABS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setPendingProfileReturnAnchor(anchor: ProfileReturnAnchor): void {
  try {
    sessionStorage.setItem(PROFILE_ANCHOR_KEY, JSON.stringify(anchor));
  } catch {
    // Ignore storage errors
  }
}

export function getProfileReturnAnchor(): ProfileReturnAnchor | null {
  try {
    const raw = sessionStorage.getItem(PROFILE_ANCHOR_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clearProfileReturnAnchor(): void {
  try {
    sessionStorage.removeItem(PROFILE_ANCHOR_KEY);
  } catch {
    // Ignore storage errors
  }
}

export function isRestoreProfileReturnActive(): boolean {
  const anchor = getProfileReturnAnchor();
  return Boolean(anchor?.restoreActive);
}

export function setPageReturnAnchor(scope: PageReturnScope, anchor: ProfileReturnAnchor): void {
  try {
    sessionStorage.setItem(
      `${PAGE_ANCHOR_PREFIX}${scope}`,
      JSON.stringify({ ...anchor, capturedAt: anchor.capturedAt ?? Date.now() })
    );
  } catch {
    // Ignore storage errors
  }
}

export function getPageReturnAnchor(scope: PageReturnScope): ProfileReturnAnchor | null {
  try {
    const raw = sessionStorage.getItem(`${PAGE_ANCHOR_PREFIX}${scope}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clearPageReturnAnchor(scope: PageReturnScope): void {
  try {
    sessionStorage.removeItem(`${PAGE_ANCHOR_PREFIX}${scope}`);
  } catch {
    // Ignore storage errors
  }
}
