import React, { useState, useMemo } from 'react';
import { StockNewsItem, StockItem, StockNewsDocumentAttachment, StockNewsMediaAttachment } from '../../types/stocks';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Clock,
  Building2,
  Sparkles,
  Flame,
  ChevronRight,
  Zap,
  Check,
  Share2,
  Bookmark,
  FileText,
  Image as ImageIcon,
  Video,
  Download,
  Eye,
  X,
  Plus,
  Newspaper,
  Trash2,
  Search
} from 'lucide-react';

interface StockNewsFeedProps {
  news: StockNewsItem[];
  stocks?: StockItem[];
  ownedTickers?: string[];
  followedTickers?: string[];
  onSelectTicker: (ticker: string) => void;
  onQuickTrade?: (ticker: string) => void;
  onOpenPostIPONews?: () => void;
  onDeleteIPONews?: (newsId: string) => void;
  currentUserId?: string;
}

function formatDocSize(bytes?: number): string {
  if (!bytes || bytes <= 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export const StockNewsFeed: React.FC<StockNewsFeedProps> = ({
  news,
  stocks = [],
  ownedTickers = [],
  followedTickers = [],
  onSelectTicker,
  onQuickTrade,
  onOpenPostIPONews,
  onDeleteIPONews,
  currentUserId,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Preview modals for photos & documents
  const [previewPhoto, setPreviewPhoto] = useState<StockNewsMediaAttachment | null>(null);
  const [previewDoc, setPreviewDoc] = useState<StockNewsDocumentAttachment | null>(null);

  // Map tickers for live stock prices
  const stockMap = useMemo(() => {
    const map = new Map<string, StockItem>();
    stocks.forEach((s) => map.set(s.ticker, s));
    return map;
  }, [stocks]);

  const handleShare = async (item: StockNewsItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const shareUrl = `${window.location.origin}${window.location.pathname}?news=${encodeURIComponent(item.id)}`;
    try {
      await navigator.clipboard?.writeText(shareUrl);
    } catch {}
    try {
      if (navigator.share) {
        await navigator.share({ url: shareUrl });
      }
    } catch {}
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const ipoUpdatesCount = useMemo(
    () => news.filter((n) => n.isUserIpoNews).length,
    [news]
  );

  const filteredNews = useMemo(() => {
    let list = news;
    if (activeCategory === 'ipo_updates') list = list.filter((n) => n.isUserIpoNews);
    else if (activeCategory === 'saved') list = list.filter((n) => bookmarkedIds.includes(n.id));

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (n) =>
          n.title.toLowerCase().includes(q) ||
          n.summary.toLowerCase().includes(q) ||
          n.source.toLowerCase().includes(q) ||
          (n.bodyText && n.bodyText.toLowerCase().includes(q)) ||
          n.tickers.some((t) => t.toLowerCase().includes(q))
      );
    }
    return list;
  }, [news, activeCategory, bookmarkedIds, searchQuery]);

  const isTextDocument = (doc: StockNewsDocumentAttachment) => {
    const lower = doc.name.toLowerCase();
    return (
      doc.mimeType.startsWith('text/') ||
      lower.endsWith('.txt') ||
      lower.endsWith('.csv') ||
      lower.endsWith('.json') ||
      lower.endsWith('.md')
    );
  };

  const decodeTextDataUrl = (url: string): string => {
    try {
      const commaIdx = url.indexOf(',');
      if (commaIdx === -1) return '';
      const meta = url.slice(0, commaIdx);
      const data = url.slice(commaIdx + 1);
      if (meta.includes('base64')) {
        return decodeURIComponent(escape(atob(data)));
      }
      return decodeURIComponent(data);
    } catch {
      return 'Unable to preview raw text. Please download the file to view.';
    }
  };

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-4 text-center">
      {/* Clean Section Header */}
      <div className="flex flex-col items-center justify-center gap-1.5 pb-3 border-b border-slate-100 text-center">
        <div>
          <h3 className="font-serif font-bold text-base sm:text-lg text-slate-900 flex items-center justify-center gap-2">
            <Flame className="w-5 h-5 text-amber-600" />
            <span>Trending Stock News</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5 text-center">
            Top market headlines, issuer IPO updates, earnings reports, documents &amp; media filings.
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-xl mx-auto">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
          <Search className="w-4 h-4 text-slate-400" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search news by headline, ticker, issuer, or keyword..."
          className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-all text-center sm:text-left"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-700 cursor-pointer text-xs font-semibold"
          >
            Clear
          </button>
        )}
      </div>

      {/* Filter Categories */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'All Trending' },
          ...(ipoUpdatesCount > 0 ? [{ id: 'ipo_updates', label: `IPO Updates (${ipoUpdatesCount})` }] : []),
          ...(bookmarkedIds.length > 0 ? [{ id: 'saved', label: `Saved (${bookmarkedIds.length})` }] : [])
        ].map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeCategory === cat.id
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Trending News List */}
      <div className="divide-y divide-slate-100">
        {filteredNews.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            No stories match this filter.
          </div>
        ) : (
          filteredNews.map((item, idx) => {
            const isBull = item.sentiment === 'bullish';
            const isBear = item.sentiment === 'bearish';
            const isBookmarked = bookmarkedIds.includes(item.id);
            const docs = item.documents || [];
            const photos = item.photos || [];
            const videos = item.videos || [];
            const hasRichAttachments = docs.length > 0 || photos.length > 0 || videos.length > 0;
            // Auto-expand user-posted IPO news if it's the very first card or toggled open
            const isExpanded = expandedId === item.id;
            const canDelete =
              item.isUserIpoNews &&
              onDeleteIPONews &&
              (!currentUserId ||
                !item.issuerId ||
                item.issuerId === currentUserId ||
                item.issuerId === 'you' ||
                item.issuerId === 'current_user');

            return (
              <div
                key={`${item.id}-${idx}`}
                onClick={() => setExpandedId(isExpanded ? null : item.id)}
                className={`py-4 first:pt-2 last:pb-2 group cursor-pointer hover:bg-slate-50/70 p-3 rounded-2xl transition-all ${
                  item.isUserIpoNews ? 'bg-amber-50/25 border border-amber-200/50 my-2' : ''
                }`}
              >
                {/* Metadata Row */}
                <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400 mb-2 text-center">
                  <div className="flex items-center justify-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-900 flex items-center gap-1.5">
                      {item.issuerAvatar ? (
                        <img
                          src={item.issuerAvatar}
                          alt={item.source}
                          className="w-4 h-4 rounded-full object-cover border border-slate-200"
                        />
                      ) : (
                        <Building2 className="w-3.5 h-3.5 text-slate-500" />
                      )}
                      <span>{item.source}</span>
                    </span>
                    {item.isUserIpoNews && (
                      <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-200 font-bold text-[10px] inline-flex items-center gap-1">
                        <Newspaper className="w-2.5 h-2.5" />
                        <span>IPO Update</span>
                      </span>
                    )}
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{item.time}</span>
                    </span>
                    {item.category && (
                      <>
                        <span>•</span>
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium text-[11px]">
                          {item.category}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="flex items-center justify-center gap-1.5 flex-wrap">
                    {docs.length > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                        <FileText className="w-2.5 h-2.5" />
                        <span>{docs.length} Doc{docs.length > 1 ? 's' : ''}</span>
                      </span>
                    )}
                    {photos.length > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                        <ImageIcon className="w-2.5 h-2.5" />
                        <span>{photos.length} Photo{photos.length > 1 ? 's' : ''}</span>
                      </span>
                    )}
                    {videos.length > 0 && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                        <Video className="w-2.5 h-2.5" />
                        <span>{videos.length} Video{videos.length > 1 ? 's' : ''}</span>
                      </span>
                    )}

                    {item.impact && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-50 text-amber-900 border border-amber-200">
                        <Sparkles className="w-2.5 h-2.5 text-amber-600" />
                        <span>{item.impact}</span>
                      </span>
                    )}

                    <span
                      className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                        isBull
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : isBear
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {isBull ? (
                        <TrendingUp className="w-2.5 h-2.5 text-emerald-600" />
                      ) : isBear ? (
                        <TrendingDown className="w-2.5 h-2.5 text-rose-600" />
                      ) : (
                        <Minus className="w-2.5 h-2.5 text-slate-500" />
                      )}
                      {item.sentiment}
                    </span>

                    <button
                      type="button"
                      onClick={(e) => toggleBookmark(item.id, e)}
                      className={`p-1 rounded-md text-slate-400 hover:text-amber-600 hover:bg-slate-100 transition-colors cursor-pointer ${
                        isBookmarked ? 'text-amber-600' : ''
                      }`}
                      title={isBookmarked ? 'Saved' : 'Bookmark story'}
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-current' : ''}`} />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleShare(item, e)}
                      className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                      title="Copy headline"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Share2 className="w-3.5 h-3.5" />
                      )}
                    </button>

                    {canDelete && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteIPONews(item.id);
                        }}
                        className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Delete IPO news update"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Title / Headline */}
                <h4 className="text-sm sm:text-base font-serif font-bold text-slate-900 group-hover:text-amber-800 transition-colors leading-snug text-center">
                  {item.title}
                </h4>

                {/* Summary / Normal Text */}
                <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed whitespace-pre-line text-center">
                  {isExpanded && item.bodyText ? item.bodyText : item.summary}
                </p>

                {/* Key Takeaway */}
                {item.keyTakeaway && (
                  <div className="mt-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70 text-xs text-slate-700 flex items-start justify-center gap-2 text-center">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-900">Key Takeaway: </span>
                      <span>{item.keyTakeaway}</span>
                    </div>
                  </div>
                )}

                {/* Inline Compact Preview for User IPO Photos, Videos & Docs (visible right away!) */}
                {item.isUserIpoNews && hasRichAttachments && !isExpanded && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="mt-3 space-y-2.5"
                  >
                    {photos.length > 0 && (
                      <div className="flex items-center gap-2 overflow-x-auto pb-1">
                        {photos.map((photo) => (
                          <button
                            key={photo.id}
                            type="button"
                            onClick={() => setPreviewPhoto(photo)}
                            className="relative w-24 h-16 rounded-xl overflow-hidden border border-slate-200 hover:border-blue-400 shrink-0 cursor-pointer group/img shadow-2xs"
                            title={`View ${photo.name}`}
                          >
                            <img
                              src={photo.url}
                              alt={photo.name}
                              className="w-full h-full object-cover group-hover/img:scale-105 transition-transform"
                            />
                          </button>
                        ))}
                      </div>
                    )}

                    {videos.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {videos.map((vid) => (
                          <div
                            key={vid.id}
                            className="rounded-xl overflow-hidden border border-purple-200 bg-slate-950"
                          >
                            <video
                              src={vid.url}
                              controls
                              playsInline
                              className="w-full max-h-52 object-contain bg-black"
                            />
                            <div className="px-2.5 py-1 bg-white text-[11px] font-semibold text-slate-700 truncate border-t border-slate-100">
                              {vid.name}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {docs.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {docs.map((doc) => (
                          <div
                            key={doc.id}
                            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-indigo-200 text-xs shadow-2xs"
                          >
                            <FileText className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                            <span className="font-semibold text-slate-800 max-w-[160px] truncate">{doc.name}</span>
                            {doc.sizeBytes ? (
                              <span className="text-[10px] font-mono text-slate-400">{formatDocSize(doc.sizeBytes)}</span>
                            ) : null}
                            <button
                              type="button"
                              onClick={() => setPreviewDoc(doc)}
                              className="p-1 rounded-md text-indigo-600 hover:bg-indigo-50 cursor-pointer"
                              title="Preview document"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            <a
                              href={doc.url}
                              download={doc.name}
                              className="p-1 rounded-md text-slate-600 hover:bg-slate-100"
                              title="Download document"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Expanded Full Article Wire Details */}
                {isExpanded && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="mt-3.5 p-4 rounded-2xl bg-amber-50/40 border border-amber-200/60 space-y-4 text-xs sm:text-sm text-slate-800 animate-fadeIn"
                  >
                    <div className="flex items-center justify-between border-b border-amber-200/40 pb-2">
                      <span className="font-bold font-serif text-amber-900 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-amber-600" />
                        <span>
                          {item.isUserIpoNews
                            ? `Official Issuer Report • ${item.ipoName || item.source}`
                            : 'Full Institutional Wire & Catalyst Intelligence Report'}
                        </span>
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">{item.readTime || '3 min read'}</span>
                    </div>

                    {item.isUserIpoNews ? (
                      <div className="space-y-4">
                        {item.bodyText && (
                          <div className="p-3.5 rounded-xl bg-white border border-slate-200/80 text-slate-800 leading-relaxed whitespace-pre-line font-sans text-xs sm:text-sm">
                            {item.bodyText}
                          </div>
                        )}

                        {/* Photos Gallery */}
                        {photos.length > 0 && (
                          <div className="space-y-2">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-800 font-mono flex items-center gap-1.5">
                              <ImageIcon className="w-3.5 h-3.5" />
                              <span>Attached Photos ({photos.length})</span>
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                              {photos.map((photo) => (
                                <button
                                  key={photo.id}
                                  type="button"
                                  onClick={() => setPreviewPhoto(photo)}
                                  className="rounded-xl overflow-hidden border border-slate-200 bg-white hover:border-blue-400 transition-all text-left cursor-pointer group/p"
                                >
                                  <img
                                    src={photo.url}
                                    alt={photo.name}
                                    className="w-full h-40 object-cover group-hover/p:scale-105 transition-transform"
                                  />
                                  <div className="px-2.5 py-1.5 text-[11px] font-medium text-slate-700 truncate border-t border-slate-100">
                                    {photo.name}
                                  </div>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Videos Player */}
                        {videos.length > 0 && (
                          <div className="space-y-2">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-purple-800 font-mono flex items-center gap-1.5">
                              <Video className="w-3.5 h-3.5" />
                              <span>Attached Videos ({videos.length})</span>
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              {videos.map((vid) => (
                                <div key={vid.id} className="rounded-xl overflow-hidden border border-purple-200 bg-slate-950">
                                  <video src={vid.url} controls playsInline className="w-full max-h-64 object-contain bg-black" />
                                  <div className="px-3 py-1.5 bg-white text-xs font-semibold text-slate-800 truncate border-t border-slate-100">
                                    {vid.name}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Documents List */}
                        {docs.length > 0 && (
                          <div className="space-y-2">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-800 font-mono flex items-center gap-1.5">
                              <FileText className="w-3.5 h-3.5" />
                              <span>Attached Documents &amp; Filings ({docs.length})</span>
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                              {docs.map((doc) => (
                                <div
                                  key={doc.id}
                                  className="p-3 rounded-xl bg-white border border-indigo-200 flex items-center justify-between gap-2"
                                >
                                  <div className="flex items-center gap-2.5 min-w-0">
                                    <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                                      <FileText className="w-4 h-4" />
                                    </div>
                                    <div className="min-w-0">
                                      <p className="font-bold text-slate-900 truncate text-xs">{doc.name}</p>
                                      <p className="text-[10px] font-mono text-slate-400">
                                        {formatDocSize(doc.sizeBytes) || 'Document'}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1 shrink-0">
                                    <button
                                      type="button"
                                      onClick={() => setPreviewDoc(doc)}
                                      className="px-2 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] cursor-pointer flex items-center gap-1"
                                    >
                                      <Eye className="w-3 h-3" />
                                      <span>View</span>
                                    </button>
                                    <a
                                      href={doc.url}
                                      download={doc.name}
                                      className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] flex items-center gap-1"
                                    >
                                      <Download className="w-3 h-3" />
                                      <span>Save</span>
                                    </a>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-2 text-slate-700 leading-relaxed font-sans">
                        <p>
                          <strong>Executive Context:</strong> Comprehensive telemetry from premier global exchange custodians and clearing desks indicates sustained institutional positioning across <span className="font-mono font-bold text-slate-900">{item.tickers.join(', ')}</span>. Market makers and primary dealers report heightened block order flow velocity.
                        </p>
                        <p>
                          <strong>Macroeconomic &amp; Sector Impact:</strong> {item.summary} Analysts note that ongoing capital reallocation into sovereign-backed equities and secure commodity vaults reinforces price discovery integrity across multi-tier liquidity venues.
                        </p>
                        <p>
                          <strong>Regulatory &amp; Compliance Audit:</strong> Verified via real-time cryptographic settlement ledgers and SEC EDGAR reporting pipelines. All participating entities maintain compliant Tier-1 solvency ratios.
                        </p>
                      </div>
                    )}

                    <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 font-medium border-t border-amber-200/40">
                      <span>
                        Source Verification: {item.source}
                        {item.issuerHandle ? ` (@${item.issuerHandle.replace(/^@/, '')})` : ''} • Feed #{item.id}
                      </span>
                      <button
                        type="button"
                        onClick={() => setExpandedId(null)}
                        className="text-amber-700 hover:text-amber-900 font-bold cursor-pointer"
                      >
                        Collapse
                      </button>
                    </div>
                  </div>
                )}

                {/* Read More prompt when collapsed */}
                {!isExpanded && (
                  <div className="mt-2 flex items-center justify-center gap-1 text-[11px] font-bold text-amber-700 hover:text-amber-800 text-center">
                    <span>
                      {item.isUserIpoNews
                        ? 'Click to expand full IPO report & attachments'
                        : '✨ Click to read full article & institutional report'}
                    </span>
                  </div>
                )}

                {/* Tickers Row & Navigation */}
                <div className="flex flex-wrap items-center justify-center gap-2 mt-3 pt-2.5 border-t border-slate-100/90 text-center">
                  <div className="flex items-center justify-center gap-1.5 flex-wrap">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Tickers:</span>
                    {item.tickers.map((t, tIdx) => {
                      const isOwned = ownedTickers.includes(t);
                      const isFollowed = followedTickers.includes(t);
                      const stock = stockMap.get(t);

                      return (
                        <button
                          key={`${t}-${tIdx}`}
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectTicker(t);
                          }}
                          className={`px-2.5 py-1 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                            isOwned
                              ? 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 border border-emerald-200'
                              : isFollowed
                              ? 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                          }`}
                          title={`View $${t} details`}
                        >
                          <span>${t}</span>
                          {stock && (
                            <span className="text-[10px] font-sans font-normal opacity-75">
                              ${stock.price.toFixed(2)}
                            </span>
                          )}
                          {isOwned && (
                            <span className="text-[9px] font-sans font-bold text-emerald-700 bg-emerald-100 px-1 rounded">
                              Owned
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-center gap-2">
                    {onQuickTrade && item.tickers.length > 0 && stockMap.has(item.tickers[0]) && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onQuickTrade(item.tickers[0]);
                        }}
                        className="py-1 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
                        title={`Trade $${item.tickers[0]}`}
                      >
                        <Zap className="w-3 h-3" />
                        <span>Trade ${item.tickers[0]}</span>
                      </button>
                    )}

                    {item.tickers[0] && stockMap.has(item.tickers[0]) && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTicker(item.tickers[0]);
                        }}
                        className="text-xs font-bold text-slate-500 hover:text-amber-800 flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>View Stock</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Photo Lightbox Modal */}
      {previewPhoto && (
        <div
          onClick={() => setPreviewPhoto(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-3xl w-full bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl"
          >
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="font-bold text-xs text-slate-900 truncate">{previewPhoto.name}</span>
              <button
                type="button"
                onClick={() => setPreviewPhoto(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="bg-slate-950 flex items-center justify-center max-h-[75vh]">
              <img
                src={previewPhoto.url}
                alt={previewPhoto.name}
                className="max-h-[75vh] w-auto object-contain"
              />
            </div>
          </div>
        </div>
      )}

      {/* Document Viewer Modal */}
      {previewDoc && (
        <div
          onClick={() => setPreviewDoc(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-4xl w-full bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl flex flex-col max-h-[85vh]"
          >
            <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50">
              <div className="flex items-center gap-2 min-w-0">
                <FileText className="w-4 h-4 text-indigo-600 shrink-0" />
                <span className="font-bold text-xs sm:text-sm text-slate-900 truncate">{previewDoc.name}</span>
                {previewDoc.sizeBytes ? (
                  <span className="text-[11px] font-mono text-slate-400 shrink-0">
                    ({formatDocSize(previewDoc.sizeBytes)})
                  </span>
                ) : null}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <a
                  href={previewDoc.url}
                  download={previewDoc.name}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </a>
                <button
                  type="button"
                  onClick={() => setPreviewDoc(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-slate-800 hover:bg-slate-200/70 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto bg-slate-100 p-4 min-h-[360px]">
              {isTextDocument(previewDoc) ? (
                <pre className="p-4 rounded-2xl bg-white border border-slate-200 text-xs font-mono text-slate-800 whitespace-pre-wrap break-words">
                  {decodeTextDataUrl(previewDoc.url)}
                </pre>
              ) : previewDoc.mimeType === 'application/pdf' || previewDoc.name.toLowerCase().endsWith('.pdf') ? (
                <iframe
                  src={previewDoc.url}
                  title={previewDoc.name}
                  className="w-full h-[65vh] rounded-2xl border border-slate-200 bg-white"
                />
              ) : (
                <div className="h-full flex flex-col items-center justify-center py-12 text-center space-y-3 bg-white rounded-2xl border border-slate-200 p-6">
                  <FileText className="w-10 h-10 text-indigo-500" />
                  <h4 className="font-bold text-sm text-slate-900">{previewDoc.name}</h4>
                  <p className="text-xs text-slate-500 max-w-md">
                    In-browser preview is supported for PDF, TXT, and CSV files. Click Download above to open this filing with your system application.
                  </p>
                  <a
                    href={previewDoc.url}
                    download={previewDoc.name}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold inline-flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download {previewDoc.name}</span>
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
