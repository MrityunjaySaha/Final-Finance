import { CustomCoin } from '../types/coinLaunch';

export interface TokenDollarEquivalenceSnapshot {
  tokensPerFinalCoin: number;
  tokenUsd: number;
  finalCoinUsd: number;
  updatedAt: string;
}

export const TOKEN_DOLLAR_EQUIVALENCE_STORAGE_KEY = 'final_finance_token_dollar_equivalence_v1';

// Baseline Token Dollar Equivalence: 28.13 Tokens : 1 Final Coin = $29.26 USD ($1.04/Token)
export const DEFAULT_TOKENS_PER_FINAL_COIN = 28.13;
export const DEFAULT_TOKEN_USD = 1.04;
export const DEFAULT_FINAL_COIN_USD = Number((DEFAULT_TOKENS_PER_FINAL_COIN * DEFAULT_TOKEN_USD).toFixed(2)); // 29.26

export const getTokenDollarEquivalenceSnapshot = (): TokenDollarEquivalenceSnapshot => {
  try {
    const raw = localStorage.getItem(TOKEN_DOLLAR_EQUIVALENCE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const tokenUsd = Number(parsed?.tokenUsd);
      const finalCoinUsd = Number(parsed?.finalCoinUsd);
      const tokensPerFinalCoin = Number(parsed?.tokensPerFinalCoin);
      if (
        Number.isFinite(tokenUsd) &&
        tokenUsd > 0 &&
        Number.isFinite(finalCoinUsd) &&
        finalCoinUsd > 0 &&
        Number.isFinite(tokensPerFinalCoin) &&
        tokensPerFinalCoin > 0
      ) {
        return {
          tokenUsd: Number(tokenUsd.toFixed(2)),
          finalCoinUsd: Number(finalCoinUsd.toFixed(2)),
          tokensPerFinalCoin: Number(tokensPerFinalCoin.toFixed(2)),
          updatedAt: String(parsed?.updatedAt || new Date().toISOString()),
        };
      }
    }
  } catch {
    // ignore storage errors
  }

  return {
    tokensPerFinalCoin: DEFAULT_TOKENS_PER_FINAL_COIN,
    tokenUsd: DEFAULT_TOKEN_USD,
    finalCoinUsd: DEFAULT_FINAL_COIN_USD,
    updatedAt: new Date().toISOString(),
  };
};

export const saveTokenDollarEquivalenceSnapshot = (params: {
  finalCoinUsd: number;
  tokenUsd: number;
}): TokenDollarEquivalenceSnapshot => {
  const safeTokenUsd = Math.max(0.01, Number(params.tokenUsd) || DEFAULT_TOKEN_USD);
  const safeFinalUsd = Math.max(0.01, Number(params.finalCoinUsd) || DEFAULT_FINAL_COIN_USD);
  const tokensPerFinalCoin = Number((safeFinalUsd / safeTokenUsd).toFixed(2));

  const snapshot: TokenDollarEquivalenceSnapshot = {
    tokensPerFinalCoin,
    tokenUsd: Number(safeTokenUsd.toFixed(2)),
    finalCoinUsd: Number(safeFinalUsd.toFixed(2)),
    updatedAt: new Date().toISOString(),
  };

  try {
    localStorage.setItem(TOKEN_DOLLAR_EQUIVALENCE_STORAGE_KEY, JSON.stringify(snapshot));
  } catch {
    // ignore storage errors
  }

  return snapshot;
};

/**
 * Resolves the USD value of 1 unit of a Final Coin using the platform's Token Dollar Equivalence
 * (tokensPerFinalCoin * tokenUsd), respecting any positive custom price overrides when set.
 */
export const getFinalCoinUsdRate = (symbol?: string, customCoins?: CustomCoin[]): number => {
  const snapshot = getTokenDollarEquivalenceSnapshot();
  const baseEquivalenceUsd = Number((snapshot.tokensPerFinalCoin * snapshot.tokenUsd).toFixed(2));

  if (symbol && customCoins && customCoins.length > 0) {
    const clean = symbol.trim().toUpperCase();
    const match = customCoins.find((c) => c.symbol.toUpperCase() === clean);
    if (match && typeof match.priceUSD === 'number' && match.priceUSD > 0) {
      return match.priceUSD;
    }
  }

  return baseEquivalenceUsd;
};
