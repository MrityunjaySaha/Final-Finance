import React, { useState, useEffect, useMemo } from 'react';
import { 
  StockItem, 
  StockOrder, 
  StockPosition,
  StockMarketWay
} from '../types/stocks';
import { 
  INITIAL_STOCKS, 
  STOCK_MARKET_WAYS,
  INITIAL_USER_STOCK_POSITIONS, 
  BREAKING_STOCK_NEWS,
  getAllActiveMarketStocks,
  IPO_UPDATED_EVENT
} from '../data/stocksData';
import { StockNewsFeed } from './stocks/StockNewsFeed';
import { StockChart } from './stocks/StockChart';
import { StockFundamentals } from './stocks/StockFundamentals';
import { StockOrderDesk } from './stocks/StockOrderDesk';
import { StockDetailPage } from './stocks/StockDetailPage';
import { QuickBuyStockModal } from './stocks/QuickBuyStockModal';
import { TradeConfirmationModal } from './stocks/TradeConfirmationModal';
import { StockMarketHoursBar } from './stocks/StockMarketHoursBar';
import { AlpacaAssetLookup } from './stocks/AlpacaAssetLookup';
import { SocialTradesFeed } from './stocks/SocialTradesFeed';
import { getLocalStockMarketStatus } from '../utils/marketHours';
import { formatStockPrice } from '../utils/stockCurrencyFormatter';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { 
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Zap,
  Users,
  ShieldCheck,
  Building2,
  Coins,
  Globe,
  Search,
  SlidersHorizontal,
  ArrowUpDown,
  TrendingUp,
  TrendingDown,
  Star,
  Eye,
  BarChart3,
  CheckCircle2,
  ArrowUpRight,
  Sparkles,
  Layers,
  Activity,
  X,
  ArrowLeft,
  LayoutGrid,
  List
} from 'lucide-react';
import { 
  getStoredStockPositions, 
  saveStoredStockPositions, 
  getStoredStockOrders, 
  saveStoredStockOrders,
  getAvailableStockPaymentSources,
  getStoredWatchlist,
  toggleStoredWatchlist,
  WATCHLIST_UPDATED_EVENT,
  matchStockSearch
} from '../utils/stockWalletBridge';
import { recordLedgerTransaction, createLedgerItemFromStockOrder } from '../utils/universalLedgerBridge';

interface StockMarketViewProps {
  currentUser: AuthSession | null;
  onOpenAuthModal: () => void;
  onNavigateBack: () => void;
  initialSelectedTicker?: string;
  initialQuickBuyStock?: StockItem | null;
  initialMarketWay?: StockMarketWay | 'all';
}

export const StockMarketView: React.FC<StockMarketViewProps> = ({
  currentUser,
  onOpenAuthModal,
  onNavigateBack,
  initialSelectedTicker,
  initialQuickBuyStock,
  initialMarketWay,
}) => {
  const { addToast, addTransaction, addNotification } = useApp();
  const userId = currentUser?.id || 'guest';
  const marketStatus = getLocalStockMarketStatus();

  // 4 Ways of Stock Market Active Selection
  const [selectedMarketWay, setSelectedMarketWay] = useState<StockMarketWay | 'all' | 'social'>(() => {
    if (initialMarketWay) return initialMarketWay;
    if (initialSelectedTicker) {
      const found = INITIAL_STOCKS.find((s) => s.ticker === initialSelectedTicker);
      if (found?.marketType) return found.marketType;
    }
    return 'final';
  });

  // Stocks Master State
  const [stocks, setStocks] = useState<StockItem[]>(() => getAllActiveMarketStocks());
  const [selectedStock, setSelectedStock] = useState<StockItem>(() => {
    const initialList = getAllActiveMarketStocks();
    if (initialSelectedTicker) {
      const found = initialList.find((s) => s.ticker === initialSelectedTicker);
      if (found) return found;
    }
    return initialList[0] || INITIAL_STOCKS[0];
  });

  // Dedicated Stock Page View State (Single stock deep-dive page)
  const [viewingStockDetail, setViewingStockDetail] = useState<StockItem | null>(() => {
    const initialList = getAllActiveMarketStocks();
    if (initialSelectedTicker) {
      const found = initialList.find((s) => s.ticker === initialSelectedTicker);
      if (found) return found;
    }
    return null;
  });

  const [watchlist, setWatchlist] = useState<string[]>(() => getStoredWatchlist(userId));
  const [activeChartTimeframe, setActiveChartTimeframe] = useState<'1D' | '1W' | '1M' | '1Y' | '5Y'>('1D');
  const [showInteractiveChart, setShowInteractiveChart] = useState<boolean>(false);

  // In-market search & filter states
  const [marketSearchQuery, setMarketSearchQuery] = useState<string>('');
  const [selectedSectorFilter, setSelectedSectorFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'marketCap' | 'gainers' | 'volume' | 'price' | 'alphabetical'>('gainers');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [isEquitiesCollapsed, setIsEquitiesCollapsed] = useState<boolean>(false);

  // Quick Trade Modal State (Buy / Sell)
  const [quickTradeStock, setQuickTradeStock] = useState<StockItem | null>(initialQuickBuyStock || null);
  const [quickTradeSide, setQuickTradeSide] = useState<'buy' | 'sell'>('buy');

  // Trade Confirmation Receipt Modal State
  const [selectedReceiptOrder, setSelectedReceiptOrder] = useState<StockOrder | null>(null);

  // User Positions & Orders Persistent State
  const [positions, setPositions] = useState<StockPosition[]>(() =>
    getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS)
  );
  const [orders, setOrders] = useState<StockOrder[]>(() =>
    getStoredStockOrders(userId)
  );

  // Sync initialSelectedTicker prop updates
  useEffect(() => {
    if (initialSelectedTicker) {
      const found = stocks.find((s) => s.ticker === initialSelectedTicker);
      if (found) {
        setViewingStockDetail(found);
        setSelectedStock(found);
        if (found.marketType) {
          setSelectedMarketWay(found.marketType);
        }
      }
    }
  }, [initialSelectedTicker, stocks]);

  // Sync viewingStockDetail with live updated price changes
  useEffect(() => {
    if (viewingStockDetail) {
      const current = stocks.find((s) => s.ticker === viewingStockDetail.ticker);
      if (current) {
        setViewingStockDetail(current);
      }
    }
  }, [stocks]);

  // Sync initialMarketWay prop updates
  useEffect(() => {
    if (initialMarketWay) {
      setSelectedMarketWay(initialMarketWay);
      setMarketSearchQuery('');
      setSelectedSectorFilter('all');
      if (initialMarketWay !== 'all') {
        const first = stocks.find(s => s.marketType === initialMarketWay);
        if (first) setSelectedStock(first);
      }
    }
  }, [initialMarketWay]);

  useEffect(() => {
    if (initialQuickBuyStock) {
      setQuickTradeStock(initialQuickBuyStock);
      setQuickTradeSide('buy');
    }
  }, [initialQuickBuyStock]);

  // Load and refresh persistent positions, orders, watchlist & IPO stocks
  useEffect(() => {
    const handleRefresh = () => {
      setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
      setOrders(getStoredStockOrders(userId));
      setStocks(getAllActiveMarketStocks());
      setWatchlist(getStoredWatchlist(userId));
    };

    handleRefresh();
    window.addEventListener(IPO_UPDATED_EVENT, handleRefresh);
    window.addEventListener(WATCHLIST_UPDATED_EVENT, handleRefresh);
    window.addEventListener('storage', handleRefresh);
    return () => {
      window.removeEventListener(IPO_UPDATED_EVENT, handleRefresh);
      window.removeEventListener(WATCHLIST_UPDATED_EVENT, handleRefresh);
      window.removeEventListener('storage', handleRefresh);
    };
  }, [userId]);

  // Live Price Fluctuations Simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setStocks((prev) =>
        prev.map((s) => {
          const delta = (Math.random() - 0.49) * (s.price * 0.0018);
          const newPrice = Math.max(0.1, Number((s.price + delta).toFixed(2)));
          const diff = Number((newPrice - (s.price - s.changeUSD)).toFixed(2));
          const base = s.price - s.changeUSD || 1;
          const pct = Number(((diff / base) * 100).toFixed(2));

          return {
            ...s,
            price: newPrice,
            changeUSD: diff,
            changePercent: pct,
          };
        })
      );
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  // Update selectedStock reference when stocks array updates
  useEffect(() => {
    const current = stocks.find((s) => s.ticker === selectedStock.ticker);
    if (current) {
      setSelectedStock(current);
    }
  }, [stocks]);

  // Handle Order Execution (updates positions and stores persistently)
  const handleOrderExecuted = (newOrder: StockOrder) => {
    // Update positions & calculate realized profit/loss for sells
    let updatedPositions: StockPosition[] = [];
    const existing = positions.find((p) => p.ticker === newOrder.ticker);
    const stockInfo = stocks.find(s => s.ticker === newOrder.ticker) || selectedStock;
    const isPersonal = stockInfo?.issuanceType === 'personal' || stockInfo?.assetCategory === 'personal' || newOrder.ticker === 'ALEX';

    let enrichedOrder: StockOrder = {
      ...newOrder,
      isPersonalStock: isPersonal,
      isBusinessStock: !isPersonal
    };

    if (newOrder.side === 'buy') {
      enrichedOrder.buyPriceUSD = newOrder.price;
      enrichedOrder.costBasisUSD = newOrder.totalUSD;

      if (existing) {
        const totalShares = existing.shares + newOrder.shares;
        const totalCost = (existing.shares * existing.avgCostUSD) + newOrder.totalUSD;
        const newAvgCost = totalCost / totalShares;
        const newTotalVal = totalShares * newOrder.price;
        const totalGain = newTotalVal - totalCost;

        updatedPositions = positions.map((p) =>
          p.ticker === newOrder.ticker
            ? {
                ...p,
                shares: totalShares,
                avgCostUSD: newAvgCost,
                currentPriceUSD: newOrder.price,
                totalValueUSD: newTotalVal,
                totalGainUSD: totalGain,
                totalGainPercent: (totalGain / totalCost) * 100,
                lastPurchasedDate: new Date().toISOString().slice(0, 10),
                primaryFundingSourceLabel: newOrder.paymentSource?.label || p.primaryFundingSourceLabel
              }
            : p
        );
      } else {
        const newPos: StockPosition = {
          ticker: newOrder.ticker,
          name: newOrder.stockName,
          shares: newOrder.shares,
          avgCostUSD: newOrder.price,
          currentPriceUSD: newOrder.price,
          totalValueUSD: newOrder.totalUSD,
          totalGainUSD: 0,
          totalGainPercent: 0,
          dailyGainUSD: 0,
          sector: newOrder.sector || 'Technology & AI',
          dividendYield: '0.50%',
          initialBoughtDate: new Date().toISOString().slice(0, 10),
          lastPurchasedDate: new Date().toISOString().slice(0, 10),
          primaryFundingSourceLabel: newOrder.paymentSource?.label
        };
        updatedPositions = [newPos, ...positions];
      }
    } else {
      // Sell - calculate exact realized gain/loss
      const buyPrice = existing ? existing.avgCostUSD : (newOrder.price * 0.85);
      const costBasis = newOrder.shares * buyPrice;
      const realizedGainLoss = Number((newOrder.totalUSD - costBasis).toFixed(2));
      const realizedGainLossPct = costBasis > 0 ? Number(((realizedGainLoss / costBasis) * 100).toFixed(2)) : 0;

      enrichedOrder.buyPriceUSD = buyPrice;
      enrichedOrder.costBasisUSD = costBasis;
      enrichedOrder.realizedGainLossUSD = realizedGainLoss;
      enrichedOrder.realizedGainLossPercent = realizedGainLossPct;

      if (existing) {
        const remainingShares = Math.max(0, existing.shares - newOrder.shares);
        if (remainingShares <= 0.0001) {
          updatedPositions = positions.filter((p) => p.ticker !== newOrder.ticker);
        } else {
          const totalVal = remainingShares * newOrder.price;
          const remainingCostBasis = remainingShares * existing.avgCostUSD;
          const totalGain = totalVal - remainingCostBasis;
          updatedPositions = positions.map((p) =>
            p.ticker === newOrder.ticker
              ? {
                  ...p,
                  shares: Number(remainingShares.toFixed(4)),
                  currentPriceUSD: newOrder.price,
                  totalValueUSD: totalVal,
                  totalGainUSD: totalGain,
                  totalGainPercent: (totalGain / remainingCostBasis) * 100,
                }
              : p
          );
        }
      } else {
        updatedPositions = positions;
      }
    }

    const updatedOrders = [enrichedOrder, ...orders];
    setOrders(updatedOrders);
    saveStoredStockOrders(userId, updatedOrders);

    setPositions(updatedPositions);
    saveStoredStockPositions(userId, updatedPositions);

    // Record into universal ledger for tax receipts
    try {
      const ledgerItem = createLedgerItemFromStockOrder(enrichedOrder, stockInfo);
      
      // Update global AppContext ledger for real-time visibility in Admin/Global desks
      addTransaction(ledgerItem);
      
      // Keep persistent user-specific storage in sync
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record stock order to ledger', e);
    }

    // Trigger universal notification
    addNotification({
      title: `${newOrder.side === 'buy' ? '📈 Buy Order Filled' : '📉 Sell Order Executed'}: ${newOrder.shares} ${newOrder.ticker}`,
      description: `${newOrder.side === 'buy' ? 'Purchased' : 'Sold'} ${newOrder.shares} shares of ${newOrder.stockName} @ $${newOrder.price.toFixed(2)} ($${newOrder.totalUSD.toLocaleString()} USD via ${newOrder.paymentSource?.label || 'Final Coin'}).`,
      type: 'stocks',
      targetTab: 'stocks',
      amount: newOrder.totalUSD,
      currency: 'USD',
    });

    // Open confirmation receipt modal
    setSelectedReceiptOrder(enrichedOrder);
  };

  const handleSelectStock = (stock: StockItem) => {
    setSelectedStock(stock);
    setViewingStockDetail(stock);
    setShowInteractiveChart(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenQuickTradeModal = (stock: StockItem, side: 'buy' | 'sell' = 'buy') => {
    setQuickTradeSide(side);
    setQuickTradeStock(stock);
  };

  const handleToggleWatchlist = (ticker: string) => {
    const next = toggleStoredWatchlist(userId, ticker);
    setWatchlist(next);
    const isNowFavorite = next.some(t => t.toUpperCase() === ticker.toUpperCase());
    const stock = stocks.find(s => s.ticker.toUpperCase() === ticker.toUpperCase());
    if (stock) {
      addNotification({
        title: isNowFavorite ? `⭐ Added to Favorites: ${stock.ticker}` : `Removed from Favorites: ${stock.ticker}`,
        description: isNowFavorite ? `${stock.name} is now tracked in your favorites list with live alerts.` : `${stock.name} removed from your favorite watchlist.`,
        type: 'stocks',
        targetTab: 'stocks',
        showToast: true,
      });
    }
  };

  // Active Market Way Details
  const activeMarketInfo = selectedMarketWay === 'social' ? { id: 'social', name: 'Social Trades Feed', title: 'Social Trades Feed', icon: Users } : STOCK_MARKET_WAYS.find((m) => m.id === selectedMarketWay);

  // Count stocks and calculate growth statistics per market way
  const marketCounts = {
    final: stocks.filter(s => s.marketType === 'final').length,
    global: 0 // Placeholder for Alpaca search
  };

  // Detailed statistics (holdings count & growth average) for active stock market types
  const marketTypeStats = useMemo(() => {
    const calcStats = (mType: 'final') => {
      const mPositions = positions.filter((p) => {
        const stk = stocks.find((s) => s.ticker.toUpperCase() === p.ticker.toUpperCase());
        return stk ? stk.marketType === mType : false;
      });
      const costBasis = mPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0);
      const gainUSD = mPositions.reduce((s, p) => s + (p.totalGainUSD || 0), 0);
      const holdingsGrowthAvg = costBasis > 0
        ? (gainUSD / costBasis) * 100
        : (mPositions.length > 0 ? mPositions.reduce((s, p) => s + (p.totalGainPercent || 0), 0) / mPositions.length : null);
      
      const mStocks = stocks.filter((s) => s.marketType === mType);
      const marketAvg = mStocks.length > 0
        ? mStocks.reduce((s, stk) => s + (stk.changePercent || 0), 0) / mStocks.length
        : 0;

      return {
        holdingsCount: mPositions.length,
        growthAvg: holdingsGrowthAvg !== null ? holdingsGrowthAvg : marketAvg,
        isHoldingsGrowth: holdingsGrowthAvg !== null,
        marketAvg,
      };
    };

    return {
      final: calcStats('final'),
    };
  }, [positions, stocks]);

  // Favorite (Watchlist) Stats
  const favoriteStocksList = useMemo(() => {
    return stocks.filter((s) => watchlist.some((w) => w.toUpperCase() === s.ticker.toUpperCase()));
  }, [stocks, watchlist]);

  const favoritePositionsList = useMemo(() => {
    return positions.filter((p) => watchlist.some((w) => w.toUpperCase() === p.ticker.toUpperCase()));
  }, [positions, watchlist]);

  const favoriteGrowthAvg = useMemo(() => {
    if (favoriteStocksList.length > 0) {
      return favoriteStocksList.reduce((s, stk) => s + (stk.changePercent || 0), 0) / favoriteStocksList.length;
    }
    return 0;
  }, [favoriteStocksList]);

  // Filter stocks for the active market mode
  const marketScopedStocks = useMemo(() => {
    if (selectedMarketWay === 'all' || selectedMarketWay === 'social') return stocks;
    return stocks.filter((s) => s.marketType === selectedMarketWay);
  }, [stocks, selectedMarketWay]);

  // Extract sectors in this market for chips
  const availableSectors = useMemo(() => {
    const sectors = new Set<string>();
    marketScopedStocks.forEach((s) => sectors.add(s.sector));
    return Array.from(sectors);
  }, [marketScopedStocks]);

  // Filtered & Sorted Equities in this market mode
  const displayedMarketStocks = useMemo(() => {
    let result = [...marketScopedStocks];

    // Text search in this market (supports ticker, company name, personal/business category, and issuance coin like AFNL, USDC, BTC, USD)
    if (marketSearchQuery.trim()) {
      result = result.filter((s) => matchStockSearch(s, marketSearchQuery));
    }

    // Sector Filter
    if (selectedSectorFilter !== 'all') {
      result = result.filter((s) => s.sector === selectedSectorFilter);
    }

    // Helper parsing for sorting
    const parseVol = (v?: string) => {
      if (!v) return 0;
      const num = parseFloat(v);
      if (v.includes('B') || v.includes('b')) return num * 1e9;
      if (v.includes('M') || v.includes('m')) return num * 1e6;
      if (v.includes('K') || v.includes('k')) return num * 1e3;
      return num || 0;
    };
    const parseCap = (c?: string) => {
      if (!c) return 0;
      const num = parseFloat(c.replace('$', ''));
      if (c.includes('T') || c.includes('t')) return num * 1e12;
      if (c.includes('B') || c.includes('b')) return num * 1e9;
      if (c.includes('M') || c.includes('m')) return num * 1e6;
      return num || 0;
    };

    // Sorting
    result.sort((a, b) => {
      if (sortBy === 'gainers') return b.changePercent - a.changePercent;
      if (sortBy === 'price') return b.price - a.price;
      if (sortBy === 'volume') return parseVol(b.volume) - parseVol(a.volume);
      if (sortBy === 'alphabetical') return a.ticker.localeCompare(b.ticker);
      // Default: market cap
      return parseCap(b.marketCap) - parseCap(a.marketCap);
    });

    return result;
  }, [marketScopedStocks, marketSearchQuery, selectedSectorFilter, sortBy]);

  // Filter news based on selected market architecture
  const filteredNews = useMemo(() => {
    if (selectedMarketWay === 'all' || selectedMarketWay === 'social') return BREAKING_STOCK_NEWS;
    const marketTickers = new Set(stocks.filter(s => s.marketType === selectedMarketWay).map(s => s.ticker));
    const matching = BREAKING_STOCK_NEWS.filter(item => 
      item.tickers?.some(t => marketTickers.has(t))
    );
    return matching.length > 0 ? matching : BREAKING_STOCK_NEWS;
  }, [selectedMarketWay, stocks]);

  const getMarketBadgeUI = (marketType?: StockMarketWay) => {
    switch (marketType) {
      case 'final':
        return { label: 'Final Stock', coin: 'AFNL', bg: 'bg-amber-100 text-amber-900 border-amber-300', icon: Zap };
      case 'stable':
        return { label: 'Stable Stock', coin: '$USDC', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300', icon: ShieldCheck };
      case 'fiat':
        return { label: 'Fiat Stock', coin: '$USD', bg: 'bg-indigo-100 text-indigo-900 border-indigo-300', icon: Building2 };
      case 'crypto':
        return { label: 'Crypto Stock', coin: '$BTC', bg: 'bg-purple-100 text-purple-900 border-purple-300', icon: Coins };
      case 'global':
        return { label: 'Global Stock', coin: 'Alpaca', bg: 'bg-sky-100 text-sky-900 border-sky-300', icon: Globe };
      default:
        return { label: 'Unified Equity', coin: 'Multi', bg: 'bg-slate-100 text-slate-800 border-slate-200', icon: Globe };
    }
  };

  const handleSelectAlpacaAsset = async (asset: any, snapshot: any) => {
    if (!asset || !snapshot) return;

    // Map Alpaca Asset to StockItem format
    const price = snapshot.latestTrade?.p || snapshot.dailyBar?.c || 0;
    const prevClose = snapshot.prevDailyBar?.c || price;
    const changeUSD = price - prevClose;
    const changePercent = prevClose !== 0 ? (changeUSD / prevClose) * 100 : 0;

    // Fetch some bars for the chart if possible
    let history: any = {
      '1D': [],
      '1W': [],
      '1M': [],
      '1Y': [],
      '5Y': []
    };

    try {
      const barsRes = await fetch(`/api/alpaca/bars/${asset.symbol}?timeframe=1Min&limit=100&asset_class=${asset.asset_class}`);
      const barsData = await barsRes.json();
      if (barsData.success && barsData.data.length > 0) {
        history['1D'] = barsData.data.map((b: any) => ({
          time: new Date(b.t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          price: b.c,
          volume: b.v,
          open: b.o,
          high: b.h,
          low: b.l,
          close: b.c
        }));
      } else {
        // Fallback to minimal data so chart doesn't crash
        history['1D'] = [
          { time: '9:30 AM', price: prevClose, volume: 0 },
          { time: 'Now', price: price, volume: 0 }
        ];
      }
    } catch (err) {
      console.error('Error fetching bars for detail page:', err);
      history['1D'] = [{ time: '9:30 AM', price: prevClose, volume: 0 }, { time: 'Now', price: price, volume: 0 }];
    }

    const mappedStock: StockItem = {
      ticker: asset.symbol,
      name: asset.name,
      price: price,
      changeUSD: changeUSD,
      changePercent: changePercent,
      marketType: 'global',
      exchange: asset.exchange,
      sector: 'All', 
      description: `${asset.name} is a global asset listed on ${asset.exchange}. Class: ${asset.asset_class}. Status: ${asset.status}. This asset is tracked in real-time via the Alpaca Unified Market Data API.`,
      high24h: snapshot.dailyBar?.h || price,
      low24h: snapshot.dailyBar?.l || price,
      openPrice: snapshot.dailyBar?.o || price,
      prevClose: prevClose,
      volume: snapshot.dailyBar?.v?.toLocaleString() || '0',
      avgVolume: 'N/A',
      marketCap: 'N/A',
      peRatio: 0,
      eps: 0,
      dividendYield: 'N/A',
      beta: 1.0,
      fiftyTwoWeekHigh: price * 1.2,
      fiftyTwoWeekLow: price * 0.8,
      analystRating: 'Hold',
      analystTargetUSD: price * 1.1,
      analystCount: 0,
      sparkline: history['1D'].map((p: any) => p.price),
      history: history
    };

    setViewingStockDetail(mappedStock);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6 pb-12 text-left">
      {/* 1. Global Equities Search Bar with Market Awareness (Removed) */}

      {viewingStockDetail ? (
        <StockDetailPage
          stock={viewingStockDetail}
          stocks={stocks}
          watchlist={watchlist}
          positions={positions}
          currentUser={currentUser}
          selectedMarketWay={selectedMarketWay}
          activeMarketTitle={activeMarketInfo?.title}
          onBackToMarkets={() => {
            setViewingStockDetail(null);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onSelectStock={handleSelectStock}
          onToggleWatchlist={handleToggleWatchlist}
          onOpenQuickTrade={handleOpenQuickTradeModal}
          onOpenAuthModal={onOpenAuthModal}
          onOrderExecuted={handleOrderExecuted}
        />
      ) : (
        <>
          {/* 3. THE WAYS OF STOCK MARKET SELECTOR TABS */}
      <div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
          {/* Way 1: Final Stock Market */}
          <button
            type="button"
            onClick={() => {
              setSelectedMarketWay('final');
              setMarketSearchQuery('');
              setSelectedSectorFilter('all');
              const firstFinal = stocks.find(s => s.marketType === 'final');
              if (firstFinal) setSelectedStock(firstFinal);
            }}
            className={`p-4 rounded-3xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 shadow-sm ${
              selectedMarketWay === 'final'
                ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-md ring-2 ring-amber-500/20'
                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                selectedMarketWay === 'final' ? 'bg-slate-950 text-amber-400' : 'bg-amber-100 text-amber-800'
              }`}>
                <Zap className="w-5 h-5" />
              </div>
              <span className={`text-[10px] font-mono font-bold px-2 py-1 rounded-full ${
                selectedMarketWay === 'final' ? 'bg-slate-950/20 text-slate-950' : 'bg-amber-100 text-amber-800'
              }`}>
                {marketTypeStats.final.holdingsCount} {marketTypeStats.final.holdingsCount === 1 ? 'Holding' : 'Holdings'}
              </span>
            </div>
            <div>
              <div className="font-bold text-base leading-tight">
                Final Stocks
              </div>
              <div className={`text-xs truncate mt-1 ${
                selectedMarketWay === 'final' ? 'text-slate-900 font-medium' : 'text-slate-500'
              }`}>
                {marketCounts.final} Assets Secured by Final Coin
              </div>
              <div className="text-xs font-mono font-bold flex items-center justify-between pt-2 mt-2 border-t border-current/20">
                <span className={selectedMarketWay === 'final' ? 'text-slate-900' : 'text-slate-500'}>Growth Avg:</span>
                <span className={selectedMarketWay === 'final' ? 'text-slate-950 font-extrabold' : (marketTypeStats.final.growthAvg >= 0 ? 'text-emerald-600' : 'text-rose-600')}>
                  {marketTypeStats.final.growthAvg >= 0 ? '+' : ''}{marketTypeStats.final.growthAvg.toFixed(2)}%
                </span>
              </div>
            </div>
          </button>

          {/* Way 5: Global Alpaca Lookup */}
          <button
            type="button"
            onClick={() => {
              setSelectedMarketWay('global');
              setMarketSearchQuery('');
              setSelectedSectorFilter('all');
            }}
            className={`p-4 rounded-3xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 shadow-sm ${
              selectedMarketWay === 'global'
                ? 'bg-sky-600 text-white border-sky-600 shadow-md ring-2 ring-sky-600/20'
                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                selectedMarketWay === 'global' ? 'bg-white text-sky-800' : 'bg-sky-100 text-sky-800'
              }`}>
                <Search className="w-5 h-5" />
              </div>
              <span className={`text-[10px] font-mono font-bold px-2 py-1 rounded-full ${
                selectedMarketWay === 'global' ? 'bg-white/20 text-white' : 'bg-sky-100 text-sky-800'
              }`}>
                Live Lookup
              </span>
            </div>
            <div>
              <div className="font-bold text-base leading-tight">
                Regular Stocks
              </div>
              <div className={`text-xs truncate mt-1 ${
                selectedMarketWay === 'global' ? 'text-sky-100 font-medium' : 'text-slate-500'
              }`}>
                Stock/Stable/Crypto Registry
              </div>
              <div className="text-xs font-mono font-bold flex items-center justify-between pt-2 mt-2 border-t border-current/20">
                <span className={selectedMarketWay === 'global' ? 'text-sky-100' : 'text-slate-500'}>Powered By:</span>
                <span className={selectedMarketWay === 'global' ? 'text-white' : 'text-slate-600'}>
                  Alpaca Institutional API
                </span>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* 4. DEDICATED IN-MARKET EQUITIES SEARCH & DIRECTORY */}
      {selectedMarketWay === 'global' ? (
        <AlpacaAssetLookup 
          onSelectAsset={handleSelectAlpacaAsset}
        />
      ) : selectedMarketWay === 'final' ? (
        <div className={`bg-white ${isEquitiesCollapsed ? 'p-4 sm:p-5' : 'space-y-4 p-5 sm:p-6'} rounded-3xl border border-slate-200 shadow-2xs transition-all`}>
          <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${isEquitiesCollapsed ? '' : 'pb-3 border-b border-slate-100'}`}>
            <div 
              onClick={() => setIsEquitiesCollapsed(!isEquitiesCollapsed)}
              className="cursor-pointer group select-none inline-block"
              title={isEquitiesCollapsed ? "Click to expand equities directory" : "Click to collapse equities directory"}
            >
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-serif font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                  {`${activeMarketInfo?.title || 'Equities Directory'}`}
                </h2>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {displayedMarketStocks.length} Assets
                </span>
                <span className="w-6 h-6 rounded-lg bg-slate-100 group-hover:bg-amber-100 text-slate-500 group-hover:text-amber-700 transition-colors inline-flex items-center justify-center">
                  {isEquitiesCollapsed ? (
                    <ChevronDown className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronUp className="w-3.5 h-3.5" />
                  )}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {isEquitiesCollapsed 
                  ? 'Click to expand search, sector filters, price charts, & asset list.'
                  : 'Search, filter, analyze charts, and 1-click trade equities in this market mode.'}
              </p>
            </div>

            {!isEquitiesCollapsed && (
              <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                {/* Sort Filter */}
                <div className="flex items-center gap-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5">
                  <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-500 font-medium">Sort:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-transparent font-bold text-slate-800 focus:outline-hidden cursor-pointer"
                  >
                    <option value="marketCap">Highest Value</option>
                    <option value="gainers">Top Gainers (%)</option>
                    <option value="volume">24h Volume</option>
                    <option value="price">Highest Price</option>
                    <option value="alphabetical">Symbol (A-Z)</option>
                  </select>
                </div>

                {/* View Mode Toggle */}
                <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setViewMode('grid')}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      viewMode === 'grid' ? 'bg-white shadow-xs text-slate-900 font-bold' : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="Grid View"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode('table')}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      viewMode === 'table' ? 'bg-white shadow-xs text-slate-900 font-bold' : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="Table View"
                  >
                    <List className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {!isEquitiesCollapsed && (
            <>
              {/* Stock Market Local Hours Bar */}
              <div className="mb-4">
                <StockMarketHoursBar />
              </div>
              {/* Search Input and Sector Filter Chips */}
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={marketSearchQuery}
                    onChange={(e) => setMarketSearchQuery(e.target.value)}
                    placeholder="Search stocks by symbol ($ALEX, $NEXA), name, or sector..."
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 focus:border-amber-500 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-400/20 font-sans shadow-2xs transition-all"
                  />
                  {marketSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setMarketSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Sector Filter Chips */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 pr-1">
                    Sector:
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedSectorFilter('all')}
                    className={`px-3 py-1 rounded-xl font-medium shrink-0 transition-colors cursor-pointer ${
                      selectedSectorFilter === 'all'
                        ? 'bg-slate-900 text-white font-bold shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    All Sectors ({marketScopedStocks.length})
                  </button>
                  {availableSectors.map((sector) => {
                    const count = marketScopedStocks.filter((s) => s.sector === sector).length;
                    return (
                      <button
                        key={sector}
                        type="button"
                        onClick={() => setSelectedSectorFilter(sector)}
                        className={`px-3 py-1 rounded-xl font-medium shrink-0 transition-colors cursor-pointer ${
                          selectedSectorFilter === sector
                            ? 'bg-slate-900 text-white font-bold shadow-xs'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        {sector} ({count})
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Stock List / Grid */}
              {displayedMarketStocks.length === 0 ? (
                <div className="py-12 px-4 text-center text-slate-500 text-xs bg-slate-50 rounded-2xl border border-slate-100">
                  <Building2 className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                  <p className="font-semibold text-slate-700 text-sm">No stocks matching your search</p>
                  <p className="text-xs text-slate-400 mt-1">Try clearing your search query or selecting "All Sectors".</p>
                  <button
                    type="button"
                    onClick={() => {
                      setMarketSearchQuery('');
                      setSelectedSectorFilter('all');
                    }}
                    className="mt-3 px-4 py-1.5 rounded-xl bg-slate-900 text-white font-bold text-xs shadow-xs hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    Reset Search &amp; Filters
                  </button>
                </div>
              ) : viewMode === 'grid' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {displayedMarketStocks.map((stock) => {
                    const isPos = stock.changeUSD >= 0;
                    const isOwned = positions.some((p) => p.ticker === stock.ticker);
                    const isFollowed = watchlist.includes(stock.ticker);
                    const badge = getMarketBadgeUI(stock.marketType);

                    return (
                      <div
                        key={stock.ticker}
                        onClick={() => handleSelectStock(stock)}
                        className="p-4 rounded-2xl border bg-white hover:bg-slate-50/80 border-slate-200/90 hover:border-slate-300 shadow-2xs hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between gap-3 group relative"
                      >
                        {/* Top: Ticker, Name, Market Badge, Watchlist */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs shrink-0 shadow-2xs group-hover:bg-amber-600 transition-colors">
                              {stock.ticker}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-mono font-bold text-sm text-slate-900 group-hover:text-amber-800">
                                  ${stock.ticker}
                                </span>
                                <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border ${badge.bg}`}>
                                  {badge.coin}
                                </span>
                                {isOwned && (
                                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                                    Owned
                                  </span>
                                )}
                              </div>
                              <h3 className="text-xs text-slate-600 font-medium truncate mt-0.5">
                                {stock.name}
                              </h3>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleWatchlist(stock.ticker);
                            }}
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              isFollowed ? 'text-amber-500 hover:bg-amber-50' : 'text-slate-300 hover:text-slate-500 hover:bg-slate-100'
                            }`}
                            title={isFollowed ? 'Remove from Watchlist' : 'Add to Watchlist'}
                          >
                            <Star className={`w-4 h-4 ${isFollowed ? 'fill-amber-400' : ''}`} />
                          </button>
                        </div>

                        {/* Mid: Price & 24h Change */}
                        <div className="flex items-baseline justify-between pt-1 border-t border-slate-100">
                          <div>
                            <span className="text-[10px] text-slate-400 uppercase font-mono block">Price</span>
                            <span className="font-mono font-bold text-base text-slate-900">
                              {formatStockPrice(stock.price, stock)}
                            </span>
                          </div>

                          <div className="text-right">
                            <span className="text-[10px] text-slate-400 uppercase font-mono block">24h Gain</span>
                            <span
                              className={`text-xs font-mono font-bold px-2 py-0.5 rounded-lg inline-flex items-center gap-0.5 ${
                                isPos ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                              }`}
                            >
                              {isPos ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                              <span>{isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%</span>
                            </span>
                          </div>
                        </div>

                        {/* Details / Sector */}
                        <div className="text-[11px] text-slate-500 flex items-center justify-between">
                          <span className="truncate max-w-[130px]">{stock.sector}</span>
                          <span className="font-mono text-[10px] text-slate-400">Vol: {stock.volume || stock.avgVolume || 'N/A'}</span>
                        </div>

                        {/* IPO Type for Final Stocks */}
                        {stock.marketType === 'final' && (stock.issuanceType === 'personal' || stock.issuanceType === 'business') && (
                          <div className="text-[9px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 inline-block">
                            {stock.issuanceType === 'personal' ? 'Personal IPO' : 'Business IPO'}
                          </div>
                        )}

                        {/* Actions: Quick 1-Click Buy / Sell / Chart */}
                        <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenQuickTradeModal(stock, 'buy');
                            }}
                            className="flex-1 py-1.5 px-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1 shadow-2xs cursor-pointer"
                          >
                            <Zap className="w-3.5 h-3.5 text-amber-400" />
                            <span>Buy ({badge.coin})</span>
                          </button>

                          {isOwned && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenQuickTradeModal(stock, 'sell');
                              }}
                              className="py-1.5 px-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs transition-colors border border-rose-200 cursor-pointer"
                            >
                              Sell
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSelectStock(stock);
                            }}
                            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                            title="Inspect Chart"
                          >
                            <BarChart3 className="w-4 h-4 text-slate-600" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Table View */
                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left text-xs divide-y divide-slate-100">
                    <thead className="bg-slate-50 text-[11px] font-mono text-slate-500 uppercase">
                      <tr>
                        <th className="py-3 px-4">Equity</th>
                        <th className="py-3 px-4">Sector</th>
                        <th className="py-3 px-4">Market Backing</th>
                        <th className="py-3 px-4 text-right">Price</th>
                        <th className="py-3 px-4 text-right">24h Change</th>
                        <th className="py-3 px-4 text-right">24h Volume</th>
                        <th className="py-3 px-4 text-center">Trade Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {displayedMarketStocks.map((stock) => {
                        const isPos = stock.changeUSD >= 0;
                        const isOwned = positions.some((p) => p.ticker === stock.ticker);
                        const badge = getMarketBadgeUI(stock.marketType);

                        return (
                          <tr
                            key={stock.ticker}
                            onClick={() => handleSelectStock(stock)}
                            className="hover:bg-slate-50/80 transition-colors cursor-pointer"
                          >
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2.5">
                                <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs shrink-0">
                                  {stock.ticker}
                                </div>
                                <div>
                                  <div className="font-mono font-bold text-slate-900 flex items-center gap-1.5">
                                    <span>${stock.ticker}</span>
                                    {isOwned && (
                                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                                        Owned
                                      </span>
                                    )}
                                  </div>
                                  <span className="text-[11px] text-slate-500">{stock.name}</span>
                                </div>
                              </div>
                            </td>
                            <td className="py-3 px-4 text-slate-600">
                              {stock.sector}
                            </td>
                            <td className="py-3 px-4">
                              <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${badge.bg}`}>
                                {badge.label} ({badge.coin})
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                              {formatStockPrice(stock.price, stock)}
                            </td>
                            <td className={`py-3 px-4 text-right font-mono font-bold ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%
                            </td>
                            <td className="py-3 px-4 text-right font-mono text-slate-500">
                              {stock.volume || stock.avgVolume || 'N/A'}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenQuickTradeModal(stock, 'buy');
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer"
                                >
                                  Buy
                                </button>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleSelectStock(stock);
                                  }}
                                  className="p-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                                  title="Inspect Chart"
                                >
                                  <BarChart3 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </div>
      ) : null}



      {/* 8. Trending Stocks News Feed Filtered by Market */}
      <StockNewsFeed
        news={filteredNews}
        stocks={stocks}
        ownedTickers={positions.map((p) => p.ticker)}
        followedTickers={watchlist}
        onSelectTicker={(ticker) => {
          const found = stocks.find((s) => s.ticker === ticker);
          if (found) {
            handleSelectStock(found);
          }
        }}
        onQuickTrade={(ticker) => {
          const found = stocks.find((s) => s.ticker === ticker);
          if (found) {
            handleOpenQuickTradeModal(found, 'buy');
          }
        }}
      />
        
      

      {/* 9. Quick 1-Click Buy / Sell Modal */}
      <QuickBuyStockModal
        stock={quickTradeStock}
        currentUser={currentUser}
        isOpen={!!quickTradeStock}
        initialSide={quickTradeSide}
        positions={positions}
        onClose={() => setQuickTradeStock(null)}
        onOpenAuthModal={onOpenAuthModal}
        onLookUpChart={(stock) => {
          handleSelectStock(stock);
          setQuickTradeStock(null);
        }}
        onExecuteBuy={handleOrderExecuted}
      />

      {/* 10. Official Trade Confirmation Receipt Slip Modal */}
      <TradeConfirmationModal
        order={selectedReceiptOrder}
        onClose={() => setSelectedReceiptOrder(null)}
        onViewPortfolio={() => {
          setSelectedReceiptOrder(null);
          onNavigateBack();
        }}
      />
        </>
      )}
    </div>
  );
};
