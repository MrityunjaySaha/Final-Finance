import React, { useState, useEffect, useMemo } from 'react';
import { 
  Briefcase, 
  Building, 
  User, 
  Search, 
  TrendingUp, 
  TrendingDown,
  ExternalLink, 
  ShieldCheck, 
  Zap, 
  Coins, 
  Building2, 
  Plus, 
  Layers,
  ArrowRight,
  Filter,
  CheckCircle2,
  Sparkles,
  Star,
  Users,
  Radio,
  Clock,
  DollarSign,
  Globe
} from 'lucide-react';
import { StockMarketWay, StockItem } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { SocialTradesFeed } from '../stocks/SocialTradesFeed';
import { IPORequest } from '../../types/stocks';
import { MyIPOsTab } from './MyIPOsTab';
import { CurrenciesDirectoryAndWalletView } from './CurrenciesDirectoryAndWalletView';
import { FinalStocksTradeOptionsModal } from './FinalStocksTradeOptionsModal';

export interface EnrichedStockPosition {
  ticker: string;
  name: string;
  shares: number;
  avgCostUSD: number;
  currentPriceUSD: number;
  totalValueUSD: number;
  totalGainUSD: number;
  totalGainPercent: number;
  sector: string;
  subSector?: string;
  marketType: StockMarketWay;
  settlementMethod: string;
  assetCategory: 'business' | 'personal' | 'spot';
  isSpotStock?: boolean;
  isEquity?: boolean;
  issuerName?: string;
  issuerHandle?: string;
  issuerAvatar?: string;
  ipoDetails?: any;
}

interface PurchasedEquityHoldingsViewProps {
  enrichedPositions: EnrichedStockPosition[];
  businessPositions: EnrichedStockPosition[];
  personalPositions: EnrichedStockPosition[];
  businessNAV: number;
  personalNAV: number;
  businessGainUSD: number;
  personalGainUSD: number;
  businessGainPercent: number;
  personalGainPercent: number;
  totalStockPositionsUSD: number;
  totalStockGainUSD: number;
  totalStockCostBasisUSD: number;
  totalStockGainPercent: number;
  selectedMarketFilter: StockMarketWay | null;
  onSelectMarketFilter: (market: StockMarketWay | null) => void;
  assetCategoryFilter: 'all' | 'business' | 'personal';
  onSelectAssetCategoryFilter: (cat: 'all' | 'business' | 'personal') => void;
  searchQuery: string;
  onSearchQueryChange: (q: string) => void;
  stocks: StockItem[];
  watchlist?: string[];
  ipos?: IPORequest[];
  onToggleWatchlist?: (ticker: string) => void;
  filteredFollowedStocks?: StockItem[];
  currentUser?: AuthSession | null;
  activeSubTab?: 'owned' | 'following' | 'social_trades' | 'my_ipos' | 'currencies' | 'coin_launchpad';
  onSelectSubTab?: (tab: 'owned' | 'following' | 'social_trades' | 'my_ipos' | 'currencies' | 'coin_launchpad') => void;
  onSelectStock?: (stock: StockItem) => void;
  onOpenTradeModal: (tickerOrStock: string | StockItem, side: 'buy' | 'sell') => void;
  onOpenStockMarket?: (marketWay?: StockMarketWay | 'all') => void;
  onOpenReleaseModal?: () => void;
  onRequestDelist?: (ipo: IPORequest) => void;
  onSwitchToPortfolioTab?: () => void;
  onSwitchToDerivativesTab?: () => void;
}

export const PurchasedEquityHoldingsView: React.FC<PurchasedEquityHoldingsViewProps> = ({
  enrichedPositions,
  businessPositions,
  personalPositions,
  businessNAV,
  personalNAV,
  businessGainUSD,
  personalGainUSD,
  businessGainPercent,
  personalGainPercent,
  totalStockPositionsUSD,
  totalStockGainUSD,
  totalStockCostBasisUSD,
  totalStockGainPercent,
  selectedMarketFilter,
  onSelectMarketFilter,
  assetCategoryFilter,
  onSelectAssetCategoryFilter,
  searchQuery,
  onSearchQueryChange,
  stocks,
  watchlist = [],
  ipos = [],
  onToggleWatchlist,
  filteredFollowedStocks,
  currentUser,
  activeSubTab = 'owned',
  onSelectSubTab,
  onSelectStock,
  onOpenTradeModal,
  onOpenStockMarket,
  onOpenReleaseModal,
  onRequestDelist,
  onSwitchToPortfolioTab,
  onSwitchToDerivativesTab,
}) => {
  // Final Stocks Trade Options Modal State
  const [isFinalTradeOptionsModalOpen, setIsFinalTradeOptionsModalOpen] = useState(false);

  // Sub-tabs state: 'owned' | 'following' | 'social_trades' | 'my_ipos' | 'currencies' | 'coin_launchpad'
  const [currentSubTab, setCurrentSubTab] = useState<'owned' | 'following' | 'social_trades' | 'my_ipos' | 'currencies' | 'coin_launchpad'>(activeSubTab || 'owned');

  useEffect(() => {
    if (activeSubTab) {
      setCurrentSubTab(activeSubTab);
    }
  }, [activeSubTab]);

  const handleSubTabChange = (tab: 'owned' | 'following' | 'social_trades' | 'my_ipos' | 'currencies' | 'coin_launchpad') => {
    setCurrentSubTab(tab);
    if (onSelectSubTab) onSelectSubTab(tab);
    onSearchQueryChange('');
  };

  // Followed stocks calculation
  const followedStocksList = useMemo(() => {
    if (filteredFollowedStocks) return filteredFollowedStocks;
    return stocks.filter((s) => {
      const isWatched = watchlist.some((w) => w.toUpperCase() === s.ticker.toUpperCase());
      if (!isWatched) return false;
      if (selectedMarketFilter && s.marketType !== selectedMarketFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().replace(/^\$/, '');
        return s.ticker.toLowerCase().includes(q) || s.name.toLowerCase().includes(q) || s.sector.toLowerCase().includes(q);
      }
      return true;
    });
  }, [stocks, watchlist, selectedMarketFilter, searchQuery, filteredFollowedStocks]);

  // Position ownership map for quick lookup
  const ownedPositionsMap = useMemo(() => {
    const map = new Map<string, EnrichedStockPosition>();
    enrichedPositions.forEach((p) => map.set(p.ticker.toUpperCase(), p));
    return map;
  }, [enrichedPositions]);

  // Filtered positions based on market filter, asset category, and search query
  const filteredPositions = enrichedPositions.filter((p) => {
    // Strict Guard: Stocks bought on spot must NEVER appear in Equity! Equity is ONLY for personal and business stocks!
    if (p.isSpotStock || p.assetCategory === 'spot' || (p as any).isEquity === false) {
      return false;
    }
    if (selectedMarketFilter && p.marketType !== selectedMarketFilter) {
      return false;
    }
    if (assetCategoryFilter !== 'all' && p.assetCategory !== assetCategoryFilter) {
      return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.trim().toLowerCase().replace(/^\$/, '');
    
    // Check coin keywords and market types
    if (q === 'fnl' || q === 'final') {
      if (p.marketType === 'final' || p.settlementMethod.toLowerCase().includes('final')) return true;
    }
    if (q === 'usdc' || q === 'usdt' || q === 'stable' || q === 'stablecoin') {
      if (p.marketType === 'stable' || p.settlementMethod.toLowerCase().includes('stable') || p.settlementMethod.toLowerCase().includes('usdc')) return true;
    }
    if (q === 'usd' || q === 'fiat' || q === 'dollar') {
      if (p.marketType === 'fiat' || p.settlementMethod.toLowerCase().includes('fiat') || p.settlementMethod.toLowerCase().includes('usd')) return true;
    }
    if (q === 'btc' || q === 'crypto' || q === 'bitcoin' || q === 'sol' || q === 'eth') {
      if (p.marketType === 'crypto' || p.settlementMethod.toLowerCase().includes('crypto') || p.settlementMethod.toLowerCase().includes('btc')) return true;
    }
    if (q === 'personal' || q === 'sovereign' || q === 'individual') {
      if (p.assetCategory === 'personal') return true;
    }
    if (q === 'business' || q === 'corporate' || q === 'company' || q === 'corp') {
      if (p.assetCategory === 'business') return true;
    }

    return (
      p.ticker.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.sector.toLowerCase().includes(q) ||
      (p.subSector && p.subSector.toLowerCase().includes(q)) ||
      p.assetCategory.toLowerCase().includes(q) ||
      (p.issuerName && p.issuerName.toLowerCase().includes(q)) ||
      (p.issuerHandle && p.issuerHandle.toLowerCase().includes(q)) ||
      (p.settlementMethod && p.settlementMethod.toLowerCase().includes(q))
    );
  });

  const getMarketBadge = (marketType?: StockMarketWay | null) => {
    switch (marketType) {
      case 'final':
        return {
          label: 'Final Stocks',
          shortLabel: 'Final',
          coin: 'Final Coins ($AFNL)',
          icon: Zap,
          bg: 'bg-amber-500/10 text-amber-900 border-amber-500/30',
          dot: 'bg-amber-500'
        };
      case 'stable':
        return {
          label: 'Stable Stocks',
          shortLabel: 'Stable',
          coin: 'Stablecoins ($USDC)',
          icon: ShieldCheck,
          bg: 'bg-emerald-500/10 text-emerald-900 border-emerald-500/30',
          dot: 'bg-emerald-500'
        };
      case 'crypto':
        return {
          label: 'Crypto Stocks',
          shortLabel: 'Crypto',
          coin: 'Cryptocurrency ($BTC)',
          icon: Coins,
          bg: 'bg-purple-500/10 text-purple-900 border-purple-500/30',
          dot: 'bg-purple-500'
        };
      case 'fiat':
        return {
          label: 'Fiat Stocks',
          shortLabel: 'Fiat',
          coin: 'Fiat USD ($USD)',
          icon: Building2,
          bg: 'bg-indigo-500/10 text-indigo-900 border-indigo-500/30',
          dot: 'bg-indigo-500'
        };
      default:
        return {
          label: 'All Markets',
          shortLabel: 'All',
          coin: 'All Settlement Currencies',
          icon: Layers,
          bg: 'bg-slate-100 text-slate-800 border-slate-200',
          dot: 'bg-slate-500'
        };
    }
  };

  const getMarketStats = (marketType: StockMarketWay) => {
    const mPositions = enrichedPositions.filter((p) => p.marketType === marketType);
    const holdingsCount = mPositions.length;
    const costBasis = mPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0);
    const gainUSD = mPositions.reduce((s, p) => s + p.totalGainUSD, 0);
    const totalVal = mPositions.reduce((s, p) => s + p.totalValueUSD, 0);

    const holdingsGainPct = costBasis > 0
      ? (gainUSD / costBasis) * 100
      : (mPositions.length > 0 ? mPositions.reduce((s, p) => s + p.totalGainPercent, 0) / mPositions.length : null);

    const mStocks = stocks.filter((s) => s.marketType === marketType);
    const marketAvg = mStocks.length > 0
      ? mStocks.reduce((s, stk) => s + (stk.changePercent || 0), 0) / mStocks.length
      : 0;

    return {
      holdingsCount,
      hasHoldings: holdingsCount > 0,
      growthAvg: holdingsGainPct !== null ? holdingsGainPct : marketAvg,
      isHoldingsGrowth: holdingsGainPct !== null,
      marketAvg,
      totalVal,
    };
  };

  const favoriteGrowthAvg = useMemo(() => {
    if (followedStocksList.length > 0) {
      return followedStocksList.reduce((s, stk) => s + (stk.changePercent || 0), 0) / followedStocksList.length;
    }
    return 0;
  }, [followedStocksList]);

  const finalStats = getMarketStats('final');
  const stableStats = getMarketStats('stable');
  const fiatStats = getMarketStats('fiat');
  const cryptoStats = getMarketStats('crypto');

  return (
    <div className="space-y-6 text-left">
      {/* 1. TOP OVERVIEW REMOVED PER USER REQUEST */}
      
      <div className="p-6 sm:p-7 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 flex items-center gap-2.5">
                <Briefcase className="w-6 h-6 text-emerald-600" />
                <span>Equity</span>
              </h1>
            </div>
          </div>
        </div>

        {/* 2. EXCLUSIVE MARKET TYPE: FINAL STOCKS SETTLED WITH FINAL COINS ($AFNL) */}
        <div className="space-y-2">
          <div className="grid grid-cols-1 gap-2.5">
            {/* 1. Final Stocks */}
            <div
              className="p-4 sm:p-5 rounded-2xl border transition-all bg-amber-50/60 border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-left shadow-2xs"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-700 flex items-center justify-center">
                    <Zap className="w-4 h-4 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-900 flex items-center gap-2">
                      <span>Final Stocks Portfolio</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-900">
                        {finalStats.holdingsCount} {finalStats.holdingsCount === 1 ? 'Holding' : 'Holdings'}
                      </span>
                    </h3>
                    <div className="text-[11px] font-mono text-slate-600 flex items-center gap-1.5 mt-0.5">
                      <span>Equity Growth Avg:</span>
                      <span className={`font-bold ${finalStats.growthAvg >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {finalStats.growthAvg >= 0 ? '' : '-'}{Math.abs(finalStats.growthAvg).toFixed(2)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  id="final-stocks-all-trade-options-btn"
                  type="button"
                  onClick={() => setIsFinalTradeOptionsModalOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 active:bg-amber-700 text-white font-bold text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer shadow-xs hover:shadow-sm whitespace-nowrap"
                >
                  <Zap className="w-4 h-4 text-amber-200 fill-amber-200" />
                  <span>Trade Options</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 3. CATEGORY CARDS: BUSINESSES VS PERSONAL STOCKS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {/* Business Equities Card */}
          <div 
            onClick={() => {
              if (currentSubTab !== 'owned') setCurrentSubTab('owned');
              onSelectAssetCategoryFilter(assetCategoryFilter === 'business' ? 'all' : 'business');
            }}
            className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer ${
              assetCategoryFilter === 'business' && currentSubTab === 'owned'
                ? 'bg-blue-50/80 border-blue-300 ring-2 ring-blue-500/20 shadow-xs'
                : 'bg-slate-50/80 hover:bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between pb-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-700 flex items-center justify-center">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm text-slate-900 flex items-center gap-1.5">
                    <span>Invested Businesses</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                      {businessPositions.length} {businessPositions.length === 1 ? 'Holding' : 'Holdings'}
                    </span>
                  </h3>
                  <div className="text-[11px] font-mono text-slate-600 flex items-center gap-1 mt-0.5">
                    <span>Growth Avg:</span>
                    <span className={`font-bold ${businessGainPercent >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {businessGainPercent >= 0 ? '' : '-'}{Math.abs(businessGainPercent).toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
              {assetCategoryFilter === 'business' && currentSubTab === 'owned' && (
                <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-md">
                  Active Filter
                </span>
              )}
            </div>

            <div className="pt-3 flex items-baseline justify-between border-t border-slate-200/60">
              <div>
                <span className="text-[10px] uppercase font-mono text-slate-400 block">Total Business (Final Coins)</span>
                <span className="font-mono text-lg sm:text-xl font-bold text-slate-900">
                  {businessNAV.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-mono text-slate-400 block">Total Return</span>
                <span className={`text-xs font-mono font-bold ${businessGainUSD >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {businessGainUSD >= 0 ? '' : '-'}{Math.abs(businessGainUSD).toLocaleString(undefined, { minimumFractionDigits: 2 })} ({businessGainPercent >= 0 ? '+' : ''}{businessGainPercent.toFixed(2)}%)
                </span>
              </div>
            </div>
          </div>

          {/* Personal Equities Card (Human Equity) */}
          <div 
            onClick={() => {
              if (currentSubTab !== 'owned') setCurrentSubTab('owned');
              onSelectAssetCategoryFilter(assetCategoryFilter === 'personal' ? 'all' : 'personal');
            }}
            className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer ${
              assetCategoryFilter === 'personal' && currentSubTab === 'owned'
                ? 'bg-purple-50/80 border-purple-300 ring-2 ring-purple-500/20 shadow-xs'
                : 'bg-slate-50/80 hover:bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between pb-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-700 flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm text-slate-900 flex items-center gap-1.5">
                    <span>Invested Human Equity (Personal Stocks)</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">
                      {personalPositions.length} {personalPositions.length === 1 ? 'Holding' : 'Holdings'}
                    </span>
                  </h3>
                  <div className="text-[11px] font-mono text-slate-600 flex items-center gap-1 mt-0.5">
                    <span>Sovereign Human Capital Growth:</span>
                    <span className={`font-bold ${personalGainPercent >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {personalGainPercent >= 0 ? '' : '-'}{Math.abs(personalGainPercent).toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
              {assetCategoryFilter === 'personal' && currentSubTab === 'owned' && (
                <span className="text-[10px] font-mono font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-md">
                  Active Filter
                </span>
              )}
            </div>

            <div className="pt-3 flex items-baseline justify-between border-t border-slate-200/60">
              <div>
                <span className="text-[10px] uppercase font-mono text-slate-400 block">Total Personal (Final Coins)</span>
                <span className="font-mono text-lg sm:text-xl font-bold text-slate-900">
                  {personalNAV.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-mono text-slate-400 block">Total Return</span>
                <span className={`text-xs font-mono font-bold ${personalGainUSD >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {personalGainUSD >= 0 ? '' : '-'}{Math.abs(personalGainUSD).toLocaleString(undefined, { minimumFractionDigits: 2 })} ({personalGainPercent >= 0 ? '+' : ''}{personalGainPercent.toFixed(2)}%)
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. SUB-NAVIGATION: EQUITY I OWN | FAVORITE | TRADED BY FRIENDS & FAMOUS TRADERS */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          {/* Sub-tab 1: Equity I Own */}
          <button
            type="button"
            id="equity-subtab-owned"
            onClick={() => handleSubTabChange('owned')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-start gap-0.5 cursor-pointer whitespace-nowrap ${
              currentSubTab === 'owned'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-950 hover:bg-emerald-100/80 border border-emerald-200/60'
            }`}
          >
            <div className="flex items-center gap-2">
              <Briefcase className={`w-4 h-4 ${currentSubTab === 'owned' ? 'text-emerald-200' : 'text-emerald-700'}`} />
              <span>Equity</span>
            </div>
          </button>

          {/* Sub-tab 2: Favorites */}
          <button
            type="button"
            id="equity-subtab-following"
            onClick={() => handleSubTabChange('following')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-start gap-0.5 cursor-pointer whitespace-nowrap ${
              currentSubTab === 'following'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <Star className={`w-4 h-4 ${currentSubTab === 'following' ? 'fill-amber-400 text-amber-400' : 'text-amber-500 fill-amber-400'}`} />
              <span>Favorites</span>
            </div>
          </button>

          {/* Sub-tab 3: Traded by Friends and Famous Traders */}
          <button
            type="button"
            id="equity-subtab-social"
            onClick={() => handleSubTabChange('social_trades')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              currentSubTab === 'social_trades'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Users className="w-4 h-4 text-amber-400" />
            <span>Social</span>
          </button>

          {/* Sub-tab 4: My IPOs */}
          <button
            type="button"
            id="equity-subtab-myipos"
            onClick={() => handleSubTabChange('my_ipos')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              currentSubTab === 'my_ipos'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Building2 className="w-4 h-4 text-amber-400" />
            <span>My IPOs &amp; Issues</span>
          </button>

          {/* Sub-tab 5: Currencies */}
          <button
            type="button"
            id="equity-subtab-currencies"
            onClick={() => handleSubTabChange('currencies')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              currentSubTab === 'currencies'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Globe className="w-4 h-4 text-emerald-500" />
            <span>Currencies</span>
          </button>
        </div>
      </div>

      {/* 4. SUB-TAB VIEW CONTENT */}
      {/* ================= VIEW 1: EQUITY I OWN ================= */}
      {currentSubTab === 'owned' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-5">
          {/* Controls Bar: Category Pills, Market Pills & Search */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div className="flex flex-wrap items-center gap-2">
              {/* Asset Category Filters */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => onSelectAssetCategoryFilter('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    assetCategoryFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All
                </button>
                <button
                  type="button"
                  onClick={() => onSelectAssetCategoryFilter('business')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    assetCategoryFilter === 'business'
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Building className="w-3 h-3" />
                  <span>Businesses</span>
                </button>
                <button
                  type="button"
                  onClick={() => onSelectAssetCategoryFilter('personal')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    assetCategoryFilter === 'personal'
                      ? 'bg-purple-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <User className="w-3 h-3" />
                  <span>Personal</span>
                </button>
              </div>

              {/* Settlement Context Label Removed */}
            </div>

            {/* Search Box */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchQueryChange(e.target.value)}
                placeholder="Search holdings, ticker, issuer..."
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 font-mono"
              />
            </div>
          </div>

          {/* Holdings Table or Empty State */}
          {filteredPositions.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-2xs">
                <Briefcase className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                {searchQuery
                  ? `No owned equity positions match "${searchQuery}"`
                  : selectedMarketFilter
                  ? `No owned equity found in ${getMarketBadge(selectedMarketFilter).label}`
                  : assetCategoryFilter !== 'all'
                  ? `No owned ${assetCategoryFilter} equities found`
                  : 'No equity positions owned yet'}
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                You haven't bought any shares in this category yet. Explore the 4 Coin Stock Markets or Sovereign IPOs to purchase equities.
              </p>
              <div className="flex items-center justify-center gap-3 pt-2">
                {onOpenStockMarket && (
                  <button
                    type="button"
                    onClick={() => onOpenStockMarket(selectedMarketFilter || 'all')}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Browse Stock Markets</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => handleSubTabChange('following')}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                  <span>View Followed Equities</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                    <th className="py-3 px-3">Asset &amp; Issuer</th>
                    <th className="py-3 px-3">Type &amp; Category</th>
                    <th className="py-3 px-3">Market &amp; Coin</th>
                    <th className="py-3 px-3 text-right">Shares</th>
                    <th className="py-3 px-3 text-right hidden sm:table-cell">Avg Cost</th>
                    <th className="py-3 px-3 text-right">Market Price</th>
                    <th className="py-3 px-3 text-right">Total Value</th>
                    <th className="py-3 px-3 text-right">Total Return</th>
                    <th className="py-3 px-3 text-right">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredPositions.map((pos, idx) => {
                    const mBadge = getMarketBadge(pos.marketType);
                    const isPersonal = pos.assetCategory === 'personal';
                    const isPositive = pos.totalGainUSD >= 0;

                    return (
                      <tr key={`${pos.ticker}-${pos.marketType}-${idx}`} className="hover:bg-slate-50/80 transition-colors group">
                        {/* Asset & Issuer */}
                        <td className="py-3 px-3">
                          <div 
                            onClick={() => {
                              if (onSelectStock) {
                                const stockItem = stocks.find(s => s.ticker === pos.ticker) || {
                                  ticker: pos.ticker,
                                  name: pos.name,
                                  price: pos.currentPriceUSD,
                                  changeUSD: 0,
                                  changePercent: pos.totalGainPercent,
                                  marketCap: 'N/A',
                                  volume: 'N/A',
                                  sector: pos.sector,
                                  dayRange: 'N/A',
                                  marketType: pos.marketType,
                                  settlementMethod: pos.settlementMethod,
                                };
                                onSelectStock(stockItem as any);
                              }
                            }}
                            className="flex items-center gap-2.5 group/asset cursor-pointer"
                            title={`View stock page for $${pos.ticker}`}
                          >
                            <div className={`w-8 h-8 rounded-xl group-hover/asset:bg-emerald-600 transition-colors flex items-center justify-center font-bold text-xs shrink-0 ${
                              isPersonal 
                                ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                                : 'bg-slate-900 text-white'
                            }`}>
                              {pos.ticker.slice(0, 3)}
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-bold text-slate-900 group-hover/asset:text-emerald-600 font-mono transition-colors">${pos.ticker}</span>
                                {isPersonal && (
                                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-100 text-purple-700 border border-purple-200">
                                    Personal
                                  </span>
                                )}
                              </div>
                              <span className="text-[11px] text-slate-500 truncate block max-w-[140px] sm:max-w-[200px] group-hover/asset:underline">
                                {pos.name}
                              </span>
                              {pos.issuerName && (
                                <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                                  By {pos.issuerName}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* Type & Category */}
                        <td className="py-3 px-3">
                          <div className="space-y-0.5">
                            <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                              isPersonal 
                                ? 'bg-purple-50 text-purple-800 border-purple-200' 
                                : 'bg-blue-50 text-blue-800 border-blue-200'
                            }`}>
                              {isPersonal ? <User className="w-2.5 h-2.5" /> : <Building className="w-2.5 h-2.5" />}
                              <span>{isPersonal ? 'Personal Stock' : 'Business Stock'}</span>
                            </span>
                            <span className="text-[10px] text-slate-400 block font-mono">
                              {pos.sector}
                            </span>
                          </div>
                        </td>

                        {/* Market & Coin */}
                        <td className="py-3 px-3">
                          <div className="space-y-0.5">
                            <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${mBadge.bg}`}>
                              <mBadge.icon className="w-2.5 h-2.5" />
                              <span>{mBadge.label}</span>
                            </span>
                            <span className="text-[10px] text-slate-500 block font-mono">
                              {pos.settlementMethod}
                            </span>
                          </div>
                        </td>

                        {/* Shares */}
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                          {pos.shares.toLocaleString()}
                        </td>

                        {/* Avg Cost */}
                        <td className="py-3 px-3 text-right font-mono text-slate-600 hidden sm:table-cell">
                          {pos.avgCostUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* Market Price */}
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                          {pos.currentPriceUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* Total Value */}
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                          {pos.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* Total Return */}
                        <td className="py-3 px-3 text-right">
                          <div className="font-mono text-right">
                            <span className={`font-bold block ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {isPositive ? '' : '-'}{Math.abs(pos.totalGainUSD).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </span>
                            <span className={`text-[10px] block ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                              ({isPositive ? '+' : ''}{pos.totalGainPercent.toFixed(2)}%)
                            </span>
                          </div>
                        </td>

                        {/* Quick Actions */}
                        <td className="py-3 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenTradeModal(pos.ticker, 'buy')}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors cursor-pointer"
                            >
                              Buy More
                            </button>
                            <button
                              type="button"
                              onClick={() => onOpenTradeModal(pos.ticker, 'sell')}
                              className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                            >
                              Sell
                            </button>
                            {onSelectStock && (
                              <button
                                type="button"
                                onClick={() => {
                                  const stockItem = stocks.find(s => s.ticker === pos.ticker);
                                  if (stockItem) onSelectStock(stockItem);
                                }}
                                title="View full stock page"
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors cursor-pointer"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ================= VIEW 2: FAVORITE ================= */}
      {currentSubTab === 'following' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
                <span>Favorite</span>
                <span className="text-xs font-mono font-normal px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {followedStocksList.length} {followedStocksList.length === 1 ? 'Equity' : 'Equities'}
                </span>
                {selectedMarketFilter && (
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${getMarketBadge(selectedMarketFilter).bg}`}>
                    {getMarketBadge(selectedMarketFilter).label}
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Personal stock and business stock IPOs you are monitoring with real-time quotes and instant 1-click execution.
              </p>
            </div>

            {/* Search Box */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchQueryChange(e.target.value)}
                placeholder="Search followed stocks..."
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-amber-500 font-mono"
              />
            </div>
          </div>

          {/* Followed Equities Table */}
          {followedStocksList.length === 0 ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center mx-auto shadow-2xs">
                <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-800">
                  {searchQuery
                    ? `No followed equities match "${searchQuery}"`
                    : selectedMarketFilter
                    ? `You are not following any ${getMarketBadge(selectedMarketFilter).label} yet`
                    : 'You haven\'t followed or starred any equities yet'}
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Click the star icon next to any personal sovereign stock or corporate equity to monitor price action, dividends, and trade signals.
                </p>
              </div>

              {/* Recommended Popular Equities to Follow */}
              <div className="pt-4 max-w-xl mx-auto">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono block mb-2">
                  Popular Equities You May Be Interested In
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {stocks.slice(0, 6).map((stock) => {
                    const isWatched = watchlist.some((w) => w.toUpperCase() === stock.ticker.toUpperCase());
                    const isPersonal = stock.marketType === 'final' || stock.assetCategory === 'personal';

                    return (
                      <div 
                        key={stock.ticker}
                        className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 hover:bg-slate-100/80 transition-all flex items-center justify-between text-left"
                      >
                        <div className="min-w-0 pr-2">
                          <div className="flex items-center gap-1">
                            <span className="font-mono font-bold text-xs text-slate-900">${stock.ticker}</span>
                            <span className={`text-[8px] font-mono px-1 py-0.2 rounded ${
                              isPersonal ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                            }`}>
                              {isPersonal ? 'Personal' : 'Business'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-500 truncate block font-mono">
                            ${stock.price.toFixed(2)} ({stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(1)}%)
                          </span>
                        </div>

                        {onToggleWatchlist && (
                          <button
                            type="button"
                            onClick={() => onToggleWatchlist(stock.ticker)}
                            title={isWatched ? 'Remove from Favorites' : 'Add to Favorites'}
                            className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                              isWatched 
                                ? 'bg-amber-100 border-amber-300 text-amber-700' 
                                : 'bg-white border-slate-200 text-slate-400 hover:text-amber-500 hover:border-amber-300'
                            }`}
                          >
                            <Star className={`w-3.5 h-3.5 ${isWatched ? 'fill-amber-400 text-amber-500' : ''}`} />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {onOpenStockMarket && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => onOpenStockMarket('all')}
                    className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Browse All Active Market Equities</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                    <th className="py-3 px-3">Follow</th>
                    <th className="py-3 px-3">Asset &amp; Category</th>
                    <th className="py-3 px-3">Market Way</th>
                    <th className="py-3 px-3 text-right">Unit Price</th>
                    <th className="py-3 px-3 text-right">24h Change</th>
                    <th className="py-3 px-3 text-right hidden sm:table-cell">Market Cap / Vol</th>
                    <th className="py-3 px-3 text-right">My Position</th>
                    <th className="py-3 px-3 text-right">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {followedStocksList.map((stk, idx) => {
                    const mBadge = getMarketBadge(stk.marketType);
                    const isPositive = stk.changePercent >= 0;
                    const isPersonal = stk.marketType === 'final' || stk.assetCategory === 'personal';
                    const ownedPos = ownedPositionsMap.get(stk.ticker.toUpperCase());

                    return (
                      <tr key={`followed-${stk.ticker}-${idx}`} className="hover:bg-slate-50/80 transition-colors group">
                        {/* Star Button */}
                        <td className="py-3 px-3">
                          {onToggleWatchlist ? (
                            <button
                              type="button"
                              onClick={() => onToggleWatchlist(stk.ticker)}
                              title="Remove from followed equities"
                              className="p-1 rounded-md text-amber-500 hover:bg-amber-50 transition-colors cursor-pointer"
                            >
                              <Star className="w-4 h-4 fill-amber-400" />
                            </button>
                          ) : (
                            <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                          )}
                        </td>

                        {/* Asset Info */}
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2.5">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                              isPersonal ? 'bg-purple-100 text-purple-800 border border-purple-200' : 'bg-slate-900 text-white'
                            }`}>
                              {stk.ticker.slice(0, 3)}
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span 
                                  onClick={() => onSelectStock && onSelectStock(stk)}
                                  className="font-bold text-slate-900 font-mono hover:text-amber-800 cursor-pointer"
                                >
                                  ${stk.ticker}
                                </span>
                                <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                                  isPersonal ? 'bg-purple-50 text-purple-700 border border-purple-200' : 'bg-blue-50 text-blue-700 border border-blue-200'
                                }`}>
                                  {isPersonal ? 'Personal' : 'Business'}
                                </span>
                              </div>
                              <span className="text-[11px] text-slate-500 truncate block max-w-[140px] sm:max-w-[200px]">
                                {stk.name}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Market Way */}
                        <td className="py-3 px-3">
                          <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${mBadge.bg}`}>
                            <mBadge.icon className="w-2.5 h-2.5" />
                            <span>{mBadge.label}</span>
                          </span>
                        </td>

                        {/* Unit Price */}
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                          ${stk.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* 24h Change */}
                        <td className="py-3 px-3 text-right font-mono">
                          <span className={`font-bold inline-flex items-center gap-0.5 ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            <span>{isPositive ? '+' : ''}{stk.changePercent.toFixed(2)}%</span>
                          </span>
                        </td>

                        {/* Market Cap / Vol */}
                        <td className="py-3 px-3 text-right font-mono text-slate-500 hidden sm:table-cell">
                          <span className="block font-bold text-slate-700">{stk.marketCap || 'N/A'}</span>
                          <span className="text-[10px] text-slate-400 block">{stk.volume || 'N/A'}</span>
                        </td>

                        {/* My Position */}
                        <td className="py-3 px-3 text-right font-mono">
                          {ownedPos ? (
                            <div>
                              <span className="font-bold text-emerald-700 block">
                                {ownedPos.shares.toLocaleString()} shs
                              </span>
                              <span className="text-[10px] text-slate-400 block">
                                ${ownedPos.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </span>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-sans">Not owned</span>
                          )}
                        </td>

                        {/* Quick Actions */}
                        <td className="py-3 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenTradeModal(stk, 'buy')}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors cursor-pointer"
                            >
                              Buy
                            </button>
                            {ownedPos && (
                              <button
                                type="button"
                                onClick={() => onOpenTradeModal(stk, 'sell')}
                                className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                              >
                                Sell
                              </button>
                            )}
                            {onSelectStock && (
                              <button
                                type="button"
                                onClick={() => onSelectStock(stk)}
                                title="View stock charts & details"
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors cursor-pointer"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ================= VIEW 3: TRADED BY FRIENDS AND FAMOUS TRADERS ================= */}
      {currentSubTab === 'social_trades' && (
        <div className="space-y-4">
          <SocialTradesFeed
            stocks={stocks}
            watchlist={watchlist}
            viewType="equity"
            selectedMarketFilter={selectedMarketFilter}
            onSelectStock={onSelectStock}
            onQuickTrade={(stock, side) => onOpenTradeModal(stock, side || 'buy')}
            onToggleWatchlist={onToggleWatchlist}
          />
        </div>
      )}

      {/* ================= VIEW 4: MY IPOS & ISSUES ================= */}
      {currentSubTab === 'my_ipos' && (
        <MyIPOsTab
          currentUser={currentUser || null}
          ipos={ipos}
          onOpenReleaseModal={onOpenReleaseModal || (() => {})}
          onRequestDelist={onRequestDelist || (() => {})}
        />
      )}
      {/* ================= VIEW 5: CURRENCIES ================= */}
      {currentSubTab === 'currencies' && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <CurrenciesDirectoryAndWalletView 
            currentUser={currentUser || null}
            sovereignOnly={true}
          />
        </div>
      )}

      {/* ================= MODAL: ALL TRADE OPTIONS WITH FINAL STOCKS ================= */}
      {isFinalTradeOptionsModalOpen && (
        <FinalStocksTradeOptionsModal
          isOpen={isFinalTradeOptionsModalOpen}
          onClose={() => setIsFinalTradeOptionsModalOpen(false)}
          stocks={stocks}
          enrichedPositions={enrichedPositions}
          currentUser={currentUser}
          onOpenTradeModal={onOpenTradeModal}
          onSelectStock={onSelectStock}
          onOpenStockMarket={onOpenStockMarket}
          onSwitchToDerivativesTab={onSwitchToDerivativesTab}
        />
      )}
    </div>
  );
};
