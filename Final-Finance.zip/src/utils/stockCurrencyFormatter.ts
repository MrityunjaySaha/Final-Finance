import { StockItem } from '../types/stocks';
import { getStoredCustomCoins } from '../data/customCoinsData';
import { CustomCoin } from '../types/coinLaunch';

export interface StockCurrencyInfo {
  code: string;
  isFinal: boolean;
  isUSD: boolean;
  isStable: boolean;
  isCrypto: boolean;
  cryptoRateUSD: number;
}

/**
 * Standard exchange rates in USD for cryptocurrencies.
 */
export const CRYPTO_RATES_USD: Record<string, number> = {
  BTC: 65000.0,  // 1 BTC = $65,000.00 USD
  ETH: 3400.0,   // 1 ETH = $3,400.00 USD
  SOL: 180.0,    // 1 SOL = $180.00 USD
};

/**
 * Returns all active Final Currencies (Admin Final Coins + user-created & community Final Coins).
 */
export function getAllFinalCoins(): CustomCoin[] {
  return getStoredCustomCoins().filter((c) => c.coinType === 'final_coin');
}

/**
 * Inspects a stock item and determines its currency code, market category, and exchange rate.
 */
export function getStockCurrencyInfo(stock?: StockItem | null): StockCurrencyInfo {
  if (!stock) {
    return { code: 'AFNL', isFinal: true, isUSD: false, isStable: false, isCrypto: false, cryptoRateUSD: 1.0 };
  }

  const rawSymbol = stock.issuanceCoinSymbol || '';
  const cleanedSymbol = rawSymbol.replace(/^\$/, '').replace(/-FNL$/i, '').trim();
  const upperSymbol = cleanedSymbol.toUpperCase();
  const customCoins = getStoredCustomCoins();
  const matchedCustomCoin = upperSymbol
    ? customCoins.find((c) => c.symbol.toUpperCase() === upperSymbol)
    : undefined;

  // All Personal & Business IPOs in the Stock Market settle in Final Currencies
  const finalCode =
    matchedCustomCoin?.coinType === 'final_coin' || stock.issuanceCoinType === 'final_coin' || stock.marketType === 'final'
      ? cleanedSymbol || 'AFNL'
      : 'AFNL';

  return {
    code: finalCode,
    isFinal: true,
    isUSD: false,
    isStable: false,
    isCrypto: false,
    cryptoRateUSD: 1.0,
  };
}

/**
 * Checks if a stock is a Final Stock (settled in any Final Currency, admin or user/community).
 */
export function isFinalStock(stock: StockItem): boolean {
  return getStockCurrencyInfo(stock).isFinal;
}

/**
 * Returns the currency symbol or ticker code for a given stock.
 */
export function getStockCurrencyCode(stock: StockItem): string {
  return getStockCurrencyInfo(stock).code;
}

/**
 * Returns the US Dollar equivalent string for stable coins and crypto.
 * Returns null for Final Coins (unpegged sovereign assets) and US Dollar itself.
 */
export function getUSDEquivalentString(_amountUSD: number, _stock?: StockItem | null): string | null {
  return null;
}

/**
 * Formats a numerical stock price as plain sovereign unit value (all final currencies are equal 1:1).
 */
export function formatStockPrice(priceUSD: number, stock?: StockItem | null, _showEquivalent: boolean = true): string {
  if (priceUSD === undefined || priceUSD === null || isNaN(priceUSD)) return '0.00';
  const formattedNum = priceUSD.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const code = stock ? getStockCurrencyCode(stock) : 'USD';
  return `${code} ${formattedNum}`;
}

/**
 * Formats market cap without a single currency symbol.
 */
export function formatStockMarketCap(stock: StockItem, _showEquivalent: boolean = true): string {
  if (!stock) return 'N/A';
  const rawCap = stock.marketCap || 'N/A';
  const cleanCap = rawCap.replace(/^[₣$]/, '').trim();
  return cleanCap;
}

/**
 * Formats an order or trade amount with the stock's final currency.
 */
export function formatStockAmount(amountUSD: number, stock?: StockItem | null, _showEquivalent: boolean = true): string {
  if (amountUSD === undefined || amountUSD === null || isNaN(amountUSD)) return '0.00';
  const formattedNum = Math.abs(amountUSD).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const sign = amountUSD < 0 ? '-' : '';
  if (stock) {
    const code = getStockCurrencyCode(stock);
    return `${sign}${code} ${formattedNum}`;
  }
  return `${sign}${formattedNum}`;
}

/**
 * Formats a Final Stock price using the F Final Currency prefix and the chosen or backing Final Currency symbol (never $ / USD).
 */
export function formatFinalStockTagPrice(
  price: number,
  stock?: StockItem | null,
  overrideCode?: string | null
): string {
  const safePrice = Number.isFinite(price) ? price : 0;
  const formattedNum = safePrice.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const cleanOverride = overrideCode ? overrideCode.replace(/^\$/, '').trim().toUpperCase() : '';
  const code = cleanOverride || (stock ? getStockCurrencyCode(stock) : 'AFNL');
  return `F ${formattedNum} ${code}`;
}
