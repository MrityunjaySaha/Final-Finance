import { useEffect, useState, useCallback } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export type PlatformKind = 'ios' | 'android' | 'macos' | 'windows' | 'linux';

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [platform, setPlatform] = useState<PlatformKind>('windows');
  const [isSafariBrowser, setIsSafariBrowser] = useState(false);
  const [isFirefox, setIsFirefox] = useState(false);
  const [isSamsungInternet, setIsSamsungInternet] = useState(false);
  const [inIframe, setInIframe] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const checkStandalone = () => {
      const mediaStandalone =
        window.matchMedia('(display-mode: standalone)').matches ||
        window.matchMedia('(display-mode: window-controls-overlay)').matches ||
        window.matchMedia('(display-mode: minimal-ui)').matches;
      const iosStandalone = (window.navigator as unknown as { standalone?: boolean }).standalone === true;
      const androidAppReferrer = document.referrer.startsWith('android-app://');
      return mediaStandalone || iosStandalone || androidAppReferrer;
    };

    setIsInstalled(checkStandalone());

    try {
      setInIframe(window.self !== window.top);
    } catch {
      setInIframe(true);
    }

    const ua = window.navigator.userAgent.toLowerCase();
    const navPlatform = (window.navigator.platform || '').toLowerCase();
    const isIPadOS =
      navPlatform === 'macintel' && typeof navigator.maxTouchPoints === 'number' && navigator.maxTouchPoints > 1;
    const isIOSDevice = /iphone|ipad|ipod/.test(ua) || isIPadOS;
    const isAndroidDevice = /android/.test(ua);
    const isMacDevice = !isIPadOS && (/macintosh|mac os x/.test(ua) || navPlatform.includes('mac'));
    const isWindowsDevice = /windows|win32|win64/.test(ua) || navPlatform.includes('win');

    if (isIOSDevice) {
      setPlatform('ios');
    } else if (isAndroidDevice) {
      setPlatform('android');
    } else if (isMacDevice) {
      setPlatform('macos');
    } else if (isWindowsDevice) {
      setPlatform('windows');
    } else {
      setPlatform('linux');
    }

    const isSafari = /safari/.test(ua) && !/chrome|chromium|crios|fxios|edgios|edg|opr|opera|samsungbrowser/.test(ua);
    setIsSafariBrowser(isSafari);
    setIsFirefox(/firefox|fxios/.test(ua));
    setIsSamsungInternet(/samsungbrowser/.test(ua));

    const displayModeMedia = window.matchMedia('(display-mode: standalone)');
    const handleDisplayModeChange = (e: MediaQueryListEvent) => {
      if (e.matches) {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    };

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    displayModeMedia.addEventListener?.('change', handleDisplayModeChange);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      displayModeMedia.removeEventListener?.('change', handleDisplayModeChange);
    };
  }, []);

  const install = useCallback(async () => {
    if (!deferredPrompt) return false;
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
        return true;
      }
    } catch (err) {
      console.warn('PWA install prompt error:', err);
    }
    return false;
  }, [deferredPrompt]);

  return {
    isInstallable: Boolean(deferredPrompt),
    isInstalled,
    isIOS: platform === 'ios',
    isAndroid: platform === 'android',
    isMac: platform === 'macos',
    isWindows: platform === 'windows',
    isLinux: platform === 'linux',
    isDesktop: platform === 'macos' || platform === 'windows' || platform === 'linux',
    platform,
    isSafariBrowser,
    isFirefox,
    isSamsungInternet,
    inIframe,
    install,
  };
}
