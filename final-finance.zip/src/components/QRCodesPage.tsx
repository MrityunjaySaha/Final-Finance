import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { QrCode, ArrowLeft, Plus, Download, Copy, Trash2, Tag, RefreshCcw, DollarSign, Hexagon, Bitcoin, RefreshCw, Landmark, Coins, Search, Clock, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AuthSession } from '../types/auth';

interface QRCodesPageProps {
  currentUser: AuthSession;
  onNavigateBack: () => void;
  onViewUserProfile?: (userIdOrHandle: string) => void;
}

type TxMode = 'fiat' | 'final' | 'crypto' | 'barter' | 'stablecoin';
type QRUsage = 'one-time' | 'inventory';
type SubTabType = 'one-time' | 'inventory' | 'ious';

interface SavedQRCode {
  id: string;
  title: string;
  usage: QRUsage;
  txMode: TxMode;
  currency: string;
  amount: string;
  value: string;
  createdAt: string;
  description?: string;
  photos?: string[];
  videos?: string[];
}

interface IOUItem {
  id: string;
  txMode: TxMode;
  type: 'owed' | 'owe';
  item: string;
  exchangeFor: string;
  counterparty: string;
  counterpartyHandle: string;
  dueDate: string;
  status: 'pending' | 'settled';
  description?: string;
  photos?: string[];
  videos?: string[];
}

export const QRCodesPage: React.FC<QRCodesPageProps> = ({ currentUser, onNavigateBack, onViewUserProfile }) => {
  const { addToast } = useApp();
  
  const [savedCodes, setSavedCodes] = useState<SavedQRCode[]>([
    {
      id: 'qr-1',
      title: 'Consulting Hour',
      usage: 'inventory',
      txMode: 'fiat',
      currency: 'USD',
      amount: '150',
      value: `ff:inventory:fiat:USD:150:${currentUser.id}`,
      createdAt: '2026-08-20',
      description: 'Senior product architectural consulting and custom development session.',
      photos: ['https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80']
    },
    {
      id: 'qr-fiat-ot',
      title: 'Express Invoice Request',
      usage: 'one-time',
      txMode: 'fiat',
      currency: 'USD',
      amount: '500',
      value: `ff:onetime:fiat:USD:500:${currentUser.id}`,
      createdAt: '2026-08-21',
      description: 'One-time milestone settlement invoice.'
    },
    {
      id: 'qr-2',
      title: 'Coffee Payment',
      usage: 'one-time',
      txMode: 'final',
      currency: 'AFNL',
      amount: '5',
      value: `ff:onetime:final:AFNL:5:${currentUser.id}`,
      createdAt: '2026-08-22'
    },
    {
      id: 'qr-final-inv',
      title: 'Final Coin Genesis Badge',
      usage: 'inventory',
      txMode: 'final',
      currency: 'AFNL',
      amount: '100',
      value: `ff:inventory:final:AFNL:100:${currentUser.id}`,
      createdAt: '2026-08-22',
      description: 'Limited edition Genesis membership NFT token tag.'
    },
    {
      id: 'qr-stable-ot',
      title: 'USDT Escrow Transfer',
      usage: 'one-time',
      txMode: 'stablecoin',
      currency: 'USDT',
      amount: '250',
      value: `ff:onetime:stablecoin:USDT:250:${currentUser.id}`,
      createdAt: '2026-08-23'
    },
    {
      id: 'qr-stable-inv',
      title: 'Stable Yield Token Tag',
      usage: 'inventory',
      txMode: 'stablecoin',
      currency: 'USDC',
      amount: '1000',
      value: `ff:inventory:stablecoin:USDC:1000:${currentUser.id}`,
      createdAt: '2026-08-23'
    },
    {
      id: 'qr-crypto-ot',
      title: 'ETH Gas & Tip QR',
      usage: 'one-time',
      txMode: 'crypto',
      currency: 'ETH',
      amount: '0.05',
      value: `ff:onetime:crypto:ETH:0.05:${currentUser.id}`,
      createdAt: '2026-08-24'
    },
    {
      id: 'qr-crypto-inv',
      title: 'Bitcoin Hardware Node Tag',
      usage: 'inventory',
      txMode: 'crypto',
      currency: 'BTC',
      amount: '0.01',
      value: `ff:inventory:crypto:BTC:0.01:${currentUser.id}`,
      createdAt: '2026-08-24'
    },
    {
      id: 'qr-barter-seed',
      title: 'Developer Laptop Exchange',
      usage: 'one-time',
      txMode: 'barter',
      currency: 'Custom Video/Audio Setup',
      amount: '1 Core i9 Laptop',
      value: `ff:onetime:barter:Custom Video/Audio Setup:1 Core i9 Laptop:${currentUser.id}`,
      createdAt: '2026-08-25',
      description: 'Premium developer laptop (32GB RAM, 1TB SSD) in exchange for pro-grade podcast or video presentation setups.',
      photos: [
        'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=600&q=80'
      ],
      videos: [
        'https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-his-laptop-34281-large.mp4'
      ]
    },
    {
      id: 'qr-barter-inv',
      title: 'Ergonomic Desk Tag',
      usage: 'inventory',
      txMode: 'barter',
      currency: 'Legal Consultation',
      amount: '1 Standing Desk',
      value: `ff:inventory:barter:Legal Consultation:1 Standing Desk:${currentUser.id}`,
      createdAt: '2026-08-26',
      description: 'Standing office desk in exchange for 2 hours of legal review.'
    }
  ]);

  const [activeTab, setActiveTab] = useState<TxMode | 'create'>('fiat');
  const [qrSubTab, setQrSubTab] = useState<SubTabType>('one-time');
  const [expandedCodeId, setExpandedCodeId] = useState<string | null>(null);
  const [searchQueryCodes, setSearchQueryCodes] = useState('');
  
  // IOUs State for all 5 transaction types
  const [ious, setIous] = useState<IOUItem[]>([
    {
      id: 'iou-fiat-1',
      txMode: 'fiat',
      type: 'owed',
      item: 'USD Invoice #1042',
      exchangeFor: '$1,500.00 USD',
      counterparty: 'Global Tech Corp',
      counterpartyHandle: '@global_tech',
      dueDate: '2026-09-30',
      status: 'pending',
      description: 'Software architecture consulting invoice.',
      photos: [],
      videos: []
    },
    {
      id: 'iou-fiat-2',
      txMode: 'fiat',
      type: 'owe',
      item: 'EUR Office Rent',
      exchangeFor: '€1,200.00 EUR',
      counterparty: 'Berlin Spaces GmbH',
      counterpartyHandle: '@berlin_spaces',
      dueDate: '2026-09-01',
      status: 'settled',
      description: 'Monthly coworking studio membership fee.',
      photos: [],
      videos: []
    },
    {
      id: 'iou-stable-1',
      txMode: 'stablecoin',
      type: 'owed',
      item: 'USDT Liquidity Share',
      exchangeFor: '500 USDT',
      counterparty: 'Apex Logistics',
      counterpartyHandle: '@apex_logistics',
      dueDate: '2026-09-25',
      status: 'pending',
      description: 'Stablecoin pool yield distribution.',
      photos: [],
      videos: []
    },
    {
      id: 'iou-final-1',
      txMode: 'final',
      type: 'owed',
      item: 'AFNL Founder Grant',
      exchangeFor: '2,500 AFNL',
      counterparty: 'Foundation DAO',
      counterpartyHandle: '@foundation_dao',
      dueDate: '2026-10-01',
      status: 'pending',
      description: 'Ecosystem milestone vesting payment.',
      photos: [],
      videos: []
    },
    {
      id: 'iou-crypto-1',
      txMode: 'crypto',
      type: 'owe',
      item: 'ETH Node Hosting',
      exchangeFor: '0.25 ETH',
      counterparty: 'NodeValidator Net',
      counterpartyHandle: '@validator_net',
      dueDate: '2026-09-20',
      status: 'pending',
      description: 'Staking infrastructure hosting service.',
      photos: [],
      videos: []
    },
    {
      id: 'iou-barter-1',
      txMode: 'barter',
      type: 'owed',
      item: 'Website Redesign',
      exchangeFor: '3 Months Accounting',
      counterparty: 'Alex Chen',
      counterpartyHandle: '@alex_chen',
      dueDate: '2026-09-15',
      status: 'pending',
      description: 'Complete UI/UX redesign of accounting client dashboard.',
      photos: ['https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=600&q=80'],
      videos: []
    },
    {
      id: 'iou-barter-2',
      txMode: 'barter',
      type: 'owe',
      item: 'Brand Logo Package',
      exchangeFor: 'Promotional Video',
      counterparty: 'Sam Carter',
      counterpartyHandle: 'user_sam',
      dueDate: '2026-09-01',
      status: 'pending',
      description: 'Custom vectors and corporate brand guidelines booklet.',
      photos: ['https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80'],
      videos: []
    }
  ]);

  // Create state
  const [usageType, setUsageType] = useState<QRUsage>('one-time');
  const [createTxMode, setCreateTxMode] = useState<TxMode>('fiat');
  const [title, setTitle] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [videos, setVideos] = useState<string[]>([]);

  const photosFileInputRef = React.useRef<HTMLInputElement>(null);
  const videosFileInputRef = React.useRef<HTMLInputElement>(null);

  const handlePhotosUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file: File) => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPhotos(prev => [...prev, reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleVideosUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file: File) => {
      if (!file.type.startsWith('video/')) return;
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setVideos(prev => [...prev, reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const removeVideo = (index: number) => {
    setVideos(prev => prev.filter((_, i) => i !== index));
  };

  const handleGenerate = () => {
    if (!title.trim() || !amount.trim() || !currency.trim()) {
      addToast({
        title: 'Missing Fields',
        message: 'Please fill in all fields (Title, Asset, Amount).',
        type: 'error'
      });
      return;
    }

    const payload = `ff:${usageType}:${createTxMode}:${currency.toUpperCase()}:${amount}:${currentUser.id}`;

    const newQr: SavedQRCode = {
      id: `qr-${Date.now()}`,
      title: title.trim(),
      usage: usageType,
      txMode: createTxMode,
      currency: currency.toUpperCase(),
      amount: amount.trim(),
      value: payload,
      createdAt: new Date().toISOString().split('T')[0],
      description: description.trim(),
      photos,
      videos
    };

    setSavedCodes([newQr, ...savedCodes]);
    setTitle('');
    setAmount('');
    setDescription('');
    setPhotos([]);
    setVideos([]);
    setActiveTab(createTxMode);
    
    addToast({
      title: 'QR Code Created',
      message: `"${newQr.title}" has been saved with pitch media.`,
      type: 'success'
    });
  };

  const handleDelete = (id: string) => {
    setSavedCodes(savedCodes.filter(c => c.id !== id));
    addToast({
      title: 'QR Code Removed',
      message: 'The QR code was removed.',
      type: 'info'
    });
  };

  const modeTabs: { id: TxMode; label: string; icon: React.ElementType }[] = [
    { id: 'fiat', label: 'Fiat', icon: DollarSign },
    { id: 'stablecoin', label: 'Stablecoins', icon: Coins },
    { id: 'final', label: 'Final Coins', icon: Hexagon },
    { id: 'crypto', label: 'Crypto', icon: Bitcoin },
    { id: 'barter', label: 'Barter IOUs', icon: RefreshCw }
  ];

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <div className="max-w-5xl mx-auto px-4 py-6">
        
        {/* Horizontal Navigation Tabs: 5 Transaction Types next to each other + Create New */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-slate-200/60 rounded-2xl mb-8 max-w-3xl mx-auto shadow-xs">
          {modeTabs.map((mode) => {
            const IconComponent = mode.icon;
            const isActive = activeTab === mode.id;
            return (
              <button
                key={mode.id}
                onClick={() => setActiveTab(mode.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive 
                    ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
                }`}
              >
                <IconComponent className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>{mode.label}</span>
              </button>
            );
          })}
          
          <button
            onClick={() => setActiveTab('create')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'create' 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'text-indigo-700 hover:bg-indigo-50 border border-indigo-200/60'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New</span>
          </button>
        </div>

        {/* If one of the 5 transaction modes is active */}
        {activeTab !== 'create' && (
          <div className="space-y-6">
            


            {/* Three Sub-tabs for each transaction method: One-Time, Inventory, and IOUs */}
            <div className="flex bg-slate-200/60 p-1 rounded-xl max-w-lg mx-auto">
              <button
                onClick={() => setQrSubTab('one-time')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  qrSubTab === 'one-time'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                One-Time QR Codes
              </button>
              <button
                onClick={() => setQrSubTab('inventory')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  qrSubTab === 'inventory'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Inventory QR / Tags
              </button>
              <button
                onClick={() => setQrSubTab('ious')}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  qrSubTab === 'ious'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                IOUs & Commitments
              </button>
            </div>

            {/* If SubTab is One-Time or Inventory */}
            {qrSubTab !== 'ious' && (
              <>
                {/* Search Bar */}
                <div className="relative max-w-md mx-auto">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder={`Search ${activeTab} QR codes by title, amount...`}
                    value={searchQueryCodes}
                    onChange={(e) => setSearchQueryCodes(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all shadow-xs"
                  />
                </div>

                {/* QR Codes Grid */}
                {(() => {
                  const filteredCodes = savedCodes.filter(code => 
                    code.txMode === activeTab &&
                    code.usage === qrSubTab &&
                    (code.title.toLowerCase().includes(searchQueryCodes.toLowerCase()) ||
                     code.amount.toLowerCase().includes(searchQueryCodes.toLowerCase()) ||
                     code.currency.toLowerCase().includes(searchQueryCodes.toLowerCase()) ||
                     (code.description && code.description.toLowerCase().includes(searchQueryCodes.toLowerCase())))
                  );

                  if (filteredCodes.length === 0) {
                    return (
                      <div className="text-center py-12 px-4 bg-white rounded-3xl border border-dashed border-slate-300">
                        <QrCode className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                        <h3 className="text-sm font-bold text-slate-800 mb-1">No {qrSubTab === 'one-time' ? 'One-Time' : 'Inventory'} QR Codes for {activeTab.toUpperCase()}</h3>
                        <p className="text-xs text-slate-500 mb-4 max-w-xs mx-auto">
                          Generate a new {qrSubTab} QR code for {activeTab} in the "Create New" tab.
                        </p>
                        <button
                          onClick={() => {
                            setCreateTxMode(activeTab);
                            setUsageType(qrSubTab);
                            setActiveTab('create');
                          }}
                          className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer"
                        >
                          Create New QR
                        </button>
                      </div>
                    );
                  }

                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredCodes.map((code) => (
                        <div key={code.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col items-center group">
                          <div className="w-full flex justify-between items-start mb-4">
                            <div className="text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider bg-indigo-50 text-indigo-700">
                              {code.usage === 'one-time' ? 'One-Time' : 'Price Tag'}
                            </div>
                            <button 
                              onClick={() => handleDelete(code.id)}
                              className="p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          
                          <div className="bg-white p-2 rounded-xl shadow-xs border border-slate-100 mb-4">
                            <QRCodeSVG 
                              value={code.value} 
                              size={140}
                              bgColor={"#ffffff"}
                              fgColor={"#0f172a"}
                              level={"Q"}
                            />
                          </div>
                          
                          <h3 className="font-bold text-slate-900 text-sm mb-1 text-center truncate w-full">{code.title}</h3>
                          
                          <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg mb-4 text-center">
                            {code.txMode === 'barter' ? (
                              <span><RefreshCw className="w-3 h-3 inline mr-1" /> {code.amount} for {code.currency}</span>
                            ) : (
                              <span>{code.currency} {code.amount}</span>
                            )}
                          </div>

                          {/* Expandable details drawer with photos & videos */}
                          {(code.description || (code.photos && code.photos.length > 0) || (code.videos && code.videos.length > 0)) && (
                            <div className="w-full mb-4">
                              <button 
                                onClick={() => setExpandedCodeId(expandedCodeId === code.id ? null : code.id)}
                                className="w-full text-center py-1.5 bg-slate-50 hover:bg-slate-100 text-[10px] text-slate-500 hover:text-indigo-700 font-bold rounded-lg border border-slate-100 transition-colors cursor-pointer"
                              >
                                {expandedCodeId === code.id ? '✕ Hide Details' : '👁️ View Details & Media'}
                              </button>
                              
                              {expandedCodeId === code.id && (
                                <div className="mt-3 p-3 rounded-xl bg-slate-50 border border-slate-200/60 space-y-3 animate-fadeIn">
                                  {code.description && (
                                    <div className="space-y-1">
                                      <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider block">Description</span>
                                      <p className="text-[11px] text-slate-600 italic leading-relaxed">
                                        "{code.description}"
                                      </p>
                                    </div>
                                  )}

                                  {code.photos && code.photos.length > 0 && (
                                    <div className="space-y-1">
                                      <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider block">Photos ({code.photos.length})</span>
                                      <div className="grid grid-cols-3 gap-1">
                                        {code.photos.map((photo, idx) => (
                                          <div key={idx} className="relative aspect-square rounded-lg overflow-hidden border border-slate-200/80 bg-white">
                                            <img src={photo} alt="" className="w-full h-full object-cover" />
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}

                                  {code.videos && code.videos.length > 0 && (
                                    <div className="space-y-1">
                                      <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider block">Videos ({code.videos.length})</span>
                                      <div className="grid grid-cols-1 gap-1">
                                        {code.videos.map((video, idx) => (
                                          <div key={idx} className="relative aspect-video rounded-lg overflow-hidden bg-slate-900 border border-slate-200/80">
                                            <video src={video} controls className="w-full h-full object-contain" />
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          )}
                          
                          <div className="w-full grid grid-cols-2 gap-2 mt-auto">
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText(code.value);
                                addToast({ title: 'Copied', message: 'Payload copied to clipboard.', type: 'info' });
                              }}
                              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                            >
                              <Copy className="w-3.5 h-3.5" />
                              Copy
                            </button>
                            <button 
                              onClick={() => addToast({ title: 'Downloaded', message: 'QR code saved.', type: 'success' })}
                              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-colors cursor-pointer"
                            >
                              <Download className="w-3.5 h-3.5" />
                              Save
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </>
            )}

            {/* If SubTab is IOUs */}
            {qrSubTab === 'ious' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-indigo-600" />
                      {modeTabs.find(m => m.id === activeTab)?.label} IOUs & Commitments
                    </h3>
                    <p className="text-xs text-slate-500">Track and settle commitments associated with {activeTab}.</p>
                  </div>
                </div>

                {(() => {
                  const modeIous = ious.filter(i => i.txMode === activeTab);
                  if (modeIous.length === 0) {
                    return (
                      <div className="bg-white rounded-2xl p-8 text-center border border-dashed border-slate-200">
                        <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                        <p className="text-xs text-slate-500">No IOUs or pending commitments recorded for {activeTab}.</p>
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-3">
                      {modeIous.map((iou) => (
                        <div key={iou.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="flex items-start gap-3">
                            <div className={`p-2.5 rounded-full shrink-0 ${
                              iou.status === 'settled' 
                                ? 'bg-slate-100 text-slate-400'
                                : iou.type === 'owed' 
                                  ? 'bg-emerald-100 text-emerald-700' 
                                  : 'bg-amber-100 text-amber-700'
                            }`}>
                              {iou.status === 'settled' ? <CheckCircle2 className="w-5 h-5" /> : <RefreshCw className="w-5 h-5" />}
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                                  iou.type === 'owed' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
                                }`}>
                                  {iou.type === 'owed' ? 'Owed to Me' : 'I Owe'}
                                </span>
                                <span className={`text-[9px] font-bold uppercase tracking-wider ${
                                  iou.status === 'settled' ? 'text-slate-500' : 'text-indigo-600'
                                }`}>
                                  {iou.status === 'settled' ? 'Settled' : 'Pending'}
                                </span>
                              </div>
                              <h4 className="font-bold text-slate-900 text-sm">{iou.item}</h4>
                              <p className="text-xs text-slate-600">Value / Exchange: <strong className="text-slate-800">{iou.exchangeFor}</strong></p>
                              <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                                <span className="text-indigo-600 font-medium">{iou.counterparty}</span>
                                &bull;
                                <span>Due: {iou.dueDate}</span>
                              </div>
                            </div>
                          </div>

                          {iou.status === 'pending' && (
                            <button
                              onClick={() => {
                                setIous(ious.map(i => i.id === iou.id ? { ...i, status: 'settled' } : i));
                                addToast({ title: 'IOU Settled', message: `${iou.item} marked as settled.`, type: 'success' });
                              }}
                              className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl transition-colors cursor-pointer shrink-0"
                            >
                              Mark Settled
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            )}

          </div>
        )}

        {/* Create New Tab View */}
        {activeTab === 'create' && (
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm max-w-lg mx-auto">
            <h2 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
              <RefreshCcw className="w-5 h-5 text-indigo-500" />
              Generate QR Code & Pitch Media
            </h2>
            
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Transaction Type / Method</label>
                <div className="grid grid-cols-5 gap-1.5">
                  {modeTabs.map(m => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setCreateTxMode(m.id)}
                      className={`py-2 px-2 rounded-xl text-[11px] font-bold border transition-all cursor-pointer text-center truncate ${
                        createTxMode === m.id
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {m.label.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">QR Code Usage / Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setUsageType('one-time')}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      usageType === 'one-time'
                        ? 'bg-indigo-50 text-indigo-700 border-indigo-300 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    One-Time Request
                  </button>
                  <button
                    type="button"
                    onClick={() => setUsageType('inventory')}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      usageType === 'inventory'
                        ? 'bg-indigo-50 text-indigo-700 border-indigo-300 shadow-xs'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Inventory Price Tag
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Title / Item Name</label>
                <input
                  type="text"
                  placeholder="e.g. Consulting Hour, Laptop, Invoice #12"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Currency / Asset</label>
                  <input
                    type="text"
                    placeholder="USD, AFNL, USDT, BTC"
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Amount / Value</label>
                  <input
                    type="text"
                    placeholder="150"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Description & Pitch Details (Optional)</label>
                <textarea
                  rows={3}
                  placeholder="Add item specs, terms, or delivery terms..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              {/* Photos upload */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Photos ({photos.length})</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {photos.map((photo, idx) => (
                    <div key={idx} className="relative w-16 h-16 rounded-lg overflow-hidden border border-slate-200">
                      <img src={photo} alt="" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => removePhoto(idx)}
                        className="absolute top-0.5 right-0.5 p-0.5 bg-black/60 text-white rounded-full text-[10px]"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => photosFileInputRef.current?.click()}
                    className="w-16 h-16 rounded-xl border border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:border-indigo-500 hover:text-indigo-600 transition-colors cursor-pointer"
                  >
                    <Plus className="w-5 h-5" />
                    <span className="text-[9px]">Add Photo</span>
                  </button>
                </div>
                <input
                  ref={photosFileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handlePhotosUpload}
                />
              </div>

              {/* Videos upload */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Videos ({videos.length})</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {videos.map((video, idx) => (
                    <div key={idx} className="relative w-24 h-16 rounded-lg overflow-hidden border border-slate-200 bg-slate-900">
                      <video src={video} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => removeVideo(idx)}
                        className="absolute top-0.5 right-0.5 p-0.5 bg-black/60 text-white rounded-full text-[10px]"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => videosFileInputRef.current?.click()}
                    className="w-20 h-16 rounded-xl border border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:border-indigo-500 hover:text-indigo-600 transition-colors cursor-pointer"
                  >
                    <Plus className="w-5 h-5" />
                    <span className="text-[9px]">Add Video</span>
                  </button>
                </div>
                <input
                  ref={videosFileInputRef}
                  type="file"
                  accept="video/*"
                  multiple
                  className="hidden"
                  onChange={handleVideosUpload}
                />
              </div>

              <div className="pt-4">
                <button
                  onClick={handleGenerate}
                  disabled={!title.trim() || !amount.trim() || !currency.trim()}
                  className="w-full py-3.5 bg-slate-900 hover:bg-black text-white text-sm font-bold rounded-xl transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
                >
                  <QrCode className="w-5 h-5" />
                  Generate & Save QR Code
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
