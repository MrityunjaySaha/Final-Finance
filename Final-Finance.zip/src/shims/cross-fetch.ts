/**
 * Browser-safe fetch shim for cross-fetch.
 * Prevents cross-fetch's browser-ponyfill from assigning `this.fetch = false`
 * on a prototype linked to Window, which throws
 * `TypeError: Cannot set property fetch of #<Window> which has only a getter`
 * inside strict iframe environments.
 */
const nativeFetch: typeof globalThis.fetch = (input, init) => {
  if (typeof globalThis.fetch !== 'function') {
    return Promise.reject(new Error('Fetch API is unavailable in this environment.'));
  }
  return globalThis.fetch(input, init);
};

export const fetch: typeof globalThis.fetch = nativeFetch;
export const Headers = globalThis.Headers;
export const Request = globalThis.Request;
export const Response = globalThis.Response;

export default nativeFetch;
