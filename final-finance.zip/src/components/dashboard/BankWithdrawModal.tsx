import React, { useState } from 'react';
import { 
  X, 
  Building2, 
  ArrowUpRight, 
  CheckCircle2, 
  ShieldCheck, 
  Lock, 
  Info,
  Clock,
  Zap,
  ArrowRight
} from 'lucide-react';
import { UserWalletData } from '../../types/wallet';
import { ConfirmModal } from '../common/ConfirmModal';

interface BankWithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableBalance: number;
  walletData: UserWalletData;
  onConfirmBankDeposit: (amount: number, bankLabel: string, methodType: 'ach' | 'wire' | 'instant') => void;
}

export const BankWithdrawModal: React.FC<BankWithdrawModalProps> = ({
  isOpen,
  onClose,
  availableBalance,
  walletData,
  onConfirmBankDeposit,
}) => {
  const [amount, setAmount] = useState<string>('5000');
  const [selectedBankId, setSelectedBankId] = useState<string>('bank-primary');
  const [transferSpeed, setTransferSpeed] = useState<'instant' | 'standard'>('instant');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [showConfirm, setShowConfirm] = useState(false);

  if (!isOpen) return null;

  const parsedAmount = parseFloat(amount) || 0;
  const maxTransferable = Math.max(0, availableBalance);
  const linkedBanks = walletData.linkedBankAccounts || [];

  const handleAmountChange = (val: string) => {
    setErrorMsg('');
    setAmount(val);
  };

  const handleSetMax = () => {
    setErrorMsg('');
    setAmount(maxTransferable.toString());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parsedAmount <= 0) {
      setErrorMsg('Please enter a valid transfer amount.');
      return;
    }
    if (parsedAmount > maxTransferable) {
      setErrorMsg(`Amount exceeds your available liquid balance of $${maxTransferable.toLocaleString()}.`);
      return;
    }

    setShowConfirm(true);
  };

  const executeConfirmedWithdrawal = () => {
    setIsProcessing(true);
    setTimeout(() => {
      let bankLabel = 'JPMorgan Chase Prime (•••• 8920)';
      if (selectedBankId.startsWith('bank-')) {
        const found = linkedBanks.find(b => b.id === selectedBankId.replace('bank-', ''));
        if (found) {
          bankLabel = `${found.bankName} (•••• ${found.accountNumberLast4})`;
        }
      }

      onConfirmBankDeposit(
        parsedAmount, 
        bankLabel, 
        transferSpeed === 'instant' ? 'instant' : 'ach'
      );
      setIsProcessing(false);
      onClose();
    }, 650);
  };

  return (
    <div 
      id="bank-deposit-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150 text-left"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="bank-deposit-modal-container"
        className="relative w-full max-w-lg rounded-3xl bg-white border border-slate-200 shadow-2xl overflow-hidden my-8 animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-sky-500/10 border border-sky-500/20 text-sky-700">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900 leading-tight">
                Deposit Money into Your Bank
              </h2>
              <p className="text-xs text-slate-500 font-mono mt-0.5">
                Transfer platform funds directly to your external bank account
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Available balance overview */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono uppercase text-slate-500 tracking-wider block">
                Available to Deposit into Bank
              </span>
              <span className="text-xl font-bold font-mono text-slate-900 mt-0.5 block">
                ${maxTransferable.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <button
              type="button"
              onClick={handleSetMax}
              className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-800 border border-amber-300/40 transition-colors cursor-pointer"
            >
              Deposit Max
            </button>
          </div>

          {/* Amount input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 block">
              Transfer Amount (USD)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-lg font-bold">
                $
              </span>
              <input
                type="number"
                min="1"
                step="any"
                value={amount}
                onChange={(e) => handleAmountChange(e.target.value)}
                placeholder="0.00"
                className="w-full pl-9 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-slate-900 font-mono font-bold text-lg focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Presets */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              {[1000, 2500, 5000, 10000, 25000].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleAmountChange(preset.toString())}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-mono font-medium transition-colors cursor-pointer"
                >
                  +${preset >= 1000 ? `${preset / 1000}k` : preset}
                </button>
              ))}
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-600 font-medium pt-1">
                {errorMsg}
              </p>
            )}
          </div>

          {/* Destination Bank Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">
              Select Destination Bank Account
            </label>
            <div className="space-y-2">
              {linkedBanks.length > 0 ? (
                linkedBanks.map((bank) => (
                  <label
                    key={bank.id}
                    className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                      selectedBankId === `bank-${bank.id}`
                        ? 'border-sky-500 bg-sky-50/50 shadow-xs'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="destBank"
                        checked={selectedBankId === `bank-${bank.id}`}
                        onChange={() => setSelectedBankId(`bank-${bank.id}`)}
                        className="accent-sky-600"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{bank.bankName}</span>
                          {bank.isDefault && (
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-100 text-sky-800 font-semibold">
                              PRIMARY
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {bank.accountType.toUpperCase()} &bull; Account ending in •••• {bank.accountNumberLast4}
                        </span>
                      </div>
                    </div>
                    <Building2 className="w-4 h-4 text-slate-400" />
                  </label>
                ))
              ) : (
                <label className="p-3.5 rounded-2xl border border-sky-500 bg-sky-50/50 flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-3">
                    <input type="radio" checked readOnly className="accent-sky-600" />
                    <div>
                      <span className="text-xs font-bold text-slate-900">JPMorgan Chase Prime</span>
                      <span className="text-[11px] text-slate-500 font-mono block">
                        CHECKING &bull; Account ending in •••• 8920
                      </span>
                    </div>
                  </div>
                  <Building2 className="w-4 h-4 text-sky-600" />
                </label>
              )}
            </div>
          </div>

          {/* Transfer Speed Option */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">
              Settlement Speed
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setTransferSpeed('instant')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  transferSpeed === 'instant'
                    ? 'border-sky-500 bg-sky-50/60 shadow-xs'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">Instant FedNow / Wire</span>
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">Available in ~15 minutes &bull; $0 fee</p>
              </button>

              <button
                type="button"
                onClick={() => setTransferSpeed('standard')}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  transferSpeed === 'standard'
                    ? 'border-sky-500 bg-sky-50/60 shadow-xs'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">Standard ACH</span>
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">1-2 business days &bull; $0 fee</p>
              </button>
            </div>
          </div>

          {/* Security Guarantee */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5 text-[11px] text-slate-600">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              FDIC-insured sweep depository settlement via Fedwire &amp; ACH network.
            </span>
          </div>

          {/* Submit Action */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isProcessing || parsedAmount <= 0 || parsedAmount > maxTransferable}
              className="w-full py-3.5 px-4 rounded-2xl bg-sky-600 hover:bg-sky-500 disabled:bg-slate-200 disabled:text-slate-400 text-white font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <span>Initiating Bank Settlement...</span>
              ) : (
                <>
                  <Building2 className="w-4 h-4" />
                  <span>
                    Deposit ${parsedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} into Bank
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={executeConfirmedWithdrawal}
        title="Confirm Bank Deposit"
        message={`Authorize a deposit of $${parsedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} into your linked bank account? Funds will be moved from your platform vault.`}
        confirmText="Confirm Deposit"
        type="info"
      />
    </div>
  );
};
