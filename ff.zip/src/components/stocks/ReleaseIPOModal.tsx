import React, { useState, useMemo, useRef } from 'react';
import { 
  X, 
  Building2, 
  User, 
  Sparkles, 
  ShieldCheck, 
  Layers, 
  DollarSign, 
  TrendingUp, 
  Briefcase, 
  Award, 
  CheckCircle2, 
  AlertCircle, 
  Coins, 
  Globe, 
  Info,
  Scale,
  Send,
  Image as ImageIcon,
  Video,
  Upload,
  Trash2,
  Star,
  Film,
  Plus,
  Search
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { IPOType, StockSector, StockMarketWay, IPORequest, IPOMediaItem } from '../../types/stocks';
import { getStoredCustomCoins } from '../../data/customCoinsData';
import { submitIPORequest, canCreatePersonalIPO, getAllActiveMarketStocks, getStoredIPORequests } from '../../data/stocksData';
import { dispatchGlobalNotification } from '../../utils/notificationService';

interface ReleaseIPOModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthSession;
  onSuccess?: (ipo: IPORequest) => void;
}

const SECTORS: StockSector[] = [
  'Technology & AI',
  'Semiconductors',
  'Gold & Commodities',
  'Banking & Finance',
  'Energy & Aerospace',
  'Consumer Staples & Defensive',
  'Crypto Treasuries & Mining',
  'Sovereign Reserves'
];

const PRESET_PERSONALITY_TRAITS = [
  'Visionary Architect',
  'Algorithmic Strategist',
  'High-Conviction Builder',
  'Mathematical Purist',
  'Decentralized Sovereign',
  'Deep-Tech Pioneer',
  'Pragmatic Operator',
  'Quantitative Arbitrageur',
  'Ecosystem Catalyst'
];

interface BusinessScalePreset {
  id: string;
  name: string;
  badge: string;
  description: string;
  shares: string;
  price: string;
  revenue: string;
  margin: string;
  growth: string;
  structure: string;
  employees: string;
  useOfProceeds: string;
}

const BUSINESS_SCALE_PRESETS: BusinessScalePreset[] = [
  {
    id: 'micro',
    name: 'Micro-Venture / Solo Studio',
    badge: '🌱 Micro ($10k - $50k)',
    description: 'Solo founder, freelance consultancy, creator studio, or boutique team.',
    shares: '2000',
    price: '5.00',
    revenue: '35000',
    margin: '45.0',
    growth: '120',
    structure: 'Single-Member LLC / Boutique Studio',
    employees: '1 Principal (Solo Founder)',
    useOfProceeds: 'Design studio equipment, high-performance compute hardware, and creator tool licensing.'
  },
  {
    id: 'small',
    name: 'Small Business / Seed Startup',
    badge: '🚀 Small Biz ($100k - $500k)',
    description: 'Local business, seed venture, micro-SaaS, or specialized partnership.',
    shares: '25000',
    price: '10.00',
    revenue: '240000',
    margin: '28.0',
    growth: '90',
    structure: 'Commercial LLC / Small Business Corp',
    employees: '3-8 Staff & Contractors',
    useOfProceeds: 'Local commercial marketing, software development, inventory expansion, and operations.'
  },
  {
    id: 'growth',
    name: 'Growth / Mid-Market Enterprise',
    badge: '📈 Mid-Market ($2M - $15M)',
    description: 'Scaling enterprise with established product-market fit and full-time personnel.',
    shares: '250000',
    price: '20.00',
    revenue: '4500000',
    margin: '22.5',
    growth: '75',
    structure: 'Singapore Private Limited (Pte. Ltd.)',
    employees: '25-50 Engineers & Operators',
    useOfProceeds: 'Global multi-region expansion, key executive recruitment, and protocol liquidity reserves.'
  },
  {
    id: 'enterprise',
    name: 'Corporate Enterprise',
    badge: '🏢 Corporate ($50M+)',
    description: 'Institutional-tier public equity issuance with global multi-jurisdiction presence.',
    shares: '2000000',
    price: '30.00',
    revenue: '38000000',
    margin: '26.0',
    growth: '140',
    structure: 'Delaware C-Corporation (Public Tier)',
    employees: '100+ Engineers & Physicists',
    useOfProceeds: 'Fabrication facilities, automated manufacturing cleanrooms, and institutional treasury reserves.'
  }
];

export const ReleaseIPOModal: React.FC<ReleaseIPOModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSuccess
}) => {
  const [ipoType, setIpoType] = useState<IPOType>('personal');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Check 1-personal-IPO constraint
  const personalIPOCheck = useMemo(() => {
    return canCreatePersonalIPO(currentUser?.id || 'you');
  }, [currentUser?.id]);

  // Available User Coins
  const allUserCoins = useMemo(() => {
    const stored = getStoredCustomCoins();
    return stored;
  }, []);

  // Filtered Coins
  // Personal IPO can select ANY Final Coin in the network (Admin, User's Own, or Peer/Community Final Coin)
  const finalCoinsOnly = useMemo(() => {
    const filtered = allUserCoins.filter((c) => c.coinType === 'final_coin');
    return filtered;
  }, [allUserCoins]);

  // Personal Final Coin Filter Switcher & Search
  const [personalFinalCoinFilter, setPersonalFinalCoinFilter] = useState<'all' | 'admin' | 'mine' | 'community'>('all');
  const [personalCoinSearch, setPersonalCoinSearch] = useState('');

  const filteredPersonalFinalCoins = useMemo(() => {
    return finalCoinsOnly.filter((c) => {
      const isMine = c.creatorId === 'you' || c.creatorId === currentUser?.id || c.creatorId === 'current_user';
      const isAdmin = c.isAdminCoin || c.creatorId === 'admin' || c.creatorId === 'super_admin';
      
      let matchesFilter = true;
      if (personalFinalCoinFilter === 'admin') matchesFilter = isAdmin;
      else if (personalFinalCoinFilter === 'mine') matchesFilter = isMine;
      else if (personalFinalCoinFilter === 'community') matchesFilter = !isAdmin && !isMine;

      if (!matchesFilter) return false;

      if (personalCoinSearch.trim()) {
        const q = personalCoinSearch.toLowerCase().trim();
        const matchesQuery =
          c.name.toLowerCase().includes(q) ||
          c.symbol.toLowerCase().includes(q) ||
          (c.creatorName && c.creatorName.toLowerCase().includes(q)) ||
          (c.creatorHandle && c.creatorHandle.toLowerCase().includes(q)) ||
          (c.description && c.description.toLowerCase().includes(q)) ||
          (c.collateralAssetType && c.collateralAssetType.toLowerCase().includes(q)) ||
          (c.contractAddress && c.contractAddress.toLowerCase().includes(q));
        if (!matchesQuery) return false;
      }

      return true;
    });
  }, [finalCoinsOnly, personalFinalCoinFilter, personalCoinSearch, currentUser?.id]);

  // Business IPO can launch with Final Coins only
  const [businessCoinTypeFilter, setBusinessCoinTypeFilter] = useState<'all' | 'admin' | 'mine' | 'community'>('all');
  const [businessCoinSearch, setBusinessCoinSearch] = useState('');

  const businessEligibleCoins = useMemo(() => {
    return allUserCoins.filter((c) => {
      if (c.coinType !== 'final_coin') return false;

      const isMine = c.creatorId === 'you' || c.creatorId === currentUser?.id || c.creatorId === 'current_user';
      const isAdmin = c.isAdminCoin || c.creatorId === 'admin' || c.creatorId === 'super_admin';
      
      let matchesFilter = true;
      if (businessCoinTypeFilter === 'admin') matchesFilter = isAdmin;
      else if (businessCoinTypeFilter === 'mine') matchesFilter = isMine;
      else if (businessCoinTypeFilter === 'community') matchesFilter = !isAdmin && !isMine;

      if (!matchesFilter) return false;

      if (businessCoinSearch.trim()) {
        const q = businessCoinSearch.toLowerCase().trim();
        const matchesQuery =
          c.name.toLowerCase().includes(q) ||
          c.symbol.toLowerCase().includes(q) ||
          (c.creatorName && c.creatorName.toLowerCase().includes(q)) ||
          (c.creatorHandle && c.creatorHandle.toLowerCase().includes(q)) ||
          (c.description && c.description.toLowerCase().includes(q)) ||
          (c.collateralAssetType && c.collateralAssetType.toLowerCase().includes(q)) ||
          (c.contractAddress && c.contractAddress.toLowerCase().includes(q));
        if (!matchesQuery) return false;
      }

      return true;
    });
  }, [allUserCoins, businessCoinTypeFilter, businessCoinSearch, currentUser?.id]);

  // Active Business Scale Preset
  const [activeBizPreset, setActiveBizPreset] = useState<string>('small');

  // Common IPO Financial Fields
  const [ticker, setTicker] = useState('');
  const [sharesOffered, setSharesOffered] = useState('25000');
  const [offeringPriceUSD, setOfferingPriceUSD] = useState('10.00');

  // Media Gallery for IPO (Photos and Videos)
  const [mediaList, setMediaList] = useState<IPOMediaItem[]>([]);
  const [mediaUploadType, setMediaUploadType] = useState<'photo' | 'video'>('photo');
  const [mediaUrlInput, setMediaUrlInput] = useState('');
  const [mediaTitleInput, setMediaTitleInput] = useState('');
  const [mediaDescInput, setMediaDescInput] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- PERSONAL IPO STATE ---
  const [fullName, setFullName] = useState(currentUser?.name || 'Sovereign Builder');
  const [profession, setProfession] = useState('Quantitative Systems Architect & Sovereign Researcher');
  const [personaProfile, setPersonaProfile] = useState('');
  const [selectedTraits, setSelectedTraits] = useState<string[]>(['Visionary Architect', 'High-Conviction Builder']);
  const [customTraitInput, setCustomTraitInput] = useState('');
  const [keyAchievements, setKeyAchievements] = useState('');
  const [personalMission, setPersonalMission] = useState('');
  const [selectedFinalCoinId, setSelectedFinalCoinId] = useState<string>(finalCoinsOnly[0]?.id || 'admin_final_coin_master');

  // Solvency NAV (4 Modes)
  const [netWorthFiatUSD, setNetWorthFiatUSD] = useState('400000');
  const [netWorthStableCoinsUSD, setNetWorthStableCoinsUSD] = useState('300000');
  const [netWorthCryptoUSD, setNetWorthCryptoUSD] = useState('400000');
  const [netWorthFinalCoins, setNetWorthFinalCoins] = useState('1000000');

  // --- BUSINESS IPO STATE ---
  const [companyName, setCompanyName] = useState('');
  const [legalStructure, setLegalStructure] = useState('Commercial LLC / Small Business Corp');
  const [sector, setSector] = useState<StockSector>('Technology & AI');
  const [industry, setIndustry] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [jurisdiction, setJurisdiction] = useState('Delaware, USA / Sovereign Registry');
  const [foundedYear, setFoundedYear] = useState('2024');
  const [headquarters, setHeadquarters] = useState('Austin, TX / Remote Studio');
  const [employeeCount, setEmployeeCount] = useState('3-8 Staff & Contractors');
  const [website, setWebsite] = useState('');
  const [businessModel, setBusinessModel] = useState('');
  const [valueProposition, setValueProposition] = useState('');
  const [annualRevenueUSD, setAnnualRevenueUSD] = useState('240000');
  const [netProfitMarginPercent, setNetProfitMarginPercent] = useState('28.0');
  const [projectedGrowthPercent, setProjectedGrowthPercent] = useState('90');
  const [ceoName, setCeoName] = useState(currentUser?.name || 'Managing Director');
  const [ctoName, setCtoName] = useState('');
  const [cfoName, setCfoName] = useState('');
  const [selectedBusinessCoinId, setSelectedBusinessCoinId] = useState<string>(allUserCoins[0]?.id || 'admin_final_coin_master');
  const [useOfProceeds, setUseOfProceeds] = useState('Commercial operations expansion, technology infrastructure scaling, and sovereign reserve collateralization.');

  // Apply Business Scale Preset
  const applyBusinessPreset = (preset: BusinessScalePreset) => {
    setActiveBizPreset(preset.id);
    setSharesOffered(preset.shares);
    setOfferingPriceUSD(preset.price);
    setAnnualRevenueUSD(preset.revenue);
    setNetProfitMarginPercent(preset.margin);
    setProjectedGrowthPercent(preset.growth);
    setLegalStructure(preset.structure);
    setEmployeeCount(preset.employees);
    setUseOfProceeds(preset.useOfProceeds);
    if (!registrationNumber) {
      setRegistrationNumber(`LLC-PROV-${Math.floor(100000 + Math.random() * 900000)}`);
    }
  };

  // Quick Auto-Generate ID helper
  const handleAutoGenerateRegistrationId = () => {
    const randomDigits = Math.floor(100000 + Math.random() * 900000);
    setRegistrationNumber(`LLC-PROV-${randomDigits}`);
  };

  // Calculations
  const calculatedShares = parseFloat(sharesOffered) || 0;
  const calculatedPrice = parseFloat(offeringPriceUSD) || 0;
  const calculatedTargetValuationUSD = calculatedShares * calculatedPrice;

  const total5ModeNetWorthUSD = useMemo(() => {
    const f = parseFloat(netWorthFiatUSD) || 0;
    const s = parseFloat(netWorthStableCoinsUSD) || 0;
    const c = parseFloat(netWorthCryptoUSD) || 0;
    const fn = parseFloat(netWorthFinalCoins) || 0;
    return f + s + c + fn;
  }, [netWorthFiatUSD, netWorthStableCoinsUSD, netWorthCryptoUSD, netWorthFinalCoins]);

  // Selected Backing Coins
  const currentBackingFinalCoin = useMemo(() => {
    return finalCoinsOnly.find((c) => c.id === selectedFinalCoinId) || finalCoinsOnly[0];
  }, [finalCoinsOnly, selectedFinalCoinId]);

  const currentBackingBusinessCoin = useMemo(() => {
    return allUserCoins.find((c) => c.id === selectedBusinessCoinId) || allUserCoins[0];
  }, [allUserCoins, selectedBusinessCoinId]);

  const toggleTrait = (trait: string) => {
    if (selectedTraits.includes(trait)) {
      setSelectedTraits(selectedTraits.filter((t) => t !== trait));
    } else {
      if (selectedTraits.length < 5) {
        setSelectedTraits([...selectedTraits, trait]);
      }
    }
  };

  const addCustomTrait = () => {
    if (customTraitInput.trim() && !selectedTraits.includes(customTraitInput.trim()) && selectedTraits.length < 5) {
      setSelectedTraits([...selectedTraits, customTraitInput.trim()]);
      setCustomTraitInput('');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    const isVid = file.type.startsWith('video/');
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const newItem: IPOMediaItem = {
        id: `med_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: isVid ? 'video' : 'photo',
        url: dataUrl,
        title: file.name.replace(/\.[^/.]+$/, ''),
        description: `Uploaded file (${(file.size / (1024 * 1024)).toFixed(2)} MB)`,
        uploadedAt: new Date().toISOString(),
        isCover: mediaList.length === 0
      };
      setMediaList((prev) => [newItem, ...prev]);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsDataURL(file);
  };

  const handleAddMediaUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaUrlInput.trim()) return;
    const newItem: IPOMediaItem = {
      id: `med_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: mediaUploadType,
      url: mediaUrlInput.trim(),
      title: mediaTitleInput.trim() || (mediaUploadType === 'video' ? 'Video Pitch' : 'Visual Asset'),
      description: mediaDescInput.trim(),
      uploadedAt: new Date().toISOString(),
      isCover: mediaList.length === 0
    };
    setMediaList((prev) => [newItem, ...prev]);
    setMediaUrlInput('');
    setMediaTitleInput('');
    setMediaDescInput('');
  };

  const handleDeleteMedia = (id: string) => {
    setMediaList((prev) => prev.filter((m) => m.id !== id));
  };

  const handleSetCover = (id: string) => {
    setMediaList((prev) =>
      prev.map((m) => ({
        ...m,
        isCover: m.id === id
      }))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (ipoType === 'personal' && !personalIPOCheck.allowed) {
      setErrorMsg(`Personal IPO Limit Reached: You already have an active personal IPO ($${personalIPOCheck.existingTicker}). Only 1 personal IPO is permitted at a time. However, you can launch unlimited Business IPOs!`);
      return;
    }

    const cleanTicker = ticker.trim().replace(/^\$/, '').toUpperCase();
    if (!cleanTicker || cleanTicker.length < 2 || cleanTicker.length > 6) {
      setErrorMsg('Stock Ticker symbol must be between 2 and 6 uppercase letters (e.g. ALEX, HYPR, NEUR).');
      return;
    }

    // Check if stock ticker is already taken
    const existingStocks = getAllActiveMarketStocks();
    const existingIPOs = getStoredIPORequests();
    const isTaken = existingStocks.some(s => s.ticker.toUpperCase() === cleanTicker) ||
                    existingIPOs.some(ipo => ipo.ticker.toUpperCase() === cleanTicker && ipo.status !== 'rejected' && ipo.status !== 'delisted');
    if (isTaken) {
      setErrorMsg(`Stock Ticker "$${cleanTicker}" is already taken. Please choose a unique ticker symbol.`);
      return;
    }

    if (calculatedShares <= 0 || calculatedPrice <= 0) {
      setErrorMsg('Please specify valid shares to offer and share offering price.');
      return;
    }

    if (ipoType === 'personal') {
      if (!fullName.trim() || !profession.trim()) {
        setErrorMsg('Please enter your full identity/name and core profession.');
        return;
      }
      if (!currentBackingFinalCoin) {
        setErrorMsg('Personal IPO requires selecting one of your sovereign Final Coins as backing.');
        return;
      }
    } else {
      if (!companyName.trim() || !industry.trim() || !headquarters.trim()) {
        setErrorMsg('Please provide company/business name, industry, and headquarters/location.');
        return;
      }
      if (!currentBackingBusinessCoin) {
        setErrorMsg('Please select a digital currency backing coin for this Business IPO.');
        return;
      }
    }

    // Auto-generate provisional ID for small businesses if not provided
    const finalRegNumber = registrationNumber.trim() || `LLC-PROV-${Math.floor(100000 + Math.random() * 900000)}`;

    setIsSubmitting(true);

    try {
      const marketWay: StockMarketWay = ipoType === 'personal'
        ? 'final' // Personal IPO is settled in Final Coin
        : (currentBackingBusinessCoin.coinType === 'stable_coin' ? 'stable' : currentBackingBusinessCoin.coinType === 'crypto' ? 'crypto' : 'final');

      const coverItem = mediaList.find((m) => m.isCover) || mediaList[0];

      const derivedHandle = currentUser?.handle
        ? `@${currentUser.handle.replace(/^@/, '')}`
        : `@${fullName.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_') || cleanTicker.toLowerCase()}`;

      const ipoPayload: Partial<IPORequest> = {
        ipoType,
        ticker: cleanTicker,
        equityName: ipoType === 'personal' ? `${fullName.trim()} Sovereign Human Equity` : companyName.trim(),
        issuerId: currentUser?.id || 'you',
        issuerName: currentUser?.name || (ipoType === 'personal' ? fullName.trim() : companyName.trim()),
        issuerHandle: currentUser?.handle || (ipoType === 'personal' ? derivedHandle.replace(/^@/, '') : cleanTicker.toLowerCase()),
        marketWay,
        sharesOffered: calculatedShares,
        offeringPriceUSD: calculatedPrice,
        targetValuationUSD: calculatedTargetValuationUSD,
        circulatingFloat: Math.round(calculatedShares * 0.4),
        mediaGallery: mediaList,
        issuerAvatar: coverItem?.type === 'photo' ? coverItem.url : undefined,
        ...(ipoType === 'personal' ? {
          personalDetails: {
            fullName: fullName.trim(),
            handle: derivedHandle,
            profession: profession.trim(),
            personaProfile: personaProfile.trim() || `${fullName} sovereign individual equity backed by multi-mode net worth reserves.`,
            personalityTraits: selectedTraits,
            keyAchievements: keyAchievements.trim() || 'Verified decentralized builder & sovereign market participant.',
            backingFinalCoinId: currentBackingFinalCoin.id,
            backingFinalCoinSymbol: currentBackingFinalCoin.symbol,
            backingFinalCoinName: `${currentBackingFinalCoin.name} (${currentBackingFinalCoin.symbol})`,
            fiveModeNetWorth: {
              fiatUSD: parseFloat(netWorthFiatUSD) || 0,
              stableCoinsUSD: parseFloat(netWorthStableCoinsUSD) || 0,
              cryptoAssetsUSD: parseFloat(netWorthCryptoUSD) || 0,
              finalCoins: parseFloat(netWorthFinalCoins) || 0,
              totalNetWorthUSD: total5ModeNetWorthUSD
            },
            valuationRationale: `Valued at ₣${(calculatedTargetValuationUSD / 1e6).toFixed(2)}M against multi-mode verified net worth (₣${(total5ModeNetWorthUSD / 1e6).toFixed(2)}M NAV).`,
            personalMission: personalMission.trim() || 'Accelerate sovereign financial rails.',
            mediaGallery: mediaList
          }
        } : {
          businessDetails: {
            companyName: companyName.trim(),
            legalStructure,
            sector,
            industry: industry.trim(),
            registrationNumber: finalRegNumber,
            jurisdiction: jurisdiction.trim(),
            foundedYear: parseInt(foundedYear, 10) || 2024,
            headquarters: headquarters.trim(),
            employeeCount,
            website: website.trim(),
            businessModel: businessModel.trim() || `${companyName} commercial operations.`,
            valueProposition: valueProposition.trim() || `${companyName} market solutions.`,
            annualRevenueUSD: parseFloat(annualRevenueUSD) || 0,
            netProfitMarginPercent: parseFloat(netProfitMarginPercent) || 0,
            projectedGrowthPercent: parseFloat(projectedGrowthPercent) || 0,
            executives: {
              ceo: ceoName.trim() || 'Managing Director',
              cto: ctoName.trim(),
              cfo: cfoName.trim()
            },
            backingCoinId: currentBackingBusinessCoin.id,
            backingCoinSymbol: currentBackingBusinessCoin.symbol,
            backingCoinType: currentBackingBusinessCoin.coinType,
            backingCoinName: `${currentBackingBusinessCoin.name} (${currentBackingBusinessCoin.symbol})`,
            useOfProceeds: useOfProceeds.trim() || 'Operations expansion, technology infrastructure scaling, and reserve asset collateralization.',
            mediaGallery: mediaList
          }
        })
      };

      const created = submitIPORequest(ipoPayload);
      setIsSubmitting(false);

      dispatchGlobalNotification({
        title: `IPO Filing Submitted: $${created.ticker}`,
        description: `${created.equityName} (${created.ipoType === 'personal' ? 'Personal' : 'Corporate'} IPO) has been submitted for exchange underwriting and listing.`,
        type: 'stocks',
        targetTab: 'stocks',
        targetId: created.ticker,
        tone: 'gold',
      });

      if (onSuccess) {
        onSuccess(created);
      }
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || 'Failed submitting IPO request.');
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-center">
        
        {/* MODAL HEADER */}
        <div className="relative px-6 py-2.5 border-b border-slate-200 flex items-center justify-center text-center bg-slate-50/70">
          <div className="flex items-center justify-center gap-2 px-8">
            <div className="w-7 h-7 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-600 font-bold shrink-0">
              <Building2 className="w-3.5 h-3.5" />
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2">
              <h2 className="font-serif text-base sm:text-lg font-bold text-slate-900">
                Initial Public Offering (IPO) Launchpad
              </h2>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                Admin Approval Required
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="absolute right-3 top-2.5 p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* IPO TYPE TOGGLE SELECTOR */}
        <div className="px-6 py-3.5 bg-slate-100/70 border-b border-slate-200 flex flex-col items-center justify-center gap-2.5 text-center">
          <div className="flex flex-wrap items-center justify-center gap-2 p-1 bg-white rounded-2xl border border-slate-200 shadow-2xs">
            <button
              type="button"
              onClick={() => setIpoType('personal')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                ipoType === 'personal'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>👤 Personal IPO (Max 1 Active)</span>
            </button>

            <button
              type="button"
              onClick={() => setIpoType('business')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                ipoType === 'business'
                  ? 'bg-white border border-slate-200 text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>🏢 Business IPO (Unlimited • 3 Currency Types)</span>
            </button>
          </div>

          <div className="text-[11px] font-mono text-slate-500 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>
              {ipoType === 'personal' 
                ? 'Limit: 1 Personal IPO at a time' 
                : 'Unlimited Business IPOs • Final / Stable / Crypto'}
            </span>
          </div>
        </div>

        {/* 1-PERSONAL-IPO LIMIT WARNING BANNER */}
        {ipoType === 'personal' && !personalIPOCheck.allowed && (
          <div className="mx-6 mt-4 p-4 rounded-2xl bg-amber-50 border border-amber-300 text-amber-900 text-xs flex flex-col sm:flex-row items-center justify-center gap-3 text-center">
            <div className="flex flex-col items-center gap-1.5">
              <div className="font-bold flex items-center justify-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Personal IPO Limit Active ({personalIPOCheck.existingTicker ? `$${personalIPOCheck.existingTicker}` : 'Active Listing'})</span>
              </div>
              <p className="text-slate-600 leading-relaxed max-w-xl">
                {personalIPOCheck.reason} You can manage or delist your current personal IPO first, or freely launch unlimited <strong>Business IPOs</strong> with any of your 3 currency types.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIpoType('business')}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold shrink-0 hover:bg-indigo-700 transition-colors cursor-pointer"
            >
              Switch to Business IPO
            </button>
          </div>
        )}

        {/* ERROR NOTIFICATION */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center justify-between gap-2.5 text-center">
            <div className="flex items-center gap-2.5 flex-1 justify-center">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
            <button
              type="button"
              onClick={() => setErrorMsg(null)}
              className="p-1 rounded-lg text-rose-500 hover:text-rose-800 hover:bg-rose-100 transition-colors cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* SCROLLABLE FORM BODY */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[calc(92vh-210px)] text-center">
          
          {/* ===================== PERSONAL IPO SECTION ===================== */}
          {ipoType === 'personal' && (
            <div className="space-y-6 text-center">
              
              {/* Informational Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-b from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/20 text-xs text-amber-900 flex flex-col items-center justify-center text-center">
                <div className="font-bold flex items-center justify-center gap-1.5 text-sm text-amber-800">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Personal Sovereign Human Equity (IPO)</span>
                </div>
              </div>

              {/* Personal Details & Persona Profile */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Your Full Legal / Sovereign Identity *
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Alex Chen"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500/30"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Core Profession &amp; Domain Expertise *
                  </label>
                  <input
                    type="text"
                    value={profession}
                    onChange={(e) => setProfession(e.target.value)}
                    placeholder="e.g. Quantitative Systems Architect, High-Conviction AI Researcher, Sovereign Asset Allocator"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500/30"
                  />
                </div>
              </div>

              {/* Personality Traits Badges */}
              <div className="flex flex-col items-center text-center">
                <label className="block text-xs font-bold text-slate-700 mb-1.5 text-center">
                  Personality Archetypes &amp; Signature Traits (Select up to 5)
                </label>
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  {PRESET_PERSONALITY_TRAITS.map((trait) => {
                    const isSelected = selectedTraits.includes(trait);
                    return (
                      <button
                        key={trait}
                        type="button"
                        onClick={() => toggleTrait(trait)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-amber-500/20 text-amber-800 border-amber-500/40 shadow-2xs'
                            : 'bg-slate-100 text-slate-600 border-transparent hover:border-slate-300'
                        }`}
                      >
                        {isSelected ? '✓ ' : '+ '}{trait}
                      </button>
                    );
                  })}
                </div>

                {/* Custom trait input */}
                <div className="flex items-center justify-center gap-2 mt-3 w-full max-w-md mx-auto">
                  <input
                    type="text"
                    value={customTraitInput}
                    onChange={(e) => setCustomTraitInput(e.target.value)}
                    placeholder="Add custom personality trait..."
                    className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-medium text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500/30 flex-1"
                  />
                  <button
                    type="button"
                    onClick={addCustomTrait}
                    className="px-3 py-1.5 rounded-xl bg-slate-200 text-slate-800 text-xs font-bold hover:bg-slate-300 cursor-pointer shrink-0"
                  >
                    Add Trait
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                  Persona Biography &amp; Prospectus Pitch
                </label>
                <textarea
                  value={personaProfile}
                  onChange={(e) => setPersonaProfile(e.target.value)}
                  rows={3}
                  placeholder="Describe your background, philosophy, historical track record, and how investors in your Human Equity will share in your future value creation..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-medium text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500/30"
                />
              </div>

              {/* SOLVENCY NET WORTH BREAKDOWN (4 MODES) */}
              <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1.5 text-center">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-1">
                  <div className="flex items-center gap-1">
                    <Scale className="w-3.5 h-3.5 text-amber-500" />
                    <span className="font-bold text-[11px] text-slate-900">
                      Solvency Net Worth Breakdown (4 Modes)
                    </span>
                  </div>
                  <div className="text-[11px] font-mono font-bold text-amber-700 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 tabular-nums">
                    Total NAV: ₣{total5ModeNetWorthUSD.toLocaleString()}
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  <div>
                    <label className="block text-[9px] font-semibold text-slate-500 mb-0.5 text-center">
                      1. Fiat ($)
                    </label>
                    <input
                      type="number"
                      value={netWorthFiatUSD}
                      onChange={(e) => setNetWorthFiatUSD(e.target.value)}
                      className="w-full px-1.5 py-0.5 rounded border border-slate-200 bg-white text-[11px] font-mono font-bold text-slate-900 text-center tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-semibold text-slate-500 mb-0.5 text-center">
                      2. Stable ($)
                    </label>
                    <input
                      type="number"
                      value={netWorthStableCoinsUSD}
                      onChange={(e) => setNetWorthStableCoinsUSD(e.target.value)}
                      className="w-full px-1.5 py-0.5 rounded border border-slate-200 bg-white text-[11px] font-mono font-bold text-slate-900 text-center tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-semibold text-slate-500 mb-0.5 text-center">
                      3. Crypto ($)
                    </label>
                    <input
                      type="number"
                      value={netWorthCryptoUSD}
                      onChange={(e) => setNetWorthCryptoUSD(e.target.value)}
                      className="w-full px-1.5 py-0.5 rounded border border-slate-200 bg-white text-[11px] font-mono font-bold text-slate-900 text-center tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-semibold text-slate-500 mb-0.5 text-center">
                      4. Final Coins (₣)
                    </label>
                    <input
                      type="number"
                      value={netWorthFinalCoins}
                      onChange={(e) => setNetWorthFinalCoins(e.target.value)}
                      className="w-full px-1.5 py-0.5 rounded border border-slate-200 bg-white text-[11px] font-mono font-bold text-slate-900 text-center tabular-nums"
                    />
                  </div>
                </div>
              </div>

              {/* STRICT FINAL COIN SELECTOR (ADMIN, OWN, OR PEER/COMMUNITY COINS) */}
              <div className="p-4 rounded-2xl border border-amber-500/30 bg-amber-500/5 space-y-3 text-center">
                <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <Coins className="w-4 h-4 text-amber-600" />
                    <span className="font-bold text-xs text-slate-900">
                      Select Backing Final Coin * (Admin, Your Own, or Someone Else's Final Coin)
                    </span>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-md">
                    Final Coin Only • Sovereign Requirement
                  </span>
                </div>

                <p className="text-[11px] text-slate-600 max-w-2xl mx-auto">
                  Select any unpegged Final Coin in the network as your equity reserve asset — search and choose the <strong>Official Final Admin Coin</strong>, your <strong>Own Minted Coin</strong>, or a <strong>Peer Creator's Final Coin</strong>.
                </p>

                {/* Search and Filter Controls */}
                <div className="space-y-2.5">
                  {/* Search input */}
                  <div className="relative max-w-2xl mx-auto">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={personalCoinSearch}
                      onChange={(e) => setPersonalCoinSearch(e.target.value)}
                      placeholder="Search Final Coins by name, ticker symbol (e.g. AFNL, NEBL), creator, or collateral..."
                      className="w-full pl-9 pr-8 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-900 text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500/30"
                    />
                    {personalCoinSearch && (
                      <button
                        type="button"
                        onClick={() => setPersonalCoinSearch('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Filter Tabs for Final Coins */}
                  <div className="flex flex-wrap items-center justify-center gap-1.5 p-1 bg-white/70 rounded-xl border border-slate-200">
                    <button
                      type="button"
                      onClick={() => setPersonalFinalCoinFilter('all')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        personalFinalCoinFilter === 'all'
                          ? 'bg-amber-500 text-slate-950 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      All Final Coins ({finalCoinsOnly.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setPersonalFinalCoinFilter('admin')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        personalFinalCoinFilter === 'admin'
                          ? 'bg-amber-500 text-slate-950 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>🛡️ Admin Official</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPersonalFinalCoinFilter('mine')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        personalFinalCoinFilter === 'mine'
                          ? 'bg-emerald-500 text-slate-950 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>👤 Your Own ({finalCoinsOnly.filter(c => c.creatorId === 'you' || c.creatorId === currentUser?.id || c.creatorId === 'current_user').length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPersonalFinalCoinFilter('community')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        personalFinalCoinFilter === 'community'
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>🌐 Someone Else's ({finalCoinsOnly.filter(c => !c.isAdminCoin && c.creatorId !== 'admin' && c.creatorId !== 'you' && c.creatorId !== currentUser?.id && c.creatorId !== 'current_user').length})</span>
                    </button>
                  </div>
                </div>

                {filteredPersonalFinalCoins.length === 0 ? (
                  <div className="p-4 rounded-xl bg-amber-100/60 text-amber-900 text-xs flex flex-col sm:flex-row items-center justify-center gap-2 text-center">
                    <span>No Final Coins found matching your search. Clear your search or select "All Final Coins" to view all available options.</span>
                    <button
                      type="button"
                      onClick={() => {
                        setPersonalFinalCoinFilter('all');
                        setPersonalCoinSearch('');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 text-[11px] font-bold shrink-0 cursor-pointer"
                    >
                      Reset Filters
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-72 overflow-y-auto pr-1">
                    {filteredPersonalFinalCoins.map((coin) => {
                      const isSelected = (currentBackingFinalCoin?.id === coin.id);
                      const isMine = coin.creatorId === 'you' || coin.creatorId === currentUser?.id || coin.creatorId === 'current_user';
                      const isAdmin = coin.isAdminCoin || coin.creatorId === 'admin' || coin.creatorId === 'super_admin';

                      return (
                        <div
                          key={coin.id}
                          onClick={() => setSelectedFinalCoinId(coin.id)}
                          className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col items-center justify-between text-center gap-2 ${
                            isSelected
                              ? 'bg-amber-500/15 border-amber-500 shadow-2xs ring-1 ring-amber-500'
                              : 'bg-white border-slate-200 hover:border-amber-400'
                          }`}
                        >
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md ${
                              isAdmin
                                ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                : isMine
                                ? 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                                : 'bg-indigo-100 text-indigo-900 border border-indigo-200'
                            }`}>
                              {isAdmin ? '🛡️ Admin Protocol' : isMine ? '👤 Your Minted Coin' : `🌐 Creator: ${coin.creatorName || coin.creatorHandle || "Peer Creator"}`}
                            </span>
                            {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-600" />}
                          </div>

                          <div className="flex flex-col items-center gap-1.5">
                            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-600 flex items-center justify-center font-bold text-sm shrink-0">
                              {coin.iconSymbol || '⚡'}
                            </div>
                            <div className="min-w-0">
                              <div className="font-bold text-xs text-slate-900 truncate">
                                {coin.name} ({coin.symbol})
                              </div>
                              <div className="text-[10px] font-mono text-slate-500 mt-0.5 tabular-nums">
                                Unpegged • ₣{(coin.priceUSD || 1).toFixed(2)} • Audit: {coin.auditScore || 98}/100
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* ===================== BUSINESS IPO SECTION ===================== */}
          {ipoType === 'business' && (
            <div className="space-y-6 text-center">
              
              {/* Informational Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-b from-indigo-500/10 via-indigo-500/5 to-transparent border border-indigo-500/20 text-xs text-indigo-950 flex flex-col items-center justify-center text-center">
                <div className="font-bold flex items-center justify-center gap-1.5 text-sm text-indigo-800">
                  <Building2 className="w-4 h-4 text-indigo-500" />
                  <span>Corporate Business Initial Public Offering (IPO)</span>
                </div>
              </div>

              {/* Company Legal Profile */}
              <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-200 space-y-3 text-center">
                <div className="flex flex-col items-center justify-center gap-1 text-center">
                  <span className="text-xs font-bold text-slate-900 flex items-center justify-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Select Business Scale &amp; Tier (Quick-Fill Presets for Small &amp; Large Entities)</span>
                  </span>
                  <span className="text-[10px] font-mono text-indigo-700">
                    Supports Solo, Micro &amp; Large Businesses
                  </span>
                </div>

                {/* Preset Chips */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {BUSINESS_SCALE_PRESETS.map((p) => {
                    const isActive = activeBizPreset === p.id;
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => applyBusinessPreset(p)}
                        className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          isActive
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-indigo-400'
                        }`}
                      >
                        <div className="text-[11px] font-bold truncate">{p.badge}</div>
                        <div className={`text-[10px] truncate mt-0.5 ${isActive ? 'text-indigo-100' : 'text-slate-500'}`}>
                          {p.name}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Company Legal Profile Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Official Company / Venture Name *
                  </label>
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="e.g. Acme Boutique Studio LLC or Hyperion Dynamics"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Legal Corporate / Business Structure *
                  </label>
                  <select
                    value={legalStructure}
                    onChange={(e) => setLegalStructure(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  >
                    <option value="Single-Member LLC / Boutique Studio">Single-Member LLC / Boutique Studio (Small Business)</option>
                    <option value="Sole Proprietorship / Creator Venture">Sole Proprietorship / Creator Venture (Solo/Small)</option>
                    <option value="Commercial LLC / Small Business Corp">Commercial LLC / Small Business Corp</option>
                    <option value="Small Business Partnership / LLP">Small Business Partnership / LLP</option>
                    <option value="Singapore Private Limited (Pte. Ltd.)">Singapore Private Limited (Pte. Ltd.)</option>
                    <option value="Private Limited (Pvt. Ltd.)">Private Limited (Pvt. Ltd.)</option>
                    <option value="S-Corporation (S-Corp)">S-Corporation (S-Corp)</option>
                    <option value="Delaware C-Corporation (Public Tier)">Delaware C-Corporation (Public Standard)</option>
                    <option value="Swiss Aktiengesellschaft (AG)">Swiss Aktiengesellschaft (AG / Zug)</option>
                    <option value="Sovereign Decentralized Autonomous Org (DAO)">Sovereign Protocol DAO</option>
                    <option value="UK Public Limited Company (PLC)">UK Public Limited Company (PLC)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Sector Classification *
                  </label>
                  <select
                    value={sector}
                    onChange={(e) => setSector(e.target.value as StockSector)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  >
                    {SECTORS.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Specific Industry / Sub-Sector *
                  </label>
                  <input
                    type="text"
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value)}
                    placeholder="e.g. Design Studio, Clean Energy, SaaS, Coffee Shop"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-center gap-2 mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      Registration No. / EIN / ID
                    </label>
                    <button
                      type="button"
                      onClick={handleAutoGenerateRegistrationId}
                      className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                    >
                      + Auto-ID
                    </button>
                  </div>
                  <input
                    type="text"
                    value={registrationNumber}
                    onChange={(e) => setRegistrationNumber(e.target.value)}
                    placeholder="e.g. LLC-PROV-948201 or EIN-84-99214"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-mono font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Headquarters / Location *
                  </label>
                  <input
                    type="text"
                    value={headquarters}
                    onChange={(e) => setHeadquarters(e.target.value)}
                    placeholder="e.g. Austin, TX / Remote Studio"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Founded Year &amp; Headcount
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      value={foundedYear}
                      onChange={(e) => setFoundedYear(e.target.value)}
                      placeholder="2024"
                      className="w-full px-2.5 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono font-semibold text-slate-900 text-center tabular-nums"
                    />
                    <input
                      type="text"
                      value={employeeCount}
                      onChange={(e) => setEmployeeCount(e.target.value)}
                      placeholder="1-5 Staff"
                      className="w-full px-2.5 py-2 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-900 text-center"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Website / Link (Optional)
                  </label>
                  <input
                    type="text"
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    placeholder="https://mybusiness.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center"
                  />
                </div>
              </div>

              {/* Commercial Model & Pitch */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Business Model &amp; Revenue Engines *
                  </label>
                  <textarea
                    value={businessModel}
                    onChange={(e) => setBusinessModel(e.target.value)}
                    rows={3}
                    placeholder="Explain revenue generation, recurring software/hardware contracts, licensing, and margins..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-medium text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    Unique Value Proposition / Competitive Moat *
                  </label>
                  <textarea
                    value={valueProposition}
                    onChange={(e) => setValueProposition(e.target.value)}
                    rows={3}
                    placeholder="Proprietary IP, patents, network moat, supply chain advantages, or verified technology patents..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-medium text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>
              </div>

              {/* Financial Performance */}
              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3 text-center">
                <span className="font-bold text-xs text-slate-900 flex items-center justify-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                  <span>Financial Metrics &amp; Commercial Track Record</span>
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1 text-center">
                      Annual Revenue (₣ AFNL)
                    </label>
                    <input
                      type="number"
                      value={annualRevenueUSD}
                      onChange={(e) => setAnnualRevenueUSD(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono font-bold text-slate-900 text-center tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1 text-center">
                      Net Profit Margin (%)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={netProfitMarginPercent}
                      onChange={(e) => setNetProfitMarginPercent(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono font-bold text-slate-900 text-center tabular-nums"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1 text-center">
                      Projected YoY Growth (%)
                    </label>
                    <input
                      type="number"
                      value={projectedGrowthPercent}
                      onChange={(e) => setProjectedGrowthPercent(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono font-bold text-slate-900 text-center tabular-nums"
                    />
                  </div>
                </div>
              </div>

              {/* Executive Leadership */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    CEO / Founder *
                  </label>
                  <input
                    type="text"
                    value={ceoName}
                    onChange={(e) => setCeoName(e.target.value)}
                    placeholder="Chief Executive Officer"
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    CTO / Technical Lead
                  </label>
                  <input
                    type="text"
                    value={ctoName}
                    onChange={(e) => setCtoName(e.target.value)}
                    placeholder="Chief Technology Officer"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                    CFO / Finance Lead
                  </label>
                  <input
                    type="text"
                    value={cfoName}
                    onChange={(e) => setCfoName(e.target.value)}
                    placeholder="Chief Financial Officer"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-900 text-xs font-semibold text-center"
                  />
                </div>
              </div>

              {/* BUSINESS BACKING COIN SELECTOR (3 CURRENCY TYPES: FINAL, STABLE, OR CRYPTO) */}
              <div className="p-4 rounded-2xl border border-indigo-500/30 bg-indigo-500/5 space-y-3 text-center">
                <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <Coins className="w-4 h-4 text-indigo-600" />
                    <span className="font-bold text-xs text-slate-900">
                      Select Digital Currency Backing Coin (Any 3 Currency Types)
                    </span>
                  </div>
                  <span className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-100 px-2.5 py-0.5 rounded-md">
                    3 Currency Types Supported: Final • Stable • Crypto
                  </span>
                </div>

                <p className="text-[11px] text-slate-600 max-w-2xl mx-auto">
                  Choose any digital currency in the network for treasury backing and dividend settlement — search across all Admin, Personal, and Community coins.
                </p>

                {/* Search and Filter Controls */}
                <div className="space-y-2.5">
                  {/* Search input */}
                  <div className="relative max-w-2xl mx-auto">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={businessCoinSearch}
                      onChange={(e) => setBusinessCoinSearch(e.target.value)}
                      placeholder="Search coins by name, ticker (e.g. AFNL, USDC, ETH), creator, or currency type..."
                      className="w-full pl-9 pr-8 py-2 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-900 text-center focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30"
                    />
                    {businessCoinSearch && (
                      <button
                        type="button"
                        onClick={() => setBusinessCoinSearch('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* 3-Currency Filter Switcher Tabs */}
                  <div className="flex flex-wrap items-center justify-center gap-1.5 p-1 bg-white/70 rounded-xl border border-slate-200">
                    <button
                      type="button"
                      onClick={() => setBusinessCoinTypeFilter('all')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        businessCoinTypeFilter === 'all'
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      All Final Coins ({finalCoinsOnly.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setBusinessCoinTypeFilter('admin')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        businessCoinTypeFilter === 'admin'
                          ? 'bg-amber-500 text-slate-950 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>🛡️ Admin Official</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setBusinessCoinTypeFilter('mine')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        businessCoinTypeFilter === 'mine'
                          ? 'bg-emerald-500 text-slate-950 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>👤 Your Own ({finalCoinsOnly.filter(c => c.creatorId === 'you' || c.creatorId === currentUser?.id || c.creatorId === 'current_user').length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setBusinessCoinTypeFilter('community')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                        businessCoinTypeFilter === 'community'
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <span>🌐 Someone Else's ({finalCoinsOnly.filter(c => !c.isAdminCoin && c.creatorId !== 'admin' && c.creatorId !== 'you' && c.creatorId !== currentUser?.id && c.creatorId !== 'current_user').length})</span>
                    </button>
                  </div>
                </div>

                {businessEligibleCoins.length === 0 ? (
                  <div className="p-4 rounded-xl bg-indigo-100/60 text-indigo-900 text-xs flex flex-col sm:flex-row items-center justify-center gap-2 text-center">
                    <span>No coins found matching your search. Clear your search or choose "All Available" to explore options.</span>
                    <button
                      type="button"
                      onClick={() => {
                        setBusinessCoinTypeFilter('all');
                        setBusinessCoinSearch('');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-bold shrink-0 cursor-pointer"
                    >
                      Reset Filters
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-h-72 overflow-y-auto pr-1">
                    {businessEligibleCoins.map((coin) => {
                      const isSelected = (currentBackingBusinessCoin?.id === coin.id);
                      const isMine = coin.creatorId === 'you' || coin.creatorId === currentUser?.id || coin.creatorId === 'current_user';
                      const isAdmin = coin.isAdminCoin || coin.creatorId === 'admin' || coin.creatorId === 'super_admin';

                      return (
                        <div
                          key={coin.id}
                          onClick={() => setSelectedBusinessCoinId(coin.id)}
                          className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col items-center justify-between text-center gap-1.5 ${
                            isSelected
                              ? 'bg-indigo-500/15 border-indigo-500 shadow-2xs ring-1 ring-indigo-500'
                              : 'bg-white border-slate-200 hover:border-indigo-400'
                          }`}
                        >
                          <div className="flex items-center justify-center gap-1.5">
                            <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                              coin.coinType === 'stable_coin'
                                ? 'bg-emerald-100 text-emerald-800'
                                : coin.coinType === 'final_coin'
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-purple-100 text-purple-900'
                            }`}>
                              {coin.coinType === 'stable_coin' ? '🛡️ Stablecoin' : coin.coinType === 'final_coin' ? '⚡ Final Coin' : '⛓️ Crypto'}
                            </span>
                            {isSelected && <CheckCircle2 className="w-4 h-4 text-indigo-600" />}
                          </div>
                          
                          <div className="font-bold text-xs text-slate-900 truncate max-w-full">
                            {coin.name} ({coin.symbol})
                          </div>

                          <div className="text-[10px] text-slate-500 truncate max-w-full">
                            {isAdmin ? '🛡️ Admin Official' : isMine ? '👤 Your Coin' : `🌐 ${coin.creatorName || coin.creatorHandle || 'Peer Creator'}`}
                          </div>

                          <div className="text-[10px] font-mono text-slate-500 mt-1 pt-1.5 border-t border-slate-100 flex items-center justify-center gap-2 w-full tabular-nums">
                            <span>₣{(coin.priceUSD || 1).toFixed(2)}</span>
                            <span>•</span>
                            <span className="text-[9px] uppercase font-bold text-indigo-600">
                              {coin.coinType === 'stable_coin' ? 'Stable' : coin.coinType === 'final_coin' ? 'Final' : 'Crypto'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* ===================== MEDIA & VISUAL PROSPECTUS (PHOTOS & VIDEOS) ===================== */}
          <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-4 text-center">
            <div className="flex flex-col items-center justify-center gap-1 text-center">
              <div className="flex items-center justify-center gap-2">
                <Film className="w-4 h-4 text-purple-500" />
                <span className="font-bold text-xs text-slate-900">
                  Media &amp; Visual Pitch Gallery (Photos &amp; Videos)
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500">
                Upload now or add/edit anytime after launch • {mediaList.length} items attached
              </span>
            </div>

            {/* Current Media Items Preview */}
            {mediaList.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {mediaList.map((m) => (
                  <div key={m.id} className="relative group rounded-xl overflow-hidden border border-slate-200 bg-indigo-600 flex flex-col">
                    <div className="aspect-video w-full bg-slate-100 flex items-center justify-center overflow-hidden relative">
                      {m.type === 'video' ? (
                        <video src={m.url} className="w-full h-full object-cover" preload="metadata" />
                      ) : (
                        <img src={m.url} alt={m.title || 'media'} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      )}
                      <span className="absolute top-1 left-1 px-1.5 py-0.5 rounded text-[8px] font-mono font-bold bg-black/75 text-white">
                        {m.type === 'video' ? 'VIDEO' : 'PHOTO'}
                      </span>
                      {m.isCover && (
                        <span className="absolute top-1 right-1 px-1.5 py-0.5 rounded text-[8px] font-mono font-bold bg-amber-400 text-slate-950 flex items-center gap-0.5">
                          <Star className="w-2.5 h-2.5 fill-slate-950" /> Cover
                        </span>
                      )}
                    </div>
                    <div className="p-2 bg-white flex items-center justify-between text-[11px]">
                      <span className="truncate font-semibold text-slate-800">{m.title || 'Asset'}</span>
                      <div className="flex items-center gap-1">
                        {!m.isCover && (
                          <button
                            type="button"
                            onClick={() => handleSetCover(m.id)}
                            className="text-[9px] font-bold text-amber-600 hover:text-amber-800 cursor-pointer"
                            title="Set as Cover"
                          >
                            Cover
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDeleteMedia(m.id)}
                          className="text-rose-500 hover:text-rose-700 p-0.5 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Quick Upload or URL Attachment Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              {/* File Upload Box */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-4 rounded-xl border border-dashed border-slate-300 hover:border-slate-400 bg-white flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors text-center"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <div className="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-600 flex items-center justify-center shrink-0">
                  <Upload className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">
                    Upload Photo or Video Pitch
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Click to select MP4/WebM video or PNG/JPG photo (up to 25MB)
                  </div>
                </div>
              </div>

              {/* Direct URL Attachment Box */}
              <div className="p-3 rounded-xl border border-slate-200 bg-white space-y-2 flex flex-col items-center justify-center text-center overflow-hidden w-full max-w-full box-border">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-[11px] font-bold text-slate-700">Or Paste URL:</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setMediaUploadType('photo')}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                        mediaUploadType === 'photo' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      Photo
                    </button>
                    <button
                      type="button"
                      onClick={() => setMediaUploadType('video')}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                        mediaUploadType === 'video' ? 'bg-purple-600 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      Video
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 w-full">
                  <input
                    type="url"
                    value={mediaUrlInput}
                    onChange={(e) => setMediaUrlInput(e.target.value)}
                    placeholder={mediaUploadType === 'video' ? 'https://.../video.mp4' : 'https://.../image.jpg'}
                    className="flex-1 min-w-0 px-2 py-1 rounded-lg border border-slate-200 text-[11px] bg-slate-50 font-mono text-center truncate"
                  />
                  <button
                    type="button"
                    onClick={handleAddMediaUrl}
                    className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-bold cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ===================== COMMON IPO OFFERING TERMS ===================== */}
          <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50 space-y-4 text-center">
            <span className="font-bold text-xs text-slate-900 flex items-center justify-center gap-1.5">
              <DollarSign className="w-4 h-4 text-amber-500" />
              <span>Stock Market Float &amp; Offering Capitalization</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                  Proposed Stock Ticker * (2-6 letters)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-mono font-bold text-slate-400">$</span>
                  <input
                    type="text"
                    value={ticker}
                    onChange={(e) => setTicker(e.target.value.toUpperCase())}
                    placeholder="ALEX"
                    maxLength={6}
                    required
                    className="w-full pl-7 pr-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono font-bold text-slate-900 uppercase text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500/30"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                  Total Shares to Issue / Float *
                </label>
                <input
                  type="number"
                  value={sharesOffered}
                  onChange={(e) => setSharesOffered(e.target.value)}
                  placeholder="1000000"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono font-bold text-slate-900 text-center tabular-nums"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 text-center">
                  Initial IPO Offering Price (₣ AFNL) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={offeringPriceUSD}
                  onChange={(e) => setOfferingPriceUSD(e.target.value)}
                  placeholder="25.00"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono font-bold text-slate-900 text-center tabular-nums"
                />
              </div>
            </div>

            {/* Target Valuation Display */}
            <div className="p-3.5 rounded-xl bg-white border border-slate-200 flex flex-col sm:flex-row items-center justify-center gap-3 text-center">
              <div className="text-xs text-slate-500 tabular-nums">
                <span>Calculated Initial Market Valuation:</span>
                <span className="font-mono font-bold text-slate-900 ml-2 text-sm">
                  ₣{calculatedTargetValuationUSD.toLocaleString()}
                </span>
              </div>

              <span className="hidden sm:inline text-slate-300">•</span>

              <div className="text-xs font-mono text-slate-500 tabular-nums">
                Initial Public Float: ~{(calculatedShares * 0.4).toLocaleString()} shares (40%)
              </div>
            </div>
          </div>



          {/* SUBMIT BUTTON */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition-all shadow-md flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Submitting Application...' : 'Submit IPO Request to Admin'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
