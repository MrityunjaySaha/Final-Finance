import React, { useState, useEffect, useMemo } from 'react';
import { X, HandCoins, Search, CheckCircle2, Calendar } from 'lucide-react';
import { recordLedgerTransaction } from '../utils/universalLedgerBridge';
import { UniversalLedgerItem } from '../types/ledger';
import { AuthSession } from '../types/auth';
import { UserPublicProfile } from '../types/social';
import {
  createLoan,
  LoanRecord,
  calculateMonthlyInstallment,
  isRegisteredInternalBank,
} from '../services/loanService';
import { ConfirmModal } from './common/ConfirmModal';
import { getStoredUserWallets } from '../data/defaultWallets';
import { getWalletCurrencyBalance } from '../utils/walletBalanceUpdater';
import { UserWalletData } from '../types/wallet';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { enqueueUserNotification } from '../services/socialService';
import { isAdminOrSuperAdminUser } from '../utils/verificationTiers';

interface ProvideLoanModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthSession | null;
  targetUser: UserPublicProfile;
  mode: 'provide' | 'ask';
  onSuccess: (msg: string) => void;
}

export const ProvideLoanModal: React.FC<ProvideLoanModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  targetUser,
  mode,
  onSuccess,
}) => {
  const [walletData, setWalletData] = useState<UserWalletData>(() =>
    getStoredUserWallets(currentUser?.id || 'guest')
  );
  const [loanAmount, setLoanAmount] = useState('1000');
  const [loanInterest, setLoanInterest] = useState('5.0');
  const [loanTermDays, setLoanTermDays] = useState('30');
  const [coinSearch, setCoinSearch] = useState('');
  const [selectedCoin, setSelectedCoin] = useState(
    () => walletData.finalCoins.find((c) => c.balance > 0)?.symbol || ''
  );
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    const fresh = getStoredUserWallets(currentUser?.id || 'guest');
    setWalletData(fresh);
    const available = fresh.finalCoins.filter((c) => c.balance > 0);
    if (mode === 'provide') {
      if (available.length > 0 && !available.some((c) => c.symbol === selectedCoin)) {
        setSelectedCoin(available[0].symbol);
      } else if (available.length === 0) {
        setSelectedCoin('');
      }
    } else if (!selectedCoin && fresh.finalCoins[0]?.symbol) {
      setSelectedCoin(fresh.finalCoins[0].symbol);
    }
  }, [currentUser?.id, isOpen, mode]);

  const ownedFinalCoins = useMemo(
    () => walletData.finalCoins.filter((c) => c.balance > 0),
    [walletData.finalCoins]
  );

  const filteredFinalCoins = useMemo(() => {
    const q = coinSearch.trim().toLowerCase();
    const base = mode === 'provide' ? ownedFinalCoins : walletData.finalCoins;
    if (!q) return base;
    return base.filter(
      (c) =>
        c.symbol.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q)
    );
  }, [coinSearch, ownedFinalCoins, walletData.finalCoins, mode]);

  const selectedCoinObj = useMemo(
    () =>
      (mode === 'provide' ? ownedFinalCoins : walletData.finalCoins).find((c) => c.symbol === selectedCoin) ||
      (mode === 'provide' ? ownedFinalCoins[0] : walletData.finalCoins[0]) ||
      null,
    [walletData.finalCoins, ownedFinalCoins, selectedCoin, mode]
  );

  const parsedAmount = parseFloat(loanAmount) || 0;
  const parsedInterest = parseFloat(loanInterest) || 0;
  const parsedTermDays = parseInt(loanTermDays, 10) || 30;
  const monthlyInstallment = useMemo(
    () => calculateMonthlyInstallment(parsedAmount, parsedInterest, parsedTermDays),
    [parsedAmount, parsedInterest, parsedTermDays]
  );
  const approxMonths = Math.max(1, Math.round((parsedTermDays / 30) * 10) / 10);

  if (!isOpen || !currentUser) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(loanAmount);
    if (isNaN(amt) || amt <= 0) {
      onSuccess('Please enter a valid loan amount.');
      return;
    }

    if (mode === 'ask') {
      const cleanHandle = ((targetUser as any).handle || targetUser.userId || '').replace(/^@+/, '');
      const isAuthorizedBank =
        isRegisteredInternalBank(targetUser.userId) ||
        isRegisteredInternalBank(targetUser.uid) ||
        isRegisteredInternalBank(cleanHandle) ||
        isRegisteredInternalBank(targetUser.email);

      if (!isAuthorizedBank) {
        onSuccess(
          'Loan requests can only be sent to individuals authorized for internal banking by Protocol Admins.'
        );
        onClose();
        return;
      }

      const borrowerHandle = `@${(currentUser.handle || currentUser.id || currentUser.uid || 'user').replace(/^@+/, '')}`;
      const lenderHandle = `@${cleanHandle || targetUser.userId}`;
      const borrowerId = currentUser.id || 'guest_trader';
      const lenderId = targetUser.userId || 'guest_trader';

      const dateObj = new Date();
      const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
      const recNum = `REC-LOAN-REQ-${Math.floor(1000 + Math.random() * 9000)}`;

      const reqItem: UniversalLedgerItem = {
        id: `rec-loan-req-${Date.now()}`,
        receiptNumber: recNum,
        taxYear: 2026,
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'deposit',
        category: 'loan',
        mode: 'final_coin',
        title: `Loan Request registered with ${lenderHandle}`,
        description: `Requested loan of ${amt.toLocaleString()} ${selectedCoin} at ${parsedInterest}% APR (${parsedTermDays} days term, est. ${monthlyInstallment.toLocaleString()} ${selectedCoin}/mo) from ${lenderHandle}.`,
        amountUSD: amt,
        feeUSD: 0.0,
        netAmountUSD: 0.0,
        sourceOrDestination: `Sovereign Credit Request`,
        counterpartyOrIssuer: lenderHandle,
        paymentCoinSymbol: selectedCoin,
        paymentCoinAmount: amt,
        taxClassification: {
          formMapping: 'Non-Taxable Transfer',
          taxableEvent: false,
          taxableAmountUSD: 0,
          holdingPeriod: 'N/A',
          taxDeductible: false,
          irsCategoryNote: 'Sovereign credit facility application.',
        },
        status: 'Settled',
        clearingNode: 'Sovereign Inter-Bank Clearing Node #04',
        cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
        signature: `SIG-REQ-${Math.floor(100000 + Math.random() * 900000)}`,
      };

      recordLedgerTransaction(borrowerId, reqItem);
      recordLedgerTransaction(lenderId, {
        ...reqItem,
        title: `Incoming Loan Request from ${borrowerHandle}`,
        description: `Received a loan request of ${amt.toLocaleString()} ${selectedCoin} at ${parsedInterest}% interest from ${borrowerHandle}.`,
      });
      recordLedgerTransaction('admin', {
        ...reqItem,
        title: `System Credit Facility Application: ${borrowerHandle} ➔ ${lenderHandle}`,
      });
      recordLedgerTransaction('super_admin', {
        ...reqItem,
        title: `System Credit Facility Application: ${borrowerHandle} ➔ ${lenderHandle}`,
      });

      window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

      dispatchGlobalNotification({
        title: `Loan Request Sent to @${targetUser.userId}`,
        description: `Requested ${amt.toLocaleString()} ${selectedCoin} at ${parsedInterest}% APR (${parsedTermDays} days).`,
        type: 'loans',
        targetTab: 'dashboard',
        amount: amt,
        currency: selectedCoin,
        showToast: false,
      });
      enqueueUserNotification([targetUser.uid, targetUser.userId], {
        title: '🏦 Incoming Loan Request',
        description: `${currentUser.name || borrowerHandle} requested a ${amt.toLocaleString()} ${selectedCoin} loan at ${parsedInterest}% APR.`,
        type: 'loans',
        targetTab: 'dashboard',
        amount: amt,
        currency: selectedCoin,
      });

      onSuccess(`Loan request for ${amt} ${selectedCoin} successfully sent to @${targetUser.userId}!`);
      onClose();
      return;
    }

    const isApprovedBank =
      isAdminOrSuperAdminUser(currentUser) ||
      isRegisteredInternalBank(currentUser.id) ||
      isRegisteredInternalBank(currentUser.uid) ||
      isRegisteredInternalBank(currentUser.handle) ||
      isRegisteredInternalBank(currentUser.email);

    if (!isApprovedBank) {
      onSuccess(
        'You must be approved to operate as a Clearing Bank by Admin before issuing Final Coin loans.'
      );
      return;
    }

    if (ownedFinalCoins.length === 0 || !selectedCoinObj || selectedCoinObj.balance <= 0) {
      onSuccess('You can only loan out a Final Currency that you currently hold with a positive balance in your Final Wallet.');
      return;
    }

    const myBankId = currentUser.id || 'guest_trader';
    const availableCoinBal = getWalletCurrencyBalance(myBankId, selectedCoin);
    if (availableCoinBal <= 0 || availableCoinBal < amt) {
      onSuccess(
        `Insufficient ${selectedCoin} balance. Max loanable: ${availableCoinBal.toLocaleString()} ${selectedCoin}, Requested: ${amt.toLocaleString()} ${selectedCoin}.`
      );
      return;
    }

    setShowConfirm(true);
  };

  const processExecution = () => {
    const amt = parseFloat(loanAmount);
    const borrowerHandle = `@${targetUser.userId}`;
    const myBankId = currentUser.id || 'guest_trader';
    const targetBankId = targetUser.userId || 'guest_trader';

    const availableCoinBal = getWalletCurrencyBalance(myBankId, selectedCoin);
    if (availableCoinBal < amt) {
      setShowConfirm(false);
      onSuccess(
        `Insufficient ${selectedCoin} balance in your Final Wallet. Available: ${availableCoinBal.toLocaleString()} ${selectedCoin}.`
      );
      return;
    }

    const now = Date.now();
    const newLoan: LoanRecord = {
      id: `loan-offer-${now}`,
      lenderId: myBankId,
      lenderHandle: `@${currentUser.id || currentUser.uid}`,
      lenderName: currentUser.name || currentUser.id || 'Loan Provider',
      lenderAvatar: currentUser.avatarUrl,
      borrowerId: targetBankId,
      borrowerHandle: borrowerHandle,
      borrowerName: targetUser.name || targetUser.userId,
      borrowerAvatar: targetUser.avatarUrl,
      amount: amt,
      coinSymbol: selectedCoin,
      interestRate: parsedInterest,
      termDays: parsedTermDays,
      monthlyInstallment,
      status: 'pending_offer',
      timestamp: new Date(now).toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      issuedAtMs: now,
      nextDueDateMs: now + Math.min(30, parsedTermDays) * 24 * 60 * 60 * 1000,
      amountPaid: 0,
    };

    createLoan(newLoan);

    dispatchGlobalNotification({
      title: `Loan Offer Sent: ${amt.toLocaleString()} ${selectedCoin}`,
      description: `Sent loan offer to ${borrowerHandle} at ${parsedInterest}% APR (${monthlyInstallment.toLocaleString()} ${selectedCoin}/mo). Awaiting borrower's final approval.`,
      type: 'loans',
      targetTab: 'subsidies',
      amount: amt,
      currency: selectedCoin,
      showToast: false,
      tone: 'gold',
    });

    enqueueUserNotification([targetUser.uid, targetUser.userId], {
      title: '🏦 New Loan Offer Awaiting Approval',
      description: `${currentUser.name || newLoan.lenderHandle} sent you a Loan Offer of ${amt.toLocaleString()} ${selectedCoin} (${parsedInterest}% APR, est. ${monthlyInstallment.toLocaleString()} ${selectedCoin}/mo). Review in Internal Banking → Ongoing Loans I've Taken.`,
      type: 'loans',
      targetTab: 'subsidies',
      amount: amt,
      currency: selectedCoin,
    });

    setShowConfirm(false);
    onSuccess(
      `Loan Offer of ${amt.toLocaleString()} ${selectedCoin} sent to ${borrowerHandle}! It now appears in their Internal Banking → Ongoing Loans I've Taken for final approval.`
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto text-center">
        {/* Centered Header */}
        <div className="relative flex flex-col items-center justify-center text-center pt-1">
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="absolute right-0 top-0 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider inline-flex items-center justify-center gap-1.5 mb-2">
            <HandCoins className="w-3 h-3" />
            <span>Inter-Bank Loan Desk</span>
          </span>
          <h3 className="text-lg font-bold text-slate-900 text-center">
            {mode === 'provide'
              ? `Issue Loan to @${targetUser.userId}`
              : `Request Loan from @${targetUser.userId}`}
          </h3>
          {mode === 'provide' && (
            <p className="text-[11px] text-slate-500 mt-1 text-center">
              You can only loan out the Final Currency and amount you currently hold in your Final Wallet.
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs text-center">
          {/* Loan Amount */}
          <div className="space-y-1.5 text-center">
            <div className="flex items-center justify-center gap-2">
              <label className="font-semibold text-slate-700 text-center">
                Loan Amount {selectedCoinObj ? `(${selectedCoinObj.symbol})` : ''}
              </label>
              {mode === 'provide' && selectedCoinObj && (
                <button
                  type="button"
                  onClick={() => setLoanAmount(String(selectedCoinObj.balance))}
                  className="text-[10px] font-mono font-bold text-amber-700 hover:text-amber-900 underline cursor-pointer"
                >
                  Max: {selectedCoinObj.balance.toLocaleString()}
                </button>
              )}
            </div>
            <input
              type="number"
              min="0.01"
              max={mode === 'provide' && selectedCoinObj ? selectedCoinObj.balance : undefined}
              step="any"
              required
              disabled={mode === 'provide' && (!selectedCoinObj || selectedCoinObj.balance <= 0)}
              value={loanAmount}
              onChange={(e) => setLoanAmount(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-bold text-slate-900 text-center tabular-nums disabled:opacity-50"
            />
            {mode === 'provide' && selectedCoinObj && parsedAmount > selectedCoinObj.balance && (
              <p className="text-[11px] font-bold text-rose-600 text-center">
                Exceeds your held {selectedCoinObj.symbol} balance ({selectedCoinObj.balance.toLocaleString()} {selectedCoinObj.symbol} available).
              </p>
            )}
          </div>

          {/* Searchable Select Final Coin from Final Wallet */}
          <div className="space-y-2 text-center">
            <label className="block font-semibold text-slate-700 text-center">
              {mode === 'provide' ? 'Select Held Final Coin' : 'Select Final Coin'}
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={coinSearch}
                onChange={(e) => setCoinSearch(e.target.value)}
                placeholder="Search your Final Wallet coins (e.g. AFNL, WOLF)..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs text-slate-900 text-center bg-slate-50/70"
              />
            </div>

            <div className="max-h-36 overflow-y-auto rounded-2xl border border-slate-200 bg-slate-50/60 p-1.5 space-y-1">
              {filteredFinalCoins.length === 0 ? (
                <div className="py-4 text-[11px] text-slate-500">
                  {ownedFinalCoins.length === 0
                    ? 'No Final Coins with positive balance found in your Final Wallet.'
                    : `No Final Coins matching "${coinSearch}".`}
                </div>
              ) : (
                filteredFinalCoins.map((coin) => {
                  const isSelected = coin.symbol === selectedCoin;
                  return (
                    <button
                      key={coin.id || coin.symbol}
                      type="button"
                      onClick={() => setSelectedCoin(coin.symbol)}
                      className={`w-full px-3 py-2 rounded-xl border text-left flex items-center justify-between gap-2 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-amber-100/80 border-amber-400 text-slate-900 shadow-2xs'
                          : 'bg-white border-slate-200/80 text-slate-700 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        {isSelected && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <div className="font-mono font-bold text-xs text-slate-900 truncate">
                            {coin.symbol}
                          </div>
                          <div className="text-[10px] text-slate-500 truncate">
                            {coin.name}
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-mono font-bold text-[11px] text-emerald-700">
                          {coin.balance.toLocaleString()} {coin.symbol}
                        </div>
                        <div className="text-[9px] text-slate-400">Available</div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
            {selectedCoinObj && (
              <div className="text-[11px] text-slate-500 font-mono">
                Selected: <strong className="text-slate-900">{selectedCoinObj.symbol}</strong> · Wallet Balance:{' '}
                <strong className="text-emerald-700">
                  {selectedCoinObj.balance.toLocaleString()} {selectedCoinObj.symbol}
                </strong>
              </div>
            )}
          </div>

          {/* Interest Rate & Term (Days) */}
          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="space-y-1.5 text-center">
              <label className="block font-semibold text-slate-700 text-center">
                Interest Rate (% APR)
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                required
                value={loanInterest}
                onChange={(e) => setLoanInterest(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium text-center"
              />
            </div>
            <div className="space-y-1.5 text-center">
              <label className="block font-semibold text-slate-700 text-center">
                Term (Days)
              </label>
              <input
                type="number"
                min="1"
                required
                value={loanTermDays}
                onChange={(e) => setLoanTermDays(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium text-center"
              />
            </div>
          </div>

          {/* Calculated Monthly Installment Preview */}
          <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-1 text-center">
            <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-800 inline-flex items-center justify-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>Estimated Monthly Installment</span>
            </div>
            <div className="text-base font-mono font-bold text-slate-900">
              {monthlyInstallment.toLocaleString()} {selectedCoin} / month
            </div>
            <div className="text-[10px] text-slate-600">
              Calculated at {parsedInterest}% APR over {parsedTermDays} days (~{approxMonths}{' '}
              {approxMonths === 1 ? 'month' : 'months'}) · Requires borrower final approval
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={
                mode === 'provide' &&
                (!selectedCoinObj ||
                  selectedCoinObj.balance <= 0 ||
                  parsedAmount <= 0 ||
                  parsedAmount > selectedCoinObj.balance)
              }
              className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {mode === 'provide' ? 'Issue Loan' : 'Send Request'}
            </button>
          </div>
        </form>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title="Confirm Loan Offer"
        message={`Send a Loan Offer of ${loanAmount} ${selectedCoin} to @${targetUser.userId} at ${loanInterest}% APR for ${loanTermDays} days (est. ${monthlyInstallment.toLocaleString()} ${selectedCoin}/mo)? Funds transfer once @${targetUser.userId} approves it in Internal Banking.`}
        confirmText="Send Loan Offer"
        type="warning"
      />
    </div>
  );
};

