import React, { useEffect, useState } from 'react';
import { CardElement, Elements, useElements, useStripe } from '@stripe/react-stripe-js';
import { AlertCircle, Building2, CheckCircle2, CreditCard, Loader2, ShieldCheck, X } from 'lucide-react';
import { AuthSession } from '../../types/auth';
import {
  createStripeSetupIntent,
  ensureStripeSession,
  getStripeConfigSafe,
  getStripePromise,
  linkBankAccountViaStripe,
  verifyStripeBankMicrodeposits,
  verifyStripeSetupIntentCard,
} from '../../services/stripeClientService';
import {
  detectVerifiedCardBrand,
  validateBillingDetailsInput,
  validatePaymentCardInput,
  validateUsBankAccountInput,
} from '../../utils/paymentValidation';
import { emitPaymentMethodsUpdated } from '../../utils/paymentMethodsBridge';

interface StripeSetupModalProps {
  isOpen: boolean;
  mode: 'card' | 'us_bank_account';
  currentUser: AuthSession;
  stripeConfigured?: boolean;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

const MAJOR_BANKS = [
  { name: 'Bank of America', defaultRouting: '026009593' },
  { name: 'Chase', defaultRouting: '021000021' },
  { name: 'Wells Fargo', defaultRouting: '121000248' },
  { name: 'Citibank', defaultRouting: '021000089' },
  { name: 'Capital One', defaultRouting: '051405515' },
  { name: 'U.S. Bank', defaultRouting: '091000022' },
  { name: 'PNC Bank', defaultRouting: '043000096' },
  { name: 'TD Bank', defaultRouting: '031101266' },
  { name: 'Charles Schwab', defaultRouting: '121202211' },
  { name: 'Ally Bank', defaultRouting: '124003116' },
];

const COUNTRIES = [
  { code: 'US', label: 'United States' },
  { code: 'CA', label: 'Canada' },
  { code: 'GB', label: 'United Kingdom' },
  { code: 'AU', label: 'Australia' },
  { code: 'DE', label: 'Germany' },
  { code: 'FR', label: 'France' },
];

const StripeCardOnlyForm: React.FC<{
  clientSecret: string;
  currentUser: AuthSession;
  onCompleted: () => void;
  onError: (msg: string) => void;
}> = ({ clientSecret, currentUser, onCompleted, onError }) => {
  const stripe = useStripe();
  const elements = useElements();

  const [email, setEmail] = useState(currentUser.email || '');
  const [phone, setPhone] = useState('');
  const [cardholderName, setCardholderName] = useState(currentUser.name || '');
  const [country, setCountry] = useState('US');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    const billingCheck = validateBillingDetailsInput({
      fullName: cardholderName,
      email,
      phone,
      country,
      addressLine1,
      city,
      state,
      postalCode,
    });
    if (!billingCheck.valid) {
      onError(billingCheck.error);
      return;
    }

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      onError('Card input is not ready yet. Please try again.');
      return;
    }

    setSubmitting(true);
    onError('');

    try {
      const { error, setupIntent } = await stripe.confirmCardSetup(clientSecret, {
        payment_method: {
          card: cardElement,
          billing_details: {
            name: cardholderName.trim(),
            email: email.trim(),
            ...(phone.trim() ? { phone: phone.trim() } : {}),
            address: {
              line1: addressLine1.trim(),
              ...(addressLine2.trim() ? { line2: addressLine2.trim() } : {}),
              city: city.trim(),
              state: state.trim(),
              postal_code: postalCode.trim(),
              country,
            },
          },
        },
      });

      if (error) {
        onError(error.message || 'Card could not be verified by your card issuer.');
        return;
      }

      if (!setupIntent || setupIntent.status !== 'succeeded') {
        onError('Card verification did not succeed. Your card was not saved.');
        return;
      }

      await verifyStripeSetupIntentCard(currentUser, setupIntent.id);
      onCompleted();
    } catch (err: any) {
      onError(err?.message || 'Unable to verify card with issuer.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3 text-center">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <div>
          <label className="block text-[11px] font-semibold text-slate-700 mb-1">
            Email Address *
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
            className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
          />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-slate-700 mb-1">
            Phone Number
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="(555) 234-5678"
            className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
          />
        </div>
      </div>

      <div>
        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
          Full Legal Name on Card *
        </label>
        <input
          type="text"
          value={cardholderName}
          onChange={(e) => setCardholderName(e.target.value)}
          placeholder="First and Last Name"
          required
          className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
        />
      </div>

      <div>
        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
          Card Information (Number, Expiration &amp; CVC) *
        </label>
        <div className="p-3 rounded-xl border border-slate-200 bg-slate-50/40">
          <CardElement
            options={{
              hidePostalCode: true,
              style: {
                base: {
                  fontSize: '14px',
                  color: '#0f172a',
                  '::placeholder': { color: '#94a3b8' },
                },
              },
            }}
          />
        </div>
      </div>

      <div className="pt-1 border-t border-slate-100 space-y-2.5">
        <p className="text-[11px] font-bold text-slate-800 uppercase tracking-wider">
          Billing Address
        </p>

        <div>
          <label className="block text-[11px] font-semibold text-slate-700 mb-1">
            Country or Region *
          </label>
          <select
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="w-full h-9 px-3 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50 focus:outline-none focus:border-slate-400"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-700 mb-1">
            Street Address *
          </label>
          <input
            type="text"
            value={addressLine1}
            onChange={(e) => setAddressLine1(e.target.value)}
            placeholder="123 Main Street"
            required
            className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
          />
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-700 mb-1">
            Apt, Suite, Unit (Optional)
          </label>
          <input
            type="text"
            value={addressLine2}
            onChange={(e) => setAddressLine2(e.target.value)}
            placeholder="Apt 4B"
            className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
          />
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">
              City *
            </label>
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="New York"
              required
              className="w-full h-9 px-2.5 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">
              State *
            </label>
            <input
              type="text"
              value={state}
              onChange={(e) => setState(e.target.value)}
              placeholder="NY"
              required
              className="w-full h-9 px-2.5 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
            />
          </div>
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">
              ZIP / Postal *
            </label>
            <input
              type="text"
              value={postalCode}
              onChange={(e) => setPostalCode(e.target.value)}
              placeholder="10001"
              required
              className="w-full h-9 px-2.5 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
            />
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={!stripe || !elements || submitting}
        className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
      >
        {submitting ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Verifying &amp; Saving Card...</span>
          </>
        ) : (
          <>
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span>Verify &amp; Save Payment Card</span>
          </>
        )}
      </button>
    </form>
  );
};

export const StripeSetupModal: React.FC<StripeSetupModalProps> = ({
  isOpen,
  mode,
  currentUser,
  stripeConfigured: stripeConfiguredProp,
  onClose,
  onSuccess,
}) => {
  const [isStripeReady, setIsStripeReady] = useState(Boolean(stripeConfiguredProp));
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [publishableKey, setPublishableKey] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Bank form state
  const [selectedBankChoice, setSelectedBankChoice] = useState('Bank of America');
  const [customBankName, setCustomBankName] = useState('');
  const [accountHolderName, setAccountHolderName] = useState(currentUser.name || '');
  const [accountType, setAccountType] = useState<'checking' | 'savings'>('checking');
  const [routingNumber, setRoutingNumber] = useState('026009593');
  const [accountNumber, setAccountNumber] = useState('');
  const [pendingBankSetupIntentId, setPendingBankSetupIntentId] = useState<string | null>(null);
  const [microAmount1, setMicroAmount1] = useState('');
  const [microAmount2, setMicroAmount2] = useState('');
  const [microDescriptor, setMicroDescriptor] = useState('');

  // Extensive Card form state (in-app)
  const [cardEmail, setCardEmail] = useState(currentUser.email || '');
  const [cardPhone, setCardPhone] = useState('');
  const [cardholderName, setCardholderName] = useState((currentUser.name || '').toUpperCase());
  const [cardNumber, setCardNumber] = useState('');
  const [cardType, setCardType] = useState<'debit' | 'credit'>('debit');
  const [expMonth, setExpMonth] = useState('');
  const [expYear, setExpYear] = useState('');
  const [cvc, setCvc] = useState('');
  const [country, setCountry] = useState('US');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    setErrorMsg('');
    setClientSecret(null);
    setAccountNumber('');
    setPendingBankSetupIntentId(null);
    setMicroAmount1('');
    setMicroAmount2('');
    setMicroDescriptor('');
    setCardNumber('');
    setExpMonth('');
    setExpYear('');
    setCvc('');
    setAddressLine1('');
    setAddressLine2('');
    setCity('');
    setState('');
    setPostalCode('');
    setCardEmail(currentUser.email || '');
    setAccountHolderName(currentUser.name || '');
    setCardholderName((currentUser.name || '').toUpperCase());

    let cancelled = false;
    const init = async () => {
      setLoading(true);
      try {
        const cfg = await getStripeConfigSafe();
        if (cancelled) return;
        const active = cfg.reachable && cfg.configured;
        setIsStripeReady(active);
        setPublishableKey(cfg.publishableKey);

        if (mode === 'card' && active && cfg.publishableKey) {
          await ensureStripeSession(currentUser);
          const intent = await createStripeSetupIntent(currentUser, 'card');
          if (!cancelled) {
            setClientSecret(intent.clientSecret);
          }
        }
      } catch {
        if (!cancelled) {
          setIsStripeReady(false);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    init();
    return () => {
      cancelled = true;
    };
  }, [isOpen, mode, currentUser.id, currentUser.uid]);

  if (!isOpen) return null;

  const resolvedBankName =
    selectedBankChoice === 'OTHER'
      ? customBankName.trim() || 'Connected Bank'
      : selectedBankChoice;

  const handleSelectBank = (name: string) => {
    setSelectedBankChoice(name);
    setErrorMsg('');
    if (name !== 'OTHER') {
      const found = MAJOR_BANKS.find((b) => b.name === name);
      if (found) {
        setRoutingNumber(found.defaultRouting);
      }
    }
  };

  const handleSaveBankAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const bankCheck = validateUsBankAccountInput({
      accountHolderName,
      routingNumber,
      accountNumber,
      accountType,
    });
    if (!bankCheck.valid) {
      setErrorMsg(bankCheck.error);
      return;
    }

    if (!isStripeReady) {
      setErrorMsg(
        'Bank details passed routing checksum checks, but verifying that this bank account actually exists requires live Stripe verification (STRIPE_SECRET_KEY) on the server. Unverified bank accounts cannot be saved.'
      );
      return;
    }

    setSubmitting(true);
    try {
      const res = await linkBankAccountViaStripe(currentUser, {
        bankName: resolvedBankName,
        accountHolderName: accountHolderName.trim(),
        accountType,
        routingNumber: bankCheck.routingNumber,
        accountNumber: bankCheck.accountNumber,
      });

      if (res.pendingVerification && res.setupIntentId) {
        setPendingBankSetupIntentId(res.setupIntentId);
        return;
      }

      emitPaymentMethodsUpdated();
      onSuccess(`${resolvedBankName} (••••${bankCheck.last4}) verified & linked to your account.`);
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Bank account could not be verified. Please check your details.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyMicrodeposits = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingBankSetupIntentId) return;
    setErrorMsg('');
    setSubmitting(true);
    try {
      const code = microDescriptor.trim();
      const a1 = Math.round(Number(microAmount1));
      const a2 = Math.round(Number(microAmount2));
      await verifyStripeBankMicrodeposits(currentUser, {
        setupIntentId: pendingBankSetupIntentId,
        ...(code ? { descriptorCode: code } : { amounts: [a1, a2] }),
      });
      emitPaymentMethodsUpdated();
      onSuccess(`${resolvedBankName} verified via micro-deposits and linked to your account.`);
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Micro-deposit verification failed. Please double-check your entries.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleValidateExtensiveCard = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cardCheck = validatePaymentCardInput({
      cardholderName,
      email: cardEmail,
      phone: cardPhone,
      cardNumber,
      expMonth,
      expYear,
      cvc,
      country,
      addressLine1,
      addressLine2,
      city,
      state,
      postalCode,
    });

    if (!cardCheck.valid) {
      setErrorMsg(cardCheck.error);
      return;
    }

    setErrorMsg(
      'All card details passed checksum and billing validation, but confirming with your card network that this debit/credit card actually exists requires STRIPE_SECRET_KEY and STRIPE_PUBLISHABLE_KEY on the server. Unverified cards cannot be saved.'
    );
  };

  const cleanCardDigits = cardNumber.replace(/\D/g, '');
  const detectedBrand = cleanCardDigits.length >= 13 ? detectVerifiedCardBrand(cleanCardDigits) : null;
  const stripePromise = getStripePromise(publishableKey);

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg rounded-3xl bg-white border border-slate-200 shadow-2xl p-6 sm:p-7 my-auto space-y-4 max-h-[92vh] overflow-y-auto"
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center pb-3 border-b border-slate-100">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-bold uppercase tracking-wider mb-1.5">
            {mode === 'us_bank_account' ? (
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
            ) : (
              <CreditCard className="w-3.5 h-3.5 text-purple-600" />
            )}
            <span>{mode === 'us_bank_account' ? 'Verified Bank Account' : 'Verified Payment Card'}</span>
          </div>
          <h3 className="text-lg font-serif font-bold text-slate-900">
            {mode === 'us_bank_account'
              ? pendingBankSetupIntentId
                ? 'Verify Bank Micro-Deposits'
                : 'Link Bank Account'
              : 'Link Payment Card'}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {mode === 'us_bank_account'
              ? pendingBankSetupIntentId
                ? 'Enter the 6-character SM code or two micro-deposit amounts from your bank statement.'
                : 'Accounts are only saved after routing and account verification succeeds.'
              : 'Complete all card and billing details to verify and save your card.'}
          </p>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center justify-center gap-2 text-center">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {loading ? (
          <div className="py-10 flex flex-col items-center justify-center gap-2 text-slate-500">
            <Loader2 className="w-6 h-6 animate-spin text-slate-700" />
            <span className="text-xs font-medium">Preparing verification form...</span>
          </div>
        ) : mode === 'us_bank_account' ? (
          pendingBankSetupIntentId ? (
            <form onSubmit={handleVerifyMicrodeposits} className="space-y-3 text-center">
              <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 flex items-center justify-center gap-2 text-center">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>
                  Your bank routing details passed initial checks. Complete verification below so this account can be saved and used.
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  6-Character Verification Code (e.g. SM1234)
                </label>
                <input
                  type="text"
                  value={microDescriptor}
                  onChange={(e) => setMicroDescriptor(e.target.value.toUpperCase())}
                  placeholder="SMXXXX"
                  maxLength={6}
                  className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono uppercase text-slate-900 bg-slate-50/50"
                />
              </div>

              <div className="text-center text-[11px] font-bold text-slate-400">OR</div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Deposit 1 (Cents)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={microAmount1}
                    onChange={(e) => setMicroAmount1(e.target.value)}
                    placeholder="32"
                    className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Deposit 2 (Cents)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={microAmount2}
                    onChange={(e) => setMicroAmount2(e.target.value)}
                    placeholder="45"
                    className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Verifying Bank Account...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Confirm &amp; Verify Bank Account</span>
                  </>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleSaveBankAccount} className="space-y-3 text-center">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Choose Your Bank
                </label>
                <div className="grid grid-cols-2 gap-1.5 mb-2">
                  {['Bank of America', 'Chase', 'Wells Fargo', 'Citibank'].map((name) => (
                    <button
                      key={name}
                      type="button"
                      onClick={() => handleSelectBank(name)}
                      className={`px-2.5 py-2 rounded-xl border text-xs font-bold text-center transition-all cursor-pointer truncate ${
                        selectedBankChoice === name
                          ? 'border-blue-600 bg-blue-50 text-blue-950 shadow-2xs'
                          : 'border-slate-200 bg-slate-50/70 hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      {name}
                    </button>
                  ))}
                </div>
                <select
                  aria-label="Bank institution"
                  value={selectedBankChoice}
                  onChange={(e) => handleSelectBank(e.target.value)}
                  className="w-full h-10 px-3 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                >
                  {MAJOR_BANKS.map((bank) => (
                    <option key={bank.name} value={bank.name}>
                      {bank.name}
                    </option>
                  ))}
                  <option value="OTHER">Other Bank...</option>
                </select>
              </div>

              {selectedBankChoice === 'OTHER' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Bank Name *
                  </label>
                  <input
                    type="text"
                    value={customBankName}
                    onChange={(e) => setCustomBankName(e.target.value)}
                    placeholder="Enter your bank's name"
                    required
                    className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Legal Name *
                  </label>
                  <input
                    type="text"
                    value={accountHolderName}
                    onChange={(e) => setAccountHolderName(e.target.value)}
                    placeholder="First & Last Name"
                    required
                    className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Account Type *
                  </label>
                  <select
                    value={accountType}
                    onChange={(e) => setAccountType(e.target.value as 'checking' | 'savings')}
                    className="w-full h-10 px-3 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                  >
                    <option value="checking">Checking</option>
                    <option value="savings">Savings</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ABA Routing Number (9 Digits) *
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={9}
                  value={routingNumber}
                  onChange={(e) => setRoutingNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="026009593"
                  required
                  className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Account Number (6–17 Digits) *
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={17}
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter bank account number"
                  required
                  className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-center justify-center gap-2 text-center">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Only verified accounts that pass bank checks are saved.</span>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Verifying Bank Account...</span>
                  </>
                ) : (
                  <>
                    <Building2 className="w-4 h-4 text-blue-400" />
                    <span>Verify &amp; Link {resolvedBankName}</span>
                  </>
                )}
              </button>
            </form>
          )
        ) : stripePromise && clientSecret ? (
          <Elements
            key={clientSecret}
            stripe={stripePromise}
            options={{
              clientSecret,
              appearance: {
                theme: 'stripe',
                variables: {
                  borderRadius: '12px',
                  colorPrimary: '#0f172a',
                },
              },
            }}
          >
            <StripeCardOnlyForm
              clientSecret={clientSecret}
              currentUser={currentUser}
              onError={setErrorMsg}
              onCompleted={() => {
                emitPaymentMethodsUpdated();
                onSuccess('Payment card verified with issuer and saved to your account.');
                onClose();
              }}
            />
          </Elements>
        ) : (
          <form onSubmit={handleValidateExtensiveCard} className="space-y-3 text-center">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={cardEmail}
                  onChange={(e) => setCardEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={cardPhone}
                  onChange={(e) => setCardPhone(e.target.value)}
                  placeholder="(555) 234-5678"
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                Full Legal Name on Card *
              </label>
              <input
                type="text"
                value={cardholderName}
                onChange={(e) => setCardholderName(e.target.value)}
                placeholder="FIRST AND LAST NAME"
                required
                className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs uppercase font-semibold text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
              />
            </div>

            <div>
              <div className="flex items-center justify-center gap-2 mb-1">
                <label className="block text-[11px] font-semibold text-slate-700">
                  Card Number *
                </label>
                {detectedBrand && (
                  <span className="text-[10px] font-bold uppercase text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {detectedBrand}
                  </span>
                )}
              </div>
              <input
                type="text"
                inputMode="numeric"
                maxLength={23}
                value={cardNumber}
                onChange={(e) => {
                  const digits = e.target.value.replace(/\D/g, '').slice(0, 19);
                  const formatted = digits.replace(/(\d{4})(?=\d)/g, '$1 ');
                  setCardNumber(formatted);
                }}
                placeholder="1234 5678 9012 3456"
                required
                className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Card Type *
                </label>
                <select
                  value={cardType}
                  onChange={(e) => setCardType(e.target.value as 'debit' | 'credit')}
                  className="w-full h-9 px-2 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                >
                  <option value="debit">Debit Card</option>
                  <option value="credit">Credit Card</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Expires (MM/YY) *
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={2}
                    value={expMonth}
                    onChange={(e) => setExpMonth(e.target.value.replace(/\D/g, ''))}
                    placeholder="MM"
                    required
                    className="w-full h-9 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50"
                  />
                  <span className="text-slate-400">/</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={2}
                    value={expYear}
                    onChange={(e) => setExpYear(e.target.value.replace(/\D/g, ''))}
                    placeholder="YY"
                    required
                    className="w-full h-9 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  CVC / CVV *
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={cvc}
                  onChange={(e) => setCvc(e.target.value.replace(/\D/g, ''))}
                  placeholder="•••"
                  required
                  className="w-full h-9 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50"
                />
              </div>
            </div>

            <div className="pt-1 border-t border-slate-100 space-y-2.5">
              <p className="text-[11px] font-bold text-slate-800 uppercase tracking-wider">
                Billing Address
              </p>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Country or Region *
                </label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full h-9 px-3 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                >
                  {COUNTRIES.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Street Address *
                </label>
                <input
                  type="text"
                  value={addressLine1}
                  onChange={(e) => setAddressLine1(e.target.value)}
                  placeholder="123 Main Street"
                  required
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Apt, Suite, Unit (Optional)
                </label>
                <input
                  type="text"
                  value={addressLine2}
                  onChange={(e) => setAddressLine2(e.target.value)}
                  placeholder="Apt 4B"
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="New York"
                    required
                    className="w-full h-9 px-2.5 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    State *
                  </label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    placeholder="NY"
                    required
                    className="w-full h-9 px-2.5 text-center rounded-xl border border-slate-200 text-xs font-medium text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    ZIP / Postal *
                  </label>
                  <input
                    type="text"
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    placeholder="10001"
                    required
                    className="w-full h-9 px-2.5 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-900 bg-slate-50/50 focus:outline-none focus:border-slate-400"
                  />
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-center justify-center gap-2 text-center">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Cards are only saved after full validation and issuer verification.</span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <CreditCard className="w-4 h-4 text-purple-400" />
              <span>Verify &amp; Save Payment Card</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
