import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Coins, 
  Layers, 
  RefreshCw, 
  ArrowUpRight, 
  ShieldCheck, 
  ExternalLink,
  ChevronRight,
  Search,
  Zap,
  Clock,
  Star,
  Users,
  Globe as GlobeIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  getStoredStockOrders, 
  saveStoredStockOrders, 
  getStoredStockPositions, 
  saveStoredStockPositions,
  categorizeStockHolding 
} from '../../utils/stockWalletBridge';
import { INITIAL_USER_STOCK_POSITIONS, getStoredIPORequests } from '../../data/stocksData';
import { StockPosition, StockOrder, StockItem, StockMarketWay } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { SocialTradesFeed } from '../stocks/SocialTradesFeed';
import { CurrenciesDirectoryAndWalletView } from './CurrenciesDirectoryAndWalletView';

interface AlpacaPosition {
  symbol: string;
  asset_class: 'us_equity' | 'crypto' | 'us_option';
  qty: number;
  avg_entry_price: number;
  market_value: number;
  unrealized_pl: number;
  unrealized_plpc: number;
  change_today: number;
  expiry?: string;
  strikePrice?: number;
  contractType?: string;
}

interface AlpacaAccount {
  cash: number;
  portfolio_value: number;
  buying_power: number;
  status: string;
}

const MOCK_STABLE_CRYPTO_POSITIONS: AlpacaPosition[] = [
  // STABLE STOCKS (categorized as 'stable' via getStockType: COIN, RIOT, MARA, MSTR, USDC, USDT, PAXG, DAI)
  {
    symbol: 'COIN',
    asset_class: 'us_equity',
    qty: 50,
    avg_entry_price: 220.00,
    market_value: 12125.00,
    unrealized_pl: 1125.00,
    unrealized_plpc: 0.1022,
    change_today: 0.0534
  },
  {
    symbol: 'USDC',
    asset_class: 'us_equity',
    qty: 5000,
    avg_entry_price: 1.00,
    market_value: 5000.00,
    unrealized_pl: 0.00,
    unrealized_plpc: 0.00,
    change_today: 0.00
  },
  
  // STABLE CALL
  {
    symbol: 'COIN_260925C00250000',
    asset_class: 'us_option',
    qty: 5,
    avg_entry_price: 12.50,
    market_value: 6250.00,
    unrealized_pl: 850.00,
    unrealized_plpc: 0.1574,
    change_today: 0.042,
    expiry: '2026-09-25T16:00:00Z',
    strikePrice: 250.00,
    contractType: 'call'
  },
  
  // STABLE PUT
  {
    symbol: 'MSTR_261016P00150000',
    asset_class: 'us_option',
    qty: 3,
    avg_entry_price: 8.20,
    market_value: 2460.00,
    unrealized_pl: -120.00,
    unrealized_plpc: -0.0487,
    change_today: -0.015,
    expiry: '2026-10-16T16:00:00Z',
    strikePrice: 150.00,
    contractType: 'put'
  },

  // CRYPTO STOCKS
  {
    symbol: 'BTC',
    asset_class: 'crypto',
    qty: 0.85,
    avg_entry_price: 88000.00,
    market_value: 80580.00,
    unrealized_pl: 5780.00,
    unrealized_plpc: 0.0772,
    change_today: 0.0620
  },
  {
    symbol: 'ETH',
    asset_class: 'crypto',
    qty: 4.5,
    avg_entry_price: 3400.00,
    market_value: 16425.00,
    unrealized_pl: 1125.00,
    unrealized_plpc: 0.0735,
    change_today: 0.0480
  },

  // CRYPTO CALL
  {
    symbol: 'BTC_260925C00950000',
    asset_class: 'us_option',
    qty: 2,
    avg_entry_price: 1500.00,
    market_value: 3000.00,
    unrealized_pl: 450.00,
    unrealized_plpc: 0.1765,
    change_today: 0.082,
    expiry: '2026-09-25T16:00:00Z',
    strikePrice: 95000.00,
    contractType: 'call'
  },

  // CRYPTO PUT
  {
    symbol: 'SOL_261016P00020000',
    asset_class: 'us_option',
    qty: 10,
    avg_entry_price: 5.50,
    market_value: 5500.00,
    unrealized_pl: 320.00,
    unrealized_plpc: 0.0618,
    change_today: 0.024,
    expiry: '2026-10-16T16:00:00Z',
    strikePrice: 200.00,
    contractType: 'put'
  }
];

interface AlpacaPortfolioViewProps {
  stocks?: StockItem[];
  watchlist?: string[];
  currentUser?: AuthSession | null;
  onSelectStock?: (stock: StockItem) => void;
  onToggleWatchlist?: (ticker: string) => void;
  onOpenStockMarket?: (marketWay?: StockMarketWay | 'all') => void;
  filteredFollowedStocks?: StockItem[];
  showOnlySummary?: boolean;
}

export const AlpacaPortfolioView: React.FC<AlpacaPortfolioViewProps> = ({
  stocks = [],
  watchlist = [],
  currentUser,
  onSelectStock,
  onToggleWatchlist,
  onOpenStockMarket,
  filteredFollowedStocks = [],
  showOnlySummary = false,
}) => {
  const [account, setAccount] = useState<AlpacaAccount | null>(null);
  const [positions, setPositions] = useState<AlpacaPosition[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stockType, setStockType] = useState<'fiat' | 'stable' | 'crypto' | 'currencies'>('fiat');
  const [subTab, setSubTab] = useState<'stocks' | 'call' | 'put' | 'favorite' | 'social'>('stocks');
  const [searchQuery, setSearchQuery] = useState('');
  const [tradeToast, setTradeToast] = useState<string | null>(null);
  const [activeTradePos, setActiveTradePos] = useState<AlpacaPosition | null>(null);
  const [tradeActionSide, setTradeActionSide] = useState<'buy' | 'sell'>('buy');
  const [tradeShares, setTradeShares] = useState<number>(1);

  const formatExpiryPretty = (expiry?: string) => {
    if (!expiry) return '';
    try {
      const clean = expiry.replace('Exp:', '').trim();
      const parts = clean.split('@');
      const datePart = parts[0].trim();
      const timePart = parts[1] ? parts[1].trim() : '16:00 ET';
      
      const dateObj = new Date(datePart);
      if (!isNaN(dateObj.getTime())) {
        const formattedDate = dateObj.toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric', 
          year: 'numeric',
          timeZone: 'UTC'
        });
        return `Exp: ${formattedDate} @ ${timePart}`;
      }
      return expiry;
    } catch {
      return expiry;
    }
  };

  const handleOpenTradeModal = (pos: AlpacaPosition) => {
    setActiveTradePos(pos);
    setTradeShares(pos.qty || 1);
    setTradeActionSide('buy');
  };

  const handleConfirmTrade = () => {
    if (!activeTradePos) return;
    const isOption = activeTradePos.asset_class === 'us_option';
    const multiplier = isOption ? 100 : 1;
    const totalCost = tradeShares * activeTradePos.avg_entry_price * multiplier;
    
    // Update local positions state
    let updatedPositions: AlpacaPosition[];
    if (tradeActionSide === 'buy') {
      let found = false;
      updatedPositions = positions.map(p => {
        if (p.symbol.toUpperCase() === activeTradePos.symbol.toUpperCase() && p.asset_class === activeTradePos.asset_class) {
          found = true;
          const newQty = p.qty + tradeShares;
          const newMarketVal = newQty * p.avg_entry_price * multiplier;
          return {
            ...p,
            qty: newQty,
            market_value: newMarketVal
          };
        }
        return p;
      });
      if (!found) {
        updatedPositions.push({
          ...activeTradePos,
          qty: tradeShares,
          market_value: totalCost
        });
      }
    } else {
      // Sell
      updatedPositions = positions.map(p => {
        if (p.symbol.toUpperCase() === activeTradePos.symbol.toUpperCase() && p.asset_class === activeTradePos.asset_class) {
          const newQty = Math.max(0, p.qty - tradeShares);
          const newMarketVal = newQty * p.avg_entry_price * multiplier;
          return {
            ...p,
            qty: newQty,
            market_value: newMarketVal
          };
        }
        return p;
      }).filter(p => p.qty > 0.0001);
    }
    setPositions(updatedPositions);

    // Update account balances
    if (account) {
      const cashDelta = tradeActionSide === 'buy' ? -totalCost : totalCost;
      const nextCash = Math.max(0, account.cash + cashDelta);
      const nextBuyingPower = Math.max(0, account.buying_power + cashDelta);
      const totalHoldingsVal = updatedPositions.reduce((s, p) => s + (p.market_value || 0), 0);
      setAccount({
        ...account,
        cash: Number(nextCash.toFixed(2)),
        buying_power: Number(nextBuyingPower.toFixed(2)),
        portfolio_value: Number((nextCash + totalHoldingsVal).toFixed(2))
      });
    }

    // If it's a stock (us_equity), update global stock positions
    if (!isOption) {
      const storedPositions = getStoredStockPositions('user_1', INITIAL_USER_STOCK_POSITIONS);
      let nextStoredPositions: StockPosition[];
      const existing = storedPositions.find(p => p.ticker.toUpperCase() === activeTradePos.symbol.toUpperCase());
      
      if (tradeActionSide === 'buy') {
        if (existing) {
          const newShares = existing.shares + tradeShares;
          const totalCostBasis = (existing.shares * existing.avgCostUSD) + totalCost;
          const newAvgCost = totalCostBasis / newShares;
          const newTotalVal = newShares * activeTradePos.avg_entry_price;
          const newGainUSD = newTotalVal - totalCostBasis;
          nextStoredPositions = storedPositions.map(p => 
            p.ticker.toUpperCase() === activeTradePos.symbol.toUpperCase()
              ? {
                  ...p,
                  shares: newShares,
                  avgCostUSD: Number(newAvgCost.toFixed(2)),
                  totalValueUSD: Number(newTotalVal.toFixed(2)),
                  totalGainUSD: Number(newGainUSD.toFixed(2)),
                  totalGainPercent: totalCostBasis > 0 ? (newGainUSD / totalCostBasis) * 100 : 0,
                  lastPurchasedDate: new Date().toISOString().slice(0, 10),
                  marketType: 'fiat',
                  isSpotStock: true,
                  assetCategory: 'spot'
                }
              : p
          );
        } else {
          nextStoredPositions = [
            {
              ticker: activeTradePos.symbol,
              name: activeTradePos.symbol,
              shares: tradeShares,
              avgCostUSD: activeTradePos.avg_entry_price,
              currentPriceUSD: activeTradePos.avg_entry_price,
              totalValueUSD: totalCost,
              totalGainUSD: 0,
              totalGainPercent: 0,
              dailyGainUSD: 0,
              sector: 'Technology & AI',
              dividendYield: '0.50%',
              initialBoughtDate: new Date().toISOString().slice(0, 10),
              lastPurchasedDate: new Date().toISOString().slice(0, 10),
              primaryFundingSourceLabel: 'USD Brokerage Clearing',
              marketType: 'fiat',
              isSpotStock: true,
              assetCategory: 'spot'
            },
            ...storedPositions
          ];
        }
      } else {
        // Sell
        if (existing) {
          const remainingShares = Math.max(0, existing.shares - tradeShares);
          if (remainingShares <= 0.0001) {
            nextStoredPositions = storedPositions.filter(p => p.ticker.toUpperCase() !== activeTradePos.symbol.toUpperCase());
          } else {
            const totalVal = remainingShares * activeTradePos.avg_entry_price;
            const costBasis = remainingShares * existing.avgCostUSD;
            const totalGain = totalVal - costBasis;
            nextStoredPositions = storedPositions.map(p => 
              p.ticker.toUpperCase() === activeTradePos.symbol.toUpperCase()
                ? {
                    ...p,
                    shares: Number(remainingShares.toFixed(4)),
                    totalValueUSD: Number(totalVal.toFixed(2)),
                    totalGainUSD: Number(totalGain.toFixed(2)),
                    totalGainPercent: costBasis > 0 ? (totalGain / costBasis) * 100 : 0,
                    marketType: 'fiat',
                    isSpotStock: true,
                    assetCategory: 'spot'
                  }
                : p
            );
          }
        } else {
          nextStoredPositions = storedPositions;
        }
      }
      saveStoredStockPositions('user_1', nextStoredPositions);
    } else {
      // Options order persistence sync
      const prevOrders = getStoredStockOrders('user_1');
      const targetDerivative = activeTradePos.contractType === 'put' ? 'put_option' : 'call_option';
      if (tradeActionSide === 'buy') {
        const existingIdx = prevOrders.findIndex(o => 
          o.ticker.toUpperCase() === activeTradePos.symbol.toUpperCase() && 
          o.derivativeType === targetDerivative &&
          o.strikePrice === activeTradePos.strikePrice
        );
        let nextOrders: StockOrder[];
        if (existingIdx >= 0) {
          const prev = prevOrders[existingIdx];
          const newQty = prev.shares + tradeShares;
          nextOrders = [...prevOrders];
          nextOrders[existingIdx] = {
            ...prev,
            shares: newQty,
            totalUSD: newQty * prev.price * 100
          };
        } else {
          const newOptionOrder: StockOrder = {
            id: `ord-alpaca-opt-${Date.now()}`,
            ticker: activeTradePos.symbol,
            stockName: `${activeTradePos.symbol} [${activeTradePos.contractType?.toUpperCase()} $${activeTradePos.strikePrice || activeTradePos.avg_entry_price}]`,
            side: 'buy',
            orderType: 'market',
            derivativeType: targetDerivative,
            shares: tradeShares,
            price: activeTradePos.avg_entry_price,
            strikePrice: activeTradePos.strikePrice || (activeTradePos.avg_entry_price * 1.05),
            expiryDate: activeTradePos.expiry || '2026-09-18 @ 16:00 ET',
            totalUSD: totalCost,
            status: 'filled',
            paymentSource: {
              id: 'ps-alpaca-brokerage',
              type: 'wallet_fiat',
              label: 'Alpaca Brokerage Account',
              subtitle: 'USD Clearing',
              balanceUSD: 50000,
              iconType: 'bank'
            },
            timestamp: new Date().toLocaleTimeString(),
            dateIso: new Date().toISOString(),
            tradeSlipId: `SLIP-OPT-${Date.now()}`
          };
          nextOrders = [newOptionOrder, ...prevOrders];
        }
        saveStoredStockOrders('user_1', nextOrders);
      } else {
        // Sell option contracts
        let remainingToSell = tradeShares;
        const nextOrders = prevOrders.map(ord => {
          if (remainingToSell <= 0) return ord;
          if (ord.ticker.toUpperCase() === activeTradePos.symbol.toUpperCase() && ord.derivativeType === targetDerivative) {
            const deduct = Math.min(ord.shares, remainingToSell);
            remainingToSell -= deduct;
            const remainingQty = ord.shares - deduct;
            return {
              ...ord,
              shares: remainingQty,
              totalUSD: remainingQty * ord.price * 100
            };
          }
          return ord;
        }).filter(ord => ord.shares > 0);
        saveStoredStockOrders('user_1', nextOrders);
      }
    }

    // Save order history
    const newOrder: StockOrder = {
      id: `ord-alpaca-${Date.now()}`,
      ticker: activeTradePos.symbol,
      stockName: `${activeTradePos.symbol} [${isOption ? 'Option Contract' : 'Spot Share'}]`,
      side: tradeActionSide,
      orderType: 'market',
      derivativeType: isOption ? (activeTradePos.contractType === 'put' ? 'put_option' : 'call_option') : 'spot',
      shares: tradeShares,
      price: activeTradePos.avg_entry_price,
      totalUSD: totalCost,
      status: 'filled',
      paymentSource: {
        id: 'ps-alpaca-brokerage',
        type: 'wallet_fiat',
        label: 'Alpaca Brokerage Account',
        subtitle: 'USD Clearing',
        balanceUSD: 50000,
        iconType: 'bank'
      },
      timestamp: new Date().toLocaleTimeString(),
      dateIso: new Date().toISOString(),
      tradeSlipId: `SLIP-ALPACA-${Date.now()}`
    };
    const prevOrders = getStoredStockOrders('user_1');
    saveStoredStockOrders('user_1', [newOrder, ...prevOrders]);
    window.dispatchEvent(new CustomEvent('final_finance_stock_positions_updated'));

    setTradeToast(`Successfully executed ${tradeActionSide.toUpperCase()} order for ${tradeShares} ${isOption ? 'contracts' : 'shares'} of ${activeTradePos.symbol} ($${totalCost.toLocaleString()}) via Alpaca routing.`);
    setActiveTradePos(null);
    setTimeout(() => {
      setTradeToast(null);
    }, 5000);
  };

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [accRes, posRes] = await Promise.all([
        fetch('/api/alpaca/account'),
        fetch('/api/alpaca/positions')
      ]);

      const accData = await accRes.json();
      const posData = await posRes.json();

      let fetchedPositions: AlpacaPosition[] = [];
      if (posData.success && Array.isArray(posData.data)) {
        fetchedPositions = posData.data;
      }

      // Load user's spot stocks from local store (e.g. AAPL, NVDA, TSLA, etc.)
      const storedPositions = getStoredStockPositions('user_1', INITIAL_USER_STOCK_POSITIONS);
      const storedIPOs = getStoredIPORequests();
      const storedOrders = getStoredStockOrders('user_1');

      const spotStockPositions: AlpacaPosition[] = storedPositions
        .filter(p => {
          const cat = categorizeStockHolding(p.ticker, null, storedIPOs);
          return p.isSpotStock || p.assetCategory === 'spot' || cat.isSpotStock;
        })
        .filter(p => !fetchedPositions.some(fp => fp.symbol.toUpperCase() === p.ticker.toUpperCase()))
        .map(p => ({
          symbol: p.ticker,
          asset_class: 'us_equity' as const,
          qty: p.shares,
          avg_entry_price: p.avgCostUSD,
          market_value: p.totalValueUSD || (p.shares * p.currentPriceUSD),
          unrealized_pl: p.totalGainUSD || ((p.currentPriceUSD - p.avgCostUSD) * p.shares),
          unrealized_plpc: (p.shares * p.avgCostUSD) > 0 ? (p.totalGainUSD || 0) / (p.shares * p.avgCostUSD) : 0,
          change_today: 0.012
        }));

      // Merge user's chosen option contracts (call & put) from local store
      const optionOrders = storedOrders.filter(o => o.derivativeType === 'call_option' || o.derivativeType === 'put_option');
      const optionPositions: AlpacaPosition[] = optionOrders.map(ord => ({
        symbol: ord.ticker,
        asset_class: 'us_option' as const,
        qty: ord.shares,
        avg_entry_price: ord.price,
        market_value: ord.totalUSD,
        unrealized_pl: ord.premiumUSD ? ord.premiumUSD * 0.05 : 12.50,
        unrealized_plpc: 0.032,
        change_today: 0.015,
        expiry: ord.expiryDate,
        strikePrice: ord.strikePrice,
        contractType: ord.derivativeType === 'call_option' ? 'call' : 'put'
      }));

      const allMerged = [...fetchedPositions, ...spotStockPositions, ...optionPositions];
      MOCK_STABLE_CRYPTO_POSITIONS.forEach(m => {
        if (!allMerged.some(pos => pos.symbol === m.symbol && pos.contractType === m.contractType)) {
          allMerged.push(m);
        }
      });
      setPositions(allMerged);

      if (accData.success && accData.data) {
        setAccount(accData.data);
      } else {
        const totalVal = allMerged.reduce((sum, p) => sum + (p.market_value || 0), 0);
        setAccount({
          cash: 100000.00,
          portfolio_value: 100000.00 + totalVal,
          buying_power: 400000.00,
          status: 'ACTIVE'
        });
      }
    } catch (err) {
      // Fallback if backend is unreachable
      const storedPositions = getStoredStockPositions('user_1', INITIAL_USER_STOCK_POSITIONS);
      const storedIPOs = getStoredIPORequests();
      const storedOrders = getStoredStockOrders('user_1');

      const spotStockPositions: AlpacaPosition[] = storedPositions
        .filter(p => {
          const cat = categorizeStockHolding(p.ticker, null, storedIPOs);
          return p.isSpotStock || p.assetCategory === 'spot' || cat.isSpotStock;
        })
        .map(p => ({
          symbol: p.ticker,
          asset_class: 'us_equity' as const,
          qty: p.shares,
          avg_entry_price: p.avgCostUSD,
          market_value: p.totalValueUSD || (p.shares * p.currentPriceUSD),
          unrealized_pl: p.totalGainUSD || 0,
          unrealized_plpc: (p.shares * p.avgCostUSD) > 0 ? (p.totalGainUSD || 0) / (p.shares * p.avgCostUSD) : 0,
          change_today: 0.012
        }));

      const optionOrders = storedOrders.filter(o => o.derivativeType === 'call_option' || o.derivativeType === 'put_option');
      const optionPositions: AlpacaPosition[] = optionOrders.map(ord => ({
        symbol: ord.ticker,
        asset_class: 'us_option' as const,
        qty: ord.shares,
        avg_entry_price: ord.price,
        market_value: ord.totalUSD,
        unrealized_pl: ord.premiumUSD ? ord.premiumUSD * 0.05 : 12.50,
        unrealized_plpc: 0.032,
        change_today: 0.015,
        expiry: ord.expiryDate,
        strikePrice: ord.strikePrice,
        contractType: ord.derivativeType === 'call_option' ? 'call' : 'put'
      }));

      const allMerged = [...spotStockPositions, ...optionPositions];
      MOCK_STABLE_CRYPTO_POSITIONS.forEach(m => {
        if (!allMerged.some(pos => pos.symbol === m.symbol && pos.contractType === m.contractType)) {
          allMerged.push(m);
        }
      });
      setPositions(allMerged);
      const totalVal = allMerged.reduce((sum, p) => sum + (p.market_value || 0), 0);
      setAccount({
        cash: 100000.00,
        portfolio_value: 100000.00 + totalVal,
        buying_power: 400000.00,
        status: 'ACTIVE'
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    const handlePositionsUpdate = () => {
      fetchData();
    };
    window.addEventListener('final_finance_stock_positions_updated', handlePositionsUpdate);
    return () => window.removeEventListener('final_finance_stock_positions_updated', handlePositionsUpdate);
  }, []);

  const getStockType = (p: AlpacaPosition) => {
    if (p.asset_class === 'crypto' || p.symbol.toUpperCase().includes('BTC') || p.symbol.toUpperCase().includes('ETH') || p.symbol.toUpperCase().includes('SOL')) {
      return 'crypto';
    }
    const s = p.symbol.toUpperCase();
    if (['COIN', 'RIOT', 'MARA', 'MSTR', 'USDC', 'USDT', 'PAXG', 'DAI'].some(symbol => s.includes(symbol))) {
      return 'stable';
    }
    return 'fiat';
  };

  const filteredPositions = useMemo(() => {
    return positions.filter(p => {
      const type = getStockType(p);
      if (type !== stockType) return false;

      if (subTab === 'stocks') {
        if (p.asset_class === 'us_option') {
          // Allow stable/crypto options to also be listed as examples in the general Stocks sub-tab
          if (stockType !== 'stable' && stockType !== 'crypto') return false;
        }
      } else if (subTab === 'call') {
        if (p.asset_class !== 'us_option' || p.contractType !== 'call') return false;
      } else if (subTab === 'put') {
        if (p.asset_class !== 'us_option' || p.contractType !== 'put') return false;
      } else if (subTab === 'favorite' || subTab === 'social') {
        return false;
      }

      const matchesSearch = p.symbol.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesSearch;
    });
  }, [positions, stockType, subTab, searchQuery]);

  const categoryFollowedStocks = useMemo(() => {
    const baseList = (filteredFollowedStocks.length > 0 ? filteredFollowedStocks : stocks.filter(s => watchlist.includes(s.ticker)));
    
    const mockFavorites: StockItem[] = [
      {
        ticker: 'USDC',
        name: 'USD Coin Stable Vault Reserve',
        price: 1.00,
        change: 0.00,
        changePercent: 0.00,
        marketType: 'stable',
        marketCap: 45000000,
        volume: 1200000,
        high: 1.00,
        low: 1.00,
        open: 1.00,
        close: 1.00,
        history: { '1D': [], '1W': [], '1M': [], '1Y': [], '5Y': [] }
      },
      {
        ticker: 'COIN',
        name: 'Coinbase Global, Inc.',
        price: 242.50,
        change: 12.30,
        changePercent: 5.34,
        marketType: 'stable',
        marketCap: 52000000000,
        volume: 8500000,
        high: 245.00,
        low: 232.10,
        open: 235.00,
        close: 242.50,
        history: { '1D': [], '1W': [], '1M': [], '1Y': [], '5Y': [] }
      },
      {
        ticker: 'BTC',
        name: 'Bitcoin Core Reserve Index',
        price: 94800.00,
        change: 5400.00,
        changePercent: 6.20,
        marketType: 'crypto',
        marketCap: 1850000000000,
        volume: 45000000000,
        high: 96000.00,
        low: 89000.00,
        open: 89400.00,
        close: 94800.00,
        history: { '1D': [], '1W': [], '1M': [], '1Y': [], '5Y': [] }
      },
      {
        ticker: 'SOL',
        name: 'Solana High-Throughput Protocol',
        price: 225.00,
        change: 15.02,
        changePercent: 7.15,
        marketType: 'crypto',
        marketCap: 104000000000,
        volume: 3800000000,
        high: 228.50,
        low: 208.20,
        open: 210.00,
        close: 225.00,
        history: { '1D': [], '1W': [], '1M': [], '1Y': [], '5Y': [] }
      }
    ];

    const combined = [...baseList];
    mockFavorites.forEach(m => {
      if (!combined.some(c => c.ticker === m.ticker)) {
        combined.push(m);
      }
    });

    return combined.filter(s => {
      const type = getStockType({ symbol: s.ticker, asset_class: s.marketType === 'crypto' ? 'crypto' : 'us_equity' } as any);
      return type === stockType;
    });
  }, [filteredFollowedStocks, stocks, watchlist, stockType]);

  const stats = useMemo(() => {
    let totalPL = positions.reduce((sum, p) => sum + p.unrealized_pl, 0);
    // Seed with user's requested number if zero for visual work with app
    if (totalPL === 0) totalPL = 2547.25;
    
    const dayChange = positions.reduce((sum, p) => sum + (p.market_value * p.change_today), 0);
    return { totalPL, dayChange };
  }, [positions]);

  // Helper to identify stablecoin related stocks
  const isStablecoinRelated = (symbol: string) => {
    const symbols = ['COIN', 'RIOT', 'MARA', 'MSTR', 'PYPL', 'HOOD', 'SQ', 'USDC', 'USDT', 'DAI', 'PAXG'];
    return symbols.includes(symbol.toUpperCase());
  };

  if (isLoading && !account) {
    return (
      <div className="flex flex-col items-center justify-center py-24 space-y-4">
        <RefreshCw className="w-10 h-10 text-amber-500 animate-spin" />
        <p className="text-slate-500 font-medium animate-pulse">Establishing secure market uplink...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {error && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 sm:p-4 flex items-center justify-between text-xs text-amber-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Alpaca live uplink notice: Using simulated paper execution mode with localized spot portfolio persistence.</span>
          </div>
          <button 
            type="button" 
            onClick={() => setError(null)} 
            className="text-amber-900 font-bold hover:underline ml-2"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Account Overview Cards */}
      {showOnlySummary && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-slate-900 text-white p-4 rounded-2xl shadow-lg relative overflow-hidden"
          >
            <div className="relative z-10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Portfolio Value</span>
                <div className="p-1.5 bg-amber-500 rounded-lg">
                  <TrendingUp className="w-3.5 h-3.5 text-black" />
                </div>
              </div>
              <div className="space-y-0.5">
                <h2 className="text-xl font-bold font-mono">
                  ${account?.portfolio_value.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </h2>
                <div className="flex items-center gap-2">
                  <span className={`text-[11px] font-bold ${stats.totalPL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {stats.totalPL >= 0 ? '+' : ''}${Math.abs(stats.totalPL).toLocaleString(undefined, { minimumFractionDigits: 2 })} Total G/L
                  </span>
                </div>
              </div>
            </div>
            <div className="absolute -right-3 -bottom-3 opacity-5">
              <TrendingUp className="w-20 h-20" />
            </div>
          </motion.div>

          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white border border-slate-200 p-4 rounded-2xl shadow-sm relative overflow-hidden"
          >
            <div className="relative z-10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider text-left">Cash & Liquidity</span>
                <div className="p-1.5 bg-slate-100 rounded-lg">
                  <Wallet className="w-3.5 h-3.5 text-slate-600" />
                </div>
              </div>
              <div className="space-y-0.5 text-left">
                <h2 className="text-xl font-bold font-mono text-slate-900">
                  ${account?.cash.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </h2>
                <span className="text-[10px] font-bold text-slate-400">Available for immediate trade</span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white border border-slate-200 p-4 rounded-2xl shadow-sm relative overflow-hidden"
          >
            <div className="relative z-10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-wider text-left">Buying Power</span>
                <div className="p-1.5 bg-indigo-100 rounded-lg">
                  <Zap className="w-3.5 h-3.5 text-indigo-600" />
                </div>
              </div>
              <div className="space-y-0.5 text-left">
                <h2 className="text-xl font-bold font-mono text-indigo-900">
                  ${account?.buying_power.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </h2>
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Margin & Cash Enabled</span>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {!showOnlySummary && (
        <>
          {/* Asset Filters & Search */}
          <div className="space-y-4">
            {/* Primary Stock Type / Currencies Hub */}
            <div className="flex items-center gap-2 p-1.5 bg-slate-100 rounded-2xl border border-slate-200 overflow-x-auto w-full max-w-full">
              <button 
                onClick={() => { setStockType('fiat'); setSubTab('stocks'); }}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${stockType === 'fiat' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
              >
                <span>💵</span> Fiat Stocks
              </button>
              <button 
                onClick={() => { setStockType('stable'); setSubTab('stocks'); }}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${stockType === 'stable' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
              >
                <span>🛡️</span> Stable Stocks
              </button>
              <button 
                onClick={() => { setStockType('crypto'); setSubTab('stocks'); }}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${stockType === 'crypto' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
              >
                <span>🪙</span> Crypto Stocks
              </button>
              <button 
                onClick={() => setStockType('currencies')}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${stockType === 'currencies' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
              >
                <GlobeIcon className="w-4 h-4" /> Currencies
              </button>
            </div>

            {/* Secondary Sub-Tab Bar & Search (for Fiat, Stable, Crypto) */}
            {stockType !== 'currencies' && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
                <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
                  <button 
                    onClick={() => setSubTab('stocks')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${subTab === 'stocks' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'}`}
                  >
                    Stocks
                  </button>
                  
                  <div className="flex items-center gap-1.5 px-3 py-2 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Options:</span>
                    <button 
                      onClick={() => setSubTab('call')}
                      className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all whitespace-nowrap cursor-pointer ${subTab === 'call' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-white text-emerald-900 border border-emerald-100 hover:bg-emerald-50'}`}
                    >
                      Call
                    </button>
                    <button 
                      onClick={() => setSubTab('put')}
                      className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all whitespace-nowrap cursor-pointer ${subTab === 'put' ? 'bg-rose-600 text-white shadow-sm' : 'bg-white text-rose-900 border border-rose-100 hover:bg-rose-50'}`}
                    >
                      Put
                    </button>
                  </div>
                  
                  <button 
                    onClick={() => setSubTab('favorite')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${subTab === 'favorite' ? 'bg-amber-100 text-amber-900 shadow-sm' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'}`}
                  >
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" /> Favorites
                  </button>
                  <button 
                    onClick={() => setSubTab('social')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${subTab === 'social' ? 'bg-indigo-100 text-indigo-900 shadow-sm' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'}`}
                  >
                    <Users className="w-3.5 h-3.5" /> Social
                  </button>
                </div>

                {subTab === 'stocks' && (
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="text"
                      placeholder={`Search ${stockType} assets...`}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 outline-none transition-all font-mono"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Main Content Area */}
          {stockType === 'currencies' ? (
            <CurrenciesDirectoryAndWalletView 
              currentUser={currentUser || null}
              hideSovereignTools={true}
            />
          ) : subTab === 'social' ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-2xs">
              <SocialTradesFeed 
                stocks={stocks}
                watchlist={watchlist}
                onToggleWatchlist={onToggleWatchlist}
                onSelectStock={onSelectStock}
                viewType="stocks"
                selectedMarketFilter={stockType}
              />
            </div>
          ) : subTab === 'favorite' ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-2xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                  Favorite {stockType.toUpperCase()} Stocks & Assets
                </h3>
                <button 
                  onClick={() => onOpenStockMarket?.('all')}
                  className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Browse Stock Markets
                </button>
              </div>
              {categoryFollowedStocks.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryFollowedStocks.map(stock => {
                    return (
                      <div 
                        key={stock.ticker}
                        onClick={() => onSelectStock?.(stock)}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 hover:border-amber-400 hover:shadow-md transition-all cursor-pointer flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white font-mono font-bold flex items-center justify-center text-xs">
                            {stock.ticker}
                          </div>
                          <div>
                            <div className="font-mono font-bold text-slate-900">${stock.ticker}</div>
                            <div className="text-xs text-slate-500 truncate max-w-[140px]">{stock.name}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono font-bold text-slate-900">${stock.price.toFixed(2)}</div>
                          <div className={`text-xs font-mono font-bold ${stock.changePercent >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-16 text-center text-slate-400 text-xs">
                  No favorite {stockType} assets tracked yet. Star assets from the market exchange to view them here.
                </div>
              )}
            </div>
          ) : (
            /* Positions Grid (Stocks / Options) */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <AnimatePresence mode="popLayout">
                {filteredPositions.map((pos) => (
                  <motion.div
                    layout
                    key={pos.symbol + (pos.contractType || '')}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm hover:shadow-md transition-all group"
                  >
                    <div className="flex items-start justify-between gap-2 mb-4 w-full min-w-0">
                      <div className="flex items-start gap-2.5 min-w-0 flex-1">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
                          pos.asset_class === 'crypto' ? 'bg-indigo-600 text-white' : 
                          pos.asset_class === 'us_option' ? (pos.contractType === 'call' ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white') : 
                          'bg-slate-900 text-white'
                        }`}>
                          {pos.symbol.slice(0, 3)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <h4 className="font-bold text-slate-900 font-mono text-xs break-all leading-normal" title={pos.symbol}>
                              {pos.symbol}
                            </h4>
                            {pos.asset_class === 'us_option' && (
                              <span className={`text-[9px] font-bold px-1 py-0.25 rounded uppercase tracking-tighter shrink-0 ${
                                pos.contractType === 'call' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                              }`}>
                                {pos.contractType || 'option'}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mt-0.5">
                            {pos.asset_class === 'us_option' ? `Option (Strike $${pos.strikePrice || 0})` : `${stockType.toUpperCase()} Asset`}
                          </span>
                          {pos.expiry && (
                            <div className="text-[9px] text-sky-700 font-mono font-bold mt-1 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-100 flex items-center gap-1 w-fit max-w-full">
                              <Clock className="w-2.5 h-2.5 text-sky-600 shrink-0" />
                              <span className="truncate">{formatExpiryPretty(pos.expiry)}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="text-right shrink-0 min-w-[70px]">
                        <div className={`flex items-center justify-end gap-0.5 text-xs font-bold ${pos.unrealized_pl >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {pos.unrealized_pl >= 0 ? <TrendingUp className="w-3 h-3 shrink-0" /> : <TrendingDown className="w-3 h-3 shrink-0" />}
                          {(pos.unrealized_plpc * 100).toFixed(2)}%
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono block">Today: {(pos.change_today * 100).toFixed(2)}%</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 py-4 border-y border-slate-50">
                      <div className="text-left">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Quantity</span>
                        <span className="text-sm font-bold text-slate-900 font-mono">{pos.qty}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Market Value</span>
                        <span className="text-sm font-bold text-slate-900 font-mono">${pos.market_value.toLocaleString()}</span>
                      </div>
                      <div className="text-left">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Avg Price</span>
                        <span className="text-sm font-bold text-slate-900 font-mono">${pos.avg_entry_price.toFixed(2)}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">Profit/Loss</span>
                        <span className={`text-sm font-bold font-mono ${pos.unrealized_pl >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {pos.unrealized_pl >= 0 ? '+' : ''}${pos.unrealized_pl.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <button 
                      onClick={() => handleOpenTradeModal(pos)}
                      className="w-full mt-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                    >
                      Execute Trade <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>

              {filteredPositions.length === 0 && (
                <div className="col-span-full py-20 text-center space-y-4">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto border border-dashed border-slate-200">
                    <Search className="w-8 h-8 text-slate-300" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-lg font-bold text-slate-900">No active {stockType} {subTab === 'call' ? 'Call Options' : subTab === 'put' ? 'Put Options' : subTab} found</h4>
                    <p className="text-sm text-slate-500 max-w-sm mx-auto">
                      You don't have any holdings in this category. Use the trade desk or market view to place orders.
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Interactive Trade Execution Modal */}
      <AnimatePresence>
        {activeTradePos && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 text-left space-y-6"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <span>{activeTradePos.symbol}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-slate-100 font-mono text-slate-600 uppercase">
                      {activeTradePos.contractType || activeTradePos.asset_class}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">Alpaca Institutional Execution Router</p>
                </div>
                <button 
                  onClick={() => setActiveTradePos(null)}
                  className="w-8 h-8 bg-slate-100 hover:bg-slate-200 rounded-full flex items-center justify-center text-slate-600 font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center p-1 bg-slate-100 rounded-2xl">
                  <button 
                    onClick={() => setTradeActionSide('buy')}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${tradeActionSide === 'buy' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
                  >
                    Buy (Long / Open)
                  </button>
                  <button 
                    onClick={() => setTradeActionSide('sell')}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${tradeActionSide === 'sell' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
                  >
                    Sell (Close / Short)
                  </button>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    {activeTradePos.asset_class === 'us_option' ? 'Number of Contracts' : 'Quantity (Shares)'}
                  </label>
                  <input 
                    type="number"
                    min="1"
                    value={tradeShares}
                    onChange={(e) => setTradeShares(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-mono font-bold text-slate-900 outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>{activeTradePos.asset_class === 'us_option' ? 'Option Premium / Share:' : 'Execution Price:'}</span>
                    <span className="font-mono font-bold text-slate-900">${activeTradePos.avg_entry_price.toFixed(2)}</span>
                  </div>
                  {activeTradePos.asset_class === 'us_option' && (
                    <div className="flex justify-between text-slate-600">
                      <span>Contract Multiplier:</span>
                      <span className="font-mono font-bold text-slate-900">100 shares</span>
                    </div>
                  )}
                  {activeTradePos.strikePrice && (
                    <div className="flex justify-between text-slate-600">
                      <span>Strike Price:</span>
                      <span className="font-mono font-bold text-slate-900">${activeTradePos.strikePrice.toFixed(2)}</span>
                    </div>
                  )}
                  {activeTradePos.expiry && (
                    <div className="flex justify-between text-slate-600">
                      <span>Expiration:</span>
                      <span className="font-mono font-bold text-sky-700">{formatExpiryPretty(activeTradePos.expiry)}</span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-sm text-slate-900">
                    <span>Estimated Total:</span>
                    <span className="font-mono text-indigo-600">
                      ${(tradeShares * activeTradePos.avg_entry_price * (activeTradePos.asset_class === 'us_option' ? 100 : 1)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button 
                  onClick={() => setActiveTradePos(null)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-2xl text-xs font-bold transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleConfirmTrade}
                  className={`flex-1 py-3 text-white rounded-2xl text-xs font-bold transition-all shadow-md ${tradeActionSide === 'buy' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'}`}
                >
                  Confirm {tradeActionSide.toUpperCase()} Order
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
