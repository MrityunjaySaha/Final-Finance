import { UserWalletData, LinkedBankAccountItem, LinkedCardItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { StockPaymentSource, StockOrder, StockPosition, StockItem, StockSector } from '../types/stocks';
import { DEFAULT_INITIAL_STOCK_ORDERS } from '../data/stocksData';

// Keys for persistence
const STOCK_POSITIONS_KEY = 'final_finance_stock_positions';
const STOCK_ORDERS_KEY = 'final_finance_stock_orders';
const STOCK_WATCHLIST_KEY = 'final_finance_watchlist';
export const WATCHLIST_UPDATED_EVENT = 'final_finance_watchlist_updated';

export const DEFAULT_WATCHLIST = ['ALEX', 'HYPR', 'AFNL-EQ', 'BSYN', 'VLT-YLD', 'NEXA', 'SOLN', 'ELEN'];

/**
 * Categorizes a stock holding into Personal Equity, Business Equity, or Regular Stock.
 * Equity is STRICTLY reserved for platform-issued Personal and Business IPOs backed by Final Coins (AFNL).
 * All other stocks (e.g. AAPL, NVDA, NEXA, BSYN, VLT-YLD, SOLN, Alpaca assets, etc.) are regular Stocks.
 */
export function categorizeStockHolding(
  ticker: string, 
  stockInfo?: Partial<StockItem> | null, 
  ipos: any[] = []
): {
  isPersonalEquity: boolean;
  isBusinessEquity: boolean;
  isEquity: boolean;
  isSpotStock: boolean;
  assetCategory: 'personal' | 'business' | 'spot';
} {
  const cleanTicker = (ticker || '').toUpperCase().trim();

  // Known platform-issued Personal Sovereign Equity IPOs (backed by Final Coins AFNL)
  const personalFinalTickers = ['ALEX', 'SATOSHI', 'ELEN', 'STERL', 'STRL'];
  
  // Known platform-issued Corporate Business Equity IPOs (backed by Final Coins AFNL)
  const businessFinalTickers = ['HYPR', 'AFNL-EQ'];

  // Check matching IPO if any
  const matchingIpo = ipos.find(i => 
    i.ticker?.toUpperCase() === cleanTicker || 
    i.id === stockInfo?.ipoRefId || 
    i.id === (stockInfo as any)?.ipoId
  );

  // Is backed by Final Coins ($AFNL)?
  const isFinalBacked = 
    personalFinalTickers.includes(cleanTicker) ||
    businessFinalTickers.includes(cleanTicker) ||
    stockInfo?.marketType === 'final' ||
    matchingIpo?.marketWay === 'final' ||
    matchingIpo?.personalDetails?.backingFinalCoinSymbol === 'AFNL' ||
    stockInfo?.issuanceCoinSymbol === 'AFNL' ||
    (stockInfo?.settlementMethod?.toLowerCase().includes('final') ?? false);

  // 1. Personal Equity: Must be personal issuance AND backed by Final Coins
  const isPersonal = 
    isFinalBacked && (
      personalFinalTickers.includes(cleanTicker) ||
      stockInfo?.issuanceType === 'personal' ||
      stockInfo?.assetCategory === 'personal' ||
      matchingIpo?.ipoType === 'personal' ||
      stockInfo?.sector === 'Sovereign Reserves'
    );

  // 2. Business Equity: Must be business issuance AND backed by Final Coins
  const isBusiness = 
    !isPersonal && isFinalBacked && (
      businessFinalTickers.includes(cleanTicker) ||
      stockInfo?.issuanceType === 'business' ||
      stockInfo?.assetCategory === 'business' ||
      matchingIpo?.ipoType === 'business'
    );

  // Equity strictly consists of Personal and Business stocks backed by Final Coins
  const isEquity = isPersonal || isBusiness;
  // Regular stocks (what was spot stock) are all other stocks (Fiat, Stable, Crypto)
  const isSpotStock = !isEquity;

  return {
    isPersonalEquity: isPersonal,
    isBusinessEquity: isBusiness,
    isEquity,
    isSpotStock,
    assetCategory: isPersonal ? 'personal' : (isBusiness ? 'business' : 'spot')
  };
}

/**
 * Loads user stock watchlist / favorites from localStorage.
 */
export function getStoredWatchlist(userId: string = 'guest'): string[] {
  try {
    const saved = localStorage.getItem(`${STOCK_WATCHLIST_KEY}_${userId}`);
    if (saved !== null) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to load watchlist from localStorage', err);
  }
  return DEFAULT_WATCHLIST;
}

/**
 * Saves user stock watchlist / favorites to localStorage and notifies all components.
 */
export function saveStoredWatchlist(userId: string = 'guest', watchlist: string[]): void {
  try {
    localStorage.setItem(`${STOCK_WATCHLIST_KEY}_${userId}`, JSON.stringify(watchlist));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent(WATCHLIST_UPDATED_EVENT, {
          detail: { userId, watchlist },
        })
      );
    }
  } catch (err) {
    console.warn('Failed to save watchlist to localStorage', err);
  }
}

/**
 * Toggles a stock ticker in the user's watchlist / favorites and saves it.
 */
export function toggleStoredWatchlist(userId: string = 'guest', ticker: string): string[] {
  const current = getStoredWatchlist(userId);
  const exists = current.some(t => t.toUpperCase() === ticker.toUpperCase());
  const next = exists
    ? current.filter(t => t.toUpperCase() !== ticker.toUpperCase())
    : [...current, ticker.toUpperCase()];
  saveStoredWatchlist(userId, next);
  return next;
}

/**
 * Universal search matcher for the Stock Market Exchange.
 * Allows searching by:
 * - Stock ticker & name
 * - Personal vs Business stock category ('personal', 'business', 'corporate', 'sovereign')
 * - Issuance / Backing coin symbol (e.g. AFNL, USDC, USD, BTC, SOL, ETH, GOLD, USDT)
 * - Issuance / Backing coin name (e.g. Final Coin, USD Coin, Bitcoin, Sovereign Gold)
 * - Market Way / Settlement Currency (Final Market, Stable Market, Fiat Market, Crypto Market)
 * - Sector, Sub-sector, Description, CEO, Issuer Name, Issuer Handle
 */
export function matchStockSearch(stock: StockItem, rawQuery: string): boolean {
  if (!rawQuery || !rawQuery.trim()) return true;
  
  const query = rawQuery.trim().toLowerCase().replace(/^\$/, '');
  const terms = query.split(/\s+/).filter(Boolean);

  return terms.every((term) => {
    // 1. Direct Ticker & Name
    if (stock.ticker.toLowerCase().includes(term)) return true;
    if (stock.name.toLowerCase().includes(term)) return true;

    // 2. Sector, Sub-sector, Exchange & Description
    if (stock.sector && stock.sector.toLowerCase().includes(term)) return true;
    if (stock.subSector && stock.subSector.toLowerCase().includes(term)) return true;
    if (stock.description && stock.description.toLowerCase().includes(term)) return true;
    if (stock.exchange && stock.exchange.toLowerCase().includes(term)) return true;
    if (stock.ceo && stock.ceo.toLowerCase().includes(term)) return true;

    // 3. Settlement Method
    if (stock.settlementMethod && stock.settlementMethod.toLowerCase().includes(term)) return true;

    // 4. Issuance Coin Symbol & Name (e.g. AFNL, USDC, BTC, USD, GOLD, ALEXCOIN)
    if (stock.issuanceCoinSymbol && stock.issuanceCoinSymbol.toLowerCase().includes(term)) return true;
    if (stock.issuanceCoinName && stock.issuanceCoinName.toLowerCase().includes(term)) return true;
    if (stock.issuanceCoinType && stock.issuanceCoinType.toLowerCase().includes(term)) return true;

    // 5. Issuer Details (for Personal & Business IPOs)
    if (stock.issuerName && stock.issuerName.toLowerCase().includes(term)) return true;
    if (stock.issuerHandle && stock.issuerHandle.toLowerCase().includes(term)) return true;

    // 6. Asset Category & Issuance Type Queries ('personal', 'business', 'sovereign', 'corporate', 'company', 'individual')
    const isPersonal = 
      stock.issuanceType === 'personal' || 
      stock.assetCategory === 'personal' || 
      stock.subSector?.toLowerCase().includes('personal') ||
      stock.sector === 'Sovereign Reserves' ||
      stock.marketType === 'final';

    const isBusiness = 
      stock.issuanceType === 'business' || 
      stock.assetCategory === 'business' ||
      (!isPersonal && stock.sector !== 'Sovereign Reserves');

    if (term === 'personal' || term === 'sovereign' || term === 'individual' || term === 'human') {
      if (isPersonal) return true;
    }

    if (term === 'business' || term === 'corporate' || term === 'corp' || term === 'company' || term === 'enterprise') {
      if (isBusiness) return true;
    }

    // 7. Coin-specific search aliases matching market issuance rules
    // Final Coins ($AFNL, Gold Vaults)
    if (term === 'fnl' || term === 'final') {
      if (stock.marketType === 'final') return true;
      if (stock.issuanceCoinSymbol?.toLowerCase().includes('fnl')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('final')) return true;
    }

    // Stablecoins ($USDC, $USDT, $USD)
    if (term === 'stable' || term === 'stablecoin' || term === 'stablecoins' || term === 'usdc' || term === 'usdt') {
      if (stock.marketType === 'stable') return true;
      if (stock.issuanceCoinSymbol?.toLowerCase().includes('usdc') || stock.issuanceCoinSymbol?.toLowerCase().includes('usdt')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('stable') || stock.settlementMethod?.toLowerCase().includes('usdc')) return true;
    }

    // Fiat Cash ($USD, Fedwire)
    if (term === 'fiat' || term === 'usd' || term === 'dollar' || term === 'dollars' || term === 'cash') {
      if (stock.marketType === 'fiat') return true;
      if (stock.settlementMethod?.toLowerCase().includes('fiat') || stock.settlementMethod?.toLowerCase().includes('usd')) return true;
    }

    // Crypto ($BTC, $ETH, $SOL)
    if (term === 'crypto' || term === 'cryptocurrency' || term === 'btc' || term === 'bitcoin' || term === 'sol' || term === 'eth') {
      if (stock.marketType === 'crypto') return true;
      if (stock.issuanceCoinSymbol?.toLowerCase().includes('btc') || stock.issuanceCoinSymbol?.toLowerCase().includes('sol') || stock.issuanceCoinSymbol?.toLowerCase().includes('eth')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('crypto') || stock.settlementMethod?.toLowerCase().includes('bitcoin')) return true;
    }

    // Gold / Bullion ($GLD, Gold tokens)
    if (term === 'gold' || term === 'bullion' || term === 'xau' || term === 'silver' || term === 'xag') {
      if (stock.ticker.toLowerCase().includes('gld') || stock.ticker.toLowerCase().includes('silv')) return true;
      if (stock.sector === 'Gold & Commodities' || stock.subSector?.toLowerCase().includes('gold')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('gold')) return true;
    }

    // 8. Famous personalities & celebrity investors stock lookup
    // Allows searching "nancy pelosi", "nancy", "pelosi", "jim simons", "warren buffett", "elon musk", etc.
    const famousHoldings: Record<string, string[]> = {
      pelosi: ['NVDA', 'AAPL', 'MSFT', 'BSYN', 'SOLN', 'HYPR', 'TSLA'],
      nancy: ['NVDA', 'AAPL', 'MSFT', 'BSYN', 'SOLN', 'HYPR', 'TSLA'],
      simons: ['TSLA', 'NVDA', 'AAPL', 'VLT-YLD'],
      jim: ['TSLA', 'NVDA', 'AAPL', 'VLT-YLD'],
      buffett: ['AAPL', 'BSYN', 'VLT-YLD'],
      warren: ['AAPL', 'BSYN', 'VLT-YLD'],
      musk: ['TSLA', 'SOLN'],
      elon: ['TSLA', 'SOLN'],
      saylor: ['SOLN', 'QBIT'],
      ackman: ['NVDA', 'AAPL'],
      cathie: ['BSYN', 'TSLA', 'SOLN'],
      wood: ['BSYN', 'TSLA', 'SOLN'],
      dalio: ['HYPR', 'VLT-YLD'],
      satoshi: ['ALEX', 'AFNL-EQ']
    };

    if (famousHoldings[term]?.includes(stock.ticker.toUpperCase())) {
      return true;
    }

    return false;
  });
}

/**
 * Filters a stock collection using the universal search matcher.
 */
export function filterStocksByQuery(stocks: StockItem[], query: string): StockItem[] {
  if (!query || !query.trim()) return stocks;
  return stocks.filter(s => matchStockSearch(s, query));
}

/**
 * Builds standard selectable payment sources from the user's stored wallet data.
 */
export function getAvailableStockPaymentSources(
  userId: string, 
  userHoldings?: { fiat: number; stable_coins: number; final_coins: number; barter: number }
): StockPaymentSource[] {
  const walletData: UserWalletData = getStoredUserWallets(userId);
  const sources: StockPaymentSource[] = [];

  // 1. Linked Bank Accounts (Primary ACH / Instant FedNow)
  walletData.linkedBankAccounts.forEach((bank) => {
    sources.push({
      id: `bank-${bank.id}`,
      type: 'bank_account',
      label: `${bank.bankName} (${bank.accountType})`,
      subtitle: `Account ••••${bank.accountNumberLast4} • ${bank.status}`,
      balanceUSD: bank.balanceUSD,
      iconType: 'bank',
      last4: bank.accountNumberLast4,
      bankName: bank.bankName,
      isDefault: bank.isDefault
    });
  });

  // 2. Linked Debit / Credit Cards
  walletData.linkedCards.forEach((card) => {
    sources.push({
      id: `card-${card.id}`,
      type: 'card',
      label: `${card.bankName || (card.brand.toUpperCase() + ' ' + card.cardType.toUpperCase())}`,
      subtitle: `${card.brand.toUpperCase()} ••••${card.cardNumberLast4} • Exp ${card.expiryMonth}/${card.expiryYear}`,
      balanceUSD: 50000, // Available revolving limit
      iconType: 'card',
      last4: card.cardNumberLast4,
      brand: card.brand,
      isDefault: card.isDefault
    });
  });

  // 3. Linked Web3 Crypto Wallets
  walletData.linkedCryptoWallets?.forEach((crypto) => {
    const addr = crypto.address || '';
    const shortAddr = addr.length > 10 ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : (addr || '0x...');
    sources.push({
      id: `crypto-${crypto.id}`,
      type: 'crypto_wallet',
      label: `${crypto.walletName} (${crypto.network})`,
      subtitle: `${shortAddr} • ${crypto.ensOrDomain || 'Web3 Connected'}`,
      balanceUSD: crypto.balanceUSD,
      iconType: 'crypto',
      walletAddress: crypto.address || '',
      walletName: crypto.walletName,
      network: crypto.network,
      isDefault: crypto.isPrimary
    });
  });

  // 4. User Wallet Fiat USD Cash & Fedwire Treasury
  const fiatUSD = walletData.fiatCurrencies.find(f => f.code === 'USD');
  const fiatBal = userHoldings?.fiat ?? fiatUSD?.balance ?? 200000;
  sources.push({
    id: 'wallet-fiat-usd',
    type: 'wallet_fiat',
    label: 'USD Cash & Treasury Reserve',
    subtitle: 'Primary Fedwire & Clearing Wallet',
    balanceUSD: fiatBal,
    iconType: 'wallet'
  });

  // 4. Stablecoins (USDC Institutional)
  const usdcCoin = walletData.stableCoins.find(s => s.symbol === 'USDC');
  const stableBal = userHoldings?.stable_coins ?? (usdcCoin ? usdcCoin.balance * usdcCoin.unitPriceUSD : 350000);
  sources.push({
    id: 'wallet-stable-usdc',
    type: 'wallet_stable',
    label: 'USD Coin (USDC Clearing)',
    subtitle: 'Institutional Stablecoin Escrow',
    balanceUSD: stableBal,
    iconType: 'crypto'
  });

  // 5. Zurich Gold Bullion & Reserve Vault
  const goldVaultBal = userHoldings?.barter ?? 500000;
  sources.push({
    id: 'wallet-gold-vault',
    type: 'wallet_gold',
    label: 'Zurich Freeport Gold Vault',
    subtitle: 'LBMA Fine Bullion Credit (999.9)',
    balanceUSD: goldVaultBal,
    iconType: 'gold'
  });

  // 6. Final Coin (AFNL) Treasury
  const fnlBal = userHoldings?.final_coins ?? 2840000;
  sources.push({
    id: 'wallet-fnl-treasury',
    type: 'wallet_final',
    label: 'Final Coin (AFNL) Treasury',
    subtitle: 'Protocol Liquidity Collateral',
    balanceUSD: fnlBal,
    iconType: 'crypto'
  });

  return sources;
}

/**
 * Executes a debit/credit on the user's wallet when buying or selling stocks.
 */
export function processStockPayment(
  userId: string,
  source: StockPaymentSource,
  amountUSD: number,
  side: 'buy' | 'sell'
): boolean {
  try {
    const walletData = getStoredUserWallets(userId);

    if (source.type === 'bank_account' && source.last4) {
      const bankIndex = walletData.linkedBankAccounts.findIndex(b => b.accountNumberLast4 === source.last4);
      if (bankIndex !== -1) {
        if (side === 'buy') {
          walletData.linkedBankAccounts[bankIndex].balanceUSD = Math.max(
            0, 
            walletData.linkedBankAccounts[bankIndex].balanceUSD - amountUSD
          );
        } else {
          walletData.linkedBankAccounts[bankIndex].balanceUSD += amountUSD;
        }
        saveStoredUserWallets(userId, walletData);
        return true;
      }
    } else if (source.type === 'wallet_fiat') {
      const fiatIndex = walletData.fiatCurrencies.findIndex(f => f.code === 'USD');
      if (fiatIndex !== -1) {
        if (side === 'buy') {
          walletData.fiatCurrencies[fiatIndex].balance = Math.max(
            0,
            walletData.fiatCurrencies[fiatIndex].balance - amountUSD
          );
        } else {
          walletData.fiatCurrencies[fiatIndex].balance += amountUSD;
        }
        saveStoredUserWallets(userId, walletData);
        return true;
      }
    } else if (source.type === 'crypto_wallet') {
      const cryptoIndex = (walletData.linkedCryptoWallets || []).findIndex(
        c => (source.walletAddress && c.address === source.walletAddress) || c.id === source.id.replace('crypto-', '')
      );
      if (cryptoIndex !== -1 && walletData.linkedCryptoWallets) {
        if (side === 'buy') {
          walletData.linkedCryptoWallets[cryptoIndex].balanceUSD = Math.max(
            0,
            walletData.linkedCryptoWallets[cryptoIndex].balanceUSD - amountUSD
          );
        } else {
          walletData.linkedCryptoWallets[cryptoIndex].balanceUSD += amountUSD;
        }
        saveStoredUserWallets(userId, walletData);
        return true;
      }
    } else if (source.type === 'wallet_stable') {
      const usdcIndex = walletData.stableCoins.findIndex(s => s.symbol === 'USDC');
      if (usdcIndex !== -1) {
        if (side === 'buy') {
          walletData.stableCoins[usdcIndex].balance = Math.max(0, walletData.stableCoins[usdcIndex].balance - amountUSD);
        } else {
          walletData.stableCoins[usdcIndex].balance += amountUSD;
        }
        saveStoredUserWallets(userId, walletData);
        return true;
      }
    }

    // For cards and other vaults, we approve instantly
    return true;
  } catch (err) {
    console.error('Failed to process stock wallet payment:', err);
    return false;
  }
}

/**
 * Loads user stock positions from local storage with fallback to initial positions.
 */
export function getStoredStockPositions(userId: string, initialFallback: StockPosition[]): StockPosition[] {
  try {
    const saved = localStorage.getItem(`${STOCK_POSITIONS_KEY}_${userId}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Normalize positions to guarantee correct categorization and fiat market attribution
        const normalized: StockPosition[] = parsed.map((p: any) => {
          const cat = categorizeStockHolding(p.ticker, p);
          const isFiat = p.ticker === 'AAPL' || p.ticker === 'NVDA' || p.ticker === 'NEXA' || p.marketType === 'global' || p.marketType === 'fiat';
          return {
            ...p,
            marketType: isFiat ? 'fiat' : (p.marketType || 'fiat'),
            assetCategory: cat.assetCategory,
            isEquity: cat.isEquity,
            isSpotStock: cat.isSpotStock,
            isPersonalEquity: cat.isPersonalEquity,
            isBusinessEquity: cat.isBusinessEquity
          };
        });

        // Ensure default stock positions (e.g. AAPL, NVDA) are preserved if missing from older sessions
        const missingDefaults = initialFallback.filter(init => 
          !normalized.some(n => n.ticker.toUpperCase() === init.ticker.toUpperCase())
        );
        return [...normalized, ...missingDefaults];
      }
    }
  } catch (err) {
    console.warn('Failed to load stock positions from localStorage', err);
  }
  return initialFallback;
}

/**
 * Saves user stock positions to local storage.
 */
export function saveStoredStockPositions(userId: string, positions: StockPosition[]): void {
  try {
    localStorage.setItem(`${STOCK_POSITIONS_KEY}_${userId}`, JSON.stringify(positions));
  } catch (err) {
    console.warn('Failed to save stock positions to localStorage', err);
  }
}

/**
 * Loads user stock orders from local storage.
 */
export function getStoredStockOrders(
  userId: string, 
  initialFallback: StockOrder[] = DEFAULT_INITIAL_STOCK_ORDERS
): StockOrder[] {
  try {
    const saved = localStorage.getItem(`${STOCK_ORDERS_KEY}_${userId}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // If parsed doesn't have any derivative orders, supplement with default examples
        const hasDerivatives = parsed.some(o => o.derivativeType && o.derivativeType !== 'spot');
        if (!hasDerivatives) {
          const merged = [...parsed, ...DEFAULT_INITIAL_STOCK_ORDERS];
          return merged;
        }
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to load stock orders from localStorage', err);
  }
  return initialFallback.length > 0 ? initialFallback : DEFAULT_INITIAL_STOCK_ORDERS;
}

/**
 * Saves user stock orders to local storage.
 */
export function saveStoredStockOrders(userId: string, orders: StockOrder[]): void {
  try {
    localStorage.setItem(`${STOCK_ORDERS_KEY}_${userId}`, JSON.stringify(orders));
  } catch (err) {
    console.warn('Failed to save stock orders to localStorage', err);
  }
}

/**
 * Helper to calculate asset allocation breakdown across all stock types bought.
 */
export interface SectorAllocation {
  sector: StockSector;
  totalValueUSD: number;
  percentage: number;
  positionsCount: number;
  totalGainUSD: number;
  totalGainPercent: number;
  color: string;
}

const SECTOR_COLORS: Record<string, string> = {
  'Technology & AI': '#3b82f6', // blue-500
  'Semiconductors': '#8b5cf6', // purple-500
  'Gold & Commodities': '#f59e0b', // amber-500
  'Banking & Finance': '#10b981', // emerald-500
  'Energy & Aerospace': '#ef4444', // red-500
  'ETFs & Indices': '#06b6d4', // cyan-500
  'All': '#64748b'
};

export function calculateSectorAllocations(positions: StockPosition[]): SectorAllocation[] {
  const totalVal = positions.reduce((acc, p) => acc + p.totalValueUSD, 0);
  if (totalVal <= 0) return [];

  const map = new Map<StockSector, { val: number; count: number; gain: number; cost: number }>();

  positions.forEach(p => {
    const current = map.get(p.sector) || { val: 0, count: 0, gain: 0, cost: 0 };
    current.val += p.totalValueUSD;
    current.count += 1;
    current.gain += p.totalGainUSD;
    current.cost += (p.shares * p.avgCostUSD);
    map.set(p.sector, current);
  });

  const result: SectorAllocation[] = [];
  map.forEach((data, sector) => {
    result.push({
      sector,
      totalValueUSD: data.val,
      percentage: Number(((data.val / totalVal) * 100).toFixed(1)),
      positionsCount: data.count,
      totalGainUSD: data.gain,
      totalGainPercent: data.cost > 0 ? Number(((data.gain / data.cost) * 100).toFixed(2)) : 0,
      color: SECTOR_COLORS[sector] || '#64748b'
    });
  });

  // Sort descending by totalValueUSD
  return result.sort((a, b) => b.totalValueUSD - a.totalValueUSD);
}
