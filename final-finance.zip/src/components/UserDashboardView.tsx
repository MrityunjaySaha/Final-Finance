import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldCheck, 
  Coins, 
  Repeat, 
  ArrowRight, 
  TrendingUp, 
  CheckCircle2, 
  Banknote, 
  Binary, 
  Plus, 
  Building2, 
  Package, 
  Wallet, 
  Layers, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CreditCard, 
  AlertTriangle, 
  Receipt, 
  History, 
  DollarSign, 
  TrendingDown, 
  BarChart3, 
  Sparkles, 
  Zap, 
  Check, 
  Compass,
  Briefcase,
  Star,
  ExternalLink,
  SlidersHorizontal,
  Archive,
  PieChart
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AuthSession } from '../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { ReserveVault, AssetClass, VaultAsset } from '../types';
import { UserWalletData, BarterGoodItem, BarterServiceItem } from '../types/wallet';
import { StockItem, StockOrder, StockPosition } from '../types/stocks';
import { INITIAL_STOCKS, INITIAL_USER_STOCK_POSITIONS } from '../data/stocksData';
import { 
  getStoredStockPositions, 
  saveStoredStockPositions, 
  getStoredStockOrders, 
  saveStoredStockOrders 
} from '../utils/stockWalletBridge';
import { WalletsPage } from './WalletsPage';
import { PortfolioPage } from './PortfolioPage';
import { AssetInventoryPage } from './AssetInventoryPage';
import { QuickBuyStockModal } from './stocks/QuickBuyStockModal';
import { TradeConfirmationModal } from './stocks/TradeConfirmationModal';
import { AccountDepositModal } from './dashboard/AccountDepositModal';
import { AccountPayModal } from './dashboard/AccountPayModal';
import { BankWithdrawModal } from './dashboard/BankWithdrawModal';
import { UniversalLedgerView } from './dashboard/UniversalLedgerView';
import { UniversalLedgerItem } from '../types/ledger';
import { 
  getStoredLedgerTransactions, 
  saveStoredLedgerTransactions, 
  recordLedgerTransaction, 
  createLedgerItemFromStockOrder, 
  createLedgerItemFromDeposit, 
  createLedgerItemFromWithdrawal,
  LEDGER_UPDATED_EVENT 
} from '../utils/universalLedgerBridge';

interface UserDashboardViewProps {
  currentUser?: AuthSession | null;
  initialActiveTab?: 'overview' | 'vaults' | 'wallets' | 'portfolio' | 'asset_inventory';
  onOpenNewListing: () => void;
  onOpenInstantSwap?: () => void;
  onOpenBarterModal: (listing?: any) => void;
  onOpenDepositModal: (vault?: any) => void;
  onOpenVoiceCallDesk: () => void;
  onViewPlatformOverview?: () => void;
  onOpenVerificationModal?: () => void;
  onSelectStock?: (stock: StockItem) => void;
  onQuickBuyStock?: (stock: StockItem) => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  currentUser,
  initialActiveTab = 'overview',
  onOpenNewListing,
  onOpenInstantSwap,
  onOpenBarterModal,
  onOpenDepositModal,
  onOpenVoiceCallDesk,
  onViewPlatformOverview,
  onOpenVerificationModal,
  onSelectStock,
  onQuickBuyStock,
}) => {
  const { vaults = [], setCurrentTab, transactions: globalTransactions, setPreviousTab, addNotification } = useApp();
  const userId = currentUser?.id || 'guest';
  
  // Tab within Combined Dashboard: 'overview' | 'portfolio' | 'wallets' | 'fiat' | 'stable' | 'final' | 'crypto' | 'barter'
  const [activeTab, setActiveTab] = useState<'overview' | 'portfolio' | 'wallets' | 'fiat' | 'stable' | 'final' | 'crypto' | 'barter'>(() => {
    if (initialActiveTab === 'portfolio') return 'portfolio';
    if (initialActiveTab === 'wallets') return 'wallets';
    return 'overview';
  });
  const [inventoryTab, setInventoryTab] = useState<any>('overview');

  // Horizontal tabs within Dashboard Overview: 'summary' | 'breakdown' | 'inventory' | 'ledger'
  const [dashboardSectionTab, setDashboardSectionTab] = useState<'summary' | 'breakdown' | 'inventory' | 'ledger'>('summary');

  useEffect(() => {
    if (initialActiveTab === 'portfolio') {
      setActiveTab('portfolio');
    } else if (initialActiveTab === 'wallets') {
      setActiveTab('wallets');
    } else if (initialActiveTab === 'overview') {
      setActiveTab('overview');
    }
  }, [initialActiveTab]);

  // Wallet data state
  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(userId));

  // Stocks & Equities Portfolio state
  const [stocks, setStocks] = useState<StockItem[]>(INITIAL_STOCKS);
  const [positions, setPositions] = useState<StockPosition[]>(() =>
    getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS)
  );
  const [orders, setOrders] = useState<StockOrder[]>(() =>
    getStoredStockOrders(userId)
  );
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_watchlist_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return ['ALEX', 'HYPR', 'AFNL-EQ', 'BSYN', 'VLT-YLD', 'NEXA', 'SOLN', 'ELEN'];
  });

  // Portfolio Subtab filter: 'all' | 'invested' | 'following'
  const [portfolioSubTab, setPortfolioSubTab] = useState<'all' | 'invested' | 'following'>('all');

  // Trade modals state
  const [quickTradeStock, setQuickTradeStock] = useState<StockItem | null>(null);
  const [quickTradeSide, setQuickTradeSide] = useState<'buy' | 'sell'>('buy');
  const [isTradeConfirmationOpen, setIsTradeConfirmationOpen] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<StockOrder | null>(null);

  // Modals
  const [isAccountDepositOpen, setIsAccountDepositOpen] = useState(false);
  const [isAccountPayOpen, setIsAccountPayOpen] = useState(false);
  const [isBankWithdrawOpen, setIsBankWithdrawOpen] = useState(false);

  // Outstanding Debt state (allows dynamic tracking & testing)
  const [outstandingDebt, setOutstandingDebt] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`final_debt_${userId}`);
      if (saved !== null) return parseFloat(saved);
    } catch {
      // fallback
    }
    return 140621.03; // Default liability ($140,621.03)
  });

  const saveDebt = (amount: number) => {
    setOutstandingDebt(amount);
    try {
      localStorage.setItem(`final_debt_${userId}`, amount.toString());
      window.dispatchEvent(new CustomEvent('final_debt_updated', { detail: { debt: amount } }));
    } catch (err) {
      console.warn('Failed to save debt', err);
    }
  };

  // Toast
  const [toastMessage, setToastMessage] = useState('');
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  // Universal Ledger & Tax Receipts State
  const ledgerTransactions = globalTransactions;

  // Sync wallet, stock & ledger changes
  useEffect(() => {
    const refreshData = () => {
      setWalletData(getStoredUserWallets(userId));
      setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
      setOrders(getStoredStockOrders(userId));
    };

    window.addEventListener('final_finance_wallets_updated', refreshData);
    window.addEventListener('final_finance_stock_positions_updated', refreshData);
    window.addEventListener('storage', refreshData);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', refreshData);
      window.removeEventListener('final_finance_stock_positions_updated', refreshData);
      window.removeEventListener('storage', refreshData);
    };
  }, [userId]);

  // Handle Watchlist toggle
  const handleToggleWatchlist = (ticker: string) => {
    setWatchlist((prev) => {
      const next = prev.includes(ticker)
        ? prev.filter((t) => t !== ticker)
        : [...prev, ticker];
      try {
        localStorage.setItem(`final_finance_watchlist_${userId}`, JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Handle opening quick trade modal from portfolio
  const handleOpenTradeModal = (tickerOrStock: string | StockItem, side: 'buy' | 'sell' = 'buy') => {
    let targetStock: StockItem | undefined;
    if (typeof tickerOrStock === 'string') {
      targetStock = stocks.find((s) => s.ticker === tickerOrStock);
      if (!targetStock) {
        // synthesize fallback
        const pos = positions.find((p) => p.ticker === tickerOrStock);
        if (pos) {
          targetStock = {
            ticker: pos.ticker,
            name: pos.name,
            price: pos.currentPriceUSD,
            changeUSD: 2.5,
            changePercent: 1.2,
            high24h: pos.currentPriceUSD * 1.02,
            low24h: pos.currentPriceUSD * 0.98,
            openPrice: pos.currentPriceUSD * 0.99,
            prevClose: pos.currentPriceUSD * 0.988,
            volume: '15.2M',
            avgVolume: '18.0M',
            marketCap: '$1.2T',
            peRatio: 28.5,
            eps: 4.8,
            dividendYield: pos.dividendYield || '0.5%',
            beta: 1.1,
            fiftyTwoWeekHigh: pos.currentPriceUSD * 1.25,
            fiftyTwoWeekLow: pos.currentPriceUSD * 0.75,
            marketType: 'fiat',
            settlementMethod: 'USD Fiat & Reserve Vault Clearing',
            sector: pos.sector,
            subSector: 'Active Equity Holding',
            description: `${pos.name} held position.`,
            exchange: 'NASDAQ',
            analystRating: 'Buy',
            analystTargetUSD: pos.currentPriceUSD * 1.15,
            analystCount: 15,
            sparkline: [pos.avgCostUSD, pos.currentPriceUSD],
            history: { '1D': [], '1W': [], '1M': [], '1Y': [], '5Y': [] }
          };
        }
      }
    } else {
      targetStock = tickerOrStock;
    }

    if (targetStock) {
      setQuickTradeStock(targetStock);
      setQuickTradeSide(side);
    }
  };

  // Handle executing an order
  const handleOrderExecuted = (newOrder: StockOrder) => {
    // 1. Update orders list
    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    saveStoredStockOrders(userId, updatedOrders);

    // 2. Update positions
    let updatedPositions: StockPosition[];
    const existingIndex = positions.findIndex((p) => p.ticker === newOrder.ticker);

    if (newOrder.side === 'buy') {
      if (existingIndex !== -1) {
        const existing = positions[existingIndex];
        const newShares = existing.shares + newOrder.shares;
        const newCostBasis = existing.shares * existing.avgCostUSD + newOrder.totalUSD;
        const newAvgCost = newCostBasis / newShares;
        const newTotalVal = newShares * newOrder.price;
        const newGainUSD = newTotalVal - newCostBasis;
        const newGainPct = newCostBasis > 0 ? (newGainUSD / newCostBasis) * 100 : 0;

        updatedPositions = positions.map((p, idx) =>
          idx === existingIndex
            ? {
                ...p,
                shares: newShares,
                avgCostUSD: Number(newAvgCost.toFixed(2)),
                currentPriceUSD: newOrder.price,
                totalValueUSD: Number(newTotalVal.toFixed(2)),
                totalGainUSD: Number(newGainUSD.toFixed(2)),
                totalGainPercent: Number(newGainPct.toFixed(2)),
                lastPurchasedDate: new Date().toISOString().slice(0, 10),
              }
            : p
        );
      } else {
        const newPos: StockPosition = {
          ticker: newOrder.ticker,
          name: newOrder.stockName,
          shares: newOrder.shares,
          avgCostUSD: newOrder.price,
          currentPriceUSD: newOrder.price,
          totalValueUSD: newOrder.totalUSD,
          totalGainUSD: 0,
          totalGainPercent: 0,
          dailyGainUSD: 0,
          sector: newOrder.sector || 'Technology & AI',
          dividendYield: '0.50%',
          initialBoughtDate: new Date().toISOString().slice(0, 10),
          lastPurchasedDate: new Date().toISOString().slice(0, 10),
          primaryFundingSourceLabel: newOrder.paymentSource?.label || 'Primary Cash Reserve'
        };
        updatedPositions = [newPos, ...positions];
      }
    } else {
      // Sell order
      if (existingIndex !== -1) {
        const existing = positions[existingIndex];
        const remainingShares = Math.max(0, existing.shares - newOrder.shares);
        if (remainingShares === 0) {
          updatedPositions = positions.filter((p) => p.ticker !== newOrder.ticker);
        } else {
          const costBasis = remainingShares * existing.avgCostUSD;
          const totalVal = remainingShares * newOrder.price;
          const gainUSD = totalVal - costBasis;
          const gainPct = costBasis > 0 ? (gainUSD / costBasis) * 100 : 0;

          updatedPositions = positions.map((p, idx) =>
            idx === existingIndex
              ? {
                  ...p,
                  shares: remainingShares,
                  currentPriceUSD: newOrder.price,
                  totalValueUSD: Number(totalVal.toFixed(2)),
                  totalGainUSD: Number(gainUSD.toFixed(2)),
                  totalGainPercent: Number(gainPct.toFixed(2)),
                }
              : p
          );
        }
      } else {
        updatedPositions = positions;
      }
    }

    setPositions(updatedPositions);
    saveStoredStockPositions(userId, updatedPositions);

    // Refresh wallet
    setWalletData(getStoredUserWallets(userId));

    // Record in Universal Ledger
    try {
      const stockInfo = INITIAL_STOCKS.find((s) => s.ticker === newOrder.ticker);
      const ledgerItem = createLedgerItemFromStockOrder(newOrder, stockInfo);
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record stock order to ledger', e);
    }

    // Show Confirmation Receipt Modal
    setConfirmedOrder(newOrder);
    setIsTradeConfirmationOpen(true);
    setQuickTradeStock(null);
    showToast(`Order executed: ${newOrder.side.toUpperCase()} ${newOrder.shares} ${newOrder.ticker} ($${newOrder.totalUSD.toLocaleString()})`);
  };

  // Primary Account Liquid Cash Balance (total fiat cash across all reserve bank accounts)
  const primaryCashBalance = walletData.fiatCurrencies.reduce((s, f) => s + f.balance * f.exchangeRateToUSD, 0);

  // Handle deposit into trading account
  const handleAccountDeposit = (amount: number, sourceLabel: string) => {
    const newBalance = primaryCashBalance + amount;
    const updatedFiat = [...walletData.fiatCurrencies];
    if (updatedFiat.length > 0) {
      updatedFiat[0] = { ...updatedFiat[0], balance: newBalance };
    } else {
      updatedFiat.push({
        id: 'fiat-usd',
        name: 'US Dollar (Reserve Cash)',
        code: 'USD',
        symbol: '$',
        balance: newBalance,
        exchangeRateToUSD: 1.0,
        accountType: 'Checking',
        institution: 'JPMorgan Chase Prime'
      });
    }

    const updatedData: UserWalletData = {
      ...walletData,
      fiatCurrencies: updatedFiat
    };

    setWalletData(updatedData);
    saveStoredUserWallets(userId, updatedData);

    // Record in Universal Ledger
    try {
      const ledgerItem = createLedgerItemFromDeposit(amount, sourceLabel, 'fiat');
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record deposit in ledger', e);
    }

    showToast(`Successfully deposited $${amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} into your account.`);
  };

  // Handle deposit into external bank account (Withdrawal)
  const handleBankDeposit = (amount: number, bankLabel: string, methodType: 'ach' | 'wire' | 'instant') => {
    if (amount > primaryCashBalance) {
      showToast('Insufficient funds to transfer to bank.');
      return;
    }

    const newBalance = primaryCashBalance - amount;
    const updatedFiat = [...walletData.fiatCurrencies];
    if (updatedFiat.length > 0) {
      updatedFiat[0] = { ...updatedFiat[0], balance: newBalance };
    }

    const updatedData: UserWalletData = {
      ...walletData,
      fiatCurrencies: updatedFiat
    };

    setWalletData(updatedData);
    saveStoredUserWallets(userId, updatedData);

    // Record in Universal Ledger
    try {
      const ledgerItem = createLedgerItemFromWithdrawal(amount, bankLabel, methodType);
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record withdrawal in ledger', e);
    }

    showToast(`Successfully deposited $${amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} into ${bankLabel}.`);
  };

  // Handle paying off owed balance
  const handleAccountPayment = (paymentAmount: number, sourceLabel: string) => {
    const newDebt = Math.max(0, outstandingDebt - paymentAmount);
    saveDebt(newDebt);

    if (primaryCashBalance < 0) {
      const newCash = primaryCashBalance + paymentAmount;
      const updatedFiat = [...walletData.fiatCurrencies];
      if (updatedFiat.length > 0) {
        updatedFiat[0] = { ...updatedFiat[0], balance: newCash };
      }
      const updatedData: UserWalletData = { ...walletData, fiatCurrencies: updatedFiat };
      setWalletData(updatedData);
      saveStoredUserWallets(userId, updatedData);
    }

    // Record in Universal Ledger
    try {
      const now = new Date();
      const randomHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      const ledgerItem: UniversalLedgerItem = {
        id: `tx-settle-${Date.now()}`,
        receiptNumber: `REC-${now.getFullYear()}-ST-${Math.floor(100000 + Math.random() * 900000)}`,
        timestamp: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} UTC`,
        dateIso: now.toISOString(),
        type: 'payment_settlement',
        category: 'money_outflow',
        mode: 'fiat',
        title: 'Settlement & Debt Obligation Payment',
        description: `Settled outstanding debt liability against account vault using ${sourceLabel}`,
        amountUSD: paymentAmount,
        feeUSD: 0.00,
        netAmountUSD: paymentAmount,
        sourceOrDestination: sourceLabel,
        counterpartyOrIssuer: 'Sovereign Clearing Node Corp',
        status: 'Audited',
        taxYear: now.getFullYear(),
        taxClassification: {
          taxableEvent: false,
          taxableAmountUSD: 0,
          formMapping: 'Non-Taxable Transfer',
          holdingPeriod: 'N/A',
          irsCategoryNote: 'Repayment of principal obligation and settlement liabilities. Not taxable income.'
        },
        cryptographicHash: `0x${randomHex}`,
        clearingNode: 'Node #4810-CH',
        signature: `SIG_${Math.floor(100000 + Math.random() * 900000)}_ECDSA`
      };
      recordLedgerTransaction(userId, ledgerItem);
      addNotification({
        title: 'Debt Settled',
        description: `Successfully settled $${paymentAmount.toLocaleString()} against your account deficit using ${sourceLabel}.`,
        type: 'vault',
        targetTab: 'dashboard',
      });
    } catch (e) {
      console.warn('Failed to record payment in ledger', e);
    }

    showToast(`Payment of $${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} authorized. Debt successfully settled!`);
  };

  // Test Toggles for Debt simulation
  const handleSimulateDebt = (targetOwed: number = 1450) => {
    saveDebt(targetOwed);
    showToast(`Account updated: Outstanding debt set to $${targetOwed.toLocaleString()} for testing payment flow.`);
  };

  const handleClearDebt = () => {
    saveDebt(0);
    showToast('Outstanding debt cleared. Account is in 100% good standing.');
  };

  // Portfolio aggregates (excluding non-priced barter goods/services, and non-convertible Final Coins)
  const finalCoinsVal = 0; // Treated as pure unit quantities, no dollar equivalence
  const stableCoinsVal = walletData.stableCoins.reduce((s, st) => s + st.balance * st.unitPriceUSD, 0);
  const fiatVal = walletData.fiatCurrencies.reduce((s, f) => s + f.balance * f.exchangeRateToUSD, 0);
  const cryptoVal = walletData.cryptoCurrencies.reduce((s, cr) => s + cr.balance * cr.unitPriceUSD, 0);
  const stocksVal = positions.reduce((s, p) => {
    const stk = stocks.find(st => st.ticker === p.ticker);
    return s + p.shares * (stk ? stk.price : p.avgCostUSD);
  }, 0);

  const barterGoodsVal = (walletData.barterGoods || []).reduce((s, g) => s + (g.quantity * (g.estimatedUnitValue || 0)), 0);
  const totalPortfolioUSD = stableCoinsVal + fiatVal + cryptoVal + stocksVal + barterGoodsVal;

  const totalBarterGoodsCount = walletData.barterGoods.reduce((sum, g) => sum + g.quantity, 0);
  const totalBarterServicesCount = walletData.barterServices.length;

  const afnlItem = walletData.finalCoins.find(c => c.symbol === 'AFNL') || { balance: 0 };
  const afnlBalance = afnlItem.balance;

  const otherFinalCoins = walletData.finalCoins.filter(c => c.symbol !== 'AFNL');
  const totalOtherFinalCoinsBalance = otherFinalCoins.reduce((s, c) => s + c.balance, 0);

  const totalStableCoinsBalance = walletData.stableCoins.reduce((s, st) => s + st.balance, 0);

  const fiatRawTotal = walletData.fiatCurrencies.reduce((s, f) => s + f.balance * f.exchangeRateToUSD, 0);
  const fiatNetUSD = fiatRawTotal - (outstandingDebt > 0 ? outstandingDebt : 0);

  const cryptoNetUSD = walletData.cryptoCurrencies.reduce((s, cr) => s + cr.balance * cr.unitPriceUSD, 0);
  const cryptoTotalAmount = walletData.cryptoCurrencies.reduce((s, cr) => s + cr.balance, 0);

  // Realized Earnings Breakdown (excluding non-priced barter and non-convertible Final Coins)
  const stocksEarned = 18450.00;
  const stableCoinsInterestEarned = 12460.00;
  const cryptoGainsEarned = 13166.00;
  const fiatBusinessEarned = 1840.00;

  // Total Realized Cash Revenue (excluding barter which has no price tag, and Final Coins which are non-convertible)
  const totalMoneyMade = stocksEarned + stableCoinsInterestEarned + cryptoGainsEarned + fiatBusinessEarned;

  // Earnings by Transactional Medium
  const earningsByMedium = [
    {
      id: 'crypto',
      title: 'Crypto-Currency Gains',
      icon: <Binary className="w-4 h-4 text-purple-600" />,
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
      displayValue: `+$${cryptoGainsEarned.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: '+8.6% trading return',
      description: 'Realized profits on closed digital asset trades & liquidity pool fees',
    },
    {
      id: 'fiat',
      title: 'Fiat Treasury Interest',
      icon: <DollarSign className="w-4 h-4 text-sky-600" />,
      badgeColor: 'bg-sky-50 text-sky-700 border-sky-200',
      displayValue: `+$${fiatBusinessEarned.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: 'Business account APY',
      description: 'Interest bearing checking and commercial money market account yields',
    },
    {
      id: 'barter',
      title: 'Barter Exchanges',
      icon: <Package className="w-4 h-4 text-amber-600" />,
      badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
      displayValue: `${totalBarterGoodsCount} Goods, ${totalBarterServicesCount} Services`,
      growth: 'Non-Priced Trades',
      description: 'Direct goods-for-goods and service retainer contracts completed without price tags',
    },
    {
      id: 'stablecoins',
      title: 'Stable Coins Yield',
      icon: <ShieldCheck className="w-4 h-4 text-emerald-600" />,
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      displayValue: `+$${stableCoinsInterestEarned.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: '5.4% APY average',
      description: 'High-yield custody interest distributed on USDC/EURC stablecoins reserves',
    },
    {
      id: 'stocks',
      title: 'Stock Market & Equities',
      icon: <BarChart3 className="w-4 h-4 text-indigo-600" />,
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      displayValue: `+$${stocksEarned.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: '+14.2% return',
      description: 'Realized capital gains, dividends & equity market trades',
    },
    {
      id: 'final_coins',
      title: 'Final Coins',
      icon: <Coins className="w-4 h-4 text-amber-600" />,
      badgeColor: 'bg-amber-50 text-amber-900 border-amber-200',
      displayValue: '+9,640 AFNL',
      growth: 'Unit Growth',
      description: 'Protocol-level non-convertible unit growth accrued directly inside your sovereign vault',
    }
  ];

  // Effective debt calculation (either positive debt or negative cash balance)
  const totalAmountOwed = outstandingDebt > 0 
    ? outstandingDebt 
    : (primaryCashBalance < 0 ? Math.abs(primaryCashBalance) : 0);

  const isOwed = totalAmountOwed > 0;

  // If activeTab is 'portfolio', cleanly render the dedicated PortfolioPage without dashboard header
  if (activeTab === 'portfolio') {
    return (
      <div className="pb-20 text-left">
        <PortfolioPage
          currentUser={currentUser}
          onSelectStock={onSelectStock}
          onOpenStockMarket={() => setCurrentTab('stocks')}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 text-left">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-semibold shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Modal 1: Deposit funds into platform account */}
      <AccountDepositModal
        isOpen={isAccountDepositOpen}
        onClose={() => setIsAccountDepositOpen(false)}
        currentBalance={primaryCashBalance}
        walletData={walletData}
        onConfirmDeposit={handleAccountDeposit}
      />

      {/* Modal 2: Deposit money into external bank (Withdrawal) */}
      <BankWithdrawModal
        isOpen={isBankWithdrawOpen}
        onClose={() => setIsBankWithdrawOpen(false)}
        availableBalance={primaryCashBalance}
        walletData={walletData}
        onConfirmBankDeposit={handleBankDeposit}
      />

      {/* Modal 3: Pay what you owe */}
      <AccountPayModal
        isOpen={isAccountPayOpen}
        onClose={() => setIsAccountPayOpen(false)}
        negativeBalance={-totalAmountOwed}
        walletData={walletData}
        onConfirmPayment={handleAccountPayment}
      />

      {/* ================= HEADER BANNER ================= */}
      <div className="border border-slate-200 bg-white rounded-3xl p-6 sm:p-8 shadow-xs text-center">
        <div className="flex flex-col items-center justify-center text-center gap-2 pb-5 border-b border-slate-100">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              <h1 className="font-serif text-3xl font-bold text-slate-900 tracking-tight text-center">
                {currentUser?.name || 'Trader Account'}
              </h1>
              <span className="inline-flex items-center gap-1.5 text-xs font-mono font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Verified
              </span>
            </div>
            <p className="text-xs text-slate-500 font-mono mt-0.5 text-center">ID: {userId}</p>
          </div>
          {!isOwed && (
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleSimulateDebt(1450)}
                className="text-xs font-mono font-semibold text-rose-700 hover:text-rose-800 px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-colors cursor-pointer"
                title="Test debt view & payment flow"
              >
                Simulate $1,450 Owed
              </button>
            </div>
          )}
        </div>

        {/* ================= HORIZONTAL SECTION TABS ================= */}
        <div className="pt-2 border-t border-slate-200/80">
          <div className="flex items-center justify-center">
            <div className="inline-flex p-1.5 rounded-2xl bg-slate-100/90 border border-slate-200 shadow-inner max-w-full overflow-x-auto gap-1">
              <button
                type="button"
                id="dashboard-tab-summary"
                onClick={() => setDashboardSectionTab('summary')}
                className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  dashboardSectionTab === 'summary'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
              >
                <Layers className={`w-4 h-4 ${dashboardSectionTab === 'summary' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>Financial Position</span>
                {isOwed && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                )}
              </button>

              <button
                type="button"
                id="dashboard-tab-breakdown"
                onClick={() => setDashboardSectionTab('breakdown')}
                className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  dashboardSectionTab === 'breakdown'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
              >
                <PieChart className={`w-4 h-4 ${dashboardSectionTab === 'breakdown' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>Capital Breakdown</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 font-bold border border-emerald-200/60 hidden sm:inline-block">
                  6 Assets
                </span>
              </button>

              <button
                type="button"
                id="dashboard-tab-inventory"
                onClick={() => setDashboardSectionTab('inventory')}
                className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  dashboardSectionTab === 'inventory'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
              >
                <Archive className={`w-4 h-4 ${dashboardSectionTab === 'inventory' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>Asset Inventory</span>
              </button>

              <button
                type="button"
                id="dashboard-tab-ledger"
                onClick={() => setDashboardSectionTab('ledger')}
                className={`flex items-center gap-2 px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  dashboardSectionTab === 'ledger'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
              >
                <Receipt className={`w-4 h-4 ${dashboardSectionTab === 'ledger' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>Ledger & Receipts</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-slate-200 text-slate-700 font-bold">
                  {ledgerTransactions.length}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================= VIEW A: OVERVIEW TABS ================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Tab 1: Financial Position & Vault Summary */}
          {dashboardSectionTab === 'summary' && (
            <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-200">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <h2 className="font-serif text-xl font-bold text-slate-900">
                    Unified Financial Position & Vault Summary
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Real-time consolidated balance sheet, multi-asset treasury capital, and liabilities
                  </p>
                </div>
                <span className="inline-flex items-center gap-1.5 text-[11px] font-mono font-bold px-3 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                  <Layers className="w-3.5 h-3.5 text-indigo-600" /> Multi-Asset Treasury
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Metric 1: Total Vault Capital */}
                <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2 flex flex-col justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Total Vault Capital
                    </span>
                    <p className="text-3xl font-bold font-mono text-slate-900 leading-none">
                      ${totalPortfolioUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-slate-500 pt-1">
                      Valuation of priced securities, stablecoins, cash & crypto assets
                    </p>
                  </div>
                  <div className="pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Asset Classes:</span>
                    <span className="font-mono font-bold text-indigo-600">Equities, Fiat, Crypto, Goods</span>
                  </div>
                </div>

                {/* Metric 2: Available Cash Balance */}
                <div className="p-5 rounded-2xl bg-indigo-50/40 border border-indigo-100 space-y-3 flex flex-col justify-between text-center">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider block">
                      Available Cash Balance
                    </span>
                    <p className="text-3xl font-bold font-mono text-indigo-700 leading-none">
                      ${primaryCashBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-slate-500 pt-1">
                      Liquid cash on hand for immediate execution
                    </p>
                  </div>
                  <div className="flex items-center justify-center gap-2 pt-2 border-t border-indigo-100/60">
                    <button
                      type="button"
                      id="dashboard-cash-deposit"
                      onClick={() => setIsAccountDepositOpen(true)}
                      className="px-4 py-1.5 text-xs font-bold text-indigo-600 bg-white hover:bg-indigo-50 border border-indigo-200 rounded-xl transition-all cursor-pointer shadow-2xs"
                    >
                      Deposit Cash
                    </button>
                    <button
                      type="button"
                      id="dashboard-cash-out"
                      onClick={() => setIsBankWithdrawOpen(true)}
                      className="px-4 py-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-all cursor-pointer shadow-2xs"
                    >
                      Cash Out
                    </button>
                  </div>
                </div>

                {/* Metric 3: How Much You Owe */}
                <div className={`p-5 rounded-2xl border space-y-3 flex flex-col justify-between transition-colors ${
                  isOwed ? 'bg-rose-50 border-rose-100' : 'bg-emerald-50 border-emerald-100'
                }`}>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        How Much You Owe
                      </span>
                    </div>
                    <p className={`text-4xl font-bold font-mono leading-none ${isOwed ? 'text-rose-600' : 'text-emerald-600'}`}>
                      ${totalAmountOwed.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>

                  <div className="pt-2">
                    {isOwed ? (
                      <button
                        type="button"
                        id="dashboard-pay-off-debt"
                        onClick={() => setIsAccountPayOpen(true)}
                        className="w-full py-2.5 px-4 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-sm font-bold transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                      >
                        <CreditCard className="w-4 h-4" />
                        <span>Pay Off Debt</span>
                      </button>
                    ) : (
                      <div className="text-center p-2 bg-white rounded-xl border border-emerald-100">
                        <p className="text-xs text-emerald-700 font-bold">
                          Account in Good Standing
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Capital Breakdown */}
          {dashboardSectionTab === 'breakdown' && (
            <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-5 animate-in fade-in slide-in-from-bottom-2 duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
                <div>
                  <h2 className="font-serif text-xl font-bold text-slate-900">
                    Vault Capital Breakdown
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Live balance and profit performance categorized across 6 asset mediums
                  </p>
                </div>

                <div className="font-mono text-center">
                  <span className="text-[11px] text-slate-400 block uppercase font-medium">Total Realized Revenue</span>
                  <span className="text-lg font-bold text-emerald-700">
                    +${totalMoneyMade.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {earningsByMedium.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl bg-white border border-slate-100 shadow-sm hover:border-slate-200 hover:shadow-md transition-all flex flex-col justify-between space-y-2 h-full"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-xl bg-slate-50 border border-slate-100 shadow-inner">
                            {item.icon}
                          </div>
                          <span className="font-bold text-xs text-slate-800">{item.title}</span>
                        </div>
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full border ${item.badgeColor}`}>
                          {item.growth}
                        </span>
                      </div>

                      <div className="pt-1.5">
                        {item.id === 'barter' ? (
                          <div className="space-y-0.5">
                            <p className="font-bold font-mono text-amber-900 text-sm">
                              Goods: {totalBarterGoodsCount}
                            </p>
                            <p className="font-bold font-mono text-amber-900 text-sm">
                              Services: {totalBarterServicesCount}
                            </p>
                          </div>
                        ) : (
                          <p className={`font-bold font-mono ${item.displayValue.startsWith('-') ? 'text-rose-700 text-base' : 'text-slate-950 text-base'}`}>
                            {item.displayValue}
                          </p>
                        )}
                        <p className="text-[11px] text-slate-500 mt-0.5 leading-tight">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Asset Inventory */}
          {dashboardSectionTab === 'inventory' && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-200">
              <AssetInventoryPage
                currentUser={currentUser!}
                onNavigateBack={() => setDashboardSectionTab('summary')}
              />
            </div>
          )}

          {/* Tab 4: Universal Comprehensive Ledger & Tax Receipts */}
          {dashboardSectionTab === 'ledger' && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-200">
              <UniversalLedgerView 
                transactions={ledgerTransactions} 
                userId={userId} 
              />
            </div>
          )}
        </div>
      )}

      {/* ================= VIEW B: DETAILED WALLETS & INVENTORY ================= */}
      {activeTab === 'wallets' && (
        <div className="space-y-6">
          <WalletsPage
            currentUser={currentUser}
            onNavigateBack={() => setActiveTab('overview')}
            onInitiateBarterProposal={(item) => onOpenBarterModal(item)}
            onDepositVaultModal={(v) => onOpenDepositModal(v)}
          />
        </div>
      )}

      {activeTab !== 'overview' && (
        <div className="space-y-6">
          <AssetInventoryPage
            currentUser={currentUser!}
            onNavigateBack={() => setActiveTab('overview')}
            initialTab={(activeTab === 'wallets' ? 'overview' : activeTab) as any}
          />
        </div>
      )}

      {/* ================= TRADE MODALS ================= */}
      {quickTradeStock && (
        <QuickBuyStockModal
          isOpen={Boolean(quickTradeStock)}
          onClose={() => setQuickTradeStock(null)}
          stock={quickTradeStock}
          currentUser={currentUser}
          initialSide={quickTradeSide}
          positions={positions}
          onOpenAuthModal={() => {}} // Not needed in dashboard context usually
          onExecuteBuy={handleOrderExecuted}
        />
      )}

      {confirmedOrder && (
        <TradeConfirmationModal
          onClose={() => {
            setIsTradeConfirmationOpen(false);
            setConfirmedOrder(null);
          }}
          order={confirmedOrder}
          onViewPortfolio={() => {
            setConfirmedOrder(null);
            // Navigate or refresh
          }}
        />
      )}
    </div>
  );
};
