import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  ArrowDownUp, 
  Sparkles, 
  Coins, 
  ShieldCheck, 
  Check, 
  AlertCircle,
  TrendingUp,
  Zap,
  Layers
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from './common/ConfirmModal';
import { recordLedgerTransaction, createLedgerItemFromVaultSwap } from '../utils/universalLedgerBridge';

interface InstantSwapModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AuthSession | null;
}

const ASSET_RATES: Record<string, { name: string; rateUSD: number; icon: string }> = {
  USDC: { name: 'USD Coin (USDC)', rateUSD: 1.00, icon: '💵' },
  USD: { name: 'United States Dollar (USD)', rateUSD: 1.00, icon: '🏛️' },
  EUR: { name: 'Euro (EUR)', rateUSD: 1.08, icon: '💶' },
  CHF: { name: 'Swiss Franc (CHF)', rateUSD: 1.13, icon: '🇨🇭' },
  BTC: { name: 'Bitcoin (BTC)', rateUSD: 68420.00, icon: '₿' },
  ETH: { name: 'Ethereum (ETH)', rateUSD: 3540.00, icon: 'Ξ' },
  GOLD_OZ: { name: 'Fine Gold (1 Troy Oz)', rateUSD: 2450.00, icon: '🥇' },
};

export const InstantSwapModal: React.FC<InstantSwapModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const { addToast, addNotification } = useApp();
  const [fromAsset, setFromAsset] = useState<string>('USDC');
  const [toAsset, setToAsset] = useState<string>('USD');
  const [fromAmount, setFromAmount] = useState<number>(500);
  const [isSwapping, setIsSwapping] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  if (!isOpen) return null;

  const fromRate = ASSET_RATES[fromAsset]?.rateUSD || 1;
  const toRate = ASSET_RATES[toAsset]?.rateUSD || 1;
  
  const estimatedReceive = ((fromAmount * fromRate) / toRate).toFixed(
    toAsset === 'BTC' || toAsset === 'ETH' || toAsset === 'GOLD_OZ' ? 4 : 2
  );

  const handleInvert = () => {
    setFromAsset(toAsset);
    setToAsset(fromAsset);
  };

  const handleExecuteSwap = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSwapping(true);
    setShowConfirm(false);

    setTimeout(() => {
      setIsSwapping(false);
      setIsSuccess(true);

      const swapValueUSD = fromAmount * fromRate;
      let mode: 'stable_coin' | 'fiat' | 'crypto' | 'gold_bullion' | 'final_coin' = 'stable_coin';
      if (fromAsset === 'USD' || fromAsset === 'EUR' || fromAsset === 'CHF' || toAsset === 'USD' || toAsset === 'EUR' || toAsset === 'CHF') {
        mode = 'fiat';
      } else if (fromAsset === 'GOLD_OZ' || toAsset === 'GOLD_OZ') {
        mode = 'gold_bullion';
      } else if (fromAsset === 'BTC' || fromAsset === 'ETH' || toAsset === 'BTC' || toAsset === 'ETH') {
        mode = 'crypto';
      }

      const ledgerItem = createLedgerItemFromVaultSwap({
        fromAsset,
        toAsset,
        fromAmount,
        toAmount: Number(estimatedReceive),
        amountUSD: swapValueUSD,
        mode
      });
      recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

      addToast({
        title: 'Instant Multi-Asset Swap Settled',
        message: `Swapped ${fromAmount} ${fromAsset} for ${estimatedReceive} ${toAsset} via Final Liquidity Engine.`,
        type: 'success',
      });
      addNotification({
        title: `⚡ Multi-Vault Swap Executed: ${fromAsset} → ${toAsset}`,
        description: `Exchanged ${fromAmount} ${fromAsset} for ${estimatedReceive} ${toAsset} at institutional zero-slippage rates.`,
        type: 'vault',
        targetTab: 'vaults',
        amount: fromAmount * fromRate,
        currency: 'USD',
      });
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
      }, 1400);
    }, 1000);
  };

  return (
    <div
      id="instant-swap-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="w-full max-w-md bg-neutral-900 border border-neutral-700/80 rounded-2xl p-5 sm:p-6 shadow-2xl text-left text-neutral-100 my-auto flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-300">
              <ArrowDownUp className="h-4 w-4" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-white tracking-wide">
                Instant Multi-Vault Swapper
              </h2>
              <p className="text-xs text-neutral-400">
                Zero-slippage cross-asset sovereign liquidity
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Swap Form */}
        <form onSubmit={handleExecuteSwap} className="mt-4 space-y-4">
          {/* FROM CONTAINER */}
          <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-1.5">
            <div className="flex justify-between items-center text-xs text-neutral-400">
              <span>You Pay</span>
              <span>Rate: ${fromRate.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0.001"
                step="any"
                value={fromAmount}
                onChange={(e) => setFromAmount(Number(e.target.value))}
                className="w-full bg-transparent text-xl font-mono font-bold text-white focus:outline-none"
              />
              <select
                value={fromAsset}
                onChange={(e) => setFromAsset(e.target.value)}
                className="bg-neutral-800 border border-neutral-700 text-xs font-bold text-amber-300 rounded-xl px-2.5 py-1.5 focus:outline-none"
              >
                {Object.entries(ASSET_RATES).map(([key, info]) => (
                  <option key={key} value={key}>
                    {info.icon} {key}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* INVERT ARROW */}
          <div className="flex justify-center -my-2 relative z-10">
            <button
              type="button"
              onClick={handleInvert}
              className="p-2 rounded-full bg-neutral-800 border border-neutral-700 text-amber-400 hover:text-amber-300 hover:bg-neutral-700 transition-all shadow-md active:scale-95"
            >
              <ArrowDownUp className="h-4 w-4" />
            </button>
          </div>

          {/* TO CONTAINER */}
          <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-1.5">
            <div className="flex justify-between items-center text-xs text-neutral-400">
              <span>You Receive (Estimated)</span>
              <span>Rate: ${toRate.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={estimatedReceive}
                className="w-full bg-transparent text-xl font-mono font-bold text-emerald-400 focus:outline-none"
              />
              <select
                value={toAsset}
                onChange={(e) => setToAsset(e.target.value)}
                className="bg-neutral-800 border border-neutral-700 text-xs font-bold text-amber-300 rounded-xl px-2.5 py-1.5 focus:outline-none"
              >
                {Object.entries(ASSET_RATES).map(([key, info]) => (
                  <option key={key} value={key}>
                    {info.icon} {key}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Route Info */}
          <div className="p-2.5 rounded-xl bg-neutral-950/40 border border-neutral-800/80 text-[11px] space-y-1.5 text-neutral-400">
            <div className="flex justify-between">
              <span>Settlement Route</span>
              <span className="text-neutral-200">Final Protocol Automated Market Maker (AMM)</span>
            </div>
            <div className="flex justify-between">
              <span>Network Protocol Fee</span>
              <span className="text-emerald-400">0.00% (Sovereign Tier Discount)</span>
            </div>
            <div className="flex justify-between">
              <span>Execution Speed</span>
              <span className="text-amber-300">Instant Finality</span>
            </div>
            <div className="border-t border-neutral-800/60 pt-1.5 mt-1.5 text-[10px] text-amber-500 leading-normal">
              ⚠️ <strong>Final Coins Protocol Notice</strong>: Final Coins (AFNL) represent permanent sovereign utility assets and are absolutely non-convertible to any other asset classes (including other Final Coins).
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="button"
            onClick={() => setShowConfirm(true)}
            disabled={isSwapping || isSuccess || fromAmount <= 0}
            className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              isSuccess
                ? 'bg-emerald-500 text-black'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 text-black hover:opacity-95 shadow-lg shadow-amber-500/20'
            }`}
          >
            {isSuccess ? (
              <>
                <Check className="h-4 w-4" />
                <span>Swap Settled Successfully</span>
              </>
            ) : isSwapping ? (
              <>
                <div className="h-4 w-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Executing Multi-Vault Settlement...</span>
              </>
            ) : (
              <>
                <Zap className="h-4 w-4" />
                <span>Execute Instant Swap</span>
              </>
            )}
          </button>
        </form>

        <ConfirmModal
          isOpen={showConfirm}
          onClose={() => setShowConfirm(false)}
          onConfirm={handleExecuteSwap}
          title="Confirm Instant Swap"
          message={`Are you sure you want to swap ${fromAmount} ${fromAsset} for approximately ${estimatedReceive} ${toAsset}? This action will execute instantly on the Final Protocol AMM.`}
          confirmText="Confirm Swap"
          type="warning"
        />
      </motion.div>
    </div>
  );
};
