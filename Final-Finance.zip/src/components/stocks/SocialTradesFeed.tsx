import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Sparkles,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  Star,
  Clock,
  Copy,
  Check,
  Eye,
  ChevronRight,
  User,
  Building,
  Search,
  X,
  ArrowLeft,
  Share2,
} from 'lucide-react';
import { StockItem, SocialStockTrade, StockMarketWay } from '../../types/stocks';
import {
  INITIAL_SOCIAL_TRADES,
  FRIENDS_AND_MUTUALS,
  FriendProfile,
  getStoredSharedSocialTrades,
  removeSharedSocialTrade,
  SHARED_SOCIAL_TRADES_EVENT,
} from '../../data/socialTradesData';

interface SocialTradesFeedProps {
  stocks: StockItem[];
  watchlist: string[];
  selectedMarketFilter?: StockMarketWay | null;
  onSelectStock?: (stock: StockItem) => void;
  onQuickTrade?: (stock: StockItem, side?: 'buy' | 'sell') => void;
  onToggleWatchlist?: (ticker: string) => void;
  viewType?: 'stocks' | 'equity';
  tickerFilter?: string;
  recentShareNotice?: string | null;
  onDismissShareNotice?: () => void;
}

const PERSONAL_TICKERS = new Set([
  'ALEX',
  'ELEN',
  'STERL',
  'STRL',
  'SATOSHI',
  'VANC',
  'SLIN',
  'KHAL',
]);

export const SocialTradesFeed: React.FC<SocialTradesFeedProps> = ({
  stocks,
  watchlist,
  selectedMarketFilter = null,
  onSelectStock,
  onQuickTrade,
  onToggleWatchlist,
  viewType = 'stocks',
  tickerFilter,
  recentShareNotice = null,
  onDismissShareNotice,
}) => {
  // Feed state
  const [trades, setTrades] = useState<SocialStockTrade[]>(() => {
    const shared = getStoredSharedSocialTrades();
    const seen = new Set(shared.map((t) => t.id));
    return [...shared, ...INITIAL_SOCIAL_TRADES.filter((t) => !seen.has(t.id))];
  });

  useEffect(() => {
    const syncSharedTrades = () => {
      const shared = getStoredSharedSocialTrades();
      setTrades((prev) => {
        const nonShared = prev.filter((t) => !t.isSharedByCurrentUser);
        const seen = new Set(shared.map((t) => t.id));
        return [...shared, ...nonShared.filter((t) => !seen.has(t.id))];
      });
    };

    window.addEventListener(SHARED_SOCIAL_TRADES_EVENT, syncSharedTrades);
    window.addEventListener('storage', syncSharedTrades);
    return () => {
      window.removeEventListener(SHARED_SOCIAL_TRADES_EVENT, syncSharedTrades);
      window.removeEventListener('storage', syncSharedTrades);
    };
  }, []);

  const [traderFilter, setTraderFilter] = useState<'friends' | 'favorite_friends'>('friends');
  const [selectedFriendUid, setSelectedFriendUid] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'personal' | 'business'>('all');
  const [sideFilter, setSideFilter] = useState<'all' | 'buy' | 'sell'>('all');
  const [instrumentFilter, setInstrumentFilter] = useState<'all' | 'equity' | 'derivatives'>('all');
  const [friendSearchQuery, setFriendSearchQuery] = useState('');
  const [copiedTradeId, setCopiedTradeId] = useState<string | null>(null);

  const effectiveMarketFilter: StockMarketWay | 'all' =
    viewType === 'equity' ? 'final' : selectedMarketFilter || 'all';

  // Favorite friends state (persisted to localStorage)
  const [favoriteFriendIds, setFavoriteFriendIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('final_favorite_friends');
      if (saved) {
        const parsed: string[] = JSON.parse(saved);
        return parsed.filter((id) => FRIENDS_AND_MUTUALS.some((f) => f.uid === id));
      }
    } catch {
      // ignore
    }
    return ['user-elena_rostova'];
  });

  useEffect(() => {
    const valid = favoriteFriendIds.filter((id) =>
      FRIENDS_AND_MUTUALS.some((f) => f.uid === id)
    );
    if (valid.length !== favoriteFriendIds.length) {
      setFavoriteFriendIds(valid);
      try {
        localStorage.setItem('final_favorite_friends', JSON.stringify(valid));
      } catch {
        // ignore
      }
    }
  }, [favoriteFriendIds]);

  const toggleFavoriteFriend = (friend: { uid: string; name: string }) => {
    setFavoriteFriendIds((prev) => {
      const clean = prev.filter((id) => FRIENDS_AND_MUTUALS.some((f) => f.uid === id));
      const isFav = clean.includes(friend.uid);
      const updated = isFav
        ? clean.filter((id) => id !== friend.uid)
        : [...clean, friend.uid];
      try {
        localStorage.setItem('final_favorite_friends', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  const getTradeCategory = (trade: SocialStockTrade): 'personal' | 'business' => {
    if (trade.assetCategory === 'personal' || trade.assetCategory === 'business') {
      return trade.assetCategory;
    }
    const matchedStock = stocks.find(
      (s) => s.ticker.toUpperCase() === trade.ticker.toUpperCase()
    );
    if (matchedStock) {
      if (
        matchedStock.assetCategory === 'personal' ||
        matchedStock.issuanceType === 'personal' ||
        matchedStock.sector === 'Sovereign Reserves'
      ) {
        return 'personal';
      }
      if (
        matchedStock.assetCategory === 'business' ||
        matchedStock.issuanceType === 'business'
      ) {
        return 'business';
      }
    }
    return PERSONAL_TICKERS.has(trade.ticker.toUpperCase()) ? 'personal' : 'business';
  };

  const isDerivativeSocialTrade = (trade: SocialStockTrade): boolean => {
    if (trade.instrumentCategory === 'derivatives') return true;
    if (trade.instrumentCategory === 'equity') return false;
    if (trade.derivativeType && trade.derivativeType !== 'spot') return true;
    if (trade.assetClass === 'Option (Call)' || trade.assetClass === 'Option (Put)') return true;
    const text = `${trade.stockName || ''} ${trade.commentary || ''}`.toLowerCase();
    return (
      text.includes('on derivatives') ||
      text.includes('call option') ||
      text.includes('put option') ||
      text.includes('futures long') ||
      text.includes('futures short')
    );
  };

  const getDerivativeContractLabel = (trade: SocialStockTrade): string | null => {
    if (!isDerivativeSocialTrade(trade)) return null;
    switch (trade.derivativeType) {
      case 'call_option':
        return 'Call Option';
      case 'put_option':
        return 'Put Option';
      case 'futures_long':
        return 'Long Futures';
      case 'futures_short':
        return 'Short Futures';
      default:
        return trade.assetClass === 'Option (Call)'
          ? 'Call Option'
          : trade.assetClass === 'Option (Put)'
          ? 'Put Option'
          : 'Derivatives';
    }
  };

  // Base friend trades valid for active view with sharing enforcement
  const marketFriendTrades = useMemo(() => {
    return trades.filter((trade) => {
      if (trade.traderType !== 'friend') return false;
      if (viewType === 'equity' && trade.marketType !== 'final') return false;
      if (viewType === 'stocks' && trade.marketType === 'final') return false;
      if (effectiveMarketFilter !== 'all' && trade.marketType !== effectiveMarketFilter) {
        return false;
      }

      // Sharing enforcement rule: if shared with all friends (or empty/all), all get it.
      // If shared with specific friend IDs, only those specific friends can view it.
      if (trade.isSharedByCurrentUser) {
        const sharedIds = trade.sharedWithFriendIds || [];
        const isSharedWithAll = sharedIds.length === 0 || sharedIds.includes('all');
        if (!isSharedWithAll) {
          if (selectedFriendUid && !sharedIds.includes(selectedFriendUid)) {
            return false;
          }
        }
      } else {
        const isKnownFriend = FRIENDS_AND_MUTUALS.some((f) => f.uid === trade.user.uid);
        if (!isKnownFriend) return false;
      }
      return true;
    });
  }, [trades, viewType, effectiveMarketFilter, selectedFriendUid]);

  const tradeCountByFriend = useMemo(() => {
    const counts = new Map<string, number>();
    marketFriendTrades.forEach((t) => {
      if (sideFilter !== 'all' && t.side !== sideFilter) return;
      if (categoryFilter !== 'all' && getTradeCategory(t) !== categoryFilter) return;
      if (instrumentFilter === 'equity' && isDerivativeSocialTrade(t)) return;
      if (instrumentFilter === 'derivatives' && !isDerivativeSocialTrade(t)) return;

      if (!t.isSharedByCurrentUser) {
        counts.set(t.user.uid, (counts.get(t.user.uid) || 0) + 1);
      } else {
        const sharedIds = t.sharedWithFriendIds || [];
        const isAll = sharedIds.length === 0 || sharedIds.includes('all');
        FRIENDS_AND_MUTUALS.forEach((f) => {
          if (isAll || sharedIds.includes(f.uid)) {
            counts.set(f.uid, (counts.get(f.uid) || 0) + 1);
          }
        });
      }
    });
    return counts;
  }, [marketFriendTrades, sideFilter, categoryFilter, instrumentFilter, stocks]);

  const favoriteFriendsList = useMemo(() => {
    const favs = FRIENDS_AND_MUTUALS.filter((f) => favoriteFriendIds.includes(f.uid));
    if (!friendSearchQuery.trim()) return favs;
    const q = friendSearchQuery.toLowerCase().trim();
    const words = q.split(/\s+/).filter(Boolean);
    return favs.filter((f) => {
      const friendTradesText = marketFriendTrades
        .filter((t) => t.user.uid === f.uid)
        .map((t) => `${t.ticker} ${t.stockName}`)
        .join(' ');
      const text = `${f.name} ${f.handle} ${f.title} ${f.bio} ${friendTradesText}`.toLowerCase();
      return words.every((w) => text.includes(w));
    });
  }, [favoriteFriendIds, friendSearchQuery, marketFriendTrades]);

  const selectedFriendProfile: FriendProfile | null = useMemo(() => {
    if (!selectedFriendUid) return null;
    return FRIENDS_AND_MUTUALS.find((f) => f.uid === selectedFriendUid) || null;
  }, [selectedFriendUid]);

  // Filtered trades list: newest first
  const filteredTrades = useMemo(() => {
    const list = marketFriendTrades.filter((trade) => {
      if (traderFilter === 'favorite_friends' && !selectedFriendUid) {
        // When in favorite tab without a specific friend selected, we show favorite friends list instead of feed directly
        return false;
      }

      if (traderFilter === 'favorite_friends') {
        if (trade.isSharedByCurrentUser) {
          const sharedIds = trade.sharedWithFriendIds || [];
          const isSharedWithAll = sharedIds.length === 0 || sharedIds.includes('all');
          const isSharedWithFav = isSharedWithAll || sharedIds.some((id) => favoriteFriendIds.includes(id));
          if (!isSharedWithFav) return false;
        } else if (!favoriteFriendIds.includes(trade.user.uid)) {
          return false;
        }
      }

      if (selectedFriendUid) {
        const isFromFriend = trade.user.uid === selectedFriendUid;
        const isSharedWithThisFriend =
          trade.isSharedByCurrentUser &&
          (!trade.sharedWithFriendIds ||
            trade.sharedWithFriendIds.length === 0 ||
            trade.sharedWithFriendIds.includes('all') ||
            trade.sharedWithFriendIds.includes(selectedFriendUid));
        if (!isFromFriend && !isSharedWithThisFriend) return false;
      }

      if (friendSearchQuery.trim()) {
        const q = friendSearchQuery.toLowerCase().trim();
        const words = q.split(/\s+/).filter(Boolean);
        const text = `${trade.user.name} ${trade.user.handle} ${trade.ticker} ${trade.stockName} ${trade.commentary || ''} ${trade.finalCoinSymbol || ''}`.toLowerCase();
        if (!words.every((w) => text.includes(w))) return false;
      }

      if (categoryFilter !== 'all') {
        if (getTradeCategory(trade) !== categoryFilter) return false;
      }

      if (sideFilter !== 'all' && trade.side !== sideFilter) return false;

      if (instrumentFilter === 'equity' && isDerivativeSocialTrade(trade)) return false;
      if (instrumentFilter === 'derivatives' && !isDerivativeSocialTrade(trade)) return false;

      if (tickerFilter && trade.ticker.toUpperCase() !== tickerFilter.toUpperCase()) {
        return false;
      }

      return true;
    });

    return [...list].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }, [
    marketFriendTrades,
    traderFilter,
    favoriteFriendIds,
    selectedFriendUid,
    friendSearchQuery,
    categoryFilter,
    sideFilter,
    instrumentFilter,
    tickerFilter,
    stocks,
  ]);

  const handleCopyTrade = (trade: SocialStockTrade) => {
    const isFinalMarket = trade.marketType === 'final';
    const coin = (trade.finalCoinSymbol || `$${trade.ticker}`).replace(/-FNL/gi, '');
    const valuationStr = isFinalMarket
      ? `${trade.totalValueUSD.toLocaleString()} ${coin}`
      : `$${trade.totalValueUSD.toLocaleString(undefined, {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}`;
    navigator.clipboard.writeText(valuationStr);
    const targetStock = stocks.find(
      (s) => s.ticker.toUpperCase() === trade.ticker.toUpperCase()
    );
    if (targetStock && onQuickTrade) {
      onQuickTrade(targetStock, trade.side);
    }
    setCopiedTradeId(trade.id);
    setTimeout(() => setCopiedTradeId(null), 2500);
  };

  const handleSelectFriend = (uid: string) => {
    setSelectedFriendUid((prev) => (prev === uid ? null : uid));
  };

  // Clean settlement method string (remove "Final Coin Clearing" and "-FNL")
  const formatSettlementMethod = (method?: string, ticker?: string) => {
    if (!method) return `$${(ticker || '').replace(/-FNL/gi, '')}`;
    const cleaned = method
      .replace(/Final Coin Clearing\s*[:\-\(]*/gi, '')
      .replace(/Final Coin Sovereign Vault\s*[:\-\(]*/gi, '')
      .replace(/-FNL/gi, '')
      .replace(/^\(|\)$/g, '')
      .trim();
    if (!cleaned && ticker) return `$${ticker.replace(/-FNL/gi, '')}`;
    return cleaned.startsWith('$') ? cleaned : `$${cleaned}`;
  };

  const formatTradeDateTime = (timestamp?: string | number | null) => {
    let dateObj: Date | null = null;
    if (timestamp) {
      const p = new Date(timestamp);
      if (!isNaN(p.getTime())) dateObj = p;
    }
    const finalD = dateObj || new Date();
    const date = finalD.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
    const time = finalD.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
    return {
      date,
      time,
      fullDateTime: `${date} at ${time}`,
    };
  };

  return (
    <div className="space-y-5 text-center max-w-4xl mx-auto">
      {/* Smooth Transition Banner when a trade was just shared from Spot */}
      {recentShareNotice && (
        <div className="p-3.5 sm:p-4 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-950 flex items-center justify-between gap-3 text-xs shadow-2xs">
          <div className="flex items-center gap-2.5 text-left min-w-0">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Share2 className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <span className="font-bold block truncate">{recentShareNotice}</span>
              <span className="text-[11px] text-indigo-700 block">
                Your shared trade now appears at the top of your feed alongside your friends&apos; shared trades.
              </span>
            </div>
          </div>
          {onDismissShareNotice && (
            <button
              type="button"
              onClick={onDismissShareNotice}
              className="p-1.5 rounded-lg text-indigo-600 hover:text-indigo-900 hover:bg-indigo-100 transition-colors cursor-pointer shrink-0"
              title="Dismiss notice"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {/* Filter & Persona Controls Bar - Fully Centered */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4 max-w-3xl mx-auto text-center">
        <div className="flex flex-col items-center justify-center gap-3">
          {/* Primary Tabs: Friends & Favorite */}
          <div className="flex items-center justify-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => {
                setTraderFilter('friends');
                setSelectedFriendUid(null);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                traderFilter === 'friends'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>Friends</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setTraderFilter('favorite_friends');
                setSelectedFriendUid(null);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                traderFilter === 'favorite_friends'
                  ? 'bg-amber-500 text-slate-950 shadow-xs font-extrabold'
                  : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200/60'
              }`}
            >
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span>Favorite ({favoriteFriendIds.length})</span>
            </button>
          </div>

          {/* Side Filter: All | Buys | Sells + Equity | Derivatives underneath */}
          <div className="flex flex-col items-center justify-center gap-2">
            <div className="flex items-center justify-center gap-1.5 flex-wrap">
              <span className="text-slate-400 font-medium text-[11px]">Side:</span>
              <button
                type="button"
                onClick={() => setSideFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  sideFilter === 'all'
                    ? 'bg-slate-800 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setSideFilter('buy')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  sideFilter === 'buy'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                }`}
              >
                Buys
              </button>
              <button
                type="button"
                onClick={() => setSideFilter('sell')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  sideFilter === 'sell'
                    ? 'bg-rose-600 text-white'
                    : 'bg-rose-50 text-rose-800 hover:bg-rose-100'
                }`}
              >
                Sells
              </button>
            </div>

            {/* Equity & Derivatives Filter Options underneath Side (applies to Friends & Favorites) */}
            <div className="flex items-center justify-center gap-1.5 flex-wrap">
              <button
                type="button"
                onClick={() => setInstrumentFilter((prev) => (prev === 'equity' ? 'all' : 'equity'))}
                className={`px-3 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  instrumentFilter === 'equity'
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Equity
              </button>
              <button
                type="button"
                onClick={() => setInstrumentFilter((prev) => (prev === 'derivatives' ? 'all' : 'derivatives'))}
                className={`px-3 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  instrumentFilter === 'derivatives'
                    ? 'bg-amber-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Derivatives
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Filter Row: All Types | Business | Personal + Search Bar - Centered */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-center gap-3 flex-wrap">
          <div className="flex items-center justify-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setCategoryFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                categoryFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Types
            </button>
            <button
              type="button"
              onClick={() => setCategoryFilter('business')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1 ${
                categoryFilter === 'business'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building className="w-3 h-3" />
              <span>Business</span>
            </button>
            <button
              type="button"
              onClick={() => setCategoryFilter('personal')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1 ${
                categoryFilter === 'personal'
                  ? 'bg-purple-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <User className="w-3 h-3" />
              <span>Personal</span>
            </button>
          </div>

          <div className="relative w-full max-w-sm mx-auto">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={friendSearchQuery}
              onChange={(e) => setFriendSearchQuery(e.target.value)}
              placeholder="Search friends, @handle, or tickers..."
              className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-amber-500 font-sans text-center"
            />
            {friendSearchQuery && (
              <button
                type="button"
                onClick={() => setFriendSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ================= FAVORITE TAB: FAVORITED FRIENDS DIRECTORY (When on favorite tab and no friend is selected) ================= */}
      {traderFilter === 'favorite_friends' && !selectedFriendUid && (
        <div className="space-y-4 max-w-3xl mx-auto text-center">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div className="text-left">
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                <span>Favorite Friends</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Click &ldquo;View Trades&rdquo; on any favorite friend to open their dedicated trade page.
              </p>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 font-bold">
              {favoriteFriendsList.length} Favorited
            </span>
          </div>

          {favoriteFriendsList.length === 0 ? (
            <div className="p-8 text-center rounded-3xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 text-amber-500 flex items-center justify-center mx-auto shadow-2xs">
                <Star className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">
                {friendSearchQuery.trim()
                  ? `No favorited friends match "${friendSearchQuery}"`
                  : 'No Favorite Friends Yet'}
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Favorite any friend in the Friends tab to track them here:
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setTraderFilter('friends')}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <Users className="w-3.5 h-3.5 text-amber-400" />
                  <span>Browse Friends</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-center">
              {favoriteFriendsList.map((friend) => {
                const count = tradeCountByFriend.get(friend.uid) || 0;

                return (
                  <div
                    key={friend.uid}
                    className="p-5 rounded-3xl border shadow-2xs hover:shadow-md transition-all flex flex-col justify-between items-center text-center gap-3.5 bg-amber-50/40 border-amber-300"
                  >
                    <div className="space-y-2.5 flex flex-col items-center text-center w-full">
                      <img
                        src={friend.avatarUrl}
                        alt={friend.name}
                        className="w-14 h-14 rounded-2xl object-cover border-2 border-slate-200 shrink-0 shadow-2xs mx-auto"
                      />
                      <div className="text-center w-full">
                        <div className="flex items-center justify-center gap-1.5 flex-wrap">
                          <span className="font-bold text-sm text-slate-900">
                            {friend.name}
                          </span>
                          {friend.verified && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                          )}
                        </div>
                        <p className="text-xs font-mono text-slate-400 mt-1 flex items-center justify-center gap-1.5 flex-wrap">
                          <span>@{friend.handle}</span>
                          <span className="text-slate-300 font-bold">&bull;</span>
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-100/80 inline-flex items-center">
                            {friend.winRate} Win
                          </span>
                        </p>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed font-medium text-center">
                        {friend.title}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-200/70 flex items-center justify-center gap-2 w-full flex-wrap">
                      <button
                        type="button"
                        onClick={() => setSelectedFriendUid(friend.uid)}
                        className="flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs active:scale-95 whitespace-nowrap bg-slate-900 hover:bg-slate-800 text-white min-w-[120px]"
                      >
                        <span>
                          {instrumentFilter === 'equity'
                            ? `View Equity (${count})`
                            : instrumentFilter === 'derivatives'
                            ? `View Derivatives (${count})`
                            : `View Trades (${count})`}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleFavoriteFriend(friend)}
                        className="py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer bg-amber-100 text-amber-900 border border-amber-300 hover:bg-rose-100 hover:text-rose-900 hover:border-rose-300 shadow-2xs whitespace-nowrap"
                        title={`Remove ${friend.name} from favorites`}
                      >
                        <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                        <span>Favorited</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ================= SELECTED PARTICULAR FRIEND DEDICATED PAGE VIEW (With Back Button) - CENTERED ================= --> */}
      {selectedFriendProfile && (
        <div className="space-y-4 max-w-2xl mx-auto text-center">
          {/* Back button header - Centered */}
          <div className="p-6 rounded-3xl bg-indigo-50/70 border border-indigo-200 flex flex-col items-center justify-center gap-3.5 text-center shadow-2xs">
            <img
              src={selectedFriendProfile.avatarUrl}
              alt={selectedFriendProfile.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-200 shadow-2xs mx-auto"
            />
            <div className="space-y-1 text-center">
              <h4 className="font-bold text-lg text-slate-900">
                {selectedFriendProfile.name}&apos;s Trade Page
              </h4>
              <div className="flex items-center justify-center gap-2">
                <span className="text-xs font-mono px-3 py-0.5 rounded-full bg-white text-indigo-700 border border-indigo-200 font-bold shadow-2xs">
                  {filteredTrades.length} {filteredTrades.length === 1 ? 'Trade' : 'Trades'}
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                @{selectedFriendProfile.handle} &bull; {selectedFriendProfile.title}
              </p>
            </div>

            <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
              <button
                type="button"
                onClick={() => toggleFavoriteFriend(selectedFriendProfile)}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-2xs ${
                  favoriteFriendIds.includes(selectedFriendProfile.uid)
                    ? 'bg-amber-100 border-amber-300 text-amber-900'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-amber-300'
                }`}
              >
                <Star
                  className={`w-3.5 h-3.5 ${
                    favoriteFriendIds.includes(selectedFriendProfile.uid)
                      ? 'fill-amber-400 text-amber-500'
                      : 'text-slate-400'
                  }`}
                />
                <span>
                  {favoriteFriendIds.includes(selectedFriendProfile.uid)
                    ? 'Favorited'
                    : 'Favorite'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedFriendUid(null)}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= SHARED TRADES STREAM (When on Friends tab OR when a friend is selected) ================= */}
      {(traderFilter === 'friends' || selectedFriendUid) && (
        <div className="space-y-4 max-w-3xl mx-auto">
          {filteredTrades.length === 0 ? (
            <div className="p-10 text-center rounded-3xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 text-slate-400 flex items-center justify-center mx-auto shadow-2xs">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="font-serif font-bold text-slate-900 text-base">
                No Matching Shared Trades
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No shared trades match your current Side, Equity/Derivatives, Stock Type, or Search filters.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSelectedFriendUid(null);
                  setCategoryFilter('all');
                  setSideFilter('all');
                  setInstrumentFilter('all');
                  setFriendSearchQuery('');
                }}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-2xs"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredTrades.map((trade, idx) => {
                const isBuy = trade.side === 'buy';
                const tradeCat = getTradeCategory(trade);
                const isPersonal = tradeCat === 'personal';
                const isFavFriend = favoriteFriendIds.includes(trade.user.uid);
                const foundStock = stocks.find(
                  (s) => s.ticker.toUpperCase() === trade.ticker.toUpperCase()
                );
                const isCopied = copiedTradeId === trade.id;
                const isFinalMarket = trade.marketType === 'final';
                const canSelectFriend =
                  !trade.isSharedByCurrentUser &&
                  FRIENDS_AND_MUTUALS.some((f) => f.uid === trade.user.uid);

                const cleanTicker = (trade.ticker || '').toUpperCase().replace(/-FNL$/i, '');
                const cleanCoin = (trade.finalCoinSymbol || `$${cleanTicker}`).replace(/-FNL/gi, '').trim();
                const displayCoin = cleanCoin.startsWith('$') ? cleanCoin : `$${cleanCoin}`;
                const cleanTotalValStr = isFinalMarket
                  ? `${trade.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 })} ${displayCoin}`
                  : `$${trade.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

                const cleanedSettlement = formatSettlementMethod(trade.settlementMethod, cleanTicker);
                const cleanCommentary = (trade.commentary || '')
                  .replace(/\(\$([A-Z]+)-FNL\)/gi, '($$$1)')
                  .replace(/-FNL/gi, '')
                  .trim();

                const exactDt = formatTradeDateTime(trade.timestamp);

                return (
                  <div
                    key={`${trade.id}-${idx}`}
                    className={`p-6 sm:p-7 rounded-3xl bg-white border transition-all hover:shadow-md space-y-4 text-center max-w-2xl mx-auto shadow-2xs ${
                      trade.isSharedByCurrentUser || trade.isRealTimeNew
                        ? 'border-indigo-300 ring-1 ring-indigo-300/30'
                        : 'border-slate-200'
                    }`}
                  >
                    {/* Header: Friend Profile + Badges + Favorite Friend Option (Centered) */}
                    <div className="flex flex-col items-center justify-center gap-2 pb-3 border-b border-slate-100 text-center">
                      <div
                        className={`relative mx-auto ${canSelectFriend ? 'cursor-pointer group' : ''}`}
                        onClick={() => {
                          if (canSelectFriend) handleSelectFriend(trade.user.uid);
                        }}
                      >
                        <img
                          src={trade.user.avatarUrl}
                          alt={trade.user.name}
                          className="w-13 h-13 rounded-2xl object-cover border-2 border-slate-200 shadow-2xs group-hover:ring-2 group-hover:ring-indigo-400 transition-all mx-auto"
                        />
                        <span
                          className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-2xs text-[10px]"
                          title={trade.isSharedByCurrentUser ? 'You' : 'Friend'}
                        >
                          🤝
                        </span>
                      </div>

                      {/* Name & verification - Centered */}
                      <div className="flex items-center justify-center gap-1.5 flex-wrap">
                        <h3
                          onClick={() => {
                            if (canSelectFriend) handleSelectFriend(trade.user.uid);
                          }}
                          className={`font-bold text-base text-slate-900 ${
                            canSelectFriend
                              ? 'hover:text-indigo-600 cursor-pointer transition-colors'
                              : ''
                          }`}
                        >
                          {trade.user.name}
                        </h3>
                        {trade.user.verified && (
                          <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />
                        )}
                      </div>

                      {/* Handle and Win rate - Centered */}
                      <div className="flex items-center justify-center gap-2 flex-wrap text-xs font-mono text-slate-500">
                        <span>@{trade.user.handle}</span>
                        {trade.user.winRate && (
                          <>
                            <span className="text-slate-300 font-bold">&bull;</span>
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                              {trade.user.winRate} Win
                            </span>
                          </>
                        )}
                      </div>

                      {/* Friend action buttons: Trades & Favorited - Centered */}
                      <div className="flex items-center justify-center gap-2 flex-wrap pt-0.5">
                        {trade.isSharedByCurrentUser && (
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            <span className="px-2.5 py-0.5 rounded-lg text-xs font-bold bg-indigo-600 text-white shadow-2xs whitespace-nowrap">
                              Shared with {trade.sharedWithLabel || 'Friends'}
                            </span>
                            <button
                              type="button"
                              onClick={() => removeSharedSocialTrade(trade.id)}
                              className="px-2.5 py-0.5 rounded-lg text-xs font-bold bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-200 transition-colors cursor-pointer"
                              title="Unshare this trade from friends feed"
                            >
                              Unshare
                            </button>
                          </div>
                        )}

                        {!trade.isSharedByCurrentUser && canSelectFriend && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleSelectFriend(trade.user.uid)}
                              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer shadow-2xs active:scale-95 whitespace-nowrap ${
                                selectedFriendUid === trade.user.uid
                                  ? 'bg-indigo-600 text-white'
                                  : 'bg-indigo-900 hover:bg-indigo-800 text-white'
                              }`}
                              title={`View dedicated page for ${trade.user.name}`}
                            >
                              <span>
                                {selectedFriendUid === trade.user.uid ? 'Viewing Trades' : 'Trades'}
                              </span>
                            </button>

                            <button
                              type="button"
                              onClick={() => toggleFavoriteFriend(trade.user)}
                              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer active:scale-95 ${
                                isFavFriend
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 border border-slate-200'
                              }`}
                              title={
                                isFavFriend
                                  ? `Favorited ${trade.user.name} - click to remove from favorites`
                                  : `Favorite ${trade.user.name}`
                              }
                            >
                              <Star
                                className={`w-3.5 h-3.5 ${
                                  isFavFriend
                                    ? 'fill-amber-500 text-amber-500'
                                    : 'text-slate-400'
                                }`}
                              />
                              <span>{isFavFriend ? 'Favorited' : 'Favorite'}</span>
                            </button>
                          </>
                        )}
                      </div>

                      {/* Title - Centered */}
                      <p className="text-xs text-slate-500 font-medium max-w-md mx-auto">
                        {trade.user.title}
                      </p>

                      {/* Timing of the transaction (exact time & date) - Centered */}
                      <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500 font-mono pt-1 flex-wrap">
                        <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-bold text-slate-700">{trade.timestampAgo || 'Just now'}</span>
                        <span className="text-slate-300 font-bold">&bull;</span>
                        <span>{exactDt.fullDateTime}</span>
                      </div>
                    </div>

                    {/* Trade Card Body - ALL ALIGNED TO CENTER */}
                    <div className="space-y-3.5 text-center flex flex-col items-center justify-center">
                      {/* BUY / SELL badge and shares in ONE LINE, CENTERED */}
                      <div className="flex items-center justify-center gap-2 flex-wrap text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-lg text-xs font-black uppercase tracking-wider ${
                            isBuy
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                              : 'bg-rose-50 text-rose-700 border border-rose-300'
                          }`}
                        >
                          {trade.side.toUpperCase()}
                        </span>
                        <span className="font-bold text-base text-slate-900">
                          {trade.shares.toLocaleString()} shares of {trade.stockName}
                        </span>
                      </div>

                      {/* Ticker, Derivative Badge (if applicable) & Category - Centered */}
                      <div className="flex items-center justify-center gap-2 flex-wrap">
                        <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded-lg bg-slate-100 text-slate-700">
                          ${cleanTicker}
                        </span>
                        {(() => {
                          const derivLabel = getDerivativeContractLabel(trade);
                          if (!derivLabel) return null;
                          return (
                            <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-amber-50 text-amber-900 border border-amber-200">
                              {derivLabel}
                              {trade.strikePrice ? ` • Strike ${trade.strikePrice.toFixed(2)}` : ''}
                              {trade.leverage ? ` • ${trade.leverage}x` : ''}
                              {trade.expiryDate ? ` • Exp ${trade.expiryDate}` : ''}
                            </span>
                          );
                        })()}
                        <span
                          className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold ${
                            isPersonal
                              ? 'bg-purple-50 text-purple-700 border border-purple-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {isPersonal ? 'Personal Asset' : 'Business Enterprise'}
                        </span>
                      </div>

                      {/* Price & Total Value (no -FNL, centered) */}
                      <div className="space-y-0.5 text-center">
                        <div className="font-black text-slate-900 text-xl font-mono">
                          {cleanTotalValStr}
                        </div>
                        <div className="text-xs text-slate-500 font-mono">
                          {isFinalMarket
                            ? `${trade.priceUSD.toFixed(2)} ${displayCoin} / share`
                            : `$${trade.priceUSD.toFixed(2)} / share`}
                        </div>
                      </div>

                      {/* Commentary (centered quote) */}
                      {cleanCommentary && (
                        <p className="text-xs text-slate-600 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 leading-relaxed font-medium text-center max-w-lg mx-auto">
                          &ldquo;{cleanCommentary}&rdquo;
                        </p>
                      )}

                      {/* Settlement & Return - Centered */}
                      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-1 text-xs text-slate-600">
                        <div className="flex items-center justify-center gap-1.5 font-medium">
                          <span className="text-slate-500">Settlement:</span>
                          <strong className="text-slate-800 font-mono">{cleanedSettlement}</strong>
                        </div>

                        {trade.gainLossPercent !== undefined && (
                          <span
                            className={`font-bold inline-flex items-center gap-1 ${
                              trade.gainLossPercent >= 0 ? 'text-emerald-600' : 'text-rose-600'
                            }`}
                          >
                            {trade.gainLossPercent >= 0 ? (
                              <TrendingUp className="w-3.5 h-3.5" />
                            ) : (
                              <TrendingDown className="w-3.5 h-3.5" />
                            )}
                            <span>{trade.gainLossPercent >= 0 ? '+' : ''}{trade.gainLossPercent}% Return</span>
                          </span>
                        )}
                      </div>

                      {/* Action Buttons - Centered */}
                      <div className="flex items-center justify-center gap-2 pt-2 border-t border-slate-100 flex-wrap w-full">
                        {onSelectStock && (
                          <button
                            type="button"
                            onClick={() => {
                              const target: StockItem = foundStock || {
                                ticker: cleanTicker,
                                name: trade.stockName || cleanTicker,
                                price: trade.priceUSD || 1,
                                changeUSD: 0,
                                changePercent: trade.gainLossPercent || 0,
                                marketCap: 'N/A',
                                volume: 'N/A',
                                avgVolume: 'N/A',
                                sector: 'Sovereign Reserves',
                                marketType: trade.marketType || 'final',
                                settlementMethod: displayCoin,
                                high24h: (trade.priceUSD || 1) * 1.03,
                                low24h: (trade.priceUSD || 1) * 0.97,
                                openPrice: trade.priceUSD || 1,
                                prevClose: trade.priceUSD || 1,
                                peRatio: 0,
                                eps: 0,
                                dividendYield: '0.00%',
                                beta: 1.0,
                                fiftyTwoWeekHigh: (trade.priceUSD || 1) * 1.2,
                                fiftyTwoWeekLow: (trade.priceUSD || 1) * 0.8,
                                description: `${trade.stockName} settled in ${displayCoin}.`,
                                exchange: 'SOVEREIGN_NODE',
                                analystRating: 'Buy',
                                analystTargetUSD: (trade.priceUSD || 1) * 1.15,
                                analystCount: 1,
                                sparkline: [trade.priceUSD || 1],
                                history: {
                                  '1D': [{ time: 'Now', price: trade.priceUSD || 1, volume: 0 }],
                                  '1W': [{ time: 'Now', price: trade.priceUSD || 1, volume: 0 }],
                                  '1M': [{ time: 'Now', price: trade.priceUSD || 1, volume: 0 }],
                                  '1Y': [{ time: 'Now', price: trade.priceUSD || 1, volume: 0 }],
                                  '5Y': [{ time: 'Now', price: trade.priceUSD || 1, volume: 0 }],
                                },
                                issuanceType: isPersonal ? 'personal' : 'business',
                                assetCategory: isPersonal ? 'personal' : 'business',
                                issuanceCoinSymbol: displayCoin,
                              };
                              onSelectStock(target);
                            }}
                            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors cursor-pointer inline-flex items-center gap-1.5 shadow-2xs"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>View Ticker</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => handleCopyTrade(trade)}
                          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-2xs active:scale-95"
                        >
                          {isCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-300">Trade Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy / Quick Trade</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
