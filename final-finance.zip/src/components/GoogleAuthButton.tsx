import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { AuthSession } from '../types/auth';
import { signInWithGoogle, getRegisteredUsers } from '../services/firebaseAuth';

interface GoogleAuthButtonProps {
  mode: 'signin' | 'signup';
  onSuccess: (user: AuthSession) => void;
  onError: (errorMessage: string) => void;
  disabled?: boolean;
}

export const GoogleAuthButton: React.FC<GoogleAuthButtonProps> = ({
  mode,
  onSuccess,
  onError,
  disabled = false,
}) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    setIsLoading(true);
    try {
      await new Promise((r) => setTimeout(r, 600));
      const registered = getRegisteredUsers();
      const userAccount = registered['gholu653@gmail.com'] || Object.values(registered)[0];
      const res = await signInWithGoogle(userAccount.email, userAccount.passwordHash, false);
      if (res.success && res.user) {
        onSuccess(res.user);
      } else {
        onError(res.error || 'Google sign-in failed.');
      }
    } catch (err: any) {
      onError(err?.message || 'Google authentication error.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      type="button"
      id={`google-${mode}-btn`}
      onClick={handleClick}
      disabled={disabled || isLoading}
      className="w-full flex items-center justify-center gap-3 py-3.5 px-4 rounded-2xl border border-slate-300 bg-white text-slate-800 text-sm font-medium hover:bg-slate-50 hover:border-slate-400 active:scale-98 transition-all cursor-pointer shadow-xs disabled:opacity-60 disabled:cursor-not-allowed min-h-[48px]"
    >
      {isLoading ? (
        <>
          <Loader2 className="w-5 h-5 text-blue-600 animate-spin shrink-0" />
          <span className="font-medium text-slate-700">Connecting to Google...</span>
        </>
      ) : (
        <>
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
            />
          </svg>
          <span className="font-medium text-slate-800">
            {mode === 'signup' ? 'Sign up with Google' : 'Sign in with Google'}
          </span>
        </>
      )}
    </button>
  );
};
