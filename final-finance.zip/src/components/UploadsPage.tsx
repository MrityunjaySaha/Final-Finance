import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  Check, 
  Package, 
  Briefcase, 
  Clock, 
  Search, 
  Filter, 
  ArrowLeft,
  Coins,
  Repeat,
  Sparkles,
  ExternalLink,
  Layers,
  Image as ImageIcon,
  Film,
  Globe,
  Users,
  Shield,
  Lock,
  CheckCircle2,
  CheckSquare,
  Square,
  X
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { MarketplaceListing, ListingStatus, ListingVisibility } from '../types/marketplace';
import { UserPublicProfile, FriendGroup } from '../types/social';
import { 
  getUserListings, 
  deleteListing, 
  updateListingStatus,
  updateListingVisibility
} from '../services/marketplaceService';
import { 
  getUserFriendGroups, 
  createFriendGroup, 
  updateFriendGroup, 
  deleteFriendGroup 
} from '../services/friendGroupService';
import { getFriendsList, getAllUsers } from '../services/socialService';
import { CreateListingDraftModal } from './CreateListingDraftModal';

interface UploadsPageProps {
  currentUser?: AuthSession | null;
  onNavigateBack?: () => void;
  onViewListingDetail?: (listing: MarketplaceListing) => void;
}

export const UploadsPage: React.FC<UploadsPageProps> = ({
  currentUser,
  onNavigateBack,
  onViewListingDetail,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'draft' | 'uploaded' | 'sold'>('all');
  const [filterVisibility, setFilterVisibility] = useState<'all' | 'public' | 'friends' | 'custom_group' | 'only_me'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [listings, setListings] = useState<MarketplaceListing[]>(() => {
    const target = currentUser?.id || currentUser?.uid || 'guest';
    const viewer = currentUser?.uid || currentUser?.id || 'guest';
    return getUserListings(target, viewer, true, currentUser?.id);
  });
  
  // Friend Groups State
  const [friendGroups, setFriendGroups] = useState<FriendGroup[]>([]);
  const [availableFriends, setAvailableFriends] = useState<UserPublicProfile[]>([]);
  const [platformUsers, setPlatformUsers] = useState<UserPublicProfile[]>([]);
  const [saveToastMessage, setSaveToastMessage] = useState<string | null>(null);

  // Modal state for creating/editing listing drafts
  const [activeModalListing, setActiveModalListing] = useState<MarketplaceListing | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');

  // Modal state for audience & privacy selector
  const [isAudienceModalOpen, setIsAudienceModalOpen] = useState(false);
  const [selectedListingForAudience, setSelectedListingForAudience] = useState<MarketplaceListing | null>(null);
  const [selectedVisibility, setSelectedVisibility] = useState<ListingVisibility>('public');
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);

  // Modal state for Friend Groups manager & creator
  const [isGroupManagerModalOpen, setIsGroupManagerModalOpen] = useState(false);
  const [isCreateGroupModalOpen, setIsCreateGroupModalOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<FriendGroup | null>(null);
  const [groupNameInput, setGroupNameInput] = useState('');
  const [groupDescInput, setGroupDescInput] = useState('');
  const [groupColorInput, setGroupColorInput] = useState('#f59e0b');
  const [groupAvatarInput, setGroupAvatarInput] = useState('');
  const groupImageFileRef = useRef<HTMLInputElement>(null);
  const [groupTypeInput, setGroupTypeInput] = useState<'friend' | 'general'>('friend');
  const [selectedMemberUids, setSelectedMemberUids] = useState<string[]>([]);
  const [memberSearchQuery, setMemberSearchQuery] = useState('');
  const [groupErrorMsg, setGroupErrorMsg] = useState('');
  const [groupToDelete, setGroupToDelete] = useState<FriendGroup | null>(null);

  const activeUid = currentUser?.uid || currentUser?.id || 'guest';

  const loadData = async () => {
    const target = currentUser?.id || currentUser?.uid || 'guest';
    const viewer = currentUser?.uid || currentUser?.id || 'guest';
    const userListings = getUserListings(target, viewer, true, currentUser?.id);
    setListings(userListings);

    // Load friend groups
    const groups = getUserFriendGroups(activeUid);
    setFriendGroups(groups);

    // Load friends
    const confirmedFriends = await getFriendsList(activeUid);
    const allUsers = await getAllUsers(activeUid);
    setAvailableFriends(confirmedFriends);
    setPlatformUsers(allUsers);
  };

  const selectableUsersForGroup = useMemo(() => {
    if (groupTypeInput === 'friend') {
      return availableFriends;
    }
    return platformUsers;
  }, [groupTypeInput, availableFriends, platformUsers]);

  useEffect(() => {
    loadData();
  }, [currentUser, activeUid]);

  const showToast = (msg: string) => {
    setSaveToastMessage(msg);
    setTimeout(() => {
      setSaveToastMessage(null);
    }, 3000);
  };

  const refreshListings = () => {
    const target = currentUser?.id || currentUser?.uid || 'guest';
    const viewer = currentUser?.uid || currentUser?.id || 'guest';
    setListings(getUserListings(target, viewer, true, currentUser?.id));
  };

  const handleOpenCreateModal = () => {
    setActiveModalListing(null);
    setModalMode('create');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (listing: MarketplaceListing) => {
    setActiveModalListing(listing);
    setModalMode('edit');
    setIsModalOpen(true);
  };

  const handleDeleteListing = (id: string) => {
    if (confirm('Are you sure you want to remove this listing?')) {
      deleteListing(currentUser?.id || 'guest', id);
      refreshListings();
      showToast('Listing removed');
    }
  };

  const handleTogglePublish = (listing: MarketplaceListing) => {
    const nextStatus: ListingStatus = listing.status === 'uploaded' ? 'draft' : 'uploaded';
    updateListingStatus(currentUser?.id || 'guest', listing.id, nextStatus);
    refreshListings();
    showToast(nextStatus === 'uploaded' ? 'Listing published live' : 'Listing moved to drafts');
  };

  // ================= AUDIENCE & PRIVACY MODAL HANDLERS =================
  const handleOpenAudienceModal = (listing: MarketplaceListing, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedListingForAudience(listing);
    setSelectedVisibility(listing.visibility || 'public');
    setSelectedGroupIds(listing.allowedGroupIds || []);
    setIsAudienceModalOpen(true);
  };

  const handleSaveAudience = () => {
    if (!selectedListingForAudience) return;
    
    const matchedGroupNames = friendGroups
      .filter(g => selectedGroupIds.includes(g.id))
      .map(g => g.name);

    const updated = updateListingVisibility(
      selectedListingForAudience.id,
      selectedVisibility,
      selectedVisibility === 'custom_group' ? selectedGroupIds : [],
      selectedVisibility === 'custom_group' ? matchedGroupNames : []
    );

    if (updated) {
      setListings(prev => prev.map(l => l.id === updated.id ? updated : l));
      const label = selectedVisibility === 'public' ? 'Public (The World)' :
                    selectedVisibility === 'friends' ? 'Friends Only' :
                    selectedVisibility === 'only_me' ? 'Only Me (Private Vault)' :
                    `Friend Group (${matchedGroupNames.join(', ') || 'Custom'})`;
      showToast(`Listing audience set to ${label}`);
    }

    setIsAudienceModalOpen(false);
    setSelectedListingForAudience(null);
  };

  const toggleGroupSelection = (groupId: string) => {
    setSelectedGroupIds(prev => 
      prev.includes(groupId) ? prev.filter(id => id !== groupId) : [...prev, groupId]
    );
  };

  // ================= FRIEND GROUP CREATION & MANAGEMENT HANDLERS =================
  const handleOpenCreateGroup = (initialGroup?: FriendGroup) => {
    if (initialGroup) {
      setEditingGroup(initialGroup);
      setGroupNameInput(initialGroup.name);
      setGroupDescInput(initialGroup.description || '');
      setGroupColorInput(initialGroup.color || '#f59e0b');
      setGroupAvatarInput(initialGroup.avatarUrl || '');
      setGroupTypeInput(initialGroup.groupType || 'friend');
      setSelectedMemberUids(initialGroup.memberUids || []);
    } else {
      setEditingGroup(null);
      setGroupNameInput('');
      setGroupDescInput('');
      setGroupColorInput('#f59e0b');
      setGroupAvatarInput('');
      setGroupTypeInput('friend');
      setSelectedMemberUids([]);
    }
    setMemberSearchQuery('');
    setGroupErrorMsg('');
    setIsCreateGroupModalOpen(true);
  };

  const handleSaveGroup = () => {
    if (!groupNameInput.trim()) {
      showToast('Please enter a group name');
      return;
    }

    const memberHandles = selectableUsersForGroup
      .filter(f => selectedMemberUids.includes(f.uid))
      .map(f => f.userId);

    if (editingGroup) {
      const updated = updateFriendGroup(editingGroup.id, {
        name: groupNameInput.trim(),
        description: groupDescInput.trim(),
        color: groupColorInput,
        avatarUrl: groupAvatarInput,
        memberUids: selectedMemberUids,
        memberHandles,
        groupType: groupTypeInput
      });
      if (updated) {
        setFriendGroups(prev => prev.map(g => g.id === updated.id ? updated : g));
        showToast(`Group "${groupNameInput}" updated`);
      }
    } else {
      const created = createFriendGroup(
        activeUid,
        groupNameInput.trim(),
        selectedMemberUids,
        groupDescInput.trim(),
        groupColorInput,
        memberHandles,
        groupTypeInput,
        groupAvatarInput
      );
      setFriendGroups(prev => [created, ...prev]);
      showToast(`Group "${groupNameInput}" created with ${selectedMemberUids.length} members`);
      
      // If creating from audience modal, auto-select this new group
      if (isAudienceModalOpen) {
        setSelectedGroupIds(prev => [...prev, created.id]);
        setSelectedVisibility('custom_group');
      }
    }

    setIsCreateGroupModalOpen(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGroupAvatarInput(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteGroup = (groupId: string, groupName: string) => {
    const group = friendGroups.find(g => g.id === groupId);
    if (group) {
      setGroupToDelete(group);
    }
  };

  const handleSetGroupType = (type: 'friend' | 'general') => {
    setGroupTypeInput(type);
    if (type === 'friend') {
      // Filter out non-friends if switching to friend group
      const friendsSet = new Set(availableFriends.map(f => f.uid));
      setSelectedMemberUids(prev => {
        const filtered = prev.filter(uid => friendsSet.has(uid));
        return filtered.slice(0, 20);
      });
    } else {
      // Enforce 30 member limit if switching to general
      setSelectedMemberUids(prev => prev.slice(0, 30));
    }
    setGroupErrorMsg('');
  };

  const confirmDeleteGroup = () => {
    if (groupToDelete) {
      deleteFriendGroup(groupToDelete.id);
      setFriendGroups(prev => prev.filter(g => g.id !== groupToDelete.id));
      setSelectedGroupIds(prev => prev.filter(id => id !== groupToDelete.id));
      showToast(`Friend group "${groupToDelete.name}" deleted`);
      setGroupToDelete(null);
    }
  };

  const toggleMemberSelection = (uid: string) => {
    setSelectedMemberUids(prev => {
      if (prev.includes(uid)) {
        setGroupErrorMsg('');
        return prev.filter(id => id !== uid);
      } else {
        const maxMembers = groupTypeInput === 'friend' ? 20 : 30;
        if (prev.length >= maxMembers) {
          setGroupErrorMsg(`A ${groupTypeInput === 'friend' ? "Friend Group" : "General Group"} is limited to ${maxMembers} people.`);
          return prev;
        }
        setGroupErrorMsg('');
        return [...prev, uid];
      }
    });
  };

  const filtered = listings.filter((item) => {
    // Filter by status (all / uploaded / draft)
    if (filterStatus !== 'all' && item.status !== filterStatus) return false;
    
    // Filter by visibility (all / public / friends / custom_group / only_me)
    if (filterVisibility !== 'all') {
      const itemVis = item.visibility || 'public';
      if (filterVisibility !== itemVis) return false;
    }

    // Filter by search query
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      item.title.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 pb-16 text-left">
      {/* Toast Notification */}
      <AnimatePresence>
        {saveToastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 bg-neutral-950 text-white border border-neutral-800 px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-medium"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{saveToastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Bar Header */}
      <div className="border border-neutral-200 bg-white rounded-3xl p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-2xs">
        <div>
          <h1 className="font-serif-lux text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight">
            My Uploads &amp; Drafts
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Upload New Listing */}
          <button
            type="button"
            onClick={handleOpenCreateModal}
            className="flex items-center gap-1.5 rounded-xl bg-neutral-950 text-white px-4 py-2 text-xs font-bold hover:bg-neutral-800 transition-colors shadow-2xs cursor-pointer active:scale-[0.98]"
          >
            <Plus className="h-4 w-4" />
            <span>Upload Goods &amp; Services</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Privacy Controls */}
      <div className="space-y-3">
        {/* Row 1: Status Tabs & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center bg-white border border-neutral-200 p-1 rounded-2xl shrink-0 shadow-2xs overflow-x-auto">
            <button
              type="button"
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                filterStatus === 'all'
                  ? 'bg-neutral-900 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              All Items ({listings.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('uploaded')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                filterStatus === 'uploaded'
                  ? 'bg-neutral-900 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              Live Uploads ({listings.filter(l => l.status === 'uploaded').length})
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('draft')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                filterStatus === 'draft'
                  ? 'bg-neutral-900 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              Drafts ({listings.filter(l => l.status === 'draft').length})
            </button>
          </div>

          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, category..."
              className="w-full pl-9 pr-3 py-2 bg-white border border-neutral-200 rounded-2xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black shadow-2xs"
            />
          </div>
        </div>

        {/* Row 2: Privacy / Audience Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider mr-1 whitespace-nowrap shrink-0">
            Audience:
          </span>
          <button
            type="button"
            onClick={() => setFilterVisibility('all')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
              filterVisibility === 'all'
                ? 'bg-neutral-900 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            All Audiences
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('public')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'public'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Globe className="w-3 h-3" />
            <span>Public ({listings.filter(l => (l.visibility || 'public') === 'public').length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('friends')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'friends'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Users className="w-3 h-3" />
            <span>Friends Only ({listings.filter(l => l.visibility === 'friends').length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('custom_group')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'custom_group'
                ? 'bg-amber-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Shield className="w-3 h-3" />
            <span>Custom Groups ({listings.filter(l => l.visibility === 'custom_group').length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('only_me')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'only_me'
                ? 'bg-slate-800 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Lock className="w-3 h-3" />
            <span>Private / Only Me ({listings.filter(l => l.visibility === 'only_me').length})</span>
          </button>
        </div>
      </div>

      {/* Grid of Listings */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 border border-neutral-200 rounded-3xl p-6 bg-white shadow-2xs space-y-3">
          <Package className="w-8 h-8 text-neutral-400 mx-auto" />
          <p className="text-neutral-500 text-sm">No uploads or drafts found in this category or privacy filter.</p>
          <button
            type="button"
            onClick={handleOpenCreateModal}
            className="text-xs text-neutral-900 font-bold hover:underline cursor-pointer"
          >
            + Create First Listing
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((item) => {
            const vis = item.visibility || 'public';
            return (
              <div
                key={item.id}
                className="border border-neutral-200 bg-white rounded-3xl overflow-hidden flex flex-col justify-between hover:border-neutral-400 transition-all shadow-2xs"
              >
                <div>
                  {/* Media Preview */}
                  <div className="relative h-44 w-full bg-neutral-950 overflow-hidden">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center text-neutral-600">
                        <ImageIcon className="h-8 w-8" />
                      </div>
                    )}

                    <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg backdrop-blur-md ${
                        item.listingIntent === 'buy'
                          ? 'bg-blue-600/90 text-white border border-blue-400'
                          : 'bg-emerald-600/90 text-white border border-emerald-400'
                      }`}>
                        {item.listingIntent === 'buy' ? 'WANTED' : 'OFFERING'}
                      </span>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg backdrop-blur-md ${
                        item.status === 'uploaded'
                          ? 'bg-neutral-900/90 text-white border border-neutral-700'
                          : 'bg-amber-500/90 text-neutral-950 border border-amber-300 font-black'
                      }`}>
                        {item.status === 'uploaded' ? 'LIVE' : 'DRAFT'}
                      </span>
                    </div>

                    {/* Interactive Audience Privacy Badge on Card */}
                    <div className="absolute top-2.5 right-2.5">
                      <button
                        type="button"
                        onClick={(e) => handleOpenAudienceModal(item, e)}
                        title="Click to edit listing audience / privacy"
                        className={`h-6 px-2.5 rounded-full text-[10px] font-bold flex items-center gap-1 shadow-md backdrop-blur-md cursor-pointer transition-transform hover:scale-105 active:scale-95 border ${
                          vis === 'public'
                            ? 'bg-emerald-500/95 text-white border-emerald-400'
                            : vis === 'friends'
                            ? 'bg-blue-600/95 text-white border-blue-400'
                            : vis === 'custom_group'
                            ? 'bg-amber-500 text-neutral-950 border-amber-300 font-black'
                            : 'bg-neutral-900/95 text-white border-neutral-700'
                        }`}
                      >
                        {vis === 'public' ? (
                          <>
                            <Globe className="w-3 h-3 shrink-0" />
                            <span>Public</span>
                          </>
                        ) : vis === 'friends' ? (
                          <>
                            <Users className="w-3 h-3 shrink-0" />
                            <span>Friends</span>
                          </>
                        ) : vis === 'custom_group' ? (
                          <>
                            <Shield className="w-3 h-3 shrink-0" />
                            <span className="truncate max-w-[80px]">
                              {item.allowedGroupNames?.[0] || 'Group'}
                            </span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-3 h-3 shrink-0" />
                            <span>Only Me</span>
                          </>
                        )}
                        <Edit3 className="w-2.5 h-2.5 ml-0.5 opacity-80" />
                      </button>
                    </div>
                  </div>

                  <div className="p-4 space-y-2.5">
                    <div className="flex items-center justify-between text-[11px] text-neutral-500">
                      <span className="font-mono uppercase font-bold text-neutral-700">{item.category}</span>
                      <span className="capitalize font-semibold text-neutral-500">{item.itemType}</span>
                    </div>

                    <h3 className="font-serif-lux text-base font-bold text-neutral-900 tracking-tight line-clamp-1">
                      {item.title}
                    </h3>

                    <p className="text-xs text-neutral-600 line-clamp-2">
                      {item.description}
                    </p>

                    {/* Price and Badges */}
                    <div className="pt-2 border-t border-neutral-100 flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-neutral-900">
                        ${(item.primaryPriceUSD || 0).toLocaleString()}
                      </span>
                      <div className="flex items-center gap-1">
                        {item.acceptedSettlements?.includes('barter') && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                            ⇄ BARTER
                          </span>
                        )}
                        {item.primaryCurrency && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-800 border border-neutral-200 font-bold uppercase">
                            {item.primaryCurrency}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="p-4 pt-0 flex items-center gap-2 border-t border-neutral-100 mt-3">
                  <button
                    type="button"
                    onClick={() => handleTogglePublish(item)}
                    className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                      item.status === 'uploaded'
                        ? 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200 border border-neutral-200'
                        : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-2xs'
                    }`}
                  >
                    <Check className="h-3.5 w-3.5" />
                    <span>{item.status === 'uploaded' ? 'Unpublish' : 'Publish Live'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOpenEditModal(item)}
                    className="p-2 rounded-xl border border-neutral-200 bg-white text-neutral-700 hover:text-black hover:border-neutral-300 transition-colors cursor-pointer"
                    title="Edit listing details"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDeleteListing(item.id)}
                    className="p-2 rounded-xl border border-neutral-200 bg-white text-neutral-400 hover:text-red-600 hover:border-red-200 transition-colors cursor-pointer"
                    title="Delete listing"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit Listing Modal */}
      {isModalOpen && (
        <CreateListingDraftModal
          isOpen={isModalOpen}
          currentUser={currentUser}
          initialDraft={activeModalListing}
          onClose={() => setIsModalOpen(false)}
          onSaved={() => {
            setIsModalOpen(false);
            refreshListings();
            showToast('Listing updated successfully');
          }}
        />
      )}

      {/* ================= MODAL: AUDIENCE & PRIVACY SELECTOR ================= */}
      <AnimatePresence>
        {isAudienceModalOpen && selectedListingForAudience && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-md w-full shadow-2xl space-y-5 text-left"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-neutral-900 text-white">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-neutral-900">Select Listing Audience</h3>
                    <p className="text-[11px] text-neutral-500 line-clamp-1">
                      {selectedListingForAudience.title}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAudienceModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Audience Options */}
              <div className="space-y-2.5">
                {/* 1. Public */}
                <label
                  onClick={() => setSelectedVisibility('public')}
                  className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                    selectedVisibility === 'public'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 mt-0.5 shrink-0 border border-emerald-200">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-neutral-900">Public (The World)</span>
                      <input
                        type="radio"
                        name="visibility-page"
                        checked={selectedVisibility === 'public'}
                        onChange={() => setSelectedVisibility('public')}
                        className="accent-black"
                      />
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Visible to everyone across the global marketplace and public profile views.
                    </p>
                  </div>
                </label>

                {/* 2. Friends Only */}
                <label
                  onClick={() => setSelectedVisibility('friends')}
                  className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                    selectedVisibility === 'friends'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-blue-50 text-blue-700 mt-0.5 shrink-0 border border-blue-200">
                    <Users className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-neutral-900">Friends Only</span>
                      <input
                        type="radio"
                        name="visibility-page"
                        checked={selectedVisibility === 'friends'}
                        onChange={() => setSelectedVisibility('friends')}
                        className="accent-black"
                      />
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Only your confirmed mutual friends on Final Finance can see and submit barter trades.
                    </p>
                  </div>
                </label>

                {/* 3. Specific Friend Group */}
                <div
                  className={`p-3 rounded-2xl border-2 transition-all ${
                    selectedVisibility === 'custom_group'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <label
                    onClick={() => setSelectedVisibility('custom_group')}
                    className="flex items-start gap-3 cursor-pointer"
                  >
                    <div className="p-2 rounded-xl bg-amber-50 text-amber-800 mt-0.5 shrink-0 border border-amber-200">
                      <Shield className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-neutral-900">Specific Friend Group</span>
                        <input
                          type="radio"
                          name="visibility-page"
                          checked={selectedVisibility === 'custom_group'}
                          onChange={() => setSelectedVisibility('custom_group')}
                          className="accent-black"
                        />
                      </div>
                      <p className="text-[11px] text-neutral-500 mt-0.5">
                        Only members of your chosen friend group(s) will have access.
                      </p>
                    </div>
                  </label>

                  {/* Friend Group Checkboxes when selected */}
                  {selectedVisibility === 'custom_group' && (
                    <div className="mt-3 pt-3 border-t border-neutral-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-neutral-800 uppercase tracking-wider">
                          Choose Friend Groups:
                        </span>
                        <button
                          type="button"
                          onClick={() => handleOpenCreateGroup()}
                          className="text-[11px] font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          <span>New Group</span>
                        </button>
                      </div>

                      {friendGroups.length === 0 ? (
                        <div className="p-3 rounded-xl bg-white border border-neutral-200 text-center space-y-1.5">
                          <p className="text-xs text-neutral-500">You have no custom friend groups yet.</p>
                          <button
                            type="button"
                            onClick={() => handleOpenCreateGroup()}
                            className="px-3 py-1 rounded-lg bg-neutral-900 text-white text-xs font-semibold cursor-pointer"
                          >
                            + Create First Friend Group
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                          {friendGroups.map((group) => {
                            const isChecked = selectedGroupIds.includes(group.id);
                            return (
                              <div
                                key={group.id}
                                onClick={() => toggleGroupSelection(group.id)}
                                className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                                  isChecked
                                    ? 'bg-amber-500/10 border-amber-400 text-neutral-950 font-semibold'
                                    : 'bg-white border-neutral-200 text-neutral-700 hover:border-neutral-300'
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <div
                                    className="w-2.5 h-2.5 rounded-full shrink-0"
                                    style={{ backgroundColor: group.color || '#f59e0b' }}
                                  />
                                  <span>{group.name}</span>
                                  <span className="text-[10px] text-neutral-400 font-mono">
                                    ({group.memberUids.length} friends)
                                  </span>
                                </div>
                                {isChecked ? (
                                  <CheckSquare className="w-4 h-4 text-amber-600" />
                                ) : (
                                  <Square className="w-4 h-4 text-neutral-300" />
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* 4. Only Me */}
                <label
                  onClick={() => setSelectedVisibility('only_me')}
                  className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                    selectedVisibility === 'only_me'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-neutral-100 text-neutral-700 mt-0.5 shrink-0 border border-neutral-200">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-neutral-900">Only Me (Private Vault)</span>
                      <input
                        type="radio"
                        name="visibility-page"
                        checked={selectedVisibility === 'only_me'}
                        onChange={() => setSelectedVisibility('only_me')}
                        className="accent-black"
                      />
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Completely private allocation. Only you can view this item in your personal depository.
                    </p>
                  </div>
                </label>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsAudienceModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveAudience}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Apply Audience</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: FRIEND GROUPS MANAGER ================= */}
      <AnimatePresence>
        {isGroupManagerModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-lg w-full shadow-2xl space-y-5 text-left max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-neutral-900 text-white">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-neutral-900">Custom Friend Groups</h3>
                    <p className="text-[11px] text-neutral-500">
                      Create circles from your friends to share specific private listings
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsGroupManagerModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Create Group CTA Banner */}
              <button
                type="button"
                onClick={() => handleOpenCreateGroup()}
                className="w-full min-h-[44px] px-4 py-2.5 rounded-2xl bg-neutral-900 hover:bg-black text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-[0.99]"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Friend Group</span>
              </button>

              {/* Groups List */}
              <div className="space-y-3">
                {friendGroups.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-2">
                    <Users className="w-8 h-8 text-neutral-400 mx-auto" />
                    <h4 className="font-bold text-xs text-neutral-800">No Friend Groups Created</h4>
                    <p className="text-[11px] text-neutral-500 max-w-xs mx-auto">
                      Organize your friends into specialized circles (e.g. Zurich Bullion Syndicate, Tech Partners) for tailored listing access.
                    </p>
                  </div>
                ) : (
                  friendGroups.map((group) => (
                    <div
                      key={group.id}
                      className="p-4 rounded-2xl border border-neutral-200/90 bg-white hover:border-neutral-300 transition-all space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3.5 h-3.5 rounded-full shrink-0"
                            style={{ backgroundColor: group.color || '#f59e0b' }}
                          />
                          <div>
                            <h4 className="font-bold text-xs text-neutral-900">{group.name}</h4>
                            {group.description && (
                              <p className="text-[11px] text-neutral-500">{group.description}</p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleOpenCreateGroup(group)}
                            title="Edit group members and details"
                            className="p-1.5 rounded-lg text-neutral-500 hover:text-black hover:bg-neutral-100 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteGroup(group.id, group.name)}
                            title="Delete group"
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Group Member Count & Chips */}
                      <div className="pt-2 border-t border-neutral-100 flex items-center justify-between text-[11px]">
                        <span className="font-mono text-neutral-500">
                          {group.memberUids.length} {group.memberUids.length === 1 ? 'member' : 'members'}
                        </span>
                        {group.memberHandles && group.memberHandles.length > 0 && (
                          <div className="flex items-center gap-1 font-mono text-neutral-400">
                            {group.memberHandles.slice(0, 3).map(h => (
                              <span key={h} className="bg-neutral-100 px-1.5 py-0.5 rounded-md text-neutral-700 text-[10px]">
                                @{h}
                              </span>
                            ))}
                            {group.memberHandles.length > 3 && (
                              <span className="text-[10px]">+{group.memberHandles.length - 3}</span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Close Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setIsGroupManagerModalOpen(false)}
                  className="w-full min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: CREATE / EDIT FRIEND GROUP ================= */}
      <AnimatePresence>
        {isCreateGroupModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-md w-full shadow-2xl space-y-4 text-left max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-neutral-900 text-white">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-neutral-900">
                      {editingGroup ? 'Edit Friend Group' : 'Create Friend Group'}
                    </h3>
                    <p className="text-[11px] text-neutral-500">Pick friends to include in this circle</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCreateGroupModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Group Type Selection */}
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Grouping Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleSetGroupType('friend')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      groupTypeInput === 'friend'
                        ? 'bg-black text-white border-black shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    <span>Friend Group</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetGroupType('general')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      groupTypeInput === 'general'
                        ? 'bg-black text-white border-black shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    <span>General Group</span>
                  </button>
                </div>
              </div>

              {/* Group Avatar URL */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-800 block">Group Image (Upload or URL)</label>
                <div className="flex gap-2">
                  <div 
                    onClick={() => groupImageFileRef.current?.click()}
                    className="w-10 h-10 rounded-xl bg-neutral-100 flex items-center justify-center shrink-0 border border-neutral-200 overflow-hidden cursor-pointer hover:bg-neutral-200 transition-colors group"
                  >
                    {groupAvatarInput ? (
                      <img src={groupAvatarInput} alt="Group preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="flex flex-col items-center">
                        <Upload className="w-3.5 h-3.5 text-neutral-400 group-hover:text-black" />
                        <span className="text-[7px] text-neutral-400 group-hover:text-black mt-0.5 uppercase font-bold">Upload</span>
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={groupImageFileRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <div className="flex-1 space-y-1">
                    <input
                      type="text"
                      value={groupAvatarInput}
                      onChange={(e) => setGroupAvatarInput(e.target.value)}
                      placeholder="Paste image URL here..."
                      className="w-full px-3 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                    />
                    {groupAvatarInput && (
                      <button
                        type="button"
                        onClick={() => setGroupAvatarInput('')}
                        className="text-[9px] text-red-500 hover:text-red-700 font-semibold cursor-pointer"
                      >
                        Remove Image
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Group Name Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-neutral-800 block">Group Name *</label>
                <input
                  type="text"
                  value={groupNameInput}
                  onChange={(e) => setGroupNameInput(e.target.value)}
                  placeholder="e.g. Zurich Bullion Syndicate, VIP Horology"
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />
              </div>

              {/* Description Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-neutral-800 block">Description (Optional)</label>
                <input
                  type="text"
                  value={groupDescInput}
                  onChange={(e) => setGroupDescInput(e.target.value)}
                  placeholder="e.g. Private circle for verified bullion swaps"
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />
              </div>

              {/* Color Tag Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-800 block">Group Color Tag</label>
                <div className="flex items-center gap-2">
                  {['#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#64748b'].map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setGroupColorInput(color)}
                      className={`w-6 h-6 rounded-full cursor-pointer transition-transform ${
                        groupColorInput === color ? 'scale-125 ring-2 ring-neutral-950 ring-offset-2' : 'hover:scale-110'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              {/* Friend Picker List */}
              <div className="space-y-2 pt-2 border-t border-neutral-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-800 block">
                    Add Friends ({selectedMemberUids.length} selected)
                  </label>
                  {selectedMemberUids.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedMemberUids([])}
                      className="text-[11px] text-neutral-500 hover:text-black cursor-pointer underline"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {/* Friend Search Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                  <input
                    type="text"
                    value={memberSearchQuery}
                    onChange={(e) => setMemberSearchQuery(e.target.value)}
                    placeholder={groupTypeInput === 'friend' ? "Search your network friends..." : "Search any user on platform..."}
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                  />
                </div>

                {/* Group Error Message */}
                {groupErrorMsg && (
                  <div className="mt-2 mb-2 p-2 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100 flex items-center justify-between">
                    <span>{groupErrorMsg}</span>
                    <button type="button" onClick={() => setGroupErrorMsg('')} className="p-0.5 hover:bg-red-100 rounded-full text-red-700">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Friends Checkbox List */}
                <div className="mt-2 space-y-1 max-h-44 overflow-y-auto pr-1">
                  {selectableUsersForGroup.length === 0 ? (
                    <div className="p-4 text-center text-xs text-neutral-400">
                      {groupTypeInput === 'friend' 
                        ? "You don't have any confirmed friends yet. Search for members to add them as friends first."
                        : "No users found in your network. Use 'Discover' to find and follow people."
                      }
                    </div>
                  ) : (
                    selectableUsersForGroup
                      .filter(f => 
                        f.name.toLowerCase().includes(memberSearchQuery.toLowerCase()) ||
                        f.userId.toLowerCase().includes(memberSearchQuery.toLowerCase())
                      )
                      .map((friend) => {
                      const isChecked = selectedMemberUids.includes(friend.uid);
                      return (
                        <div
                          key={friend.uid}
                          onClick={() => toggleMemberSelection(friend.uid)}
                          className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                            isChecked
                              ? 'bg-neutral-900 text-white border-neutral-900 font-medium'
                              : 'bg-white border-neutral-200 text-neutral-800 hover:border-neutral-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-neutral-200 overflow-hidden shrink-0 flex items-center justify-center font-bold text-[10px]">
                              {friend.avatarUrl ? (
                                <img src={friend.avatarUrl} alt={friend.name} className="w-full h-full object-cover" />
                              ) : (
                                friend.name.charAt(0).toUpperCase()
                              )}
                            </div>
                            <div>
                              <p className="font-semibold leading-tight">{friend.name}</p>
                              <p className={`text-[10px] font-mono ${isChecked ? 'text-neutral-300' : 'text-neutral-400'}`}>
                                @{friend.userId}
                              </p>
                            </div>
                          </div>

                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Square className="w-4 h-4 text-neutral-300" />
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsCreateGroupModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveGroup}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{editingGroup ? 'Save Changes' : 'Create Group'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL 6: CONFIRM DELETE GROUP ================= */}
      {groupToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-sm w-full overflow-hidden flex flex-col">
            <div className="p-5 border-b border-neutral-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-black">Delete Group</h3>
                <p className="text-[11px] text-neutral-400">This action cannot be undone.</p>
              </div>
            </div>
            <div className="p-5">
              <p className="text-xs text-neutral-600 leading-relaxed">
                Are you sure you want to delete the <span className="font-bold text-neutral-900">"{groupToDelete.name}"</span> group? Members will not be removed from your connections, but this grouping will be permanently lost.
              </p>
            </div>
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setGroupToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteGroup}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors shadow-xs cursor-pointer"
              >
                Delete Group
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
