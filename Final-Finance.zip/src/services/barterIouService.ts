import {
  getIdentityAliases,
  enqueueUserNotification,
} from './socialService';

function normalizeUserKey(raw: string): string {
  return raw.trim().toLowerCase().replace(/^@/, '').replace(/[^a-z0-9]/g, '');
}

export const BARTER_IOUS_STORAGE_KEY = 'ff_barter_ious_v1';
export const BARTER_IOUS_UPDATED_EVENT = 'final_finance_barter_ious_updated';

export type BarterIOUSource = 'marketplace' | 'auction' | 'otc_chat' | 'direct';

export type BarterIOUStatus =
  | 'pending_both'
  | 'awaiting_counterparty'
  | 'awaiting_initiator'
  | 'confirmed';

export interface BarterIOUParty {
  id: string;
  uid?: string;
  handle: string;
  name: string;
  obligationDescription: string;
}

export interface BarterIOUHistoryEntry {
  actorId: string;
  actorName: string;
  action: 'created' | 'confirmed';
  note?: string;
  timestamp: string;
}

export interface BarterIOU {
  id: string;
  referenceCode: string;
  source: BarterIOUSource;
  proposalId?: string;
  listingId?: string;
  listingTitle: string;
  estimatedValueUSD: number;
  sweetenerSummary?: string;
  createdAt: string;
  updatedAt: string;
  dueDate: string;
  initiator: BarterIOUParty;
  counterparty: BarterIOUParty;
  initiatorConfirmed: boolean;
  initiatorConfirmedAt?: string;
  counterpartyConfirmed: boolean;
  counterpartyConfirmedAt?: string;
  status: BarterIOUStatus;
  history: BarterIOUHistoryEntry[];
}

export interface UserIdentityLike {
  id?: string;
  uid?: string;
  handle?: string;
  name?: string;
  email?: string;
}

function buildUserIdentityKeys(user?: UserIdentityLike | null): Set<string> {
  const keys = new Set<string>();
  if (!user) return keys;
  const rawTokens = [user.id, user.uid, user.handle, user.name, user.email].filter(
    (v): v is string => typeof v === 'string' && v.trim().length > 0
  );

  for (const token of rawTokens) {
    const clean = token.trim().toLowerCase().replace(/^@/, '');
    if (!clean) continue;
    keys.add(clean);
    keys.add(clean.replace(/^user[-_]/, ''));
    const norm = normalizeUserKey(clean);
    if (norm) keys.add(norm);
    for (const alias of getIdentityAliases(token)) {
      const aClean = alias.trim().toLowerCase().replace(/^@/, '');
      if (!aClean) continue;
      keys.add(aClean);
      keys.add(aClean.replace(/^user[-_]/, ''));
      const aNorm = normalizeUserKey(aClean);
      if (aNorm) keys.add(aNorm);
    }
  }
  return keys;
}

export function doesPartyMatchUser(
  party: Pick<BarterIOUParty, 'id' | 'uid' | 'handle' | 'name'>,
  user?: UserIdentityLike | null
): boolean {
  if (!user) return false;
  const userKeys = buildUserIdentityKeys(user);
  if (userKeys.size === 0) return false;
  const partyKeys = buildUserIdentityKeys({
    id: party.id,
    uid: party.uid,
    handle: party.handle,
    name: party.name,
  });
  for (const pk of partyKeys) {
    if (userKeys.has(pk)) return true;
  }
  return false;
}

export function getViewerRoleInBarterIOU(
  iou: BarterIOU,
  user?: UserIdentityLike | null
): 'initiator' | 'counterparty' | 'observer' {
  if (doesPartyMatchUser(iou.initiator, user)) return 'initiator';
  if (doesPartyMatchUser(iou.counterparty, user)) return 'counterparty';
  return 'observer';
}

function computeStatus(
  initiatorConfirmed: boolean,
  counterpartyConfirmed: boolean
): BarterIOUStatus {
  if (initiatorConfirmed && counterpartyConfirmed) return 'confirmed';
  if (initiatorConfirmed && !counterpartyConfirmed) return 'awaiting_counterparty';
  if (!initiatorConfirmed && counterpartyConfirmed) return 'awaiting_initiator';
  return 'pending_both';
}

function buildDefaultDueDate(daysAhead = 14): string {
  const dt = new Date(Date.now() + daysAhead * 24 * 60 * 60 * 1000);
  return dt.toISOString().split('T')[0];
}

function getDefaultSeedBarterIOUs(): BarterIOU[] {
  const now = new Date().toISOString();
  return [
    {
      id: 'iou-barter-seed-1',
      referenceCode: 'IOU-BRT-1041',
      source: 'direct',
      listingTitle: 'Website Redesign ↔ 3 Months Accounting',
      estimatedValueUSD: 4500,
      createdAt: now,
      updatedAt: now,
      dueDate: buildDefaultDueDate(21),
      initiator: {
        id: 'super_admin_ranma',
        uid: 'super_admin_ranma',
        handle: 'ranma',
        name: 'Ranma',
        obligationDescription: 'Website Redesign & UI/UX Client Dashboard',
      },
      counterparty: {
        id: 'alex_chen',
        uid: 'user-alex_chen',
        handle: 'alex_chen',
        name: 'Alex Chen',
        obligationDescription: '3 Months Bookkeeping & Sovereign Tax Accounting',
      },
      initiatorConfirmed: false,
      counterpartyConfirmed: true,
      counterpartyConfirmedAt: now,
      status: 'awaiting_initiator',
      history: [
        {
          actorId: 'alex_chen',
          actorName: 'Alex Chen',
          action: 'created',
          note: 'Mutual barter IOU initialized for Website Redesign ↔ 3 Months Accounting.',
          timestamp: now,
        },
        {
          actorId: 'alex_chen',
          actorName: 'Alex Chen',
          action: 'confirmed',
          note: 'Alex Chen confirmed accounting retainer readiness.',
          timestamp: now,
        },
      ],
    },
    {
      id: 'iou-barter-seed-2',
      referenceCode: 'IOU-BRT-1042',
      source: 'direct',
      listingTitle: 'Brand Logo Package ↔ Promotional Video',
      estimatedValueUSD: 2800,
      createdAt: now,
      updatedAt: now,
      dueDate: buildDefaultDueDate(14),
      initiator: {
        id: 'admin_awesomedbz',
        uid: 'admin_awesomedbz',
        handle: 'awesomedbz',
        name: 'Awesome DBZ',
        obligationDescription: 'Brand Logo Package & Vector Guidelines Booklet',
      },
      counterparty: {
        id: 'user_sam',
        uid: 'user-sam',
        handle: 'sam_carter',
        name: 'Sam Carter',
        obligationDescription: 'Promotional 4K Launch Video Production',
      },
      initiatorConfirmed: false,
      counterpartyConfirmed: false,
      status: 'pending_both',
      history: [
        {
          actorId: 'user_sam',
          actorName: 'Sam Carter',
          action: 'created',
          note: 'Mutual barter IOU initialized for Brand Logo Package ↔ Promotional Video.',
          timestamp: now,
        },
      ],
    },
  ];
}

function loadAllBarterIOUsRaw(): BarterIOU[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(BARTER_IOUS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    } else {
      const seeded = getDefaultSeedBarterIOUs();
      localStorage.setItem(BARTER_IOUS_STORAGE_KEY, JSON.stringify(seeded));
      return seeded;
    }
  } catch (err) {
    console.warn('Failed reading barter IOUs:', err);
  }
  return [];
}

function saveAllBarterIOUsRaw(list: BarterIOU[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(BARTER_IOUS_STORAGE_KEY, JSON.stringify(list));
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent(BARTER_IOUS_UPDATED_EVENT));
    }, 0);
  } catch (err) {
    console.error('Failed saving barter IOUs:', err);
  }
}

export function getAllBarterIOUs(): BarterIOU[] {
  return loadAllBarterIOUsRaw().sort(
    (a, b) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime()
  );
}

export function getBarterIOUsForUser(user?: UserIdentityLike | null): BarterIOU[] {
  const all = getAllBarterIOUs();
  if (!user) return [];
  const matched = all.filter(
    (iou) =>
      doesPartyMatchUser(iou.initiator, user) ||
      doesPartyMatchUser(iou.counterparty, user)
  );
  return matched;
}

export interface CreateBarterIOUParams {
  source: BarterIOUSource;
  proposalId?: string;
  listingId?: string;
  listingTitle: string;
  estimatedValueUSD: number;
  sweetenerSummary?: string;
  dueDate?: string;
  initiator: {
    id: string;
    uid?: string;
    handle?: string;
    name: string;
    obligationDescription: string;
  };
  counterparty: {
    id: string;
    uid?: string;
    handle?: string;
    name: string;
    obligationDescription: string;
  };
  notifyParties?: boolean;
}

export function createBarterIOU(params: CreateBarterIOUParams): BarterIOU {
  const current = loadAllBarterIOUsRaw();

  // Deduplicate if an IOU was already generated for the same proposalId
  if (params.proposalId) {
    const existing = current.find((i) => i.proposalId === params.proposalId);
    if (existing) return existing;
  }

  const now = new Date().toISOString();
  const suffix = Math.floor(1000 + Math.random() * 9000);
  const newIOU: BarterIOU = {
    id: `iou-brt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    referenceCode: `IOU-BRT-${suffix}`,
    source: params.source,
    proposalId: params.proposalId,
    listingId: params.listingId,
    listingTitle: params.listingTitle,
    estimatedValueUSD: Math.max(0, Math.round((Number(params.estimatedValueUSD) || 0) * 100) / 100),
    sweetenerSummary: params.sweetenerSummary?.trim() || undefined,
    createdAt: now,
    updatedAt: now,
    dueDate: params.dueDate || buildDefaultDueDate(14),
    initiator: {
      id: params.initiator.id,
      uid: params.initiator.uid,
      handle: (params.initiator.handle || params.initiator.id).replace(/^@/, ''),
      name: params.initiator.name || 'Peer Member',
      obligationDescription: params.initiator.obligationDescription,
    },
    counterparty: {
      id: params.counterparty.id,
      uid: params.counterparty.uid,
      handle: (params.counterparty.handle || params.counterparty.id).replace(/^@/, ''),
      name: params.counterparty.name || 'Counterparty Peer',
      obligationDescription: params.counterparty.obligationDescription,
    },
    initiatorConfirmed: false,
    counterpartyConfirmed: false,
    status: 'pending_both',
    history: [
      {
        actorId: params.initiator.id,
        actorName: params.initiator.name,
        action: 'created',
        note: `Mutual Barter IOU created for both ${params.initiator.name} and ${params.counterparty.name}.`,
        timestamp: now,
      },
    ],
  };

  saveAllBarterIOUsRaw([newIOU, ...current]);

  if (params.notifyParties !== false) {
    const initTargets = [
      newIOU.initiator.id,
      newIOU.initiator.uid || '',
      newIOU.initiator.handle,
    ].filter(Boolean);
    const cpTargets = [
      newIOU.counterparty.id,
      newIOU.counterparty.uid || '',
      newIOU.counterparty.handle,
    ].filter(Boolean);

    if (initTargets.length > 0) {
      enqueueUserNotification(initTargets, {
        title: `📜 Barter IOU Issued (${newIOU.referenceCode})`,
        description: `Barter IOU with ${newIOU.counterparty.name} for "${newIOU.listingTitle}" created. Track and confirm fulfillment in Barter IOUs.`,
        type: 'trade',
        targetTab: 'qrcodes',
        targetId: newIOU.id,
        amount: newIOU.estimatedValueUSD,
        currency: 'USD',
      });
    }

    if (cpTargets.length > 0) {
      enqueueUserNotification(cpTargets, {
        title: `📜 Barter IOU Created for You (${newIOU.referenceCode})`,
        description: `${newIOU.initiator.name} initiated a barter exchange for "${newIOU.listingTitle}". Review & confirm your side in Barter IOUs.`,
        type: 'trade',
        targetTab: 'qrcodes',
        targetId: newIOU.id,
        amount: newIOU.estimatedValueUSD,
        currency: 'USD',
      });
    }
  }

  return newIOU;
}

export function confirmBarterIOU(
  iouId: string,
  user: UserIdentityLike,
  options?: { sideOverride?: 'initiator' | 'counterparty'; note?: string }
): { success: boolean; iou?: BarterIOU; error?: string; roleConfirmed?: 'initiator' | 'counterparty' } {
  const all = loadAllBarterIOUsRaw();
  const idx = all.findIndex((i) => i.id === iouId);
  if (idx === -1) {
    return { success: false, error: 'Barter IOU record could not be found.' };
  }

  const target = all[idx];
  const detectedRole = getViewerRoleInBarterIOU(target, user);
  const roleToConfirm =
    options?.sideOverride || (detectedRole !== 'observer' ? detectedRole : null);

  if (!roleToConfirm) {
    return {
      success: false,
      error: 'Only the two parties in this barter exchange can confirm this IOU.',
    };
  }

  if (roleToConfirm === 'initiator' && target.initiatorConfirmed) {
    return { success: true, iou: target, roleConfirmed: 'initiator' };
  }
  if (roleToConfirm === 'counterparty' && target.counterpartyConfirmed) {
    return { success: true, iou: target, roleConfirmed: 'counterparty' };
  }

  const now = new Date().toISOString();
  const nextInitiatorConfirmed =
    roleToConfirm === 'initiator' ? true : target.initiatorConfirmed;
  const nextCounterpartyConfirmed =
    roleToConfirm === 'counterparty' ? true : target.counterpartyConfirmed;
  const nextStatus = computeStatus(nextInitiatorConfirmed, nextCounterpartyConfirmed);

  const actorName =
    user.name ||
    (roleToConfirm === 'initiator' ? target.initiator.name : target.counterparty.name);
  const actorId =
    user.id ||
    (roleToConfirm === 'initiator' ? target.initiator.id : target.counterparty.id);

  const updated: BarterIOU = {
    ...target,
    initiatorConfirmed: nextInitiatorConfirmed,
    initiatorConfirmedAt:
      roleToConfirm === 'initiator' ? now : target.initiatorConfirmedAt,
    counterpartyConfirmed: nextCounterpartyConfirmed,
    counterpartyConfirmedAt:
      roleToConfirm === 'counterparty' ? now : target.counterpartyConfirmedAt,
    status: nextStatus,
    updatedAt: now,
    history: [
      ...target.history,
      {
        actorId,
        actorName,
        action: 'confirmed',
        note:
          options?.note ||
          (nextStatus === 'confirmed'
            ? `${actorName} confirmed their side — both parties have now confirmed & settled this Barter IOU.`
            : `${actorName} confirmed fulfillment on their side. Awaiting counterparty confirmation.`),
        timestamp: now,
      },
    ],
  };

  all[idx] = updated;
  saveAllBarterIOUsRaw(all);

  // Notify the other party of confirmation progress
  const otherParty = roleToConfirm === 'initiator' ? updated.counterparty : updated.initiator;
  const otherTargets = [otherParty.id, otherParty.uid || '', otherParty.handle].filter(Boolean);
  if (otherTargets.length > 0) {
    enqueueUserNotification(otherTargets, {
      title:
        nextStatus === 'confirmed'
          ? `✅ Barter IOU Settled by Both Parties (${updated.referenceCode})`
          : `🤝 Barter IOU Confirmed by ${actorName} (${updated.referenceCode})`,
      description:
        nextStatus === 'confirmed'
          ? `Both parties confirmed "${updated.listingTitle}". The mutual barter IOU is now fully settled.`
          : `${actorName} confirmed their side of "${updated.listingTitle}". Please confirm your side to settle the Barter IOU.`,
      type: 'trade',
      targetTab: 'qrcodes',
      targetId: updated.id,
      amount: updated.estimatedValueUSD,
      currency: 'USD',
    });
  }

  return { success: true, iou: updated, roleConfirmed: roleToConfirm };
}
