import React, { useState, useEffect, useMemo } from 'react';
import { StockItem, StockNewsItem } from '../../types/stocks';
import { getAllCombinedStockNews } from '../../data/stocksData';
import { 
  Newspaper, 
  Clock, 
  ExternalLink, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Sparkles,
  Calendar,
  Award,
  FileText,
  BarChart3,
  Zap,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Download,
  Image as ImageIcon,
  Video,
  Upload,
  Trash2,
  Plus,
  X
} from 'lucide-react';
import {
  GeneralStockMediaItem,
  getGeneralStockMedia,
  saveGeneralStockMedia,
  deleteGeneralStockMedia,
  readFileAsDataUrl,
  STOCK_GENERAL_MEDIA_UPDATED_EVENT
} from '../../utils/stockMediaStorage';

interface StockNewsSectionProps {
  stock: StockItem;
  allNews?: StockNewsItem[];
  onSelectTicker?: (ticker: string) => void;
  onQuickTrade?: (stock: StockItem, side?: 'buy' | 'sell') => void;
}

export const StockNewsSection: React.FC<StockNewsSectionProps> = ({
  stock,
  allNews = getAllCombinedStockNews(),
  onSelectTicker,
  onQuickTrade,
}) => {
  const [activeMainTab, setActiveMainTab] = useState<'news' | 'media'>('news');
  const [activeCategory, setActiveCategory] = useState<'All' | 'Headlines' | 'Filings & Earnings' | 'Analyst Notes' | 'Sector Macro'>('All');

  // General media state for this stock
  const [generalMedia, setGeneralMedia] = useState<GeneralStockMediaItem[]>(() => getGeneralStockMedia(stock.ticker));
  const [isUploadingMedia, setIsUploadingMedia] = useState(false);
  const [mediaTitle, setMediaTitle] = useState('');
  const [mediaType, setMediaType] = useState<'photo' | 'video'>('photo');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    const syncMedia = () => {
      setGeneralMedia(getGeneralStockMedia(stock.ticker));
    };
    window.addEventListener(STOCK_GENERAL_MEDIA_UPDATED_EVENT, syncMedia);
    window.addEventListener('storage', syncMedia);
    return () => {
      window.removeEventListener(STOCK_GENERAL_MEDIA_UPDATED_EVENT, syncMedia);
      window.removeEventListener('storage', syncMedia);
    };
  }, [stock.ticker]);

  const handleUploadGeneralMedia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      setUploadError('Please select a photo or video file to upload.');
      return;
    }
    try {
      const url = await readFileAsDataUrl(selectedFile);
      const isVideo = selectedFile.type.startsWith('video/') || selectedFile.name.toLowerCase().endsWith('.mp4');
      const newItem: GeneralStockMediaItem = {
        id: `gm_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        ticker: stock.ticker,
        type: isVideo ? 'video' : 'photo',
        url,
        name: mediaTitle.trim() || selectedFile.name,
        uploaderName: 'Verified Shareholder',
        timestamp: 'Just now'
      };
      saveGeneralStockMedia(newItem);
      setIsUploadingMedia(false);
      setMediaTitle('');
      setSelectedFile(null);
      setUploadError(null);
    } catch (err: any) {
      setUploadError(err.message || 'Failed to upload media.');
    }
  };

  // Filter news for this specific stock
  const directStockNews = allNews.filter((n) => n.tickers.includes(stock.ticker));
  const sectorRelatedNews = allNews.filter((n) => !n.tickers.includes(stock.ticker) && (
    (stock.sector === 'Technology & AI' && n.category === 'Tech & AI') ||
    (stock.sector === 'Semiconductors' && (n.category === 'Semiconductors' || n.category === 'Tech & AI')) ||
    (stock.sector === 'Gold & Commodities' && n.category === 'Gold & Commodities') ||
    (stock.sector === 'Banking & Finance' && n.category === 'Banking & Macro') ||
    (stock.sector === 'Energy & Aerospace' && n.category === 'Energy & Defense') ||
    (stock.sector === 'ETFs & Indices' && n.category === 'Earnings')
  ));

  // Synthesize tailored stock-specific items if none found
  const combinedNews: StockNewsItem[] = [
    ...directStockNews,
    ...(directStockNews.length === 0 ? [
      {
        id: `news-${stock.ticker}-special-1`,
        title: `${stock.name} (${stock.ticker}) Reports Accelerated Institutional Accumulation & Multi-Quarter Margin Expansion`,
        source: 'Bloomberg Terminal Intelligence',
        time: '24m ago',
        sentiment: 'bullish' as const,
        tickers: [stock.ticker],
        category: 'Earnings' as const,
        impact: 'High Impact' as const,
        keyTakeaway: `Wall street consensus raised price target to $${(stock.analystTargetUSD || stock.price || 0).toFixed(2)} based on strong ${stock.subSector || stock.sector} execution and cash flow generation.`,
        summary: `Institutional block orders and prime brokerage desks reported steady net asset accumulation in ${stock.name}, driven by robust order backlog and disciplined capital allocation.`,
        readTime: '3 min read'
      },
      {
        id: `news-${stock.ticker}-special-2`,
        title: `${stock.ticker} SEC Form 8-K Regulatory Disclosure: Strategic Operations & Executive Update`,
        source: 'SEC EDGAR Wire',
        time: '2h ago',
        sentiment: 'neutral' as const,
        tickers: [stock.ticker],
        category: 'Earnings' as const,
        impact: 'Macro Trend' as const,
        keyTakeaway: 'Corporate filing confirms balance sheet strength, compliant shareholder disclosures, and continued dividend & investment roadmap.',
        summary: `${stock.name} completed quarterly governance disclosures with the Securities and Exchange Commission, reinforcing operational guidance.`,
        readTime: '2 min read'
      }
    ] : []),
    ...sectorRelatedNews
  ];

  // News category filtering
  const filteredArticles = combinedNews.filter((item) => {
    if (activeCategory === 'All') return true;
    if (activeCategory === 'Headlines') return item.impact === 'High Impact';
    if (activeCategory === 'Filings & Earnings') return item.category === 'Earnings' || item.title.includes('SEC') || item.title.includes('Earnings') || item.title.includes('Report');
    if (activeCategory === 'Analyst Notes') return item.title.includes('Target') || item.title.includes('Consensus') || item.title.includes('Analyst') || item.title.includes('Wall Street') || item.sentiment === 'bullish';
    if (activeCategory === 'Sector Macro') return item.category !== 'Earnings';
    return true;
  });

  // Calculate sentiment stats for this ticker
  const tickerMentions = combinedNews.filter(n => n.tickers.includes(stock.ticker));
  const bullishCount = tickerMentions.filter(n => n.sentiment === 'bullish').length;
  const totalCount = Math.max(1, tickerMentions.length);
  const bullishPct = Math.round((bullishCount / totalCount) * 100);

  return (
    <div id="stock-news-section" className="space-y-6">
      {/* 1. Header with Live News Intelligence */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-200 text-xs font-mono font-bold">
                ${stock.ticker} WIRE
              </span>
              <span className="inline-flex items-center gap-1.5 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Live Market Feeds
              </span>
            </div>
            <h3 className="font-serif font-bold text-lg text-slate-900 mt-2 flex items-center gap-2">
              <Newspaper className="w-5 h-5 text-amber-700" />
              <span>${stock.ticker} News &amp; Issuer Updates</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Curated financial headlines, earnings conference wires, SEC filings, photos &amp; videos for {stock.name}.
            </p>
          </div>

          {/* Quick Trade CTA */}
          {onQuickTrade && (
            <button
              type="button"
              onClick={() => onQuickTrade(stock, 'buy')}
              className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs transition-all flex items-center gap-2 shadow-xs cursor-pointer self-start md:self-auto"
            >
              <Zap className="w-4 h-4 fill-white" />
              <span>Instant Trade {stock.ticker}</span>
            </button>
          )}
        </div>

        {/* 2. Key Intelligence Highlights Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-5">
          {/* Card A: Sentiment Gauge */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
              <span>Market News Sentiment</span>
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-bold font-serif text-emerald-700">
              {bullishPct >= 70 ? 'Strong Bullish' : bullishPct >= 50 ? 'Moderately Bullish' : 'Neutral Hold'}
            </div>
            <div className="w-full bg-slate-200 h-2 rounded-full mt-2 overflow-hidden flex">
              <div className="bg-emerald-500 h-full" style={{ width: `${bullishPct}%` }} />
              <div className="bg-slate-300 h-full" style={{ width: `${100 - bullishPct}%` }} />
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">
              {bullishPct}% positive catalyst coverage in last 48 hours
            </p>
          </div>

          {/* Card B: SEC & Earnings Calendar */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
              <span>Next Earnings Release</span>
              <Calendar className="w-4 h-4 text-slate-600" />
            </div>
            <div className="text-xl font-bold font-mono text-slate-900">
              {stock.nextEarningsDate || 'Upcoming Q3 Report'}
            </div>
            <p className="text-xs font-semibold text-slate-600 mt-1">
              Consensus Est: {stock.consensusEps || `$${(stock.eps && stock.eps > 0) ? (stock.eps * 0.28).toFixed(2) : '1.15'}`} EPS
            </p>
            <p className="text-[11px] text-emerald-700 font-semibold mt-0.5">
              {stock.lastQuarterSurprise || '+6.2% Beat last quarter'}
            </p>
          </div>

          {/* Card C: Analyst Action Summary */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
              <span>Analyst 12M Price Target</span>
              <Award className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-xl font-bold font-mono text-slate-900">
              ${(stock.analystTargetUSD || stock.price || 0).toFixed(2)}
            </div>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`text-xs font-bold font-mono ${(stock.analystTargetUSD || stock.price) >= stock.price ? 'text-emerald-600' : 'text-rose-600'}`}>
                {(stock.analystTargetUSD || stock.price) >= stock.price ? '+' : ''}
                {((((stock.analystTargetUSD || stock.price) - stock.price) / (stock.price || 1)) * 100).toFixed(1)}% Upside
              </span>
              <span className="text-xs text-slate-400">• {stock.analystCount || 12} Coverage Firms</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Consensus: <strong className="text-slate-700">{stock.analystRating}</strong>
            </p>
          </div>
        </div>

        {/* 3. Two Main Tabs: News (with associated media) vs Media (general uploads) */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-3 mb-4">
          <button
            type="button"
            onClick={() => setActiveMainTab('news')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeMainTab === 'news'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Newspaper className="w-4 h-4" />
            <span>News &amp; Associated Media ({filteredArticles.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveMainTab('media')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
              activeMainTab === 'media'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>Media ({generalMedia.length})</span>
          </button>
        </div>

        {activeMainTab === 'news' ? (
          <>
            {/* Category Filter Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-2 border-b border-slate-100 mb-4">
              {(
                [
                  'All',
                  'Headlines',
                  'Filings & Earnings',
                  'Analyst Notes',
                  'Sector Macro'
                ] as const
              ).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    activeCategory === cat
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Article Feed List */}
            <div className="divide-y divide-slate-100">
              {filteredArticles.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  No news articles found for this specific filter.
                </div>
              ) : (
                filteredArticles.map((article, idx) => {
                  const isBull = article.sentiment === 'bullish';
                  const isBear = article.sentiment === 'bearish';

                  return (
                    <div key={`${article.id}-${idx}`} className="py-4.5 first:pt-0 last:pb-0 group">
                      {/* Article Metadata Bar */}
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-800">{article.source}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <span>{article.time}</span>
                          </span>
                          <span>•</span>
                          <span>{article.readTime}</span>
                        </div>

                        {/* Sentiment & Impact Badges */}
                        <div className="flex items-center gap-1.5">
                          {article.impact && (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700">
                              {article.impact}
                            </span>
                          )}
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold capitalize ${
                              isBull
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                                : isBear
                                ? 'bg-rose-50 text-rose-700 border border-rose-200/60'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {isBull ? (
                              <TrendingUp className="w-3 h-3 text-emerald-600" />
                            ) : isBear ? (
                              <TrendingDown className="w-3 h-3 text-rose-600" />
                            ) : (
                              <Minus className="w-3 h-3 text-slate-400" />
                            )}
                            <span>{article.sentiment}</span>
                          </span>
                        </div>
                      </div>

                      {/* Headline */}
                      <h4 className="font-serif font-bold text-sm sm:text-base text-slate-900 group-hover:text-amber-800 transition-colors leading-snug">
                        {article.title}
                      </h4>

                      {/* Key Takeaway Highlight Callout */}
                      {article.keyTakeaway && (
                        <div className="mt-2.5 p-3 rounded-2xl bg-amber-50/70 border border-amber-200/60 text-xs text-amber-950 flex items-start gap-2">
                          <Sparkles className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                          <div className="leading-relaxed">
                            <strong className="font-bold text-amber-900">Key Takeaway: </strong>
                            <span>{article.keyTakeaway}</span>
                          </div>
                        </div>
                      )}

                      {/* Summary / Body Text */}
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-2 whitespace-pre-line">
                        {article.bodyText || article.summary}
                      </p>

                      {article.photos && article.photos.length > 0 && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2.5">
                          {article.photos.map((photo) => (
                            <img
                              key={photo.id}
                              src={photo.url}
                              alt={photo.name}
                              className="w-full h-28 object-cover rounded-xl border border-slate-200 shadow-2xs"
                            />
                          ))}
                        </div>
                      )}

                      {article.videos && article.videos.length > 0 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2.5">
                          {article.videos.map((vid) => (
                            <video
                              key={vid.id}
                              src={vid.url}
                              controls
                              playsInline
                              className="w-full max-h-48 rounded-xl bg-black border border-slate-200 shadow-2xs"
                            />
                          ))}
                        </div>
                      )}

                      {article.documents && article.documents.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2.5">
                          {article.documents.map((doc) => (
                            <a
                              key={doc.id}
                              href={doc.url}
                              download={doc.name}
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-50 border border-indigo-200 text-xs font-bold text-indigo-700 hover:bg-indigo-50"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              <span className="truncate max-w-[180px]">{doc.name}</span>
                              <Download className="w-3 h-3" />
                            </a>
                          ))}
                        </div>
                      )}

                      {/* Footer with Tickers & Actions */}
                      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-50">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[11px] text-slate-400 font-semibold">Related Tickers:</span>
                          {article.tickers.map((t, tIdx) => (
                            <button
                              key={`${t}-${tIdx}`}
                              type="button"
                              onClick={() => onSelectTicker && onSelectTicker(t)}
                              className={`text-xs font-mono font-bold px-2 py-0.5 rounded-lg border transition-colors cursor-pointer ${
                                t === stock.ticker
                                  ? 'bg-amber-100 text-amber-900 border-amber-300'
                                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              ${t}
                            </button>
                          ))}
                        </div>

                        {/* Trade / Action Link */}
                        {onQuickTrade && (
                          <button
                            type="button"
                            onClick={() => onQuickTrade(stock, 'buy')}
                            className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            <span>Trade ${stock.ticker}</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </>
        ) : (
          <div className="space-y-6 py-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h4 className="font-serif font-bold text-sm sm:text-base text-slate-900 mb-1">
                  General Media Gallery for {stock.name} ({stock.ticker})
                </h4>
                <p className="text-xs text-slate-500">
                  General photos and videos uploaded by shareholders and market participants.
                </p>
              </div>
            </div>

            {generalMedia.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs bg-slate-50 rounded-2xl border border-slate-100 space-y-3">
                <ImageIcon className="w-10 h-10 text-slate-300 mx-auto" />
                <p>No general photos or videos uploaded for ${stock.ticker} yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {generalMedia.map((m) => (
                  <div key={m.id} className="rounded-2xl overflow-hidden border border-slate-200 bg-white shadow-2xs group relative">
                    {m.type === 'video' ? (
                      <video src={m.url} controls playsInline className="w-full h-44 object-cover bg-black" />
                    ) : (
                      <img src={m.url} alt={m.name} className="w-full h-44 object-cover group-hover:scale-105 transition-transform" />
                    )}
                    <div className="p-3 border-t border-slate-100 flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-bold text-xs text-slate-900 truncate">{m.name}</p>
                        <p className="text-[10px] text-slate-400 mt-0.5 truncate">
                          By {m.uploaderName || 'Community'} • {m.timestamp}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Upload General Media Modal */}
      {isUploadingMedia && (
        <div
          onClick={() => setIsUploadingMedia(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-md w-full bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl p-6 space-y-4 text-left"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-serif font-bold text-base text-slate-900 flex items-center gap-2">
                <Upload className="w-4 h-4 text-amber-600" />
                <span>Upload General Media • ${stock.ticker}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsUploadingMedia(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {uploadError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{uploadError}</span>
              </div>
            )}

            <form onSubmit={handleUploadGeneralMedia} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Media Title / Description</label>
                <input
                  type="text"
                  value={mediaTitle}
                  onChange={(e) => setMediaTitle(e.target.value)}
                  placeholder="e.g. Facility Tour, Vault Inspection, Product Demo..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Photo or Video File</label>
                <input
                  type="file"
                  accept="image/*,video/*"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      setSelectedFile(e.target.files[0]);
                      setUploadError(null);
                    }
                  }}
                  className="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-50 file:text-amber-800 hover:file:bg-amber-100 cursor-pointer"
                />
                {selectedFile && (
                  <p className="mt-1 text-[11px] text-emerald-700 font-semibold">
                    Selected: {selectedFile.name} ({(selectedFile.size / (1024 * 1024)).toFixed(2)} MB)
                  </p>
                )}
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsUploadingMedia(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold cursor-pointer shadow-xs"
                >
                  Upload &amp; Post Media
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
