import { useEffect, useMemo, useState } from 'react';
import { AuthSession } from '../types/auth';
import {
  ACCOUNT_STATUS_UPDATED_EVENT,
  isAccountDeactivated,
  isAccountLocked,
} from './accountStatusStorage';

export const PRESENCE_UPDATED_EVENT = 'final_finance_presence_updated';
const PRESENCE_STORAGE_KEY = 'final_finance_presence_v1';
const PRESENCE_LAST_SEEN_KEY = 'final_finance_presence_last_seen_v1';
const PRESENCE_TAB_ID_KEY = 'final_finance_presence_tab_id';
const PRESENCE_CHANNEL_NAME = 'final_finance_presence';

const HEARTBEAT_INTERVAL_MS = 15_000;
const PRESENCE_TTL_MS = 60_000;
const SERVER_POLL_INTERVAL_MS = 15_000;

export interface PresenceSessionRecord {
  tabId: string;
  keys: string[];
  name?: string;
  lastSeenAt: number;
}

export interface UserPresenceStatus {
  isOnline: boolean;
  lastSeenAt?: number;
  label: 'Online' | 'Offline';
}

const KNOWN_PRESENCE_ALIAS_GROUPS: string[][] = [
  ['demo-ranma-superadmin', 'demo-super-admin', 'google-super_admin_ranma', 'super_admin_ranma', 'ranmaanimaker@gmail.com', 'adm-1', 'ranma'],
  ['demo-dbz-admin', 'demo-admin-officer', 'google-officer_dbz', 'officer_dbz', 'awesomedbz@gmail.com', 'adm-2', 'awesomedbz'],
  ['demo-alex-morgan', 'demo-vip-alex', 'alex_morgan', 'alex@finalfinance.io'],
  ['demo-satoshi-nakamoto', 'creator_satoshi', 'satoshi_nakamoto', 'satoshi', 'satoshi@finalfinance.io', 'adm-4'],
  ['demo-jordan-belfort', 'demo-jordan', 'jordan_belfort', 'jordan', 'jordan@finalfinance.io', 'adm-3'],
  ['user-elena_rostova', 'creator_elena', 'demo-elena', 'elena_rostova', 'elena_compliance', 'elena', 'elena@monaco-yachting.mc', 'elena.rostova@finalfinance.io', 'adm-5'],
  ['user-alex_chen', 'creator_alex_chen', 'alex_chen', 'alex.chen@finalfinance.io'],
  ['user-marcus_vance', 'demo-marcus', 'quant_trader_mark', 'marcus_vance', 'vance_capital', 'marcus@vance-holdings.com', 'marcus.vance@finalfinance.io', 'adm-6'],
  ['user-lord_sterling', 'lord_sterling', 'sterling_vault', 'sterling@zurich-escrow.ch'],
  ['user-gholu653', 'google-gholu653', 'gholu653', 'gholu653@gmail.com'],
  ['user-trader_alex', 'trader_alex', 'trader.alex@gmail.com'],
  ['guest', 'guest_user', 'guest_trader', 'demo-guest-trader', 'guest@finalfinance.io'],
];

let memoryServerSessions: PresenceSessionRecord[] = [];
let memoryServerLastSeen: Record<string, number> = {};
let lastServerFetchAt = 0;
let serverFetchInFlight: Promise<void> | null = null;
let cachedBroadcastChannel: BroadcastChannel | null = null;

function getPresenceChannel(): BroadcastChannel | null {
  if (typeof window === 'undefined' || typeof BroadcastChannel === 'undefined') {
    return null;
  }
  if (!cachedBroadcastChannel) {
    try {
      cachedBroadcastChannel = new BroadcastChannel(PRESENCE_CHANNEL_NAME);
    } catch {
      return null;
    }
  }
  return cachedBroadcastChannel;
}

export function getPresenceTabId(): string {
  if (typeof window === 'undefined') return 'tab-server';
  try {
    let existing = window.sessionStorage.getItem(PRESENCE_TAB_ID_KEY);
    if (!existing) {
      existing =
        typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
          ? `tab-${crypto.randomUUID()}`
          : `tab-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      window.sessionStorage.setItem(PRESENCE_TAB_ID_KEY, existing);
    }
    return existing;
  } catch {
    return `tab-mem-${Date.now()}`;
  }
}

export function expandPresenceIdentifiers(
  identifiers: string | Array<string | undefined | null> | null | undefined
): string[] {
  const inputList = Array.isArray(identifiers) ? identifiers : [identifiers];
  const keys = new Set<string>();

  const addVariants = (rawVal: string) => {
    const trimmed = rawVal.trim();
    if (!trimmed) return;
    const lower = trimmed.toLowerCase();
    const noAt = lower.replace(/^@/, '');
    keys.add(lower);
    keys.add(noAt);

    if (noAt.startsWith('user-')) {
      keys.add(noAt.slice(5));
    } else if (noAt.startsWith('demo-')) {
      keys.add(noAt.slice(5));
    } else if (noAt.startsWith('google-')) {
      const bare = noAt.slice(7);
      keys.add(bare);
      keys.add(`user-${bare}`);
    } else if (noAt.startsWith('creator_')) {
      const bare = noAt.slice(8);
      keys.add(bare);
      keys.add(`user-${bare}`);
    } else if (!noAt.includes('@')) {
      keys.add(`user-${noAt}`);
      keys.add(`google-${noAt}`);
    }
  };

  for (const item of inputList) {
    if (typeof item === 'string' && item.trim()) {
      addVariants(item);
    }
  }

  for (const group of KNOWN_PRESENCE_ALIAS_GROUPS) {
    if (group.some((alias) => keys.has(alias.toLowerCase()))) {
      for (const alias of group) {
        addVariants(alias);
      }
    }
  }

  // Merge registered user handles/emails from localStorage if available
  if (typeof window !== 'undefined') {
    try {
      const rawReg = window.localStorage.getItem('final_finance_registered_users');
      if (rawReg) {
        const regMap = JSON.parse(rawReg);
        if (regMap && typeof regMap === 'object') {
          Object.values<any>(regMap).forEach((acc) => {
            if (!acc) return;
            const accUid = acc.uid ? String(acc.uid).toLowerCase() : '';
            const accUserId = acc.userId ? String(acc.userId).toLowerCase().replace(/^@/, '') : '';
            const accEmail = acc.email ? String(acc.email).toLowerCase() : '';
            if (
              (accUid && keys.has(accUid)) ||
              (accUserId && (keys.has(accUserId) || keys.has(`user-${accUserId}`))) ||
              (accEmail && keys.has(accEmail))
            ) {
              if (accUid) addVariants(accUid);
              if (accUserId) addVariants(accUserId);
              if (accEmail) addVariants(accEmail);
            }
          });
        }
      }
    } catch {
      // ignore parse errors
    }
  }

  return Array.from(keys).filter(Boolean);
}

export function extractSessionPresenceKeys(session: AuthSession | null | undefined): string[] {
  if (!session) return [];
  return expandPresenceIdentifiers([
    session.uid,
    session.id,
    session.handle,
    session.email,
    session.user?.email,
  ]);
}

function readLocalPresenceMap(): Record<string, PresenceSessionRecord> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(PRESENCE_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return {};
    const now = Date.now();
    const cleaned: Record<string, PresenceSessionRecord> = {};
    let changed = false;

    for (const [tabId, rec] of Object.entries<any>(parsed)) {
      if (!rec || typeof rec.lastSeenAt !== 'number' || !Array.isArray(rec.keys)) {
        changed = true;
        continue;
      }
      if (now - rec.lastSeenAt > PRESENCE_TTL_MS) {
        changed = true;
        continue;
      }
      cleaned[tabId] = {
        tabId,
        keys: rec.keys.map((k: unknown) => String(k).toLowerCase()),
        name: typeof rec.name === 'string' ? rec.name : undefined,
        lastSeenAt: rec.lastSeenAt,
      };
    }

    if (changed) {
      window.localStorage.setItem(PRESENCE_STORAGE_KEY, JSON.stringify(cleaned));
    }
    return cleaned;
  } catch {
    return {};
  }
}

function readLocalLastSeenMap(): Record<string, number> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(PRESENCE_LAST_SEEN_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeLocalLastSeenKeys(keys: string[], timestamp: number): void {
  if (typeof window === 'undefined' || keys.length === 0) return;
  try {
    const current = readLocalLastSeenMap();
    for (const k of keys) {
      current[k.toLowerCase()] = timestamp;
    }
    window.localStorage.setItem(PRESENCE_LAST_SEEN_KEY, JSON.stringify(current));
  } catch {
    // ignore storage quota errors
  }
}

function emitPresenceChanged(): void {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent(PRESENCE_UPDATED_EVENT));
  const channel = getPresenceChannel();
  if (channel) {
    try {
      channel.postMessage({ type: 'presence_updated', at: Date.now() });
    } catch {
      // ignore broadcast errors
    }
  }
}

function readCurrentAuthSessionKeys(): Set<string> | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem('final_finance_auth_session');
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AuthSession;
    const keys = extractSessionPresenceKeys(parsed);
    return keys.length > 0 ? new Set(keys) : null;
  } catch {
    return null;
  }
}

export function publishPresenceHeartbeat(session: AuthSession | null | undefined): void {
  if (typeof window === 'undefined' || !session) return;
  const keys = extractSessionPresenceKeys(session);
  if (keys.length === 0) return;

  // Never publish online if locked or deactivated
  if (isAccountLocked(keys) || isAccountDeactivated(keys)) {
    markPresenceOffline(keys);
    return;
  }

  const tabId = getPresenceTabId();
  const now = Date.now();
  const map = readLocalPresenceMap();
  map[tabId] = {
    tabId,
    keys,
    name: session.name,
    lastSeenAt: now,
  };

  try {
    window.localStorage.setItem(PRESENCE_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // ignore storage errors
  }
  writeLocalLastSeenKeys(keys, now);
  emitPresenceChanged();

  void fetch('/api/presence/heartbeat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tabId, keys, name: session.name }),
    keepalive: true,
  }).catch(() => {
    // Offline/client-only fallback works via localStorage + BroadcastChannel
  });
}

export function markPresenceOffline(
  sessionOrIdentifiers?: AuthSession | string | Array<string | undefined | null> | null,
  options?: { useBeacon?: boolean }
): void {
  if (typeof window === 'undefined') return;
  const tabId = getPresenceTabId();
  const explicitKeys =
    sessionOrIdentifiers && typeof sessionOrIdentifiers === 'object' && !Array.isArray(sessionOrIdentifiers)
      ? extractSessionPresenceKeys(sessionOrIdentifiers as AuthSession)
      : expandPresenceIdentifiers(sessionOrIdentifiers as any);

  const map = readLocalPresenceMap();
  const removedKeys = new Set<string>(explicitKeys);
  const now = Date.now();

  if (map[tabId]) {
    for (const k of map[tabId].keys) removedKeys.add(k);
    delete map[tabId];
  }

  if (explicitKeys.length > 0) {
    const explicitSet = new Set(explicitKeys);
    for (const [id, rec] of Object.entries(map)) {
      if (id === tabId || rec.keys.some((k) => explicitSet.has(k))) {
        for (const k of rec.keys) removedKeys.add(k);
        delete map[id];
      }
    }
  }

  try {
    window.localStorage.setItem(PRESENCE_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // ignore
  }

  const allRemoved = Array.from(removedKeys);
  if (allRemoved.length > 0) {
    writeLocalLastSeenKeys(allRemoved, now);
  }
  if (memoryServerSessions.length > 0) {
    memoryServerSessions = memoryServerSessions.filter((rec) => rec.tabId !== tabId);
  }

  emitPresenceChanged();

  const payload = JSON.stringify({ tabId, keys: allRemoved });
  if (options?.useBeacon && typeof navigator !== 'undefined' && typeof navigator.sendBeacon === 'function') {
    try {
      const blob = new Blob([payload], { type: 'application/json' });
      navigator.sendBeacon('/api/presence/offline', blob);
      return;
    } catch {
      // fallback to keepalive fetch
    }
  }

  void fetch('/api/presence/offline', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: payload,
    keepalive: true,
  }).catch(() => {
    // ignore network failure
  });
}

export async function refreshServerPresence(force = false): Promise<void> {
  if (typeof window === 'undefined') return;
  const now = Date.now();
  if (!force && (serverFetchInFlight || now - lastServerFetchAt < 5_000)) {
    return;
  }

  serverFetchInFlight = (async () => {
    try {
      const resp = await fetch('/api/presence');
      if (!resp.ok) return;
      const data = await resp.json();
      if (data?.success && Array.isArray(data.sessions)) {
        const localNow = Date.now();
        const offset = typeof data.serverTime === 'number' ? localNow - data.serverTime : 0;
        memoryServerSessions = data.sessions.map((s: any) => ({
          tabId: String(s.tabId || ''),
          keys: Array.isArray(s.keys) ? s.keys.map((k: unknown) => String(k).toLowerCase()) : [],
          name: typeof s.name === 'string' ? s.name : undefined,
          lastSeenAt: typeof s.lastSeen === 'number' ? s.lastSeen + offset : localNow,
        }));
        if (data.lastSeen && typeof data.lastSeen === 'object') {
          const nextSeen: Record<string, number> = {};
          for (const [k, ts] of Object.entries<any>(data.lastSeen)) {
            if (typeof ts === 'number') {
              nextSeen[k.toLowerCase()] = ts + offset;
            }
          }
          memoryServerLastSeen = nextSeen;
        }
        lastServerFetchAt = Date.now();
        window.dispatchEvent(new CustomEvent(PRESENCE_UPDATED_EVENT));
      }
    } catch {
      // ignore network failure and continue using localStorage + BroadcastChannel
    } finally {
      serverFetchInFlight = null;
    }
  })();

  await serverFetchInFlight;
}

export function resolveUserPresence(
  identifiers: string | Array<string | undefined | null> | null | undefined,
  forceOffline = false
): UserPresenceStatus {
  const keys = expandPresenceIdentifiers(identifiers);
  if (keys.length === 0) {
    return { isOnline: false, label: 'Offline' };
  }

  if (forceOffline || isAccountLocked(keys) || isAccountDeactivated(keys)) {
    return { isOnline: false, label: 'Offline' };
  }

  const keySet = new Set(keys);
  const now = Date.now();
  let latestSeenAt: number | undefined;
  let isOnline = false;

  // 1. Check if this matches the currently active signed-in session in this window
  const currentSessionKeys = readCurrentAuthSessionKeys();
  if (currentSessionKeys && keys.some((k) => currentSessionKeys.has(k))) {
    isOnline = true;
    latestSeenAt = now;
  }

  // 2. Check active local tabs (same browser across tabs)
  const localMap = readLocalPresenceMap();
  for (const rec of Object.values(localMap)) {
    if (now - rec.lastSeenAt <= PRESENCE_TTL_MS && rec.keys.some((k) => keySet.has(k))) {
      isOnline = true;
      if (!latestSeenAt || rec.lastSeenAt > latestSeenAt) {
        latestSeenAt = rec.lastSeenAt;
      }
    }
  }

  // 3. Check active server sessions (cross-browser sessions)
  for (const rec of memoryServerSessions) {
    if (now - rec.lastSeenAt <= PRESENCE_TTL_MS && rec.keys.some((k) => keySet.has(k))) {
      isOnline = true;
      if (!latestSeenAt || rec.lastSeenAt > latestSeenAt) {
        latestSeenAt = rec.lastSeenAt;
      }
    }
  }

  // 4. Lookup lastSeen timestamp if offline
  if (!latestSeenAt) {
    const localLastSeen = readLocalLastSeenMap();
    for (const k of keys) {
      const ts = Math.max(localLastSeen[k] || 0, memoryServerLastSeen[k] || 0);
      if (ts > 0 && (!latestSeenAt || ts > latestSeenAt)) {
        latestSeenAt = ts;
      }
    }
  }

  return {
    isOnline,
    lastSeenAt: latestSeenAt,
    label: isOnline ? 'Online' : 'Offline',
  };
}

export function useUserPresence(
  identifiers: string | Array<string | undefined | null> | null | undefined,
  forceOffline = false
): UserPresenceStatus {
  const serializedIds = useMemo(
    () => (Array.isArray(identifiers) ? identifiers.filter(Boolean).join('|') : identifiers || ''),
    [identifiers]
  );

  const [status, setStatus] = useState<UserPresenceStatus>(() =>
    resolveUserPresence(identifiers, forceOffline)
  );

  useEffect(() => {
    const update = () => {
      setStatus(resolveUserPresence(identifiers, forceOffline));
    };

    update();
    void refreshServerPresence(false);

    const handleStorage = (e: StorageEvent) => {
      if (
        !e.key ||
        e.key === PRESENCE_STORAGE_KEY ||
        e.key === PRESENCE_LAST_SEEN_KEY ||
        e.key === 'final_finance_auth_session'
      ) {
        update();
      }
    };

    const channel = getPresenceChannel();
    const handleBroadcast = () => update();

    window.addEventListener(PRESENCE_UPDATED_EVENT, update);
    window.addEventListener(ACCOUNT_STATUS_UPDATED_EVENT, update);
    window.addEventListener('storage', handleStorage);
    channel?.addEventListener('message', handleBroadcast);

    const expiryTimer = window.setInterval(update, 10_000);

    return () => {
      window.removeEventListener(PRESENCE_UPDATED_EVENT, update);
      window.removeEventListener(ACCOUNT_STATUS_UPDATED_EVENT, update);
      window.removeEventListener('storage', handleStorage);
      channel?.removeEventListener('message', handleBroadcast);
      window.clearInterval(expiryTimer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serializedIds, forceOffline]);

  return status;
}

export function usePresenceLifecycle(authSession: AuthSession | null): void {
  const sessionKey = authSession
    ? `${authSession.uid}|${authSession.id}|${authSession.email}`
    : '';

  useEffect(() => {
    if (!authSession) {
      markPresenceOffline(null);
      return;
    }

    publishPresenceHeartbeat(authSession);
    void refreshServerPresence(true);

    const heartbeatTimer = window.setInterval(() => {
      publishPresenceHeartbeat(authSession);
    }, HEARTBEAT_INTERVAL_MS);

    const pollTimer = window.setInterval(() => {
      void refreshServerPresence(true);
    }, SERVER_POLL_INTERVAL_MS);

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        publishPresenceHeartbeat(authSession);
        void refreshServerPresence(true);
      }
    };

    const handlePageHide = () => {
      markPresenceOffline(authSession, { useBeacon: true });
    };

    const handleStorageSync = (e: StorageEvent) => {
      if (e.key === PRESENCE_STORAGE_KEY || e.key === 'final_finance_auth_session') {
        window.dispatchEvent(new CustomEvent(PRESENCE_UPDATED_EVENT));
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('focus', handleVisibilityOrFocus);
    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('beforeunload', handlePageHide);
    window.addEventListener('storage', handleStorageSync);

    return () => {
      window.clearInterval(heartbeatTimer);
      window.clearInterval(pollTimer);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('focus', handleVisibilityOrFocus);
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('beforeunload', handlePageHide);
      window.removeEventListener('storage', handleStorageSync);
      markPresenceOffline(authSession);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionKey]);
}
