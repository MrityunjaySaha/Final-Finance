import React, { useState, useEffect } from 'react';
import {
  Phone,
  Video,
  Users,
  Search,
  Trash2,
  X,
  ArrowLeft,
} from 'lucide-react';
import { CallLog } from '../types/callLog';
import { 
  deleteCallLog, 
  clearCallLogs, 
  subscribeToCallLogs 
} from '../services/callLogService';
import { AuthSession } from '../types/auth';

interface CallLogsViewProps {
  currentUser?: AuthSession | null;
  onOpenVoiceCall: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }, isGroup?: boolean, groupParticipants?: any[]) => void;
  onOpenVideoCall: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }, isGroup?: boolean, groupParticipants?: any[]) => void;
  onViewUserProfile?: (userIdOrHandle: string) => void;
  onOpenChatWithUser?: (uid: string) => void;
  onBackToMessages?: () => void;
}

export const CallLogsView: React.FC<CallLogsViewProps> = ({
  onOpenVoiceCall,
  onOpenVideoCall,
  onViewUserProfile,
  onBackToMessages,
}) => {
  const [logs, setLogs] = useState<CallLog[]>([]);
  const [filter, setFilter] = useState<'all' | 'missed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showConfirmClear, setShowConfirmClear] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToCallLogs((updatedLogs) => {
      setLogs(updatedLogs);
    });
    return () => unsubscribe();
  }, []);

  // Format Duration cleanly (e.g. 6m 12s)
  const formatDuration = (seconds: number) => {
    if (!seconds || seconds <= 0) return null;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins === 0) return `${secs}s`;
    return `${mins}m ${secs.toString().padStart(2, '0')}s`;
  };

  // Format Date cleanly (e.g. "10:45 AM", "Yesterday", "Aug 15")
  const formatCallDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      const now = new Date();
      const isToday = d.toDateString() === now.toDateString();

      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const isYesterday = d.toDateString() === yesterday.toDateString();

      const timeStr = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

      if (isToday) {
        return timeStr;
      }
      if (isYesterday) {
        return `Yesterday, ${timeStr}`;
      }
      return `${d.toLocaleDateString([], { month: 'short', day: 'numeric' })}, ${timeStr}`;
    } catch {
      return '';
    }
  };

  // Filter logs
  const filteredLogs = logs.filter((log) => {
    if (filter === 'missed' && log.status === 'completed') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = log.targetName?.toLowerCase().includes(q);
      const matchGroup = log.groupName?.toLowerCase().includes(q);
      if (!matchName && !matchGroup) return false;
    }

    return true;
  });

  const handleCallBack = (log: CallLog) => {
    const isGroup = log.scope === 'group';
    const isVideo = log.type === 'video';

    if (isGroup) {
      const target = {
        uid: log.targetUid || log.id,
        userId: log.targetHandle || 'group_room',
        name: log.targetName || log.groupName || 'Group Room',
        avatarUrl: log.targetAvatarUrl,
      };
      if (isVideo) {
        onOpenVideoCall(target, true, log.participants || []);
      } else {
        onOpenVoiceCall(target, true, log.participants || []);
      }
    } else {
      const target = {
        uid: log.targetUid || 'peer',
        userId: log.targetHandle || 'peer_user',
        name: log.targetName,
        avatarUrl: log.targetAvatarUrl,
      };
      if (isVideo) {
        onOpenVideoCall(target, false);
      } else {
        onOpenVoiceCall(target, false);
      }
    }
  };

  return (
    <div className="h-full flex flex-col bg-white text-left overflow-hidden select-none w-full">
      {/* Minimal Top Navigation */}
      <div className="px-4 py-3 border-b border-neutral-200 bg-white flex items-center justify-between gap-3 shrink-0">
        {/* Left: Back / Title */}
        <div className="flex items-center gap-2">
          {onBackToMessages && (
            <button
              type="button"
              onClick={onBackToMessages}
              className="p-1.5 rounded-full text-neutral-500 hover:text-black hover:bg-neutral-100 transition-colors cursor-pointer"
              title="Back to Messages"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <h2 className="text-lg font-bold text-neutral-900 tracking-tight">
            Calls
          </h2>
        </div>

        {/* Center: Segmented Control [ All | Missed ] */}
        <div className="flex items-center bg-neutral-100 p-0.5 rounded-lg text-xs">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-md font-medium transition-all cursor-pointer ${
              filter === 'all'
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            All
          </button>
          <button
            type="button"
            onClick={() => setFilter('missed')}
            className={`px-3 py-1 rounded-md font-medium transition-all cursor-pointer ${
              filter === 'missed'
                ? 'bg-white text-red-600 shadow-xs'
                : 'text-neutral-500 hover:text-neutral-900'
            }`}
          >
            Missed
          </button>
        </div>

        {/* Right: Actions (Search Toggle / Clear) */}
        <div className="flex items-center gap-1">
          {logs.length > 0 && (
            <button
              type="button"
              onClick={() => setShowConfirmClear(true)}
              className="px-2.5 py-1 text-xs font-medium text-neutral-500 hover:text-red-600 transition-colors cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Clean Search Input */}
      <div className="px-4 py-2 border-b border-neutral-100 bg-neutral-50/50">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name..."
            className="w-full pl-8 pr-7 py-1.5 bg-neutral-100/90 border-0 rounded-lg text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:bg-white focus:ring-1 focus:ring-neutral-300 transition-all"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Pristine Clean Call History List */}
      <div className="flex-1 overflow-y-auto divide-y divide-neutral-100">
        {filteredLogs.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-neutral-400">
            <Phone className="w-7 h-7 stroke-1 mb-2 text-neutral-300" />
            <p className="text-sm text-neutral-600 font-medium">No Calls</p>
            <p className="text-xs text-neutral-400 mt-0.5">
              {filter === 'missed' ? 'You have no missed calls' : 'Your recent calls will appear here'}
            </p>
          </div>
        ) : (
          filteredLogs.map((log) => {
            const isVideo = log.type === 'video';
            const isGroup = log.scope === 'group';
            const isMissed = log.status === 'missed' || log.status === 'cancelled' || log.status === 'declined';
            const isOutgoing = log.direction === 'outgoing';
            const duration = formatDuration(log.durationSeconds);
            const dateStr = formatCallDate(log.timestamp);

            return (
              <div
                key={log.id}
                onClick={() => handleCallBack(log)}
                className="flex items-center px-4 sm:px-5 py-3 hover:bg-neutral-50 transition-colors cursor-pointer group"
              >
                {/* 1. Avatar */}
                <div 
                  onClick={(e) => {
                    if (!isGroup && onViewUserProfile && (log.targetHandle || log.targetUid)) {
                      e.stopPropagation();
                      onViewUserProfile(log.targetHandle || log.targetUid!);
                    }
                  }}
                  className="w-10 h-10 rounded-full overflow-hidden bg-neutral-100 shrink-0 mr-3.5 border border-neutral-200/70 flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity"
                  title={!isGroup ? "View Profile" : undefined}
                >
                  {isGroup ? (
                    <div className="w-full h-full bg-neutral-900 text-white flex items-center justify-center">
                      <Users className="w-5 h-5 text-neutral-300" />
                    </div>
                  ) : log.targetAvatarUrl ? (
                    <img
                      src={log.targetAvatarUrl}
                      alt={log.targetName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-neutral-900 text-white flex items-center justify-center font-semibold text-sm">
                      {log.targetName?.charAt(0)?.toUpperCase() || 'U'}
                    </div>
                  )}
                </div>

                {/* 2. Center Column: Name & Details */}
                <div className="flex-1 min-w-0 pr-3">
                  <div className="flex items-center justify-between mb-0.5">
                    <h3
                      className={`text-sm font-semibold truncate ${
                        isMissed ? 'text-red-600' : 'text-neutral-900'
                      }`}
                    >
                      {log.targetName}
                    </h3>
                    <span className="text-xs text-neutral-400 font-normal shrink-0 ml-2">
                      {dateStr}
                    </span>
                  </div>

                  <div className="flex items-center text-xs text-neutral-500 gap-1.5">
                    {/* Call Modality Icon */}
                    {isVideo ? (
                      <Video className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                    ) : (
                      <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                    )}

                    {/* Status label */}
                    <span className={isMissed ? 'text-red-500 font-medium' : 'text-neutral-500'}>
                      {isMissed ? 'Missed' : isOutgoing ? 'Outgoing' : 'Incoming'}
                    </span>

                    {/* Duration if connected */}
                    {duration && (
                      <>
                        <span className="text-neutral-300">•</span>
                        <span>{duration}</span>
                      </>
                    )}

                    {/* Group info if group */}
                    {isGroup && (
                      <>
                        <span className="text-neutral-300">•</span>
                        <span>{log.participantsCount} participants</span>
                      </>
                    )}
                  </div>
                </div>

                {/* 3. Right: Single Clean Redial Button & Hover Delete */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteCallLog(log.id);
                    }}
                    className="w-8 h-8 rounded-full text-neutral-300 hover:text-red-600 hover:bg-neutral-100 flex items-center justify-center transition-colors cursor-pointer opacity-0 group-hover:opacity-100"
                    title="Delete log"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCallBack(log);
                    }}
                    className="w-8 h-8 rounded-full hover:bg-neutral-200/80 text-neutral-600 hover:text-neutral-900 flex items-center justify-center transition-colors cursor-pointer"
                    title={`Call ${log.targetName}`}
                  >
                    {isVideo ? (
                      <Video className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Phone className="w-4 h-4 text-neutral-800" />
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Simple Clear All Confirmation Modal */}
      {showConfirmClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-2xs">
          <div className="w-full max-w-xs bg-white rounded-2xl p-5 shadow-xl border border-neutral-200 text-center">
            <h3 className="text-sm font-bold text-neutral-900">Clear All Calls?</h3>
            <p className="text-xs text-neutral-500 mt-1">This will remove all call records from your history.</p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <button
                type="button"
                onClick={() => setShowConfirmClear(false)}
                className="px-3.5 py-1.5 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-xs font-medium text-neutral-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  clearCallLogs();
                  setShowConfirmClear(false);
                }}
                className="px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-xs font-bold text-white cursor-pointer shadow-2xs"
              >
                Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
