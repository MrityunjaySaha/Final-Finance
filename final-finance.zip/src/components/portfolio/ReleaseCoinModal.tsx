import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Zap,
  Coins,
  DollarSign,
  Info,
  CheckCircle2,
  Sparkles,
  Layers,
  Lock,
  ArrowRight,
  AlertCircle,
  Percent,
  Upload,
  Image as ImageIcon,
  Trash2,
  Camera,
  Link,
  Crown,
  TrendingUp,
  Activity
} from 'lucide-react';
import {
  CustomCoin,
  CustomCoinType,
  PegCurrency,
  MAX_COINS_PER_TYPE,
  TOTAL_CREATABLE_COINS,
  MAX_MARKET_COINS_TOTAL,
  TOTAL_DIGITAL_CURRENCY_TYPES,
  MAX_FINAL_COINS_PER_USER
} from '../../types/coinLaunch';
import {
  INR_TO_USD_RATE,
  canUserReleaseCoin,
  canUserReleaseFinalCoin,
  getMarketCoinCapacity
} from '../../data/customCoinsData';
import { AuthSession } from '../../types/auth';

interface ReleaseCoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthSession | null;
  existingCoins: CustomCoin[];
  onCoinReleased: (newCoin: CustomCoin) => void;
  defaultType?: CustomCoinType;
}

const COLOR_PRESETS = [
  { id: 'emerald', label: 'Emerald Mint', bg: 'from-emerald-500 via-teal-600 to-emerald-700 text-white', iconColor: 'text-emerald-400' },
  { id: 'amber', label: 'Golden Sovereign', bg: 'from-amber-400 via-amber-500 to-amber-600 text-slate-950', iconColor: 'text-amber-500' },
  { id: 'purple', label: 'Cosmic Violet', bg: 'from-purple-600 via-indigo-600 to-violet-700 text-white', iconColor: 'text-purple-400' },
  { id: 'blue', label: 'Swiss Azure', bg: 'from-blue-600 via-cyan-600 to-sky-700 text-white', iconColor: 'text-cyan-400' },
  { id: 'orange', label: 'Indian Saffron', bg: 'from-orange-500 via-amber-500 to-rose-600 text-white', iconColor: 'text-orange-400' },
  { id: 'rose', label: 'Ruby Velvet', bg: 'from-rose-500 via-pink-600 to-red-700 text-white', iconColor: 'text-rose-400' },
];

const ICONS = ['🛡️', '⚡', '⛓️', '$', '₹', '💎', '🏛️', '🌌', '👑', '🌟', '🚀', '🔥', '🦅', '🦁', '🪙', '🪐', '🌊'];

const PHOTO_PRESETS = [
  { id: 'gold_vault', label: 'Sovereign Gold Vault', url: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?w=300&auto=format&fit=crop&q=80' },
  { id: 'digital_core', label: 'Quantum Ledger Core', url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=300&auto=format&fit=crop&q=80' },
  { id: 'crypto_eagle', label: 'Imperial Sovereign Emblem', url: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?w=300&auto=format&fit=crop&q=80' },
  { id: 'blue_chip', label: 'Silicon Quantum Chip', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&auto=format&fit=crop&q=80' },
  { id: 'emerald_matrix', label: 'Emerald Reserve Vault', url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=300&auto=format&fit=crop&q=80' },
  { id: 'ruby_sovereign', label: 'Ruby Royal Treasury', url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=300&auto=format&fit=crop&q=80' }
];

export const ReleaseCoinModal: React.FC<ReleaseCoinModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  existingCoins,
  onCoinReleased,
  defaultType = 'final_coin'
}) => {
  const userId = currentUser?.id || 'user_demo';
  const userName = currentUser?.name || 'Sovereign Pioneer';
  const userHandle = currentUser?.username || currentUser?.id || 'pioneer_trader';
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  const [coinType, setCoinType] = useState<CustomCoinType>(defaultType);
  const [pegCurrency, setPegCurrency] = useState<PegCurrency>('USD');
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('');
  const [totalSupply, setTotalSupply] = useState<number>(10000000);
  const [circulatingSupply, setCirculatingSupply] = useState<number>(6000000);
  const [customPriceUSD, setCustomPriceUSD] = useState<number>(10.0);
  const [reserveRatioPercent, setReserveRatioPercent] = useState<number>(100);
  const [reserveBackingDescription, setReserveBackingDescription] = useState('');
  const [collateralAssetType, setCollateralAssetType] = useState('US Treasury Escrow & Cash Reserves');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [videos, setVideos] = useState<string[]>([]);
  const photosFileInputRef = useRef<HTMLInputElement>(null);
  const videosFileInputRef = useRef<HTMLInputElement>(null);
  const [selectedColor, setSelectedColor] = useState(COLOR_PRESETS[0]);
  const [selectedIcon, setSelectedIcon] = useState('🛡️');
  const [logoStyle, setLogoStyle] = useState<'icon' | 'photo'>('icon');
  const [logoUrl, setLogoUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [network, setNetwork] = useState('Final Ledger Layer-1');
  const [issueAsAdmin, setIssueAsAdmin] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Live fluctuating USD/INR exchange rate baseline for stable coin issuance
  const [liveUsdInrRate, setLiveUsdInrRate] = useState<number>(86.20);
  const [rateTrend, setRateTrend] = useState<'up' | 'down' | 'stable'>('stable');

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveUsdInrRate((prev) => {
        const delta = (Math.random() - 0.48) * 0.08;
        const updated = parseFloat((prev + delta).toFixed(2));
        setRateTrend(delta > 0 ? 'up' : delta < 0 ? 'down' : 'stable');
        return Math.max(84.00, Math.min(90.00, updated));
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleAdditionalPhotosUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    Array.from(files).forEach((file: File) => {
      if (!file.type.startsWith('image/')) {
        setErrorMsg('Please upload valid image files only.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPhotos(prev => [...prev, reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleVideosUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    Array.from(files).forEach((file: File) => {
      if (!file.type.startsWith('video/')) {
        setErrorMsg('Please upload valid video files only.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setVideos(prev => [...prev, reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const removeVideo = (index: number) => {
    setVideos(prev => prev.filter((_, i) => i !== index));
  };

  if (!isOpen) return null;

  const handlePhotoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please upload a valid image file (PNG, JPG, SVG, WebP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setLogoUrl(reader.result);
        setLogoStyle('photo');
      }
    };
    reader.readAsDataURL(file);
  };

  // Quota status for each type
  const marketCapacity = getMarketCoinCapacity(existingCoins);
  const stableQuota = canUserReleaseCoin(existingCoins, userId, 'stable_coin', isAdmin && issueAsAdmin);
  const finalQuota = canUserReleaseFinalCoin(existingCoins, userId, isAdmin && issueAsAdmin);
  const cryptoQuota = canUserReleaseCoin(existingCoins, userId, 'crypto', isAdmin && issueAsAdmin);

  const currentQuota = coinType === 'stable_coin' ? stableQuota : coinType === 'crypto' ? cryptoQuota : finalQuota;

  // Auto configure defaults on type change
  const handleTypeChange = (type: CustomCoinType) => {
    setCoinType(type);
    setErrorMsg('');
    if (type === 'stable_coin') {
      const isUserIssuingAdmin = isAdmin && issueAsAdmin;
      const initialPeg: PegCurrency = isUserIssuingAdmin ? pegCurrency : 'USD';
      setPegCurrency(initialPeg);
      setSelectedIcon(initialPeg === 'INR' ? '₹' : '$');
      setSelectedColor(initialPeg === 'INR' ? COLOR_PRESETS[4] : COLOR_PRESETS[0]);
      setCollateralAssetType(initialPeg === 'INR' ? 'INR Bank Escrow & Sovereign RBI Bonds' : 'US Treasury Escrow & Cash Reserves');
      setReserveBackingDescription(initialPeg === 'INR' ? '100% Fully Backed by Indian Rupee (INR) Bank Reserves in sovereign custody.' : '100% Fully Backed by US Dollar Cash & Short-Term US Treasury Bills.');
    } else if (type === 'crypto') {
      setSelectedIcon('💎');
      setSelectedColor(COLOR_PRESETS[2]);
      setPegCurrency('none');
      setCollateralAssetType('Proof-of-Stake Validator Collateral & Market Liquidity Pool');
      setReserveBackingDescription('Dynamic Cryptocurrency Market Reserve backed by Proof-of-Stake validator nodes & autonomous liquidity.');
    } else if (type === 'final_coin') {
      setSelectedIcon('⚡');
      setSelectedColor(COLOR_PRESETS[1]);
      setPegCurrency('none');
      setCollateralAssetType('Final Admin Coin (AFNL) 1:1 Vault');
      setReserveBackingDescription('100% Backed by Final Admin Coin (AFNL) at exact 1:1 ratio.');
    }
  };

  const handlePegChange = (peg: PegCurrency) => {
    setPegCurrency(peg);
    if (peg === 'INR') {
      setSelectedIcon('₹');
      setSelectedColor(COLOR_PRESETS[4]);
      setCollateralAssetType('INR Bank Escrow & Sovereign RBI Bonds');
      setReserveBackingDescription('100% Fully Backed by Indian Rupee (INR) Bank Reserves in sovereign custody.');
    } else if (peg === 'USD') {
      setSelectedIcon('$');
      setSelectedColor(COLOR_PRESETS[0]);
      setCollateralAssetType('US Treasury Escrow & Cash Reserves');
      setReserveBackingDescription('100% Fully Backed by US Dollar Cash & Short-Term US Treasury Bills.');
    }
  };

  const calculateEffectivePrice = () => {
    if (coinType === 'stable_coin') {
      if ((isAdmin && issueAsAdmin) && pegCurrency === 'INR') {
        return INR_TO_USD_RATE; // 0.0116
      }
      return 1.00; // $1.00 USD (All user stablecoins are 1:1 USD)
    } else if (coinType === 'crypto') {
      return Math.max(0.0001, customPriceUSD || 10.00);
    } else {
      return Math.max(0.0001, customPriceUSD || 28.75);
    }
  };

  const effectivePriceUSD = calculateEffectivePrice();
  const calculatedMarketCapUSD = (circulatingSupply || 0) * effectivePriceUSD;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Reserved names validation (Absolute: no one can claim them, not even admins)
    const reservedNames = [
      'stable coin',
      'stable coins',
      'final coin',
      'final coins',
      'cryptocurrency',
      'cryptocurrencies',
      'crypto-currency',
      'crypto-currencies'
    ];
    if (reservedNames.includes(name.trim().toLowerCase())) {
      setErrorMsg(`"${name}" is a reserved system name. No one can claim it, not even administrators.`);
      return;
    }

    // Duplicate name validation (Globally unique across all users' coins)
    if (existingCoins.some(coin => coin.name.toLowerCase() === name.trim().toLowerCase())) {
        setErrorMsg(`A coin with the name "${name}" already exists on the platform. All coin names must be globally unique.`);
        return;
    }

    // Duplicate symbol / handle validation (Globally unique across all users' coins)
    if (!symbol.trim() || symbol.length < 2 || symbol.length > 8) {
      setErrorMsg('Coin Ticker / Symbol must be between 2 and 8 characters.');
      return;
    }
    if (existingCoins.some(coin => coin.symbol.toUpperCase() === symbol.trim().toUpperCase())) {
      setErrorMsg(`The coin handle/ticker "${symbol.trim().toUpperCase()}" is already claimed. Each coin handle must be globally unique.`);
      return;
    }
    if (totalSupply <= 0) {
      setErrorMsg('Total Supply must be greater than zero.');
      return;
    }
    if (circulatingSupply > totalSupply) {
      setErrorMsg('Circulating supply cannot exceed total supply.');
      return;
    }

    if (!currentQuota.allowed) {
      if (coinType === 'final_coin') {
        setErrorMsg(finalQuota.reason || `Maximum Final Coin limit reached: You can create up to ${MAX_FINAL_COINS_PER_USER} sovereign Final Coins.`);
      } else {
        setErrorMsg(`Type quota reached: You have reached the maximum allowed ${coinType.replace('_', ' ')}s.`);
      }
      return;
    }

    setIsSubmitting(true);

    const randomHex = Math.random().toString(16).substring(2, 10) + Math.random().toString(16).substring(2, 10);
    const contractAddress = `0x${symbol.toUpperCase()}${randomHex.substring(0, 32)}`;

    let effectivePegCurrency: PegCurrency = 'none';
    let pegTargetDisplay = '1:1 Pegged to Final Admin Coin (AFNL)';

    if (coinType === 'stable_coin') {
      effectivePegCurrency = pegCurrency;

      if (effectivePegCurrency === 'INR') {
        pegTargetDisplay = '₹1.00 INR (Indian Rupee Pegged)';
      } else {
        pegTargetDisplay = '$1.00 USD (US Dollar Pegged)';
      }
    } else if (coinType === 'crypto') {
      effectivePegCurrency = 'none';
      pegTargetDisplay = 'Floating Cryptocurrency (Market Valuation)';
    } else {
      effectivePegCurrency = 'none';
      pegTargetDisplay = 'Sovereign Asset (Unpegged)';
    }

    // Market capacity status check: Max 10 active coins total in the live market
    const marketCapacity = getMarketCoinCapacity(existingCoins);
    const isLiveMarketEligible = !marketCapacity.isMarketFull;

    const newCoin: CustomCoin = {
      id: `custom_coin_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      name: name.trim(),
      symbol: symbol.trim().toUpperCase(),
      coinType,
      pegCurrency: effectivePegCurrency,
      pegTargetDisplay,
      pegRateUSD: coinType === 'final_coin' ? 0 : effectivePriceUSD,
      priceUSD: coinType === 'final_coin' ? 0 : effectivePriceUSD,
      totalSupply,
      circulatingSupply,
      burnedSupply: 0,
      reserveRatioPercent: coinType === 'final_coin' ? 0 : Math.max(100, reserveRatioPercent || 100),
      reserveBackingDescription: reserveBackingDescription || 'Standard Sovereign Collateral Vault',
      collateralAssetType,
      decimals: 18,
      creatorId: isAdmin && issueAsAdmin ? 'admin' : userId,
      creatorName: isAdmin && issueAsAdmin ? 'System Protocol Admin' : userName,
      creatorHandle: isAdmin && issueAsAdmin ? 'protocol_admin' : userHandle,
      isAdminCoin: Boolean(isAdmin && issueAsAdmin),
      createdAt: new Date().toISOString(),
      contractAddress,
      network,
      logoBg: selectedColor.bg,
      iconSymbol: selectedIcon,
      logoUrl: logoStyle === 'photo' && logoUrl.trim() ? logoUrl.trim() : undefined,
      description: description.trim() || `${name} (${symbol.toUpperCase()}) sovereign digital token deployed on ${network}.`,
      photos,
      videos,
      status: isLiveMarketEligible ? 'active' : 'paused',
      auditScore: 98,
      holdersCount: 1,
      dailyVolumeUSD: Math.round(calculatedMarketCapUSD * 0.05),
      change24h: 0.0,
      high24h: effectivePriceUSD,
      low24h: effectivePriceUSD
    };

    setTimeout(() => {
      onCoinReleased(newCoin);
      setIsSubmitting(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-8 text-left">
        
        {/* Header */}
        <div className="p-6 bg-slate-50 text-slate-900 flex items-center justify-between border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400 shadow-inner">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-xl font-bold tracking-tight">Deploy &amp; Release New Coin</h2>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-900 border border-amber-400/30">
                  {coinType === 'final_coin' ? `Final Coin (Max 5, 1 at a time)` : 'Sovereign Deployment'}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Issue your own Stable Coin (USD or INR pegged), Final Coin (max 5 created, 1 deploying at a time), or Cryptocurrency.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-500 hover:text-slate-900 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quota & Market Capacity Indicator Bar */}
        <div className="bg-slate-100 px-6 py-3 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-500 font-semibold">Mint Quotas:</span>
            <div className="flex items-center gap-1.5 font-mono text-[11px] flex-wrap">
              <span className={`px-2 py-0.5 rounded-md ${coinType === 'stable_coin' ? 'bg-emerald-500/20 text-emerald-800 font-bold border border-emerald-500/30' : 'bg-slate-200/60 text-slate-600'}`}>
                🛡️ Stable: {stableQuota.currentCount}/10
              </span>
              <span className={`px-2 py-0.5 rounded-md ${coinType === 'final_coin' ? 'bg-amber-500/20 text-amber-800 font-bold border border-amber-500/30' : 'bg-slate-200/60 text-slate-600'}`}>
                ⚡ Final: {finalQuota.currentCount}/5 (Max 5, 1 at a time)
              </span>
              <span className={`px-2 py-0.5 rounded-md ${coinType === 'crypto' ? 'bg-purple-500/20 text-purple-800 font-bold border border-purple-500/30' : 'bg-slate-200/60 text-slate-600'}`}>
                💎 Crypto: {cryptoQuota.currentCount}/10
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono text-[11px] shrink-0">
            <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-700 border border-indigo-500/20 font-bold flex items-center gap-1.5">
              <span>🏛️ Live Market:</span>
              <span className="font-extrabold">{marketCapacity.totalActiveInMarket}/10 Total Active</span>
            </span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {errorMsg && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* 1. SELECT COIN ARCHETYPE (STABLE vs FINAL vs CRYPTO) */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              1. Coin Archetype
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              
              {/* Stable Coin Card */}
              <button
                type="button"
                onClick={() => handleTypeChange('stable_coin')}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                  coinType === 'stable_coin'
                    ? 'bg-emerald-50/90 border-emerald-500 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'bg-white hover:bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                    1:1 Fiat Pegged
                  </span>
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 flex items-center justify-between">
                    <span>Stable Coin</span>
                    <span className="text-[10px] font-mono text-slate-400">{stableQuota.currentCount}/10</span>
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                    {isAdmin && issueAsAdmin
                      ? 'Pegged to US Dollar ($USD) or Indian Rupee (₹INR). Sovereign protocol reserve.'
                      : 'Pegged 1:1 to the US Dollar ($USD). Backed by fiat/treasury reserves.'}
                  </p>
                </div>
              </button>

              {/* Final Coin Card */}
              <button
                type="button"
                onClick={() => handleTypeChange('final_coin')}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                  coinType === 'final_coin'
                    ? 'bg-amber-50/90 border-amber-500 ring-2 ring-amber-500/20 shadow-xs'
                    : 'bg-white hover:bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                    <Zap className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                    Pegged to Nothing
                  </span>
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 flex items-center justify-between">
                    <span>Final Coin</span>
                    <span className="text-[10px] font-mono text-slate-400">{finalQuota.currentCount}/10</span>
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                    Pegged to nothing. Sovereign unpegged valuation backed by organic protocol reserve.
                  </p>
                </div>
              </button>

              {/* Cryptocurrency Card */}
              <button
                type="button"
                onClick={() => handleTypeChange('crypto')}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                  coinType === 'crypto'
                    ? 'bg-purple-50/90 border-purple-500 ring-2 ring-purple-500/20 shadow-xs'
                    : 'bg-white hover:bg-slate-50 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold">
                    <Coins className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-800">
                    Floating Market
                  </span>
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 flex items-center justify-between">
                    <span>Cryptocurrency</span>
                    <span className="text-[10px] font-mono text-slate-400">{cryptoQuota.currentCount}/10</span>
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                    Unpegged floating crypto token. Valuation moves dynamically via global market valuation ratios.
                  </p>
                </div>
              </button>

            </div>
          </div>

          {/* 2. PEG CURRENCY & PRICING RULES */}
          {coinType === 'stable_coin' && (
            <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Stable Coin Peg Rules</span>
                </label>
                <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-lg border border-emerald-200 text-[10px] font-mono font-bold text-emerald-900">
                  <Activity className={`w-3 h-3 ${rateTrend === 'up' ? 'text-emerald-600' : rateTrend === 'down' ? 'text-rose-600' : 'text-blue-600'}`} />
                  <span>Live USD/INR Valuation: ₹{liveUsdInrRate.toFixed(2)}</span>
                </div>
              </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => handlePegChange('USD')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                      pegCurrency === 'USD'
                        ? 'bg-white border-emerald-600 ring-2 ring-emerald-500/30 shadow-xs'
                        : 'bg-emerald-100/40 hover:bg-white border-emerald-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                        $
                      </div>
                      <div>
                        <h5 className="font-bold text-xs text-slate-900">US Dollar ($USD)</h5>
                        <span className="text-[10px] text-emerald-800 font-mono">1 Token = $1.00 USD</span>
                      </div>
                    </div>
                    {pegCurrency === 'USD' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePegChange('INR')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                      pegCurrency === 'INR'
                        ? 'bg-white border-orange-500 ring-2 ring-orange-500/30 shadow-xs'
                        : 'bg-orange-50/50 hover:bg-white border-orange-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-orange-500 to-amber-600 text-white flex items-center justify-center font-bold text-sm">
                        ₹
                      </div>
                      <div>
                        <h5 className="font-bold text-xs text-slate-900">Indian Rupee (₹INR)</h5>
                        <span className="text-[10px] text-orange-700 font-mono">1 INR = ~$({(1 / liveUsdInrRate).toFixed(4)}) USD</span>
                      </div>
                    </div>
                    {pegCurrency === 'INR' && <CheckCircle2 className="w-4 h-4 text-orange-600" />}
                  </button>
                </div>
            </div>
          )}

          {coinType === 'crypto' && (
            <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-purple-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Coins className="w-3.5 h-3.5 text-purple-600" />
                  <span>Cryptocurrency Valuation Ratio</span>
                </label>
                <span className="text-[10px] font-mono text-purple-700">Floating Market Rate</span>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-purple-200 text-xs text-slate-700 flex items-center gap-3">
                <TrendingUp className="w-5 h-5 text-purple-600 shrink-0" />
                <span>
                  <strong>Normal Cryptocurrency Mechanics:</strong> This cryptocurrency is unpegged. Its exchange rate floats dynamically on open exchange markets based on supply, demand, and trading volume.
                </span>
              </div>
            </div>
          )}

          {/* 3. BASIC TOKEN PARAMETERS (NAME, TICKER, PRICE) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Token Name */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700  block">
                Token Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Nebula Final Coin"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Token Ticker */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700  block">
                Symbol / Ticker <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                maxLength={8}
                value={symbol}
                onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                placeholder={
                  coinType === 'stable_coin'
                    ? pegCurrency === 'INR' ? 'e.g. BSR' : 'e.g. ASD'
                    : coinType === 'final_coin'
                    ? 'e.g. NBL'
                    : 'e.g. QYT'
                }
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono font-bold text-slate-900 placeholder-slate-400 uppercase focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Total Supply */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700  block">
                Total Supply Minted
              </label>
              <input
                type="number"
                min={100}
                max={100000000000}
                value={totalSupply}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setTotalSupply(val);
                  if (circulatingSupply > val) setCirculatingSupply(val);
                }}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Circulating Supply */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700  block">
                Initial Circulating Supply
              </label>
              <input
                type="number"
                min={1}
                max={totalSupply}
                value={circulatingSupply}
                onChange={(e) => setCirculatingSupply(Number(e.target.value))}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

          </div>

          {/* 4. VISUAL BADGE & LOGO PHOTO CUSTOMIZATION */}
          <div className="space-y-4 pt-3 border-t border-slate-100 ">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <label className="text-xs font-bold text-slate-700  uppercase tracking-wider block">
                4. Coin Visual Branding &amp; Logo Design
              </label>
              
              <div className="flex items-center gap-1.5 p-1 bg-slate-100  rounded-xl">
                <button
                  type="button"
                  onClick={() => setLogoStyle('icon')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    logoStyle === 'icon'
                      ? 'bg-white  text-slate-900  shadow-xs'
                      : 'text-slate-500 hover:text-slate-800 '
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Emblem / Symbol</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLogoStyle('photo')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    logoStyle === 'photo'
                      ? 'bg-amber-500 text-slate-950 shadow-xs font-extrabold'
                      : 'text-slate-500 hover:text-slate-800 '
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>📸 Custom Photo Logo</span>
                </button>
              </div>
            </div>

            {/* Sub-section: Custom Photo Logo */}
            {logoStyle === 'photo' ? (
              <div className="p-4 rounded-2xl bg-amber-500/5 border border-amber-500/20 space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                  {/* Photo Logo Preview Circle/Box */}
                  <div className="relative w-16 h-16 rounded-2xl overflow-hidden bg-white border-2 border-amber-500 shadow-md shrink-0 flex items-center justify-center text-slate-400">
                    {logoUrl ? (
                      <img src={logoUrl} alt="Coin Logo" className="w-full h-full object-cover" />
                    ) : (
                      <ImageIcon className="w-7 h-7 text-amber-400/60" />
                    )}
                  </div>

                  <div className="space-y-2 flex-1 w-full">
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={handlePhotoFileUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3.5 py-2 rounded-xl bg-white text-slate-800 border border-slate-200 hover:bg-slate-50 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                      >
                        <Upload className="w-3.5 h-3.5 text-amber-400" />
                        <span>Upload Photo / Logo</span>
                      </button>

                      {logoUrl && (
                        <button
                          type="button"
                          onClick={() => setLogoUrl('')}
                          className="px-3 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-700 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Clear Photo</span>
                        </button>
                      )}
                    </div>

                    {/* Direct Image URL input */}
                    <div className="relative">
                      <Link className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="url"
                        value={logoUrl}
                        onChange={(e) => setLogoUrl(e.target.value)}
                        placeholder="Or paste any direct image URL (https://...)"
                        className="w-full pl-8 pr-3.5 py-2 rounded-xl bg-white  border border-slate-200  text-xs text-slate-900  placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Curated Preset Coin Photos */}
                <div className="space-y-2 pt-2 border-t border-amber-500/10">
                  <span className="text-[11px] font-bold text-slate-600  block">
                    Or select a curated sovereign emblem photograph:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                    {PHOTO_PRESETS.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setLogoUrl(p.url);
                          setLogoStyle('photo');
                        }}
                        className={`p-1.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                          logoUrl === p.url
                            ? 'bg-amber-500/20 border-amber-500 ring-2 ring-amber-500/30'
                            : 'bg-white  border-slate-200  hover:border-amber-400'
                        }`}
                        title={p.label}
                      >
                        <img src={p.url} alt={p.label} className="w-7 h-7 rounded-lg object-cover shrink-0" />
                        <span className="text-[10px] font-semibold text-slate-700  truncate">
                          {p.label.split(' ')[0]}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              /* Sub-section: Preset Colors & Icon Emblems */
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50  border border-slate-200 ">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700  block">
                    Badge Color Preset
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {COLOR_PRESETS.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setSelectedColor(c)}
                        className={`w-7 h-7 rounded-lg bg-gradient-to-br ${c.bg} transition-all cursor-pointer flex items-center justify-center ${
                          selectedColor.id === c.id ? 'ring-2 ring-slate-900 scale-110 shadow-xs' : 'opacity-80 hover:opacity-100'
                        }`}
                        title={c.label}
                      >
                        {selectedColor.id === c.id && <CheckCircle2 className="w-3.5 h-3.5 text-white drop-shadow-sm" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700  block">
                    Emblem / Icon
                  </label>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {ICONS.map((ic) => (
                      <button
                        key={ic}
                        type="button"
                        onClick={() => setSelectedIcon(ic)}
                        className={`w-7 h-7 rounded-lg border text-sm flex items-center justify-center transition-all cursor-pointer ${
                          selectedIcon === ic ? 'bg-indigo-600 text-white border-indigo-600 scale-110 shadow-xs' : 'bg-slate-50 hover:bg-slate-100 border-slate-200'
                        }`}
                      >
                        {ic}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 6. COIN DESCRIPTION, PHOTOS & VIDEOS PITCH */}
          <div className="space-y-4 pt-4 border-t border-slate-100 ">
            <label className="text-xs font-bold text-slate-700  uppercase tracking-wider block">
              6. Coin Description, Photos &amp; Videos Pitch
            </label>

            {/* Small Description */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700  block">
                Small Description / Project Pitch
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Give a brief description, mission statement, or pitch for your new coin to attract backers and holders..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Media Upload (Photos & Videos) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Photos upload */}
              <div className="space-y-2 p-4 rounded-2xl bg-slate-50  border border-slate-200 ">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 ">
                    📸 Pitch Photos Gallery ({photos.length})
                  </span>
                  <input
                    type="file"
                    ref={photosFileInputRef}
                    accept="image/*"
                    multiple
                    onChange={handleAdditionalPhotosUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => photosFileInputRef.current?.click()}
                    className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100  text-indigo-600  text-xs font-bold transition-colors cursor-pointer"
                  >
                    + Add Photos
                  </button>
                </div>
                
                {photos.length === 0 ? (
                  <p className="text-[11px] text-slate-400 italic">No photos uploaded yet.</p>
                ) : (
                  <div className="grid grid-cols-4 gap-2 max-h-32 overflow-y-auto pt-1">
                    {photos.map((photo, idx) => (
                      <div key={idx} className="relative aspect-square rounded-lg overflow-hidden border border-slate-200 group">
                        <img src={photo} alt={`Uploaded ${idx}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => removePhoto(idx)}
                          className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity duration-150 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4 text-rose-400" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Videos upload */}
              <div className="space-y-2 p-4 rounded-2xl bg-slate-50  border border-slate-200 ">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 ">
                    🎥 Presentation Videos ({videos.length})
                  </span>
                  <input
                    type="file"
                    ref={videosFileInputRef}
                    accept="video/*"
                    multiple
                    onChange={handleVideosUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => videosFileInputRef.current?.click()}
                    className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100  text-indigo-600  text-xs font-bold transition-colors cursor-pointer"
                  >
                    + Add Videos
                  </button>
                </div>

                {videos.length === 0 ? (
                  <p className="text-[11px] text-slate-400 italic">No presentation videos uploaded yet.</p>
                ) : (
                  <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto pt-1">
                    {videos.map((video, idx) => (
                      <div key={idx} className="relative aspect-video rounded-lg overflow-hidden border border-slate-200 bg-slate-100 group">
                        <video src={video} className="w-full h-full object-cover" muted />
                        <div className="absolute bottom-1 left-1.5 text-[9px] text-white bg-black/50 px-1 py-0.5 rounded font-mono">
                          Video {idx + 1}
                        </div>
                        <button
                          type="button"
                          onClick={() => removeVideo(idx)}
                          className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity duration-150 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4 text-rose-400" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Admin Issue Option (if admin) */}
          {isAdmin && (
            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                  👑
                </div>
                <div>
                  <h5 className="font-bold text-xs text-slate-900 ">Issue as Official Admin Coin</h5>
                  <p className="text-[11px] text-slate-600 ">Tags coin with gold institutional verified protocol badge.</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={issueAsAdmin}
                onChange={(e) => setIssueAsAdmin(e.target.checked)}
                className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
              />
            </div>
          )}

          {/* Real-time Preview */}
          <div className="p-4 rounded-2xl bg-slate-50 text-slate-900 border border-slate-200 space-y-3 shadow-md">
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Live Mint Preview
              </span>
              <span>Layer-1 Smart Contract</span>
            </div>

            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {logoStyle === 'photo' && logoUrl ? (
                  <div className="w-12 h-12 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-md shrink-0 bg-white">
                    <img src={logoUrl} alt={name || 'Coin Logo'} className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${selectedColor.bg} flex items-center justify-center text-xl font-bold shadow-md shrink-0`}>
                    {selectedIcon}
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-slate-900">{name || 'Your Coin Name'}</h4>
                    <span className="font-mono text-xs font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                      ${symbol || 'TICKER'}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    ⚡ Unpegged Final Coin
                  </span>
                </div>
              </div>

              <div className="text-right font-mono">
                <span className="text-[10px] uppercase text-slate-400 block">Unit Price</span>
                <span className="text-base font-bold text-emerald-400">
                  {effectivePriceUSD >= 1 ? `$${effectivePriceUSD.toFixed(2)}` : `$${effectivePriceUSD.toFixed(4)}`}
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Cap: ${(calculatedMarketCapUSD / 1000000).toFixed(2)}M
                </span>
              </div>
            </div>
          </div>

          {/* Footer & Submit */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200 ">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200   text-slate-700  text-xs font-bold transition-colors cursor-pointer"
            >
              Cancel
            </button>

            {/* Large Prominent Deploy & Mint Coin Button */}
            <button
              type="submit"
              disabled={isSubmitting || !currentQuota.allowed}
              className={`w-full sm:w-auto px-8 py-3.5 rounded-2xl text-xs sm:text-sm font-extrabold transition-all shadow-lg flex items-center justify-center gap-2.5 cursor-pointer whitespace-nowrap ${
                currentQuota.allowed
                  ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/25 hover:shadow-amber-500/40 hover:scale-[1.02] active:scale-[0.98]'
                  : 'bg-slate-300  text-slate-500 cursor-not-allowed'
              }`}
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Broadcasting to Ledger...</span>
                </span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950 shrink-0" />
                  <span>Deploy &amp; Mint Coin ({currentQuota.currentCount + 1}/10)</span>
                  <ArrowRight className="w-4 h-4 text-slate-950 shrink-0" />
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
