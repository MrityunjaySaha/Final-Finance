import React, { useState, useEffect, useMemo } from 'react';
import {
  Ticket,
  Store,
  UtensilsCrossed,
  Car,
  Plus,
  CheckCircle2,
  PauseCircle,
  PlayCircle,
  Trash2,
  ShieldCheck,
  AlertCircle,
  Sparkles,
  Search,
  History,
  Check,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import {
  CouponCategory,
  CouponChannel,
  CouponDiscountType,
  CouponIssuerRole,
  PlatformCoupon,
} from '../types/coupon';
import {
  COUPONS_UPDATED_EVENT,
  deleteIssuedCoupon,
  getAllPlatformCoupons,
  getCouponsIssuedByUser,
  getUserCouponIssuerCapabilities,
  issuePlatformCoupon,
  toggleCouponActiveStatus,
} from '../services/couponService';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { BASE_FINAL_CURRENCIES } from './PointOfSaleView';
import { getAllPlatformFinalCoins } from '../services/fundraisingService';

interface CouponIssuerWidgetProps {
  currentUser: AuthSession | null;
  fixedRole?: CouponIssuerRole;
  fixedLocationId?: string;
  fixedLocationName?: string;
  defaultLocationId?: string;
  onOpenVerificationModal?: (tier?: 1 | 2 | 3) => void;
  onNavigateToPOS?: (tab?: 'retail' | 'restaurant') => void;
  onNavigateToRideShare?: () => void;
}

const DRIVER_VEHICLE_SLOTS: Array<{
  key: 'all' | 'car' | 'auto_rickshaw' | 'motor_bike';
  label: string;
  value: string;
}> = [
  { key: 'all', label: 'All 3 Vehicle Types', value: 'All Vehicles (Car, Auto Rickshaw, Motor Bike)' },
  { key: 'car', label: 'Car', value: 'Car' },
  { key: 'auto_rickshaw', label: 'Auto Rickshaw', value: 'Auto Rickshaw' },
  { key: 'motor_bike', label: 'Motor Bike', value: 'Motor Bike' },
];

export const CouponIssuerWidget: React.FC<CouponIssuerWidgetProps> = ({
  currentUser,
  fixedRole,
  fixedLocationId,
  fixedLocationName,
  defaultLocationId,
  onOpenVerificationModal,
  onNavigateToPOS,
  onNavigateToRideShare,
}) => {
  const userId = currentUser?.id || currentUser?.uid || 'guest';
  const [role, setRole] = useState<CouponIssuerRole>(fixedRole || 'restaurant_owner');
  const [allCoupons, setAllCoupons] = useState<PlatformCoupon[]>(() => getAllPlatformCoupons());
  const [coinsVersion, setCoinsVersion] = useState(0);
  const [historyFilter, setHistoryFilter] = useState<'all' | CouponCategory>('all');

  const capabilities = useMemo(
    () => getUserCouponIssuerCapabilities(currentUser),
    [currentUser, allCoupons]
  );

  // Sync role when fixedRole prop changes
  useEffect(() => {
    if (fixedRole) setRole(fixedRole);
  }, [fixedRole]);

  useEffect(() => {
    const sync = () => setAllCoupons(getAllPlatformCoupons());
    const syncCoins = () => setCoinsVersion((v) => v + 1);
    window.addEventListener(COUPONS_UPDATED_EVENT, sync);
    window.addEventListener('final_finance_custom_coins_updated', syncCoins);
    window.addEventListener('final_finance_wallets_updated', syncCoins);
    window.addEventListener('storage', sync);
    window.addEventListener('storage', syncCoins);
    return () => {
      window.removeEventListener(COUPONS_UPDATED_EVENT, sync);
      window.removeEventListener('final_finance_custom_coins_updated', syncCoins);
      window.removeEventListener('final_finance_wallets_updated', syncCoins);
      window.removeEventListener('storage', sync);
      window.removeEventListener('storage', syncCoins);
    };
  }, []);

  const allPlatformFinalCurrencies = useMemo(() => {
    const map = new Map<string, { symbol: string; name: string }>();
    BASE_FINAL_CURRENCIES.forEach((c) => {
      const sym = c.symbol.trim().toUpperCase();
      map.set(sym, { symbol: sym, name: c.name });
    });
    getAllPlatformFinalCoins(userId).forEach((fc) => {
      const sym = fc.symbol.trim().toUpperCase();
      if (!map.has(sym)) {
        map.set(sym, { symbol: sym, name: fc.name || sym });
      }
    });
    return Array.from(map.values());
  }, [userId, coinsVersion]);

  const [code, setCode] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [locationSearchQuery, setLocationSearchQuery] = useState('');
  const [selectedLocationId, setSelectedLocationId] = useState(
    fixedLocationId || defaultLocationId || 'custom'
  );
  const [customMerchantName, setCustomMerchantName] = useState(fixedLocationName || '');
  const [vehicleType, setVehicleType] = useState('All Vehicles (Car, Auto Rickshaw, Motor Bike)');
  const [discountType, setDiscountType] = useState<CouponDiscountType>('percentage');
  const [discountValue, setDiscountValue] = useState('15');
  const [selectedCurrencies, setSelectedCurrencies] = useState<string[]>(['ANY']);
  const [currencySearchQuery, setCurrencySearchQuery] = useState('');
  const [minOrderAmount, setMinOrderAmount] = useState('20');
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('');
  const [validChannels, setValidChannels] = useState<CouponChannel>('both');
  const [expiresAt, setExpiresAt] = useState('2027-12-31');
  const [maxRedemptions, setMaxRedemptions] = useState('200');
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  // Strictly list ONLY the user's own restaurants or retail stores
  const ownedLocationsForRole = useMemo(() => {
    if (role === 'restaurant_owner') return capabilities.ownedRestaurants;
    if (role === 'retail_owner') return capabilities.ownedRetailStores;
    return [];
  }, [role, capabilities.ownedRestaurants, capabilities.ownedRetailStores]);

  const filteredOwnedLocations = useMemo(() => {
    const q = locationSearchQuery.trim().toLowerCase();
    if (!q) return ownedLocationsForRole;
    return ownedLocationsForRole.filter(
      (loc) =>
        loc.name.toLowerCase().includes(q) ||
        (loc.cuisineOrCategory || '').toLowerCase().includes(q) ||
        (loc.address || '').toLowerCase().includes(q)
    );
  }, [ownedLocationsForRole, locationSearchQuery]);

  // Map driver's registered 3 vehicle slots by type key
  const registeredDriverVehicleByType = useMemo(() => {
    const map: Record<string, (typeof capabilities.driverVehicles)[number] | undefined> = {};
    capabilities.driverVehicles.forEach((v) => {
      const vt = (v.vehicleType || '').toLowerCase();
      if (vt.includes('rickshaw')) map.auto_rickshaw = v;
      else if (vt.includes('moto') || vt.includes('bike')) map.motor_bike = v;
      else map.car = v;
    });
    return map;
  }, [capabilities.driverVehicles]);

  useEffect(() => {
    setLocationSearchQuery('');
    if (fixedLocationId) {
      setSelectedLocationId(fixedLocationId);
      if (fixedLocationName) setCustomMerchantName(fixedLocationName);
      return;
    }
    if (role === 'restaurant_owner' || role === 'retail_owner') {
      if (ownedLocationsForRole.length > 0) {
        const preferred =
          (defaultLocationId && ownedLocationsForRole.find((l) => l.id === defaultLocationId)) ||
          ownedLocationsForRole[0];
        setSelectedLocationId(preferred.id);
        setCustomMerchantName(preferred.name);
      } else {
        setSelectedLocationId('custom');
        setCustomMerchantName('');
      }
    } else {
      setSelectedLocationId('driver_fleet');
      setCustomMerchantName(`${currentUser?.name || 'Driver'} Ride-Share Fleet`);
      if (capabilities.driverVehicles.length === 1) {
        const only = capabilities.driverVehicles[0];
        setVehicleType(`${only.vehicleTypeLabel} · ${only.vehicleClass}`);
      } else {
        setVehicleType('All Vehicles (Car, Auto Rickshaw, Motor Bike)');
      }
    }
  }, [
    role,
    fixedLocationId,
    fixedLocationName,
    defaultLocationId,
    ownedLocationsForRole,
    capabilities.driverVehicles,
    currentUser?.name,
  ]);

  const roleAllowed = useMemo(() => {
    if (role === 'restaurant_owner') return capabilities.canIssueRestaurant;
    if (role === 'retail_owner') return capabilities.canIssueRetail;
    return capabilities.canIssueDriver;
  }, [role, capabilities]);

  const hasRequiredProfileForRole = useMemo(() => {
    if (fixedLocationId) return true;
    if (role === 'restaurant_owner') return ownedLocationsForRole.length > 0;
    if (role === 'retail_owner') return ownedLocationsForRole.length > 0;
    return capabilities.driverVehicles.length > 0;
  }, [fixedLocationId, role, ownedLocationsForRole.length, capabilities.driverVehicles.length]);

  const categoryForRole: CouponCategory =
    role === 'restaurant_owner'
      ? 'restaurant'
      : role === 'retail_owner'
        ? 'retail'
        : 'ride_share';

  const issuedByMeAll = useMemo(() => {
    const allMine = getCouponsIssuedByUser(currentUser, allCoupons);
    if (fixedRole) {
      return allMine.filter((c) => c.issuerRole === fixedRole);
    }
    return allMine;
  }, [currentUser, allCoupons, fixedRole]);

  const issuedRetailCoupons = useMemo(
    () => issuedByMeAll.filter((c) => c.category === 'retail'),
    [issuedByMeAll]
  );
  const issuedRestaurantCoupons = useMemo(
    () => issuedByMeAll.filter((c) => c.category === 'restaurant'),
    [issuedByMeAll]
  );
  const issuedDriverCoupons = useMemo(
    () => issuedByMeAll.filter((c) => c.category === 'ride_share'),
    [issuedByMeAll]
  );

  const handleGenerateCode = () => {
    const prefix =
      role === 'restaurant_owner' ? 'DINE' : role === 'retail_owner' ? 'SHOP' : 'RIDE';
    const suffix = Math.floor(100 + Math.random() * 900);
    setCode(`${prefix}${discountValue || '15'}-${suffix}`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    if (!currentUser) {
      setFormError('Please sign in to issue coupons.');
      return;
    }
    if (!hasRequiredProfileForRole) {
      setFormError(
        role === 'restaurant_owner'
          ? "You don't have a restaurant."
          : role === 'retail_owner'
            ? "You don't have a retail store."
            : 'Sign up for at least one of the 3 vehicle types first to issue driving coupons.'
      );
      return;
    }
    if (!roleAllowed) {
      setFormError(
        `Tier 2 Verification (2 Legal IDs) or an active ${
          role === 'restaurant_owner'
            ? 'Restaurant'
            : role === 'retail_owner'
              ? 'Retail Store'
              : 'Driver Fleet'
        } profile is required to issue coupons.`
      );
      return;
    }

    const matchedLoc = ownedLocationsForRole.find((l) => l.id === selectedLocationId);
    const resolvedMerchantName =
      role === 'driver'
        ? customMerchantName.trim() || `${currentUser.name || 'Sovereign'} Ride-Share Fleet`
        : fixedLocationName ||
          matchedLoc?.name ||
          (selectedLocationId === 'any'
            ? `All My ${role === 'restaurant_owner' ? 'Restaurants' : 'Retail Stores'}`
            : customMerchantName.trim()) ||
          (role === 'restaurant_owner' ? 'My Sovereign Restaurant' : 'My Sovereign Retail Store');

    const res = issuePlatformCoupon({
      code,
      title,
      description,
      category: categoryForRole,
      issuerRole: role,
      issuerId: userId,
      issuerHandle: currentUser.handle || `@${userId}`,
      issuerName: currentUser.name || userId,
      merchantLocationId:
        role === 'driver'
          ? undefined
          : fixedLocationId ||
            (selectedLocationId !== 'custom' ? selectedLocationId : undefined),
      merchantName: resolvedMerchantName,
      vehicleType: role === 'driver' ? vehicleType : undefined,
      discountType,
      discountValue: parseFloat(discountValue) || 0,
      currency: selectedCurrencies.includes('ANY') ? 'ANY' : selectedCurrencies.join(', '),
      minOrderAmount: parseFloat(minOrderAmount) || 0,
      maxDiscountAmount: maxDiscountAmount ? parseFloat(maxDiscountAmount) : undefined,
      validChannels,
      expiresAt,
      maxRedemptions: maxRedemptions ? parseInt(maxRedemptions, 10) : undefined,
    });

    if (!res.success || !res.coupon) {
      setFormError(res.error || 'Could not issue coupon.');
      return;
    }

    setCode('');
    setTitle('');
    setDescription('');
    setFormSuccess(`Coupon ${res.coupon.code} issued and live for customers!`);
    dispatchGlobalNotification({
      title: `Coupon Issued: ${res.coupon.code}`,
      description: `${res.coupon.title} is now live for ${
        validChannels === 'both'
          ? 'online & in-person'
          : validChannels === 'online'
            ? 'online'
            : 'in-person'
      } transactions.`,
      type: role === 'driver' ? 'ride_share' : 'pos',
      targetTab: 'coupons',
      showToast: true,
      tone: 'success',
    });
  };

  const renderIssuedCouponCard = (c: PlatformCoupon) => (
    <div
      key={c.id}
      className="w-full min-w-0 overflow-hidden p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2.5 text-center flex flex-col items-center justify-between"
    >
      <div className="w-full min-w-0 space-y-1 text-center">
        <div className="flex flex-wrap items-center justify-center gap-2 text-[10px] font-mono font-bold text-neutral-500">
          <span className="text-amber-700">{c.code}</span>
          <span>·</span>
          <span>
            {c.category === 'restaurant'
              ? 'Restaurant'
              : c.category === 'retail'
                ? 'Retail Store'
                : 'Driving'}
          </span>
          <span>·</span>
          <span className={c.active ? 'text-emerald-700' : 'text-rose-600'}>
            {c.active ? 'Active' : 'Paused'}
          </span>
        </div>
        <p className="w-full text-xs font-bold text-neutral-900 break-words leading-snug">{c.title}</p>
        <p className="w-full text-[11px] font-mono font-bold text-emerald-700 tabular-nums break-words">
          {c.discountType === 'percentage'
            ? `${c.discountValue}% Off${c.currency && c.currency !== 'ANY' ? ` (${c.currency})` : ''}`
            : `${c.discountValue} ${c.currency === 'ANY' ? 'Any Final Currency' : c.currency} Off`}
          {' · '}
          {c.validChannels === 'both'
            ? 'Online & In-Person'
            : c.validChannels === 'online'
              ? 'Online Only'
              : 'In-Person Only'}
        </p>
        <p className="w-full text-[10px] text-neutral-500 font-mono tabular-nums break-words">
          {c.merchantName}
          {c.vehicleType ? ` · ${c.vehicleType}` : ''}
        </p>
        <p className="text-[10px] text-neutral-400 font-mono tabular-nums">
          Issued {new Date(c.createdAt).toLocaleDateString()} · Redeemed {c.redemptionCount}
          {c.maxRedemptions ? `/${c.maxRedemptions}` : ''} · Exp {c.expiresAt}
        </p>
      </div>

      <div className="flex items-center justify-center gap-2 pt-1">
        <button
          type="button"
          onClick={() => toggleCouponActiveStatus(c.id, c.issuerId)}
          className="px-3 py-1.5 rounded-xl bg-white border border-neutral-200 hover:bg-neutral-100 text-[11px] font-bold text-neutral-700 inline-flex items-center gap-1 cursor-pointer"
        >
          {c.active ? (
            <>
              <PauseCircle className="w-3.5 h-3.5 text-amber-600" />
              <span>Pause</span>
            </>
          ) : (
            <>
              <PlayCircle className="w-3.5 h-3.5 text-emerald-600" />
              <span>Activate</span>
            </>
          )}
        </button>
        <button
          type="button"
          onClick={() => deleteIssuedCoupon(c.id, c.issuerId)}
          className="px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-200 hover:bg-rose-100 text-[11px] font-bold text-rose-700 inline-flex items-center gap-1 cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Delete</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 max-w-3xl mx-auto text-center">
      {/* Issuance Form Card */}
      <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-xs space-y-5 text-center">
        <div className="flex flex-col items-center justify-center gap-1.5 text-center">
          <div className="w-11 h-11 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center">
            <Ticket className="w-5 h-5" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-neutral-900">
            {fixedRole === 'restaurant_owner'
              ? 'Issue Restaurant Coupon'
              : fixedRole === 'retail_owner'
                ? 'Issue Retail Store Coupon'
                : fixedRole === 'driver'
                  ? 'Issue Driver Ride-Share Coupon'
                  : 'Issue Platform Coupon'}
          </h3>
          <p className="text-xs text-neutral-500 max-w-md mx-auto">
            Restaurant owners, retail store owners, and drivers can issue coupons usable for online checkout and in-person transactions.
          </p>
        </div>

        {/* Role Selector (when not locked by host page) */}
        {!fixedRole && (
          <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-neutral-100 rounded-2xl mx-auto">
            <button
              type="button"
              onClick={() => setRole('restaurant_owner')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                role === 'restaurant_owner'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>Restaurant Owner</span>
            </button>
            <button
              type="button"
              onClick={() => setRole('retail_owner')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                role === 'retail_owner'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              <span>Retail Store Owner</span>
            </button>
            <button
              type="button"
              onClick={() => setRole('driver')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                role === 'driver'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>Ride-Share Driver</span>
            </button>
          </div>
        )}

        {!hasRequiredProfileForRole ? (
          <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-1.5 text-center max-w-lg mx-auto">
            <AlertCircle className="w-6 h-6 text-amber-600 mx-auto" />
            <p className="text-xs font-bold text-neutral-900">
              {role === 'restaurant_owner'
                ? "You don't have a restaurant."
                : role === 'retail_owner'
                  ? "You don't have a retail store."
                  : "You haven't signed up for any of the 3 vehicle types yet."}
            </p>
            <p className="text-[11px] text-neutral-500">
              {role === 'driver'
                ? 'Sign up as a driver for a Car, Auto Rickshaw, or Motor Bike first to issue driving coupons.'
                : role === 'restaurant_owner'
                  ? 'Add or register a restaurant first before issuing restaurant coupons.'
                  : 'Add or register a retail store first before issuing retail coupons.'}
            </p>
          </div>
        ) : !roleAllowed ? (
          <div className="p-5 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-3 text-center max-w-lg mx-auto">
            <AlertCircle className="w-6 h-6 text-amber-600 mx-auto" />
            <p className="text-xs font-bold text-neutral-900">
              Tier 2 Verification Required to Issue{' '}
              {role === 'restaurant_owner'
                ? 'Restaurant'
                : role === 'retail_owner'
                  ? 'Retail Store'
                  : 'Driver'}{' '}
              Coupons
            </p>
            <p className="text-[11px] text-neutral-600">
              Complete Tier 2 verification (2 Legal IDs) to issue coupons.
            </p>
            {onOpenVerificationModal && (
              <button
                type="button"
                onClick={() => onOpenVerificationModal(2)}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1.5"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Complete Tier 2 Verification</span>
              </button>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs text-center max-w-xl mx-auto">
            {/* Searchable List of User's Own Restaurants / Retail Stores */}
            {!fixedLocationId && (role === 'restaurant_owner' || role === 'retail_owner') && (
              <div className="space-y-2.5 text-center p-4 rounded-2xl bg-neutral-50 border border-neutral-200">
                <label className="block font-bold text-neutral-800 text-center">
                  {role === 'restaurant_owner'
                    ? `Select Restaurant (${ownedLocationsForRole.length} Owned)`
                    : `Select Retail Store (${ownedLocationsForRole.length} Owned)`}
                </label>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={locationSearchQuery}
                    onChange={(e) => setLocationSearchQuery(e.target.value)}
                    placeholder={
                      role === 'restaurant_owner'
                        ? 'Search your restaurants by name, cuisine, or address...'
                        : 'Search your retail stores by name, category, or address...'
                    }
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div className="max-h-48 overflow-y-auto space-y-1.5 px-0.5">
                  {filteredOwnedLocations.length === 0 ? (
                    <p className="text-[11px] text-neutral-500 py-3">
                      No owned {role === 'restaurant_owner' ? 'restaurants' : 'retail stores'} match "{locationSearchQuery}".
                    </p>
                  ) : (
                    filteredOwnedLocations.map((loc) => {
                      const isSelected = selectedLocationId === loc.id;
                      return (
                        <button
                          key={loc.id}
                          type="button"
                          onClick={() => {
                            setSelectedLocationId(loc.id);
                            setCustomMerchantName(loc.name);
                          }}
                          className={`w-full p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                            isSelected
                              ? 'bg-amber-50 border-amber-500 ring-1 ring-amber-400 text-neutral-900'
                              : 'bg-white border-neutral-200 hover:border-neutral-300 text-neutral-700'
                          }`}
                        >
                          <div className="flex items-center justify-center gap-1.5 font-bold text-xs">
                            {isSelected && <Check className="w-3.5 h-3.5 text-amber-600 shrink-0" />}
                            <span>{loc.name}</span>
                          </div>
                          {(loc.cuisineOrCategory || loc.address) && (
                            <span className="text-[10px] text-neutral-500">
                              {[loc.cuisineOrCategory, loc.address].filter(Boolean).join(' · ')}
                            </span>
                          )}
                        </button>
                      );
                    })
                  )}

                  {ownedLocationsForRole.length > 1 && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedLocationId('any');
                        setCustomMerchantName(
                          `All My ${role === 'restaurant_owner' ? 'Restaurants' : 'Retail Stores'}`
                        );
                      }}
                      className={`w-full p-2 rounded-xl border text-center transition-all cursor-pointer text-[11px] font-bold ${
                        selectedLocationId === 'any'
                          ? 'bg-amber-50 border-amber-500 text-amber-900'
                          : 'bg-white border-dashed border-neutral-300 hover:border-neutral-400 text-neutral-600'
                      }`}
                    >
                      Apply to All My {role === 'restaurant_owner' ? 'Restaurants' : 'Retail Stores'} ({ownedLocationsForRole.length})
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Driver: Simple Fleet Name + Direct 3 Vehicle Type Selector (no search needed) */}
            {role === 'driver' && (
              <div className="space-y-3 p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                <div className="space-y-1.5 text-center">
                  <label className="block font-bold text-neutral-800 text-center">Driver Display / Fleet Name</label>
                  <input
                    type="text"
                    required
                    value={customMerchantName}
                    onChange={(e) => setCustomMerchantName(e.target.value)}
                    placeholder="e.g. Sovereign Express Fleet"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 text-center"
                  />
                </div>
                <div className="space-y-1.5 text-center">
                  <label className="block font-bold text-neutral-800 text-center">
                    Vehicle Type (1 Driver Slot per Type)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {DRIVER_VEHICLE_SLOTS.map((slot) => {
                      const registered =
                        slot.key === 'all' ? undefined : registeredDriverVehicleByType[slot.key];
                      const optionValue = registered
                        ? `${registered.vehicleTypeLabel} · ${registered.vehicleClass}`
                        : slot.value;
                      const isSelected = vehicleType === optionValue;
                      return (
                        <button
                          key={slot.key}
                          type="button"
                          onClick={() => setVehicleType(optionValue)}
                          className={`p-2 rounded-xl border text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-0.5 ${
                            isSelected
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : 'bg-white text-neutral-700 border-neutral-200 hover:border-neutral-300'
                          }`}
                        >
                          <span className="text-[11px] font-bold">{slot.label}</span>
                          {registered && (
                            <span
                              className={`text-[9px] truncate max-w-full ${
                                isSelected ? 'text-emerald-100' : 'text-neutral-400'
                              }`}
                            >
                              {registered.makeModel}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Coupon Code & Title */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
              <div className="space-y-1.5 text-center">
                <div className="flex items-center justify-center gap-2">
                  <label className="font-semibold text-neutral-700 text-center">Coupon Code *</label>
                  <button
                    type="button"
                    onClick={handleGenerateCode}
                    className="text-[10px] font-bold text-amber-700 hover:text-amber-900 underline inline-flex items-center gap-0.5 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Auto-Generate</span>
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="e.g. SAVE15"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center uppercase"
                />
              </div>
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">Offer Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 15% Off Weekend Orders"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 text-center"
                />
              </div>
            </div>

            {/* Discount Type, Value & Final Currency */}
            <div className={`grid grid-cols-1 gap-3 text-center ${discountType === 'percentage' ? 'sm:grid-cols-2 lg:grid-cols-4' : 'sm:grid-cols-3'}`}>
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">Discount Type</label>
                <select
                  value={discountType}
                  onChange={(e) => setDiscountType(e.target.value as CouponDiscountType)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-bold text-neutral-900 text-center"
                >
                  <option value="percentage">Percentage (% Off)</option>
                  <option value="fixed">Fixed Final Currency Off</option>
                </select>
              </div>
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">
                  {discountType === 'percentage' ? 'Percent Off (%)' : 'Amount Off (Final)'}
                </label>
                <input
                  type="number"
                  min="0.1"
                  max={discountType === 'percentage' ? 100 : undefined}
                  step="any"
                  required
                  value={discountValue}
                  onChange={(e) => setDiscountValue(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center tabular-nums"
                />
              </div>
              <div className="space-y-1.5 text-center sm:col-span-2 lg:col-span-3">
                <label className="block font-semibold text-neutral-700 text-center">
                  Final Currencies (Select Up to 5 — All Worth Same)
                </label>
                <div className="relative mb-2 max-w-sm mx-auto">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={currencySearchQuery}
                    onChange={(e) => setCurrencySearchQuery(e.target.value)}
                    placeholder="Search final currencies (e.g. AFNL, USDC, ALEX)..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div className="flex flex-wrap items-center justify-center gap-1.5 max-h-36 overflow-y-auto p-2 bg-neutral-50 border border-neutral-200 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setSelectedCurrencies(['ANY'])}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                      selectedCurrencies.includes('ANY')
                        ? 'bg-neutral-900 text-white'
                        : 'bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    ★ Any Final Currency (All Coins)
                  </button>
                  {allPlatformFinalCurrencies
                    .filter((c) => c.symbol.toLowerCase().includes(currencySearchQuery.toLowerCase()) || c.name.toLowerCase().includes(currencySearchQuery.toLowerCase()))
                    .map((c) => {
                      const isSelected = selectedCurrencies.includes(c.symbol);
                      return (
                        <button
                          key={c.symbol}
                          type="button"
                          onClick={() => {
                            if (selectedCurrencies.includes('ANY')) {
                              setSelectedCurrencies([c.symbol]);
                              return;
                            }
                            if (isSelected) {
                              const next = selectedCurrencies.filter((s) => s !== c.symbol);
                              setSelectedCurrencies(next.length === 0 ? ['ANY'] : next);
                            } else {
                              if (selectedCurrencies.length >= 5) {
                                alert('You can select up to 5 final currencies.');
                                return;
                              }
                              setSelectedCurrencies([...selectedCurrencies, c.symbol]);
                            }
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                          }`}
                        >
                          {c.symbol} — {c.name} {isSelected ? '✓' : ''}
                        </button>
                      );
                    })}
                </div>
              </div>
              {discountType === 'percentage' && (
                <div className="space-y-1.5 text-center">
                  <label className="block font-semibold text-neutral-700 text-center">
                    Max Discount Cap (Optional)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    placeholder="No cap"
                    value={maxDiscountAmount}
                    onChange={(e) => setMaxDiscountAmount(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center tabular-nums"
                  />
                </div>
              )}
            </div>

            {/* Transaction Channel Eligibility, Min Order, Expiry */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">Valid Transaction Type</label>
                <select
                  value={validChannels}
                  onChange={(e) => setValidChannels(e.target.value as CouponChannel)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-bold text-neutral-900 text-center"
                >
                  <option value="both">Both Online &amp; In-Person</option>
                  <option value="online">Online Transactions Only</option>
                  <option value="in_person">In-Person Transactions Only</option>
                </select>
              </div>
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">Min Order / Fare</label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={minOrderAmount}
                  onChange={(e) => setMinOrderAmount(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center tabular-nums"
                />
              </div>
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">Expiration Date</label>
                <input
                  type="date"
                  value={expiresAt}
                  onChange={(e) => setExpiresAt(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
              <div className="sm:col-span-2 space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">Description / Terms</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Valid for online orders and in-person checkout..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center"
                />
              </div>
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-neutral-700 text-center">Max Redemptions</label>
                <input
                  type="number"
                  min="1"
                  value={maxRedemptions}
                  onChange={(e) => setMaxRedemptions(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center tabular-nums"
                />
              </div>
            </div>

            {formError && (
              <p className="text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2 text-center">
                {formError}
              </p>
            )}
            {formSuccess && (
              <p className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2 text-center flex items-center justify-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{formSuccess}</span>
              </p>
            )}

            <button
              type="submit"
              className="w-full max-w-sm mx-auto py-3 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-bold transition-all cursor-pointer inline-flex items-center justify-center gap-2 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Issue Coupon</span>
            </button>
          </form>
        )}
      </div>

      {/* Issued Coupons History Section (3 Separate Sections: Retail, Restaurants, Driving) */}
      <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-xs space-y-6 text-center">
        <div className="space-y-1 text-center">
          <div className="inline-flex items-center justify-center gap-1.5 text-neutral-800">
            <History className="w-4 h-4 text-amber-600" />
            <h4 className="text-sm font-bold text-neutral-900">
              Issued Coupons History ({issuedByMeAll.length})
            </h4>
          </div>
        </div>

        {!fixedRole ? (
          <div className="space-y-6 text-center">
            {/* 1. Retail */}
            <div className="space-y-2.5 text-center">
              <div className="inline-flex items-center justify-center gap-1.5 text-xs font-bold text-indigo-800">
                <Store className="w-4 h-4 text-indigo-600" />
                <span>Retail ({issuedRetailCoupons.length})</span>
              </div>
              {issuedRetailCoupons.length === 0 ? (
                <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                  <p className="text-xs text-neutral-500">No retail coupons issued yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-center">
                  {issuedRetailCoupons.map(renderIssuedCouponCard)}
                </div>
              )}
            </div>

            {/* 2. Restaurants */}
            <div className="space-y-2.5 text-center pt-4 border-t border-neutral-100">
              <div className="inline-flex items-center justify-center gap-1.5 text-xs font-bold text-amber-800">
                <UtensilsCrossed className="w-4 h-4 text-amber-600" />
                <span>Restaurants ({issuedRestaurantCoupons.length})</span>
              </div>
              {issuedRestaurantCoupons.length === 0 ? (
                <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                  <p className="text-xs text-neutral-500">No restaurant coupons issued yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-center">
                  {issuedRestaurantCoupons.map(renderIssuedCouponCard)}
                </div>
              )}
            </div>

            {/* 3. Driving */}
            <div className="space-y-2.5 text-center pt-4 border-t border-neutral-100">
              <div className="inline-flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-800">
                <Car className="w-4 h-4 text-emerald-600" />
                <span>Driving ({issuedDriverCoupons.length})</span>
              </div>
              {issuedDriverCoupons.length === 0 ? (
                <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                  <p className="text-xs text-neutral-500">No driving coupons issued yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-center">
                  {issuedDriverCoupons.map(renderIssuedCouponCard)}
                </div>
              )}
            </div>
          </div>
        ) : issuedByMeAll.length === 0 ? (
          <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
            <p className="text-xs text-neutral-500">No issued coupons yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-center">
            {issuedByMeAll.map(renderIssuedCouponCard)}
          </div>
        )}
      </div>
    </div>
  );
};

