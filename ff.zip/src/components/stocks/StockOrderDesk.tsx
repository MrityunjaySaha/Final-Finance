import React, { useState, useEffect, useMemo } from 'react';
import { StockItem, StockOrder, StockPaymentSource, DerivativeType } from '../../types/stocks';
import { useApp } from '../../context/AppContext';
import { AuthSession } from '../../types/auth';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Wallet, 
  ShieldCheck, 
  AlertCircle,
  Zap,
  Lock,
  Calendar,
  Clock,
  X
} from 'lucide-react';
import {
  getAvailableStockPaymentSources,
  getAllSystemSellCurrencies,
  processStockPayment
} from '../../utils/stockWalletBridge';
import { ConfirmModal } from '../common/ConfirmModal';
import { SellCurrencyPicker } from './SellCurrencyPicker';
import { getLocalStockMarketStatus } from '../../utils/marketHours';
import { formatStockPrice, getUSDEquivalentString, getStockCurrencyCode, isFinalStock } from '../../utils/stockCurrencyFormatter';

function getDefaultFutureSettlementDate(): string {
  const future = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  return future.toISOString().split('T')[0];
}

function getTodayDateString(): string {
  return new Date().toISOString().split('T')[0];
}

interface StockOrderDeskProps {
  stock: StockItem;
  currentUser: AuthSession | null;
  onOpenAuthModal: () => void;
  onOpenLinkBankModal?: () => void;
  onOrderExecuted: (order: StockOrder) => void;
  preselectedOption?: {
    type: 'call' | 'put';
    strike: number;
    expiry: string;
    symbol: string;
  } | null;
}

export const StockOrderDesk: React.FC<StockOrderDeskProps> = ({
  stock,
  currentUser,
  onOpenAuthModal,
  onOpenLinkBankModal,
  onOrderExecuted,
  preselectedOption,
}) => {
  const { addToast, addTransaction } = useApp();
  const marketStatus = getLocalStockMarketStatus();
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [instrumentType, setInstrumentType] = useState<DerivativeType>('spot');
  const [orderType, setOrderType] = useState<'market' | 'limit' | 'stop'>('market');
  const [inputMode, setInputMode] = useState<'shares' | 'dollars'>('shares');
  const [sharesInput, setSharesInput] = useState<string>('10');
  const [dollarsInput, setDollarsInput] = useState<string>('1000');
  const [limitPriceInput, setLimitPriceInput] = useState<string>(stock.price.toFixed(2));
  
  // Derivative specific states
  const [strikePriceInput, setStrikePriceInput] = useState<string>(stock.price.toFixed(2));
  const [expiryDate, setExpiryDate] = useState<string>(() => getDefaultFutureSettlementDate());
  const [expiryTime, setExpiryTime] = useState<string>('16:00');
  const [leverageInput, setLeverageInput] = useState<string>('10');

  const [selectedSourceId, setSelectedSourceId] = useState<string>('');
  const [selectedSellCurrency, setSelectedSellCurrency] = useState<StockPaymentSource | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sourcesVersion, setSourcesVersion] = useState(0);
  const [showConfirm, setShowConfirm] = useState(false);
  const [orderError, setOrderError] = useState<string | null>(null);

  useEffect(() => {
    setOrderError(null);
  }, [instrumentType, side, dollarsInput, sharesInput, expiryDate, expiryTime, leverageInput, stock.ticker]);

  useEffect(() => {
    setSelectedSellCurrency(null);
  }, [stock.ticker]);

  useEffect(() => {
    if (preselectedOption) {
      setInstrumentType(preselectedOption.type === 'call' ? 'call_option' : 'put_option');
      setStrikePriceInput(preselectedOption.strike.toString());
      setExpiryDate(preselectedOption.expiry);
      addToast({
        type: 'info',
        title: 'Option Contract Selected',
        message: `Applied ${preselectedOption.type.toUpperCase()} $${preselectedOption.strike} Exp ${preselectedOption.expiry} to your order.`,
      });
    }
  }, [preselectedOption]);

  useEffect(() => {
    const handleUpdate = () => setSourcesVersion((v) => v + 1);
    window.addEventListener('final_finance_wallets_updated', handleUpdate);
    window.addEventListener('final_finance_custom_coins_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleUpdate);
      window.removeEventListener('final_finance_custom_coins_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  const availableBuySources = useMemo(
    () => getAvailableStockPaymentSources(currentUser?.id || 'guest', undefined, stock),
    [currentUser?.id, sourcesVersion, stock]
  );
  const allSystemSellCurrencies = useMemo(
    () => getAllSystemSellCurrencies(currentUser?.id || 'guest', stock),
    [currentUser?.id, sourcesVersion, stock]
  );

  useEffect(() => {
    if (allSystemSellCurrencies.length > 0) {
      if (!selectedSellCurrency) {
        setSelectedSellCurrency(allSystemSellCurrencies[0]);
      } else {
        const refreshed = allSystemSellCurrencies.find(c => c.id === selectedSellCurrency.id);
        setSelectedSellCurrency(refreshed || allSystemSellCurrencies[0]);
      }
    }
  }, [allSystemSellCurrencies]);

  const activeBuySource = availableBuySources.find(s => s.id === selectedSourceId) || availableBuySources[0];
  const activeSellSource = selectedSellCurrency || allSystemSellCurrencies[0] || activeBuySource;
  const activeSource = side === 'buy' ? activeBuySource : activeSellSource;
  const isFinalEquity = isFinalStock(stock) || stock.marketType === 'final' || (stock.settlementMethod?.toLowerCase().includes('final') ?? false);
  const isFutures = instrumentType === 'futures_long' || instrumentType === 'futures_short';
  const isMarketClosedForSpot = (!instrumentType || instrumentType === 'spot') && !marketStatus.isOpen;

  const executionPrice = orderType === 'market' ? stock.price : (parseFloat(limitPriceInput) || stock.price);

  const numShares = inputMode === 'shares'
    ? parseFloat(sharesInput) || 0
    : Number(((parseFloat(dollarsInput) || 0) / executionPrice).toFixed(4));

  // Cost calculation based on instrument type
  const strikePrice = parseFloat(strikePriceInput) || stock.price;
  const optionPremiumRate = 0.05; // 5% of underlying for options premium
  const parsedLeverage = parseFloat(leverageInput);
  const leverage = Number.isFinite(parsedLeverage) && parsedLeverage >= 1 ? Math.min(100, parsedLeverage) : 1;
  
  const totalCostUSD = useMemo(() => {
    if (instrumentType === 'call_option' || instrumentType === 'put_option') {
      // Options cost = Premium paid (shares * price * 5%)
      const baseVal = (inputMode === 'shares' ? numShares : (parseFloat(dollarsInput) || 0)) * executionPrice;
      return baseVal * optionPremiumRate;
    } else if (instrumentType === 'futures_long' || instrumentType === 'futures_short') {
      // Futures margin cost = Notional value / leverage
      const notional = (inputMode === 'shares' ? numShares : (parseFloat(dollarsInput) || 0)) * executionPrice;
      return notional / leverage;
    } else {
      // Spot
      return inputMode === 'shares'
        ? (parseFloat(sharesInput) || 0) * executionPrice
        : parseFloat(dollarsInput) || 0;
    }
  }, [instrumentType, inputMode, numShares, dollarsInput, executionPrice, leverage]);

  const availableBalanceUSD = activeBuySource ? activeBuySource.balanceUSD : 0;
  const canAfford = side === 'buy' ? availableBalanceUSD >= totalCostUSD && totalCostUSD > 0 : true;

  const handleSharesPercent = (pct: number) => {
    if (side === 'buy') {
      const maxShares = Math.floor((availableBalanceUSD * pct) / executionPrice);
      setInputMode('shares');
      setSharesInput(Math.max(1, maxShares).toString());
    } else {
      setInputMode('shares');
      setSharesInput((20 * pct).toFixed(0));
    }
  };

  const handleDollarPreset = (amt: number) => {
    setInputMode('dollars');
    setDollarsInput(amt.toString());
  };

  const validateFuturesSchedule = (): boolean => {
    if (!isFutures) return true;
    if (!Number.isFinite(parsedLeverage) || parsedLeverage < 1 || parsedLeverage > 100) {
      setOrderError('Please choose a leverage multiplier between 1x and 100x.');
      return false;
    }
    if (!expiryDate || !expiryTime) {
      setOrderError('Please set both a settlement date and time for your futures contract.');
      return false;
    }
    const scheduled = new Date(`${expiryDate}T${expiryTime}`);
    if (isNaN(scheduled.getTime()) || scheduled.getTime() <= Date.now()) {
      setOrderError('Futures settlement date and time must be in the future.');
      return false;
    }
    return true;
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    const isSpot = !instrumentType || instrumentType === 'spot';
    if (isSpot && !marketStatus.isOpen) {
      setOrderError(
        `Spot exchange closed (${marketStatus.dayOfWeek}). Individual stocks trade Mon–Fri 9:30 AM – 4:00 PM EST. Switch to Call, Put, or Futures to trade 24/7.`
      );
      return;
    }

    if (!validateFuturesSchedule()) return;

    if (numShares <= 0 || totalCostUSD <= 0) {
      setOrderError('Please enter a valid amount or share quantity to execute.');
      return;
    }

    if (side === 'buy' && !canAfford) {
      setOrderError(
        `Your ${activeBuySource.label} wallet has ${formatStockPrice(availableBalanceUSD, stock, false)} available, which cannot cover this ${formatStockPrice(totalCostUSD, stock, false)} trade.`
      );
      return;
    }

    setShowConfirm(true);
  };

  const executeConfirmedOrder = () => {
    const isSpot = !instrumentType || instrumentType === 'spot';
    if (isSpot && !marketStatus.isOpen) {
      setOrderError(
        `Spot exchange closed (${marketStatus.dayOfWeek}). Individual stocks trade Mon–Fri 9:30 AM – 4:00 PM EST. Switch to Call, Put, or Futures to trade 24/7.`
      );
      setIsSubmitting(false);
      setShowConfirm(false);
      return;
    }

    if (!validateFuturesSchedule()) {
      setShowConfirm(false);
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      processStockPayment(currentUser!.id, activeSource, totalCostUSD, side);

      const instrumentName = 
        instrumentType === 'call_option' ? `Call Option (${strikePrice} Strike)` :
        instrumentType === 'put_option' ? `Put Option (${strikePrice} Strike)` :
        instrumentType === 'futures_long' ? `Futures Long (${leverage}x · ${expiryDate} ${expiryTime})` :
        instrumentType === 'futures_short' ? `Futures Short (${leverage}x · ${expiryDate} ${expiryTime})` :
        `Spot Shares`;

      const isOptionsOrFutures = instrumentType && instrumentType !== 'spot';
      const isMarketOpen = isOptionsOrFutures ? true : marketStatus.isOpen;
      const orderStatus: 'filled' | 'open' = isMarketOpen ? 'filled' : 'open';

      const newOrder: StockOrder = {
        id: `ord-${Date.now()}`,
        ticker: stock.ticker,
        stockName: `${stock.name} [${instrumentName}]`,
        side,
        orderType,
        derivativeType: instrumentType,
        strikePrice: instrumentType.includes('option') ? strikePrice : undefined,
        expiryDate: instrumentType.includes('option') || instrumentType.includes('futures') ? expiryDate : undefined,
        expiryTime: isFutures ? expiryTime : undefined,
        leverage: instrumentType.includes('futures') ? leverage : undefined,
        premiumUSD: instrumentType.includes('option') ? totalCostUSD : undefined,
        shares: numShares,
        price: executionPrice,
        limitPrice: orderType !== 'market' ? parseFloat(limitPriceInput) : undefined,
        totalUSD: totalCostUSD,
        paymentSource: activeSource,
        status: orderStatus,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        dateIso: new Date().toISOString(),
        sector: stock.sector,
        tradeSlipId: `SLIP-${Date.now().toString().slice(-8)}`
      };

      onOrderExecuted(newOrder);

      // Add to global ledger
      addTransaction({
        taxYear: new Date().getFullYear(),
        type: side === 'buy' ? 'stock_buy' : 'stock_sell',
        category: 'trade',
        mode: (activeSource.type as string) === 'crypto' ? 'crypto' : 'fiat_currency',
        title: `${side.toUpperCase()} ${stock.ticker} - ${instrumentName} (${isMarketOpen ? 'Regular Hours' : 'After-Hours Queue'})`,
        description: isMarketOpen
          ? `Executed ${side.toUpperCase()} order during regular local market hours for ${numShares} units of ${stock.ticker} at $${executionPrice.toFixed(2)}.`
          : `Queued ${side.toUpperCase()} order for ${numShares} units of ${stock.ticker} at $${executionPrice.toFixed(2)}. Will fill when regular market hours resume (Mon–Fri 9:30 AM – 4:00 PM local time).`,
        amountUSD: totalCostUSD,
        feeUSD: 0,
        netAmountUSD: side === 'buy' ? -totalCostUSD : totalCostUSD,
        sourceOrDestination: currentUser!.name,
        counterpartyOrIssuer: 'Global Stock Exchange',
        issuerHandle: currentUser!.handle,
        status: isMarketOpen ? 'Settled' : 'Pending Open',
        clearingNode: 'STOCK-EX-NODE-4',
        taxClassification: {
          formMapping: 'Securities Transaction',
          taxableEvent: true,
          taxableAmountUSD: totalCostUSD,
          irsCategoryNote: `Stock market ${side} execution`
        }
      });

      setIsSubmitting(false);

      addToast({
        type: isMarketOpen ? (side === 'buy' ? 'gold' : 'success') : 'info',
        title: isMarketOpen 
          ? `Executed ${instrumentName} on ${stock.ticker} ($${totalCostUSD.toFixed(2)})`
          : `Order Queued for Market Open (${stock.ticker})`,
        message: isMarketOpen
          ? `Successfully placed ${side.toUpperCase()} order for ${numShares} units of ${stock.ticker} during regular local stock market hours.`
          : `Regular stock market hours are Mon–Fri 9:30 AM – 4:00 PM (${marketStatus.timeZone}). Your ${side.toUpperCase()} trade for ${stock.ticker} has been queued for market open.`,
      });
    }, 600);
  };

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm flex flex-col justify-between">
      <div>
        {/* Local Market Hours Notice Banner */}
        <div className={`mb-4 p-3 rounded-2xl border text-xs flex items-start justify-between gap-2.5 ${
          (instrumentType !== 'spot' || marketStatus.isOpen) 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
            : 'bg-amber-50 border-amber-200 text-amber-950'
        }`}>
          <div className="flex items-start gap-2.5">
            <span className={`w-2.5 h-2.5 rounded-full shrink-0 mt-1 ${(instrumentType !== 'spot' || marketStatus.isOpen) ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
            <div>
              <span className="font-bold">
                {instrumentType !== 'spot'
                  ? '24/7 Options & Futures Active'
                  : marketStatus.isOpen
                  ? 'Regular Market Open'
                  : `Spot Market Closed (${marketStatus.dayOfWeek})`}
              </span>
              <span className="text-[11px] block text-slate-600 font-normal mt-0.5 leading-relaxed">
                {instrumentType !== 'spot' 
                  ? 'Options and futures trade 24/7, including after-hours, weekends, and holidays.' 
                  : marketStatus.isOpen
                  ? 'Spot equity trading is active during regular hours (Mon–Fri 9:30 AM – 4:00 PM EST).'
                  : 'Individual stocks only trade Mon–Fri 9:30 AM – 4:00 PM EST. Switch to Call, Put, or Long/Short Fut below to trade 24/7.'}
              </span>
            </div>
          </div>
          {instrumentType === 'spot' && !marketStatus.isOpen && (
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-200/80 text-rose-950 shrink-0">
              Spot Halted
            </span>
          )}
        </div>

        {/* Instrument Selector Tabs: Spot vs Derivatives (Call, Put, Futures) */}
        <div className="mb-4 space-y-1.5">
          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
            Trading Instrument &amp; Derivatives
          </label>
          <div className="grid grid-cols-5 gap-1 p-1 bg-slate-100 rounded-2xl text-[11px] font-bold">
            <button
              type="button"
              onClick={() => setInstrumentType('spot')}
              className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                instrumentType === 'spot'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Spot
            </button>
            <button
              type="button"
              onClick={() => setInstrumentType('call_option')}
              className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                instrumentType === 'call_option'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Call ↗
            </button>
            <button
              type="button"
              onClick={() => setInstrumentType('put_option')}
              className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                instrumentType === 'put_option'
                  ? 'bg-rose-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Put ↘
            </button>
            <button
              type="button"
              onClick={() => setInstrumentType('futures_long')}
              className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                instrumentType === 'futures_long'
                  ? 'bg-amber-500 text-slate-950 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Long Fut
            </button>
            <button
              type="button"
              onClick={() => setInstrumentType('futures_short')}
              className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                instrumentType === 'futures_short'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Short Fut
            </button>
          </div>
        </div>

        {/* Top Side Switcher: Buy / Sell */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-slate-100 border border-slate-200">
          <button
            type="button"
            onClick={() => setSide('buy')}
            className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              side === 'buy'
                ? 'bg-emerald-500 text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            <span>Open Long / Buy</span>
          </button>
          <button
            type="button"
            onClick={() => setSide('sell')}
            className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              side === 'sell'
                ? 'bg-rose-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ArrowDownRight className="w-4 h-4 stroke-[2.5]" />
            <span>Open Short / Sell</span>
          </button>
        </div>

        {/* Derivative Specific Controls (Strike Price, Expiry, Leverage) */}
        {(instrumentType === 'call_option' || instrumentType === 'put_option') && (
          <div className="mt-3.5 p-3 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-amber-900">
              <span>Options Contract Parameters</span>
              <div className="flex flex-col items-end gap-1">
                <span className="text-[10px] font-mono bg-amber-200/60 px-2 py-0.5 rounded text-amber-950">5% Premium Cost</span>
                {preselectedOption?.symbol && (
                  <span className="text-[9px] font-mono text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200 uppercase">
                    {preselectedOption.symbol}
                  </span>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Strike Price</label>
                <input
                  type="number"
                  step="0.5"
                  value={strikePriceInput}
                  onChange={(e) => setStrikePriceInput(e.target.value)}
                  className="w-full h-9 px-3 rounded-xl border border-amber-300 bg-white font-mono text-xs font-bold text-slate-900"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Expiry Date</label>
                <input
                  type="date"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  className="w-full h-9 px-3 rounded-xl border border-amber-300 bg-white font-mono text-xs font-bold text-slate-900"
                />
              </div>
            </div>
          </div>
        )}

        {isFutures && (
          <div className="mt-3.5 p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-slate-900">
              <span>Futures Settlement &amp; Leverage</span>
              <span className="text-[11px] font-mono text-indigo-700 tabular-nums">{leverage}x Leverage</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 flex items-center gap-1 mb-1">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span>Settlement Date</span>
                </label>
                <input
                  type="date"
                  min={getTodayDateString()}
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  required
                  className="w-full h-9 px-2.5 rounded-xl border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-600 flex items-center gap-1 mb-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>Settlement Time</span>
                </label>
                <input
                  type="time"
                  value={expiryTime}
                  onChange={(e) => setExpiryTime(e.target.value)}
                  required
                  className="w-full h-9 px-2.5 rounded-xl border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums"
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <label htmlFor="desk-leverage-input" className="text-[11px] font-semibold text-slate-600">
                  Custom Leverage (1x – 100x)
                </label>
                <div className="relative w-24">
                  <input
                    id="desk-leverage-input"
                    type="number"
                    min={1}
                    max={100}
                    step={1}
                    value={leverageInput}
                    onChange={(e) => setLeverageInput(e.target.value)}
                    onBlur={() => {
                      const val = Math.max(1, Math.min(100, Math.round(parseFloat(leverageInput) || 1)));
                      setLeverageInput(val.toString());
                    }}
                    className="w-full h-8 pl-2.5 pr-6 rounded-lg border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 font-mono text-[11px] font-bold text-slate-400 pointer-events-none">
                    x
                  </span>
                </div>
              </div>
              <input
                type="range"
                min={1}
                max={100}
                step={1}
                value={leverage}
                onChange={(e) => setLeverageInput(e.target.value)}
                className="w-full accent-indigo-600 cursor-pointer"
                aria-label="Custom leverage slider"
              />
              <div className="grid grid-cols-6 gap-1">
                {[1, 2, 5, 10, 25, 50].map((lev) => (
                  <button
                    key={lev}
                    type="button"
                    onClick={() => setLeverageInput(lev.toString())}
                    className={`py-1.5 rounded-lg border text-[11px] font-mono font-bold tabular-nums transition-all cursor-pointer ${
                      leverage === lev
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {lev}x
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Order Type Tabs & Input Mode */}
        <div className="flex items-center justify-between mt-4 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-1">
            {(['market', 'limit', 'stop'] as const).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setOrderType(type)}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg uppercase tracking-wider transition-colors cursor-pointer ${
                  orderType === type
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 text-xs">
            <button
              type="button"
              onClick={() => setInputMode('shares')}
              className={`px-2 py-0.5 rounded font-bold cursor-pointer transition-colors ${
                inputMode === 'shares' ? 'bg-amber-100 text-amber-900' : 'text-slate-400 hover:text-slate-700'
              }`}
            >
              Units/Contracts
            </button>
            <span className="text-slate-300">|</span>
            <button
              type="button"
              onClick={() => setInputMode('dollars')}
              className={`px-2 py-0.5 rounded font-bold cursor-pointer transition-colors ${
                inputMode === 'dollars' ? 'bg-amber-100 text-amber-900' : 'text-slate-400 hover:text-slate-700'
              }`}
            >
              Final Currency
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmitOrder} className="mt-4 space-y-3.5">
          {/* Amount / Shares Input */}
          {inputMode === 'shares' ? (
            <div>
              <div className="flex items-center justify-between mb-1.5 text-xs">
                <label className="font-semibold text-slate-700">Quantity / Contracts</label>
                <span className="text-slate-400 font-mono">Lot Size: 1</span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  value={sharesInput}
                  onChange={(e) => setSharesInput(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500/50 text-slate-900 font-mono font-bold text-sm bg-slate-50/50"
                  placeholder="10"
                  required
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400">
                  UNITS
                </div>
              </div>

              {/* Quick Percent Buttons */}
              <div className="grid grid-cols-4 gap-1.5 mt-2">
                {[
                  { label: '25%', val: 0.25 },
                  { label: '50%', val: 0.5 },
                  { label: '75%', val: 0.75 },
                  { label: '100%', val: 1.0 },
                ].map((p) => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => handleSharesPercent(p.val)}
                    className="py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[10px] font-bold text-slate-600 transition-colors cursor-pointer text-center"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-1.5 text-xs">
                <label className="font-semibold text-slate-700">Final Currency Amount</label>
                <span className="text-slate-400 font-mono">≈ {numShares} units</span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={dollarsInput}
                  onChange={(e) => setDollarsInput(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500/50 text-slate-900 font-mono font-bold text-sm bg-slate-50/50"
                  placeholder="1000"
                  required
                />
              </div>

              {/* Quick Currency Presets */}
              <div className="grid grid-cols-4 gap-1.5 mt-2">
                {[100, 500, 1000, 5000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => handleDollarPreset(amt)}
                    className="py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[10px] font-bold text-slate-600 transition-colors cursor-pointer text-center"
                  >
                    {amt.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Limit Price Input if Limit/Stop */}
          {orderType !== 'market' && (
            <div>
              <div className="flex items-center justify-between mb-1.5 text-xs">
                <label className="font-semibold text-slate-700">
                  {orderType === 'limit' ? 'Limit Price' : 'Stop Trigger Price'}
                </label>
                <span className="text-slate-400 font-mono">Current: {formatStockPrice(stock.price, stock, false)}</span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  value={limitPriceInput}
                  onChange={(e) => setLimitPriceInput(e.target.value)}
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500/50 text-slate-900 font-mono font-bold text-sm bg-slate-50/50"
                  placeholder="0.00"
                  required
                />
              </div>
            </div>
          )}

          {/* Payment Method Selection */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700">
                {side === 'buy' ? 'Funding Source' : 'Deposit Proceeds To'}
              </label>
              <span className="text-[11px] font-mono text-slate-500">
                {side === 'buy'
                  ? `${getStockCurrencyCode(stock)} Settlement Only`
                  : isFinalEquity
                  ? 'Final Coins Only'
                  : 'Any System Currency'}
              </span>
            </div>

            {side === 'buy' ? (
              <div className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Wallet className="w-4 h-4 text-slate-500 shrink-0" />
                  <div className="min-w-0">
                    <span className="font-mono font-bold text-xs text-slate-900 block">
                      {activeBuySource.label}
                    </span>
                    <span className="text-[11px] text-slate-500 block">
                      Wallet Balance
                    </span>
                  </div>
                </div>
                <span className="font-mono font-bold text-xs text-slate-900 tabular-nums shrink-0">
                  {availableBalanceUSD.toLocaleString()} available
                </span>
              </div>
            ) : (
              <>
                <SellCurrencyPicker
                  currencies={allSystemSellCurrencies}
                  selectedSource={activeSellSource}
                  onSelect={(src) => setSelectedSellCurrency(src)}
                  finalCoinsOnly={isFinalEquity}
                />
                <p className="text-[10px] text-slate-500 text-left">
                  {isFinalEquity
                    ? 'Final stocks can only be sold into Final Coins (no stablecoins, fiat, or crypto). Search any Final Coin across the platform.'
                    : 'Choose any currency across the platform (including currencies not currently in your wallet). Proceeds deposit immediately.'}
                </p>
              </>
            )}
          </div>

          {/* Order Summary Box */}
          <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-3 space-y-1.5 text-xs">
            <div className="flex items-center justify-between text-slate-500">
              <span>Instrument Type</span>
              <span className="font-bold text-slate-900 uppercase">{instrumentType.replace('_', ' ')}</span>
            </div>
            {isFutures && expiryDate && expiryTime && (
              <div className="flex items-center justify-between text-slate-500">
                <span>Settlement Schedule</span>
                <span className="font-mono font-semibold text-slate-900 tabular-nums">
                  {expiryDate} · {expiryTime}
                </span>
              </div>
            )}
            <div className="flex items-center justify-between text-slate-500">
              <span>Estimated Execution Price</span>
              <div className="text-right">
                <span className="font-mono font-semibold text-slate-800 block tabular-nums">
                  {formatStockPrice(executionPrice, stock, false)}
                </span>
                {getUSDEquivalentString(executionPrice, stock) && (
                  <span className="font-mono text-[10px] text-slate-400 block mt-0.5">
                    {getUSDEquivalentString(executionPrice, stock)}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between text-slate-500">
              <span>Platform Clearing Fee</span>
              <span className="font-mono font-semibold text-emerald-700">
                0.00
              </span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex items-center justify-between font-bold text-slate-900">
              <span>{side === 'buy' ? 'Total Margin / Cost' : 'Net Proceeds'}</span>
              <div className="text-right">
                <span className="font-mono text-sm text-slate-900 block tabular-nums">
                  {formatStockPrice(totalCostUSD, stock, false)}
                </span>
                {getUSDEquivalentString(totalCostUSD, stock) && (
                  <span className="font-mono text-[10px] text-slate-500 block mt-0.5">
                    {getUSDEquivalentString(totalCostUSD, stock)}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Prominent Inline Order Error Banner */}
          {orderError && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-300 text-rose-900 text-xs flex items-start gap-2.5 shadow-xs">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 text-left">
                <span className="font-bold block text-rose-900">Order Cannot Be Executed</span>
                <span className="text-[11px] text-rose-800 block mt-0.5 leading-relaxed">{orderError}</span>
              </div>
              <button 
                type="button" 
                onClick={() => setOrderError(null)}
                className="text-rose-400 hover:text-rose-800 p-0.5 cursor-pointer rounded"
                title="Dismiss warning"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Submit Button */}
          {currentUser ? (
            isMarketClosedForSpot ? (
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-sm cursor-pointer flex items-center justify-center gap-2 bg-rose-500/15 border border-rose-300 text-rose-900 hover:bg-rose-500/25"
              >
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Spot Market Closed ({marketStatus.dayOfWeek}) — Switch to Options/Futures</span>
              </button>
            ) : (
              <button
                type="submit"
                disabled={isSubmitting || (side === 'buy' && !canAfford)}
                className={`w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-sm cursor-pointer flex items-center justify-center gap-2 ${
                  side === 'buy'
                    ? canAfford
                      ? 'bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-slate-950'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-rose-500 hover:bg-rose-400 active:scale-[0.99] text-white'
                }`}
              >
                {isSubmitting ? (
                  <span>Routing to Derivatives Exchange...</span>
                ) : side === 'buy' ? (
                  canAfford ? (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>Execute {instrumentType.replace('_', ' ')} ({formatStockPrice(totalCostUSD, stock, false)})</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4 h-4" />
                      <span>Insufficient Funds in Selected Source</span>
                    </>
                  )
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    <span>Execute Short / Sell ({formatStockPrice(totalCostUSD, stock, false)})</span>
                  </>
                )}
              </button>
            )
          ) : (
            <button
              type="button"
              onClick={onOpenAuthModal}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-bold transition-all shadow-sm cursor-pointer flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>Sign In to Trade Derivatives</span>
            </button>
          )}
        </form>
      </div>

      {/* Footer Security Badges */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
        <div className="flex items-center gap-1 text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
          <span>Sovereign Clearinghouse</span>
        </div>
        <span className="font-mono">Zero-Fee Derivatives Engine</span>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={executeConfirmedOrder}
        title={side === 'buy' ? 'Confirm Order' : 'Confirm Sale'}
        message={
          side === 'buy'
            ? `Authorize the purchase of ${numShares} units of ${stock.ticker}${isFutures ? ` settling ${expiryDate} at ${expiryTime}` : ''}? Total cost: ${formatStockPrice(totalCostUSD, stock, false)}.`
            : `Authorize the sale of ${numShares} units of ${stock.ticker}${isFutures ? ` settling ${expiryDate} at ${expiryTime}` : ''} for ${formatStockPrice(totalCostUSD, stock, false)}, deposited to your wallet in ${activeSellSource.label}?`
        }
        confirmText={side === 'buy' ? 'Confirm Purchase' : 'Confirm Sale'}
        type={side === 'buy' ? 'info' : 'warning'}
      />
    </div>
  );
};
