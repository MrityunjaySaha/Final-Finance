import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  StockItem, 
  StockOrder, 
  StockPosition,
  StockMarketWay,
  DerivativeType,
  StockNewsItem,
  IPORequest
} from '../types/stocks';
import { 
  INITIAL_STOCKS, 
  STOCK_MARKET_WAYS,
  INITIAL_USER_STOCK_POSITIONS, 
  BREAKING_STOCK_NEWS,
  getAllActiveMarketStocks,
  getAllCombinedStockNews,
  getStoredIPORequests,
  deleteIPONewsItem,
  IPO_UPDATED_EVENT,
  IPO_NEWS_UPDATED_EVENT,
  MOCK_OPTIONS
} from '../data/stocksData';
import { OptionItem } from '../types/stocks';
import { StockNewsFeed } from './stocks/StockNewsFeed';
import { StockChart } from './stocks/StockChart';
import { StockFundamentals } from './stocks/StockFundamentals';
import { StockOrderDesk } from './stocks/StockOrderDesk';
import { StockDetailPage } from './stocks/StockDetailPage';
import { QuickBuyStockModal } from './stocks/QuickBuyStockModal';
import { TradeConfirmationModal } from './stocks/TradeConfirmationModal';
import { PostIPONewsModal } from './stocks/PostIPONewsModal';
import { StockMarketHoursBar } from './stocks/StockMarketHoursBar';
import { AlpacaAssetLookup } from './stocks/AlpacaAssetLookup';
import { SocialTradesFeed } from './stocks/SocialTradesFeed';
import { getLocalStockMarketStatus } from '../utils/marketHours';
import { formatStockPrice } from '../utils/stockCurrencyFormatter';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { 
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Zap,
  User,
  Users,
  ShieldCheck,
  Building2,
  Coins,
  Globe,
  Search,
  SlidersHorizontal,
  ArrowUpDown,
  TrendingUp,
  TrendingDown,
  Star,
  Eye,
  BarChart3,
  CheckCircle2,
  ArrowUpRight,
  Sparkles,
  Layers,
  Activity,
  X,
  ArrowLeft,
  LayoutGrid,
  List,
  Lock
} from 'lucide-react';
import { 
  getStoredStockPositions, 
  saveStoredStockPositions, 
  getStoredStockOrders, 
  saveStoredStockOrders,
  getAvailableStockPaymentSources,
  getStoredWatchlist,
  toggleStoredWatchlist,
  WATCHLIST_UPDATED_EVENT,
  matchStockSearch,
  saveDynamicAlpacaStock
} from '../utils/stockWalletBridge';
import { recordLedgerTransaction, createLedgerItemFromStockOrder } from '../utils/universalLedgerBridge';
import { getAnonymousIssuerDebtSummary } from '../services/loanService';

interface StockMarketViewProps {
  currentUser: AuthSession | null;
  onOpenAuthModal: () => void;
  onNavigateBack: () => void;
  initialSelectedTicker?: string;
  initialSelectedStock?: StockItem | null;
  onClearSelectedStock?: () => void;
  portfolioReturnLabel?: string;
  onBackToPortfolioTab?: () => void;
  initialQuickBuyStock?: StockItem | null;
  initialMarketWay?: StockMarketWay | 'all';
  marketResetKey?: number;
}

export const StockMarketView: React.FC<StockMarketViewProps> = ({
  currentUser,
  onOpenAuthModal,
  onNavigateBack,
  initialSelectedTicker,
  initialSelectedStock,
  onClearSelectedStock,
  portfolioReturnLabel,
  onBackToPortfolioTab,
  initialQuickBuyStock,
  initialMarketWay,
  marketResetKey,
}) => {
  const { addToast, addTransaction, addNotification } = useApp();
  const userId = currentUser?.id || 'guest';
  const marketStatus = getLocalStockMarketStatus();

  // Stock Market Active Selection
  const [selectedMarketWay, setSelectedMarketWay] = useState<StockMarketWay | 'all' | 'social' | 'favorites'>(() => {
    if (initialMarketWay) return initialMarketWay;
    if (initialSelectedStock?.marketType) return initialSelectedStock.marketType;
    if (initialSelectedTicker) {
      const found = INITIAL_STOCKS.find((s) => s.ticker === initialSelectedTicker);
      if (found?.marketType) return found.marketType;
    }
    return 'final';
  });

  // Options View Specific States
  const [optionsTab, setOptionsTab] = useState<'call' | 'put'>('call');
  const [optionsCategory, setOptionsCategory] = useState<'all' | 'fiat' | 'stable' | 'crypto'>('all');

  // Stocks Master State
  const [stocks, setStocks] = useState<StockItem[]>(() => getAllActiveMarketStocks());
  const [selectedStock, setSelectedStock] = useState<StockItem>(() => {
    const initialList = getAllActiveMarketStocks();
    if (initialSelectedTicker) {
      const found = initialList.find((s) => s.ticker === initialSelectedTicker);
      if (found) return found;
    }
    if (initialSelectedStock) return initialSelectedStock;
    return initialList[0] || INITIAL_STOCKS[0];
  });

  // Dedicated Stock Page View State (Single stock deep-dive page)
  const [viewingStockDetail, setViewingStockDetail] = useState<StockItem | null>(() => {
    const initialList = getAllActiveMarketStocks();
    if (initialSelectedTicker) {
      const found = initialList.find((s) => s.ticker === initialSelectedTicker);
      if (found) return found;
    }
    if (initialSelectedStock) return initialSelectedStock;
    return null;
  });

  const lastAppliedTickerRef = useRef<string | undefined>(initialSelectedTicker);

  const [activeOptionType, setActiveOptionType] = useState<'call' | 'put'>('call');
  const [activeOptionCategory, setActiveOptionCategory] = useState<'fiat' | 'stable' | 'crypto' | 'all'>('all');
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    const stored = getStoredWatchlist(userId);
    return stored.length > 0 ? stored : ['ALEX', 'HYPR', 'AFNL-EQ', 'BSYN'];
  });
  const [activeChartTimeframe, setActiveChartTimeframe] = useState<'1D' | '1W' | '1M' | '1Y' | '5Y'>('1D');
  const [showInteractiveChart, setShowInteractiveChart] = useState<boolean>(false);

  // In-market search & filter states
  const [marketSearchQuery, setMarketSearchQuery] = useState<string>('');
  const [selectedSectorFilter, setSelectedSectorFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'marketCap' | 'gainers' | 'volume' | 'price' | 'alphabetical'>('gainers');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [isEquitiesCollapsed, setIsEquitiesCollapsed] = useState<boolean>(false);

  // Quick Trade Modal State (Buy / Sell / Trade Options)
  const [quickTradeStock, setQuickTradeStock] = useState<StockItem | null>(initialQuickBuyStock || null);
  const [quickTradeSide, setQuickTradeSide] = useState<'buy' | 'sell'>('buy');
  const [quickTradeDerivative, setQuickTradeDerivative] = useState<DerivativeType>('spot');

  // Trade Confirmation Receipt Modal State
  const [selectedReceiptOrder, setSelectedReceiptOrder] = useState<StockOrder | null>(null);

  // User Positions, Orders, IPOs & News Persistent State
  const [positions, setPositions] = useState<StockPosition[]>(() =>
    getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS)
  );
  const [orders, setOrders] = useState<StockOrder[]>(() =>
    getStoredStockOrders(userId)
  );
  const [ipos, setIpos] = useState<IPORequest[]>(() => getStoredIPORequests());
  const [allNews, setAllNews] = useState<StockNewsItem[]>(() => getAllCombinedStockNews());
  const [isPostIPONewsOpen, setIsPostIPONewsOpen] = useState(false);
  const [loansTick, setLoansTick] = useState(0);

  // Reset stock detail view when user explicitly navigates to Stock Market Exchange from dropdown
  useEffect(() => {
    if (marketResetKey && marketResetKey > 0) {
      lastAppliedTickerRef.current = undefined;
      setViewingStockDetail(null);
      setQuickTradeStock(null);
    }
  }, [marketResetKey]);

  // Sync initialSelectedTicker prop updates ONLY when the ticker prop genuinely changes (never on price ticks)
  useEffect(() => {
    if (initialSelectedTicker && initialSelectedTicker !== lastAppliedTickerRef.current) {
      lastAppliedTickerRef.current = initialSelectedTicker;
      const found = stocks.find((s) => s.ticker === initialSelectedTicker) || initialSelectedStock;
      if (found) {
        setViewingStockDetail(found);
        setSelectedStock(found);
        if (found.marketType) {
          setSelectedMarketWay(found.marketType);
        }
      }
    } else if (!initialSelectedTicker) {
      lastAppliedTickerRef.current = undefined;
    }
  }, [initialSelectedTicker, initialSelectedStock]);

  // Sync viewingStockDetail with live updated price changes
  useEffect(() => {
    if (viewingStockDetail) {
      const current = stocks.find((s) => s.ticker === viewingStockDetail.ticker);
      if (current) {
        setViewingStockDetail(current);
      }
    }
  }, [stocks]);

  // Sync initialMarketWay prop updates
  useEffect(() => {
    if (initialMarketWay) {
      setSelectedMarketWay(initialMarketWay);
      setMarketSearchQuery('');
      setSelectedSectorFilter('all');
      if (initialMarketWay !== 'all') {
        const first = stocks.find(s => s.marketType === initialMarketWay);
        if (first) setSelectedStock(first);
      }
    }
  }, [initialMarketWay]);

  useEffect(() => {
    if (initialQuickBuyStock) {
      setQuickTradeStock(initialQuickBuyStock);
      setQuickTradeSide('buy');
    }
  }, [initialQuickBuyStock]);

  // Load and refresh persistent positions, orders, watchlist, IPOs & IPO news
  useEffect(() => {
    const handleRefresh = () => {
      setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
      setOrders(getStoredStockOrders(userId));
      setStocks(getAllActiveMarketStocks());
      setWatchlist(getStoredWatchlist(userId));
      setIpos(getStoredIPORequests());
      setAllNews(getAllCombinedStockNews());
    };

    const handleLoansSync = () => setLoansTick((t) => t + 1);
    handleRefresh();
    window.addEventListener(IPO_UPDATED_EVENT, handleRefresh);
    window.addEventListener(IPO_NEWS_UPDATED_EVENT, handleRefresh);
    window.addEventListener(WATCHLIST_UPDATED_EVENT, handleRefresh);
    window.addEventListener('final_finance_alpaca_stocks_updated', handleRefresh);
    window.addEventListener('final_finance_loans_updated', handleLoansSync);
    window.addEventListener('storage', handleRefresh);
    window.addEventListener('storage', handleLoansSync);
    return () => {
      window.removeEventListener(IPO_UPDATED_EVENT, handleRefresh);
      window.removeEventListener(IPO_NEWS_UPDATED_EVENT, handleRefresh);
      window.removeEventListener(WATCHLIST_UPDATED_EVENT, handleRefresh);
      window.removeEventListener('final_finance_alpaca_stocks_updated', handleRefresh);
      window.removeEventListener('final_finance_loans_updated', handleLoansSync);
      window.removeEventListener('storage', handleRefresh);
      window.removeEventListener('storage', handleLoansSync);
    };
  }, [userId]);

  // Live Price Fluctuations Simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setStocks((prev) =>
        prev.map((s) => {
          const delta = (Math.random() - 0.49) * (s.price * 0.0018);
          const newPrice = Math.max(0.1, Number((s.price + delta).toFixed(2)));
          const diff = Number((newPrice - (s.price - s.changeUSD)).toFixed(2));
          const base = s.price - s.changeUSD || 1;
          const pct = Number(((diff / base) * 100).toFixed(2));

          return {
            ...s,
            price: newPrice,
            changeUSD: diff,
            changePercent: pct,
          };
        })
      );
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  // Update selectedStock reference when stocks array updates
  useEffect(() => {
    const current = stocks.find((s) => s.ticker === selectedStock.ticker);
    if (current) {
      setSelectedStock(current);
    }
  }, [stocks]);

  // Handle Order Execution (updates positions for spot shares and stores all orders persistently)
  const handleOrderExecuted = (newOrder: StockOrder) => {
    const isSpotOrder = !newOrder.derivativeType || newOrder.derivativeType === 'spot';
    let updatedPositions: StockPosition[] = positions;
    const existing = positions.find((p) => p.ticker === newOrder.ticker);
    const stockInfo = stocks.find(s => s.ticker === newOrder.ticker) || selectedStock;
    const isPersonal = stockInfo?.issuanceType === 'personal' || stockInfo?.assetCategory === 'personal' || newOrder.ticker === 'ALEX';

    let enrichedOrder: StockOrder = {
      ...newOrder,
      isPersonalStock: isPersonal,
      isBusinessStock: !isPersonal
    };

    if (isSpotOrder) {
      if (newOrder.side === 'buy') {
        enrichedOrder.buyPriceUSD = newOrder.price;
        enrichedOrder.costBasisUSD = newOrder.totalUSD;

        if (existing) {
          const totalShares = existing.shares + newOrder.shares;
          const totalCost = (existing.shares * existing.avgCostUSD) + newOrder.totalUSD;
          const newAvgCost = totalCost / totalShares;
          const newTotalVal = totalShares * newOrder.price;
          const totalGain = newTotalVal - totalCost;

          updatedPositions = positions.map((p) =>
            p.ticker === newOrder.ticker
              ? {
                  ...p,
                  shares: totalShares,
                  avgCostUSD: newAvgCost,
                  currentPriceUSD: newOrder.price,
                  totalValueUSD: newTotalVal,
                  totalGainUSD: totalGain,
                  totalGainPercent: (totalGain / totalCost) * 100,
                  lastPurchasedDate: new Date().toISOString().slice(0, 10),
                  primaryFundingSourceLabel: newOrder.paymentSource?.label || p.primaryFundingSourceLabel
                }
              : p
          );
        } else {
          const newPos: StockPosition = {
            ticker: newOrder.ticker,
            name: newOrder.stockName,
            shares: newOrder.shares,
            avgCostUSD: newOrder.price,
            currentPriceUSD: newOrder.price,
            totalValueUSD: newOrder.totalUSD,
            totalGainUSD: 0,
            totalGainPercent: 0,
            dailyGainUSD: 0,
            sector: newOrder.sector || 'Technology & AI',
            dividendYield: '0.50%',
            initialBoughtDate: new Date().toISOString().slice(0, 10),
            lastPurchasedDate: new Date().toISOString().slice(0, 10),
            primaryFundingSourceLabel: newOrder.paymentSource?.label
          };
          updatedPositions = [newPos, ...positions];
        }
      } else {
        // Sell spot shares - calculate exact realized gain/loss
        const buyPrice = existing ? existing.avgCostUSD : (newOrder.price * 0.85);
        const costBasis = newOrder.shares * buyPrice;
        const realizedGainLoss = Number((newOrder.totalUSD - costBasis).toFixed(2));
        const realizedGainLossPct = costBasis > 0 ? Number(((realizedGainLoss / costBasis) * 100).toFixed(2)) : 0;

        enrichedOrder.buyPriceUSD = buyPrice;
        enrichedOrder.costBasisUSD = costBasis;
        enrichedOrder.realizedGainLossUSD = realizedGainLoss;
        enrichedOrder.realizedGainLossPercent = realizedGainLossPct;

        if (existing) {
          const remainingShares = Math.max(0, existing.shares - newOrder.shares);
          if (remainingShares <= 0.0001) {
            updatedPositions = positions.filter((p) => p.ticker !== newOrder.ticker);
          } else {
            const totalVal = remainingShares * newOrder.price;
            const remainingCostBasis = remainingShares * existing.avgCostUSD;
            const totalGain = totalVal - remainingCostBasis;
            updatedPositions = positions.map((p) =>
              p.ticker === newOrder.ticker
                ? {
                    ...p,
                    shares: Number(remainingShares.toFixed(4)),
                    currentPriceUSD: newOrder.price,
                    totalValueUSD: totalVal,
                    totalGainUSD: totalGain,
                    totalGainPercent: (totalGain / remainingCostBasis) * 100,
                  }
                : p
            );
          }
        }
      }
    }

    const updatedOrders = [enrichedOrder, ...orders];
    setOrders(updatedOrders);
    saveStoredStockOrders(userId, updatedOrders);

    if (isSpotOrder) {
      setPositions(updatedPositions);
      saveStoredStockPositions(userId, updatedPositions);
    }

    // Record into universal ledger for tax receipts
    try {
      const ledgerItem = createLedgerItemFromStockOrder(enrichedOrder, stockInfo);
      
      // Update global AppContext ledger for real-time visibility in Admin/Global desks
      addTransaction(ledgerItem);
      
      // Keep persistent user-specific storage in sync
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record stock order to ledger', e);
    }

    // Trigger universal notification
    addNotification({
      title: `${newOrder.side === 'buy' ? '📈 Buy Order Filled' : '📉 Sell Order Executed'}: ${newOrder.shares} ${newOrder.ticker}`,
      description: `${newOrder.side === 'buy' ? 'Executed' : 'Sold'} ${newOrder.shares} units of ${newOrder.stockName} @ ${newOrder.price.toFixed(2)} (${newOrder.totalUSD.toLocaleString()} via ${newOrder.paymentSource?.label || 'Final Coin'}).`,
      type: 'stocks',
      targetTab: 'stocks',
      targetId: newOrder.ticker,
      amount: newOrder.totalUSD,
      currency: newOrder.paymentSource?.label || 'AFNL',
    });

    // Open confirmation receipt modal
    setSelectedReceiptOrder(enrichedOrder);
  };

  const handleSelectStock = (stock: StockItem) => {
    setSelectedStock(stock);
    setViewingStockDetail(stock);
    setShowInteractiveChart(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenQuickTradeModal = (
    stock: StockItem,
    side: 'buy' | 'sell' = 'buy',
    initialDerivative: DerivativeType = 'spot'
  ) => {
    setQuickTradeSide(side);
    setQuickTradeDerivative(initialDerivative);
    setQuickTradeStock(stock);
  };

  const handleToggleWatchlist = (ticker: string) => {
    const next = toggleStoredWatchlist(userId, ticker);
    setWatchlist(next);
    const isNowFavorite = next.some(t => t.toUpperCase() === ticker.toUpperCase());
    const stock = stocks.find(s => s.ticker.toUpperCase() === ticker.toUpperCase());
    if (stock) {
      if (isNowFavorite) {
        saveDynamicAlpacaStock(stock);
      }
      addNotification({
        title: isNowFavorite ? `⭐ Added to Favorites: ${stock.ticker}` : `Removed from Favorites: ${stock.ticker}`,
        description: isNowFavorite ? `${stock.name} is now tracked in your favorites list with live alerts.` : `${stock.name} removed from your favorite watchlist.`,
        type: 'stocks',
        targetTab: 'stocks',
        showToast: true,
      });
    }
  };

  // Active Market Way Details
  const activeMarketInfo = selectedMarketWay === 'social' ? { id: 'social', name: 'Social Trades Feed', title: 'Social Trades Feed', icon: Users } : STOCK_MARKET_WAYS.find((m) => m.id === selectedMarketWay);

  // Count stocks and calculate growth statistics per market way
  const marketCounts = {
    final: stocks.filter(s => s.marketType === 'final').length,
    stable: stocks.filter(s => s.marketType === 'stable').length,
    fiat: stocks.filter(s => s.marketType === 'fiat').length,
    crypto: stocks.filter(s => s.marketType === 'crypto').length,
    global: 0 // Placeholder for Alpaca search
  };

  // Detailed statistics (holdings count & growth average) for active stock market types
  const marketTypeStats = useMemo(() => {
    const calcStats = (mType: 'final' | 'stable' | 'fiat' | 'crypto') => {
      const mPositions = positions.filter((p) => {
        const stk = stocks.find((s) => s.ticker.toUpperCase() === p.ticker.toUpperCase());
        return stk ? stk.marketType === mType : false;
      });
      const costBasis = mPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0);
      const gainUSD = mPositions.reduce((s, p) => s + (p.totalGainUSD || 0), 0);
      const holdingsGrowthAvg = costBasis > 0
        ? (gainUSD / costBasis) * 100
        : (mPositions.length > 0 ? mPositions.reduce((s, p) => s + (p.totalGainPercent || 0), 0) / mPositions.length : null);
      
      const mStocks = stocks.filter((s) => s.marketType === mType);
      const marketAvg = mStocks.length > 0
        ? mStocks.reduce((s, stk) => s + (stk.changePercent || 0), 0) / mStocks.length
        : 0;

      return {
        holdingsCount: mPositions.length,
        growthAvg: holdingsGrowthAvg !== null ? holdingsGrowthAvg : marketAvg,
        isHoldingsGrowth: holdingsGrowthAvg !== null,
        marketAvg,
      };
    };

    return {
      final: calcStats('final'),
      stable: calcStats('stable'),
      fiat: calcStats('fiat'),
      crypto: calcStats('crypto'),
    };
  }, [positions, stocks]);

  // Favorite (Watchlist) Stats
  const favoriteStocksList = useMemo(() => {
    return stocks.filter((s) => watchlist.some((w) => w.toUpperCase() === s.ticker.toUpperCase()));
  }, [stocks, watchlist]);

  const favoritePositionsList = useMemo(() => {
    return positions.filter((p) => watchlist.some((w) => w.toUpperCase() === p.ticker.toUpperCase()));
  }, [positions, watchlist]);

  const favoriteGrowthAvg = useMemo(() => {
    if (favoriteStocksList.length > 0) {
      return favoriteStocksList.reduce((s, stk) => s + (stk.changePercent || 0), 0) / favoriteStocksList.length;
    }
    return 0;
  }, [favoriteStocksList]);

  // Filter stocks for Personal & Business IPOs traded exclusively in Final Currencies
  const marketScopedStocks = useMemo(() => {
    const finalIpoStocks = stocks.filter(
      (s) => (s.marketType === 'final' || !s.marketType) && (s.issuanceType === 'personal' || s.issuanceType === 'business' || s.assetCategory === 'personal' || s.assetCategory === 'business' || Boolean(s.ipoRefId))
    );
    if (selectedMarketWay === 'favorites') {
      return finalIpoStocks.filter((s) => watchlist.some((w) => w.toUpperCase() === s.ticker.toUpperCase()));
    }
    return finalIpoStocks;
  }, [stocks, selectedMarketWay, watchlist]);

  // Extract sectors in this market for chips
  const availableSectors = useMemo(() => {
    const sectors = new Set<string>();
    marketScopedStocks.forEach((s) => sectors.add(s.sector));
    return Array.from(sectors);
  }, [marketScopedStocks]);

  // Filtered & Sorted Equities in this market mode
  const displayedMarketStocks = useMemo(() => {
    let result = [...marketScopedStocks];

    // Text search in this market (supports ticker, company name, personal/business category, and issuance coin like AFNL, USDC, BTC, USD)
    if (marketSearchQuery.trim()) {
      result = result.filter((s) => matchStockSearch(s, marketSearchQuery));
    }

    // Sector Filter
    if (selectedSectorFilter !== 'all') {
      result = result.filter((s) => s.sector === selectedSectorFilter);
    }

    // Helper parsing for sorting
    const parseVol = (v?: string) => {
      if (!v) return 0;
      const num = parseFloat(v);
      if (v.includes('B') || v.includes('b')) return num * 1e9;
      if (v.includes('M') || v.includes('m')) return num * 1e6;
      if (v.includes('K') || v.includes('k')) return num * 1e3;
      return num || 0;
    };
    const parseCap = (c?: string) => {
      if (!c) return 0;
      const num = parseFloat(c.replace('$', ''));
      if (c.includes('T') || c.includes('t')) return num * 1e12;
      if (c.includes('B') || c.includes('b')) return num * 1e9;
      if (c.includes('M') || c.includes('m')) return num * 1e6;
      return num || 0;
    };

    // Sorting
    result.sort((a, b) => {
      if (sortBy === 'gainers') return b.changePercent - a.changePercent;
      if (sortBy === 'price') return b.price - a.price;
      if (sortBy === 'volume') return parseVol(b.volume) - parseVol(a.volume);
      if (sortBy === 'alphabetical') return a.ticker.localeCompare(b.ticker);
      // Default: market cap
      return parseCap(b.marketCap) - parseCap(a.marketCap);
    });

    return result;
  }, [marketScopedStocks, marketSearchQuery, selectedSectorFilter, sortBy]);

  // Filter news based on selected market architecture (always keep user-posted IPO news visible at top)
  const filteredNews = useMemo(() => {
    const userIpoNews = allNews.filter((item) => item.isUserIpoNews);
    const systemNews = allNews.filter((item) => !item.isUserIpoNews);
    if (selectedMarketWay === 'all' || selectedMarketWay === 'social') {
      return [...userIpoNews, ...systemNews];
    }
    const marketTickers = new Set(stocks.filter(s => s.marketType === selectedMarketWay).map(s => s.ticker));
    const matchingSystem = systemNews.filter(item => 
      item.tickers?.some(t => marketTickers.has(t))
    );
    return [...userIpoNews, ...(matchingSystem.length > 0 ? matchingSystem : systemNews)];
  }, [selectedMarketWay, stocks, allNews]);

  const getMarketBadgeUI = (_marketType?: StockMarketWay, item?: StockItem) => {
    const personalTickers = ['ALEX', 'ELEN', 'VANC', 'SLIN', 'KHAL', 'SATO', 'SATOSHI', 'STRL', 'STERL'];
    const isPersonal =
      item?.issuanceType === 'personal' ||
      item?.assetCategory === 'personal' ||
      (item?.ticker ? personalTickers.includes(item.ticker.toUpperCase()) : false);

    if (isPersonal) {
      return { label: 'Personal Stock', coin: item?.issuanceCoinSymbol || 'AFNL', bg: 'bg-purple-100 text-purple-900 border-purple-300', icon: User };
    }
    return { label: 'Business Stock', coin: item?.issuanceCoinSymbol || 'AFNL', bg: 'bg-blue-100 text-blue-900 border-blue-300', icon: Building2 };
  };

  const handleSelectAlpacaAsset = async (asset: any, snapshot: any) => {
    if (!asset || !snapshot) return;

    // Map Alpaca Asset to StockItem format
    const price = snapshot.latestTrade?.p || snapshot.dailyBar?.c || 0;
    const prevClose = snapshot.prevDailyBar?.c || price;
    const changeUSD = price - prevClose;
    const changePercent = prevClose !== 0 ? (changeUSD / prevClose) * 100 : 0;

    // Fetch some bars for the chart if possible
    let history: any = {
      '1D': [],
      '1W': [],
      '1M': [],
      '1Y': [],
      '5Y': []
    };

    try {
      const barsRes = await fetch(`/api/alpaca/bars/${asset.symbol}?timeframe=1Min&limit=100&asset_class=${asset.asset_class}`);
      const barsData = await barsRes.json();
      if (barsData.success && barsData.data.length > 0) {
        history['1D'] = barsData.data.map((b: any) => ({
          time: new Date(b.t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          price: b.c,
          volume: b.v,
          open: b.o,
          high: b.h,
          low: b.l,
          close: b.c
        }));
      } else {
        // Fallback to minimal data so chart doesn't crash
        history['1D'] = [
          { time: '9:30 AM', price: prevClose, volume: 0 },
          { time: 'Now', price: price, volume: 0 }
        ];
      }
    } catch (err) {
      console.error('Error fetching bars for detail page:', err);
      history['1D'] = [{ time: '9:30 AM', price: prevClose, volume: 0 }, { time: 'Now', price: price, volume: 0 }];
    }

    const mappedStock: StockItem = {
      ticker: asset.symbol,
      name: asset.name,
      price: price,
      changeUSD: changeUSD,
      changePercent: changePercent,
      marketType: 'global',
      exchange: asset.exchange,
      sector: 'All', 
      description: `${asset.name} is a global asset listed on ${asset.exchange}. Class: ${asset.asset_class}. Status: ${asset.status}. This asset is tracked in real-time via the Alpaca Unified Market Data API.`,
      high24h: snapshot.dailyBar?.h || price,
      low24h: snapshot.dailyBar?.l || price,
      openPrice: snapshot.dailyBar?.o || price,
      prevClose: prevClose,
      volume: snapshot.dailyBar?.v?.toLocaleString() || '0',
      avgVolume: 'N/A',
      marketCap: 'N/A',
      peRatio: 0,
      eps: 0,
      dividendYield: 'N/A',
      beta: 1.0,
      fiftyTwoWeekHigh: price * 1.2,
      fiftyTwoWeekLow: price * 0.8,
      analystRating: 'Hold',
      analystTargetUSD: price * 1.1,
      analystCount: 0,
      sparkline: history['1D'].map((p: any) => p.price),
      history: history
    };

    saveDynamicAlpacaStock(mappedStock);
    setViewingStockDetail(mappedStock);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6 pb-12 text-center">
      {/* 1. Global Equities Search Bar with Market Awareness (Removed) */}

      {viewingStockDetail ? (
        <StockDetailPage
          stock={viewingStockDetail}
          stocks={stocks}
          watchlist={watchlist}
          positions={positions}
          orders={orders}
          currentUser={currentUser}
          selectedMarketWay={selectedMarketWay}
          activeMarketTitle={activeMarketInfo?.title}
          portfolioReturnLabel={portfolioReturnLabel}
          onBackToPortfolioTab={onBackToPortfolioTab}
          onBackToMarkets={() => {
            lastAppliedTickerRef.current = undefined;
            setViewingStockDetail(null);
            onClearSelectedStock?.();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onSelectStock={handleSelectStock}
          onToggleWatchlist={handleToggleWatchlist}
          onOpenQuickTrade={handleOpenQuickTradeModal}
          onOpenAuthModal={onOpenAuthModal}
          onOrderExecuted={handleOrderExecuted}
        />
      ) : (
        <div className="space-y-6 text-center">
          {/* Title */}
          <div className="space-y-1">
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 tracking-tight">
              Final Stock Exchange
            </h1>
            <p className="text-xs sm:text-sm text-slate-500">
              Trade Personal and Business IPO equities, options, and futures contracts settled strictly in Final Currencies.
            </p>
          </div>

          {/* Search Bar Input */}
          <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-2xs max-w-2xl mx-auto">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={marketSearchQuery}
                onChange={(e) => setMarketSearchQuery(e.target.value)}
                placeholder="Search Personal & Business IPOs by ticker or name (e.g. ALEX, HYPR, BSYN, NEXA)..."
                className="w-full pl-10 pr-10 py-3 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 focus:border-amber-500 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-400/20 font-sans shadow-2xs transition-all"
              />
              {marketSearchQuery && (
                <button
                  type="button"
                  onClick={() => setMarketSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Only show stock once typed in */}
          {marketSearchQuery.trim() && (
            displayedMarketStocks.length === 0 ? (
              <div className="bg-white p-10 rounded-3xl border border-slate-200 shadow-2xs text-center max-w-xl mx-auto space-y-2">
                <h3 className="text-base font-bold text-slate-900">No IPO Stocks Found</h3>
                <p className="text-xs text-slate-500">
                  No Personal or Business IPOs match "{marketSearchQuery}". Try another symbol like ALEX, HYPR, BSYN, or NEXA.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 max-w-6xl mx-auto">
                {displayedMarketStocks.map((stock, idx) => {
                  const isPos = stock.changeUSD >= 0;
                  const isOwned = positions.some((p) => p.ticker === stock.ticker);
                  const isFollowed = watchlist.includes(stock.ticker);
                  const badge = getMarketBadgeUI(stock.marketType, stock);

                  return (
                    <div
                      key={`stock-market-view-${stock.ticker}-${stock.marketType || 'gen'}-${idx}`}
                      onClick={() => handleSelectStock(stock)}
                      className="p-4 rounded-2xl border bg-white hover:bg-slate-50/80 border-slate-200/90 hover:border-slate-300 shadow-2xs hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between gap-3 group relative text-left"
                    >
                      {/* Top: Ticker, Name, Market Badge, Watchlist */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs shrink-0 shadow-2xs group-hover:bg-amber-600 transition-colors">
                            {stock.ticker}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-mono font-bold text-sm text-slate-900 group-hover:text-amber-800">
                                ${stock.ticker}
                              </span>
                              <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border ${badge.bg}`}>
                                {badge.coin}
                              </span>
                              {isOwned && (
                                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                                  Owned
                                </span>
                              )}
                            </div>
                            <h3 className="text-xs text-slate-600 font-medium truncate mt-0.5">
                              {stock.name}
                            </h3>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleWatchlist(stock.ticker);
                          }}
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            isFollowed ? 'text-amber-500 hover:bg-amber-50' : 'text-slate-300 hover:text-slate-500 hover:bg-slate-100'
                          }`}
                          title={isFollowed ? 'Remove from Watchlist' : 'Add to Watchlist'}
                        >
                          <Star className={`w-4 h-4 ${isFollowed ? 'fill-amber-400' : ''}`} />
                        </button>
                      </div>

                      {/* Mid: Price & 24h Change (Centered without overlap) */}
                      <div className="flex items-center justify-center gap-6 py-2.5 border-t border-slate-100 text-center">
                        <div className="text-center">
                          <span className="text-[10px] text-slate-400 uppercase font-mono block">Price</span>
                          <span className="font-mono font-bold text-base text-slate-900">
                            {formatStockPrice(stock.price, stock)}
                          </span>
                        </div>

                        <div className="h-7 w-px bg-slate-200" />

                        <div className="text-center">
                          <span className="text-[10px] text-slate-400 uppercase font-mono block">24h Gain</span>
                          <span
                            className={`text-xs font-mono font-bold px-2.5 py-1 rounded-lg inline-flex items-center gap-1 ${
                              isPos ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                            }`}
                          >
                            {isPos ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            <span>{isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%</span>
                          </span>
                        </div>
                      </div>

                      {/* Details / Sector */}
                      <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1 border-t border-slate-100">
                        <span className="truncate max-w-[130px]">{stock.sector}</span>
                        <span className="font-mono text-[10px] text-slate-400">Vol: {stock.volume || stock.avgVolume || 'N/A'}</span>
                      </div>

                      {/* Anonymized Issuer Final Currency Loan Debts (Personal & Business Stocks) */}
                      {(stock.marketType === 'final' ||
                        stock.issuanceType === 'personal' ||
                        stock.issuanceType === 'business' ||
                        stock.assetCategory === 'personal' ||
                        stock.assetCategory === 'business') && (() => {
                        void loansTick;
                        const matchingIpo = ipos.find(
                          (i) => i.ticker?.toUpperCase() === stock.ticker.toUpperCase().replace(/-FNL$/i, '')
                        );
                        const debtSummary = getAnonymousIssuerDebtSummary([
                          stock.issuerHandle,
                          stock.issuerName,
                          matchingIpo?.issuerId,
                          matchingIpo?.issuerHandle,
                          matchingIpo?.issuerName,
                          stock.ceo,
                        ]);

                        return (
                          <div className="p-2 rounded-xl bg-slate-50 border border-slate-200/80 text-center space-y-1">
                            <div className="inline-flex items-center justify-center gap-1 text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                              <Lock className="w-2.5 h-2.5 text-slate-400" />
                              <span>Final Loan Debt (Private Lender)</span>
                            </div>
                            {debtSummary.byCurrency.length === 0 ? (
                              <div className="text-[11px] font-mono font-semibold text-emerald-700">
                                0 Final Currency Loan Debts
                              </div>
                            ) : (
                              <div className="flex flex-wrap items-center justify-center gap-1">
                                {debtSummary.byCurrency.map((d) => (
                                  <span
                                    key={d.coinSymbol}
                                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${
                                      d.defaultedCount > 0 || d.overdueCount > 0
                                        ? 'bg-rose-50 border-rose-200 text-rose-800'
                                        : 'bg-amber-50 border-amber-200 text-amber-900'
                                    }`}
                                  >
                                    Owes {d.totalOwed.toLocaleString()} {d.coinSymbol}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })()}

                      {/* Actions: Quick 1-Click Buy / Sell / Chart */}
                      <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenQuickTradeModal(stock, 'buy');
                          }}
                          className="flex-1 py-1.5 px-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1 shadow-2xs cursor-pointer"
                        >
                          <Zap className="w-3.5 h-3.5 text-amber-400" />
                          <span>Buy ({badge.coin})</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelectStock(stock);
                          }}
                          className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                          title="Inspect Chart"
                        >
                          <BarChart3 className="w-4 h-4 text-slate-600" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          )}
        </div>
      )}

      {/* 8. Trending Stocks News Feed (Shown only in Stock Market directory, never on individual stock page) */}
      {!viewingStockDetail && (
        <StockNewsFeed
          news={filteredNews}
          stocks={stocks}
          ownedTickers={positions.map((p) => p.ticker)}
          followedTickers={watchlist}
          currentUserId={currentUser?.id}
          onOpenPostIPONews={() => {
            if (!currentUser) {
              onOpenAuthModal();
              return;
            }
            setIsPostIPONewsOpen(true);
          }}
          onDeleteIPONews={(newsId) => {
            deleteIPONewsItem(newsId);
            setAllNews(getAllCombinedStockNews());
            addToast({
              type: 'info',
              title: 'IPO News Removed',
              message: 'Your IPO news update was removed from Trending Stock News.'
            });
          }}
          onSelectTicker={(ticker) => {
            const found = stocks.find((s) => s.ticker === ticker);
            if (found) {
              handleSelectStock(found);
            }
          }}
          onQuickTrade={(ticker) => {
            const found = stocks.find((s) => s.ticker === ticker);
            if (found) {
              handleOpenQuickTradeModal(found, 'buy');
            }
          }}
        />
      )}

      {/* Post IPO News / Earnings Modal */}
      {isPostIPONewsOpen && (
        <PostIPONewsModal
          isOpen={isPostIPONewsOpen}
          onClose={() => setIsPostIPONewsOpen(false)}
          ipos={ipos}
          currentUser={currentUser}
          onPublished={(item) => {
            setAllNews(getAllCombinedStockNews());
            addToast({
              type: 'success',
              title: `IPO News Published ($${item.tickers[0]})`,
              message: `"${item.title}" is now live in Trending Stock News.`
            });
          }}
        />
      )}

      {/* 9. Quick Buy / Trade Options Modal */}
      <QuickBuyStockModal
        stock={quickTradeStock}
        currentUser={currentUser}
        isOpen={!!quickTradeStock}
        initialSide={quickTradeSide}
        initialDerivativeType={quickTradeDerivative}
        positions={positions}
        onClose={() => setQuickTradeStock(null)}
        onOpenAuthModal={onOpenAuthModal}
        onLookUpChart={(stock) => {
          handleSelectStock(stock);
          setQuickTradeStock(null);
        }}
        onExecuteBuy={handleOrderExecuted}
      />

      {/* 10. Official Trade Confirmation Receipt Slip Modal */}
      <TradeConfirmationModal
        order={selectedReceiptOrder}
        onClose={() => setSelectedReceiptOrder(null)}
        onViewPortfolio={() => {
          setSelectedReceiptOrder(null);
          onNavigateBack();
        }}
      />
    </div>
  );
};
