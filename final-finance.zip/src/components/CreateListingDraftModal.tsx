import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Plus, 
  Check, 
  ArrowRight, 
  Package, 
  Briefcase, 
  Repeat, 
  Sparkles, 
  ShieldCheck, 
  Building2, 
  Coins, 
  Save, 
  Upload, 
  Trash2, 
  AlertCircle, 
  Tag, 
  DollarSign, 
  Eye, 
  Layers, 
  MapPin, 
  Clock, 
  FileText, 
  Image as ImageIcon,
  Video as VideoIcon,
  Play,
  Film,
  Shuffle,
  CheckCircle2,
  HelpCircle,
  Maximize2,
  Globe,
  Users,
  Lock,
  Shield,
  CheckSquare,
  Square
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { MarketplaceListing, MarketplaceItemType, SettlementMethod, ListingStatus, MediaItem, ListingIntent, PrimaryTradeMode, ListingVisibility } from '../types/marketplace';
import { FriendGroup } from '../types/social';
import { createOrUpdateListing } from '../services/marketplaceService';
import { getUserFriendGroups } from '../services/friendGroupService';

interface CreateListingDraftModalProps {
  isOpen: boolean;
  currentUser?: AuthSession | null;
  initialDraft?: MarketplaceListing | null;
  initialMode?: 'create' | 'edit';
  onClose: () => void;
  onSaved: (listing: MarketplaceListing, status: ListingStatus) => void;
}

const GOODS_CATEGORIES = [
  'Precious Metals & Bullion',
  'Hardware & Compute',
  'Electronics & Technology',
  'Real Estate & Land Titles',
  'Luxury Goods & Watches',
  'Vehicles & Transport',
  'Industrial Equipment',
  'Art & Collectibles',
  'Commodities & Raw Materials',
  'Other Physical Assets'
];

const SERVICES_CATEGORIES = [
  'Cybersecurity & Auditing',
  'Financial Advisory & Legal',
  'Software & Blockchain Engineering',
  'Design & Creative Strategy',
  'Consulting & Management',
  'Marketing & Growth',
  'Data Science & AI Engineering',
  'Taxation & Accounting',
  'Escrow & Custody Services',
  'Other Professional Services'
];

const SAMPLE_MEDIA_PRESETS = {
  good: [
    {
      url: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
      type: 'image' as const,
      name: 'Fine Gold Bullion Bar'
    },
    {
      url: 'https://assets.mixkit.co/videos/preview/mixkit-gold-bars-in-a-vault-42795-large.mp4',
      type: 'video' as const,
      name: 'Gold Vault Video.mp4'
    },
    {
      url: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=800&q=80',
      type: 'image' as const,
      name: 'High-Density GPU Rig'
    },
    {
      url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
      type: 'image' as const,
      name: 'Luxury Timepiece'
    },
    {
      url: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-luxury-watch-43187-large.mp4',
      type: 'video' as const,
      name: 'Watch Movement.mp4'
    }
  ],
  service: [
    {
      url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
      type: 'image' as const,
      name: 'Smart Contract Audit Code'
    },
    {
      url: 'https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-code-42845-large.mp4',
      type: 'video' as const,
      name: 'Code Review Session.mp4'
    },
    {
      url: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80',
      type: 'image' as const,
      name: 'Legal Advisory Suite'
    },
    {
      url: 'https://assets.mixkit.co/videos/preview/mixkit-server-room-with-blinking-lights-42934-large.mp4',
      type: 'video' as const,
      name: 'Data Architecture.mp4'
    }
  ]
};

export const CreateListingDraftModal: React.FC<CreateListingDraftModalProps> = ({
  isOpen,
  currentUser,
  initialDraft,
  initialMode = 'create',
  onClose,
  onSaved,
}) => {
  // Form State
  const [listingIntent, setListingIntent] = useState<ListingIntent>('sell');
  const [itemType, setItemType] = useState<MarketplaceItemType>('good');
  const [primaryTradeMode, setPrimaryTradeMode] = useState<PrimaryTradeMode>('currency');
  const [primaryCurrency, setPrimaryCurrency] = useState<string>('USD');
  const [acceptedCurrencyList, setAcceptedCurrencyList] = useState<string[]>(['USD', 'AFNL', 'USDC']);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(GOODS_CATEGORIES[0]);
  const [description, setDescription] = useState('');
  
  // Media items
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [urlInput, setUrlInput] = useState('');
  const [mediaTypeInput, setMediaTypeInput] = useState<'image' | 'video'>('image');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingMedia, setIsUploadingMedia] = useState(false);

  // Tags
  const [customTagInput, setCustomTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  
  // Goods fields
  const [quantity, setQuantity] = useState<number>(1);
  const [unitLabel, setUnitLabel] = useState('units');
  const [condition, setCondition] = useState<'Brand New' | 'Mint' | 'Refurbished' | 'Certified Rare' | 'Good' | 'Fair'>('Brand New');
  const [location, setLocation] = useState('');

  // Services fields
  const [availableUnits, setAvailableUnits] = useState<number>(10);
  const [unitType, setUnitType] = useState<'Hours' | 'Sessions' | 'Consultations' | 'Deliverables' | 'Credits'>('Hours');
  const [turnaroundTime, setTurnaroundTime] = useState('2-3 Business Days');
  const [deliverables, setDeliverables] = useState('');
  const [skillInput, setSkillInput] = useState('');
  const [skills, setSkills] = useState<string[]>([]);

  // Multi-Settlement Methods Selected
  const [acceptedSettlements, setAcceptedSettlements] = useState<SettlementMethod[]>([
    'barter',
    'final_coins',
    'stable_coins',
    'fiat',
    'crypto'
  ]);

  // Privacy & Listing Visibility
  const [visibility, setVisibility] = useState<ListingVisibility>('public');
  const [allowedGroupIds, setAllowedGroupIds] = useState<string[]>([]);
  const [friendGroups, setFriendGroups] = useState<FriendGroup[]>([]);

  // Cross-Transactional Terms
  const [acceptSplitSettlements, setAcceptSplitSettlements] = useState(true);
  const [splitPreferences, setSplitPreferences] = useState('Open to 50% Barter trade + 50% Coins or custom mix');
  const [customExchangeOffers, setCustomExchangeOffers] = useState('Seeking precious metals, tech hardware, or professional consulting in trade');

  // Settlement-specific pricing terms
  const [barterDesired, setBarterDesired] = useState('');
  const [barterExchangeType, setBarterExchangeType] = useState<'good' | 'service' | 'any'>('any');
  const [barterEstimatedUSD, setBarterEstimatedUSD] = useState<number>(1000);
  const [barterOpenOffers, setBarterOpenOffers] = useState(true);

  const [finalCoinSymbol, setFinalCoinSymbol] = useState('AFNL');
  const [finalCoinAmount, setFinalCoinAmount] = useState<number>(80);

  const [stableCoinSymbol, setStableCoinSymbol] = useState('USDC');
  const [stableCoinAmount, setStableCoinAmount] = useState<number>(1000);
  const [stableCoinNetwork, setStableCoinNetwork] = useState('Polygon');

  const [fiatCurrencyCode, setFiatCurrencyCode] = useState('USD');
  const [fiatAmount, setFiatAmount] = useState<number>(1000);

  const [cryptoSymbol, setCryptoSymbol] = useState('ETH');
  const [cryptoAmount, setCryptoAmount] = useState<number>(0.35);
  const [cryptoNetwork, setCryptoNetwork] = useState('Ethereum');

  // UI state
  const [activeTab, setActiveTab] = useState<'details' | 'settlement' | 'preview'>('details');
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Populate friend groups
  useEffect(() => {
    const userGroups = getUserFriendGroups(currentUser?.uid || currentUser?.id || 'guest');
    setFriendGroups(userGroups);
  }, [currentUser]);

  // Populate form if initialDraft is provided
  useEffect(() => {
    if (initialDraft) {
      setListingIntent(initialDraft.listingIntent || 'sell');
      setItemType(initialDraft.itemType);
      setPrimaryTradeMode(initialDraft.primaryTradeMode || 'currency');
      setPrimaryCurrency(initialDraft.primaryCurrency || 'USD');
      setAcceptedCurrencyList(initialDraft.acceptedCurrencyList || ['USD', 'AFNL', 'USDC']);
      setTitle(initialDraft.title);
      setCategory(initialDraft.category);
      setDescription(initialDraft.description);
      setVisibility(initialDraft.visibility || 'public');
      setAllowedGroupIds(initialDraft.allowedGroupIds || []);
      
      // Populate media
      if (initialDraft.mediaList && initialDraft.mediaList.length > 0) {
        setMediaList(initialDraft.mediaList);
      } else if (initialDraft.imageUrl) {
        setMediaList([
          {
            id: 'init-img',
            url: initialDraft.imageUrl,
            type: 'image',
            name: 'Cover Image'
          },
          ...(initialDraft.videoUrl ? [{
            id: 'init-vid',
            url: initialDraft.videoUrl,
            type: 'video' as const,
            name: 'Preview Video'
          }] : [])
        ]);
      }

      setTags(initialDraft.tags || []);
      setAcceptedSettlements(initialDraft.acceptedSettlements || ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto']);
      
      if (initialDraft.crossTransactionalTerms) {
        setAcceptSplitSettlements(initialDraft.crossTransactionalTerms.acceptSplitSettlements);
        setSplitPreferences(initialDraft.crossTransactionalTerms.splitPreferences || '');
        setCustomExchangeOffers(initialDraft.crossTransactionalTerms.customExchangeOffers || '');
      }

      if (initialDraft.barterTerms) {
        setBarterDesired(initialDraft.barterTerms.desiredTrades);
        setBarterExchangeType(initialDraft.barterTerms.desiredExchangeType || 'any');
        setBarterOpenOffers(initialDraft.barterTerms.openToOffers);
        if (initialDraft.barterTerms.estimatedValueUSD) {
          setBarterEstimatedUSD(initialDraft.barterTerms.estimatedValueUSD);
        }
      }

      if (initialDraft.finalCoinsPricing) {
        setFinalCoinSymbol(initialDraft.finalCoinsPricing.symbol);
        setFinalCoinAmount(initialDraft.finalCoinsPricing.amount);
      }

      if (initialDraft.stableCoinsPricing) {
        setStableCoinSymbol(initialDraft.stableCoinsPricing.symbol);
        setStableCoinAmount(initialDraft.stableCoinsPricing.amount);
        setStableCoinNetwork(initialDraft.stableCoinsPricing.network);
      }

      if (initialDraft.fiatPricing) {
        setFiatCurrencyCode(initialDraft.fiatPricing.currencyCode);
        setFiatAmount(initialDraft.fiatPricing.amount);
      }

      if (initialDraft.cryptoPricing) {
        setCryptoSymbol(initialDraft.cryptoPricing.symbol);
        setCryptoAmount(initialDraft.cryptoPricing.amount);
        setCryptoNetwork(initialDraft.cryptoPricing.network);
      }

      if (initialDraft.itemType === 'good') {
        setQuantity(initialDraft.quantity || 1);
        setUnitLabel(initialDraft.unitLabel || 'units');
        setCondition(initialDraft.condition || 'Brand New');
        setLocation(initialDraft.location || '');
      } else {
        setAvailableUnits(initialDraft.availableUnits || 10);
        setUnitType(initialDraft.unitType || 'Hours');
        setTurnaroundTime(initialDraft.turnaroundTime || '2-3 Business Days');
        setDeliverables(initialDraft.deliverables || '');
        setSkills(initialDraft.skills || []);
      }
    } else {
      setListingIntent('sell');
      setItemType('good');
      setPrimaryTradeMode('currency');
      setPrimaryCurrency('USD');
      setAcceptedCurrencyList(['USD', 'AFNL', 'USDC']);
      setCategory(GOODS_CATEGORIES[0]);
      setMediaList([]);
    }
  }, [initialDraft, isOpen]);

  const [isDragOver, setIsDragOver] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);

  const processFiles = (fileList: FileList | File[]) => {
    const files = Array.from(fileList);
    if (files.length === 0) return;

    setIsUploadingMedia(true);

    files.forEach((file: File) => {
      const isVideo = Boolean(file.type.startsWith('video/') || file.name.match(/\.(mp4|webm|mov|ogg)$/i));
      const isImage = Boolean(file.type.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|gif|svg)$/i));

      if (!isImage && !isVideo) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const resultUrl = event.target?.result as string;
        if (resultUrl) {
          const item: MediaItem = {
            id: `media-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
            url: resultUrl,
            type: isVideo ? 'video' : 'image',
            name: file.name,
            size: file.size
          };
          setMediaList(prev => [...prev, item]);
        }
      };
      reader.readAsDataURL(file);
    });

    setTimeout(() => {
      setIsUploadingMedia(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }, 400);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleAddMediaUrl = () => {
    if (!urlInput.trim()) return;
    const isVid = mediaTypeInput === 'video' || urlInput.match(/\.(mp4|webm|mov|ogg)$/i);
    const newMedia: MediaItem = {
      id: `media-${Date.now()}`,
      url: urlInput.trim(),
      type: isVid ? 'video' : 'image',
      name: isVid ? 'Online Video' : 'Online Photo'
    };
    setMediaList(prev => [...prev, newMedia]);
    setUrlInput('');
  };

  const handleRemoveMedia = (id: string) => {
    setMediaList(prev => prev.filter(m => m.id !== id));
  };

  const handleSetPrimaryMedia = (index: number) => {
    if (index === 0) return;
    setMediaList(prev => {
      const copy = [...prev];
      const selected = copy.splice(index, 1)[0];
      return [selected, ...copy];
    });
  };

  const handleToggleSettlement = (method: SettlementMethod) => {
    if (acceptedSettlements.includes(method)) {
      if (acceptedSettlements.length === 1) {
        setErrorMsg('At least one settlement method must be selected.');
        return;
      }
      setAcceptedSettlements(prev => prev.filter(m => m !== method));
    } else {
      setAcceptedSettlements(prev => [...prev, method]);
      setErrorMsg('');
    }
  };

  // Keep acceptedCurrencyList synchronized with active settlement categories
  useEffect(() => {
    const nextCurrencies: string[] = [];
    if (acceptedSettlements.includes('fiat')) {
      nextCurrencies.push(fiatCurrencyCode || 'USD');
    }
    if (acceptedSettlements.includes('final_coins')) {
      nextCurrencies.push('AFNL');
    }
    if (acceptedSettlements.includes('stable_coins')) {
      nextCurrencies.push(stableCoinSymbol || 'USDC');
    }
    if (acceptedSettlements.includes('crypto')) {
      nextCurrencies.push(cryptoSymbol || 'ETH');
    }
    setAcceptedCurrencyList(nextCurrencies.length > 0 ? nextCurrencies : ['USD']);
  }, [acceptedSettlements, fiatCurrencyCode, stableCoinSymbol, cryptoSymbol]);

  const handleAddTag = (e?: React.KeyboardEvent | React.MouseEvent) => {
    if (e && 'key' in e && e.key !== 'Enter') return;
    if (e && 'preventDefault' in e) e.preventDefault();
    const clean = customTagInput.trim().toLowerCase().replace(/^#/, '');
    if (clean && !tags.includes(clean)) {
      setTags(prev => [...prev, clean]);
      setCustomTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(prev => prev.filter(t => t !== tagToRemove));
  };

  const handleSubmit = (targetStatus: ListingStatus) => {
    setErrorMsg('');
    if (!title.trim()) {
      setErrorMsg('Please enter a listing title.');
      setActiveTab('details');
      return;
    }

    if (acceptedSettlements.length === 0) {
      setErrorMsg('Please select at least one accepted settlement method.');
      setActiveTab('settlement');
      return;
    }

    setIsSubmitting(true);

    const primaryImage = mediaList.find(m => m.type === 'image')?.url || mediaList[0]?.url || '';
    const primaryVideo = mediaList.find(m => m.type === 'video')?.url || '';

    const activeUserId = currentUser?.id || 'guest';
    
    // Determine effective primary trade mode and currency
    const effectivePrimaryTradeMode = !acceptedSettlements.some(s => s !== 'barter') ? 'barter' : 'currency';
    let effectivePrimaryCurrency = primaryCurrency;
    if (acceptedSettlements.includes('fiat')) {
      effectivePrimaryCurrency = fiatCurrencyCode || 'USD';
    } else if (acceptedSettlements.includes('final_coins')) {
      effectivePrimaryCurrency = 'AFNL';
    } else if (acceptedSettlements.includes('stable_coins')) {
      effectivePrimaryCurrency = stableCoinSymbol || 'USDC';
    } else if (acceptedSettlements.includes('crypto')) {
      effectivePrimaryCurrency = cryptoSymbol || 'ETH';
    }

    // Calculate primary price USD from active pricing
    let calculatedPrimaryPriceUSD = 1000;
    if (effectivePrimaryTradeMode === 'barter' && acceptedSettlements.includes('barter')) {
      calculatedPrimaryPriceUSD = barterEstimatedUSD || 1000;
    } else {
      if (effectivePrimaryCurrency === 'AFNL' || effectivePrimaryCurrency === 'final_coins') {
        calculatedPrimaryPriceUSD = (finalCoinAmount || 80) * 20;
      } else if (['USD', 'EUR', 'CHF', 'GBP'].includes(effectivePrimaryCurrency)) {
        calculatedPrimaryPriceUSD = fiatAmount || 1000;
      } else if (effectivePrimaryCurrency === 'USDC' || effectivePrimaryCurrency === 'USDT') {
        calculatedPrimaryPriceUSD = stableCoinAmount || 1000;
      } else if (effectivePrimaryCurrency === 'BTC') {
        calculatedPrimaryPriceUSD = (cryptoAmount || 0.35) * 95000;
      } else if (effectivePrimaryCurrency === 'ETH') {
        calculatedPrimaryPriceUSD = (cryptoAmount || 0.35) * 3650;
      } else {
        calculatedPrimaryPriceUSD = fiatAmount || stableCoinAmount || (finalCoinAmount ? finalCoinAmount * 20 : 1000);
      }
    }

    const matchedGroupNames = friendGroups
      .filter(g => allowedGroupIds.includes(g.id))
      .map(g => g.name);

    const payload: Partial<MarketplaceListing> & { title: string; itemType: MarketplaceItemType; status: ListingStatus } = {
      id: initialDraft?.id,
      userId: activeUserId,
      creatorName: currentUser?.name || activeUserId,
      creatorHandle: activeUserId,
      creatorAvatar: currentUser?.avatarUrl,
      listingIntent,
      itemType,
      primaryTradeMode: effectivePrimaryTradeMode,
      primaryCurrency: effectivePrimaryCurrency,
      primaryPriceUSD: calculatedPrimaryPriceUSD,
      title: title.trim(),
      category: category || (itemType === 'good' ? GOODS_CATEGORIES[0] : SERVICES_CATEGORIES[0]),
      description: description.trim(),
      status: targetStatus,
      visibility,
      allowedGroupIds: visibility === 'custom_group' ? allowedGroupIds : [],
      allowedGroupNames: visibility === 'custom_group' ? matchedGroupNames : [],
      
      acceptedSettlements,
      acceptedCurrencyList,
      crossTransactionalTerms: {
        acceptSplitSettlements,
        splitPreferences: splitPreferences.trim(),
        customExchangeOffers: customExchangeOffers.trim(),
        openToCustomMix: true,
      },

      barterTerms: acceptedSettlements.includes('barter') ? {
        desiredTrades: barterDesired.trim() || 'Open to high-value physical goods, precious metals, or professional services in trade.',
        desiredExchangeType: barterExchangeType,
        openToOffers: barterOpenOffers,
        estimatedValueUSD: barterEstimatedUSD || 1000
      } : undefined,

      finalCoinsPricing: acceptedSettlements.includes('final_coins') ? {
        symbol: finalCoinSymbol,
        amount: finalCoinAmount || 80,
      } : undefined,

      stableCoinsPricing: acceptedSettlements.includes('stable_coins') ? {
        symbol: stableCoinSymbol,
        amount: stableCoinAmount || 1000,
        network: stableCoinNetwork,
      } : undefined,

      fiatPricing: acceptedSettlements.includes('fiat') ? {
        currencyCode: fiatCurrencyCode,
        amount: fiatAmount || 1000,
      } : undefined,

      cryptoPricing: acceptedSettlements.includes('crypto') ? {
        symbol: cryptoSymbol,
        amount: cryptoAmount || 0.35,
        network: cryptoNetwork,
      } : undefined,

      quantity: itemType === 'good' ? quantity : undefined,
      unitLabel: itemType === 'good' ? unitLabel : undefined,
      condition: itemType === 'good' ? condition : undefined,
      location: itemType === 'good' ? location : undefined,

      availableUnits: itemType === 'service' ? availableUnits : undefined,
      unitType: itemType === 'service' ? unitType : undefined,
      turnaroundTime: itemType === 'service' ? turnaroundTime : undefined,
      deliverables: itemType === 'service' ? deliverables : undefined,
      skills: itemType === 'service' ? skills : undefined,

      imageUrl: primaryImage,
      videoUrl: primaryVideo,
      mediaList: mediaList,
      tags: tags.length > 0 ? tags : [itemType, category.toLowerCase()],
    };

    try {
      const saved = createOrUpdateListing(activeUserId, payload);
      setIsSubmitting(false);
      onSaved(saved, targetStatus);
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMsg(err.message || 'Failed to save listing');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* HEADER */}
        <div className="px-5 sm:px-6 py-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-black text-white flex items-center justify-center shadow-xs">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-black tracking-tight flex items-center gap-2">
                <span>{initialDraft ? 'Edit Listing / Draft' : 'Upload Goods & Services'}</span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-neutral-200 text-neutral-800">
                  Cross-Transactional
                </span>
              </h2>
              <p className="text-xs text-neutral-500">
                Upload photos, videos, and configure multi-asset earnings &amp; barter exchange options
              </p>
            </div>
          </div>

          <button
            id="close-draft-modal-btn"
            type="button"
            onClick={onClose}
            className="p-2 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-200 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEPPER TABS */}
        <div className="px-5 sm:px-6 pt-3 pb-2 border-b border-neutral-100 bg-white flex items-center gap-2 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('details')}
            className={`min-h-[36px] px-4 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'details'
                ? 'bg-black text-white font-semibold shadow-xs'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>1. Details &amp; Media ({mediaList.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('settlement')}
            className={`min-h-[36px] px-4 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'settlement'
                ? 'bg-black text-white font-semibold shadow-xs'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>2. Cross-Transactional Earnings ({acceptedSettlements.length} Modes)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`min-h-[36px] px-4 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'preview'
                ? 'bg-black text-white font-semibold shadow-xs'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>3. Live Preview &amp; Publish</span>
          </button>
        </div>

        {/* ERROR BANNER */}
        {errorMsg && (
          <div className="mx-5 sm:mx-6 mt-3 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* MODAL BODY */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-5">
          {/* ================= TAB 1: DETAILS & MEDIA UPLOAD ================= */}
          {activeTab === 'details' && (
            <div className="space-y-5">
              {/* Intent Switcher: Upload to Sell vs Upload to Buy/Request */}
              <div className="p-4 rounded-2xl bg-neutral-900 text-white shadow-sm space-y-2.5">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400">
                      Listing Intent &amp; Market Direction
                    </span>
                    <h3 className="text-sm font-bold text-white mt-0.5">
                      Are you offering to Sell or looking to Buy / Request?
                    </h3>
                  </div>
                  <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                    listingIntent === 'sell' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  }`}>
                    {listingIntent === 'sell' ? 'Offering to Sell' : 'Seeking to Buy (RFP)'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <button
                    id="intent-sell-btn"
                    type="button"
                    onClick={() => setListingIntent('sell')}
                    className={`min-h-[46px] p-3 rounded-xl flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer border ${
                      listingIntent === 'sell'
                        ? 'bg-emerald-500 text-black border-emerald-400 shadow-sm'
                        : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:border-neutral-500'
                    }`}
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload to SELL (Offering Asset/Service)</span>
                  </button>

                  <button
                    id="intent-buy-btn"
                    type="button"
                    onClick={() => setListingIntent('buy')}
                    className={`min-h-[46px] p-3 rounded-xl flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer border ${
                      listingIntent === 'buy'
                        ? 'bg-blue-500 text-white border-blue-400 shadow-sm'
                        : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:border-neutral-500'
                    }`}
                  >
                    <DollarSign className="w-4 h-4" />
                    <span>Upload to BUY / WANTED (Seeking Asset/Service)</span>
                  </button>
                </div>
              </div>

              {/* Type Switcher: Goods vs Services */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-2">
                  Marketplace Asset Form
                </label>
                <div className="grid grid-cols-2 gap-3 p-1.5 bg-neutral-100 rounded-2xl">
                  <button
                    id="select-type-good"
                    type="button"
                    onClick={() => {
                      setItemType('good');
                      setCategory(GOODS_CATEGORIES[0]);
                    }}
                    className={`min-h-[46px] p-2.5 rounded-xl flex items-center justify-center gap-2.5 text-xs font-medium transition-all cursor-pointer ${
                      itemType === 'good'
                        ? 'bg-white text-black font-bold shadow-xs border border-neutral-200'
                        : 'text-neutral-600 hover:text-black'
                    }`}
                  >
                    <Package className="w-4 h-4" />
                    <span>Physical Good / Precious Metal / Vault Asset</span>
                  </button>

                  <button
                    id="select-type-service"
                    type="button"
                    onClick={() => {
                      setItemType('service');
                      setCategory(SERVICES_CATEGORIES[0]);
                    }}
                    className={`min-h-[46px] p-2.5 rounded-xl flex items-center justify-center gap-2.5 text-xs font-medium transition-all cursor-pointer ${
                      itemType === 'service'
                        ? 'bg-white text-black font-bold shadow-xs border border-neutral-200'
                        : 'text-neutral-600 hover:text-black'
                    }`}
                  >
                    <Briefcase className="w-4 h-4" />
                    <span>Professional Service / Audit / Advisory / Capacity</span>
                  </button>
                </div>
              </div>

              {/* Title input */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Listing Title <span className="text-red-500">*</span>
                </label>
                <input
                  id="draft-title-input"
                  type="text"
                  placeholder={itemType === 'good' ? 'e.g. 1oz Fine Gold Bullion Bar (99.99% Purity)' : 'e.g. Smart Contract Security & Formal Audit'}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full min-h-[42px] px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black transition-all"
                  required
                />
              </div>

              {/* Category & Specifics Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Category
                  </label>
                  <select
                    id="draft-category-select"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                  >
                    {(itemType === 'good' ? GOODS_CATEGORIES : SERVICES_CATEGORIES).map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                {itemType === 'good' ? (
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Item Condition
                    </label>
                    <select
                      id="draft-condition-select"
                      value={condition}
                      onChange={(e) => setCondition(e.target.value as any)}
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                    >
                      <option value="Brand New">Brand New (Sealed / Uncirculated)</option>
                      <option value="Mint">Mint Condition</option>
                      <option value="Certified Rare">Certified Rare / Numismatic</option>
                      <option value="Refurbished">Refurbished</option>
                      <option value="Good">Good Condition</option>
                      <option value="Fair">Fair / Vintage</option>
                    </select>
                  </div>
                ) : (
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Turnaround / Delivery Time
                    </label>
                    <input
                      id="draft-turnaround-input"
                      type="text"
                      placeholder="e.g. 2-5 Business Days"
                      value={turnaroundTime}
                      onChange={(e) => setTurnaroundTime(e.target.value)}
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black"
                    />
                  </div>
                )}
              </div>

              {/* Quantity / Units */}
              {itemType === 'good' ? (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Available Inventory / Quantity
                    </label>
                    <input
                      id="draft-quantity-input"
                      type="number"
                      min={1}
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Unit Measure
                    </label>
                    <input
                      id="draft-unit-label-input"
                      type="text"
                      placeholder="e.g. bars, items, sets, oz, kg"
                      value={unitLabel}
                      onChange={(e) => setUnitLabel(e.target.value)}
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black"
                    />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Available Capacity / Slots
                    </label>
                    <input
                      id="draft-available-units-input"
                      type="number"
                      min={1}
                      value={availableUnits}
                      onChange={(e) => setAvailableUnits(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Billing / Unit Format
                    </label>
                    <select
                      id="draft-unit-type-select"
                      value={unitType}
                      onChange={(e) => setUnitType(e.target.value as any)}
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                    >
                      <option value="Hours">Hours</option>
                      <option value="Sessions">Sessions</option>
                      <option value="Consultations">Consultations</option>
                      <option value="Deliverables">Deliverables</option>
                      <option value="Credits">Credits</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Item Description &amp; Specifications
                </label>
                <textarea
                  id="draft-description-input"
                  rows={3}
                  placeholder="Provide comprehensive details, provenance, purity, deliverables, and guarantees..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black transition-all resize-none"
                />
              </div>

              {/* PHOTOS & VIDEOS UPLOAD SECTION */}
              <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200/90 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold text-black flex items-center gap-1.5">
                      <Film className="w-4 h-4 text-neutral-800" />
                      <span>Photos &amp; Video Media</span>
                    </span>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Upload multiple high-resolution photos and video demonstrations directly from your device.
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-1.5 self-start sm:self-auto">
                    <span className="text-[10px] bg-neutral-900 text-white px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 shadow-2xs">
                      <ImageIcon className="w-3 h-3 text-emerald-400" />
                      <span>{mediaList.filter(m => m.type === 'image').length} Photo{mediaList.filter(m => m.type === 'image').length === 1 ? '' : 's'}</span>
                    </span>
                    <span className="text-[10px] bg-indigo-600 text-white px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 shadow-2xs">
                      <Film className="w-3 h-3 text-indigo-200" />
                      <span>{mediaList.filter(m => m.type === 'video').length} Video{mediaList.filter(m => m.type === 'video').length === 1 ? '' : 's'}</span>
                    </span>
                  </div>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,video/*"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                  id="media-file-input"
                />

                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-2.5 ${
                    isDragOver
                      ? 'border-black bg-neutral-200/80 scale-[1.01]'
                      : 'border-neutral-300 bg-white hover:border-neutral-400 hover:bg-neutral-50/80'
                  }`}
                >
                  <div className="w-12 h-12 rounded-2xl bg-neutral-100 flex items-center justify-center text-neutral-800 shadow-2xs">
                    {isUploadingMedia ? (
                      <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Upload className="w-6 h-6" />
                    )}
                  </div>

                  <div className="space-y-0.5 max-w-sm">
                    <p className="text-xs font-bold text-black">
                      {isUploadingMedia
                        ? 'Processing photos & videos...'
                        : 'Drag & drop multiple photos and videos here'}
                    </p>
                    <p className="text-[11px] text-neutral-500">
                      or <span className="font-semibold text-black underline">browse local files</span> (supports JPG, PNG, WEBP, GIF, MP4, WEBM, MOV)
                    </p>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        fileInputRef.current?.click();
                      }}
                      className="min-h-[34px] px-4 py-1.5 rounded-xl bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Select Photos &amp; Videos</span>
                    </button>
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="text-[11px] text-neutral-600 hover:text-black font-medium flex items-center gap-1 cursor-pointer"
                  >
                    <span>{showUrlInput ? '− Hide external URL input' : '+ Or import from web link (Optional URL)'}</span>
                  </button>

                  {showUrlInput && (
                    <div className="flex items-center gap-2 mt-2 p-2 bg-white rounded-xl border border-neutral-200">
                      <select
                        value={mediaTypeInput}
                        onChange={(e) => setMediaTypeInput(e.target.value as any)}
                        className="min-h-[36px] px-2.5 py-1 rounded-lg border border-neutral-200 bg-neutral-50 text-xs text-black cursor-pointer shrink-0"
                      >
                        <option value="image">Photo Link</option>
                        <option value="video">Video Link</option>
                      </select>
                      <input
                        type="url"
                        placeholder="https://... (.jpg, .png, .mp4, web video)"
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        className="flex-1 min-h-[36px] px-3 py-1 rounded-lg border border-neutral-200 bg-neutral-50 text-xs text-black font-mono text-[11px] focus:bg-white focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleAddMediaUrl}
                        className="min-h-[36px] px-4 py-1 rounded-lg bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
                      >
                        Add
                      </button>
                    </div>
                  )}
                </div>

                {mediaList.length > 0 ? (
                  <div className="space-y-2 pt-2 border-t border-neutral-200/80">
                    <div className="flex items-center justify-between text-xs text-neutral-600 font-medium">
                      <span>Attached Media ({mediaList.length})</span>
                      <span className="text-[11px] text-neutral-400">First item is used as primary cover</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {mediaList.map((media, idx) => (
                        <div
                          key={media.id}
                          className={`relative rounded-2xl overflow-hidden border-2 bg-neutral-900 group shadow-xs ${
                            idx === 0 ? 'border-black ring-2 ring-black/20' : 'border-neutral-200 hover:border-neutral-400'
                          }`}
                        >
                          <div className="aspect-[16/10] w-full flex items-center justify-center bg-black/95">
                            {media.type === 'video' ? (
                              <video
                                src={media.url}
                                controls
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <img
                                src={media.url}
                                alt={media.name || `Media ${idx + 1}`}
                                className="w-full h-full object-cover"
                              />
                            )}
                          </div>

                          <div className="absolute top-1.5 left-1.5 flex items-center gap-1 pointer-events-none">
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded text-white shadow-2xs ${
                              media.type === 'video' ? 'bg-indigo-600' : 'bg-neutral-800'
                            }`}>
                              {media.type === 'video' ? 'VIDEO' : 'PHOTO'}
                            </span>
                            {idx === 0 && (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-600 text-white shadow-2xs">
                                COVER
                              </span>
                            )}
                          </div>

                          <div className="absolute bottom-1.5 left-1.5 right-1.5 flex items-center justify-between gap-1 opacity-90 group-hover:opacity-100 transition-opacity">
                            {idx !== 0 ? (
                              <button
                                type="button"
                                onClick={() => handleSetPrimaryMedia(idx)}
                                className="px-2 py-0.5 rounded-md bg-black/80 hover:bg-black text-white text-[10px] font-medium cursor-pointer transition-colors"
                                title="Set as primary cover"
                              >
                                Make Cover
                              </button>
                            ) : (
                              <span className="text-[9px] text-white/80 pl-1 font-medium">Primary</span>
                            )}
                            <button
                              type="button"
                              onClick={() => handleRemoveMedia(media.id)}
                              className="p-1 rounded-md bg-red-600/90 hover:bg-red-700 text-white cursor-pointer transition-colors"
                              title="Delete media"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-neutral-100/70 border border-neutral-200 text-center text-xs text-neutral-500">
                    No photos or videos attached yet. You can upload multiple files or publish with standard asset visuals.
                  </div>
                )}
              </div>

              {/* Tags */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Search &amp; Catalog Tags ({tags.length})
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Add tag and press Enter (e.g. gold, bullion, audit, hardware)..."
                    value={customTagInput}
                    onChange={(e) => setCustomTagInput(e.target.value)}
                    onKeyDown={handleAddTag}
                    className="flex-1 min-h-[38px] px-3 py-1.5 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black"
                  />
                  <button
                    type="button"
                    onClick={handleAddTag}
                    className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-neutral-200 hover:bg-neutral-300 text-xs font-medium text-black cursor-pointer transition-colors"
                  >
                    Add Tag
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 mt-2">
                  {tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 bg-neutral-100 text-neutral-800 rounded-lg text-xs font-medium flex items-center gap-1.5"
                    >
                      #{tag}
                      <button
                        type="button"
                        onClick={() => handleRemoveTag(tag)}
                        className="text-neutral-400 hover:text-black cursor-pointer"
                      >
                        &times;
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* ================= LISTING AUDIENCE & PRIVACY ================= */}
              <div className="pt-2 border-t border-neutral-200/80 space-y-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-900">
                    Listing Audience &amp; Privacy (Who Can See This?)
                  </label>
                  <p className="text-[11px] text-neutral-500">
                    Choose whether this allocation is open to the entire world, restricted to confirmed friends, shared only with a specific friend group, or kept private to you.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Public */}
                  <label
                    onClick={() => setVisibility('public')}
                    className={`flex items-start gap-2.5 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                      visibility === 'public'
                        ? 'border-neutral-950 bg-neutral-50 shadow-2xs'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 mt-0.5 shrink-0 border border-emerald-200">
                      <Globe className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-neutral-900">Public (The World)</span>
                        <input
                          type="radio"
                          name="draft-visibility"
                          checked={visibility === 'public'}
                          onChange={() => setVisibility('public')}
                          className="accent-black"
                        />
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-0.5">
                        Visible to everyone across the global marketplace and explore feeds.
                      </p>
                    </div>
                  </label>

                  {/* Friends Only */}
                  <label
                    onClick={() => setVisibility('friends')}
                    className={`flex items-start gap-2.5 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                      visibility === 'friends'
                        ? 'border-neutral-950 bg-neutral-50 shadow-2xs'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="p-1.5 rounded-lg bg-blue-50 text-blue-700 mt-0.5 shrink-0 border border-blue-200">
                      <Users className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-neutral-900">Friends Only</span>
                        <input
                          type="radio"
                          name="draft-visibility"
                          checked={visibility === 'friends'}
                          onChange={() => setVisibility('friends')}
                          className="accent-black"
                        />
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-0.5">
                        Only confirmed mutual friends in your network can view and trade.
                      </p>
                    </div>
                  </label>

                  {/* Custom Friend Group */}
                  <label
                    onClick={() => setVisibility('custom_group')}
                    className={`flex items-start gap-2.5 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                      visibility === 'custom_group'
                        ? 'border-neutral-950 bg-neutral-50 shadow-2xs'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="p-1.5 rounded-lg bg-amber-50 text-amber-800 mt-0.5 shrink-0 border border-amber-200">
                      <Shield className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-neutral-900">Specific Friend Group</span>
                        <input
                          type="radio"
                          name="draft-visibility"
                          checked={visibility === 'custom_group'}
                          onChange={() => setVisibility('custom_group')}
                          className="accent-black"
                        />
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-0.5">
                        Shared exclusively with members of your selected custom circle(s).
                      </p>
                    </div>
                  </label>

                  {/* Only Me */}
                  <label
                    onClick={() => setVisibility('only_me')}
                    className={`flex items-start gap-2.5 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                      visibility === 'only_me'
                        ? 'border-neutral-950 bg-neutral-50 shadow-2xs'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="p-1.5 rounded-lg bg-neutral-100 text-neutral-700 mt-0.5 shrink-0 border border-neutral-200">
                      <Lock className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-neutral-900">Only Me (Private)</span>
                        <input
                          type="radio"
                          name="draft-visibility"
                          checked={visibility === 'only_me'}
                          onChange={() => setVisibility('only_me')}
                          className="accent-black"
                        />
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-0.5">
                        Private vault asset visible only in your own personal allocations.
                      </p>
                    </div>
                  </label>
                </div>

                {/* Sub-group list if custom_group is selected */}
                {visibility === 'custom_group' && (
                  <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-2">
                    <span className="text-[11px] font-bold text-neutral-800 uppercase tracking-wider block">
                      Select Allowed Friend Groups:
                    </span>
                    {friendGroups.length === 0 ? (
                      <p className="text-xs text-neutral-500">
                        No custom friend groups yet. You can create groups anytime from your Profile.
                      </p>
                    ) : (
                      <div className="space-y-1.5 max-h-32 overflow-y-auto">
                        {friendGroups.map((group) => {
                          const isSelected = allowedGroupIds.includes(group.id);
                          return (
                            <div
                              key={group.id}
                              onClick={() => {
                                setAllowedGroupIds(prev => 
                                  prev.includes(group.id) ? prev.filter(id => id !== group.id) : [...prev, group.id]
                                );
                              }}
                              className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                                isSelected
                                  ? 'bg-amber-500/10 border-amber-400 font-semibold text-neutral-950'
                                  : 'bg-white border-neutral-200 text-neutral-700 hover:border-neutral-300'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <div
                                  className="w-2.5 h-2.5 rounded-full shrink-0"
                                  style={{ backgroundColor: group.color || '#f59e0b' }}
                                />
                                <span>{group.name}</span>
                                <span className="text-[10px] text-neutral-400 font-mono">
                                  ({group.memberUids.length} friends)
                                </span>
                              </div>
                              {isSelected ? (
                                <CheckSquare className="w-4 h-4 text-amber-600" />
                              ) : (
                                <Square className="w-4 h-4 text-neutral-300" />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="pt-3 flex justify-end">
                <button
                  type="button"
                  onClick={() => setActiveTab('settlement')}
                  className="min-h-[44px] px-6 py-2.5 rounded-xl bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-all flex items-center gap-2 cursor-pointer shadow-xs"
                >
                  <span>Next: Configure Cross-Transactional Earnings</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}          {/* ================= TAB 2: MULTI-SETTLEMENT PRICING ================= */}
          {activeTab === 'settlement' && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <div className="font-bold text-black text-sm flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Accepted Settlement Modalities ({acceptedSettlements.length} Selected)</span>
                  </div>
                </div>
                <p className="text-neutral-600 text-[11px] mt-0.5">
                  Check the settlement modalities you accept. When checked, its pricing or trade options will open directly below.
                </p>
              </div>

              {/* VERTICAL ACCORDION / STACK FORMAT */}
              <div className="space-y-3">
                {/* 1. BARTER TRADE */}
                <div className={`rounded-2xl border transition-all overflow-hidden ${
                  acceptedSettlements.includes('barter')
                    ? 'border-emerald-500/40 bg-emerald-50/20 shadow-xs'
                    : 'border-neutral-200 bg-white hover:border-neutral-300'
                }`}>
                  <button
                    type="button"
                    onClick={() => handleToggleSettlement('barter')}
                    className="w-full p-3.5 flex items-center justify-between text-left cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        acceptedSettlements.includes('barter') ? 'bg-emerald-500 text-white' : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        <Repeat className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-black flex items-center gap-2">
                          <span>1. Barter Trade</span>
                          {acceptedSettlements.includes('barter') && (
                            <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.2 rounded-full font-semibold">
                              Active
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-500">Physical Goods, Commodities, Real Estate &amp; Services</div>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${
                      acceptedSettlements.includes('barter')
                        ? 'bg-neutral-900 text-white'
                        : 'border border-neutral-300 bg-neutral-50 text-transparent'
                    }`}>
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  {acceptedSettlements.includes('barter') && (
                    <div className="px-4 pb-4 pt-2 border-t border-emerald-500/20 space-y-3 bg-white">
                      <div>
                        <label className="block text-xs font-semibold text-neutral-700 mb-1">
                          {listingIntent === 'sell' ? 'What physical assets or services would you accept in trade?' : 'What physical assets or services can you offer in trade?'}
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. 100oz Gold Bullion, High-End Luxury Watches, Server GPU Compute, Real Estate Deeds..."
                          value={barterDesired}
                          onChange={(e) => setBarterDesired(e.target.value)}
                          className="w-full min-h-[40px] px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Estimated Trade Value (USD Equivalent)
                          </label>
                          <div className="relative">
                            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 text-xs font-bold">$</span>
                            <input
                              type="number"
                              min={1}
                              value={barterEstimatedUSD}
                              onChange={(e) => setBarterEstimatedUSD(Math.max(1, parseFloat(e.target.value) || 1))}
                              className="w-full min-h-[40px] pl-8 pr-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black font-mono focus:outline-none focus:bg-white focus:border-black"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Accept Exchange Type
                          </label>
                          <select
                            value={barterExchangeType}
                            onChange={(e) => setBarterExchangeType(e.target.value as any)}
                            className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                          >
                            <option value="any">Any (Physical Goods or Services)</option>
                            <option value="good">Physical Goods / Precious Metals Only</option>
                            <option value="service">Professional Services Only</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 2. FINAL COINS (AFNL) */}
                <div className={`rounded-2xl border transition-all overflow-hidden ${
                  acceptedSettlements.includes('final_coins')
                    ? 'border-amber-500/40 bg-amber-50/20 shadow-xs'
                    : 'border-neutral-200 bg-white hover:border-neutral-300'
                }`}>
                  <button
                    type="button"
                    onClick={() => handleToggleSettlement('final_coins')}
                    className="w-full p-3.5 flex items-center justify-between text-left cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        acceptedSettlements.includes('final_coins') ? 'bg-amber-500 text-black' : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-black flex items-center gap-2">
                          <span>2. Final Coins (AFNL)</span>
                          {acceptedSettlements.includes('final_coins') && (
                            <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.2 rounded-full font-semibold">
                              Active
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-500">Platform Native Settlement Unit (Benchmarked at $20 / AFNL)</div>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${
                      acceptedSettlements.includes('final_coins')
                        ? 'bg-neutral-900 text-white'
                        : 'border border-neutral-300 bg-neutral-50 text-transparent'
                    }`}>
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  {acceptedSettlements.includes('final_coins') && (
                    <div className="px-4 pb-4 pt-2 border-t border-amber-500/20 space-y-3 bg-white">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Amount in AFNL Coins
                          </label>
                          <div className="relative">
                            <input
                              type="number"
                              min={1}
                              value={finalCoinAmount}
                              onChange={(e) => setFinalCoinAmount(Math.max(1, parseFloat(e.target.value) || 1))}
                              className="w-full min-h-[40px] px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black font-mono focus:outline-none focus:bg-white focus:border-black"
                            />
                            <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 text-xs font-bold">AFNL</span>
                          </div>
                        </div>
                        <div className="flex flex-col justify-center">
                          <span className="text-xs text-neutral-700 font-medium">
                            Estimated USD Value: <strong className="font-mono text-black">${(finalCoinAmount * 20).toLocaleString()} USD</strong>
                          </span>
                          <span className="text-[11px] text-neutral-500">
                            Based on platform native benchmark ($20 / AFNL)
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 3. STABLECOINS */}
                <div className={`rounded-2xl border transition-all overflow-hidden ${
                  acceptedSettlements.includes('stable_coins')
                    ? 'border-blue-500/40 bg-blue-50/20 shadow-xs'
                    : 'border-neutral-200 bg-white hover:border-neutral-300'
                }`}>
                  <button
                    type="button"
                    onClick={() => handleToggleSettlement('stable_coins')}
                    className="w-full p-3.5 flex items-center justify-between text-left cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        acceptedSettlements.includes('stable_coins') ? 'bg-blue-500 text-white' : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-black flex items-center gap-2">
                          <span>3. Stablecoins</span>
                          {acceptedSettlements.includes('stable_coins') && (
                            <span className="text-[10px] bg-blue-100 text-blue-800 px-2 py-0.2 rounded-full font-semibold">
                              Active
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-500">USD Coin (USDC) &amp; Tether (USDT) on instant settlement rails</div>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${
                      acceptedSettlements.includes('stable_coins')
                        ? 'bg-neutral-900 text-white'
                        : 'border border-neutral-300 bg-neutral-50 text-transparent'
                    }`}>
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  {acceptedSettlements.includes('stable_coins') && (
                    <div className="px-4 pb-4 pt-2 border-t border-blue-500/20 space-y-3 bg-white">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Default Stablecoin Asset
                          </label>
                          <select
                            value={stableCoinSymbol}
                            onChange={(e) => setStableCoinSymbol(e.target.value)}
                            className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                          >
                            <option value="USDC">USDC (USD Coin)</option>
                            <option value="USDT">USDT (Tether)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Amount ({stableCoinSymbol})
                          </label>
                          <div className="relative">
                            <input
                              type="number"
                              min={1}
                              value={stableCoinAmount}
                              onChange={(e) => setStableCoinAmount(Math.max(1, parseFloat(e.target.value) || 1))}
                              className="w-full min-h-[40px] px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black font-mono focus:outline-none focus:bg-white focus:border-black"
                            />
                            <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 text-xs font-bold">$</span>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Settlement Network / Chain
                          </label>
                          <select
                            value={stableCoinNetwork}
                            onChange={(e) => setStableCoinNetwork(e.target.value)}
                            className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                          >
                            <option value="Polygon">Polygon (Zero Gas)</option>
                            <option value="Ethereum">Ethereum Mainnet</option>
                            <option value="Arbitrum">Arbitrum One</option>
                            <option value="Solana">Solana</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 4. FIAT CURRENCY */}
                <div className={`rounded-2xl border transition-all overflow-hidden ${
                  acceptedSettlements.includes('fiat')
                    ? 'border-purple-500/40 bg-purple-50/20 shadow-xs'
                    : 'border-neutral-200 bg-white hover:border-neutral-300'
                }`}>
                  <button
                    type="button"
                    onClick={() => handleToggleSettlement('fiat')}
                    className="w-full p-3.5 flex items-center justify-between text-left cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        acceptedSettlements.includes('fiat') ? 'bg-purple-600 text-white' : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-black flex items-center gap-2">
                          <span>4. Fiat Currency</span>
                          {acceptedSettlements.includes('fiat') && (
                            <span className="text-[10px] bg-purple-100 text-purple-800 px-2 py-0.2 rounded-full font-semibold">
                              Active
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-500">Traditional Bank Wire, Escrow &amp; Card (USD, EUR, GBP, CHF)</div>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${
                      acceptedSettlements.includes('fiat')
                        ? 'bg-neutral-900 text-white'
                        : 'border border-neutral-300 bg-neutral-50 text-transparent'
                    }`}>
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  {acceptedSettlements.includes('fiat') && (
                    <div className="px-4 pb-4 pt-2 border-t border-purple-500/20 space-y-3 bg-white">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Primary Fiat Unit
                          </label>
                          <select
                            value={fiatCurrencyCode}
                            onChange={(e) => setFiatCurrencyCode(e.target.value)}
                            className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                          >
                            <option value="USD">USD ($ - US Dollar)</option>
                            <option value="EUR">EUR (€ - Euro)</option>
                            <option value="GBP">GBP (£ - British Pound)</option>
                            <option value="CHF">CHF (Swiss Franc)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Amount ({fiatCurrencyCode})
                          </label>
                          <input
                            type="number"
                            min={1}
                            value={fiatAmount}
                            onChange={(e) => setFiatAmount(Math.max(1, parseFloat(e.target.value) || 1))}
                            className="w-full min-h-[40px] px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black font-mono focus:outline-none focus:bg-white focus:border-black"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 5. CRYPTO */}
                <div className={`rounded-2xl border transition-all overflow-hidden ${
                  acceptedSettlements.includes('crypto')
                    ? 'border-orange-500/40 bg-orange-50/20 shadow-xs'
                    : 'border-neutral-200 bg-white hover:border-neutral-300'
                }`}>
                  <button
                    type="button"
                    onClick={() => handleToggleSettlement('crypto')}
                    className="w-full p-3.5 flex items-center justify-between text-left cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        acceptedSettlements.includes('crypto') ? 'bg-orange-500 text-white' : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        <Coins className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-black flex items-center gap-2">
                          <span>5. Cryptocurrency</span>
                          {acceptedSettlements.includes('crypto') && (
                            <span className="text-[10px] bg-orange-100 text-orange-800 px-2 py-0.2 rounded-full font-semibold">
                              Active
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-neutral-500">Native Layer 1 Assets (Bitcoin, Ethereum, Solana)</div>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all ${
                      acceptedSettlements.includes('crypto')
                        ? 'bg-neutral-900 text-white'
                        : 'border border-neutral-300 bg-neutral-50 text-transparent'
                    }`}>
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  {acceptedSettlements.includes('crypto') && (
                    <div className="px-4 pb-4 pt-2 border-t border-orange-500/20 space-y-3 bg-white">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Primary Crypto Asset
                          </label>
                          <select
                            value={cryptoSymbol}
                            onChange={(e) => setCryptoSymbol(e.target.value)}
                            className="w-full min-h-[40px] px-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black cursor-pointer"
                          >
                            <option value="ETH">ETH (Ethereum)</option>
                            <option value="BTC">BTC (Bitcoin)</option>
                            <option value="SOL">SOL (Solana)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Amount ({cryptoSymbol})
                          </label>
                          <input
                            type="number"
                            step="0.0001"
                            min={0.0001}
                            value={cryptoAmount}
                            onChange={(e) => setCryptoAmount(Math.max(0.0001, parseFloat(e.target.value) || 0.0001))}
                            className="w-full min-h-[40px] px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black font-mono focus:outline-none focus:border-black"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-700 mb-1">
                            Network
                          </label>
                          <input
                            type="text"
                            value={cryptoNetwork}
                            onChange={(e) => setCryptoNetwork(e.target.value)}
                            className="w-full min-h-[40px] px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50/50 text-xs text-black focus:outline-none focus:bg-white focus:border-black"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* CROSS-TRANSACTIONAL SPLIT TOGGLE */}
              <div className="p-4 rounded-2xl bg-neutral-900 text-white space-y-3 shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shuffle className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold">Cross-Transactional &amp; Split Settlement Terms</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={acceptSplitSettlements}
                      onChange={(e) => setAcceptSplitSettlements(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-neutral-700 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setActiveTab('details')}
                  className="min-h-[42px] px-5 py-2 rounded-xl border border-neutral-200 bg-white text-neutral-700 text-xs font-semibold hover:border-black hover:text-black transition-all cursor-pointer"
                >
                  &larr; Back to Details
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('preview')}
                  className="min-h-[44px] px-6 py-2.5 rounded-xl bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-all flex items-center gap-2 cursor-pointer shadow-xs"
                >
                  <span>Next: Review &amp; Preview</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* ================= TAB 3: LIVE PREVIEW ================= */}
          {activeTab === 'preview' && (
            <div className="space-y-5">
              <div className="p-3.5 rounded-2xl bg-neutral-100/80 text-xs text-neutral-600 flex items-center justify-between">
                <span>Review your cross-transactional listing before publishing:</span>
                <span className="font-semibold text-black">{mediaList.length} media item(s)</span>
              </div>

              <div className="border border-neutral-200 rounded-3xl overflow-hidden bg-white shadow-sm max-w-2xl mx-auto">
                <div className="aspect-video w-full bg-neutral-900 relative overflow-hidden flex items-center justify-center">
                  {mediaList.length > 0 ? (
                    mediaList[0].type === 'video' ? (
                      <video src={mediaList[0].url} controls className="w-full h-full object-cover" />
                    ) : (
                      <img src={mediaList[0].url} alt="" className="w-full h-full object-cover" />
                    )
                  ) : (
                    <div className="text-neutral-500 text-xs flex flex-col items-center gap-2">
                      <ImageIcon className="w-8 h-8 opacity-40" />
                      <span>No media uploaded yet</span>
                    </div>
                  )}

                  {/* Intent Badge overlay */}
                  <div className="absolute top-3 left-3 flex items-center gap-2">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider shadow-sm ${
                      listingIntent === 'sell'
                        ? 'bg-emerald-500 text-black'
                        : 'bg-blue-600 text-white'
                    }`}>
                      {listingIntent === 'sell' ? 'Offering to Sell' : 'Wanted / RFP'}
                    </span>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-black/80 text-white backdrop-blur-xs">
                      {itemType === 'good' ? 'Physical Asset' : 'Service'}
                    </span>
                  </div>

                  <div className="absolute top-3 right-3">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-400 text-black shadow-xs uppercase">
                      Primary: {primaryTradeMode === 'barter' ? 'Barter Swap' : primaryCurrency}
                    </span>
                  </div>
                </div>

                <div className="p-5 space-y-4">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-neutral-400 font-semibold uppercase">{category}</span>
                      <span className="text-xs font-mono font-bold text-neutral-900">
                        {primaryTradeMode === 'barter'
                          ? `~$${barterEstimatedUSD.toLocaleString()} USD Est.`
                          : `${primaryCurrency === 'USD' ? '$' : ''}${
                              primaryCurrency === 'AFNL'
                                ? `${finalCoinAmount} AFNL`
                                : primaryCurrency === 'USDC' || primaryCurrency === 'USDT'
                                ? `${stableCoinAmount} ${primaryCurrency}`
                                : primaryCurrency === 'BTC' || primaryCurrency === 'ETH' || primaryCurrency === 'SOL'
                                ? `${cryptoAmount} ${cryptoSymbol}`
                                : `${fiatAmount.toLocaleString()} ${fiatCurrencyCode}`
                            }`}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-black mt-0.5">{title || 'Untitled Listing'}</h3>
                    <p className="text-xs text-neutral-600 mt-1 leading-relaxed">{description || 'No description provided.'}</p>
                  </div>

                  {/* Accepted Currencies & Barter Summary */}
                  <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-black">
                      <span>Accepted Currencies &amp; Modalities:</span>
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                        {acceptedCurrencyList.length} Currencies {acceptedSettlements.includes('barter') && '+ Barter'}
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {acceptedCurrencyList.map(curr => (
                        <span key={curr} className="px-2 py-0.5 rounded-md bg-neutral-200 text-neutral-800 text-[10px] font-mono font-bold">
                          {curr}
                        </span>
                      ))}
                      {acceptedSettlements.includes('barter') && (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                          ⇄ Barter Trade
                        </span>
                      )}
                    </div>

                    {acceptedSettlements.includes('barter') && barterDesired && (
                      <div className="pt-2 border-t border-neutral-200 text-[11px] text-neutral-700">
                        <span className="font-semibold text-black">Desired Barter: </span>
                        <span>{barterDesired}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* MODAL FOOTER */}
        <div className="px-5 sm:px-6 py-4 border-t border-neutral-100 bg-neutral-50 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-neutral-500 text-center sm:text-left">
            <span>You can save as a <strong>Draft</strong> anytime or publish directly to the <strong>Live Marketplace</strong>.</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              id="save-draft-btn"
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSubmit('draft')}
              className="flex-1 sm:flex-none min-h-[44px] px-5 py-2.5 rounded-xl border border-neutral-300 bg-white text-neutral-800 text-xs font-semibold hover:border-black hover:bg-neutral-100 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4 text-neutral-600" />
              <span>Save as Draft</span>
            </button>

            <button
              id="upload-to-marketplace-btn"
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSubmit('uploaded')}
              className="flex-1 sm:flex-none min-h-[44px] px-7 py-2.5 rounded-xl bg-black text-white text-xs font-bold hover:bg-neutral-800 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-98"
            >
              <Upload className="w-4 h-4 text-white" />
              <span>{isSubmitting ? 'Uploading...' : 'Upload to Marketplace'}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
