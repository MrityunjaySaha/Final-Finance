import React from 'react';
import { StockItem, StockOrder, StockPosition, StockMarketWay } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { StockFundamentals } from './StockFundamentals';
import { StockOrderDesk } from './StockOrderDesk';
import { StockNewsFeed } from './StockNewsFeed';
import { SocialTradesFeed } from './SocialTradesFeed';
import { AlpacaOptionsChain } from './AlpacaOptionsChain';
import { BREAKING_STOCK_NEWS } from '../../data/stocksData';
import { formatStockPrice, formatStockMarketCap, formatStockAmount, getUSDEquivalentString } from '../../utils/stockCurrencyFormatter';
import { 
  ArrowLeft, 
  ChevronRight, 
  Star, 
  Zap, 
  Users,
  CheckCircle2, 
  TrendingUp, 
  TrendingDown, 
  ShieldCheck, 
  BarChart3, 
  Building2, 
  Coins, 
  Globe 
} from 'lucide-react';

interface StockDetailPageProps {
  stock: StockItem;
  stocks: StockItem[];
  watchlist: string[];
  positions: StockPosition[];
  currentUser: AuthSession | null;
  selectedMarketWay: StockMarketWay | 'all' | 'social';
  activeMarketTitle?: string;
  onBackToMarkets: () => void;
  onSelectStock: (stock: StockItem) => void;
  onToggleWatchlist: (ticker: string) => void;
  onOpenQuickTrade: (stock: StockItem, side: 'buy' | 'sell') => void;
  onOpenAuthModal: () => void;
  onOrderExecuted: (order: StockOrder) => void;
}

export const StockDetailPage: React.FC<StockDetailPageProps> = ({
  stock,
  stocks,
  watchlist,
  positions,
  currentUser,
  selectedMarketWay,
  activeMarketTitle,
  onBackToMarkets,
  onSelectStock,
  onToggleWatchlist,
  onOpenQuickTrade,
  onOpenAuthModal,
  onOrderExecuted,
}) => {
  const [selectedOption, setSelectedOption] = React.useState<{
    type: 'call' | 'put';
    strike: number;
    expiry: string;
    symbol: string;
  } | null>(null);

  const getMarketBadgeUI = (marketType?: StockMarketWay) => {
    switch (marketType) {
      case 'final':
        return { label: 'Final Stock', coin: 'AFNL', bg: 'bg-amber-100 text-amber-900 border-amber-300', icon: Zap };
      case 'stable':
        return { label: 'Stable Stock', coin: '$USDC', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300', icon: ShieldCheck };
      case 'fiat':
        return { label: 'Fiat Stock', coin: '$USD', bg: 'bg-indigo-100 text-indigo-900 border-indigo-300', icon: Building2 };
      case 'crypto':
        return { label: 'Crypto Stock', coin: '$BTC', bg: 'bg-purple-100 text-purple-900 border-purple-300', icon: Coins };
      case 'global':
        return { label: 'Global Asset', coin: 'Alpaca', bg: 'bg-sky-100 text-sky-900 border-sky-300', icon: Globe };
      default:
        return { label: 'Unified Equity', coin: 'Multi', bg: 'bg-slate-100 text-slate-800 border-slate-200', icon: Globe };
    }
  };

  const badge = getMarketBadgeUI(stock.marketType);
  const isPos = stock.changeUSD >= 0;
  const isOwned = positions.some((p) => p.ticker.toUpperCase() === stock.ticker.toUpperCase());
  const userPosition = positions.find((p) => p.ticker.toUpperCase() === stock.ticker.toUpperCase());
  const isFollowed = watchlist.some((t) => t.toUpperCase() === stock.ticker.toUpperCase());

  const relatedStocks = stocks
    .filter((item) => item.ticker !== stock.ticker && item.marketType === stock.marketType)
    .slice(0, 3);

  const relatedNews = BREAKING_STOCK_NEWS.filter(
    (item) => item.tickers?.includes(stock.ticker)
  ).slice(0, 4);

  return (
    <div className="space-y-6 text-left">
      {/* 1. Back to Directory & Quick Action Bar */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={onBackToMarkets}
            className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to {selectedMarketWay === 'all' ? 'All Equities' : activeMarketTitle || 'Stock Markets'}</span>
          </button>

          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <ChevronRight className="w-3 h-3 text-slate-300" />
            <span className="text-slate-600 font-medium">{badge.label}</span>
            <ChevronRight className="w-3 h-3 text-slate-300" />
            <span className="text-slate-900 font-mono font-bold">${stock.ticker}</span>
          </div>
        </div>

        {/* Right Header Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => onToggleWatchlist(stock.ticker)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              isFollowed
                ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-2xs'
                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <Star className={`w-3.5 h-3.5 ${isFollowed ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`} />
            <span>{isFollowed ? 'Favorited' : 'Add to Favorites'}</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenQuickTrade(stock, 'buy')}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-sm"
          >
            <Zap className="w-3.5 h-3.5 text-white" />
            <span>Quick Buy</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenQuickTrade(stock, 'sell')}
            className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
          >
            Quick Sell
          </button>

          <button
            type="button"
            onClick={() => {
              const el = document.getElementById('options-chain-section');
              if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }}
            className="px-3.5 py-1.5 rounded-xl bg-sky-100 hover:bg-sky-200 text-sky-800 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Trade Options
          </button>
        </div>
      </div>

      {/* 2. Stock Hero Overview Card */}
      <div className="p-5 sm:p-7 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-5 border-b border-slate-100">
          <div className="flex items-start gap-4 sm:gap-5 flex-1">
            <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-slate-50 text-slate-800 flex items-center justify-center font-mono font-bold text-sm sm:text-xl shadow-sm shrink-0 border border-slate-200">
              {stock.ticker.slice(0, 4)}
            </div>
            <div className="flex-1">
              <h1 className="text-xl sm:text-2xl font-mono font-extrabold text-slate-900 tracking-tight leading-none mb-1.5">
                ${stock.ticker}
              </h1>
              <h2 className="text-sm sm:text-lg font-serif font-bold text-slate-700 tracking-tight leading-tight">
                {stock.name}
              </h2>
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="text-[10px] sm:text-xs font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold border border-slate-200 whitespace-nowrap">
                  {stock.exchange}
                </span>
                <span className="text-[10px] sm:text-xs font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold border border-slate-200 whitespace-nowrap">
                  {stock.sector}
                </span>
                <span className={`text-[10px] sm:text-xs font-mono font-bold px-2 py-0.5 rounded-full border whitespace-nowrap ${badge.bg}`}>
                  {badge.label}
                </span>
              </div>
              <div className="flex items-center gap-2 flex-wrap mt-1.5 text-xs text-slate-500">
                {stock.subSector && (
                  <>
                    <span>{stock.subSector}</span>
                    <span className="text-slate-300">•</span>
                  </>
                )}
                <span>{stock.settlementMethod || 'Direct Vault Clearing'}</span>
              </div>
              {isOwned && (
                <div className="mt-2.5 inline-flex items-center gap-1.5 text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Holdings: {userPosition?.shares} Shares</span>
                </div>
              )}
            </div>
          </div>

          {/* Big Real-Time Price & Pulse */}
          <div className="flex items-center gap-4 self-start lg:self-auto shrink-0 pl-14 sm:pl-0">
            <div className="text-left lg:text-right">
              <div className="flex items-center gap-2 lg:justify-end">
                <span className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                <span className="font-mono font-bold text-2xl sm:text-3xl text-slate-900 tracking-tight">
                  {formatStockPrice(stock.price, stock, false)}
                </span>
              </div>
              {getUSDEquivalentString(stock.price, stock) && (
                <span className="font-mono text-xs text-slate-500 block lg:text-right mt-0.5">
                  {getUSDEquivalentString(stock.price, stock)}
                </span>
              )}
              <div className={`text-xs sm:text-sm font-mono font-bold flex items-center gap-1 lg:justify-end mt-1 ${
                isPos ? 'text-emerald-600' : 'text-rose-600'
              }`}>
                {isPos ? <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <TrendingDown className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                <span>
                  {isPos ? '+' : ''}{formatStockAmount(stock.changeUSD, stock, false)} ({isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%)
                </span>
                <span className="text-slate-400 font-normal text-[10px] sm:text-[11px] ml-1">Today</span>
              </div>
            </div>
          </div>
        </div>

        {/* Key Intraday Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 pt-1">
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Market Cap</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{formatStockMarketCap(stock)}</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">24h Volume</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.volume || stock.avgVolume || 'N/A'}</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Day Range</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">
              {formatStockPrice(stock.low24h ?? (stock.price * 0.98), stock, false)} - {formatStockPrice(stock.high24h ?? (stock.price * 1.02), stock, false)}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">52W Range</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">
              {formatStockPrice(stock.fiftyTwoWeekLow ?? (stock.price * 0.75), stock, false)} - {formatStockPrice(stock.fiftyTwoWeekHigh ?? (stock.price * 1.25), stock, false)}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">P/E Ratio</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.peRatio ? `${stock.peRatio}x` : '28.4x'}</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Div Yield</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.dividendYield || '0.50%'}</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Beta</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.beta ? stock.beta.toFixed(2) : '1.15'}</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Analyst Target</span>
            <span className="font-mono font-bold text-xs text-emerald-600 block mt-0.5">
              {formatStockPrice(stock.analystTargetUSD || stock.price * 1.15, stock)}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Main 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: Fundamentals, Profile, News */}
        <div className="lg:col-span-7 space-y-6">
          {/* Fundamentals */}
          <StockFundamentals stock={stock} />

          {/* Alpaca Options Chain Integration */}
          {(stock.marketType === 'global' || stock.marketType === 'fiat') && (
            <div id="options-chain-section" className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4 scroll-mt-6">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h2 className="font-serif font-bold text-base sm:text-lg text-slate-900 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-sky-600" />
                  <span>Options Chain</span>
                </h2>
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-tight">
                  <Globe className="w-3 h-3" />
                  Live Alpaca Data
                </div>
              </div>
              <AlpacaOptionsChain 
                symbol={stock.ticker} 
                onSelectContract={(c, settlementTime) => {
                  const formattedExp = new Date(c.expiration_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' });
                  setSelectedOption({
                    type: c.type,
                    strike: c.strike_price,
                    expiry: `Exp: ${formattedExp} @ ${settlementTime} ET`,
                    symbol: c.symbol
                  });
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </div>
          )}

          {/* About & Profile */}
          <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
            <h2 className="font-serif font-bold text-base sm:text-lg text-slate-900 flex items-center gap-2 pb-3 border-b border-slate-100">
              <Building2 className="w-4 h-4 text-slate-700" />
              <span>About {stock.name} (${stock.ticker})</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {stock.description || `${stock.name} is a premier publicly listed enterprise within the ${stock.sector} sector, actively traded across institutional sovereign liquidity venues and settled via ${badge.label} clearing rails.`}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Exchange Venue</span>
                <span className="font-mono font-bold text-slate-800 mt-0.5 block">{stock.exchange}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Custody Vault Node</span>
                <span className="font-mono font-bold text-slate-800 mt-0.5 block truncate">
                  {(stock as any).custodyVaultNode || '0xFNL-NODE-7729'}
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Settlement Speed</span>
                <span className="font-mono font-bold text-emerald-700 mt-0.5 block">Instant T+0 Finality</span>
              </div>
            </div>
          </div>

          {/* Related News */}
          <div className="space-y-6">
            {/* Social Trades & Sentiment */}
            <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-base text-slate-900">Social Sentiment & Activity</h3>
                    <p className="text-xs text-slate-500">Real-time trades by friends & famous personalities</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-700 text-[10px] font-bold uppercase tracking-wider">
                  <TrendingUp className="w-3 h-3" />
                  <span>Bullish Outlook</span>
                </div>
              </div>
              
              <div className="max-h-[600px] overflow-y-auto pr-1 -mr-1">
                <SocialTradesFeed 
                  stocks={stocks}
                  watchlist={watchlist}
                  tickerFilter={stock.ticker}
                  viewType={stock.marketType === 'final' ? 'equity' : 'stocks'}
                  onSelectStock={onSelectStock}
                  onToggleWatchlist={onToggleWatchlist}
                  onQuickTrade={(stk) => onOpenQuickTrade(stk, 'buy')}
                />
              </div>
            </div>

            <StockNewsFeed
            news={relatedNews.length > 0 ? relatedNews : BREAKING_STOCK_NEWS}
            stocks={stocks}
            ownedTickers={positions.map((p) => p.ticker)}
            followedTickers={watchlist}
            onSelectTicker={(ticker) => {
              const found = stocks.find((item) => item.ticker === ticker);
              if (found) onSelectStock(found);
            }}
            onQuickTrade={(ticker) => {
              const found = stocks.find((item) => item.ticker === ticker);
              if (found) onOpenQuickTrade(found, 'buy');
            }}
          />
          </div>
        </div>

        {/* RIGHT COLUMN: Order Desk, Positions, Clearance Guarantee, Recommendations */}
        <div className="lg:col-span-5 space-y-6">
          {/* Institutional Stock Order Desk */}
          <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden">
            <StockOrderDesk
              stock={stock}
              currentUser={currentUser}
              onOpenAuthModal={onOpenAuthModal}
              onOrderExecuted={onOrderExecuted}
              preselectedOption={selectedOption}
            />
          </div>

          {/* Active Position (if owned) */}
          {userPosition && (
            <div className="p-5 sm:p-6 rounded-3xl bg-emerald-50/60 border border-emerald-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-200/60">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="font-serif font-bold text-sm text-emerald-950">Your Active Position</span>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  {userPosition.shares} Shares
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-emerald-700/80 block text-[11px]">Avg Cost Basis</span>
                  <span className="font-mono font-bold text-slate-900 text-sm">${userPosition.avgCostUSD.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-emerald-700/80 block text-[11px]">Total Valuation</span>
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    ${userPosition.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div>
                  <span className="text-emerald-700/80 block text-[11px]">Total Return ($)</span>
                  <span className={`font-mono font-bold text-sm ${userPosition.totalGainUSD >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                    {userPosition.totalGainUSD >= 0 ? '+' : ''}${userPosition.totalGainUSD.toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-emerald-700/80 block text-[11px]">Total Return (%)</span>
                  <span className={`font-mono font-bold text-sm ${userPosition.totalGainPercent >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                    {userPosition.totalGainPercent >= 0 ? '+' : ''}{userPosition.totalGainPercent.toFixed(2)}%
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Clearance & Sovereign Vault Backing */}
          <div className="p-5 rounded-3xl bg-slate-50 border border-slate-200 text-slate-900 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <h3 className="font-serif font-bold text-sm text-slate-900">Sovereign Clearing Guarantee</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Every share of <span className="font-mono font-bold text-slate-900">${stock.ticker}</span> purchased via the {badge.label} is 100% custodied in cryptographic cold vaults with audited 1:1 proof-of-reserves.
            </p>
            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-200 font-mono">
              <span>Fee: 0.00%</span>
              <span className="text-emerald-600 font-bold">Status: Verified</span>
            </div>
          </div>

          {/* Related Equities */}
          {relatedStocks.length > 0 && (
            <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-serif font-bold text-sm text-slate-900">
                  Other {badge.label}s
                </h3>
                <span className="text-[11px] text-slate-400 font-mono">Explore</span>
              </div>

              <div className="space-y-2">
                {relatedStocks.map((rel) => {
                  const relPos = rel.changeUSD >= 0;
                  return (
                    <button
                      key={rel.ticker}
                      type="button"
                      onClick={() => onSelectStock(rel)}
                      className="w-full p-3 rounded-2xl bg-slate-50 hover:bg-amber-50/60 border border-slate-100 hover:border-amber-300 transition-all flex items-center justify-between text-left cursor-pointer group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-700 font-mono font-bold text-xs flex items-center justify-center group-hover:bg-amber-100 group-hover:text-amber-700 transition-colors border border-slate-200 group-hover:border-amber-200">
                          {rel.ticker.slice(0, 3)}
                        </div>
                        <div>
                          <div className="font-mono font-bold text-xs text-slate-900 group-hover:text-amber-800">
                            ${rel.ticker}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate max-w-[130px]">{rel.name}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-xs text-slate-900">${rel.price.toFixed(2)}</div>
                        <div className={`font-mono text-[10px] font-semibold ${relPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {relPos ? '+' : ''}{rel.changePercent.toFixed(2)}%
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
