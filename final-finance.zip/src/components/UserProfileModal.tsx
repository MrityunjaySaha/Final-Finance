import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserProfile, AssetClass } from '../types';
import { CURRENT_USER } from '../data/mockData';
import { 
  User, 
  CheckCircle2, 
  ShieldCheck, 
  Wallet, 
  Edit3, 
  Sparkles, 
  Layers, 
  Award,
  RefreshCw
} from 'lucide-react';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, setCurrentUser, addToast, setCurrentTab } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser.name);
  const [bio, setBio] = useState(currentUser.bio);
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatarUrl);
  const [tier, setTier] = useState(currentUser.tier);

  if (!isOpen) return null;

  const PRESET_PERSONAS: UserProfile[] = [
    {
      ...CURRENT_USER,
      id: 'marcus-aurelius',
      name: 'Marcus Aurelius Vance',
      handle: '@marcus_vance',
      avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
      bio: 'Sovereign Multi-Asset Allocator & Quantitative Barter Arbitrageur. Managing private vault allocations across Gold, Final Coins, and deep cold-storage BTC.',
      tier: 'Sovereign',
      portfolioNAV: 4785200,
      holdings: {
        barter: 1850000,
        final_coins: 1420000,
        stable_coins: 515200,
        fiat: 200000,
        crypto: 800000
      }
    },
    {
      id: 'lord-sterling',
      name: 'Lord Sterling',
      handle: '@sterling_vault',
      email: 'sterling@zurich-escrow.ch',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      bio: 'Swiss Freeport Trustee & 1st Edition Imperial Gold Bullion Syndicate Master. Specializing in physical allocated bullion barters.',
      tier: 'Sovereign',
      verified: true,
      joinedDate: 'January 2024',
      portfolioNAV: 18450000,
      followersCount: 5240,
      followingCount: 310,
      holdings: {
        barter: 9800000,
        final_coins: 4500000,
        stable_coins: 2150000,
        fiat: 1000000,
        crypto: 1000000
      }
    },
    {
      id: 'elena-rostova',
      name: 'Elena Rostova',
      handle: '@elena_commodities',
      email: 'elena@monaco-yachting.mc',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
      bio: 'Global Maritime & Aviation Barter Broker. Facilitating charter deed swaps against Final Coins algorithmic treasury tranches.',
      tier: 'Institutional',
      verified: true,
      joinedDate: 'March 2024',
      portfolioNAV: 12600000,
      followersCount: 3890,
      followingCount: 420,
      holdings: {
        barter: 7200000,
        final_coins: 2400000,
        stable_coins: 1500000,
        fiat: 500000,
        crypto: 1000000
      }
    }
  ];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentUser(prev => ({
      ...prev,
      name,
      bio,
      avatarUrl,
      tier
    }));
    setIsEditing(false);
    addToast({
      type: 'success',
      title: 'Profile Updated',
      message: 'Sovereign credentials and bio successfully saved.'
    });
  };

  const handleSelectPersona = (p: UserProfile) => {
    setCurrentUser(p);
    setName(p.name);
    setBio(p.bio);
    setAvatarUrl(p.avatarUrl);
    setTier(p.tier);
    addToast({
      type: 'gold',
      title: 'Active Persona Switched',
      message: `Logged in as ${p.name} (${p.tier}).`
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl border border-amber-500/30 bg-[#0d1017] p-6 shadow-2xl space-y-6 my-8">
        
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <User className="h-5 w-5 text-amber-400" />
            <h3 className="font-serif text-lg font-bold text-white">
              Sovereign Member Profile & Portfolio
            </h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white text-sm">✕</button>
        </div>

        {/* User Card */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="flex items-center gap-3.5">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="h-14 w-14 rounded-full object-cover border-2 border-amber-500/40"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="font-serif text-base font-bold text-white">{currentUser.name}</h4>
                {currentUser.verified && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
              </div>
              <p className="text-xs font-mono text-neutral-400">{currentUser.handle} • {currentUser.email}</p>
              <span className="inline-block mt-1 rounded bg-amber-500/20 px-2 py-0.5 text-[9px] font-mono font-bold text-amber-300 border border-amber-500/30">
                {currentUser.tier} Tier Member
              </span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider block">Net Asset Value (NAV)</span>
            <p className="font-mono text-xl font-bold text-amber-300">
              ${currentUser.portfolioNAV.toLocaleString()}
            </p>
          </div>
        </div>

        {/* 5 Vaults Portfolio Breakdown */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
            5 Dedicated Vault Allocations
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {(['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'] as AssetClass[]).map((vault) => {
              const amount = currentUser.holdings[vault] || 0;
              const pct = ((amount / (currentUser.portfolioNAV || 1)) * 100).toFixed(1);
              const isBarter = vault === 'barter';
              const isFinalCoins = vault === 'final_coins';
              return (
                <div key={vault} className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-2.5 text-center">
                  <p className="text-[10px] font-mono capitalize text-neutral-400 truncate">{vault.replace('_', ' ')}</p>
                  <p className="font-mono text-xs font-bold text-white mt-0.5">
                    {isBarter ? (
                      <span className="text-amber-400 font-bold">Priceless</span>
                    ) : isFinalCoins ? (
                      `${(amount / 1.42).toLocaleString(undefined, { maximumFractionDigits: 0 })} AFNL`
                    ) : (
                      `$${amount.toLocaleString()}`
                    )}
                  </p>
                  <span className="text-[9px] font-mono text-amber-400">
                    {isBarter ? 'Direct Barter' : isFinalCoins ? 'Utility Units' : `${pct}% NAV`}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Edit Bio Form */}
        {isEditing ? (
          <form onSubmit={handleSaveProfile} className="space-y-3 rounded-xl border border-neutral-800 bg-neutral-900/40 p-4">
            <div>
              <label className="text-xs font-semibold text-white block mb-1">Display Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-white block mb-1">Bio / Allocation Strategy</label>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs text-white"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="rounded-lg border border-neutral-800 px-3 py-1 text-xs text-neutral-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-amber-500 px-3 py-1 text-xs font-bold text-black hover:bg-amber-400"
              >
                Save Changes
              </button>
            </div>
          </form>
        ) : (
          <div className="flex items-center justify-between rounded-xl border border-neutral-800 bg-neutral-900/40 p-3 text-xs text-neutral-300">
            <p className="italic max-w-lg">"{currentUser.bio}"</p>
            <button
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-1 text-amber-400 hover:underline text-xs font-semibold shrink-0 ml-2"
            >
              <Edit3 className="h-3 w-3" /> Edit Bio
            </button>
          </div>
        )}

        {/* Switch Investor Personas */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
            Switch Institutional Persona
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {PRESET_PERSONAS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => handleSelectPersona(p)}
                className={`text-left rounded-xl border p-2.5 transition-all flex items-center gap-2 ${
                  currentUser.id === p.id
                    ? 'border-amber-400 bg-amber-500/20 ring-1 ring-amber-500/30'
                    : 'border-neutral-800 bg-neutral-900 hover:border-neutral-700'
                }`}
              >
                <img src={p.avatarUrl} alt={p.name} className="h-8 w-8 rounded-full object-cover shrink-0" />
                <div className="truncate">
                  <p className="text-xs font-bold text-white truncate">{p.name}</p>
                  <p className="text-[10px] font-mono text-amber-300 truncate">${(p.portfolioNAV / 1000000).toFixed(1)}M NAV</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-neutral-800 bg-neutral-900 px-5 py-2 text-xs font-bold text-white hover:bg-neutral-800"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
