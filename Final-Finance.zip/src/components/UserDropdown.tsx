import React, { useState, useRef, useEffect } from 'react';
import { 
  LogOut, 
  ChevronDown, 
  LayoutDashboard,
  Upload,
  QrCode,
  Store,
  Users,
  MessageSquare,
  TrendingUp,
  Landmark,
  Settings,
  Target,
  ShieldCheck,
  Crown,
  ArrowRight,
  Check,
  CheckCircle2,
  Briefcase,
  Twitter,
  Car,
  Ticket,
  User
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { signOut } from '../services/firebaseAuth';
import { PresenceStatusBadge } from './common/PresenceBadge';

interface UserDropdownProps {
  currentUser: AuthSession;
  onNavigate: (view: 'landing' | 'dashboard' | 'vaults' | 'marketplace' | 'community' | 'social' | 'messages' | 'stocks' | 'subsidies' | 'uploads' | 'qrcodes' | 'point_of_sale' | 'wallets' | 'asset_inventory' | 'settings' | 'ai_studio' | 'fundraising' | 'admin' | 'superadmin' | 'portfolio' | 'holdings' | 'tweeting' | 'ride_share' | 'coupons' | 'transfer_funds') => void;
  onViewMyProfile?: () => void;
  onOpenAuthModal?: () => void;
  onSignOut: () => void;
  onOpenVerificationModal?: () => void;
}

export const UserDropdown: React.FC<UserDropdownProps> = ({
  currentUser,
  onNavigate,
  onViewMyProfile,
  onSignOut,
  onOpenVerificationModal,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedHandle, setCopiedHandle] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleSignOut = async () => {
    await signOut();
    setIsOpen(false);
    onSignOut();
    onNavigate('landing');
  };

  const handleNavigate = (view: any) => {
    setIsOpen(false);
    onNavigate(view);
  };

  const handleCopyHandle = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(`@${currentUser.id}`);
    setCopiedHandle(true);
    setTimeout(() => setCopiedHandle(false), 1500);
  };

  const cleanEmail = (currentUser.email || '').trim().toLowerCase();
  const isSuperAdmin = currentUser.role === 'super_admin' || cleanEmail === 'ranmaanimaker@gmail.com';
  const isAdmin = currentUser.role === 'admin' || currentUser.role === 'super_admin' || cleanEmail === 'awesomedbz@gmail.com' || cleanEmail === 'ranmaanimaker@gmail.com';

  return (
    <>
      <div ref={dropdownRef} className="relative inline-block text-left">
        {/* Trigger Button with User Handle & Avatar */}
        <button
          id="user-account-dropdown-trigger"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="min-h-[40px] pl-2 pr-3 py-1.5 rounded-full bg-slate-100/90 hover:bg-slate-200/90 border border-slate-200 text-slate-900 flex items-center gap-2.5 transition-all cursor-pointer shadow-2xs group active:scale-[0.98]"
          aria-haspopup="true"
          aria-expanded={isOpen}
          title="Account Menu"
        >
          {/* Avatar */}
          <div className="relative">
            {currentUser.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-slate-300"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-serif font-bold">
                {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
              </div>
            )}
            {currentUser.isVerified !== false && (
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-white" />
            )}
          </div>

          {/* Handle and Name */}
          <div className="text-left hidden sm:block max-w-[130px]">
            <p className="text-xs font-bold text-slate-900 truncate leading-tight">
              {currentUser.name}
            </p>
            <p className="text-[10px] font-mono text-slate-500 truncate leading-tight">
              @{currentUser.id}
            </p>
          </div>

          <ChevronDown className={`w-3.5 h-3.5 text-slate-400 group-hover:text-slate-900 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Clean, Organized, Left-Aligned Dropdown Menu Panel (stretched cleanly with no visible scrollbar) */}
        {isOpen && (
          <div
            id="user-account-dropdown-menu"
            className="absolute left-0 top-full mt-2 w-76 sm:w-80 max-h-[calc(100vh-4.25rem)] overflow-y-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden bg-white/95 backdrop-blur-xl border border-slate-200/90 rounded-2xl shadow-2xl z-[60] text-left py-0 animate-in fade-in zoom-in-95 duration-150 origin-top-left"
          >
            {/* Header: User Profile Card (Left-Aligned) - Name, Username, Email, then Settings Page & Get Verified on same line */}
            <div 
              onClick={() => handleNavigate('settings')}
              className="px-3.5 pt-2.5 pb-1.5 bg-slate-50/80 hover:bg-amber-50/60 transition-colors cursor-pointer group text-left"
              title="Go to Account & Security Settings"
            >
              <div className="flex items-start gap-2.5 text-left">
                <div className="relative shrink-0 mt-0.5">
                  {currentUser.avatarUrl ? (
                    <img
                      src={currentUser.avatarUrl}
                      alt={currentUser.name}
                      className="w-9 h-9 rounded-xl object-cover border border-slate-200 shadow-2xs group-hover:ring-2 group-hover:ring-amber-500/50 transition-all"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-9 h-9 rounded-xl bg-slate-900 group-hover:bg-amber-700 text-white flex items-center justify-center text-sm font-serif font-bold shadow-2xs transition-colors">
                      {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
                    </div>
                  )}
                  {currentUser.isVerified !== false && (
                    <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-amber-500 text-white flex items-center justify-center ring-1.5 ring-white" title="Verified Member">
                      <ShieldCheck className="w-2 h-2" />
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1 space-y-0.5 leading-tight text-left">
                  {/* Name */}
                  <div className="flex items-center justify-start gap-1 min-w-0">
                    <h4 className="font-bold text-xs text-slate-900 group-hover:text-amber-900 transition-colors truncate leading-tight text-left">
                      {currentUser.name}
                    </h4>
                    {currentUser.isVerified !== false && (
                      <span title="Verified" className="inline-flex items-center shrink-0">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 fill-emerald-100 shrink-0" />
                      </span>
                    )}
                  </div>

                  {/* Username (@handle) */}
                  <div className="flex items-center justify-start gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={handleCopyHandle}
                      className="text-[10px] font-mono text-slate-500 hover:text-slate-800 transition-colors inline-flex items-center gap-1 cursor-pointer truncate leading-tight text-left"
                      title="Click to copy handle"
                    >
                      <span>@{currentUser.id}</span>
                      {copiedHandle ? (
                        <Check className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                      ) : null}
                    </button>
                  </div>

                  {/* Email */}
                  <p className="text-[10px] text-slate-400 truncate leading-tight text-left">{currentUser.email}</p>

                  {/* Settings Page + Get Verified on the exact same line below name, username, and email */}
                  <div className="pt-0.5 flex items-center justify-start gap-2 flex-wrap">
                    <div className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 group-hover:text-amber-950 transition-colors leading-tight whitespace-nowrap">
                      <Settings className="w-2.5 h-2.5 text-amber-600 shrink-0" />
                      <span>Settings Page</span>
                    </div>

                    {currentUser.isVerified === false && (
                      <>
                        <span className="text-slate-300 text-[10px]">·</span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setIsOpen(false);
                            if (onOpenVerificationModal) onOpenVerificationModal();
                          }}
                          className="text-[9px] font-bold px-2 py-0.5 rounded bg-slate-200 hover:bg-amber-100 text-slate-700 hover:text-amber-900 transition-colors cursor-pointer shrink-0 leading-none whitespace-nowrap"
                        >
                          Get Verified
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>



            {/* Admin & SuperAdmin Controls (Restricted to Admin / SuperAdmin) */}
            {(isSuperAdmin || isAdmin) && (
              <div className="py-1 px-2 space-y-1 bg-amber-50/40 text-left">
                {isSuperAdmin && (
                  <button
                    id="dropdown-nav-superadmin"
                    type="button"
                    onClick={() => handleNavigate('superadmin')}
                    className="w-full px-3 py-1.5 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left bg-amber-500/10 text-amber-950 hover:bg-amber-500/20 transition-colors cursor-pointer font-bold border border-amber-300/80"
                  >
                    <Crown className="w-4 h-4 text-amber-600 shrink-0" />
                    <span className="flex-1 truncate">SuperAdmin Console</span>
                    <ArrowRight className="w-3.5 h-3.5 text-amber-700 shrink-0 ml-auto" />
                  </button>
                )}

                {isAdmin && (
                  <button
                    id="dropdown-nav-admin"
                    type="button"
                    onClick={() => handleNavigate('admin')}
                    className="w-full px-3 py-1.5 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left bg-blue-50/80 text-blue-950 hover:bg-blue-100 transition-colors cursor-pointer font-bold border border-blue-200"
                  >
                    <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                    <span className="flex-1 truncate">Admin Portal</span>
                    <ArrowRight className="w-3.5 h-3.5 text-blue-700 shrink-0 ml-auto" />
                  </button>
                )}
              </div>
            )}

            {/* Main Navigation Items (Left-Aligned, maximum line spacing without scrolling) */}
            <div className="pt-0 pb-0 px-2 space-y-1 text-left">
              <button
                id="dropdown-nav-subsidies"
                type="button"
                onClick={() => handleNavigate('subsidies')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Landmark className="w-4 h-4 text-amber-600 shrink-0" />
                <span>UBI, Subsidy, &amp; Internal Banking</span>
              </button>

              <button
                id="dropdown-nav-tweeting"
                type="button"
                onClick={() => handleNavigate('tweeting')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-emerald-50 hover:text-emerald-950 transition-colors cursor-pointer font-medium leading-snug"
              >
                <span className="w-4 h-4 rounded-md bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Twitter className="w-2.5 h-2.5 -scale-x-100 -rotate-12 fill-white" />
                </span>
                <span>Tweet</span>
              </button>

              <button
                id="dropdown-nav-point-of-sale"
                type="button"
                onClick={() => handleNavigate('point_of_sale')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Store className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Point of Sale</span>
              </button>

              <button
                id="dropdown-nav-ride-share"
                type="button"
                onClick={() => handleNavigate('ride_share')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Car className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Ride-Share</span>
              </button>

              <button
                id="dropdown-nav-coupons"
                type="button"
                onClick={() => handleNavigate('coupons')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-amber-50 hover:text-amber-950 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Ticket className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Coupons</span>
              </button>

              <button
                id="dropdown-nav-stocks"
                type="button"
                onClick={() => handleNavigate('stocks')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <TrendingUp className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Stock Market Exchange</span>
              </button>

              <button
                id="dropdown-nav-portfolio"
                type="button"
                onClick={() => handleNavigate('portfolio')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Briefcase className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Stock Portfolio</span>
              </button>

              <button
                id="dropdown-nav-fundraising"
                type="button"
                onClick={() => handleNavigate('fundraising')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Target className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Fundraising &amp; Charity</span>
              </button>

              <button
                id="dropdown-nav-qrcodes"
                type="button"
                onClick={() => handleNavigate('qrcodes')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <QrCode className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>QR Codes</span>
              </button>

              <button
                id="dropdown-nav-dashboard"
                type="button"
                onClick={() => handleNavigate('dashboard')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <LayoutDashboard className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Dashboard Overview</span>
              </button>

              <button
                id="dropdown-nav-social"
                type="button"
                onClick={() => handleNavigate('social')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Users className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Community &amp; Social Feed</span>
              </button>

              <button
                id="dropdown-nav-messages"
                type="button"
                onClick={() => handleNavigate('messages')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <MessageSquare className="w-4 h-4 text-sky-600 shrink-0" />
                <span>Social Interactions</span>
              </button>

              <button
                id="dropdown-nav-uploads"
                type="button"
                onClick={() => handleNavigate('uploads')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium leading-snug"
              >
                <Upload className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Uploads &amp; Drafts</span>
              </button>

              <button
                id="dropdown-signout-btn"
                type="button"
                onClick={handleSignOut}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer font-semibold leading-snug"
              >
                <LogOut className="w-4 h-4 text-rose-500 shrink-0" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
