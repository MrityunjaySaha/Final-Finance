import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Sparkles, 
  Coins, 
  Lock, 
  CreditCard, 
  BarChart3, 
  Check, 
  ArrowRight, 
  ShieldCheck, 
  Layers, 
  TrendingUp, 
  ExternalLink,
  Info,
  DollarSign
} from 'lucide-react';
import { SearchableProduct } from '../data/searchCatalog';
import { AuthSession } from '../types/auth';
import { ConfirmModal } from './common/ConfirmModal';
import { useApp } from '../context/AppContext';
import { recordLedgerTransaction, createLedgerItemFromMarketplacePurchase } from '../utils/universalLedgerBridge';

interface ProductDetailModalProps {
  product: SearchableProduct | null;
  currentUser?: AuthSession | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (actionType: 'barter' | 'stake' | 'swap' | 'wire' | 'deposit', product: SearchableProduct) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  currentUser,
  isOpen,
  onClose,
  onSelectAction,
}) => {
  const { addToast, addNotification } = useApp();
  const [selectedLotSize, setSelectedLotSize] = useState<number>(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [actionConfirmed, setActionConfirmed] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  if (!isOpen || !product) return null;

  const handleAction = () => {
    setShowConfirm(true);
  };

  const processExecution = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setActionConfirmed(true);

      // Parse price estimate
      const numericPrice = parseFloat(product.price.replace(/[^0-9.]/g, '')) || 1000;
      const totalAmountUSD = numericPrice * selectedLotSize;

      // Record in Universal Ledger
      const ledgerItem = createLedgerItemFromMarketplacePurchase({
        productName: product.name,
        quantity: selectedLotSize,
        priceUSD: totalAmountUSD,
        category: product.category
      });
      recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

      addToast({
        title: 'Asset Allocation Authorized',
        message: `Allocated ${selectedLotSize}x ${product.name} with formal escrow settlement.`,
        type: 'gold'
      });

      addNotification({
        title: `🛍️ Marketplace Order Placed: ${product.name}`,
        description: `Authorized escrow allocation for ${selectedLotSize} unit(s) @ ${product.price}.`,
        type: 'marketplace',
        targetTab: 'marketplace',
        amount: totalAmountUSD,
        currency: 'USD'
      });

      setTimeout(() => {
        setActionConfirmed(false);
        onClose();
      }, 1400);
    }, 800);
  };

  return (
    <div
      id="product-detail-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 12 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="w-full max-w-xl bg-white border border-neutral-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative text-left my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 sm:top-5 sm:right-5 min-h-[36px] min-w-[36px] flex items-center justify-center rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Info */}
        <div className="flex items-start gap-4 pb-4 border-b border-neutral-100 pr-8">
          <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Coins className="w-6 h-6 text-amber-400" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-neutral-900 text-white font-medium">
                {product.badge || 'SOVEREIGN ASSET'}
              </span>
              <span className="text-xs text-neutral-400 font-medium">
                {product.category}
              </span>
            </div>

            <h2 className="font-serif-lux text-xl sm:text-2xl font-light text-black tracking-tight leading-snug">
              {product.name}
            </h2>
          </div>
        </div>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto pr-1 py-4 space-y-5 flex-1">
          {/* Price & Value Block */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/90 flex items-center justify-between">
            <div>
              <p className="text-[11px] text-neutral-400 uppercase tracking-wider font-mono">Reference Valuation</p>
              <p className="text-lg sm:text-xl font-bold text-black font-mono mt-0.5">
                {product.price}
              </p>
            </div>
            <div className="flex items-center gap-1 text-emerald-700 bg-emerald-100/80 px-2.5 py-1 rounded-full text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Audited LBMA / Multi-Sig</span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono mb-1.5">
              Asset Provenance &amp; Specifications
            </h3>
            <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Highlights & Features */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono mb-2">
              Guaranteed Features
            </h3>
            <div className="space-y-2">
              {product.features.map((feat, idx) => (
                <div key={idx} className="flex items-center gap-2.5 text-xs text-neutral-800">
                  <div className="w-4 h-4 rounded-full bg-black text-white flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5" />
                  </div>
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Allocation Quantity Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono">
                Order / Allocation Lot Size
              </label>
              <span className="text-xs font-mono font-semibold text-black">
                {selectedLotSize} Unit{selectedLotSize > 1 ? 's' : ''}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {[1, 5, 10, 25, 50].map((lot) => (
                <button
                  key={lot}
                  type="button"
                  onClick={() => setSelectedLotSize(lot)}
                  className={`min-h-[38px] flex-1 py-1.5 rounded-xl text-xs font-mono font-semibold transition-all cursor-pointer ${
                    selectedLotSize === lot
                      ? 'bg-black text-white shadow-xs'
                      : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                  }`}
                >
                  {lot}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="pt-4 border-t border-neutral-100 flex items-center justify-between gap-3">
          <div className="text-xs text-neutral-500 font-mono hidden sm:block">
            Escrow: Final Finance Zurich
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              disabled={isProcessing || actionConfirmed}
              onClick={handleAction}
              className="flex-1 sm:flex-none min-h-[42px] px-6 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60"
            >
              {actionConfirmed ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Allocation Confirmed!</span>
                </>
              ) : isProcessing ? (
                <span>Locking Escrow Order...</span>
              ) : (
                <>
                  <span>Initiate Allocation</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title="Confirm Asset Allocation"
        message={`Authorize the allocation of ${selectedLotSize} unit(s) of ${product.name}? This will initiate a formal escrow contract for ${product.price}.`}
        confirmText="Confirm Allocation"
        type="info"
      />
    </div>
  );
};
