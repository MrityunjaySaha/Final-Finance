import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { getStoredCustomCoins } from '../data/customCoinsData';
import { getAllWorldCurrencies } from '../data/worldCurrenciesData';
import { TransactionMode, UniversalLedgerItem } from '../types/ledger';
import { AuctionBid, AuctionConfig, SettlementMethod } from '../types/marketplace';
import {
  createLedgerItemFromBarter,
  createLedgerItemFromMarketplacePurchase,
  recordLedgerTransaction
} from '../utils/universalLedgerBridge';
import {
  getAuctionBids,
  getAuctionRemainingLabel,
  getMinimumNextBidUSD,
  saveAuctionBidsForListing,
  submitBarterTradeProposal,
  updateListingAuctionState,
  updateListingStatus,
} from './marketplaceService';
import { areUsersBlockedEitherWay, enqueueUserNotification, isAdminAccount } from './socialService';
import {
  WalletProviderId,
  calculateWalletPurchaseFee,
  formatInsufficientCurrencyError,
} from '../utils/transactionFees';
import { checkRestrictedMarketplaceItem } from '../data/restrictedItemsPolicy';
import { createBarterIOU } from './barterIouService';

export type CurrencyTypeId = 'final_coins' | 'stable_coins' | 'fiat' | 'crypto';
export type SettlementModeId = CurrencyTypeId | 'barter';

export interface TargetListingForTrade {
  id: string;
  title: string;
  sellerId: string;
  sellerName: string;
  sellerHandle?: string;
  estimatedValueUSD?: number;
  priceUSD?: number;
  primaryPriceUSD?: number;
  priceInNative?: string;
  category?: string;
  description?: string;
  imageUrl?: string;
  itemType?: 'good' | 'service';
  listingIntent?: 'sell' | 'buy' | 'auction';
  auctionConfig?: AuctionConfig;
  primaryTradeMode?: 'currency' | 'barter';
  primaryCurrency?: string;
  acceptedSettlements?: SettlementMethod[];
  acceptedCurrencyList?: string[];
  finalCoinsPricing?: { symbol: string; amount: number };
  finalCoinsPricingList?: Array<{ symbol: string; amount: number; name?: string }>;
  stableCoinsPricing?: { symbol: string; amount: number; network?: string };
  fiatPricing?: { currencyCode: string; amount: number };
  cryptoPricing?: { symbol: string; amount: number; network?: string };
  barterDesired?: string;
  barterTerms?: {
    desiredTrades: string;
    desiredExchangeType?: 'good' | 'service' | 'any';
    openToOffers: boolean;
    estimatedValueUSD?: number;
  };
  quantity?: number;
  unitLabel?: string;
  availableUnits?: number;
  unitType?: string;
  turnaroundTime?: string;
  deliverables?: string;
  condition?: string;
  location?: string;
  status?: string;
}

export interface SettlementCoinOption {
  symbol: string;
  name: string;
  currencyType: CurrencyTypeId;
  mode: TransactionMode;
  walletBalance: number;
  linkedBankBalanceUnits: number;
  linkedBankName?: string;
  totalAvailableUnits: number;
  unitPriceUSD: number;
  baseUnits: number;
  feeUSD: number;
  feeUnits: number;
  totalUSD: number;
  totalRequiredUnits: number;
  requiredUnits: number;
  walletProvider: WalletProviderId;
  walletProviderLabel: string;
  feeLabel: string;
  hasSufficientBalance: boolean;
  isSellerPreferred: boolean;
  network?: string;
  decimals: number;
  badge: string;
}

export interface DealExecutionResult {
  success: boolean;
  error?: string;
  ledgerItem?: UniversalLedgerItem;
  proposalId?: string;
  barterIouId?: string;
  barterIouCode?: string;
  settlementMode: SettlementModeId;
  coinSymbol?: string;
  baseUnits?: number;
  paidUnits?: number;
  amountUSD: number;
  feeUSD?: number;
  totalUSD?: number;
  walletProviderLabel?: string;
  feeLabel?: string;
  assetEnrolledName?: string;
  remainingQuantity?: number;
  markedSold?: boolean;
}

const AFNL_BENCHMARK_USD = 20;

export const CURRENCY_TYPE_META: Record<
  CurrencyTypeId,
  { label: string; shortLabel: string; description: string }
> = {
  final_coins: {
    label: 'Final Coins',
    shortLabel: 'Final Coins',
    description: 'Native ecosystem settlement tokens (AFNL & peer Final Coins)',
  },
  stable_coins: {
    label: 'Stablecoins',
    shortLabel: 'Stablecoins',
    description: 'USD / Gold / Euro pegged digital settlement assets (USDC, PAXG, EURC, USDT)',
  },
  fiat: {
    label: 'Fiat Currency',
    shortLabel: 'Fiat Currency',
    description: 'Treasury & Bank Reserve Currencies (USD, CHF, EUR, GBP)',
  },
  crypto: {
    label: 'Cryptocurrency',
    shortLabel: 'Crypto',
    description: 'Layer-1 Digital Assets (BTC, ETH, SOL & listed cryptocurrencies)',
  },
};

export function getListingValuationUSD(listing?: Partial<TargetListingForTrade> | null): number {
  if (!listing) return 0;
  const raw =
    listing.estimatedValueUSD ??
    listing.priceUSD ??
    listing.primaryPriceUSD ??
    listing.barterTerms?.estimatedValueUSD ??
    0;
  return Number(raw) > 0 ? Number(raw) : 0;
}

export function getAllowedSettlementModes(
  listing?: Partial<TargetListingForTrade> | null
): SettlementModeId[] {
  if (!listing) {
    return ['final_coins', 'stable_coins', 'fiat', 'crypto', 'barter'];
  }
  if (Array.isArray(listing.acceptedSettlements) && listing.acceptedSettlements.length > 0) {
    return Array.from(new Set(listing.acceptedSettlements)) as SettlementModeId[];
  }
  const inferred: SettlementModeId[] = [];
  if (listing.finalCoinsPricing || listing.acceptedCurrencyList?.includes('AFNL')) {
    inferred.push('final_coins');
  }
  if (
    listing.stableCoinsPricing ||
    listing.acceptedCurrencyList?.some((c) => ['USDC', 'USDT', 'PAXG', 'EURC', 'EURS'].includes(c.toUpperCase()))
  ) {
    inferred.push('stable_coins');
  }
  if (
    listing.fiatPricing ||
    listing.acceptedCurrencyList?.some((c) => ['USD', 'EUR', 'GBP', 'CHF'].includes(c.toUpperCase()))
  ) {
    inferred.push('fiat');
  }
  if (
    listing.cryptoPricing ||
    listing.acceptedCurrencyList?.some((c) => ['BTC', 'ETH', 'SOL'].includes(c.toUpperCase()))
  ) {
    inferred.push('crypto');
  }
  if (listing.barterDesired || listing.barterTerms?.desiredTrades || listing.primaryTradeMode === 'barter') {
    inferred.push('barter');
  }
  return inferred.length > 0 ? inferred : ['final_coins', 'stable_coins', 'fiat', 'crypto', 'barter'];
}

export function getListingSettlementSummary(
  listing?: Partial<TargetListingForTrade> | null
): string {
  const modes = getAllowedSettlementModes(listing);
  const parts: string[] = [];
  const listed = (listing?.acceptedCurrencyList || []).map((c) => c.toUpperCase());

  if (modes.includes('fiat')) {
    const fiatSym = listed.find((c) => ['USD', 'EUR', 'GBP', 'CHF'].includes(c)) || 'Fiat';
    parts.push(fiatSym);
  }
  if (modes.includes('final_coins')) {
    parts.push('AFNL');
  }
  if (modes.includes('stable_coins')) {
    const stSym = listed.find((c) => ['USDC', 'USDT', 'PAXG', 'EURC', 'EURS'].includes(c)) || 'Stablecoins';
    parts.push(stSym);
  }
  if (modes.includes('crypto')) {
    const crSym = listed.find((c) => ['BTC', 'ETH', 'SOL'].includes(c)) || 'Crypto';
    parts.push(crSym);
  }
  if (modes.includes('barter')) {
    parts.push('Barter');
  }
  return parts.length > 0 ? parts.join(' • ') : 'Multi-Asset • Barter';
}

export function getListingTradeActionLabel(
  listing?: Partial<TargetListingForTrade> | null
): string {
  if (!listing) return 'Buy or Barter';
  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') return 'Settled / Sold';
  if (listing.listingIntent === 'auction') {
    const remaining = getAuctionRemainingLabel(listing.auctionConfig?.endTimeIso);
    if (listing.auctionConfig?.status === 'ended' || remaining.isEnded) {
      return 'Auction Ended';
    }
    return 'Place Bid';
  }
  if (listing.listingIntent === 'buy') return 'Fulfill / Make Offer';
  const modes = getAllowedSettlementModes(listing);
  const acceptsCurrency = modes.some((m) => m !== 'barter');
  const acceptsBarter = modes.includes('barter');
  if (acceptsCurrency && acceptsBarter) return 'Buy or Barter';
  if (acceptsCurrency) return 'Buy Now';
  return 'Propose Barter';
}

function getCoinDecimals(currencyType: CurrencyTypeId, symbol: string): number {
  if (currencyType === 'crypto') {
    return symbol === 'SOL' ? 2 : 6;
  }
  return 2;
}

function roundCoinAmount(val: number, decimals: number): number {
  const factor = Math.pow(10, decimals);
  return Math.ceil(val * factor) / factor;
}

function computeCoinPricingBreakdown(params: {
  currencyType: CurrencyTypeId;
  symbol: string;
  network?: string;
  valuationUSD: number;
  unitPriceUSD: number;
  decimals: number;
  explicitUnits?: number;
}) {
  const { currencyType, symbol, network, valuationUSD, unitPriceUSD, decimals, explicitUnits } = params;
  const safeUnitPrice = unitPriceUSD > 0 ? unitPriceUSD : 1;
  const baseUSD =
    valuationUSD > 0
      ? valuationUSD
      : explicitUnits && explicitUnits > 0
      ? explicitUnits * safeUnitPrice
      : 0;
  const baseUnits =
    explicitUnits && explicitUnits > 0
      ? Number(explicitUnits.toFixed(decimals))
      : baseUSD > 0
      ? roundCoinAmount(baseUSD / safeUnitPrice, decimals)
      : 0;

  const feeInfo = calculateWalletPurchaseFee({
    category: currencyType,
    subtotalUSD: baseUSD,
    symbol,
    network,
  });

  const feeUnits =
    feeInfo.feeUSD > 0 ? roundCoinAmount(feeInfo.feeUSD / safeUnitPrice, decimals) : 0;
  const totalUSD = Number((baseUSD + feeInfo.feeUSD).toFixed(2));
  const totalRequiredUnits = Number((baseUnits + feeUnits).toFixed(decimals));

  return {
    baseUSD,
    baseUnits,
    feeUSD: feeInfo.feeUSD,
    feeUnits,
    totalUSD,
    totalRequiredUnits,
    requiredUnits: totalRequiredUnits,
    walletProvider: feeInfo.walletProvider,
    walletProviderLabel: feeInfo.walletProviderLabel,
    feeLabel: feeInfo.feeLabel,
  };
}

export const KNOWN_FIAT_SYMBOLS = new Set([
  'USD', 'EUR', 'GBP', 'CHF', 'JPY', 'CAD', 'AUD', 'CNY', 'INR', 'SGD', 'HKD', 'NZD', 'SEK', 'NOK', 'KRW', 'BRL', 'MXN', 'ZAR', 'AED', 'SAR'
]);

export const KNOWN_STABLECOIN_SYMBOLS = new Set([
  'USDC', 'USDT', 'PAXG', 'EURC', 'EURS', 'DAI', 'BUSD', 'TUSD', 'USDD', 'FDUSD', 'PYUSD', 'BDRS', 'ASVD'
]);

export const KNOWN_CRYPTO_SYMBOLS = new Set([
  'BTC', 'ETH', 'SOL', 'BNB', 'XRP', 'ADA', 'DOGE', 'AVAX', 'DOT', 'MATIC', 'TRX', 'LINK', 'LTC', 'NEAR', 'UNI'
]);

export function isFinalCoinSymbol(symbol: string): boolean {
  const sym = (symbol || '').toUpperCase().trim();
  if (!sym) return false;
  if (sym === 'AFNL' || sym.startsWith('FNL')) return true;
  if (KNOWN_FIAT_SYMBOLS.has(sym) || KNOWN_STABLECOIN_SYMBOLS.has(sym) || KNOWN_CRYPTO_SYMBOLS.has(sym)) {
    return false;
  }
  return true;
}

export function getListingAcceptableFinalCurrencies(
  listing: Partial<TargetListingForTrade> | null
): Map<string, { symbol: string; name?: string; explicitAmount?: number }> {
  const acceptable = new Map<string, { symbol: string; name?: string; explicitAmount?: number }>();
  if (!listing) return acceptable;

  // 1. Explicit finalCoinsPricing
  if (listing.finalCoinsPricing?.symbol) {
    const sym = listing.finalCoinsPricing.symbol.toUpperCase().trim();
    const amt = Number(listing.finalCoinsPricing.amount);
    if (sym) {
      acceptable.set(sym, { symbol: sym, explicitAmount: amt > 0 ? amt : undefined });
    }
  }

  // 2. Explicit finalCoinsPricingList if present
  if (Array.isArray((listing as any).finalCoinsPricingList)) {
    for (const item of (listing as any).finalCoinsPricingList) {
      const sym = String(item?.symbol || '').toUpperCase().trim();
      const amt = Number(item?.amount);
      if (sym) {
        acceptable.set(sym, {
          symbol: sym,
          explicitAmount: amt > 0 ? amt : undefined,
          name: item?.name,
        });
      }
    }
  }

  // 3. Parse priceInNative (e.g. "23 AFNL or 20 SDF", "23 AFNL / 20 SDF", "22,500 AFNL", "14,400 AFNL")
  if (listing.priceInNative && typeof listing.priceInNative === 'string') {
    const regex = /([0-9,.]+)\s*([A-Za-z0-9_-]+)/g;
    let m: RegExpExecArray | null;
    while ((m = regex.exec(listing.priceInNative)) !== null) {
      const rawNum = m[1].replace(/,/g, '');
      const parsedNum = parseFloat(rawNum);
      const sym = m[2].toUpperCase().trim();
      if (!sym) continue;
      if (isFinalCoinSymbol(sym)) {
        if (!isNaN(parsedNum) && parsedNum > 0) {
          if (!acceptable.has(sym)) {
            acceptable.set(sym, { symbol: sym, explicitAmount: parsedNum });
          } else if (acceptable.get(sym)?.explicitAmount === undefined) {
            acceptable.get(sym)!.explicitAmount = parsedNum;
          }
        }
      }
    }
  }

  // 4. Check acceptedCurrencyList for final coins
  if (Array.isArray(listing.acceptedCurrencyList)) {
    for (const raw of listing.acceptedCurrencyList) {
      const sym = String(raw || '').toUpperCase().trim();
      if (!sym) continue;
      if (isFinalCoinSymbol(sym)) {
        if (!acceptable.has(sym)) {
          acceptable.set(sym, { symbol: sym });
        }
      }
    }
  }

  // 5. Check primaryCurrency
  if (listing.primaryCurrency) {
    const sym = listing.primaryCurrency.toUpperCase().trim();
    if (sym && isFinalCoinSymbol(sym)) {
      if (!acceptable.has(sym)) {
        acceptable.set(sym, { symbol: sym });
      }
    }
  }

  // 6. If listing accepts final_coins mode but no specific coin was recognized, default to AFNL
  const allowedModes = getAllowedSettlementModes(listing);
  if (acceptable.size === 0 && allowedModes.includes('final_coins')) {
    acceptable.set('AFNL', {
      symbol: 'AFNL',
      explicitAmount: listing.finalCoinsPricing?.amount,
    });
  }

  return acceptable;
}

export interface FinalCurrencyPriceItem {
  symbol: string;
  name: string;
  amount: number;
  amountFormatted: string;
  usdEquivalent: number;
  unitPriceUSD: number;
  isPrimary: boolean;
  icon?: string;
  network?: string;
}

export interface RegularCurrencyPriceItem {
  symbol: string;
  category: 'fiat' | 'stable_coins' | 'crypto';
  categoryLabel: string;
  name: string;
  amount: number;
  amountFormatted: string;
  usdEquivalent: number;
  network?: string;
  isPrimary: boolean;
  icon?: string;
}

export interface BarterTermsDisplay {
  isAccepted: boolean;
  desiredTrades: string;
  desiredExchangeType: 'good' | 'service' | 'any';
  estimatedValueUSD: number;
  openToOffers: boolean;
  splitPreferences?: string;
  customExchangeOffers?: string;
}

export interface ListingPricingSummary {
  valuationUSD: number;
  primaryCurrency?: string;
  finalCurrencies: FinalCurrencyPriceItem[];
  regularCurrencies: RegularCurrencyPriceItem[];
  barter: BarterTermsDisplay;
}

export function getListingComprehensivePricing(
  listing: Partial<TargetListingForTrade> | any
): ListingPricingSummary {
  const valuationUSD = getListingValuationUSD(listing);
  const customCoins = getStoredCustomCoins();
  const worldCurrencies = getAllWorldCurrencies();
  const allowedModes = getAllowedSettlementModes(listing);
  const acceptedList = (listing?.acceptedCurrencyList || []).map((s: any) => String(s).toUpperCase().trim());
  const primaryCurrency = (listing?.primaryCurrency || '').toUpperCase().trim();

  // 1. FINAL CURRENCIES
  const finalCurrencies: FinalCurrencyPriceItem[] = [];
  if (allowedModes.includes('final_coins')) {
    const acceptableFinals = getListingAcceptableFinalCurrencies(listing);

    acceptableFinals.forEach((info, sym) => {
      const customMatch = customCoins.find((c) => c.symbol.toUpperCase() === sym);
      const explicitAmt = info.explicitAmount;
      const unitPriceUSD =
        explicitAmt && valuationUSD > 0
          ? valuationUSD / explicitAmt
          : customMatch?.priceUSD && customMatch.priceUSD > 0
          ? customMatch.priceUSD
          : sym === 'AFNL'
          ? AFNL_BENCHMARK_USD
          : AFNL_BENCHMARK_USD;
      const decimals = getCoinDecimals('final_coins', sym);
      const amount =
        explicitAmt && explicitAmt > 0
          ? explicitAmt
          : valuationUSD > 0
          ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals)
          : 0;
      const usdEquivalent = explicitAmt && valuationUSD > 0 ? valuationUSD : amount * unitPriceUSD;
      const isPrimary = sym === primaryCurrency || sym === (listing?.finalCoinsPricing?.symbol?.toUpperCase().trim() || 'AFNL');

      finalCurrencies.push({
        symbol: sym,
        name: customMatch?.name || info.name || (sym === 'AFNL' ? 'Final Admin Coin' : `${sym} Sovereign Final Coin`),
        amount,
        amountFormatted: `${amount.toLocaleString(undefined, { maximumFractionDigits: decimals })} ${sym}`,
        usdEquivalent,
        unitPriceUSD,
        isPrimary,
        icon: customMatch?.iconSymbol || (sym === 'AFNL' ? '⚡' : '🪙'),
        network: customMatch?.network || 'Final Sovereign L1',
      });
    });
  }

  // 2. REGULAR CURRENCIES (Fiat, Stablecoins, Crypto)
  const regularCurrencies: RegularCurrencyPriceItem[] = [];
  const addedRegularSyms = new Set<string>();

  // A. Fiat
  if (allowedModes.includes('fiat')) {
    if (listing?.fiatPricing?.currencyCode) {
      const code = listing.fiatPricing.currencyCode.toUpperCase().trim();
      const amt = listing.fiatPricing.amount;
      const wc = worldCurrencies.find((w) => w.symbol.toUpperCase() === code);
      const rate = wc?.unitPriceUSD || 1;
      regularCurrencies.push({
        symbol: code,
        category: 'fiat',
        categoryLabel: 'Fiat Reserve',
        name: wc?.name || `${code} Treasury Reserve`,
        amount: amt,
        amountFormatted: `${code === 'USD' ? '$' : ''}${amt.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${code}`,
        usdEquivalent: amt * rate,
        network: wc?.issuer || 'Central Bank / Sovereign Treasury',
        isPrimary: code === primaryCurrency,
        icon: '💵',
      });
      addedRegularSyms.add(code);
    }

    acceptedList
      .filter((sym: string) => KNOWN_FIAT_SYMBOLS.has(sym) && !addedRegularSyms.has(sym))
      .forEach((code: string) => {
        const wc = worldCurrencies.find((w) => w.symbol.toUpperCase() === code);
        const rate = wc?.unitPriceUSD || (code === 'EUR' ? 1.08 : code === 'CHF' ? 1.15 : code === 'GBP' ? 1.28 : 1);
        const decimals = getCoinDecimals('fiat', code);
        const amt = valuationUSD > 0 ? roundCoinAmount(valuationUSD / rate, decimals) : 0;
        regularCurrencies.push({
          symbol: code,
          category: 'fiat',
          categoryLabel: 'Fiat Reserve',
          name: wc?.name || `${code} Currency`,
          amount: amt,
          amountFormatted: `${code === 'USD' ? '$' : ''}${amt.toLocaleString(undefined, { maximumFractionDigits: decimals })} ${code}`,
          usdEquivalent: valuationUSD,
          network: wc?.issuer || 'Treasury Clearing',
          isPrimary: code === primaryCurrency,
          icon: '💵',
        });
        addedRegularSyms.add(code);
      });

    if (addedRegularSyms.size === 0 && valuationUSD > 0) {
      regularCurrencies.push({
        symbol: 'USD',
        category: 'fiat',
        categoryLabel: 'Fiat Reserve',
        name: 'US Dollar Treasury Reserve',
        amount: valuationUSD,
        amountFormatted: `$${valuationUSD.toLocaleString()} USD`,
        usdEquivalent: valuationUSD,
        network: 'US Federal Reserve / Treasury Escrow',
        isPrimary: primaryCurrency === 'USD',
        icon: '💵',
      });
      addedRegularSyms.add('USD');
    }
  }

  // B. Stablecoins
  if (allowedModes.includes('stable_coins')) {
    if (listing?.stableCoinsPricing?.symbol) {
      const sym = listing.stableCoinsPricing.symbol.toUpperCase().trim();
      const amt = listing.stableCoinsPricing.amount;
      const wc = worldCurrencies.find((w) => w.symbol.toUpperCase() === sym);
      regularCurrencies.push({
        symbol: sym,
        category: 'stable_coins',
        categoryLabel: 'Stablecoin',
        name: wc?.name || `${sym} Digital Stablecoin`,
        amount: amt,
        amountFormatted: `${amt.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${sym}`,
        usdEquivalent: amt * (wc?.unitPriceUSD || 1),
        network: listing.stableCoinsPricing.network || wc?.network || 'Polygon & Ethereum',
        isPrimary: sym === primaryCurrency,
        icon: '🛡️',
      });
      addedRegularSyms.add(sym);
    }

    acceptedList
      .filter((sym: string) => KNOWN_STABLECOIN_SYMBOLS.has(sym) && !addedRegularSyms.has(sym))
      .forEach((sym: string) => {
        const wc = worldCurrencies.find((w) => w.symbol.toUpperCase() === sym);
        const unitPrice = wc?.unitPriceUSD || (sym === 'PAXG' ? 2880 : 1);
        const decimals = getCoinDecimals('stable_coins', sym);
        const amt = valuationUSD > 0 ? roundCoinAmount(valuationUSD / unitPrice, decimals) : 0;
        regularCurrencies.push({
          symbol: sym,
          category: 'stable_coins',
          categoryLabel: 'Stablecoin',
          name: wc?.name || `${sym} Stablecoin`,
          amount: amt,
          amountFormatted: `${amt.toLocaleString(undefined, { maximumFractionDigits: decimals })} ${sym}`,
          usdEquivalent: valuationUSD,
          network: wc?.network || 'EVM / Polygon',
          isPrimary: sym === primaryCurrency,
          icon: '🛡️',
        });
        addedRegularSyms.add(sym);
      });
  }

  // C. Cryptocurrencies
  if (allowedModes.includes('crypto')) {
    if (listing?.cryptoPricing?.symbol) {
      const sym = listing.cryptoPricing.symbol.toUpperCase().trim();
      const amt = listing.cryptoPricing.amount;
      const wc = worldCurrencies.find((w) => w.symbol.toUpperCase() === sym);
      const decimals = getCoinDecimals('crypto', sym);
      regularCurrencies.push({
        symbol: sym,
        category: 'crypto',
        categoryLabel: 'Cryptocurrency',
        name: wc?.name || `${sym} Digital Asset`,
        amount: amt,
        amountFormatted: `${amt.toLocaleString(undefined, { maximumFractionDigits: decimals })} ${sym}`,
        usdEquivalent: valuationUSD,
        network: listing.cryptoPricing.network || wc?.network || `${sym} Mainnet`,
        isPrimary: sym === primaryCurrency,
        icon: sym === 'BTC' ? '₿' : sym === 'ETH' ? 'Ξ' : '⚡',
      });
      addedRegularSyms.add(sym);
    }

    acceptedList
      .filter((sym: string) => KNOWN_CRYPTO_SYMBOLS.has(sym) && !addedRegularSyms.has(sym))
      .forEach((sym: string) => {
        const wc = worldCurrencies.find((w) => w.symbol.toUpperCase() === sym);
        const unitPrice = wc?.unitPriceUSD || (sym === 'BTC' ? 95000 : sym === 'ETH' ? 2800 : sym === 'SOL' ? 180 : 1);
        const decimals = getCoinDecimals('crypto', sym);
        const amt = valuationUSD > 0 ? roundCoinAmount(valuationUSD / unitPrice, decimals) : 0;
        regularCurrencies.push({
          symbol: sym,
          category: 'crypto',
          categoryLabel: 'Cryptocurrency',
          name: wc?.name || `${sym} Layer-1`,
          amount: amt,
          amountFormatted: `${amt.toLocaleString(undefined, { maximumFractionDigits: decimals })} ${sym}`,
          usdEquivalent: valuationUSD,
          network: wc?.network || `${sym} Network`,
          isPrimary: sym === primaryCurrency,
          icon: sym === 'BTC' ? '₿' : sym === 'ETH' ? 'Ξ' : '⚡',
        });
        addedRegularSyms.add(sym);
      });
  }

  // 3. BARTER
  const barterTerms: BarterTermsDisplay = {
    isAccepted: allowedModes.includes('barter'),
    desiredTrades:
      listing?.barterDesired ||
      listing?.barterTerms?.desiredTrades ||
      'Open to physical reserve bullion, luxury timepieces, compute hours, or verified professional service retainers.',
    desiredExchangeType: listing?.barterTerms?.desiredExchangeType || (listing?.itemType === 'service' ? 'service' : 'good'),
    estimatedValueUSD: listing?.barterTerms?.estimatedValueUSD || valuationUSD,
    openToOffers: listing?.barterTerms?.openToOffers ?? true,
    splitPreferences: listing?.crossTransactionalTerms?.splitPreferences,
    customExchangeOffers: listing?.crossTransactionalTerms?.customExchangeOffers,
  };

  return {
    valuationUSD,
    primaryCurrency,
    finalCurrencies,
    regularCurrencies,
    barter: barterTerms,
  };
}

export function getCurrencyOptionsForType(
  userId: string,
  listing: Partial<TargetListingForTrade> | null,
  currencyType: CurrencyTypeId,
  overrideUSDAmount?: number
): SettlementCoinOption[] {
  const wallet = getStoredUserWallets(userId || 'guest');
  const customCoins = getStoredCustomCoins();
  const worldCurrencies = getAllWorldCurrencies();

  const valuationUSD =
    typeof overrideUSDAmount === 'number' && overrideUSDAmount > 0
      ? overrideUSDAmount
      : getListingValuationUSD(listing);

  const preferredSet = new Set(
    [
      ...(listing?.acceptedCurrencyList || []),
      listing?.primaryCurrency,
      listing?.finalCoinsPricing?.symbol,
      listing?.stableCoinsPricing?.symbol,
      listing?.fiatPricing?.currencyCode,
      listing?.cryptoPricing?.symbol,
    ]
      .filter(Boolean)
      .map((s) => String(s).toUpperCase().trim())
  );

  const optionsMap = new Map<string, SettlementCoinOption>();

  if (currencyType === 'final_coins') {
    if (listing) {
      // LISTING SETTLEMENT MODE:
      // Strictly show ONLY relevant, acceptable final currencies for this listing!
      const acceptableFinals = getListingAcceptableFinalCurrencies(listing);

      acceptableFinals.forEach((info, sym) => {
        const walletMatch = (wallet.finalCoins || []).find((c) => c.symbol.toUpperCase() === sym);
        const customMatch = customCoins.find((c) => c.symbol.toUpperCase() === sym);
        const explicitPricing = info.explicitAmount;

        const unitPriceUSD =
          explicitPricing && valuationUSD > 0
            ? valuationUSD / explicitPricing
            : walletMatch?.unitPriceUSD && walletMatch.unitPriceUSD > 0
            ? walletMatch.unitPriceUSD
            : customMatch?.priceUSD && customMatch.priceUSD > 0
            ? customMatch.priceUSD
            : sym === 'AFNL'
            ? AFNL_BENCHMARK_USD
            : AFNL_BENCHMARK_USD;

        const decimals = getCoinDecimals('final_coins', sym);
        const pricing = computeCoinPricingBreakdown({
          currencyType: 'final_coins',
          symbol: sym,
          network: walletMatch?.network || customMatch?.network || 'Final Sovereign L1',
          valuationUSD,
          unitPriceUSD,
          decimals,
          explicitUnits: explicitPricing && !overrideUSDAmount ? explicitPricing : undefined,
        });

        const balance = walletMatch ? Number(walletMatch.balance || 0) : 0;

        optionsMap.set(sym, {
          symbol: sym,
          name:
            walletMatch?.name ||
            customMatch?.name ||
            info.name ||
            (sym === 'AFNL' ? 'Final Admin Coin' : `${sym} Sovereign Final Coin`),
          currencyType: 'final_coins',
          mode: 'final_coin',
          walletBalance: balance,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: balance,
          unitPriceUSD,
          ...pricing,
          hasSufficientBalance: balance >= pricing.totalRequiredUnits && pricing.totalRequiredUnits > 0,
          isSellerPreferred: true,
          network: walletMatch?.network || customMatch?.network || 'Final Sovereign L1',
          decimals,
          badge: explicitPricing
            ? `${explicitPricing.toLocaleString(undefined, { maximumFractionDigits: decimals })} ${sym}`
            : `$${unitPriceUSD.toFixed(2)} / ${sym}`,
        });
      });
    } else {
      // VAULT / GENERAL OVERVIEW MODE (no target listing selected):
      (wallet.finalCoins || []).forEach((fc) => {
        const sym = (fc.symbol || '').toUpperCase().trim();
        if (!sym) return;
        const customMatch = customCoins.find((c) => c.symbol.toUpperCase() === sym);
        const unitPriceUSD =
          fc.unitPriceUSD > 0
            ? fc.unitPriceUSD
            : customMatch?.priceUSD && customMatch.priceUSD > 0
            ? customMatch.priceUSD
            : AFNL_BENCHMARK_USD;
        const decimals = getCoinDecimals('final_coins', sym);
        const pricing = computeCoinPricingBreakdown({
          currencyType: 'final_coins',
          symbol: sym,
          network: fc.network || customMatch?.network || 'Final Sovereign L1',
          valuationUSD,
          unitPriceUSD,
          decimals,
        });
        const balance = Number(fc.balance || 0);
        optionsMap.set(sym, {
          symbol: sym,
          name: fc.name || customMatch?.name || sym,
          currencyType: 'final_coins',
          mode: 'final_coin',
          walletBalance: balance,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: balance,
          unitPriceUSD,
          ...pricing,
          hasSufficientBalance: balance >= pricing.totalRequiredUnits,
          isSellerPreferred: sym === 'AFNL',
          network: fc.network || customMatch?.network || 'Final Sovereign L1',
          decimals,
          badge: `$${unitPriceUSD.toFixed(2)} / ${sym}`,
        });
      });

      customCoins
        .filter((c) => c.coinType === 'final_coin')
        .forEach((cc) => {
          const sym = cc.symbol.toUpperCase().trim();
          if (!sym || optionsMap.has(sym)) return;
          const unitPriceUSD = cc.priceUSD && cc.priceUSD > 0 ? cc.priceUSD : AFNL_BENCHMARK_USD;
          const decimals = getCoinDecimals('final_coins', sym);
          const pricing = computeCoinPricingBreakdown({
            currencyType: 'final_coins',
            symbol: sym,
            network: cc.network || 'Final Sovereign L1',
            valuationUSD,
            unitPriceUSD,
            decimals,
          });
          optionsMap.set(sym, {
            symbol: sym,
            name: cc.name,
            currencyType: 'final_coins',
            mode: 'final_coin',
            walletBalance: 0,
            linkedBankBalanceUnits: 0,
            totalAvailableUnits: 0,
            unitPriceUSD,
            ...pricing,
            hasSufficientBalance: pricing.totalRequiredUnits === 0,
            isSellerPreferred: sym === 'AFNL',
            network: cc.network || 'Final Sovereign L1',
            decimals,
            badge: `$${unitPriceUSD.toFixed(2)} / ${sym}`,
          });
        });
    }
  } else if (currencyType === 'stable_coins') {
    (wallet.stableCoins || []).forEach((sc) => {
      const sym = (sc.symbol || '').toUpperCase().trim();
      if (!sym) return;
      const explicitPricing =
        listing?.stableCoinsPricing?.symbol?.toUpperCase() === sym && listing.stableCoinsPricing.amount > 0
          ? listing.stableCoinsPricing.amount
          : undefined;
      const unitPriceUSD =
        explicitPricing && valuationUSD > 0
          ? valuationUSD / explicitPricing
          : sc.unitPriceUSD > 0
          ? sc.unitPriceUSD
          : 1;
      const decimals = getCoinDecimals('stable_coins', sym);
      const pricing = computeCoinPricingBreakdown({
        currencyType: 'stable_coins',
        symbol: sym,
        network: sc.network,
        valuationUSD,
        unitPriceUSD,
        decimals,
        explicitUnits: explicitPricing && !overrideUSDAmount ? explicitPricing : undefined,
      });
      const balance = Number(sc.balance || 0);
      optionsMap.set(sym, {
        symbol: sym,
        name: sc.name || sym,
        currencyType: 'stable_coins',
        mode: 'stable_coin',
        walletBalance: balance,
        linkedBankBalanceUnits: 0,
        totalAvailableUnits: balance,
        unitPriceUSD,
        ...pricing,
        hasSufficientBalance: balance + 1e-6 >= pricing.totalRequiredUnits,
        isSellerPreferred: preferredSet.has(sym),
        network: sc.network,
        decimals,
        badge: `${sc.peggedCurrency} • ${sc.network}`,
      });
    });

    worldCurrencies
      .filter((w) => w.category === 'stablecoin')
      .forEach((wc) => {
        const sym = wc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = wc.unitPriceUSD > 0 ? wc.unitPriceUSD : 1;
        const decimals = getCoinDecimals('stable_coins', sym);
        const pricing = computeCoinPricingBreakdown({
          currencyType: 'stable_coins',
          symbol: sym,
          network: wc.network,
          valuationUSD,
          unitPriceUSD,
          decimals,
        });
        optionsMap.set(sym, {
          symbol: sym,
          name: wc.name,
          currencyType: 'stable_coins',
          mode: 'stable_coin',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          ...pricing,
          hasSufficientBalance: pricing.totalRequiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: wc.network,
          decimals,
          badge: wc.network,
        });
      });

    customCoins
      .filter((c) => c.coinType === 'stable_coin')
      .forEach((cc) => {
        const sym = cc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = cc.priceUSD || cc.pegRateUSD || 1;
        const decimals = getCoinDecimals('stable_coins', sym);
        const pricing = computeCoinPricingBreakdown({
          currencyType: 'stable_coins',
          symbol: sym,
          network: cc.network,
          valuationUSD,
          unitPriceUSD,
          decimals,
        });
        optionsMap.set(sym, {
          symbol: sym,
          name: cc.name,
          currencyType: 'stable_coins',
          mode: 'stable_coin',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          ...pricing,
          hasSufficientBalance: pricing.totalRequiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: cc.network,
          decimals,
          badge: cc.network || 'Custom Stablecoin',
        });
      });
  } else if (currencyType === 'fiat') {
    (wallet.fiatCurrencies || []).forEach((fi) => {
      const code = (fi.code || '').toUpperCase().trim();
      if (!code) return;
      const exchangeRateToUSD = fi.exchangeRateToUSD > 0 ? fi.exchangeRateToUSD : 1;
      const explicitPricing =
        listing?.fiatPricing?.currencyCode?.toUpperCase() === code && listing.fiatPricing.amount > 0
          ? listing.fiatPricing.amount
          : undefined;
      const decimals = getCoinDecimals('fiat', code);
      const pricing = computeCoinPricingBreakdown({
        currencyType: 'fiat',
        symbol: code,
        network: fi.institution,
        valuationUSD,
        unitPriceUSD: exchangeRateToUSD,
        decimals,
        explicitUnits: explicitPricing && !overrideUSDAmount ? explicitPricing : undefined,
      });
      const cashBalance = Number(fi.balance || 0);
      const matchingBanks = (wallet.linkedBankAccounts || []).filter(
        (b) => b.currency.toUpperCase() === code && (b.balanceUSD || 0) > 0
      );
      const bankUSD = matchingBanks.reduce((sum, b) => sum + (b.balanceUSD || 0), 0);
      const linkedBankUnits = bankUSD / exchangeRateToUSD;
      const totalAvailableUnits = cashBalance + linkedBankUnits;

      optionsMap.set(code, {
        symbol: code,
        name: fi.name || code,
        currencyType: 'fiat',
        mode: 'fiat',
        walletBalance: cashBalance,
        linkedBankBalanceUnits: linkedBankUnits,
        linkedBankName: matchingBanks[0]?.bankName,
        totalAvailableUnits,
        unitPriceUSD: exchangeRateToUSD,
        ...pricing,
        hasSufficientBalance: totalAvailableUnits + 1e-6 >= pricing.totalRequiredUnits,
        isSellerPreferred: preferredSet.has(code),
        network: fi.institution,
        decimals,
        badge: matchingBanks[0]
          ? `${fi.institution} + ${matchingBanks[0].bankName}`
          : fi.institution,
      });
    });

    worldCurrencies
      .filter((w) => w.category === 'fiat')
      .forEach((wc) => {
        const code = wc.symbol.toUpperCase().trim();
        if (!code || optionsMap.has(code)) return;
        const exchangeRateToUSD = wc.unitPriceUSD > 0 ? wc.unitPriceUSD : 1;
        const decimals = getCoinDecimals('fiat', code);
        const pricing = computeCoinPricingBreakdown({
          currencyType: 'fiat',
          symbol: code,
          network: wc.issuer,
          valuationUSD,
          unitPriceUSD: exchangeRateToUSD,
          decimals,
        });
        const matchingBanks = (wallet.linkedBankAccounts || []).filter(
          (b) => b.currency.toUpperCase() === code && (b.balanceUSD || 0) > 0
        );
        const bankUSD = matchingBanks.reduce((sum, b) => sum + (b.balanceUSD || 0), 0);
        const linkedBankUnits = bankUSD / exchangeRateToUSD;

        optionsMap.set(code, {
          symbol: code,
          name: wc.name,
          currencyType: 'fiat',
          mode: 'fiat',
          walletBalance: 0,
          linkedBankBalanceUnits: linkedBankUnits,
          linkedBankName: matchingBanks[0]?.bankName,
          totalAvailableUnits: linkedBankUnits,
          unitPriceUSD: exchangeRateToUSD,
          ...pricing,
          hasSufficientBalance: linkedBankUnits + 1e-6 >= pricing.totalRequiredUnits,
          isSellerPreferred: preferredSet.has(code),
          network: wc.issuer,
          decimals,
          badge: wc.issuer,
        });
      });
  } else if (currencyType === 'crypto') {
    (wallet.cryptoCurrencies || []).forEach((cr) => {
      const sym = (cr.symbol || '').toUpperCase().trim();
      if (!sym) return;
      const explicitPricing =
        listing?.cryptoPricing?.symbol?.toUpperCase() === sym && listing.cryptoPricing.amount > 0
          ? listing.cryptoPricing.amount
          : undefined;
      const unitPriceUSD =
        explicitPricing && valuationUSD > 0
          ? valuationUSD / explicitPricing
          : cr.unitPriceUSD > 0
          ? cr.unitPriceUSD
          : 1;
      const decimals = getCoinDecimals('crypto', sym);
      const pricing = computeCoinPricingBreakdown({
        currencyType: 'crypto',
        symbol: sym,
        network: cr.network,
        valuationUSD,
        unitPriceUSD,
        decimals,
        explicitUnits: explicitPricing && !overrideUSDAmount ? explicitPricing : undefined,
      });
      const balance = Number(cr.balance || 0);
      optionsMap.set(sym, {
        symbol: sym,
        name: cr.name || sym,
        currencyType: 'crypto',
        mode: 'crypto',
        walletBalance: balance,
        linkedBankBalanceUnits: 0,
        totalAvailableUnits: balance,
        unitPriceUSD,
        ...pricing,
        hasSufficientBalance: balance + 1e-6 >= pricing.totalRequiredUnits,
        isSellerPreferred: preferredSet.has(sym),
        network: cr.network,
        decimals,
        badge: cr.network,
      });
    });

    worldCurrencies
      .filter((w) => w.category === 'crypto')
      .forEach((wc) => {
        const sym = wc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = wc.unitPriceUSD > 0 ? wc.unitPriceUSD : 1;
        const decimals = getCoinDecimals('crypto', sym);
        const pricing = computeCoinPricingBreakdown({
          currencyType: 'crypto',
          symbol: sym,
          network: wc.network,
          valuationUSD,
          unitPriceUSD,
          decimals,
        });
        optionsMap.set(sym, {
          symbol: sym,
          name: wc.name,
          currencyType: 'crypto',
          mode: 'crypto',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          ...pricing,
          hasSufficientBalance: pricing.totalRequiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: wc.network,
          decimals,
          badge: wc.network,
        });
      });

    customCoins
      .filter((c) => c.coinType === 'crypto')
      .forEach((cc) => {
        const sym = cc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = cc.priceUSD && cc.priceUSD > 0 ? cc.priceUSD : 1;
        const decimals = getCoinDecimals('crypto', sym);
        const pricing = computeCoinPricingBreakdown({
          currencyType: 'crypto',
          symbol: sym,
          network: cc.network || 'Multi-Chain',
          valuationUSD,
          unitPriceUSD,
          decimals,
        });
        optionsMap.set(sym, {
          symbol: sym,
          name: cc.name,
          currencyType: 'crypto',
          mode: 'crypto',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          ...pricing,
          hasSufficientBalance: pricing.totalRequiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: cc.network || 'Multi-Chain',
          decimals,
          badge: cc.network || 'Custom Crypto',
        });
      });
  }

  return Array.from(optionsMap.values()).sort((a, b) => {
    if (a.isSellerPreferred !== b.isSellerPreferred) return a.isSellerPreferred ? -1 : 1;
    if (a.hasSufficientBalance !== b.hasSufficientBalance) return a.hasSufficientBalance ? -1 : 1;
    if ((a.totalAvailableUnits > 0) !== (b.totalAvailableUnits > 0)) {
      return a.totalAvailableUnits > 0 ? -1 : 1;
    }
    return a.symbol.localeCompare(b.symbol);
  });
}

function deductOrCreditCoinInWallet(
  userId: string,
  coinOption: SettlementCoinOption,
  unitsDelta: number,
  direction: 'deduct' | 'credit'
): { success: boolean; error?: string } {
  const wallet = getStoredUserWallets(userId);
  const sym = coinOption.symbol.toUpperCase();

  if (coinOption.currencyType === 'final_coins') {
    if (!wallet.finalCoins) wallet.finalCoins = [];
    const idx = wallet.finalCoins.findIndex((c) => c.symbol.toUpperCase() === sym);
    if (direction === 'deduct') {
      if (idx === -1 || wallet.finalCoins[idx].balance < unitsDelta) {
        return {
          success: false,
          error: formatInsufficientCurrencyError({
            symbol: sym,
            name: coinOption.name,
            available: idx !== -1 ? wallet.finalCoins[idx].balance : 0,
            required: unitsDelta,
            maxDecimals: 4,
          }),
        };
      }
      wallet.finalCoins[idx].balance = Number((wallet.finalCoins[idx].balance - unitsDelta).toFixed(4));
    } else {
      if (idx !== -1) {
        wallet.finalCoins[idx].balance = Number((wallet.finalCoins[idx].balance + unitsDelta).toFixed(4));
      } else {
        wallet.finalCoins.push({
          id: `fc-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(4)),
          unitPriceUSD: sym === 'AFNL' ? 0 : coinOption.unitPriceUSD,
          change24h: 0,
          utility: 'Marketplace settlement proceeds',
        });
      }
    }
  } else if (coinOption.currencyType === 'stable_coins') {
    if (!wallet.stableCoins) wallet.stableCoins = [];
    const idx = wallet.stableCoins.findIndex((c) => c.symbol.toUpperCase() === sym);
    if (direction === 'deduct') {
      if (idx === -1 || wallet.stableCoins[idx].balance < unitsDelta) {
        return {
          success: false,
          error: formatInsufficientCurrencyError({
            symbol: sym,
            name: coinOption.name,
            available: idx !== -1 ? wallet.stableCoins[idx].balance : 0,
            required: unitsDelta,
            maxDecimals: 4,
          }),
        };
      }
      wallet.stableCoins[idx].balance = Number((wallet.stableCoins[idx].balance - unitsDelta).toFixed(4));
    } else {
      if (idx !== -1) {
        wallet.stableCoins[idx].balance = Number((wallet.stableCoins[idx].balance + unitsDelta).toFixed(4));
      } else {
        wallet.stableCoins.push({
          id: `sc-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(4)),
          unitPriceUSD: coinOption.unitPriceUSD || 1,
          peggedCurrency: 'USD',
          yieldAPY: 4.5,
          network: coinOption.network || 'Polygon & Ethereum',
        });
      }
    }
  } else if (coinOption.currencyType === 'fiat') {
    if (!wallet.fiatCurrencies) wallet.fiatCurrencies = [];
    const idx = wallet.fiatCurrencies.findIndex((f) => f.code.toUpperCase() === sym);
    const rate = idx !== -1 ? wallet.fiatCurrencies[idx].exchangeRateToUSD || coinOption.unitPriceUSD || 1 : coinOption.unitPriceUSD || 1;
    if (direction === 'deduct') {
      const cashAvail = idx !== -1 ? wallet.fiatCurrencies[idx].balance : 0;
      const matchingBanks = (wallet.linkedBankAccounts || []).filter(
        (b) => b.currency.toUpperCase() === sym && (b.balanceUSD || 0) > 0
      );
      const bankAvailUnits = matchingBanks.reduce((s, b) => s + (b.balanceUSD || 0) / rate, 0);
      if (cashAvail + bankAvailUnits + 1e-6 < unitsDelta) {
        return {
          success: false,
          error: formatInsufficientCurrencyError({
            symbol: sym,
            name: coinOption.name,
            available: cashAvail + bankAvailUnits,
            required: unitsDelta,
            maxDecimals: 2,
          }),
        };
      }
      let remainingToDeduct = unitsDelta;
      if (idx !== -1 && cashAvail > 0) {
        const deductFromCash = Math.min(cashAvail, remainingToDeduct);
        wallet.fiatCurrencies[idx].balance = Number((cashAvail - deductFromCash).toFixed(2));
        remainingToDeduct -= deductFromCash;
      }
      if (remainingToDeduct > 1e-6 && wallet.linkedBankAccounts) {
        let remainingUSD = remainingToDeduct * rate;
        for (const bank of wallet.linkedBankAccounts) {
          if (bank.currency.toUpperCase() === sym && (bank.balanceUSD || 0) > 0 && remainingUSD > 0) {
            const deductUSD = Math.min(bank.balanceUSD || 0, remainingUSD);
            bank.balanceUSD = Number(((bank.balanceUSD || 0) - deductUSD).toFixed(2));
            remainingUSD -= deductUSD;
          }
        }
      }
    } else {
      if (idx !== -1) {
        wallet.fiatCurrencies[idx].balance = Number((wallet.fiatCurrencies[idx].balance + unitsDelta).toFixed(2));
      } else {
        wallet.fiatCurrencies.push({
          id: `fi-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          code: sym,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(2)),
          exchangeRateToUSD: rate,
          accountType: 'Settlement Reserve',
          institution: 'Sovereign Clearing',
        });
      }
    }
  } else if (coinOption.currencyType === 'crypto') {
    if (!wallet.cryptoCurrencies) wallet.cryptoCurrencies = [];
    const idx = wallet.cryptoCurrencies.findIndex((c) => c.symbol.toUpperCase() === sym);
    if (direction === 'deduct') {
      if (idx === -1 || wallet.cryptoCurrencies[idx].balance < unitsDelta) {
        return {
          success: false,
          error: formatInsufficientCurrencyError({
            symbol: sym,
            name: coinOption.name,
            available: idx !== -1 ? wallet.cryptoCurrencies[idx].balance : 0,
            required: unitsDelta,
            maxDecimals: 6,
          }),
        };
      }
      wallet.cryptoCurrencies[idx].balance = Number((wallet.cryptoCurrencies[idx].balance - unitsDelta).toFixed(6));
    } else {
      if (idx !== -1) {
        wallet.cryptoCurrencies[idx].balance = Number((wallet.cryptoCurrencies[idx].balance + unitsDelta).toFixed(6));
      } else {
        wallet.cryptoCurrencies.push({
          id: `cr-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(6)),
          unitPriceUSD: coinOption.unitPriceUSD || 1,
          change24h: 0,
          network: coinOption.network || 'Multi-Chain',
          walletAddress: `0x${Date.now().toString(16)}escrow`,
        });
      }
    }
  }

  saveStoredUserWallets(userId, wallet);
  return { success: true };
}

function enrollAcquiredListingInBuyerInventory(
  buyerId: string,
  listing: TargetListingForTrade,
  valuationUSD: number
): string {
  const wallet = getStoredUserWallets(buyerId);
  const isService =
    listing.itemType === 'service' ||
    (listing.category && String(listing.category).toLowerCase().includes('service'));

  if (isService) {
    if (!wallet.barterServices) wallet.barterServices = [];
    const units = listing.availableUnits || 1;
    wallet.barterServices.unshift({
      id: `bs-acq-${listing.id}-${Date.now()}`,
      name: listing.title,
      category: listing.category || 'Professional Services',
      availableUnits: units,
      unitType: (listing.unitType as any) || 'Deliverables',
      hourlyRateValue: Number((valuationUSD / Math.max(1, units)).toFixed(2)),
      deliverableDescription: listing.deliverables || `Acquired service contract from ${listing.sellerName}`,
      turnaroundTime: listing.turnaroundTime || 'Active Retainer',
      skills: ['Acquired Service', 'Escrow Verified'],
    });
  } else {
    if (!wallet.barterGoods) wallet.barterGoods = [];
    wallet.barterGoods.unshift({
      id: `bg-acq-${listing.id}-${Date.now()}`,
      name: listing.title,
      category: listing.category || 'Precious Metals & Bullion',
      quantity: 1,
      unitLabel: listing.unitLabel || 'unit',
      estimatedUnitValue: valuationUSD,
      condition: (listing.condition as any) || 'Certified Vault',
      description: `Acquired via Sovereign Marketplace from ${listing.sellerName}`,
      location: listing.location || 'Zurich Depository',
      imageUrl: listing.imageUrl,
    });
  }

  saveStoredUserWallets(buyerId, wallet);
  return listing.title;
}

export function executeCurrencyListingDeal(params: {
  buyerId: string;
  buyerName: string;
  buyerHandle?: string;
  listing: TargetListingForTrade;
  coinOption: SettlementCoinOption;
  overrideValuationUSD?: number;
  forceMarkSold?: boolean;
}): DealExecutionResult {
  const { buyerId, listing, coinOption, overrideValuationUSD, forceMarkSold } = params;

  if (!buyerId || buyerId === 'guest') {
    return {
      success: false,
      error: 'Please sign in to execute a marketplace transaction.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') {
    return {
      success: false,
      error: 'This listing has already been settled and sold.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  const restrictionCheck = checkRestrictedMarketplaceItem({
    title: listing.title,
    description: listing.description,
    category: listing.category,
  });
  if (restrictionCheck.restricted) {
    return {
      success: false,
      error:
        restrictionCheck.reason ||
        'This item is prohibited under our U.S. & Oregon marketplace restriction policy.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  const allowedModes = getAllowedSettlementModes(listing);
  if (!allowedModes.includes(coinOption.currencyType)) {
    return {
      success: false,
      error: `The seller does not accept ${CURRENCY_TYPE_META[coinOption.currencyType].label} for this listing.`,
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  if (coinOption.currencyType === 'final_coins') {
    const acceptableFinals = getListingAcceptableFinalCurrencies(listing);
    const symUpper = coinOption.symbol.toUpperCase().trim();
    if (!acceptableFinals.has(symUpper)) {
      return {
        success: false,
        error: `The seller does not accept ${coinOption.symbol} for this listing. Acceptable final currencies: ${Array.from(acceptableFinals.keys()).join(', ')}.`,
        settlementMode: coinOption.currencyType,
        amountUSD: 0,
      };
    }
  }

  const buyerClean = buyerId.replace(/^user-/, '').toLowerCase();
  const sellerClean = (listing.sellerId || '').replace(/^user-/, '').toLowerCase();
  const sellerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (buyerClean && (buyerClean === sellerClean || buyerClean === sellerHandleClean)) {
    return {
      success: false,
      error: 'You cannot execute a purchase against your own listing.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  const amountUSD =
    typeof overrideValuationUSD === 'number' && overrideValuationUSD > 0
      ? overrideValuationUSD
      : getListingValuationUSD(listing);
  const isBuyIntent = listing.listingIntent === 'buy';
  const unitPrice = coinOption.unitPriceUSD > 0 ? coinOption.unitPriceUSD : 1;
  const pricing = computeCoinPricingBreakdown({
    currencyType: coinOption.currencyType,
    symbol: coinOption.symbol,
    network: coinOption.network,
    valuationUSD: amountUSD,
    unitPriceUSD: unitPrice,
    decimals: coinOption.decimals,
    explicitUnits:
      !overrideValuationUSD && coinOption.baseUnits > 0 ? coinOption.baseUnits : undefined,
  });

  const baseUnits = pricing.baseUnits;
  const feeUSD = isBuyIntent ? 0 : pricing.feeUSD;
  const feeUnits = isBuyIntent ? 0 : pricing.feeUnits;
  const totalUnits = isBuyIntent ? baseUnits : Number((baseUnits + feeUnits).toFixed(coinOption.decimals));
  const totalUSD = isBuyIntent ? amountUSD : Number((amountUSD + feeUSD).toFixed(2));

  if (baseUnits <= 0 || amountUSD <= 0) {
    return {
      success: false,
      error: 'Invalid settlement amount for this listing.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  // For standard 'sell' listings: buyer pays totalUnits (item valuation + wallet fee), seller receives baseUnits
  // For 'buy' (wanted/RFP) listings: buyer (current user) fulfills request and receives baseUnits from listing creator
  if (!isBuyIntent) {
    const deductRes = deductOrCreditCoinInWallet(buyerId, coinOption, totalUnits, 'deduct');
    if (!deductRes.success) {
      return {
        success: false,
        error: deductRes.error,
        settlementMode: coinOption.currencyType,
        amountUSD,
        feeUSD,
        totalUSD,
      };
    }
    if (listing.sellerId) {
      deductOrCreditCoinInWallet(listing.sellerId, coinOption, baseUnits, 'credit');
    }
    enrollAcquiredListingInBuyerInventory(buyerId, listing, amountUSD);
  } else {
    deductOrCreditCoinInWallet(buyerId, coinOption, baseUnits, 'credit');
  }

  const currentQty = typeof listing.quantity === 'number' ? listing.quantity : 1;
  const remainingQuantity = forceMarkSold ? 0 : Math.max(0, currentQty - 1);
  const markedSold = Boolean(forceMarkSold) || remainingQuantity === 0;

  if (markedSold) {
    updateListingStatus(buyerId, listing.id, 'sold', {
      buyerId,
      buyerName: params.buyerName,
      buyerHandle: params.buyerHandle,
    });
  }

  const ledgerItem = createLedgerItemFromMarketplacePurchase({
    listingTitle: listing.title,
    category: listing.category || (listing.itemType === 'service' ? 'Services' : 'Marketplace Assets'),
    amountUSD,
    feeUSD,
    totalUSD,
    walletProvider: feeUSD > 0 ? pricing.walletProviderLabel : undefined,
    paymentCoinSymbol: coinOption.symbol,
    paymentCoinAmount: totalUnits,
    quantity: 1,
    sellerName: listing.sellerName,
    sellerHandle: listing.sellerHandle?.replace(/^@/, ''),
    sellerId: listing.sellerId,
    paymentMethod: `${totalUnits.toLocaleString(undefined, { maximumFractionDigits: coinOption.decimals })} ${coinOption.symbol} (${CURRENCY_TYPE_META[coinOption.currencyType].label})`,
    mode: coinOption.mode,
  });

  recordLedgerTransaction(buyerId, ledgerItem);

  return {
    success: true,
    ledgerItem,
    settlementMode: coinOption.currencyType,
    coinSymbol: coinOption.symbol,
    baseUnits,
    paidUnits: totalUnits,
    amountUSD,
    feeUSD,
    totalUSD,
    walletProviderLabel: pricing.walletProviderLabel,
    feeLabel: pricing.feeLabel,
    assetEnrolledName: !isBuyIntent ? listing.title : undefined,
    remainingQuantity,
    markedSold,
  };
}

export function executeBarterListingDeal(params: {
  buyerId: string;
  buyerUid?: string;
  buyerHandle?: string;
  buyerName: string;
  listing: TargetListingForTrade;
  offeringType: 'inventory' | 'custom';
  inventoryKind: 'good' | 'service';
  selectedGoodId?: string;
  selectedServiceId?: string;
  offeredUnits?: number;
  customOfferText?: string;
  sweetenerCoin?: SettlementCoinOption | null;
  sweetenerAmountUSD?: number;
  sourceOverride?: 'marketplace' | 'auction';
}): DealExecutionResult {
  const {
    buyerId,
    buyerUid,
    buyerHandle,
    buyerName,
    listing,
    offeringType,
    inventoryKind,
    selectedGoodId,
    selectedServiceId,
    offeredUnits = 1,
    customOfferText,
    sweetenerCoin,
    sweetenerAmountUSD = 0,
    sourceOverride,
  } = params;

  if (!buyerId || buyerId === 'guest') {
    return {
      success: false,
      error: 'Please sign in to submit a barter trade.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  if (listing.status === 'sold') {
    return {
      success: false,
      error: 'This listing has already been settled and sold.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  const targetRestriction = checkRestrictedMarketplaceItem({
    title: listing.title,
    description: listing.description,
    category: listing.category,
  });
  if (targetRestriction.restricted) {
    return {
      success: false,
      error:
        targetRestriction.reason ||
        'This item is prohibited under our U.S. & Oregon marketplace restriction policy.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  const allowedModes = getAllowedSettlementModes(listing);
  if (!allowedModes.includes('barter')) {
    return {
      success: false,
      error: 'The seller only accepts direct currency payment for this listing.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  const buyerClean = buyerId.replace(/^user-/, '').toLowerCase();
  const sellerClean = (listing.sellerId || '').replace(/^user-/, '').toLowerCase();
  const sellerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (buyerClean && (buyerClean === sellerClean || buyerClean === sellerHandleClean)) {
    return {
      success: false,
      error: 'You cannot execute a barter against your own listing.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  const wallet = getStoredUserWallets(buyerId);
  let offeredDescription = '';
  let offeredEstimatedUSD = 0;

  if (offeringType === 'inventory') {
    if (inventoryKind === 'good') {
      const goodIdx = wallet.barterGoods.findIndex((g) => g.id === selectedGoodId);
      if (goodIdx === -1) {
        return {
          success: false,
          error: 'Please select a valid physical asset from your inventory or switch to Custom Barter Offer.',
          settlementMode: 'barter',
          amountUSD: 0,
        };
      }
      const good = wallet.barterGoods[goodIdx];
      const offerRestriction = checkRestrictedMarketplaceItem({
        title: good.name,
        description: good.description,
        category: good.category,
      });
      if (offerRestriction.restricted) {
        return {
          success: false,
          error:
            offerRestriction.reason ||
            'Your barter offer includes a prohibited item under our U.S. & Oregon marketplace restriction policy.',
          settlementMode: 'barter',
          amountUSD: 0,
        };
      }
      const units = Math.max(1, Math.min(good.quantity, Math.floor(offeredUnits)));
      offeredEstimatedUSD = units * good.estimatedUnitValue;
      offeredDescription = `${units}x ${good.name} (${good.condition}) — Valued at $${offeredEstimatedUSD.toLocaleString()} USD`;
      if (good.quantity > units) {
        wallet.barterGoods[goodIdx].quantity = good.quantity - units;
      } else {
        wallet.barterGoods.splice(goodIdx, 1);
      }
    } else {
      const srvIdx = wallet.barterServices.findIndex((s) => s.id === selectedServiceId);
      if (srvIdx === -1) {
        return {
          success: false,
          error: 'Please select a valid service retainer from your portfolio or switch to Custom Barter Offer.',
          settlementMode: 'barter',
          amountUSD: 0,
        };
      }
      const srv = wallet.barterServices[srvIdx];
      const offerRestriction = checkRestrictedMarketplaceItem({
        title: srv.name,
        description: srv.deliverableDescription,
        category: srv.category,
      });
      if (offerRestriction.restricted) {
        return {
          success: false,
          error:
            offerRestriction.reason ||
            'Your barter offer includes a prohibited item under our U.S. & Oregon marketplace restriction policy.',
          settlementMode: 'barter',
          amountUSD: 0,
        };
      }
      const units = Math.max(1, Math.min(srv.availableUnits, Math.floor(offeredUnits)));
      offeredEstimatedUSD = units * srv.hourlyRateValue;
      offeredDescription = `${units} ${srv.unitType} of ${srv.name} — Valued at $${offeredEstimatedUSD.toLocaleString()} USD`;
      if (srv.availableUnits > units) {
        wallet.barterServices[srvIdx].availableUnits = srv.availableUnits - units;
      } else {
        wallet.barterServices.splice(srvIdx, 1);
      }
    }
  } else {
    const cleanText = (customOfferText || '').trim();
    if (!cleanText) {
      return {
        success: false,
        error: 'Please describe the goods or services you are offering in barter.',
        settlementMode: 'barter',
        amountUSD: 0,
      };
    }
    const offerRestriction = checkRestrictedMarketplaceItem({
      customOfferText: cleanText,
    });
    if (offerRestriction.restricted) {
      return {
        success: false,
        error:
          offerRestriction.reason ||
          'Your barter offer includes a prohibited item under our U.S. & Oregon marketplace restriction policy.',
        settlementMode: 'barter',
        amountUSD: 0,
      };
    }
    offeredDescription = cleanText;
    offeredEstimatedUSD = getListingValuationUSD(listing);
  }

  let sweetenerBaseUnits = 0;
  let sweetenerTotalUnits = 0;
  let sweetenerFeeUSD = 0;
  let sweetenerWalletLabel: string | undefined;
  let sweetenerFeeLabel: string | undefined;
  let sweetenerSymbol: string | undefined;

  if (sweetenerCoin && sweetenerAmountUSD > 0) {
    const sweetenerPricing = computeCoinPricingBreakdown({
      currencyType: sweetenerCoin.currencyType,
      symbol: sweetenerCoin.symbol,
      network: sweetenerCoin.network,
      valuationUSD: sweetenerAmountUSD,
      unitPriceUSD: sweetenerCoin.unitPriceUSD > 0 ? sweetenerCoin.unitPriceUSD : 1,
      decimals: sweetenerCoin.decimals,
    });
    sweetenerBaseUnits = sweetenerPricing.baseUnits;
    sweetenerTotalUnits = sweetenerPricing.totalRequiredUnits;
    sweetenerFeeUSD = sweetenerPricing.feeUSD;
    sweetenerWalletLabel = sweetenerPricing.walletProviderLabel;
    sweetenerFeeLabel = sweetenerPricing.feeLabel;

    // Save inventory deduction before debiting sweetener
    saveStoredUserWallets(buyerId, wallet);
    const deductRes = deductOrCreditCoinInWallet(buyerId, sweetenerCoin, sweetenerTotalUnits, 'deduct');
    if (!deductRes.success) {
      return {
        success: false,
        error: deductRes.error,
        settlementMode: 'barter',
        amountUSD: 0,
      };
    }
    if (listing.sellerId) {
      deductOrCreditCoinInWallet(listing.sellerId, sweetenerCoin, sweetenerBaseUnits, 'credit');
    }
    sweetenerSymbol = sweetenerCoin.symbol;
  } else {
    saveStoredUserWallets(buyerId, wallet);
  }

  const proposal = submitBarterTradeProposal({
    listingId: listing.id,
    listingTitle: listing.title,
    senderId: buyerId,
    senderName: buyerName,
    recipientId: listing.sellerId || 'counterparty',
    offeredItemsDescription: offeredDescription,
    offeredSweetenerUSD: sweetenerAmountUSD > 0 ? sweetenerAmountUSD : undefined,
    offeredSweetenerToken:
      sweetenerSymbol && sweetenerTotalUnits > 0
        ? { symbol: sweetenerSymbol, amount: sweetenerTotalUnits }
        : undefined,
  });

  const estimatedTotalUSD = Math.max(
    getListingValuationUSD(listing),
    offeredEstimatedUSD + (sweetenerAmountUSD > 0 ? sweetenerAmountUSD : 0)
  );

  const ledgerItem = createLedgerItemFromBarter({
    offeredDescription:
      sweetenerSymbol && sweetenerBaseUnits > 0
        ? `${offeredDescription} + ${sweetenerBaseUnits.toLocaleString()} ${sweetenerSymbol} ($${sweetenerAmountUSD.toLocaleString()} USD)`
        : offeredDescription,
    targetListingTitle: listing.title,
    counterpartyName: listing.sellerName || 'Counterparty Peer',
    sweetenerUSD: sweetenerAmountUSD > 0 ? sweetenerAmountUSD : 0,
    estimatedTotalValueUSD: estimatedTotalUSD,
    feeUSD: sweetenerFeeUSD,
    walletProvider: sweetenerFeeUSD > 0 ? sweetenerWalletLabel : undefined,
    mode: sweetenerCoin?.mode,
  });

  recordLedgerTransaction(buyerId, ledgerItem);

  const sweetenerLabel =
    sweetenerSymbol && sweetenerTotalUnits > 0
      ? `${sweetenerBaseUnits.toLocaleString()} ${sweetenerSymbol} ($${sweetenerAmountUSD.toLocaleString()} USD${sweetenerFeeUSD > 0 ? ` + $${sweetenerFeeUSD.toFixed(2)} ${sweetenerWalletLabel || ''} fee` : ''})`
      : undefined;

  const createdBarterIOU = createBarterIOU({
    source: sourceOverride || (listing.listingIntent === 'auction' ? 'auction' : 'marketplace'),
    proposalId: proposal.proposalId,
    listingId: listing.id,
    listingTitle: listing.title,
    estimatedValueUSD: estimatedTotalUSD,
    sweetenerSummary: sweetenerLabel,
    initiator: {
      id: buyerId,
      uid: buyerUid,
      handle: (buyerHandle || buyerId).replace(/^@/, ''),
      name: buyerName || 'Member',
      obligationDescription: sweetenerLabel
        ? `${offeredDescription} + ${sweetenerLabel}`
        : offeredDescription,
    },
    counterparty: {
      id: listing.sellerId || 'counterparty',
      handle: (listing.sellerHandle || listing.sellerId || 'counterparty').replace(/^@/, ''),
      name: listing.sellerName || 'Counterparty Peer',
      obligationDescription: listing.title,
    },
  });

  return {
    success: true,
    proposalId: proposal.proposalId,
    barterIouId: createdBarterIOU.id,
    barterIouCode: createdBarterIOU.referenceCode,
    ledgerItem,
    settlementMode: 'barter',
    coinSymbol: sweetenerSymbol,
    baseUnits: sweetenerBaseUnits > 0 ? sweetenerBaseUnits : undefined,
    paidUnits: sweetenerTotalUnits > 0 ? sweetenerTotalUnits : undefined,
    amountUSD: estimatedTotalUSD,
    feeUSD: sweetenerFeeUSD,
    totalUSD: Number((estimatedTotalUSD + sweetenerFeeUSD).toFixed(2)),
    walletProviderLabel: sweetenerWalletLabel,
    feeLabel: sweetenerFeeLabel,
  };
}

// ==================== AUCTION BIDDING & 5-MODE SETTLEMENT ====================

export interface PlaceAuctionBidParams {
  bidderId: string;
  bidderUid?: string;
  bidderName: string;
  bidderHandle: string;
  bidderAvatar?: string;
  listing: TargetListingForTrade;
  amountUSD: number;
  mode: SettlementMethod;
  coinOption?: SettlementCoinOption | null;
  barterOfferingType?: 'inventory' | 'custom';
  barterInventoryKind?: 'good' | 'service';
  barterSelectedItemId?: string;
  barterOfferedUnits?: number;
  barterOfferDescription?: string;
  sweetenerCoin?: SettlementCoinOption | null;
  sweetenerAmountUSD?: number;
}

export interface PlaceAuctionBidResult {
  success: boolean;
  error?: string;
  bid?: AuctionBid;
  updatedConfig?: AuctionConfig;
}

export function placeAuctionBid(params: PlaceAuctionBidParams): PlaceAuctionBidResult {
  const {
    bidderId,
    bidderUid,
    bidderName,
    bidderHandle,
    bidderAvatar,
    listing,
    amountUSD,
    mode,
    coinOption,
    barterOfferingType,
    barterInventoryKind,
    barterSelectedItemId,
    barterOfferedUnits,
    barterOfferDescription,
    sweetenerCoin,
    sweetenerAmountUSD = 0,
  } = params;

  if (!bidderId || bidderId === 'guest') {
    return { success: false, error: 'Please sign in to place a bid on this auction.' };
  }

  if (listing.listingIntent !== 'auction') {
    return { success: false, error: 'This listing is not configured as an auction.' };
  }

  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') {
    return { success: false, error: 'This auction has already been settled.' };
  }

  const targetRestriction = checkRestrictedMarketplaceItem({
    title: listing.title,
    description: listing.description,
    category: listing.category,
  });
  if (targetRestriction.restricted) {
    return {
      success: false,
      error:
        targetRestriction.reason ||
        'This auction involves a prohibited item under our U.S. & Oregon marketplace restriction policy.',
    };
  }

  const remaining = getAuctionRemainingLabel(listing.auctionConfig?.endTimeIso);
  if (listing.auctionConfig?.status === 'ended' || remaining.isEnded) {
    return { success: false, error: 'This auction has ended and is awaiting settlement.' };
  }

  const bidderClean = bidderId.replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const sellerClean = (listing.sellerId || '').replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const sellerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (bidderClean && (bidderClean === sellerClean || bidderClean === sellerHandleClean)) {
    return { success: false, error: 'You cannot place bids on your own auction.' };
  }

  const targetUid = listing.sellerId?.startsWith('user-') ? listing.sellerId : `user-${sellerClean}`;
  const viewerUid = bidderUid || (bidderId.startsWith('user-') ? bidderId : `user-${bidderClean}`);
  if (
    !isAdminAccount(bidderId) &&
    !isAdminAccount(bidderUid) &&
    (areUsersBlockedEitherWay(viewerUid, targetUid) ||
      areUsersBlockedEitherWay(bidderId, listing.sellerId) ||
      areUsersBlockedEitherWay(bidderClean, sellerHandleClean))
  ) {
    return { success: false, error: 'Bidding unavailable: accounts have blocked each other.' };
  }

  const allowedModes = getAllowedSettlementModes(listing);
  if (!allowedModes.includes(mode)) {
    return {
      success: false,
      error: `Seller does not accept ${mode === 'barter' ? 'Barter' : CURRENCY_TYPE_META[mode].label} on this auction.`,
    };
  }

  const minNextBid = getMinimumNextBidUSD(listing);
  const roundedBidUSD = Math.round(Number(amountUSD) * 100) / 100;
  if (!Number.isFinite(roundedBidUSD) || roundedBidUSD < minNextBid) {
    return {
      success: false,
      error: `Bid must be at least $${minNextBid.toLocaleString()} USD.`,
    };
  }

  let currencySymbol: string | undefined;
  let nativeAmount: number | undefined;

  if (mode === 'barter') {
    if (!barterOfferDescription || !barterOfferDescription.trim()) {
      return { success: false, error: 'Please provide details of the goods or services you are offering in barter.' };
    }
    const offerRestriction = checkRestrictedMarketplaceItem({
      customOfferText: barterOfferDescription,
    });
    if (offerRestriction.restricted) {
      return {
        success: false,
        error:
          offerRestriction.reason ||
          'Your barter bid includes a prohibited item under our U.S. & Oregon marketplace restriction policy.',
      };
    }
    if (sweetenerCoin && sweetenerAmountUSD > 0) {
      const sweetenerCheck = getCurrencyOptionsForType(
        bidderId,
        listing,
        sweetenerCoin.currencyType,
        sweetenerAmountUSD
      ).find((c) => c.symbol === sweetenerCoin.symbol);
      if (!sweetenerCheck || !sweetenerCheck.hasSufficientBalance) {
        return {
          success: false,
          error: formatInsufficientCurrencyError({
            symbol: sweetenerCoin.symbol,
            name: sweetenerCoin.name,
            available: sweetenerCheck?.totalAvailableUnits ?? 0,
            required: sweetenerCheck?.requiredUnits ?? sweetenerAmountUSD,
            maxDecimals: sweetenerCoin.decimals,
          }),
        };
      }
    }
  } else {
    if (!coinOption) {
      return { success: false, error: `Please select a valid ${CURRENCY_TYPE_META[mode].label} asset.` };
    }
    const liveOptions = getCurrencyOptionsForType(bidderId, listing, mode, roundedBidUSD);
    const verifiedOption = liveOptions.find((c) => c.symbol === coinOption.symbol) || coinOption;
    if (!verifiedOption.hasSufficientBalance) {
      return {
        success: false,
        error: formatInsufficientCurrencyError({
          symbol: verifiedOption.symbol,
          name: verifiedOption.name,
          available: verifiedOption.totalAvailableUnits,
          required: verifiedOption.requiredUnits,
          maxDecimals: verifiedOption.decimals,
        }),
      };
    }
    currencySymbol = verifiedOption.symbol;
    nativeAmount = verifiedOption.requiredUnits;
  }

  const existingBids = getAuctionBids(listing.id);
  const previousLeader = existingBids.find((b) => b.status === 'active');

  const updatedBids: AuctionBid[] = existingBids.map((b) =>
    b.status === 'active' ? { ...b, status: 'outbid' } : b
  );

  const newBid: AuctionBid = {
    id: `bid-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    listingId: listing.id,
    bidderId,
    bidderUid: viewerUid,
    bidderName,
    bidderHandle: bidderHandle.replace(/^@/, ''),
    bidderAvatar,
    amountUSD: roundedBidUSD,
    mode,
    currencySymbol,
    nativeAmount,
    barterOfferDescription: mode === 'barter' ? barterOfferDescription?.trim() : undefined,
    barterOfferingType: mode === 'barter' ? barterOfferingType : undefined,
    barterInventoryKind: mode === 'barter' ? barterInventoryKind : undefined,
    barterSelectedItemId: mode === 'barter' ? barterSelectedItemId : undefined,
    barterOfferedUnits: mode === 'barter' ? barterOfferedUnits : undefined,
    sweetenerCoinSymbol: sweetenerCoin && sweetenerAmountUSD > 0 ? sweetenerCoin.symbol : undefined,
    sweetenerCurrencyType: sweetenerCoin && sweetenerAmountUSD > 0 ? sweetenerCoin.currencyType : undefined,
    sweetenerAmountUSD: sweetenerCoin && sweetenerAmountUSD > 0 ? sweetenerAmountUSD : undefined,
    createdAt: new Date().toISOString(),
    status: 'active',
  };

  const nextBidsList = [newBid, ...updatedBids];
  saveAuctionBidsForListing(listing.id, nextBidsList);

  const baseConfig: AuctionConfig = listing.auctionConfig || {
    startingBidUSD: roundedBidUSD,
    minIncrementUSD: 100,
    endTimeIso: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
    bidCount: 0,
    status: 'live',
  };

  let nextEndTimeIso = baseConfig.endTimeIso;
  if (baseConfig.allowAutoExtend && remaining.msRemaining > 0 && remaining.msRemaining < 5 * 60 * 1000) {
    nextEndTimeIso = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  }

  const nextConfig: AuctionConfig = {
    ...baseConfig,
    endTimeIso: nextEndTimeIso,
    highestBidUSD: roundedBidUSD,
    highestBidderId: bidderId,
    highestBidderUid: viewerUid,
    highestBidderName: bidderName,
    highestBidderHandle: bidderHandle.replace(/^@/, ''),
    highestBidMode: mode,
    bidCount: nextBidsList.length,
    status: 'live',
  };

  updateListingAuctionState(listing.id, (curr) => ({
    ...curr,
    primaryPriceUSD: roundedBidUSD,
    auctionConfig: nextConfig,
  }));

  const modeLabel =
    mode === 'barter'
      ? `Barter ($${roundedBidUSD.toLocaleString()} eq.)`
      : `${nativeAmount?.toLocaleString()} ${currencySymbol} ($${roundedBidUSD.toLocaleString()})`;

  enqueueUserNotification([listing.sellerId, sellerHandleClean], {
    title: `🔨 New Auction Bid on "${listing.title}"`,
    description: `${bidderName} (@${bidderHandle.replace(/^@/, '')}) placed a ${modeLabel} bid.`,
    type: 'trade',
    targetTab: 'marketplace',
    targetId: listing.id,
  });

  if (previousLeader && previousLeader.bidderId !== bidderId) {
    enqueueUserNotification([previousLeader.bidderId, previousLeader.bidderUid || '', previousLeader.bidderHandle], {
      title: `⚠️ You Were Outbid on "${listing.title}"`,
      description: `A new highest bid of $${roundedBidUSD.toLocaleString()} USD (${mode === 'barter' ? 'Barter' : currencySymbol}) was placed.`,
      type: 'trade',
      targetTab: 'marketplace',
      targetId: listing.id,
    });
  }

  return { success: true, bid: newBid, updatedConfig: nextConfig };
}

export function acceptAuctionBid(params: {
  sellerId: string;
  sellerName: string;
  listing: TargetListingForTrade;
  bidId: string;
}): DealExecutionResult {
  const { sellerId, listing, bidId } = params;
  const bids = getAuctionBids(listing.id);
  const targetBid = bids.find((b) => b.id === bidId);
  if (!targetBid) {
    return {
      success: false,
      error: 'Selected bid could not be found.',
      settlementMode: 'final_coins',
      amountUSD: 0,
    };
  }

  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') {
    return {
      success: false,
      error: 'This auction has already been settled.',
      settlementMode: targetBid.mode,
      amountUSD: 0,
    };
  }

  const sellerClean = sellerId.replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const ownerClean = (listing.sellerId || '').replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const ownerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (sellerClean !== ownerClean && sellerClean !== ownerHandleClean) {
    return {
      success: false,
      error: 'Only the auction creator can accept and settle bids.',
      settlementMode: targetBid.mode,
      amountUSD: 0,
    };
  }

  let execResult: DealExecutionResult;

  if (targetBid.mode === 'barter') {
    let sweetenerCoinObj: SettlementCoinOption | null = null;
    if (targetBid.sweetenerCurrencyType && targetBid.sweetenerCoinSymbol && (targetBid.sweetenerAmountUSD || 0) > 0) {
      const opts = getCurrencyOptionsForType(
        targetBid.bidderId,
        listing,
        targetBid.sweetenerCurrencyType,
        targetBid.sweetenerAmountUSD
      );
      sweetenerCoinObj = opts.find((c) => c.symbol === targetBid.sweetenerCoinSymbol) || opts[0] || null;
    }

    execResult = executeBarterListingDeal({
      buyerId: targetBid.bidderId,
      buyerUid: targetBid.bidderUid,
      buyerHandle: targetBid.bidderHandle,
      buyerName: targetBid.bidderName,
      listing,
      offeringType: targetBid.barterOfferingType === 'inventory' ? 'inventory' : 'custom',
      inventoryKind: targetBid.barterInventoryKind || 'good',
      selectedGoodId: targetBid.barterInventoryKind === 'good' ? targetBid.barterSelectedItemId : undefined,
      selectedServiceId: targetBid.barterInventoryKind === 'service' ? targetBid.barterSelectedItemId : undefined,
      offeredUnits: targetBid.barterOfferedUnits || 1,
      customOfferText: targetBid.barterOfferDescription || `Winning auction barter bid ($${targetBid.amountUSD.toLocaleString()} USD eq.)`,
      sweetenerCoin: sweetenerCoinObj,
      sweetenerAmountUSD: targetBid.sweetenerAmountUSD || 0,
      sourceOverride: 'auction',
    });
    if (!execResult.success) return execResult;
    enrollAcquiredListingInBuyerInventory(targetBid.bidderId, listing, targetBid.amountUSD);
  } else {
    const opts = getCurrencyOptionsForType(targetBid.bidderId, listing, targetBid.mode, targetBid.amountUSD);
    const chosenCoin =
      opts.find((c) => c.symbol === targetBid.currencySymbol) || opts[0];
    if (!chosenCoin) {
      return {
        success: false,
        error: `Could not resolve currency asset for ${targetBid.mode}.`,
        settlementMode: targetBid.mode,
        amountUSD: 0,
      };
    }

    execResult = executeCurrencyListingDeal({
      buyerId: targetBid.bidderId,
      buyerName: targetBid.bidderName,
      buyerHandle: targetBid.bidderHandle,
      listing,
      coinOption: chosenCoin,
      overrideValuationUSD: targetBid.amountUSD,
      forceMarkSold: true,
    });
    if (!execResult.success) return execResult;
  }

  const nextBids: AuctionBid[] = bids.map((b) =>
    b.id === targetBid.id ? { ...b, status: 'accepted' } : { ...b, status: 'declined' }
  );
  saveAuctionBidsForListing(listing.id, nextBids);

  updateListingAuctionState(listing.id, (curr) => ({
    ...curr,
    status: 'sold',
    buyerId: targetBid.bidderId,
    buyerUid: targetBid.bidderUid,
    buyerName: targetBid.bidderName,
    buyerHandle: targetBid.bidderHandle,
    primaryPriceUSD: targetBid.amountUSD,
    auctionConfig: {
      ...(curr.auctionConfig || {
        startingBidUSD: targetBid.amountUSD,
        minIncrementUSD: 100,
        endTimeIso: new Date().toISOString(),
        bidCount: nextBids.length,
        status: 'settled',
      }),
      highestBidUSD: targetBid.amountUSD,
      highestBidderId: targetBid.bidderId,
      highestBidderName: targetBid.bidderName,
      highestBidderHandle: targetBid.bidderHandle,
      highestBidMode: targetBid.mode,
      bidCount: nextBids.length,
      status: 'settled',
      winningBidId: targetBid.id,
    },
  }));

  enqueueUserNotification([targetBid.bidderId, targetBid.bidderUid || '', targetBid.bidderHandle], {
    title: `🏆 You Won the Auction: "${listing.title}"`,
    description: `Your ${targetBid.mode === 'barter' ? 'Barter' : targetBid.currencySymbol} bid of $${targetBid.amountUSD.toLocaleString()} USD was accepted and settled!`,
    type: 'trade',
    targetTab: 'marketplace',
    targetId: listing.id,
  });

  return {
    ...execResult,
    markedSold: true,
    amountUSD: targetBid.amountUSD,
  };
}

export function buyNowAuctionListing(params: {
  buyerId: string;
  buyerName: string;
  buyerHandle?: string;
  listing: TargetListingForTrade;
  mode: SettlementMethod;
  coinOption?: SettlementCoinOption | null;
  barterOfferingType?: 'inventory' | 'custom';
  barterInventoryKind?: 'good' | 'service';
  barterSelectedItemId?: string;
  barterOfferedUnits?: number;
  barterCustomOfferText?: string;
  sweetenerCoin?: SettlementCoinOption | null;
  sweetenerAmountUSD?: number;
}): DealExecutionResult {
  const { buyerId, buyerName, buyerHandle, listing, mode } = params;
  const buyNowUSD = Number(listing.auctionConfig?.buyNowPriceUSD || 0);
  if (buyNowUSD <= 0) {
    return {
      success: false,
      error: 'Instant Buy Now price is not enabled for this auction.',
      settlementMode: mode,
      amountUSD: 0,
    };
  }

  let res: DealExecutionResult;
  if (mode === 'barter') {
    res = executeBarterListingDeal({
      buyerId,
      buyerHandle,
      buyerName,
      listing,
      offeringType: params.barterOfferingType || 'custom',
      inventoryKind: params.barterInventoryKind || 'good',
      selectedGoodId: params.barterSelectedItemId,
      selectedServiceId: params.barterSelectedItemId,
      offeredUnits: params.barterOfferedUnits || 1,
      customOfferText: params.barterCustomOfferText || `Instant Buy Now Barter ($${buyNowUSD.toLocaleString()} USD)`,
      sweetenerCoin: params.sweetenerCoin,
      sweetenerAmountUSD: params.sweetenerAmountUSD || 0,
      sourceOverride: 'auction',
    });
    if (!res.success) return res;
    enrollAcquiredListingInBuyerInventory(buyerId, listing, buyNowUSD);
  } else {
    if (!params.coinOption) {
      return {
        success: false,
        error: 'Please select a valid payment asset for Buy Now settlement.',
        settlementMode: mode,
        amountUSD: 0,
      };
    }
    res = executeCurrencyListingDeal({
      buyerId,
      buyerName,
      buyerHandle,
      listing,
      coinOption: params.coinOption,
      overrideValuationUSD: buyNowUSD,
      forceMarkSold: true,
    });
    if (!res.success) return res;
  }

  const existingBids = getAuctionBids(listing.id);
  if (existingBids.length > 0) {
    saveAuctionBidsForListing(
      listing.id,
      existingBids.map((b) => ({ ...b, status: 'declined' }))
    );
  }

  updateListingAuctionState(listing.id, (curr) => ({
    ...curr,
    status: 'sold',
    buyerId,
    buyerName,
    buyerHandle: buyerHandle?.replace(/^@/, '') || buyerId,
    primaryPriceUSD: buyNowUSD,
    auctionConfig: {
      ...(curr.auctionConfig || {
        startingBidUSD: buyNowUSD,
        minIncrementUSD: 100,
        endTimeIso: new Date().toISOString(),
        bidCount: existingBids.length,
        status: 'settled',
      }),
      highestBidUSD: buyNowUSD,
      highestBidderId: buyerId,
      highestBidderName: buyerName,
      highestBidderHandle: buyerHandle?.replace(/^@/, '') || buyerId,
      highestBidMode: mode,
      status: 'settled',
    },
  }));

  enqueueUserNotification([listing.sellerId, listing.sellerHandle || ''], {
    title: `⚡ Auction Sold via Buy Now: "${listing.title}"`,
    description: `${buyerName} executed Instant Buy Now at $${buyNowUSD.toLocaleString()} USD.`,
    type: 'trade',
    targetTab: 'marketplace',
    targetId: listing.id,
  });

  return {
    ...res,
    markedSold: true,
    amountUSD: buyNowUSD,
  };
}
