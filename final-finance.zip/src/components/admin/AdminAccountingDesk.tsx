import React, { useState, useEffect } from 'react';
import { Search, Users, Coins } from 'lucide-react';
import { getStoredUserWallets } from '../../data/defaultWallets';
import { getUserProfile } from '../../services/socialService';

interface AccountingUser {
  id: string;
  name: string;
  handle: string;
  avatarUrl?: string;
}

const MOCK_USERS_BASIC: { id: string; name: string; handle: string }[] = [
  { id: 'demo-jordan-belfort', name: 'Jordan Belfort', handle: '@jordan_belfort' },
  { id: 'demo-satoshi-nakamoto', name: 'Satoshi Nakamoto', handle: '@satoshi_nakamoto' },
  { id: 'demo-alex-morgan', name: 'Alex Morgan', handle: '@alex_morgan' },
];

interface AdminAccountingDeskProps {
  onViewProfile: (userId: string) => void;
}

export const AdminAccountingDesk: React.FC<AdminAccountingDeskProps> = ({ onViewProfile }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<AccountingUser[]>([]);

  useEffect(() => {
    async function loadUsers() {
      const fullUsers = await Promise.all(
        MOCK_USERS_BASIC.map(async (u) => {
          const profile = await getUserProfile(u.id);
          return {
            ...u,
            avatarUrl: profile?.avatarUrl,
          };
        })
      );
      setUsers(fullUsers);
    }
    loadUsers();
  }, []);

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.handle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getUserBalances = (userId: string) => {
    const wallets = getStoredUserWallets(userId);
    return {
      final: wallets.finalCoins.reduce((sum, c) => sum + c.balance, 0),
    };
  };

  const totalCirculatingFinalCoins = users.reduce((sum, u) => sum + getUserBalances(u.id).final, 0);

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-serif text-xl font-bold text-slate-900">System Accounting Ledger</h2>
          <p className="text-sm text-slate-500">
            Total Final Admin Coins in Circulation: <span className="font-bold text-amber-700">{totalCirculatingFinalCoins.toLocaleString()}</span>
          </p>
        </div>
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search users..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-64"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-slate-500 uppercase bg-slate-50/50">
            <tr>
              <th className="px-6 py-4">User</th>
              <th className="px-6 py-4 text-right">Final Admin Coins</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredUsers.map(user => {
              const balances = getUserBalances(user.id);
              return (
                <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {user.avatarUrl ? (
                        <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full object-cover" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                          <Users className="w-4 h-4" />
                        </div>
                      )}
                      <div>
                        <button 
                          onClick={() => onViewProfile(user.id)}
                          className="font-bold text-slate-900 hover:text-blue-600 transition-colors"
                        >
                          {user.name}
                        </button>
                        <div className="text-xs text-slate-400">{user.handle}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono font-medium text-amber-700">{balances.final.toLocaleString()}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
