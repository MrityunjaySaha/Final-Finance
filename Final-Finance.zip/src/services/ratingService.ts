export interface Review {
  id: string;
  targetUserId: string; // The user being rated (uid or handle)
  reviewerId: string;   // The user leaving the review (uid or handle)
  reviewerUid?: string; // Optional secondary UID to prevent duplicates across handle/uid
  reviewerName: string;
  reviewerAvatar?: string;
  rating: number;       // 1-5
  comment: string;
  timestamp: number;
  updatedAt?: number;
}

const STORAGE_KEY = 'ff_user_ratings';

function normId(val?: string): string {
  return String(val || '').replace(/^@/, '').trim().toLowerCase();
}

function isSameReviewer(r: Review, reviewerIds: (string | undefined)[]): boolean {
  const cleanInputs = reviewerIds.map(normId).filter(Boolean);
  if (cleanInputs.length === 0) return false;
  const rId = normId(r.reviewerId);
  const rUid = normId(r.reviewerUid);
  return cleanInputs.includes(rId) || (rUid.length > 0 && cleanInputs.includes(rUid));
}

function loadAllRatings(): Review[] {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error('Error parsing ratings', e);
    return [];
  }
}

export const getRatingsForUser = (userId: string): Review[] => {
  const cleanTarget = normId(userId);
  const allRatings = loadAllRatings().filter((r) => normId(r.targetUserId) === cleanTarget);

  // Deduplicate by reviewer keeping the most recent entry in case legacy duplicates exist
  const dedupedByReviewer = new Map<string, Review>();
  const sortedNewestFirst = [...allRatings].sort((a, b) => (b.updatedAt || b.timestamp) - (a.updatedAt || a.timestamp));
  sortedNewestFirst.forEach((rev) => {
    const key = normId(rev.reviewerId) || normId(rev.reviewerUid) || rev.id;
    if (!dedupedByReviewer.has(key)) {
      dedupedByReviewer.set(key, rev);
    }
  });

  return Array.from(dedupedByReviewer.values()).sort(
    (a, b) => (b.updatedAt || b.timestamp) - (a.updatedAt || a.timestamp)
  );
};

export const getExistingReviewByReviewer = (
  targetUserId: string,
  reviewerIds: (string | undefined)[]
): Review | null => {
  const ratings = getRatingsForUser(targetUserId);
  return ratings.find((r) => isSameReviewer(r, reviewerIds)) || null;
};

export const addReview = (
  review: Omit<Review, 'id' | 'timestamp' | 'updatedAt'>
): { review: Review; isUpdate: boolean } => {
  const allRatings = loadAllRatings();
  const cleanTarget = normId(review.targetUserId);
  const reviewerKeys = [review.reviewerId, review.reviewerUid];
  const now = Date.now();

  const existingIndices: number[] = [];
  allRatings.forEach((r, idx) => {
    if (normId(r.targetUserId) === cleanTarget && isSameReviewer(r, reviewerKeys)) {
      existingIndices.push(idx);
    }
  });

  if (existingIndices.length > 0) {
    const primaryExisting = allRatings[existingIndices[0]];
    const updatedReview: Review = {
      ...primaryExisting,
      targetUserId: review.targetUserId,
      reviewerId: review.reviewerId,
      reviewerUid: review.reviewerUid || primaryExisting.reviewerUid,
      reviewerName: review.reviewerName,
      reviewerAvatar: review.reviewerAvatar,
      rating: review.rating,
      comment: review.comment,
      updatedAt: now,
    };

    // Remove any duplicate entries by this same reviewer for this target and store the single updated review
    const cleaned = allRatings.filter((_, idx) => !existingIndices.includes(idx));
    cleaned.unshift(updatedReview);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cleaned));
    return { review: updatedReview, isUpdate: true };
  }

  const newReview: Review = {
    ...review,
    id: `rev-${now}-${Math.random().toString(36).substr(2, 9)}`,
    timestamp: now,
  };

  allRatings.push(newReview);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(allRatings));
  return { review: newReview, isUpdate: false };
};

export const getAverageRating = (userId: string): { average: number; count: number } => {
  const ratings = getRatingsForUser(userId);
  if (ratings.length === 0) return { average: 0, count: 0 };
  const sum = ratings.reduce((acc, r) => acc + r.rating, 0);
  return {
    average: parseFloat((sum / ratings.length).toFixed(1)),
    count: ratings.length,
  };
};
