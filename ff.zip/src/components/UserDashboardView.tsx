import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldCheck, 
  Coins, 
  Repeat, 
  ArrowRight, 
  TrendingUp, 
  CheckCircle2, 
  Banknote, 
  Binary, 
  Plus, 
  Building2, 
  Package, 
  Wallet, 
  Layers, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CreditCard, 
  AlertTriangle, 
  Receipt, 
  History, 
  DollarSign, 
  TrendingDown, 
  BarChart3, 
  Sparkles, 
  Zap, 
  Check, 
  Compass,
  Briefcase,
  Star,
  ExternalLink,
  SlidersHorizontal,
  Archive,
  PieChart,
  Scale,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AuthSession } from '../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { ReserveVault, AssetClass, VaultAsset } from '../types';
import { UserWalletData, BarterGoodItem, BarterServiceItem } from '../types/wallet';
import { StockItem, StockOrder, StockPosition } from '../types/stocks';
import { INITIAL_STOCKS, INITIAL_USER_STOCK_POSITIONS } from '../data/stocksData';
import { 
  getStoredStockPositions, 
  saveStoredStockPositions, 
  getStoredStockOrders, 
  saveStoredStockOrders 
} from '../utils/stockWalletBridge';
import { getAllLoans, LoanRecord } from '../services/loanService';
import { WalletsPage } from './WalletsPage';
import { PortfolioPage } from './PortfolioPage';
import { AssetInventoryPage } from './AssetInventoryPage';
import { QuickBuyStockModal } from './stocks/QuickBuyStockModal';
import { TradeConfirmationModal } from './stocks/TradeConfirmationModal';
import { AccountDepositModal } from './dashboard/AccountDepositModal';
import { AccountPayModal } from './dashboard/AccountPayModal';
import { BankWithdrawModal } from './dashboard/BankWithdrawModal';
import { UniversalLedgerView } from './dashboard/UniversalLedgerView';
import { UniversalLedgerItem } from '../types/ledger';
import { 
  getStoredLedgerTransactions, 
  saveStoredLedgerTransactions, 
  recordLedgerTransaction, 
  createLedgerItemFromStockOrder, 
  createLedgerItemFromDeposit, 
  createLedgerItemFromWithdrawal,
  syncStoredPosOrdersToLedger,
  syncStoredRideShareToLedger,
  normalizeLedgerItem,
  LEDGER_UPDATED_EVENT 
} from '../utils/universalLedgerBridge';
import {
  getPortfolioTabSnapshot,
  isRestoreProfileReturnActive,
  updatePortfolioTabSnapshot
} from '../utils/profileReturnState';

interface UserDashboardViewProps {
  currentUser?: AuthSession | null;
  initialActiveTab?: 'overview' | 'vaults' | 'wallets' | 'portfolio' | 'asset_inventory';
  onOpenNewListing: () => void;
  onOpenInstantSwap?: () => void;
  onOpenBarterModal: (listing?: any) => void;
  onOpenDepositModal: (vault?: any) => void;
  onOpenVoiceCallDesk: () => void;
  onViewPlatformOverview?: () => void;
  onOpenVerificationModal?: () => void;
  onSelectStock?: (stock: StockItem) => void;
  onQuickBuyStock?: (stock: StockItem) => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  currentUser,
  initialActiveTab = 'overview',
  onOpenNewListing,
  onOpenInstantSwap,
  onOpenBarterModal,
  onOpenDepositModal,
  onOpenVoiceCallDesk,
  onViewPlatformOverview,
  onOpenVerificationModal,
  onSelectStock,
  onQuickBuyStock,
}) => {
  const { vaults = [], setCurrentTab, transactions: globalTransactions, setPreviousTab, addNotification } = useApp();
  const userId = currentUser?.id || currentUser?.uid || 'guest';
  
  // Tab within Combined Dashboard: 'overview' | 'portfolio' | 'wallets' | 'fiat' | 'stable' | 'final' | 'crypto' | 'barter'
  const [activeTab, setActiveTab] = useState<'overview' | 'portfolio' | 'wallets' | 'fiat' | 'stable' | 'final' | 'crypto' | 'barter'>(() => {
    if (isRestoreProfileReturnActive()) {
      const saved = getPortfolioTabSnapshot().dashboardTab;
      if (
        saved === 'overview' ||
        saved === 'portfolio' ||
        saved === 'wallets' ||
        saved === 'fiat' ||
        saved === 'stable' ||
        saved === 'final' ||
        saved === 'crypto' ||
        saved === 'barter'
      ) {
        return saved;
      }
    }
    if (initialActiveTab === 'portfolio') return 'portfolio';
    if (initialActiveTab === 'wallets') return 'wallets';
    return 'overview';
  });

  useEffect(() => {
    updatePortfolioTabSnapshot({ dashboardTab: activeTab });
  }, [activeTab]);
  const [inventoryTab, setInventoryTab] = useState<any>('overview');

  // Horizontal tabs within Dashboard Overview: 'inventory' | 'ledger'
  const [dashboardSectionTab, setDashboardSectionTab] = useState<'inventory' | 'ledger'>(() => {
    try {
      if (sessionStorage.getItem('final_finance_open_ledger_tab') === '1') {
        sessionStorage.removeItem('final_finance_open_ledger_tab');
        return 'ledger';
      }
    } catch {}
    return 'inventory';
  });

  useEffect(() => {
    if (initialActiveTab === 'portfolio') {
      setActiveTab('portfolio');
    } else if (initialActiveTab === 'wallets') {
      setActiveTab('wallets');
    } else if (initialActiveTab === 'overview') {
      setActiveTab('overview');
    }
  }, [initialActiveTab]);

  useEffect(() => {
    const openLedger = () => {
      setActiveTab('overview');
      setDashboardSectionTab('ledger');
      try { sessionStorage.removeItem('final_finance_open_ledger_tab'); } catch {}
    };
    window.addEventListener('final_finance_open_ledger_tab', openLedger);
    syncStoredPosOrdersToLedger(userId);
    syncStoredRideShareToLedger(userId);
    return () => window.removeEventListener('final_finance_open_ledger_tab', openLedger);
  }, [userId]);

  // Wallet data state
  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(userId));

  // Stocks & Equities Portfolio state
  const [stocks, setStocks] = useState<StockItem[]>(INITIAL_STOCKS);
  const [positions, setPositions] = useState<StockPosition[]>(() =>
    getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS)
  );
  const [orders, setOrders] = useState<StockOrder[]>(() =>
    getStoredStockOrders(userId)
  );
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_watchlist_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return ['ALEX', 'HYPR', 'AFNL-EQ', 'BSYN', 'VLT-YLD', 'NEXA', 'SOLN', 'ELEN', 'QBIT', 'HASH-M', 'REAL-STBL'];
  });

  // Portfolio Subtab filter: 'all' | 'invested' | 'following'
  const [portfolioSubTab, setPortfolioSubTab] = useState<'all' | 'invested' | 'following'>('all');

  // Trade modals state
  const [quickTradeStock, setQuickTradeStock] = useState<StockItem | null>(null);
  const [quickTradeSide, setQuickTradeSide] = useState<'buy' | 'sell'>('buy');
  const [isTradeConfirmationOpen, setIsTradeConfirmationOpen] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<StockOrder | null>(null);

  // Modals
  const [isAccountDepositOpen, setIsAccountDepositOpen] = useState(false);
  const [isAccountPayOpen, setIsAccountPayOpen] = useState(false);
  const [isBankWithdrawOpen, setIsBankWithdrawOpen] = useState(false);

  // Outstanding Debt state (allows dynamic tracking & testing)
  const [outstandingDebt, setOutstandingDebt] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`final_debt_${userId}`);
      if (saved !== null) return parseFloat(saved);
    } catch {
      // fallback
    }
    return 140621.03; // Default liability ($140,621.03)
  });

  const saveDebt = (amount: number) => {
    setOutstandingDebt(amount);
    try {
      localStorage.setItem(`final_debt_${userId}`, amount.toString());
      window.dispatchEvent(new CustomEvent('final_debt_updated', { detail: { debt: amount } }));
    } catch (err) {
      console.warn('Failed to save debt', err);
    }
  };

  // Loans from loanService
  const [loansVersion, setLoansVersion] = useState(0);
  const allLoans = useMemo(() => getAllLoans(), [loansVersion]);

  const activeBorrowedLoans = useMemo(() => {
    return allLoans.filter(l => 
      (l.borrowerId === userId || l.borrowerHandle === `@${userId}`) && l.status === 'active'
    );
  }, [allLoans, userId]);

  const activeLentLoans = useMemo(() => {
    return allLoans.filter(l => 
      (l.lenderId === userId || l.lenderHandle === `@${userId}`) && l.status === 'active'
    );
  }, [allLoans, userId]);

  const borrowedLoansUSD = useMemo(() => {
    return activeBorrowedLoans.reduce((sum, l) => sum + (l.coinSymbol === 'AFNL' ? 0 : l.amount), 0);
  }, [activeBorrowedLoans]);

  const lentLoansUSD = useMemo(() => {
    return activeLentLoans.reduce((sum, l) => sum + (l.coinSymbol === 'AFNL' ? 0 : l.amount), 0);
  }, [activeLentLoans]);

  // Toast
  const [toastMessage, setToastMessage] = useState('');
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  // Universal Ledger & Tax Receipts State with real-time sync
  const [ledgerVersion, setLedgerVersion] = useState(0);
  const ledgerTransactions = useMemo(() => {
    const userSpecific = getStoredLedgerTransactions(userId);
    const seenIds = new Set<string>();
    const combined: UniversalLedgerItem[] = [];

    userSpecific.forEach((item) => {
      if (!seenIds.has(item.id)) {
        seenIds.add(item.id);
        combined.push(item);
      }
    });

    (globalTransactions || []).forEach((item) => {
      const normalized = normalizeLedgerItem(item);
      if (!seenIds.has(normalized.id)) {
        seenIds.add(normalized.id);
        combined.push(normalized);
      }
    });

    return combined.sort((a, b) => {
      const timeA = new Date(a.dateIso || a.timestamp).getTime() || 0;
      const timeB = new Date(b.dateIso || b.timestamp).getTime() || 0;
      return timeB - timeA;
    });
  }, [globalTransactions, userId, ledgerVersion]);

  // Sync wallet, stock, loan, debt & ledger changes
  useEffect(() => {
    const refreshData = () => {
      setWalletData(getStoredUserWallets(userId));
      setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
      setOrders(getStoredStockOrders(userId));
      setLedgerVersion((v) => v + 1);
      setLoansVersion((v) => v + 1);
    };

    const handleDebtUpdate = (e: any) => {
      if (e.detail?.debt !== undefined) {
        setOutstandingDebt(Number(e.detail.debt));
      } else {
        try {
          const saved = localStorage.getItem(`final_debt_${userId}`);
          if (saved !== null) setOutstandingDebt(parseFloat(saved));
        } catch {}
      }
    };

    const handleLoansUpdate = () => {
      setLoansVersion((v) => v + 1);
    };

    window.addEventListener('final_finance_wallets_updated', refreshData);
    window.addEventListener('final_finance_stock_positions_updated', refreshData);
    window.addEventListener('final_finance_ledger_updated', refreshData);
    window.addEventListener('final_finance_global_transactions_updated', refreshData);
    window.addEventListener('final_debt_updated', handleDebtUpdate);
    window.addEventListener('final_finance_loans_updated', handleLoansUpdate);
    window.addEventListener('final_finance_listings_updated', refreshData);
    window.addEventListener('storage', refreshData);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', refreshData);
      window.removeEventListener('final_finance_stock_positions_updated', refreshData);
      window.removeEventListener('final_finance_ledger_updated', refreshData);
      window.removeEventListener('final_finance_global_transactions_updated', refreshData);
      window.removeEventListener('final_debt_updated', handleDebtUpdate);
      window.removeEventListener('final_finance_loans_updated', handleLoansUpdate);
      window.removeEventListener('final_finance_listings_updated', refreshData);
      window.removeEventListener('storage', refreshData);
    };
  }, [userId]);

  // Handle Watchlist toggle
  const handleToggleWatchlist = (ticker: string) => {
    setWatchlist((prev) => {
      const next = prev.includes(ticker)
        ? prev.filter((t) => t !== ticker)
        : [...prev, ticker];
      try {
        localStorage.setItem(`final_finance_watchlist_${userId}`, JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Handle opening quick trade modal from portfolio
  const handleOpenTradeModal = (tickerOrStock: string | StockItem, side: 'buy' | 'sell' = 'buy') => {
    let targetStock: StockItem | undefined;
    if (typeof tickerOrStock === 'string') {
      targetStock = stocks.find((s) => s.ticker === tickerOrStock);
      if (!targetStock) {
        // synthesize fallback
        const pos = positions.find((p) => p.ticker === tickerOrStock);
        if (pos) {
          targetStock = {
            ticker: pos.ticker,
            name: pos.name,
            price: pos.currentPriceUSD,
            changeUSD: 2.5,
            changePercent: 1.2,
            high24h: pos.currentPriceUSD * 1.02,
            low24h: pos.currentPriceUSD * 0.98,
            openPrice: pos.currentPriceUSD * 0.99,
            prevClose: pos.currentPriceUSD * 0.988,
            volume: '15.2M',
            avgVolume: '18.0M',
            marketCap: '$1.2T',
            peRatio: 28.5,
            eps: 4.8,
            dividendYield: pos.dividendYield || '0.5%',
            beta: 1.1,
            fiftyTwoWeekHigh: pos.currentPriceUSD * 1.25,
            fiftyTwoWeekLow: pos.currentPriceUSD * 0.75,
            marketType: 'fiat',
            settlementMethod: 'USD Fiat & Reserve Vault Clearing',
            sector: pos.sector,
            subSector: 'Active Equity Holding',
            description: `${pos.name} held position.`,
            exchange: 'NASDAQ',
            analystRating: 'Buy',
            analystTargetUSD: pos.currentPriceUSD * 1.15,
            analystCount: 15,
            sparkline: [pos.avgCostUSD, pos.currentPriceUSD],
            history: { '1D': [], '1W': [], '1M': [], '1Y': [], '5Y': [] }
          };
        }
      }
    } else {
      targetStock = tickerOrStock;
    }

    if (targetStock) {
      setQuickTradeStock(targetStock);
      setQuickTradeSide(side);
    }
  };

  // Handle executing an order
  const handleOrderExecuted = (newOrder: StockOrder) => {
    // 1. Update orders list
    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    saveStoredStockOrders(userId, updatedOrders);

    // 2. Update positions
    let updatedPositions: StockPosition[];
    const existingIndex = positions.findIndex((p) => p.ticker === newOrder.ticker);

    if (newOrder.side === 'buy') {
      if (existingIndex !== -1) {
        const existing = positions[existingIndex];
        const newShares = existing.shares + newOrder.shares;
        const newCostBasis = existing.shares * existing.avgCostUSD + newOrder.totalUSD;
        const newAvgCost = newCostBasis / newShares;
        const newTotalVal = newShares * newOrder.price;
        const newGainUSD = newTotalVal - newCostBasis;
        const newGainPct = newCostBasis > 0 ? (newGainUSD / newCostBasis) * 100 : 0;

        updatedPositions = positions.map((p, idx) =>
          idx === existingIndex
            ? {
                ...p,
                shares: newShares,
                avgCostUSD: Number(newAvgCost.toFixed(2)),
                currentPriceUSD: newOrder.price,
                totalValueUSD: Number(newTotalVal.toFixed(2)),
                totalGainUSD: Number(newGainUSD.toFixed(2)),
                totalGainPercent: Number(newGainPct.toFixed(2)),
                lastPurchasedDate: new Date().toISOString().slice(0, 10),
              }
            : p
        );
      } else {
        const newPos: StockPosition = {
          ticker: newOrder.ticker,
          name: newOrder.stockName,
          shares: newOrder.shares,
          avgCostUSD: newOrder.price,
          currentPriceUSD: newOrder.price,
          totalValueUSD: newOrder.totalUSD,
          totalGainUSD: 0,
          totalGainPercent: 0,
          dailyGainUSD: 0,
          sector: newOrder.sector || 'Technology & AI',
          dividendYield: '0.50%',
          initialBoughtDate: new Date().toISOString().slice(0, 10),
          lastPurchasedDate: new Date().toISOString().slice(0, 10),
          primaryFundingSourceLabel: newOrder.paymentSource?.label || 'Primary Cash Reserve'
        };
        updatedPositions = [newPos, ...positions];
      }
    } else {
      // Sell order
      if (existingIndex !== -1) {
        const existing = positions[existingIndex];
        const remainingShares = Math.max(0, existing.shares - newOrder.shares);
        if (remainingShares === 0) {
          updatedPositions = positions.filter((p) => p.ticker !== newOrder.ticker);
        } else {
          const costBasis = remainingShares * existing.avgCostUSD;
          const totalVal = remainingShares * newOrder.price;
          const gainUSD = totalVal - costBasis;
          const gainPct = costBasis > 0 ? (gainUSD / costBasis) * 100 : 0;

          updatedPositions = positions.map((p, idx) =>
            idx === existingIndex
              ? {
                  ...p,
                  shares: remainingShares,
                  currentPriceUSD: newOrder.price,
                  totalValueUSD: Number(totalVal.toFixed(2)),
                  totalGainUSD: Number(gainUSD.toFixed(2)),
                  totalGainPercent: Number(gainPct.toFixed(2)),
                }
              : p
          );
        }
      } else {
        updatedPositions = positions;
      }
    }

    setPositions(updatedPositions);
    saveStoredStockPositions(userId, updatedPositions);

    // Refresh wallet
    setWalletData(getStoredUserWallets(userId));

    // Record in Universal Ledger
    try {
      const stockInfo = INITIAL_STOCKS.find((s) => s.ticker === newOrder.ticker);
      const ledgerItem = createLedgerItemFromStockOrder(newOrder, stockInfo);
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record stock order to ledger', e);
    }

    // Show Confirmation Receipt Modal
    setConfirmedOrder(newOrder);
    setIsTradeConfirmationOpen(true);
    setQuickTradeStock(null);
    showToast(`Order executed: ${newOrder.side.toUpperCase()} ${newOrder.shares} ${newOrder.ticker} ($${newOrder.totalUSD.toLocaleString()})`);
    addNotification({
      title: `${newOrder.side === 'buy' ? '📈 Buy Order Executed' : '📉 Sell Order Executed'}: ${newOrder.shares} ${newOrder.ticker}`,
      description: `${newOrder.side === 'buy' ? 'Purchased' : 'Sold'} ${newOrder.shares} shares of ${newOrder.stockName} for $${newOrder.totalUSD.toLocaleString()}.`,
      type: 'stocks',
      targetTab: 'stocks',
      targetId: newOrder.ticker,
      amount: newOrder.totalUSD,
      showToast: false,
    });
  };

  // Primary Account Liquid Cash Balance (total fiat cash across all reserve bank accounts)
  const primaryCashBalance = walletData.fiatCurrencies.reduce((s, f) => s + f.balance * f.exchangeRateToUSD, 0);

  // Handle deposit into trading account
  const handleAccountDeposit = (amount: number, sourceLabel: string) => {
    const newBalance = primaryCashBalance + amount;
    const updatedFiat = [...walletData.fiatCurrencies];
    if (updatedFiat.length > 0) {
      updatedFiat[0] = { ...updatedFiat[0], balance: newBalance };
    } else {
      updatedFiat.push({
        id: 'fiat-usd',
        name: 'US Dollar (Reserve Cash)',
        code: 'USD',
        symbol: '$',
        balance: newBalance,
        exchangeRateToUSD: 1.0,
        accountType: 'Checking',
        institution: 'JPMorgan Chase Prime'
      });
    }

    const updatedData: UserWalletData = {
      ...walletData,
      fiatCurrencies: updatedFiat
    };

    setWalletData(updatedData);
    saveStoredUserWallets(userId, updatedData);

    // Record in Universal Ledger
    try {
      const ledgerItem = createLedgerItemFromDeposit(amount, sourceLabel, 'fiat');
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record deposit in ledger', e);
    }

    showToast(`Successfully deposited $${amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} into your account.`);
    addNotification({
      title: 'Cash Deposit Confirmed',
      description: `Deposited $${amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} USD via ${sourceLabel}.`,
      type: 'wallet',
      targetTab: 'dashboard',
      amount,
      currency: 'USD',
      showToast: false,
    });
  };

  // Handle deposit into external bank account (Withdrawal)
  const handleBankDeposit = (amount: number, bankLabel: string, methodType: 'ach' | 'wire' | 'instant') => {
    if (amount > primaryCashBalance) {
      showToast('Insufficient funds to transfer to bank.');
      return;
    }

    const newBalance = primaryCashBalance - amount;
    const updatedFiat = [...walletData.fiatCurrencies];
    if (updatedFiat.length > 0) {
      updatedFiat[0] = { ...updatedFiat[0], balance: newBalance };
    }

    const updatedData: UserWalletData = {
      ...walletData,
      fiatCurrencies: updatedFiat
    };

    setWalletData(updatedData);
    saveStoredUserWallets(userId, updatedData);

    // Record in Universal Ledger
    try {
      const ledgerItem = createLedgerItemFromWithdrawal(amount, bankLabel, methodType);
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record withdrawal in ledger', e);
    }

    showToast(`Successfully deposited $${amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} into ${bankLabel}.`);
    addNotification({
      title: 'Bank Transfer Dispatched',
      description: `Transferred $${amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} USD to ${bankLabel} via ${methodType.toUpperCase()}.`,
      type: 'wallet',
      targetTab: 'dashboard',
      amount,
      currency: 'USD',
      showToast: false,
    });
  };

  // Handle paying off owed balance
  const handleAccountPayment = (paymentAmount: number, sourceLabel: string) => {
    const newDebt = Math.max(0, outstandingDebt - paymentAmount);
    saveDebt(newDebt);

    if (primaryCashBalance < 0) {
      const newCash = primaryCashBalance + paymentAmount;
      const updatedFiat = [...walletData.fiatCurrencies];
      if (updatedFiat.length > 0) {
        updatedFiat[0] = { ...updatedFiat[0], balance: newCash };
      }
      const updatedData: UserWalletData = { ...walletData, fiatCurrencies: updatedFiat };
      setWalletData(updatedData);
      saveStoredUserWallets(userId, updatedData);
    }

    // Record in Universal Ledger
    try {
      const now = new Date();
      const randomHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      const ledgerItem: UniversalLedgerItem = {
        id: `tx-settle-${Date.now()}`,
        receiptNumber: `REC-${now.getFullYear()}-ST-${Math.floor(100000 + Math.random() * 900000)}`,
        timestamp: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} UTC`,
        dateIso: now.toISOString(),
        type: 'payment_settlement',
        category: 'money_outflow',
        mode: 'fiat',
        title: 'Settlement & Debt Obligation Payment',
        description: `Settled outstanding debt liability against account vault using ${sourceLabel}`,
        amountUSD: paymentAmount,
        feeUSD: 0.00,
        netAmountUSD: paymentAmount,
        sourceOrDestination: sourceLabel,
        counterpartyOrIssuer: 'Sovereign Clearing Node Corp',
        status: 'Audited',
        taxYear: now.getFullYear(),
        taxClassification: {
          taxableEvent: false,
          taxableAmountUSD: 0,
          formMapping: 'Non-Taxable Transfer',
          holdingPeriod: 'N/A',
          irsCategoryNote: 'Repayment of principal obligation and settlement liabilities. Not taxable income.'
        },
        cryptographicHash: `0x${randomHex}`,
        clearingNode: 'Node #4810-CH',
        signature: `SIG_${Math.floor(100000 + Math.random() * 900000)}_ECDSA`
      };
      recordLedgerTransaction(userId, ledgerItem);
      addNotification({
        title: 'Debt Settled',
        description: `Successfully settled $${paymentAmount.toLocaleString()} against your account deficit using ${sourceLabel}.`,
        type: 'vault',
        targetTab: 'dashboard',
      });
    } catch (e) {
      console.warn('Failed to record payment in ledger', e);
    }

    showToast(`Payment of $${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} authorized. Debt successfully settled!`);
  };

  // Test Toggles for Debt simulation
  const handleSimulateDebt = (targetOwed: number = 1450) => {
    saveDebt(targetOwed);
    showToast(`Account updated: Outstanding debt set to $${targetOwed.toLocaleString()} for testing payment flow.`);
  };

  const handleClearDebt = () => {
    saveDebt(0);
    showToast('Outstanding debt cleared. Account is in 100% good standing.');
  };

  // Portfolio aggregates (excluding non-convertible Final Coins for USD pricing)
  const finalCoinsVal = 0; // Pure sovereign protocol standard
  const stableCoinsVal = walletData.stableCoins.reduce((s, st) => s + st.balance * st.unitPriceUSD, 0);
  const fiatVal = walletData.fiatCurrencies.reduce((s, f) => s + f.balance * f.exchangeRateToUSD, 0);
  const cryptoVal = walletData.cryptoCurrencies.reduce((s, cr) => s + cr.balance * cr.unitPriceUSD, 0);
  const stocksVal = positions.reduce((s, p) => {
    const stk = stocks.find(st => st.ticker === p.ticker);
    return s + p.shares * (stk ? stk.price : p.avgCostUSD);
  }, 0);
  const barterGoodsVal = (walletData.barterGoods || []).reduce((s, g) => s + (g.quantity * (g.estimatedUnitValue || 0)), 0);

  // Total Priced Capital across the 5 asset classes
  const totalPricedCapital = stableCoinsVal + fiatVal + cryptoVal + stocksVal + barterGoodsVal;

  // Gross Assets (Capital + Active Lent Loans Receivable)
  const totalGrossAssets = totalPricedCapital + lentLoansUSD;

  // Total Gross Liabilities (Account Debt + Active Borrowed Loans + Cash Overdraft)
  const totalGrossLiabilities = outstandingDebt + borrowedLoansUSD + (primaryCashBalance < 0 ? Math.abs(primaryCashBalance) : 0);

  // Net Asset Value (NAV / Net Worth)
  const netWorth = totalGrossAssets - totalGrossLiabilities;

  // Institutional Solvency & Adequacy Ratios
  const reserveAdequacyRatio = totalGrossLiabilities > 0 ? (totalGrossAssets / totalGrossLiabilities) * 100 : 999;
  const debtToEquityRatio = netWorth > 0 ? (totalGrossLiabilities / netWorth) * 100 : 0;
  const liquidCapital = primaryCashBalance + stableCoinsVal;

  // Capital Allocation Percentages
  const stockPct = totalPricedCapital > 0 ? (stocksVal / totalPricedCapital) * 100 : 0;
  const cryptoPct = totalPricedCapital > 0 ? (cryptoVal / totalPricedCapital) * 100 : 0;
  const fiatPct = totalPricedCapital > 0 ? (fiatVal / totalPricedCapital) * 100 : 0;
  const stablePct = totalPricedCapital > 0 ? (stableCoinsVal / totalPricedCapital) * 100 : 0;
  const barterPct = totalPricedCapital > 0 ? (barterGoodsVal / totalPricedCapital) * 100 : 0;

  // Counts & Units
  const totalBarterGoodsCount = (walletData.barterGoods || []).reduce((sum, g) => sum + g.quantity, 0);
  const totalBarterServicesCount = (walletData.barterServices || []).length;

  const afnlItem = walletData.finalCoins.find(c => c.symbol === 'AFNL') || { balance: 0 };
  const afnlBalance = afnlItem.balance;
  const otherFinalCoins = walletData.finalCoins.filter(c => c.symbol !== 'AFNL');
  const totalOtherFinalCoinsBalance = otherFinalCoins.reduce((s, c) => s + c.balance, 0);

  // Dynamic Realized & Accrued Treasury Performance
  const stocksGainUSD = positions.reduce((s, p) => s + (p.totalGainUSD || 0), 0);
  const stocksCostBasis = positions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0);
  const stocksGainPct = stocksCostBasis > 0 ? (stocksGainUSD / stocksCostBasis) * 100 : 0;

  const stableCoinsYieldAnnual = walletData.stableCoins.reduce((s, st) => s + (st.balance * st.unitPriceUSD * ((st.yieldAPY || 5.4) / 100)), 0);
  const crypto24hGainUSD = walletData.cryptoCurrencies.reduce((s, cr) => s + (cr.balance * cr.unitPriceUSD * ((cr.change24h || 0) / 100)), 0);
  const fiatYieldAnnual = walletData.fiatCurrencies.reduce((s, f) => s + (f.balance * f.exchangeRateToUSD * 0.042), 0);

  const totalMoneyMade = Math.max(0, stocksGainUSD) + stableCoinsYieldAnnual + Math.max(0, crypto24hGainUSD) + fiatYieldAnnual;

  // Effective debt calculation
  const totalAmountOwed = totalGrossLiabilities;
  const isOwed = totalAmountOwed > 0;

  // Earnings by Transactional Medium with Live Dynamic Balances
  const earningsByMedium = [
    {
      id: 'stocks',
      title: 'Stocks & Public Equities',
      icon: <BarChart3 className="w-4 h-4 text-indigo-600" />,
      badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      balanceUSD: stocksVal,
      allocationPct: stockPct,
      displayValue: `$${stocksVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: `${stocksGainUSD >= 0 ? '+' : ''}${stocksGainPct.toFixed(1)}% Return`,
      subText: `${positions.length} open equity positions held`,
      description: 'Capital gains, dividends & equity market clearing positions',
      actionLabel: 'Trade Stocks',
      onAction: () => setCurrentTab('stocks'),
    },
    {
      id: 'crypto',
      title: 'Crypto-Currencies',
      icon: <Binary className="w-4 h-4 text-purple-600" />,
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
      balanceUSD: cryptoVal,
      allocationPct: cryptoPct,
      displayValue: `$${cryptoVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: `${crypto24hGainUSD >= 0 ? '+' : ''}$${Math.abs(crypto24hGainUSD).toLocaleString(undefined, { maximumFractionDigits: 0 })} 24h`,
      subText: `${walletData.cryptoCurrencies.length} assets (BTC, ETH, SOL)`,
      description: 'Glacier cold storage BTC, staked Ethereum & high-speed liquidity',
      actionLabel: 'Swap Crypto',
      onAction: () => {
        if (onOpenInstantSwap) onOpenInstantSwap();
      },
    },
    {
      id: 'fiat',
      title: 'Fiat Treasury Reserves',
      icon: <DollarSign className="w-4 h-4 text-sky-600" />,
      badgeColor: 'bg-sky-50 text-sky-700 border-sky-200',
      balanceUSD: fiatVal,
      allocationPct: fiatPct,
      displayValue: `$${fiatVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: '4.2% Commercial Yield',
      subText: `${walletData.fiatCurrencies.length} commercial bank accounts (USD, CHF, GBP)`,
      description: 'JPMorgan Chase & UBS institutional checking & escrow accounts',
      actionLabel: 'Deposit Cash',
      onAction: () => setIsAccountDepositOpen(true),
    },
    {
      id: 'stablecoins',
      title: 'Stable Coins Treasury',
      icon: <ShieldCheck className="w-4 h-4 text-emerald-600" />,
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      balanceUSD: stableCoinsVal,
      allocationPct: stablePct,
      displayValue: `$${stableCoinsVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: '5.4% Weighted APY',
      subText: `+$${stableCoinsYieldAnnual.toLocaleString(undefined, { maximumFractionDigits: 0 })}/yr yield`,
      description: 'High-yield institutional custody interest distributed on USDC, PAXG & EURC',
      actionLabel: 'Deposit Vault',
      onAction: () => {
        if (onOpenDepositModal) onOpenDepositModal();
      },
    },
    {
      id: 'barter',
      title: 'Physical Bullion & Barter Vault',
      icon: <Package className="w-4 h-4 text-amber-600" />,
      badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
      balanceUSD: barterGoodsVal,
      allocationPct: barterPct,
      displayValue: `$${barterGoodsVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      growth: `${totalBarterGoodsCount} Goods, ${totalBarterServicesCount} Services`,
      subText: 'Zurich Freeport & Alpine Vaults',
      description: 'Fine gold bullion ingots, luxury horology, AI GPU nodes & retainer contracts',
      actionLabel: 'Inspect Inventory',
      onAction: () => setDashboardSectionTab('inventory'),
    },
    {
      id: 'final_coins',
      title: 'Final Coins Sovereign Standard',
      icon: <Coins className="w-4 h-4 text-amber-600" />,
      badgeColor: 'bg-amber-50 text-amber-900 border-amber-200',
      balanceUSD: 0,
      allocationPct: 0,
      displayValue: `${afnlBalance.toLocaleString()} AFNL`,
      growth: '+0.1 AFNL/min Active',
      subText: `${otherFinalCoins.length} custom minted currencies`,
      description: 'Protocol-level non-convertible sovereign standard accrued directly in your vault',
      actionLabel: 'Transfer Coins',
      onAction: () => {
        if (onOpenBarterModal) onOpenBarterModal();
      },
    }
  ];

  // If activeTab is 'portfolio', cleanly render the dedicated PortfolioPage without dashboard header
  if (activeTab === 'portfolio') {
    return (
      <div className="pb-20 text-left">
        <PortfolioPage
          currentUser={currentUser}
          onSelectStock={onSelectStock}
          onOpenStockMarket={() => setCurrentTab('stocks')}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 text-left">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-semibold shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Modal 1: Deposit funds into platform account */}
      <AccountDepositModal
        isOpen={isAccountDepositOpen}
        onClose={() => setIsAccountDepositOpen(false)}
        currentBalance={primaryCashBalance}
        walletData={walletData}
        onConfirmDeposit={handleAccountDeposit}
      />

      {/* Modal 2: Deposit money into external bank (Withdrawal) */}
      <BankWithdrawModal
        isOpen={isBankWithdrawOpen}
        onClose={() => setIsBankWithdrawOpen(false)}
        availableBalance={primaryCashBalance}
        walletData={walletData}
        onConfirmBankDeposit={handleBankDeposit}
      />

      {/* Modal 3: Pay what you owe */}
      <AccountPayModal
        isOpen={isAccountPayOpen}
        onClose={() => setIsAccountPayOpen(false)}
        negativeBalance={-totalAmountOwed}
        walletData={walletData}
        onConfirmPayment={handleAccountPayment}
      />

      {/* ================= HEADER BANNER ================= */}
      <div className="border border-slate-200 bg-white rounded-3xl p-6 sm:p-8 shadow-xs text-center">
        <div className="flex flex-col items-center justify-center text-center gap-2 pb-5 border-b border-slate-100">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              <h1 className="font-serif text-3xl font-bold text-slate-900 tracking-tight text-center">
                {currentUser?.name || 'Trader Account'}
              </h1>
              <span className="inline-flex items-center gap-1.5 text-xs font-mono font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Verified
              </span>
            </div>
            <p className="text-xs text-slate-500 font-mono mt-0.5 text-center">ID: {userId}</p>
          </div>
        </div>

        {/* ================= HORIZONTAL SECTION TABS ================= */}
        <div className="pt-4">
          <div className="flex items-center justify-center">
            <div className="inline-flex p-1.5 rounded-2xl bg-slate-100/90 border border-slate-200 shadow-inner max-w-full overflow-x-auto gap-1">
              <button
                type="button"
                id="dashboard-tab-inventory"
                onClick={() => setDashboardSectionTab('inventory')}
                className={`flex items-center gap-2 px-5 sm:px-7 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  dashboardSectionTab === 'inventory'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
              >
                <Archive className={`w-4 h-4 ${dashboardSectionTab === 'inventory' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>Asset Inventory</span>
              </button>

              <button
                type="button"
                id="dashboard-tab-ledger"
                onClick={() => setDashboardSectionTab('ledger')}
                className={`flex items-center gap-2 px-5 sm:px-7 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  dashboardSectionTab === 'ledger'
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
              >
                <Receipt className={`w-4 h-4 ${dashboardSectionTab === 'ledger' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>Ledger & Receipts</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-slate-200 text-slate-700 font-bold">
                  {ledgerTransactions.length}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================= VIEW A: OVERVIEW TABS ================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Tab 1: Asset Inventory */}
          {dashboardSectionTab === 'inventory' && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-200">
              <AssetInventoryPage
                currentUser={currentUser!}
                onOpenDepositModal={onOpenDepositModal}
                onOpenInstantSwap={onOpenInstantSwap}
                onOpenBarterModal={onOpenBarterModal}
                onSelectStock={onSelectStock}
              />
            </div>
          )}

          {/* Tab 4: Universal Comprehensive Ledger & Tax Receipts */}
          {dashboardSectionTab === 'ledger' && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-200">
              <UniversalLedgerView 
                transactions={ledgerTransactions} 
                userId={userId} 
              />
            </div>
          )}
        </div>
      )}

      {/* ================= VIEW B: DETAILED WALLETS & INVENTORY ================= */}
      {activeTab === 'wallets' && (
        <div className="space-y-6">
          <WalletsPage
            currentUser={currentUser}
            onNavigateBack={() => setActiveTab('overview')}
            onInitiateBarterProposal={(item) => onOpenBarterModal(item)}
            onDepositVaultModal={(v) => onOpenDepositModal(v)}
          />
        </div>
      )}

      {activeTab !== 'overview' && activeTab !== 'wallets' && (
        <div className="space-y-6">
          <AssetInventoryPage
            currentUser={currentUser!}
            onNavigateBack={() => setActiveTab('overview')}
            initialTab={activeTab as any}
            onOpenDepositModal={onOpenDepositModal}
            onOpenInstantSwap={onOpenInstantSwap}
            onOpenBarterModal={onOpenBarterModal}
            onSelectStock={onSelectStock}
          />
        </div>
      )}

      {/* ================= TRADE MODALS ================= */}
      {quickTradeStock && (
        <QuickBuyStockModal
          isOpen={Boolean(quickTradeStock)}
          onClose={() => setQuickTradeStock(null)}
          stock={quickTradeStock}
          currentUser={currentUser}
          initialSide={quickTradeSide}
          positions={positions}
          onOpenAuthModal={() => {}} // Not needed in dashboard context usually
          onExecuteBuy={handleOrderExecuted}
        />
      )}

      {confirmedOrder && (
        <TradeConfirmationModal
          onClose={() => {
            setIsTradeConfirmationOpen(false);
            setConfirmedOrder(null);
          }}
          order={confirmedOrder}
          onViewPortfolio={() => {
            setConfirmedOrder(null);
            // Navigate or refresh
          }}
        />
      )}
    </div>
  );
};
