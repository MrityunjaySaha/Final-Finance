import {
  CustomCoin,
  CustomCoinType,
  MAX_COINS_PER_TYPE,
  MAX_FINAL_COINS_PER_USER,
  TOTAL_CREATABLE_COINS,
  MAX_MARKET_COINS_TOTAL,
  TOTAL_DIGITAL_CURRENCY_TYPES,
  FinalCoinDeploymentStatus
} from '../types/coinLaunch';

export const INR_TO_USD_RATE = 0.0116; // 1 INR = ~$0.0116 USD (₹86.20 = $1 USD)
export const USD_TO_INR_RATE = 86.20;

export const INITIAL_CUSTOM_COINS: CustomCoin[] = [
  // 1. ADMIN COIN (Institutional Sovereign Master Asset)
  {
    id: 'admin_final_coin_master',
    name: 'Final Admin Coin',
    symbol: 'AFNL',
    coinType: 'final_coin',
    pegCurrency: 'none',
    pegTargetDisplay: 'Sovereign Asset (Unpegged)',
    pegRateUSD: 0,
    priceUSD: 0,
    totalSupply: 100000000,
    circulatingSupply: 46200000,
    burnedSupply: 3800000,
    reserveRatioPercent: 0,
    reserveBackingDescription: 'Sovereign Protocol Reserves. No external currency peg.',
    collateralAssetType: 'Protocol Sovereign Vault Assets',
    decimals: 18,
    creatorId: 'admin',
    creatorName: 'System Protocol Admin',
    creatorHandle: 'protocol_admin',
    creatorAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80',
    isAdminCoin: true,
    createdAt: '2026-01-01T00:00:00Z',
    contractAddress: '0xAFNL000000000000000000000000000000000001',
    network: 'Final Ledger Layer-1',
    logoBg: 'from-amber-400 via-amber-500 to-amber-600 text-slate-950',
    iconSymbol: '⚡',
    description: 'The premier sovereign currency issued by Final Finance Governance. Independent unit of account.',
    status: 'active',
    auditScore: 99,
    holdersCount: 38420,
    dailyVolumeUSD: 0,
    change24h: 0,
    high24h: 0,
    low24h: 0
  },

  // 2. DEMO USER CREATED COINS & STABLECOINS / CRYPTOCURRENCIES
  {
    id: 'user_inr_stable_01',
    name: 'Bharat Digital Rupee',
    symbol: 'BDRS',
    coinType: 'stable_coin',
    pegCurrency: 'INR',
    pegTargetDisplay: '₹1.00 INR (Indian Rupee Pegged)',
    pegRateUSD: 0.0116,
    priceUSD: 0.0116,
    totalSupply: 500000000,
    circulatingSupply: 180000000,
    burnedSupply: 1000000,
    reserveRatioPercent: 101,
    reserveBackingDescription: 'Indian Rupee sovereign bank deposit reserves with automated RBI Repo rate yield staking.',
    collateralAssetType: 'INR Bank Escrow & RBI T-Bills',
    decimals: 2,
    creatorId: 'admin',
    creatorName: 'System Protocol Admin',
    creatorHandle: 'protocol_admin',
    isAdminCoin: true,
    createdAt: '2026-02-10T14:30:00Z',
    contractAddress: '0x8892f3a9a149bfe9931bfa829490214a9082bd01',
    network: 'Final Ledger / Polygon POS',
    logoBg: 'from-orange-500 via-amber-500 to-emerald-600 text-white',
    iconSymbol: '₹',
    description: 'A 1:1 pegged Indian Rupee sovereign stablecoin enabling zero-fee remittances and cross-border trades across Asia.',
    status: 'active',
    auditScore: 96,
    holdersCount: 1420,
    dailyVolumeUSD: 420000,
    change24h: 0.01,
    high24h: 0.01162,
    low24h: 0.01158
  },
  {
    id: 'user_usd_stable_01',
    name: 'Apex Sovereign Dollar',
    symbol: 'ASVD',
    coinType: 'stable_coin',
    pegCurrency: 'USD',
    pegTargetDisplay: '$1.00 USD (US Dollar Pegged)',
    pegRateUSD: 1.00,
    priceUSD: 1.00,
    totalSupply: 50000000,
    circulatingSupply: 22000000,
    burnedSupply: 500000,
    reserveRatioPercent: 105,
    reserveBackingDescription: '100% US Dollar backed treasury pool held in diversified Swiss custody vaults.',
    collateralAssetType: 'USD Escrow & Swiss Custody',
    decimals: 6,
    creatorId: 'user_demo',
    creatorName: 'Marcus Vance',
    creatorHandle: 'marcus_vance',
    isAdminCoin: false,
    createdAt: '2026-02-14T11:00:00Z',
    contractAddress: '0x17c938198fba8123908efc1234901928340192a4',
    network: 'Final Ledger Layer-1',
    logoBg: 'from-emerald-600 via-teal-600 to-cyan-500 text-white',
    iconSymbol: '$',
    description: 'High-yield US dollar pegged sovereign stablecoin backed by Swiss custody vault accounts.',
    status: 'active',
    auditScore: 97,
    holdersCount: 3190,
    dailyVolumeUSD: 2400000,
    change24h: 0.00,
    high24h: 1.0002,
    low24h: 0.9997
  },
  {
    id: 'user_final_coin_01',
    name: 'Nebula Final Coin',
    symbol: 'NEBL',
    coinType: 'final_coin',
    pegCurrency: 'none',
    pegTargetDisplay: 'Sovereign Asset (Unpegged)',
    pegRateUSD: 0,
    priceUSD: 0,
    totalSupply: 5000000,
    circulatingSupply: 2800000,
    burnedSupply: 200000,
    reserveRatioPercent: 0,
    reserveBackingDescription: 'Sovereign unit of account. Independent valuation.',
    collateralAssetType: 'Sovereign Protocol Reserve',
    decimals: 18,
    creatorId: 'user_demo_marcus',
    creatorName: 'Dr. Marcus Vance (Peer Creator)',
    creatorHandle: 'marcus_vance',
    isAdminCoin: false,
    createdAt: '2026-02-18T09:15:00Z',
    contractAddress: '0x49c87f123a9b9182370912401827419823719283',
    network: 'Final Ledger Layer-1',
    logoBg: 'from-rose-500 via-pink-600 to-purple-600 text-white',
    iconSymbol: '🌌',
    description: 'Sovereign final coin with independent protocol valuation.',
    status: 'active',
    auditScore: 94,
    holdersCount: 2180,
    dailyVolumeUSD: 0,
    change24h: 0,
    high24h: 0,
    low24h: 0
  },
  {
    id: 'community_aurora_final',
    name: 'Aurora Sovereign Final Coin',
    symbol: 'ASOV',
    coinType: 'final_coin',
    pegCurrency: 'none',
    pegTargetDisplay: 'Sovereign Asset (Unpegged)',
    pegRateUSD: 0,
    priceUSD: 0,
    totalSupply: 15000000,
    circulatingSupply: 7200000,
    burnedSupply: 300000,
    reserveRatioPercent: 0,
    reserveBackingDescription: 'Sovereign unit of account. Independent valuation.',
    collateralAssetType: 'Sovereign Protocol Reserve',
    decimals: 18,
    creatorId: 'creator_sarah_lin',
    creatorName: 'Dr. Sarah Lin (Peer Creator)',
    creatorHandle: 'sarah_lin',
    isAdminCoin: false,
    createdAt: '2026-02-12T08:00:00Z',
    contractAddress: '0xASOV000000000000000000000000000000000099',
    network: 'Final Ledger Layer-1',
    logoBg: 'from-teal-400 via-emerald-500 to-cyan-600 text-slate-950',
    iconSymbol: '🌿',
    description: 'Autonomous sovereign final coin with independent protocol valuation.',
    status: 'active',
    auditScore: 97,
    holdersCount: 3410,
    dailyVolumeUSD: 0,
    change24h: 0,
    high24h: 0,
    low24h: 0
  },
  {
    id: 'user_crypto_01',
    name: 'Zenith Quantum Chain',
    symbol: 'ZNTH',
    coinType: 'crypto',
    pegCurrency: 'none',
    pegTargetDisplay: 'Floating Cryptocurrency (Market Exchange)',
    pegRateUSD: 42.15,
    priceUSD: 42.15,
    totalSupply: 10000000,
    circulatingSupply: 6400000,
    burnedSupply: 350000,
    reserveRatioPercent: 120,
    reserveBackingDescription: 'Layer-1 Proof-of-Stake validator consensus token with automated gas burn mechanism.',
    collateralAssetType: 'Validator PoS Collateral',
    decimals: 18,
    creatorId: 'user_demo',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena_crypto',
    isAdminCoin: false,
    createdAt: '2026-02-05T16:00:00Z',
    contractAddress: '0x99281a8c7b653018249019283401928340192847',
    network: 'Zenith Proof-of-Stake Network',
    logoBg: 'from-purple-600 via-indigo-600 to-violet-700 text-white',
    iconSymbol: '💎',
    description: 'Ultra-fast sub-second transaction throughput sovereign cryptocurrency for enterprise settlement.',
    status: 'active',
    auditScore: 95,
    holdersCount: 4890,
    dailyVolumeUSD: 3120000,
    change24h: -1.85,
    high24h: 44.20,
    low24h: 41.10
  }
];

const STORAGE_KEY = 'final_finance_custom_coins_v1';

export function getStoredCustomCoins(): CustomCoin[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const adminMasterSeed = INITIAL_CUSTOM_COINS.find(c => c.id === 'admin_final_coin_master')!;

    if (raw) {
      let parsed: CustomCoin[] = JSON.parse(raw);
      // Filter out removed admin stable coin, admin crypto currency, and Sovereign Genesis Final Coin
      parsed = parsed.filter(c => 
        c.id !== 'admin_stable_coin_master' && 
        c.id !== 'admin_crypto_master' && 
        c.id !== 'user_my_final_coin' && 
        c.symbol !== 'SGEN' &&
        c.symbol !== 'FLC' &&
        c.name !== 'Final Liquidity Credit' &&
        !c.name?.toLowerCase().includes('sovereign genesis')
      );
      
      // Ensure admin_final_coin_master is properly synchronized
      parsed = parsed.map(c => {
        if (c.id === 'admin_final_coin_master') {
          return { ...adminMasterSeed, ...c, symbol: 'AFNL', name: 'Final Admin Coin', coinType: 'final_coin' };
        }
        if (c.coinType === 'final_coin' && c.circulatingSupply === 2000000) {
          return { ...c, circulatingSupply: 0 };
        }
        return c;
      });

      // Ensure final admin coin exists
      if (!parsed.some(c => c.id === 'admin_final_coin_master')) {
        parsed.unshift(adminMasterSeed);
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
      return parsed;
    }
  } catch (err) {
    console.error('Error loading custom coins:', err);
  }
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_CUSTOM_COINS));
  } catch {}
  return INITIAL_CUSTOM_COINS;
}

export function saveCustomCoins(coins: CustomCoin[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(coins));
    window.dispatchEvent(new Event('final_finance_custom_coins_updated'));
  } catch (err) {
    console.error('Error saving custom coins:', err);
  }
}

export function getCoinsByUserAndType(
  coins: CustomCoin[],
  userId: string,
  type: CustomCoinType
): CustomCoin[] {
  return coins.filter((c) => (c.creatorId === userId || (c.isAdminCoin && (userId === 'admin' || userId === 'super_admin'))) && c.coinType === type);
}

export function getMarketCoinCapacity(coins: CustomCoin[]): {
  totalActiveInMarket: number;
  maxMarketCapacity: number;
  marketRemaining: number;
  isMarketFull: boolean;
  totalCreatableAcrossTypes: number;
  coinsPerTypeLimit: number;
  totalTypes: number;
  breakdown: {
    stable_coin: number;
    final_coin: number;
    crypto: number;
  };
} {
  const activeMarketCoins = coins.filter((c) => c.status === 'active');
  const stableCount = activeMarketCoins.filter((c) => c.coinType === 'stable_coin').length;
  const finalCount = activeMarketCoins.filter((c) => c.coinType === 'final_coin').length;
  const cryptoCount = activeMarketCoins.filter((c) => c.coinType === 'crypto').length;
  const totalActive = activeMarketCoins.length;
  const maxMarketCapacity = MAX_MARKET_COINS_TOTAL;

  return {
    totalActiveInMarket: totalActive,
    maxMarketCapacity,
    marketRemaining: Math.max(0, maxMarketCapacity - totalActive),
    isMarketFull: totalActive >= maxMarketCapacity,
    totalCreatableAcrossTypes: TOTAL_CREATABLE_COINS,
    coinsPerTypeLimit: MAX_COINS_PER_TYPE,
    totalTypes: TOTAL_DIGITAL_CURRENCY_TYPES,
    breakdown: {
      stable_coin: stableCount,
      final_coin: finalCount,
      crypto: cryptoCount,
    }
  };
}

export function canUserReleaseCoin(
  coins: CustomCoin[],
  userId: string,
  type: CustomCoinType,
  isAdmin: boolean
): {
  allowed: boolean;
  currentCount: number;
  maxAllowed: number;
  remaining: number;
  totalUserCoins: number;
  totalUserLimit: number;
  totalUserRemaining: number;
  marketCapacity: {
    totalActiveInMarket: number;
    maxMarketCapacity: number;
    marketRemaining: number;
    isMarketFull: boolean;
  };
} {
  // If admin, check admin-created coins of that type, otherwise check user's coins
  const userTypeCoins = coins.filter((c) => {
    if (isAdmin) {
      return c.isAdminCoin && c.coinType === type;
    }
    return c.creatorId === userId && !c.isAdminCoin && c.coinType === type;
  });

  const allUserCoins = coins.filter((c) => {
    if (isAdmin) {
      return c.isAdminCoin;
    }
    return c.creatorId === userId && !c.isAdminCoin;
  });

  const currentCount = userTypeCoins.length;
  const maxAllowed = type === 'final_coin' ? MAX_FINAL_COINS_PER_USER : MAX_COINS_PER_TYPE; // 5 for final coins
  const totalUserLimit = MAX_FINAL_COINS_PER_USER;
  const allowed = currentCount < maxAllowed;
  const remaining = Math.max(0, maxAllowed - currentCount);
  const totalUserRemaining = Math.max(0, totalUserLimit - allUserCoins.length);

  const marketCap = getMarketCoinCapacity(coins);

  return {
    allowed,
    currentCount,
    maxAllowed,
    remaining,
    totalUserCoins: allUserCoins.length,
    totalUserLimit,
    totalUserRemaining,
    marketCapacity: {
      totalActiveInMarket: marketCap.totalActiveInMarket,
      maxMarketCapacity: marketCap.maxMarketCapacity,
      marketRemaining: marketCap.marketRemaining,
      isMarketFull: marketCap.isMarketFull
    }
  };
}

export function canUserReleaseFinalCoin(
  coins: CustomCoin[],
  userId: string,
  isAdmin: boolean = false
): {
  allowed: boolean;
  currentCount: number;
  maxAllowed: number;
  remaining: number;
  reason?: string;
} {
  const userFinalCoins = coins.filter((c) => {
    if (isAdmin) {
      return c.isAdminCoin && c.coinType === 'final_coin';
    }
    return (c.creatorId === userId || c.creatorId === 'you' || c.creatorHandle === 'sovereign_builder') && !c.isAdminCoin && c.coinType === 'final_coin';
  });

  const currentCount = userFinalCoins.length;
  const maxAllowed = MAX_FINAL_COINS_PER_USER; // 5
  const remaining = Math.max(0, maxAllowed - currentCount);

  let allowed = true;
  let reason: string | undefined = undefined;

  if (currentCount >= maxAllowed) {
    allowed = false;
    reason = `Maximum creation quota reached: You have created ${currentCount}/${maxAllowed} Final Coins (limit is 5 per user).`;
  }

  return {
    allowed,
    currentCount,
    maxAllowed,
    remaining,
    reason
  };
}

export function mintCustomCoinSupply(
  coinId: string,
  amount: number,
  userId: string
): { success: boolean; updatedCoin?: CustomCoin; message: string } {
  const coins = getStoredCustomCoins();
  const index = coins.findIndex(c => c.id === coinId);
  if (index === -1) {
    return { success: false, message: 'Coin not found in protocol directory.' };
  }

  const coin = coins[index];
  const isOwner = coin.creatorId === userId || coin.creatorId === 'you' || userId === 'admin';
  if (!isOwner) {
    return { success: false, message: 'Unauthorized: Only the creator can mint additional supply for this Final Coin.' };
  }

  const updatedCoin: CustomCoin = {
    ...coin,
    totalSupply: coin.totalSupply + amount,
    circulatingSupply: coin.circulatingSupply + amount
  };

  coins[index] = updatedCoin;
  saveCustomCoins(coins);

  return {
    success: true,
    updatedCoin,
    message: `Successfully minted ${amount.toLocaleString()} ${coin.symbol}. Total supply is now ${updatedCoin.totalSupply.toLocaleString()} ${coin.symbol}.`
  };
}

export function burnCustomCoinSupply(
  coinId: string,
  amount: number,
  userId: string
): { success: boolean; updatedCoin?: CustomCoin; message: string } {
  const coins = getStoredCustomCoins();
  const index = coins.findIndex(c => c.id === coinId);
  if (index === -1) {
    return { success: false, message: 'Coin not found in protocol directory.' };
  }

  const coin = coins[index];
  const isOwner = coin.creatorId === userId || coin.creatorId === 'you' || userId === 'admin';
  if (!isOwner) {
    return { success: false, message: 'Unauthorized: Only the creator can burn supply for this Final Coin.' };
  }

  if (coin.circulatingSupply < amount) {
    return { success: false, message: `Insufficient circulating supply to burn. Available: ${coin.circulatingSupply.toLocaleString()}` };
  }

  const updatedCoin: CustomCoin = {
    ...coin,
    totalSupply: Math.max(0, coin.totalSupply - amount),
    circulatingSupply: Math.max(0, coin.circulatingSupply - amount),
    burnedSupply: (coin.burnedSupply || 0) + amount
  };

  coins[index] = updatedCoin;
  saveCustomCoins(coins);

  return {
    success: true,
    updatedCoin,
    message: `Successfully burned ${amount.toLocaleString()} ${coin.symbol} from supply. Deflationary event recorded on-chain.`
  };
}

export function updateCustomCoinAttachments(
  coinId: string,
  attachments: import('../types/coinLaunch').CoinAttachment[],
  userId: string
): { success: boolean; updatedCoin?: CustomCoin; message: string } {
  const coins = getStoredCustomCoins();
  const index = coins.findIndex(c => c.id === coinId);
  if (index === -1) {
    return { success: false, message: 'Coin not found in protocol directory.' };
  }

  const coin = coins[index];
  const isOwner = coin.creatorId === userId || coin.creatorId === 'you' || userId === 'admin';
  if (!isOwner) {
    return { success: false, message: 'Unauthorized: Only the creator can modify attachments.' };
  }

  const photoUrls = attachments.filter(a => a.type === 'photo').map(a => a.url);
  const videoUrls = attachments.filter(a => a.type === 'video').map(a => a.url);

  const updatedCoin: CustomCoin = {
    ...coin,
    attachments,
    photos: photoUrls,
    videos: videoUrls
  };

  coins[index] = updatedCoin;
  saveCustomCoins(coins);

  return {
    success: true,
    updatedCoin,
    message: 'Attachments updated successfully.'
  };
}

export function updateCustomCoin(
  coinId: string,
  updates: Partial<CustomCoin>,
  userId: string
): { success: boolean; updatedCoin?: CustomCoin; message: string } {
  const coins = getStoredCustomCoins();
  const index = coins.findIndex(c => c.id === coinId);
  if (index === -1) {
    return { success: false, message: 'Coin not found in protocol directory.' };
  }

  const coin = coins[index];
  const isOwner = coin.creatorId === userId || coin.creatorId === 'you' || userId === 'admin';
  if (!isOwner) {
    return { success: false, message: 'Unauthorized: Only the creator can update coin details.' };
  }

  const updatedCoin: CustomCoin = {
    ...coin,
    ...updates
  };

  coins[index] = updatedCoin;
  saveCustomCoins(coins);

  return {
    success: true,
    updatedCoin,
    message: 'Coin details updated successfully.'
  };
}


export function deleteCustomCoin(coinId: string, userId: string): { success: boolean; message: string } {
  const coins = getStoredCustomCoins();
  const index = coins.findIndex(c => c.id === coinId);
  if (index === -1) {
    return { success: false, message: 'Coin not found.' };
  }
  const coin = coins[index];
  const isOwner = coin.creatorId === userId || coin.creatorId === 'you' || userId === 'admin';
  if (!isOwner) {
    return { success: false, message: 'Unauthorized: Only the creator can delete this coin.' };
  }
  
  coins.splice(index, 1);
  saveCustomCoins(coins);
  return { success: true, message: `Successfully deleted ${coin.symbol}.` };
}
