import { Tweet, TweetPoll, TweetReply, TweetTradeReceipt, TweetSharedPost, TweetLinkPreview, SharedTweetCardData, TWEETING_MAX_CHARS } from '../types/tweet';
import { getCurrentSession } from './firebaseAuth';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { isUserFollowedOrFriend } from './socialService';
import { getAllActiveMarketStocks } from '../data/stocksData';
import { isFinalStock } from '../utils/stockCurrencyFormatter';

export { TWEETING_MAX_CHARS };
export const TWEETS_STORAGE_KEY = 'final_finance_tweets_v1';
export const TWEETS_UPDATED_EVENT = 'final_finance_tweets_updated';

export const DEFAULT_SEED_TWEETS: Tweet[] = [
  {
    id: 'tweet-1',
    authorId: 'creator_alex_chen',
    authorName: 'Alex Chen',
    authorHandle: 'alex_chen',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    isVerified: true,
    content: 'Just deployed our newest zero-knowledge liquidity engine to sovereign vaults on #FinalFinance #AFNL! 🚀 Our verified NAV reached ₣AFNL 25.00M backed by gold & 5-mode reserves. What asset class should anchor Q3 expansion? Vote below! F:ALEX #Bullish',
    createdAt: Date.now() - 1000 * 60 * 25,
    timestamp: '25m ago',
    photos: [
      'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800'
    ],
    poll: {
      id: 'poll-1',
      options: [
        { id: 'opt-1', text: 'Gold Bullion & Sovereign Vaults', votes: 142 },
        { id: 'opt-2', text: 'Decentralized AI Royalty Tokens', votes: 218 },
        { id: 'opt-3', text: 'Tier-1 Fiat Reserves', votes: 45 },
        { id: 'opt-4', text: 'High-Yield Proof of Stake', votes: 89 }
      ],
      voterIds: {},
      totalVotes: 494,
      durationDays: 3,
      expiresAt: Date.now() + 1000 * 60 * 60 * 48
    },
    likes: 124,
    likedBy: [],
    retweets: 38,
    retweetedBy: [],
    bookmarks: 19,
    bookmarkedBy: [],
    views: 3420,
    replies: [
      {
        id: 'reply-1-1',
        tweetId: 'tweet-1',
        authorId: 'creator_elena',
        authorName: 'Elena Rostova',
        authorHandle: 'elena',
        authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
        content: 'Impressive milestone @alex_chen! Backing AI licensing with physical bullion vaults sets the golden standard.',
        timestamp: '15m ago',
        createdAt: Date.now() - 1000 * 60 * 15,
        likes: 12,
        likedBy: []
      }
    ],
    hashtags: ['FinalFinance', 'AFNL', 'Bullish'],
    mentions: [],
    tickers: ['ALEX']
  },
  {
    id: 'tweet-2',
    authorId: 'creator_satoshi',
    authorName: 'Satoshi Nakamoto',
    authorHandle: 'satoshi',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    isVerified: true,
    content: 'Mathematical purity in decentralized settlement cannot be negotiated. The strict 1 Final Currency rule for personal human equities ensures solvency without counterfeit dilution. #Decentralized #SovereignEquity',
    createdAt: Date.now() - 1000 * 60 * 75,
    timestamp: '1h ago',
    likes: 489,
    likedBy: [],
    retweets: 182,
    retweetedBy: [],
    bookmarks: 77,
    bookmarkedBy: [],
    views: 14850,
    replies: [],
    hashtags: ['Decentralized', 'SovereignEquity'],
    mentions: [],
    tickers: []
  },
  {
    id: 'tweet-3',
    authorId: 'creator_elena',
    authorName: 'Elena Rostova',
    authorHandle: 'elena',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    isVerified: true,
    content: 'Reviewing our multi-vault bullion holdings in Zurich today. Over ₣AFNL 12.00M in physical bars secured across Tier-3 depository vaults. Transparency is everything in modern finance. ✨ #GoldVaults #AFNL',
    createdAt: Date.now() - 1000 * 60 * 180,
    timestamp: '3h ago',
    photos: [
      'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&q=80&w=800'
    ],
    likes: 215,
    likedBy: [],
    retweets: 52,
    retweetedBy: [],
    bookmarks: 31,
    bookmarkedBy: [],
    views: 6180,
    replies: [],
    hashtags: ['GoldVaults', 'AFNL'],
    mentions: [],
    tickers: []
  },
  {
    id: 'tweet-4',
    authorId: 'quant_trader_mark',
    authorName: 'Marcus Vance',
    authorHandle: 'vance_capital',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    isVerified: false,
    content: 'Poll: How do you allocate your Final Stocks portfolio during volatile macro weeks? Let me know your risk profile! #SovereignEquity #Bullish',
    createdAt: Date.now() - 1000 * 60 * 320,
    timestamp: '5h ago',
    poll: {
      id: 'poll-2',
      options: [
        { id: 'opt-2-1', text: '100% Personal Sovereign Equities', votes: 88 },
        { id: 'opt-2-2', text: '50% Final Equities / 50% Vault Gold', votes: 145 },
        { id: 'opt-2-3', text: 'Algorithmic Derivatives & Options', votes: 62 }
      ],
      voterIds: {},
      totalVotes: 295,
      durationDays: 7,
      expiresAt: Date.now() + 1000 * 60 * 60 * 120
    },
    likes: 78,
    likedBy: [],
    retweets: 14,
    retweetedBy: [],
    bookmarks: 9,
    bookmarkedBy: [],
    views: 2450,
    replies: [],
    hashtags: ['SovereignEquity', 'Bullish'],
    mentions: [],
    tickers: []
  }
];

export function extractHashtags(text: string): string[] {
  const matches = text.match(/#([a-zA-Z0-9_]+)/g);
  if (!matches) return [];
  return Array.from(new Set(matches.map((m) => m.slice(1))));
}

export function extractMentions(text: string): string[] {
  const matches = text.match(/@([a-zA-Z0-9_]+)/g);
  if (!matches) return [];
  return Array.from(new Set(matches.map((m) => m.slice(1))));
}

export function getFinalStockPool() {
  return getAllActiveMarketStocks().filter((s) => isFinalStock(s));
}

export function extractTickers(text: string): string[] {
  const matches = text.match(/(?:^|[\s(])(?:[Ff]:|₣)([a-zA-Z][a-zA-Z0-9_-]*)/g);
  if (!matches) return [];
  const finalTickerSet = new Set(getFinalStockPool().map((s) => s.ticker.toUpperCase()));
  return Array.from(
    new Set(
      matches
        .map((m) => m.replace(/^[\s(]*(?:[Ff]:|₣)/, '').toUpperCase())
        .filter((tk) => finalTickerSet.has(tk))
    )
  );
}

export function getStoredTweets(): Tweet[] {
  try {
    const raw = localStorage.getItem(TWEETS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(TWEETS_STORAGE_KEY, JSON.stringify(DEFAULT_SEED_TWEETS));
      return DEFAULT_SEED_TWEETS;
    }
    const parsed = JSON.parse(raw) as Tweet[];
    if (!parsed || parsed.length === 0) return DEFAULT_SEED_TWEETS;
    const finalTickerSet = new Set(getFinalStockPool().map((s) => s.ticker.toUpperCase()));
    return parsed.map((t) => {
      if (t.id === 'tweet-1' && t.content.includes('$ALEX')) {
        return {
          ...t,
          content: t.content.replace(/\$ALEX\b/g, 'F:ALEX'),
          tickers: (t.tickers || ['ALEX']).filter((tk) => finalTickerSet.has(tk.toUpperCase())),
        };
      }
      if (t.tickers && t.tickers.length > 0) {
        return {
          ...t,
          tickers: t.tickers.filter((tk) => finalTickerSet.has(tk.toUpperCase())),
        };
      }
      return t;
    });
  } catch (err) {
    console.error('Failed reading tweets from storage:', err);
    return DEFAULT_SEED_TWEETS;
  }
}

export function saveStoredTweets(tweets: Tweet[]): void {
  try {
    localStorage.setItem(TWEETS_STORAGE_KEY, JSON.stringify(tweets));
    window.dispatchEvent(new CustomEvent(TWEETS_UPDATED_EVENT, { detail: tweets }));
  } catch (err) {
    console.error('Failed saving tweets to storage:', err);
  }
}

/**
 * Checks if the tweet's author is in the current user's friends list or followed list
 */
export function isAuthorFollowedOrFriend(
  authorId: string, 
  authorHandle: string, 
  viewerUid?: string, 
  viewerHandle?: string
): boolean {
  if (!viewerUid && !viewerHandle) {
    const session = getCurrentSession();
    viewerUid = session?.uid || session?.id || '';
    viewerHandle = (session?.id || session?.email?.split('@')[0] || '').toLowerCase().replace(/^@/, '');
  }

  const cleanAuthorHandle = authorHandle.toLowerCase().replace(/^@/, '');
  const cleanViewerHandle = (viewerHandle || '').toLowerCase().replace(/^@/, '');

  // Never notify user of their own tweets
  if (
    (viewerUid && (authorId === viewerUid || authorId.toLowerCase() === viewerUid.toLowerCase())) ||
    (cleanViewerHandle && cleanAuthorHandle === cleanViewerHandle)
  ) {
    return false;
  }

  // 1. Check direct socialService friendship & following
  if (viewerUid && isUserFollowedOrFriend(viewerUid, authorId)) return true;
  if (viewerUid && isUserFollowedOrFriend(viewerUid, cleanAuthorHandle)) return true;
  if (cleanViewerHandle && isUserFollowedOrFriend(cleanViewerHandle, cleanAuthorHandle)) return true;

  // 2. Check localStorage followed & friends handles
  try {
    const savedFollowed = localStorage.getItem('final_finance_followed_tweet_handles');
    if (savedFollowed) {
      const list = JSON.parse(savedFollowed) as string[];
      if (list.map((h) => h.toLowerCase().replace(/^@/, '')).includes(cleanAuthorHandle)) {
        return true;
      }
    }
  } catch {}

  try {
    const savedFriends = localStorage.getItem('final_finance_friend_tweet_handles');
    if (savedFriends) {
      const list = JSON.parse(savedFriends) as string[];
      if (list.map((h) => h.toLowerCase().replace(/^@/, '')).includes(cleanAuthorHandle)) {
        return true;
      }
    }
  } catch {}

  // 3. Fallback to default connections ONLY if no explicit followed list has been saved yet
  const hasCustomFollowed = typeof window !== 'undefined' && localStorage.getItem('final_finance_followed_tweet_handles') !== null;
  if (!hasCustomFollowed) {
    const defaultNetwork = ['alex_chen', 'satoshi', 'elena', 'sterling_vault', 'elena_rostova'];
    if (defaultNetwork.includes(cleanAuthorHandle)) {
      return true;
    }
  }

  return false;
}

/**
 * Dispatches a real-time notification with audio chime, toast, and notification drawer item
 * whenever a tweet is posted by a friend or followed user.
 */
export function notifyIfTweetFromFriendOrFollowed(tweet: Tweet): void {
  try {
    const session = getCurrentSession();
    const currentUid = session?.uid || session?.id || '';
    const currentHandle = (session?.id || session?.email?.split('@')[0] || '').toLowerCase().replace(/^@/, '');

    // Never notify user of their own tweets
    if (
      (currentUid && (tweet.authorId === currentUid || tweet.authorId.toLowerCase() === currentUid.toLowerCase())) ||
      (currentHandle && tweet.authorHandle.toLowerCase().replace(/^@/, '') === currentHandle)
    ) {
      return;
    }

    if (!isAuthorFollowedOrFriend(tweet.authorId, tweet.authorHandle, currentUid, currentHandle)) {
      return;
    }

    const cleanContent = tweet.content.trim();
    const shortContent = cleanContent.length > 95 ? cleanContent.slice(0, 92) + '...' : cleanContent;

    // Send global notification (audio chime, browser push, header bell badge, in-app toast)
    dispatchGlobalNotification({
      title: `New Tweet from ${tweet.authorName}`,
      description: `@${tweet.authorHandle.replace(/^@/, '')}: "${shortContent}"`,
      type: 'social',
      targetTab: 'tweeting',
      targetId: tweet.id,
      tone: 'message',
      showToast: true,
      toastType: 'info'
    });
  } catch (err) {
    console.debug('Failed dispatching tweet notification:', err);
  }
}

export function createTweet(params: {
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  content: string;
  photos?: string[];
  video?: string;
  videos?: string[];
  pollOptions?: string[];
  pollDurationDays?: number;
  tradeReceipt?: TweetTradeReceipt;
  sharedPost?: TweetSharedPost;
  quotedTweet?: Tweet;
  retweetedTweetId?: string;
  isDirectRetweet?: boolean;
  linkPreviews?: Record<string, TweetLinkPreview>;
  extraHashtags?: string[];
  stockCurrencies?: Record<string, string>;
}): Tweet {
  const current = getStoredTweets();
  const cleanContent = params.content.trim().slice(0, TWEETING_MAX_CHARS);

  let poll: TweetPoll | undefined = undefined;
  if (params.pollOptions && params.pollOptions.filter((o) => o.trim().length > 0).length >= 2) {
    const validOptions = params.pollOptions.filter((o) => o.trim().length > 0);
    const clampedDays = Math.min(365, Math.max(1, Math.round(params.pollDurationDays || 1)));
    poll = {
      id: `poll_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      options: validOptions.map((text, idx) => ({
        id: `opt-${idx + 1}`,
        text: text.trim(),
        votes: 0
      })),
      voterIds: {},
      totalVotes: 0,
      durationDays: clampedDays,
      expiresAt: Date.now() + clampedDays * 24 * 60 * 60 * 1000
    };
  }

  const mergedHashtags = Array.from(
    new Set([
      ...extractHashtags(cleanContent),
      ...(params.extraHashtags || []).map((h) => h.replace(/^#/, '').trim()).filter(Boolean),
    ])
  );
  const finalTickerSet = new Set(getFinalStockPool().map((s) => s.ticker.toUpperCase()));
  const receiptTicker = params.tradeReceipt?.ticker?.toUpperCase();
  const mergedTickers = Array.from(
    new Set([
      ...extractTickers(cleanContent),
      ...(receiptTicker && finalTickerSet.has(receiptTicker) ? [receiptTicker] : []),
    ])
  );

  const normalizedStockCurrencies: Record<string, string> = {};
  if (params.stockCurrencies) {
    Object.entries(params.stockCurrencies).forEach(([tickerKey, coinSym]) => {
      const upperTicker = tickerKey.toUpperCase().trim();
      const cleanCoin = coinSym.replace(/^\$/, '').trim().toUpperCase();
      if (upperTicker && cleanCoin && finalTickerSet.has(upperTicker)) {
        normalizedStockCurrencies[upperTicker] = cleanCoin;
      }
    });
  }

  const targetOriginalId = params.retweetedTweetId || params.quotedTweet?.id;

  const newTweet: Tweet = {
    id: `tweet_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    authorId: params.authorId,
    authorName: params.authorName,
    authorHandle: params.authorHandle.replace(/^@/, ''),
    authorAvatar: params.authorAvatar,
    isVerified: true,
    content: cleanContent,
    createdAt: Date.now(),
    timestamp: 'Just now',
    photos: params.photos && params.photos.length > 0 ? params.photos : undefined,
    video: (params.videos && params.videos[0]) || params.video || undefined,
    videos: params.videos && params.videos.length > 0 ? params.videos : (params.video ? [params.video] : undefined),
    poll,
    tradeReceipt: params.tradeReceipt,
    sharedPost: params.sharedPost,
    quotedTweet: params.quotedTweet,
    retweetedTweetId: targetOriginalId,
    isDirectRetweet: params.isDirectRetweet,
    linkPreviews: params.linkPreviews && Object.keys(params.linkPreviews).length > 0 ? params.linkPreviews : undefined,
    likes: 0,
    likedBy: [],
    retweets: 0,
    retweetedBy: [],
    bookmarks: 0,
    bookmarkedBy: [],
    views: 1,
    replies: [],
    hashtags: mergedHashtags,
    mentions: extractMentions(cleanContent),
    tickers: mergedTickers,
    stockCurrencies: Object.keys(normalizedStockCurrencies).length > 0 ? normalizedStockCurrencies : undefined
  };

  // Unified Retweet accounting: whenever a tweet retweets/quotes an original tweet,
  // increment the original tweet's retweet counter cleanly.
  const syncedCurrent = targetOriginalId
    ? current.map((t) => {
        if (t.id !== targetOriginalId) return t;
        const alreadyRetweeted = t.retweetedBy.includes(params.authorId);
        const retweetedBy = alreadyRetweeted ? t.retweetedBy : [...t.retweetedBy, params.authorId];
        return {
          ...t,
          retweets: t.retweets + 1,
          retweetedBy,
        };
      })
    : current;

  const updated = [newTweet, ...syncedCurrent];
  saveStoredTweets(updated);

  // Trigger instant notification for followed accounts & friends
  notifyIfTweetFromFriendOrFollowed(newTweet);

  return newTweet;
}

export const NETWORK_TWEET_PRESETS = [
  {
    authorId: 'creator_alex_chen',
    authorName: 'Alex Chen',
    authorHandle: 'alex_chen',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    content: 'Just finalized the verified NAV audit for our Sovereign AI licensing tranches. Bullion-anchored liquidity up +18.4% this quarter! 📈 #FinalFinance #AFNL'
  },
  {
    authorId: 'creator_elena',
    authorName: 'Elena Rostova',
    authorHandle: 'elena',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    content: 'Tier-1 Zurich Freeport allocation completed. 500oz fine gold safely registered into multi-vault cryptographic custody. ✨ #GoldVaults'
  },
  {
    authorId: 'creator_satoshi',
    authorName: 'Satoshi Nakamoto',
    authorHandle: 'satoshi',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    content: 'The foundation of sound sovereign money requires verifiable scarcity without middleman trust. The math speaks for itself. #Decentralized'
  },
  {
    authorId: 'user-lord_sterling',
    authorName: 'Lord Sterling',
    authorHandle: 'sterling_vault',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    content: 'Imperial Gold Bullion tranches are moving fast this week. Over ₣AFNL 14.5M cleared through P2P barter corridors with zero counterparty risk. #Bullion'
  },
  {
    authorId: 'creator_alex_chen',
    authorName: 'Alex Chen',
    authorHandle: 'alex_chen',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    content: 'Personal sovereign equities allow talent to be tokenized directly without Wall Street dilution. Exciting times for independent creators! F:ALEX'
  }
];

export function simulateNetworkTweet(presetIndex?: number): Tweet {
  const chosen = presetIndex !== undefined 
    ? NETWORK_TWEET_PRESETS[presetIndex % NETWORK_TWEET_PRESETS.length]
    : NETWORK_TWEET_PRESETS[Math.floor(Math.random() * NETWORK_TWEET_PRESETS.length)];
  return createTweet(chosen);
}

export function toggleTweetLike(tweetId: string, userId: string): Tweet | null {
  const current = getStoredTweets();
  let updatedTweet: Tweet | null = null;
  const next = current.map((t) => {
    if (t.id === tweetId) {
      const alreadyLiked = t.likedBy.includes(userId);
      const likedBy = alreadyLiked ? t.likedBy.filter((id) => id !== userId) : [...t.likedBy, userId];
      const likes = Math.max(0, t.likes + (alreadyLiked ? -1 : 1));
      updatedTweet = { ...t, likes, likedBy };
      return updatedTweet;
    }
    return t;
  });
  saveStoredTweets(next);
  return updatedTweet;
}

export function resolveRootTweet(tweet: Tweet, allTweets?: Tweet[]): Tweet {
  if (tweet.isDirectRetweet && tweet.quotedTweet) {
    const live = (allTweets || getStoredTweets()).find((item) => item.id === tweet.quotedTweet!.id);
    return live || tweet.quotedTweet;
  }
  return tweet;
}

export function toggleTweetRetweet(
  tweetId: string,
  userId: string,
  actor?: { authorName: string; authorHandle: string; authorAvatar: string }
): Tweet | null {
  const current = getStoredTweets();
  const clicked = current.find((t) => t.id === tweetId);
  if (!clicked) return null;
  const targetTweet = resolveRootTweet(clicked, current);
  const targetId = targetTweet.id;

  const existingDirectRepost = current.find(
    (t) => t.isDirectRetweet && t.retweetedTweetId === targetId && t.authorId === userId
  );
  const alreadyRetweeted = Boolean(existingDirectRepost) || targetTweet.retweetedBy.includes(userId);

  if (alreadyRetweeted) {
    const next = current
      .filter((t) => !(t.isDirectRetweet && t.retweetedTweetId === targetId && t.authorId === userId))
      .map((t) => {
        if (t.id !== targetId) return t;
        return {
          ...t,
          retweetedBy: t.retweetedBy.filter((id) => id !== userId),
          retweets: Math.max(0, t.retweets - 1),
        };
      });
    saveStoredTweets(next);
    return next.find((t) => t.id === targetId) || null;
  }

  // Direct Retweet: update original tweet counts AND create a visible direct-retweet feed item if actor info provided
  if (actor) {
    return createTweet({
      authorId: userId,
      authorName: actor.authorName,
      authorHandle: actor.authorHandle,
      authorAvatar: actor.authorAvatar,
      content: '',
      quotedTweet: targetTweet,
      retweetedTweetId: targetId,
      isDirectRetweet: true,
    });
  }

  let updatedTweet: Tweet | null = null;
  const next = current.map((t) => {
    if (t.id === targetId) {
      const retweetedBy = t.retweetedBy.includes(userId) ? t.retweetedBy : [...t.retweetedBy, userId];
      updatedTweet = { ...t, retweets: t.retweets + 1, retweetedBy };
      return updatedTweet;
    }
    return t;
  });
  saveStoredTweets(next);
  return updatedTweet;
}

export function toggleTweetBookmark(tweetId: string, userId: string): Tweet | null {
  const current = getStoredTweets();
  let updatedTweet: Tweet | null = null;
  const next = current.map((t) => {
    if (t.id === tweetId) {
      const alreadyBookmarked = t.bookmarkedBy.includes(userId);
      const bookmarkedBy = alreadyBookmarked
        ? t.bookmarkedBy.filter((id) => id !== userId)
        : [...t.bookmarkedBy, userId];
      const bookmarks = Math.max(0, t.bookmarks + (alreadyBookmarked ? -1 : 1));
      updatedTweet = { ...t, bookmarks, bookmarkedBy };
      return updatedTweet;
    }
    return t;
  });
  saveStoredTweets(next);
  return updatedTweet;
}

export function formatOrdinalDay(day: number): string {
  const n = Math.max(1, Math.round(day));
  const mod100 = n % 100;
  if (mod100 >= 11 && mod100 <= 13) return `${n}th`;
  switch (n % 10) {
    case 1:
      return `${n}st`;
    case 2:
      return `${n}nd`;
    case 3:
      return `${n}rd`;
    default:
      return `${n}th`;
  }
}

export function formatPollTimeRemaining(poll: TweetPoll): { isEnded: boolean; label: string } {
  const remainingMs = poll.expiresAt - Date.now();
  if (remainingMs <= 0) {
    return { isEnded: true, label: `Ended (${poll.durationDays}d poll)` };
  }
  const remainingDays = Math.ceil(remainingMs / (24 * 60 * 60 * 1000));
  if (remainingDays > 1) {
    return { isEnded: false, label: `${poll.durationDays}d poll · ${remainingDays}d left` };
  }
  const remainingHours = Math.max(1, Math.ceil(remainingMs / (60 * 60 * 1000)));
  return { isEnded: false, label: `${poll.durationDays}d poll · ${remainingHours}h left` };
}

export function voteInTweetPoll(tweetId: string, optionId: string, userId: string): Tweet | null {
  const current = getStoredTweets();
  let updatedTweet: Tweet | null = null;
  const next = current.map((t) => {
    if (t.id === tweetId && t.poll) {
      // Disallow voting after expiration or duplicate vote
      if (t.poll.expiresAt && Date.now() > t.poll.expiresAt) return t;
      if (t.poll.voterIds[userId]) return t;
      const options = t.poll.options.map((opt) => {
        if (opt.id === optionId) {
          return { ...opt, votes: opt.votes + 1 };
        }
        return opt;
      });
      const voterIds = { ...t.poll.voterIds, [userId]: optionId };
      const totalVotes = t.poll.totalVotes + 1;
      const updatedPoll: TweetPoll = {
        ...t.poll,
        options,
        voterIds,
        totalVotes
      };
      updatedTweet = { ...t, poll: updatedPoll };
      return updatedTweet;
    }
    return t;
  });
  saveStoredTweets(next);
  return updatedTweet;
}

export function addTweetReply(params: {
  tweetId: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  content: string;
}): TweetReply | null {
  const current = getStoredTweets();
  let createdReply: TweetReply | null = null;

  const next = current.map((t) => {
    if (t.id === params.tweetId) {
      const reply: TweetReply = {
        id: `reply_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        tweetId: params.tweetId,
        authorId: params.authorId,
        authorName: params.authorName,
        authorHandle: params.authorHandle.replace(/^@/, ''),
        authorAvatar: params.authorAvatar,
        content: params.content.trim().slice(0, 280),
        timestamp: 'Just now',
        createdAt: Date.now(),
        likes: 0,
        likedBy: []
      };
      createdReply = reply;
      return {
        ...t,
        replies: [...t.replies, reply]
      };
    }
    return t;
  });

  saveStoredTweets(next);
  return createdReply;
}

export function toggleTweetReplyLike(tweetId: string, replyId: string, userId: string): boolean {
  const current = getStoredTweets();
  const next = current.map((t) => {
    if (t.id === tweetId) {
      return {
        ...t,
        replies: t.replies.map((r) => {
          if (r.id === replyId) {
            const alreadyLiked = r.likedBy.includes(userId);
            return {
              ...r,
              likedBy: alreadyLiked ? r.likedBy.filter((id) => id !== userId) : [...r.likedBy, userId],
              likes: Math.max(0, r.likes + (alreadyLiked ? -1 : 1))
            };
          }
          return r;
        })
      };
    }
    return t;
  });
  saveStoredTweets(next);
  return true;
}

export function deleteTweet(tweetId: string): boolean {
  const current = getStoredTweets();
  const target = current.find((t) => t.id === tweetId);
  let next = current.filter((t) => t.id !== tweetId);
  if (target?.isDirectRetweet && target.retweetedTweetId) {
    next = next.map((t) => {
      if (t.id !== target.retweetedTweetId) return t;
      return {
        ...t,
        retweetedBy: t.retweetedBy.filter((id) => id !== target.authorId),
        retweets: Math.max(0, t.retweets - 1),
      };
    });
  }
  saveStoredTweets(next);
  return true;
}

export function buildSharedTweetCardData(rawTweet: Tweet): SharedTweetCardData {
  const tweet = rawTweet.isDirectRetweet && rawTweet.quotedTweet ? rawTweet.quotedTweet : rawTweet;
  const firstLinkPreview = tweet.linkPreviews ? Object.values(tweet.linkPreviews)[0] : undefined;
  const thumbnailUrl =
    tweet.photos?.[0] ||
    tweet.sharedPost?.imageUrl ||
    firstLinkPreview?.imageUrl ||
    firstLinkPreview?.fallbackImageUrl ||
    tweet.quotedTweet?.photos?.[0] ||
    tweet.quotedTweet?.sharedPost?.imageUrl ||
    undefined;

  const videoUrl = (tweet.videos && tweet.videos[0]) || tweet.video || tweet.quotedTweet?.video || undefined;

  let contextLabel = 'Tweeting Wire';
  if (tweet.tradeReceipt) {
    contextLabel = `${tweet.tradeReceipt.side === 'buy' ? 'Buy' : 'Sell'} ${tweet.tradeReceipt.ticker} · ${tweet.tradeReceipt.coinLabel}`;
  } else if (tweet.sharedPost) {
    const typeMap: Record<string, string> = {
      campaign: 'Fundraiser',
      restaurant: 'Restaurant',
      retail: 'Retail Store',
      auction: 'Auction',
      service: 'Service',
      good: 'Marketplace',
    };
    contextLabel = `${typeMap[tweet.sharedPost.itemType] || 'Listing'} · ${tweet.sharedPost.title}`;
  } else if (tweet.poll) {
    contextLabel = `Poll · ${tweet.poll.options.length} options · ${tweet.poll.totalVotes} votes`;
  } else if (tweet.quotedTweet) {
    contextLabel = `Retweet · @${tweet.quotedTweet.authorHandle}`;
  } else if (videoUrl) {
    contextLabel = 'Video Post';
  } else if (tweet.photos && tweet.photos.length > 0) {
    contextLabel = `${tweet.photos.length} ${tweet.photos.length === 1 ? 'Photo' : 'Photos'}`;
  } else if (tweet.tickers && tweet.tickers.length > 0) {
    contextLabel = `Market · ${tweet.tickers.slice(0, 2).map((tk) => `F:${tk}`).join(' · ')}`;
  }

  return {
    tweetId: tweet.id,
    authorId: tweet.authorId,
    authorName: tweet.authorName,
    authorHandle: tweet.authorHandle,
    authorAvatar: tweet.authorAvatar,
    isVerified: tweet.isVerified,
    content: tweet.content || tweet.sharedPost?.description || '',
    timestamp: tweet.timestamp,
    createdAt: tweet.createdAt,
    thumbnailUrl,
    videoUrl,
    contextLabel,
    hashtags: tweet.hashtags?.slice(0, 4),
    tickers: tweet.tickers?.slice(0, 3),
    likes: tweet.likes,
    retweets: tweet.retweets,
    repliesCount: tweet.replies?.length || 0,
    quotedAuthorName: tweet.quotedTweet?.authorName,
    quotedAuthorHandle: tweet.quotedTweet?.authorHandle,
    quotedContent: tweet.quotedTweet?.content,
  };
}


