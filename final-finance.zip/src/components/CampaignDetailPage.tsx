import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  Share2,
  Bookmark,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Users,
  Coins,
  DollarSign,
  Repeat,
  HeartHandshake,
  PauseCircle,
  PlayCircle,
  ExternalLink,
  Layers,
  FileText,
  Video,
  Image as ImageIcon,
  AlertTriangle,
  Receipt,
  MessageSquare,
  ThumbsUp,
  Info,
  Calendar,
  Lock,
  X
} from 'lucide-react';
import {
  UserCampaign,
  UploadedMedia,
  isUserCampaignInitiator,
  isUserCampaignDonor,
  getUserDonationsForCampaign,
  getUserTotalDonatedToCampaign,
  updateCampaignStatus,
  donateToCampaign
} from '../services/fundraisingService';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';

interface CampaignDetailPageProps {
  campaign: UserCampaign;
  currentUser?: AuthSession | null;
  onBack: () => void;
  onRefresh: () => void;
  onOpenAuthModal?: () => void;
}

export const CampaignDetailPage: React.FC<CampaignDetailPageProps> = ({
  campaign,
  currentUser,
  onBack,
  onRefresh,
  onOpenAuthModal
}) => {
  const { addToast } = useApp();
  const activeUserId = currentUser?.username || currentUser?.id || 'you';

  // Ensure page scrolls to top immediately upon entering or changing campaign
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) {
      document.documentElement.scrollTop = 0;
    }
    if (document.body) {
      document.body.scrollTop = 0;
    }
  }, [campaign.id]);

  const isInitiator = isUserCampaignInitiator(campaign, activeUserId);
  const isDonor = isUserCampaignDonor(campaign, activeUserId);
  const userDonations = getUserDonationsForCampaign(campaign, activeUserId);
  const userTotalDonated = getUserTotalDonatedToCampaign(campaign, activeUserId);

  // Active Tab
  const [activeTab, setActiveTab] = useState<'story' | 'milestones' | 'gallery' | 'updates' | 'faq'>('story');

  // Media Gallery Selection (default to video if available, else first image)
  const [selectedMediaIndex, setSelectedMediaIndex] = useState<number>(0);

  // Donation Modal
  const [isDonateModalOpen, setIsDonateModalOpen] = useState(false);
  const [donationModality, setDonationModality] = useState<string>(campaign.acceptedModalities[0] || 'Final Coins (FC)');
  const [donationAmount, setDonationAmount] = useState<string>('500');
  const [donorMessage, setDonorMessage] = useState<string>('');
  const [isSubmittingDonation, setIsSubmittingDonation] = useState(false);

  // Pause Modal
  const [isPauseModalOpen, setIsPauseModalOpen] = useState(false);
  const [pauseReasonInput, setPauseReasonInput] = useState(campaign.pauseReason || '');

  // Bookmark state
  const [isBookmarked, setIsBookmarked] = useState(false);

  // Calculations
  const progressPercent = Math.min(100, Math.round((campaign.raisedAmountUSD / campaign.targetAmountUSD) * 100));
  
  const endDate = new Date(campaign.endDateTime);
  const now = new Date();
  const diffMs = endDate.getTime() - now.getTime();
  const daysRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
  const isExpired = diffMs <= 0;

  // Media fallback
  const mediaList: UploadedMedia[] = campaign.mediaList && campaign.mediaList.length > 0
    ? campaign.mediaList
    : [
        {
          id: 'def-1',
          url: campaign.bannerUrl,
          name: 'campaign_banner.jpg',
          type: 'image',
          sizeFormatted: '2.5 MB',
          caption: campaign.title
        }
      ];

  const currentMedia = mediaList[selectedMediaIndex] || mediaList[0];

  const handleBack = () => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    onBack();
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: campaign.title,
          text: campaign.shortDescription,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        addToast({
          type: 'success',
          title: 'Link Copied',
          message: 'Campaign share link copied to clipboard.'
        });
      }
    } catch {
      // Ignored
    }
  };

  const handleToggleStatus = (nextStatus: 'active' | 'paused') => {
    if (nextStatus === 'paused') {
      setIsPauseModalOpen(true);
      return;
    }

    const success = updateCampaignStatus(campaign.id, 'active');
    if (success) {
      addToast({
        type: 'success',
        title: 'Campaign Resumed',
        message: `"${campaign.title}" is now active.`
      });
      onRefresh();
    }
  };

  const handleConfirmPause = () => {
    const success = updateCampaignStatus(
      campaign.id,
      'paused',
      pauseReasonInput.trim() || 'Voluntarily paused by campaign initiator.'
    );
    if (success) {
      addToast({
        type: 'info',
        title: 'Campaign Paused',
        message: 'Campaign has been paused. Escrow deposits remain secure.'
      });
      setIsPauseModalOpen(false);
      onRefresh();
    }
  };

  const handleSubmitDonation = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(donationAmount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      addToast({
        type: 'error',
        title: 'Invalid Amount',
        message: 'Please enter an amount greater than 0.'
      });
      return;
    }

    setIsSubmittingDonation(true);
    setTimeout(() => {
      const donorName = currentUser?.name || (currentUser?.username ? `@${currentUser.username}` : 'You (Current User)');
      const donorHandle = currentUser?.username || 'you';
      const donorId = currentUser?.username || 'you';
      const donorAvatar = currentUser?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80';

      const success = donateToCampaign(campaign.id, {
        donorId,
        donorHandle,
        donorName,
        donorAvatar,
        amountUSD: numericAmount,
        modality: donationModality,
        message: donorMessage.trim() || undefined
      });

      setIsSubmittingDonation(false);
      if (success) {
        addToast({
          type: 'success',
          title: 'Contribution Successful',
          message: `You backed "${campaign.title}" with $${numericAmount.toLocaleString()} via ${donationModality}.`
        });
        setIsDonateModalOpen(false);
        setDonorMessage('');
        onRefresh();
      }
    }, 350);
  };

  return (
    <div className="space-y-6 pb-16 max-w-7xl mx-auto">
      {/* Clean Top Navigation Bar */}
      <div className="flex items-center justify-between gap-3 bg-white rounded-2xl border border-slate-200 px-4 py-2.5 shadow-xs">
        <button
          type="button"
          onClick={handleBack}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-slate-600" />
          <span>Back to Campaigns</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Initiator Controls */}
          {isInitiator && (
            <>
              {campaign.status === 'active' ? (
                <button
                  type="button"
                  onClick={() => setIsPauseModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-semibold transition-colors cursor-pointer"
                >
                  <PauseCircle className="w-3.5 h-3.5 text-amber-600" />
                  <span>Pause Campaign</span>
                </button>
              ) : campaign.status === 'paused' ? (
                <button
                  type="button"
                  onClick={() => handleToggleStatus('active')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 text-xs font-semibold transition-colors cursor-pointer"
                >
                  <PlayCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Resume Campaign</span>
                </button>
              ) : null}
            </>
          )}

          <button
            type="button"
            onClick={() => {
              setIsBookmarked(!isBookmarked);
              addToast({
                type: 'info',
                title: isBookmarked ? 'Removed Bookmark' : 'Saved to Watchlist',
                message: isBookmarked ? 'Campaign removed from watchlist.' : 'Saved to your watched campaigns.'
              });
            }}
            className={`p-2 rounded-xl border transition-colors cursor-pointer ${
              isBookmarked
                ? 'bg-amber-50 border-amber-300 text-amber-600'
                : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-600'
            }`}
            title="Bookmark campaign"
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-500' : ''}`} />
          </button>

          <button
            type="button"
            onClick={handleShare}
            className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
            title="Share campaign"
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => {
              if (!currentUser && onOpenAuthModal) {
                onOpenAuthModal();
                return;
              }
              setIsDonateModalOpen(true);
            }}
            disabled={campaign.status === 'completed' || campaign.status === 'paused'}
            className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs ${
              campaign.status === 'completed' || campaign.status === 'paused'
                ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
            }`}
          >
            <HeartHandshake className="w-4 h-4" />
            <span>{isDonor ? 'Contribute More' : 'Back Campaign'}</span>
          </button>
        </div>
      </div>

      {/* Paused Notice (Only if campaign is currently paused) */}
      {campaign.status === 'paused' && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-amber-950">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5 text-xs">
            <div className="font-bold flex items-center gap-2">
              <span>Campaign Temporarily Paused</span>
              {isInitiator && (
                <span className="font-mono text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded font-semibold">
                  By You
                </span>
              )}
            </div>
            <p className="text-amber-900 leading-relaxed">
              {campaign.pauseReason || 'This campaign is temporarily paused by the initiator. Escrow deposits remain safe.'}
            </p>
          </div>
        </div>
      )}

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Media Player & Overview (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Header Metadata */}
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="px-2.5 py-0.5 rounded-md font-mono font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                {campaign.category}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-md font-mono font-bold uppercase ${
                  campaign.status === 'active'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : campaign.status === 'completed'
                    ? 'bg-sky-100 text-sky-800 border border-sky-300'
                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}
              >
                {campaign.status}
              </span>
              {isInitiator && campaign.status === 'paused' && (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-amber-200 text-amber-950 border border-amber-300">
                  Paused by You
                </span>
              )}
              {isInitiator && isDonor ? (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-emerald-900 text-white">
                  Created & Co-Backed (${userTotalDonated.toLocaleString()})
                </span>
              ) : isInitiator ? (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-slate-900 text-white">
                  Created by You
                </span>
              ) : isDonor ? (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                  Backed (${userTotalDonated.toLocaleString()})
                </span>
              ) : null}
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 leading-tight">
              {campaign.title}
            </h1>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {campaign.shortDescription}
            </p>
          </div>

          {/* Featured Media Player / Image Display */}
          <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-200 shadow-sm aspect-video">
            {currentMedia.type === 'video' ? (
              <video
                key={currentMedia.url}
                src={currentMedia.url}
                controls
                autoPlay={false}
                className="w-full h-full object-cover"
                poster={campaign.bannerUrl}
              />
            ) : (
              <img
                key={currentMedia.url}
                src={currentMedia.url}
                alt={currentMedia.caption || campaign.title}
                className="w-full h-full object-cover"
              />
            )}

            {currentMedia.caption && (
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 text-white text-xs font-mono flex items-center justify-between">
                <span className="line-clamp-1">{currentMedia.caption}</span>
                <span className="text-[11px] text-neutral-300 shrink-0 ml-2">
                  {currentMedia.sizeFormatted}
                </span>
              </div>
            )}
          </div>

          {/* Media Carousel (if > 1 item) */}
          {mediaList.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {mediaList.map((med, idx) => (
                <button
                  key={med.id}
                  type="button"
                  onClick={() => setSelectedMediaIndex(idx)}
                  className={`relative w-18 h-12 rounded-lg overflow-hidden border-2 shrink-0 transition-all cursor-pointer ${
                    selectedMediaIndex === idx
                      ? 'border-emerald-600 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={med.url} alt={med.name} className="w-full h-full object-cover" />
                  {med.type === 'video' && (
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-white">
                      <Video className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Funding Progress & Initiator Info (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Main Funding Progress Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            {/* Raised vs Target */}
            <div className="space-y-1.5">
              <div className="flex items-baseline justify-between">
                <div>
                  <span className="font-serif text-3xl font-bold text-slate-900">
                    ${campaign.raisedAmountUSD.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-500 font-mono ml-1.5">
                    raised
                  </span>
                </div>
                <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  {progressPercent}%
                </span>
              </div>

              <div className="w-full h-2.5 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    campaign.status === 'completed'
                      ? 'bg-sky-500'
                      : campaign.status === 'paused'
                      ? 'bg-amber-500'
                      : 'bg-emerald-600'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-xs font-mono text-slate-500 pt-0.5">
                <span>Target: ${campaign.targetAmountUSD.toLocaleString()}</span>
                <span>{campaign.backersCount.toLocaleString()} Backers</span>
              </div>
            </div>

            {/* Key Stats */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Timeline</span>
                </div>
                <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                  {campaign.status === 'completed' ? 'Fully Funded' : isExpired ? 'Ended' : `${daysRemaining} Days Left`}
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Escrow</span>
                </div>
                <div className="text-sm font-bold font-mono text-emerald-700 mt-0.5">
                  Verified Vault
                </div>
              </div>
            </div>

            {/* Target Breakdown */}
            <div className="space-y-1.5 pt-1 border-t border-slate-100">
              <span className="text-[11px] font-mono font-semibold text-slate-500 uppercase">
                Accepted Modalities
              </span>
              <div className="grid grid-cols-2 gap-1.5 text-xs font-mono">
                {campaign.targetBreakdown.acceptsFinalCoins && (
                  <div className="flex items-center justify-between bg-emerald-50/70 border border-emerald-200 px-2.5 py-1.5 rounded-lg text-emerald-950">
                    <span className="flex items-center gap-1 font-semibold text-[11px]">
                      <Coins className="w-3 h-3 text-emerald-600" />
                      Final Coins
                    </span>
                    <span>${campaign.targetBreakdown.finalCoinsAmount.toLocaleString()}</span>
                  </div>
                )}
                {campaign.targetBreakdown.acceptsFiat && (
                  <div className="flex items-center justify-between bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-lg text-slate-800">
                    <span className="flex items-center gap-1 font-semibold text-[11px]">
                      <DollarSign className="w-3 h-3 text-slate-600" />
                      Fiat USD
                    </span>
                    <span>${campaign.targetBreakdown.fiatAmount.toLocaleString()}</span>
                  </div>
                )}
                {campaign.targetBreakdown.acceptsStablecoins && (
                  <div className="flex items-center justify-between bg-blue-50 border border-blue-200 px-2.5 py-1.5 rounded-lg text-blue-900">
                    <span className="flex items-center gap-1 font-semibold text-[11px]">
                      <Repeat className="w-3 h-3 text-blue-600" />
                      USDC/USDT
                    </span>
                    <span>${campaign.targetBreakdown.stablecoinsAmount.toLocaleString()}</span>
                  </div>
                )}
                {campaign.targetBreakdown.acceptsBarter && (
                  <div className="flex items-center justify-between bg-amber-50 border border-amber-200 px-2.5 py-1.5 rounded-lg text-amber-950">
                    <span className="flex items-center gap-1 font-semibold text-[11px]">
                      <Layers className="w-3 h-3 text-amber-600" />
                      Barter
                    </span>
                    <span className="text-[10px] truncate max-w-[80px]">Accepted</span>
                  </div>
                )}
              </div>
            </div>

            {/* Back Campaign CTA */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => {
                  if (!currentUser && onOpenAuthModal) {
                    onOpenAuthModal();
                    return;
                  }
                  setIsDonateModalOpen(true);
                }}
                disabled={campaign.status === 'completed' || campaign.status === 'paused'}
                className={`w-full py-3 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 shadow-xs ${
                  campaign.status === 'completed' || campaign.status === 'paused'
                    ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                }`}
              >
                <HeartHandshake className="w-4 h-4" />
                <span>
                  {campaign.status === 'completed'
                    ? 'Campaign Fully Funded'
                    : campaign.status === 'paused'
                    ? 'Campaign Paused'
                    : isDonor
                    ? 'Contribute Additional Funds'
                    : 'Back This Campaign'}
                </span>
              </button>
            </div>
          </div>

          {/* Initiator Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400 font-semibold uppercase text-[11px]">
                Campaign Initiator
              </span>
              {campaign.verifiedCreator && (
                <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  Verified
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              <img
                src={campaign.creatorAvatar}
                alt={campaign.creatorName}
                className="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <span>{campaign.creatorName}</span>
                  {isInitiator && (
                    <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-bold">
                      YOU
                    </span>
                  )}
                </h4>
                <div className="text-xs font-mono text-slate-500">
                  @{campaign.creatorHandle}
                </div>
              </div>
            </div>

            {campaign.creatorBio && (
              <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                {campaign.creatorBio}
              </p>
            )}

            {campaign.creatorWebsite && (
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Website:</span>
                <a
                  href={campaign.creatorWebsite}
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-700 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>{campaign.creatorWebsite.replace(/^https?:\/\//, '')}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Tabs Row */}
      <div className="border-b border-slate-200">
        <div className="flex items-center gap-1 overflow-x-auto pb-px">
          {[
            { id: 'story', label: 'Story & Narrative', icon: FileText },
            { id: 'milestones', label: `Milestones (${campaign.milestones?.length || 3})`, icon: CheckCircle2 },
            { id: 'gallery', label: `Gallery (${mediaList.length})`, icon: ImageIcon },
            { id: 'updates', label: `Updates & Backers (${(campaign.updates?.length || 0) + (campaign.donations?.length || 0)})`, icon: Users },
            { id: 'faq', label: 'FAQ & Risks', icon: Info },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2.5 text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors flex items-center gap-1.5 border-b-2 cursor-pointer ${
                  isSelected
                    ? 'border-emerald-600 text-emerald-950 font-bold'
                    : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-600' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Panels */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        {/* Story Tab */}
        {activeTab === 'story' && (
          <div className="max-w-3xl space-y-4">
            <div className="text-slate-700 text-xs sm:text-sm leading-relaxed space-y-3">
              {campaign.fullStory.split('\n\n').map((para, i) => {
                if (para.startsWith('### ')) {
                  return (
                    <h3 key={`h3-${i}`} className="font-serif text-base sm:text-lg font-bold text-slate-900 mt-5 mb-1.5">
                      {para.replace('### ', '')}
                    </h3>
                  );
                }
                return (
                  <p key={`p-${i}`} className="leading-relaxed">
                    {para}
                  </p>
                );
              })}
            </div>

            {campaign.targetBreakdown.acceptsBarter && campaign.targetBreakdown.barterDescription && (
              <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 space-y-1 mt-4">
                <div className="flex items-center gap-1.5 text-amber-950 font-bold text-xs">
                  <Layers className="w-3.5 h-3.5 text-amber-600" />
                  <span>Physical Barter Goods Accepted</span>
                </div>
                <p className="text-xs text-amber-900 leading-relaxed">
                  {campaign.targetBreakdown.barterDescription}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Milestones Tab */}
        {activeTab === 'milestones' && (
          <div className="space-y-4 max-w-3xl">
            <div className="space-y-1">
              <h3 className="font-serif text-lg font-bold text-slate-900">
                Milestone Escrow Schedule
              </h3>
              <p className="text-xs text-slate-500">
                Funds are held in on-chain multi-signature timelock vaults and released per verified phase.
              </p>
            </div>

            <div className="space-y-3">
              {(campaign.milestones || [
                {
                  id: 'm-1',
                  title: 'Phase 1: Architecture Blueprint & Lab Validation',
                  targetUSD: Math.round(campaign.targetAmountUSD * 0.3),
                  description: 'Engineering lab setup, component sourcing, and preliminary zero-knowledge stress testing.',
                  status: 'completed',
                  escrowReleasePercent: 30,
                  date: '2026-08-01',
                  txHash: '0x38419280918e907d6b31c884f2b604e287a9e102'
                },
                {
                  id: 'm-2',
                  title: 'Phase 2: Alpha Hardware Assembly & Field Prototyping',
                  targetUSD: Math.round(campaign.targetAmountUSD * 0.5),
                  description: 'Manufacturing of core nodes and closed-circuit trial testing.',
                  status: 'in_progress',
                  escrowReleasePercent: 50,
                  date: '2026-09-01'
                },
                {
                  id: 'm-3',
                  title: 'Phase 3: Public Network Release & Full Deployment',
                  targetUSD: campaign.targetAmountUSD,
                  description: 'Full commercial rollout and open-source SDK distribution.',
                  status: 'upcoming',
                  escrowReleasePercent: 20,
                  date: '2026-09-20'
                }
              ]).map((ms, idx) => (
                <div
                  key={ms.id}
                  className={`rounded-xl border p-3.5 sm:p-4 ${
                    ms.status === 'completed'
                      ? 'bg-emerald-50/40 border-emerald-200'
                      : ms.status === 'in_progress'
                      ? 'bg-blue-50/30 border-blue-200'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-mono font-bold shrink-0 mt-0.5 ${
                          ms.status === 'completed'
                            ? 'bg-emerald-600 text-white'
                            : ms.status === 'in_progress'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-300 text-slate-700'
                        }`}
                      >
                        {idx + 1}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                          {ms.title}
                        </h4>
                        <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                          {ms.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 sm:text-right shrink-0">
                      <span className="text-xs font-mono font-bold text-slate-900">
                        ${ms.targetUSD.toLocaleString()}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                          ms.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : ms.status === 'in_progress'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {ms.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Gallery Tab */}
        {activeTab === 'gallery' && (
          <div className="space-y-4">
            <h3 className="font-serif text-lg font-bold text-slate-900">
              Media & Documentation
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {mediaList.map((med, i) => (
                <div
                  key={med.id}
                  onClick={() => setSelectedMediaIndex(i)}
                  className="group relative rounded-xl overflow-hidden bg-slate-900 border border-slate-200 aspect-video cursor-pointer"
                >
                  <img
                    src={med.url}
                    alt={med.name}
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-200"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent p-2.5 flex flex-col justify-end text-white text-xs">
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="uppercase bg-white/20 px-1.5 py-0.5 rounded">
                        {med.type}
                      </span>
                      <span className="text-neutral-300">{med.sizeFormatted}</span>
                    </div>
                    {med.caption && (
                      <p className="mt-1 text-xs line-clamp-1 text-neutral-200">
                        {med.caption}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Updates & Backers Combined Tab */}
        {activeTab === 'updates' && (
          <div className="space-y-6 max-w-3xl">
            {/* Updates Section */}
            <div className="space-y-3">
              <h3 className="font-serif text-lg font-bold text-slate-900">
                Creator Field Updates
              </h3>
              <div className="space-y-2.5">
                {(campaign.updates || [
                  {
                    id: 'up-def-1',
                    title: 'Campaign Launched on Final Finance',
                    date: campaign.createdAt,
                    author: campaign.creatorName,
                    likesCount: 24,
                    content: 'Campaign is live and open for multi-asset backing. Thank you to our initial community supporters.'
                  }
                ]).map((up) => (
                  <div key={up.id} className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                        {up.title}
                      </h4>
                      <span className="text-[11px] font-mono text-slate-400">
                        {up.date}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      {up.content}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Backers Section */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-lg font-bold text-slate-900">
                  Recent Backers
                </h3>
                <span className="text-xs font-mono text-slate-500">
                  {campaign.donations?.length || 0} Backers Recorded
                </span>
              </div>

              <div className="space-y-2">
                {campaign.donations && campaign.donations.length > 0 ? (
                  campaign.donations.map((don) => (
                    <div key={don.id} className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={don.donorAvatar}
                          alt={don.donorName}
                          className="w-8 h-8 rounded-lg object-cover border border-slate-200 shrink-0"
                        />
                        <div>
                          <div className="font-bold text-slate-900">
                            {don.donorName}
                          </div>
                          <div className="text-[11px] font-mono text-slate-400">
                            {don.modality} • {new Date(don.timestamp).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <span className="font-mono font-bold text-emerald-700">
                        ${don.amountUSD.toLocaleString()}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6 text-slate-400 font-mono text-xs">
                    No public donations recorded yet.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* FAQ & Risks Tab */}
        {activeTab === 'faq' && (
          <div className="space-y-4 max-w-3xl">
            <h3 className="font-serif text-lg font-bold text-slate-900">
              Frequently Asked Questions
            </h3>
            
            <div className="space-y-2.5">
              {(campaign.faqs || [
                {
                  question: 'How are backer funds safeguarded?',
                  answer: 'All contributions are locked in multi-signature smart contract escrow vaults. Funds are only unlocked upon independent verification of milestones.'
                },
                {
                  question: 'Can I request a refund if milestones fail?',
                  answer: 'Yes. If a project fails milestone verification or is cancelled, remaining escrow capital is returned proportionally to donors in their original asset modality.'
                }
              ]).map((faq, i) => (
                <div key={`faq-${i}`} className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                    {faq.question}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>

            {campaign.risksAndChallenges && (
              <div className="bg-slate-100 border border-slate-300 rounded-xl p-4 space-y-1 mt-4">
                <div className="flex items-center gap-1.5 text-slate-900 font-bold text-xs">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  <span>Technical Risks & Challenges</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {campaign.risksAndChallenges}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Donation Modal */}
      <AnimatePresence>
        {isDonateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-lg font-bold text-slate-900">
                    Back This Campaign
                  </h3>
                  <p className="text-xs text-slate-500 font-mono truncate max-w-[280px]">
                    {campaign.title}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsDonateModalOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSubmitDonation} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-xs font-mono font-semibold text-slate-700">
                    Contribution Modality
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {campaign.acceptedModalities.map((mod) => (
                      <button
                        key={mod}
                        type="button"
                        onClick={() => setDonationModality(mod)}
                        className={`p-2 rounded-xl border text-xs font-mono text-left transition-all cursor-pointer ${
                          donationModality === mod
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {mod}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono font-semibold text-slate-700">
                    Amount (USD Equivalent)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-xs">$</span>
                    <input
                      type="number"
                      min="1"
                      step="any"
                      value={donationAmount}
                      onChange={(e) => setDonationAmount(e.target.value)}
                      required
                      className="w-full pl-7 pr-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-xs"
                      placeholder="500"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 pt-1">
                    {[100, 250, 500, 1000, 5000].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setDonationAmount(preset.toString())}
                        className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-mono font-semibold transition-colors cursor-pointer"
                      >
                        ${preset}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono font-semibold text-slate-700">
                    Public Note (Optional)
                  </label>
                  <textarea
                    rows={2}
                    value={donorMessage}
                    onChange={(e) => setDonorMessage(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                    placeholder="Supporting open innovation..."
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsDonateModalOpen(false)}
                    className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingDonation}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>{isSubmittingDonation ? 'Confirming...' : 'Confirm Pledge'}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Pause Modal */}
      <AnimatePresence>
        {isPauseModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-3.5"
            >
              <div className="flex items-center gap-2.5 text-amber-700">
                <PauseCircle className="w-5 h-5 shrink-0" />
                <h3 className="font-serif text-base font-bold text-slate-900">
                  Pause Campaign Pledges
                </h3>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                Pausing temporarily stops new pledges from being made. Escrow funds remain safe. Reason for backers:
              </p>

              <textarea
                rows={2}
                value={pauseReasonInput}
                onChange={(e) => setPauseReasonInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs"
                placeholder="E.g., Temporarily paused while awaiting telemetry approval..."
              />

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsPauseModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPause}
                  className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
                >
                  Confirm Pause
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
