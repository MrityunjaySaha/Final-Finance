import dns from 'node:dns/promises';
import net from 'node:net';

export interface ServerLinkPreviewResult {
  url: string;
  finalUrl: string;
  domain: string;
  title: string;
  description: string;
  imageUrl?: string;
  fallbackImageUrl?: string;
  siteName?: string;
  authorName?: string;
  mediaType?: 'video' | 'audio' | 'article' | 'website';
  videoId?: string;
  faviconUrl?: string;
  resolved: boolean;
}

interface CacheEntry {
  data: ServerLinkPreviewResult;
  expiresAt: number;
}

const PREVIEW_CACHE_TTL_MS = 15 * 60 * 1000;
const MAX_CACHE_SIZE = 400;
const FETCH_TIMEOUT_MS = 6500;
const MAX_HTML_BYTES = 1_500_000;
const MAX_REDIRECTS = 3;

const previewCache = new Map<string, CacheEntry>();

function getCached(key: string): ServerLinkPreviewResult | null {
  const entry = previewCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    previewCache.delete(key);
    return null;
  }
  return entry.data;
}

function setCached(key: string, data: ServerLinkPreviewResult): void {
  if (previewCache.size >= MAX_CACHE_SIZE) {
    const oldestKey = previewCache.keys().next().value;
    if (oldestKey) previewCache.delete(oldestKey);
  }
  previewCache.set(key, {
    data,
    expiresAt: Date.now() + PREVIEW_CACHE_TTL_MS,
  });
}

function isPrivateOrBlockedIp(ip: string): boolean {
  const cleaned = ip.trim().toLowerCase();
  if (!cleaned) return true;

  // Handle IPv4-mapped IPv6 like ::ffff:127.0.0.1
  if (cleaned.startsWith('::ffff:')) {
    return isPrivateOrBlockedIp(cleaned.slice(7));
  }

  const family = net.isIP(cleaned);
  if (family === 4) {
    const parts = cleaned.split('.').map(Number);
    if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) return true;
    const [a, b] = parts;
    if (a === 0) return true; // 0.0.0.0/8
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 127) return true; // 127.0.0.0/8 loopback
    if (a === 169 && b === 254) return true; // 169.254.0.0/16 link-local & cloud metadata
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 100 && b >= 64 && b <= 127) return true; // 100.64.0.0/10 CGNAT
    if (a >= 224) return true; // Multicast & reserved
    return false;
  }

  if (family === 6) {
    if (cleaned === '::' || cleaned === '::1') return true;
    if (cleaned.startsWith('fc') || cleaned.startsWith('fd')) return true; // Unique local fc00::/7
    if (cleaned.startsWith('fe8') || cleaned.startsWith('fe9') || cleaned.startsWith('fea') || cleaned.startsWith('feb')) {
      return true; // Link-local fe80::/10
    }
    if (cleaned.startsWith('ff')) return true; // Multicast
    return false;
  }

  return true;
}

async function assertSafeExternalUrl(rawUrl: string): Promise<URL> {
  if (!rawUrl || rawUrl.length > 2048) {
    throw new Error('Invalid URL length');
  }
  const parsed = new URL(rawUrl);
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Only http and https URLs are supported');
  }
  const hostname = parsed.hostname.toLowerCase();
  if (
    !hostname ||
    hostname === 'localhost' ||
    hostname.endsWith('.localhost') ||
    hostname.endsWith('.local') ||
    hostname.endsWith('.internal') ||
    hostname === 'metadata.google.internal'
  ) {
    throw new Error('Blocked host');
  }

  if (net.isIP(hostname)) {
    if (isPrivateOrBlockedIp(hostname)) {
      throw new Error('Blocked private IP');
    }
    return parsed;
  }

  try {
    const records = await dns.lookup(hostname, { all: true });
    if (!records || records.length === 0) {
      throw new Error('DNS resolution failed');
    }
    for (const rec of records) {
      if (isPrivateOrBlockedIp(rec.address)) {
        throw new Error('Blocked private network address');
      }
    }
  } catch (err: any) {
    if (err?.message?.startsWith('Blocked')) throw err;
    throw new Error('Could not resolve host');
  }

  return parsed;
}

export function extractYouTubeVideoId(urlStr: string): string | null {
  try {
    const u = new URL(urlStr);
    const host = u.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'youtu.be') {
      const id = u.pathname.split('/').filter(Boolean)[0];
      return id && /^[a-zA-Z0-9_-]{6,20}$/.test(id) ? id : null;
    }
    if (host.endsWith('youtube.com') || host === 'youtube-nocookie.com') {
      const v = u.searchParams.get('v');
      if (v && /^[a-zA-Z0-9_-]{6,20}$/.test(v)) return v;
      const segments = u.pathname.split('/').filter(Boolean);
      if (segments.length >= 2 && ['shorts', 'live', 'embed', 'v', 'watch'].includes(segments[0])) {
        const id = segments[1];
        if (id && /^[a-zA-Z0-9_-]{6,20}$/.test(id)) return id;
      }
    }
  } catch {}
  return null;
}

function decodeHtmlEntities(input: string): string {
  if (!input) return '';
  return input
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;|&#x27;/gi, "'")
    .replace(/&nbsp;/gi, ' ')
    .replace(/&mdash;/gi, '—')
    .replace(/&ndash;/gi, '–')
    .replace(/&hellip;/gi, '…')
    .replace(/&#(\d+);/g, (_, dec) => {
      const code = Number(dec);
      return Number.isFinite(code) && code > 0 && code < 0x10ffff ? String.fromCodePoint(code) : _;
    })
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => {
      const code = parseInt(hex, 16);
      return Number.isFinite(code) && code > 0 && code < 0x10ffff ? String.fromCodePoint(code) : _;
    })
    .replace(/\s+/g, ' ')
    .trim();
}

function resolveHttpImageUrl(candidate: string | undefined, baseUrl: string): string | undefined {
  if (!candidate) return undefined;
  const trimmed = decodeHtmlEntities(candidate).trim();
  if (!trimmed || trimmed.startsWith('data:') || trimmed.startsWith('javascript:')) return undefined;
  try {
    const resolved = new URL(trimmed, baseUrl);
    if (resolved.protocol !== 'http:' && resolved.protocol !== 'https:') return undefined;
    return resolved.toString();
  } catch {
    return undefined;
  }
}

function parseMetaAttributes(tag: string): Record<string, string> {
  const attrs: Record<string, string> = {};
  const attrRegex = /([a-zA-Z0-9_:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/g;
  let match: RegExpExecArray | null;
  while ((match = attrRegex.exec(tag)) !== null) {
    const key = match[1].toLowerCase();
    const val = match[2] ?? match[3] ?? match[4] ?? '';
    attrs[key] = val;
  }
  return attrs;
}

function extractHtmlMetadata(html: string, baseUrl: string) {
  const metaMap = new Map<string, string>();
  const metaRegex = /<meta\b[^>]*>/gi;
  let m: RegExpExecArray | null;
  while ((m = metaRegex.exec(html)) !== null) {
    const attrs = parseMetaAttributes(m[0]);
    const key = (attrs.property || attrs.name || attrs.itemprop || '').toLowerCase().trim();
    const content = attrs.content;
    if (key && content && !metaMap.has(key)) {
      metaMap.set(key, decodeHtmlEntities(content));
    }
  }

  let linkImageSrc: string | undefined;
  let linkIcon: string | undefined;
  const linkRegex = /<link\b[^>]*>/gi;
  while ((m = linkRegex.exec(html)) !== null) {
    const attrs = parseMetaAttributes(m[0]);
    const rel = (attrs.rel || '').toLowerCase();
    const href = attrs.href;
    if (!href) continue;
    if (rel === 'image_src' && !linkImageSrc) {
      linkImageSrc = href;
    } else if ((rel.includes('apple-touch-icon') || rel === 'icon' || rel === 'shortcut icon') && !linkIcon) {
      linkIcon = href;
    }
  }

  const titleMatch = html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i);
  const rawPageTitle = titleMatch ? decodeHtmlEntities(titleMatch[1]) : '';

  // Parse JSON-LD if available for precise video/article headline & thumbnailUrl
  let ldTitle = '';
  let ldDescription = '';
  let ldImage = '';
  let ldAuthor = '';
  let ldType = '';
  const ldRegex = /<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  while ((m = ldRegex.exec(html)) !== null) {
    try {
      const parsed = JSON.parse(m[1].trim());
      const items = Array.isArray(parsed)
        ? parsed
        : Array.isArray(parsed?.['@graph'])
          ? parsed['@graph']
          : [parsed];
      for (const item of items) {
        if (!item || typeof item !== 'object') continue;
        if (!ldTitle && (item.headline || item.name)) {
          ldTitle = decodeHtmlEntities(String(item.headline || item.name));
        }
        if (!ldDescription && item.description) {
          ldDescription = decodeHtmlEntities(String(item.description));
        }
        if (!ldImage) {
          const thumb = item.thumbnailUrl || item.image;
          if (typeof thumb === 'string') ldImage = thumb;
          else if (Array.isArray(thumb) && typeof thumb[0] === 'string') ldImage = thumb[0];
          else if (thumb && typeof thumb === 'object' && typeof thumb.url === 'string') ldImage = thumb.url;
        }
        if (!ldAuthor && item.author) {
          if (typeof item.author === 'string') ldAuthor = decodeHtmlEntities(item.author);
          else if (typeof item.author?.name === 'string') ldAuthor = decodeHtmlEntities(item.author.name);
        }
        if (!ldType && typeof item['@type'] === 'string') {
          ldType = item['@type'].toLowerCase();
        }
      }
    } catch {}
  }

  const ogType = (metaMap.get('og:type') || '').toLowerCase();
  const hasVideoMeta =
    ogType.includes('video') ||
    metaMap.has('og:video') ||
    metaMap.has('og:video:url') ||
    metaMap.has('twitter:player') ||
    ldType.includes('video');

  const title =
    metaMap.get('og:title') ||
    metaMap.get('twitter:title') ||
    ldTitle ||
    metaMap.get('title') ||
    rawPageTitle;

  const description =
    metaMap.get('og:description') ||
    metaMap.get('twitter:description') ||
    metaMap.get('description') ||
    ldDescription ||
    '';

  const rawImage =
    metaMap.get('og:image:secure_url') ||
    metaMap.get('og:image') ||
    metaMap.get('og:image:url') ||
    metaMap.get('twitter:image:src') ||
    metaMap.get('twitter:image') ||
    ldImage ||
    linkImageSrc;

  const imageUrl = resolveHttpImageUrl(rawImage, baseUrl);
  const faviconUrl = resolveHttpImageUrl(linkIcon, baseUrl) || `${new URL(baseUrl).origin}/favicon.ico`;
  const siteName = metaMap.get('og:site_name') || undefined;
  const authorName = metaMap.get('author') || metaMap.get('article:author') || ldAuthor || undefined;

  let mediaType: ServerLinkPreviewResult['mediaType'] = 'website';
  if (hasVideoMeta) mediaType = 'video';
  else if (ogType.includes('music') || ogType.includes('audio')) mediaType = 'audio';
  else if (ogType.includes('article') || ldType.includes('article')) mediaType = 'article';

  return {
    title,
    description,
    imageUrl,
    faviconUrl,
    siteName,
    authorName,
    mediaType,
  };
}

async function fetchWithTimeoutAndRedirects(initialUrl: URL): Promise<{ finalUrl: string; contentType: string; text: string } | null> {
  let currentUrl = initialUrl;

  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    await assertSafeExternalUrl(currentUrl.toString());

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

    try {
      const response = await fetch(currentUrl.toString(), {
        method: 'GET',
        redirect: 'manual',
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (compatible; LinkPreviewBot/1.0; +https://example.com) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
        },
      });

      if (response.status >= 300 && response.status < 400) {
        const location = response.headers.get('location');
        if (!location) return null;
        currentUrl = new URL(location, currentUrl.toString());
        continue;
      }

      if (!response.ok) {
        return null;
      }

      const contentType = (response.headers.get('content-type') || '').toLowerCase();
      if (!contentType.includes('text/html') && !contentType.includes('application/xhtml') && !contentType.includes('application/json')) {
        return null;
      }

      const reader = response.body?.getReader();
      if (!reader) {
        const text = await response.text();
        return { finalUrl: currentUrl.toString(), contentType, text: text.slice(0, MAX_HTML_BYTES) };
      }

      const chunks: Uint8Array[] = [];
      let total = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          total += value.byteLength;
          if (total > MAX_HTML_BYTES) {
            chunks.push(value.subarray(0, value.byteLength - (total - MAX_HTML_BYTES)));
            await reader.cancel().catch(() => {});
            break;
          }
          chunks.push(value);
        }
      }

      const decoder = new TextDecoder('utf-8', { fatal: false });
      const text = decoder.decode(Buffer.concat(chunks));
      return { finalUrl: currentUrl.toString(), contentType, text };
    } finally {
      clearTimeout(timer);
    }
  }

  return null;
}

async function fetchJsonEndpoint(endpointUrl: string): Promise<any | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 4500);
  try {
    const res = await fetch(endpointUrl, {
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
        'User-Agent': 'Mozilla/5.0 (compatible; LinkPreviewBot/1.0)',
      },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function tryOEmbedResolution(targetUrl: string, domain: string): Promise<Partial<ServerLinkPreviewResult> | null> {
  const encoded = encodeURIComponent(targetUrl);

  let oembedUrl: string | null = null;
  let defaultSiteName: string | undefined;
  let defaultMediaType: ServerLinkPreviewResult['mediaType'] = 'video';

  if (domain.includes('youtube.com') || domain === 'youtu.be' || domain === 'youtube-nocookie.com') {
    oembedUrl = `https://www.youtube.com/oembed?url=${encoded}&format=json`;
    defaultSiteName = 'YouTube';
    defaultMediaType = 'video';
  } else if (domain.includes('vimeo.com')) {
    oembedUrl = `https://vimeo.com/api/oembed.json?url=${encoded}`;
    defaultSiteName = 'Vimeo';
    defaultMediaType = 'video';
  } else if (domain.includes('tiktok.com')) {
    oembedUrl = `https://www.tiktok.com/oembed?url=${encoded}`;
    defaultSiteName = 'TikTok';
    defaultMediaType = 'video';
  } else if (domain.includes('open.spotify.com')) {
    oembedUrl = `https://open.spotify.com/oembed?url=${encoded}`;
    defaultSiteName = 'Spotify';
    defaultMediaType = 'audio';
  } else if (domain.includes('soundcloud.com')) {
    oembedUrl = `https://soundcloud.com/oembed?format=json&url=${encoded}`;
    defaultSiteName = 'SoundCloud';
    defaultMediaType = 'audio';
  } else if (domain.includes('dailymotion.com') || domain === 'dai.ly') {
    oembedUrl = `https://www.dailymotion.com/services/oembed?url=${encoded}&format=json`;
    defaultSiteName = 'Dailymotion';
    defaultMediaType = 'video';
  } else if (domain.includes('reddit.com')) {
    oembedUrl = `https://www.reddit.com/oembed?url=${encoded}`;
    defaultSiteName = 'Reddit';
    defaultMediaType = 'article';
  } else if (domain === 'x.com' || domain.endsWith('.x.com') || domain === 'twitter.com' || domain.endsWith('.twitter.com')) {
    oembedUrl = `https://publish.twitter.com/oembed?url=${encoded}&omit_script=true`;
    defaultSiteName = 'X';
    defaultMediaType = 'article';
  }

  if (!oembedUrl) return null;
  const data = await fetchJsonEndpoint(oembedUrl);
  if (!data || typeof data !== 'object') return null;

  let title = typeof data.title === 'string' ? decodeHtmlEntities(data.title) : '';
  const authorName = typeof data.author_name === 'string' ? decodeHtmlEntities(data.author_name) : undefined;
  const siteName = typeof data.provider_name === 'string' ? data.provider_name : defaultSiteName;
  const thumbnailUrl = typeof data.thumbnail_url === 'string' ? resolveHttpImageUrl(data.thumbnail_url, targetUrl) : undefined;

  let description = '';
  if (!title && typeof data.html === 'string' && authorName) {
    // Twitter oEmbed omits title; extract plain tweet snippet from oEmbed HTML
    const pMatch = data.html.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
    const plainSnippet = pMatch ? decodeHtmlEntities(pMatch[1].replace(/<[^>]+>/g, ' ')) : '';
    title = plainSnippet ? `${authorName}: "${plainSnippet.slice(0, 110)}${plainSnippet.length > 110 ? '…' : ''}"` : `Post by ${authorName}`;
    description = plainSnippet;
  } else if (authorName && siteName) {
    description = `${siteName} · By ${authorName}`;
  }

  if (!title && !thumbnailUrl) return null;

  return {
    title: title || undefined,
    description: description || undefined,
    imageUrl: thumbnailUrl,
    siteName,
    authorName,
    mediaType: data.type === 'video' ? 'video' : defaultMediaType,
  };
}

function buildReadableSlugTitle(parsedUrl: URL, domain: string): string {
  const segments = parsedUrl.pathname
    .split('/')
    .map((s) => s.trim())
    .filter(Boolean);
  if (segments.length === 0) {
    return domain;
  }
  const last = decodeURIComponent(segments[segments.length - 1])
    .replace(/\.(html?|php|aspx?|jsp)$/i, '')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!last || last.length < 2) return domain;
  return last.charAt(0).toUpperCase() + last.slice(1);
}

export async function resolveServerLinkPreview(rawUrl: string): Promise<ServerLinkPreviewResult> {
  const parsed = await assertSafeExternalUrl(rawUrl);
  const normalizedUrl = parsed.toString();

  const cached = getCached(normalizedUrl);
  if (cached) return cached;

  const domain = parsed.hostname.replace(/^www\./, '').toLowerCase();
  const ytVideoId = extractYouTubeVideoId(normalizedUrl);

  // Run oEmbed and direct HTML scrape in parallel for maximum precision
  const [oembedData, htmlRes] = await Promise.all([
    tryOEmbedResolution(normalizedUrl, domain),
    fetchWithTimeoutAndRedirects(parsed).catch(() => null),
  ]);

  const finalUrl = htmlRes?.finalUrl || normalizedUrl;
  const htmlMeta = htmlRes?.text ? extractHtmlMetadata(htmlRes.text, finalUrl) : null;

  let title = oembedData?.title || htmlMeta?.title || '';
  let description = htmlMeta?.description || oembedData?.description || '';
  let imageUrl = oembedData?.imageUrl || htmlMeta?.imageUrl;
  let fallbackImageUrl: string | undefined = htmlMeta?.imageUrl;
  const siteName = oembedData?.siteName || htmlMeta?.siteName || (ytVideoId ? 'YouTube' : undefined);
  const authorName = oembedData?.authorName || htmlMeta?.authorName;
  const mediaType = oembedData?.mediaType || htmlMeta?.mediaType || (ytVideoId ? 'video' : 'website');

  // YouTube-specific precision upgrade: prefer maxresdefault -> hqdefault fallback
  if (ytVideoId) {
    const maxResThumb = `https://i.ytimg.com/vi/${ytVideoId}/maxresdefault.jpg`;
    const hqThumb = `https://i.ytimg.com/vi/${ytVideoId}/hqdefault.jpg`;
    imageUrl = maxResThumb;
    fallbackImageUrl = oembedData?.imageUrl || hqThumb;

    // Clean trailing " - YouTube" from scraped <title> if oEmbed wasn't present
    if (title.endsWith(' - YouTube')) {
      title = title.slice(0, -' - YouTube'.length).trim();
    }
    if (!title) {
      title = `YouTube Video (${ytVideoId})`;
    }
    if (!description && authorName) {
      description = `Video by ${authorName} on YouTube`;
    }
  }

  // GitHub-specific precision fallback if HTML scrape didn't yield an image
  if (domain === 'github.com') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    if (parts.length >= 2) {
      const owner = parts[0];
      const repo = parts[1];
      if (!imageUrl) {
        imageUrl = `https://opengraph.githubassets.com/1/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
      }
      if (!title) {
        title = `${owner}/${repo}`;
      }
    }
  }

  if (!title) {
    title = buildReadableSlugTitle(parsed, domain);
  }
  if (!description) {
    description = parsed.pathname && parsed.pathname !== '/' ? `${domain}${parsed.pathname}` : normalizedUrl;
  }

  const result: ServerLinkPreviewResult = {
    url: normalizedUrl,
    finalUrl,
    domain,
    title,
    description,
    imageUrl,
    fallbackImageUrl: fallbackImageUrl && fallbackImageUrl !== imageUrl ? fallbackImageUrl : undefined,
    siteName,
    authorName,
    mediaType,
    videoId: ytVideoId || undefined,
    faviconUrl: htmlMeta?.faviconUrl || `${parsed.origin}/favicon.ico`,
    resolved: Boolean(oembedData || htmlMeta?.title || htmlMeta?.imageUrl || ytVideoId),
  };

  setCached(normalizedUrl, result);
  return result;
}
