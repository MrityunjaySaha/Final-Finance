import React, { useState, useRef } from 'react';
import { 
  X, 
  Image as ImageIcon, 
  Video, 
  Upload, 
  Trash2, 
  Star, 
  Play, 
  Plus, 
  Check, 
  Sparkles, 
  FileText, 
  Eye, 
  ExternalLink,
  Film,
  AlertCircle
} from 'lucide-react';
import { IPORequest, IPOMediaItem } from '../../types/stocks';
import { updateIPOMedia } from '../../data/stocksData';

interface ManageIPOMediaModalProps {
  isOpen: boolean;
  onClose: () => void;
  ipo: IPORequest;
  onSaved?: (updatedIpo: IPORequest) => void;
}

const PRESET_MEDIA_LIBRARY: Omit<IPOMediaItem, 'id' | 'uploadedAt'>[] = [
  {
    type: 'photo',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1000&auto=format&fit=crop&q=80',
    title: 'Advanced Micro-Semiconductor Architecture',
    description: 'Next-generation quantum substrate wafer in ISO-1 certified cleanroom facility.',
    isCover: false
  },
  {
    type: 'photo',
    url: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=1000&auto=format&fit=crop&q=80',
    title: 'Sovereign Node Cluster Telemetry',
    description: 'High-availability validator hardware with direct satellite uplinks.',
    isCover: false
  },
  {
    type: 'photo',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1000&auto=format&fit=crop&q=80',
    title: 'Institutional Vault Reserve Storage',
    description: 'Allocated sovereign gold bars and physical cold-custody vault lockers.',
    isCover: false
  },
  {
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    title: 'Executive Vision & Strategic Roadmap Presentation',
    description: '3-minute executive prospectus summary for institutional and sovereign shareholders.',
    isCover: false
  },
  {
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    title: 'Live Protocol Demonstration & Performance Benchmark',
    description: 'Live testing recording showcasing sub-second transaction clearing and zero slippage.',
    isCover: false
  }
];

export const ManageIPOMediaModal: React.FC<ManageIPOMediaModalProps> = ({
  isOpen,
  onClose,
  ipo,
  onSaved
}) => {
  const [mediaList, setMediaList] = useState<IPOMediaItem[]>(() => {
    return ipo.mediaGallery || 
      (ipo.ipoType === 'personal' ? ipo.personalDetails?.mediaGallery : ipo.businessDetails?.mediaGallery) || 
      [];
  });

  const [activeTab, setActiveTab] = useState<'gallery' | 'upload' | 'presets'>('gallery');
  const [selectedPreviewMedia, setSelectedPreviewMedia] = useState<IPOMediaItem | null>(null);

  // New Media Form State
  const [newType, setNewType] = useState<'photo' | 'video'>('photo');
  const [newUrl, setNewUrl] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [isCover, setIsCover] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError(null);
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');

    if (!isImage && !isVideo) {
      setUploadError('Please select a valid image (PNG, JPG, WebP) or video (MP4, WebM) file.');
      return;
    }

    if (file.size > 25 * 1024 * 1024) {
      setUploadError('File exceeds 25MB limit. Please upload a smaller file or use an external URL.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      const newItem: IPOMediaItem = {
        id: `med_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: isVideo ? 'video' : 'photo',
        url: dataUrl,
        title: file.name.replace(/\.[^/.]+$/, ''),
        description: `Uploaded file (${(file.size / (1024 * 1024)).toFixed(2)} MB)`,
        uploadedAt: new Date().toISOString(),
        isCover: mediaList.length === 0
      };

      setMediaList((prev) => [newItem, ...prev]);
      setActiveTab('gallery');
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    reader.onerror = () => {
      setUploadError('Failed to read file. Please try again.');
    };

    reader.readAsDataURL(file);
  };

  const handleAddUrlMedia = (e: React.FormEvent) => {
    e.preventDefault();
    setUploadError(null);

    if (!newUrl.trim()) {
      setUploadError('Please enter a valid media URL.');
      return;
    }

    const newItem: IPOMediaItem = {
      id: `med_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: newType,
      url: newUrl.trim(),
      title: newTitle.trim() || (newType === 'video' ? 'Official Video Prospectus' : 'Equity Asset Photo'),
      description: newDesc.trim(),
      uploadedAt: new Date().toISOString(),
      isCover: isCover || mediaList.length === 0
    };

    if (isCover) {
      setMediaList((prev) => [newItem, ...prev.map((m) => ({ ...m, isCover: false }))]);
    } else {
      setMediaList((prev) => [newItem, ...prev]);
    }

    setNewUrl('');
    setNewTitle('');
    setNewDesc('');
    setIsCover(false);
    setActiveTab('gallery');
  };

  const handleAddPreset = (preset: Omit<IPOMediaItem, 'id' | 'uploadedAt'>) => {
    const newItem: IPOMediaItem = {
      ...preset,
      id: `med_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      uploadedAt: new Date().toISOString()
    };
    setMediaList((prev) => [...prev, newItem]);
  };

  const handleDeleteMedia = (id: string) => {
    setMediaList((prev) => prev.filter((m) => m.id !== id));
    if (selectedPreviewMedia?.id === id) {
      setSelectedPreviewMedia(null);
    }
  };

  const handleSetCover = (id: string) => {
    setMediaList((prev) =>
      prev.map((m) => ({
        ...m,
        isCover: m.id === id
      }))
    );
  };

  const handleSaveAll = () => {
    setIsSaving(true);
    const success = updateIPOMedia(ipo.id, mediaList);
    setIsSaving(false);

    if (success) {
      setSaveSuccessMsg(true);
      if (onSaved) {
        onSaved({
          ...ipo,
          mediaGallery: mediaList,
          businessDetails: ipo.businessDetails ? { ...ipo.businessDetails, mediaGallery: mediaList } : undefined,
          personalDetails: ipo.personalDetails ? { ...ipo.personalDetails, mediaGallery: mediaList } : undefined
        });
      }
      setTimeout(() => {
        setSaveSuccessMsg(false);
        onClose();
      }, 1000);
    }
  };

  const photoCount = mediaList.filter((m) => m.type === 'photo').length;
  const videoCount = mediaList.filter((m) => m.type === 'video').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-8 text-left animate-in fade-in zoom-in-95 duration-200">
        
        {/* TOP HEADER */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif text-lg font-bold text-white">
                  Media &amp; Prospectus Visual Gallery
                </h3>
                <span className="px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 font-mono text-xs font-bold border border-amber-400/30">
                  ${ipo.ticker}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Upload and manage high-resolution photos and video pitch clips for {ipo.equityName}.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* NAVIGATION SUB-TABS */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-50 border-b border-slate-200 text-xs">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('gallery')}
              className={`px-4 py-2 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'gallery'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Current Gallery ({mediaList.length})</span>
              <span className="text-[10px] opacity-75 font-mono">({photoCount}P / {videoCount}V)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`px-4 py-2 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'upload'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>+ Upload New Photo / Video</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('presets')}
              className={`px-4 py-2 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'presets'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Asset Library Presets</span>
            </button>
          </div>

          <span className="text-[11px] text-slate-500 hidden sm:inline-block font-mono">
            Supports MP4, WebM, PNG, JPG, WebP
          </span>
        </div>

        {/* MODAL BODY */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-6">
          
          {/* TAB 1: CURRENT GALLERY VIEW */}
          {activeTab === 'gallery' && (
            <div>
              {mediaList.length === 0 ? (
                <div className="p-10 text-center rounded-3xl bg-slate-50 border-2 border-dashed border-slate-200 space-y-3">
                  <Film className="w-10 h-10 text-slate-300 mx-auto" />
                  <h4 className="font-serif text-base font-bold text-slate-800">
                    No visual media attached yet
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Upload executive portraits, cleanroom facilities, team photos, or video presentations to enhance investor confidence.
                  </p>
                  <div className="flex items-center justify-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('upload')}
                      className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-all cursor-pointer"
                    >
                      Upload First Asset
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('presets')}
                      className="px-4 py-2 rounded-xl bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold hover:bg-amber-200 transition-all cursor-pointer"
                    >
                      Pick from Presets
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {mediaList.map((item) => {
                    const isVid = item.type === 'video';
                    return (
                      <div
                        key={item.id}
                        className={`group relative rounded-2xl border overflow-hidden bg-slate-900 transition-all shadow-xs flex flex-col ${
                          item.isCover ? 'border-amber-400 ring-2 ring-amber-400/40' : 'border-slate-200'
                        }`}
                      >
                        {/* Media Preview Thumbnail / Player */}
                        <div className="relative aspect-video w-full bg-slate-950 flex items-center justify-center overflow-hidden">
                          {isVid ? (
                            <video
                              src={item.url}
                              className="w-full h-full object-cover"
                              preload="metadata"
                            />
                          ) : (
                            <img
                              src={item.url}
                              alt={item.title || 'IPO media'}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          )}

                          {/* Top Badges */}
                          <div className="absolute top-2 left-2 flex items-center gap-1.5">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold flex items-center gap-1 backdrop-blur-md shadow-xs ${
                              isVid ? 'bg-purple-600/90 text-white' : 'bg-blue-600/90 text-white'
                            }`}>
                              {isVid ? <Video className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
                              <span>{isVid ? 'Video Clip' : 'Photo'}</span>
                            </span>

                            {item.isCover && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-400 text-slate-950 flex items-center gap-1 shadow-xs">
                                <Star className="w-3 h-3 fill-slate-950" />
                                <span>Cover</span>
                              </span>
                            )}
                          </div>

                          {/* Play / Inspect Overlay Button */}
                          <button
                            type="button"
                            onClick={() => setSelectedPreviewMedia(item)}
                            className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white gap-2 cursor-pointer"
                          >
                            <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:scale-110 transition-transform">
                              {isVid ? <Play className="w-5 h-5 fill-white ml-0.5" /> : <Eye className="w-5 h-5" />}
                            </div>
                          </button>
                        </div>

                        {/* Title & Actions */}
                        <div className="p-3 bg-white space-y-1.5 flex-1 flex flex-col justify-between">
                          <div>
                            <h5 className="font-bold text-xs text-slate-900 truncate">
                              {item.title || (isVid ? 'Video Prospectus' : 'Visual Asset')}
                            </h5>
                            {item.description && (
                              <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">
                                {item.description}
                              </p>
                            )}
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                            {!item.isCover ? (
                              <button
                                type="button"
                                onClick={() => handleSetCover(item.id)}
                                className="text-[11px] font-semibold text-amber-700 hover:text-amber-900 flex items-center gap-1 cursor-pointer"
                              >
                                <Star className="w-3 h-3" />
                                <span>Make Cover</span>
                              </button>
                            ) : (
                              <span className="text-[11px] font-mono font-bold text-amber-600">
                                Primary Display
                              </span>
                            )}

                            <button
                              type="button"
                              onClick={() => handleDeleteMedia(item.id)}
                              className="text-rose-600 hover:text-rose-800 p-1 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                              title="Delete asset"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: UPLOAD OR ENTER URL */}
          {activeTab === 'upload' && (
            <div className="space-y-6">
              
              {/* Drag & Drop File Upload Box */}
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="p-8 rounded-3xl border-2 border-dashed border-slate-300 hover:border-slate-400 bg-slate-50/50 hover:bg-slate-100/50 text-center cursor-pointer transition-all space-y-3"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-700 mx-auto flex items-center justify-center">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif text-sm font-bold text-slate-800">
                    Click to browse or drag &amp; drop photos or videos
                  </h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Supports high-resolution PNG, JPG, WebP photos &amp; MP4/WebM video pitch files (up to 25MB).
                  </p>
                </div>
              </div>

              {uploadError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{uploadError}</span>
                </div>
              )}

              <div className="relative flex items-center justify-center">
                <div className="border-t border-slate-200 w-full" />
                <span className="bg-white px-3 text-[11px] font-mono uppercase text-slate-400 tracking-wider absolute">
                  OR Add via Direct URL
                </span>
              </div>

              {/* URL Form */}
              <form onSubmit={handleAddUrlMedia} className="p-5 rounded-2xl bg-white border border-slate-200 space-y-4">
                <div className="flex items-center gap-3">
                  <label className="text-xs font-bold text-slate-700">Media Type:</label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setNewType('photo')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                        newType === 'photo'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      <span>Photo</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewType('video')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                        newType === 'video'
                          ? 'bg-purple-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>Video</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Direct Media URL (HTTPS)
                    </label>
                    <input
                      type="url"
                      placeholder={newType === 'video' ? 'https://example.com/pitch-video.mp4' : 'https://example.com/photo.jpg'}
                      value={newUrl}
                      onChange={(e) => setNewUrl(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Asset Title
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Lab Cleanroom / Founder Keynote"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Caption / Description (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Brief description for prospective shareholders..."
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isCover}
                      onChange={(e) => setIsCover(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                    />
                    <span>Set as Primary Cover Asset</span>
                  </label>

                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Media Gallery</span>
                  </button>
                </div>
              </form>

            </div>
          )}

          {/* TAB 3: ASSET LIBRARY PRESETS */}
          {activeTab === 'presets' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-serif text-sm font-bold text-slate-900">
                    High-Definition Asset Library Presets
                  </h4>
                  <p className="text-xs text-slate-500">
                    One-click add sovereign institution grade stock photos and video demonstration footage.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {PRESET_MEDIA_LIBRARY.map((preset, idx) => {
                  const isVid = preset.type === 'video';
                  const alreadyAdded = mediaList.some((m) => m.url === preset.url);

                  return (
                    <div
                      key={idx}
                      className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex gap-3 items-start"
                    >
                      <div className="relative w-20 h-16 rounded-xl bg-slate-900 shrink-0 overflow-hidden">
                        {isVid ? (
                          <video
                            src={preset.url}
                            className="w-full h-full object-cover"
                            preload="metadata"
                          />
                        ) : (
                          <img
                            src={preset.url}
                            alt={preset.title || 'preset'}
                            className="w-full h-full object-cover"
                          />
                        )}
                        <span className="absolute bottom-1 right-1 px-1 py-0.5 rounded text-[8px] font-mono font-bold bg-black/75 text-white">
                          {isVid ? 'VIDEO' : 'PHOTO'}
                        </span>
                      </div>

                      <div className="flex-1 min-w-0 space-y-1">
                        <h5 className="font-bold text-xs text-slate-900 truncate">
                          {preset.title}
                        </h5>
                        <p className="text-[11px] text-slate-500 line-clamp-2">
                          {preset.description}
                        </p>

                        <div className="pt-1">
                          {alreadyAdded ? (
                            <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              <span>Added</span>
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleAddPreset(preset)}
                              className="px-3 py-1 rounded-lg bg-slate-900 text-white text-[11px] font-bold hover:bg-slate-800 transition-all cursor-pointer flex items-center gap-1"
                            >
                              <Plus className="w-3 h-3" />
                              <span>Add to IPO</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ACTIVE PREVIEW LIGHTBOX / VIDEO PLAYER */}
          {selectedPreviewMedia && (
            <div className="p-4 rounded-3xl bg-slate-950 text-white space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-white/10 text-white">
                    {selectedPreviewMedia.type.toUpperCase()} PREVIEW
                  </span>
                  <h5 className="font-bold text-xs truncate max-w-xs sm:max-w-md">
                    {selectedPreviewMedia.title}
                  </h5>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedPreviewMedia(null)}
                  className="text-slate-400 hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="aspect-video w-full rounded-2xl overflow-hidden bg-black flex items-center justify-center">
                {selectedPreviewMedia.type === 'video' ? (
                  <video
                    src={selectedPreviewMedia.url}
                    controls
                    autoPlay
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <img
                    src={selectedPreviewMedia.url}
                    alt={selectedPreviewMedia.title || 'preview'}
                    className="w-full h-full object-contain"
                  />
                )}
              </div>

              {selectedPreviewMedia.description && (
                <p className="text-xs text-slate-300 italic">
                  "{selectedPreviewMedia.description}"
                </p>
              )}
            </div>
          )}

        </div>

        {/* BOTTOM ACTION FOOTER */}
        <div className="p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs text-slate-500">
            {saveSuccessMsg ? (
              <span className="text-emerald-700 font-bold flex items-center gap-1.5">
                <Check className="w-4 h-4" />
                <span>Media gallery updated and synced to IPO record!</span>
              </span>
            ) : (
              <span>Changes are saved permanently across all investor portals and Admin audits.</span>
            )}
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSaveAll}
              disabled={isSaving}
              className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-sm cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
            >
              <Check className="w-4 h-4 text-emerald-400" />
              <span>{isSaving ? 'Saving...' : 'Save Gallery Changes'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
