import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  ArrowLeft, 
  Users, 
  Package, 
  Building2, 
  ExternalLink, 
  ShieldCheck, 
  Sparkles, 
  Check, 
  MessageSquare, 
  UserPlus, 
  SlidersHorizontal,
  Coins,
  TrendingUp,
  Tag,
  Lock,
  CreditCard,
  X,
  BarChart2,
  ChevronRight,
  Zap
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { UserPublicProfile } from '../types/social';
import { SEARCHABLE_PRODUCTS, SearchableProduct } from '../data/searchCatalog';
import { INITIAL_STOCKS } from '../data/stocksData';
import { StockItem } from '../types/stocks';
import { getAllUsers, followUser, unfollowUser, getFollowingList, sendFriendRequest, getFriendsList } from '../services/socialService';
import { useApp } from '../context/AppContext';
import { MarketplaceListing } from '../types';

interface SearchResultsPageProps {
  initialQuery?: string;
  currentUser?: AuthSession | null;
  onNavigateBack: () => void;
  onSelectProduct: (product: SearchableProduct) => void;
  onSelectUser: (userIdOrHandle: string) => void;
  onSelectStock?: (stock: StockItem) => void;
  onQuickBuyStock?: (stock: StockItem) => void;
  onOpenDirectMessage?: (targetUser: UserPublicProfile) => void;
}

type FilterCategory = 'all' | 'stocks' | 'people' | 'products' | 'marketplace' | 'vaults';

export const SearchResultsPage: React.FC<SearchResultsPageProps> = ({
  initialQuery = '',
  currentUser,
  onNavigateBack,
  onSelectProduct,
  onSelectUser,
  onSelectStock,
  onQuickBuyStock,
  onOpenDirectMessage,
}) => {
  const { listings } = useApp();
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('all');
  const [allUsers, setAllUsers] = useState<UserPublicProfile[]>([]);
  const [followingUids, setFollowingUids] = useState<Set<string>>(new Set());
  const [friendUids, setFriendUids] = useState<Set<string>>(new Set());
  const [pendingFriendReqUids, setPendingFriendReqUids] = useState<Set<string>>(new Set());
  const [isLoadingUsers, setIsLoadingUsers] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // Sync initial query if it changes from outside
  useEffect(() => {
    if (initialQuery) {
      setSearchQuery(initialQuery);
    }
  }, [initialQuery]);

  // Load all platform users and follow/friend relationships
  useEffect(() => {
    let isMounted = true;
    const loadUserData = async () => {
      setIsLoadingUsers(true);
      try {
        const uid = currentUser?.uid || currentUser?.id || 'guest';
        const [users, following, friends] = await Promise.all([
          getAllUsers(uid),
          getFollowingList(uid),
          getFriendsList(uid),
        ]);
        if (isMounted) {
          setAllUsers(users);
          setFollowingUids(new Set(following.map((f) => f.uid)));
          setFriendUids(new Set(friends.map((f) => f.uid)));
        }
      } catch (err) {
        console.error('Failed to load users for search:', err);
      } finally {
        if (isMounted) setIsLoadingUsers(false);
      }
    };
    loadUserData();
    return () => {
      isMounted = false;
    };
  }, [currentUser]);

  // Handle follow / unfollow toggle
  const handleToggleFollow = async (targetUser: UserPublicProfile) => {
    if (!currentUser) return;
    setActionLoadingId(`follow_${targetUser.uid}`);
    try {
      const isFollowing = followingUids.has(targetUser.uid);
      if (isFollowing) {
        await unfollowUser(currentUser.uid, targetUser.uid);
        setFollowingUids((prev) => {
          const next = new Set(prev);
          next.delete(targetUser.uid);
          return next;
        });
      } else {
        await followUser(currentUser, { uid: targetUser.uid, userId: targetUser.userId });
        setFollowingUids((prev) => new Set(prev).add(targetUser.uid));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoadingId(null);
    }
  };

  // Handle send friend request
  const handleSendFriendRequest = async (targetUser: UserPublicProfile) => {
    if (!currentUser) return;
    setActionLoadingId(`friend_${targetUser.uid}`);
    try {
      await sendFriendRequest(currentUser, {
        uid: targetUser.uid,
        userId: targetUser.userId,
        name: targetUser.name,
        avatarUrl: targetUser.avatarUrl,
      });
      setPendingFriendReqUids((prev) => new Set(prev).add(targetUser.uid));
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoadingId(null);
    }
  };

  const cleanQuery = searchQuery.trim().toLowerCase().replace(/^[@#]/, '');
  const rawSymbol = cleanQuery.replace(/^\$/, '');

  // 1. Matched Stocks & Equities
  const matchedStocks = useMemo(() => {
    if (!cleanQuery) return INITIAL_STOCKS.slice(0, 6);
    return INITIAL_STOCKS.filter((s) => {
      return (
        s.ticker.toLowerCase().includes(rawSymbol) ||
        s.name.toLowerCase().includes(cleanQuery) ||
        s.sector.toLowerCase().includes(cleanQuery) ||
        (s.subSector && s.subSector.toLowerCase().includes(cleanQuery)) ||
        s.description.toLowerCase().includes(cleanQuery)
      );
    });
  }, [cleanQuery, rawSymbol]);

  // 2. Matched Users
  const matchedUsers = useMemo(() => {
    if (!cleanQuery) return allUsers;
    return allUsers.filter((u) => {
      return (
        u.name.toLowerCase().includes(cleanQuery) ||
        u.userId.toLowerCase().includes(cleanQuery) ||
        (u.bio && u.bio.toLowerCase().includes(cleanQuery)) ||
        (u.organization && u.organization.toLowerCase().includes(cleanQuery)) ||
        (u.reputationBadge && u.reputationBadge.toLowerCase().includes(cleanQuery))
      );
    });
  }, [allUsers, cleanQuery]);

  // 3. Matched Search Catalog Products & Vault Assets
  const matchedCatalogProducts = useMemo(() => {
    if (!cleanQuery) return SEARCHABLE_PRODUCTS;
    return SEARCHABLE_PRODUCTS.filter((p) => {
      return (
        p.name.toLowerCase().includes(cleanQuery) ||
        p.category.toLowerCase().includes(cleanQuery) ||
        p.description.toLowerCase().includes(cleanQuery) ||
        p.tags.some((t) => t.toLowerCase().includes(cleanQuery)) ||
        p.features.some((f) => f.toLowerCase().includes(cleanQuery))
      );
    });
  }, [cleanQuery]);

  // 4. Matched Marketplace Live Listings
  const matchedMarketplaceListings = useMemo(() => {
    if (!cleanQuery) return listings.slice(0, 12);
    return listings.filter((item) => {
      return (
        item.title.toLowerCase().includes(cleanQuery) ||
        item.description.toLowerCase().includes(cleanQuery) ||
        item.category.toLowerCase().includes(cleanQuery) ||
        item.sellerName.toLowerCase().includes(cleanQuery) ||
        item.sellerHandle.toLowerCase().includes(cleanQuery) ||
        (item.appraisalGrade && item.appraisalGrade.toLowerCase().includes(cleanQuery))
      );
    });
  }, [listings, cleanQuery]);

  const totalResults = 
    matchedStocks.length +
    matchedUsers.length + 
    matchedCatalogProducts.length + 
    matchedMarketplaceListings.length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 text-left"
    >
      {/* Top Header & Search Bar Row */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-neutral-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onNavigateBack}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-200 text-neutral-800 text-xs font-semibold shadow-2xs transition-all hover:shadow-xs cursor-pointer group"
          >
            <ArrowLeft className="w-4 h-4 text-neutral-500 group-hover:-translate-x-0.5 group-hover:text-black transition-transform" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="font-serif-lux text-2xl sm:text-3xl font-light text-black tracking-tight flex items-center gap-2.5">
              <span>Universal Search &amp; Recommendations</span>
            </h1>
            <p className="text-xs text-neutral-500 font-sans">
              Discover verified personal &amp; business equities ($ALEX, $HYPR, $BSYN), sovereign peers, multi-vault assets, commodities, and OTC listings.
            </p>
          </div>
        </div>

        {/* Live Search Input Inside Results Page */}
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search equities ($ALEX, $HYPR, $BSYN), peers, vaults, listings..."
            className="w-full pl-10 pr-9 py-2.5 rounded-2xl bg-white border border-neutral-200 text-neutral-900 text-xs focus:outline-none focus:border-black focus:ring-1 focus:ring-black shadow-2xs"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-3 text-neutral-400 hover:text-black"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs Bar */}
      <div className="flex items-center justify-between gap-3 overflow-x-auto pb-2 border-b border-neutral-100 scrollbar-none">
        <div className="flex items-center gap-2">
          {[
            { key: 'all', label: 'All Results', count: totalResults },
            { key: 'stocks', label: 'Equities & Stocks', count: matchedStocks.length },
            { key: 'people', label: 'Members & Profiles', count: matchedUsers.length },
            { key: 'products', label: 'Vault Reserves & Bullion', count: matchedCatalogProducts.length },
            { key: 'marketplace', label: 'Live OTC Listings', count: matchedMarketplaceListings.length },
          ].map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setActiveFilter(tab.key as FilterCategory)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                activeFilter === tab.key
                  ? 'bg-black text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 hover:text-neutral-900'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                activeFilter === tab.key ? 'bg-neutral-800 text-neutral-200' : 'bg-neutral-200 text-neutral-700'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        <span className="text-xs text-neutral-400 font-mono shrink-0 hidden sm:block">
          {searchQuery ? `Query: "${searchQuery}"` : 'Browse Recommendations'}
        </span>
      </div>

      {/* ================= SECTION 0: EQUITIES & STOCKS ================= */}
      {(activeFilter === 'all' || activeFilter === 'stocks') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                <TrendingUp className="w-3.5 h-3.5" />
              </div>
              <h2 className="font-serif-lux text-lg font-medium text-neutral-900">
                Equities, Stocks &amp; Reserve Indices
              </h2>
              <span className="text-xs text-neutral-400 font-mono">({matchedStocks.length})</span>
            </div>
            {matchedStocks.length > 4 && activeFilter === 'all' && (
              <button
                type="button"
                onClick={() => setActiveFilter('stocks')}
                className="text-xs font-semibold text-emerald-800 hover:text-emerald-900 hover:underline cursor-pointer"
              >
                View all {matchedStocks.length} stocks &rarr;
              </button>
            )}
          </div>

          {matchedStocks.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-2xl border border-neutral-200 text-neutral-400 text-xs">
              No equities or companies matched your query "{searchQuery}".
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(activeFilter === 'all' ? matchedStocks.slice(0, 6) : matchedStocks).map((stock) => {
                const isPos = stock.changeUSD >= 0;
                return (
                  <div
                    key={stock.ticker}
                    onClick={() => onSelectStock && onSelectStock(stock)}
                    className="bg-white border border-neutral-200 hover:border-amber-300 hover:shadow-md rounded-2xl p-4.5 shadow-2xs transition-all flex flex-col justify-between group text-left cursor-pointer"
                    title={`Open ${stock.name} (${stock.ticker}) full profile, charts, and news`}
                  >
                    <div>
                      {/* Top Row: Symbol, Exchange & Price */}
                      <div className="flex items-start justify-between gap-3 group-hover:text-amber-800 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-neutral-900 text-white flex items-center justify-center font-mono font-bold text-xs shrink-0 shadow-2xs group-hover:bg-amber-600 transition-colors">
                            {stock.ticker}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-sm text-neutral-900 group-hover:text-amber-800 transition-colors">
                                ${stock.ticker}
                              </span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-600 font-mono">
                                {stock.exchange}
                              </span>
                            </div>
                            <p className="text-xs font-medium text-neutral-900 truncate">
                              {stock.name}
                            </p>
                          </div>
                        </div>

                        <div className="text-right font-mono">
                          <div className="text-sm font-bold text-neutral-900">
                            ${stock.price.toFixed(2)}
                          </div>
                          <div className={`text-xs font-bold ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%
                          </div>
                        </div>
                      </div>

                      {/* Description & Sector */}
                      <p className="text-xs text-neutral-500 line-clamp-2 mt-3 leading-relaxed">
                        {stock.description}
                      </p>

                      <div className="mt-3 flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-700 font-mono">
                          {stock.sector}
                        </span>
                        <span className="text-[10px] text-neutral-400 font-mono">
                          Cap: {stock.marketCap}
                        </span>
                        <span className="text-[10px] text-neutral-400 font-mono">
                          P/E: {stock.peRatio}
                        </span>
                      </div>
                    </div>

                    {/* Action Row */}
                    <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between gap-2">
                      <span className="text-xs text-neutral-500 font-medium group-hover:text-amber-800 flex items-center gap-1 transition-colors">
                        <span>Explore {stock.ticker} page, fundamentals &amp; news</span>
                        <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ================= SECTION 1: PEOPLE & PROFILES ================= */}
      {(activeFilter === 'all' || activeFilter === 'people') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-xs">
                <Users className="w-3.5 h-3.5" />
              </div>
              <h2 className="font-serif-lux text-lg font-medium text-neutral-900">
                Ecosystem Members &amp; Counterparties
              </h2>
              <span className="text-xs text-neutral-400 font-mono">({matchedUsers.length})</span>
            </div>
            {matchedUsers.length > 4 && activeFilter === 'all' && (
              <button
                type="button"
                onClick={() => setActiveFilter('people')}
                className="text-xs font-semibold text-amber-800 hover:text-amber-900 hover:underline cursor-pointer"
              >
                View all {matchedUsers.length} members &rarr;
              </button>
            )}
          </div>

          {matchedUsers.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-2xl border border-neutral-200 text-neutral-400 text-xs">
              No counterparties matched your query "{searchQuery}".
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(activeFilter === 'all' ? matchedUsers.slice(0, 6) : matchedUsers).map((user) => {
                const isFollowing = followingUids.has(user.uid);
                const isFriend = friendUids.has(user.uid);
                const hasSentReq = pendingFriendReqUids.has(user.uid);
                const isMe = currentUser?.uid === user.uid || currentUser?.id === user.userId;

                return (
                  <div
                    key={user.uid}
                    className="bg-white border border-neutral-200 hover:border-neutral-300 rounded-2xl p-4.5 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between group text-left"
                  >
                    <div>
                      {/* User Top Card Header */}
                      <div className="flex items-start justify-between gap-3">
                        <button
                          type="button"
                          onClick={() => onSelectUser(user.userId)}
                          className="flex items-center gap-3 text-left min-w-0 cursor-pointer group-hover:opacity-90 transition-opacity"
                        >
                          {user.avatarUrl ? (
                            <img
                              src={user.avatarUrl}
                              alt={user.name}
                              className="w-12 h-12 rounded-2xl object-cover border border-neutral-200 shadow-2xs shrink-0"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center font-serif text-lg font-bold shrink-0">
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <h3 className="text-sm font-bold text-neutral-900 truncate group-hover:underline">
                                {user.name}
                              </h3>
                              {user.isVerified && (
                                <ShieldCheck className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                              )}
                            </div>
                            <p className="text-xs text-neutral-500 font-mono truncate">
                              @{user.userId}
                            </p>
                          </div>
                        </button>

                        {user.reputationBadge && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-900 shrink-0">
                            {user.reputationBadge}
                          </span>
                        )}
                      </div>

                      {/* Bio or Tagline */}
                      <p className="text-xs text-neutral-600 line-clamp-2 mt-3 leading-relaxed">
                        {user.bio || 'Verified platform member participating in sovereign reserve asset clearing.'}
                      </p>

                      {/* Organization / Trade Volume */}
                      <div className="flex items-center gap-3 mt-3 pt-3 border-t border-neutral-100 text-[11px] text-neutral-500 font-mono">
                        {user.organization && (
                          <div className="flex items-center gap-1 truncate">
                            <Building2 className="w-3 h-3 text-neutral-400 shrink-0" />
                            <span className="truncate">{user.organization}</span>
                          </div>
                        )}
                        {user.totalTradeVolumeUSD ? (
                          <div className="flex items-center gap-1 ml-auto shrink-0 font-semibold text-neutral-800">
                            <span>${(user.totalTradeVolumeUSD / 1000).toFixed(0)}k Vol</span>
                          </div>
                        ) : null}
                      </div>
                    </div>

                    {/* Actions Row */}
                    <div className="flex items-center gap-2 mt-4 pt-3 border-t border-neutral-100">
                      <button
                        type="button"
                        onClick={() => onSelectUser(user.userId)}
                        className="flex-1 py-1.5 px-3 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-semibold transition-colors text-center cursor-pointer shadow-2xs"
                      >
                        View Profile
                      </button>

                      {onOpenDirectMessage && !isMe && (
                        <button
                          type="button"
                          onClick={() => onOpenDirectMessage(user)}
                          title="Direct OTC Message"
                          className="p-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 transition-colors cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {!isMe && currentUser && (
                        <button
                          type="button"
                          onClick={() => handleToggleFollow(user)}
                          disabled={actionLoadingId === `follow_${user.uid}`}
                          className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                            isFollowing
                              ? 'bg-white border-neutral-300 text-neutral-700 hover:border-red-300 hover:text-red-600'
                              : 'bg-white border-amber-300 text-amber-900 hover:bg-amber-50'
                          }`}
                        >
                          {isFollowing ? 'Following' : 'Follow'}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ================= SECTION 2: RESERVE VAULT ASSETS & BULLION ================= */}
      {(activeFilter === 'all' || activeFilter === 'products') && (
        <div className="space-y-4 pt-4 border-t border-neutral-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-900 flex items-center justify-center font-bold text-xs">
                <Coins className="w-3.5 h-3.5" />
              </div>
              <h2 className="font-serif-lux text-lg font-medium text-neutral-900">
                Reserve Vault Assets &amp; Bullion Catalog
              </h2>
              <span className="text-xs text-neutral-400 font-mono">({matchedCatalogProducts.length})</span>
            </div>
            {matchedCatalogProducts.length > 4 && activeFilter === 'all' && (
              <button
                type="button"
                onClick={() => setActiveFilter('products')}
                className="text-xs font-semibold text-emerald-800 hover:text-emerald-900 hover:underline cursor-pointer"
              >
                View all {matchedCatalogProducts.length} assets &rarr;
              </button>
            )}
          </div>

          {matchedCatalogProducts.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-2xl border border-neutral-200 text-neutral-400 text-xs">
              No reserve products matched your query "{searchQuery}".
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(activeFilter === 'all' ? matchedCatalogProducts.slice(0, 6) : matchedCatalogProducts).map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => onSelectProduct(prod)}
                  className="bg-white border border-neutral-200 hover:border-neutral-300 rounded-2xl p-4.5 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between cursor-pointer group text-left"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                        {prod.badge || prod.category}
                      </span>
                      <span className="text-xs font-bold font-mono text-neutral-900">
                        {prod.price}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-neutral-900 mt-2 group-hover:text-amber-900 group-hover:underline">
                      {prod.name}
                    </h3>
                    <p className="text-xs text-neutral-600 mt-1 line-clamp-2 leading-relaxed">
                      {prod.description}
                    </p>

                    <div className="flex flex-wrap gap-1.5 mt-3">
                      {prod.features.slice(0, 2).map((feat, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-600 font-mono"
                        >
                          ✓ {feat}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 mt-3 border-t border-neutral-100 text-xs">
                    <span className="text-neutral-400 font-mono text-[11px]">{prod.category}</span>
                    <span className="font-semibold text-neutral-900 group-hover:text-amber-800 flex items-center gap-1">
                      View Specifications &rarr;
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ================= SECTION 3: LIVE MARKETPLACE LISTINGS ================= */}
      {(activeFilter === 'all' || activeFilter === 'marketplace') && (
        <div className="space-y-4 pt-4 border-t border-neutral-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-purple-100 text-purple-900 flex items-center justify-center font-bold text-xs">
                <Package className="w-3.5 h-3.5" />
              </div>
              <h2 className="font-serif-lux text-lg font-medium text-neutral-900">
                Live Peer-to-Peer OTC Marketplace
              </h2>
              <span className="text-xs text-neutral-400 font-mono">({matchedMarketplaceListings.length})</span>
            </div>
            {matchedMarketplaceListings.length > 4 && activeFilter === 'all' && (
              <button
                type="button"
                onClick={() => setActiveFilter('marketplace')}
                className="text-xs font-semibold text-purple-800 hover:text-purple-900 hover:underline cursor-pointer"
              >
                View all {matchedMarketplaceListings.length} listings &rarr;
              </button>
            )}
          </div>

          {matchedMarketplaceListings.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-2xl border border-neutral-200 text-neutral-400 text-xs">
              No marketplace listings found matching "{searchQuery}".
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {(activeFilter === 'all' ? matchedMarketplaceListings.slice(0, 8) : matchedMarketplaceListings).map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectProduct({
                    id: item.id,
                    name: item.title,
                    category: item.category,
                    price: `$${item.priceUSD.toLocaleString()} USD`,
                    description: item.description,
                    iconName: 'Package',
                    badge: item.appraisalGrade || 'VERIFIED',
                    features: ['Escrow Protected', item.sellerVerified ? 'KYC Verified Seller' : 'Platform Member'],
                    tags: [item.category, item.sellerName]
                  })}
                  className="bg-white border border-neutral-200 hover:border-neutral-300 rounded-2xl overflow-hidden shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between cursor-pointer group text-left"
                >
                  <div className="aspect-4/3 relative overflow-hidden bg-neutral-100">
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <span className="absolute top-2 left-2 text-[10px] font-mono px-2 py-0.5 rounded-md bg-black/75 text-white backdrop-blur-xs font-bold uppercase">
                      {item.category.replace('_', ' ')}
                    </span>
                    <span className="absolute bottom-2 right-2 text-xs font-mono font-bold px-2 py-1 rounded-lg bg-white/95 text-black shadow-xs">
                      ${item.priceUSD.toLocaleString()}
                    </span>
                  </div>

                  <div className="p-3.5 flex flex-col justify-between flex-1">
                    <div>
                      <h3 className="text-xs font-bold text-neutral-900 group-hover:underline line-clamp-1">
                        {item.title}
                      </h3>
                      <p className="text-[11px] text-neutral-500 line-clamp-2 mt-1">
                        {item.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2.5 mt-2.5 border-t border-neutral-100 text-[10px] text-neutral-500 font-mono">
                      <span>Seller: @{item.sellerHandle}</span>
                      <span className="text-amber-800 font-semibold group-hover:underline">Inspect &rarr;</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
};
