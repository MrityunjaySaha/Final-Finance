import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Search, Users, Coins, TrendingUp, Lock, Unlock } from 'lucide-react';
import { getStoredUserWallets } from '../../data/defaultWallets';
import { getUserProfile } from '../../services/socialService';
import { getStoredCustomCoins } from '../../data/customCoinsData';
import { getStoredStockPositions } from '../../utils/stockWalletBridge';
import { INITIAL_USER_STOCK_POSITIONS } from '../../data/stocksData';
import { setPendingProfileReturnAnchor, getProfileReturnAnchor, clearProfileReturnAnchor } from '../../utils/profileReturnState';
import {
  ACCOUNT_STATUS_UPDATED_EVENT,
  isAccountLocked,
  setAccountLocked,
} from '../../utils/accountStatusStorage';
import { PresenceAvatarDot, PresenceStatusBadge } from '../common/PresenceBadge';

interface AccountingUser {
  id: string;
  name: string;
  handle: string;
  avatarUrl?: string;
  email?: string;
}

const MOCK_USERS_BASIC: { id: string; name: string; handle: string; email?: string }[] = [
  { id: 'demo-jordan-belfort', name: 'Jordan Belfort', handle: '@jordan_belfort', email: 'jordan@finalfinance.io' },
  { id: 'demo-satoshi-nakamoto', name: 'Satoshi Nakamoto', handle: '@satoshi_nakamoto', email: 'satoshi@finalfinance.io' },
  { id: 'demo-alex-morgan', name: 'Alex Morgan', handle: '@alex_morgan', email: 'alex@finalfinance.io' },
  { id: 'user-default', name: 'Sovereign Trader', handle: '@sovereign_trader' },
];

interface AdminAccountingDeskProps {
  onViewProfile: (userId: string) => void;
  onNotify?: (msg: string, type: 'success' | 'warning' | 'info') => void;
}

export const AdminAccountingDesk: React.FC<AdminAccountingDeskProps> = ({ onViewProfile, onNotify }) => {
  const initialAnchor = React.useMemo(() => {
    const a = getProfileReturnAnchor();
    if (a && (a.adminTab === 'accounting' || a.sourceLabel === 'admin_accounting') && a.restoreActive) {
      return a;
    }
    return null;
  }, []);

  const [mainTab, setMainTab] = useState<'people' | 'stocks' | 'currencies'>(initialAnchor?.accountingMainTab || 'people');
  const [searchTerm, setSearchTerm] = useState(initialAnchor?.adminSearchTerm || '');
  const [users, setUsers] = useState<AccountingUser[]>([]);
  const [profilesHydrated, setProfilesHydrated] = useState(false);
  const [expandedUserId, setExpandedUserId] = useState<string | null>(initialAnchor?.accountingExpandedUserId ?? null);
  const [userActiveTab, setUserActiveTab] = useState<{ [userId: string]: 'currencies' | 'stocks' }>({});
  const [lockedStatus, setLockedStatus] = useState<{ [userId: string]: boolean }>({});
  const [syncTick, setSyncTick] = useState(0);
  const pendingAnchorRef = useRef<string | null>(initialAnchor?.listingId || null);
  const savedScrollYRef = useRef<number | null>(
    typeof initialAnchor?.scrollY === 'number' ? initialAnchor.scrollY : null
  );
  const [highlightedAnchorId, setHighlightedAnchorId] = useState<string | null>(null);

  const computeLockedMap = (list: AccountingUser[]): { [userId: string]: boolean } => {
    const map: { [userId: string]: boolean } = {};
    for (const u of list) {
      map[u.id] = isAccountLocked([u.id, u.handle, u.email]);
    }
    return map;
  };

  useEffect(() => {
    let mounted = true;
    async function loadUsers() {
      let registeredList: AccountingUser[] = [];
      try {
        const stored = localStorage.getItem('final_finance_registered_users');
        if (stored) {
          const regMap = JSON.parse(stored);
          registeredList = Object.values<any>(regMap).map(acc => ({
            id: `user-${acc.userId}`,
            name: acc.name || acc.userId,
            handle: `@${acc.userId}`,
            avatarUrl: acc.avatarUrl,
            email: acc.email,
          }));
        }
      } catch {}

      const combined = [...MOCK_USERS_BASIC, ...registeredList];
      const uniqueMap = new Map<string, AccountingUser>();
      combined.forEach(u => uniqueMap.set(u.id, u));
      const allUnique = Array.from(uniqueMap.values());

      if (!mounted) return;
      // Populate list and lock statuses immediately so anchor scroll target renders cleanly
      setUsers(allUnique);
      setLockedStatus(computeLockedMap(allUnique));

      const fullUsers = await Promise.all(
        allUnique.map(async (u) => {
          const profile = await getUserProfile(u.id);
          return {
            ...u,
            avatarUrl: profile?.avatarUrl || u.avatarUrl,
            email: profile?.email || u.email,
          };
        })
      );
      if (!mounted) return;
      setUsers(fullUsers);
      setLockedStatus(computeLockedMap(fullUsers));
      setProfilesHydrated(true);
    }
    loadUsers();

    const handleSync = () => setSyncTick((t) => t + 1);
    const handleAccountStatusSync = () => {
      setUsers((prev) => {
        setLockedStatus(computeLockedMap(prev));
        return prev;
      });
    };
    window.addEventListener('final_finance_custom_coins_updated', handleSync);
    window.addEventListener('final_finance_loans_updated', handleSync);
    window.addEventListener('final_finance_wallets_updated', handleSync);
    window.addEventListener('final_finance_stocks_updated', handleSync);
    window.addEventListener(ACCOUNT_STATUS_UPDATED_EVENT, handleAccountStatusSync);
    window.addEventListener('storage', handleSync);
    window.addEventListener('storage', handleAccountStatusSync);
    return () => {
      mounted = false;
      window.removeEventListener('final_finance_custom_coins_updated', handleSync);
      window.removeEventListener('final_finance_loans_updated', handleSync);
      window.removeEventListener('final_finance_wallets_updated', handleSync);
      window.removeEventListener('final_finance_stocks_updated', handleSync);
      window.removeEventListener(ACCOUNT_STATUS_UPDATED_EVENT, handleAccountStatusSync);
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('storage', handleAccountStatusSync);
    };
  }, []);

  useEffect(() => {
    const anchorId = pendingAnchorRef.current;
    if (!anchorId || users.length === 0) return;
    let cancelled = false;

    const restoreExactFrame = (finalize: boolean) => {
      if (cancelled) return;
      const selector = `[data-accounting-anchor="${anchorId.replace(/"/g, '\\"')}"]`;
      const el = document.querySelector(selector) as HTMLElement | null;
      const headerEl = document.querySelector('header');
      const headerHeight = headerEl ? headerEl.getBoundingClientRect().height : 65;

      if (savedScrollYRef.current !== null) {
        window.scrollTo({ top: savedScrollYRef.current, behavior: 'instant' as ScrollBehavior });
      }

      if (el) {
        const rect = el.getBoundingClientRect();
        const isObscuredByHeader = rect.top < headerHeight && rect.bottom > 0 && savedScrollYRef.current === null;
        const isOutsideViewport = rect.bottom < headerHeight + 8 || rect.top > window.innerHeight - 8;

        if (savedScrollYRef.current === null || isOutsideViewport || isObscuredByHeader) {
          const targetTop = Math.max(0, window.scrollY + rect.top - (headerHeight + 24));
          window.scrollTo({ top: targetTop, behavior: 'instant' as ScrollBehavior });
        }

        setHighlightedAnchorId(anchorId);

        if (finalize) {
          pendingAnchorRef.current = null;
          savedScrollYRef.current = null;
          clearProfileReturnAnchor();
          setTimeout(() => setHighlightedAnchorId(null), 1800);
        }
      }
    };

    const raf = requestAnimationFrame(() => {
      restoreExactFrame(false);
    });
    const t1 = window.setTimeout(() => restoreExactFrame(false), 60);
    const t2 = profilesHydrated ? window.setTimeout(() => restoreExactFrame(true), 120) : null;

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      window.clearTimeout(t1);
      if (t2 !== null) window.clearTimeout(t2);
    };
  }, [users, mainTab, profilesHydrated]);

  const handleInspectUserClick = (
    userId: string,
    anchorId?: string,
    tabOverride?: 'people' | 'stocks' | 'currencies'
  ) => {
    const targetMainTab = tabOverride || mainTab;
    const resolvedAnchorId = anchorId || `${targetMainTab}-${userId}`;
    setPendingProfileReturnAnchor({
      sourceLabel: 'Back to Accounting',
      adminTab: 'accounting',
      accountingMainTab: targetMainTab,
      accountingExpandedUserId: expandedUserId,
      adminSearchTerm: searchTerm,
      restoreActive: true,
      listingId: resolvedAnchorId,
      scrollY: window.scrollY,
    });
    onViewProfile(userId);
  };

  const toggleLockAccount = (user: AccountingUser) => {
    const current = lockedStatus[user.id] || false;
    const next = !current;
    const cleanUsername = (user.handle || user.id).replace(/^@/, '');
    setAccountLocked([user.id, user.handle, user.email], next, {
      uid: user.id,
      userId: cleanUsername,
      name: user.name,
      email: user.email,
      avatarUrl: user.avatarUrl,
      source: 'user_lock',
    });
    setLockedStatus((prev) => ({ ...prev, [user.id]: next }));
    if (onNotify) {
      onNotify(
        next 
          ? `Account for ${user.name} has been LOCKED by Admin. User access is restricted.`
          : `Account for ${user.name} has been UNLOCKED. Access restored.`,
        next ? 'warning' : 'success'
      );
    }
  };

  const getUserDetails = (userId: string) => {
    const wallets = getStoredUserWallets(userId);
    const positions = getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS);
    return {
      finalCoins: wallets.finalCoins || [],
      stocks: positions || [],
    };
  };

  const { allHoldersStocks, allHoldersCurrencies } = useMemo(() => {
    void syncTick;
    const stockMap = new Map<string, Array<{ user: AccountingUser; shares: number }>>();
    const currencyMap = new Map<string, Array<{ user: AccountingUser; balance: number }>>();

    users.forEach((u) => {
      const details = getUserDetails(u.id);
      details.stocks.forEach((st: any) => {
        const key = st.ticker || st.stockName || 'STOCK';
        if (!stockMap.has(key)) stockMap.set(key, []);
        stockMap.get(key)!.push({ user: u, shares: st.shares || 0 });
      });

      details.finalCoins.forEach((fc: any) => {
        const key = fc.symbol || 'COIN';
        if (!currencyMap.has(key)) currencyMap.set(key, []);
        currencyMap.get(key)!.push({ user: u, balance: fc.balance || 0 });
      });
    });

    return {
      allHoldersStocks: Array.from(stockMap.entries()),
      allHoldersCurrencies: Array.from(currencyMap.entries()),
    };
  }, [users, syncTick]);

  const { totalCirculation, distinctCount, afnlCirculation } = useMemo(() => {
    let total = 0;
    let afnl = 0;
    allHoldersCurrencies.forEach(([symbol, holders]) => {
      const symTotal = holders.reduce((sum, h) => sum + (h.balance || 0), 0);
      total += symTotal;
      if (symbol.toUpperCase() === 'AFNL') {
        afnl += symTotal;
      }
    });
    return {
      totalCirculation: total > 0 ? total : 278100000,
      distinctCount: allHoldersCurrencies.length > 0 ? allHoldersCurrencies.length : 6,
      afnlCirculation: afnl > 0 ? afnl : 45000000,
    };
  }, [allHoldersCurrencies]);

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.handle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredStocks = allHoldersStocks.filter(([ticker, holders]) => 
    ticker.toLowerCase().includes(searchTerm.toLowerCase()) ||
    holders.some(h => h.user.name.toLowerCase().includes(searchTerm.toLowerCase()) || h.user.handle.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredCurrencies = allHoldersCurrencies.filter(([symbol, holders]) => 
    symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
    holders.some(h => h.user.name.toLowerCase().includes(searchTerm.toLowerCase()) || h.user.handle.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden text-center space-y-6 p-6">
      {/* Header Centered */}
      <div className="flex flex-col items-center justify-center text-center space-y-3 pb-6 border-b border-slate-100">
        <h2 className="font-serif text-2xl font-bold text-slate-900 tracking-tight">System Accounting Ledger</h2>
        <p className="text-sm font-semibold text-slate-700">
          Overall Final Currencies in Circulation:{' '}
          <span className="font-bold text-amber-700 font-mono text-base">
            {totalCirculation.toLocaleString()}
          </span>{' '}
          <span className="text-xs text-slate-500 font-medium">
            ({distinctCount} Final Currencies)
          </span>
        </p>
        <p className="text-xs font-semibold text-slate-600">
          Admin Final Coins (AFNL) in Circulation:{' '}
          <span className="font-bold text-indigo-700 font-mono">
            {afnlCirculation.toLocaleString()} AFNL
          </span>
        </p>

        {/* 3 Tabs next to each other, centered */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2 pb-1">
          <button
            type="button"
            onClick={() => setMainTab('people')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
              mainTab === 'people'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>People ({users.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setMainTab('stocks')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
              mainTab === 'stocks'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Stocks ({allHoldersStocks.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setMainTab('currencies')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
              mainTab === 'currencies'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>Final Currencies ({allHoldersCurrencies.length})</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative w-full max-w-md mx-auto pt-2">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder={
              mainTab === 'people'
                ? 'Search people by name or handle...'
                : mainTab === 'stocks'
                  ? 'Search stocks by ticker or holder name...'
                  : 'Search final currencies by symbol or holder name...'
            }
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium text-slate-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* ================= TAB 1: PEOPLE ================= */}
      {mainTab === 'people' && (
        <div className="space-y-4 max-w-4xl mx-auto text-center">
          <h3 className="font-bold text-sm text-slate-800 text-center">Registered People &amp; Individual Holdings Inspection</h3>
          
          {filteredUsers.length === 0 ? (
            <p className="text-xs text-slate-500 py-8">No people found matching "{searchTerm}".</p>
          ) : (
            filteredUsers.map((user) => {
              const details = getUserDetails(user.id);
              const isUserExpanded = expandedUserId === user.id;
              const activeTab = userActiveTab[user.id] || 'currencies';
              const stockCount = details.stocks.length || 16;
              const isLocked = lockedStatus[user.id] || false;

              const peopleAnchorId = `people-${user.id}`;
              return (
                <div
                  key={user.id}
                  data-accounting-anchor={peopleAnchorId}
                  className={`bg-white border rounded-3xl p-5 shadow-xs space-y-4 text-center transition-all ${
                    highlightedAnchorId === peopleAnchorId
                      ? 'border-amber-400 ring-2 ring-amber-400/50'
                      : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-center">
                    <div className="flex items-center justify-center sm:justify-start gap-3">
                      <button
                        type="button"
                        onClick={() => handleInspectUserClick(user.id, peopleAnchorId, 'people')}
                        className="relative cursor-pointer shrink-0"
                        title={`View ${user.name}'s profile`}
                      >
                        {user.avatarUrl ? (
                          <img src={user.avatarUrl} alt={user.name} className="w-10 h-10 rounded-2xl object-cover border border-slate-200" />
                        ) : (
                          <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm">
                            {user.name.charAt(0)}
                          </div>
                        )}
                        <PresenceAvatarDot
                          identifiers={[user.id, user.handle, user.email]}
                          forceOffline={isLocked}
                          size="xs"
                        />
                      </button>

                      <div className="text-left">
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleInspectUserClick(user.id, peopleAnchorId, 'people')}
                            className="font-bold text-slate-900 hover:text-amber-700 transition-colors text-left text-sm cursor-pointer"
                          >
                            {user.name}
                          </button>
                          <PresenceStatusBadge
                            identifiers={[user.id, user.handle, user.email]}
                            forceOffline={isLocked}
                            size="xs"
                          />
                          {isLocked && (
                            <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 text-[10px] font-bold inline-flex items-center gap-1">
                              <Lock className="w-2.5 h-2.5" /> Locked
                            </span>
                          )}
                        </div>
                        <p className="text-xs font-mono text-slate-400">{user.handle}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => toggleLockAccount(user)}
                        className={`px-3 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1 cursor-pointer transition-colors ${
                          isLocked 
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white' 
                            : 'bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700'
                        }`}
                        title={isLocked ? 'Unlock account access' : 'Lock account access (Restrict user sign-in)'}
                      >
                        {isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                        <span>{isLocked ? 'Unlock Account' : 'Lock Account'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setExpandedUserId(isUserExpanded ? null : user.id)}
                        className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <span>{isUserExpanded ? 'Hide Holdings' : 'Inspect Holdings'}</span>
                      </button>
                    </div>
                  </div>

                  {isUserExpanded && (
                    <div className="space-y-3 pt-3 border-t border-slate-100 animate-in fade-in duration-150 text-left">
                      <div className="flex items-center justify-center gap-2 border-b border-slate-200 pb-2">
                        <button
                          type="button"
                          onClick={() => setUserActiveTab({ ...userActiveTab, [user.id]: 'currencies' })}
                          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                            activeTab === 'currencies'
                              ? 'bg-amber-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                          }`}
                        >
                          <Coins className="w-3.5 h-3.5" />
                          <span>Final Currencies Owned ({details.finalCoins.length})</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setUserActiveTab({ ...userActiveTab, [user.id]: 'stocks' })}
                          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                            activeTab === 'stocks'
                              ? 'bg-indigo-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                          }`}
                        >
                          <TrendingUp className="w-3.5 h-3.5" />
                          <span>Stock Holdings ({stockCount})</span>
                        </button>
                      </div>

                      {activeTab === 'currencies' && (
                        <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200/80 space-y-2 animate-in fade-in duration-150">
                          {details.finalCoins.length === 0 ? (
                            <p className="text-xs text-slate-500 italic text-center py-2">No final currencies recorded in wallet.</p>
                          ) : (
                            <div className="space-y-1.5">
                              {details.finalCoins.map((coin, idx) => (
                                <div key={`${coin.symbol}-${idx}`} className="flex items-center justify-between text-xs bg-white p-2.5 rounded-xl border border-amber-100">
                                  <span className="font-mono font-bold text-slate-900">{coin.symbol} — {coin.name}</span>
                                  <span className="font-mono font-bold text-amber-700">{coin.balance.toLocaleString()}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {activeTab === 'stocks' && (
                        <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-200/80 space-y-2 animate-in fade-in duration-150">
                          {details.stocks.length === 0 ? (
                            <p className="text-xs text-slate-500 italic text-center py-2">No stock positions recorded for user.</p>
                          ) : (
                            <div className="space-y-1.5">
                              {details.stocks.map((stock: any, idx: number) => (
                                <div key={`${stock.ticker}-${idx}`} className="flex items-center justify-between text-xs bg-white p-2.5 rounded-xl border border-indigo-100">
                                  <div>
                                    <span className="font-bold text-slate-900">{stock.stockName || stock.ticker}</span>
                                    <span className="ml-1 font-mono text-[10px] text-slate-500">(${stock.ticker})</span>
                                  </div>
                                  <span className="font-mono font-bold text-indigo-700">{(stock.shares || 0).toLocaleString()} sh</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ================= TAB 2: STOCKS ================= */}
      {mainTab === 'stocks' && (
        <div className="space-y-4 w-full max-w-4xl mx-auto text-center">
          <h3 className="font-bold text-sm text-slate-800 text-center">Stocks &amp; All People Holding Each Stock</h3>
          
          {filteredStocks.length === 0 ? (
            <p className="text-xs text-slate-500 py-8">No stocks found matching "{searchTerm}".</p>
          ) : (
            filteredStocks.map(([ticker, holders]) => (
              <div key={ticker} className="w-full max-w-full overflow-hidden bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3 text-center">
                <div className="flex flex-col items-center justify-center text-center gap-1.5 border-b border-slate-100 pb-3">
                  <span className="font-mono font-bold text-base text-slate-900 break-all">${ticker}</span>
                  <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-xl">
                    {holders.length} {holders.length === 1 ? 'Holder' : 'Holders'}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {holders.map((h, idx) => {
                    const stockAnchorId = `stocks-${ticker}-${h.user.id}`;
                    return (
                      <div
                        key={`${h.user.id}-${idx}`}
                        data-accounting-anchor={stockAnchorId}
                        className={`flex flex-col items-center justify-center text-center gap-1 text-xs bg-slate-50 p-3 rounded-xl border min-w-0 w-full overflow-hidden transition-all ${
                          highlightedAnchorId === stockAnchorId
                            ? 'border-amber-400 ring-2 ring-amber-400/50'
                            : 'border-slate-200/70'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => handleInspectUserClick(h.user.id, stockAnchorId, 'stocks')}
                          className="font-bold text-slate-900 hover:text-amber-700 transition-colors cursor-pointer max-w-full truncate"
                        >
                          {h.user.name}
                        </button>
                        <span className="text-[11px] font-mono text-slate-400 max-w-full truncate">{h.user.handle}</span>
                        <span className="font-mono font-bold text-indigo-700 break-words">{(h.shares || 0).toLocaleString()} sh</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* ================= TAB 3: FINAL CURRENCIES ================= */}
      {mainTab === 'currencies' && (
        <div className="space-y-4 w-full max-w-4xl mx-auto text-center">
          <h3 className="font-bold text-sm text-slate-800 text-center">Final Currencies &amp; All People Holding Each Currency</h3>
          
          {filteredCurrencies.length === 0 ? (
            <p className="text-xs text-slate-500 py-8">No final currencies found matching "{searchTerm}".</p>
          ) : (
            filteredCurrencies.map(([symbol, holders]) => (
              <div key={symbol} className="w-full max-w-full overflow-hidden bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3 text-center">
                <div className="flex flex-col items-center justify-center text-center gap-1.5 border-b border-slate-100 pb-3">
                  <span className="font-mono font-bold text-base text-slate-900 break-all">{symbol}</span>
                  <span className="text-xs font-semibold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-xl">
                    {holders.length} {holders.length === 1 ? 'Holder' : 'Holders'}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {holders.map((h, idx) => {
                    const currencyAnchorId = `currencies-${symbol}-${h.user.id}`;
                    return (
                      <div
                        key={`${h.user.id}-${idx}`}
                        data-accounting-anchor={currencyAnchorId}
                        className={`flex flex-col items-center justify-center text-center gap-1 text-xs bg-slate-50 p-3 rounded-xl border min-w-0 w-full overflow-hidden transition-all ${
                          highlightedAnchorId === currencyAnchorId
                            ? 'border-amber-400 ring-2 ring-amber-400/50'
                            : 'border-slate-200/70'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => handleInspectUserClick(h.user.id, currencyAnchorId, 'currencies')}
                          className="font-bold text-slate-900 hover:text-amber-700 transition-colors cursor-pointer max-w-full truncate"
                        >
                          {h.user.name}
                        </button>
                        <span className="text-[11px] font-mono text-slate-400 max-w-full truncate">{h.user.handle}</span>
                        <span className="font-mono font-bold text-amber-700 break-words">{(h.balance || 0).toLocaleString()} {symbol}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
