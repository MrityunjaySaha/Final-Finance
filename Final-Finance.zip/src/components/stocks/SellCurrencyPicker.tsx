import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Search, ChevronDown, Check, X } from 'lucide-react';
import { StockPaymentSource } from '../../types/stocks';

interface SellCurrencyPickerProps {
  currencies: StockPaymentSource[];
  selectedSource: StockPaymentSource;
  onSelect: (source: StockPaymentSource) => void;
  finalCoinsOnly?: boolean;
}

type CategoryFilter = 'all' | 'final' | 'stable' | 'fiat' | 'crypto';

const CATEGORY_LABELS: Record<CategoryFilter, string> = {
  all: 'All',
  final: 'Final Coins',
  stable: 'Stablecoins',
  fiat: 'Fiat',
  crypto: 'Crypto',
};

export const SellCurrencyPicker: React.FC<SellCurrencyPickerProps> = ({
  currencies,
  selectedSource,
  onSelect,
  finalCoinsOnly = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<CategoryFilter>('all');
  const containerRef = useRef<HTMLDivElement>(null);

  const availableCategories = useMemo(() => {
    const present = new Set<CategoryFilter>();
    currencies.forEach((c) => {
      if (c.currencyCategory) present.add(c.currencyCategory);
    });
    return (['all', 'final', 'stable', 'fiat', 'crypto'] as CategoryFilter[]).filter(
      (cat) => cat === 'all' || present.has(cat)
    );
  }, [currencies]);

  useEffect(() => {
    if (category !== 'all' && !availableCategories.includes(category)) {
      setCategory('all');
    }
  }, [category, availableCategories]);

  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase().replace(/^\$/, '');
    return currencies.filter((c) => {
      if (category !== 'all' && c.currencyCategory !== category) return false;
      if (!q) return true;
      return (
        (c.currencyCode || '').toLowerCase().includes(q) ||
        c.label.toLowerCase().includes(q) ||
        (c.currencyName || c.subtitle).toLowerCase().includes(q) ||
        (c.creatorName || '').toLowerCase().includes(q)
      );
    });
  }, [currencies, query, category]);

  const selectedCode = selectedSource.currencyCode || selectedSource.label.replace(/^\$/, '');
  const selectedName = selectedSource.currencyName || selectedSource.subtitle;

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500/40 flex items-center justify-between gap-3 transition-colors cursor-pointer text-left"
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-mono font-bold text-slate-900 tabular-nums shrink-0">
              {selectedSource.label}
            </span>
            <span className="text-slate-300" aria-hidden="true">·</span>
            <span className="text-slate-600 truncate">{selectedName}</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono tabular-nums mt-0.5">
            {(selectedSource.balanceUSD || 0) > 0
              ? `${selectedSource.balanceUSD.toLocaleString()} ${selectedCode} in wallet`
              : `0 ${selectedCode} in wallet · Adds directly to wallet on sale`}
          </div>
        </div>
        <ChevronDown
          className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-150 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {isOpen && (
        <div className="mt-1.5 w-full rounded-2xl border border-slate-200 bg-white shadow-xl overflow-hidden z-30">
          {/* Search Input */}
          <div className="p-2.5 border-b border-slate-100 space-y-2 bg-slate-50/70">
            <div className="relative flex items-center">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={
                  finalCoinsOnly
                    ? 'Search any Final Coin (AFNL, NEBL, ASOV...)'
                    : 'Search any currency (AFNL, NEBL, USDC, BTC, JPY...)'
                }
                className="w-full h-9 pl-8 pr-8 rounded-lg border border-slate-200 bg-white text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                autoFocus
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  className="absolute right-2.5 text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
                  aria-label="Clear currency search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Category Tabs (only shown when multiple currency categories are eligible) */}
            {availableCategories.length > 2 && (
              <div className="flex items-center gap-1 overflow-x-auto">
                {availableCategories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                      category === cat
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
                    }`}
                  >
                    {CATEGORY_LABELS[cat]}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Currency List */}
          <div className="max-h-52 overflow-y-auto divide-y divide-slate-100">
            {filtered.length === 0 ? (
              <div className="py-6 px-4 text-center text-xs text-slate-500">
                No matching currencies found for "{query}".
              </div>
            ) : (
              filtered.map((item) => {
                const isSelected = item.id === selectedSource.id;
                const code = item.currencyCode || item.label.replace(/^\$/, '');
                const hasBalance = (item.balanceUSD || 0) > 0;

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelect(item);
                      setIsOpen(false);
                    }}
                    className={`w-full px-3.5 py-2.5 text-left flex items-center justify-between gap-3 transition-colors cursor-pointer ${
                      isSelected ? 'bg-amber-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono font-bold text-slate-900 tabular-nums shrink-0">
                          {item.label}
                        </span>
                        <span className="text-slate-300" aria-hidden="true">·</span>
                        <span className="font-medium text-slate-800 truncate">
                          {item.currencyName || item.subtitle}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5 truncate">
                        <span>{CATEGORY_LABELS[item.currencyCategory || 'final'] || 'Currency'}</span>
                        {item.creatorName && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="truncate">By {item.creatorName}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 text-right">
                      <span
                        className={`text-[11px] font-mono tabular-nums ${
                          hasBalance ? 'font-semibold text-slate-800' : 'text-slate-400'
                        }`}
                      >
                        {hasBalance ? `${item.balanceUSD.toLocaleString()} ${code}` : '0 in wallet'}
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-amber-700 shrink-0" />}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
