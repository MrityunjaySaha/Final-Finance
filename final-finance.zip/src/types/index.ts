export type AssetClass = 'barter' | 'final_coins' | 'stable_coins' | 'fiat' | 'crypto';

export * from './ledger';
export * from './marketplace';

export interface ReserveVault {
  id: AssetClass;
  name: string;
  shortCode: string;
  tagline: string;
  description: string;
  totalReserveUSD: number;
  change24h: number;
  icon: string;
  accentColor: string;
  bgGradient: string;
  reserveAssets: VaultAsset[];
  auditScore: number;
  backingRatio: number;
}

export interface VaultAsset {
  id: string;
  name: string;
  symbol: string;
  category: AssetClass;
  balance: number;
  unitPriceUSD: number;
  totalValueUSD: number;
  change24h: number;
  imageUrl: string;
  purityOrGrade?: string;
  custodyLocation?: string;
  isAiGenerated?: boolean;
}

export interface MarketplaceListing {
  id: string;
  title: string;
  category: AssetClass;
  priceUSD: number;
  priceInNative?: string;
  sellerId: string;
  sellerName: string;
  sellerHandle: string;
  sellerAvatar: string;
  sellerVerified: boolean;
  description: string;
  imageUrl: string;
  imageResolution?: string;
  modelUsed?: string;
  attributes: Record<string, string>;
  createdAt: string;
  status: 'active' | 'draft' | 'sold';
  likes: number;
  isLiked?: boolean;
  featured?: boolean;
  appraisalGrade?: string;
  // Intent and Trade specifics
  listingIntent?: 'sell' | 'buy'; // 'sell' (For Sale / Offering) vs 'buy' (Wanted / Buying / RFP)
  itemType?: 'good' | 'service'; // 'good' (Physical asset) vs 'service' (Professional service)
  primaryTradeMode?: 'currency' | 'barter'; // Currency trade vs Barter trade
  primaryCurrency?: string;
  acceptedSettlements?: ('barter' | 'final_coins' | 'stable_coins' | 'fiat' | 'crypto')[];
  acceptedCurrencyList?: string[];
  barterDesired?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  handle: string;
  email: string;
  avatarUrl: string;
  bio: string;
  tier: 'Sovereign' | 'Institutional' | 'Accredited' | 'Pioneer';
  verified: boolean;
  joinedDate: string;
  portfolioNAV: number;
  followersCount: number;
  followingCount: number;
  isFollowed?: boolean;
  holdings: {
    barter: number;
    final_coins: number;
    stable_coins: number;
    fiat: number;
    crypto: number;
  };
}

export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  authorTier: string;
  authorVerified: boolean;
  content: string;
  imageUrl?: string;
  imageMeta?: {
    model: string;
    resolution: string;
    prompt: string;
  };
  assetTag?: {
    name: string;
    category: AssetClass;
    valuation: number;
  };
  likes: number;
  isLiked?: boolean;
  commentsCount: number;
  comments?: PostComment[];
  shares: number;
  createdAt: string;
}

export interface PostComment {
  id: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  imageUrl?: string;
  tradeProposal?: {
    offeredAsset: string;
    offeredValue: number;
    requestedAsset: string;
    requestedValue: number;
    status: 'pending' | 'accepted' | 'declined';
  };
  createdAt: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  name: string;
  avatar: string;
  participantIds: string[];
  lastMessageText: string;
  lastMessageTime: string;
  unreadCount: number;
  isVerifiedDesk?: boolean;
}

export interface GeneratedImageHistory {
  id: string;
  imageUrl: string;
  prompt: string;
  model: string;
  aspectRatio: string;
  imageSize: '1K' | '2K' | '4K';
  createdAt: string;
  isEdit?: boolean;
  referenceImageUrl?: string;
  category?: AssetClass;
}
