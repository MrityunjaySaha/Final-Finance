import React, { useState } from 'react';
// import { motion, AnimatePresence } from 'motion/react';
import { 
  Building2, 
  CreditCard, 
  Wallet,
  X, 
  ShieldCheck, 
  Check, 
  Plus, 
  Lock, 
  AlertCircle,
  HelpCircle,
  Zap,
  Globe
} from 'lucide-react';
import { UserWalletData, LinkedBankAccountItem, LinkedCardItem, LinkedCryptoWalletItem } from '../../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../../data/defaultWallets';

interface LinkBankCardModalProps {
  userId: string;
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'bank' | 'card' | 'crypto';
  onSuccess: (type: 'bank' | 'card' | 'crypto', label: string) => void;
}

export const LinkBankCardModal: React.FC<LinkBankCardModalProps> = ({
  userId,
  isOpen,
  onClose,
  initialTab = 'bank',
  onSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<'bank' | 'card' | 'crypto'>(initialTab);

  // Bank Form State
  const [bankName, setBankName] = useState('JPMorgan Chase & Co.');
  const [accountType, setAccountType] = useState<'Checking' | 'Savings' | 'Brokerage'>('Checking');
  const [routingNumber, setRoutingNumber] = useState('021000021');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountHolder, setAccountHolder] = useState('Alexander Sterling');
  const [initialDepositUSD, setInitialDepositUSD] = useState('50000');

  // Card Form State
  const [cardholderName, setCardholderName] = useState('ALEXANDER STERLING');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('12');
  const [expiryYear, setExpiryYear] = useState('28');
  const [cvv, setCvv] = useState('');
  const [cardBrand, setCardBrand] = useState<'visa' | 'mastercard' | 'amex'>('visa');
  const [cardType, setCardType] = useState<'debit' | 'credit'>('debit');

  // Crypto Form State
  const [walletType, setWalletType] = useState<'metamask' | 'phantom' | 'coinbase' | 'ledger' | 'walletconnect' | 'custom'>('metamask');
  const [walletNetwork, setWalletNetwork] = useState<'Ethereum' | 'Solana' | 'Bitcoin' | 'Polygon' | 'Base' | 'Arbitrum'>('Ethereum');
  const [cryptoAddress, setCryptoAddress] = useState('');
  const [ensOrDomain, setEnsOrDomain] = useState('');
  const [initialCryptoBalUSD, setInitialCryptoBalUSD] = useState('50000');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Listen for Escape key to close modal
  React.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isSubmitting) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isSubmitting, onClose]);

  // Reset tab if modal reopened with different initialTab
  React.useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const handleLinkBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accountNumber || accountNumber.length < 4) {
      setErrorMsg('Please enter a valid bank account number (at least 4 digits).');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    setTimeout(() => {
      const walletData = getStoredUserWallets(userId);
      const last4 = accountNumber.slice(-4);
      const newBank: LinkedBankAccountItem = {
        id: `bank-${Date.now()}`,
        accountHolderName: accountHolder || 'Alexander Sterling',
        bankName: bankName || 'Connected Bank',
        accountType: accountType as any,
        routingNumberMasked: `••••${routingNumber.slice(-4) || '0210'}`,
        accountNumberLast4: last4,
        currency: 'USD',
        country: 'United States',
        isDefault: (walletData.linkedBankAccounts?.length || 0) === 0,
        status: 'Instant FedNow Connected',
        addedAt: new Date().toISOString(),
        balanceUSD: parseFloat(initialDepositUSD) || 50000,
      };

      walletData.linkedBankAccounts = [newBank, ...(walletData.linkedBankAccounts || [])];
      saveStoredUserWallets(userId, walletData);

      setIsSubmitting(false);
      onSuccess('bank', `${newBank.bankName} (••••${last4})`);
      onClose();
    }, 600);
  };

  const handleLinkCard = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNum = cardNumber.replace(/\s+/g, '');
    if (cleanNum.length < 4) {
      setErrorMsg('Please enter a valid 16-digit card number.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    setTimeout(() => {
      const walletData = getStoredUserWallets(userId);
      const last4 = cleanNum.slice(-4);
      const newCard: LinkedCardItem = {
        id: `card-${Date.now()}`,
        cardholderName: cardholderName.toUpperCase() || 'ALEXANDER STERLING',
        cardNumberLast4: last4,
        brand: cardBrand,
        cardType: cardType,
        expiryMonth: expiryMonth.padStart(2, '0'),
        expiryYear: expiryYear.slice(-2),
        bankName: cardBrand === 'visa' ? 'Visa Signature Reserve' : 'Mastercard World Elite',
        isDefault: (walletData.linkedCards?.length || 0) === 0,
        addedAt: new Date().toISOString(),
        billingZip: '10001'
      };

      walletData.linkedCards = [newCard, ...(walletData.linkedCards || [])];
      saveStoredUserWallets(userId, walletData);

      setIsSubmitting(false);
      onSuccess('card', `${newCard.brand.toUpperCase()} ${newCard.cardType.toUpperCase()} (••••${last4})`);
      onClose();
    }, 600);
  };

  const handleLinkCrypto = (e: React.FormEvent) => {
    e.preventDefault();
    let addr = cryptoAddress.trim();
    if (!addr) {
      if (walletType === 'metamask') addr = '0x71C' + Math.random().toString(16).substring(2, 10) + '...3a9';
      else if (walletType === 'phantom') addr = '7XwK' + Math.random().toString(36).substring(2, 10) + '...sol';
      else if (walletType === 'ledger') addr = 'bc1q' + Math.random().toString(36).substring(2, 10) + '...glacier';
      else addr = '0x88F' + Math.random().toString(16).substring(2, 10) + '...sec';
    }

    setIsSubmitting(true);
    setErrorMsg('');

    setTimeout(() => {
      const walletData = getStoredUserWallets(userId);
      const walletNames: Record<string, string> = {
        metamask: 'MetaMask Web3 Vault',
        phantom: 'Phantom Solana Vault',
        coinbase: 'Coinbase Smart Wallet',
        ledger: 'Ledger Cold Hardware Vault',
        walletconnect: 'WalletConnect Multi-Chain',
        custom: `${walletNetwork} Web3 Vault`
      };

      const newCrypto: LinkedCryptoWalletItem = {
        id: `cw-${Date.now()}`,
        walletName: walletNames[walletType] || 'Web3 Crypto Wallet',
        walletType: walletType as any,
        address: addr,
        network: walletNetwork,
        isPrimary: (walletData.linkedCryptoWallets?.length || 0) === 0,
        connectedAt: new Date().toISOString(),
        balanceUSD: parseFloat(initialCryptoBalUSD) || 50000,
        ensOrDomain: ensOrDomain || (walletType === 'metamask' ? 'alexander.eth' : walletType === 'phantom' ? 'sterling.sol' : undefined)
      };

      walletData.linkedCryptoWallets = [newCrypto, ...(walletData.linkedCryptoWallets || [])];
      saveStoredUserWallets(userId, walletData);

      setIsSubmitting(false);
      onSuccess('crypto', `${newCrypto.walletName} (${newCrypto.network})`);
      onClose();
    }, 600);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md rounded-3xl bg-white border border-slate-200 shadow-2xl p-6 sm:p-7 overflow-hidden my-auto"
      >
          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer z-10"
            title="Close (Esc)"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center pb-4 border-b border-slate-100">
            <h3 className="text-lg sm:text-xl font-serif font-bold text-slate-900">
              Link Funding Account or Wallet
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Connect your bank, card, or Web3 crypto wallet with instant zero-fee settlement.
            </p>
          </div>

          {/* Switcher: Bank vs Card vs Crypto */}
          <div className="grid grid-cols-3 gap-1 p-1 rounded-2xl bg-slate-100 border border-slate-200 mt-4">
            <button
              type="button"
              onClick={() => {
                setActiveTab('bank');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeTab === 'bank'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="truncate">Bank (FedNow)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('card');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeTab === 'card'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5 text-purple-600 shrink-0" />
              <span className="truncate">Debit / Card</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('crypto');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeTab === 'crypto'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Wallet className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="truncate">Crypto Wallet</span>
            </button>
          </div>

          {errorMsg && (
            <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* 1. Bank Account Form */}
          {activeTab === 'bank' && (
            <form onSubmit={handleLinkBank} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Financial Institution
                </label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                >
                  <option value="JPMorgan Chase & Co.">JPMorgan Chase &amp; Co.</option>
                  <option value="Bank of America">Bank of America</option>
                  <option value="Wells Fargo Bank N.A.">Wells Fargo Bank N.A.</option>
                  <option value="Citigroup Private Client">Citigroup Private Client</option>
                  <option value="Silicon Valley Bank (SVB)">Silicon Valley Bank (SVB)</option>
                  <option value="UBS Switzerland AG">UBS Switzerland AG</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Account Type
                  </label>
                  <select
                    value={accountType}
                    onChange={(e) => setAccountType(e.target.value as any)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                  >
                    <option value="Checking">Checking</option>
                    <option value="Savings">Savings</option>
                    <option value="Brokerage">Brokerage</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Starting Balance ($)
                  </label>
                  <input
                    type="number"
                    value={initialDepositUSD}
                    onChange={(e) => setInitialDepositUSD(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-mono font-bold text-slate-800 bg-slate-50/50"
                    placeholder="50000"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Routing Number (ABA / Fedwire)
                </label>
                <input
                  type="text"
                  value={routingNumber}
                  onChange={(e) => setRoutingNumber(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                  placeholder="021000021"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Account Number
                </label>
                <input
                  type="password"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                  placeholder="••••••••8831"
                  required
                />
              </div>

              <div className="p-2.5 rounded-xl bg-blue-50/70 border border-blue-100 text-[11px] text-blue-900 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>Protected by 256-bit bank grade encryption with Instant FedNow clearance.</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm mt-2"
              >
                {isSubmitting ? (
                  <span>Verifying with FedNow...</span>
                ) : (
                  <>
                    <Building2 className="w-4 h-4" />
                    <span>Connect &amp; Link Bank Account</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* 2. Card Form */}
          {activeTab === 'card' && (
            <form onSubmit={handleLinkCard} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Cardholder Name
                </label>
                <input
                  type="text"
                  value={cardholderName}
                  onChange={(e) => setCardholderName(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs uppercase font-semibold text-slate-800 bg-slate-50/50"
                  placeholder="ALEXANDER STERLING"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Card Number (16 Digits)
                </label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                  placeholder="4829 •••• •••• 9104"
                  maxLength={19}
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Card Type
                  </label>
                  <select
                    value={cardType}
                    onChange={(e) => setCardType(e.target.value as any)}
                    className="w-full h-10 px-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                  >
                    <option value="debit">Debit</option>
                    <option value="credit">Credit</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Expiry
                  </label>
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={expiryMonth}
                      onChange={(e) => setExpiryMonth(e.target.value)}
                      className="w-full h-10 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                      placeholder="12"
                      maxLength={2}
                    />
                    <span>/</span>
                    <input
                      type="text"
                      value={expiryYear}
                      onChange={(e) => setExpiryYear(e.target.value)}
                      className="w-full h-10 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                      placeholder="28"
                      maxLength={2}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    CVV / CVC
                  </label>
                  <input
                    type="password"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value)}
                    className="w-full h-10 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                    placeholder="•••"
                    maxLength={4}
                    required
                  />
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-purple-50/70 border border-purple-100 text-[11px] text-purple-900 flex items-start gap-2">
                <Lock className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                <span>PCI-DSS Tier 1 tokenized card storage. Never stored in plain text.</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm mt-2"
              >
                {isSubmitting ? (
                  <span>Authorizing Card...</span>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    <span>Link Card to Stock Wallet</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* 3. Crypto Wallet Form */}
          {activeTab === 'crypto' && (
            <form onSubmit={handleLinkCrypto} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Choose Web3 Wallet Provider
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'metamask', label: 'MetaMask', icon: '🦊' },
                    { id: 'phantom', label: 'Phantom', icon: '👻' },
                    { id: 'coinbase', label: 'Coinbase', icon: '🔵' },
                    { id: 'ledger', label: 'Ledger', icon: '🛡️' },
                    { id: 'walletconnect', label: 'WalletConnect', icon: '⚡' },
                    { id: 'custom', label: 'Custom Web3', icon: '🔗' },
                  ].map((w) => (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() => setWalletType(w.id as any)}
                      className={`p-2 rounded-xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                        walletType === w.id
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-2xs'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      <span className="text-base">{w.icon}</span>
                      <span className="text-[10px]">{w.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Blockchain Network
                  </label>
                  <select
                    value={walletNetwork}
                    onChange={(e) => setWalletNetwork(e.target.value as any)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                  >
                    <option value="Ethereum">Ethereum (ERC-20)</option>
                    <option value="Solana">Solana (SPL)</option>
                    <option value="Bitcoin">Bitcoin (SegWit)</option>
                    <option value="Polygon">Polygon (AggLayer)</option>
                    <option value="Base">Base L2</option>
                    <option value="Arbitrum">Arbitrum Nitro</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Liquid Balance ($ USD)
                  </label>
                  <input
                    type="number"
                    value={initialCryptoBalUSD}
                    onChange={(e) => setInitialCryptoBalUSD(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-mono font-bold text-slate-800 bg-slate-50/50"
                    placeholder="50000"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Public Wallet Address
                </label>
                <input
                  type="text"
                  value={cryptoAddress}
                  onChange={(e) => setCryptoAddress(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                  placeholder={
                    walletNetwork === 'Solana' 
                      ? '7XwK8f921a9LzP201948xX...'
                      : walletNetwork === 'Bitcoin'
                      ? 'bc1q9d83274fak9201f829a...'
                      : '0x71C83952fA98246E28198751...'
                  }
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  ENS / Domain Handle (Optional)
                </label>
                <input
                  type="text"
                  value={ensOrDomain}
                  onChange={(e) => setEnsOrDomain(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                  placeholder="alexander.eth or sterling.sol"
                />
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-100 text-[11px] text-emerald-900 flex items-start gap-2">
                <Globe className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Web3 Signature verification. Self-custodial title linked to your Final Finance account.</span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm mt-2"
              >
                {isSubmitting ? (
                  <span>Signing Web3 Handshake...</span>
                ) : (
                  <>
                    <Zap className="w-4 h-4 text-emerald-400" />
                    <span>Connect &amp; Link Crypto Wallet</span>
                  </>
                )}
              </button>
            </form>
          )}
      </div>
    </div>
  );
};
