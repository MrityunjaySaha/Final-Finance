export const ACCOUNT_STATUS_UPDATED_EVENT = 'final_finance_account_status_updated';

const SELF_DEACTIVATED_STORAGE_KEY = 'ff_self_deactivated_accounts_v1';
const DELETED_ACCOUNTS_STORAGE_KEY = 'ff_deleted_accounts_v1';
const LOCKED_ACCOUNTS_STORAGE_KEY = 'ff_locked_accounts_v1';

export interface LockedAccountRecord {
  uid: string;
  userId: string;
  name: string;
  email?: string;
  avatarUrl?: string;
  source: 'user_lock' | 'super_admin_lock';
  lockedAt: string;
}

export interface SelfDeactivatedAccountRecord {
  uid: string;
  userId: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: 'user' | 'admin' | 'super_admin' | 'guest';
  deactivatedAt: string;
}

export interface DeletedAccountRecord {
  id: string;
  uid: string;
  userId: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: 'user' | 'admin' | 'super_admin' | 'guest';
  jobTitle?: string;
  deletedAt: string;
  deletedBy: 'self';
}

function expandSingleIdentifier(raw: string): string[] {
  const trimmed = raw.trim();
  if (!trimmed) return [];
  const lower = trimmed.toLowerCase();
  const noAt = lower.replace(/^@/, '');
  const results = new Set<string>([trimmed, lower, noAt]);

  // Extract bare handle from prefixes like user-*, demo-*, google-*
  let bare = noAt;
  if (bare.startsWith('user-')) bare = bare.slice(5);
  else if (bare.startsWith('demo-')) bare = bare.slice(5);
  else if (bare.startsWith('google-')) bare = bare.slice(7);

  if (bare) {
    results.add(bare);
    results.add(`user-${bare}`);
    results.add(`demo-${bare}`);
    results.add(`google-${bare}`);
    results.add(bare.replace(/-/g, '_'));
    results.add(`user-${bare.replace(/-/g, '_')}`);
    results.add(`demo-${bare.replace(/_/g, '-')}`);
  }

  return Array.from(results);
}

export function buildIdentityKeys(identifiers: Array<string | undefined | null>): string[] {
  const keys = new Set<string>();
  for (const id of identifiers) {
    if (!id || typeof id !== 'string') continue;
    for (const variant of expandSingleIdentifier(id)) {
      keys.add(variant);
    }
  }
  return Array.from(keys);
}

export function emitAccountStatusUpdated(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(ACCOUNT_STATUS_UPDATED_EVENT));
  }
}

export function getLockedAccountRecords(
  filterSource?: 'user_lock' | 'super_admin_lock'
): LockedAccountRecord[] {
  try {
    const raw = localStorage.getItem(LOCKED_ACCOUNTS_STORAGE_KEY);
    const list: LockedAccountRecord[] = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(list)) return [];
    if (filterSource) {
      return list.filter((rec) => rec.source === filterSource);
    }
    return list;
  } catch {
    return [];
  }
}

export function isAccountLocked(identifiers: Array<string | undefined | null>): boolean {
  const keys = buildIdentityKeys(identifiers);
  for (const k of keys) {
    try {
      if (localStorage.getItem(`ff_user_locked_${k}`) === 'true') {
        return true;
      }
    } catch {
      // ignore storage errors
    }
  }
  return false;
}

export function setAccountLocked(
  identifiers: Array<string | undefined | null>,
  locked: boolean,
  metadata?: {
    uid?: string;
    userId?: string;
    name?: string;
    email?: string;
    avatarUrl?: string;
    source?: 'user_lock' | 'super_admin_lock';
  }
): void {
  const keys = buildIdentityKeys(identifiers);
  for (const k of keys) {
    try {
      if (locked) {
        localStorage.setItem(`ff_user_locked_${k}`, 'true');
      } else {
        localStorage.removeItem(`ff_user_locked_${k}`);
      }
    } catch {
      // ignore
    }
  }

  try {
    const existing = getLockedAccountRecords();
    const keySet = new Set(keys.map((k) => k.toLowerCase()));
    const cleanSource = metadata?.source || 'user_lock';
    const filtered = existing.filter((rec) => {
      const recKeys = buildIdentityKeys([rec.uid, rec.userId, rec.email]).map((k) => k.toLowerCase());
      const matchesIdentity = recKeys.some((k) => keySet.has(k));
      if (!matchesIdentity) return true;
      if (locked) {
        return rec.source !== cleanSource;
      }
      // If unlocking with an explicit source, only remove records of that source unless no metadata given
      if (metadata?.source) {
        return rec.source !== metadata.source;
      }
      return false;
    });

    if (locked) {
      const fallbackUserId = (
        metadata?.userId ||
        identifiers.find((i) => typeof i === 'string' && i.trim().length > 0) ||
        'user'
      )
        .trim()
        .toLowerCase()
        .replace(/^@/, '')
        .replace(/^demo-/, '')
        .replace(/^user-/, '');
      const nextRecord: LockedAccountRecord = {
        uid: metadata?.uid || `user-${fallbackUserId}`,
        userId: fallbackUserId,
        name: metadata?.name || fallbackUserId,
        email: metadata?.email?.trim().toLowerCase(),
        avatarUrl: metadata?.avatarUrl,
        source: cleanSource,
        lockedAt: new Date().toISOString(),
      };
      localStorage.setItem(LOCKED_ACCOUNTS_STORAGE_KEY, JSON.stringify([nextRecord, ...filtered]));
    } else {
      localStorage.setItem(LOCKED_ACCOUNTS_STORAGE_KEY, JSON.stringify(filtered));
    }
  } catch {
    // ignore
  }

  emitAccountStatusUpdated();
}

export function getSelfDeactivatedAccounts(
  filterRole?: 'user' | 'admin'
): SelfDeactivatedAccountRecord[] {
  try {
    const raw = localStorage.getItem(SELF_DEACTIVATED_STORAGE_KEY);
    const list: SelfDeactivatedAccountRecord[] = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(list)) return [];
    if (filterRole === 'admin') {
      return list.filter((item) => item.role === 'admin' || item.role === 'super_admin');
    }
    if (filterRole === 'user') {
      return list.filter((item) => item.role !== 'admin' && item.role !== 'super_admin');
    }
    return list;
  } catch {
    return [];
  }
}

export function isAccountDeactivated(identifiers: Array<string | undefined | null>): boolean {
  const keys = buildIdentityKeys(identifiers);
  for (const k of keys) {
    try {
      if (localStorage.getItem(`ff_user_deactivated_${k}`) === 'true') {
        return true;
      }
    } catch {
      // ignore
    }
  }
  if (keys.length > 0) {
    const keySet = new Set(keys.map((k) => k.toLowerCase()));
    const list = getSelfDeactivatedAccounts();
    return list.some(
      (rec) =>
        keySet.has((rec.userId || '').toLowerCase()) ||
        keySet.has((rec.uid || '').toLowerCase()) ||
        keySet.has((rec.email || '').toLowerCase())
    );
  }
  return false;
}

export function markAccountSelfDeactivated(account: {
  uid?: string;
  id?: string;
  userId?: string;
  name?: string;
  email?: string;
  avatarUrl?: string;
  role?: 'user' | 'admin' | 'super_admin' | 'guest';
}): void {
  const cleanUserId = (account.userId || account.id || account.email?.split('@')[0] || 'member')
    .trim()
    .toLowerCase()
    .replace(/^@/, '');
  const cleanEmail = (account.email || '').trim().toLowerCase();
  const cleanUid = (account.uid || `user-${cleanUserId}`).trim();

  const keys = buildIdentityKeys([cleanUid, cleanUserId, account.id, cleanEmail]);
  for (const k of keys) {
    try {
      localStorage.setItem(`ff_user_deactivated_${k}`, 'true');
    } catch {
      // ignore
    }
  }

  try {
    const existing = getSelfDeactivatedAccounts();
    const keySet = new Set(keys.map((k) => k.toLowerCase()));
    const filtered = existing.filter(
      (rec) =>
        !keySet.has((rec.userId || '').toLowerCase()) &&
        !keySet.has((rec.uid || '').toLowerCase()) &&
        !(cleanEmail && (rec.email || '').toLowerCase() === cleanEmail)
    );
    const nextRecord: SelfDeactivatedAccountRecord = {
      uid: cleanUid,
      userId: cleanUserId,
      name: account.name || cleanUserId,
      email: cleanEmail,
      avatarUrl: account.avatarUrl,
      role: account.role || 'user',
      deactivatedAt: new Date().toISOString(),
    };
    localStorage.setItem(SELF_DEACTIVATED_STORAGE_KEY, JSON.stringify([nextRecord, ...filtered]));
  } catch {
    // ignore
  }

  emitAccountStatusUpdated();
}

export function clearAccountDeactivated(identifiers: Array<string | undefined | null>): void {
  const keys = buildIdentityKeys(identifiers);
  for (const k of keys) {
    try {
      localStorage.removeItem(`ff_user_deactivated_${k}`);
    } catch {
      // ignore
    }
  }

  try {
    const existing = getSelfDeactivatedAccounts();
    if (existing.length > 0) {
      const keySet = new Set(keys.map((k) => k.toLowerCase()));
      const filtered = existing.filter(
        (rec) =>
          !keySet.has((rec.userId || '').toLowerCase()) &&
          !keySet.has((rec.uid || '').toLowerCase()) &&
          !keySet.has((rec.email || '').toLowerCase())
      );
      localStorage.setItem(SELF_DEACTIVATED_STORAGE_KEY, JSON.stringify(filtered));
    }
  } catch {
    // ignore
  }

  emitAccountStatusUpdated();
}

export function getDeletedAccounts(filterRole?: 'user' | 'admin'): DeletedAccountRecord[] {
  try {
    const raw = localStorage.getItem(DELETED_ACCOUNTS_STORAGE_KEY);
    const list: DeletedAccountRecord[] = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(list)) return [];
    const sorted = [...list].sort(
      (a, b) => new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime()
    );
    if (filterRole === 'admin') {
      return sorted.filter((item) => item.role === 'admin' || item.role === 'super_admin');
    }
    if (filterRole === 'user') {
      return sorted.filter((item) => item.role !== 'admin' && item.role !== 'super_admin');
    }
    return sorted;
  } catch {
    return [];
  }
}

export function getDeletedAccountEmails(): Set<string> {
  const emails = new Set<string>();
  for (const rec of getDeletedAccounts()) {
    if (rec.email) {
      emails.add(rec.email.trim().toLowerCase());
    }
  }
  return emails;
}

export function recordDeletedAccount(account: {
  uid?: string;
  id?: string;
  userId?: string;
  name?: string;
  email?: string;
  avatarUrl?: string;
  role?: 'user' | 'admin' | 'super_admin' | 'guest';
  jobTitle?: string;
}): DeletedAccountRecord {
  const cleanUserId = (account.userId || account.id || account.email?.split('@')[0] || 'deleted_user')
    .trim()
    .toLowerCase()
    .replace(/^@/, '');
  const cleanEmail = (account.email || '').trim().toLowerCase();
  const cleanUid = (account.uid || `user-${cleanUserId}`).trim();

  const record: DeletedAccountRecord = {
    id: `del-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    uid: cleanUid,
    userId: cleanUserId,
    name: account.name || cleanUserId,
    email: cleanEmail,
    avatarUrl: account.avatarUrl,
    role: account.role || 'user',
    jobTitle: account.jobTitle,
    deletedAt: new Date().toISOString(),
    deletedBy: 'self',
  };

  try {
    const existing = getDeletedAccounts();
    const filtered = existing.filter(
      (item) =>
        !(cleanEmail && item.email.toLowerCase() === cleanEmail) &&
        item.userId.toLowerCase() !== cleanUserId
    );
    localStorage.setItem(DELETED_ACCOUNTS_STORAGE_KEY, JSON.stringify([record, ...filtered]));
  } catch {
    // ignore
  }

  // Clean up any deactivated or locked flags for this deleted account so it doesn't linger in Deactivated
  clearAccountDeactivated([cleanUid, cleanUserId, account.id, cleanEmail]);
  setAccountLocked([cleanUid, cleanUserId, account.id, cleanEmail], false);

  return record;
}
