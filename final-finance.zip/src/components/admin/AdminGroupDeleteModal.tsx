import React, { useEffect } from 'react';
import { Trash2, X, Users } from 'lucide-react';
import { AdminGroup } from '../../services/adminGroupService';

interface AdminGroupDeleteModalProps {
  group: AdminGroup;
  onClose: () => void;
  onConfirm: () => void;
}

export const AdminGroupDeleteModal: React.FC<AdminGroupDeleteModalProps> = ({
  group,
  onClose,
  onConfirm,
}) => {
  // Handle ESC key to dismiss
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const memberCount = group.adminIds.length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-group-title"
    >
      <div
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4.5 border-b border-rose-100 flex items-center justify-between bg-rose-50/70 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 border border-rose-200 shadow-2xs">
              <Trash2 className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h3 id="delete-group-title" className="font-serif text-base font-bold text-slate-900">
                Delete Admin Group
              </h3>
              <p className="text-[11px] text-rose-700 font-medium">
                Confirmation required before removal
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="w-8 h-8 rounded-full hover:bg-rose-200/60 flex items-center justify-center text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4 flex-1 overflow-y-auto min-h-0">
          <p className="text-xs text-slate-600 leading-relaxed">
            Are you sure you want to permanently delete the admin group{' '}
            <strong className="text-slate-900 font-bold">"{group.name}"</strong>?
          </p>

          {/* Group Summary Preview */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <span
                  className="w-3.5 h-3.5 rounded-full shrink-0 ring-2 ring-white shadow-xs"
                  style={{ backgroundColor: group.color }}
                />
                <span className="font-serif font-bold text-sm text-slate-900 truncate">
                  {group.name}
                </span>
              </div>
              <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono font-bold bg-white text-slate-700 border border-slate-200 shrink-0">
                {memberCount} {memberCount === 1 ? 'Admin' : 'Admins'}
              </span>
            </div>

            {group.description && (
              <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed italic">
                "{group.description}"
              </p>
            )}
          </div>

          {/* Safety Notice */}
          <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200 text-[11px] text-amber-900 leading-relaxed space-y-1">
            <p className="font-bold text-amber-950 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-amber-700 shrink-0" />
              Member Accounts Are Safe:
            </p>
            <p className="text-amber-800">
              Deleting this group removes the group configuration and unassigns all members. No administrator accounts or system credentials will be deleted.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-end gap-2.5 bg-slate-50/70 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete Group</span>
          </button>
        </div>
      </div>
    </div>
  );
};
