import React, { useState, useEffect, useMemo } from 'react';
import { getAllLoans } from '../services/loanService';
import { useApp } from '../context/AppContext';
import { 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  Timer, 
  Zap, 
  Coins, 
  ShieldCheck,
  FileCheck,
  AlertCircle,
  ArrowDownLeft,
  Wallet,
  Check,
  ExternalLink,
  Image,
  Video,
  Upload,
  X
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { recordLedgerTransaction, createLedgerItemFromGrantClaim } from '../utils/universalLedgerBridge';

interface SubsidiesGrantsPageProps {
  currentUser?: AuthSession | null;
  onOpenVerification?: () => void;
  onNavigateToSettings?: () => void;
  onNavigateBack?: () => void;
}

export const SubsidiesGrantsPage: React.FC<SubsidiesGrantsPageProps> = ({
  currentUser,
  onOpenVerification,
  onNavigateToSettings,
}) => {
  const { addNotification } = useApp();
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeBankingView, setActiveBankingView] = useState<'transactions' | 'portfolio'>('transactions');
  const [activePortfolioTab, setActivePortfolioTab] = useState<'ongoing' | 'concluded'>('ongoing');
  const [activeLoanType, setActiveLoanType] = useState<'given' | 'received'>('given');
  const [activeSubTab, setActiveSubTab] = useState<'ubi' | 'grants' | 'banking'>('ubi');
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';
  const userId = currentUser?.id || 'guest_trader';

  const allLoans = useMemo(() => {
    const realLoans = getAllLoans();
    const handle = currentUser?.handle || 'user';
    const exampleLoans = [
      { id: 'ex-given-active', amount: 5000, coinSymbol: 'AFNL', status: 'active', lenderHandle: handle, borrowerHandle: 'alice', termDays: 30, issuedAtMs: Date.now() - 5000000 },
      { id: 'ex-rcv-active', amount: 2500, coinSymbol: 'AFNL', status: 'active', lenderHandle: 'bob', borrowerHandle: handle, termDays: 14, issuedAtMs: Date.now() - 2000000 },
      { id: 'ex-given-repaid', amount: 10000, coinSymbol: 'AFNL', status: 'repaid', lenderHandle: handle, borrowerHandle: 'charlie', termDays: 60, issuedAtMs: Date.now() - 10000000 },
      { id: 'ex-rcv-defaulted', amount: 3500, coinSymbol: 'AFNL', status: 'defaulted', lenderHandle: 'dave', borrowerHandle: handle, termDays: 30, issuedAtMs: Date.now() - 15000000 }
    ];
    return [...realLoans, ...exampleLoans];
  }, [currentUser?.handle]);
  const activeLoans = useMemo(() => allLoans.filter(l => l.status === 'active'), [allLoans]);
  const concludedLoans = useMemo(() => allLoans.filter(l => l.status === 'repaid' || l.status === 'defaulted'), [allLoans]);
  const receivedLoans = useMemo(() => allLoans.filter(l => l.borrowerHandle === currentUser?.handle), [allLoans, currentUser?.handle]);
  const userGender = localStorage.getItem(`ff_user_gender_${userId}`) || currentUser?.gender || 'male';
  const accrualRate = userGender === 'female' ? 0.12 : userGender === 'other' ? 0.11 : 0.1;

  // Check if user is verified with at least 1 form of ID
  const isVerified = Boolean(
    currentUser?.isVerified ||
    currentUser?.verification?.verified ||
    (currentUser?.verification?.idDocument1Type && currentUser?.verification?.idDocument1Name) ||
    localStorage.getItem(`ff_user_verified_${userId}`) === 'true'
  );

  // Signup Grant status: 'unclaimed' | 'claimed_to_pool' | 'deposited'
  const [signupStatus, setSignupStatus] = useState<'unclaimed' | 'claimed_to_pool' | 'deposited'>(() => {
    return (localStorage.getItem(`ff_signup_status_${userId}`) as any) || 'unclaimed';
  });

  // Accrued subsidy state (starts at 0.0 by default)
  const [unclaimedAccruedAFNL, setUnclaimedAccruedAFNL] = useState<number>(() => {
    const saved = localStorage.getItem(`ff_unclaimed_accrued_${userId}`);
    return saved ? parseFloat(saved) : 0;
  });

  const [claimedAccruedAFNL, setClaimedAccruedAFNL] = useState<number>(() => {
    const saved = localStorage.getItem(`ff_claimed_accrued_${userId}`);
    return saved ? parseFloat(saved) : 0;
  });

  // Countdown timer for next AFNL unit (60 seconds, persistent across page navigation & signed out state)
  const [secondsRemaining, setSecondsRemaining] = useState<number>(() => {
    const now = Date.now();
    let lastTsStr = localStorage.getItem(`ff_last_accrual_ts_${userId}`);
    if (!lastTsStr) {
      lastTsStr = now.toString();
      localStorage.setItem(`ff_last_accrual_ts_${userId}`, lastTsStr);
    }
    const lastTs = parseInt(lastTsStr, 10);
    const elapsedSec = Math.floor((now - lastTs) / 1000);

    // If enough time passed while away, catch up accrued minutes automatically
    if (elapsedSec >= 60) {
      const completedMinutes = Math.floor(elapsedSec / 60);
      const remainingSeconds = elapsedSec % 60;
      
      const newLastTs = now - (remainingSeconds * 1000);
      localStorage.setItem(`ff_last_accrual_ts_${userId}`, newLastTs.toString());

      const currentUnclaimed = parseFloat(localStorage.getItem(`ff_unclaimed_accrued_${userId}`) || '0');
      const added = completedMinutes * accrualRate;
      const updatedUnclaimed = Math.round((currentUnclaimed + added) * 100) / 100;
      localStorage.setItem(`ff_unclaimed_accrued_${userId}`, updatedUnclaimed.toString());

      return 60 - remainingSeconds > 0 ? 60 - remainingSeconds : 60;
    } else {
      const rem = 60 - elapsedSec;
      return rem > 0 && rem <= 60 ? rem : 60;
    }
  });

  // Wallet data state
  const [walletData, setWalletData] = useState(() => getStoredUserWallets(userId));

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Listen to external wallet updates
  useEffect(() => {
    const handleWalletUpdate = () => {
      setWalletData(getStoredUserWallets(userId));
    };
    window.addEventListener('final_finance_wallets_updated', handleWalletUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleWalletUpdate);
    };
  }, [userId]);

  // Bank Application State
  const [bankAppStatus, setBankAppStatus] = useState<'none' | 'pending' | 'approved'>(() => {
    return (localStorage.getItem(`ff_bank_app_status_${userId}`) as any) || 'none';
  });
  const [bankModalOpen, setBankModalOpen] = useState(false);
  const [institutionName, setInstitutionName] = useState('');
  const [capitalReserves, setCapitalReserves] = useState('250,000');
  const [institutionReason, setInstitutionReason] = useState('');

  // Final Coin Loan Desk State
  const [loanModalOpen, setLoanModalOpen] = useState(false);
  const [borrowerHandle, setBorrowerHandle] = useState('@');
  const [loanAmount, setLoanAmount] = useState('1000');
  const [loanSymbol, setLoanSymbol] = useState('AFNL');
  const [loanInterest, setLoanInterest] = useState('4.5');
  const [loanTermDays, setLoanTermDays] = useState('30');
  const [loansIssued, setLoansIssued] = useState<any[]>([]);
  const [loansReceived, setLoansReceived] = useState<any[]>([]);
  const [activeLoanTab, setActiveLoanTab] = useState<'issued' | 'received'>('issued');

  useEffect(() => {
    // dynamically import to avoid top level circular deps if any, or just import
    import('../services/loanService').then(m => {
      const { issued, received } = m.getLoansForUser(userId);
      setLoansIssued(issued);
      setLoansReceived(received);
    });
  }, [userId]);

  const reloadLoans = async () => {
    const m = await import('../services/loanService');
    const { issued, received } = m.getLoansForUser(userId);
    setLoansIssued(issued);
    setLoansReceived(received);
  };

  const handleRepayLoan = async (loan: any) => {
    const m = await import('../services/loanService');
    const { getStoredUserWallets, saveStoredUserWallets } = await import('../data/defaultWallets');

    const wallet = getStoredUserWallets(userId);
    const afnl = wallet.finalCoins.find(c => c.symbol === 'AFNL');
    
    // Principal + Interest
    const repaymentAmount = loan.amount + (loan.amount * (loan.interestRate / 100));

    if (!afnl || afnl.balance < repaymentAmount) {
        showToast(`Insufficient AFNL to repay this loan. You need ${repaymentAmount.toLocaleString()} AFNL.`);
        return;
    }
    
    afnl.balance -= repaymentAmount;
    saveStoredUserWallets(userId, wallet);
    window.dispatchEvent(new Event('final_finance_wallets_updated'));
    
    m.updateLoanStatus(loan.id, 'repaid');

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-REPAY-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

    const repayItemOut = {
        id: `rec-repay-out-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        receiptNumber: recNum,
        taxYear: 2026,
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'loan_repaid' as const,
        category: 'loan' as const,
        mode: loan.coinSymbol === 'AFNL' ? 'final_coin' as const : 'stable_coin' as const,
        title: `Loan Repaid to ${loan.lenderHandle}`,
        description: `Repaid principal & interest for loan of ${loan.amount.toLocaleString()} ${loan.coinSymbol} to ${loan.lenderHandle}. Total paid: ${repaymentAmount.toLocaleString()}`,
        amountUSD: repaymentAmount,
        feeUSD: 0.00,
        netAmountUSD: -repaymentAmount,
        sourceOrDestination: loan.lenderHandle,
        counterpartyOrIssuer: `User Wallet (@${currentUser?.handle || 'wallet'})`,
        paymentCoinSymbol: loan.coinSymbol,
        paymentCoinAmount: repaymentAmount,
        taxClassification: {
            formMapping: 'Non-Taxable Transfer' as const,
            taxableEvent: false,
            taxableAmountUSD: 0,
            holdingPeriod: 'N/A' as const,
            taxDeductible: false,
            irsCategoryNote: 'Sovereign loan principal repayment out.'
        },
        status: 'Settled' as const,
        clearingNode: 'Sovereign Clearing Node #01',
        cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
        signature: `SIG-REPAY-${Math.floor(100000 + Math.random() * 900000)}`
    };

    recordLedgerTransaction(userId, repayItemOut as any);
    
    const lenderWallet = getStoredUserWallets(loan.lenderId);
    const lenderAfnl = lenderWallet.finalCoins.find(c => c.symbol === 'AFNL');
    if (lenderAfnl) {
        lenderAfnl.balance += repaymentAmount;
        saveStoredUserWallets(loan.lenderId, lenderWallet);
    }
    
    const repayItemIn = { ...repayItemOut, 
        id: `rec-repay-in-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        netAmountUSD: repaymentAmount,
        title: `Loan Repayment Received from ${loan.borrowerHandle}`,
        description: `Received principal & interest repayment for loan of ${loan.amount.toLocaleString()} ${loan.coinSymbol} from ${loan.borrowerHandle}. Total received: ${repaymentAmount.toLocaleString()}`,
        sourceOrDestination: loan.borrowerHandle,
        counterpartyOrIssuer: `Clearing Bank Vault (@${loan.lenderId})`,
        taxClassification: { ...repayItemOut.taxClassification, irsCategoryNote: 'Sovereign loan principal repayment in.' }
    };
    recordLedgerTransaction(loan.lenderId, repayItemIn as any);

    showToast(`Loan of ${loan.amount} ${loan.coinSymbol} successfully repaid.`);
    addNotification({
      title: 'Loan Successfully Repaid',
      description: `Your loan of ${loan.amount} ${loan.coinSymbol} has been fully settled and repaid.`,
      type: 'loans',
      targetTab: 'subsidies',
    });
    reloadLoans();
  };

  const handleDefaultLoan = async (loan: any) => {
    const now = Date.now();
    const dueDateMs = loan.issuedAtMs + (loan.termDays * 24 * 60 * 60 * 1000);
    
    if (now < dueDateMs) {
      const daysLeft = Math.ceil((dueDateMs - now) / (24 * 60 * 60 * 1000));
      showToast(`Cannot declare default yet. This loan is not due for another ${daysLeft} days.`);
      return;
    }

    const m = await import('../services/loanService');
    m.updateLoanStatus(loan.id, 'defaulted');
    
    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-DEFAULT-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

    const defaultItem = {
        id: `rec-default-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        receiptNumber: recNum,
        taxYear: 2026,
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'loan_written_off' as const,
        category: 'loan' as const,
        mode: loan.coinSymbol === 'AFNL' ? 'final_coin' as const : 'stable_coin' as const,
        title: `Loan Default Declared for ${loan.borrowerHandle}`,
        description: `Bad debt write-off for defaulted loan of ${loan.amount.toLocaleString()} ${loan.coinSymbol} by ${loan.borrowerHandle}.`,
        amountUSD: loan.amount,
        feeUSD: 0.00,
        netAmountUSD: -loan.amount,
        sourceOrDestination: loan.borrowerHandle,
        counterpartyOrIssuer: `Clearing Bank Vault (@${currentUser?.handle || 'bank'})`,
        paymentCoinSymbol: loan.coinSymbol,
        paymentCoinAmount: loan.amount,
        taxClassification: {
            formMapping: 'Schedule C / Business Expense' as const,
            taxableEvent: true,
            taxableAmountUSD: -loan.amount,
            holdingPeriod: 'N/A' as const,
            taxDeductible: true,
            irsCategoryNote: 'Bad debt write-off for uncollectible sovereign loan.'
        },
        status: 'Settled' as const,
        clearingNode: 'Sovereign Clearing Node #01',
        cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
        signature: `SIG-DEF-${Math.floor(100000 + Math.random() * 900000)}`
    };

    recordLedgerTransaction(userId, defaultItem as any);
    
    const defaultItemBorrower = { ...defaultItem, 
        id: `rec-default-borrower-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        type: 'loan_defaulted' as const,
        netAmountUSD: 0,
        title: `Loan Defaulted to ${loan.lenderHandle}`,
        description: `Failed to repay loan of ${loan.amount.toLocaleString()} ${loan.coinSymbol} to ${loan.lenderHandle}.`,
        sourceOrDestination: loan.lenderHandle,
        counterpartyOrIssuer: `User Wallet (@${loan.borrowerId})`,
        taxClassification: { ...defaultItem.taxClassification, formMapping: 'Non-Taxable Transfer' as const, taxableEvent: false, taxDeductible: false, irsCategoryNote: 'Loan defaulted' }
    };
    recordLedgerTransaction(loan.borrowerId, defaultItemBorrower as any);

    showToast(`Loan to ${loan.borrowerHandle} declared defaulted.`);
    reloadLoans();
  };

  const handleApplyForBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!institutionName.trim()) {
      showToast('Please enter your institution or bank name.');
      return;
    }
    setBankAppStatus('pending');
    localStorage.setItem(`ff_bank_app_status_${userId}`, 'pending');
    localStorage.setItem(`ff_bank_app_name_${userId}`, institutionName);
    showToast('Bank Application Submitted for Review.');
    setBankModalOpen(false);
  };

  const handleCancelBankApp = () => {
    setBankAppStatus('none');
    localStorage.removeItem(`ff_bank_app_status_${userId}`);
    localStorage.removeItem(`ff_bank_app_name_${userId}`);
    showToast('Banking Application Cancelled.');
  };

  const handleIssueLoan = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(loanAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('Please enter a valid loan amount.');
      return;
    }
    if (!borrowerHandle.trim()) {
      showToast('Please enter a borrower handle.');
      return;
    }

    import('../services/loanService').then(m => {
      const bh = borrowerHandle.startsWith('@') ? borrowerHandle : `@${borrowerHandle}`;
      const newLoan = {
        id: `loan-${Date.now()}`,
        lenderId: userId,
        lenderHandle: currentUser?.handle || '@clearing_bank',
        borrowerId: bh.replace('@', ''),
        borrowerHandle: bh,
        amount: amt,
        coinSymbol: loanSymbol,
        interestRate: parseFloat(loanInterest) || 5.0,
        termDays: parseInt(loanTermDays, 10) || 30,
        status: 'active' as const,
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
        issuedAtMs: Date.now()
      };

      m.createLoan(newLoan as any);
      reloadLoans();

      const dateObj = new Date();
      const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
      const recNum = `REC-LOAN-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

      const ledgerItem = {
        id: `rec-loan-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        receiptNumber: recNum,
        taxYear: 2026,
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'loan_issued' as const,
        category: 'loan' as const,
        mode: loanSymbol === 'AFNL' ? 'final_coin' as const : 'stable_coin' as const,
        title: `Final Coin Loan Issued (Giving Loan to ${bh})`,
        description: `Issued ${amt.toLocaleString()} ${loanSymbol} loan at ${newLoan.interestRate}% APR (${newLoan.termDays} days term) to ${bh}.`,
        amountUSD: amt,
        feeUSD: 0.00,
        netAmountUSD: amt,
        sourceOrDestination: `Clearing Bank Vault (@${currentUser?.handle || 'bank'})`,
        counterpartyOrIssuer: bh,
        paymentCoinSymbol: loanSymbol,
        paymentCoinAmount: amt,
        taxClassification: {
          formMapping: 'Non-Taxable Transfer' as const,
          taxableEvent: false,
          taxableAmountUSD: 0,
          holdingPeriod: 'N/A' as const,
          taxDeductible: false,
          irsCategoryNote: 'Inter-bank sovereign final coin loan principal issuance.'
        },
        status: 'Settled' as const,
        clearingNode: 'Sovereign Clearing Node #01',
        cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
        signature: `SIG-LOAN-${Math.floor(100000 + Math.random() * 900000)}`
      };

      recordLedgerTransaction(userId, ledgerItem);
      setLoanModalOpen(false);
      setBorrowerHandle('@');
      setLoanAmount('1000');
      showToast(`Successfully issued loan of ${amt.toLocaleString()} ${loanSymbol} to ${bh}!`);
    });
  };

  // Timestamp-based robust accrual logic (0.1 AFNL every 1 minute) persistent across page navigation
  useEffect(() => {
    if (!localStorage.getItem(`ff_last_accrual_ts_${userId}`)) {
      localStorage.setItem(`ff_last_accrual_ts_${userId}`, Date.now().toString());
    }

    const interval = setInterval(() => {
      const now = Date.now();
      const lastTs = parseInt(localStorage.getItem(`ff_last_accrual_ts_${userId}`) || now.toString(), 10);
      const elapsedSeconds = Math.floor((now - lastTs) / 1000);

      if (elapsedSeconds >= 60) {
        const completedMinutes = Math.floor(elapsedSeconds / 60);
        const remainingSeconds = elapsedSeconds % 60;

        const newLastTs = now - (remainingSeconds * 1000);
        localStorage.setItem(`ff_last_accrual_ts_${userId}`, newLastTs.toString());

        // Add accrualRate per completed minute
        setUnclaimedAccruedAFNL(curr => {
          const added = completedMinutes * accrualRate;
          const updated = Math.round((curr + added) * 100) / 100;
          localStorage.setItem(`ff_unclaimed_accrued_${userId}`, updated.toString());
          return updated;
        });

        setSecondsRemaining(60 - remainingSeconds);
      } else {
        setSecondsRemaining(60 - elapsedSeconds);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [userId]);

  // Claim 4,000 AFNL Signup Grant into deposit pool (One-time only, requires verification)
  const handleClaimSignupGrant = () => {
    if (!isVerified) {
      showToast('You must be verified with at least 1 form of ID in Settings before claiming grants.');
      return;
    }

    if (signupStatus === 'deposited' || signupStatus === 'claimed_to_pool') {
      showToast('Signup grant is a one-time bonus and has already been claimed.');
      return;
    }

    setSignupStatus('claimed_to_pool');
    localStorage.setItem(`ff_signup_status_${userId}`, 'claimed_to_pool');
    showToast('Successfully added your one-time 4,000 Final Admin Coins (AFNL) signup grant to your deposit pool!');
    addNotification({
      title: 'One-Time Signup Grant Claimed',
      description: 'Successfully claimed your one-time 4,000 AFNL protocol bonus to your deposit pool.',
      type: 'vault',
      targetTab: 'subsidies',
    });
  };

  // Claim Unclaimed Accrued Subsidy into deposit pool (requires verification)
  const handleClaimAccrued = () => {
    if (!isVerified) {
      showToast('You must be verified with at least 1 form of ID in Settings before claiming subsidies.');
      return;
    }

    if (unclaimedAccruedAFNL <= 0) {
      showToast('No accrued subsidy available to claim yet.');
      return;
    }

    const claimAmount = unclaimedAccruedAFNL;
    const newClaimed = Math.round((claimedAccruedAFNL + claimAmount) * 10) / 10;
    
    setClaimedAccruedAFNL(newClaimed);
    localStorage.setItem(`ff_claimed_accrued_${userId}`, newClaimed.toString());

    setUnclaimedAccruedAFNL(0);
    localStorage.setItem(`ff_unclaimed_accrued_${userId}`, '0');

    showToast(`Claimed +${claimAmount.toFixed(1)} AFNL accrued subsidy into your deposit pool!`);
    addNotification({
      title: 'Sovereign Subsidy Claimed',
      description: `Successfully claimed +${claimAmount.toFixed(1)} AFNL accrued subsidy into your deposit pool.`,
      type: 'vault',
      targetTab: 'subsidies',
    });
  };

  // Total claimable AFNL waiting to be deposited
  const totalClaimableAFNL = (signupStatus === 'claimed_to_pool' ? 4000 : 0) + claimedAccruedAFNL;

  // Deposit AFNL into Final Wallet (requires verification)
  const handleDepositToFinalWallet = () => {
    if (!isVerified) {
      showToast('You must be verified with at least 1 form of ID in Settings before depositing coins.');
      return;
    }

    if (totalClaimableAFNL <= 0) {
      showToast('No AFNL coins available in your deposit pool to deposit.');
      return;
    }

    try {
      const wallet = getStoredUserWallets(userId);
      const afnlIndex = wallet.finalCoins.findIndex(c => c.symbol === 'AFNL');

      if (afnlIndex >= 0) {
        wallet.finalCoins[afnlIndex].balance += totalClaimableAFNL;
      } else {
        wallet.finalCoins.unshift({
          id: 'fc-admin-subsidy-signup',
          name: 'Final Admin Coin',
          symbol: 'AFNL',
          balance: totalClaimableAFNL,
          unitPriceUSD: 28.75,
          change24h: 3.84,
          utility: 'Initial 4000 AFNL signup grant & continuous 0.1 AFNL/min (~4,000/mo) subsidy accrual.'
        });
      }

      saveStoredUserWallets(userId, wallet);
      setWalletData(wallet);
      window.dispatchEvent(new Event('final_finance_wallets_updated'));

      if (signupStatus === 'claimed_to_pool') {
        setSignupStatus('deposited');
        localStorage.setItem(`ff_signup_status_${userId}`, 'deposited');
      }

      setClaimedAccruedAFNL(0);
      localStorage.setItem(`ff_claimed_accrued_${userId}`, '0');

      // Record in Universal Ledger
      const totalAmountUSD = totalClaimableAFNL * 28.75;
      const isSignup = signupStatus === 'claimed_to_pool';
      const ledgerItem = createLedgerItemFromGrantClaim({
        grantName: isSignup ? 'One-Time Sovereign Signup Grant' : 'Sovereign Community Subsidy Accrual',
        amountAFNL: totalClaimableAFNL,
        amountUSD: totalAmountUSD,
        isSignup
      });
      recordLedgerTransaction(userId, ledgerItem);

      showToast(`Successfully deposited AFNL into your Final Wallet!`);
    } catch (err) {
      console.warn('Failed to deposit AFNL to wallet', err);
      showToast('Error depositing AFNL to Final Wallet.');
    }
  };

  const afnlCoin = walletData.finalCoins.find(c => c.symbol === 'AFNL') || {
    balance: 0,
    unitPriceUSD: 28.75
  };

  // Grant Requests state
  const [grantRequests, setGrantRequests] = useState<Array<{
    id: string;
    name: string;
    description: string;
    amountAFNL: number;
    status: 'Pending' | 'Approved' | 'Cancelled';
    date: string;
    mediaAttachments?: Array<{ type: 'image' | 'video'; url: string; name: string }>;
  }>>(() => {
    try {
      const saved = localStorage.getItem(`ff_grant_requests_${userId}`);
      return saved ? JSON.parse(saved) : [
        {
          id: 'req-1',
          name: 'Greenfield Node Subsidy',
          description: 'Sovereign validator node expansion and community liquidity support.',
          amountAFNL: 15000,
          status: 'Approved',
          date: '2026-08-20',
          mediaAttachments: [
            { type: 'image', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80', name: 'validator_architecture.png' }
          ]
        }
      ];
    } catch {
      return [];
    }
  });

  const [reqName, setReqName] = useState('');
  const [reqDesc, setReqDesc] = useState('');
  const [reqAmount, setReqAmount] = useState('');
  const [reqMedia, setReqMedia] = useState<Array<{ type: 'image' | 'video'; url: string; name: string }>>([]);
  const [requestFilter, setRequestFilter] = useState<'All' | 'Pending' | 'Approved' | 'Cancelled'>('All');

  const handleCancelRequest = (id: string) => {
    const updated = grantRequests.map(req => req.id === id ? { ...req, status: 'Cancelled' as const } : req);
    setGrantRequests(updated);
    localStorage.setItem(`ff_grant_requests_${userId}`, JSON.stringify(updated));
    showToast('Grant request cancelled successfully.');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const newItems: Array<{ type: 'image' | 'video'; url: string; name: string }> = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isVideo = file.type.startsWith('video/');
      const url = URL.createObjectURL(file);
      newItems.push({
        type: isVideo ? 'video' : 'image',
        url,
        name: file.name
      });
    }
    setReqMedia([...reqMedia, ...newItems]);
    showToast(`Attached ${newItems.length} media file(s).`);
  };

  const handleAddSampleMedia = (type: 'image' | 'video') => {
    if (type === 'image') {
      setReqMedia([
        ...reqMedia,
        {
          type: 'image',
          url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=600&auto=format&fit=crop&q=80',
          name: 'project_blueprint_preview.png'
        }
      ]);
    } else {
      setReqMedia([
        ...reqMedia,
        {
          type: 'video',
          url: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-and-numbers-31936-large.mp4',
          name: 'node_demo_walkthrough.mp4'
        }
      ]);
    }
    showToast(`Added sample ${type} attachment.`);
  };

  const handleRemoveMedia = (index: number) => {
    setReqMedia(reqMedia.filter((_, i) => i !== index));
  };

  const handleSendGrantRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isVerified) {
      showToast('You must be verified with ID in Settings before submitting grant requests to admin.');
      return;
    }
    if (!reqName.trim() || !reqDesc.trim() || !reqAmount) {
      showToast('Please provide grant name, description, and requested AFNL amount.');
      return;
    }
    const amountNum = parseFloat(reqAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      showToast('Please enter a valid positive number for Final Admin Coins (AFNL).');
      return;
    }

    const newReq = {
      id: 'req-' + Date.now(),
      name: reqName.trim(),
      description: reqDesc.trim(),
      amountAFNL: amountNum,
      status: 'Pending' as const,
      date: new Date().toISOString().split('T')[0],
      mediaAttachments: reqMedia.length > 0 ? reqMedia : undefined
    };

    const updated = [newReq, ...grantRequests];
    setGrantRequests(updated);
    localStorage.setItem(`ff_grant_requests_${userId}`, JSON.stringify(updated));

    showToast(`Successfully sent grant request for ${amountNum.toLocaleString()} AFNL with ${reqMedia.length} attachment(s) to Admin!`);
    setReqName('');
    setReqDesc('');
    setReqAmount('');
    setReqMedia([]);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 text-left">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-3 text-xs font-medium animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Horizontal Sub-Tabs: UBI | Grants & Subsidies | Internal Banking */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveSubTab('ubi')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'ubi'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>UBI</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('grants')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'grants'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Grants &amp; Subsidies</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('banking')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'banking'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Internal Banking</span>
        </button>
      </div>

      {/* Top Header & Horizontal Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200/80 flex items-center justify-center shadow-xs">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-serif font-bold text-slate-900 text-2xl">
              {activeSubTab === 'ubi' ? 'UBI (Universal Basic Income)' : activeSubTab === 'grants' ? 'Grants & Subsidies' : 'Internal Banking'}
            </h1>
            <p className="text-xs text-slate-500">
              {activeSubTab === 'ubi'
                ? '4,000 AFNL one-time signup grant + 0.1 AFNL accrued every 1 minute (~4,000 AFNL per month).'
                : activeSubTab === 'grants'
                ? 'Protocol-backed grants, trade subsidies, and public ecosystem allocations.'
                : 'Manage connected bank accounts, instant FedNow wire settlements, and institutional credit lines.'}
            </p>
          </div>
        </div>

        {/* Verification Status Pill */}
        <div className={`px-4 py-2 rounded-2xl border text-xs font-semibold flex items-center gap-2 ${
          isVerified 
            ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
            : 'bg-amber-50 text-amber-800 border-amber-200'
        }`}>
          {isVerified ? (
            <>
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Verified with ID</span>
            </>
          ) : (
            <>
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span>ID Verification Required</span>
            </>
          )}
        </div>
      </div>

      {/* Verification Notice Banner if Unverified */}
      {!isVerified && (
        <div className="bg-amber-50 border border-amber-200/90 rounded-3xl p-6 text-amber-900 space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center shrink-0 text-amber-700 mt-0.5">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h2 className="text-sm font-bold text-amber-950">ID Verification Required to Claim Grants &amp; Subsidies</h2>
              <p className="text-xs text-amber-800 leading-relaxed">
                Per sovereign protocol rules, you must provide at least 1 form of identification (Driver&apos;s License, Passport, or National ID) in your account Settings before you can claim your 4,000 AFNL signup grant, accrue 0.1 AFNL per-minute subsidies, or deposit Final Admin Coins into your Final Wallet.
              </p>
            </div>
          </div>
          <div className="pt-1 pl-12">
            <button
              type="button"
              onClick={() => {
                if (onNavigateToSettings) onNavigateToSettings();
              }}
              className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <span>Go to Settings to Verify ID</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Tab 1: UBI View */}
      {activeSubTab === 'ubi' && (
        <div className={`space-y-6 ${!isVerified ? 'opacity-75' : ''}`}>
          {/* 1. Initial 4,000 AFNL Signup Grant Card (One-time) */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider">
                    One-Time Signup Grant
                  </span>
                  <span className="text-[10px] font-mono text-emerald-700 font-medium flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Permanent Welcome Bonus
                  </span>
                </div>
                <h2 className="text-lg font-bold text-slate-900">4,000 Final Admin Coins (AFNL) Signup Grant</h2>
                <p className="text-xs text-slate-500">
                  Exclusive one-time welcome grant upon registration. Claimable once into your deposit pool (requires verified ID).
                </p>
              </div>

              <button
                type="button"
                disabled={!isVerified || signupStatus === 'deposited' || signupStatus === 'claimed_to_pool'}
                onClick={handleClaimSignupGrant}
                className={`px-6 py-3 rounded-2xl font-bold text-xs transition-all flex items-center gap-2 shadow-sm shrink-0 ${
                  !isVerified
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : signupStatus === 'deposited'
                    ? 'bg-emerald-100 text-emerald-800 cursor-default border border-emerald-200'
                    : signupStatus === 'claimed_to_pool'
                    ? 'bg-blue-100 text-blue-800 cursor-default border border-blue-200'
                    : 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-amber-600/20'
                }`}
              >
                {signupStatus === 'deposited' ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-700" />
                    <span>Already Deposited</span>
                  </>
                ) : signupStatus === 'claimed_to_pool' ? (
                  <>
                    <Check className="w-4 h-4 text-blue-700" />
                    <span>In Deposit Pool</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 text-amber-200" />
                    <span>Claim 4,000 AFNL Grant</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 2. Continuous Per-Minute Accrual Stream */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-blue-100 text-blue-900 uppercase tracking-wider">
                    Continuous Accrual
                  </span>
                  <span className="text-[10px] font-mono font-medium text-slate-500">{accrualRate} AFNL / Minute</span>
                </div>
                <h2 className="text-lg font-bold text-slate-900">Per-Minute Active UBI Stream</h2>
                <p className="text-xs text-slate-500">
                  Accrues {accrualRate} Final Admin Coin every completed minute based on your registered profile gender. Requires verified ID.
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-medium text-slate-600">
                <span>Next {accrualRate} AFNL Unit Unlock in {secondsRemaining}s</span>
                <span className="font-mono">{Math.round(((60 - secondsRemaining) / 60) * 100)}%</span>
              </div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200/60">
                <div 
                  className="bg-amber-500 h-full rounded-full transition-all duration-1000"
                  style={{ width: `${((60 - secondsRemaining) / 60) * 100}%` }}
                />
              </div>
            </div>

            {/* Accrued Status Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-50/50 to-slate-50 border border-amber-200/60 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="space-y-1 text-center sm:text-left">
                <div className="text-xs text-amber-900 font-medium">Unclaimed Accrued UBI</div>
                <div className="text-2xl font-serif font-bold text-slate-900">
                  +{unclaimedAccruedAFNL.toFixed(2)} <span className="text-xs font-mono font-bold text-amber-700">AFNL</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Accumulates {accrualRate} AFNL every minute. Click claim to add to your deposit pool.
                </p>
              </div>

              <button
                type="button"
                disabled={!isVerified || unclaimedAccruedAFNL <= 0}
                onClick={handleClaimAccrued}
                className={`px-6 py-3 rounded-2xl font-bold text-xs transition-all flex items-center gap-2 shadow-sm ${
                  !isVerified
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : unclaimedAccruedAFNL > 0
                    ? 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-amber-600/20'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>{unclaimedAccruedAFNL > 0 ? `Claim +${unclaimedAccruedAFNL.toFixed(2)} AFNL to Pool` : 'Accumulating...'}</span>
              </button>
            </div>
          </div>

          {/* 3. Final Wallet Deposit Section */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 text-slate-900 space-y-6 shadow-sm">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 border border-amber-500/20 flex items-center justify-center">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">Final Wallet Deposit Vault</h3>
                  <p className="text-xs text-slate-500">Transfer claimed UBI grants &amp; subsidies directly into your sovereign Final Wallet</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-500/20 text-xs font-mono font-bold">
                Ready to Deposit
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="text-[11px] font-mono text-slate-500 uppercase tracking-wider">Total Claimable Deposit Pool</div>
                <div className="text-3xl font-mono font-bold text-amber-600">
                  {totalClaimableAFNL.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 })} <span className="text-xs font-normal text-slate-500">AFNL</span>
                </div>
                <p className="text-[11px] text-slate-500 pt-1">
                  ({signupStatus === 'deposited' ? '4,000 grant already deposited' : signupStatus === 'claimed_to_pool' ? '4,000 grant in pool' : '4,000 one-time grant unclaimed'} + {claimedAccruedAFNL.toFixed(1)} claimed accrued)
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="text-[11px] font-mono text-slate-500 uppercase tracking-wider">Current Final Wallet Balance</div>
                <div className="text-3xl font-mono font-bold text-slate-900">
                  {typeof afnlCoin.balance === 'number' ? afnlCoin.balance.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 }) : '0.0'} <span className="text-xs font-normal text-slate-500">AFNL</span>
                </div>
                <p className="text-[11px] text-emerald-600 pt-1 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Synchronized with Final Wallet
                </p>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                {isVerified ? 'Depositing credits AFNL instantly to your protocol wallet.' : 'ID verification required before deposit.'}
              </span>
              <button
                type="button"
                disabled={!isVerified || totalClaimableAFNL <= 0}
                onClick={handleDepositToFinalWallet}
                className={`px-8 py-3.5 rounded-2xl font-bold text-xs transition-all flex items-center gap-2 shadow-sm ${
                  !isVerified
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-200'
                    : totalClaimableAFNL > 0
                    ? 'bg-amber-500 hover:bg-amber-600 text-white cursor-pointer shadow-amber-500/20'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-200'
                }`}
              >
                <ArrowDownLeft className="w-4 h-4" />
                <span>Deposit {totalClaimableAFNL > 0 ? `${totalClaimableAFNL.toFixed(1)} ` : ''}AFNL to Final Wallet</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Grants & Subsidies View */}
      {activeSubTab === 'grants' && (
        <div className="space-y-6 animate-fade-in">
          {/* Request Grant from Admin Card */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider">
                  Admin Request Portal
                </span>
                <h2 className="text-lg font-bold text-slate-900">Request Custom Grant or Subsidy from Admin</h2>
                <p className="text-xs text-slate-500">
                  Submit a formal sovereign grant or subsidy request to the protocol administrator. Requests can only be requested in Final Admin Coins (AFNL).
                </p>
              </div>
            </div>

            <form onSubmit={handleSendGrantRequest} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Grant / Subsidy Name</label>
                  <input
                    type="text"
                    value={reqName}
                    onChange={(e) => setReqName(e.target.value)}
                    placeholder="e.g. Regional Clean Energy Subsidy"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-slate-50/50"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Requested Amount (Final Admin Coins - AFNL Only)</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="any"
                      value={reqAmount}
                      onChange={(e) => setReqAmount(e.target.value)}
                      placeholder="e.g. 10000"
                      className="w-full pl-4 pr-16 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-slate-50/50 font-mono"
                    />
                    <span className="absolute right-3 top-2.5 text-xs font-mono font-bold text-amber-700">AFNL</span>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Description &amp; Purpose</label>
                <textarea
                  rows={3}
                  value={reqDesc}
                  onChange={(e) => setReqDesc(e.target.value)}
                  placeholder="Describe the objective, community impact, or node deployment for this grant..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-slate-50/50 resize-none"
                />
              </div>

              {/* Photo & Video Attachments Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Upload className="w-3.5 h-3.5 text-amber-600" />
                    <span>Attach Photos &amp; Videos (Proof of work, blueprint, demo)</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleAddSampleMedia('image')}
                      className="text-[10px] text-amber-700 hover:text-amber-800 font-semibold underline cursor-pointer"
                    >
                      + Sample Photo
                    </button>
                    <span className="text-slate-300">|</span>
                    <button
                      type="button"
                      onClick={() => handleAddSampleMedia('video')}
                      className="text-[10px] text-amber-700 hover:text-amber-800 font-semibold underline cursor-pointer"
                    >
                      + Sample Video
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <label className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-dashed border-slate-300 hover:border-amber-500 bg-slate-50/50 hover:bg-amber-50/30 transition-all cursor-pointer text-xs font-medium text-slate-600">
                    <Upload className="w-4 h-4 text-slate-400" />
                    <span>Upload local photos or videos...</span>
                    <input
                      type="file"
                      accept="image/*,video/*"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {reqMedia.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2">
                    {reqMedia.map((m, idx) => (
                      <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-video flex items-center justify-center">
                        {m.type === 'image' ? (
                          <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-slate-900 flex items-center justify-center text-white relative">
                            <Video className="w-6 h-6 text-amber-400" />
                            <span className="absolute bottom-1 left-1 text-[9px] bg-black/60 px-1 rounded truncate max-w-[90%]">{m.name}</span>
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRemoveMedia(idx)}
                          className="absolute top-1 right-1 w-6 h-6 rounded-full bg-slate-900/80 hover:bg-rose-600 text-white flex items-center justify-center text-xs transition-all shadow"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  {isVerified ? 'Request goes directly to protocol administrator review.' : 'ID verification required to submit requests.'}
                </span>
                <button
                  type="submit"
                  disabled={!isVerified}
                  className={`px-6 py-3 rounded-xl font-bold text-xs transition-all flex items-center gap-2 shadow-sm ${
                    !isVerified
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-amber-600/20'
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  <span>Send Request to Admin</span>
                </button>
              </div>
            </form>
          </div>

          {/* Submitted Grant Requests List */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-blue-100 text-blue-900 uppercase tracking-wider">
                  Submitted Requests
                </span>
                <h2 className="text-lg font-bold text-slate-900">Your Admin Grant Requests</h2>
                <p className="text-xs text-slate-500">
                  History of subsidy and grant requests submitted to protocol administration.
                </p>
              </div>

              {/* Status Filter Tabs */}
              <div className="flex flex-nowrap items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold overflow-x-auto max-w-full">
                {(['All', 'Pending', 'Approved', 'Cancelled'] as const).map((tab) => (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setRequestFilter(tab)}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                      requestFilter === tab
                        ? 'bg-white text-slate-900 shadow-2xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {grantRequests.filter(r => requestFilter === 'All' || r.status === requestFilter).length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                No {requestFilter !== 'All' ? requestFilter.toLowerCase() : ''} grant or subsidy requests found.
              </div>
            ) : (
              <div className="space-y-3">
                {grantRequests
                  .filter(req => requestFilter === 'All' || req.status === requestFilter)
                  .map((req) => (
                  <div key={req.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900">{req.name}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          req.status === 'Approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : req.status === 'Cancelled'
                            ? 'bg-slate-200 text-slate-700'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {req.status}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">{req.date}</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">{req.description}</p>
                      {req.mediaAttachments && req.mediaAttachments.length > 0 && (
                        <div className="flex items-center gap-2 pt-2 flex-wrap">
                          {req.mediaAttachments.map((m, mIdx) => (
                            <div key={mIdx} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-[11px] font-medium text-slate-700 shadow-2xs">
                              {m.type === 'image' ? (
                                <Image className="w-3.5 h-3.5 text-amber-600" />
                              ) : (
                                <Video className="w-3.5 h-3.5 text-blue-600" />
                              )}
                              <span className="truncate max-w-[120px]">{m.name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-4 shrink-0 justify-between sm:justify-end">
                      <div className="text-right">
                        <div className="text-sm font-mono font-bold text-amber-700">
                          {req.amountAFNL.toLocaleString()} AFNL
                        </div>
                        <div className="text-[10px] text-slate-400">Final Admin Coins</div>
                      </div>
                      {req.status === 'Pending' && (
                        <button
                          type="button"
                          onClick={() => handleCancelRequest(req.id)}
                          className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-rose-100 text-slate-700 hover:text-rose-700 text-xs font-bold transition-all cursor-pointer"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Internal Banking View */}
      {activeSubTab === 'banking' && (
        <div className="space-y-6 animate-fade-in">



            {/* Clearing Bank License & Final Coin Loan Desk */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/80 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-amber-200/60">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-500 text-slate-950 uppercase tracking-wider">
                      Clearing Bank Status
                    </span>
                    {bankAppStatus === 'approved' && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        ✅ Approved Bank License
                      </span>
                    )}
                    {bankAppStatus === 'pending' && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                        ⏳ Pending Admin Review
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-bold text-slate-900">Inter-Bank Final Coin Lending Institution</h3>
                  <p className="text-xs text-slate-600">
                    {bankAppStatus === 'approved'
                      ? 'You are an approved Clearing Bank. You are authorized to issue and loan your Final Coins (AFNL) to other users.'
                      : bankAppStatus === 'pending'
                      ? 'Your application to become an approved Clearing Bank is currently under review by Admin.'
                      : 'Request Admin approval to operate as an approved Clearing Bank and loan your final coins to other users.'}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {bankAppStatus === 'none' && (
                    <button
                      type="button"
                      onClick={() => setBankModalOpen(true)}
                      className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
                    >
                      Apply to Become a Bank
                    </button>
                  )}
                  {bankAppStatus === 'pending' && (
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-amber-800 bg-amber-100 px-3 py-2 rounded-xl">Review Pending</span>
                      <button
                        type="button"
                        onClick={handleCancelBankApp}
                        className="px-3 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                      {isAdmin && (
                        <button
                          type="button"
                          onClick={() => {
                            setBankAppStatus('approved');
                            localStorage.setItem(`ff_bank_app_status_${userId}`, 'approved');
                            showToast('Admin approved your Clearing Bank license!');
                          }}
                          className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all cursor-pointer"
                          title="Instant Admin Approve for Demo"
                        >
                          ⚙️ Approve Bank (Admin)
                        </button>
                      )}
                    </div>
                  )}
                  {bankAppStatus === 'approved' && (
                    <button
                      type="button"
                      onClick={() => setLoanModalOpen(true)}
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-2 cursor-pointer"
                    >
                      <Coins className="w-4 h-4" />
                      Issue Final Coin Loan
                    </button>
                  )}
                </div>
              </div>

              {/* Loan Desk Details if Approved */}
              {bankAppStatus === 'approved' && (
                <div className="space-y-4 pt-2">
                  <div className="flex p-1 bg-slate-100 rounded-2xl w-full">
                    <button
                      onClick={() => setActiveLoanTab('issued')}
                      className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                        activeLoanTab === 'issued'
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      Loans Issued ({loansIssued.length})
                    </button>
                    <button
                      onClick={() => setActiveLoanTab('received')}
                      className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                        activeLoanTab === 'received'
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      Loans Received ({loansReceived.length})
                    </button>
                  </div>

                  {activeLoanTab === 'issued' ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-[11px] uppercase tracking-wider text-slate-400">Active Final Coin Loans Issued</h4>
                        <span className="text-[11px] text-slate-500 italic">Earn interest on sovereign lending</span>
                      </div>

                      {loansIssued.length === 0 ? (
                        <div className="p-8 text-center bg-white/70 rounded-2xl border border-amber-200/50 text-slate-500 text-xs italic">
                          No active loans issued yet.
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {loansIssued.map(loan => {
                            const dueDateMs = loan.issuedAtMs + (loan.termDays * 24 * 60 * 60 * 1000);
                            const isOverdue = Date.now() > dueDateMs;

                            return (
                              <div key={loan.id} className="p-4 rounded-2xl bg-white border border-amber-200/60 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                                <div className="space-y-1">
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono font-bold text-slate-900 text-sm">
                                      {loan.amount.toLocaleString()} {loan.coinSymbol}
                                    </span>
                                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                      loan.status === 'active' ? (isOverdue ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800') : loan.status === 'repaid' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                                    }`}>
                                      {loan.status === 'active' && isOverdue ? 'OVERDUE' : loan.status.toUpperCase()}
                                    </span>
                                  </div>
                                  <div className="text-slate-500">
                                    Lent to: <span className="font-semibold text-slate-800">{loan.borrowerHandle}</span> • Rate: <span className="font-mono text-slate-800">{loan.interestRate}%</span> • {loan.termDays}d
                                  </div>
                                </div>
                                
                                <div className="flex items-center gap-2">
                                  <span className="text-[11px] text-slate-400 font-mono">{loan.timestamp}</span>
                                  {loan.status === 'active' && (
                                    <button
                                      type="button"
                                      onClick={() => handleDefaultLoan(loan)}
                                      disabled={!isOverdue}
                                      className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                                        isOverdue 
                                          ? 'bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer' 
                                          : 'bg-slate-50 text-slate-400 cursor-not-allowed opacity-60'
                                      }`}
                                      title={isOverdue ? "Declare Default" : "Loan is not yet due"}
                                    >
                                      {isOverdue ? 'Default' : 'Not Due'}
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-[11px] uppercase tracking-wider text-slate-400">Active Final Coin Loans Received</h4>
                        <span className="text-[11px] text-slate-500 italic">Manage your sovereign debt</span>
                      </div>

                      {loansReceived.length === 0 ? (
                        <div className="p-8 text-center bg-white/70 rounded-2xl border border-amber-200/50 text-slate-500 text-xs italic">
                          No active loans received.
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {loansReceived.map(loan => {
                            const dueDateMs = loan.issuedAtMs + (loan.termDays * 24 * 60 * 60 * 1000);
                            const isOverdue = Date.now() > dueDateMs;

                            return (
                              <div key={loan.id} className="p-4 rounded-2xl bg-white border border-amber-200/60 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                                <div className="space-y-1">
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono font-bold text-slate-900 text-sm">
                                      {loan.amount.toLocaleString()} {loan.coinSymbol}
                                    </span>
                                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                      loan.status === 'active' ? (isOverdue ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800') : loan.status === 'repaid' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                                    }`}>
                                      {loan.status === 'active' && isOverdue ? 'OVERDUE' : loan.status.toUpperCase()}
                                    </span>
                                  </div>
                                  <div className="text-slate-500">
                                    From: <span className="font-semibold text-slate-800">{loan.lenderHandle}</span> • Rate: <span className="font-mono text-slate-800">{loan.interestRate}%</span> • {loan.termDays}d
                                  </div>
                                </div>
                                
                                <div className="flex items-center gap-2">
                                  <span className="text-[11px] text-slate-400 font-mono">{loan.timestamp}</span>
                                  {loan.status === 'active' && (
                                    <button
                                      type="button"
                                      onClick={() => handleRepayLoan(loan)}
                                      className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 font-semibold transition-all cursor-pointer"
                                    >
                                      Repay
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Internal Banking Main Tabs */}
            <div className="flex p-1 bg-slate-100 rounded-2xl w-full">
              <button
                onClick={() => setActiveBankingView('transactions')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  activeBankingView === 'transactions'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Recent Internal Banking Transactions
              </button>
              <button
                onClick={() => setActiveBankingView('portfolio')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  activeBankingView === 'portfolio'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Loan Portfolio Summary
              </button>
            </div>

            {/* Content for Banking Tabs */}
            {activeBankingView === 'transactions' ? (
              <div className="space-y-3 pt-2">
                <h3 className="font-bold text-sm text-slate-900">Recent Transactions</h3>
                <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 text-xs">
                  {allLoans.length === 0 ? (
                    <div className="p-4 text-center text-slate-500">No recent banking transactions.</div>
                  ) : (
                    allLoans.map(loan => (
                      <div key={loan.id} className="p-3.5 flex items-center justify-between bg-slate-50/50">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold ${loan.status === 'active' ? 'bg-amber-100 text-amber-800' : loan.status === 'repaid' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                            {loan.status === 'active' ? 'LN' : loan.status === 'repaid' ? 'IN' : 'DF'}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900">Loan {loan.status === 'active' ? 'Ongoing' : loan.status === 'repaid' ? 'Repaid' : 'Defaulted'}</div>
                            <div className="text-[11px] text-slate-500">To: {loan.borrowerHandle}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono font-bold text-slate-900">{loan.amount.toLocaleString()} {loan.coinSymbol}</div>
                          <div className="text-[10px] text-slate-400">{loan.status}</div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Nested Portfolio Tabs */}
                <div className="flex p-1 bg-slate-100 rounded-2xl w-full">
                  <button
                    onClick={() => { setActivePortfolioTab('ongoing'); setActiveLoanType('given'); }}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                      activePortfolioTab === 'ongoing'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Ongoing Loans
                  </button>
                  <button
                    onClick={() => { setActivePortfolioTab('concluded'); setActiveLoanType('given'); }}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                      activePortfolioTab === 'concluded'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Concluded Loans
                  </button>
                </div>

                {/* Sub-Tabs: Given/Received */}
                <div className="flex p-1 gap-1 w-full">
                  <button
                    onClick={() => setActiveLoanType('given')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                      activeLoanType === 'given'
                        ? 'bg-amber-100 text-amber-900 shadow-sm'
                        : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    Loans Given
                  </button>
                  <button
                    onClick={() => setActiveLoanType('received')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                      activeLoanType === 'received'
                        ? 'bg-sky-100 text-sky-900 shadow-sm'
                        : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    Loans Received
                  </button>
                </div>

                {/* Content for Filtered Loans */}
                <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
                  <h4 className="font-semibold text-sm text-slate-700 capitalize">{activePortfolioTab} Loans {activeLoanType}</h4>
                  {allLoans.filter(l => {
                    const userH = currentUser?.handle || 'user';
                    const matchesStatus = activePortfolioTab === 'ongoing' ? (l.status === 'active' || l.id.includes('active')) : (l.status === 'repaid' || l.status === 'defaulted' || l.id.includes('repaid') || l.id.includes('defaulted') || l.id.includes('default'));
                    const matchesType = activeLoanType === 'given' 
                      ? (l.lenderHandle === userH || l.id.includes('given')) 
                      : (l.borrowerHandle === userH || l.id.includes('rcv'));
                    return matchesStatus && matchesType;
                  }).length === 0 ? <p className="text-xs text-slate-400">No {activePortfolioTab} loans {activeLoanType}.</p> : (
                    <div className="space-y-3">
                      {allLoans.filter(l => {
                        const userH = currentUser?.handle || 'user';
                        const matchesStatus = activePortfolioTab === 'ongoing' ? (l.status === 'active' || l.id.includes('active')) : (l.status === 'repaid' || l.status === 'defaulted' || l.id.includes('repaid') || l.id.includes('defaulted') || l.id.includes('default'));
                        const matchesType = activeLoanType === 'given' 
                          ? (l.lenderHandle === userH || l.id.includes('given')) 
                          : (l.borrowerHandle === userH || l.id.includes('rcv'));
                        return matchesStatus && matchesType;
                      }).map(loan => {
                        const issuedMs = loan.issuedAtMs || Date.now();
                        const termDays = loan.termDays || 30;
                        const dueMs = issuedMs + termDays * 24 * 60 * 60 * 1000;
                        const dueDateObj = new Date(dueMs);
                        const dueDateStr = dueDateObj.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) + ' at ' + dueDateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                        const isGiven = activeLoanType === 'given' || loan.id.includes('given');

                        return (
                          <div key={loan.id} className={`p-4 rounded-2xl border text-xs font-mono ${loan.status === 'active' ? 'bg-amber-50/70 border-amber-200 text-amber-950' : loan.status === 'repaid' ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950' : 'bg-rose-50/70 border-rose-200 text-rose-950'}`}>
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-sm">{(loan.amount || 0).toLocaleString()} {loan.coinSymbol || 'AFNL'}</span>
                              <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-white/90 border border-black/10 shadow-2xs">
                                {loan.status}
                              </span>
                            </div>
                            <div className="mt-3 pt-3 border-t border-black/10 space-y-1.5 text-[11px] opacity-90">
                              <div className="flex justify-between">
                                <span className="font-semibold text-slate-600">{isGiven ? 'Issued To:' : 'Issued From:'}</span>
                                <span className="font-bold">@{isGiven ? (loan.borrowerHandle || 'borrower') : (loan.lenderHandle || 'lender')}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-semibold text-slate-600">Exact Due Date & Time:</span>
                                <span className="font-bold">{dueDateStr}</span>
                              </div>
                              <div className="flex justify-between text-[10px] opacity-75 pt-1">
                                <span>Term: {termDays} Days</span>
                                <span>Issued: {new Date(issuedMs).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
      )}

      {/* Bank Application Modal */}
      {bankModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider">
                  Clearing Institution License
                </span>
                <h3 className="text-lg font-bold text-slate-900">Apply to Become a Clearing Bank</h3>
              </div>
              <button
                type="button"
                onClick={() => setBankModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleApplyForBank} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-700">Institution / Bank Name</label>
                <input
                  type="text"
                  required
                  value={institutionName}
                  onChange={e => setInstitutionName(e.target.value)}
                  placeholder="e.g. Zurich Prime Clearing Bank"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-semibold text-slate-700">Capital Reserves (USD)</label>
                <input
                  type="text"
                  required
                  value={capitalReserves}
                  onChange={e => setCapitalReserves(e.target.value)}
                  placeholder="250,000"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-semibold text-slate-700">Clearing Mandate &amp; Reason</label>
                <textarea
                  rows={3}
                  value={institutionReason}
                  onChange={e => setInstitutionReason(e.target.value)}
                  placeholder="Describe your intended liquidity provisioning and final coin lending operations..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setBankModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer"
                >
                  Submit Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Issue Final Coin Loan Modal */}
      {loanModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider">
                  Inter-Bank Loan Desk
                </span>
                <h3 className="text-lg font-bold text-slate-900">Issue Final Coin Loan</h3>
              </div>
              <button
                type="button"
                onClick={() => setLoanModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleIssueLoan} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-semibold text-slate-700">Borrower Handle / User</label>
                <input
                  type="text"
                  required
                  value={borrowerHandle}
                  onChange={e => setBorrowerHandle(e.target.value)}
                  placeholder="@elena_rostova"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Loan Amount</label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={loanAmount}
                    onChange={e => setLoanAmount(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Coin Asset</label>
                  <select
                    value={loanSymbol}
                    onChange={e => setLoanSymbol(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium bg-white"
                  >
                    <option value="AFNL">AFNL (Final Admin Coin)</option>
                    <option value="USDC">USDC</option>
                    <option value="GOLD">GOLD</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Interest Rate (% APR)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    required
                    value={loanInterest}
                    onChange={e => setLoanInterest(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="font-semibold text-slate-700">Term (Days)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={loanTermDays}
                    onChange={e => setLoanTermDays(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setLoanModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer"
                >
                  Issue Loan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
