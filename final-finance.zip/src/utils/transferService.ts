import { TransactionMode } from '../types/ledger';
import { UserWalletData, FinalCoinItem, StableCoinItem, FiatCurrencyItem, CryptoCurrencyItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { createLedgerItemFromP2PTransfer, recordLedgerTransaction, getStoredLedgerTransactions } from './universalLedgerBridge';
import { UniversalLedgerItem } from '../types/ledger';

export interface TransferCurrencyOption {
  id: string;
  symbol: string;
  name: string;
  mode: TransactionMode;
  categoryLabel: 'Final Coins' | 'Stablecoins' | 'Fiat Currency' | 'Cryptocurrency';
  balance: number;
  unitPriceUSD: number;
  iconBg: string;
  badge: string;
  decimals: number;
}

export interface ExecuteTransferParams {
  senderId: string;
  senderName: string;
  senderHandle?: string;
  recipientId: string;
  recipientName: string;
  recipientHandle?: string;
  coinId: string;
  coinSymbol: string;
  coinName: string;
  mode: TransactionMode;
  amount: number;
  amountUSD: number;
  memo?: string;
}

export interface TransferResult {
  success: boolean;
  error?: string;
  receipt?: UniversalLedgerItem;
  remainingBalance?: number;
}

/**
  * Returns all available transfer currency options with current user balances for all 4 categories.
  */
export function getTransferCurrenciesForUser(userId: string): {
  finalCoins: TransferCurrencyOption[];
  stableCoins: TransferCurrencyOption[];
  fiatCurrencies: TransferCurrencyOption[];
  cryptoCurrencies: TransferCurrencyOption[];
  all: TransferCurrencyOption[];
} {
  const wallet: UserWalletData = getStoredUserWallets(userId);

  const finalCoins: TransferCurrencyOption[] = (wallet.finalCoins || []).map((c: FinalCoinItem) => ({
    id: c.id,
    symbol: c.symbol,
    name: c.name,
    mode: 'final_coin' as TransactionMode,
    categoryLabel: 'Final Coins',
    balance: c.balance,
    unitPriceUSD: 0,
    iconBg: 'bg-amber-500 text-black',
    badge: 'Native Sovereign Asset',
    decimals: 2
  }));

  const stableCoins: TransferCurrencyOption[] = (wallet.stableCoins || []).map((c: StableCoinItem) => ({
    id: c.id,
    symbol: c.symbol,
    name: c.name,
    mode: 'stable_coin' as TransactionMode,
    categoryLabel: 'Stablecoins',
    balance: c.balance,
    unitPriceUSD: c.unitPriceUSD,
    iconBg: 'bg-emerald-600 text-white',
    badge: `${c.peggedCurrency} Pegged • ${c.yieldAPY}% APY`,
    decimals: 2
  }));

  const fiatCurrencies: TransferCurrencyOption[] = (wallet.fiatCurrencies || []).map((c: FiatCurrencyItem) => ({
    id: c.id,
    symbol: c.code,
    name: c.name,
    mode: 'fiat' as TransactionMode,
    categoryLabel: 'Fiat Currency',
    balance: c.balance,
    unitPriceUSD: c.exchangeRateToUSD,
    iconBg: 'bg-sky-600 text-white',
    badge: `${c.accountType} • ${c.institution}`,
    decimals: 2
  }));

  const cryptoCurrencies: TransferCurrencyOption[] = (wallet.cryptoCurrencies || []).map((c: CryptoCurrencyItem) => ({
    id: c.id,
    symbol: c.symbol,
    name: c.name,
    mode: 'crypto' as TransactionMode,
    categoryLabel: 'Cryptocurrency',
    balance: c.balance,
    unitPriceUSD: c.unitPriceUSD,
    iconBg: 'bg-indigo-600 text-white',
    badge: `${c.network}`,
    decimals: 4
  }));

  return {
    finalCoins,
    stableCoins,
    fiatCurrencies,
    cryptoCurrencies,
    all: [...finalCoins, ...stableCoins, ...fiatCurrencies, ...cryptoCurrencies]
  };
}

/**
 * Executes a Peer-to-Peer Transfer:
 * 1. Checks balance in sender's wallet.
 * 2. Deducts from sender's wallet and saves.
 * 3. Credits recipient's wallet and saves.
 * 4. Records transaction in Universal Ledger for both sender and recipient.
 */
export function executePeerTransfer(params: ExecuteTransferParams): TransferResult {
  const {
    senderId,
    senderName,
    senderHandle,
    recipientId,
    recipientName,
    recipientHandle,
    coinSymbol,
    coinName,
    mode,
    amount,
    amountUSD,
    memo
  } = params;

  if (!amount || amount <= 0) {
    return { success: false, error: 'Transfer amount must be greater than 0.' };
  }

  const senderWallet = getStoredUserWallets(senderId);
  let availableBalance = 0;
  let remainingBalance = 0;

  // 1. Deduct from Sender
  if (mode === 'final_coin') {
    const coinIdx = senderWallet.finalCoins.findIndex(c => c.symbol.toLowerCase() === coinSymbol.toLowerCase());
    if (coinIdx === -1) return { success: false, error: `Coin ${coinSymbol} not found in your Final Coins vault.` };
    availableBalance = senderWallet.finalCoins[coinIdx].balance;
    if (availableBalance < amount) {
      return { success: false, error: `Insufficient ${coinSymbol} balance. Available: ${availableBalance.toLocaleString()} ${coinSymbol}` };
    }
    senderWallet.finalCoins[coinIdx].balance -= amount;
    remainingBalance = senderWallet.finalCoins[coinIdx].balance;
  } else if (mode === 'stable_coin') {
    const coinIdx = senderWallet.stableCoins.findIndex(c => c.symbol.toLowerCase() === coinSymbol.toLowerCase());
    if (coinIdx === -1) return { success: false, error: `Stablecoin ${coinSymbol} not found in your wallet.` };
    availableBalance = senderWallet.stableCoins[coinIdx].balance;
    if (availableBalance < amount) {
      return { success: false, error: `Insufficient ${coinSymbol} balance. Available: ${availableBalance.toLocaleString()} ${coinSymbol}` };
    }
    senderWallet.stableCoins[coinIdx].balance -= amount;
    remainingBalance = senderWallet.stableCoins[coinIdx].balance;
  } else if (mode === 'fiat') {
    const fiatIdx = senderWallet.fiatCurrencies.findIndex(c => c.code.toLowerCase() === coinSymbol.toLowerCase());
    if (fiatIdx === -1) return { success: false, error: `Fiat currency ${coinSymbol} not found in your cash vault.` };
    availableBalance = senderWallet.fiatCurrencies[fiatIdx].balance;
    if (availableBalance < amount) {
      return { success: false, error: `Insufficient ${coinSymbol} balance. Available: ${availableBalance.toLocaleString()} ${coinSymbol}` };
    }
    senderWallet.fiatCurrencies[fiatIdx].balance -= amount;
    remainingBalance = senderWallet.fiatCurrencies[fiatIdx].balance;
  } else if (mode === 'crypto') {
    const cryptoIdx = senderWallet.cryptoCurrencies.findIndex(c => c.symbol.toLowerCase() === coinSymbol.toLowerCase());
    if (cryptoIdx === -1) return { success: false, error: `Cryptocurrency ${coinSymbol} not found in your crypto vault.` };
    availableBalance = senderWallet.cryptoCurrencies[cryptoIdx].balance;
    if (availableBalance < amount) {
      return { success: false, error: `Insufficient ${coinSymbol} balance. Available: ${availableBalance.toLocaleString()} ${coinSymbol}` };
    }
    senderWallet.cryptoCurrencies[cryptoIdx].balance -= amount;
    remainingBalance = senderWallet.cryptoCurrencies[cryptoIdx].balance;
  }

  // Save Sender Wallet
  saveStoredUserWallets(senderId, senderWallet);

  // 2. Credit Recipient Wallet
  if (recipientId && recipientId !== senderId) {
    const recipientWallet = getStoredUserWallets(recipientId);
    if (mode === 'final_coin') {
      const rCoinIdx = recipientWallet.finalCoins.findIndex(c => c.symbol.toLowerCase() === coinSymbol.toLowerCase());
      if (rCoinIdx !== -1) {
        recipientWallet.finalCoins[rCoinIdx].balance += amount;
      }
    } else if (mode === 'stable_coin') {
      const rCoinIdx = recipientWallet.stableCoins.findIndex(c => c.symbol.toLowerCase() === coinSymbol.toLowerCase());
      if (rCoinIdx !== -1) {
        recipientWallet.stableCoins[rCoinIdx].balance += amount;
      }
    } else if (mode === 'fiat') {
      const rFiatIdx = recipientWallet.fiatCurrencies.findIndex(c => c.code.toLowerCase() === coinSymbol.toLowerCase());
      if (rFiatIdx !== -1) {
        recipientWallet.fiatCurrencies[rFiatIdx].balance += amount;
      }
    } else if (mode === 'crypto') {
      const rCryptoIdx = recipientWallet.cryptoCurrencies.findIndex(c => c.symbol.toLowerCase() === coinSymbol.toLowerCase());
      if (rCryptoIdx !== -1) {
        recipientWallet.cryptoCurrencies[rCryptoIdx].balance += amount;
      }
    }
    saveStoredUserWallets(recipientId, recipientWallet);
  }

  // 3. Create & Record Universal Ledger Item for Sender
  const senderLedgerItem = createLedgerItemFromP2PTransfer({
    amount,
    amountUSD,
    coinSymbol,
    coinName,
    mode,
    senderUser: { id: senderId, name: senderName, handle: senderHandle },
    recipientUser: { id: recipientId, name: recipientName, handle: recipientHandle },
    memo,
    isSender: true
  });
  recordLedgerTransaction(senderId, senderLedgerItem);

  // 4. Create & Record Universal Ledger Item for Recipient
  if (recipientId && recipientId !== senderId) {
    const recipientLedgerItem = createLedgerItemFromP2PTransfer({
      amount,
      amountUSD,
      coinSymbol,
      coinName,
      mode,
      senderUser: { id: senderId, name: senderName, handle: senderHandle },
      recipientUser: { id: recipientId, name: recipientName, handle: recipientHandle },
      memo,
      isSender: false
    });
    recordLedgerTransaction(recipientId, recipientLedgerItem);
  }

  return {
    success: true,
    receipt: senderLedgerItem,
    remainingBalance
  };
}

export interface ExecuteAdminTransferParams {
  adminId: string;
  adminName: string;
  adminHandle?: string;
  targetUserId: string;
  targetName: string;
  targetHandle?: string;
  action: 'add' | 'deduct';
  coinSymbol: string;
  coinName: string;
  amount: number;
  unitPriceUSD?: number;
  reason?: string;
}

/**
 * Creates a formatted ledger record from an Admin Transfer (System Mint or Burn).
 */
export function createLedgerItemFromAdminTransfer(params: {
  amount: number;
  amountUSD: number;
  coinSymbol: string;
  coinName: string;
  adminUser: { id: string; name: string; handle?: string };
  targetUser: { id: string; name: string; handle?: string };
  action: 'add' | 'deduct';
  reason?: string;
  isForAdminView: boolean;
}): UniversalLedgerItem {
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-ADM-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

  const isAdd = params.action === 'add';
  const targetHandle = params.targetUser.handle || params.targetUser.name;
  
  let title = '';
  let description = '';

  if (params.isForAdminView) {
    title = isAdd
      ? `Admin System Mint: +${params.amount.toLocaleString()} ${params.coinSymbol} -> @${targetHandle}`
      : `Admin System Deduction: -${params.amount.toLocaleString()} ${params.coinSymbol} <- @${targetHandle}`;
    description = isAdd
      ? `System Admin Mint: Issued ${params.amount.toLocaleString()} ${params.coinSymbol} directly to user @${targetHandle}.${params.reason ? ` Note: "${params.reason}"` : ''}`
      : `System Admin Burn: Deducted ${params.amount.toLocaleString()} ${params.coinSymbol} from user @${targetHandle}.${params.reason ? ` Note: "${params.reason}"` : ''}`;
  } else {
    title = isAdd
      ? `Admin Credit Received: +${params.amount.toLocaleString()} ${params.coinSymbol}`
      : `Admin Adjustment Deduction: -${params.amount.toLocaleString()} ${params.coinSymbol}`;
    description = isAdd
      ? `System Protocol Mint: Credited ${params.amount.toLocaleString()} ${params.coinSymbol} to your account balance by Protocol Admin.${params.reason ? ` Note: "${params.reason}"` : ''}`
      : `System Protocol Adjustment: Deducted ${params.amount.toLocaleString()} ${params.coinSymbol} from your account balance by Protocol Admin.${params.reason ? ` Note: "${params.reason}"` : ''}`;
  }

  return {
    id: `rec-adm-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: isAdd ? 'deposit' : 'p2p_transfer',
    category: 'transfer',
    mode: 'final_coin',
    title,
    description,
    amountUSD: params.amountUSD,
    feeUSD: 0.00,
    netAmountUSD: params.amountUSD,
    sourceOrDestination: isAdd ? 'Sovereign Admin System Mint Vault' : 'Sovereign Admin System Burn Reserve',
    counterpartyOrIssuer: params.isForAdminView 
      ? `User @${targetHandle}` 
      : `Protocol Admin Console`,
    paymentCoinSymbol: params.coinSymbol,
    paymentCoinAmount: params.amount,
    taxClassification: {
      formMapping: 'Administrative Adjustment',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Administrative protocol ledger mint / burn transaction.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Admin Console Node #00 (System Mint Gateway)',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-ADM-MINT-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Executes an Admin Transfer (Mint or Burn) into/from a target user's wallet without altering the Admin's balance.
 */
export function executeAdminTransfer(params: ExecuteAdminTransferParams): TransferResult {
  const {
    adminId,
    adminName,
    adminHandle,
    targetUserId,
    targetName,
    targetHandle,
    action,
    coinSymbol,
    coinName,
    amount,
    unitPriceUSD = 0,
    reason
  } = params;

  if (!amount || amount <= 0) {
    return { success: false, error: 'Transfer amount must be greater than 0.' };
  }

  const targetWallet = getStoredUserWallets(targetUserId);
  let updatedBalance = 0;

  // Ensure finalCoins exists
  if (!targetWallet.finalCoins) {
    targetWallet.finalCoins = [];
  }

  let coinIdx = targetWallet.finalCoins.findIndex(
    c => c.symbol.toLowerCase() === coinSymbol.toLowerCase()
  );

  if (coinIdx === -1) {
    const newBal = action === 'add' ? amount : 0;
    targetWallet.finalCoins.push({
      id: `fc-admin-${coinSymbol.toLowerCase()}-${Date.now()}`,
      name: coinName || `${coinSymbol} Sovereign Token`,
      symbol: coinSymbol,
      balance: newBal,
      unitPriceUSD,
      change24h: 3.5,
      utility: 'System Admin mint allocation'
    });
    updatedBalance = newBal;
  } else {
    if (action === 'add') {
      targetWallet.finalCoins[coinIdx].balance += amount;
    } else {
      targetWallet.finalCoins[coinIdx].balance = Math.max(
        0,
        targetWallet.finalCoins[coinIdx].balance - amount
      );
    }
    updatedBalance = targetWallet.finalCoins[coinIdx].balance;
  }

  // Save Target User Wallet
  saveStoredUserWallets(targetUserId, targetWallet);

  const amountUSD = amount * unitPriceUSD;

  // Target User Ledger Record
  const targetLedgerItem = createLedgerItemFromAdminTransfer({
    amount,
    amountUSD,
    coinSymbol,
    coinName,
    adminUser: { id: adminId, name: adminName, handle: adminHandle },
    targetUser: { id: targetUserId, name: targetName, handle: targetHandle },
    action,
    reason,
    isForAdminView: false
  });
  recordLedgerTransaction(targetUserId, targetLedgerItem);

  // Admin View Ledger Record
  const adminLedgerItem = createLedgerItemFromAdminTransfer({
    amount,
    amountUSD,
    coinSymbol,
    coinName,
    adminUser: { id: adminId, name: adminName, handle: adminHandle },
    targetUser: { id: targetUserId, name: targetName, handle: targetHandle },
    action,
    reason,
    isForAdminView: true
  });
  if (adminId && adminId !== targetUserId) {
    recordLedgerTransaction(adminId, adminLedgerItem);
  }

  // Ensure recording in global ledger
  recordLedgerTransaction('global', adminLedgerItem);

  // Dispatch wallet update event for live UI refresh
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('final_finance_wallet_updated'));
  }

  return {
    success: true,
    receipt: adminLedgerItem,
    remainingBalance: updatedBalance
  };
}

/**
 * Returns P2P transfers from the ledger associated with a particular user or between two users.
 */
export function getTransfersBetweenUsers(currentUserId: string, targetUserIdOrHandle?: string): UniversalLedgerItem[] {
  const transactions = getStoredLedgerTransactions(currentUserId);
  const p2pItems = transactions.filter(t => t.type === 'p2p_transfer' || t.category === 'transfer' || t.title.toLowerCase().includes('peer transfer'));
  
  if (!targetUserIdOrHandle) return p2pItems;

  const targetLower = targetUserIdOrHandle.toLowerCase().replace('@', '');
  return p2pItems.filter(t => 
    t.counterpartyOrIssuer.toLowerCase().includes(targetLower) ||
    t.sourceOrDestination.toLowerCase().includes(targetLower) ||
    t.description.toLowerCase().includes(targetLower)
  );
}
