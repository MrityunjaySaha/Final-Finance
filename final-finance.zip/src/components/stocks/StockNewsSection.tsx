import React, { useState } from 'react';
import { StockItem, StockNewsItem } from '../../types/stocks';
import { BREAKING_STOCK_NEWS } from '../../data/stocksData';
import { 
  Newspaper, 
  Clock, 
  ExternalLink, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Sparkles,
  Calendar,
  Award,
  FileText,
  BarChart3,
  Zap,
  ArrowRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

interface StockNewsSectionProps {
  stock: StockItem;
  allNews?: StockNewsItem[];
  onSelectTicker?: (ticker: string) => void;
  onQuickTrade?: (stock: StockItem, side?: 'buy' | 'sell') => void;
}

export const StockNewsSection: React.FC<StockNewsSectionProps> = ({
  stock,
  allNews = BREAKING_STOCK_NEWS,
  onSelectTicker,
  onQuickTrade,
}) => {
  const [activeCategory, setActiveCategory] = useState<'All' | 'Headlines' | 'Filings & Earnings' | 'Analyst Notes' | 'Sector Macro'>('All');

  // Filter news for this specific stock
  const directStockNews = allNews.filter((n) => n.tickers.includes(stock.ticker));
  const sectorRelatedNews = allNews.filter((n) => !n.tickers.includes(stock.ticker) && (
    (stock.sector === 'Technology & AI' && n.category === 'Tech & AI') ||
    (stock.sector === 'Semiconductors' && (n.category === 'Semiconductors' || n.category === 'Tech & AI')) ||
    (stock.sector === 'Gold & Commodities' && n.category === 'Gold & Commodities') ||
    (stock.sector === 'Banking & Finance' && n.category === 'Banking & Macro') ||
    (stock.sector === 'Energy & Aerospace' && n.category === 'Energy & Defense') ||
    (stock.sector === 'ETFs & Indices' && n.category === 'Earnings')
  ));

  // Synthesize tailored stock-specific items if none found
  const combinedNews: StockNewsItem[] = [
    ...directStockNews,
    ...(directStockNews.length === 0 ? [
      {
        id: `news-${stock.ticker}-special-1`,
        title: `${stock.name} (${stock.ticker}) Reports Accelerated Institutional Accumulation & Multi-Quarter Margin Expansion`,
        source: 'Bloomberg Terminal Intelligence',
        time: '24m ago',
        sentiment: 'bullish' as const,
        tickers: [stock.ticker],
        category: 'Earnings' as const,
        impact: 'High Impact' as const,
        keyTakeaway: `Wall street consensus raised price target to $${(stock.analystTargetUSD || stock.price || 0).toFixed(2)} based on strong ${stock.subSector || stock.sector} execution and cash flow generation.`,
        summary: `Institutional block orders and prime brokerage desks reported steady net asset accumulation in ${stock.name}, driven by robust order backlog and disciplined capital allocation.`,
        readTime: '3 min read'
      },
      {
        id: `news-${stock.ticker}-special-2`,
        title: `${stock.ticker} SEC Form 8-K Regulatory Disclosure: Strategic Operations & Executive Update`,
        source: 'SEC EDGAR Wire',
        time: '2h ago',
        sentiment: 'neutral' as const,
        tickers: [stock.ticker],
        category: 'Earnings' as const,
        impact: 'Macro Trend' as const,
        keyTakeaway: 'Corporate filing confirms balance sheet strength, compliant shareholder disclosures, and continued dividend & investment roadmap.',
        summary: `${stock.name} completed quarterly governance disclosures with the Securities and Exchange Commission, reinforcing operational guidance.`,
        readTime: '2 min read'
      }
    ] : []),
    ...sectorRelatedNews
  ];

  // News category filtering
  const filteredArticles = combinedNews.filter((item) => {
    if (activeCategory === 'All') return true;
    if (activeCategory === 'Headlines') return item.impact === 'High Impact';
    if (activeCategory === 'Filings & Earnings') return item.category === 'Earnings' || item.title.includes('SEC') || item.title.includes('Earnings') || item.title.includes('Report');
    if (activeCategory === 'Analyst Notes') return item.title.includes('Target') || item.title.includes('Consensus') || item.title.includes('Analyst') || item.title.includes('Wall Street') || item.sentiment === 'bullish';
    if (activeCategory === 'Sector Macro') return item.category !== 'Earnings';
    return true;
  });

  // Calculate sentiment stats for this ticker
  const tickerMentions = combinedNews.filter(n => n.tickers.includes(stock.ticker));
  const bullishCount = tickerMentions.filter(n => n.sentiment === 'bullish').length;
  const totalCount = Math.max(1, tickerMentions.length);
  const bullishPct = Math.round((bullishCount / totalCount) * 100);

  return (
    <div id="stock-news-section" className="space-y-6">
      {/* 1. Header with Live News Intelligence */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-200 text-xs font-mono font-bold">
                ${stock.ticker} WIRE
              </span>
              <span className="inline-flex items-center gap-1.5 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Live Market Feeds
              </span>
            </div>
            <h3 className="font-serif font-bold text-lg text-slate-900 mt-2 flex items-center gap-2">
              <Newspaper className="w-5 h-5 text-amber-700" />
              <span>Real-Time News &amp; Catalysts for {stock.name} ({stock.ticker})</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Curated financial headlines, earnings conference wires, SEC filings, and Wall Street rating actions.
            </p>
          </div>

          {/* Quick Trade CTA */}
          {onQuickTrade && (
            <button
              type="button"
              onClick={() => onQuickTrade(stock, 'buy')}
              className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs transition-all flex items-center gap-2 shadow-xs cursor-pointer self-start md:self-auto"
            >
              <Zap className="w-4 h-4 fill-white" />
              <span>Instant Trade {stock.ticker}</span>
            </button>
          )}
        </div>

        {/* 2. Key Intelligence Highlights Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-5">
          {/* Card A: Sentiment Gauge */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
              <span>Market News Sentiment</span>
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-bold font-serif text-emerald-700">
              {bullishPct >= 70 ? 'Strong Bullish' : bullishPct >= 50 ? 'Moderately Bullish' : 'Neutral Hold'}
            </div>
            <div className="w-full bg-slate-200 h-2 rounded-full mt-2 overflow-hidden flex">
              <div className="bg-emerald-500 h-full" style={{ width: `${bullishPct}%` }} />
              <div className="bg-slate-300 h-full" style={{ width: `${100 - bullishPct}%` }} />
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">
              {bullishPct}% positive catalyst coverage in last 48 hours
            </p>
          </div>

          {/* Card B: SEC & Earnings Calendar */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
              <span>Next Earnings Release</span>
              <Calendar className="w-4 h-4 text-slate-600" />
            </div>
            <div className="text-xl font-bold font-mono text-slate-900">
              {stock.nextEarningsDate || 'Upcoming Q3 Report'}
            </div>
            <p className="text-xs font-semibold text-slate-600 mt-1">
              Consensus Est: {stock.consensusEps || `$${(stock.eps && stock.eps > 0) ? (stock.eps * 0.28).toFixed(2) : '1.15'}`} EPS
            </p>
            <p className="text-[11px] text-emerald-700 font-semibold mt-0.5">
              {stock.lastQuarterSurprise || '+6.2% Beat last quarter'}
            </p>
          </div>

          {/* Card C: Analyst Action Summary */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-1">
              <span>Analyst 12M Price Target</span>
              <Award className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-xl font-bold font-mono text-slate-900">
              ${(stock.analystTargetUSD || stock.price || 0).toFixed(2)}
            </div>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`text-xs font-bold font-mono ${(stock.analystTargetUSD || stock.price) >= stock.price ? 'text-emerald-600' : 'text-rose-600'}`}>
                {(stock.analystTargetUSD || stock.price) >= stock.price ? '+' : ''}
                {((((stock.analystTargetUSD || stock.price) - stock.price) / (stock.price || 1)) * 100).toFixed(1)}% Upside
              </span>
              <span className="text-xs text-slate-400">• {stock.analystCount || 12} Coverage Firms</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Consensus: <strong className="text-slate-700">{stock.analystRating}</strong>
            </p>
          </div>
        </div>

        {/* 3. Category Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-2 border-b border-slate-100 mb-4">
          {(
            [
              'All',
              'Headlines',
              'Filings & Earnings',
              'Analyst Notes',
              'Sector Macro'
            ] as const
          ).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeCategory === cat
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 4. Article Feed List */}
        <div className="divide-y divide-slate-100">
          {filteredArticles.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No news articles found for this specific filter.
            </div>
          ) : (
            filteredArticles.map((article) => {
              const isBull = article.sentiment === 'bullish';
              const isBear = article.sentiment === 'bearish';

              return (
                <div key={article.id} className="py-4.5 first:pt-0 last:pb-0 group">
                  {/* Article Metadata Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800">{article.source}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{article.time}</span>
                      </span>
                      <span>•</span>
                      <span>{article.readTime}</span>
                    </div>

                    {/* Sentiment & Impact Badges */}
                    <div className="flex items-center gap-1.5">
                      {article.impact && (
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700">
                          {article.impact}
                        </span>
                      )}
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold capitalize ${
                          isBull
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                            : isBear
                            ? 'bg-rose-50 text-rose-700 border border-rose-200/60'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {isBull ? (
                          <TrendingUp className="w-3 h-3 text-emerald-600" />
                        ) : isBear ? (
                          <TrendingDown className="w-3 h-3 text-rose-600" />
                        ) : (
                          <Minus className="w-3 h-3 text-slate-400" />
                        )}
                        <span>{article.sentiment}</span>
                      </span>
                    </div>
                  </div>

                  {/* Headline */}
                  <h4 className="font-serif font-bold text-sm sm:text-base text-slate-900 group-hover:text-amber-800 transition-colors leading-snug">
                    {article.title}
                  </h4>

                  {/* Key Takeaway Highlight Callout */}
                  {article.keyTakeaway && (
                    <div className="mt-2.5 p-3 rounded-2xl bg-amber-50/70 border border-amber-200/60 text-xs text-amber-950 flex items-start gap-2">
                      <Sparkles className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <div className="leading-relaxed">
                        <strong className="font-bold text-amber-900">Key Takeaway: </strong>
                        <span>{article.keyTakeaway}</span>
                      </div>
                    </div>
                  )}

                  {/* Summary Text */}
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-2">
                    {article.summary}
                  </p>

                  {/* Footer with Tickers & Actions */}
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-50">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[11px] text-slate-400 font-semibold">Related Tickers:</span>
                      {article.tickers.map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => onSelectTicker && onSelectTicker(t)}
                          className={`text-xs font-mono font-bold px-2 py-0.5 rounded-lg border transition-colors cursor-pointer ${
                            t === stock.ticker
                              ? 'bg-amber-100 text-amber-900 border-amber-300'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          ${t}
                        </button>
                      ))}
                    </div>

                    {/* Trade / Action Link */}
                    {onQuickTrade && (
                      <button
                        type="button"
                        onClick={() => onQuickTrade(stock, 'buy')}
                        className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <span>Trade ${stock.ticker}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
