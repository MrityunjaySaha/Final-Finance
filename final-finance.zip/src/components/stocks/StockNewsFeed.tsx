import React, { useState } from 'react';
import { StockNewsItem, StockItem } from '../../types/stocks';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Clock, 
  Building2, 
  Sparkles, 
  Flame, 
  ChevronRight,
  ExternalLink,
  Zap,
  Check,
  Share2,
  Bookmark
} from 'lucide-react';

interface StockNewsFeedProps {
  news: StockNewsItem[];
  stocks?: StockItem[];
  ownedTickers?: string[];
  followedTickers?: string[];
  onSelectTicker: (ticker: string) => void;
  onQuickTrade?: (ticker: string) => void;
}

export const StockNewsFeed: React.FC<StockNewsFeedProps> = ({
  news,
  stocks = [],
  ownedTickers = [],
  followedTickers = [],
  onSelectTicker,
  onQuickTrade,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  // Map tickers for live stock prices
  const stockMap = React.useMemo(() => {
    const map = new Map<string, StockItem>();
    stocks.forEach((s) => map.set(s.ticker, s));
    return map;
  }, [stocks]);

  const handleShare = (item: StockNewsItem, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(`${item.title} (${item.source})`);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const filteredNews = React.useMemo(() => {
    if (activeCategory === 'all') return news;
    if (activeCategory === 'saved') return news.filter(n => bookmarkedIds.includes(n.id));
    if (activeCategory === 'bullish') return news.filter(n => n.sentiment === 'bullish');
    if (activeCategory === 'bearish') return news.filter(n => n.sentiment === 'bearish');
    return news.filter(n => (n.category || '').toLowerCase().includes(activeCategory.toLowerCase()));
  }, [news, activeCategory, bookmarkedIds]);

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-4">
      {/* Clean Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
        <div>
          <h3 className="font-serif font-bold text-base sm:text-lg text-slate-900 flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-600" />
            <span>Trending Stock News</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Top market headlines, corporate earnings, and breaking equity catalysts.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Live Wire</span>
          </span>
        </div>
      </div>

      {/* Filter Categories */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'All Trending' },
          { id: 'bullish', label: '🚀 Bullish Catalysts' },
          { id: 'ai', label: 'AI & Chips' },
          { id: 'earnings', label: 'Earnings' },
          { id: 'macro', label: 'Macro & Fed' },
          ...(bookmarkedIds.length > 0 ? [{ id: 'saved', label: `Saved (${bookmarkedIds.length})` }] : [])
        ].map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeCategory === cat.id
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Trending News List */}
      <div className="divide-y divide-slate-100">
        {filteredNews.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            No stories match this filter.
          </div>
        ) : (
          filteredNews.map((item) => {
          const isBull = item.sentiment === 'bullish';
          const isBear = item.sentiment === 'bearish';
          const isBookmarked = bookmarkedIds.includes(item.id);
          const isExpanded = expandedId === item.id;

          return (
            <div
              key={item.id}
              onClick={() => setExpandedId(isExpanded ? null : item.id)}
              className="py-4 first:pt-1 last:pb-1 group cursor-pointer hover:bg-slate-50/70 p-3 rounded-2xl transition-all"
            >
              {/* Metadata Row */}
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 mb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-slate-900 flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-slate-500" />
                    {item.source}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>{item.time}</span>
                  </span>
                  {item.category && (
                    <>
                      <span>•</span>
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium text-[11px]">
                        {item.category}
                      </span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  {item.impact && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-50 text-amber-900 border border-amber-200">
                      <Sparkles className="w-2.5 h-2.5 text-amber-600" />
                      <span>{item.impact}</span>
                    </span>
                  )}

                  <span
                    className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                      isBull
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : isBear
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}
                  >
                    {isBull ? (
                      <TrendingUp className="w-2.5 h-2.5 text-emerald-600" />
                    ) : isBear ? (
                      <TrendingDown className="w-2.5 h-2.5 text-rose-600" />
                    ) : (
                      <Minus className="w-2.5 h-2.5 text-slate-500" />
                    )}
                    {item.sentiment}
                  </span>

                  <button
                    type="button"
                    onClick={(e) => toggleBookmark(item.id, e)}
                    className={`p-1 rounded-md text-slate-400 hover:text-amber-600 hover:bg-slate-100 transition-colors ${
                      isBookmarked ? 'text-amber-600' : ''
                    }`}
                    title={isBookmarked ? 'Saved' : 'Bookmark story'}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-current' : ''}`} />
                  </button>

                  <button
                    type="button"
                    onClick={(e) => handleShare(item, e)}
                    className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                    title="Copy headline"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Share2 className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Title / Headline */}
              <h4 className="text-sm sm:text-base font-serif font-bold text-slate-900 group-hover:text-amber-800 transition-colors leading-snug">
                {item.title}
              </h4>

              {/* Summary */}
              <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
                {item.summary}
              </p>

              {/* Key Takeaway */}
              {item.keyTakeaway && (
                <div className="mt-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70 text-xs text-slate-700 flex items-start gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-900">Key Takeaway: </span>
                    <span>{item.keyTakeaway}</span>
                  </div>
                </div>
              )}

              {/* Expanded Full Article Wire Details */}
              {isExpanded && (
                <div className="mt-3.5 p-4 rounded-2xl bg-amber-50/40 border border-amber-200/60 space-y-3 text-xs sm:text-sm text-slate-800 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-amber-200/40 pb-2">
                    <span className="font-bold font-serif text-amber-900 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-600" />
                      <span>Full Institutional Wire &amp; Catalyst Intelligence Report</span>
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">{item.readTime || '3 min read'}</span>
                  </div>

                  <div className="space-y-2 text-slate-700 leading-relaxed font-sans">
                    <p>
                      <strong>Executive Context:</strong> Comprehensive telemetry from premier global exchange custodians and clearing desks indicates sustained institutional positioning across <span className="font-mono font-bold text-slate-900">{item.tickers.join(', ')}</span>. Market makers and primary dealers report heightened block order flow velocity.
                    </p>
                    <p>
                      <strong>Macroeconomic &amp; Sector Impact:</strong> {item.summary} Analysts note that ongoing capital reallocation into sovereign-backed equities and secure commodity vaults reinforces price discovery integrity across multi-tier liquidity venues.
                    </p>
                    <p>
                      <strong>Regulatory &amp; Compliance Audit:</strong> Verified via real-time cryptographic settlement ledgers and SEC EDGAR reporting pipelines. All participating entities maintain compliant Tier-1 solvency ratios.
                    </p>
                  </div>

                  <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 font-medium">
                    <span>Source Verification: {item.source} • Secure Feed ID #{item.id}</span>
                    <span className="text-amber-700 font-bold">Click card again to collapse</span>
                  </div>
                </div>
              )}

              {/* Read More prompt when collapsed */}
              {!isExpanded && (
                <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-amber-700 hover:text-amber-800">
                  <span>✨ Click to read full article &amp; institutional report</span>
                </div>
              )}

              {/* Tickers Row & Navigation */}
              <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2.5 border-t border-slate-100/90">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Tickers:</span>
                  {item.tickers.map((t) => {
                    const isOwned = ownedTickers.includes(t);
                    const isFollowed = followedTickers.includes(t);
                    const stock = stockMap.get(t);

                    return (
                      <button
                        key={t}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTicker(t);
                        }}
                        className={`px-2.5 py-1 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                          isOwned
                            ? 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 border border-emerald-200'
                            : isFollowed
                            ? 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                        }`}
                        title={`View $${t} details`}
                      >
                        <span>${t}</span>
                        {stock && (
                          <span className="text-[10px] font-sans font-normal opacity-75">
                            ${stock.price.toFixed(2)}
                          </span>
                        )}
                        {isOwned && (
                          <span className="text-[9px] font-sans font-bold text-emerald-700 bg-emerald-100 px-1 rounded">
                            Owned
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2">
                  {onQuickTrade && item.tickers.length > 0 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickTrade(item.tickers[0]);
                      }}
                      className="py-1 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
                      title={`Trade $${item.tickers[0]}`}
                    >
                      <Zap className="w-3 h-3" />
                      <span>Trade ${item.tickers[0]}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (item.tickers[0]) {
                        onSelectTicker(item.tickers[0]);
                      }
                    }}
                    className="text-xs font-bold text-slate-500 hover:text-amber-800 flex items-center gap-0.5 cursor-pointer"
                  >
                    <span>View Stock</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        }))}
      </div>
    </div>
  );
};
