import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  RefreshCw,
  ShieldCheck,
  ArrowRightLeft,
  Plus,
  UserCheck,
  Hourglass,
} from 'lucide-react';
import {
  BarterIOU,
  BARTER_IOUS_UPDATED_EVENT,
  confirmBarterIOU,
  createBarterIOU,
  getBarterIOUsForUser,
  getViewerRoleInBarterIOU,
  UserIdentityLike,
} from '../../services/barterIouService';
import { useApp } from '../../context/AppContext';

interface BarterIOUsPanelProps {
  currentUser: UserIdentityLike & { name?: string };
  variant?: 'light' | 'dark';
  allowCreate?: boolean;
  onViewUserProfile?: (userIdOrHandle: string) => void;
}

export const BarterIOUsPanel: React.FC<BarterIOUsPanelProps> = ({
  currentUser,
  variant = 'light',
  allowCreate = true,
  onViewUserProfile,
}) => {
  const { addToast, addNotification } = useApp();
  const [ious, setIous] = useState<BarterIOU[]>(() => getBarterIOUsForUser(currentUser));
  const [filterMode, setFilterMode] = useState<'all' | 'action_needed' | 'confirmed'>('all');
  const [showCreateForm, setShowCreateForm] = useState(false);

  // Quick Direct Barter IOU creation state
  const [counterpartyHandle, setCounterpartyHandle] = useState('');
  const [counterpartyName, setCounterpartyName] = useState('');
  const [exchangeTitle, setExchangeTitle] = useState('');
  const [myObligation, setMyObligation] = useState('');
  const [theirObligation, setTheirObligation] = useState('');
  const [estimatedValueUSD, setEstimatedValueUSD] = useState('');
  const [dueDate, setDueDate] = useState(() => {
    const dt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
    return dt.toISOString().split('T')[0];
  });

  useEffect(() => {
    const sync = () => {
      setIous(getBarterIOUsForUser(currentUser));
    };
    sync();
    window.addEventListener(BARTER_IOUS_UPDATED_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(BARTER_IOUS_UPDATED_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, [currentUser.id, currentUser.uid, currentUser.handle, currentUser.name, currentUser.email]);

  const counts = useMemo(() => {
    let actionNeeded = 0;
    let waitingOther = 0;
    let settled = 0;
    for (const iou of ious) {
      const role = getViewerRoleInBarterIOU(iou, currentUser);
      const userConfirmed =
        role === 'initiator'
          ? iou.initiatorConfirmed
          : role === 'counterparty'
            ? iou.counterpartyConfirmed
            : false;
      if (iou.status === 'confirmed') {
        settled += 1;
      } else if (!userConfirmed && role !== 'observer') {
        actionNeeded += 1;
      } else {
        waitingOther += 1;
      }
    }
    return { actionNeeded, waitingOther, settled, total: ious.length };
  }, [ious, currentUser]);

  const filteredIous = useMemo(() => {
    if (filterMode === 'all') return ious;
    if (filterMode === 'confirmed') return ious.filter((i) => i.status === 'confirmed');
    return ious.filter((i) => {
      if (i.status === 'confirmed') return false;
      const role = getViewerRoleInBarterIOU(i, currentUser);
      if (role === 'initiator') return !i.initiatorConfirmed;
      if (role === 'counterparty') return !i.counterpartyConfirmed;
      return true;
    });
  }, [ious, filterMode, currentUser]);

  const handleConfirmSide = (iou: BarterIOU) => {
    const res = confirmBarterIOU(iou.id, currentUser);
    if (!res.success || !res.iou) {
      addToast({
        title: 'Confirmation Failed',
        message: res.error || 'Could not record your confirmation.',
        type: 'error',
      });
      return;
    }

    const updated = res.iou;
    setIous(getBarterIOUsForUser(currentUser));

    if (updated.status === 'confirmed') {
      addToast({
        title: 'Barter IOU Fully Confirmed & Settled',
        message: `Both parties confirmed ${updated.referenceCode} ("${updated.listingTitle}").`,
        type: 'gold',
      });
      addNotification({
        title: `✅ Barter IOU Settled (${updated.referenceCode})`,
        description: `Both you and your counterparty confirmed "${updated.listingTitle}".`,
        type: 'trade',
        targetTab: 'qrcodes',
        targetId: updated.id,
        amount: updated.estimatedValueUSD,
        currency: 'USD',
      });
    } else {
      addToast({
        title: 'Your Side Confirmed',
        message: `Recorded your confirmation for ${updated.referenceCode}. Waiting on counterparty confirmation.`,
        type: 'success',
      });
    }
  };

  const handleCreateDirectIOU = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanTarget = counterpartyHandle.trim().replace(/^@/, '');
    if (!cleanTarget || !myObligation.trim() || !theirObligation.trim()) {
      addToast({
        title: 'Missing Details',
        message: 'Enter the counterparty handle/ID and what each party is providing.',
        type: 'error',
      });
      return;
    }

    const titleToUse =
      exchangeTitle.trim() ||
      `${myObligation.trim().slice(0, 32)} ↔ ${theirObligation.trim().slice(0, 32)}`;

    const created = createBarterIOU({
      source: 'direct',
      listingTitle: titleToUse,
      estimatedValueUSD: Number(estimatedValueUSD) || 0,
      dueDate,
      initiator: {
        id: currentUser.id || currentUser.uid || 'member',
        uid: currentUser.uid,
        handle: currentUser.handle || currentUser.id || 'member',
        name: currentUser.name || 'Member',
        obligationDescription: myObligation.trim(),
      },
      counterparty: {
        id: cleanTarget,
        uid: cleanTarget.startsWith('user-') ? cleanTarget : `user-${cleanTarget}`,
        handle: cleanTarget,
        name: counterpartyName.trim() || `@${cleanTarget}`,
        obligationDescription: theirObligation.trim(),
      },
    });

    setIous(getBarterIOUsForUser(currentUser));
    setShowCreateForm(false);
    setCounterpartyHandle('');
    setCounterpartyName('');
    setExchangeTitle('');
    setMyObligation('');
    setTheirObligation('');
    setEstimatedValueUSD('');

    addToast({
      title: `Mutual Barter IOU Created (${created.referenceCode})`,
      message: `Issued to both you and ${created.counterparty.name} for tracking and confirmation.`,
      type: 'gold',
    });
  };

  const isDark = variant === 'dark';

  return (
    <div
      className={`rounded-3xl border p-4 sm:p-6 space-y-5 text-center ${
        isDark
          ? 'bg-neutral-900 border-amber-500/30 text-white'
          : 'bg-white border-slate-200 text-slate-900 shadow-xs'
      }`}
    >
      {/* Header */}
      <div className="flex flex-col items-center justify-center gap-3 text-center">
        <div className="space-y-1 flex flex-col items-center text-center">
          <h3
            className={`text-base font-bold flex items-center justify-center gap-2 text-center ${
              isDark ? 'text-white font-serif' : 'text-slate-900'
            }`}
          >
            <ArrowRightLeft className={`w-4 h-4 shrink-0 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
            <span>Mutual Barter IOUs &amp; Confirmations</span>
          </h3>
          <p className={`text-xs max-w-xl mx-auto text-center ${isDark ? 'text-neutral-400' : 'text-slate-500'}`}>
            Automatically issued to both parties whenever a barter is chosen. Each party tracks obligations and confirms fulfillment.
          </p>
        </div>

        <div className="flex items-center justify-center gap-2 flex-wrap">
          {allowCreate && (
            <button
              type="button"
              onClick={() => setShowCreateForm((v) => !v)}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                isDark
                  ? 'bg-amber-500 hover:bg-amber-400 text-neutral-950'
                  : 'bg-slate-900 hover:bg-slate-800 text-white'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{showCreateForm ? 'Close Form' : 'New Barter IOU'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary Strip */}
      <div className="grid grid-cols-3 gap-2.5 text-center">
        <div
          className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center ${
            isDark ? 'bg-neutral-950 border-neutral-800' : 'bg-amber-50/70 border-amber-200/80'
          }`}
        >
          <p className={`text-[10px] font-mono uppercase ${isDark ? 'text-neutral-400' : 'text-amber-800'}`}>
            Needs Your Confirm
          </p>
          <p className={`text-lg font-black font-mono tabular-nums ${isDark ? 'text-amber-400' : 'text-amber-700'}`}>
            {counts.actionNeeded}
          </p>
        </div>
        <div
          className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center ${
            isDark ? 'bg-neutral-950 border-neutral-800' : 'bg-indigo-50/70 border-indigo-200/80'
          }`}
        >
          <p className={`text-[10px] font-mono uppercase ${isDark ? 'text-neutral-400' : 'text-indigo-800'}`}>
            Awaiting Peer
          </p>
          <p className={`text-lg font-black font-mono tabular-nums ${isDark ? 'text-sky-400' : 'text-indigo-700'}`}>
            {counts.waitingOther}
          </p>
        </div>
        <div
          className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center ${
            isDark ? 'bg-neutral-950 border-neutral-800' : 'bg-emerald-50/70 border-emerald-200/80'
          }`}
        >
          <p className={`text-[10px] font-mono uppercase ${isDark ? 'text-neutral-400' : 'text-emerald-800'}`}>
            Both Confirmed
          </p>
          <p className={`text-lg font-black font-mono tabular-nums ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>
            {counts.settled}
          </p>
        </div>
      </div>

      {/* Quick Create Form */}
      {showCreateForm && (
        <form
          onSubmit={handleCreateDirectIOU}
          className={`p-4 rounded-2xl border space-y-3 ${
            isDark ? 'bg-neutral-950 border-amber-500/40' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <p className={`text-xs font-bold ${isDark ? 'text-amber-300' : 'text-slate-900'}`}>
            Issue Mutual Barter IOU (Sent to Both Parties)
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={`block text-[11px] font-semibold mb-1 ${isDark ? 'text-neutral-300' : 'text-slate-700'}`}>
                Counterparty @Handle / User ID *
              </label>
              <input
                type="text"
                value={counterpartyHandle}
                onChange={(e) => setCounterpartyHandle(e.target.value)}
                placeholder="e.g. @elena_quant or awesomedbz"
                required
                className={`w-full px-3 py-2 rounded-xl border text-xs ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-white placeholder:text-neutral-500'
                    : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'
                }`}
              />
            </div>
            <div>
              <label className={`block text-[11px] font-semibold mb-1 ${isDark ? 'text-neutral-300' : 'text-slate-700'}`}>
                Counterparty Display Name
              </label>
              <input
                type="text"
                value={counterpartyName}
                onChange={(e) => setCounterpartyName(e.target.value)}
                placeholder="e.g. Elena Quant"
                className={`w-full px-3 py-2 rounded-xl border text-xs ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-white placeholder:text-neutral-500'
                    : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'
                }`}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className={`block text-[11px] font-semibold mb-1 ${isDark ? 'text-neutral-300' : 'text-slate-700'}`}>
                What You Provide / Deliver *
              </label>
              <input
                type="text"
                value={myObligation}
                onChange={(e) => setMyObligation(e.target.value)}
                placeholder="e.g. 500g Fine Silver Bar"
                required
                className={`w-full px-3 py-2 rounded-xl border text-xs ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-white placeholder:text-neutral-500'
                    : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'
                }`}
              />
            </div>
            <div>
              <label className={`block text-[11px] font-semibold mb-1 ${isDark ? 'text-neutral-300' : 'text-slate-700'}`}>
                What Counterparty Provides *
              </label>
              <input
                type="text"
                value={theirObligation}
                onChange={(e) => setTheirObligation(e.target.value)}
                placeholder="e.g. 12 Hours Smart Contract Audit"
                required
                className={`w-full px-3 py-2 rounded-xl border text-xs ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-white placeholder:text-neutral-500'
                    : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'
                }`}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className={`block text-[11px] font-semibold mb-1 ${isDark ? 'text-neutral-300' : 'text-slate-700'}`}>
                Swap Title (Optional)
              </label>
              <input
                type="text"
                value={exchangeTitle}
                onChange={(e) => setExchangeTitle(e.target.value)}
                placeholder="e.g. Silver for Audit Retainer"
                className={`w-full px-3 py-2 rounded-xl border text-xs ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-white placeholder:text-neutral-500'
                    : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'
                }`}
              />
            </div>
            <div>
              <label className={`block text-[11px] font-semibold mb-1 ${isDark ? 'text-neutral-300' : 'text-slate-700'}`}>
                Estimated Value ($USD)
              </label>
              <input
                type="number"
                min={0}
                value={estimatedValueUSD}
                onChange={(e) => setEstimatedValueUSD(e.target.value)}
                placeholder="e.g. 1500"
                className={`w-full px-3 py-2 rounded-xl border text-xs font-mono ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-white placeholder:text-neutral-500'
                    : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'
                }`}
              />
            </div>
            <div>
              <label className={`block text-[11px] font-semibold mb-1 ${isDark ? 'text-neutral-300' : 'text-slate-700'}`}>
                Target Completion Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-mono ${
                  isDark
                    ? 'bg-neutral-900 border-neutral-700 text-white'
                    : 'bg-white border-slate-300 text-slate-900'
                }`}
              />
            </div>
          </div>

          <div className="flex justify-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowCreateForm(false)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer ${
                isDark ? 'text-neutral-300 hover:bg-neutral-800' : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer"
            >
              Issue Barter IOU to Both Parties
            </button>
          </div>
        </form>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center justify-center gap-2 flex-wrap">
        {(
          [
            { id: 'all', label: `All Barter IOUs (${counts.total})` },
            { id: 'action_needed', label: `Needs Your Confirmation (${counts.actionNeeded})` },
            { id: 'confirmed', label: `Both Confirmed (${counts.settled})` },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilterMode(tab.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
              filterMode === tab.id
                ? isDark
                  ? 'bg-amber-500 text-neutral-950 border-amber-500 font-bold'
                  : 'bg-slate-900 text-white border-slate-900 font-bold'
                : isDark
                  ? 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* IOU Cards */}
      {filteredIous.length === 0 ? (
        <div
          className={`p-8 rounded-2xl border border-dashed text-center space-y-2 ${
            isDark ? 'bg-neutral-950/60 border-neutral-800' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <Clock className={`w-8 h-8 mx-auto ${isDark ? 'text-neutral-600' : 'text-slate-300'}`} />
          <p className={`text-xs ${isDark ? 'text-neutral-400' : 'text-slate-500'}`}>
            No barter IOUs match this view yet. Any barter trade or accepted barter bid automatically creates a mutual Barter IOU for both parties.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredIous.map((iou) => {
            const viewerRole = getViewerRoleInBarterIOU(iou, currentUser);
            const viewerIsInitiator = viewerRole === 'initiator';
            const viewerParty = viewerIsInitiator ? iou.initiator : iou.counterparty;
            const otherParty = viewerIsInitiator ? iou.counterparty : iou.initiator;
            const viewerConfirmed =
              viewerRole === 'initiator'
                ? iou.initiatorConfirmed
                : viewerRole === 'counterparty'
                  ? iou.counterpartyConfirmed
                  : false;
            const otherConfirmed =
              viewerRole === 'initiator'
                ? iou.counterpartyConfirmed
                : iou.initiatorConfirmed;

            return (
              <div
                key={iou.id}
                className={`p-4 rounded-2xl border space-y-3 transition-all ${
                  iou.status === 'confirmed'
                    ? isDark
                      ? 'bg-emerald-950/20 border-emerald-500/30'
                      : 'bg-emerald-50/40 border-emerald-200'
                    : isDark
                      ? 'bg-neutral-950 border-neutral-800'
                      : 'bg-white border-slate-200 shadow-2xs'
                }`}
              >
                {/* Top Metadata Row */}
                <div className="flex flex-col items-center justify-center gap-2 text-center">
                  <div className="min-w-0 flex flex-col items-center text-center">
                    <div className="flex items-center justify-center gap-2 flex-wrap mb-1.5">
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border ${
                          isDark
                            ? 'bg-neutral-900 border-neutral-700 text-amber-300'
                            : 'bg-slate-100 border-slate-200 text-slate-700'
                        }`}
                      >
                        {iou.referenceCode}
                      </span>
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-lg ${
                          iou.status === 'confirmed'
                            ? isDark
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-emerald-100 text-emerald-800'
                            : !viewerConfirmed && viewerRole !== 'observer'
                              ? isDark
                                ? 'bg-amber-500/20 text-amber-300'
                                : 'bg-amber-100 text-amber-900'
                              : isDark
                                ? 'bg-sky-500/20 text-sky-300'
                                : 'bg-indigo-100 text-indigo-800'
                        }`}
                      >
                        {iou.status === 'confirmed'
                          ? 'Both Confirmed · Settled'
                          : !viewerConfirmed && viewerRole !== 'observer'
                            ? 'Awaiting Your Confirmation'
                            : `Awaiting ${otherParty.name}`}
                      </span>
                      <span className={`text-[10px] font-mono uppercase ${isDark ? 'text-neutral-500' : 'text-slate-400'}`}>
                        {iou.source.replace('_', ' ')}
                      </span>
                    </div>
                    <h4 className={`font-bold text-sm text-center ${isDark ? 'text-white' : 'text-slate-900'}`}>
                      {iou.listingTitle}
                    </h4>
                  </div>

                  <div className="text-center shrink-0">
                    {iou.estimatedValueUSD > 0 && (
                      <p className={`text-sm font-black font-mono tabular-nums ${isDark ? 'text-amber-300' : 'text-amber-700'}`}>
                        ~${iou.estimatedValueUSD.toLocaleString()} USD eq.
                      </p>
                    )}
                    <p className={`text-[11px] font-mono ${isDark ? 'text-neutral-400' : 'text-slate-500'}`}>
                      Due: {iou.dueDate}
                    </p>
                  </div>
                </div>

                {/* Two-Sided Obligations */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-center">
                  <div
                    className={`p-3 rounded-xl border text-center ${
                      isDark ? 'bg-neutral-900/90 border-neutral-800' : 'bg-amber-50/50 border-amber-200/70'
                    }`}
                  >
                    <p className={`text-[10px] font-mono uppercase font-bold mb-1 ${isDark ? 'text-amber-300' : 'text-amber-800'}`}>
                      {viewerRole !== 'observer' ? 'You Provide (Your Barter Obligation)' : `${iou.initiator.name} Provides`}
                    </p>
                    <p className={`text-xs font-semibold ${isDark ? 'text-neutral-100' : 'text-slate-800'}`}>
                      {viewerRole !== 'observer' ? viewerParty.obligationDescription : iou.initiator.obligationDescription}
                    </p>
                    {viewerIsInitiator && iou.sweetenerSummary && (
                      <p className={`text-[11px] font-mono mt-1 ${isDark ? 'text-amber-400' : 'text-amber-700'}`}>
                        Sweetener Included: {iou.sweetenerSummary}
                      </p>
                    )}
                  </div>

                  <div
                    className={`p-3 rounded-xl border text-center ${
                      isDark ? 'bg-neutral-900/90 border-neutral-800' : 'bg-indigo-50/40 border-indigo-200/70'
                    }`}
                  >
                    <p className={`text-[10px] font-mono uppercase font-bold mb-1 ${isDark ? 'text-sky-300' : 'text-indigo-800'}`}>
                      {viewerRole !== 'observer'
                        ? `You Receive (From ${otherParty.name})`
                        : `${iou.counterparty.name} Provides`}
                    </p>
                    <p className={`text-xs font-semibold ${isDark ? 'text-neutral-100' : 'text-slate-800'}`}>
                      {viewerRole !== 'observer' ? otherParty.obligationDescription : iou.counterparty.obligationDescription}
                    </p>
                    {!viewerIsInitiator && iou.sweetenerSummary && (
                      <p className={`text-[11px] font-mono mt-1 ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>
                        + Counterparty Sweetener: {iou.sweetenerSummary}
                      </p>
                    )}
                  </div>
                </div>

                {/* Dual-Party Confirmation Tracker & Action */}
                <div
                  className={`pt-3 border-t flex flex-col items-center justify-center gap-3 text-center ${
                    isDark ? 'border-neutral-800' : 'border-slate-100'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-center gap-2 text-[11px]">
                    {/* Party 1 Status */}
                    <button
                      type="button"
                      onClick={() => onViewUserProfile?.(iou.initiator.handle || iou.initiator.id)}
                      className={`inline-flex items-center justify-center gap-1.5 px-2.5 py-1 rounded-xl border transition-colors ${
                        iou.initiatorConfirmed
                          ? isDark
                            ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                            : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : isDark
                            ? 'bg-neutral-900 border-neutral-700 text-neutral-300'
                            : 'bg-slate-50 border-slate-200 text-slate-600'
                      } ${onViewUserProfile ? 'cursor-pointer hover:opacity-85' : 'cursor-default'}`}
                    >
                      {iou.initiatorConfirmed ? (
                        <UserCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      ) : (
                        <Hourglass className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      )}
                      <span className="font-semibold">
                        {iou.initiator.name}: {iou.initiatorConfirmed ? 'Confirmed' : 'Pending'}
                      </span>
                    </button>

                    {/* Party 2 Status */}
                    <button
                      type="button"
                      onClick={() => onViewUserProfile?.(iou.counterparty.handle || iou.counterparty.id)}
                      className={`inline-flex items-center justify-center gap-1.5 px-2.5 py-1 rounded-xl border transition-colors ${
                        iou.counterpartyConfirmed
                          ? isDark
                            ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                            : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : isDark
                            ? 'bg-neutral-900 border-neutral-700 text-neutral-300'
                            : 'bg-slate-50 border-slate-200 text-slate-600'
                      } ${onViewUserProfile ? 'cursor-pointer hover:opacity-85' : 'cursor-default'}`}
                    >
                      {iou.counterpartyConfirmed ? (
                        <UserCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      ) : (
                        <Hourglass className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      )}
                      <span className="font-semibold">
                        {iou.counterparty.name}: {iou.counterpartyConfirmed ? 'Confirmed' : 'Pending'}
                      </span>
                    </button>
                  </div>

                  {/* Confirmation CTA */}
                  <div className="flex items-center justify-center gap-2 shrink-0">
                    {viewerRole !== 'observer' && !viewerConfirmed ? (
                      <button
                        type="button"
                        onClick={() => handleConfirmSide(iou)}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Confirm My Side</span>
                      </button>
                    ) : iou.status === 'confirmed' ? (
                      <span
                        className={`inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold ${
                          isDark
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Confirmed by Both</span>
                      </span>
                    ) : (
                      <span
                        className={`inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold ${
                          isDark
                            ? 'bg-neutral-800 text-sky-300 border border-neutral-700'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        }`}
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Confirmed by You · Waiting on {otherConfirmed ? 'Settlement' : otherParty.name}</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
