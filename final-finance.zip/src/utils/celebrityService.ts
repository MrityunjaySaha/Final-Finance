export interface CelebrityTrader {
  uid: string;
  name: string;
  handle: string;
  avatarUrl: string;
  title: string;
  verified: boolean;
  winRate: string;
  bio: string;
  category: 'politician' | 'quant' | 'macro' | 'crypto' | 'growth' | 'value' | 'visionary' | 'pioneer';
  focusMarkets: ('fiat' | 'stable' | 'crypto' | 'final')[];
  topTickers: string[];
  followersCount: string;
  congressionalMember?: boolean;
}

export const CELEBRITY_TRADERS: CelebrityTrader[] = [
  {
    uid: 'famous-pelosi',
    name: 'Nancy Pelosi',
    handle: 'pelosi_portfolio',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    title: 'Congressional Disclosures & Tech Allocator',
    verified: true,
    congressionalMember: true,
    winRate: '89.4%',
    bio: 'Periodic Congressional Financial Disclosure Tracker. Known for high-conviction LEAPS call options and mega-cap semiconductor infrastructure allocations.',
    category: 'politician',
    focusMarkets: ['fiat', 'stable', 'crypto', 'final'],
    topTickers: ['NVDA', 'MSFT', 'AAPL', 'PANW', 'TSLA'],
    followersCount: '482.5K'
  },
  {
    uid: 'famous-jim_simons',
    name: 'Jim Simons',
    handle: 'renaissance_tech',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    title: 'Founder, Renaissance Technologies',
    verified: true,
    winRate: '99.1%',
    bio: 'Father of quantitative mathematical trading and the Medallion Fund. Ultra-high-frequency algorithmic statistical arbitrage across liquid equities.',
    category: 'quant',
    focusMarkets: ['fiat', 'crypto'],
    topTickers: ['TSLA', 'NVDA', 'AAPL', 'GOOGL'],
    followersCount: '315.2K'
  },
  {
    uid: 'famous-buffett',
    name: 'Warren Buffett',
    handle: 'oracle_of_omaha',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: 'Chairman & CEO, Berkshire Hathaway',
    verified: true,
    winRate: '94.2%',
    bio: 'Value compounding, durable economic moats, and stable treasury yield accumulation with zero speculative counterparty leverage.',
    category: 'value',
    focusMarkets: ['fiat', 'stable'],
    topTickers: ['AAPL', 'BSYN', 'VLT-YLD', 'OXY'],
    followersCount: '920.4K'
  },
  {
    uid: 'famous-saylor',
    name: 'Michael Saylor',
    handle: 'saylor',
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
    title: 'Executive Chairman, MicroStrategy',
    verified: true,
    winRate: '91.0%',
    bio: 'Institutional digital monetary energy pioneer. Aggressive treasury balance sheet accumulation across decentralized protocol equities.',
    category: 'crypto',
    focusMarkets: ['crypto', 'stable', 'fiat'],
    topTickers: ['MSTR', 'SOLN', 'BTC', 'COIN'],
    followersCount: '640.1K'
  },
  {
    uid: 'famous-cathie',
    name: 'Cathie Wood',
    handle: 'cathie_ark',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    title: 'Founder & CIO, ARK Invest',
    verified: true,
    winRate: '79.2%',
    bio: 'Disruptive innovation, autonomous robotaxis, artificial intelligence compute, and multi-omics genomic technology allocations.',
    category: 'growth',
    focusMarkets: ['fiat', 'crypto', 'stable'],
    topTickers: ['TSLA', 'COIN', 'NVDA', 'ROKU', 'BSYN'],
    followersCount: '512.8K'
  },
  {
    uid: 'famous-ackman',
    name: 'Bill Ackman',
    handle: 'bill_ackman',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    title: 'CEO, Pershing Square Capital',
    verified: true,
    winRate: '87.2%',
    bio: 'Concentrated activist investments in high-free-cash-flow corporate franchises with wide economic barriers to entry.',
    category: 'value',
    focusMarkets: ['fiat'],
    topTickers: ['NVDA', 'GOOGL', 'CMG', 'HLT'],
    followersCount: '298.0K'
  },
  {
    uid: 'famous-dalio',
    name: 'Ray Dalio',
    handle: 'raydalio',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
    title: 'Founder, Bridgewater Associates',
    verified: true,
    winRate: '92.1%',
    bio: 'All-Weather risk-parity macroeconomic frameworks, global debt cycle hedging, and sovereign gold-backed liquidity reserves.',
    category: 'macro',
    focusMarkets: ['fiat', 'stable', 'final'],
    topTickers: ['GLD', 'VLT-YLD', 'HYPR', 'SPY'],
    followersCount: '750.3K'
  },
  {
    uid: 'famous-elon',
    name: 'Elon Musk',
    handle: 'elonmusk',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    title: 'Technoking, Tesla & SpaceX',
    verified: true,
    winRate: '86.5%',
    bio: 'Systems engineering, robotics, humanoid perception compute clusters, and decentralized microgrid infrastructure.',
    category: 'visionary',
    focusMarkets: ['fiat', 'crypto'],
    topTickers: ['TSLA', 'NEXA', 'SOLN'],
    followersCount: '1.4M'
  },
  {
    uid: 'demo-satoshi-nakamoto',
    name: 'Satoshi Nakamoto',
    handle: 'satoshi_nakamoto',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: 'Pioneer of Sovereign Digital Cash',
    verified: true,
    winRate: '98.5%',
    bio: 'Zero-knowledge proofs, peer-to-peer sovereign equity allocations, and cryptographic trustless liquidity settlement.',
    category: 'pioneer',
    focusMarkets: ['final', 'crypto'],
    topTickers: ['ALEX', 'AFNL-EQ', 'QBIT'],
    followersCount: '2.1M'
  }
];

const FAVORITE_CELEBRITIES_KEY = 'final_finance_favorite_celebrities';

/**
 * Retrieve favorite celebrity IDs from localStorage
 */
export function getFavoriteCelebrityIds(): string[] {
  if (typeof window === 'undefined') return ['famous-pelosi', 'famous-jim_simons'];
  try {
    const saved = localStorage.getItem(FAVORITE_CELEBRITIES_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (err) {
    console.warn('Failed to load favorite celebrities', err);
  }
  // Default with Nancy Pelosi and Jim Simons so users immediately have initial favorites
  const defaults = ['famous-pelosi', 'famous-jim_simons'];
  try {
    localStorage.setItem(FAVORITE_CELEBRITIES_KEY, JSON.stringify(defaults));
  } catch {}
  return defaults;
}

/**
 * Check if a celebrity is favorited
 */
export function isCelebrityFavorited(uid: string): boolean {
  const favorites = getFavoriteCelebrityIds();
  return favorites.includes(uid);
}

/**
 * Toggle favorite status of a celebrity
 */
export function toggleFavoriteCelebrity(uid: string): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const current = getFavoriteCelebrityIds();
    let updated: string[];
    let isNowFav: boolean;

    if (current.includes(uid)) {
      updated = current.filter(id => id !== uid);
      isNowFav = false;
    } else {
      updated = [...current, uid];
      isNowFav = true;
    }

    localStorage.setItem(FAVORITE_CELEBRITIES_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent('final_finance_favorite_celebrities_updated', {
      detail: { favorites: updated, toggledUid: uid, isFavorited: isNowFav }
    }));

    return isNowFav;
  } catch (err) {
    console.warn('Failed to toggle favorite celebrity', err);
    return false;
  }
}

/**
 * Search celebrities by name, handle, title, bio, or top tickers
 */
export function searchCelebrities(query: string): CelebrityTrader[] {
  if (!query || !query.trim()) return [];
  const q = query.trim().toLowerCase();
  
  return CELEBRITY_TRADERS.filter(celeb => {
    return (
      celeb.name.toLowerCase().includes(q) ||
      celeb.handle.toLowerCase().includes(q) ||
      celeb.title.toLowerCase().includes(q) ||
      celeb.bio.toLowerCase().includes(q) ||
      celeb.category.toLowerCase().includes(q) ||
      celeb.topTickers.some(ticker => ticker.toLowerCase().includes(q))
    );
  });
}

/**
 * Get full objects of all favorited celebrities
 */
export function getFavoriteCelebrities(): CelebrityTrader[] {
  const favIds = getFavoriteCelebrityIds();
  return CELEBRITY_TRADERS.filter(c => favIds.includes(c.uid));
}
