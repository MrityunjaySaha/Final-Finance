// Crisp built-in vector showcase photos & walkaround videos for sector fleet options

const encodeSvg = (svg: string) =>
  `data:image/svg+xml;utf8,${encodeURIComponent(svg.trim())}`;

const buildExteriorSvg = (opts: {
  kind: 'suv' | 'fastback' | 'limo' | 'rickshaw' | 'moto';
  bgTop: string;
  bgBottom: string;
  accent: string;
  bodyFill: string;
  title: string;
  subtitle: string;
}) => {
  const { kind, bgTop, bgBottom, accent, bodyFill, title, subtitle } = opts;

  let silhouette = '';
  if (kind === 'suv') {
    silhouette = `
      <path d="M90 155 L112 112 Q125 94 155 92 L248 92 Q278 92 296 118 L322 126 Q336 130 338 148 L338 160 L86 160 Z" fill="${bodyFill}" stroke="${accent}" stroke-width="2.5"/>
      <path d="M132 100 L195 98 L195 124 L118 124 Z" fill="#0f172a" opacity="0.88"/>
      <path d="M204 98 L256 98 L280 124 L204 124 Z" fill="#0f172a" opacity="0.88"/>
      <rect x="314" y="133" width="18" height="7" rx="3" fill="#38bdf8"/>
      <rect x="88" y="134" width="12" height="7" rx="2" fill="#f43f5e"/>
      <circle cx="136" cy="160" r="22" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="136" cy="160" r="10" fill="#cbd5e1"/>
      <circle cx="284" cy="160" r="22" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="284" cy="160" r="10" fill="#cbd5e1"/>
    `;
  } else if (kind === 'fastback') {
    silhouette = `
      <path d="M76 156 L104 120 Q138 92 192 92 L246 94 Q282 102 316 128 L342 136 Q350 142 346 158 L76 158 Z" fill="${bodyFill}" stroke="${accent}" stroke-width="2.5"/>
      <path d="M134 102 L196 100 L196 124 L114 124 Z" fill="#09090b" opacity="0.9"/>
      <path d="M204 100 L254 102 L288 124 L204 124 Z" fill="#09090b" opacity="0.9"/>
      <rect x="324" y="138" width="18" height="6" rx="3" fill="#a5b4fc"/>
      <rect x="80" y="136" width="14" height="5" rx="2" fill="#fb7185"/>
      <circle cx="134" cy="159" r="21" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="134" cy="159" r="10" fill="#94a3b8"/>
      <circle cx="290" cy="159" r="21" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="290" cy="159" r="10" fill="#94a3b8"/>
    `;
  } else if (kind === 'limo') {
    silhouette = `
      <path d="M54 156 L78 122 Q108 92 152 92 L268 92 Q298 95 322 124 L356 130 Q368 134 366 158 L54 158 Z" fill="${bodyFill}" stroke="${accent}" stroke-width="2.5"/>
      <path d="M114 100 L176 100 L176 123 L96 123 Z" fill="#020617" opacity="0.95"/>
      <path d="M184 100 L252 100 L252 123 L184 123 Z" fill="#020617" opacity="0.95"/>
      <path d="M260 100 L292 102 L310 123 L260 123 Z" fill="#020617" opacity="0.95"/>
      <line x1="112" y1="138" x2="310" y2="138" stroke="${accent}" stroke-width="1.5" opacity="0.7"/>
      <rect x="342" y="136" width="20" height="7" rx="3" fill="#fde68a"/>
      <circle cx="116" cy="159" r="21" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="116" cy="159" r="10" fill="#e2e8f0"/>
      <circle cx="308" cy="159" r="21" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="308" cy="159" r="10" fill="#e2e8f0"/>
    `;
  } else if (kind === 'rickshaw') {
    silhouette = `
      <path d="M118 156 L118 96 Q120 76 146 76 L236 76 Q268 78 278 106 L296 148 L296 158 L112 158 Z" fill="${bodyFill}" stroke="${accent}" stroke-width="2.5"/>
      <path d="M132 88 L196 88 L196 124 L132 124 Z" fill="#022c22" opacity="0.85"/>
      <path d="M234 86 L266 88 L278 122 L234 122 Z" fill="#0f172a" opacity="0.85"/>
      <rect x="132" y="128" width="64" height="16" rx="4" fill="#10b981" opacity="0.28"/>
      <rect x="286" y="132" width="12" height="9" rx="3" fill="#fef08a"/>
      <circle cx="150" cy="160" r="18" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="150" cy="160" r="8" fill="#a7f3d0"/>
      <circle cx="276" cy="160" r="18" fill="#09090b" stroke="${accent}" stroke-width="3"/>
      <circle cx="276" cy="160" r="8" fill="#a7f3d0"/>
    `;
  } else {
    silhouette = `
      <path d="M115 138 L156 112 L212 106 L248 92 L276 110 L264 132 L216 146 L148 148 Z" fill="${bodyFill}" stroke="${accent}" stroke-width="2.5"/>
      <path d="M148 112 Q178 104 202 114 L182 126 L138 124 Z" fill="#fb7185" opacity="0.85"/>
      <path d="M236 92 L262 84 L274 92 L252 104 Z" fill="#0f172a" opacity="0.9"/>
      <line x1="252" y1="104" x2="290" y2="156" stroke="#cbd5e1" stroke-width="5" stroke-linecap="round"/>
      <circle cx="132" cy="156" r="24" fill="none" stroke="#09090b" stroke-width="9"/>
      <circle cx="132" cy="156" r="20" fill="none" stroke="${accent}" stroke-width="2.5"/>
      <circle cx="132" cy="156" r="7" fill="#cbd5e1"/>
      <circle cx="290" cy="156" r="24" fill="none" stroke="#09090b" stroke-width="9"/>
      <circle cx="290" cy="156" r="20" fill="none" stroke="${accent}" stroke-width="2.5"/>
      <circle cx="290" cy="156" r="7" fill="#cbd5e1"/>
    `;
  }

  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 236">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${bgTop}"/>
          <stop offset="100%" stop-color="${bgBottom}"/>
        </linearGradient>
      </defs>
      <rect width="420" height="236" fill="url(#bg)"/>
      <rect x="0" y="176" width="420" height="60" fill="#09090b" opacity="0.55"/>
      <line x1="24" y1="181" x2="396" y2="181" stroke="${accent}" stroke-width="1.5" stroke-dasharray="8 6" opacity="0.5"/>
      ${silhouette}
      <text x="210" y="34" text-anchor="middle" fill="#ffffff" font-family="system-ui, sans-serif" font-size="14" font-weight="700">${title}</text>
      <text x="210" y="54" text-anchor="middle" fill="${accent}" font-family="monospace" font-size="10" font-weight="700">${subtitle}</text>
      <text x="210" y="214" text-anchor="middle" fill="#cbd5e1" font-family="monospace" font-size="10">EXTERIOR PROFILE · VERIFIED FLEET PHOTO</text>
    </svg>
  `);
};

const buildInteriorSpecsSvg = (opts: {
  bg: string;
  accent: string;
  title: string;
  specsLine1: string;
  specsLine2: string;
}) => {
  const { bg, accent, title, specsLine1, specsLine2 } = opts;
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 236">
      <rect width="420" height="236" fill="${bg}"/>
      <rect x="18" y="18" width="384" height="200" rx="16" fill="#09090b" fill-opacity="0.45" stroke="${accent}" stroke-opacity="0.55" stroke-width="1.5"/>
      <rect x="44" y="64" width="146" height="92" rx="14" fill="#18181b" stroke="${accent}" stroke-width="1.5"/>
      <rect x="230" y="64" width="146" height="92" rx="14" fill="#18181b" stroke="${accent}" stroke-width="1.5"/>
      <circle cx="117" cy="100" r="18" fill="${accent}" fill-opacity="0.18" stroke="${accent}" stroke-width="2"/>
      <path d="M107 100 L114 107 L128 93" fill="none" stroke="${accent}" stroke-width="2.5" stroke-linecap="round"/>
      <text x="117" y="138" text-anchor="middle" fill="#f8fafc" font-family="monospace" font-size="10" font-weight="700">${specsLine1}</text>
      <circle cx="303" cy="100" r="18" fill="${accent}" fill-opacity="0.18" stroke="${accent}" stroke-width="2"/>
      <rect x="293" y="92" width="20" height="16" rx="3" fill="none" stroke="${accent}" stroke-width="2"/>
      <text x="303" y="138" text-anchor="middle" fill="#f8fafc" font-family="monospace" font-size="10" font-weight="700">${specsLine2}</text>
      <text x="210" y="46" text-anchor="middle" fill="#ffffff" font-family="system-ui, sans-serif" font-size="13" font-weight="700">${title}</text>
      <text x="210" y="194" text-anchor="middle" fill="${accent}" font-family="monospace" font-size="10" font-weight="700">CABIN &amp; EQUIPMENT INSPECTION · VERIFIED</text>
    </svg>
  `);
};

export interface DefaultVehicleShowcase {
  photos: string[];
  videos: string[];
  specs: string;
  color: string;
  seats: string;
}

export const DEFAULT_VEHICLE_MEDIA: Record<string, DefaultVehicleShowcase> = {
  'drv-econ-1': {
    color: 'Glacier White',
    seats: '4 Passengers · Climate Control',
    specs: 'Electric SUV · Fast USB-C · Trunk Space (3 Suitcases)',
    photos: [
      buildExteriorSvg({
        kind: 'suv',
        bgTop: '#1e293b',
        bgBottom: '#0f172a',
        accent: '#38bdf8',
        bodyFill: '#f1f5f9',
        title: 'VW ID.4 Pro Electric (2025)',
        subtitle: 'ECONOMY · CAR · PLATE ZH-412-809'
      }),
      buildInteriorSpecsSvg({
        bg: '#0f172a',
        accent: '#38bdf8',
        title: 'VW ID.4 Cabin & Comfort Highlights',
        specsLine1: '4 SEATS · ALL-ELECTRIC',
        specsLine2: '3 BAGS · CLIMATE SYNC'
      })
    ],
    videos: ['/videos/economy-ev.mp4']
  },
  'drv-ev-1': {
    color: 'Magnesium Silver Slate',
    seats: '4 Passengers · Panoramic Glass Roof',
    specs: 'Dual-Motor AWD · Acoustic Cabin · Harman Kardon Audio',
    photos: [
      buildExteriorSvg({
        kind: 'fastback',
        bgTop: '#1e1b4b',
        bgBottom: '#0f172a',
        accent: '#818cf8',
        bodyFill: '#cbd5e1',
        title: 'Polestar 2 Long Range (2025)',
        subtitle: 'COMFORT EV · CAR · PLATE ZH-618-334'
      }),
      buildInteriorSpecsSvg({
        bg: '#1e1b4b',
        accent: '#818cf8',
        title: 'Polestar 2 Executive EV Interior',
        specsLine1: 'PANORAMIC ROOF · AWD',
        specsLine2: 'QUIET CABIN · 3 BAGS'
      })
    ],
    videos: ['/videos/comfort-ev.mp4']
  },
  'drv-lux-1': {
    color: 'Obsidian Black Metallic',
    seats: '3 Rear Lounge Passengers · Executive Chauffeur',
    specs: 'Maybach Rear Reclining Lounge · Privacy Glass · Chilled Refreshments',
    photos: [
      buildExteriorSvg({
        kind: 'limo',
        bgTop: '#18181b',
        bgBottom: '#09090b',
        accent: '#f59e0b',
        bodyFill: '#27272a',
        title: 'Mercedes-Maybach S680 (2025)',
        subtitle: 'LUXURY LIMOUSINE · PLATE ZH-100-777'
      }),
      buildInteriorSpecsSvg({
        bg: '#18181b',
        accent: '#f59e0b',
        title: 'Maybach S680 First-Class Cabin',
        specsLine1: 'LOUNGE SEATS · PRIVACY',
        specsLine2: 'CHAUFFEUR · 4 BAGS'
      })
    ],
    videos: ['/videos/luxury-limo.mp4']
  },
  'drv-rick-1': {
    color: 'Matte Black & Sovereign Emerald',
    seats: '3 Passengers · Open-Air City Cab',
    specs: 'Zero-Emission Electric Three-Wheeler · Nimble Old-Town Access',
    photos: [
      buildExteriorSvg({
        kind: 'rickshaw',
        bgTop: '#064e3b',
        bgBottom: '#022c22',
        accent: '#34d399',
        bodyFill: '#18181b',
        title: 'Bajaj RE Electric Three-Wheeler (2025)',
        subtitle: 'AUTO RICKSHAW · PLATE ZH-R30-218'
      }),
      buildInteriorSpecsSvg({
        bg: '#022c22',
        accent: '#34d399',
        title: 'Electric Auto Rickshaw Seating & Canopy',
        specsLine1: '3 PASSENGERS · CANOPY',
        specsLine2: 'CITY EXPRESS · ZERO CO2'
      })
    ],
    videos: ['/videos/auto-rickshaw.mp4']
  },
  'drv-moto-1': {
    color: 'Graphite Black & Crimson Trim',
    seats: '1 Pillion Passenger · Helmet Included',
    specs: 'High-Torque Electric Moto · Extra Dot-Certified Passenger Helmet & Vest',
    photos: [
      buildExteriorSvg({
        kind: 'moto',
        bgTop: '#1f2937',
        bgBottom: '#111827',
        accent: '#fb7185',
        bodyFill: '#27272a',
        title: 'Zero SR/F Sovereign Moto (2025)',
        subtitle: 'MOTO EXPRESS · MOTOR BIKE · ZH-M92-14'
      }),
      buildInteriorSpecsSvg({
        bg: '#111827',
        accent: '#fb7185',
        title: 'Moto Express Passenger Gear & Safety',
        specsLine1: '1 PASSENGER · HELMET',
        specsLine2: 'FASTEST LANE · ZERO CO2'
      })
    ],
    videos: ['/videos/moto-express.mp4']
  }
};

export const getCustomDriverVehicleFallbackPhoto = (
  vehicleType: 'Car' | 'Auto Rickshaw' | 'Motor Bike',
  model: string,
  plate: string
) => {
  const kind =
    vehicleType === 'Auto Rickshaw'
      ? 'rickshaw'
      : vehicleType === 'Motor Bike'
        ? 'moto'
        : 'fastback';
  return buildExteriorSvg({
    kind,
    bgTop: '#1e293b',
    bgBottom: '#09090b',
    accent: '#10b981',
    bodyFill: '#334155',
    title: model || vehicleType,
    subtitle: `${vehicleType.toUpperCase()} · PLATE ${plate || 'VERIFIED'}`
  });
};
