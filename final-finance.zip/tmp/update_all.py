import re

# 1. Update publicDisclosuresAgent.ts
agent_path = 'src/services/publicDisclosuresAgent.ts'
with open(agent_path, 'r', encoding='utf-8') as f:
    agent_content = f.read()

# Add friend profiles to TARGET_DISCLOSURE_ENTITIES if not already there
friend_profiles_snippet = '''  // ================= FRIEND & MUTUAL SYNDICATE PEERS =================
  {
    id: 'demo-satoshi-nakamoto',
    name: 'Satoshi Nakamoto',
    identifier: 'Peer ID: SATOSHI-GENESIS-01',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Syndicate Portfolio Report',
    filingFeedUrl: 'https://etherscan.io/address/0xd8da6bf269',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'Pioneer of Sovereign Digital Cash & Peer Syndicate Anchor',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-SYNDICATE-2024-001',
    issuerName: 'Alex Chen Sovereign Human Equity / Bitcoin Reserve',
    issuerTradingSymbol: 'ALEX / BTC',
    relationship: 'Syndicate Peer & Core Contributor',
    certificationText: 'Certified peer network transaction and sovereign asset allocation disclosure.',
    digitalSignature: 'Signed by Satoshi Nakamoto (Genesis Consensus Key)',
    footnotes: [
      'Peer-to-peer syndicate allocation validated by decentralized consensus nodes.',
      'Includes both open market acquisition (buy) and liquidity rebalancing (sell) transactions.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Alex Chen Sovereign Human Equity (ALEX)',
        transactionDate: '2024-08-18',
        filingDate: '2024-08-19',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '850 shares',
        price: '$28.75',
        valuation: '$24,437.50',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Genesis Holding'
      },
      {
        securityTitle: 'Alex Chen Sovereign Human Equity (ALEX)',
        transactionDate: '2024-08-22',
        filingDate: '2024-08-22',
        transactionCode: 'S - Profit Taking Sale',
        action: 'SELL',
        shares: '300 shares',
        price: '$29.50',
        valuation: '$8,850.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Sale Tranche'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-08-18 | Filed: 2024-08-19',
        filer_name: 'Satoshi Nakamoto',
        disclosure_type: 'Peer Syndicate Portfolio Report',
        ticker: 'ALEX',
        action: 'BUY',
        share_quantity_or_value: '$24,437.50 (850 shares)',
        asset_class: 'Stock',
        source_document_url: 'https://etherscan.io/address/0xd8da6bf269',
        cik_or_member_id: 'Peer ID: SATOSHI-GENESIS-01'
      },
      {
        timestamp: 'Execution: 2024-08-22 | Filed: 2024-08-22',
        filer_name: 'Satoshi Nakamoto',
        disclosure_type: 'Peer Syndicate Portfolio Report',
        ticker: 'ALEX',
        action: 'SELL',
        share_quantity_or_value: '$8,850.00 (300 shares)',
        asset_class: 'Stock',
        source_document_url: 'https://etherscan.io/address/0xd8da6bf269',
        cik_or_member_id: 'Peer ID: SATOSHI-GENESIS-01'
      }
    ]
  },
  {
    id: 'user-elena_rostova',
    name: 'Elena Rostova',
    identifier: 'Peer ID: ELENA-PLASMA-09',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Syndicate Portfolio Report',
    filingFeedUrl: 'https://github.com/elena-rostova-plasma',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    role: 'Lead Plasma Magnetics & Sovereign Trustee',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-SYNDICATE-2024-002',
    issuerName: 'Final Network Treasury Equity',
    issuerTradingSymbol: 'AFNL-EQ',
    relationship: 'Syndicate Peer & Trustee',
    certificationText: 'Certified peer network transaction and sovereign asset allocation disclosure.',
    digitalSignature: 'Signed by Elena Rostova (Verified Peer Trustee)',
    footnotes: [
      'Peer syndicate portfolio rebalancing and treasury equity acquisition.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Final Network Treasury Equity (AFNL-EQ)',
        transactionDate: '2024-08-15',
        filingDate: '2024-08-16',
        transactionCode: 'P - Treasury Reinforcement',
        action: 'BUY',
        shares: '350 shares',
        price: '$310.50',
        valuation: '$108,675.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Treasury Holding'
      },
      {
        securityTitle: 'Final Network Treasury Equity (AFNL-EQ)',
        transactionDate: '2024-08-21',
        filingDate: '2024-08-21',
        transactionCode: 'S - Liquidity Realignment',
        action: 'SELL',
        shares: '120 shares',
        price: '$315.00',
        valuation: '$37,800.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Syndicate Sale'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-08-15 | Filed: 2024-08-16',
        filer_name: 'Elena Rostova',
        disclosure_type: 'Peer Syndicate Portfolio Report',
        ticker: 'AFNL-EQ',
        action: 'BUY',
        share_quantity_or_value: '$108,675.00 (350 shares)',
        asset_class: 'Stock',
        source_document_url: 'https://github.com/elena-rostova-plasma',
        cik_or_member_id: 'Peer ID: ELENA-PLASMA-09'
      },
      {
        timestamp: 'Execution: 2024-08-21 | Filed: 2024-08-21',
        filer_name: 'Elena Rostova',
        disclosure_type: 'Peer Syndicate Portfolio Report',
        ticker: 'AFNL-EQ',
        action: 'SELL',
        share_quantity_or_value: '$37,800.00 (120 shares)',
        asset_class: 'Stock',
        source_document_url: 'https://github.com/elena-rostova-plasma',
        cik_or_member_id: 'Peer ID: ELENA-PLASMA-09'
      }
    ]
  },'''

if 'demo-satoshi-nakamoto' not in agent_content:
    agent_content = agent_content.replace('export const TARGET_DISCLOSURE_ENTITIES: TargetEntityProfile[] = [', 'export const TARGET_DISCLOSURE_ENTITIES: TargetEntityProfile[] = [\n' + friend_profiles_snippet)
    with open(agent_path, 'w', encoding='utf-8') as f:
        f.write(agent_content)
    print('Updated publicDisclosuresAgent.ts')

# Update getEntityProfile fallback for friend/mutual names
with open(agent_path, 'r', encoding='utf-8') as f:
    agent_content = f.read()

fallback_update = '''  const isGovernmental = normalized.includes('pelosi') || normalized.includes('senat') || normalized.includes('congress') || normalized.includes('tuberville');
  const isEntrepreneur = normalized.includes('musk') || normalized.includes('huang') || normalized.includes('bezos') || normalized.includes('zuck') || normalized.includes('saylor');
  const isCrypto = normalized.includes('satoshi') || normalized.includes('vitalik') || normalized.includes('nakamoto');
  const isFriend = normalized.includes('elena') || normalized.includes('sterling') || normalized.includes('marcus') || normalized.includes('sophia') || normalized.includes('friend');

  const sourceAgency = isFriend ? 'Peer Syndicate Network' : (isGovernmental ? 'US House Public Disclosures' : 'SEC EDGAR');'''

if 'isFriend' not in agent_content:
    agent_content = agent_content.replace('  const isGovernmental = normalized.includes(\'pelosi\') || normalized.includes(\'senat\') || normalized.includes(\'congress\') || normalized.includes(\'tuberville\');', fallback_update)
    agent_content = agent_content.replace("sourceAgency: isGovernmental ? 'US House Public Disclosures' : 'SEC EDGAR',", "sourceAgency,")
    with open(agent_path, 'w', encoding='utf-8') as f:
        f.write(agent_content)
    print('Updated getEntityProfile in publicDisclosuresAgent.ts')

# 2. Update CelebrityOfficialFilingView.tsx
view_path = 'src/components/stocks/CelebrityOfficialFilingView.tsx'
with open(view_path, 'r', encoding='utf-8') as f:
    view_content = f.read()

# Remove sticky classes from top bar
sticky_old = 'className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 sticky top-2 z-20 backdrop-blur-md bg-white/95"'
sticky_new = 'className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"'
view_content = view_content.replace(sticky_old, sticky_new)

# Check if friend profile to hide Official .gov source button and customize theme
friend_check_code = '''  const isFriendProfile = profile.sourceAgency === 'Peer Syndicate Network' || profile.id.startsWith('user-') || profile.id.startsWith('demo-');

  // Badge styling according to celebrity category
  const getCategoryTheme = () => {
    if (isFriendProfile) {
      return {
        badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300',
        sealTitle: 'COMMUNITY PEER LEDGER & SYNDICATE DISCLOSURE',
        formTitle: 'PEER PORTFOLIO TRANSACTION & ALLOCATION REPORT',
        sealSubtitle: 'Verified Real-Time Peer Portfolio & Syndicate Execution Ledger',
        ombText: 'COMMUNITY SYNDICATE PROTOCOL • Verified Community Peer Network'
      };
    }
    switch (profile.entityCategory) {'''

view_content = view_content.replace('  // Badge styling according to celebrity category\n  const getCategoryTheme = () => {\n    switch (profile.entityCategory) {', friend_check_code)

# Conditionally render Official .gov source button
gov_button_old = '''          <a
            href={profile.filingFeedUrl}
            target="_blank"
            rel="noreferrer"
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
            title="Open official government agency source"
          >
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span>Official .gov Source</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>'''

gov_button_new = '''          {!isFriendProfile && (
            <a
              href={profile.filingFeedUrl}
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
              title="Open official government agency source"
            >
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              <span>Official .gov Source</span>
              <ExternalLink className="w-3 h-3 text-slate-400" />
            </a>
          )}'''

view_content = view_content.replace(gov_button_old, gov_button_new)

with open(view_path, 'w', encoding='utf-8') as f:
    f.write(view_content)
print('Updated CelebrityOfficialFilingView.tsx')
