import crypto from 'crypto';
import Stripe from 'stripe';
import { validateUsBankAccountInput } from '../utils/paymentValidation';

let cachedClient: Stripe | null = null;
let cachedKey: string | undefined;

const SESSION_SIGNING_SECRET =
  process.env.STRIPE_SESSION_SECRET?.trim() || crypto.randomBytes(32).toString('hex');

// In-memory cache mapping appUserId -> Stripe Customer ID
const userCustomerCache = new Map<string, string>();

export interface StripeSessionClaims {
  userId: string;
  customerId: string;
  email?: string;
  exp: number;
}

export interface StripeSavedPaymentMethod {
  id: string;
  type: 'card' | 'us_bank_account';
  isDefault: boolean;
  created: number;
  // Card fields (safe non-sensitive metadata only)
  brand?: string;
  last4: string;
  expMonth?: number;
  expYear?: number;
  funding?: string;
  cardholderName?: string;
  // Bank fields (safe non-sensitive metadata only)
  bankName?: string;
  accountType?: string;
  routingNumber?: string;
  status?: string;
}

export interface MarketMembershipStatus {
  configured: boolean;
  priceIdConfigured: boolean;
  priceId: string | null;
  customerId: string;
  hasSubscription: boolean;
  subscriptionId: string | null;
  status: string;
  cancelAtPeriodEnd: boolean;
  currentPeriodEnd: string | null;
  planName: string;
  monthlyAmountUSD: number;
  defaultPaymentMethod: StripeSavedPaymentMethod | null;
}

function readEnvSecret(name: string): string | null {
  const raw = process.env[name];
  if (typeof raw !== 'string') return null;
  let trimmed = raw.trim();
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    trimmed = trimmed.slice(1, -1).trim();
  }
  if (!trimmed || /^MY_[A-Z0-9_]+$/i.test(trimmed)) {
    return null;
  }
  return trimmed;
}

function isCleanAsciiToken(value: string): boolean {
  return value.length > 0 && !/[\s|]/.test(value) && /^[\x21-\x7E]+$/.test(value);
}

export class StripeConfigError extends Error {
  public readonly statusCode = 503;
  constructor(message: string) {
    super(message);
    this.name = 'StripeConfigError';
  }
}

export class StripeSessionAuthError extends Error {
  public readonly statusCode = 401;
  constructor(message: string) {
    super(message);
    this.name = 'StripeSessionAuthError';
  }
}

export function mapStripeErrorToHttp(
  error: unknown,
  fallbackMessage = 'Stripe request failed'
): { status: number; message: string; isConfigError?: boolean } {
  if (error instanceof StripeConfigError) {
    return { status: 503, message: error.message, isConfigError: true };
  }
  if (error instanceof StripeSessionAuthError) {
    return { status: 401, message: error.message };
  }

  const errObj = error as {
    type?: string;
    code?: string;
    statusCode?: number;
    message?: string;
  } | null;

  const rawMsg = typeof errObj?.message === 'string' && errObj.message.trim() ? errObj.message.trim() : fallbackMessage;
  const errType = errObj?.type || '';

  if (errType === 'StripeAuthenticationError' || errObj?.statusCode === 401) {
    return {
      status: 503,
      isConfigError: true,
      message: 'Stripe rejected STRIPE_SECRET_KEY (authentication failed). Please verify your Stripe secret key in environment secrets.',
    };
  }

  if (errType === 'StripePermissionError') {
    return {
      status: 503,
      isConfigError: true,
      message: rawMsg || 'Configured Stripe API key lacks required permissions.',
    };
  }

  if (errType === 'StripeRateLimitError' || errObj?.statusCode === 429) {
    return { status: 429, message: rawMsg };
  }

  if (errType === 'StripeConnectionError' || errType === 'StripeAPIError') {
    return { status: 502, message: rawMsg };
  }

  if (rawMsg.includes('Forbidden:')) {
    return { status: 403, message: rawMsg };
  }

  if (rawMsg.includes('Authentication required') || rawMsg.includes('session token')) {
    return { status: 401, message: rawMsg };
  }

  return { status: 400, message: rawMsg };
}

function validateStripeSecretKey(): { valid: boolean; key: string | null; reason?: string } {
  const val = readEnvSecret('STRIPE_SECRET_KEY');
  if (!val) {
    return {
      valid: false,
      key: null,
      reason: 'Stripe is not configured. Set STRIPE_SECRET_KEY in environment secrets.',
    };
  }
  if (!isCleanAsciiToken(val) || !/^(sk|rk)_/.test(val)) {
    return {
      valid: false,
      key: null,
      reason: 'STRIPE_SECRET_KEY format is invalid. Expected a single key starting with sk_test_, sk_live_, rk_test_, or rk_live_ with no spaces or extra characters.',
    };
  }
  return { valid: true, key: val };
}

function validateStripePublishableKey(): { valid: boolean; key: string | null; reason?: string } {
  const val =
    readEnvSecret('STRIPE_PUBLISHABLE_KEY') ||
    readEnvSecret('VITE_STRIPE_PUBLISHABLE_KEY');
  if (!val) {
    return { valid: false, key: null };
  }
  if (!isCleanAsciiToken(val) || !/^pk_/.test(val)) {
    return {
      valid: false,
      key: null,
      reason: 'STRIPE_PUBLISHABLE_KEY format is invalid. Expected a publishable key starting with pk_test_ or pk_live_.',
    };
  }
  return { valid: true, key: val };
}

function validateStripeWebhookSecret(): { valid: boolean; secret: string | null; reason?: string } {
  const val = readEnvSecret('STRIPE_WEBHOOK_SECRET');
  if (!val) {
    return {
      valid: false,
      secret: null,
      reason: 'STRIPE_WEBHOOK_SECRET is not configured in environment secrets.',
    };
  }
  if (!isCleanAsciiToken(val) || !/^whsec_/.test(val)) {
    return {
      valid: false,
      secret: null,
      reason: 'STRIPE_WEBHOOK_SECRET format is invalid. Expected a signing secret starting with whsec_.',
    };
  }
  return { valid: true, secret: val };
}

function validateMembershipPriceId(): { valid: boolean; priceId: string | null; reason?: string } {
  const val = readEnvSecret('STRIPE_MEMBERSHIP_PRICE_ID');
  if (!val) {
    return { valid: false, priceId: null };
  }
  if (!isCleanAsciiToken(val) || !/^price_/.test(val)) {
    return {
      valid: false,
      priceId: null,
      reason: 'STRIPE_MEMBERSHIP_PRICE_ID format is invalid. Expected a Stripe Price ID starting with price_.',
    };
  }
  return { valid: true, priceId: val };
}

export function isStripeConfigured(): boolean {
  return validateStripeSecretKey().valid;
}

export function isWebhookConfigured(): boolean {
  return validateStripeWebhookSecret().valid;
}

export function getStripePublishableKey(): string | null {
  return validateStripePublishableKey().key;
}

export function getMembershipPriceId(): string | null {
  return validateMembershipPriceId().priceId;
}

export function getStripeConfigDiagnostics() {
  const secretCheck = validateStripeSecretKey();
  const pubCheck = validateStripePublishableKey();
  const webhookCheck = validateStripeWebhookSecret();
  const priceCheck = validateMembershipPriceId();

  const configurationError =
    secretCheck.reason || pubCheck.reason || priceCheck.reason || null;

  return {
    configured: secretCheck.valid,
    secretKeyPresent: Boolean(readEnvSecret('STRIPE_SECRET_KEY')),
    secretKeyValid: secretCheck.valid,
    publishableKeyPresent: Boolean(
      readEnvSecret('STRIPE_PUBLISHABLE_KEY') || readEnvSecret('VITE_STRIPE_PUBLISHABLE_KEY')
    ),
    publishableKeyValid: pubCheck.valid,
    publishableKey: pubCheck.key,
    webhookConfigured: webhookCheck.valid,
    membershipPriceConfigured: priceCheck.valid,
    configurationError,
  };
}

export function getStripeClient(): Stripe {
  const secretCheck = validateStripeSecretKey();
  if (!secretCheck.valid || !secretCheck.key) {
    throw new StripeConfigError(
      secretCheck.reason || 'Stripe is not configured. Set STRIPE_SECRET_KEY in environment secrets.'
    );
  }
  if (!cachedClient || cachedKey !== secretCheck.key) {
    cachedClient = new Stripe(secretCheck.key);
    cachedKey = secretCheck.key;
  }
  return cachedClient;
}

function assertPositiveInt(value: unknown, fieldName: string): number {
  const num = Number(value);
  if (!Number.isInteger(num) || num <= 0) {
    throw new Error(`${fieldName} must be a positive integer in minor currency units (cents).`);
  }
  return num;
}

function sanitizeSafeUrl(rawUrl: unknown, fallbackPath: string, requestOrigin?: string): string {
  const envBase = readEnvSecret('APP_URL');
  const baseUrl = (envBase || requestOrigin || 'http://localhost:3000').replace(/\/+$/, '');

  if (typeof rawUrl !== 'string' || !rawUrl.trim()) {
    return `${baseUrl}${fallbackPath}`;
  }
  try {
    const parsed = new URL(rawUrl, baseUrl);
    const allowedOrigin = new URL(baseUrl).origin;
    if ((parsed.protocol === 'https:' || parsed.protocol === 'http:') && parsed.origin === allowedOrigin) {
      return parsed.toString();
    }
  } catch {
    // Fall back to safe base URL path
  }
  return `${baseUrl}${fallbackPath}`;
}

function sanitizeCurrency(rawCurrency: unknown): string {
  const cur = typeof rawCurrency === 'string' && rawCurrency.trim() ? rawCurrency.trim().toLowerCase() : 'usd';
  if (!/^[a-z]{3}$/.test(cur)) {
    throw new Error('currency must be a valid 3-letter ISO currency code.');
  }
  return cur;
}

function sanitizeUserId(rawUserId: unknown): string {
  if (typeof rawUserId !== 'string') {
    throw new Error('Valid userId is required.');
  }
  const trimmed = rawUserId.trim();
  if (!trimmed || trimmed.length > 128 || !/^[a-zA-Z0-9_.\-@:]+$/.test(trimmed)) {
    throw new Error('Invalid userId format.');
  }
  return trimmed;
}

function base64UrlEncode(input: Buffer | string): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function base64UrlDecode(input: string): Buffer {
  const pad = input.length % 4 === 0 ? '' : '='.repeat(4 - (input.length % 4));
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/') + pad;
  return Buffer.from(normalized, 'base64');
}

export function issueStripeSessionToken(claims: Omit<StripeSessionClaims, 'exp'>): string {
  const fullClaims: StripeSessionClaims = {
    ...claims,
    exp: Date.now() + 12 * 60 * 60 * 1000, // 12 hours
  };
  const payload = base64UrlEncode(JSON.stringify(fullClaims));
  const sig = base64UrlEncode(
    crypto.createHmac('sha256', SESSION_SIGNING_SECRET).update(payload).digest()
  );
  return `${payload}.${sig}`;
}

export function verifyStripeSessionToken(authHeader?: string): StripeSessionClaims {
  if (!authHeader || typeof authHeader !== 'string' || !authHeader.startsWith('Bearer ')) {
    throw new StripeSessionAuthError('Authentication required: missing Bearer token.');
  }
  const token = authHeader.slice('Bearer '.length).trim();
  const parts = token.split('.');
  if (parts.length !== 2) {
    throw new StripeSessionAuthError('Invalid session token format.');
  }
  const [payload, providedSig] = parts;
  const expectedSig = base64UrlEncode(
    crypto.createHmac('sha256', SESSION_SIGNING_SECRET).update(payload).digest()
  );
  const providedBuf = Buffer.from(providedSig);
  const expectedBuf = Buffer.from(expectedSig);
  if (providedBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(providedBuf, expectedBuf)) {
    throw new StripeSessionAuthError('Invalid session token signature.');
  }
  let parsed: StripeSessionClaims;
  try {
    parsed = JSON.parse(base64UrlDecode(payload).toString('utf8'));
  } catch {
    throw new StripeSessionAuthError('Corrupted session token payload.');
  }
  if (!parsed?.userId || !parsed?.customerId || typeof parsed.exp !== 'number' || parsed.exp < Date.now()) {
    throw new StripeSessionAuthError('Session token expired. Please refresh settings.');
  }
  return parsed;
}

// ============================================================================
// CUSTOMER PROFILE MANAGEMENT
// ============================================================================

function isActiveStripeCustomer(
  c: Stripe.Customer | Stripe.DeletedCustomer | null | undefined
): c is Stripe.Customer {
  return Boolean(c && (c as Stripe.DeletedCustomer).deleted !== true);
}

export async function ensureStripeCustomerForUser(params: {
  userId: unknown;
  email?: unknown;
  name?: unknown;
}): Promise<{ customerId: string; email?: string }> {
  const stripe = getStripeClient();
  const userId = sanitizeUserId(params.userId);
  const email =
    typeof params.email === 'string' && params.email.includes('@')
      ? params.email.trim().toLowerCase().slice(0, 160)
      : undefined;
  const name =
    typeof params.name === 'string' && params.name.trim()
      ? params.name.trim().slice(0, 120)
      : undefined;

  const cachedId = userCustomerCache.get(userId);
  if (cachedId) {
    try {
      const existing = await stripe.customers.retrieve(cachedId);
      if (isActiveStripeCustomer(existing)) {
        return { customerId: existing.id, email: existing.email || email };
      }
    } catch {
      userCustomerCache.delete(userId);
    }
  }

  // Search by metadata.appUserId (userId is already strict-validated against [a-zA-Z0-9_.-@])
  try {
    const searchRes = await stripe.customers.search({
      query: `metadata['appUserId']:'${userId}'`,
      limit: 1,
    });
    const matchedSearch = searchRes.data.find(isActiveStripeCustomer);
    if (matchedSearch) {
      userCustomerCache.set(userId, matchedSearch.id);
      return { customerId: matchedSearch.id, email: matchedSearch.email || email };
    }
  } catch {
    // Fallback to email list lookup if Customer Search isn't available
  }

  if (email) {
    const listRes = await stripe.customers.list({ email, limit: 5 });
    const matched = listRes.data.find(
      (c) => isActiveStripeCustomer(c) && (!c.metadata?.appUserId || c.metadata.appUserId === userId)
    );
    if (matched) {
      if (!matched.metadata?.appUserId) {
        await stripe.customers.update(matched.id, {
          metadata: { ...matched.metadata, appUserId: userId },
        });
      }
      userCustomerCache.set(userId, matched.id);
      return { customerId: matched.id, email: matched.email || email };
    }
  }

  const created = await stripe.customers.create({
    email,
    name,
    metadata: { appUserId: userId },
  });
  userCustomerCache.set(userId, created.id);
  return { customerId: created.id, email: created.email || email };
}

function mapStripePaymentMethod(
  pm: Stripe.PaymentMethod,
  defaultPaymentMethodId: string | null
): StripeSavedPaymentMethod | null {
  const isDefault = Boolean(defaultPaymentMethodId && pm.id === defaultPaymentMethodId);
  if (pm.type === 'card' && pm.card) {
    return {
      id: pm.id,
      type: 'card',
      isDefault,
      created: pm.created,
      brand: pm.card.brand,
      last4: pm.card.last4,
      expMonth: pm.card.exp_month,
      expYear: pm.card.exp_year,
      funding: pm.card.funding,
      cardholderName: pm.billing_details?.name || undefined,
    };
  }
  if (pm.type === 'us_bank_account' && pm.us_bank_account) {
    const bank = pm.us_bank_account;
    const verificationStatus = bank.financial_connections_account
      ? 'Verified (Instant ACH)'
      : 'Connected Bank (ACH)';
    return {
      id: pm.id,
      type: 'us_bank_account',
      isDefault,
      created: pm.created,
      bankName: pm.metadata?.bankName || bank.bank_name || 'Connected Bank Account',
      last4: bank.last4 || '0000',
      accountType: bank.account_type || 'checking',
      routingNumber: bank.routing_number ? `••••${bank.routing_number.slice(-4)}` : '••••',
      status: verificationStatus,
    };
  }
  return null;
}

async function getDefaultPaymentMethodId(customerId: string): Promise<string | null> {
  const stripe = getStripeClient();
  const customer = await stripe.customers.retrieve(customerId);
  if (!isActiveStripeCustomer(customer)) {
    throw new Error('Stripe customer profile not found.');
  }
  const rawDefault = customer.invoice_settings?.default_payment_method;
  if (!rawDefault) return null;
  return typeof rawDefault === 'string' ? rawDefault : rawDefault.id;
}

async function assertPaymentMethodOwnership(customerId: string, paymentMethodId: string): Promise<Stripe.PaymentMethod> {
  if (!paymentMethodId || typeof paymentMethodId !== 'string' || !paymentMethodId.startsWith('pm_')) {
    throw new Error('Invalid paymentMethodId.');
  }
  const stripe = getStripeClient();
  const pm = await stripe.paymentMethods.retrieve(paymentMethodId);
  const pmCustomer = typeof pm.customer === 'string' ? pm.customer : pm.customer?.id;
  if (pmCustomer !== customerId) {
    throw new Error('Forbidden: payment method does not belong to your Stripe customer profile.');
  }
  return pm;
}

export async function listCustomerPaymentMethods(customerId: string): Promise<{
  customerId: string;
  defaultPaymentMethodId: string | null;
  paymentMethods: StripeSavedPaymentMethod[];
}> {
  const stripe = getStripeClient();
  const defaultPaymentMethodId = await getDefaultPaymentMethodId(customerId);

  const [cardsRes, banksRes] = await Promise.all([
    stripe.paymentMethods.list({ customer: customerId, type: 'card', limit: 100 }),
    stripe.paymentMethods.list({ customer: customerId, type: 'us_bank_account', limit: 100 }),
  ]);

  const combined = [...banksRes.data, ...cardsRes.data]
    .map((pm) => mapStripePaymentMethod(pm, defaultPaymentMethodId))
    .filter((item): item is StripeSavedPaymentMethod => Boolean(item))
    .sort((a, b) => Number(b.isDefault) - Number(a.isDefault) || b.created - a.created);

  return {
    customerId,
    defaultPaymentMethodId,
    paymentMethods: combined,
  };
}

export async function createCustomerSetupIntent(params: {
  customerId: string;
  preference?: 'card' | 'us_bank_account' | 'both';
}): Promise<{
  setupIntentId: string;
  clientSecret: string;
  paymentMethodTypes: string[];
}> {
  const stripe = getStripeClient();
  const pref =
    params.preference === 'us_bank_account'
      ? 'us_bank_account'
      : params.preference === 'both'
      ? 'both'
      : 'card';

  if (pref === 'us_bank_account') {
    const intent = await stripe.setupIntents.create({
      customer: params.customerId,
      allowed_payment_method_types: ['us_bank_account'],
      usage: 'off_session',
      payment_method_options: {
        us_bank_account: {
          verification_method: 'automatic',
        },
      },
    });
    if (!intent.client_secret) {
      throw new Error('Stripe SetupIntent did not return a client secret.');
    }
    return {
      setupIntentId: intent.id,
      clientSecret: intent.client_secret,
      paymentMethodTypes: intent.payment_method_types,
    };
  }

  if (pref === 'both') {
    try {
      const intent = await stripe.setupIntents.create({
        customer: params.customerId,
        allowed_payment_method_types: ['card', 'us_bank_account'],
        usage: 'off_session',
        payment_method_options: {
          us_bank_account: {
            verification_method: 'automatic',
          },
        },
      });
      if (!intent.client_secret) {
        throw new Error('Stripe SetupIntent did not return a client secret.');
      }
      return {
        setupIntentId: intent.id,
        clientSecret: intent.client_secret,
        paymentMethodTypes: intent.payment_method_types,
      };
    } catch {
      const fallbackIntent = await stripe.setupIntents.create({
        customer: params.customerId,
        automatic_payment_methods: { enabled: true },
        usage: 'off_session',
      });
      if (!fallbackIntent.client_secret) {
        throw new Error('Stripe SetupIntent did not return a client secret.');
      }
      return {
        setupIntentId: fallbackIntent.id,
        clientSecret: fallbackIntent.client_secret,
        paymentMethodTypes: fallbackIntent.payment_method_types,
      };
    }
  }

  const intent = await stripe.setupIntents.create({
    customer: params.customerId,
    allowed_payment_method_types: ['card'],
    usage: 'off_session',
  });
  if (!intent.client_secret) {
    throw new Error('Stripe SetupIntent did not return a client secret.');
  }
  return {
    setupIntentId: intent.id,
    clientSecret: intent.client_secret,
    paymentMethodTypes: intent.payment_method_types,
  };
}

export async function createSetupCheckoutSession(params: {
  customerId: string;
  preference?: 'card' | 'us_bank_account' | 'both';
  successUrl?: string;
  cancelUrl?: string;
  requestOrigin?: string;
}) {
  const stripe = getStripeClient();
  const requestedTypes: Array<Stripe.Checkout.SessionCreateParams.AllowedPaymentMethodType> =
    params.preference === 'us_bank_account'
      ? ['us_bank_account']
      : params.preference === 'both'
      ? ['card', 'us_bank_account']
      : ['card'];

  const createSessionWithTypes = (types: Array<Stripe.Checkout.SessionCreateParams.AllowedPaymentMethodType>) =>
    stripe.checkout.sessions.create({
      mode: 'setup',
      currency: 'usd',
      customer: params.customerId,
      allowed_payment_method_types: types,
      success_url: sanitizeSafeUrl(
        params.successUrl,
        '/?stripe_setup=success&tab=payment_methods',
        params.requestOrigin
      ),
      cancel_url: sanitizeSafeUrl(
        params.cancelUrl,
        '/?stripe_setup=cancelled&tab=payment_methods',
        params.requestOrigin
      ),
    });

  let session: Stripe.Checkout.Session;
  if (params.preference === 'both') {
    try {
      session = await createSessionWithTypes(requestedTypes);
    } catch {
      session = await createSessionWithTypes(['card']);
    }
  } else {
    session = await createSessionWithTypes(requestedTypes);
  }

  return {
    id: session.id,
    url: session.url,
    status: session.status,
  };
}

export async function setDefaultCustomerPaymentMethod(params: {
  customerId: string;
  paymentMethodId: string;
}) {
  const stripe = getStripeClient();
  await assertPaymentMethodOwnership(params.customerId, params.paymentMethodId);
  await stripe.customers.update(params.customerId, {
    invoice_settings: {
      default_payment_method: params.paymentMethodId,
    },
  });
  return listCustomerPaymentMethods(params.customerId);
}

export async function detachCustomerPaymentMethod(params: {
  customerId: string;
  paymentMethodId: string;
}) {
  const stripe = getStripeClient();
  await assertPaymentMethodOwnership(params.customerId, params.paymentMethodId);
  await stripe.paymentMethods.detach(params.paymentMethodId);
  return listCustomerPaymentMethods(params.customerId);
}

export async function linkUsBankAccountToCustomer(params: {
  customerId: string;
  bankName: unknown;
  accountHolderName: unknown;
  accountType?: unknown;
  routingNumber: unknown;
  accountNumber: unknown;
  email?: string;
  clientIp?: string;
  userAgent?: string;
}) {
  const stripe = getStripeClient();
  const bankName =
    typeof params.bankName === 'string' && params.bankName.trim()
      ? params.bankName.trim().slice(0, 80)
      : 'Bank Account';
  const accountHolderName =
    typeof params.accountHolderName === 'string' && params.accountHolderName.trim()
      ? params.accountHolderName.trim().slice(0, 120)
      : '';

  const bankCheck = validateUsBankAccountInput({
    accountHolderName,
    routingNumber: String(params.routingNumber || ''),
    accountNumber: String(params.accountNumber || ''),
    accountType: typeof params.accountType === 'string' ? params.accountType : 'checking',
  });
  if (!bankCheck.valid) {
    throw new Error(bankCheck.error);
  }

  const accountType =
    params.accountType === 'savings' ? 'savings' : 'checking';

  const pm = await stripe.paymentMethods.create({
    type: 'us_bank_account',
    us_bank_account: {
      account_holder_type: 'individual',
      account_type: accountType,
      routing_number: bankCheck.routingNumber,
      account_number: bankCheck.accountNumber,
    },
    billing_details: {
      name: accountHolderName,
      ...(params.email ? { email: params.email } : {}),
    },
    metadata: {
      bankName,
    },
  });

  const setupIntent = await stripe.setupIntents.create({
    customer: params.customerId,
    payment_method: pm.id,
    allowed_payment_method_types: ['us_bank_account'],
    usage: 'off_session',
    confirm: true,
    mandate_data: {
      customer_acceptance: {
        type: 'online',
        online: {
          ip_address: params.clientIp || '127.0.0.1',
          user_agent: (params.userAgent || 'FinalFinance/1.0').slice(0, 250),
        },
      },
    },
  });

  if (setupIntent.status === 'requires_action') {
    const arrivalTs = setupIntent.next_action?.verify_with_microdeposits?.arrival_date;
    return {
      ...(await listCustomerPaymentMethods(params.customerId)),
      pendingVerification: true,
      setupIntentId: setupIntent.id,
      paymentMethodId: pm.id,
      arrivalDate: arrivalTs ? new Date(arrivalTs * 1000).toISOString() : null,
    };
  }

  if (setupIntent.status !== 'succeeded') {
    await stripe.paymentMethods.detach(pm.id).catch(() => {});
    throw new Error('Bank account could not be verified. Please verify your routing and account details.');
  }

  const currentDefault = await getDefaultPaymentMethodId(params.customerId);
  if (!currentDefault) {
    await stripe.customers.update(params.customerId, {
      invoice_settings: { default_payment_method: pm.id },
    });
  }

  return {
    ...(await listCustomerPaymentMethods(params.customerId)),
    pendingVerification: false,
    setupIntentId: setupIntent.id,
    paymentMethodId: pm.id,
  };
}

export async function verifyUsBankMicrodeposits(params: {
  customerId: string;
  setupIntentId: unknown;
  amounts?: unknown;
  descriptorCode?: unknown;
}) {
  const stripe = getStripeClient();
  const setupIntentId = typeof params.setupIntentId === 'string' ? params.setupIntentId.trim() : '';
  if (!setupIntentId.startsWith('seti_')) {
    throw new Error('Invalid SetupIntent ID for bank verification.');
  }

  const existingIntent = await stripe.setupIntents.retrieve(setupIntentId);
  const intentCustomer = typeof existingIntent.customer === 'string'
    ? existingIntent.customer
    : existingIntent.customer?.id;
  if (intentCustomer !== params.customerId) {
    throw new Error('Forbidden: bank verification session does not belong to your account.');
  }

  const descriptorCode =
    typeof params.descriptorCode === 'string' && params.descriptorCode.trim()
      ? params.descriptorCode.trim()
      : undefined;

  let amounts: [number, number] | undefined;
  if (Array.isArray(params.amounts) && params.amounts.length === 2) {
    const a1 = Number(params.amounts[0]);
    const a2 = Number(params.amounts[1]);
    if (!Number.isInteger(a1) || !Number.isInteger(a2) || a1 <= 0 || a2 <= 0) {
      throw new Error('Enter two valid micro-deposit amounts in cents.');
    }
    amounts = [a1, a2];
  }

  if (!descriptorCode && !amounts) {
    throw new Error('Enter the 6-character SM descriptor code or both micro-deposit amounts.');
  }

  const verified = await stripe.setupIntents.verifyMicrodeposits(setupIntentId, {
    ...(descriptorCode ? { descriptor_code: descriptorCode } : {}),
    ...(amounts ? { amounts } : {}),
  });

  if (verified.status !== 'succeeded') {
    throw new Error('Bank micro-deposit verification did not succeed. Check your statement values and try again.');
  }

  const pmId = typeof verified.payment_method === 'string'
    ? verified.payment_method
    : verified.payment_method?.id;

  const currentDefault = await getDefaultPaymentMethodId(params.customerId);
  if (pmId && !currentDefault) {
    await stripe.customers.update(params.customerId, {
      invoice_settings: { default_payment_method: pmId },
    });
  }

  return listCustomerPaymentMethods(params.customerId);
}

export async function verifySetupIntentCard(params: {
  customerId: string;
  setupIntentId: unknown;
}) {
  const stripe = getStripeClient();
  const setupIntentId = typeof params.setupIntentId === 'string' ? params.setupIntentId.trim() : '';
  if (!setupIntentId.startsWith('seti_')) {
    throw new Error('Invalid card setup session.');
  }

  const intent = await stripe.setupIntents.retrieve(setupIntentId, {
    expand: ['payment_method'],
  });
  const intentCustomer = typeof intent.customer === 'string'
    ? intent.customer
    : intent.customer?.id;
  if (intentCustomer !== params.customerId) {
    throw new Error('Forbidden: card setup session does not belong to your account.');
  }

  if (intent.status !== 'succeeded') {
    throw new Error('Card verification has not completed. Your card was not saved.');
  }

  const pm =
    typeof intent.payment_method === 'object' && intent.payment_method && 'id' in intent.payment_method
      ? (intent.payment_method as Stripe.PaymentMethod)
      : typeof intent.payment_method === 'string'
      ? await stripe.paymentMethods.retrieve(intent.payment_method)
      : null;

  if (!pm || pm.type !== 'card' || !pm.card) {
    throw new Error('Verified payment method is not a valid card.');
  }

  const cvcCheck = pm.card.checks?.cvc_check;
  const zipCheck = pm.card.checks?.address_postal_code_check;
  if (cvcCheck === 'fail' || zipCheck === 'fail') {
    await stripe.paymentMethods.detach(pm.id).catch(() => {});
    throw new Error(
      cvcCheck === 'fail'
        ? 'Card security code (CVC) verification failed with your card issuer. Card was not saved.'
        : 'Billing ZIP/postal code verification failed with your card issuer. Card was not saved.'
    );
  }

  const currentDefault = await getDefaultPaymentMethodId(params.customerId);
  if (!currentDefault) {
    await stripe.customers.update(params.customerId, {
      invoice_settings: { default_payment_method: pm.id },
    });
  }

  return listCustomerPaymentMethods(params.customerId);
}

export async function executeStripePaymentMethodCharge(params: {
  customerId: string;
  paymentMethodId: unknown;
  amountUSD: unknown;
  baseAmountUSD?: unknown;
  feeUSD?: unknown;
  description?: unknown;
  purpose?: 'deposit' | 'debt_payment' | 'purchase';
  targetAssetClass?: string;
  targetCurrencyCode?: string;
}): Promise<{
  paymentIntentId: string;
  status: string;
  requiresAction: boolean;
  clientSecret: string | null;
  amountUSD: number;
  baseAmountUSD: number;
  feeUSD: number;
  amountCents: number;
  paymentMethodId: string;
  paymentMethodType: 'card' | 'us_bank_account';
  sourceLabel: string;
}> {
  const stripe = getStripeClient();
  const paymentMethodId = typeof params.paymentMethodId === 'string' ? params.paymentMethodId.trim() : '';
  const pm = await assertPaymentMethodOwnership(params.customerId, paymentMethodId);

  if (pm.type !== 'card' && pm.type !== 'us_bank_account') {
    throw new Error('Only verified payment cards and US bank accounts can be charged.');
  }
  const paymentMethodType: 'card' | 'us_bank_account' =
    pm.type === 'card' ? 'card' : 'us_bank_account';

  const rawAmount = Number(params.amountUSD);
  if (!Number.isFinite(rawAmount) || rawAmount < 0.5 || rawAmount > 1_000_000) {
    throw new Error('Amount must be between $0.50 and $1,000,000.00 USD.');
  }

  const amountCents = Math.round(rawAmount * 100);
  const amountUSD = amountCents / 100;
  const rawFee = Number(params.feeUSD);
  const feeUSD = Number.isFinite(rawFee) && rawFee >= 0 ? Math.round(rawFee * 100) / 100 : 0;
  const rawBase = Number(params.baseAmountUSD);
  const baseAmountUSD =
    Number.isFinite(rawBase) && rawBase > 0
      ? Math.round(rawBase * 100) / 100
      : Math.max(0, Math.round((amountUSD - feeUSD) * 100) / 100);
  const purpose =
    params.purpose === 'debt_payment'
      ? 'debt_payment'
      : params.purpose === 'purchase'
      ? 'purchase'
      : 'deposit';
  const targetAssetClass =
    typeof params.targetAssetClass === 'string' && params.targetAssetClass.trim()
      ? params.targetAssetClass.trim().slice(0, 32)
      : 'fiat';
  const targetCurrencyCode =
    typeof params.targetCurrencyCode === 'string' && params.targetCurrencyCode.trim()
      ? params.targetCurrencyCode.trim().toUpperCase().slice(0, 16)
      : 'USD';

  const sourceLabel =
    paymentMethodType === 'card' && pm.card
      ? `${(pm.card.brand || 'Card').toUpperCase()} ••••${pm.card.last4}`
      : paymentMethodType === 'us_bank_account' && pm.us_bank_account
      ? `${pm.metadata?.bankName || pm.us_bank_account.bank_name || 'Bank Account'} ••••${pm.us_bank_account.last4 || '0000'}`
      : 'Verified Stripe Method';

  const description =
    typeof params.description === 'string' && params.description.trim()
      ? params.description.trim().slice(0, 200)
      : purpose === 'debt_payment'
      ? `Final Finance Debt Settlement via ${sourceLabel}`
      : purpose === 'purchase'
      ? `Final Finance Marketplace Allocation via ${sourceLabel}`
      : `Final Finance ${targetCurrencyCode} Treasury Deposit via ${sourceLabel}`;

  const intent = await stripe.paymentIntents.create({
    customer: params.customerId,
    payment_method: pm.id,
    amount: amountCents,
    currency: 'usd',
    confirm: true,
    off_session: true,
    allowed_payment_method_types: [paymentMethodType],
    description,
    metadata: {
      purpose,
      targetAssetClass,
      targetCurrencyCode,
      sourceLabel,
      baseAmountUSD: baseAmountUSD.toFixed(2),
      feeUSD: feeUSD.toFixed(2),
    },
  });

  if (intent.status === 'requires_action') {
    return {
      paymentIntentId: intent.id,
      status: intent.status,
      requiresAction: true,
      clientSecret: intent.client_secret,
      amountUSD,
      baseAmountUSD,
      feeUSD,
      amountCents,
      paymentMethodId: pm.id,
      paymentMethodType,
      sourceLabel,
    };
  }

  if (intent.status !== 'succeeded' && intent.status !== 'processing') {
    throw new Error(
      `Stripe payment authorization returned status "${intent.status}". No funds were charged.`
    );
  }

  return {
    paymentIntentId: intent.id,
    status: intent.status,
    requiresAction: false,
    clientSecret: null,
    amountUSD,
    baseAmountUSD,
    feeUSD,
    amountCents,
    paymentMethodId: pm.id,
    paymentMethodType,
    sourceLabel,
  };
}

// ============================================================================
// MARKET MEMBERSHIP ($2/MONTH) SUBSCRIPTION MANAGEMENT
// ============================================================================

function findMembershipSubscription(
  subscriptions: Stripe.Subscription[],
  membershipPriceId: string | null
): Stripe.Subscription | null {
  const statusRank: Record<string, number> = {
    active: 5,
    trialing: 4,
    past_due: 3,
    incomplete: 2,
    canceled: 1,
  };

  const candidates = subscriptions.filter((sub) => {
    if (sub.metadata?.membership === 'market_membership') return true;
    if (membershipPriceId && sub.items.data.some((item) => item.price?.id === membershipPriceId)) {
      return true;
    }
    return false;
  });

  if (candidates.length === 0) return null;
  candidates.sort((a, b) => {
    const rankDiff = (statusRank[b.status] || 0) - (statusRank[a.status] || 0);
    if (rankDiff !== 0) return rankDiff;
    return (b.created || 0) - (a.created || 0);
  });
  return candidates[0];
}

function getSubscriptionPeriodEndIso(sub: Stripe.Subscription): string | null {
  const periodEndUnix =
    (sub as unknown as { current_period_end?: number }).current_period_end ||
    sub.items?.data?.[0]?.current_period_end;
  if (typeof periodEndUnix === 'number' && periodEndUnix > 0) {
    return new Date(periodEndUnix * 1000).toISOString();
  }
  return null;
}

export async function getCustomerMembershipStatus(customerId: string): Promise<MarketMembershipStatus> {
  const stripe = getStripeClient();
  const priceId = getMembershipPriceId();

  const [subsRes, methodsInfo] = await Promise.all([
    stripe.subscriptions.list({
      customer: customerId,
      status: 'all',
      limit: 20,
      expand: ['data.default_payment_method'],
    }),
    listCustomerPaymentMethods(customerId),
  ]);

  const matchedSub = findMembershipSubscription(subsRes.data, priceId);
  const defaultPm =
    methodsInfo.paymentMethods.find((m) => m.isDefault) || methodsInfo.paymentMethods[0] || null;

  const isActiveState = matchedSub
    ? ['active', 'trialing', 'past_due', 'incomplete'].includes(matchedSub.status)
    : false;

  return {
    configured: true,
    priceIdConfigured: Boolean(priceId),
    priceId,
    customerId,
    hasSubscription: isActiveState,
    subscriptionId: matchedSub ? matchedSub.id : null,
    status: matchedSub ? matchedSub.status : 'none',
    cancelAtPeriodEnd: matchedSub ? Boolean(matchedSub.cancel_at_period_end) : false,
    currentPeriodEnd: matchedSub ? getSubscriptionPeriodEndIso(matchedSub) : null,
    planName: 'Market Membership',
    monthlyAmountUSD: 2,
    defaultPaymentMethod: defaultPm,
  };
}

let cachedMembershipPriceId: string | null = null;

async function resolveMembershipPriceId(stripe: Stripe): Promise<string> {
  const envPriceId = getMembershipPriceId();
  if (envPriceId) return envPriceId;
  if (cachedMembershipPriceId) return cachedMembershipPriceId;

  const lookupKey = 'final_finance_market_membership_2usd_monthly';
  const existing = await stripe.prices.list({
    lookup_keys: [lookupKey],
    active: true,
    limit: 1,
  });
  if (existing.data.length > 0) {
    cachedMembershipPriceId = existing.data[0].id;
    return cachedMembershipPriceId;
  }

  const created = await stripe.prices.create({
    currency: 'usd',
    unit_amount: 200,
    recurring: { interval: 'month' },
    lookup_key: lookupKey,
    product_data: {
      name: 'Market Membership',
      metadata: {
        membership: 'market_membership',
      },
    },
    metadata: {
      membership: 'market_membership',
    },
  });
  cachedMembershipPriceId = created.id;
  return cachedMembershipPriceId;
}

export async function startMarketMembershipWithSavedMethod(params: {
  customerId: string;
  paymentMethodId?: string;
}): Promise<{
  membership: MarketMembershipStatus;
  requiresAction: boolean;
  clientSecret?: string | null;
}> {
  const stripe = getStripeClient();
  const priceId = await resolveMembershipPriceId(stripe);

  // Avoid duplicate active subscriptions
  const currentStatus = await getCustomerMembershipStatus(params.customerId);
  if (currentStatus.hasSubscription && (currentStatus.status === 'active' || currentStatus.status === 'trialing')) {
    return { membership: currentStatus, requiresAction: false };
  }

  let resolvedPmId: string | null = null;
  if (params.paymentMethodId) {
    await assertPaymentMethodOwnership(params.customerId, params.paymentMethodId);
    resolvedPmId = params.paymentMethodId;
  } else {
    const methods = await listCustomerPaymentMethods(params.customerId);
    resolvedPmId =
      methods.defaultPaymentMethodId ||
      methods.paymentMethods[0]?.id ||
      null;
  }

  if (!resolvedPmId) {
    throw new Error('No saved payment method found. Please link a bank account or card under "Banks, Cards & Crypto" first.');
  }

  // Ensure customer default payment method is set so recurring renewals succeed
  await stripe.customers.update(params.customerId, {
    invoice_settings: { default_payment_method: resolvedPmId },
  });

  const subscription = await stripe.subscriptions.create({
    customer: params.customerId,
    items: [{ price: priceId, quantity: 1 }],
    default_payment_method: resolvedPmId,
    payment_behavior: 'allow_incomplete',
    payment_settings: {
      save_default_payment_method: 'on_subscription',
    },
    expand: ['latest_invoice.payment_intent'],
    metadata: {
      membership: 'market_membership',
    },
  });

  const latestInvoice = subscription.latest_invoice as
    | (Stripe.Invoice & { payment_intent?: Stripe.PaymentIntent | string | null })
    | string
    | null;
  const paymentIntent =
    latestInvoice && typeof latestInvoice === 'object' && latestInvoice.payment_intent && typeof latestInvoice.payment_intent === 'object'
      ? latestInvoice.payment_intent
      : null;

  const requiresAction =
    subscription.status === 'incomplete' &&
    Boolean(paymentIntent?.client_secret) &&
    paymentIntent?.status === 'requires_action';

  const membership = await getCustomerMembershipStatus(params.customerId);
  return {
    membership,
    requiresAction,
    clientSecret: requiresAction ? paymentIntent?.client_secret || null : null,
  };
}

export async function createMarketMembershipCheckoutSession(params: {
  customerId: string;
  successUrl?: string;
  cancelUrl?: string;
  requestOrigin?: string;
}) {
  const stripe = getStripeClient();
  const savedMethods = await listCustomerPaymentMethods(params.customerId);
  if (savedMethods.paymentMethods.length === 0) {
    throw new Error(
      'No bank account or card is linked with Stripe. Please link a bank account or payment card under the "Banks, Cards & Crypto" tab first.'
    );
  }

  const priceId = await resolveMembershipPriceId(stripe);

  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    customer: params.customerId,
    line_items: [{ price: priceId, quantity: 1 }],
    subscription_data: {
      metadata: {
        membership: 'market_membership',
      },
    },
    metadata: {
      membership: 'market_membership',
    },
    success_url: sanitizeSafeUrl(
      params.successUrl,
      '/?stripe_membership=success&tab=verification',
      params.requestOrigin
    ),
    cancel_url: sanitizeSafeUrl(
      params.cancelUrl,
      '/?stripe_membership=cancelled&tab=verification',
      params.requestOrigin
    ),
  });

  return {
    id: session.id,
    url: session.url,
    status: session.status,
  };
}

export async function updateMarketMembershipCancellation(params: {
  customerId: string;
  subscriptionId: string;
  cancelAtPeriodEnd: boolean;
}): Promise<MarketMembershipStatus> {
  const stripe = getStripeClient();
  if (!params.subscriptionId || !params.subscriptionId.startsWith('sub_')) {
    throw new Error('Valid subscriptionId is required.');
  }
  const sub = await stripe.subscriptions.retrieve(params.subscriptionId);
  const subCustomer = typeof sub.customer === 'string' ? sub.customer : sub.customer?.id;
  if (subCustomer !== params.customerId) {
    throw new Error('Forbidden: subscription does not belong to your Stripe customer profile.');
  }

  await stripe.subscriptions.update(params.subscriptionId, {
    cancel_at_period_end: params.cancelAtPeriodEnd,
  });

  return getCustomerMembershipStatus(params.customerId);
}

// ============================================================================
// EXISTING PLATFORM STRIPE ROUTES (Payments, Billing Portal, Connect, Invoicing, Tax)
// ============================================================================

// 1. Payments: PaymentIntent
export async function createPaymentIntent(params: {
  amountCents: number;
  currency?: string;
  customerId?: string;
  description?: string;
  metadata?: Record<string, string>;
}) {
  const stripe = getStripeClient();
  const amount = assertPositiveInt(params.amountCents, 'amountCents');
  const currency = sanitizeCurrency(params.currency);

  const intent = await stripe.paymentIntents.create({
    amount,
    currency,
    customer: params.customerId || undefined,
    description: params.description || 'Final Finance Platform Payment',
    automatic_payment_methods: { enabled: true },
    metadata: params.metadata || {},
  });

  return {
    id: intent.id,
    clientSecret: intent.client_secret,
    status: intent.status,
    amount: intent.amount,
    currency: intent.currency,
  };
}

// 2. Payments & Billing: Checkout Session (one-time payment or recurring subscription + automatic tax)
export async function createCheckoutSession(params: {
  mode: 'payment' | 'subscription' | 'setup';
  priceId?: string;
  unitAmountCents?: number;
  currency?: string;
  productName?: string;
  quantity?: number;
  customerId?: string;
  customerEmail?: string;
  automaticTax?: boolean;
  successUrl?: string;
  cancelUrl?: string;
  requestOrigin?: string;
}) {
  const stripe = getStripeClient();
  if (params.mode === 'setup') {
    if (!params.customerId) {
      throw new Error('customerId is required for setup Checkout Session.');
    }
    return createSetupCheckoutSession({
      customerId: params.customerId,
      successUrl: params.successUrl,
      cancelUrl: params.cancelUrl,
      requestOrigin: params.requestOrigin,
    });
  }

  const mode = params.mode === 'subscription' ? 'subscription' : 'payment';
  const quantity = params.quantity ? assertPositiveInt(params.quantity, 'quantity') : 1;

  const resolvedPriceId = params.priceId || (mode === 'subscription' ? getMembershipPriceId() || undefined : undefined);

  const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = resolvedPriceId
    ? [{ price: resolvedPriceId, quantity }]
    : [
        {
          price_data: {
            currency: (params.currency || 'usd').trim().toLowerCase(),
            product_data: {
              name: params.productName || 'Final Finance Service',
            },
            unit_amount: assertPositiveInt(params.unitAmountCents, 'unitAmountCents'),
            ...(mode === 'subscription' ? { recurring: { interval: 'month' } } : {}),
          },
          quantity,
        },
      ];

  const session = await stripe.checkout.sessions.create({
    mode,
    line_items: lineItems,
    customer: params.customerId || undefined,
    customer_email: !params.customerId ? params.customerEmail : undefined,
    automatic_tax: { enabled: params.automaticTax !== false },
    success_url: sanitizeSafeUrl(params.successUrl, '/?stripe_checkout=success', params.requestOrigin),
    cancel_url: sanitizeSafeUrl(params.cancelUrl, '/?stripe_checkout=cancelled', params.requestOrigin),
  });

  return {
    id: session.id,
    url: session.url,
    status: session.status,
  };
}

// 3. Billing: Customer Portal Session
export async function createBillingPortalSession(params: {
  customerId: string;
  returnUrl?: string;
  requestOrigin?: string;
}) {
  const stripe = getStripeClient();
  if (!params.customerId || typeof params.customerId !== 'string') {
    throw new Error('customerId is required.');
  }

  const portal = await stripe.billingPortal.sessions.create({
    customer: params.customerId,
    return_url: sanitizeSafeUrl(params.returnUrl, '/', params.requestOrigin),
  });

  return {
    id: portal.id,
    url: portal.url,
  };
}

// 4. Connect: Connected Account & Onboarding Link
export async function createConnectedAccount(params: {
  email: string;
  country?: string;
  businessType?: 'individual' | 'company';
}) {
  const stripe = getStripeClient();
  if (!params.email || typeof params.email !== 'string') {
    throw new Error('Valid email is required for Connect account creation.');
  }

  const account = await stripe.accounts.create({
    type: 'express',
    country: (params.country || 'US').trim().toUpperCase(),
    email: params.email.trim(),
    business_type: params.businessType || 'individual',
    capabilities: {
      card_payments: { requested: true },
      transfers: { requested: true },
    },
  });

  return {
    accountId: account.id,
    chargesEnabled: account.charges_enabled,
    payoutsEnabled: account.payouts_enabled,
  };
}

export async function createConnectOnboardingLink(params: {
  accountId: string;
  refreshUrl?: string;
  returnUrl?: string;
  requestOrigin?: string;
}) {
  const stripe = getStripeClient();
  if (!params.accountId || typeof params.accountId !== 'string') {
    throw new Error('accountId is required.');
  }

  const link = await stripe.accountLinks.create({
    account: params.accountId,
    refresh_url: sanitizeSafeUrl(params.refreshUrl, '/?connect=refresh', params.requestOrigin),
    return_url: sanitizeSafeUrl(params.returnUrl, '/?connect=complete', params.requestOrigin),
    type: 'account_onboarding',
  });

  return {
    url: link.url,
    expiresAt: link.expires_at,
  };
}

// 5. Invoicing: Create Invoice Item, Draft Invoice, Finalize & Send
export async function createAndFinalizeInvoice(params: {
  customerId: string;
  description: string;
  amountCents: number;
  currency?: string;
  daysUntilDue?: number;
  automaticTax?: boolean;
}) {
  const stripe = getStripeClient();
  if (!params.customerId || typeof params.customerId !== 'string') {
    throw new Error('customerId is required.');
  }

  const amount = assertPositiveInt(params.amountCents, 'amountCents');
  const currency = (params.currency || 'usd').trim().toLowerCase();

  const invoice = await stripe.invoices.create({
    customer: params.customerId,
    collection_method: 'send_invoice',
    days_until_due: params.daysUntilDue && params.daysUntilDue > 0 ? Math.min(90, Math.floor(params.daysUntilDue)) : 30,
    automatic_tax: { enabled: params.automaticTax !== false },
  });

  await stripe.invoiceItems.create({
    customer: params.customerId,
    invoice: invoice.id,
    amount,
    currency,
    description: params.description || 'Platform Invoice Line Item',
  });

  const finalized = await stripe.invoices.finalizeInvoice(invoice.id);

  return {
    id: finalized.id,
    status: finalized.status,
    hostedInvoiceUrl: finalized.hosted_invoice_url,
    invoicePdf: finalized.invoice_pdf,
    amountDue: finalized.amount_due,
    currency: finalized.currency,
  };
}

// 6. Tax: Calculate Stripe Tax
export async function calculateStripeTax(params: {
  currency?: string;
  amountCents: number;
  reference?: string;
  taxCode?: string;
  customerAddress: {
    line1?: string;
    city?: string;
    state?: string;
    postal_code: string;
    country: string;
  };
}) {
  const stripe = getStripeClient();
  const amount = assertPositiveInt(params.amountCents, 'amountCents');
  if (!params.customerAddress?.country || !params.customerAddress?.postal_code) {
    throw new Error('customerAddress.country and customerAddress.postal_code are required.');
  }

  const calculation = await stripe.tax.calculations.create({
    currency: (params.currency || 'usd').trim().toLowerCase(),
    line_items: [
      {
        amount,
        reference: params.reference || 'L1',
        tax_code: params.taxCode || 'txcd_10000000',
      },
    ],
    customer_details: {
      address: {
        line1: params.customerAddress.line1,
        city: params.customerAddress.city,
        state: params.customerAddress.state,
        postal_code: params.customerAddress.postal_code,
        country: params.customerAddress.country.trim().toUpperCase(),
      },
      address_source: 'shipping',
    },
  });

  return {
    id: calculation.id,
    amountTotal: calculation.amount_total,
    taxAmountExclusive: calculation.tax_amount_exclusive,
    taxAmountInclusive: calculation.tax_amount_inclusive,
    currency: calculation.currency,
    taxBreakdown: calculation.tax_breakdown,
  };
}

// 7. Webhooks: Signature Verification & Event Processing
export function verifyStripeWebhookEvent(rawBody: Buffer, signature: string): Stripe.Event {
  const webhookCheck = validateStripeWebhookSecret();
  if (!webhookCheck.valid || !webhookCheck.secret) {
    throw new StripeConfigError(webhookCheck.reason || 'STRIPE_WEBHOOK_SECRET is not configured.');
  }
  const stripe = getStripeClient();
  return stripe.webhooks.constructEvent(rawBody, signature, webhookCheck.secret);
}

export async function handleStripeWebhookEvent(event: Stripe.Event): Promise<void> {
  const stripe = getStripeClient();

  switch (event.type) {
    case 'setup_intent.succeeded': {
      const setupIntent = event.data.object as Stripe.SetupIntent;
      const customerId =
        typeof setupIntent.customer === 'string'
          ? setupIntent.customer
          : setupIntent.customer?.id;
      const pmId =
        typeof setupIntent.payment_method === 'string'
          ? setupIntent.payment_method
          : setupIntent.payment_method?.id;
      if (customerId && pmId) {
        try {
          const currentDefault = await getDefaultPaymentMethodId(customerId);
          if (!currentDefault) {
            await stripe.customers.update(customerId, {
              invoice_settings: { default_payment_method: pmId },
            });
          }
        } catch {
          // Non-fatal if customer was already updated
        }
      }
      break;
    }

    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      const customerId =
        typeof session.customer === 'string'
          ? session.customer
          : session.customer?.id;
      if (session.mode === 'setup' && customerId && session.setup_intent) {
        const setupIntentId =
          typeof session.setup_intent === 'string'
            ? session.setup_intent
            : session.setup_intent.id;
        try {
          const si = await stripe.setupIntents.retrieve(setupIntentId);
          const pmId =
            typeof si.payment_method === 'string'
              ? si.payment_method
              : si.payment_method?.id;
          if (pmId) {
            const currentDefault = await getDefaultPaymentMethodId(customerId);
            if (!currentDefault) {
              await stripe.customers.update(customerId, {
                invoice_settings: { default_payment_method: pmId },
              });
            }
          }
        } catch {
          // Non-fatal
        }
      }
      break;
    }

    case 'customer.subscription.created':
    case 'customer.subscription.updated':
    case 'customer.subscription.deleted':
    case 'invoice.paid':
    case 'invoice.payment_failed':
      // Stripe remains authoritative for subscription and invoice state;
      // `/api/stripe/membership/status` queries live subscription state directly.
      break;

    default:
      break;
  }
}
