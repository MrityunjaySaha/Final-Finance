import React, { useState } from 'react';
import { Crown, Search, ShieldAlert, ShieldCheck, UserX, UserCheck, Mail, AtSign, MessageSquare, AlertCircle, FolderHeart, Users } from 'lucide-react';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { getAdminEscalations, updateEscalationStatus, AdminEscalation } from '../services/feedbackService';
import { getAdminGroups, AdminGroup, AdminMember, getAdminMembers, updateAdminMemberTitle, setAdminMemberStatus } from '../services/adminGroupService';
import { AdminGroupsTab } from './admin/AdminGroupsTab';
import { AdminGroupAssignModal } from './admin/AdminGroupAssignModal';
import { AdminDeactivateConfirmModal } from './admin/AdminDeactivateConfirmModal';
import { AdminJobTitleModal } from './admin/AdminJobTitleModal';
import { AdminEscalationConfirmModal } from './admin/AdminEscalationConfirmModal';

interface SuperAdminPageProps {
  currentUser: AuthSession;
  onNavigateToAdmin?: () => void;
  onNavigateToVaults?: () => void;
  onNavigateToMarketplace?: () => void;
}

export const SuperAdminPage: React.FC<SuperAdminPageProps> = ({
  currentUser,
}) => {
  const { addToast, addNotification } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [adminTab, setAdminTab] = useState<'active' | 'deactivated' | 'groups' | 'escalations'>('active');
  
  const [adminGroups, setAdminGroupsList] = useState<AdminGroup[]>(() => getAdminGroups());
  const [selectedAdminForGrouping, setSelectedAdminForGrouping] = useState<AdminMember | null>(null);
  const [adminToDeactivate, setAdminToDeactivate] = useState<AdminMember | null>(null);
  const [adminForTitleEdit, setAdminForTitleEdit] = useState<AdminMember | null>(null);

  const refreshGroups = () => {
    setAdminGroupsList(getAdminGroups());
  };

  const [escalations, setEscalations] = useState<AdminEscalation[]>(() => getAdminEscalations());
  const [replyTexts, setReplyTexts] = useState<{[id: string]: string}>({});
  const [escalationActionConfirm, setEscalationActionConfirm] = useState<{
    escalation: AdminEscalation;
    targetStatus: 'investigating' | 'resolved';
  } | null>(null);

  const handleConfirmEscalationAction = () => {
    if (!escalationActionConfirm) return;
    const { escalation, targetStatus } = escalationActionConfirm;
    handleResolveEscalation(escalation.id, targetStatus);
    setEscalationActionConfirm(null);
  };

  const handleResolveEscalation = (id: string, status: AdminEscalation['status']) => {
    const reply = replyTexts[id] || '';
    const success = updateEscalationStatus(id, status, reply.trim() ? reply.trim() : undefined);
    if (success) {
      setEscalations(getAdminEscalations());
      addToast({
        type: 'success',
        title: 'Escalation Updated',
        message: `Escalation report status updated to ${status}.`,
      });
      // Register global system notification
      const targetEsc = escalations.find(e => e.id === id);
      const subjectLabel = targetEsc ? targetEsc.subject : 'System advisory';
      addNotification({
        title: `Advisory Status: ${status.toUpperCase()}`,
        description: `"${subjectLabel}" updated to [${status.toUpperCase()}] by Super Admin.`,
        type: 'system',
        targetTab: 'admin' // Redirect to Admin/SuperAdmin Page
      });
    }
  };

  const [admins, setAdmins] = useState<AdminMember[]>(() => getAdminMembers());

  const handleInitiateDeactivate = (admin: AdminMember) => {
    setAdminToDeactivate(admin);
  };

  const handleConfirmDeactivate = () => {
    if (!adminToDeactivate) return;
    const updated = setAdminMemberStatus(adminToDeactivate.id, 'deactivated');
    setAdmins(updated);
    addToast({
      type: 'error',
      title: 'Admin Deactivated',
      message: `Account for ${adminToDeactivate.name} has been deactivated.`,
    });
    setAdminToDeactivate(null);
  };

  const handleReactivate = (admin: AdminMember) => {
    const updated = setAdminMemberStatus(admin.id, 'active');
    setAdmins(updated);
    addToast({
      type: 'success',
      title: 'Admin Reactivated',
      message: `Account for ${admin.name} has been successfully reactivated.`,
    });
  };

  const handleSaveJobTitle = (title: string) => {
    if (!adminForTitleEdit) return;
    const updated = updateAdminMemberTitle(adminForTitleEdit.id, title);
    setAdmins(updated);
    addToast({
      type: 'success',
      title: 'Job Title Updated',
      message: `Job title for ${adminForTitleEdit.name} set to "${title}".`,
    });
    setAdminForTitleEdit(null);
  };

  const filteredAdmins = admins.filter(
    (adm) =>
      adm.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      adm.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      adm.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeAdmins = filteredAdmins.filter((a) => a.status === 'active');
  const deactivatedAdmins = filteredAdmins.filter((a) => a.status === 'deactivated');

  const activeCount = admins.filter((a) => a.status === 'active').length;
  const deactivatedCount = admins.filter((a) => a.status === 'deactivated').length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-16 font-sans">
      {/* Header Banner - Compact & Clean */}
      <div className="border-b border-slate-200 bg-white shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 sm:py-4">
          <div className="relative flex items-center justify-center min-h-[40px]">
            {/* Centered Title */}
            <div className="flex items-center justify-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 shadow-xs shrink-0">
                <Crown className="w-5 h-5 stroke-[2.2]" />
              </div>
              <h1 className="font-serif text-lg sm:text-xl font-bold text-slate-900 tracking-tight whitespace-nowrap text-center">
                Super Admin Control
              </h1>
            </div>

            {/* Session Info (Absolute Right) */}
            <div className="hidden sm:flex items-center gap-2 absolute right-0">
              <div className="text-right">
                <p className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Super Admin Session</p>
                <p className="text-xs font-mono text-amber-600 font-semibold">{currentUser?.email || 'ranmaanimaker@gmail.com'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 sm:mt-5 space-y-4">
        {/* Search & Tabs Bar */}
        <div className="bg-white rounded-2xl border border-slate-200 p-3 sm:p-4 flex flex-col lg:flex-row items-center justify-between gap-3 shadow-xs">
          <div className="relative w-full lg:max-w-xs">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={adminTab === 'groups' ? 'Search in admin directory...' : 'Search admins by name, email, or handle...'}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 transition-colors"
            />
          </div>

          {/* Side-by-Side Tabs: Active, Deactivated, Groups (under deactivated, before advisories), Advisories */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full lg:w-auto">
            <button
              type="button"
              onClick={() => setAdminTab('active')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                adminTab === 'active'
                  ? 'bg-emerald-50 text-emerald-900 border-emerald-300 shadow-xs ring-2 ring-emerald-500/20'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <span className="truncate">Active</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[11px] font-mono font-bold shrink-0 ${
                adminTab === 'active' ? 'bg-emerald-200/80 text-emerald-900' : 'bg-slate-100 text-slate-700'
              }`}>
                {activeAdmins.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('deactivated')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                adminTab === 'deactivated'
                  ? 'bg-rose-50 text-rose-900 border-rose-300 shadow-xs ring-2 ring-rose-500/20'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
              <span className="truncate">Deactivated</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[11px] font-mono font-bold shrink-0 ${
                adminTab === 'deactivated' ? 'bg-rose-200/80 text-rose-900' : 'bg-slate-100 text-slate-700'
              }`}>
                {deactivatedAdmins.length}
              </span>
            </button>

            {/* Tab: Groups (under deactivated, but before advisories) */}
            <button
              type="button"
              onClick={() => setAdminTab('groups')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                adminTab === 'groups'
                  ? 'bg-indigo-50 text-indigo-950 border-indigo-300 shadow-xs ring-2 ring-indigo-500/20'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <FolderHeart className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span className="truncate">Groups</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[11px] font-mono font-bold shrink-0 ${
                adminTab === 'groups' ? 'bg-indigo-200/80 text-indigo-900' : 'bg-slate-100 text-slate-700'
              }`}>
                {adminGroups.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setAdminTab('escalations')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                adminTab === 'escalations'
                  ? 'bg-amber-50 text-amber-950 border-amber-300 shadow-xs ring-2 ring-amber-500/20'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <span className="truncate">Advisories</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[11px] font-mono font-bold shrink-0 ${
                adminTab === 'escalations' ? 'bg-amber-200/80 text-amber-950' : 'bg-slate-100 text-slate-700'
              }`}>
                {escalations.filter(e => e.status === 'pending').length}
              </span>
            </button>
          </div>
        </div>

        {/* Active Tab Content */}
        {adminTab === 'active' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-emerald-50/40">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <h2 className="font-serif text-base font-bold text-slate-900">Active Administrators</h2>
              </div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-100/80 px-2.5 py-1 rounded-full border border-emerald-200">
                {activeAdmins.length} {activeAdmins.length === 1 ? 'Member' : 'Members'}
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {activeAdmins.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  No active admin members found matching "{searchQuery}"
                </div>
              ) : (
                activeAdmins.map((admin) => (
                  <div key={admin.id} className="p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/80 transition-colors">
                    <div className="flex items-start sm:items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold font-serif text-base border shrink-0 bg-amber-50 text-amber-700 border-amber-200">
                        {admin.name.charAt(0)}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-slate-900">{admin.name}</span>
                          <span className="font-mono text-xs text-amber-600">{admin.handle}</span>
                          
                          {/* System Role: everyone is Admin besides Super Admin */}
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${
                            admin.role === 'super_admin'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-blue-50 text-blue-700 border-blue-200'
                          }`}>
                            {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                          </span>

                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Active
                          </span>
                        </div>

                        <div className="flex items-center gap-4 text-xs text-slate-500 flex-wrap">
                          <span className="flex items-center gap-1">
                            <Mail className="w-3.5 h-3.5 text-slate-400" />
                            {admin.email}
                          </span>
                          <span>•</span>
                          <span>{admin.permissionsCount} Permissions</span>
                          <span>•</span>
                          <span>Last Active: {admin.lastActive}</span>
                        </div>

                        {/* Assigned Admin Groups */}
                        {(() => {
                          const assigned = adminGroups.filter((g) => g.adminIds.includes(admin.id));
                          if (assigned.length === 0) return null;
                          return (
                            <div className="flex items-center gap-1.5 flex-wrap pt-1">
                              <span className="text-[10px] font-mono text-slate-400">Groups:</span>
                              {assigned.map((g) => {
                                const secondaryTitle = g.memberSecondaryTitles?.[admin.id];
                                return (
                                  <span
                                    key={g.id}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border"
                                    style={{
                                      backgroundColor: `${g.color}15`,
                                      borderColor: `${g.color}40`,
                                      color: g.color,
                                    }}
                                  >
                                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: g.color }} />
                                    <span>{g.name}</span>
                                    {secondaryTitle && (
                                      <span className="font-medium opacity-90 text-[9px] border-l pl-1 border-current ml-0.5">
                                        {secondaryTitle}
                                      </span>
                                    )}
                                  </span>
                                );
                              })}
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    {/* Actions: Group and Deactivate side-by-side, centered */}
                    <div className="flex items-center justify-center gap-2 self-center shrink-0">
                      {/* Group Assignment Button */}
                      <button
                        type="button"
                        onClick={() => setSelectedAdminForGrouping(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 hover:border-indigo-200 shrink-0"
                        title="Assign to groups (can belong to multiple groups)"
                      >
                        <FolderHeart className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Group</span>
                        {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length > 0 && (
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-mono font-bold leading-none">
                            {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length}
                          </span>
                        )}
                      </button>

                      {admin.role === 'super_admin' ? (
                        <span className="text-[11px] text-amber-700 font-semibold italic px-3 py-1.5 bg-amber-50 rounded-xl border border-amber-200 shrink-0 flex items-center justify-center text-center">
                          Root Authority Protected
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleInitiateDeactivate(admin)}
                          className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 shrink-0"
                          title="Deactivate admin account (requires confirmation)"
                        >
                          <UserX className="w-3.5 h-3.5" />
                          <span>Deactivate</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Deactivated Tab Content */}
        {adminTab === 'deactivated' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-rose-50/40">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <h2 className="font-serif text-base font-bold text-slate-900">Deactivated Administrators</h2>
              </div>
              <span className="text-xs font-bold text-rose-700 bg-rose-100/80 px-2.5 py-1 rounded-full border border-rose-200">
                {deactivatedAdmins.length} {deactivatedAdmins.length === 1 ? 'Member' : 'Members'}
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {deactivatedAdmins.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  No deactivated admin accounts found matching "{searchQuery}"
                </div>
              ) : (
                deactivatedAdmins.map((admin) => (
                  <div key={admin.id} className="p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/80 transition-colors opacity-90">
                    <div className="flex items-start sm:items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center font-bold font-serif text-base border shrink-0 bg-slate-100 text-slate-400 border-slate-200">
                        {admin.name.charAt(0)}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-slate-900">{admin.name}</span>
                          <span className="font-mono text-xs text-slate-500">{admin.handle}</span>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${
                            admin.role === 'super_admin'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}>
                            {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                          </span>

                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-200">
                            Deactivated
                          </span>
                        </div>

                        <div className="flex items-center gap-4 text-xs text-slate-500 flex-wrap">
                          <span className="flex items-center gap-1">
                            <Mail className="w-3.5 h-3.5 text-slate-400" />
                            {admin.email}
                          </span>
                          <span>•</span>
                          <span>{admin.permissionsCount} Permissions</span>
                          <span>•</span>
                          <span>Last Active: {admin.lastActive}</span>
                        </div>

                        {/* Assigned Admin Groups */}
                        {(() => {
                          const assigned = adminGroups.filter((g) => g.adminIds.includes(admin.id));
                          if (assigned.length === 0) return null;
                          return (
                            <div className="flex items-center gap-1.5 flex-wrap pt-1">
                              <span className="text-[10px] font-mono text-slate-400">Groups:</span>
                              {assigned.map((g) => {
                                const secondaryTitle = g.memberSecondaryTitles?.[admin.id];
                                return (
                                  <span
                                    key={g.id}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border"
                                    style={{
                                      backgroundColor: `${g.color}15`,
                                      borderColor: `${g.color}40`,
                                      color: g.color,
                                    }}
                                  >
                                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: g.color }} />
                                    <span>{g.name}</span>
                                    {secondaryTitle && (
                                      <span className="font-medium opacity-90 text-[9px] border-l pl-1 border-current ml-0.5">
                                        {secondaryTitle}
                                      </span>
                                    )}
                                  </span>
                                );
                              })}
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    {/* Actions: Group and Reactivate side-by-side, centered */}
                    <div className="flex items-center justify-center gap-2 self-center shrink-0">
                      {/* Group Assignment Button */}
                      <button
                        type="button"
                        onClick={() => setSelectedAdminForGrouping(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 hover:border-indigo-200 shrink-0"
                        title="Assign to groups (can belong to multiple groups)"
                      >
                        <FolderHeart className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Group</span>
                        {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length > 0 && (
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-mono font-bold leading-none">
                            {adminGroups.filter((g) => g.adminIds.includes(admin.id)).length}
                          </span>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleReactivate(admin)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 shrink-0"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Reactivate</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab: Groups (under deactivated, but before advisories) */}
        {adminTab === 'groups' && (
          <AdminGroupsTab
            groups={adminGroups}
            allAdmins={admins}
            onRefresh={refreshGroups}
            onToast={addToast}
          />
        )}

        {/* Tab: Escalation Reports */}
        {adminTab === 'escalations' && (
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-amber-50/40">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-500" />
                <h2 className="font-serif text-base font-bold text-slate-900">Priority Admin Escalations</h2>
              </div>
              <span className="text-xs font-bold text-amber-700 bg-amber-100/80 px-2.5 py-1 rounded-full border border-amber-200">
                {escalations.length} Active Bulletins
              </span>
            </div>

            <div className="divide-y divide-slate-100 p-6 space-y-6 bg-slate-50/30">
              {escalations.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No active admin escalations logged.
                </div>
              ) : (
                escalations.map((esc) => (
                  <div key={esc.id} className="p-5 rounded-2xl border border-slate-200 bg-white hover:shadow-2xs transition-shadow space-y-4">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-slate-900">{esc.subject}</span>
                          <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                            esc.severity === 'critical' ? 'bg-red-100 text-red-800' :
                            esc.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                            esc.severity === 'medium' ? 'bg-amber-100 text-amber-800' :
                            'bg-slate-100 text-slate-800'
                          }`}>
                            {esc.severity}
                          </span>
                          <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                            esc.status === 'resolved' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                            esc.status === 'investigating' ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' :
                            'bg-amber-100 text-amber-800 border border-amber-200'
                          }`}>
                            {esc.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          Escalated by <span className="font-semibold text-slate-700">{esc.adminName}</span> ({esc.adminEmail}) • {new Date(esc.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <span className="text-xs font-mono text-slate-400 font-bold bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200">{esc.id}</span>
                    </div>

                    <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl">
                      <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap font-sans">{esc.message}</p>
                    </div>

                    {/* Action Panel for Super Admin to respond */}
                    <div className="pt-3 border-t border-slate-100 space-y-3">
                      <div>
                        {esc.status === 'resolved' ? (
                          <div className="space-y-3">
                            {(esc.investigatingNotes || esc.resolvedNotes || esc.superAdminNotes) ? (
                              <>
                                {esc.investigatingNotes && (
                                  <div className="space-y-1">
                                    <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">Investigating Response</label>
                                    <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl">
                                      <p className="text-xs text-slate-700 italic">"{esc.investigatingNotes}"</p>
                                    </div>
                                  </div>
                                )}
                                {esc.resolvedNotes && (
                                  <div className="space-y-1">
                                    <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">Resolution Notes</label>
                                    <div className="p-3 bg-emerald-50/50 border border-emerald-100 rounded-xl">
                                      <p className="text-xs text-slate-700 italic">"{esc.resolvedNotes}"</p>
                                    </div>
                                  </div>
                                )}
                                {esc.superAdminNotes && !esc.investigatingNotes && !esc.resolvedNotes && (
                                  <div className="space-y-1">
                                    <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">Super Admin Response</label>
                                    <div className="p-3 bg-amber-50/50 border border-amber-100 rounded-xl">
                                      <p className="text-xs text-slate-700 italic">"{esc.superAdminNotes}"</p>
                                    </div>
                                  </div>
                                )}
                              </>
                            ) : (
                              <div className="space-y-1">
                                <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">Cryptographic Response / Resolving Notes</label>
                                <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-center">
                                  <p className="text-xs text-slate-400 italic">No notes added.</p>
                                </div>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {esc.investigatingNotes && (
                              <div className="space-y-1">
                                <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">Investigating Response Sent</label>
                                <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl">
                                  <p className="text-xs text-slate-700 italic">"{esc.investigatingNotes}"</p>
                                </div>
                              </div>
                            )}

                            {/* "Mark as Investigating" centered above the written response box */}
                            {esc.status !== 'investigating' && (
                              <div className="flex justify-center">
                                <button
                                  type="button"
                                  onClick={() => setEscalationActionConfirm({ escalation: esc, targetStatus: 'investigating' })}
                                  className="px-5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
                                >
                                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-ping"></span>
                                  <span>Mark as Investigating</span>
                                </button>
                              </div>
                            )}

                            {/* Written Response Input Box */}
                            <div className="space-y-1">
                              <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">Resolving Response / Notes (Saved automatically on status transition)</label>
                              <input
                                type="text"
                                value={replyTexts[esc.id] || ''}
                                onChange={(e) => setReplyTexts(prev => ({ ...prev, [esc.id]: e.target.value }))}
                                placeholder="Write instructions, authorization codes, Swiss sweep overrides, or resolution details..."
                                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:ring-1 focus:ring-amber-500 bg-white"
                              />
                            </div>

                            {/* "Resolve Advisory & Close" centered under the written response box */}
                            <div className="flex justify-center">
                              <button
                                type="button"
                                onClick={() => setEscalationActionConfirm({ escalation: esc, targetStatus: 'resolved' })}
                                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
                              >
                                <span>Resolve Advisory &amp; Close</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modal: Group Assignment for an individual admin */}
      {selectedAdminForGrouping && (
        <AdminGroupAssignModal
          admin={selectedAdminForGrouping}
          allGroups={adminGroups}
          onClose={() => setSelectedAdminForGrouping(null)}
          onGroupsUpdated={refreshGroups}
          onToast={addToast}
        />
      )}

      {/* Modal: Job Title Assignment */}
      {adminForTitleEdit && (
        <AdminJobTitleModal
          admin={adminForTitleEdit}
          onClose={() => setAdminForTitleEdit(null)}
          onSave={handleSaveJobTitle}
        />
      )}

      {/* Modal: Confirm Deactivation */}
      {adminToDeactivate && (
        <AdminDeactivateConfirmModal
          admin={adminToDeactivate}
          onClose={() => setAdminToDeactivate(null)}
          onConfirm={handleConfirmDeactivate}
        />
      )}

      {/* Modal: Confirm Escalation Action (Mark Investigating / Resolve & Close) */}
      {escalationActionConfirm && (
        <AdminEscalationConfirmModal
          escalation={escalationActionConfirm.escalation}
          targetStatus={escalationActionConfirm.targetStatus}
          notes={replyTexts[escalationActionConfirm.escalation.id]}
          onClose={() => setEscalationActionConfirm(null)}
          onConfirm={handleConfirmEscalationAction}
        />
      )}
    </div>
  );
};


