export const TWEETING_MAX_CHARS = 500;

export interface TweetPollOption {
  id: string;
  text: string;
  votes: number;
}

export interface TweetPoll {
  id: string;
  question?: string;
  options: TweetPollOption[];
  voterIds: Record<string, string>; // userId -> optionId
  totalVotes: number;
  durationDays: number;
  expiresAt: number;
}

export interface TweetReply {
  id: string;
  tweetId: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  content: string;
  timestamp: string;
  createdAt: number;
  likes: number;
  likedBy: string[];
}

export interface TweetTradeReceipt {
  instrumentCategory: 'equity' | 'derivatives';
  assetName: string;
  ticker: string;
  side: 'buy' | 'sell';
  shares: number;
  price: number;
  totalValue: number;
  coinLabel: string;
  derivativeLabel?: string;
  strikePrice?: number;
  leverage?: number;
  expiryDate?: string;
  gainLossPercent?: number;
}

export interface TweetSharedPostComment {
  reviewerName: string;
  reviewerAvatar?: string;
  rating: number;
  comment: string;
  timestamp?: number;
}

export interface TweetSharedPost {
  listingId: string;
  title: string;
  description: string;
  category: string;
  itemType: 'good' | 'service' | 'auction' | 'campaign' | 'retail' | 'restaurant';
  statusLabel: string;
  sellerHandle: string;
  sellerName?: string;
  priceUSD: number;
  currencySymbol?: string;
  acceptedCurrencies?: string[];
  locationName?: string;
  locationId?: string;
  channelLabel?: string;
  imageUrl?: string;
  averageRating?: number;
  ratingCount?: number;
  userRating?: number;
  userComment?: string;
  comments?: TweetSharedPostComment[];
}

export interface TweetLinkPreview {
  url: string;
  domain: string;
  title: string;
  description: string;
  imageUrl?: string;
  fallbackImageUrl?: string;
  siteName?: string;
  authorName?: string;
  mediaType?: 'video' | 'audio' | 'article' | 'website';
  videoId?: string;
  faviconUrl?: string;
  resolved?: boolean;
}

export interface Tweet {
  id: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  isVerified?: boolean;
  content: string;
  createdAt: number;
  timestamp: string;
  photos?: string[];
  video?: string;
  videos?: string[];
  poll?: TweetPoll;
  tradeReceipt?: TweetTradeReceipt;
  sharedPost?: TweetSharedPost;
  quotedTweet?: Tweet;
  retweetedTweetId?: string;
  isDirectRetweet?: boolean;
  linkPreviews?: Record<string, TweetLinkPreview>;
  likes: number;
  likedBy: string[];
  retweets: number;
  retweetedBy: string[];
  bookmarks: number;
  bookmarkedBy: string[];
  views: number;
  replies: TweetReply[];
  hashtags: string[];
  mentions: string[];
  tickers?: string[];
  stockCurrencies?: Record<string, string>;
}

export interface SharedTweetCardData {
  tweetId: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  isVerified?: boolean;
  content: string;
  timestamp: string;
  createdAt: number;
  thumbnailUrl?: string;
  videoUrl?: string;
  contextLabel?: string;
  hashtags?: string[];
  tickers?: string[];
  likes?: number;
  retweets?: number;
  repliesCount?: number;
  quotedAuthorName?: string;
  quotedAuthorHandle?: string;
  quotedContent?: string;
}
