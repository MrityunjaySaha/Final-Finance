import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Twitter,
  Tag,
  Upload,
  Image as ImageIcon,
  Video,
  Store,
  UtensilsCrossed,
  Coins
} from 'lucide-react';
import { CatalogItem } from './PointOfSaleView';
import { createTweet, TWEETING_MAX_CHARS } from '../services/tweetingService';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';

interface SharePOSItemOnTweetingModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: CatalogItem | null;
  locationId: string;
  locationName: string;
  locationOwnerHandle?: string;
  channelLabel: string;
  acceptedCurrencies: string[];
  currentUser?: AuthSession | null;
}

export const SharePOSItemOnTweetingModal: React.FC<SharePOSItemOnTweetingModalProps> = ({
  isOpen,
  onClose,
  item,
  locationId,
  locationName,
  locationOwnerHandle,
  channelLabel,
  acceptedCurrencies,
  currentUser,
}) => {
  const { addToast } = useApp();
  const [note, setNote] = useState('');
  const [extraPhotos, setExtraPhotos] = useState<string[]>([]);
  const [extraVideos, setExtraVideos] = useState<string[]>([]);
  const [mediaUrlInput, setMediaUrlInput] = useState('');
  const [includeItemGalleryMedia, setIncludeItemGalleryMedia] = useState(true);
  const [isPosting, setIsPosting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setNote('');
      setExtraPhotos([]);
      setExtraVideos([]);
      setMediaUrlInput('');
      setIncludeItemGalleryMedia(true);
    }
  }, [isOpen, item?.id, channelLabel]);

  if (!isOpen || !item) return null;

  const authorId = currentUser?.id || currentUser?.uid || currentUser?.username || 'user_ranma';
  const authorName = currentUser?.name || 'Ranma';
  const authorHandle = (currentUser?.id || currentUser?.username || 'super_admin_ranma').replace(/^@/, '');
  const authorAvatar =
    currentUser?.avatarUrl ||
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80';

  const cleanCatTag = item.category.replace(/[^a-zA-Z0-9]/g, '') || 'StoreItem';
  const cleanCurrencyTag = item.currency.replace(/[^a-zA-Z0-9]/g, '') || 'AFNL';
  const suggestedHashtags = [
    '#FinalFinance',
    item.type === 'restaurant' ? '#RestaurantMenu' : '#RetailStore',
    `#${cleanCatTag}`,
    `#${cleanCurrencyTag}`,
  ];

  const primaryImage = item.image || (item.photos && item.photos[0]) || undefined;
  const itemExistingExtraPhotos = (item.photos || []).filter((p) => p && p !== primaryImage);
  const itemExistingVideos = (item.videos || []).filter(Boolean);

  const toggleHashtag = (tag: string) => {
    if (note.includes(tag)) {
      setNote((prev) => prev.replace(tag, '').replace(/\s{2,}/g, ' ').trim());
    } else {
      setNote((prev) => {
        const next = prev ? `${prev} ${tag}` : tag;
        return next.slice(0, TWEETING_MAX_CHARS);
      });
    }
  };

  const handleFilePick = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          if (file.type.startsWith('video/')) {
            setExtraVideos((prev) => [...prev, reader.result as string]);
          } else if (file.type.startsWith('image/')) {
            setExtraPhotos((prev) => [...prev, reader.result as string]);
          }
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleAttachMediaUrl = () => {
    const url = mediaUrlInput.trim();
    if (!url) return;
    if (/\.(mp4|webm|mov|ogg)(\?|$)/i.test(url) || url.startsWith('data:video/')) {
      setExtraVideos((prev) => [...prev, url]);
    } else {
      setExtraPhotos((prev) => [...prev, url]);
    }
    setMediaUrlInput('');
  };

  const handleShare = () => {
    if (isPosting) return;
    setIsPosting(true);

    try {
      const trimmedNote = note.trim();
      const defaultContent = `Checking out "${item.name}" (${channelLabel}) at ${locationName} — ${item.price.toLocaleString()} ${item.currency}${
        acceptedCurrencies.length > 1 ? ` (Accepts: ${acceptedCurrencies.join(', ')})` : ''
      }. #FinalFinance #${cleanCatTag}`;

      const combinedPhotos = Array.from(
        new Set([
          ...(includeItemGalleryMedia ? itemExistingExtraPhotos : []),
          ...extraPhotos,
        ])
      );
      const combinedVideos = Array.from(
        new Set([
          ...(includeItemGalleryMedia ? itemExistingVideos : []),
          ...extraVideos,
        ])
      );

      const newTweet = createTweet({
        authorId,
        authorName,
        authorHandle,
        authorAvatar,
        content: (trimmedNote.length > 0 ? trimmedNote : defaultContent).slice(0, TWEETING_MAX_CHARS),
        photos: combinedPhotos.length > 0 ? combinedPhotos : undefined,
        videos: combinedVideos.length > 0 ? combinedVideos : undefined,
        extraHashtags: [
          'FinalFinance',
          item.type === 'restaurant' ? 'Restaurant' : 'Retail',
          cleanCatTag,
        ],
        sharedPost: {
          listingId: item.id,
          title: item.name,
          description: item.description || `${channelLabel} listing at ${locationName}`,
          category: item.category,
          itemType: item.type === 'restaurant' ? 'restaurant' : 'retail',
          statusLabel: channelLabel.toUpperCase(),
          channelLabel,
          locationName,
          locationId,
          sellerHandle: locationOwnerHandle || authorHandle,
          sellerName: locationName,
          priceUSD: item.price,
          currencySymbol: item.currency,
          acceptedCurrencies,
          imageUrl: primaryImage,
        },
      });

      addToast({
        type: 'success',
        title: 'Shared on Tweet',
        message: `"${item.name}" (${channelLabel}) was posted to the Tweet feed.`,
      });

      window.dispatchEvent(
        new CustomEvent('open_tweeting_feed', { detail: { tweetId: newTweet.id } })
      );

      setNote('');
      setExtraPhotos([]);
      setExtraVideos([]);
      onClose();
    } catch (err) {
      console.error('Failed to share POS item to Tweet:', err);
      addToast({
        type: 'error',
        title: 'Share Failed',
        message: 'Could not publish to Tweet. Please try again.',
      });
    } finally {
      setIsPosting(false);
    }
  };

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full max-h-[92vh] overflow-hidden flex flex-col items-center text-center mx-auto my-auto relative"
        >
          {/* Header */}
          <div className="relative w-full bg-neutral-950 text-white pt-5 pb-4 px-6 border-b border-neutral-800 flex flex-col items-center text-center">
            <button
              type="button"
              onClick={onClose}
              className="absolute right-4 top-4 p-2 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold uppercase tracking-wider mb-1.5">
              <span className="w-4 h-4 rounded bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Twitter className="w-2.5 h-2.5 -scale-x-100 -rotate-12 fill-white" />
              </span>
              <span>Share on Tweet</span>
            </div>

            <h3 className="font-serif-lux text-base sm:text-lg font-bold text-white text-center leading-snug">
              Share {item.type === 'restaurant' ? 'Dish' : 'Item'} to Tweet
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5 text-center">
              Add your own notes, extra photos, and videos for {channelLabel}
            </p>
          </div>

          {/* Modal Body */}
          <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[calc(92vh-130px)] w-full text-center flex flex-col items-center">
            {/* Author Row */}
            <div className="flex items-center justify-center gap-3 w-full py-1">
              <img
                src={authorAvatar}
                alt={authorName}
                className="w-10 h-10 rounded-full object-cover border border-slate-200 shadow-2xs"
              />
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-bold text-slate-900">{authorName}</span>
                  <span className="text-xs text-slate-500 font-mono">@{authorHandle}</span>
                </div>
                <span className="text-[11px] text-emerald-700 font-medium">
                  Posting to Tweet Public Feed
                </span>
              </div>
            </div>

            {/* Own Notes / Caption */}
            <div className="w-full space-y-2 text-center">
              <div className="relative">
                <textarea
                  value={note}
                  maxLength={TWEETING_MAX_CHARS}
                  onChange={(e) => setNote(e.target.value.slice(0, TWEETING_MAX_CHARS))}
                  placeholder={
                    item.type === 'restaurant'
                      ? `Write your tasting notes or recommendation for "${item.name}"...`
                      : `Write your own notes, review, or promo details for "${item.name}"...`
                  }
                  rows={3}
                  className="w-full p-3.5 rounded-2xl border border-slate-200 bg-slate-50 text-slate-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all resize-none shadow-inner"
                />
                <div className="flex items-center justify-between text-[11px] font-mono px-1 text-slate-400">
                  <span className="flex items-center gap-1 text-slate-500">
                    <Tag className="w-3 h-3 text-slate-400" />
                    Quick Tags
                  </span>
                  <span className={`tabular-nums ${note.length > TWEETING_MAX_CHARS - 30 ? 'text-amber-600 font-bold' : 'text-slate-400'}`}>
                    {note.length} / {TWEETING_MAX_CHARS}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-center flex-wrap gap-1.5">
                {suggestedHashtags.map((tag) => {
                  const isActive = note.includes(tag);
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleHashtag(tag)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-colors cursor-pointer border ${
                        isActive
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Additional Photos & Videos Attachment Section */}
            <div className="w-full p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5 text-center">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11px] font-bold text-slate-800 font-mono uppercase flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Additional Photos &amp; Videos</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500">
                  {extraPhotos.length} photos • {extraVideos.length} videos added
                </span>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                multiple
                className="hidden"
                onChange={(e) => {
                  handleFilePick(e.target.files);
                  e.target.value = '';
                }}
              />

              <div className="flex flex-col sm:flex-row items-center gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full sm:w-auto px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-xs font-bold text-slate-800 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Add Photos / Videos</span>
                </button>
                <div className="flex items-center gap-1.5 w-full">
                  <input
                    type="url"
                    placeholder="Or paste photo/video URL..."
                    value={mediaUrlInput}
                    onChange={(e) => setMediaUrlInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAttachMediaUrl();
                      }
                    }}
                    className="flex-1 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-xs min-w-0"
                  />
                  <button
                    type="button"
                    onClick={handleAttachMediaUrl}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold cursor-pointer shrink-0"
                  >
                    Attach
                  </button>
                </div>
              </div>

              {(itemExistingExtraPhotos.length > 0 || itemExistingVideos.length > 0) && (
                <label className="flex items-center justify-center gap-2 text-[11px] text-slate-700 cursor-pointer pt-0.5">
                  <input
                    type="checkbox"
                    checked={includeItemGalleryMedia}
                    onChange={(e) => setIncludeItemGalleryMedia(e.target.checked)}
                    className="rounded text-emerald-600"
                  />
                  <span>
                    Include item&apos;s existing gallery media (
                    {itemExistingExtraPhotos.length} extra photos, {itemExistingVideos.length} videos)
                  </span>
                </label>
              )}

              {(extraPhotos.length > 0 || extraVideos.length > 0) && (
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  {extraPhotos.map((pUrl, idx) => (
                    <div
                      key={`tw-ep-${idx}`}
                      className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-300 bg-white"
                    >
                      <img src={pUrl} alt="" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setExtraPhotos((prev) => prev.filter((_, i) => i !== idx))}
                        className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/75 text-white text-[10px] flex items-center justify-center cursor-pointer"
                        aria-label="Remove photo"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                  {extraVideos.map((vUrl, idx) => (
                    <div
                      key={`tw-ev-${idx}`}
                      className="relative w-24 h-16 rounded-xl overflow-hidden border border-emerald-300 bg-black flex items-center justify-center"
                    >
                      <video src={vUrl} className="w-full h-full object-cover opacity-80" />
                      <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-white text-[9px] font-mono flex items-center gap-0.5">
                        <Video className="w-2.5 h-2.5" />
                        V{idx + 1}
                      </span>
                      <button
                        type="button"
                        onClick={() => setExtraVideos((prev) => prev.filter((_, i) => i !== idx))}
                        className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/75 text-white text-[10px] flex items-center justify-center cursor-pointer"
                        aria-label="Remove video"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Embedded POS Item Preview */}
            <div className="w-full text-center space-y-1">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block text-center">
                Embedded {item.type === 'restaurant' ? 'Menu Dish' : 'Retail Product'} Card
              </span>
              <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3 sm:p-4 text-center flex flex-col items-center space-y-2.5 shadow-2xs">
                {primaryImage && (
                  <div className="w-full h-32 sm:h-36 rounded-xl overflow-hidden bg-slate-900 relative">
                    <img
                      src={primaryImage}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 left-2 flex items-center gap-1.5 flex-wrap">
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-emerald-600 text-white uppercase shadow-xs">
                        {channelLabel}
                      </span>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-slate-900/80 backdrop-blur-xs text-white uppercase shadow-xs">
                        {item.category}
                      </span>
                    </div>
                  </div>
                )}

                <div className="space-y-1 text-center max-w-md px-1">
                  {!primaryImage && (
                    <div className="flex flex-wrap items-center justify-center gap-1.5 pb-0.5">
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-emerald-600 text-white uppercase">
                        {channelLabel}
                      </span>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-slate-200 text-slate-800 uppercase">
                        {item.category}
                      </span>
                    </div>
                  )}
                  <h4 className="font-serif-lux text-sm sm:text-base font-bold text-slate-900 leading-snug break-words">
                    {item.name}
                  </h4>
                  {item.description && (
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  )}
                </div>

                <div className="w-full flex flex-wrap items-center justify-center gap-2 text-xs font-mono font-bold text-emerald-700 pt-1">
                  <Coins className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {item.price.toLocaleString()} {item.currency}
                    {acceptedCurrencies.length > 1
                      ? ` • Accepts (${acceptedCurrencies.length}/5): ${acceptedCurrencies.join(', ')}`
                      : ''}
                  </span>
                </div>

                <div className="flex items-center justify-center gap-1.5 text-[11px] font-mono text-slate-600 pt-1.5 border-t border-slate-200/70 w-full">
                  {item.type === 'restaurant' ? (
                    <UtensilsCrossed className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  ) : (
                    <Store className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  )}
                  <span className="truncate">{locationName}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-3 w-full pt-1">
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleShare}
                disabled={isPosting}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-300 text-white text-xs sm:text-sm font-bold transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Twitter className="w-4 h-4 -scale-x-100 -rotate-12 fill-white" />
                <span>{isPosting ? 'Posting...' : 'Post to Tweet'}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
