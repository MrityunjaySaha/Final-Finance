import { UserWalletData, LinkedBankAccountItem, LinkedCardItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { StockPaymentSource, StockOrder, StockPosition, StockItem, StockSector } from '../types/stocks';
import { DEFAULT_INITIAL_STOCK_ORDERS } from '../data/stocksData';
import { getStockCurrencyCode, isFinalStock } from './stockCurrencyFormatter';
import { getStoredCustomCoins } from '../data/customCoinsData';
import { getAllWorldCurrencies } from '../data/worldCurrenciesData';

// Keys for persistence
const STOCK_POSITIONS_KEY = 'final_finance_stock_positions';
const STOCK_ORDERS_KEY = 'final_finance_stock_orders';
const STOCK_WATCHLIST_KEY = 'final_finance_watchlist';
export const WATCHLIST_UPDATED_EVENT = 'final_finance_watchlist_updated';

export const DEFAULT_WATCHLIST = ['ALEX', 'HYPR', 'AFNL-EQ', 'BSYN', 'VLT-YLD', 'NEXA', 'SOLN', 'ELEN', 'QBIT', 'HASH-M', 'REAL-STBL', 'BTC', 'ETH', 'USDC', 'GLD-STBL', 'DEFI-S', 'VAL-ETH', 'STBL-A', 'STBL-B', 'CRPT-A', 'CRPT-B'];

/**
 * Categorizes a stock holding into Personal Equity, Business Equity, or Regular Stock.
 * Equity is STRICTLY reserved for platform-issued Personal and Business IPOs backed by Final Coins (AFNL).
 * All other stocks (e.g. AAPL, NVDA, NEXA, BSYN, VLT-YLD, SOLN, Alpaca assets, etc.) are regular Stocks.
 */
export function categorizeStockHolding(
  ticker: string, 
  stockInfo?: Partial<StockItem> | null, 
  ipos: any[] = []
): {
  isPersonalEquity: boolean;
  isBusinessEquity: boolean;
  isEquity: boolean;
  isSpotStock: boolean;
  assetCategory: 'personal' | 'business' | 'spot';
} {
  const cleanTicker = (ticker || '').toUpperCase().trim();

  // Known platform-issued Personal Sovereign Equity IPOs (backed by Final Coins AFNL)
  const personalFinalTickers = ['ALEX', 'SATOSHI', 'ELEN', 'STERL', 'STRL'];
  
  // Known platform-issued Corporate Business Equity IPOs (backed by Final Coins AFNL)
  const businessFinalTickers = ['HYPR', 'AFNL-EQ'];

  // Check matching IPO if any
  const matchingIpo = ipos.find(i => 
    i.ticker?.toUpperCase() === cleanTicker || 
    i.id === stockInfo?.ipoRefId || 
    i.id === (stockInfo as any)?.ipoId
  );

  // Is backed by Final Coins ($AFNL)?
  const isFinalBacked = 
    personalFinalTickers.includes(cleanTicker) ||
    businessFinalTickers.includes(cleanTicker) ||
    stockInfo?.marketType === 'final' ||
    matchingIpo?.marketWay === 'final' ||
    matchingIpo?.personalDetails?.backingFinalCoinSymbol === 'AFNL' ||
    stockInfo?.issuanceCoinSymbol === 'AFNL' ||
    (stockInfo?.settlementMethod?.toLowerCase().includes('final') ?? false);

  // 1. Personal Equity: Must be personal issuance AND backed by Final Coins
  const isPersonal = 
    isFinalBacked && (
      personalFinalTickers.includes(cleanTicker) ||
      stockInfo?.issuanceType === 'personal' ||
      stockInfo?.assetCategory === 'personal' ||
      matchingIpo?.ipoType === 'personal' ||
      stockInfo?.sector === 'Sovereign Reserves'
    );

  // 2. Business Equity: Must be business issuance AND backed by Final Coins
  const isBusiness = 
    !isPersonal && isFinalBacked && (
      businessFinalTickers.includes(cleanTicker) ||
      stockInfo?.issuanceType === 'business' ||
      stockInfo?.assetCategory === 'business' ||
      matchingIpo?.ipoType === 'business'
    );

  // Equity strictly consists of Personal and Business stocks backed by Final Coins
  const isEquity = isPersonal || isBusiness;
  // Regular stocks (what was spot stock) are all other stocks (Fiat, Stable, Crypto)
  const isSpotStock = !isEquity;

  return {
    isPersonalEquity: isPersonal,
    isBusinessEquity: isBusiness,
    isEquity,
    isSpotStock,
    assetCategory: isPersonal ? 'personal' : (isBusiness ? 'business' : 'spot')
  };
}

/**
 * Loads user stock watchlist / favorites from localStorage.
 */
export function getStoredWatchlist(userId: string = 'guest'): string[] {
  try {
    const saved = localStorage.getItem(`${STOCK_WATCHLIST_KEY}_${userId}`);
    if (saved !== null) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        // Ensure system defaults are merged so user sees new mock examples
        const merged = [...parsed];
        DEFAULT_WATCHLIST.forEach(ticker => {
          if (!merged.some(t => t.toUpperCase() === ticker.toUpperCase())) {
            merged.push(ticker);
          }
        });
        return merged;
      }
    }
  } catch (err) {
    console.warn('Failed to load watchlist from localStorage', err);
  }
  return DEFAULT_WATCHLIST;
}

/**
 * Saves user stock watchlist / favorites to localStorage and notifies all components.
 */
export function saveStoredWatchlist(userId: string = 'guest', watchlist: string[]): void {
  try {
    localStorage.setItem(`${STOCK_WATCHLIST_KEY}_${userId}`, JSON.stringify(watchlist));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent(WATCHLIST_UPDATED_EVENT, {
          detail: { userId, watchlist },
        })
      );
    }
  } catch (err) {
    console.warn('Failed to save watchlist to localStorage', err);
  }
}

/**
 * Toggles a stock ticker in the user's watchlist / favorites and saves it.
 */
export function toggleStoredWatchlist(userId: string = 'guest', ticker: string): string[] {
  const current = getStoredWatchlist(userId);
  const exists = current.some(t => t.toUpperCase() === ticker.toUpperCase());
  const next = exists
    ? current.filter(t => t.toUpperCase() !== ticker.toUpperCase())
    : [...current, ticker.toUpperCase()];
  saveStoredWatchlist(userId, next);
  return next;
}

/**
 * Universal search matcher for the Stock Market Exchange.
 * Allows searching by:
 * - Stock ticker & name
 * - Personal vs Business stock category ('personal', 'business', 'corporate', 'sovereign')
 * - Issuance / Backing coin symbol (e.g. AFNL, USDC, USD, BTC, SOL, ETH, GOLD, USDT)
 * - Issuance / Backing coin name (e.g. Final Coin, USD Coin, Bitcoin, Sovereign Gold)
 * - Market Way / Settlement Currency (Final Market, Stable Market, Fiat Market, Crypto Market)
 * - Sector, Sub-sector, Description, CEO, Issuer Name, Issuer Handle
 */
export function matchStockSearch(stock: StockItem, rawQuery: string): boolean {
  if (!rawQuery || !rawQuery.trim()) return true;
  
  const query = rawQuery.trim().toLowerCase().replace(/^\$/, '');
  const terms = query.split(/\s+/).filter(Boolean);

  return terms.every((term) => {
    // 1. Direct Ticker & Name
    if (stock.ticker.toLowerCase().includes(term)) return true;
    if (stock.name.toLowerCase().includes(term)) return true;

    // 2. Sector, Sub-sector, Exchange & Description
    if (stock.sector && stock.sector.toLowerCase().includes(term)) return true;
    if (stock.subSector && stock.subSector.toLowerCase().includes(term)) return true;
    if (stock.description && stock.description.toLowerCase().includes(term)) return true;
    if (stock.exchange && stock.exchange.toLowerCase().includes(term)) return true;
    if (stock.ceo && stock.ceo.toLowerCase().includes(term)) return true;

    // 3. Settlement Method
    if (stock.settlementMethod && stock.settlementMethod.toLowerCase().includes(term)) return true;

    // 4. Issuance Coin Symbol & Name (e.g. AFNL, USDC, BTC, USD, GOLD, ALEXCOIN)
    if (stock.issuanceCoinSymbol && stock.issuanceCoinSymbol.toLowerCase().includes(term)) return true;
    if (stock.issuanceCoinName && stock.issuanceCoinName.toLowerCase().includes(term)) return true;
    if (stock.issuanceCoinType && stock.issuanceCoinType.toLowerCase().includes(term)) return true;

    // 5. Issuer Details (for Personal & Business IPOs)
    if (stock.issuerName && stock.issuerName.toLowerCase().includes(term)) return true;
    if (stock.issuerHandle && stock.issuerHandle.toLowerCase().includes(term)) return true;

    // 6. Asset Category & Issuance Type Queries ('personal', 'business', 'sovereign', 'corporate', 'company', 'individual')
    const isPersonal = 
      stock.issuanceType === 'personal' || 
      stock.assetCategory === 'personal' || 
      stock.subSector?.toLowerCase().includes('personal') ||
      stock.sector === 'Sovereign Reserves' ||
      stock.marketType === 'final';

    const isBusiness = 
      stock.issuanceType === 'business' || 
      stock.assetCategory === 'business' ||
      (!isPersonal && stock.sector !== 'Sovereign Reserves');

    if (term === 'personal' || term === 'sovereign' || term === 'individual' || term === 'human') {
      if (isPersonal) return true;
    }

    if (term === 'business' || term === 'corporate' || term === 'corp' || term === 'company' || term === 'enterprise') {
      if (isBusiness) return true;
    }

    // 7. Coin-specific search aliases matching market issuance rules
    // Final Coins ($AFNL, Gold Vaults)
    if (term === 'fnl' || term === 'final') {
      if (stock.marketType === 'final') return true;
      if (stock.issuanceCoinSymbol?.toLowerCase().includes('fnl')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('final')) return true;
    }

    // Stablecoins ($USDC, $USDT, $USD)
    if (term === 'stable' || term === 'stablecoin' || term === 'stablecoins' || term === 'usdc' || term === 'usdt') {
      if (stock.marketType === 'stable') return true;
      if (stock.issuanceCoinSymbol?.toLowerCase().includes('usdc') || stock.issuanceCoinSymbol?.toLowerCase().includes('usdt')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('stable') || stock.settlementMethod?.toLowerCase().includes('usdc')) return true;
    }

    // Fiat Cash ($USD, Fedwire)
    if (term === 'fiat' || term === 'usd' || term === 'dollar' || term === 'dollars' || term === 'cash') {
      if (stock.marketType === 'fiat') return true;
      if (stock.settlementMethod?.toLowerCase().includes('fiat') || stock.settlementMethod?.toLowerCase().includes('usd')) return true;
    }

    // Crypto ($BTC, $ETH, $SOL)
    if (term === 'crypto' || term === 'cryptocurrency' || term === 'btc' || term === 'bitcoin' || term === 'sol' || term === 'eth') {
      if (stock.marketType === 'crypto') return true;
      if (stock.issuanceCoinSymbol?.toLowerCase().includes('btc') || stock.issuanceCoinSymbol?.toLowerCase().includes('sol') || stock.issuanceCoinSymbol?.toLowerCase().includes('eth')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('crypto') || stock.settlementMethod?.toLowerCase().includes('bitcoin')) return true;
    }

    // Gold / Bullion ($GLD, Gold tokens)
    if (term === 'gold' || term === 'bullion' || term === 'xau' || term === 'silver' || term === 'xag') {
      if (stock.ticker.toLowerCase().includes('gld') || stock.ticker.toLowerCase().includes('silv')) return true;
      if (stock.sector === 'Gold & Commodities' || stock.subSector?.toLowerCase().includes('gold')) return true;
      if (stock.settlementMethod?.toLowerCase().includes('gold')) return true;
    }

    // 8. Famous personalities & celebrity investors stock lookup
    // Allows searching "nancy pelosi", "nancy", "pelosi", "jim simons", "warren buffett", "elon musk", etc.
    const famousHoldings: Record<string, string[]> = {
      pelosi: ['HYPR', 'ALEX', 'ELEN', 'BSYN', 'SOLN', 'AUR', 'VEX'],
      nancy: ['HYPR', 'ALEX', 'ELEN', 'BSYN', 'SOLN', 'AUR', 'VEX'],
      simons: ['VEX', 'HYPR', 'ALEX', 'VLT-YLD', 'QBIT'],
      jim: ['VEX', 'HYPR', 'ALEX', 'VLT-YLD', 'QBIT'],
      buffett: ['ALEX', 'BSYN', 'VLT-YLD', 'AUR'],
      warren: ['ALEX', 'BSYN', 'VLT-YLD', 'AUR'],
      musk: ['HYPR', 'SOLN', 'ELEN'],
      elon: ['HYPR', 'SOLN', 'ELEN'],
      saylor: ['SOLN', 'QBIT', 'AUR'],
      ackman: ['HYPR', 'ALEX', 'BSYN'],
      cathie: ['BSYN', 'ELEN', 'SOLN', 'QBIT'],
      wood: ['BSYN', 'ELEN', 'SOLN', 'QBIT'],
      dalio: ['HYPR', 'VLT-YLD', 'AUR'],
      satoshi: ['ALEX', 'AFNL-EQ', 'ELEN']
    };

    if (famousHoldings[term]?.includes(stock.ticker.toUpperCase())) {
      return true;
    }

    return false;
  });
}

/**
 * Filters a stock collection using the universal search matcher.
 */
export function filterStocksByQuery(stocks: StockItem[], query: string): StockItem[] {
  if (!query || !query.trim()) return stocks;
  return stocks.filter(s => matchStockSearch(s, query));
}

/**
 * Builds the single unified wallet payment source strictly for the currency the stock is worth in.
 * Currencies are never compartmentalized into separate vaults or labeled "(Personal Wallet)".
 */
export function getAvailableStockPaymentSources(
  userId: string, 
  _userHoldings?: { fiat: number; stable_coins: number; final_coins: number; barter: number },
  stock?: StockItem | null
): StockPaymentSource[] {
  const walletData: UserWalletData = getStoredUserWallets(userId);

  // Determine the target currency code for this specific stock
  const rawTargetCurrency = stock ? getStockCurrencyCode(stock) : 'AFNL';
  const targetCurrencyClean = rawTargetCurrency.toUpperCase().replace(/^\$/, '').trim();
  const targetSymbol = `$${targetCurrencyClean}`;

  if (!stock || targetCurrencyClean === 'AFNL') {
    const userAfnl = walletData.finalCoins?.find(
      c => c.symbol.toUpperCase().replace(/^\$/, '') === 'AFNL'
    );
    return [
      {
        id: 'wallet-final-afnl',
        type: 'wallet_final',
        label: '$AFNL',
        subtitle: 'Wallet Balance',
        balanceUSD: userAfnl?.balance ?? 0,
        iconType: 'crypto',
        isDefault: true
      }
    ];
  }

  if (targetCurrencyClean === 'USDC' || targetCurrencyClean === 'USDT' || targetCurrencyClean === 'EURC' || targetCurrencyClean === 'PAXG' || stock.marketType === 'stable') {
    const stableCode = ['USDC', 'USDT', 'EURC', 'PAXG'].includes(targetCurrencyClean) ? targetCurrencyClean : 'USDC';
    const matchedStable = walletData.stableCoins?.find(
      s => s.symbol.toUpperCase().replace(/^\$/, '') === stableCode
    );
    return [
      {
        id: `wallet-stable-${stableCode.toLowerCase()}`,
        type: 'wallet_stable',
        label: `$${stableCode}`,
        subtitle: 'Wallet Balance',
        balanceUSD: matchedStable?.balance ?? 0,
        iconType: 'bank',
        isDefault: true
      }
    ];
  }

  if (targetCurrencyClean === 'USD' || targetCurrencyClean === 'CHF' || targetCurrencyClean === 'GBP' || stock.marketType === 'fiat') {
    const fiatCode = ['USD', 'CHF', 'GBP'].includes(targetCurrencyClean) ? targetCurrencyClean : 'USD';
    const matchedFiat = walletData.fiatCurrencies?.find(
      f => f.code.toUpperCase() === fiatCode
    );
    return [
      {
        id: `wallet-fiat-${fiatCode.toLowerCase()}`,
        type: 'wallet_fiat',
        label: `$${fiatCode}`,
        subtitle: 'Wallet Balance',
        balanceUSD: matchedFiat?.balance ?? 0,
        iconType: 'bank',
        isDefault: true
      }
    ];
  }

  if (targetCurrencyClean === 'BTC' || targetCurrencyClean === 'ETH' || targetCurrencyClean === 'SOL' || stock.marketType === 'crypto') {
    const matchedCrypto = walletData.cryptoCurrencies?.find(
      c => c.symbol.toUpperCase().replace(/^\$/, '') === targetCurrencyClean
    );
    const cryptoBalanceUSD = matchedCrypto
      ? (matchedCrypto.balance || 0) * (matchedCrypto.unitPriceUSD || 1)
      : (
          walletData.linkedCryptoWallets?.find(
            c => c.walletName.toUpperCase().includes(targetCurrencyClean) || c.network.toUpperCase().includes(targetCurrencyClean)
          )?.balanceUSD ?? 0
        );
    return [
      {
        id: `wallet-crypto-${targetCurrencyClean.toLowerCase()}`,
        type: 'crypto_wallet',
        label: `$${targetCurrencyClean}`,
        subtitle: 'Wallet Balance',
        balanceUSD: Number(cryptoBalanceUSD.toFixed(2)),
        iconType: 'crypto',
        isDefault: true
      }
    ];
  }

  // Specific final coin (e.g. ALEX-FNL, GLD-FNL, BSYN-FNL, etc.) stored directly in the unified wallet
  const matchedUserCoin = walletData.finalCoins?.find(
    c => c.symbol.toUpperCase().replace(/^\$/, '') === targetCurrencyClean
  );
  return [
    {
      id: `wallet-final-${targetCurrencyClean.toLowerCase()}`,
      type: 'wallet_final',
      label: targetSymbol,
      subtitle: 'Wallet Balance',
      balanceUSD: matchedUserCoin?.balance ?? 0,
      iconType: 'crypto',
      isDefault: true
    }
  ];
}

/**
 * Builds the complete list of currencies across the platform for receiving sale proceeds.
 * - For Final Stocks: strictly restricted to Final Coins only (including peer-created Final Coins not yet held).
 * - For all other stocks: all currencies across the platform (Final Coins, Stablecoins, Fiat, Crypto).
 */
export function getAllSystemSellCurrencies(
  userId: string,
  preferredStock?: StockItem | null
): StockPaymentSource[] {
  const walletData: UserWalletData = getStoredUserWallets(userId);
  const bySymbol = new Map<string, StockPaymentSource>();

  const preferredCode = preferredStock
    ? getStockCurrencyCode(preferredStock).toUpperCase().replace(/^\$/, '').trim()
    : 'AFNL';

  const finalCoinsOnly = Boolean(
    preferredStock &&
      (isFinalStock(preferredStock) ||
        preferredStock.marketType === 'final' ||
        preferredStock.settlementMethod?.toLowerCase().includes('final'))
  );

  // 1. Seed with user's existing wallet holdings (Final Coins always eligible)
  (walletData.finalCoins || []).forEach(fc => {
    const code = (fc.symbol || '').toUpperCase().replace(/^\$/, '').trim();
    if (!code) return;
    bySymbol.set(code, {
      id: `sell-final-${code.toLowerCase()}`,
      type: 'wallet_final',
      label: `$${code}`,
      subtitle: fc.name || 'Final Coin',
      balanceUSD: fc.balance ?? 0,
      iconType: 'crypto',
      currencyCode: code,
      currencyName: fc.name || code,
      currencyCategory: 'final',
      unitPriceUSD: 0,
      isDefault: code === preferredCode
    });
  });

  if (!finalCoinsOnly) {
    (walletData.stableCoins || []).forEach(sc => {
      const code = (sc.symbol || '').toUpperCase().replace(/^\$/, '').trim();
      if (!code || bySymbol.has(code)) return;
      bySymbol.set(code, {
        id: `sell-stable-${code.toLowerCase()}`,
        type: 'wallet_stable',
        label: `$${code}`,
        subtitle: sc.name || 'Stablecoin',
        balanceUSD: sc.balance ?? 0,
        iconType: 'bank',
        currencyCode: code,
        currencyName: sc.name || code,
        currencyCategory: 'stable',
        unitPriceUSD: sc.unitPriceUSD || 1,
        network: sc.network,
        isDefault: code === preferredCode
      });
    });

    (walletData.fiatCurrencies || []).forEach(fi => {
      const code = (fi.code || '').toUpperCase().trim();
      if (!code || bySymbol.has(code)) return;
      bySymbol.set(code, {
        id: `sell-fiat-${code.toLowerCase()}`,
        type: 'wallet_fiat',
        label: `$${code}`,
        subtitle: fi.name || 'Fiat Currency',
        balanceUSD: fi.balance ?? 0,
        iconType: 'bank',
        currencyCode: code,
        currencyName: fi.name || code,
        currencyCategory: 'fiat',
        unitPriceUSD: fi.exchangeRateToUSD || 1,
        isDefault: code === preferredCode
      });
    });

    (walletData.cryptoCurrencies || []).forEach(cr => {
      const code = (cr.symbol || '').toUpperCase().replace(/^\$/, '').trim();
      if (!code || bySymbol.has(code)) return;
      bySymbol.set(code, {
        id: `sell-crypto-${code.toLowerCase()}`,
        type: 'crypto_wallet',
        label: `$${code}`,
        subtitle: cr.name || 'Cryptocurrency',
        balanceUSD: Number(((cr.balance || 0) * (cr.unitPriceUSD || 1)).toFixed(2)),
        iconType: 'crypto',
        currencyCode: code,
        currencyName: cr.name || code,
        currencyCategory: 'crypto',
        unitPriceUSD: cr.unitPriceUSD || 1,
        network: cr.network,
        isDefault: code === preferredCode
      });
    });
  }

  // 2. Add custom / peer-created coins from the system directory (even if user holds 0)
  try {
    const customCoins = getStoredCustomCoins();
    customCoins.forEach(cc => {
      if (finalCoinsOnly && cc.coinType !== 'final_coin') return;

      const code = (cc.symbol || '').toUpperCase().replace(/^\$/, '').trim();
      if (!code) return;
      const existing = bySymbol.get(code);
      const category: 'final' | 'stable' | 'crypto' =
        cc.coinType === 'final_coin' ? 'final' : cc.coinType === 'stable_coin' ? 'stable' : 'crypto';
      const sourceType =
        category === 'final' ? 'wallet_final' : category === 'stable' ? 'wallet_stable' : 'crypto_wallet';

      if (existing) {
        existing.currencyName = existing.currencyName || cc.name;
        if (!cc.isAdminCoin && cc.creatorName) {
          existing.creatorName = cc.creatorName;
        }
      } else {
        bySymbol.set(code, {
          id: `sell-${category}-${code.toLowerCase()}`,
          type: sourceType,
          label: `$${code}`,
          subtitle: cc.name || code,
          balanceUSD: 0,
          iconType: category === 'stable' ? 'bank' : 'crypto',
          currencyCode: code,
          currencyName: cc.name || code,
          currencyCategory: category,
          creatorName: !cc.isAdminCoin ? cc.creatorName : undefined,
          unitPriceUSD: cc.coinType === 'final_coin' ? 0 : (cc.priceUSD || cc.pegRateUSD || 1),
          network: cc.network,
          isDefault: code === preferredCode
        });
      }
    });
  } catch (err) {
    console.warn('Could not load custom coins for sell lookup:', err);
  }

  // 3. Add global world currencies (fiat, stablecoins, crypto) from catalog only when not a Final Stock
  if (!finalCoinsOnly) {
    try {
      const worldCurrencies = getAllWorldCurrencies();
      worldCurrencies.forEach(wc => {
        const code = (wc.symbol || '').toUpperCase().replace(/^\$/, '').trim();
        if (!code || bySymbol.has(code)) return;
        const category: 'stable' | 'fiat' | 'crypto' =
          wc.category === 'stablecoin' ? 'stable' : wc.category === 'fiat' ? 'fiat' : 'crypto';
        const sourceType =
          category === 'stable' ? 'wallet_stable' : category === 'fiat' ? 'wallet_fiat' : 'crypto_wallet';

        bySymbol.set(code, {
          id: `sell-${category}-${code.toLowerCase()}`,
          type: sourceType,
          label: `$${code}`,
          subtitle: wc.name || code,
          balanceUSD: 0,
          iconType: category === 'crypto' ? 'crypto' : 'bank',
          currencyCode: code,
          currencyName: wc.name || code,
          currencyCategory: category,
          unitPriceUSD: wc.unitPriceUSD || 1,
          network: wc.network,
          isDefault: code === preferredCode
        });
      });
    } catch (err) {
      console.warn('Could not load world currencies for sell lookup:', err);
    }
  }

  // Sort: stock's native currency first, then currencies currently in wallet, then alphabetical
  return Array.from(bySymbol.values()).sort((a, b) => {
    const aIsPref = a.currencyCode === preferredCode ? 1 : 0;
    const bIsPref = b.currencyCode === preferredCode ? 1 : 0;
    if (aIsPref !== bIsPref) return bIsPref - aIsPref;

    const aHasBal = (a.balanceUSD || 0) > 0 ? 1 : 0;
    const bHasBal = (b.balanceUSD || 0) > 0 ? 1 : 0;
    if (aHasBal !== bHasBal) return bHasBal - aHasBal;

    return (a.currencyCode || a.label).localeCompare(b.currencyCode || b.label);
  });
}

/**
 * Executes an immediate debit/credit directly on the user's unified wallet when buying or selling stocks.
 */
export function processStockPayment(
  userId: string,
  source: StockPaymentSource,
  amountUSD: number,
  side: 'buy' | 'sell'
): boolean {
  try {
    const walletData = getStoredUserWallets(userId);
    const symbolClean = (source.currencyCode || source.label.replace(/^\$/, '').split(' ')[0]).trim().toUpperCase();

    if (source.type === 'bank_account' && source.last4) {
      const bankIndex = walletData.linkedBankAccounts.findIndex(b => b.accountNumberLast4 === source.last4);
      if (bankIndex !== -1) {
        if (side === 'buy') {
          walletData.linkedBankAccounts[bankIndex].balanceUSD = Math.max(
            0, 
            walletData.linkedBankAccounts[bankIndex].balanceUSD - amountUSD
          );
        } else {
          walletData.linkedBankAccounts[bankIndex].balanceUSD += amountUSD;
        }
        saveStoredUserWallets(userId, walletData);
        return true;
      }
    } else if (source.type === 'wallet_fiat') {
      const fiatCode = symbolClean || 'USD';
      if (!walletData.fiatCurrencies) walletData.fiatCurrencies = [];
      const fiatIndex = walletData.fiatCurrencies.findIndex(f => f.code.toUpperCase() === fiatCode);
      const rateToUSD = source.unitPriceUSD && source.unitPriceUSD > 0 ? source.unitPriceUSD : 1;
      const unitsDelta = amountUSD / rateToUSD;

      if (fiatIndex !== -1) {
        const existingRate = walletData.fiatCurrencies[fiatIndex].exchangeRateToUSD || rateToUSD || 1;
        const delta = amountUSD / existingRate;
        if (side === 'buy') {
          walletData.fiatCurrencies[fiatIndex].balance = Math.max(
            0,
            walletData.fiatCurrencies[fiatIndex].balance - delta
          );
        } else {
          walletData.fiatCurrencies[fiatIndex].balance += delta;
        }
      } else if (side === 'sell') {
        walletData.fiatCurrencies.push({
          id: `fi-${fiatCode.toLowerCase()}-${Date.now()}`,
          name: source.currencyName || fiatCode,
          code: fiatCode,
          symbol: fiatCode,
          balance: Number(unitsDelta.toFixed(2)),
          exchangeRateToUSD: rateToUSD,
          accountType: 'Wallet Account',
          institution: 'Sovereign Clearing'
        });
      }
      saveStoredUserWallets(userId, walletData);
      return true;
    } else if (source.type === 'crypto_wallet') {
      if (!walletData.cryptoCurrencies) walletData.cryptoCurrencies = [];
      const cryptoCurrencyIdx = walletData.cryptoCurrencies.findIndex(
        c => c.symbol.toUpperCase() === symbolClean
      );
      if (cryptoCurrencyIdx !== -1) {
        const unitPrice = walletData.cryptoCurrencies[cryptoCurrencyIdx].unitPriceUSD || source.unitPriceUSD || 1;
        const tokenDelta = amountUSD / unitPrice;
        if (side === 'buy') {
          walletData.cryptoCurrencies[cryptoCurrencyIdx].balance = Math.max(
            0,
            Number((walletData.cryptoCurrencies[cryptoCurrencyIdx].balance - tokenDelta).toFixed(6))
          );
        } else {
          walletData.cryptoCurrencies[cryptoCurrencyIdx].balance = Number(
            (walletData.cryptoCurrencies[cryptoCurrencyIdx].balance + tokenDelta).toFixed(6)
          );
        }
        saveStoredUserWallets(userId, walletData);
        return true;
      }

      if (side === 'sell') {
        const unitPrice = source.unitPriceUSD && source.unitPriceUSD > 0 ? source.unitPriceUSD : 1;
        const tokenDelta = Number((amountUSD / unitPrice).toFixed(6));
        walletData.cryptoCurrencies.push({
          id: `cr-${symbolClean.toLowerCase()}-${Date.now()}`,
          name: source.currencyName || symbolClean,
          symbol: symbolClean,
          balance: tokenDelta,
          unitPriceUSD: unitPrice,
          change24h: 0,
          network: source.network || 'Multi-Chain',
          walletAddress: `0x${Date.now().toString(16)}wallet`
        });
        saveStoredUserWallets(userId, walletData);
        return true;
      }

      const cryptoIndex = (walletData.linkedCryptoWallets || []).findIndex(
        c => (source.walletAddress && c.address === source.walletAddress) ||
             c.id === source.id.replace('crypto-', '') ||
             c.network.toUpperCase().includes(symbolClean) ||
             c.walletName.toUpperCase().includes(symbolClean)
      );
      if (cryptoIndex !== -1 && walletData.linkedCryptoWallets) {
        walletData.linkedCryptoWallets[cryptoIndex].balanceUSD = Math.max(
          0,
          walletData.linkedCryptoWallets[cryptoIndex].balanceUSD - amountUSD
        );
        saveStoredUserWallets(userId, walletData);
        return true;
      }
    } else if (source.type === 'wallet_stable') {
      const stableSymbol = symbolClean || 'USDC';
      if (!walletData.stableCoins) walletData.stableCoins = [];
      const stableIndex = walletData.stableCoins.findIndex(s => s.symbol.toUpperCase() === stableSymbol);
      const unitPrice = source.unitPriceUSD && source.unitPriceUSD > 0 ? source.unitPriceUSD : 1;
      const unitsDelta = amountUSD / unitPrice;

      if (stableIndex !== -1) {
        const existingRate = walletData.stableCoins[stableIndex].unitPriceUSD || unitPrice || 1;
        const delta = amountUSD / existingRate;
        if (side === 'buy') {
          walletData.stableCoins[stableIndex].balance = Math.max(0, walletData.stableCoins[stableIndex].balance - delta);
        } else {
          walletData.stableCoins[stableIndex].balance += delta;
        }
      } else if (side === 'sell') {
        walletData.stableCoins.push({
          id: `sc-${stableSymbol.toLowerCase()}-${Date.now()}`,
          name: source.currencyName || stableSymbol,
          symbol: stableSymbol,
          balance: Number(unitsDelta.toFixed(2)),
          unitPriceUSD: unitPrice,
          peggedCurrency: 'USD',
          yieldAPY: 0,
          network: source.network || 'Native Wallet'
        });
      }
      saveStoredUserWallets(userId, walletData);
      return true;
    } else if (source.type === 'wallet_final') {
      const coinSymbol = symbolClean || 'AFNL';
      if (!walletData.finalCoins) walletData.finalCoins = [];
      const coinIndex = walletData.finalCoins.findIndex(c => c.symbol.toUpperCase() === coinSymbol);
      if (coinIndex !== -1) {
        if (side === 'buy') {
          walletData.finalCoins[coinIndex].balance = Math.max(0, (walletData.finalCoins[coinIndex].balance || 0) - amountUSD);
        } else {
          walletData.finalCoins[coinIndex].balance = (walletData.finalCoins[coinIndex].balance || 0) + amountUSD;
        }
      } else if (side === 'sell') {
        walletData.finalCoins.push({
          id: `fc-${coinSymbol.toLowerCase()}-${Date.now()}`,
          name: source.currencyName || (coinSymbol === 'AFNL' ? 'Final Admin Coin' : `${coinSymbol} Final Coin`),
          symbol: coinSymbol,
          balance: amountUSD,
          unitPriceUSD: 0,
          change24h: 0,
          utility: 'Direct wallet holding'
        });
      }
      saveStoredUserWallets(userId, walletData);
      return true;
    }

    return true;
  } catch (err) {
    console.error('Failed to process stock wallet payment:', err);
    return false;
  }
}

/**
 * Loads user stock positions from local storage with fallback to initial positions.
 */
export function getStoredStockPositions(userId: string, initialFallback: StockPosition[]): StockPosition[] {
  try {
    const saved = localStorage.getItem(`${STOCK_POSITIONS_KEY}_${userId}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Normalize positions to guarantee correct categorization and attribution
        const normalized: StockPosition[] = parsed.map((p: any) => {
          const cat = categorizeStockHolding(p.ticker, p);
          return {
            ...p,
            marketType: p.marketType || 'final',
            assetCategory: cat.assetCategory,
            isEquity: cat.isEquity,
            isSpotStock: cat.isSpotStock,
            isPersonalEquity: cat.isPersonalEquity,
            isBusinessEquity: cat.isBusinessEquity
          };
        });

        // Ensure default stock positions are preserved if missing from older sessions, deduplicated by ticker
        const seenTickers = new Set<string>();
        const dedupedNormalized: StockPosition[] = [];
        for (const item of normalized) {
          const t = (item.ticker || '').toUpperCase();
          if (t && !seenTickers.has(t)) {
            seenTickers.add(t);
            dedupedNormalized.push(item);
          }
        }
        const missingDefaults = initialFallback.filter(init => {
          const t = (init.ticker || '').toUpperCase();
          if (!t || seenTickers.has(t)) return false;
          seenTickers.add(t);
          return true;
        });
        return [...dedupedNormalized, ...missingDefaults];
      }
    }
  } catch (err) {
    console.warn('Failed to load stock positions from localStorage', err);
  }
  return Array.from(new Map(initialFallback.map(p => [p.ticker.toUpperCase(), p])).values());
}

/**
 * Saves user stock positions to local storage.
 */
export function saveStoredStockPositions(userId: string, positions: StockPosition[]): void {
  try {
    localStorage.setItem(`${STOCK_POSITIONS_KEY}_${userId}`, JSON.stringify(positions));
  } catch (err) {
    console.warn('Failed to save stock positions to localStorage', err);
  }
}

/**
 * Loads user stock orders from local storage.
 */
export function getStoredStockOrders(
  userId: string, 
  initialFallback: StockOrder[] = DEFAULT_INITIAL_STOCK_ORDERS
): StockOrder[] {
  try {
    const saved = localStorage.getItem(`${STOCK_ORDERS_KEY}_${userId}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Sanitize any legacy stock orders (convert AAPL, TSLA, NVDA to sovereign final stocks)
        const sanitized: StockOrder[] = parsed.map((ord: any) => {
          const t = (ord.ticker || '').toUpperCase();
          if (t === 'AAPL') {
            return {
              ...ord,
              ticker: 'ALEX',
              stockName: 'Alex Chen Sovereign Human Equity [Call Option (32.00 Strike)]',
              tradeSlipId: ord.tradeSlipId?.replace('AAPL', 'ALEX') || 'SLIP-ALEX-CALL',
              sector: 'Sovereign Reserves' as StockSector,
              isPersonalStock: true
            };
          }
          if (t === 'TSLA') {
            return {
              ...ord,
              ticker: 'ELEN',
              stockName: 'Dr. Elena Rostova Plasma Physics Equity [Put Option (28.00 Strike)]',
              tradeSlipId: ord.tradeSlipId?.replace('TSLA', 'ELEN') || 'SLIP-ELEN-PUT',
              sector: 'Sovereign Reserves' as StockSector,
              isPersonalStock: true
            };
          }
          if (t === 'NVDA') {
            return {
              ...ord,
              ticker: 'HYPR',
              stockName: 'Hyperion Quantum Fusion Energy [Futures Long (10x Leverage)]',
              tradeSlipId: ord.tradeSlipId?.replace('NVDA', 'HYPR') || 'SLIP-HYPR-FUT',
              sector: 'Energy & Aerospace' as StockSector,
              isBusinessStock: true
            };
          }
          const cleanedLabel = ord.paymentSource?.label
            ? String(ord.paymentSource.label).replace(/-FNL/gi, '')
            : ord.paymentSource?.label;
          return {
            ...ord,
            stockName: ord.stockName ? String(ord.stockName).replace(/₣/g, '') : ord.stockName,
            ...(ord.paymentSource ? { paymentSource: { ...ord.paymentSource, label: cleanedLabel } } : {}),
          };
        }).filter((ord: StockOrder) => {
          const t = (ord.ticker || '').toUpperCase();
          return !['AAPL', 'TSLA', 'NVDA', 'MSFT', 'GOOG', 'AMZN', 'META', 'SPY', 'QQQ'].includes(t);
        });

        const dedupedSanitized = Array.from(
          new Map(sanitized.map(o => [o.id, o])).values()
        );

        // Supplement any missing default closed/done derivative orders or spot orders without duplicating IDs
        const hasDerivatives = dedupedSanitized.some(o => o.derivativeType && o.derivativeType !== 'spot');
        const hasClosedDerivatives = dedupedSanitized.some(o => o.derivativeType && o.derivativeType !== 'spot' && o.side === 'sell');
        if (!hasDerivatives || !hasClosedDerivatives) {
          const existingIds = new Set(dedupedSanitized.map(o => o.id));
          const extraDefaults = DEFAULT_INITIAL_STOCK_ORDERS.filter(d => !existingIds.has(d.id));
          const merged = [...dedupedSanitized, ...extraDefaults];
          saveStoredStockOrders(userId, merged);
          return merged;
        }
        return dedupedSanitized;
      }
    }
  } catch (err) {
    console.warn('Failed to load stock orders from localStorage', err);
  }
  return initialFallback.length > 0 ? initialFallback : DEFAULT_INITIAL_STOCK_ORDERS;
}

/**
 * Saves user stock orders to local storage.
 */
export function saveStoredStockOrders(userId: string, orders: StockOrder[]): void {
  try {
    localStorage.setItem(`${STOCK_ORDERS_KEY}_${userId}`, JSON.stringify(orders));
  } catch (err) {
    console.warn('Failed to save stock orders to localStorage', err);
  }
}

/**
 * Helper to calculate asset allocation breakdown across all stock types bought.
 */
export interface SectorAllocation {
  sector: StockSector;
  totalValueUSD: number;
  percentage: number;
  positionsCount: number;
  totalGainUSD: number;
  totalGainPercent: number;
  color: string;
}

const SECTOR_COLORS: Record<string, string> = {
  'Technology & AI': '#3b82f6', // blue-500
  'Semiconductors': '#8b5cf6', // purple-500
  'Gold & Commodities': '#f59e0b', // amber-500
  'Banking & Finance': '#10b981', // emerald-500
  'Energy & Aerospace': '#ef4444', // red-500
  'ETFs & Indices': '#06b6d4', // cyan-500
  'All': '#64748b'
};

export function calculateSectorAllocations(positions: StockPosition[]): SectorAllocation[] {
  const totalVal = positions.reduce((acc, p) => acc + p.totalValueUSD, 0);
  if (totalVal <= 0) return [];

  const map = new Map<StockSector, { val: number; count: number; gain: number; cost: number }>();

  positions.forEach(p => {
    const current = map.get(p.sector) || { val: 0, count: 0, gain: 0, cost: 0 };
    current.val += p.totalValueUSD;
    current.count += 1;
    current.gain += p.totalGainUSD;
    current.cost += (p.shares * p.avgCostUSD);
    map.set(p.sector, current);
  });

  const result: SectorAllocation[] = [];
  map.forEach((data, sector) => {
    result.push({
      sector,
      totalValueUSD: data.val,
      percentage: Number(((data.val / totalVal) * 100).toFixed(1)),
      positionsCount: data.count,
      totalGainUSD: data.gain,
      totalGainPercent: data.cost > 0 ? Number(((data.gain / data.cost) * 100).toFixed(2)) : 0,
      color: SECTOR_COLORS[sector] || '#64748b'
    });
  });

  // Sort descending by totalValueUSD
  return result.sort((a, b) => b.totalValueUSD - a.totalValueUSD);
}

/**
 * Saves a dynamically loaded Alpaca stock to localStorage so all components share the state.
 */
export function saveDynamicAlpacaStock(stock: StockItem): void {
  try {
    const saved = localStorage.getItem('final_finance_alpaca_stocks');
    const list = saved ? JSON.parse(saved) : [];
    if (!list.some((s: any) => s.ticker.toUpperCase() === stock.ticker.toUpperCase())) {
      list.push(stock);
      localStorage.setItem('final_finance_alpaca_stocks', JSON.stringify(list));
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('final_finance_alpaca_stocks_updated'));
      }
    }
  } catch (err) {
    console.error('Error saving dynamic alpaca stock', err);
  }
}
