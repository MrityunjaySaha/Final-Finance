import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

console.log('Main.tsx: Application starting...');
const rootElement = document.getElementById('root');
if (!rootElement) {
  console.error('CRITICAL: Root element not found!');
}
createRoot(rootElement!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
);
console.log('Main.tsx: Render called');

