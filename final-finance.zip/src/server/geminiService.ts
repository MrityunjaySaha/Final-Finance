import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import * as alpaca from './alpacaService';

dotenv.config();

export function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is not configured');
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export interface GenerateImageParams {
  prompt: string;
  model?: string;
  aspectRatio?: '1:1' | '3:4' | '4:3' | '9:16' | '16:9' | '1:4' | '1:8' | '4:1' | '8:1';
  imageSize?: '1K' | '2K' | '4K';
  useSearch?: boolean;
  referenceImage?: string; // base64
  referenceMimeType?: string;
}

export async function generateOrEditImage(params: GenerateImageParams) {
  const ai = getGeminiClient();
  const requestedModel = params.model || (params.referenceImage ? 'gemini-3.1-flash-image-preview' : 'gemini-3-pro-image-preview');

  const parts: Array<{ text?: string; inlineData?: { data: string; mimeType: string } }> = [];

  if (params.referenceImage) {
    let cleanBase64 = params.referenceImage;
    let mimeType = params.referenceMimeType || 'image/png';
    
    if (cleanBase64.includes('base64,')) {
      const match = cleanBase64.match(/^data:([^;]+);base64,(.+)$/);
      if (match) {
        mimeType = match[1];
        cleanBase64 = match[2];
      } else {
        cleanBase64 = cleanBase64.split('base64,')[1];
      }
    }

    parts.push({
      inlineData: {
        data: cleanBase64,
        mimeType: mimeType,
      },
    });
  }

  parts.push({
    text: params.prompt,
  });

  const config: Record<string, unknown> = {};

  const imageConfig: Record<string, unknown> = {};
  if (params.aspectRatio) {
    imageConfig.aspectRatio = params.aspectRatio;
  }
  if (params.imageSize && (requestedModel.includes('pro') || requestedModel.includes('flash-image'))) {
    imageConfig.imageSize = params.imageSize;
  }

  if (Object.keys(imageConfig).length > 0) {
    config.imageConfig = imageConfig;
  }

  if (params.useSearch && (requestedModel.includes('pro') || requestedModel.includes('flash-image'))) {
    config.tools = [
      {
        googleSearch: {
          searchTypes: {
            webSearch: {},
            ...(requestedModel.includes('flash') ? { imageSearch: {} } : {}),
          },
        },
      },
    ];
  }

  try {
    const response = await ai.models.generateContent({
      model: requestedModel,
      contents: {
        parts: parts,
      },
      config: Object.keys(config).length > 0 ? config : undefined,
    });

    let imageUrl = '';
    let textResponse = '';

    const candidate = response.candidates?.[0];
    if (candidate?.content?.parts) {
      for (const part of candidate.content.parts) {
        if (part.inlineData?.data) {
          const mime = part.inlineData.mimeType || 'image/png';
          imageUrl = `data:${mime};base64,${part.inlineData.data}`;
        } else if (part.text) {
          textResponse += part.text + ' ';
        }
      }
    }

    return {
      success: true,
      imageUrl,
      text: textResponse.trim(),
      model: requestedModel,
      aspectRatio: params.aspectRatio || '1:1',
      imageSize: params.imageSize || '1K',
    };
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : String(error);
    console.error('Gemini image generation error:', errMessage);
    
    // Attempt fallback with alias if preview suffix fails
    try {
      const fallbackModel = requestedModel.replace('-preview', '');
      if (fallbackModel !== requestedModel) {
        const fallbackRes = await ai.models.generateContent({
          model: fallbackModel,
          contents: { parts },
          config: Object.keys(config).length > 0 ? config : undefined,
        });

        let imageUrl = '';
        let textResponse = '';
        if (fallbackRes.candidates?.[0]?.content?.parts) {
          for (const part of fallbackRes.candidates[0].content.parts) {
            if (part.inlineData?.data) {
              const mime = part.inlineData.mimeType || 'image/png';
              imageUrl = `data:${mime};base64,${part.inlineData.data}`;
            } else if (part.text) {
              textResponse += part.text + ' ';
            }
          }
        }

        if (imageUrl) {
          return {
            success: true,
            imageUrl,
            text: textResponse.trim(),
            model: fallbackModel,
            aspectRatio: params.aspectRatio || '1:1',
            imageSize: params.imageSize || '1K',
          };
        }
      }
    } catch (fallbackError) {
      console.error('Fallback model also failed:', fallbackError);
    }

    return {
      success: false,
      error: errMessage,
      model: requestedModel,
    };
  }
}

export async function enhanceAssetPrompt(prompt: string, category?: string) {
  const ai = getGeminiClient();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `You are an elite creative visual designer for luxury financial assets, minted physical reserve tokens, high-end commodities, vault certificates, and ultra-rare digital collectibles.
Enhance the following prompt into an exquisite, photorealistic 8K render prompt with dramatic studio lighting, rich metallic textures (24k gold, brushed platinum, obsidian, iridescent holographic foil), macroeconomic prestige, and museum-grade physical depth.

Category context: ${category || 'General Luxury Asset'}
Original prompt: "${prompt}"

Provide ONLY the enhanced prompt in 2 to 3 concise, highly descriptive sentences. Do not use quotes or introductory text.`,
    });

    return {
      success: true,
      enhancedPrompt: response.text?.trim() || prompt,
    };
  } catch (error: unknown) {
    return {
      success: false,
      enhancedPrompt: prompt,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function generateValuationReport(assetName: string, category: string, initialPrice: number, attributes: string) {
  const ai = getGeminiClient();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `Provide a realistic institutional appraisal and macroeconomic audit prospectus for the following luxury asset in the Final Finance multi-asset reserve ecosystem:

Asset Name: ${assetName}
Asset Class / Vault: ${category}
Stated Valuation: $${initialPrice.toLocaleString()}
Attributes & Provenance: ${attributes}

Format as a structured concise report with:
1. Executive Appraisal Summary
2. Liquidity & Vault Collateral Grade (AAA to BBB)
3. 12-Month Projected Appreciation & Yield Potential
4. Multi-Vault Swap Feasibility & Barter Index`,
    });

    return {
      success: true,
      report: response.text?.trim() || '',
    };
  } catch (error: unknown) {
    return {
      success: false,
      report: '',
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

const tradingTools = {
  function_declarations: [
    {
      name: 'getAccountBalance',
      description: 'Get the current cash balance, buying power, and portfolio value from the Alpaca account.',
      parameters: { type: Type.OBJECT, properties: {}, required: [] },
    },
    {
      name: 'getPortfolioPositions',
      description: 'List all current stock, crypto, and option positions with their market values and profit/loss.',
      parameters: { type: Type.OBJECT, properties: {}, required: [] },
    },
    {
      name: 'searchAssets',
      description: 'Search for tradable assets by class (stocks, crypto, or options).',
      parameters: {
        type: Type.OBJECT,
        properties: {
          assetClass: { 
            type: Type.STRING, 
            enum: ['us_equity', 'crypto', 'us_option'], 
            description: 'The category of assets to search for.' 
          },
        },
        required: ['assetClass'],
      },
    },
    {
      name: 'getMarketStatus',
      description: 'Check if the stock market is currently open and get next open/close times.',
      parameters: { type: Type.OBJECT, properties: {}, required: [] },
    },
    {
      name: 'placeTradeOrder',
      description: 'Place a buy or sell order for a stock, cryptocurrency, or option contract.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          symbol: { type: Type.STRING, description: 'The ticker symbol (e.g., AAPL, BTC/USD, or an option contract symbol).' },
          qty: { type: Type.NUMBER, description: 'The number of shares or units to trade.' },
          side: { type: Type.STRING, enum: ['buy', 'sell'], description: 'Whether to buy or sell.' },
          type: { type: Type.STRING, enum: ['market', 'limit'], description: 'The order type.' },
          limitPrice: { type: Type.NUMBER, description: 'The limit price for limit orders.' },
        },
        required: ['symbol', 'qty', 'side'],
      },
    },
  ],
};

export async function processChatRequest(message: string, history: any[] = []) {
  const ai = getGeminiClient();
  
  const chat = ai.chats.create({
    model: 'gemini-3.7-flash',
    config: {
      tools: [{ functionDeclarations: tradingTools.function_declarations as any }],
      systemInstruction: "You are an elite Final Finance Trading Assistant connected to Alpaca. You help users manage their global portfolio across regular stocks, cryptocurrency (including stablecoins), and options contracts. You understand that stablecoin-related stocks like COIN, RIOT, and MSTR are important for this ecosystem. You provide institutional-grade clarity and precise execution for all market orders.",
    },
    history: history,
  });

  try {
    let response = await chat.sendMessage({ message });
    const calls = response.functionCalls;

    if (calls && calls.length > 0) {
      const call = calls[0];
      let toolResponse;
      switch (call.name) {
        case 'getAccountBalance':
          toolResponse = await alpaca.getAccount();
          break;
        case 'getPortfolioPositions':
          toolResponse = await alpaca.getPositions();
          break;
        case 'searchAssets':
          toolResponse = await alpaca.getAssets((call.args as any).assetClass);
          break;
        case 'getMarketStatus':
          toolResponse = await alpaca.getMarketClock();
          break;
        case 'placeTradeOrder':
          const { symbol, qty, side, type, limitPrice } = call.args as any;
          toolResponse = await alpaca.placeOrder(symbol, qty, side, type, limitPrice);
          break;
        default:
          toolResponse = { success: false, error: 'Unknown tool' };
      }

      // Send the tool response back to the model to generate a final message
      response = await chat.sendMessage({
        message: [
          {
            functionResponse: {
              name: call.name,
              response: toolResponse,
            },
          },
        ],
      } as any); // SDK type workaround for tool response in sendMessage
    }

    return {
      success: true,
      text: response.text || "I processed your request but have no further details.",
      history: await chat.getHistory(),
    };
  } catch (error: any) {
    console.error('Chat processing error:', error.message);
    return {
      success: false,
      text: "I encountered an error while processing your request. Please check your API configuration.",
      error: error.message,
    };
  }
}
