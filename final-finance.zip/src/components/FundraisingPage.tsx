import React, { useState, useMemo, useRef, useEffect } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import {
  Target,
  Plus,
  TrendingUp,
  Users,
  DollarSign,
  Coins,
  Repeat,
  Search,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Building,
  PauseCircle,
  PlayCircle,
  Image as ImageIcon,
  Video,
  UploadCloud,
  X,
  HeartHandshake,
  Sparkles,
  ArrowUpRight,
  Receipt,
  UserCheck,
  Layers,
  Flame,
  Award,
  Zap,
  Globe,
  FileText,
  Lock,
  Power
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import {
  UserCampaign,
  UploadedMedia,
  getUserInvolvedCampaigns,
  isUserCampaignInitiator,
  isUserCampaignDonor,
  getUserDonationsForCampaign,
  getUserTotalDonatedToCampaign,
  createCampaign,
  updateCampaignStatus,
  donateToCampaign,
  getAllCampaigns,
  getTrendingCharityOfTheDay
} from '../services/fundraisingService';
import { CampaignDetailPage } from './CampaignDetailPage';

interface FundraisingPageProps {
  currentUser?: AuthSession | null;
  onOpenAuthModal?: () => void;
}

export const FundraisingPage: React.FC<FundraisingPageProps> = ({
  currentUser,
  onOpenAuthModal,
}) => {
  const { addToast, addNotification } = useApp();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const activeUserId = currentUser?.id || currentUser?.uid || 'you';

  // Role filter: all / initiated / donated / paused_by_me / explore (by others)
  const [roleFilter, setRoleFilter] = useState<'all' | 'initiated' | 'donated' | 'paused_by_me' | 'others'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'completed' | 'paused'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCampaignForDetail, setSelectedCampaignForDetail] = useState<UserCampaign | null>(null);

  const openCampaignDetail = (campaignToOpen: UserCampaign) => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    setSelectedCampaignForDetail(campaignToOpen);
  };
  
  // Campaigns list state: fetches based on filter
  const [campaigns, setCampaigns] = useState<UserCampaign[]>(() => {
    const all = getAllCampaigns();
    return all;
  });

  const trendingCharity = useMemo(() => {
    return getTrendingCharityOfTheDay();
  }, [campaigns]);

  // Reload data when user or filter changes
  useEffect(() => {
    const all = getAllCampaigns();
    if (roleFilter === 'all') {
      setCampaigns(all);
    } else if (roleFilter === 'initiated') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId)));
    } else if (roleFilter === 'donated') {
      setCampaigns(all.filter((c) => isUserCampaignDonor(c, activeUserId)));
    } else if (roleFilter === 'paused_by_me') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId) && c.status === 'paused'));
    } else if (roleFilter === 'others') {
      setCampaigns(all.filter((c) => !isUserCampaignInitiator(c, activeUserId) && !isUserCampaignDonor(c, activeUserId)));
    }
  }, [activeUserId, roleFilter]);

  const refreshCampaigns = () => {
    const all = getAllCampaigns();
    if (roleFilter === 'all') {
      setCampaigns(all);
    } else if (roleFilter === 'initiated') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId)));
    } else if (roleFilter === 'donated') {
      setCampaigns(all.filter((c) => isUserCampaignDonor(c, activeUserId)));
    } else if (roleFilter === 'paused_by_me') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId) && c.status === 'paused'));
    } else if (roleFilter === 'others') {
      setCampaigns(all.filter((c) => !isUserCampaignInitiator(c, activeUserId) && !isUserCampaignDonor(c, activeUserId)));
    }
  };

  // Create Campaign Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'Tech & AI' | 'Clean Energy' | 'Community' | 'Infrastructure' | 'Creative'>('Tech & AI');
  const [newShortDesc, setNewShortDesc] = useState('');

  // Target Modalities State
  const [acceptsFiat, setAcceptsFiat] = useState(true);
  const [fiatAmount, setFiatAmount] = useState('50000');
  const [acceptsFinalCoins, setAcceptsFinalCoins] = useState(true);
  const [finalCoinsAmount, setFinalCoinsAmount] = useState('25000');
  const [acceptsStablecoins, setAcceptsStablecoins] = useState(false);
  const [stablecoinsAmount, setStablecoinsAmount] = useState('0');
  const [acceptsCrypto, setAcceptsCrypto] = useState(false);
  const [cryptoAmount, setCryptoAmount] = useState('0');
  const [acceptsBarter, setAcceptsBarter] = useState(false);
  const [barterDescription, setBarterDescription] = useState('');
  const [barterEstimatedValueUSD, setBarterEstimatedValueUSD] = useState('0');

  // End Date & Time State (Default 30 days from now)
  const defaultFutureDate = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    const dateStr = d.toISOString().split('T')[0];
    return `${dateStr}T18:00`;
  }, []);
  const [endDateTime, setEndDateTime] = useState(defaultFutureDate);

  // Uploaded Photos & Videos
  const [uploadedMediaList, setUploadedMediaList] = useState<UploadedMedia[]>([]);

  // Donation / Backing Modal State
  const [selectedDonationCampaign, setSelectedDonationCampaign] = useState<UserCampaign | null>(null);
  const [donationModality, setDonationModality] = useState<string>('Final Coins (FC)');
  const [donationAmount, setDonationAmount] = useState<string>('500');
  const [donationMessage, setDonationMessage] = useState<string>('');

  // Audit Ledger Modal State
  const [selectedAuditCampaign, setSelectedAuditCampaign] = useState<UserCampaign | null>(null);

  // Calculated Combined Target for creation
  const calculatedTotalUSD = useMemo(() => {
    let total = 0;
    if (acceptsFiat) total += parseFloat(fiatAmount) || 0;
    if (acceptsFinalCoins) total += parseFloat(finalCoinsAmount) || 0;
    if (acceptsStablecoins) total += parseFloat(stablecoinsAmount) || 0;
    if (acceptsCrypto) total += parseFloat(cryptoAmount) || 0;
    if (acceptsBarter) total += parseFloat(barterEstimatedValueUSD) || 0;
    return total;
  }, [
    acceptsFiat,
    fiatAmount,
    acceptsFinalCoins,
    finalCoinsAmount,
    acceptsStablecoins,
    stablecoinsAmount,
    acceptsCrypto,
    cryptoAmount,
    acceptsBarter,
    barterEstimatedValueUSD,
  ]);

  // Handle File Upload (Photos & Videos)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newItems: UploadedMedia[] = [];

    Array.from(files).forEach((file: File) => {
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isImage && !isVideo) {
        addToast({
          type: 'error',
          title: 'Unsupported File Format',
          message: `${file.name} is not a valid image or video file.`,
        });
        return;
      }

      const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
      const objectUrl = URL.createObjectURL(file);

      newItems.push({
        id: `media-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        url: objectUrl,
        name: file.name,
        type: isVideo ? 'video' : 'image',
        sizeFormatted: `${sizeInMB} MB`,
      });
    });

    if (newItems.length > 0) {
      setUploadedMediaList((prev) => [...prev, ...newItems]);
      addToast({
        type: 'success',
        title: 'Media Uploaded',
        message: `Added ${newItems.length} file(s) to campaign gallery.`,
      });
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveMedia = (id: string) => {
    setUploadedMediaList((prev) => prev.filter((m) => m.id !== id));
  };

  // Helper to format remaining time
  const formatTimeRemaining = (isoString: string) => {
    const target = new Date(isoString).getTime();
    const now = Date.now();
    const diffMs = target - now;

    if (diffMs <= 0) {
      return { text: 'Campaign Concluded', expired: true };
    }

    const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (days > 0) {
      return { text: `${days}d ${hours}h left`, expired: false };
    }
    return { text: `${hours}h ${minutes}m left`, expired: false };
  };

  // Filtered campaigns strictly based on user role + status + search
  const filteredCampaigns = useMemo(() => {
    return campaigns.filter((c) => {
      const matchStatus = filterStatus === 'all' ? true : c.status === filterStatus;
      const matchSearch =
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.creatorName.toLowerCase().includes(searchQuery.toLowerCase());
      return matchStatus && matchSearch;
    });
  }, [campaigns, filterStatus, searchQuery]);

  // Aggregate Stats for User's portfolio
  const stats = useMemo(() => {
    const all = getAllCampaigns();
    const allInvolved = getUserInvolvedCampaigns(activeUserId, 'all');
    const initiated = all.filter((c) => isUserCampaignInitiator(c, activeUserId));
    const backed = all.filter((c) => isUserCampaignDonor(c, activeUserId));
    const pausedByMe = initiated.filter((c) => c.status === 'paused');

    const totalTarget = allInvolved.reduce((sum, c) => sum + c.targetAmountUSD, 0);
    const totalRaised = allInvolved.reduce((sum, c) => sum + c.raisedAmountUSD, 0);
    const totalBackers = allInvolved.reduce((sum, c) => sum + c.backersCount, 0);
    const activeCount = all.filter((c) => c.status === 'active').length;
    const completedCount = all.filter((c) => c.status === 'completed').length;
    
    // User total contributions as a donor across all campaigns
    let userDonatedTotal = 0;
    all.forEach((c) => {
      userDonatedTotal += getUserTotalDonatedToCampaign(c, activeUserId);
    });

    const overallProgress = totalTarget > 0 ? Math.min(100, Math.round((totalRaised / totalTarget) * 100)) : 0;
    return {
      totalTarget,
      totalRaised,
      totalBackers,
      activeCount,
      completedCount,
      overallProgress,
      initiatedCount: initiated.length,
      backedCount: backed.length,
      pausedByMeCount: pausedByMe.length,
      othersCount: all.filter(c => !isUserCampaignInitiator(c, activeUserId) && !isUserCampaignDonor(c, activeUserId)).length,
      userDonatedTotal,
      allCount: all.length,
    };
  }, [campaigns, activeUserId]);

  // Toggle status handler for campaigns user initiated
  const handleToggleStatus = (campId: string, nextStatus: 'active' | 'paused' | 'completed') => {
    updateCampaignStatus(campId, nextStatus);
    refreshCampaigns();
    addToast({
      type: 'info',
      title: 'Campaign Status Updated',
      message: nextStatus === 'completed' 
        ? 'Campaign has been successfully ENDED and archived.' 
        : `Campaign has been set to ${nextStatus.toUpperCase()}.`,
    });
  };

  // Create Campaign Submit
  const handleCreateCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuthModal?.();
      return;
    }

    if (!newTitle.trim()) {
      addToast({
        type: 'error',
        title: 'Validation Error',
        message: 'Please provide a campaign title.',
      });
      return;
    }

    if (!acceptsFiat && !acceptsFinalCoins && !acceptsStablecoins && !acceptsCrypto && !acceptsBarter) {
      addToast({
        type: 'error',
        title: 'Funding Target Required',
        message: 'Select at least one currency or barter modality for your funding target.',
      });
      return;
    }

    if (calculatedTotalUSD <= 0 && !acceptsBarter) {
      addToast({
        type: 'error',
        title: 'Invalid Target',
        message: 'Please specify a funding target amount greater than $0.',
      });
      return;
    }

    // Build accepted modalities labels
    const modalities: string[] = [];
    if (acceptsFiat) modalities.push(`Fiat ($${(parseFloat(fiatAmount) || 0).toLocaleString()})`);
    if (acceptsFinalCoins) modalities.push(`Final Coins (${(parseFloat(finalCoinsAmount) || 0).toLocaleString()} FC)`);
    if (acceptsStablecoins) modalities.push(`Stablecoins ($${(parseFloat(stablecoinsAmount) || 0).toLocaleString()})`);
    if (acceptsCrypto) modalities.push(`Crypto ($${(parseFloat(cryptoAmount) || 0).toLocaleString()})`);
    if (acceptsBarter) modalities.push(`Barter: ${barterDescription.slice(0, 30) || 'Goods & Services'}`);

    // Determine banner URL from first uploaded media or fallback
    let banner = 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80';
    if (uploadedMediaList.length > 0) {
      banner = uploadedMediaList[0].url;
    }

    const created = createCampaign({
      title: newTitle.trim(),
      creatorId: currentUser.id || 'you',
      creatorName: currentUser.name || 'You (Current User)',
      creatorHandle: currentUser.id || 'you',
      creatorAvatar: currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      category: newCategory,
      shortDescription: newShortDesc.trim() || 'Community-backed sovereign initiative on Final Finance.',
      fullStory: newShortDesc.trim() || 'Full milestone blueprint and documentation verified in vault escrow.',
      targetBreakdown: {
        acceptsFiat,
        fiatAmount: parseFloat(fiatAmount) || 0,
        acceptsFinalCoins,
        finalCoinsAmount: parseFloat(finalCoinsAmount) || 0,
        acceptsStablecoins,
        stablecoinsAmount: parseFloat(stablecoinsAmount) || 0,
        acceptsCrypto,
        cryptoAmount: parseFloat(cryptoAmount) || 0,
        acceptsBarter,
        barterDescription: barterDescription.trim(),
        barterEstimatedValueUSD: parseFloat(barterEstimatedValueUSD) || 0,
      },
      targetAmountUSD: calculatedTotalUSD || 10000,
      raisedAmountUSD: 0,
      backersCount: 0,
      endDateTime: endDateTime || defaultFutureDate,
      status: 'active',
      acceptedModalities: modalities,
      mediaList: uploadedMediaList,
      bannerUrl: banner,
      verifiedCreator: true,
      featured: true,
    });

    refreshCampaigns();
    setIsCreateModalOpen(false);

    // Reset fields
    setNewTitle('');
    setNewShortDesc('');
    setFiatAmount('50000');
    setFinalCoinsAmount('25000');
    setBarterDescription('');
    setBarterEstimatedValueUSD('0');
    setUploadedMediaList([]);

    addToast({
      type: 'success',
      title: 'Campaign Created',
      message: `"${created.title}" with target $${created.targetAmountUSD.toLocaleString()} is now live!`,
    });

    addNotification({
      title: `🚀 Fundraising Campaign Launched: ${created.title}`,
      description: `Target of $${created.targetAmountUSD.toLocaleString()} USD opened for community backing across multiple modalities.`,
      type: 'fundraising',
      targetTab: 'fundraising',
      amount: created.targetAmountUSD,
      currency: 'USD',
    });
  };

  // Handle Donation Submit
  const handleDonateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDonationCampaign) return;
    if (!currentUser) {
      onOpenAuthModal?.();
      return;
    }

    const amt = parseFloat(donationAmount);
    if (!amt || amt <= 0) {
      addToast({
        type: 'error',
        title: 'Invalid Contribution',
        message: 'Please enter a valid contribution amount greater than 0.',
      });
      return;
    }

    const success = donateToCampaign(selectedDonationCampaign.id, {
      donorId: currentUser.id || 'you',
      donorHandle: currentUser.id || 'you',
      donorName: currentUser.name || 'You (Current User)',
      donorAvatar: currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      amountUSD: amt,
      modality: donationModality,
      message: donationMessage.trim() || undefined,
    });

    if (success) {
      addToast({
        type: 'success',
        title: 'Donation Confirmed',
        message: `You successfully contributed $${amt.toLocaleString()} via ${donationModality} to "${selectedDonationCampaign.title}".`,
      });
      addNotification({
        title: `🤝 Contribution Confirmed: $${amt.toLocaleString()} USD`,
        description: `You backed "${selectedDonationCampaign.title}" via ${donationModality}.`,
        type: 'fundraising',
        targetTab: 'fundraising',
        amount: amt,
        currency: 'USD',
      });
      refreshCampaigns();
      setSelectedDonationCampaign(null);
      setDonationAmount('500');
      setDonationMessage('');
    }
  };

  if (selectedCampaignForDetail) {
    return (
      <div className="space-y-6">
        <CampaignDetailPage
          campaign={selectedCampaignForDetail}
          currentUser={currentUser}
          onBack={() => {
            window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
            if (document.documentElement) document.documentElement.scrollTop = 0;
            if (document.body) document.body.scrollTop = 0;
            setSelectedCampaignForDetail(null);
          }}
          onRefresh={() => {
            refreshCampaigns();
            const all = getAllCampaigns();
            const updated = all.find((c) => c.id === selectedCampaignForDetail.id);
            if (updated) setSelectedCampaignForDetail(updated);
          }}
          onOpenAuthModal={onOpenAuthModal}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-16">
      {/* Search Bar Above the Box */}
      <div className="max-w-2xl mx-auto w-full">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search campaigns, creators, categories, tags..."
            className="w-full pl-9.5 pr-8 py-2.5 text-xs sm:text-sm rounded-2xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-xs"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 rounded-lg cursor-pointer"
              title="Clear search query"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Trending Campaign Feed */}
      <div className="max-w-2xl mx-auto w-full space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider font-mono">🔥 Trending Feed</span>
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <span className="text-[10px] text-slate-400 font-medium">Real-time Backing Velocity</span>
        </div>

        <div className="flex gap-3 overflow-x-auto pb-2 snap-x scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
          {campaigns.filter(c => c.status === 'active').slice(0, 4).map((camp, idx) => {
            const growthRate = idx === 0 ? '+480%' : idx === 1 ? '+325%' : idx === 2 ? '+210%' : '+180%';
            const fundPercent = Math.min(100, Math.round((camp.raisedAmountUSD / camp.targetAmountUSD) * 100));
            
            return (
              <div
                key={camp.id}
                onClick={() => {
                  window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
                  setSelectedCampaignForDetail(camp);
                }}
                className="snap-start shrink-0 w-64 bg-white border border-slate-200/80 hover:border-emerald-500/30 rounded-2xl p-3.5 hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between space-y-3"
              >
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-slate-100 bg-slate-50">
                    <img src={camp.bannerUrl} alt={camp.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 font-mono">
                        {growthRate}
                      </span>
                      <span className="text-[9px] font-mono text-slate-400 truncate">{camp.creatorName}</span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mt-1 line-clamp-1 leading-snug">{camp.title}</h4>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span>${camp.raisedAmountUSD.toLocaleString()} raised</span>
                    <span className="font-bold text-slate-700">{fundPercent}%</span>
                  </div>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${fundPercent}%` }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sovereign Header with Create Campaign Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5 max-w-4xl mx-auto w-full">
        <div>
          <h1 className="text-2xl font-bold font-serif text-slate-950 tracking-tight">Campaigns</h1>
          <p className="text-xs text-slate-500">Create, fund, and manage community backing initiatives with multi-asset support.</p>
        </div>
        <button
          type="button"
          onClick={() => {
            if (!currentUser) {
              onOpenAuthModal?.();
            } else {
              setIsCreateModalOpen(true);
            }
          }}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Campaign</span>
        </button>
      </div>

      {/* Filter Row: Role Selector Tabs + Status Tabs */}
      <div className="space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs max-w-full scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
            <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider mr-1 whitespace-nowrap shrink-0">
              Involvement:
            </span>
            <button
              type="button"
              onClick={() => setRoleFilter('all')}
              className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                roleFilter === 'all'
                  ? 'bg-neutral-900 text-white shadow-2xs'
                  : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
              }`}
            >
              <span>All Campaigns</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${roleFilter === 'all' ? 'bg-neutral-800 text-emerald-400' : 'bg-neutral-100 text-neutral-600'}`}>
                {getAllCampaigns().length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setRoleFilter('initiated')}
              className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                roleFilter === 'initiated'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>Initiated by Me</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${roleFilter === 'initiated' ? 'bg-emerald-700 text-white' : 'bg-neutral-100 text-neutral-600'}`}>
                {stats.initiatedCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setRoleFilter('donated')}
              className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                roleFilter === 'donated'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5 text-blue-300" />
              <span>Backed by Me</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${roleFilter === 'donated' ? 'bg-blue-700 text-white' : 'bg-neutral-100 text-neutral-600'}`}>
                {stats.backedCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setRoleFilter('paused_by_me')}
              className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                roleFilter === 'paused_by_me'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
              }`}
            >
              <PauseCircle className="w-3.5 h-3.5 text-amber-300" />
              <span>Paused by Me</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${roleFilter === 'paused_by_me' ? 'bg-amber-700 text-white' : 'bg-neutral-100 text-neutral-600'}`}>
                {stats.pausedByMeCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setRoleFilter('others')}
              className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                roleFilter === 'others'
                  ? 'bg-purple-600 text-white shadow-2xs'
                  : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-purple-300" />
              <span>By Others</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${roleFilter === 'others' ? 'bg-purple-700 text-white' : 'bg-neutral-100 text-neutral-600'}`}>
                {stats.othersCount}
              </span>
            </button>
          </div>

          {/* Status Pills */}
          <div className="flex items-center gap-1 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/80 overflow-x-auto max-w-full shrink-0 scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
            {[
              { id: 'all', label: 'All Statuses', count: campaigns.length },
              { id: 'active', label: 'Active', count: campaigns.filter((c) => c.status === 'active').length },
              { id: 'completed', label: 'Completed', count: campaigns.filter((c) => c.status === 'completed').length },
              { id: 'paused', label: 'Paused', count: campaigns.filter((c) => c.status === 'paused').length },
            ].map((tab) => {
              const isActive = filterStatus === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilterStatus(tab.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 shrink-0 ${
                    isActive ? 'bg-neutral-900 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                      isActive
                        ? 'bg-neutral-800 text-emerald-400 font-bold'
                        : 'bg-white/80 text-slate-500 border border-slate-200/60'
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>



      {/* Campaigns List (Cards / Rows) */}
      <div className="space-y-4">
        {filteredCampaigns.map((camp) => {
          const isInitiator = isUserCampaignInitiator(camp, activeUserId);
          const isDonor = isUserCampaignDonor(camp, activeUserId);
          const userDonations = getUserDonationsForCampaign(camp, activeUserId);
          const userTotalDonated = getUserTotalDonatedToCampaign(camp, activeUserId);

          const progressPercent = Math.min(100, Math.round((camp.raisedAmountUSD / camp.targetAmountUSD) * 100));
          const timeInfo = formatTimeRemaining(camp.endDateTime);

          return (
            <div
              key={camp.id}
              className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:border-slate-300 hover:shadow-md transition-all space-y-4 group/card"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
                {/* Left: Thumbnail & Main Info (Clickable to open Detail Page) */}
                <div className="flex items-start gap-4 min-w-0 flex-1">
                  <div
                    onClick={() => openCampaignDetail(camp)}
                    className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-slate-100 overflow-hidden shrink-0 border border-slate-200 cursor-pointer group"
                    title="Click to view full campaign details"
                  >
                    <img
                      src={camp.bannerUrl}
                      alt={camp.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-1.5 left-1.5 flex flex-col gap-1">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                          camp.status === 'active'
                            ? 'bg-emerald-500 text-slate-950'
                            : camp.status === 'completed'
                            ? 'bg-sky-500 text-white'
                            : 'bg-amber-500 text-slate-950'
                        }`}
                      >
                        {camp.status}
                      </span>
                      {camp.mediaList && camp.mediaList.some((m) => m.type === 'video') && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase bg-purple-600 text-white flex items-center gap-0.5">
                          <Video className="w-2.5 h-2.5" />
                          Video
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="min-w-0 space-y-1.5 flex-1">
                    {/* Role Badges & Category */}
                    <div className="flex flex-wrap items-center gap-2">
                      {isInitiator && camp.status === 'paused' && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold shadow-2xs">
                          <PauseCircle className="w-3.5 h-3.5 text-amber-700" />
                          <span>Paused by Me</span>
                        </span>
                      )}

                      {isInitiator && isDonor ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-950 border border-emerald-300 font-bold shadow-2xs">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Initiated & Co-Backed (${userTotalDonated.toLocaleString()})</span>
                        </span>
                      ) : isInitiator ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold shadow-2xs">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Initiated by Me</span>
                        </span>
                      ) : isDonor ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 border border-blue-300 font-bold shadow-2xs">
                          <HeartHandshake className="w-3.5 h-3.5 text-blue-700" />
                          <span>Backed by Me • ${userTotalDonated.toLocaleString()} Contributed</span>
                        </span>
                      ) : null}

                      {camp.isTrendingToday && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold shadow-2xs">
                          <Flame className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                          <span>Top Trending Charity ({camp.trendingGrowth24h || '+520% today'})</span>
                        </span>
                      )}

                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 font-semibold">
                        {camp.category}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">
                        Lead: {camp.creatorName}
                      </span>
                    </div>

                    <h3
                      onClick={() => openCampaignDetail(camp)}
                      className="font-serif text-base sm:text-lg font-bold text-slate-900 line-clamp-1 hover:text-emerald-700 transition-colors cursor-pointer flex items-center gap-1.5 group/title"
                    >
                      <span>{camp.title}</span>
                      <ArrowUpRight className="w-4 h-4 opacity-0 group-hover/title:opacity-100 transition-opacity text-emerald-600" />
                    </h3>

                    <p
                      onClick={() => openCampaignDetail(camp)}
                      className="text-xs text-slate-600 line-clamp-2 leading-relaxed cursor-pointer hover:text-slate-900"
                    >
                      {camp.shortDescription}
                    </p>

                    {/* Target Modalities Breakdown Chips */}
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      <span className="text-[10px] font-mono text-slate-400 mr-0.5">Target Mix:</span>
                      {camp.acceptedModalities.map((mod, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-50 text-slate-700 border border-slate-200"
                        >
                          {mod}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Middle: Progress Bar & Numeric Data */}
                <div
                  onClick={() => openCampaignDetail(camp)}
                  className="lg:w-72 space-y-2 lg:px-4 lg:border-l lg:border-r border-slate-100 shrink-0 cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-emerald-700 text-sm">
                        ${camp.raisedAmountUSD.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono ml-1">
                        / ${camp.targetAmountUSD.toLocaleString()}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-slate-900 text-xs">
                      {progressPercent}%
                    </span>
                  </div>

                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        camp.status === 'completed'
                          ? 'bg-sky-500'
                          : camp.status === 'paused'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-0.5">
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-slate-400" />
                      <span>{camp.backersCount} Backers</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span className={timeInfo.expired ? 'text-amber-700 font-semibold' : 'text-slate-600'}>
                        {camp.status === 'completed' ? 'Goal Met' : timeInfo.text}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="grid grid-cols-1 sm:grid-cols-3 lg:flex lg:flex-col gap-2 shrink-0 w-full lg:w-44">
                  {/* Donate / Back Campaign Button */}
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedDonationCampaign(camp);
                      setDonationModality(camp.acceptedModalities[0] || 'Final Coins (FC)');
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer w-full justify-center shadow-xs"
                  >
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>{isDonor ? 'Contribute More' : 'Back / Donate'}</span>
                  </button>

                   {/* If user is initiator, allow pausing / resuming and ending */}
                  {isInitiator && (
                    <>
                      {camp.status === 'active' ? (
                        <>
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(camp.id, 'paused')}
                            className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer w-full justify-center"
                          >
                            <PauseCircle className="w-3.5 h-3.5 text-amber-600" />
                            <span>Pause</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm('Are you sure you want to end this campaign? This will mark it as Completed and archive active pledges.')) {
                                handleToggleStatus(camp.id, 'completed');
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer w-full justify-center"
                            title="End Campaign and archive/claim escrow backing pledges."
                          >
                            <Power className="w-3.5 h-3.5 text-rose-600" />
                            <span>End Campaign</span>
                          </button>
                        </>
                      ) : camp.status === 'paused' ? (
                        <>
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(camp.id, 'active')}
                            className="px-3 py-1.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer w-full justify-center"
                          >
                            <PlayCircle className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Resume</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm('Are you sure you want to end this campaign? This will mark it as Completed and archive active pledges.')) {
                                handleToggleStatus(camp.id, 'completed');
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer w-full justify-center"
                            title="End Campaign and archive/claim escrow backing pledges."
                          >
                            <Power className="w-3.5 h-3.5 text-rose-600" />
                            <span>End Campaign</span>
                          </button>
                        </>
                      ) : null}
                    </>
                  )}

                  {/* Audit Ledger Button with Access Validation */}
                  {(isInitiator || currentUser?.role === 'admin' || currentUser?.role === 'super_admin') && (
                    <button
                      type="button"
                      onClick={() => setSelectedAuditCampaign(camp)}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer w-full justify-center border border-slate-200"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Audit Vault</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Donor Contribution Sub-Panel (if user has donated) */}
              {isDonor && userDonations.length > 0 && (
                <div className="pt-3 border-t border-slate-100 bg-slate-50/60 -mx-5 sm:-mx-6 -mb-5 sm:-mb-6 p-4 rounded-b-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-blue-600 shrink-0" />
                    <span className="font-semibold text-slate-800">
                      Your Contribution Receipt:
                    </span>
                    <span className="font-mono font-bold text-blue-700">
                      ${userTotalDonated.toLocaleString()} USD
                    </span>
                    <span className="text-slate-500 font-mono text-[11px]">
                      ({userDonations.length} transaction{userDonations.length > 1 ? 's' : ''})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-500">
                      Last: {userDonations[0].modality} on {new Date(userDonations[0].timestamp).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {filteredCampaigns.length === 0 && (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 max-w-lg mx-auto space-y-4">
            <Target className="w-12 h-12 text-slate-300 mx-auto" />
            <div>
              <h3 className="text-base font-bold text-slate-900">No campaigns found</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                {roleFilter === 'initiated'
                  ? "You haven't initiated any fundraising campaigns yet."
                  : roleFilter === 'donated'
                  ? "You haven't contributed to any campaigns as a donor yet."
                  : "Only campaigns you have initiated or donated to are displayed here."}
              </p>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setRoleFilter('all');
                  setFilterStatus('all');
                  setSearchQuery('');
                }}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-800 transition-colors cursor-pointer"
              >
                Reset Filters
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!currentUser) {
                    onOpenAuthModal?.();
                  } else {
                    setIsCreateModalOpen(true);
                  }
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Launch a Campaign</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ================= MODAL: DONATE / BACK CAMPAIGN ================= */}
      <AnimatePresence>
        {selectedDonationCampaign && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden"
            >
              <div className="p-5 bg-neutral-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <HeartHandshake className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono uppercase text-emerald-400 font-semibold block">
                      Escrow Backing Pledge
                    </span>
                    <h3 className="font-serif text-base font-bold text-white truncate max-w-[280px]">
                      {selectedDonationCampaign.title}
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedDonationCampaign(null)}
                  className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleDonateSubmit} className="p-6 space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">
                    Select Contribution Modality
                  </label>
                  <select
                    value={donationModality}
                    onChange={(e) => setDonationModality(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
                  >
                    <option value="Final Coins (FC)">Final Coins (FC)</option>
                    <option value="Fiat USD Wire / Card">Fiat USD ($)</option>
                    <option value="USDC / USDT Stablecoins">USDC / USDT Stablecoins</option>
                    <option value="BTC / ETH Crypto Reserve">Crypto (BTC / ETH / SOL)</option>
                    <option value="Physical Equipment / Barter">Physical Barter Hardware</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1 flex items-center justify-between">
                    <span>Contribution Amount (USD Value)</span>
                    <span className="text-[11px] font-mono text-emerald-700 font-semibold">
                      Goal: ${selectedDonationCampaign.targetAmountUSD.toLocaleString()}
                    </span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                      $
                    </span>
                    <input
                      type="number"
                      min="1"
                      value={donationAmount}
                      onChange={(e) => setDonationAmount(e.target.value)}
                      placeholder="500"
                      className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>

                {/* Quick amount chips */}
                <div className="flex items-center gap-2">
                  {[100, 500, 1000, 5000].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setDonationAmount(val.toString())}
                      className="px-2.5 py-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-[11px] font-mono font-medium text-slate-700 cursor-pointer"
                    >
                      +${val}
                    </button>
                  ))}
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-900 block mb-1">
                    Public Note or Barter Specification (Optional)
                  </label>
                  <input
                    type="text"
                    value={donationMessage}
                    onChange={(e) => setDonationMessage(e.target.value)}
                    placeholder="e.g. Backing green tech milestone with verified compute nodes."
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  />
                </div>

                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-900 leading-relaxed">
                  <span className="font-bold block">Sovereign Vault Guarantee:</span>
                  Your donation is held securely in the multi-signatory escrow vault until campaign milestone delivery.
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedDonationCampaign(null)}
                    className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/20"
                  >
                    <HeartHandshake className="w-4 h-4" />
                    <span>Confirm Pledge</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: AUDIT VAULT LEDGER ================= */}
      <AnimatePresence>
        {selectedAuditCampaign && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full overflow-hidden"
            >
              <div className="p-5 bg-neutral-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono uppercase text-emerald-400 font-semibold block">
                      Audited Escrow Ledger
                    </span>
                    <h3 className="font-serif text-base font-bold text-white truncate max-w-[320px]">
                      {selectedAuditCampaign.title}
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedAuditCampaign(null)}
                  className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                {!(isUserCampaignInitiator(selectedAuditCampaign, activeUserId) || currentUser?.role === 'admin' || currentUser?.role === 'super_admin') ? (
                  <div className="p-6 text-center space-y-4">
                    <div className="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center mx-auto text-rose-500">
                      <Lock className="w-8 h-8" />
                    </div>
                    <div className="space-y-1.5">
                      <h4 className="font-bold text-slate-900 text-sm">Access Denied: Restricted Vault</h4>
                      <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                        This campaign was not initiated by you. Under Final Finance zero-knowledge escrow protocols, donor ledgers and transaction audit books are strictly private to the Initiator, Campaign Lead, and authorized Governance Administrators.
                      </p>
                    </div>
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[10px] text-slate-500 text-left space-y-1">
                      <div>• Current User Handle: <span className="font-mono font-bold text-slate-700">@{currentUser?.id || 'guest'}</span></div>
                      <div>• Authorization Status: <span className="text-rose-600 font-bold font-mono">UNAUTHORIZED</span></div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedAuditCampaign(null)}
                      className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      Return to Dashboard
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                        <span className="text-[10px] font-mono text-slate-400 block uppercase">Target Goal</span>
                        <span className="text-base font-bold font-mono text-slate-900">
                          ${selectedAuditCampaign.targetAmountUSD.toLocaleString()}
                        </span>
                      </div>
                      <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200">
                        <span className="text-[10px] font-mono text-emerald-700 block uppercase">Locked in Escrow</span>
                        <span className="text-base font-bold font-mono text-emerald-800">
                          ${selectedAuditCampaign.raisedAmountUSD.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-xs font-mono uppercase font-bold text-slate-700">
                          Verified Donor Transactions ({selectedAuditCampaign.donations?.length || 0})
                        </h4>
                        <span className="text-[10px] font-mono text-slate-400">
                          Private Audit View
                        </span>
                      </div>
                      {selectedAuditCampaign.donations && selectedAuditCampaign.donations.length > 0 ? (
                        <div className="space-y-2">
                          {selectedAuditCampaign.donations.map((don) => (
                            <div
                              key={don.id}
                              className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 flex flex-col gap-2 text-xs"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2.5">
                                  <img
                                    src={don.donorAvatar}
                                    alt={don.donorName}
                                    className="w-7 h-7 rounded-full object-cover border border-slate-200"
                                  />
                                  <div>
                                    <span className="font-semibold text-slate-900 block">{don.donorName}</span>
                                    <span className="text-[10px] font-mono text-slate-500">
                                      @{don.donorHandle || 'anonymous'} • {new Date(don.timestamp).toLocaleDateString()}
                                    </span>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <span className="font-mono font-bold text-emerald-700 block">
                                    +${don.amountUSD.toLocaleString()} USD
                                  </span>
                                  <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded border border-slate-200/50">
                                    {don.modality}
                                  </span>
                                </div>
                              </div>
                              {don.message && (
                                <div className="mt-1 p-2 bg-white rounded-lg border border-slate-200/60 text-[11px] text-slate-600 leading-relaxed">
                                  <span className="font-bold text-[10px] text-slate-400 uppercase tracking-wider block mb-0.5 font-mono">
                                    Contribution Item / Note Detail
                                  </span>
                                  "{don.message}"
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="p-4 text-center rounded-xl bg-slate-50 border border-slate-200 text-slate-500 text-xs">
                          No external donor transactions recorded yet.
                        </div>
                      )}
                    </div>

                    <div className="p-3 bg-neutral-900 text-neutral-300 rounded-2xl text-[11px] font-mono space-y-1">
                      <div className="flex justify-between">
                        <span className="text-neutral-400">Escrow Address:</span>
                        <span className="text-emerald-400">0x7F9B...4e92</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-400">Audit Status:</span>
                        <span className="text-emerald-400">100% Cryptographically Verified</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-400">Expiry Threshold:</span>
                        <span>{new Date(selectedAuditCampaign.endDateTime).toLocaleString()}</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setSelectedAuditCampaign(null)}
                      className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer"
                    >
                      Close Audit Ledger
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: LAUNCH NEW CAMPAIGN ================= */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full my-8 overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-6 bg-neutral-900 text-white flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-semibold block">
                    Sovereign Multi-Asset Proposal
                  </span>
                  <h3 className="font-serif text-lg font-bold text-white mt-0.5">
                    Launch Fundraising Campaign
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form Body */}
              <form onSubmit={handleCreateCampaign} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
                {/* 1. Basic Info */}
                <div className="space-y-3">
                  <h4 className="text-xs font-mono uppercase font-bold text-slate-500 tracking-wider">
                    1. Campaign Overview
                  </h4>

                  <div>
                    <label className="text-xs font-bold text-slate-900 block mb-1">
                      Campaign Title
                    </label>
                    <input
                      type="text"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="e.g., Autonomous Solar Microgrid Protocol"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-900 block mb-1">
                        Category
                      </label>
                      <select
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value as any)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
                      >
                        <option value="Tech & AI">Tech &amp; AI</option>
                        <option value="Clean Energy">Clean Energy</option>
                        <option value="Community">Community</option>
                        <option value="Infrastructure">Infrastructure</option>
                        <option value="Creative">Creative</option>
                      </select>
                    </div>

                    {/* Date and Time End Picker */}
                    <div>
                      <label className="text-xs font-bold text-slate-900 block mb-1 flex items-center justify-between">
                        <span>Campaign End Date &amp; Time</span>
                        <span className="text-[10px] text-slate-400 font-mono font-normal">Exact Expiry</span>
                      </label>
                      <div className="relative">
                        <input
                          type="datetime-local"
                          value={endDateTime}
                          onChange={(e) => setEndDateTime(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-900 block mb-1">
                      Short Description &amp; Deliverables
                    </label>
                    <textarea
                      value={newShortDesc}
                      onChange={(e) => setNewShortDesc(e.target.value)}
                      placeholder="Explain the project scope, hardware deliverables, or barter milestones..."
                      rows={3}
                      className="w-full p-3 rounded-xl border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>

                {/* 2. Funding Target Options (Barter, 4 Currencies, Combo) */}
                <div className="space-y-4 pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-mono uppercase font-bold text-slate-500 tracking-wider">
                        2. Funding Target &amp; Modality Selection
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Choose any currency type, barter equipment, or a combination mix.
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-mono text-slate-400 block uppercase">Total Target Value</span>
                      <span className="text-sm font-bold font-mono text-emerald-700">
                        ${calculatedTotalUSD.toLocaleString()} USD Eq.
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* 1. Final Coins (FC) */}
                    <div
                      className={`p-3.5 rounded-2xl border transition-all ${
                        acceptsFinalCoins ? 'border-emerald-500 bg-emerald-50/40' : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={acceptsFinalCoins}
                            onChange={(e) => setAcceptsFinalCoins(e.target.checked)}
                            className="rounded text-emerald-600 focus:ring-emerald-500"
                          />
                          <Coins className="w-4 h-4 text-emerald-700" />
                          <span className="text-xs font-bold text-slate-900">Final Coins (FC)</span>
                        </label>
                      </div>
                      {acceptsFinalCoins && (
                        <div className="relative mt-2">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                            FC
                          </span>
                          <input
                            type="number"
                            value={finalCoinsAmount}
                            onChange={(e) => setFinalCoinsAmount(e.target.value)}
                            placeholder="25000"
                            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                          />
                        </div>
                      )}
                    </div>

                    {/* 2. Fiat Currency (USD, EUR, etc.) */}
                    <div
                      className={`p-3.5 rounded-2xl border transition-all ${
                        acceptsFiat ? 'border-emerald-500 bg-emerald-50/40' : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={acceptsFiat}
                            onChange={(e) => setAcceptsFiat(e.target.checked)}
                            className="rounded text-emerald-600 focus:ring-emerald-500"
                          />
                          <Building className="w-4 h-4 text-emerald-700" />
                          <span className="text-xs font-bold text-slate-900">Fiat Currency (USD)</span>
                        </label>
                      </div>
                      {acceptsFiat && (
                        <div className="relative mt-2">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                            $
                          </span>
                          <input
                            type="number"
                            value={fiatAmount}
                            onChange={(e) => setFiatAmount(e.target.value)}
                            placeholder="50000"
                            className="w-full pl-7 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                          />
                        </div>
                      )}
                    </div>

                    {/* 3. Stablecoins (USDC / USDT) */}
                    <div
                      className={`p-3.5 rounded-2xl border transition-all ${
                        acceptsStablecoins ? 'border-emerald-500 bg-emerald-50/40' : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={acceptsStablecoins}
                            onChange={(e) => setAcceptsStablecoins(e.target.checked)}
                            className="rounded text-emerald-600 focus:ring-emerald-500"
                          />
                          <DollarSign className="w-4 h-4 text-emerald-700" />
                          <span className="text-xs font-bold text-slate-900">Stablecoins (USDC / USDT)</span>
                        </label>
                      </div>
                      {acceptsStablecoins && (
                        <div className="relative mt-2">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                            $
                          </span>
                          <input
                            type="number"
                            value={stablecoinsAmount}
                            onChange={(e) => setStablecoinsAmount(e.target.value)}
                            placeholder="25000"
                            className="w-full pl-7 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                          />
                        </div>
                      )}
                    </div>

                    {/* 4. Crypto Assets (BTC / ETH) */}
                    <div
                      className={`p-3.5 rounded-2xl border transition-all ${
                        acceptsCrypto ? 'border-emerald-500 bg-emerald-50/40' : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={acceptsCrypto}
                            onChange={(e) => setAcceptsCrypto(e.target.checked)}
                            className="rounded text-emerald-600 focus:ring-emerald-500"
                          />
                          <TrendingUp className="w-4 h-4 text-emerald-700" />
                          <span className="text-xs font-bold text-slate-900">Crypto (BTC / ETH / SOL)</span>
                        </label>
                      </div>
                      {acceptsCrypto && (
                        <div className="relative mt-2">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                            $
                          </span>
                          <input
                            type="number"
                            value={cryptoAmount}
                            onChange={(e) => setCryptoAmount(e.target.value)}
                            placeholder="15000"
                            className="w-full pl-7 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs font-mono bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* 5. Physical Barter & Service Deliverables */}
                  <div
                    className={`p-4 rounded-2xl border transition-all ${
                      acceptsBarter ? 'border-amber-500 bg-amber-50/30' : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={acceptsBarter}
                          onChange={(e) => setAcceptsBarter(e.target.checked)}
                          className="rounded text-amber-600 focus:ring-amber-500"
                        />
                        <Repeat className="w-4 h-4 text-amber-700" />
                        <span className="text-xs font-bold text-slate-900">
                          Barter Goods &amp; Direct Equipment
                        </span>
                      </label>
                      <span className="text-[10px] font-mono text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                        Counter-Trade Escrow
                      </span>
                    </div>

                    {acceptsBarter && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
                        <div className="sm:col-span-2">
                          <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                            Barter Equipment / Hardware Specs Requested
                          </label>
                          <input
                            type="text"
                            value={barterDescription}
                            onChange={(e) => setBarterDescription(e.target.value)}
                            placeholder="e.g. 5x H100 GPU Racks, Solar Inverters, or Drone telemetry parts"
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-200 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                            Est. Barter Value ($ USD)
                          </label>
                          <input
                            type="number"
                            value={barterEstimatedValueUSD}
                            onChange={(e) => setBarterEstimatedValueUSD(e.target.value)}
                            placeholder="15000"
                            className="w-full px-3 py-1.5 rounded-xl border border-slate-200 font-mono text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* 3. Upload Videos and Photos */}
                <div className="space-y-3 pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-mono uppercase font-bold text-slate-500 tracking-wider">
                        3. Campaign Media (Upload Photos &amp; Videos)
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Upload high-resolution images, architectural renders, or pitch video clips.
                      </p>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">
                      {uploadedMediaList.length} file(s) added
                    </span>
                  </div>

                  {/* Hidden File Input */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    multiple
                    accept="image/*,video/*"
                    className="hidden"
                  />

                  {/* Drag & Drop / Click Zone */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-6 rounded-2xl border-2 border-dashed border-slate-200 hover:border-emerald-500 bg-slate-50/60 hover:bg-emerald-50/20 transition-all text-center cursor-pointer group"
                  >
                    <div className="flex items-center justify-center gap-3 mb-2">
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-emerald-600 shadow-xs group-hover:scale-105 transition-transform">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-purple-600 shadow-xs group-hover:scale-105 transition-transform">
                        <Video className="w-5 h-5" />
                      </div>
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-sky-600 shadow-xs group-hover:scale-105 transition-transform">
                        <UploadCloud className="w-5 h-5" />
                      </div>
                    </div>
                    <span className="text-xs font-bold text-slate-900 block">
                      Click or Drag &amp; Drop to Upload Photos &amp; Videos
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-1 font-mono">
                      PNG, JPG, WebP, MP4, MOV, WebM supported (Up to 50MB per file)
                    </span>
                  </div>

                  {/* Uploaded Media Gallery Preview */}
                  {uploadedMediaList.length > 0 && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                      {uploadedMediaList.map((media) => (
                        <div
                          key={media.id}
                          className="relative rounded-xl border border-slate-200 bg-slate-100 overflow-hidden group h-24"
                        >
                          {media.type === 'video' ? (
                            <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center text-white p-2">
                              <Video className="w-6 h-6 text-purple-400 mb-1" />
                              <span className="text-[9px] font-mono text-center truncate max-w-full">
                                {media.name}
                              </span>
                            </div>
                          ) : (
                            <img
                              src={media.url}
                              alt={media.name}
                              className="w-full h-full object-cover"
                            />
                          )}

                          <div className="absolute top-1.5 left-1.5">
                            <span
                              className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold uppercase ${
                                media.type === 'video'
                                  ? 'bg-purple-600 text-white'
                                  : 'bg-neutral-900/80 text-white'
                              }`}
                            >
                              {media.type}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveMedia(media.id);
                            }}
                            className="absolute top-1.5 right-1.5 p-1 rounded-full bg-red-600 text-white hover:bg-red-700 transition-colors shadow-xs cursor-pointer"
                          >
                            <X className="w-3 h-3" />
                          </button>

                          <div className="absolute bottom-0 inset-x-0 bg-neutral-900/80 backdrop-blur-xs px-1.5 py-0.5 text-[9px] font-mono text-slate-200 truncate">
                            {media.sizeFormatted}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Submit & Cancel Buttons */}
                <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="flex-1 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/20"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Publish Sovereign Campaign</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
