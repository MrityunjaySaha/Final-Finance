import { recordLedgerTransaction, createLedgerItemFromCampaignDonation } from '../utils/universalLedgerBridge';

export interface CampaignTargetBreakdown {
  acceptsFiat: boolean;
  fiatAmount: number;
  acceptsFinalCoins: boolean;
  finalCoinsAmount: number;
  acceptsStablecoins: boolean;
  stablecoinsAmount: number;
  acceptsCrypto: boolean;
  cryptoAmount: number;
  acceptsBarter: boolean;
  barterDescription: string;
  barterEstimatedValueUSD: number;
}

export interface UploadedMedia {
  id: string;
  url: string;
  name: string;
  type: 'image' | 'video';
  sizeFormatted: string;
  caption?: string;
}

export interface CampaignDonation {
  id: string;
  donorId: string;
  donorHandle: string;
  donorName: string;
  donorAvatar: string;
  amountUSD: number;
  modality: string;
  timestamp: string;
  message?: string;
}

export interface CampaignUpdate {
  id: string;
  title: string;
  date: string;
  content: string;
  author: string;
  likesCount?: number;
  mediaUrl?: string;
}

export interface CampaignMilestone {
  id: string;
  title: string;
  targetUSD: number;
  description: string;
  status: 'completed' | 'in_progress' | 'upcoming';
  escrowReleasePercent: number;
  date: string;
  txHash?: string;
}

export interface CampaignFAQ {
  question: string;
  answer: string;
}

export interface UserCampaign {
  id: string;
  title: string;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  creatorAvatar: string;
  creatorBio?: string;
  creatorAddress?: string;
  creatorWebsite?: string;
  creatorContactEmail?: string;
  category: 'Tech & AI' | 'Clean Energy' | 'Community' | 'Infrastructure' | 'Creative';
  shortDescription: string;
  fullStory: string;
  targetBreakdown: CampaignTargetBreakdown;
  targetAmountUSD: number;
  raisedAmountUSD: number;
  backersCount: number;
  endDateTime: string; // ISO date-time string
  status: 'active' | 'completed' | 'paused' | 'draft';
  pauseReason?: string;
  createdAt: string;
  acceptedModalities: string[];
  mediaList: UploadedMedia[];
  bannerUrl: string;
  videoUrl?: string;
  verifiedCreator: boolean;
  featured?: boolean;
  isTrendingToday?: boolean;
  trendingRank?: number;
  trendingGrowth24h?: string;
  donations: CampaignDonation[];
  updates?: CampaignUpdate[];
  milestones?: CampaignMilestone[];
  faqs?: CampaignFAQ[];
  risksAndChallenges?: string;
}

const STORAGE_KEY = 'final_finance_campaigns_v7';

function normalizeUserKey(s?: string): string {
  if (!s) return '';
  return s.trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '').split('@')[0].replace(/[_\-\s]/g, '');
}

// Initial Mock Campaigns:
// Initiated by user (active, paused, completed, co-backed), Backed by user (active, completed), and External campaigns
const INITIAL_CAMPAIGNS: UserCampaign[] = [
  {
    id: 'camp-init-backed-1',
    title: 'Verifiable AI Neural Compute Cluster & GPU Pods',
    creatorId: 'you',
    creatorName: 'You (Current User)',
    creatorHandle: 'you',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Core system architect and decentralized high-performance computing researcher building zero-knowledge AI training infrastructures.',
    creatorAddress: '0x7F9a94C381E2B5c4d093F52E9B4988F064AcD31e',
    creatorWebsite: 'https://neuralmesh.foundation',
    creatorContactEmail: 'contact@neuralmesh.foundation',
    category: 'Tech & AI',
    shortDescription: 'Community-funded open-source GPU cluster delivering zero-knowledge verified AI compute bandwidth to independent builders and open research labs.',
    fullStory: `### The Vision & Mission
Artificial intelligence models have become centralized within three hyper-scalers, pricing out universities, non-profit institutions, and independent open-source model developers. 

The **Verifiable AI Neural Compute Cluster** is a decentralized physical infrastructure network (DePIN) deployment designed to provide sovereign, low-latency, and cryptographically verified AI compute. Every training epoch is validated using zero-knowledge STARK proofs, guaranteeing data provenance without leaking proprietary model weights.

### Engineering & Hardware Topology
- **Phase 1 Pod Deployment**: 64x NVIDIA H100 SXM5 80GB tensor-core nodes linked via 3.2 Tbps Quantum-2 InfiniBand networking.
- **Physical Collocation**: Tier-4 hydro-powered Scandinavian data center boasting a PUE (Power Usage Effectiveness) of 1.08.
- **Smart Contract Escrow**: Contributions are locked in a multi-signature timelock vault on Final Finance. Disbursements require 4-of-6 validation signatures from our independent technical review board upon verifiable physical hardware delivery.

### Multi-Asset Participation & Modalities
We actively accept fiat bank wires, Final Coins (FC) with zero platform fees, USDC/USDT stablecoins, and physical hardware barter (server racks, liquid-cooling distribution manifolds, PCIe Gen5 risers).

### Founder Staking Commitment
As initiator of this campaign, **You have committed a personal $10,000 USD co-seed stake in Final Coins (FC)** to fund initial data center deposit reserves and hardware freight escrow.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 200000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 150000,
      acceptsStablecoins: true,
      stablecoinsAmount: 100000,
      acceptsCrypto: true,
      cryptoAmount: 50000,
      acceptsBarter: true,
      barterDescription: 'PCIe Riser Chassis, Liquid Cooling Racks & InfiniBand Switches',
      barterEstimatedValueUSD: 0,
    },
    targetAmountUSD: 500000,
    raisedAmountUSD: 412000,
    backersCount: 640,
    endDateTime: '2026-09-18T23:59:00',
    status: 'active',
    createdAt: '2026-08-01',
    acceptedModalities: ['Final Coins (FC)', 'ETH / BTC', 'USDT / USDC', 'Server Hardware Barter', 'Fiat USD'],
    mediaList: [
      {
        id: 'm-gpu-1',
        url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
        name: 'neural_cluster_server_rack.png',
        type: 'image',
        sizeFormatted: '4.1 MB',
        caption: 'High-density GPU cluster rack layout in hydro-electric data pod facility.'
      },
      {
        id: 'm-gpu-2',
        url: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=1200&auto=format&fit=crop&q=80',
        name: 'quantum_infiniband_switch.jpg',
        type: 'image',
        sizeFormatted: '3.8 MB',
        caption: 'High-speed 3.2 Tbps Quantum-2 optical interconnect testing.'
      },
      {
        id: 'm-gpu-vid',
        url: 'https://assets.mixkit.co/videos/preview/mixkit-circuit-board-microchip-technology-interface-31835-large.mp4',
        name: 'neural_zk_benchmarking_demo.mp4',
        type: 'video',
        sizeFormatted: '18.4 MB',
        caption: 'Live demonstration of zero-knowledge tensor execution validation engine.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-circuit-board-microchip-technology-interface-31835-large.mp4',
    verifiedCreator: true,
    featured: true,
    milestones: [
      {
        id: 'ms-gpu-1',
        title: 'Tier-4 Scandinavian Facility Collocation Agreement',
        targetUSD: 100000,
        description: 'Securing hydro-power allocation and high-density liquid-cooled rack footprint with 99.999% uptime guarantee.',
        status: 'completed',
        escrowReleasePercent: 20,
        date: '2026-08-05',
        txHash: '0x884f2b604e287a9e1028e469c84918e907d6b31c'
      },
      {
        id: 'ms-gpu-2',
        title: 'First 32x H100 Node Procurement & Quantum Interconnect',
        targetUSD: 250000,
        description: 'Direct manufacturer hardware acquisition and InfiniBand optical switch interconnect assembly.',
        status: 'completed',
        escrowReleasePercent: 50,
        date: '2026-08-16',
        txHash: '0x17c0a969f21394bf32998a44b1d033e089d71c42'
      },
      {
        id: 'ms-gpu-3',
        title: 'Full 64-GPU Cluster Deployment & zk-STARK Prover Testing',
        targetUSD: 450000,
        description: 'Complete physical assembly and public telemetry stress testing for multi-tenant open model training.',
        status: 'in_progress',
        escrowReleasePercent: 20,
        date: '2026-09-05'
      },
      {
        id: 'ms-gpu-4',
        title: 'Public Open-Source Developer API & SDK Release',
        targetUSD: 500000,
        description: 'Decentralized job scheduler and multi-token compute credits exchange launched globally.',
        status: 'upcoming',
        escrowReleasePercent: 10,
        date: '2026-09-25'
      }
    ],
    updates: [
      {
        id: 'up-gpu-1',
        title: 'Milestone 2 Completed: Hardware Nodes Delivered to Data Center',
        date: '2026-08-16',
        author: 'You (Campaign Initiator)',
        likesCount: 142,
        content: 'We are thrilled to share that the initial 32x H100 SXM5 compute units have safely arrived at our Scandinavian facility! Pre-installation thermal diagnostics passed with 100% optical link reliability.'
      },
      {
        id: 'up-gpu-2',
        title: 'Zero-Knowledge Proof Benchmark Results Published',
        date: '2026-08-10',
        author: 'You (Campaign Initiator)',
        likesCount: 98,
        content: 'Our engineering team benchmarked the zk-STARK validation cycle: we achieved under 1.2% overhead for distributed FP8 matrix operations. Full open-source benchmarks are now published on our GitHub repository.'
      }
    ],
    faqs: [
      {
        question: 'Who owns the physical compute hardware?',
        answer: 'The hardware is held in a sovereign trust governed by verified backers holding governance keys through the Final Finance escrow protocol.'
      },
      {
        question: 'How do backers receive compute credits?',
        answer: 'Backers receive proportional NeuralMesh Compute Allocations (NM-CREDITS) mapped to their wallet upon milestone completion.'
      },
      {
        question: 'Can I contribute server chassis or cooling parts via Barter?',
        answer: 'Yes! Select the "Barter" modality and describe your hardware. Our operations team will inspect freight specs and issue on-chain escrow credit.'
      }
    ],
    risksAndChallenges: 'Global supply chain variance for specialized optical transceivers. We have mitigated this through binding allocation contracts with dual Tier-1 hardware suppliers.',
    donations: [
      {
        id: 'don-user-founder-seed',
        donorId: 'you',
        donorHandle: 'you',
        donorName: 'You (Current User)',
        donorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
        amountUSD: 10000,
        modality: 'Final Coins (FC)',
        timestamp: '2026-08-01T10:00:00Z',
        message: 'Founder seed stake: committing initial hardware node reserves.'
      },
      {
        id: 'don-ext-1',
        donorId: 'deep_compute_syndicate',
        donorHandle: 'deep_compute',
        donorName: 'DeepCompute Syndicate',
        donorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
        amountUSD: 45000,
        modality: 'USDC',
        timestamp: '2026-08-03T16:20:00Z',
        message: 'Accelerating decentralized zero-knowledge machine learning.'
      },
      {
        id: 'don-ext-2',
        donorId: 'cyber_frontier_dao',
        donorHandle: 'cyber_dao',
        donorName: 'Cyber Frontier DAO',
        donorAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80',
        amountUSD: 25000,
        modality: 'ETH / BTC',
        timestamp: '2026-08-08T14:10:00Z',
        message: 'Decentralized AI compute is the foundation for censorship-resistant innovation.'
      }
    ],
  },
  {
    id: 'camp-init-1',
    title: 'Autonomous Decentralized Microgrid Protocol',
    creatorId: 'you',
    creatorName: 'You (Current User)',
    creatorHandle: 'you',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Clean-tech engineer and founder developing sovereign, microgrid power-routing firmware for decentralized municipal networks.',
    creatorAddress: '0x7F9a94C381E2B5c4d093F52E9B4988F064AcD31e',
    creatorWebsite: 'https://microgrid-protocol.io',
    creatorContactEmail: 'lead@microgrid-protocol.io',
    category: 'Clean Energy',
    shortDescription: 'Peer-to-peer solar energy trading and decentralized smart grid balance nodes for emerging community micro-utilities.',
    fullStory: `### The Challenge
Modern power grids are brittle, monopolistic, and vulnerable to climate extremes. Rural communities and urban neighborhoods produce massive distributed solar kilowatt-hours during daylight peaks but lack fair, real-time settlement mechanisms.

### Our Solution
The Autonomous Decentralized Microgrid Protocol is a hardware-and-software standard combining:
1. **IoT Smart Meter Gateway**: Bi-directional, tamper-proof current transducers measuring phase-accurate kilowatt-hours.
2. **Sub-Second Settlement Engine**: Instant settlement across neighbors via Final Coins (FC) and micro-fiat liquidity channels.
3. **Autonomous Battery Buffers**: Community-owned 48V LiFePO4 battery nodes that absorb peak daytime surplus and dispatch stored energy during twilight spikes.

### Transparent Milestone Vault
All contributions are protected under the Final Finance multi-sig smart contract escrow. Funds unlock only as hardware manufacturing passes independent third-party electrical lab safety inspections.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 100000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 50000,
      acceptsStablecoins: true,
      stablecoinsAmount: 50000,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: true,
      barterDescription: 'High-density Inverter Modules & 48V LiFePO4 Battery Banks',
      barterEstimatedValueUSD: 50000,
    },
    targetAmountUSD: 250000,
    raisedAmountUSD: 184500,
    backersCount: 342,
    endDateTime: '2026-09-15T18:00:00',
    status: 'active',
    createdAt: '2026-07-28',
    acceptedModalities: ['Fiat USD', 'Final Coins (FC)', 'USDC / USDT', 'Hardware Barter'],
    mediaList: [
      {
        id: 'm1',
        url: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=1200&auto=format&fit=crop&q=80',
        name: 'solar_station_node.jpg',
        type: 'image',
        sizeFormatted: '2.4 MB',
        caption: 'Pilot community rooftop solar collector array with integrated smart inverter.'
      },
      {
        id: 'm1-sub',
        url: 'https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?w=1200&auto=format&fit=crop&q=80',
        name: 'inverter_station_internals.jpg',
        type: 'image',
        sizeFormatted: '3.1 MB',
        caption: 'Internal smart routing telemetry controller and circuit breaker fail-safes.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    featured: true,
    milestones: [
      {
        id: 'ms-grid-1',
        title: 'Firmware & Smart Meter Certification',
        targetUSD: 60000,
        description: 'Completed UL1741 electrical safety and IEEE 2030.5 smart grid interoperability audits.',
        status: 'completed',
        escrowReleasePercent: 24,
        date: '2026-08-02',
        txHash: '0x498a83d7192f440a1829e928410291e0a84b901a'
      },
      {
        id: 'ms-grid-2',
        title: 'Pilot Community Grid Deployment (50 Homes)',
        targetUSD: 140000,
        description: 'Installing 50 residential transceiver nodes and 3 central battery storage vaults in the pilot district.',
        status: 'in_progress',
        escrowReleasePercent: 56,
        date: '2026-08-30'
      },
      {
        id: 'ms-grid-3',
        title: 'Wide Commercial Rollout & Cross-Grid Clearing',
        targetUSD: 250000,
        description: 'Opening open-source hardware blue-prints and decentralized clearing house API.',
        status: 'upcoming',
        escrowReleasePercent: 20,
        date: '2026-09-15'
      }
    ],
    updates: [
      {
        id: 'up-grid-1',
        title: 'Pilot district installation surpasses 35 homes',
        date: '2026-08-14',
        author: 'You (Campaign Initiator)',
        likesCount: 87,
        content: 'Our installation crew has energized 35 smart nodes. Real-time P2P energy trades are functioning flawlessly with sub-300ms confirmation times.'
      }
    ],
    faqs: [
      {
        question: 'How do homeowners participate?',
        answer: 'Any property with rooftop solar or storage batteries can plug in our open gateway module to immediately begin monetizing surplus generation.'
      }
    ],
    risksAndChallenges: 'Interconnection rules vary by regional utility. We strictly adhere to standard IEEE 1547 behind-the-meter guidelines.',
    donations: [
      {
        id: 'don-1',
        donorId: 'satoshi_vault',
        donorHandle: 'satoshi_vault',
        donorName: 'Sovereign Node Syndicate',
        donorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
        amountUSD: 25000,
        modality: 'Final Coins (FC)',
        timestamp: '2026-08-05T14:20:00Z',
        message: 'Supporting decentralized physical infrastructure and local energy resilience.'
      }
    ],
  },
  {
    id: 'camp-init-paused-1',
    title: 'Sub-Orbital Optical Satellite Mesh Network',
    creatorId: 'you',
    creatorName: 'You (Current User)',
    creatorHandle: 'you',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Aerospace telemetry engineer and open satellite communications researcher.',
    creatorAddress: '0x7F9a94C381E2B5c4d093F52E9B4988F064AcD31e',
    creatorWebsite: 'https://opensatmesh.space',
    creatorContactEmail: 'telemetry@opensatmesh.space',
    category: 'Tech & AI',
    shortDescription: 'Free open-source laser inter-satellite relay link firmware. Currently paused by you pending FAA spectrum telemetry sign-off.',
    pauseReason: 'Temporarily paused by You (Campaign Initiator) while awaiting official FAA / ITU optical satellite downlink telemetry spectrum confirmation. All backer escrow deposits remain 100% frozen in the secure timelock vault. You can resume this campaign anytime with one click.',
    fullStory: `### Campaign Overview (Paused Status)
The **Sub-Orbital Optical Satellite Mesh Network** is designed to provide free, high-bandwidth laser relay communication across CubeSat constellations, bypassing congested ground station monopolies.

### Current Paused Notice
**Notice from You (Creator)**: This campaign is temporarily paused by the initiator while our engineering counsel finalizes inter-satellite laser frequency licensing filings with international regulatory bodies. 

- **Escrow Safety**: All $142,000 USD contributed to date is locked safely in the automated multi-sig smart contract escrow.
- **Resumption**: As soon as the formal license approval document is filed on-chain, You (Creator) can instantly resume funding operations with the click of the "Resume Campaign" button above.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 150000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 100000,
      acceptsStablecoins: true,
      stablecoinsAmount: 50000,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: true,
      barterDescription: 'Optical Transceiver Lenses & CubeSat 3U Chassis',
      barterEstimatedValueUSD: 50000,
    },
    targetAmountUSD: 350000,
    raisedAmountUSD: 142000,
    backersCount: 180,
    endDateTime: '2026-10-01T00:00:00',
    status: 'paused',
    createdAt: '2026-07-10',
    acceptedModalities: ['Final Coins (FC)', 'USDC', 'Hardware Barter'],
    mediaList: [
      {
        id: 'm-sat',
        url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&auto=format&fit=crop&q=80',
        name: 'satellite_mesh_orbit.jpg',
        type: 'image',
        sizeFormatted: '3.1 MB',
        caption: 'Sub-orbital optical laser mesh simulation between 3U CubeSat nodes.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    milestones: [
      {
        id: 'ms-sat-1',
        title: 'Optical Transceiver Lab Calibration',
        targetUSD: 100000,
        description: 'Zero-dispersion bench tests achieving 10 Gbps inter-node throughput in vacuum chamber.',
        status: 'completed',
        escrowReleasePercent: 28,
        date: '2026-07-25',
        txHash: '0x992384918e907d6b31c884f2b604e287a9e1028e'
      },
      {
        id: 'ms-sat-2',
        title: 'Regulatory Telemetry Filing & CubeSat Chassis Integration',
        targetUSD: 200000,
        description: 'Submitting ITU paperwork and manufacturing vibration-damped satellite mounting frames.',
        status: 'in_progress',
        escrowReleasePercent: 28,
        date: '2026-09-10'
      }
    ],
    updates: [
      {
        id: 'up-sat-pause',
        title: 'Status Update: Voluntary Campaign Pause for Regulatory Telemetry Sign-Off',
        date: '2026-08-01',
        author: 'You (Campaign Initiator)',
        likesCount: 65,
        content: 'To safeguard backer capital, we have paused incoming pledges while we finalize spectrum coordination. All escrow funds remain 100% safeguarded.'
      }
    ],
    donations: [],
  },
  {
    id: 'camp-init-paused-2',
    title: 'Autonomous Arctic Climate Drone Sensor Sentry',
    creatorId: 'you',
    creatorName: 'You (Current User)',
    creatorHandle: 'you',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Polar robotics researcher and climate sensing instrument designer.',
    creatorAddress: '0x7F9a94C381E2B5c4d093F52E9B4988F064AcD31e',
    creatorWebsite: 'https://arcticsentry.earth',
    creatorContactEmail: 'expeditions@arcticsentry.earth',
    category: 'Clean Energy',
    shortDescription: 'Autonomous long-range UAVs measuring sea ice thickness and atmospheric methane anomalies. Paused by you for extreme sub-zero motor testing.',
    pauseReason: 'Paused by You (Creator) during rigorous -50°C thermal battery stress testing in the cryo-wind tunnel. Resuming as soon as composite rotor de-icing certifications complete.',
    fullStory: `### Project Objectives
Accurate polar climate metrics are critical to anticipating extreme global weather patterns. The **Arctic Climate Drone Sensor Sentry** fleet uses low-drag composite wings, micro-radar altimeters, and cryogenic lithium-sulfur batteries to sample remote ice shelves without costly icebreaker ships.

### Why You Paused This Campaign
You paused pledges while our engineering team executes cold-chamber calibration on the automated rotor de-icing heating elements. This guarantees backers will only fund flight-proven hardware.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 80000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 60000,
      acceptsStablecoins: true,
      stablecoinsAmount: 40000,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: true,
      barterDescription: 'Carbon-Fiber Wing Shells & High-Sensitivity Methane Spectrometers',
      barterEstimatedValueUSD: 20000,
    },
    targetAmountUSD: 200000,
    raisedAmountUSD: 85000,
    backersCount: 112,
    endDateTime: '2026-10-15T12:00:00',
    status: 'paused',
    createdAt: '2026-07-20',
    acceptedModalities: ['Final Coins (FC)', 'USDC', 'Barter Sensors', 'Fiat USD'],
    mediaList: [
      {
        id: 'm-arctic',
        url: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?w=1200&auto=format&fit=crop&q=80',
        name: 'arctic_drone_flight.jpg',
        type: 'image',
        sizeFormatted: '4.4 MB',
        caption: 'Long-range glider UAV undergoing polar horizon trial tests.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    donations: [],
  },
  {
    id: 'camp-init-completed-1',
    title: 'Modular Atmospheric Clean Water Condenser Arrays',
    creatorId: 'you',
    creatorName: 'You (Current User)',
    creatorHandle: 'you',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Zero-waste hydrological engineer and decentralized utility infrastructure founder.',
    creatorAddress: '0x7F9a94C381E2B5c4d093F52E9B4988F064AcD31e',
    creatorWebsite: 'https://atmospheric-water.org',
    creatorContactEmail: 'deploy@atmospheric-water.org',
    category: 'Clean Energy',
    shortDescription: 'Zero-grid moisture harvesting atmospheric condensers generating 1,000 liters of pristine drinking water daily per modular pod.',
    fullStory: `### 100% Fully Funded & Successfully Deployed!
Initiated by You on Final Finance, this project reached its full $120,000 USD crowdfunding target and completed all 3 construction phases.

### Realized Impact
- **12 Production Units Deployed**: Providing clean, mineralized drinking water to off-grid rural communities.
- **Zero Grid Energy Consumption**: 100% solar and Peltier heat-pipe thermal cycling.
- **All Escrow Released**: Multi-sig escrow smart contracts disbursed 100% of capital upon verified installation telemetry.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 50000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 40000,
      acceptsStablecoins: true,
      stablecoinsAmount: 30000,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: false,
      barterDescription: '',
      barterEstimatedValueUSD: 0,
    },
    targetAmountUSD: 120000,
    raisedAmountUSD: 120000,
    backersCount: 410,
    endDateTime: '2026-08-14T00:00:00',
    status: 'completed',
    createdAt: '2026-06-25',
    acceptedModalities: ['Final Coins (FC)', 'USDC', 'Fiat USD'],
    mediaList: [
      {
        id: 'm-water',
        url: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=1200&auto=format&fit=crop&q=80',
        name: 'water_condenser_field.jpg',
        type: 'image',
        sizeFormatted: '3.3 MB',
        caption: 'Completed solar-powered atmospheric condensation unit in operation.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    milestones: [
      {
        id: 'ms-water-1',
        title: 'Prototype Lab Testing & Water Purity Lab Certification',
        targetUSD: 40000,
        description: 'Passed WHO guidelines for heavy metal and biological contaminant filtering.',
        status: 'completed',
        escrowReleasePercent: 33,
        date: '2026-07-05',
        txHash: '0x33b8a19280918e907d6b31c884f2b604e287a9e1'
      },
      {
        id: 'ms-water-2',
        title: 'Manufacturing of First 12 Production Condensers',
        targetUSD: 80000,
        description: 'Precision CNC machining of aluminum condensor fins and food-grade mineralizer tanks.',
        status: 'completed',
        escrowReleasePercent: 33,
        date: '2026-07-28',
        txHash: '0x88f1c09938e907d6b31c884f2b604e287a9e1028'
      },
      {
        id: 'ms-water-3',
        title: 'Field Installation & Telemetry Commissioning',
        targetUSD: 120000,
        description: 'Active field operation and real-time output reporting onto the public ledger.',
        status: 'completed',
        escrowReleasePercent: 34,
        date: '2026-08-14',
        txHash: '0x99104fa287a9e1028e469c84918e907d6b31c884'
      }
    ],
    updates: [
      {
        id: 'up-water-finish',
        title: 'Campaign Complete! All 12 Condenser Arrays Operational',
        date: '2026-08-14',
        author: 'You (Campaign Initiator)',
        likesCount: 215,
        content: 'Thank you to all 410 backers! All 12 condensers are delivering 12,000+ liters of fresh water each day. The public dashboard is now accessible.'
      }
    ],
    donations: [
      {
        id: 'don-init-comp-1',
        donorId: 'desert_aid',
        donorHandle: 'desert_aid',
        donorName: 'Arid Climate Relief Initiative',
        donorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
        amountUSD: 30000,
        modality: 'USDC',
        timestamp: '2026-07-02T11:00:00Z',
        message: 'Deploying atmospheric water condensation in drought-impacted agricultural regions.'
      }
    ],
  },
  {
    id: 'camp-donor-1',
    title: 'High-Altitude Alpine Water Sanctuary & Filter Reserve',
    creatorId: 'alpine_trust',
    creatorName: 'Alpine Bio-Sanctuary Trust',
    creatorHandle: 'alpine_trust',
    creatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Mountain watershed conservationists safeguarding glaciated headwaters and providing gravity-fed mineral filtration.',
    creatorAddress: '0x3D9218F127494f61eE145e656d02FfE79244093B',
    creatorWebsite: 'https://alpinewatershed.org',
    creatorContactEmail: 'trust@alpinewatershed.org',
    category: 'Community',
    shortDescription: 'Protecting natural alpine spring sources and installing sovereign zero-waste natural filtration for remote valley villages.',
    fullStory: `### Preserving High-Altitude Headwaters
Alpine aquifers feed over 40% of downstream agricultural valleys. Industrial runoff and climate retreat threaten these pristine water reserves.

The **Alpine Bio-Sanctuary Trust** preserves natural recharge zones while building gravity-assisted sand and biochar filtration basins for remote villages.

### Your Contribution
**You backed this campaign with $5,000 USD in Final Coins (FC)**. The campaign successfully achieved 100% funding ($85,000 USD raised) with complete milestone verification on the Final Finance ledger.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 50000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 35000,
      acceptsStablecoins: false,
      stablecoinsAmount: 0,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: false,
      barterDescription: '',
      barterEstimatedValueUSD: 0,
    },
    targetAmountUSD: 85000,
    raisedAmountUSD: 85000,
    backersCount: 230,
    endDateTime: '2026-08-01T12:00:00',
    status: 'completed',
    createdAt: '2026-06-15',
    acceptedModalities: ['Fiat EUR / USD', 'Stablecoins', 'Final Coins (FC)'],
    mediaList: [
      {
        id: 'm3',
        url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1200&auto=format&fit=crop&q=80',
        name: 'alpine_spring_reserve.jpg',
        type: 'image',
        sizeFormatted: '3.6 MB',
        caption: 'Protected alpine glacial runoff basin and gravity filter intake.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    donations: [
      {
        id: 'don-user-1',
        donorId: 'you',
        donorHandle: 'you',
        donorName: 'You (Current User)',
        donorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
        amountUSD: 5000,
        modality: 'Final Coins (FC)',
        timestamp: '2026-06-20T10:15:00Z',
        message: 'Honored to contribute to pristine mountain watershed conservation and village health.'
      },
      {
        id: 'don-alpine-2',
        donorId: 'eco_steward_fund',
        donorHandle: 'eco_stewards',
        donorName: 'Eco-Stewards Foundation',
        donorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
        amountUSD: 30000,
        modality: 'Fiat EUR / USD',
        timestamp: '2026-06-25T16:00:00Z',
        message: 'Protecting alpine biodiversity corridors.'
      }
    ],
  },
  {
    id: 'camp-donor-2',
    title: 'Autonomous Agro-Forestry Drone Fleet',
    creatorId: 'drone_forestry_intl',
    creatorName: 'Global Agro-Forestry Consortium',
    creatorHandle: 'drone_forestry_intl',
    creatorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Autonomous roboticists and silviculture ecologists scaling automated tree planting.',
    creatorAddress: '0x99A8c3B432E27891789182390FcA41982847B012',
    creatorWebsite: 'https://agroforestry-drones.org',
    creatorContactEmail: 'fleet@agroforestry-drones.org',
    category: 'Infrastructure',
    shortDescription: 'LIDAR-equipped heavy seed planting drones restoring degraded biodiversity corridors at 10x manual planting speed.',
    fullStory: `### Restoring Forests with Autonomous Robotics
Deforestation and wildfires degrade millions of acres yearly. Traditional human planting is bottlenecked by rugged mountainous terrain.

The **Autonomous Agro-Forestry Drone Fleet** deploys autonomous hexacopters equipped with pneumatic seed pellet injectors. Each seed pod contains native mycorrhizal fungi, moisture retention gel, and organic nutrients.

### Backed by You
**You backed this campaign with $2,500 USD in USDC**. The campaign is actively in progress ($94,000 USD raised of $160,000 USD target) with 154 worldwide backers.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 60000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 40000,
      acceptsStablecoins: true,
      stablecoinsAmount: 40000,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: true,
      barterDescription: 'Carbon Fiber Propellers & Drone Telemetry Transmitters',
      barterEstimatedValueUSD: 20000,
    },
    targetAmountUSD: 160000,
    raisedAmountUSD: 94000,
    backersCount: 154,
    endDateTime: '2026-09-25T15:30:00',
    status: 'active',
    createdAt: '2026-08-10',
    acceptedModalities: ['Barter Drone Parts', 'Final Coins (FC)', 'USDC', 'USD Wire'],
    mediaList: [
      {
        id: 'm4',
        url: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?w=1200&auto=format&fit=crop&q=80',
        name: 'drone_forestry_flight.jpg',
        type: 'image',
        sizeFormatted: '1.9 MB',
        caption: 'Hexacopter seed injector drone flying aerial reforestation waypoint grid.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    donations: [
      {
        id: 'don-user-2',
        donorId: 'you',
        donorHandle: 'you',
        donorName: 'You (Current User)',
        donorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
        amountUSD: 2500,
        modality: 'USDC',
        timestamp: '2026-08-12T09:30:00Z',
        message: 'Backing automated reforestation corridors and ecological restoration.'
      }
    ],
  },
  {
    id: 'camp-trending-charity-1',
    title: 'Clean Oceans Coral Bio-Regeneration & Turtle Habitat Vault',
    creatorId: 'ocean_regen_ngo',
    creatorName: 'Ocean Biosphere Global Alliance',
    creatorHandle: 'ocean_regen_ngo',
    creatorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Non-profit marine biologists, ocean robotics teams, and indigenous coastal stewards restoring damaged reef barriers.',
    creatorAddress: '0x1A89bF421762b9a8901928aBcE98127390F12aBC',
    creatorWebsite: 'https://oceanbiosphere.foundation',
    creatorContactEmail: 'savecoral@oceanbiosphere.foundation',
    category: 'Community',
    shortDescription: 'Deploying solar-powered mineral accretion artificial reefs to restore 500 hectares of endangered coral ecosystems and marine shelters.',
    fullStory: `### Top Trending Charity of the Day
**Ocean Biosphere Global Alliance** is spearheading the world's most aggressive coral reef restoration program using safe low-voltage mineral accretion technology (Biorock).

### How It Works
1. **Solar-Powered Anode Buoys**: Moored solar buoys trickle a gentle electric current to underwater steel frames.
2. **Accelerated Calcium Carbonate**: Limestone crystals precipitate on the frame, accelerating natural coral growth by 400% and boosting survival against bleaching spikes.
3. **Marine Nursery Shelters**: Providing immediate protected sanctuary for green sea turtles, clownfish, and endangered reef fauna.

### Backed by You & 1,420 Global Donors
**You have contributed $1,000 USD in Final Coins (FC)**. This campaign is surging with +520% donor growth in the last 24 hours, approaching 83% of its $300,000 USD target.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 100000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 150000,
      acceptsStablecoins: true,
      stablecoinsAmount: 50000,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: true,
      barterDescription: 'Marine-Grade Titanium Electrodes & Solar Buoys',
      barterEstimatedValueUSD: 25000,
    },
    targetAmountUSD: 300000,
    raisedAmountUSD: 248500,
    backersCount: 1420,
    endDateTime: '2026-09-15T23:59:00',
    status: 'active',
    createdAt: '2026-08-01',
    acceptedModalities: ['Final Coins (FC)', 'USDC / USDT', 'Fiat USD', 'Hardware Barter'],
    mediaList: [
      {
        id: 'm-ocean',
        url: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=1200&auto=format&fit=crop&q=80',
        name: 'coral_reef_regeneration.jpg',
        type: 'image',
        sizeFormatted: '4.7 MB',
        caption: 'Flourishing electric mineral accretion coral matrix and sea turtle nursery.'
      },
      {
        id: 'm-ocean-sub',
        url: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=1200&auto=format&fit=crop&q=80',
        name: 'underwater_reef_drone.jpg',
        type: 'image',
        sizeFormatted: '3.9 MB',
        caption: 'Autonomous underwater ROV inspecting coral polyp attachment rates.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    featured: true,
    isTrendingToday: true,
    trendingRank: 1,
    trendingGrowth24h: '+520% today',
    donations: [
      {
        id: 'don-user-ocean-backed',
        donorId: 'you',
        donorHandle: 'you',
        donorName: 'You (Current User)',
        donorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
        amountUSD: 1000,
        modality: 'Final Coins (FC)',
        timestamp: '2026-08-20T19:00:00Z',
        message: 'Supporting vital coral reef accretion and marine life protection.'
      },
      {
        id: 'don-ocean-1',
        donorId: 'eco_patron',
        donorHandle: 'eco_patron',
        donorName: 'Blue Planet Trust',
        donorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
        amountUSD: 50000,
        modality: 'Final Coins (FC)',
        timestamp: '2026-08-20T18:00:00Z',
        message: 'Accelerating ocean reef protection and marine sanctuaries.'
      }
    ],
  },
  {
    id: 'camp-others-active-1',
    title: 'Open Source Brain-Computer Interface Sensor Rig',
    creatorId: 'neuro_foundry',
    creatorName: 'NeuroFoundry Labs',
    creatorHandle: 'neuro_foundry',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Open-source neural prosthetics engineers designing low-latency non-invasive EEG headsets.',
    creatorAddress: '0x5C82A971b802a90184bE9182390F127390F12aBD',
    creatorWebsite: 'https://neurofoundry.io',
    creatorContactEmail: 'labs@neurofoundry.io',
    category: 'Tech & AI',
    shortDescription: 'Accessible 32-channel dry-electrode EEG headset for hands-free assistive robotics and ALS patient communication.',
    fullStory: `### Accessible Neural Assistive Technology
High-performance EEG systems typically cost $25,000+ and require conductive gels that dry out within two hours.

**NeuroFoundry Labs** has developed an open-source 32-channel dry-electrode sensor rig with sub-5ms Bluetooth telemetry. Anyone can 3D-print the headset chassis and solder the open PCB.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 80000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 60000,
      acceptsStablecoins: true,
      stablecoinsAmount: 40000,
      acceptsCrypto: true,
      cryptoAmount: 20000,
      acceptsBarter: false,
      barterDescription: '',
      barterEstimatedValueUSD: 0,
    },
    targetAmountUSD: 200000,
    raisedAmountUSD: 145000,
    backersCount: 520,
    endDateTime: '2026-09-30T18:00:00',
    status: 'active',
    createdAt: '2026-08-05',
    acceptedModalities: ['Final Coins (FC)', 'USDC', 'Hardware Barter'],
    mediaList: [
      {
        id: 'm-neuro',
        url: 'https://images.unsplash.com/photo-1507413245164-6160d8298b31?w=1200&auto=format&fit=crop&q=80',
        name: 'bci_sensor_headset.jpg',
        type: 'image',
        sizeFormatted: '2.8 MB',
        caption: 'Dry-electrode 32-channel prototype headband mounted on calibration mannequin.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1507413245164-6160d8298b31?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    donations: [
      {
        id: 'don-neuro-1',
        donorId: 'alice_research',
        donorHandle: 'alice_research',
        donorName: 'Alice Vance',
        donorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
        amountUSD: 15000,
        modality: 'USDC',
        timestamp: '2026-08-08T11:00:00Z',
        message: 'Accelerating open-source assistive neurology.'
      }
    ],
  },
  {
    id: 'camp-others-completed-1',
    title: 'The Great Architectural Archives (Digital Vault)',
    creatorId: 'arch_preservation_guild',
    creatorName: 'Historic Architecture Guild',
    creatorHandle: 'arch_preservation_guild',
    creatorAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=120&auto=format&fit=crop&q=80',
    creatorBio: 'Preservationists and 3D LiDAR archivists digitizing endangered architectural heritage.',
    creatorAddress: '0x8892A01290382B819827390F127390F12aBCD819',
    creatorWebsite: 'https://architectural-vault.org',
    creatorContactEmail: 'curator@architectural-vault.org',
    category: 'Creative',
    shortDescription: 'Completed digitization of 50,000 rare hand-drawn structural blueprints and architectural models into open interactive 3D scans.',
    fullStory: `### Preserving Global Structural Heritage
Ancient blueprints and historical masonry drawings are susceptible to humidity degradation and fire loss.

The **Historic Architecture Guild** deployed high-precision photogrammetry scanners across 40 historical archives, rendering 50,000 sub-millimeter 3D point clouds and downloadable BIM assets under an open Creative Commons license.`,
    targetBreakdown: {
      acceptsFiat: true,
      fiatAmount: 30000,
      acceptsFinalCoins: true,
      finalCoinsAmount: 20000,
      acceptsStablecoins: false,
      stablecoinsAmount: 0,
      acceptsCrypto: false,
      cryptoAmount: 0,
      acceptsBarter: true,
      barterDescription: 'High-Res Optical Scanning Equipment',
      barterEstimatedValueUSD: 10000,
    },
    targetAmountUSD: 60000,
    raisedAmountUSD: 60000,
    backersCount: 285,
    endDateTime: '2026-08-15T00:00:00',
    status: 'completed',
    createdAt: '2026-07-12',
    acceptedModalities: ['Final Coins (FC)', 'Stablecoins', 'CAD/BIM Asset Barter'],
    mediaList: [
      {
        id: 'm5',
        url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&auto=format&fit=crop&q=80',
        name: 'blueprint_archive_render.jpg',
        type: 'image',
        sizeFormatted: '5.2 MB',
        caption: 'Interactive 3D structural wireframe reconstruction of historic cathedral arches.'
      }
    ],
    bannerUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&auto=format&fit=crop&q=80',
    verifiedCreator: true,
    donations: [
      {
        id: 'don-arch-1',
        donorId: 'urban_futures',
        donorHandle: 'urban_futures',
        donorName: 'Urban Futures Foundation',
        donorAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=120&auto=format&fit=crop&q=80',
        amountUSD: 20000,
        modality: 'Fiat EUR / USD',
        timestamp: '2026-07-20T14:30:00Z',
        message: 'Preserving our collective architectural heritage for future generations.'
      }
    ],
  }
];

let campaignsStore: UserCampaign[] | null = null;

function loadCampaignsStore(): UserCampaign[] {
  if (campaignsStore) return campaignsStore;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        campaignsStore = parsed;
        return campaignsStore;
      }
    }
  } catch (e) {
    console.error('Error reading campaigns storage:', e);
  }
  campaignsStore = [...INITIAL_CAMPAIGNS];
  saveCampaignsStore();
  return campaignsStore;
}

function saveCampaignsStore(): void {
  if (!campaignsStore) return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(campaignsStore));
  } catch (e) {
    console.error('Error saving campaigns storage:', e);
  }
}

/**
 * Checks if a user is the initiator/creator of a campaign
 */
export function isUserCampaignInitiator(camp: UserCampaign, userIdOrHandle?: string): boolean {
  if (!userIdOrHandle) {
    return camp.creatorId === 'you' || camp.creatorHandle === 'you';
  }
  const cleanTargetNorm = normalizeUserKey(userIdOrHandle);
  const campCreatorIdNorm = normalizeUserKey(camp.creatorId);
  const campCreatorHandleNorm = normalizeUserKey(camp.creatorHandle);

  return (
    campCreatorIdNorm === cleanTargetNorm ||
    campCreatorHandleNorm === cleanTargetNorm ||
    camp.creatorId === userIdOrHandle ||
    camp.creatorHandle === userIdOrHandle ||
    (camp.creatorId === 'you' && (cleanTargetNorm === 'you' || !cleanTargetNorm))
  );
}

/**
 * Checks if a user has donated / backed a campaign
 */
export function isUserCampaignDonor(camp: UserCampaign, userIdOrHandle?: string): boolean {
  if (!camp.donations || camp.donations.length === 0) return false;
  if (!userIdOrHandle) {
    return camp.donations.some(d => d.donorId === 'you' || d.donorHandle === 'you');
  }
  const cleanTargetNorm = normalizeUserKey(userIdOrHandle);

  return camp.donations.some(d => {
    const donorIdNorm = normalizeUserKey(d.donorId);
    const donorHandleNorm = normalizeUserKey(d.donorHandle);
    return (
      donorIdNorm === cleanTargetNorm ||
      donorHandleNorm === cleanTargetNorm ||
      d.donorId === userIdOrHandle ||
      d.donorHandle === userIdOrHandle ||
      (d.donorId === 'you' && (cleanTargetNorm === 'you' || !cleanTargetNorm))
    );
  });
}

/**
 * Returns all donations made by the specified user for a given campaign
 */
export function getUserDonationsForCampaign(camp: UserCampaign, userIdOrHandle?: string): CampaignDonation[] {
  if (!camp.donations || camp.donations.length === 0) return [];
  if (!userIdOrHandle) {
    return camp.donations.filter(d => d.donorId === 'you' || d.donorHandle === 'you');
  }
  const cleanTargetNorm = normalizeUserKey(userIdOrHandle);

  return camp.donations.filter(d => {
    const donorIdNorm = normalizeUserKey(d.donorId);
    const donorHandleNorm = normalizeUserKey(d.donorHandle);
    return (
      donorIdNorm === cleanTargetNorm ||
      donorHandleNorm === cleanTargetNorm ||
      d.donorId === userIdOrHandle ||
      d.donorHandle === userIdOrHandle ||
      (d.donorId === 'you' && (cleanTargetNorm === 'you' || !cleanTargetNorm))
    );
  });
}

/**
 * Returns the total dollar value donated by the specified user to a campaign
 */
export function getUserTotalDonatedToCampaign(camp: UserCampaign, userIdOrHandle?: string): number {
  const donations = getUserDonationsForCampaign(camp, userIdOrHandle);
  return donations.reduce((sum, d) => sum + (d.amountUSD || 0), 0);
}

/**
 * STRICT FILTER: Returns ONLY campaigns that the user has initiated OR was a part of, as a donor.
 */
export function getUserInvolvedCampaigns(
  userIdOrHandle?: string,
  roleFilter: 'all' | 'initiated' | 'donated' | 'paused_by_me' = 'all'
): UserCampaign[] {
  const all = loadCampaignsStore();

  return all.filter(camp => {
    const isInitiator = isUserCampaignInitiator(camp, userIdOrHandle);
    const isDonor = isUserCampaignDonor(camp, userIdOrHandle);

    if (roleFilter === 'initiated') {
      return isInitiator;
    }
    if (roleFilter === 'donated') {
      return isDonor;
    }
    if (roleFilter === 'paused_by_me') {
      return isInitiator && camp.status === 'paused';
    }
    // 'all' = must be initiated OR donor
    return isInitiator || isDonor;
  });
}

/**
 * Returns all public campaigns for discovery/browsing if needed
 */
export function getAllCampaigns(): UserCampaign[] {
  return loadCampaignsStore();
}

/**
 * Creates and stores a new campaign initiated by the user
 */
export function createCampaign(newCamp: Omit<UserCampaign, 'id' | 'createdAt' | 'donations'>): UserCampaign {
  loadCampaignsStore();
  const created: UserCampaign = {
    ...newCamp,
    id: `camp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    createdAt: new Date().toISOString().split('T')[0],
    donations: [],
  };

  campaignsStore = [created, ...(campaignsStore || [])];
  saveCampaignsStore();
  return created;
}

/**
 * Updates campaign status (active | paused | completed)
 */
export function updateCampaignStatus(campId: string, status: 'active' | 'completed' | 'paused', pauseReason?: string): boolean {
  loadCampaignsStore();
  if (!campaignsStore) return false;
  let found = false;
  campaignsStore = campaignsStore.map(c => {
    if (c.id === campId) {
      found = true;
      return { 
        ...c, 
        status,
        pauseReason: status === 'paused' ? (pauseReason || c.pauseReason || 'Paused by campaign initiator.') : c.pauseReason 
      };
    }
    return c;
  });
  if (found) {
    saveCampaignsStore();
  }
  return found;
}

/**
 * Records a donation / contribution from a user to a campaign
 */
export function donateToCampaign(
  campId: string,
  donation: {
    donorId: string;
    donorHandle: string;
    donorName: string;
    donorAvatar: string;
    amountUSD: number;
    modality: string;
    message?: string;
  }
): boolean {
  loadCampaignsStore();
  if (!campaignsStore) return false;

  let updated = false;
  campaignsStore = campaignsStore.map(c => {
    if (c.id === campId) {
      updated = true;
      const newDonation: CampaignDonation = {
        id: `don-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        donorId: donation.donorId,
        donorHandle: donation.donorHandle,
        donorName: donation.donorName,
        donorAvatar: donation.donorAvatar,
        amountUSD: donation.amountUSD,
        modality: donation.modality,
        timestamp: new Date().toISOString(),
        message: donation.message,
      };

      const nextRaised = (c.raisedAmountUSD || 0) + donation.amountUSD;
      const isNewDonor = !c.donations.some(d => normalizeUserKey(d.donorId) === normalizeUserKey(donation.donorId));
      const nextBackers = isNewDonor ? (c.backersCount || 0) + 1 : c.backersCount;
      const nextStatus = nextRaised >= c.targetAmountUSD ? 'completed' : c.status;

      return {
        ...c,
        raisedAmountUSD: nextRaised,
        backersCount: nextBackers,
        status: nextStatus,
        donations: [newDonation, ...c.donations],
      };
    }
    return c;
  });

  if (updated) {
    saveCampaignsStore();
    const targetedCampaign = campaignsStore.find(c => c.id === campId);
    if (targetedCampaign) {
      const isCharity = targetedCampaign.category.toLowerCase().includes('charity') || targetedCampaign.category.toLowerCase().includes('relief') || targetedCampaign.category.toLowerCase().includes('aid');
      const ledgerItem = createLedgerItemFromCampaignDonation({
        campaignId: campId,
        campaignTitle: targetedCampaign.title,
        amountUSD: donation.amountUSD,
        modality: donation.modality,
        isCharity
      });
      recordLedgerTransaction(donation.donorId, ledgerItem);
    }
  }
  return updated;
}

/**
 * Returns the top trending charity campaign of the day
 */
export function getTrendingCharityOfTheDay(): UserCampaign | null {
  const all = loadCampaignsStore();
  const trending = all.find(c => c.isTrendingToday) || all.find(c => c.category === 'Community' && c.status === 'active') || all[0] || null;
  return trending;
}
