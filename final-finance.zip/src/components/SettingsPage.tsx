import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  Lock, 
  Bell, 
  Save, 
  Check, 
  AlertCircle, 
  Loader2, 
  ArrowLeft, 
  Camera, 
  Eye, 
  EyeOff, 
  AtSign, 
  Mail, 
  ShieldCheck, 
  CreditCard, 
  FileCheck, 
  CheckCircle2, 
  Clock,
  ExternalLink,
  ImageIcon,
  Upload,
  Trash2,
  Sparkles,
  RefreshCw,
  Building2,
  Wallet,
  Plus,
  Globe,
  Zap,
  MessageSquare,
  Heart,
  Users,
  TrendingUp,
  Landmark,
  ShoppingBag,
  Volume2,
  VolumeX,
  Radio,
  Award,
  Rocket,
  RotateCcw,
  FileText,
  Play,
  Reply,
  Send
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { updateUserAccountProfile, cancelUserSubscription, checkUserIdAvailability, checkEmailAvailability, deactivateUserAccount, deleteUserAccount } from '../services/firebaseAuth';
import { updateUserPublicProfile } from '../services/socialService';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { LinkBankCardModal } from './stocks/LinkBankCardModal';
import { UserWalletData, LinkedBankAccountItem, LinkedCardItem, LinkedCryptoWalletItem } from '../types/wallet';
import { submitFeedback, getFeedbackList, deleteFeedback, AppFeedback } from '../services/feedbackService';
import { requestBrowserNotificationPermission, getBrowserNotificationPermission, resetNotificationPreferences } from '../utils/notificationService';

// Preset Avatars
const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=400&auto=format&fit=crop&q=80',
];

// Preset Covers
const COVER_PRESETS = [
  'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=1400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=1400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=1400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1400&auto=format&fit=crop&q=80',
];

interface SettingsPageProps {
  currentUser?: AuthSession | null;
  onUpdateSession: (updated: AuthSession) => void;
  onNavigateBack?: () => void;
  onOpenVerificationModal?: () => void;
  onViewPublicProfile?: (userId: string) => void;
  initialTab?: 'profile' | 'security' | 'verification' | 'payment_methods' | 'notifications' | 'account_deactivation' | 'give_feedback' | 'response_back';
}

/**
 * Resizes and compresses an uploaded image file on the client side
 */
const compressImageFile = (file: File, maxWidth: number, maxHeight: number, quality = 0.85): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = document.createElement('img');
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedDataUrl);
        } else {
          resolve(event.target?.result as string);
        }
      };
      img.onerror = (error) => reject(error);
    };
    reader.onerror = (error) => reject(error);
  });
};

export const SettingsPage: React.FC<SettingsPageProps> = ({
  currentUser,
  onUpdateSession,
  onNavigateBack,
  onOpenVerificationModal,
  onViewPublicProfile,
  initialTab = 'profile'
}) => {
  const { 
    addNotification,
    notificationPrefs,
    updateNotificationPrefs,
    triggerTestNotification
  } = useApp();
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'verification' | 'payment_methods' | 'notifications' | 'account_deactivation' | 'give_feedback' | 'response_back'>(
    initialTab || 'profile'
  );
  
  // Feedback States
  const [feedbackCategory, setFeedbackCategory] = useState<'bug' | 'feature' | 'ui' | 'general' | 'other'>('general');
  const [feedbackComments, setFeedbackComments] = useState('');
  const [feedbackSuggestions, setFeedbackSuggestions] = useState('');
  const [feedbackIsAnonymous, setFeedbackIsAnonymous] = useState(false);
  const [isFeedbackSubmitting, setIsFeedbackSubmitting] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState(false);
  const [deletingFeedbackId, setDeletingFeedbackId] = useState<string | null>(null);

  // Wallet / Linked Accounts & Crypto State
  const [userWallets, setUserWallets] = useState<UserWalletData>(() => 
    getStoredUserWallets(currentUser?.id || 'guest')
  );
  const [feedbackHistory, setFeedbackHistory] = useState<AppFeedback[]>([]);
  const [isLinkModalOpen, setIsLinkModalOpen] = useState(false);
  const [linkModalTab, setLinkModalTab] = useState<'bank' | 'card' | 'crypto'>('bank');

  // Reactively synchronize linked payment methods
  React.useEffect(() => {
    if (!currentUser?.id) return;
    setUserWallets(getStoredUserWallets(currentUser.id));
    const handleUpdate = () => {
      setUserWallets(getStoredUserWallets(currentUser.id));
    };
    window.addEventListener('final_finance_wallets_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [currentUser?.id]);

  // Load Feedback History
  React.useEffect(() => {
    if (activeTab === 'response_back') {
      const all = getFeedbackList();
      // If user is logged in, prioritize their items, but always include demo reviewed/resolved items for demonstration
      setFeedbackHistory(all);
    }
  }, [activeTab, currentUser?.id, currentUser?.uid, feedbackSuccess]);

  const handleSetDefaultBank = (bankId: string) => {
    if (!currentUser?.id) return;
    const updated: UserWalletData = {
      ...userWallets,
      linkedBankAccounts: (userWallets.linkedBankAccounts || []).map(b => ({
        ...b,
        isDefault: b.id === bankId
      }))
    };
    setUserWallets(updated);
    saveStoredUserWallets(currentUser.id, updated);
    setSuccessMessage('Primary settlement bank account updated.');
  };

  const handleRemoveBank = (bankId: string) => {
    if (!currentUser?.id) return;
    const updated: UserWalletData = {
      ...userWallets,
      linkedBankAccounts: (userWallets.linkedBankAccounts || []).filter(b => b.id !== bankId)
    };
    setUserWallets(updated);
    saveStoredUserWallets(currentUser.id, updated);
    setSuccessMessage('Bank account unlinked successfully.');
  };

  const handleSetDefaultCard = (cardId: string) => {
    if (!currentUser?.id) return;
    const updated: UserWalletData = {
      ...userWallets,
      linkedCards: (userWallets.linkedCards || []).map(c => ({
        ...c,
        isDefault: c.id === cardId
      }))
    };
    setUserWallets(updated);
    saveStoredUserWallets(currentUser.id, updated);
    setSuccessMessage('Primary default card updated.');
  };

  const handleRemoveCard = (cardId: string) => {
    if (!currentUser?.id) return;
    const updated: UserWalletData = {
      ...userWallets,
      linkedCards: (userWallets.linkedCards || []).filter(c => c.id !== cardId)
    };
    setUserWallets(updated);
    saveStoredUserWallets(currentUser.id, updated);
    setSuccessMessage('Payment card unlinked successfully.');
  };

  const handleSetPrimaryCrypto = (cryptoId: string) => {
    if (!currentUser?.id) return;
    const updated: UserWalletData = {
      ...userWallets,
      linkedCryptoWallets: (userWallets.linkedCryptoWallets || []).map(w => ({
        ...w,
        isPrimary: w.id === cryptoId
      }))
    };
    setUserWallets(updated);
    saveStoredUserWallets(currentUser.id, updated);
    setSuccessMessage('Primary Web3 crypto wallet updated.');
  };

  const handleRemoveCrypto = (cryptoId: string) => {
    if (!currentUser?.id) return;
    const updated: UserWalletData = {
      ...userWallets,
      linkedCryptoWallets: (userWallets.linkedCryptoWallets || []).filter(w => w.id !== cryptoId)
    };
    setUserWallets(updated);
    saveStoredUserWallets(currentUser.id, updated);
    setSuccessMessage('Web3 crypto wallet disconnected.');
  };
  
  // Profile Form States
  const [fullName, setFullName] = useState(currentUser?.name || '');
  const [userId, setUserId] = useState(currentUser?.id || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [gender, setGender] = useState<'male' | 'female' | 'other' | ''>(currentUser?.gender || '');
  const [avatarUrl, setAvatarUrl] = useState(currentUser?.avatarUrl || '');
  const [coverUrl, setCoverUrl] = useState(currentUser?.coverUrl || '');

  // File Upload refs & loading
  const avatarFileInputRef = useRef<HTMLInputElement>(null);
  const coverFileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessingAvatar, setIsProcessingAvatar] = useState(false);
  const [isProcessingCover, setIsProcessingCover] = useState(false);

  // Security Form States
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(true);

  // Notification Preferences
  const [notifyTrades, setNotifyTrades] = useState(true);
  const [notifyMessages, setNotifyMessages] = useState(true);
  const [notifyVaultYield, setNotifyVaultYield] = useState(true);
  const [notifyFriendRequests, setNotifyFriendRequests] = useState(true);

  // State status
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Danger Zone States & Handlers
  const [showDeactivateModal, setShowDeactivateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmationInput, setDeleteConfirmationInput] = useState('');
  const [isDangerProcessing, setIsDangerProcessing] = useState(false);

  const handleDeactivateAccount = async () => {
    setIsDangerProcessing(true);
    setErrorMessage('');
    try {
      const res = await deactivateUserAccount();
      if (res.success) {
        addNotification('Account deactivated successfully. Signing out...', 'info');
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else {
        setErrorMessage(res.error || 'Failed to deactivate account.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error deactivating account');
    } finally {
      setIsDangerProcessing(false);
      setShowDeactivateModal(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirmationInput.trim() !== currentUser?.id && deleteConfirmationInput.trim().toLowerCase() !== 'delete') {
      setErrorMessage('Please type your exact User ID or "DELETE" to confirm permanent account deletion.');
      return;
    }
    setIsDangerProcessing(true);
    setErrorMessage('');
    try {
      const res = await deleteUserAccount();
      if (res.success) {
        addNotification('Account permanently deleted. Signing out...', 'error');
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else {
        setErrorMessage(res.error || 'Failed to delete account.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error deleting account');
    } finally {
      setIsDangerProcessing(false);
      setShowDeleteModal(false);
    }
  };

  const [userIdStatus, setUserIdStatus] = useState<{ available: boolean; message?: string }>(() => 
    checkUserIdAvailability(currentUser?.id || '', currentUser?.id)
  );
  const [emailStatus, setEmailStatus] = useState<{ available: boolean; message?: string }>(() => 
    checkEmailAvailability(currentUser?.email || '', currentUser?.email)
  );

  const handleUserIdChange = (val: string) => {
    const clean = val.toLowerCase().replace(/[^a-z0-9_.-]/g, '');
    setUserId(clean);
    const res = checkUserIdAvailability(clean, currentUser?.id);
    setUserIdStatus(res);
  };

  const handleEmailChange = (val: string) => {
    const clean = val.trim();
    setEmail(clean);
    const res = checkEmailAvailability(clean, currentUser?.email);
    setEmailStatus(res);
  };

  // Avatar Upload Handler
  const handleAvatarFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingAvatar(true);
    setErrorMessage('');
    try {
      const dataUrl = await compressImageFile(file, 500, 500, 0.85);
      setAvatarUrl(dataUrl);
      setSuccessMessage('Avatar photo loaded. Click "Save Profile" below to apply changes.');
    } catch (err) {
      setErrorMessage('Failed to process avatar image file. Please try another image.');
    } finally {
      setIsProcessingAvatar(false);
      // Reset input value so same file can be re-selected if needed
      if (avatarFileInputRef.current) avatarFileInputRef.current.value = '';
    }
  };

  // Cover Upload Handler
  const handleCoverFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingCover(true);
    setErrorMessage('');
    try {
      const dataUrl = await compressImageFile(file, 1400, 600, 0.85);
      setCoverUrl(dataUrl);
      setSuccessMessage('Cover banner loaded. Click "Save Profile" below to apply changes.');
    } catch (err) {
      setErrorMessage('Failed to process cover banner image. Please try another image.');
    } finally {
      setIsProcessingCover(false);
      if (coverFileInputRef.current) coverFileInputRef.current.value = '';
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !userId.trim()) {
      setErrorMessage('Full Name and User ID Handle are required.');
      return;
    }

    const cleanUserId = userId.trim().toLowerCase().replace(/^@/, '');
    const cleanEmail = email.trim().toLowerCase();

    const idCheck = checkUserIdAvailability(cleanUserId, currentUser?.id);
    if (!idCheck.available) {
      setErrorMessage(idCheck.message || 'User ID is unavailable.');
      return;
    }

    if (cleanEmail) {
      const emailCheck = checkEmailAvailability(cleanEmail, currentUser?.email);
      if (!emailCheck.available) {
        setErrorMessage(emailCheck.message || 'Email is unavailable.');
        return;
      }
    }

    setIsSaving(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      // 1. Update public profile directory entry
      if (currentUser?.uid) {
        await updateUserPublicProfile(currentUser.uid, {
          name: fullName.trim(),
          userId: cleanUserId,
          email: cleanEmail,
          bio: bio,
          avatarUrl: avatarUrl.trim(),
          coverUrl: coverUrl.trim(),
        });
      }

      // 2. Update session and account registry
      const res = await updateUserAccountProfile({
        fullName: fullName.trim(),
        userId: cleanUserId,
        email: cleanEmail,
        bio: bio,
        gender: gender,
        avatarUrl: avatarUrl.trim(),
        coverUrl: coverUrl.trim(),
      });

      if (res.success && res.user) {
        localStorage.setItem(`ff_user_gender_${cleanUserId}`, gender);
        if (currentUser?.id) {
          localStorage.setItem(`ff_user_gender_${currentUser.id}`, gender);
        }
        onUpdateSession(res.user);
        setSuccessMessage('Profile and account details updated successfully.');
      } else {
        setErrorMessage(res.error || 'Failed to update profile.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error updating profile');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveSecurity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!newPassword) {
      setErrorMessage('Please provide a new password.');
      return;
    }
    if (newPassword.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMessage('New passwords do not match.');
      return;
    }

    setIsSaving(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const res = await updateUserAccountProfile({
        fullName: currentUser.name,
        userId: currentUser.id,
        newPassword,
      });

      if (res.success && res.user) {
        onUpdateSession(res.user);
        setSuccessMessage('Security credentials and password updated successfully.');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setErrorMessage(res.error || 'Failed to update password');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error updating security settings');
    } finally {
      setIsSaving(false);
    }
  };

  if (!currentUser) {
    return (
      <div className="text-center py-16">
        <p className="text-neutral-500 text-sm">Please sign in to access Account &amp; Security Settings.</p>
      </div>
    );
  }

  return (
    <div
      id="settings-page-root"
      className="w-full max-w-4xl mx-auto text-left px-3 sm:px-4 py-2 sm:py-4"
    >
      {/* Hidden File Inputs for Direct Photo Uploads */}
      <input
        type="file"
        ref={avatarFileInputRef}
        onChange={handleAvatarFileSelect}
        accept="image/png,image/jpeg,image/jpg,image/webp,image/gif"
        className="hidden"
      />
      <input
        type="file"
        ref={coverFileInputRef}
        onChange={handleCoverFileSelect}
        accept="image/png,image/jpeg,image/jpg,image/webp,image/gif"
        className="hidden"
      />

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-100 mb-6">
        <div>
          <h1 className="font-serif-lux text-2xl sm:text-3xl font-light text-black tracking-tight flex items-center gap-2.5">
            <span>Account &amp; Security Settings</span>
          </h1>
          <p className="text-xs font-sans text-neutral-500 mt-0.5">
            Manage your profile identity, security credentials, verification, and alert preferences
          </p>
        </div>

        {/* View Public Profile Quick Link */}
        <div className="flex flex-row items-center justify-center gap-2 shrink-0 w-full sm:w-auto">
          {onViewPublicProfile && (
            <button
              type="button"
              onClick={() => onViewPublicProfile(currentUser.id || currentUser.uid)}
              className="min-h-[38px] px-3.5 py-1.5 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs whitespace-nowrap"
            >
              <ExternalLink className="w-3.5 h-3.5 text-neutral-500" />
              <span>View Public Profile</span>
            </button>
          )}
        </div>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 p-1 bg-neutral-100 rounded-2xl mb-6 overflow-x-auto">
        {/* Tab 1: Profile & Identity */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('profile');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'profile'
              ? 'bg-white text-black font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>Profile &amp; Identity</span>
        </button>

        {/* Tab 2: Security & Password */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('security');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'security'
              ? 'bg-white text-black font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Security &amp; Password</span>
        </button>

        {/* Tab 3: Verification & Subscription */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('verification');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'verification'
              ? 'bg-white text-black font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
          <span>Verification &amp; Subscription</span>
        </button>

        {/* Tab 4: Linked Accounts & Wallets */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('payment_methods');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'payment_methods'
              ? 'bg-white text-black font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Building2 className="w-3.5 h-3.5 text-blue-600" />
          <span>Banks, Cards &amp; Crypto</span>
        </button>

        {/* Tab 5: Notifications */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('notifications');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'notifications'
              ? 'bg-white text-black font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Notifications</span>
        </button>

        {/* Tab 5.5: Give App Feedback */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('give_feedback');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'give_feedback'
              ? 'bg-white text-black font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
          <span>Give App Feedback</span>
        </button>

        {/* Tab 5.6: Response Back */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('response_back');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'response_back'
              ? 'bg-white text-black font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-black'
          }`}
        >
          <Reply className="w-3.5 h-3.5 text-emerald-500" />
          <span>Response Back</span>
        </button>

        {/* Tab 6: Deactivate or Delete Account */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('account_deactivation');
            setErrorMessage('');
            setSuccessMessage('');
          }}
          className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'account_deactivation'
              ? 'bg-white text-red-600 font-semibold shadow-xs border border-red-200'
              : 'text-neutral-600 hover:text-red-600'
          }`}
        >
          <Trash2 className="w-3.5 h-3.5 text-red-500" />
          <span>Deactivate or Delete</span>
        </button>
      </div>

      {/* Status Messages */}
      {errorMessage && (
        <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2 mb-6">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {successMessage && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 mb-6">
          <Check className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* ================= TAB 1: PROFILE & IDENTITY ================= */}
      {activeTab === 'profile' && (
        <form onSubmit={handleSaveProfile} className="space-y-6">
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-6 shadow-xs space-y-7">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3.5">
              <h2 className="text-base font-semibold text-black flex items-center gap-2">
                <User className="w-4 h-4 text-neutral-800" />
                <span>Public Persona &amp; Identity</span>
              </h2>
              <span className="text-[11px] font-mono text-neutral-500">
                @{currentUser.id}
              </span>
            </div>

            {/* Photo Section: Cover & Avatar with DIRECT FILE UPLOAD */}
            <div className="space-y-6 bg-neutral-50/70 p-4 sm:p-5 rounded-2xl border border-neutral-200/80">
              {/* Cover Photo Field & Direct Upload */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-neutral-600" />
                    <span>Profile Cover Banner</span>
                  </label>
                  <div className="flex items-center gap-2">
                    {coverUrl && (
                      <button
                        type="button"
                        onClick={() => setCoverUrl('')}
                        className="text-[11px] text-neutral-500 hover:text-red-600 flex items-center gap-1 cursor-pointer transition-colors"
                        title="Remove cover"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Reset to Default</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Banner Preview */}
                <div className="relative h-32 sm:h-36 w-full rounded-2xl bg-neutral-900 overflow-hidden border border-neutral-200 group">
                  {coverUrl ? (
                    <img src={coverUrl} alt="Cover preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-xs text-neutral-400 font-sans p-4 text-center">
                      <ImageIcon className="w-6 h-6 mb-1 text-neutral-500" />
                      <span>Default Sovereign Carbon Banner</span>
                    </div>
                  )}

                  {/* Overlay Upload Button on Hover */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => coverFileInputRef.current?.click()}
                      disabled={isProcessingCover}
                      className="px-3.5 py-1.5 rounded-xl bg-white text-black text-xs font-semibold flex items-center gap-1.5 shadow-md hover:bg-neutral-100 cursor-pointer transition-all"
                    >
                      {isProcessingCover ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      <span>Upload Banner Photo</span>
                    </button>
                  </div>
                </div>

                {/* Cover Action Controls (Upload Button + URL Input + Presets) */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => coverFileInputRef.current?.click()}
                    disabled={isProcessingCover}
                    className="min-h-[38px] px-4 py-2 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs shrink-0"
                  >
                    {isProcessingCover ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Upload className="w-3.5 h-3.5" />
                    )}
                    <span>Upload Cover Photo</span>
                  </button>

                  <div className="relative flex-1">
                    <input
                      type="url"
                      value={coverUrl}
                      onChange={(e) => setCoverUrl(e.target.value)}
                      placeholder="Or paste image URL (https://...)"
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-300 text-xs text-black font-mono focus:outline-none focus:border-black bg-white"
                    />
                  </div>
                </div>

                {/* Cover Presets */}
                <div className="flex items-center gap-1.5 overflow-x-auto pt-1 pb-0.5">
                  <span className="text-[11px] text-neutral-500 shrink-0 flex items-center gap-1 mr-1">
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span>Presets:</span>
                  </span>
                  {COVER_PRESETS.map((preset, idx) => (
                    <button
                      key={`cover-${idx}`}
                      type="button"
                      onClick={() => setCoverUrl(preset)}
                      className={`h-6 px-2.5 rounded-lg border text-[10px] font-medium transition-all shrink-0 cursor-pointer ${
                        coverUrl === preset
                          ? 'border-black bg-black text-white'
                          : 'border-neutral-200 bg-white text-neutral-600 hover:bg-neutral-100 hover:text-black'
                      }`}
                    >
                      Theme {idx + 1}
                    </button>
                  ))}
                </div>
              </div>

              {/* Avatar Photo Field & Direct Upload */}
              <div className="pt-4 border-t border-neutral-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-neutral-600" />
                    <span>Profile Avatar Photo</span>
                  </label>
                  {avatarUrl && (
                    <button
                      type="button"
                      onClick={() => setAvatarUrl('')}
                      className="text-[11px] text-neutral-500 hover:text-red-600 flex items-center gap-1 cursor-pointer transition-colors"
                      title="Reset avatar"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Use Initials</span>
                    </button>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                  {/* Avatar Preview */}
                  <div className="relative group shrink-0">
                    {avatarUrl ? (
                      <img
                        src={avatarUrl}
                        alt={fullName}
                        className="w-20 h-20 sm:w-22 sm:h-22 rounded-full object-cover border-2 border-white ring-2 ring-neutral-200 shadow-sm"
                      />
                    ) : (
                      <div className="w-20 h-20 sm:w-22 sm:h-22 rounded-full bg-black text-white flex items-center justify-center text-2xl font-serif-lux border-2 border-white ring-2 ring-neutral-200 shadow-sm">
                        {fullName ? fullName.charAt(0).toUpperCase() : 'U'}
                      </div>
                    )}

                    {/* Hover Upload Button */}
                    <button
                      type="button"
                      onClick={() => avatarFileInputRef.current?.click()}
                      disabled={isProcessingAvatar}
                      className="absolute inset-0 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs cursor-pointer"
                      title="Upload new avatar"
                    >
                      {isProcessingAvatar ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-5 h-5" />}
                    </button>
                  </div>

                  {/* Avatar Controls */}
                  <div className="flex-1 space-y-2 w-full">
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <button
                        type="button"
                        onClick={() => avatarFileInputRef.current?.click()}
                        disabled={isProcessingAvatar}
                        className="min-h-[38px] px-4 py-2 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs shrink-0"
                      >
                        {isProcessingAvatar ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Upload className="w-3.5 h-3.5" />
                        )}
                        <span>Upload Avatar Photo</span>
                      </button>

                      <div className="relative flex-1">
                        <input
                          type="url"
                          value={avatarUrl}
                          onChange={(e) => setAvatarUrl(e.target.value)}
                          placeholder="Or paste avatar URL (https://...)"
                          className="w-full px-3.5 py-2 rounded-xl border border-neutral-300 text-xs text-black font-mono focus:outline-none focus:border-black bg-white"
                        />
                      </div>
                    </div>

                    {/* Avatar Presets */}
                    <div className="flex items-center gap-1.5 overflow-x-auto pt-1">
                      <span className="text-[11px] text-neutral-500 shrink-0 flex items-center gap-1 mr-1">
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        <span>Presets:</span>
                      </span>
                      {AVATAR_PRESETS.map((preset, idx) => (
                        <button
                          key={`avatar-${idx}`}
                          type="button"
                          onClick={() => setAvatarUrl(preset)}
                          className={`w-7 h-7 rounded-full overflow-hidden border transition-all shrink-0 cursor-pointer ${
                            avatarUrl === preset
                              ? 'border-black ring-2 ring-black scale-110'
                              : 'border-neutral-200 hover:border-neutral-400'
                          }`}
                        >
                          <img src={preset} alt={`Preset ${idx + 1}`} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Name and Handle Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">Full Legal Name / Display Title</label>
                <div className="relative">
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-neutral-300 text-xs sm:text-sm text-black focus:outline-none focus:border-black"
                    required
                  />
                  <User className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-neutral-700">User ID / Handle</label>
                  {userId && (
                    <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                      userIdStatus.available ? 'text-emerald-600' : 'text-red-600'
                    }`}>
                      {userIdStatus.available ? (
                        <>
                          <CheckCircle2 className="w-3 h-3" />
                          <span>{userIdStatus.message || 'Available'}</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-3 h-3" />
                          <span>{userIdStatus.message || 'Unavailable'}</span>
                        </>
                      )}
                    </span>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="text"
                    value={userId}
                    onChange={(e) => handleUserIdChange(e.target.value)}
                    className={`w-full px-3.5 py-2.5 pl-9 rounded-xl border text-xs sm:text-sm text-black font-mono focus:outline-none ${
                      !userIdStatus.available ? 'border-red-300 bg-red-50/20' : 'border-neutral-300 focus:border-black'
                    }`}
                    required
                  />
                  <AtSign className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                </div>
              </div>
            </div>

            {/* Email */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-neutral-700">Primary Email Address</label>
                {email && (
                  <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                    emailStatus.available ? 'text-emerald-600' : 'text-red-600'
                  }`}>
                    {emailStatus.available ? (
                      <>
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{emailStatus.message || 'Available'}</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3 h-3" />
                        <span>{emailStatus.message || 'Unavailable'}</span>
                      </>
                    )}
                  </span>
                )}
              </div>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => handleEmailChange(e.target.value)}
                  className={`w-full px-3.5 py-2.5 pl-9 rounded-xl border text-xs sm:text-sm text-black focus:outline-none ${
                    !emailStatus.available ? 'border-red-300 bg-red-50/20' : 'border-neutral-300 focus:border-black'
                  }`}
                  required
                />
                <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
              </div>
            </div>

            {/* Gender Selection */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Gender Identity</label>
              <div className="grid grid-cols-3 gap-2">
                {(['male', 'female', 'other'] as const).map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGender(g)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-semibold capitalize transition-all cursor-pointer ${
                      gender === g
                        ? 'border-black bg-black text-white shadow-xs'
                        : 'border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-700'
                    }`}
                  >
                    {g === 'other' ? 'Other Gender' : g}
                  </button>
                ))}
              </div>
            </div>

            {/* Bio with No Limit */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-neutral-700">Bio / About Yourself &amp; Trading Focus</label>
                <span className="text-[10px] text-emerald-600 font-semibold px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200">
                  No Character Limit
                </span>
              </div>
              <textarea
                rows={4}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Describe your sovereign vault goals, barter assets, liquidity tranches, or personal background without length limits..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs sm:text-sm text-black focus:outline-none focus:border-black resize-y min-h-[100px]"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isSaving || isProcessingAvatar || isProcessingCover}
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer shadow-xs disabled:opacity-50 flex items-center gap-2"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Save Profile &amp; Account Changes</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* ================= TAB 2: SECURITY & PASSWORD ================= */}
      {activeTab === 'security' && (
        <form onSubmit={handleSaveSecurity} className="space-y-6">
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-100 pb-3.5">
              <h2 className="text-base font-semibold text-black flex items-center gap-2">
                <Lock className="w-4 h-4 text-neutral-800" />
                <span>Security &amp; Password Credentials</span>
              </h2>
              {currentUser.provider === 'google' && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-[11px] font-semibold">
                  <svg className="w-3 h-3" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Google Account Linked</span>
                </span>
              )}
            </div>

            {/* Provider banner for Google accounts */}
            {currentUser.provider === 'google' && (
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-slate-700 text-xs flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-semibold text-slate-900">Signed in with Google Single Sign-On</p>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    You can set or change a local account password anytime below. Setting a password enables hybrid access so you can sign in directly using your <strong>User ID</strong> (<code>@{currentUser.id}</code>) or <strong>Email</strong> (<code>{currentUser.email}</code>) in addition to Google Single Sign-On.
                  </p>
                </div>
              </div>
            )}

            {/* Password Fields */}
            <div className="space-y-4">
              {currentUser.provider !== 'google' && (
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">Current Password (optional)</label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs sm:text-sm text-black focus:outline-none focus:border-black"
                  />
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-neutral-700">
                    {currentUser.provider === 'google' ? 'Set / Update Account Password' : 'New Password'}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[11px] text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showPassword ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs sm:text-sm text-black focus:outline-none focus:border-black"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">Confirm New Password</label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs sm:text-sm text-black focus:outline-none focus:border-black"
                  required
                />
              </div>
            </div>

            {/* 2FA Toggle */}
            <div className="pt-4 border-t border-neutral-100 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-black flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Two-Factor Authentication (2FA)</span>
                </p>
                <p className="text-[11px] text-neutral-500">Require multi-vault signature confirmation for transactions.</p>
              </div>

              <button
                type="button"
                onClick={() => setTwoFactorEnabled(!twoFactorEnabled)}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                  twoFactorEnabled ? 'bg-black' : 'bg-neutral-300'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    twoFactorEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isSaving}
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer shadow-xs disabled:opacity-50 flex items-center gap-2"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Update Security Credentials</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* ================= TAB 3: VERIFICATION & $2/MO SUBSCRIPTION ================= */}
      {activeTab === 'verification' && (
        <div className="space-y-6">
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-100 pb-5">
              <div>
                <h2 className="text-base font-semibold text-black flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-amber-600" />
                  <span>Member Identity Verification &amp; Subscription</span>
                </h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Requires 2 verified forms of government/legal ID + $2.00/month recurring membership.
                </p>
              </div>

              {currentUser?.isVerified ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold self-start sm:self-auto">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Verified Member</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-semibold self-start sm:self-auto">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                  <span>Unverified Account</span>
                </span>
              )}
            </div>

            {/* Status Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-black flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4 text-blue-600" />
                    <span>2 Legal IDs Status</span>
                  </span>
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                    currentUser?.isVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {currentUser?.isVerified ? '2 / 2 Verified' : 'Action Needed'}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-500">
                  {currentUser?.isVerified
                    ? 'Passport & Sovereign Driver License verified with biometric matching.'
                    : 'Submit 2 forms of government ID to enable high-tier vaults & badge.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-black flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <span>$2.00 / month Membership</span>
                  </span>
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                    currentUser?.subscriptionActive ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-200 text-neutral-700'
                  }`}>
                    {currentUser?.subscriptionActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-500">
                  {currentUser?.subscriptionActive
                    ? 'Monthly auto-renew via sovereign card/crypto gateway active.'
                    : 'Subscribing unlocks verified gold shield & OTC direct swap liquidity.'}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              {currentUser?.isVerified ? (
                <button
                  type="button"
                  onClick={async () => {
                    const res = await cancelUserSubscription();
                    if (res.success && res.user) {
                      onUpdateSession(res.user);
                      setSuccessMessage('Subscription cancelled.');
                    }
                  }}
                  className="px-4 py-2 rounded-xl border border-neutral-300 text-neutral-700 hover:bg-neutral-50 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Manage / Cancel Subscription
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    if (onOpenVerificationModal) onOpenVerificationModal();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify with 2 IDs &amp; Subscribe ($2/mo)</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 4: NOTIFICATIONS ================= */}
      {activeTab === 'notifications' && (
        <div className="space-y-6">
          {/* Header Card */}
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-100 pb-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-700">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-black">Unified Notification &amp; Alert Engine</h2>
                  <p className="text-xs text-neutral-500">Configure multi-channel audio cues, floating toasts, browser pushes, and trade event alerts.</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerTestNotification('stocks')}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 text-xs font-bold transition-all shadow-xs cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Send Test Alert</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const defs = resetNotificationPreferences();
                    updateNotificationPrefs(defs);
                    addNotification({
                      title: 'Preferences Restored',
                      description: 'All alert and notification channels restored to defaults.',
                      type: 'system',
                      showToast: true,
                    });
                  }}
                  className="p-2 rounded-xl border border-neutral-200 hover:bg-neutral-50 text-neutral-600 hover:text-black transition-colors cursor-pointer"
                  title="Reset to default preferences"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Delivery Channels (Sound, In-App Banner, Desktop Push) */}
            <div>
              <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3">Delivery Channels</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                
                {/* Channel 1: Synthesized Audio Chimes */}
                <div className={`p-4 rounded-2xl border transition-all ${notificationPrefs.soundEnabled ? 'bg-amber-50/40 border-amber-200' : 'bg-neutral-50 border-neutral-200'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-neutral-900">
                      {notificationPrefs.soundEnabled ? <Volume2 className="w-4 h-4 text-amber-700" /> : <VolumeX className="w-4 h-4 text-neutral-400" />}
                      <span className="text-xs font-bold">Audio Chimes</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={notificationPrefs.soundEnabled}
                      onChange={(e) => updateNotificationPrefs({ soundEnabled: e.target.checked })}
                      className="w-4 h-4 accent-amber-600 cursor-pointer"
                    />
                  </div>
                  <p className="text-[11px] text-neutral-500 leading-relaxed">Synthesizes distinct Web Audio bell frequencies for trading fills and messages.</p>
                </div>

                {/* Channel 2: In-App Toast Banners */}
                <div className={`p-4 rounded-2xl border transition-all ${notificationPrefs.inAppBannerEnabled ? 'bg-amber-50/40 border-amber-200' : 'bg-neutral-50 border-neutral-200'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-neutral-900">
                      <Zap className="w-4 h-4 text-amber-700" />
                      <span className="text-xs font-bold">In-App Banners</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={notificationPrefs.inAppBannerEnabled}
                      onChange={(e) => updateNotificationPrefs({ inAppBannerEnabled: e.target.checked })}
                      className="w-4 h-4 accent-amber-600 cursor-pointer"
                    />
                  </div>
                  <p className="text-[11px] text-neutral-500 leading-relaxed">Displays top floating toast cards with quick action buttons and status indicators.</p>
                </div>

                {/* Channel 3: Desktop Browser Push */}
                <div className={`p-4 rounded-2xl border transition-all ${notificationPrefs.browserPushEnabled ? 'bg-amber-50/40 border-amber-200' : 'bg-neutral-50 border-neutral-200'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-neutral-900">
                      <Radio className="w-4 h-4 text-amber-700" />
                      <span className="text-xs font-bold">Browser Push</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={notificationPrefs.browserPushEnabled}
                      onChange={async (e) => {
                        const checked = e.target.checked;
                        if (checked && getBrowserNotificationPermission() !== 'granted') {
                          const res = await requestBrowserNotificationPermission();
                          updateNotificationPrefs({ browserPushEnabled: res === 'granted' });
                        } else {
                          updateNotificationPrefs({ browserPushEnabled: checked });
                        }
                      }}
                      className="w-4 h-4 accent-amber-600 cursor-pointer"
                    />
                  </div>
                  <p className="text-[11px] text-neutral-500 leading-relaxed">OS-native notifications when tabs are in the background or minimized.</p>
                </div>

              </div>
            </div>

            {/* Granular Notification Categories */}
            <div>
              <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3">Event Categories</h3>
              <div className="divide-y divide-neutral-100 border border-neutral-100 rounded-2xl overflow-hidden">
                {[
                  {
                    key: 'notifyStocks',
                    icon: <TrendingUp className="w-4 h-4 text-emerald-600" />,
                    title: 'Stock Market & Equities (All 4 Ways + Favorites)',
                    desc: 'Live price alerts, order fills, limit triggers, and holding growth milestone notifications.',
                    category: 'stocks' as const,
                  },
                  {
                    key: 'notifyTrades',
                    icon: <Sparkles className="w-4 h-4 text-amber-600" />,
                    title: 'OTC Barter & Trade Proposals',
                    desc: 'Incoming barter offers, escrow locks, and counterparty settlement confirmations.',
                    category: 'trade' as const,
                  },
                  {
                    key: 'notifyVaultYield',
                    icon: <Landmark className="w-4 h-4 text-amber-700" />,
                    title: 'Reserve Vault & Bullion Custody',
                    desc: 'Physical vault allocations, Zurich depository audits, and yields.',
                    category: 'vault' as const,
                  },
                  {
                    key: 'notifyWallet',
                    icon: <Wallet className="w-4 h-4 text-sky-600" />,
                    title: 'Wallets, Transfers & Staking Epochs',
                    desc: 'Final Coin deposits, multi-signature transactions, and staking reward distributions.',
                    category: 'wallet' as const,
                  },
                  {
                    key: 'notifyMarketplace',
                    icon: <ShoppingBag className="w-4 h-4 text-purple-600" />,
                    title: 'Marketplace Listings & Inquiries',
                    desc: 'Buyer purchases, offer submissions, and listing draft publication status.',
                    category: 'marketplace' as const,
                  },
                  {
                    key: 'notifyMessages',
                    icon: <MessageSquare className="w-4 h-4 text-indigo-600" />,
                    title: 'Direct Messages & Conferences',
                    desc: 'Real-time trader chats, audio/video meeting pings, and institutional desk replies.',
                    category: 'chat' as const,
                  },
                  {
                    key: 'notifyFriendRequests',
                    icon: <Users className="w-4 h-4 text-pink-600" />,
                    title: 'Social Network, Follows & Comments',
                    desc: 'New community followers, post likes, broadcast shares, and mentions.',
                    category: 'social' as const,
                  },
                  {
                    key: 'notifySubsidies',
                    icon: <Award className="w-4 h-4 text-teal-600" />,
                    title: 'Sovereign Subsidies & Grants',
                    desc: 'Claim approval disbursements, government research subsidies, and tax credit checks.',
                    category: 'subsidies' as const,
                  },
                  {
                    key: 'notifyFundraising',
                    icon: <Rocket className="w-4 h-4 text-orange-600" />,
                    title: 'Fundraising & Capital Campaigns',
                    desc: 'Milestone backer investments, round closures, and equity allocations.',
                    category: 'fundraising' as const,
                  },
                  {
                    key: 'notifySecurity',
                    icon: <ShieldCheck className="w-4 h-4 text-rose-600" />,
                    title: 'Security, Multi-Factor & Biometrics',
                    desc: 'New device logins, session expirations, passkey updates, and ledger reversals.',
                    category: 'security' as const,
                  },
                  {
                    key: 'notifySystem',
                    icon: <Zap className="w-4 h-4 text-slate-700" />,
                    title: 'System & Engine Telemetry',
                    desc: 'Final Finance ledger synchronization, network latency, and backup audits.',
                    category: 'system' as const,
                  },
                ].map((item) => (
                  <div key={item.key} className="p-3.5 sm:px-4 flex items-center justify-between gap-3 hover:bg-neutral-50/70 transition-colors">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="p-2 rounded-xl bg-neutral-100 shrink-0 mt-0.5">
                        {item.icon}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-neutral-900 truncate">{item.title}</p>
                        <p className="text-[11px] text-neutral-500 line-clamp-1 leading-normal">{item.desc}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <button
                        type="button"
                        onClick={() => triggerTestNotification(item.category)}
                        className="px-2 py-1 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-[10px] font-bold inline-flex items-center gap-1 transition-colors cursor-pointer"
                        title={`Send sample ${item.title} alert`}
                      >
                        <Play className="w-2.5 h-2.5 fill-current" />
                        <span className="hidden sm:inline">Test</span>
                      </button>

                      <input
                        type="checkbox"
                        checked={Boolean(notificationPrefs[item.key as keyof typeof notificationPrefs])}
                        onChange={(e) => updateNotificationPrefs({ [item.key]: e.target.checked })}
                        className="w-4 h-4 accent-amber-600 cursor-pointer"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ================= TAB: GIVE APP FEEDBACK ================= */}
      {activeTab === 'give_feedback' && (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex items-center gap-3 border-b border-neutral-100 pb-4">
              <div className="p-2.5 bg-indigo-50 rounded-2xl text-indigo-600">
                <MessageSquare className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-black">Give App Feedback</h2>
                <p className="text-xs text-neutral-500">Help us improve your Final Finance ecosystem experience</p>
              </div>
            </div>

            {feedbackSuccess ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-50 border border-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                  <Check className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-serif-lux text-xl font-bold text-neutral-900">
                    Feedback Submitted Successfully!
                  </h4>
                  <p className="text-sm text-neutral-500 max-w-sm mx-auto leading-relaxed">
                    Thank you for your valuable insights. Your feedback has been logged and forwarded directly to the system administrators for review.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setFeedbackSuccess(false);
                    setFeedbackComments('');
                    setFeedbackSuggestions('');
                    setFeedbackCategory('general');
                    setFeedbackIsAnonymous(false);
                  }}
                  className="min-h-[44px] px-8 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all cursor-pointer shadow-md"
                >
                  Submit More Feedback
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!feedbackComments.trim()) return;
                  setIsFeedbackSubmitting(true);
                  setTimeout(() => {
                    submitFeedback({
                      rating: 5,
                      category: feedbackCategory,
                      comments: feedbackComments,
                      suggestions: feedbackSuggestions || undefined,
                      isAnonymous: feedbackIsAnonymous,
                      user: currentUser,
                    });
                    addNotification({
                      title: 'Feedback Logged Successfully',
                      description: `Your ${feedbackCategory.toUpperCase()} review was sent directly to administrative queues. Thank you!`,
                      type: 'feedback',
                      targetTab: 'settings',
                    });
                    setIsFeedbackSubmitting(false);
                    setFeedbackSuccess(true);
                  }, 750);
                }}
                className="max-w-2xl space-y-6"
              >
                {/* Category Selection */}
                <div>
                  <label className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block mb-2">
                    Feedback Category
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {[
                      { id: 'general', label: 'General Thoughts' },
                      { id: 'bug', label: 'Bug Report' },
                      { id: 'feature', label: 'Feature Request' },
                      { id: 'ui', label: 'UI/UX Polish' },
                      { id: 'other', label: 'Other Idea' },
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setFeedbackCategory(cat.id as any)}
                        className={`px-4 py-3 rounded-2xl text-xs font-semibold border transition-all text-center cursor-pointer ${
                          feedbackCategory === cat.id
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                            : 'bg-neutral-50 border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Feedback comments */}
                <div>
                  <label className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block mb-2">
                    What was your experience?
                  </label>
                  <textarea
                    required
                    value={feedbackComments}
                    onChange={(e) => setFeedbackComments(e.target.value)}
                    placeholder="Tell us what you liked, what felt confusing, or describe any bugs encountered..."
                    className="w-full px-4 py-3 rounded-2xl border border-neutral-200 bg-neutral-50/50 text-xs sm:text-sm text-black focus:outline-none focus:border-indigo-500 focus:bg-white transition-all resize-y min-h-[120px]"
                  />
                </div>

                {/* Suggestions */}
                <div>
                  <label className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider block mb-2">
                    Do you have any usability suggestions? (Optional)
                  </label>
                  <textarea
                    value={feedbackSuggestions}
                    onChange={(e) => setFeedbackSuggestions(e.target.value)}
                    placeholder="e.g. Add more filtering options to the vault view..."
                    className="w-full px-4 py-3 rounded-2xl border border-neutral-200 bg-neutral-50/50 text-xs sm:text-sm text-black focus:outline-none focus:border-indigo-500 focus:bg-white transition-all resize-y min-h-[80px]"
                  />
                </div>

                {/* Anonymous Toggle */}
                <div className="flex items-center justify-between p-4 bg-neutral-50 rounded-2xl border border-neutral-200">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white rounded-xl shadow-2xs">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-neutral-900">Submit Anonymously</p>
                      <p className="text-[10px] text-neutral-500">Your handle and avatar will be hidden from administrators.</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFeedbackIsAnonymous(!feedbackIsAnonymous)}
                    className={`w-10 h-6 rounded-full p-1 transition-colors ${
                      feedbackIsAnonymous ? 'bg-emerald-600' : 'bg-neutral-300'
                    }`}
                  >
                    <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      feedbackIsAnonymous ? 'translate-x-4' : 'translate-x-0'
                    }`} />
                  </button>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isFeedbackSubmitting}
                    className="w-full sm:w-auto min-h-[44px] px-10 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-lg disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isFeedbackSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Sending Feedback...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Submit Feedback Entry</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB: RESPONSE BACK ================= */}
      {activeTab === 'response_back' && (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-6 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600">
                  <Reply className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-black">Response Back</h2>
                  <p className="text-xs text-neutral-500">Track responses from the administration team regarding your feedback.</p>
                </div>
              </div>
            </div>

            {feedbackHistory.length === 0 ? (
              <div className="py-12 text-center space-y-3 bg-neutral-50/50 rounded-2xl border border-dashed border-neutral-200">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto text-neutral-300 shadow-sm">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-neutral-900">No feedback entries yet</p>
                  <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                    Your submitted comments and official admin response messages will appear here.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {feedbackHistory.map((fb) => (
                  <div key={fb.id} className="p-5 rounded-2xl border border-neutral-200 bg-neutral-50/30 hover:bg-white hover:border-neutral-300 transition-all space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-white border border-neutral-200 flex items-center justify-center text-neutral-400 shadow-2xs">
                          <MessageSquare className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-neutral-900 capitalize">{fb.category}</span>
                            <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                              fb.status === 'resolved' ? 'bg-emerald-100 text-emerald-800' :
                              fb.status === 'reviewed' ? 'bg-indigo-100 text-indigo-800' :
                              'bg-amber-100 text-amber-800'
                            }`}>
                              {fb.status}
                            </span>
                          </div>
                          <p className="text-[10px] text-neutral-400 mt-0.5">
                            Submitted {new Date(fb.timestamp).toLocaleDateString()} at {new Date(fb.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                      <div className="text-[10px] font-mono text-neutral-400">#{fb.id.slice(-6).toUpperCase()}</div>
                    </div>

                    <div className="bg-white/80 p-3.5 rounded-xl border border-neutral-100/80 shadow-3xs">
                      <p className="text-xs text-neutral-700 leading-relaxed italic">"{fb.comments}"</p>
                      {fb.suggestions && (
                        <div className="mt-2 pt-2 border-t border-neutral-100">
                          <p className="text-[11px] font-semibold text-neutral-500 uppercase tracking-tighter mb-1">Suggestions</p>
                          <p className="text-[11px] text-neutral-600 leading-relaxed">{fb.suggestions}</p>
                        </div>
                      )}
                    </div>

                    {fb.reviewMessage && (
                      <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 space-y-2 animate-in fade-in slide-in-from-top-2 duration-500">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                            <Clock className="w-3.5 h-3.5" />
                          </div>
                          <h4 className="text-xs font-bold text-indigo-900">Review</h4>
                          {fb.reviewedAt && (
                            <span className="text-[10px] text-indigo-600 ml-auto font-medium">
                              {new Date(fb.reviewedAt).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-indigo-800 leading-relaxed font-medium pl-8">
                          {fb.reviewMessage}
                        </p>
                      </div>
                    )}

                    {fb.status === 'resolved' && fb.resolutionMessage && (
                      <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 space-y-2 animate-in fade-in slide-in-from-top-2 duration-500">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                          <h4 className="text-xs font-bold text-emerald-900">Resolution</h4>
                          {fb.resolvedAt && (
                            <span className="text-[10px] text-emerald-600 ml-auto font-medium">
                              {new Date(fb.resolvedAt).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-emerald-800 leading-relaxed font-medium pl-8">
                          {fb.resolutionMessage}
                        </p>
                      </div>
                    )}

                    {fb.status === 'reviewed' && !fb.reviewMessage && (
                      <div className="flex items-center gap-2 py-1 px-3 rounded-lg bg-indigo-50/50 border border-indigo-100 w-fit">
                        <Loader2 className="w-3 h-3 text-indigo-500 animate-spin" />
                        <span className="text-[10px] font-semibold text-indigo-700">Currently under formal review by the team</span>
                      </div>
                    )}

                    {/* Trash Button at the bottom of the entire section */}
                    <div className="pt-2 flex justify-end">
                      {deletingFeedbackId === fb.id ? (
                        <div className="flex items-center gap-2 animate-in fade-in zoom-in-95 duration-200">
                          <span className="text-[10px] font-bold text-red-600 uppercase tracking-tight">Confirm Deletion?</span>
                          <button
                            type="button"
                            onClick={() => {
                              deleteFeedback(fb.id);
                              setDeletingFeedbackId(null);
                              setFeedbackSuccess(!feedbackSuccess);
                            }}
                            className="px-3 py-1 bg-red-600 text-white rounded-lg text-[10px] font-bold hover:bg-red-700 transition-colors shadow-2xs cursor-pointer"
                          >
                            Delete
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeletingFeedbackId(null)}
                            className="px-3 py-1 bg-neutral-100 text-neutral-500 rounded-lg text-[10px] font-bold hover:bg-neutral-200 transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setDeletingFeedbackId(fb.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-neutral-600 text-[10px] font-bold hover:bg-neutral-100 hover:text-red-600 hover:border-red-200 transition-all cursor-pointer shadow-3xs"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Trash</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB: ACCOUNT DEACTIVATION & DELETION ================= */}
      {activeTab === 'account_deactivation' && (
        <div className="bg-white border border-red-200/90 rounded-3xl p-6 shadow-xs space-y-6">
          <div className="flex items-center gap-3 border-b border-neutral-100 pb-4">
            <div className="w-10 h-10 rounded-2xl bg-red-50 flex items-center justify-center text-red-600">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-black">Account Deactivation &amp; Permanent Deletion</h2>
              <p className="text-xs text-neutral-500">Manage temporary suspension or permanent removal of your account and data.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl bg-amber-50/50 border border-amber-200 space-y-4 flex flex-col justify-between">
              <div className="space-y-2">
                <h3 className="text-xs font-semibold text-amber-900 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  <span>Deactivate Account</span>
                </h3>
                <p className="text-xs text-neutral-600 leading-relaxed">
                  Temporarily suspend your account and hide your public profile and listings. Your data is preserved and you can reactivate anytime simply by signing back in with your credentials.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowDeactivateModal(true)}
                className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-2"
              >
                <span>Deactivate Account</span>
              </button>
            </div>

            <div className="p-5 rounded-2xl bg-red-50/60 border border-red-200 space-y-4 flex flex-col justify-between">
              <div className="space-y-2">
                <h3 className="text-xs font-semibold text-red-900 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-600"></span>
                  <span>Delete Account Permanently</span>
                </h3>
                <p className="text-xs text-neutral-600 leading-relaxed">
                  Permanently delete your account, login credentials, profile, chat history, and local wallet vaults. This action cannot be undone and all data will be erased.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setDeleteConfirmationInput('');
                  setShowDeleteModal(true);
                }}
                className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-semibold transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Account Permanently</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: LINKED PAYMENT METHODS, BANKS & CRYPTO WALLETS */}
      {activeTab === 'payment_methods' && (
        <div className="space-y-6">
          {/* Header Sync Banner */}
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-sm text-slate-900">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-amber-600 uppercase tracking-wider mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Unified Settlement Layer</span>
                </div>
                <h2 className="text-lg font-serif-lux font-light tracking-tight text-slate-900">
                  Banks, Cards &amp; Web3 Crypto Wallets
                </h2>
                <p className="text-xs text-slate-500 mt-1 max-w-xl">
                  Payment methods linked here are automatically shared and accepted across the Equities Stock Exchange, P2P Vaults, and Cash Reserves without redundant re-verification.
                </p>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    setLinkModalTab('bank');
                    setIsLinkModalOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
                >
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>+ Link Bank</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setLinkModalTab('card');
                    setIsLinkModalOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
                >
                  <CreditCard className="w-3.5 h-3.5 text-purple-600" />
                  <span>+ Link Card</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setLinkModalTab('crypto');
                    setIsLinkModalOpen(true);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-emerald-200"
                >
                  <Wallet className="w-3.5 h-3.5 text-emerald-600" />
                  <span>+ Connect Crypto</span>
                </button>
              </div>
            </div>

            {/* Quick Status Pill Bar */}
            <div className="flex items-center gap-2 sm:gap-4 mt-4 pt-3 border-t border-slate-100 text-xs text-slate-600 flex-wrap">
              <span className="flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                <strong className="text-slate-900">{userWallets.linkedBankAccounts?.length || 0}</strong> Banks Connected
              </span>
              <span className="text-slate-300">•</span>
              <span className="flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-purple-600" />
                <strong className="text-slate-900">{userWallets.linkedCards?.length || 0}</strong> Cards Active
              </span>
              <span className="text-slate-300">•</span>
              <span className="flex items-center gap-1.5">
                <Wallet className="w-3.5 h-3.5 text-emerald-600" />
                <strong className="text-slate-900">{userWallets.linkedCryptoWallets?.length || 0}</strong> Web3 Wallets Linked
              </span>
            </div>
          </div>

          {/* Section 1: Linked Bank Accounts */}
          <div className="p-4 sm:p-5 rounded-3xl border border-neutral-200 bg-white shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-700">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Linked Bank Accounts</h3>
                  <p className="text-xs text-slate-500">Direct FedNow instant settlement and ACH wire transfers</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setLinkModalTab('bank');
                  setIsLinkModalOpen(true);
                }}
                className="px-3 py-1.5 rounded-xl border border-blue-200 bg-blue-50/60 hover:bg-blue-100 text-blue-900 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Bank</span>
              </button>
            </div>

            {(!userWallets.linkedBankAccounts || userWallets.linkedBankAccounts.length === 0) ? (
              <div className="p-6 rounded-2xl border border-dashed border-neutral-200 text-center bg-neutral-50/60">
                <Building2 className="w-8 h-8 mx-auto text-neutral-400 mb-2 opacity-60" />
                <p className="text-xs font-bold text-slate-700">No bank accounts linked yet</p>
                <p className="text-[11px] text-slate-500 mt-0.5 max-w-sm mx-auto">
                  Connect a checking or savings account (e.g., Chase, Wells Fargo, BofA) for instant ACH deposits and equities settlements.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setLinkModalTab('bank');
                    setIsLinkModalOpen(true);
                  }}
                  className="mt-3 px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 hover:text-slate-900 transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Link Bank Account</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {userWallets.linkedBankAccounts.map((bank) => (
                  <div
                    key={bank.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50/40 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{bank.bankName}</span>
                          {bank.isDefault && (
                            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[10px] font-bold uppercase tracking-wider">
                              Default
                            </span>
                          )}
                          <span className="px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-semibold flex items-center gap-0.5">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{bank.status || 'FedNow Instant'}</span>
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveBank(bank.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-all cursor-pointer"
                          title="Unlink Bank Account"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="space-y-1 text-xs text-slate-600 font-mono">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Account:</span>
                          <span className="font-semibold text-slate-800 capitalize">{bank.accountType} ••••{bank.accountNumberLast4}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Routing:</span>
                          <span>{bank.routingNumberMasked || '••••0210'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Settlement Cap:</span>
                          <span className="font-bold text-emerald-700">${(bank.balanceUSD ?? 150000).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {!bank.isDefault && (
                      <button
                        type="button"
                        onClick={() => handleSetDefaultBank(bank.id)}
                        className="mt-3 pt-2.5 border-t border-slate-200/80 text-[11px] font-bold text-slate-600 hover:text-slate-900 transition-colors text-left flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Set as Default Bank</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 2: Linked Payment Cards */}
          <div className="p-4 sm:p-5 rounded-3xl border border-neutral-200 bg-white shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-700">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Linked Payment Cards</h3>
                  <p className="text-xs text-slate-500">Instant debit and credit card authorizations</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setLinkModalTab('card');
                  setIsLinkModalOpen(true);
                }}
                className="px-3 py-1.5 rounded-xl border border-purple-200 bg-purple-50/60 hover:bg-purple-100 text-purple-900 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Card</span>
              </button>
            </div>

            {(!userWallets.linkedCards || userWallets.linkedCards.length === 0) ? (
              <div className="p-6 rounded-2xl border border-dashed border-neutral-200 text-center bg-neutral-50/60">
                <CreditCard className="w-8 h-8 mx-auto text-neutral-400 mb-2 opacity-60" />
                <p className="text-xs font-bold text-slate-700">No payment cards linked yet</p>
                <p className="text-[11px] text-slate-500 mt-0.5 max-w-sm mx-auto">
                  Link a Visa, Mastercard, or American Express for 1-click purchases and instantaneous reserve funding.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setLinkModalTab('card');
                    setIsLinkModalOpen(true);
                  }}
                  className="mt-3 px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 hover:text-slate-900 transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Link Payment Card</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {userWallets.linkedCards.map((card) => (
                  <div
                    key={card.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50/40 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{card.brand ? card.brand.toUpperCase() : 'CARD'}</span>
                          <span className="px-1.5 py-0.5 rounded-md bg-slate-200 text-slate-700 text-[10px] font-bold uppercase">
                            {card.cardType || 'debit'}
                          </span>
                          {card.isDefault && (
                            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[10px] font-bold uppercase tracking-wider">
                              Default
                            </span>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveCard(card.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-all cursor-pointer"
                          title="Unlink Card"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="space-y-1 text-xs text-slate-600 font-mono">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Card Number:</span>
                          <span className="font-bold text-slate-800">•••• •••• •••• {card.cardNumberLast4}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Expires:</span>
                          <span>{card.expiryMonth}/{card.expiryYear}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Holder:</span>
                          <span className="font-sans font-medium text-slate-700 truncate max-w-[140px]">{card.cardholderName}</span>
                        </div>
                      </div>
                    </div>

                    {!card.isDefault && (
                      <button
                        type="button"
                        onClick={() => handleSetDefaultCard(card.id)}
                        className="mt-3 pt-2.5 border-t border-slate-200/80 text-[11px] font-bold text-slate-600 hover:text-slate-900 transition-colors text-left flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Set as Default Card</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 3: Connected Web3 Crypto Wallets */}
          <div className="p-4 sm:p-5 rounded-3xl border border-neutral-200 bg-white shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-700">
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Connected Web3 Crypto Wallets</h3>
                  <p className="text-xs text-slate-500">Non-custodial wallets &amp; smart contract execution</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setLinkModalTab('crypto');
                  setIsLinkModalOpen(true);
                }}
                className="px-3 py-1.5 rounded-xl border border-emerald-200 bg-emerald-50/60 hover:bg-emerald-100 text-emerald-900 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Connect Wallet</span>
              </button>
            </div>

            {(!userWallets.linkedCryptoWallets || userWallets.linkedCryptoWallets.length === 0) ? (
              <div className="p-6 rounded-2xl border border-dashed border-neutral-200 text-center bg-neutral-50/60">
                <Wallet className="w-8 h-8 mx-auto text-neutral-400 mb-2 opacity-60" />
                <p className="text-xs font-bold text-slate-700">No Web3 crypto wallets connected</p>
                <p className="text-[11px] text-slate-500 mt-0.5 max-w-sm mx-auto">
                  Connect MetaMask, Phantom, Coinbase Wallet, or Ledger to directly fund equities purchases and on-chain settlements.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setLinkModalTab('crypto');
                    setIsLinkModalOpen(true);
                  }}
                  className="mt-3 px-3.5 py-1.5 rounded-xl bg-white border border-emerald-200 text-emerald-700 text-xs font-bold hover:bg-emerald-50 transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Connect Crypto Wallet</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {userWallets.linkedCryptoWallets.map((wallet) => (
                  <div
                    key={wallet.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50/40 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{wallet.walletName}</span>
                          <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                            {wallet.network}
                          </span>
                          {wallet.isPrimary && (
                            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[10px] font-bold uppercase tracking-wider">
                              Primary
                            </span>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveCrypto(wallet.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-all cursor-pointer"
                          title="Disconnect Crypto Wallet"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="space-y-1 text-xs text-slate-600 font-mono">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Address:</span>
                          <span className="font-semibold text-slate-800">
                            {wallet.address && wallet.address.length > 14
                              ? `${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`
                              : (wallet.address || '0x...')}
                          </span>
                        </div>
                        {wallet.ensOrDomain && (
                          <div className="flex justify-between">
                            <span className="text-slate-400 font-sans text-[11px]">Handle / ENS:</span>
                            <span className="font-sans font-semibold text-emerald-700">{wallet.ensOrDomain}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-sans text-[11px]">Reserve Balance:</span>
                          <span className="font-bold text-slate-900">${(wallet.balanceUSD ?? 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {!wallet.isPrimary && (
                      <button
                        type="button"
                        onClick={() => handleSetPrimaryCrypto(wallet.id)}
                        className="mt-3 pt-2.5 border-t border-slate-200/80 text-[11px] font-bold text-emerald-700 hover:text-emerald-800 transition-colors text-left flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Set as Primary Crypto Wallet</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Global Link Bank, Card, or Crypto Wallet Modal */}
      <LinkBankCardModal
        userId={currentUser.id || 'guest'}
        isOpen={isLinkModalOpen}
        initialTab={linkModalTab}
        onClose={() => setIsLinkModalOpen(false)}
        onSuccess={(type, label) => {
          const typeName = type === 'bank' ? 'Bank Account' : type === 'card' ? 'Card' : 'Crypto Wallet';
          setSuccessMessage(`Successfully linked ${label} to your unified payment accounts.`);
        }}
      />


      {/* Deactivate Account Confirmation Modal */}
      {showDeactivateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 w-full max-w-md text-black space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-semibold">Deactivate Your Account?</h3>
                <p className="text-xs text-neutral-500">Your profile will be hidden and your session ended.</p>
              </div>
            </div>
            <p className="text-xs text-neutral-600 bg-neutral-50 p-3 rounded-xl border border-neutral-200">
              Deactivation is temporary. You can reactivate your account at any time by logging back in with your credentials.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeactivateModal(false)}
                disabled={isDangerProcessing}
                className="px-4 py-2 rounded-xl border border-neutral-300 text-neutral-700 text-xs font-semibold hover:bg-neutral-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeactivateAccount}
                disabled={isDangerProcessing}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-xs"
              >
                {isDangerProcessing && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Confirm Deactivation</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Account Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 w-full max-w-md text-black space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-red-100 flex items-center justify-center text-red-600">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-red-700">Delete Account Permanently?</h3>
                <p className="text-xs text-neutral-500">This action is irreversible and permanent.</p>
              </div>
            </div>
            <p className="text-xs text-neutral-600 bg-red-50 p-3 rounded-xl border border-red-200">
              All your vault records, profile data, linked cards, and subscription settings will be permanently erased.
            </p>
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-neutral-700">
                Type your User ID (<span className="font-mono text-black font-bold">@{currentUser?.id}</span>) or <span className="font-mono text-red-600 font-bold">DELETE</span> to confirm:
              </label>
              <input
                type="text"
                value={deleteConfirmationInput}
                onChange={(e) => setDeleteConfirmationInput(e.target.value)}
                placeholder={`Type @${currentUser?.id} or DELETE`}
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs font-mono text-black focus:outline-none focus:border-red-600"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDangerProcessing}
                className="px-4 py-2 rounded-xl border border-neutral-300 text-neutral-700 text-xs font-semibold hover:bg-neutral-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteAccount}
                disabled={isDangerProcessing || (!deleteConfirmationInput.trim())}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
              >
                {isDangerProcessing && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Permanently Delete Account</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};