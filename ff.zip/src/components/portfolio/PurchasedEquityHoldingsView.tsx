import React, { useState, useEffect, useMemo } from 'react';
import { 
  Briefcase, 
  Building, 
  User, 
  Search, 
  TrendingUp, 
  TrendingDown,
  ExternalLink, 
  ShieldCheck, 
  Zap, 
  Coins, 
  Building2, 
  Plus, 
  Layers,
  ArrowRight,
  Filter,
  CheckCircle2,
  Sparkles,
  Star,
  Users,
  Radio,
  Clock,
  DollarSign,
  Globe,
  Share2,
  ArrowLeftRight,
  X,
  Check,
  Twitter
} from 'lucide-react';
import { StockMarketWay, StockItem, StockOrder, SocialStockTrade } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { IPORequest } from '../../types/stocks';
import { MyIPOsTab } from './MyIPOsTab';
import { CurrenciesDirectoryAndWalletView } from './CurrenciesDirectoryAndWalletView';
import { FinalStocksTradeOptionsModal } from './FinalStocksTradeOptionsModal';
import { createTweet } from '../../services/tweetingService';
import { getCurrentSession } from '../../services/firebaseAuth';
import {
  FRIENDS_AND_MUTUALS,
  getStoredSharedSocialTrades,
  removeSharedSocialTrade,
  saveSharedSocialTrade,
  SHARED_SOCIAL_TRADES_EVENT
} from '../../data/socialTradesData';

export interface EnrichedStockPosition {
  ticker: string;
  name: string;
  shares: number;
  avgCostUSD: number;
  currentPriceUSD: number;
  totalValueUSD: number;
  totalGainUSD: number;
  totalGainPercent: number;
  sector: string;
  subSector?: string;
  marketType: StockMarketWay;
  settlementMethod: string;
  assetCategory: 'business' | 'personal' | 'spot';
  isSpotStock?: boolean;
  isEquity?: boolean;
  issuerName?: string;
  issuerHandle?: string;
  issuerAvatar?: string;
  ipoDetails?: any;
}

interface PurchasedEquityHoldingsViewProps {
  enrichedPositions: EnrichedStockPosition[];
  businessPositions: EnrichedStockPosition[];
  personalPositions: EnrichedStockPosition[];
  businessNAV: number;
  personalNAV: number;
  businessGainUSD: number;
  personalGainUSD: number;
  businessGainPercent: number;
  personalGainPercent: number;
  totalStockPositionsUSD: number;
  totalStockGainUSD: number;
  totalStockCostBasisUSD: number;
  totalStockGainPercent: number;
  selectedMarketFilter: StockMarketWay | null;
  onSelectMarketFilter: (market: StockMarketWay | null) => void;
  assetCategoryFilter: 'all' | 'business' | 'personal';
  onSelectAssetCategoryFilter: (cat: 'all' | 'business' | 'personal') => void;
  searchQuery: string;
  onSearchQueryChange: (q: string) => void;
  stocks: StockItem[];
  watchlist?: string[];
  ipos?: IPORequest[];
  orders?: StockOrder[];
  onToggleWatchlist?: (ticker: string) => void;
  filteredFollowedStocks?: StockItem[];
  currentUser?: AuthSession | null;
  activeSubTab?: 'owned' | 'following' | 'my_ipos' | 'currencies' | 'coin_launchpad';
  onSelectSubTab?: (tab: 'owned' | 'following' | 'my_ipos' | 'currencies' | 'coin_launchpad') => void;
  onSelectStock?: (stock: StockItem) => void;
  onOpenTradeModal: (tickerOrStock: string | StockItem, side: 'buy' | 'sell') => void;
  onOpenStockMarket?: (marketWay?: StockMarketWay | 'all') => void;
  onOpenReleaseModal?: () => void;
  onRequestDelist?: (ipo: IPORequest) => void;
  onSwitchToPortfolioTab?: () => void;
  onSwitchToDerivativesTab?: () => void;
  onNavigateToSocial?: (notice?: string) => void;
}

export const PurchasedEquityHoldingsView: React.FC<PurchasedEquityHoldingsViewProps> = ({
  enrichedPositions,
  businessPositions,
  personalPositions,
  businessNAV,
  personalNAV,
  businessGainUSD,
  personalGainUSD,
  businessGainPercent,
  personalGainPercent,
  totalStockPositionsUSD,
  totalStockGainUSD,
  totalStockCostBasisUSD,
  totalStockGainPercent,
  selectedMarketFilter,
  onSelectMarketFilter,
  assetCategoryFilter,
  onSelectAssetCategoryFilter,
  searchQuery,
  onSearchQueryChange,
  stocks,
  watchlist = [],
  ipos = [],
  orders = [],
  onToggleWatchlist,
  filteredFollowedStocks,
  currentUser,
  activeSubTab = 'owned',
  onSelectSubTab,
  onSelectStock,
  onOpenTradeModal,
  onOpenStockMarket,
  onOpenReleaseModal,
  onRequestDelist,
  onSwitchToPortfolioTab,
  onSwitchToDerivativesTab,
  onNavigateToSocial,
}) => {
  // Final Stocks Trade Options Modal State
  const [isFinalTradeOptionsModalOpen, setIsFinalTradeOptionsModalOpen] = useState(false);

  // Share Trade with Friends Modal State & Live Shared Status
  const friendsList = useMemo(() => FRIENDS_AND_MUTUALS, []);
  const [sharedTrades, setSharedTrades] = useState<SocialStockTrade[]>(() => getStoredSharedSocialTrades());
  const [sharingPosition, setSharingPosition] = useState<EnrichedStockPosition | null>(null);
  const [shareSide, setShareSide] = useState<'buy' | 'sell'>('buy');
  const [shareSharesInput, setShareSharesInput] = useState<string>('1');
  const [shareNoteInput, setShareNoteInput] = useState<string>('');
  const [shareToSocial, setShareToSocial] = useState<boolean>(true);
  const [shareToTweeting, setShareToTweeting] = useState<boolean>(false);
  const [shareAudienceMode, setShareAudienceMode] = useState<'all' | 'selected'>('all');
  const [selectedFriendIds, setSelectedFriendIds] = useState<string[]>(() =>
    FRIENDS_AND_MUTUALS.map((f) => f.uid)
  );
  const [shareToast, setShareToast] = useState<{ text: string; sharedToSocial: boolean; sharedToTweeting: boolean } | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [favoritesCategoryFilter, setFavoritesCategoryFilter] = useState<'all' | 'business' | 'personal'>('all');

  useEffect(() => {
    const syncShared = () => setSharedTrades(getStoredSharedSocialTrades());
    window.addEventListener(SHARED_SOCIAL_TRADES_EVENT, syncShared);
    window.addEventListener('storage', syncShared);
    return () => {
      window.removeEventListener(SHARED_SOCIAL_TRADES_EVENT, syncShared);
      window.removeEventListener('storage', syncShared);
    };
  }, []);

  const handleUnshareTicker = (ticker: string) => {
    const matches = sharedTrades.filter((t) => t.ticker.toUpperCase() === ticker.toUpperCase());
    if (matches.length === 0) return;
    matches.forEach((m) => removeSharedSocialTrade(m.id));
    setSharedTrades(getStoredSharedSocialTrades());
    setShareToast({
      text: `Unshared $${ticker.toUpperCase()} trade from friends' Social feed.`,
      sharedToSocial: false,
      sharedToTweeting: false,
    });
    setTimeout(() => setShareToast(null), 4000);
  };

  const getSpotCoinLabel = (ticker: string): string => {
    const t = (ticker || '').toUpperCase().trim();
    if (t === 'ALEX') return '$ALEX';
    if (t === 'BSYN') return '$BSYN';
    if (t === 'GLD' || t === 'GLD-STBL') return '$GLD';
    if (t === 'HYPR') return '$HYPR';
    if (t === 'SOLN') return '$SOLN';
    if (t === 'QBIT') return '$QBIT';
    if (t === 'AFNL-EQ') return '$AFNL';
    return `$${t}`;
  };

  const handleOpenShareModal = (
    pos: EnrichedStockPosition,
    overrideOrder?: StockOrder,
    presetTweetingOnly = false
  ) => {
    const matchingOrders = orders.filter(
      (o) => o.ticker.toUpperCase() === pos.ticker.toUpperCase() && (!o.derivativeType || o.derivativeType === 'spot')
    );
    const latestOrder = overrideOrder || matchingOrders[0];
    const initialSide: 'buy' | 'sell' = latestOrder?.side || 'buy';
    const initialShares = latestOrder?.shares ?? pos.shares ?? 1;

    setSharingPosition(pos);
    setShareSide(initialSide);
    setShareSharesInput(String(Number(initialShares.toFixed(4))));
    setShareToSocial(!presetTweetingOnly);
    setShareToTweeting(presetTweetingOnly);
    setShareAudienceMode('all');
    setSelectedFriendIds(friendsList.map((f) => f.uid));
    setShareNoteInput(
      `Shared my ${initialSide === 'buy' ? 'purchase' : 'sale'} of $${pos.ticker} on Final Equity Spot.`
    );
  };

  const handleToggleShareFriend = (uid: string) => {
    setSelectedFriendIds((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const handleConfirmShareTrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sharingPosition) return;
    if (!shareToSocial && !shareToTweeting) return;

    const targetFriends =
      shareAudienceMode === 'all'
        ? friendsList
        : friendsList.filter((f) => selectedFriendIds.includes(f.uid));
    if (shareToSocial && targetFriends.length === 0) return;

    const parsedShares = Math.max(0.0001, parseFloat(shareSharesInput) || sharingPosition.shares || 1);
    const unitPrice = sharingPosition.currentPriceUSD || sharingPosition.avgCostUSD || 1;
    const totalVal = Number((parsedShares * unitPrice).toFixed(2));
    const coinLabel = getSpotCoinLabel(sharingPosition.ticker);
    const isPersonal = sharingPosition.assetCategory === 'personal';

    const sharedLabel =
      shareAudienceMode === 'all' || targetFriends.length === friendsList.length
        ? 'All Friends'
        : targetFriends.map((f) => f.name.split(' ')[0]).join(', ');

    if (shareToSocial) {
      const newSocialTrade: SocialStockTrade = {
        id: `shared-trade-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        traderType: 'friend',
        user: {
          uid: currentUser?.uid || currentUser?.id || 'current-user',
          name: currentUser?.name || 'You',
          handle: (currentUser?.email ? currentUser.email.split('@')[0] : 'sovereign_trader').toLowerCase(),
          avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
          title: 'Sovereign Equity Holder',
          verified: true,
          isFriend: true,
          friendsCount: friendsList.length,
          winRate: '88.5%',
        },
        ticker: sharingPosition.ticker,
        stockName: sharingPosition.name,
        marketType: 'final',
        assetCategory: isPersonal ? 'personal' : 'business',
        side: shareSide,
        shares: Number(parsedShares.toFixed(4)),
        priceUSD: unitPrice,
        totalValueUSD: totalVal,
        timestamp: new Date().toISOString(),
        timestampAgo: 'Just now',
        commentary:
          shareNoteInput.trim() ||
          `Shared a ${shareSide.toUpperCase()} trade on $${sharingPosition.ticker} (${coinLabel}).`,
        settlementMethod: coinLabel,
        gainLossPercent: Number((sharingPosition.totalGainPercent || 0).toFixed(2)),
        isRealTimeNew: true,
        isSharedByCurrentUser: true,
        sharedWithFriendIds: targetFriends.map((f) => f.uid),
        sharedWithLabel: sharedLabel,
        finalCoinSymbol: coinLabel,
        instrumentCategory: 'equity',
        derivativeType: 'spot',
      };

      saveSharedSocialTrade(newSocialTrade);
      setSharedTrades(getStoredSharedSocialTrades());
    }

    if (shareToTweeting) {
      const activeUser = currentUser || getCurrentSession();
      const authorId = activeUser?.uid || activeUser?.id || 'current-user';
      const authorName = activeUser?.name || 'Sovereign Trader';
      const authorHandle = (
        activeUser?.id ||
        (activeUser?.email ? activeUser.email.split('@')[0] : '') ||
        'sovereign_trader'
      )
        .toLowerCase()
        .replace(/[^a-z0-9_]/g, '_');
      const authorAvatar =
        activeUser?.avatarUrl ||
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80';

      const tickerUpper = sharingPosition.ticker.toUpperCase();
      const baseNote =
        shareNoteInput.trim() ||
        `Shared my ${shareSide === 'buy' ? 'purchase' : 'sale'} of $${tickerUpper} on Final Equity Spot.`;
      const hasTicker = new RegExp(`\\$${tickerUpper}\\b`, 'i').test(baseNote);
      const tweetContent = hasTicker ? baseNote : `${baseNote} $${tickerUpper}`;

      createTweet({
        authorId,
        authorName,
        authorHandle,
        authorAvatar,
        content: tweetContent,
        extraHashtags: ['FinalEquity'],
        tradeReceipt: {
          instrumentCategory: 'equity',
          assetName: sharingPosition.name || tickerUpper,
          ticker: tickerUpper,
          side: shareSide,
          shares: Number(parsedShares.toFixed(4)),
          price: unitPrice,
          totalValue: totalVal,
          coinLabel,
          gainLossPercent: Number((sharingPosition.totalGainPercent || 0).toFixed(2)),
        },
      });
    }

    setSharingPosition(null);
    setShareToast(null);
    const noticeMsg =
      shareToSocial && shareToTweeting
        ? `Shared ${shareSide.toUpperCase()} ${Number(parsedShares.toFixed(4))} $${sharingPosition.ticker} to Social & Tweeting`
        : shareToTweeting
        ? `Posted ${shareSide.toUpperCase()} ${Number(parsedShares.toFixed(4))} $${sharingPosition.ticker} (${coinLabel}) to Tweeting`
        : `Shared ${shareSide.toUpperCase()} ${Number(parsedShares.toFixed(4))} $${sharingPosition.ticker} (${coinLabel}) with ${sharedLabel}`;

    if (shareToSocial && !shareToTweeting && onNavigateToSocial) {
      onNavigateToSocial(noticeMsg);
    } else {
      setShareToast({
        text: noticeMsg,
        sharedToSocial: shareToSocial,
        sharedToTweeting: shareToTweeting,
      });
      setTimeout(() => setShareToast(null), 5000);
    }
  };

  // Sub-tabs state: 'owned' | 'following' | 'my_ipos' | 'currencies' | 'coin_launchpad'
  const [currentSubTab, setCurrentSubTab] = useState<'owned' | 'following' | 'my_ipos' | 'currencies' | 'coin_launchpad'>(activeSubTab || 'owned');

  useEffect(() => {
    if (activeSubTab) {
      setCurrentSubTab(activeSubTab);
    }
  }, [activeSubTab]);

  const handleSubTabChange = (tab: 'owned' | 'following' | 'my_ipos' | 'currencies' | 'coin_launchpad') => {
    setCurrentSubTab(tab);
    if (onSelectSubTab) onSelectSubTab(tab);
    onSearchQueryChange('');
  };

  const PERSONAL_EQUITY_TICKERS = new Set(['ALEX', 'ELEN', 'STERL', 'STRL', 'SATOSHI', 'VANC', 'SLIN', 'KHAL']);
  const isPersonalEquityStock = (stk: StockItem) =>
    stk.assetCategory === 'personal' ||
    stk.issuanceType === 'personal' ||
    PERSONAL_EQUITY_TICKERS.has((stk.ticker || '').toUpperCase());

  // Followed stocks calculation
  const followedStocksList = useMemo(() => {
    const base = filteredFollowedStocks
      ? filteredFollowedStocks
      : stocks.filter((s) => {
          const isWatched = watchlist.some((w) => w.toUpperCase() === s.ticker.toUpperCase());
          if (!isWatched) return false;
          if (selectedMarketFilter && s.marketType !== selectedMarketFilter) return false;
          if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase().replace(/^\$/, '');
            return s.ticker.toLowerCase().includes(q) || s.name.toLowerCase().includes(q) || s.sector.toLowerCase().includes(q);
          }
          return true;
        });

    if (favoritesCategoryFilter === 'all') return base;
    return base.filter((stk) =>
      favoritesCategoryFilter === 'personal' ? isPersonalEquityStock(stk) : !isPersonalEquityStock(stk)
    );
  }, [stocks, watchlist, selectedMarketFilter, searchQuery, filteredFollowedStocks, favoritesCategoryFilter]);

  // Active Equity tickers currently held (so History strictly excludes active stocks and only shows done ones)
  const activeEquityTickers = useMemo(() => {
    const set = new Set<string>();
    enrichedPositions.forEach((p) => {
      if (!p.isSpotStock && p.assetCategory !== 'spot' && p.shares > 0) {
        set.add(p.ticker.toUpperCase());
      }
    });
    return set;
  }, [enrichedPositions]);

  // Strictly filter orders to done/closed spot transactions (no active open orders, no active equity holdings, no derivative contracts)
  const spotHistoryOrders = useMemo(() => {
    return orders.filter((o) => {
      if (o.derivativeType && o.derivativeType !== 'spot') return false;
      if (o.status === 'open') return false;
      if (o.side === 'buy' && activeEquityTickers.has((o.ticker || '').toUpperCase())) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase().replace(/^\$/, '');
        return (
          (o.ticker || '').toLowerCase().includes(q) ||
          (o.stockName || '').toLowerCase().includes(q) ||
          (o.issuerName || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [orders, activeEquityTickers, searchQuery]);

  const formatTransactionDateTime = (ord: StockOrder) => {
    let dateObj: Date | null = null;
    if (ord.dateIso) {
      const p = new Date(ord.dateIso);
      if (!isNaN(p.getTime())) dateObj = p;
    }
    if (!dateObj && ord.timestamp) {
      const p = new Date(ord.timestamp);
      if (!isNaN(p.getTime())) dateObj = p;
    }
    if (!dateObj && typeof ord.timestamp === 'string' && ord.timestamp.includes(':')) {
      return {
        date: 'Aug 20, 2026',
        time: ord.timestamp,
        full: `Aug 20, 2026, ${ord.timestamp}`
      };
    }
    const finalD = dateObj || new Date();
    return {
      date: finalD.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      time: finalD.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true }),
      full: `${finalD.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}, ${finalD.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true })}`
    };
  };

  // Position ownership map for quick lookup
  const ownedPositionsMap = useMemo(() => {
    const map = new Map<string, EnrichedStockPosition>();
    enrichedPositions.forEach((p) => map.set(p.ticker.toUpperCase(), p));
    return map;
  }, [enrichedPositions]);

  // Filtered positions based on market filter, asset category, and search query
  const filteredPositions = enrichedPositions.filter((p) => {
    // Strict Guard: Stocks bought on spot must NEVER appear in Equity! Equity is ONLY for personal and business stocks!
    if (p.isSpotStock || p.assetCategory === 'spot' || (p as any).isEquity === false) {
      return false;
    }
    if (selectedMarketFilter && p.marketType !== selectedMarketFilter) {
      return false;
    }
    if (assetCategoryFilter !== 'all' && p.assetCategory !== assetCategoryFilter) {
      return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.trim().toLowerCase().replace(/^\$/, '');
    
    // Check coin keywords and market types
    if (q === 'fnl' || q === 'final') {
      if (p.marketType === 'final' || p.settlementMethod.toLowerCase().includes('final')) return true;
    }
    if (q === 'usdc' || q === 'usdt' || q === 'stable' || q === 'stablecoin') {
      if (p.marketType === 'stable' || p.settlementMethod.toLowerCase().includes('stable') || p.settlementMethod.toLowerCase().includes('usdc')) return true;
    }
    if (q === 'usd' || q === 'fiat' || q === 'dollar') {
      if (p.marketType === 'fiat' || p.settlementMethod.toLowerCase().includes('fiat') || p.settlementMethod.toLowerCase().includes('usd')) return true;
    }
    if (q === 'btc' || q === 'crypto' || q === 'bitcoin' || q === 'sol' || q === 'eth') {
      if (p.marketType === 'crypto' || p.settlementMethod.toLowerCase().includes('crypto') || p.settlementMethod.toLowerCase().includes('btc')) return true;
    }
    if (q === 'personal' || q === 'sovereign' || q === 'individual') {
      if (p.assetCategory === 'personal') return true;
    }
    if (q === 'business' || q === 'corporate' || q === 'company' || q === 'corp') {
      if (p.assetCategory === 'business') return true;
    }

    return (
      p.ticker.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.sector.toLowerCase().includes(q) ||
      (p.subSector && p.subSector.toLowerCase().includes(q)) ||
      p.assetCategory.toLowerCase().includes(q) ||
      (p.issuerName && p.issuerName.toLowerCase().includes(q)) ||
      (p.issuerHandle && p.issuerHandle.toLowerCase().includes(q)) ||
      (p.settlementMethod && p.settlementMethod.toLowerCase().includes(q))
    );
  });

  const getMarketBadge = (marketType?: StockMarketWay | null) => {
    switch (marketType) {
      case 'final':
        return {
          label: 'Final Stocks',
          shortLabel: 'Final',
          coin: 'Final Coins ($AFNL)',
          icon: Zap,
          bg: 'bg-amber-500/10 text-amber-900 border-amber-500/30',
          dot: 'bg-amber-500'
        };
      case 'stable':
        return {
          label: 'Stable Stocks',
          shortLabel: 'Stable',
          coin: 'Stablecoins ($USDC)',
          icon: ShieldCheck,
          bg: 'bg-emerald-500/10 text-emerald-900 border-emerald-500/30',
          dot: 'bg-emerald-500'
        };
      case 'crypto':
        return {
          label: 'Crypto Stocks',
          shortLabel: 'Crypto',
          coin: 'Cryptocurrency ($BTC)',
          icon: Coins,
          bg: 'bg-purple-500/10 text-purple-900 border-purple-500/30',
          dot: 'bg-purple-500'
        };
      case 'fiat':
        return {
          label: 'Fiat Stocks',
          shortLabel: 'Fiat',
          coin: 'Fiat USD ($USD)',
          icon: Building2,
          bg: 'bg-indigo-500/10 text-indigo-900 border-indigo-500/30',
          dot: 'bg-indigo-500'
        };
      default:
        return {
          label: 'All Markets',
          shortLabel: 'All',
          coin: 'All Settlement Currencies',
          icon: Layers,
          bg: 'bg-slate-100 text-slate-800 border-slate-200',
          dot: 'bg-slate-500'
        };
    }
  };

  const getFinalCurrencyLabel = (stk: StockItem): string => {
    const t = (stk.ticker || '').toUpperCase().trim();
    const cleanIssuance = stk.issuanceCoinSymbol?.replace(/^\$/, '').replace(/-FNL$/i, '').trim();
    if (stk.marketType === 'stable') return `$${cleanIssuance || 'USDC'}`;
    if (stk.marketType === 'crypto') return `$${cleanIssuance || 'BTC'}`;
    if (stk.marketType === 'fiat' || stk.marketType === 'global') return `$${cleanIssuance || 'USD'}`;
    if (cleanIssuance && cleanIssuance !== 'AFNL') return `$${cleanIssuance}`;
    if (t === 'AFNL-EQ') return '$AFNL';
    if (t === 'GLD' || t === 'GLD-STBL') return '$GLD';
    return `$${t.replace(/-FNL$/i, '')}`;
  };

  const getMarketStats = (marketType: StockMarketWay) => {
    const mPositions = enrichedPositions.filter((p) => p.marketType === marketType);
    const holdingsCount = mPositions.length;
    const costBasis = mPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0);
    const gainUSD = mPositions.reduce((s, p) => s + p.totalGainUSD, 0);
    const totalVal = mPositions.reduce((s, p) => s + p.totalValueUSD, 0);

    const holdingsGainPct = costBasis > 0
      ? (gainUSD / costBasis) * 100
      : (mPositions.length > 0 ? mPositions.reduce((s, p) => s + p.totalGainPercent, 0) / mPositions.length : null);

    const mStocks = stocks.filter((s) => s.marketType === marketType);
    const marketAvg = mStocks.length > 0
      ? mStocks.reduce((s, stk) => s + (stk.changePercent || 0), 0) / mStocks.length
      : 0;

    return {
      holdingsCount,
      hasHoldings: holdingsCount > 0,
      growthAvg: holdingsGainPct !== null ? holdingsGainPct : marketAvg,
      isHoldingsGrowth: holdingsGainPct !== null,
      marketAvg,
      totalVal,
    };
  };

  const favoriteGrowthAvg = useMemo(() => {
    if (followedStocksList.length > 0) {
      return followedStocksList.reduce((s, stk) => s + (stk.changePercent || 0), 0) / followedStocksList.length;
    }
    return 0;
  }, [followedStocksList]);

  const finalStats = getMarketStats('final');
  const stableStats = getMarketStats('stable');
  const fiatStats = getMarketStats('fiat');
  const cryptoStats = getMarketStats('crypto');

  const activeSpotCount = enrichedPositions.filter((p) => !p.isSpotStock && p.assetCategory !== 'spot').length;

  return (
    <div className="space-y-4 text-center w-full max-w-full min-w-0">
      {/* 1. Centered Header & Filter Bar (Matches Derivatives Layout) */}
      <div className="w-full min-w-0 rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-4 text-center">
        <div className="flex flex-col items-center justify-center gap-2.5 text-center">
          <div className="w-11 h-11 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center justify-center shrink-0">
            <Briefcase className="w-5 h-5 text-emerald-600" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-600 font-bold block">
              Sovereign People &amp; Business Equity
            </span>
            <h2 className="font-serif text-2xl font-bold text-slate-900 flex items-center justify-center gap-2">
              <span>Equity Portfolio</span>
            </h2>
          </div>

          <div className="flex items-center justify-center gap-2">
            <span className="text-xs font-mono px-3 py-1 rounded-full bg-slate-100 text-slate-700 font-bold">
              {currentSubTab === 'owned' && showHistory
                ? `${spotHistoryOrders.length} History ${spotHistoryOrders.length === 1 ? 'Record' : 'Records'}`
                : currentSubTab === 'owned'
                ? `${activeSpotCount} ${activeSpotCount === 1 ? 'Equity' : 'Equities'}`
                : currentSubTab === 'following'
                ? `${followedStocksList.length} ${followedStocksList.length === 1 ? 'Favorite' : 'Favorites'}`
                : currentSubTab === 'my_ipos'
                ? `${ipos.length} ${ipos.length === 1 ? 'IPO' : 'IPOs'}`
                : 'Final Currencies'}
            </span>
          </div>
        </div>

        {/* Centered Navigation & Filter Buttons */}
        <div className="flex flex-col items-center justify-center w-full gap-2.5 pt-3 border-t border-slate-100">
          {/* Primary Equity Sections */}
          <div className="flex flex-row items-center justify-center gap-2 w-full flex-wrap">
            <button
              type="button"
              id="equity-subtab-owned"
              onClick={() => handleSubTabChange('owned')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                currentSubTab === 'owned'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-emerald-50 text-emerald-950 hover:bg-emerald-100 border border-emerald-200/60'
              }`}
            >
              Spot
            </button>
            <button
              type="button"
              id="equity-subtab-following"
              onClick={() => handleSubTabChange('following')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                currentSubTab === 'following'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Favorites
            </button>
            <button
              type="button"
              id="equity-subtab-myipos"
              onClick={() => handleSubTabChange('my_ipos')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                currentSubTab === 'my_ipos'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              My IPOs &amp; Issues
            </button>
            <button
              type="button"
              id="equity-subtab-currencies"
              onClick={() => handleSubTabChange('currencies')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                currentSubTab === 'currencies'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Currencies
            </button>
          </div>

          {/* Spot Category & History Filters */}
          {currentSubTab === 'owned' && (
            <div className="flex flex-col items-center justify-center w-full gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  onSelectAssetCategoryFilter('all');
                  setShowHistory(false);
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  assetCategoryFilter === 'all' && !showHistory
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All Final Assets
              </button>
              <div className="flex flex-row items-center justify-center gap-2 w-full flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    onSelectAssetCategoryFilter('business');
                    setShowHistory(false);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    assetCategoryFilter === 'business' && !showHistory
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-blue-50 text-blue-900 hover:bg-blue-100 border border-blue-200/60'
                  }`}
                >
                  Businesses
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSelectAssetCategoryFilter('personal');
                    setShowHistory(false);
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    assetCategoryFilter === 'personal' && !showHistory
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-purple-50 text-purple-900 hover:bg-purple-100 border border-purple-200/60'
                  }`}
                >
                  Personal
                </button>
                <button
                  type="button"
                  onClick={() => setShowHistory(true)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    showHistory
                      ? 'bg-amber-500 text-slate-950 shadow-2xs font-extrabold'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>History</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 2. SUB-TAB VIEW CONTENT */}
      {/* ================= VIEW 1: SPOT (OWNED EQUITY + HISTORY) ================= */}
      {currentSubTab === 'owned' && (
        <div className="w-full min-w-0 rounded-3xl border border-slate-200 bg-white p-4 sm:p-5 shadow-2xs space-y-4 text-center">
          <div className="flex flex-col items-center justify-center gap-3 pb-3 border-b border-slate-100">
            <h3 className="font-serif text-base font-bold text-slate-900 flex items-center justify-center gap-2">
              {showHistory ? (
                <>
                  <Clock className="w-4 h-4 text-amber-500" />
                  <span>Spot Trading History</span>
                </>
              ) : (
                <>
                  <Briefcase className="w-4 h-4 text-emerald-600" />
                  <span>Spot Equity Holdings</span>
                </>
              )}
            </h3>

            {/* Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchQueryChange(e.target.value)}
                placeholder={showHistory ? 'Search history, ticker, issuer...' : 'Search ticker, equity, issuer...'}
                className="w-full pl-9 pr-8 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 font-mono text-center"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchQueryChange('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {showHistory ? (
            spotHistoryOrders.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mx-auto shadow-2xs">
                  <Clock className="w-7 h-7" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">No trading history recorded yet</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Every stock you buy or sell will appear here with share options.
                </p>
              </div>
            ) : (
              <div className="w-full overflow-x-auto touch-pan-x">
                <table className="w-full text-center border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                      <th className="py-3 px-3 text-center">Date &amp; Time</th>
                      <th className="py-3 px-3 text-center">Asset &amp; Ticker</th>
                      <th className="py-3 px-3 text-center">Side</th>
                      <th className="py-3 px-3 text-center">Shares</th>
                      <th className="py-3 px-3 text-center">Price</th>
                      <th className="py-3 px-3 text-center">Total Value</th>
                      <th className="py-3 px-3 text-center">Share / Unshare</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {spotHistoryOrders.map((ord, idx) => {
                      const isBuy = ord.side === 'buy';
                      const coinLabel = getSpotCoinLabel(ord.ticker);
                      const dt = formatTransactionDateTime(ord);
                      const isShared = sharedTrades.some(
                        (t) => t.ticker.toUpperCase() === ord.ticker.toUpperCase() && t.shares === ord.shares && t.side === ord.side
                      );
                      return (
                        <tr key={`${ord.id || idx}`} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-3 text-center font-mono text-xs">
                            <div className="font-bold text-slate-800">{dt.date}</div>
                            <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3 text-slate-400" />
                              <span>{dt.time}</span>
                            </div>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <div 
                              onClick={() => {
                                const foundStock = stocks.find(s => s.ticker.toUpperCase() === ord.ticker.toUpperCase());
                                if (foundStock && onSelectStock) onSelectStock(foundStock);
                                else if (onOpenTradeModal) onOpenTradeModal(ord.ticker, 'buy');
                              }}
                              className="flex items-center justify-center gap-2.5 group/asset cursor-pointer"
                              title={`View stock page for $${ord.ticker}`}
                            >
                              <div className={`w-8 h-8 rounded-xl group-hover/asset:bg-emerald-600 transition-colors flex items-center justify-center font-bold text-xs shrink-0 ${
                                ord.isPersonalStock 
                                  ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                                  : 'bg-slate-900 text-white'
                              }`}>
                                {ord.ticker.slice(0, 3)}
                              </div>
                              <div className="text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  <span className="font-bold text-slate-900 group-hover/asset:text-emerald-600 font-mono transition-colors">${ord.ticker}</span>
                                  {ord.isPersonalStock ? (
                                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-100 text-purple-700 border border-purple-200">
                                      Personal
                                    </span>
                                  ) : (
                                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-blue-100 text-blue-700 border border-blue-200">
                                      Business
                                    </span>
                                  )}
                                </div>
                                <span className="text-[11px] text-slate-700 font-medium truncate block max-w-[150px] sm:max-w-[200px] group-hover/asset:underline mx-auto">
                                  {ord.stockName}
                                </span>
                                {ord.issuerName && (
                                  <span className="text-[10px] text-slate-400 font-mono flex items-center justify-center gap-1">
                                    By {ord.issuerName}
                                  </span>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${isBuy ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                              {ord.side.toUpperCase()}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-center font-mono font-bold">
                            {ord.shares.toLocaleString()}
                          </td>
                          <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                            {(ord.price || 0).toFixed(2)} {coinLabel}
                          </td>
                          <td className="py-3 px-3 text-center font-mono font-bold">
                            {(ord.totalUSD || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })} {coinLabel}
                          </td>
                          <td className="py-3 px-2.5 text-center">
                            <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                              {isShared ? (
                                <button
                                  type="button"
                                  onClick={() => handleUnshareTicker(ord.ticker)}
                                  className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-rose-600 text-white font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                                >
                                  <Check className="w-3 h-3" />
                                  <span>Unshare</span>
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const posFromOrder: EnrichedStockPosition = {
                                      ticker: ord.ticker,
                                      name: ord.stockName || ord.ticker,
                                      shares: ord.shares,
                                      avgCostUSD: ord.price || 1,
                                      currentPriceUSD: ord.price || 1,
                                      totalValueUSD: ord.totalUSD || ord.shares * (ord.price || 1),
                                      totalGainUSD: ord.totalGainUSD || 0,
                                      totalGainPercent: ord.totalGainPercent || 0,
                                      marketType: 'final',
                                      settlementMethod: coinLabel,
                                      sector: ord.sector || 'Sovereign Reserves',
                                      assetCategory: ord.isPersonalStock ? 'personal' : 'business',
                                      isSpotStock: false,
                                      isEquity: true,
                                      issuerName: ord.issuerName,
                                    };
                                    handleOpenShareModal(posFromOrder, ord, false);
                                  }}
                                  className="px-2.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                                  title="Share to Social"
                                >
                                  <Share2 className="w-3 h-3" />
                                  <span>Share</span>
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  const posFromOrder: EnrichedStockPosition = {
                                    ticker: ord.ticker,
                                    name: ord.stockName || ord.ticker,
                                    shares: ord.shares,
                                    avgCostUSD: ord.price || 1,
                                    currentPriceUSD: ord.price || 1,
                                    totalValueUSD: ord.totalUSD || ord.shares * (ord.price || 1),
                                    totalGainUSD: ord.totalGainUSD || 0,
                                    totalGainPercent: ord.totalGainPercent || 0,
                                    marketType: 'final',
                                    settlementMethod: coinLabel,
                                    sector: ord.sector || 'Sovereign Reserves',
                                    assetCategory: ord.isPersonalStock ? 'personal' : 'business',
                                    isSpotStock: false,
                                    isEquity: true,
                                    issuerName: ord.issuerName,
                                  };
                                  handleOpenShareModal(posFromOrder, ord, true);
                                }}
                                className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                                title="Share this trade on Tweeting"
                              >
                                <Twitter className="w-3 h-3 -scale-x-100 -rotate-12" />
                                <span>Tweet</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )
          ) : filteredPositions.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-2xs">
                <Briefcase className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                {searchQuery
                  ? `No owned equity positions match "${searchQuery}"`
                  : selectedMarketFilter
                  ? `No owned equity found in ${getMarketBadge(selectedMarketFilter).label}`
                  : assetCategoryFilter !== 'all'
                  ? `No owned ${assetCategoryFilter} equities found`
                  : 'No equity positions owned yet'}
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                You haven't bought any shares in this category yet. Explore the 4 Coin Stock Markets or Sovereign IPOs to purchase equities.
              </p>
              <div className="flex items-center justify-center gap-3 pt-2">
                {onOpenStockMarket && (
                  <button
                    type="button"
                    onClick={() => onOpenStockMarket(selectedMarketFilter || 'all')}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Browse Stock Markets</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => handleSubTabChange('following')}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                  <span>View Followed Equities</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="w-full overflow-x-auto touch-pan-x">
              <table className="w-full text-center border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                    <th className="py-2.5 px-2.5 text-left">Asset &amp; Issuer</th>
                    <th className="py-2.5 px-2.5 text-center hidden xl:table-cell">Type &amp; Category</th>
                    <th className="py-2.5 px-2.5 text-center">Coin</th>
                    <th className="py-2.5 px-2.5 text-center">Shares</th>
                    <th className="py-2.5 px-2.5 text-center hidden lg:table-cell">Avg Cost</th>
                    <th className="py-2.5 px-2.5 text-center">Market Price</th>
                    <th className="py-2.5 px-2.5 text-center">Total Value</th>
                    <th className="py-2.5 px-2.5 text-center">Total Return</th>
                    <th className="py-2.5 px-2.5 text-center">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredPositions.map((pos, idx) => {
                    const isPersonal = pos.assetCategory === 'personal';
                    const isPositive = pos.totalGainUSD >= 0;
                    const buildStockItem = (): StockItem => {
                      const found = stocks.find(s => s.ticker === pos.ticker);
                      if (found) {
                        return {
                          ...found,
                          issuanceType: found.issuanceType || (isPersonal ? 'personal' : 'business'),
                          assetCategory: found.assetCategory || (isPersonal ? 'personal' : 'business'),
                          issuerName: found.issuerName || pos.issuerName,
                        };
                      }
                      return {
                        ticker: pos.ticker,
                        name: pos.name,
                        price: pos.currentPriceUSD,
                        changeUSD: 0,
                        changePercent: pos.totalGainPercent,
                        marketCap: 'N/A',
                        volume: 'N/A',
                        avgVolume: 'N/A',
                        sector: pos.sector as any,
                        marketType: pos.marketType,
                        settlementMethod: pos.settlementMethod,
                        high24h: pos.currentPriceUSD * 1.02,
                        low24h: pos.currentPriceUSD * 0.98,
                        openPrice: pos.avgCostUSD || pos.currentPriceUSD,
                        prevClose: pos.avgCostUSD || pos.currentPriceUSD,
                        peRatio: 0,
                        eps: 0,
                        dividendYield: '0.00%',
                        beta: 1.0,
                        fiftyTwoWeekHigh: pos.currentPriceUSD * 1.2,
                        fiftyTwoWeekLow: pos.currentPriceUSD * 0.8,
                        description: `${pos.name} (${pos.ticker}) sovereign equity.`,
                        exchange: 'SOVEREIGN_NODE',
                        analystRating: 'Buy',
                        analystTargetUSD: pos.currentPriceUSD * 1.1,
                        analystCount: 1,
                        sparkline: [pos.currentPriceUSD, pos.currentPriceUSD],
                        history: {
                          '1D': [{ time: 'Open', price: pos.currentPriceUSD, volume: 0 }, { time: 'Now', price: pos.currentPriceUSD, volume: 0 }],
                          '1W': [{ time: 'Mon', price: pos.currentPriceUSD, volume: 0 }, { time: 'Now', price: pos.currentPriceUSD, volume: 0 }],
                          '1M': [{ time: 'Start', price: pos.currentPriceUSD, volume: 0 }, { time: 'Now', price: pos.currentPriceUSD, volume: 0 }],
                          '1Y': [{ time: 'Start', price: pos.currentPriceUSD, volume: 0 }, { time: 'Now', price: pos.currentPriceUSD, volume: 0 }],
                          '5Y': [{ time: 'Start', price: pos.currentPriceUSD, volume: 0 }, { time: 'Now', price: pos.currentPriceUSD, volume: 0 }],
                        },
                        issuanceType: isPersonal ? 'personal' : 'business',
                        assetCategory: isPersonal ? 'personal' : 'business',
                        issuerName: pos.issuerName,
                      };
                    };

                    return (
                      <tr key={`${pos.ticker}-${pos.marketType}-${idx}`} className="hover:bg-slate-50/80 transition-colors group">
                        {/* Asset & Issuer */}
                        <td className="py-2.5 px-2.5 text-left">
                          <div 
                            onClick={() => {
                              if (onSelectStock) {
                                onSelectStock(buildStockItem());
                              }
                            }}
                            className="flex items-center justify-start gap-2.5 group/asset cursor-pointer"
                            title={`View stock page for $${pos.ticker}`}
                          >
                            <div className={`w-8 h-8 rounded-xl group-hover/asset:bg-emerald-600 transition-colors flex items-center justify-center font-bold text-xs shrink-0 ${
                              isPersonal 
                                ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                                : 'bg-slate-900 text-white'
                            }`}>
                              {pos.ticker.slice(0, 3)}
                            </div>
                            <div className="text-left min-w-0">
                              <div className="flex items-center justify-start gap-1.5">
                                <span className="font-bold text-slate-900 group-hover/asset:text-emerald-600 font-mono transition-colors">${pos.ticker}</span>
                                {isPersonal ? (
                                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-100 text-purple-700 border border-purple-200">
                                    Personal
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-blue-100 text-blue-700 border border-blue-200">
                                    Business
                                  </span>
                                )}
                              </div>
                              <span className="text-[11px] text-slate-500 truncate block max-w-[150px] sm:max-w-[200px] group-hover/asset:underline">
                                {pos.name}
                              </span>
                              {pos.issuerName && (
                                <span className="text-[10px] text-slate-400 font-mono flex items-center justify-start gap-1">
                                  By {pos.issuerName}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* Type & Category */}
                        <td className="py-2.5 px-2.5 text-center hidden xl:table-cell">
                          <div className="space-y-0.5 flex flex-col items-center">
                            <span className="text-xs text-slate-800 font-mono font-medium">
                              {pos.sector}
                            </span>
                          </div>
                        </td>

                        {/* Coin Sticker */}
                        <td className="py-2.5 px-2.5 text-center">
                          <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold px-2 py-1 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs whitespace-nowrap">
                            <Coins className="w-3 h-3 text-amber-600 shrink-0" />
                            <span>{getSpotCoinLabel(pos.ticker)}</span>
                          </span>
                        </td>

                        {/* Shares */}
                        <td className="py-2.5 px-2.5 text-center font-mono font-bold text-slate-900">
                          {Number((pos.shares || 0).toFixed(4)).toLocaleString(undefined, { maximumFractionDigits: 4 })}
                        </td>

                        {/* Avg Cost */}
                        <td className="py-2.5 px-2.5 text-center font-mono text-slate-600 hidden lg:table-cell">
                          {pos.avgCostUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* Market Price */}
                        <td className="py-2.5 px-2.5 text-center font-mono font-bold text-slate-900 whitespace-nowrap">
                          {pos.currentPriceUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {getSpotCoinLabel(pos.ticker)}
                        </td>

                        {/* Total Value */}
                        <td className="py-2.5 px-2.5 text-center font-mono font-bold text-slate-900 whitespace-nowrap">
                          {pos.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {getSpotCoinLabel(pos.ticker)}
                        </td>

                        {/* Total Return */}
                        <td className="py-2.5 px-2.5 text-center">
                          <div className="font-mono text-center whitespace-nowrap">
                            <span className={`font-bold block ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {isPositive ? '' : '-'}{Math.abs(pos.totalGainUSD).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </span>
                            <span className={`text-[10px] block ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                              ({isPositive ? '+' : ''}{pos.totalGainPercent.toFixed(2)}%)
                            </span>
                          </div>
                        </td>

                        {/* Quick Actions */}
                        <td className="py-2.5 px-2.5 text-center">
                          <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => onOpenTradeModal(pos.ticker, 'buy')}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                              title="Buy or sell shares / contracts"
                            >
                              <ArrowLeftRight className="w-3 h-3" />
                              <span>Buy / Sell</span>
                            </button>
                            {sharedTrades.some((t) => t.ticker.toUpperCase() === pos.ticker.toUpperCase()) ? (
                              <button
                                type="button"
                                onClick={() => handleUnshareTicker(pos.ticker)}
                                className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-rose-600 text-white font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                                title="Unshare trade from friends' Social feed"
                              >
                                <Check className="w-3 h-3" />
                                <span>Unshare</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleOpenShareModal(pos, undefined, false)}
                                className="px-2.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                                title="Share trade to Social or Tweeting"
                              >
                                <Share2 className="w-3 h-3" />
                                <span>Share</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleOpenShareModal(pos, undefined, true)}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                              title="Share this equity position on Tweeting"
                            >
                              <Twitter className="w-3 h-3 -scale-x-100 -rotate-12" />
                              <span>Tweet</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ================= VIEW 2: FAVORITE ================= */}
      {currentSubTab === 'following' && (
        <div className="w-full min-w-0 rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-5 text-center">
          <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-slate-100 text-center">
            <div className="flex flex-col items-center gap-1">
              <h2 className="font-serif text-lg font-bold text-slate-900 flex items-center justify-center gap-2 flex-wrap">
                <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
                <span>Favorite Equities</span>
                <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {followedStocksList.length} {followedStocksList.length === 1 ? 'Equity' : 'Equities'}
                </span>
              </h2>
              <p className="text-xs text-slate-500 max-w-lg mx-auto">
                Personal stock and business stock IPOs you are monitoring with real-time Final currency quotes and instant execution.
              </p>
            </div>

            {/* Favorites Category Filter + Search */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 w-full">
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setFavoritesCategoryFilter('all')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    favoritesCategoryFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All
                </button>
                <button
                  type="button"
                  onClick={() => setFavoritesCategoryFilter('business')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                    favoritesCategoryFilter === 'business'
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Building className="w-3 h-3" />
                  <span>Businesses</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFavoritesCategoryFilter('personal')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                    favoritesCategoryFilter === 'personal'
                      ? 'bg-purple-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <User className="w-3 h-3" />
                  <span>Personal</span>
                </button>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => onSearchQueryChange(e.target.value)}
                  placeholder="Search followed equities..."
                  className="w-full pl-9 pr-8 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-amber-500 font-mono text-center"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => onSearchQueryChange('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Followed Equities Table */}
          {followedStocksList.length === 0 ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center mx-auto shadow-2xs">
                <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-800">
                  {searchQuery
                    ? `No followed equities match "${searchQuery}"`
                    : selectedMarketFilter
                    ? `You are not following any ${getMarketBadge(selectedMarketFilter).label} yet`
                    : 'You haven\'t followed or starred any equities yet'}
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Click the star icon next to any personal sovereign stock or corporate equity to monitor price action, dividends, and trade signals.
                </p>
              </div>

              {/* Recommended Popular Equities to Follow */}
              <div className="pt-4 max-w-xl mx-auto">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono block mb-2">
                  Popular Equities You May Be Interested In
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {stocks.slice(0, 6).map((stock, idx) => {
                    const isWatched = watchlist.some((w) => w.toUpperCase() === stock.ticker.toUpperCase());
                    const isPersonal = isPersonalEquityStock(stock);

                    return (
                      <div 
                        key={`rec-${stock.ticker}-${idx}`}
                        className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 hover:bg-slate-100/80 transition-all flex items-center justify-between text-left"
                      >
                        <div className="min-w-0 pr-2">
                          <div className="flex items-center gap-1">
                            <span className="font-mono font-bold text-xs text-slate-900">${stock.ticker}</span>
                            <span className={`text-[8px] font-mono px-1 py-0.2 rounded ${
                              isPersonal ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                            }`}>
                              {isPersonal ? 'Personal' : 'Business'}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-500 truncate block font-mono">
                            {(stock.price ?? 0).toFixed(2)} ({(stock.changePercent ?? 0) >= 0 ? '+' : ''}{(stock.changePercent ?? 0).toFixed(1)}%)
                          </span>
                        </div>

                        {onToggleWatchlist && (
                          <button
                            type="button"
                            onClick={() => onToggleWatchlist(stock.ticker)}
                            title={isWatched ? 'Remove from Favorites' : 'Add to Favorites'}
                            className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                              isWatched 
                                ? 'bg-amber-100 border-amber-300 text-amber-700' 
                                : 'bg-white border-slate-200 text-slate-400 hover:text-amber-500 hover:border-amber-300'
                            }`}
                          >
                            <Star className={`w-3.5 h-3.5 ${isWatched ? 'fill-amber-400 text-amber-500' : ''}`} />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {onOpenStockMarket && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => onOpenStockMarket('all')}
                    className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Browse All Active Market Equities</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full overflow-x-auto touch-pan-x">
              <table className="w-full text-center border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                    <th className="py-3 px-3 text-center">Follow</th>
                    <th className="py-3 px-3 text-center">Asset &amp; Category</th>
                    <th className="py-3 px-3 text-center">Final Currency</th>
                    <th className="py-3 px-3 text-center">Unit Price</th>
                    <th className="py-3 px-3 text-center">24h Change</th>
                    <th className="py-3 px-3 text-center hidden sm:table-cell">Market Cap / Vol</th>
                    <th className="py-3 px-3 text-center">My Position</th>
                    <th className="py-3 px-3 text-center">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {followedStocksList.map((stk, idx) => {
                    const isPositive = (stk.changePercent ?? 0) >= 0;
                    const isPersonal = isPersonalEquityStock(stk);
                    const ownedPos = ownedPositionsMap.get(stk.ticker.toUpperCase());

                    return (
                      <tr key={`followed-${stk.ticker}-${idx}`} className="hover:bg-slate-50/80 transition-colors group">
                        {/* Star Button */}
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center">
                            {onToggleWatchlist ? (
                              <button
                                type="button"
                                onClick={() => onToggleWatchlist(stk.ticker)}
                                title="Remove from followed equities"
                                className="p-1 rounded-md text-amber-500 hover:bg-amber-50 transition-colors cursor-pointer"
                              >
                                <Star className="w-4 h-4 fill-amber-400" />
                              </button>
                            ) : (
                              <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                            )}
                          </div>
                        </td>

                        {/* Asset Info */}
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center gap-2.5">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                              isPersonal ? 'bg-purple-100 text-purple-800 border border-purple-200' : 'bg-slate-900 text-white'
                            }`}>
                              {stk.ticker.slice(0, 3)}
                            </div>
                            <div className="text-center">
                              <div className="flex items-center justify-center gap-1.5">
                                <span 
                                  onClick={() => onSelectStock && onSelectStock(stk)}
                                  className="font-bold text-slate-900 font-mono hover:text-amber-800 cursor-pointer"
                                >
                                  ${stk.ticker}
                                </span>
                                <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                                  isPersonal ? 'bg-purple-50 text-purple-700 border border-purple-200' : 'bg-blue-50 text-blue-700 border border-blue-200'
                                }`}>
                                  {isPersonal ? 'Personal' : 'Business'}
                                </span>
                              </div>
                              <span className="text-[11px] text-slate-500 truncate block max-w-[140px] sm:max-w-[200px] mx-auto">
                                {stk.name}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* Final Currency Used */}
                        <td className="py-3 px-3 text-center">
                          <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs">
                            <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                            <span>{getFinalCurrencyLabel(stk)}</span>
                          </span>
                        </td>

                        {/* Unit Price */}
                        <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                          {(stk.price ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* 24h Change */}
                        <td className="py-3 px-3 text-center font-mono">
                          <span className={`font-bold inline-flex items-center gap-0.5 ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            <span>{isPositive ? '+' : ''}{(stk.changePercent ?? 0).toFixed(2)}%</span>
                          </span>
                        </td>

                        {/* Market Cap / Vol */}
                        <td className="py-3 px-3 text-center font-mono text-slate-500 hidden sm:table-cell">
                          <span className="block font-bold text-slate-700">{stk.marketCap || 'N/A'}</span>
                          <span className="text-[10px] text-slate-400 block">{stk.volume || 'N/A'}</span>
                        </td>

                        {/* My Position */}
                        <td className="py-3 px-3 text-center font-mono">
                          {ownedPos ? (
                            <div>
                              <span className="font-bold text-emerald-700 block">
                                {Number((ownedPos.shares || 0).toFixed(4)).toLocaleString(undefined, { maximumFractionDigits: 4 })} shs
                              </span>
                              <span className="text-[10px] text-slate-400 block">
                                {(ownedPos.totalValueUSD ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </span>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-sans">Not owned</span>
                          )}
                        </td>

                        {/* Quick Actions */}
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => onOpenTradeModal(stk, 'buy')}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                              title="Buy or sell shares / contracts"
                            >
                              <ArrowLeftRight className="w-3 h-3" />
                              <span>Buy / Sell</span>
                            </button>
                            {onSelectStock && (
                              <button
                                type="button"
                                onClick={() => onSelectStock(stk)}
                                title="View stock information"
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-600 transition-colors cursor-pointer"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ================= VIEW 3: MY IPOS & ISSUES ================= */}
      {currentSubTab === 'my_ipos' && (
        <MyIPOsTab
          currentUser={currentUser || null}
          ipos={ipos}
          onOpenReleaseModal={onOpenReleaseModal || (() => {})}
          onRequestDelist={onRequestDelist || (() => {})}
        />
      )}
      {/* ================= VIEW 4: CURRENCIES ================= */}
      {currentSubTab === 'currencies' && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <CurrenciesDirectoryAndWalletView 
            currentUser={currentUser || null}
            sovereignOnly={true}
          />
        </div>
      )}

      {/* ================= SHARE TRADE CONFIRMATION TOAST ================= */}
      {shareToast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-3 rounded-2xl bg-slate-900 text-white border border-indigo-400/40 shadow-2xl flex items-center gap-3 text-xs animate-in fade-in slide-in-from-bottom-3 flex-wrap justify-center">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-medium">{shareToast.text}</span>
          {shareToast.sharedToSocial && onNavigateToSocial && (
            <button
              type="button"
              onClick={() => {
                setShareToast(null);
                onNavigateToSocial();
              }}
              className="px-2.5 py-1 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-[11px] cursor-pointer whitespace-nowrap transition-colors"
            >
              View in Social
            </button>
          )}
          {shareToast.sharedToTweeting && (
            <button
              type="button"
              onClick={() => {
                setShareToast(null);
                window.dispatchEvent(new CustomEvent('open_tweeting_feed'));
              }}
              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] cursor-pointer whitespace-nowrap transition-colors inline-flex items-center gap-1"
            >
              <Twitter className="w-3 h-3 -scale-x-100 -rotate-12 fill-white" />
              <span>View in Tweeting</span>
            </button>
          )}
        </div>
      )}

      {/* ================= MODAL: SHARE FINAL STOCK TRADE ================= */}
      {sharingPosition && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 text-left">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-md max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <Share2 className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-sm text-slate-900 truncate">
                    Share Equity Spot Position
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono truncate">
                    ${sharingPosition.ticker} &bull; {getSpotCoinLabel(sharingPosition.ticker)}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSharingPosition(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmShareTrade} className="p-5 space-y-4 text-xs">
              {/* Recent Order Presets if any exist */}
              {orders.some((o) => o.ticker.toUpperCase() === sharingPosition.ticker.toUpperCase()) && (
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono block">
                    Recent Trades for ${sharingPosition.ticker}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {orders
                      .filter((o) => o.ticker.toUpperCase() === sharingPosition.ticker.toUpperCase())
                      .slice(0, 3)
                      .map((ord) => (
                        <button
                          key={ord.id}
                          type="button"
                          onClick={() => {
                            setShareSide(ord.side);
                            setShareSharesInput(String(Number((ord.shares || 1).toFixed(4))));
                            setShareNoteInput(
                              `Shared my ${ord.side === 'buy' ? 'purchase' : 'sale'} of $${sharingPosition.ticker} on Final Equity Spot.`
                            );
                          }}
                          className={`px-2.5 py-1 rounded-lg border text-[11px] font-mono font-bold cursor-pointer transition-colors ${
                            ord.side === 'buy'
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100'
                              : 'bg-rose-50 border-rose-200 text-rose-800 hover:bg-rose-100'
                          }`}
                        >
                          {ord.side.toUpperCase()} {Number((ord.shares || 0).toFixed(2))} shs
                        </button>
                      ))}
                  </div>
                </div>
              )}

              {/* Bought vs Sold Switcher */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono block">
                  Trade Action
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setShareSide('buy');
                      setShareNoteInput(
                        `Bought $${sharingPosition.ticker} on Final Equity Spot.`
                      );
                    }}
                    className={`py-2 rounded-lg font-bold transition-all cursor-pointer ${
                      shareSide === 'buy'
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Bought Final Stock
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShareSide('sell');
                      setShareNoteInput(
                        `Sold $${sharingPosition.ticker} on Final Equity Spot.`
                      );
                    }}
                    className={`py-2 rounded-lg font-bold transition-all cursor-pointer ${
                      shareSide === 'sell'
                        ? 'bg-rose-600 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Sold Final Stock
                  </button>
                </div>
              </div>

              {/* Shares & Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono block mb-1">
                    Shares
                  </label>
                  <input
                    type="number"
                    min="0.0001"
                    step="any"
                    value={shareSharesInput}
                    onChange={(e) => setShareSharesInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono block mb-1">
                    Final Currency
                  </label>
                  <div className="px-3 py-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 font-mono font-bold flex items-center gap-1.5">
                    <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="truncate">{getSpotCoinLabel(sharingPosition.ticker)}</span>
                  </div>
                </div>
              </div>

              {/* Share Destinations */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono block">
                  Share To
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShareToSocial((prev) => !prev)}
                    className={`px-3 py-2 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      shareToSocial
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>Social Feed</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShareToTweeting((prev) => !prev)}
                    className={`px-3 py-2 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      shareToTweeting
                        ? 'bg-emerald-600 border-emerald-600 text-white shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Twitter className={`w-3.5 h-3.5 -scale-x-100 -rotate-12 ${shareToTweeting ? 'fill-white' : ''}`} />
                    <span>Tweeting</span>
                  </button>
                </div>
              </div>

              {/* Share With Friends Selector */}
              {shareToSocial && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                    Share With
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setShareAudienceMode('all');
                        setSelectedFriendIds(friendsList.map((f) => f.uid));
                      }}
                      className={`px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer ${
                        shareAudienceMode === 'all'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      All Friends
                    </button>
                    <button
                      type="button"
                      onClick={() => setShareAudienceMode('selected')}
                      className={`px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer ${
                        shareAudienceMode === 'selected'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      Pick Friends
                    </button>
                  </div>
                </div>

                {shareAudienceMode === 'selected' && (
                  <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 rounded-2xl bg-slate-50 border border-slate-200">
                    {friendsList.map((friend) => {
                      const checked = selectedFriendIds.includes(friend.uid);
                      return (
                        <button
                          key={friend.uid}
                          type="button"
                          onClick={() => handleToggleShareFriend(friend.uid)}
                          className={`w-full px-2.5 py-1.5 rounded-xl border flex items-center justify-between transition-colors cursor-pointer ${
                            checked
                              ? 'bg-indigo-50 border-indigo-300 text-indigo-950'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <img
                              src={friend.avatarUrl}
                              alt={friend.name}
                              className="w-6 h-6 rounded-full object-cover shrink-0"
                            />
                            <div className="text-left min-w-0">
                              <span className="font-bold text-xs block truncate">{friend.name}</span>
                              <span className="text-[10px] font-mono text-slate-400 block truncate">@{friend.handle}</span>
                            </div>
                          </div>
                          <span
                            className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 ${
                              checked
                                ? 'bg-indigo-600 border-indigo-600 text-white'
                                : 'border-slate-300 bg-white'
                            }`}
                          >
                            {checked && <Check className="w-3 h-3" />}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
              )}

              {/* Note */}
              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono block mb-1">
                  Note {shareToTweeting ? '/ Tweet Text' : 'for Friends'}
                </label>
                <textarea
                  rows={2}
                  value={shareNoteInput}
                  onChange={(e) => setShareNoteInput(e.target.value)}
                  placeholder="Add an optional note about this Final stock trade..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSharingPosition(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={
                    (!shareToSocial && !shareToTweeting) ||
                    (shareToSocial && shareAudienceMode === 'selected' && selectedFriendIds.length === 0)
                  }
                  className={`px-4 py-2 rounded-xl disabled:opacity-50 text-white font-bold transition-colors inline-flex items-center gap-1.5 cursor-pointer shadow-xs ${
                    shareToTweeting && !shareToSocial
                      ? 'bg-emerald-600 hover:bg-emerald-500'
                      : 'bg-indigo-600 hover:bg-indigo-500'
                  }`}
                >
                  {shareToTweeting && !shareToSocial ? (
                    <Twitter className="w-3.5 h-3.5 -scale-x-100 -rotate-12 fill-white" />
                  ) : (
                    <Share2 className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {shareToSocial && shareToTweeting
                      ? 'Share to Social & Tweeting'
                      : shareToTweeting
                      ? 'Post to Tweeting'
                      : 'Share to Social'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: ALL TRADE OPTIONS WITH FINAL STOCKS ================= */}
      {isFinalTradeOptionsModalOpen && (
        <FinalStocksTradeOptionsModal
          isOpen={isFinalTradeOptionsModalOpen}
          onClose={() => setIsFinalTradeOptionsModalOpen(false)}
          stocks={stocks}
          enrichedPositions={enrichedPositions}
          currentUser={currentUser}
          onOpenTradeModal={onOpenTradeModal}
          onSelectStock={onSelectStock}
          onOpenStockMarket={onOpenStockMarket}
          onSwitchToDerivativesTab={onSwitchToDerivativesTab}
        />
      )}
    </div>
  );
};
