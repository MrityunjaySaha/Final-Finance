import React, { useState, useEffect, useRef } from 'react';
import { Search, Users, Unlock, Check } from 'lucide-react';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { getUserProfile } from '../../services/socialService';
import {
  setPendingProfileReturnAnchor,
  getProfileReturnAnchor,
  clearProfileReturnAnchor,
} from '../../utils/profileReturnState';
import {
  ACCOUNT_STATUS_UPDATED_EVENT,
  buildIdentityKeys,
  getLockedAccountRecords,
  isAccountLocked,
  setAccountLocked,
} from '../../utils/accountStatusStorage';
import { PresenceAvatarDot, PresenceStatusBadge } from '../common/PresenceBadge';

interface LockedUserItem {
  uid: string;
  userId: string;
  name: string;
  email?: string;
  avatarUrl?: string;
  role: string;
  lockedAt?: string;
}

const STATIC_USER_POOL: LockedUserItem[] = [
  {
    uid: 'demo-jordan-belfort',
    userId: 'jordan_belfort',
    name: 'Jordan Belfort',
    email: 'jordan@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    role: 'admin',
  },
  {
    uid: 'demo-satoshi-nakamoto',
    userId: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    email: 'satoshi@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'user',
  },
  {
    uid: 'demo-alex-morgan',
    userId: 'alex_morgan',
    name: 'Alex Morgan',
    email: 'alex@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    role: 'user',
  },
  {
    uid: 'user-default',
    userId: 'sovereign_trader',
    name: 'Sovereign Trader',
    role: 'user',
  },
  {
    uid: 'user-gholu653',
    userId: 'gholu653',
    name: 'Gholu',
    email: 'gholu653@gmail.com',
    avatarUrl: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    role: 'user',
  },
  {
    uid: 'user-lord_sterling',
    userId: 'sterling_vault',
    name: 'Lord Sterling',
    email: 'sterling@zurich-escrow.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'user',
  },
  {
    uid: 'user-elena_rostova',
    userId: 'elena_rostova',
    name: 'Elena Rostova',
    email: 'elena@monaco-yachting.mc',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    role: 'user',
  },
  {
    uid: 'user-marcus_vance',
    userId: 'marcus_vance',
    name: 'Marcus Vance',
    email: 'marcus@vance-holdings.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    role: 'user',
  },
];

interface AdminLockedDeskProps {
  onViewProfile: (userId: string) => void;
  onNotify?: (message: string, type: 'success' | 'info' | 'error') => void;
}

export const AdminLockedDesk: React.FC<AdminLockedDeskProps> = ({ onViewProfile, onNotify }) => {
  const initialAnchor = React.useMemo(() => {
    const a = getProfileReturnAnchor();
    if (a && a.adminTab === 'locked' && a.restoreActive) {
      return a;
    }
    return null;
  }, []);

  const [searchTerm, setSearchTerm] = useState(initialAnchor?.adminSearchTerm || '');
  const [lockedUsers, setLockedUsers] = useState<LockedUserItem[]>([]);
  const [profilesHydrated, setProfilesHydrated] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const pendingAnchorRef = useRef<string | null>(initialAnchor?.listingId || null);
  const savedScrollYRef = useRef<number | null>(
    typeof initialAnchor?.scrollY === 'number' ? initialAnchor.scrollY : null
  );
  const [highlightedAnchorId, setHighlightedAnchorId] = useState<string | null>(null);
  const [failedAvatars, setFailedAvatars] = useState<Record<string, boolean>>({});

  const handleInspectUser = (userId: string) => {
    const anchorId = `locked-${userId}`;
    setPendingProfileReturnAnchor({
      sourceLabel: 'Back to Locked',
      adminTab: 'locked',
      adminSearchTerm: searchTerm,
      listingId: anchorId,
      restoreActive: true,
      scrollY: window.scrollY,
    });
    onViewProfile(userId);
  };

  useEffect(() => {
    let mounted = true;
    const loadLockedUsers = async () => {
      // 1. Registered users
      let registeredList: LockedUserItem[] = [];
      try {
        const stored = localStorage.getItem('final_finance_registered_users');
        if (stored) {
          const regMap = JSON.parse(stored);
          registeredList = Object.values<any>(regMap).map((account) => ({
            uid: `user-${account.userId}`,
            userId: account.userId,
            name: account.name || account.userId,
            email: account.email,
            avatarUrl:
              account.avatarUrl ||
              `https://ui-avatars.com/api/?name=${encodeURIComponent(
                account.name || account.userId
              )}&background=0f172a&color=f8fafc&bold=true&size=128`,
            role: 'user',
          }));
        }
      } catch (e) {
        console.error('Error reading registered users for locked list:', e);
      }

      // 2. Custom profiles
      let customList: LockedUserItem[] = [];
      try {
        const storedCustom = localStorage.getItem('final_finance_custom_profiles_map');
        if (storedCustom) {
          const customMap = JSON.parse(storedCustom);
          customList = Object.values<any>(customMap).map((prof) => ({
            uid: prof.uid || `user-${prof.userId}`,
            userId: prof.userId,
            name: prof.name || prof.userId,
            email: prof.email,
            avatarUrl: prof.avatarUrl,
            role: prof.role || 'user',
          }));
        }
      } catch {
        // ignore
      }

      // 3. Explicit user-lock records (from Accounting or Profile Sovereign Guard)
      const userLockRecords = getLockedAccountRecords('user_lock');
      const superAdminOnlyRecords = getLockedAccountRecords('super_admin_lock');
      const superAdminOnlyKeys = new Set<string>();
      for (const rec of superAdminOnlyRecords) {
        buildIdentityKeys([rec.uid, rec.userId, rec.email]).forEach((k) =>
          superAdminOnlyKeys.add(k.toLowerCase())
        );
      }
      const userLockKeys = new Set<string>();
      for (const rec of userLockRecords) {
        buildIdentityKeys([rec.uid, rec.userId, rec.email]).forEach((k) =>
          userLockKeys.add(k.toLowerCase())
        );
      }

      const explicitLockedItems: LockedUserItem[] = userLockRecords.map((rec) => ({
        uid: rec.uid,
        userId: rec.userId,
        name: rec.name || rec.userId,
        email: rec.email,
        avatarUrl: rec.avatarUrl,
        role: 'user',
        lockedAt: rec.lockedAt,
      }));

      // 4. Combine & de-duplicate by normalized handle
      const uniqueMap = new Map<string, LockedUserItem>();
      [...STATIC_USER_POOL, ...registeredList, ...customList, ...explicitLockedItems].forEach((u) => {
        if (!u.userId) return;
        const key = u.userId.toLowerCase().replace(/^@/, '');
        const existing = uniqueMap.get(key);
        uniqueMap.set(key, {
          ...(existing || {}),
          ...u,
          userId: key,
          avatarUrl: u.avatarUrl || existing?.avatarUrl,
          email: u.email || existing?.email,
        });
      });

      const lockedOnly = Array.from(uniqueMap.values()).filter((user) => {
        const ids = [user.userId, user.uid, user.email];
        if (!isAccountLocked(ids)) return false;
        const expanded = buildIdentityKeys(ids).map((k) => k.toLowerCase());
        const hasExplicitUserLock = expanded.some((k) => userLockKeys.has(k));
        const hasSuperAdminLock = expanded.some((k) => superAdminOnlyKeys.has(k));
        if (hasSuperAdminLock && !hasExplicitUserLock) {
          return false;
        }
        return true;
      });

      if (!mounted) return;
      setLockedUsers(lockedOnly);

      // Hydrate avatars/names from social profiles where available
      const hydrated = await Promise.all(
        lockedOnly.map(async (u) => {
          const prof = await getUserProfile(u.userId);
          return {
            ...u,
            name: prof?.name || u.name,
            avatarUrl: prof?.avatarUrl || u.avatarUrl,
            email: prof?.email || u.email,
          };
        })
      );
      if (!mounted) return;
      setLockedUsers(hydrated);
      setProfilesHydrated(true);
    };

    loadLockedUsers();
    window.addEventListener(ACCOUNT_STATUS_UPDATED_EVENT, loadLockedUsers);
    window.addEventListener('storage', loadLockedUsers);
    return () => {
      mounted = false;
      window.removeEventListener(ACCOUNT_STATUS_UPDATED_EVENT, loadLockedUsers);
      window.removeEventListener('storage', loadLockedUsers);
    };
  }, [refreshTrigger]);

  useEffect(() => {
    const anchorId = pendingAnchorRef.current;
    if (!anchorId || lockedUsers.length === 0) return;
    let cancelled = false;
    const restoreExactFrame = (finalize: boolean) => {
      if (cancelled) return;
      const selector = `[data-locked-anchor="${anchorId.replace(/"/g, '\\"')}"]`;
      const el = document.querySelector(selector) as HTMLElement | null;
      const headerEl = document.querySelector('header');
      const headerHeight = headerEl ? headerEl.getBoundingClientRect().height : 65;

      if (savedScrollYRef.current !== null) {
        window.scrollTo({ top: savedScrollYRef.current, behavior: 'instant' as ScrollBehavior });
      }

      if (el) {
        const rect = el.getBoundingClientRect();
        const isOutsideViewport = rect.bottom < headerHeight + 8 || rect.top > window.innerHeight - 8;
        if (savedScrollYRef.current === null || isOutsideViewport) {
          const targetTop = Math.max(0, window.scrollY + rect.top - (headerHeight + 24));
          window.scrollTo({ top: targetTop, behavior: 'instant' as ScrollBehavior });
        }
        setHighlightedAnchorId(anchorId);
        if (finalize) {
          pendingAnchorRef.current = null;
          savedScrollYRef.current = null;
          clearProfileReturnAnchor();
          setTimeout(() => setHighlightedAnchorId(null), 1800);
        }
      }
    };
    const raf = requestAnimationFrame(() => restoreExactFrame(false));
    const t1 = window.setTimeout(() => restoreExactFrame(false), 60);
    const t2 = profilesHydrated ? window.setTimeout(() => restoreExactFrame(true), 120) : null;
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      window.clearTimeout(t1);
      if (t2 !== null) window.clearTimeout(t2);
    };
  }, [lockedUsers, profilesHydrated]);

  const handleUnlock = (user: LockedUserItem) => {
    setAccountLocked([user.userId, user.uid, user.email], false, {
      source: 'user_lock',
    });

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-UNLOCK-${Math.floor(1000 + Math.random() * 9000)}`;

    const unlockItem = {
      id: `rec-unlock-${Date.now()}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'deposit',
      category: 'transfer',
      mode: 'final_coin',
      title: `Account Unlocked by Operator`,
      description: `Security lock lifted on profile @${user.userId} by System Administrator from Admin Locked Desk. Access restored.`,
      amountUSD: 0,
      feeUSD: 0.0,
      netAmountUSD: 0.0,
      sourceOrDestination: `Sovereign Guard Security Desk`,
      counterpartyOrIssuer: `@${user.userId}`,
      paymentCoinSymbol: 'AFNL',
      paymentCoinAmount: 0,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Administrative account unlock.',
      },
      signature: `SIG-UNLOCK-${Math.floor(100000 + Math.random() * 900000)}`,
    };

    recordLedgerTransaction(user.userId, unlockItem as any);
    recordLedgerTransaction('admin', unlockItem as any);
    recordLedgerTransaction('super_admin', unlockItem as any);
    window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

    if (onNotify) {
      onNotify(`Account @${user.userId} has been unlocked.`, 'success');
    }
    setRefreshTrigger((prev) => prev + 1);
  };

  const filtered = lockedUsers.filter(
    (u) =>
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.userId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (u.email && u.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden text-center">
      <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col items-center justify-center text-center gap-4 bg-white">
        <div className="flex items-center justify-center gap-2 flex-wrap">
          <h2 className="font-serif text-xl font-bold text-slate-900 text-center">
            Locked Accounts
          </h2>
          <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-xs font-bold font-mono">
            Total: {lockedUsers.length}
          </span>
        </div>

        {/* Real-time search filter */}
        <div className="relative w-full max-w-sm mx-auto">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search locked accounts by name or username..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>
      </div>

      <div>
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center mx-auto mb-3.5 border border-slate-200">
              <Check className="w-6 h-6 text-emerald-600" />
            </div>
            <h3 className="font-serif text-sm font-bold text-slate-950">No Locked Accounts</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              {lockedUsers.length === 0
                ? 'No user accounts are currently locked.'
                : 'No locked accounts match your current search query.'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 text-left">
            {filtered.map((user) => {
              const rowAnchorId = `locked-${user.userId}`;
              const avatarFailed = Boolean(failedAvatars[user.userId]);
              return (
                <div
                  key={`${user.uid}-${user.userId}`}
                  data-locked-anchor={rowAnchorId}
                  className={`px-4 sm:px-6 py-4 flex items-center justify-between gap-3 transition-colors ${
                    highlightedAnchorId === rowAnchorId
                      ? 'bg-amber-50/80 ring-2 ring-inset ring-amber-400/60'
                      : 'hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleInspectUser(user.userId)}
                      className="relative cursor-pointer shrink-0 rounded-full"
                      title={`View ${user.name}'s profile`}
                    >
                      {user.avatarUrl && !avatarFailed ? (
                        <img
                          src={user.avatarUrl}
                          alt={user.name}
                          referrerPolicy="no-referrer"
                          onError={() =>
                            setFailedAvatars((prev) => ({ ...prev, [user.userId]: true }))
                          }
                          className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-sm border border-slate-200 shrink-0">
                          {user.name ? user.name.charAt(0).toUpperCase() : <Users className="w-5 h-5" />}
                        </div>
                      )}
                      <PresenceAvatarDot
                        identifiers={[user.uid, user.userId, user.email]}
                        forceOffline
                        size="xs"
                      />
                    </button>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          type="button"
                          onClick={() => handleInspectUser(user.userId)}
                          className="font-bold text-slate-900 hover:text-amber-700 transition-colors text-left cursor-pointer text-sm truncate"
                        >
                          {user.name}
                        </button>
                        <PresenceStatusBadge
                          identifiers={[user.uid, user.userId, user.email]}
                          forceOffline
                          size="xs"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleInspectUser(user.userId)}
                        className="text-xs font-mono text-slate-500 hover:text-amber-700 transition-colors cursor-pointer block truncate mt-0.5"
                      >
                        @{user.userId}
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleUnlock(user)}
                    className="px-3.5 py-2 bg-emerald-600 text-white hover:bg-emerald-500 text-xs font-bold rounded-xl transition-colors cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 shadow-2xs"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    <span>Unlock</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
