import React, { useEffect, useMemo, useState } from 'react';
import {
  X,
  CreditCard,
  Building2,
  Coins,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Plus,
  Wallet,
  DollarSign,
  Bitcoin,
  Lock,
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { UserWalletData } from '../../types/wallet';
import { UniversalLedgerItem } from '../../types/ledger';
import { LoanRecord, getLoanRemainingBalance, payAheadLoan } from '../../services/loanService';
import {
  StripeSavedPaymentMethod,
  executeStripeCharge,
  getStripeConfigSafe,
  getStripePromise,
} from '../../services/stripeClientService';
import { verifyWalletSignatureOnServer } from '../../services/privyClientService';
import { applyCurrencyWalletDelta } from '../../utils/walletBalanceUpdater';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { dispatchGlobalNotification } from '../../utils/notificationService';
import {
  VerifiedCryptoWalletSummary,
  loadVerifiedPaymentSources,
} from '../../utils/paymentMethodsBridge';
import {
  calculateWalletPurchaseFee,
  formatInsufficientCurrencyError,
} from '../../utils/transactionFees';
import { ConfirmModal } from '../common/ConfirmModal';

export interface DebtPaymentCompletionPayload {
  paymentAmount: number;
  sourceLabel: string;
  methodType: string;
  isExternalCharge: boolean;
  debitedCurrencyCode?: string;
  debitedUnits?: number;
  paymentIntentId?: string;
  remainingDebt: number;
}

interface AccountPayModalProps {
  isOpen: boolean;
  onClose: () => void;
  negativeBalance: number;
  accountDebtUSD?: number;
  borrowedLoans?: LoanRecord[];
  currentUser?: AuthSession | null;
  walletData: UserWalletData;
  verifiedBanks?: StripeSavedPaymentMethod[];
  verifiedCards?: StripeSavedPaymentMethod[];
  verifiedCryptoWallets?: VerifiedCryptoWalletSummary[];
  initialSourceId?: string;
  onOpenLinkMethod?: (type: 'bank' | 'card' | 'crypto') => void;
  onPaymentCompleted?: (payload: DebtPaymentCompletionPayload) => void;
  onConfirmPayment?: (paymentAmount: number, sourceLabel: string, methodType: string) => void;
}

interface InventoryPayOption {
  id: string;
  category: 'fiat' | 'stable_coin' | 'crypto';
  code: string;
  name: string;
  units: number;
  unitPriceUSD: number;
  usdValue: number;
}

export const AccountPayModal: React.FC<AccountPayModalProps> = ({
  isOpen,
  onClose,
  negativeBalance,
  accountDebtUSD,
  borrowedLoans = [],
  currentUser,
  walletData,
  verifiedBanks,
  verifiedCards,
  verifiedCryptoWallets,
  initialSourceId,
  onOpenLinkMethod,
  onPaymentCompleted,
  onConfirmPayment,
}) => {
  const userId = currentUser?.id || 'guest';
  const totalDueAmount = Math.max(0, Math.abs(negativeBalance));

  const [payOption, setPayOption] = useState<'full' | 'custom'>('full');
  const [customAmount, setCustomAmount] = useState<string>(totalDueAmount.toFixed(2));
  const [selectedSourceId, setSelectedSourceId] = useState<string>(initialSourceId || '');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const [loadedBanks, setLoadedBanks] = useState<StripeSavedPaymentMethod[]>(verifiedBanks || []);
  const [loadedCards, setLoadedCards] = useState<StripeSavedPaymentMethod[]>(verifiedCards || []);
  const [loadedCryptos, setLoadedCryptos] = useState<VerifiedCryptoWalletSummary[]>(verifiedCryptoWallets || []);
  const [isLoadingSources, setIsLoadingSources] = useState(false);

  const effectiveBanks = verifiedBanks ?? loadedBanks;
  const effectiveCards = verifiedCards ?? loadedCards;
  const effectiveCryptos = verifiedCryptoWallets ?? loadedCryptos;

  useEffect(() => {
    if (!isOpen) return;
    setErrorMsg('');
    setPayOption('full');
    setCustomAmount(totalDueAmount > 0 ? totalDueAmount.toFixed(2) : '0');

    if (currentUser && (verifiedBanks === undefined || verifiedCards === undefined || verifiedCryptoWallets === undefined)) {
      setIsLoadingSources(true);
      loadVerifiedPaymentSources(currentUser)
        .then((res) => {
          setLoadedBanks(res.banks);
          setLoadedCards(res.cards);
          setLoadedCryptos(res.cryptoWallets);
        })
        .catch(() => {})
        .finally(() => setIsLoadingSources(false));
    }
  }, [isOpen, totalDueAmount, currentUser, verifiedBanks, verifiedCards, verifiedCryptoWallets]);

  // All held Fiat, Stablecoin, and Crypto balances in Asset Inventory with positive balance
  const inventorySources = useMemo<InventoryPayOption[]>(() => {
    const items: InventoryPayOption[] = [];

    for (const f of walletData.fiatCurrencies || []) {
      const rate = Number(f.exchangeRateToUSD || 1);
      const bal = Number(f.balance || 0);
      if (bal > 0) {
        items.push({
          id: `inv-fiat-${f.code.toUpperCase()}`,
          category: 'fiat',
          code: f.code.toUpperCase(),
          name: f.name,
          units: bal,
          unitPriceUSD: rate,
          usdValue: bal * rate,
        });
      }
    }

    for (const s of walletData.stableCoins || []) {
      const price = Number(s.unitPriceUSD || 1);
      const bal = Number(s.balance || 0);
      if (bal > 0) {
        items.push({
          id: `inv-stable-${s.symbol.toUpperCase()}`,
          category: 'stable_coin',
          code: s.symbol.toUpperCase(),
          name: s.name,
          units: bal,
          unitPriceUSD: price,
          usdValue: bal * price,
        });
      }
    }

    for (const c of walletData.cryptoCurrencies || []) {
      const price = Number(c.unitPriceUSD || 1);
      const bal = Number(c.balance || 0);
      if (bal > 0) {
        items.push({
          id: `inv-crypto-${c.symbol.toUpperCase()}`,
          category: 'crypto',
          code: c.symbol.toUpperCase(),
          name: c.name,
          units: bal,
          unitPriceUSD: price,
          usdValue: bal * price,
        });
      }
    }

    return items;
  }, [walletData]);

  useEffect(() => {
    if (!isOpen) return;
    if (initialSourceId) {
      setSelectedSourceId(initialSourceId);
      return;
    }
    if (selectedSourceId) {
      const exists =
        effectiveBanks.some((b) => `stripe-${b.id}` === selectedSourceId) ||
        effectiveCards.some((c) => `stripe-${c.id}` === selectedSourceId) ||
        effectiveCryptos.some((w) => `wallet-${w.address.toLowerCase()}` === selectedSourceId) ||
        inventorySources.some((i) => i.id === selectedSourceId);
      if (exists) return;
    }

    if (effectiveBanks.length > 0) {
      setSelectedSourceId(`stripe-${effectiveBanks[0].id}`);
    } else if (effectiveCards.length > 0) {
      setSelectedSourceId(`stripe-${effectiveCards[0].id}`);
    } else if (inventorySources.length > 0) {
      setSelectedSourceId(inventorySources[0].id);
    } else if (effectiveCryptos.length > 0) {
      setSelectedSourceId(`wallet-${effectiveCryptos[0].address.toLowerCase()}`);
    } else {
      setSelectedSourceId('');
    }
  }, [isOpen, initialSourceId, effectiveBanks, effectiveCards, effectiveCryptos, inventorySources, selectedSourceId]);

  if (!isOpen) return null;

  const paymentAmount =
    payOption === 'full' ? totalDueAmount : Math.max(0, parseFloat(customAmount) || 0);
  const projectedRemaining = Math.max(0, totalDueAmount - paymentAmount);

  const isSelectedCard = Boolean(
    selectedSourceId.startsWith('stripe-') &&
      effectiveCards.some((c) => `stripe-${c.id}` === selectedSourceId)
  );
  const selectedCryptoWallet = selectedSourceId.startsWith('wallet-')
    ? effectiveCryptos.find((w) => `wallet-${w.address.toLowerCase()}` === selectedSourceId)
    : undefined;

  const selectedInventory = inventorySources.find((i) => i.id === selectedSourceId);

  let processingFeeUSD = 0;
  let feeDescriptionLabel = 'No processing fee';
  if (paymentAmount > 0 && isSelectedCard) {
    const stripeFee = calculateWalletPurchaseFee({
      category: 'fiat',
      subtotalUSD: paymentAmount,
      symbol: 'USD',
    });
    processingFeeUSD = stripeFee.feeUSD;
    feeDescriptionLabel = stripeFee.feeLabel;
  } else if (paymentAmount > 0 && selectedCryptoWallet) {
    const privyFee = calculateWalletPurchaseFee({
      category: 'crypto',
      subtotalUSD: paymentAmount,
      symbol: 'ETH',
      network: selectedCryptoWallet.network,
    });
    processingFeeUSD = privyFee.feeUSD;
    feeDescriptionLabel = privyFee.nativeUnits && privyFee.nativeSymbol
      ? `${privyFee.feeLabel} (~${privyFee.nativeUnits} ${privyFee.nativeSymbol})`
      : privyFee.feeLabel;
  } else if (paymentAmount > 0 && selectedInventory) {
    const invFee = calculateWalletPurchaseFee({
      category: selectedInventory.category,
      subtotalUSD: paymentAmount,
      symbol: selectedInventory.code,
    });
    processingFeeUSD = invFee.feeUSD;
    feeDescriptionLabel = invFee.nativeUnits && invFee.nativeSymbol
      ? `${invFee.feeLabel} (~${invFee.nativeUnits} ${invFee.nativeSymbol})`
      : invFee.feeLabel;
  }
  const totalChargedUSD =
    paymentAmount > 0 ? Math.round((paymentAmount + processingFeeUSD) * 100) / 100 : 0;

  const requiredUnitsForSelectedInventory = selectedInventory
    ? totalChargedUSD / Math.max(0.000001, selectedInventory.unitPriceUSD)
    : 0;
  const insufficientSelectedInventory = Boolean(
    selectedInventory && requiredUnitsForSelectedInventory > selectedInventory.units + 1e-6
  );

  const loansTotalUSD = borrowedLoans.reduce(
    (sum, l) => sum + (l.coinSymbol === 'AFNL' ? 0 : getLoanRemainingBalance(l)),
    0
  );
  const deficitBreakdownUSD =
    typeof accountDebtUSD === 'number' ? accountDebtUSD : Math.max(0, totalDueAmount - loansTotalUSD);

  const handlePaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (paymentAmount <= 0) {
      setErrorMsg('Enter a payment amount greater than $0.00.');
      return;
    }
    if (!selectedSourceId) {
      setErrorMsg('Select a verified bank account, card, wallet, or held currency balance.');
      return;
    }
    if (insufficientSelectedInventory && selectedInventory) {
      setErrorMsg(
        formatInsufficientCurrencyError({
          symbol: selectedInventory.code,
          name: selectedInventory.name,
          available: selectedInventory.units,
          required: requiredUnitsForSelectedInventory,
          maxDecimals: selectedInventory.category === 'crypto' ? 6 : 2,
        })
      );
      return;
    }

    setShowConfirm(true);
  };

  const processExecution = async () => {
    setShowConfirm(false);
    setErrorMsg('');
    setIsProcessing(true);

    try {
      let sourceLabel = '';
      let methodType = 'bank';
      let isExternalCharge = false;
      let debitedCurrencyCode: string | undefined;
      let debitedUnits: number | undefined;
      let paymentIntentId: string | undefined;

      if (selectedSourceId.startsWith('stripe-')) {
        if (!currentUser) {
          throw new Error('Sign in to pay with a verified bank account or card.');
        }
        const pmId = selectedSourceId.replace('stripe-', '');
        const charge = await executeStripeCharge(currentUser, {
          paymentMethodId: pmId,
          amountUSD: totalChargedUSD,
          baseAmountUSD: paymentAmount,
          feeUSD: processingFeeUSD,
          purpose: 'debt_payment',
          targetAssetClass: 'liability',
          targetCurrencyCode: 'USD',
        });

        if (charge.requiresAction && charge.clientSecret) {
          const cfg = await getStripeConfigSafe();
          const stripe = await getStripePromise(cfg.publishableKey);
          if (!stripe) {
            throw new Error('Additional card authentication is required.');
          }
          const confirmed = await stripe.confirmCardPayment(charge.clientSecret);
          if (confirmed.error) {
            throw new Error(confirmed.error.message || 'Card authentication failed.');
          }
        }

        paymentIntentId = charge.paymentIntentId;
        sourceLabel = charge.sourceLabel;
        methodType = charge.paymentMethodType === 'card' ? 'card' : 'bank';
        isExternalCharge = true;
      } else if (selectedSourceId.startsWith('wallet-')) {
        const addr = selectedSourceId.replace('wallet-', '');
        const matchedWallet = effectiveCryptos.find((w) => w.address.toLowerCase() === addr.toLowerCase());
        if (!matchedWallet) {
          throw new Error('Selected crypto wallet is not verified.');
        }

        const eth = (window as unknown as { ethereum?: { request?: (args: { method: string; params?: unknown[] }) => Promise<unknown> } }).ethereum;
        if (eth?.request) {
          try {
            const challenge = `Authorize Final Finance debt settlement of $${paymentAmount.toFixed(2)} USD + $${processingFeeUSD.toFixed(2)} network fee (Total $${totalChargedUSD.toFixed(2)})\nWallet: ${matchedWallet.address}\nTimestamp: ${new Date().toISOString()}`;
            const sig = (await eth.request({
              method: 'personal_sign',
              params: [challenge, matchedWallet.address],
            })) as string;
            await verifyWalletSignatureOnServer({
              address: matchedWallet.address,
              message: challenge,
              signature: sig,
            });
          } catch (walletErr: any) {
            if (walletErr?.code === 4001) {
              throw new Error('Wallet signature cancelled. Payment was not submitted.');
            }
          }
        }

        sourceLabel = `${matchedWallet.label} (${matchedWallet.address.slice(0, 6)}...${matchedWallet.address.slice(-4)})`;
        methodType = 'crypto';
        isExternalCharge = true;
      } else if (selectedInventory) {
        const unitsToDebit = totalChargedUSD / Math.max(0.000001, selectedInventory.unitPriceUSD);
        const res = applyCurrencyWalletDelta({
          userId,
          currencySymbol: selectedInventory.code,
          currencyName: selectedInventory.name,
          delta: -unitsToDebit,
          requireSufficientBalance: true,
        });
        if (!res.success) {
          throw new Error(
            res.error ||
              formatInsufficientCurrencyError({
                symbol: selectedInventory.code,
                name: selectedInventory.name,
                available: selectedInventory.units,
                required: unitsToDebit,
              })
          );
        }
        debitedCurrencyCode = selectedInventory.code;
        debitedUnits = unitsToDebit;
        sourceLabel = `${selectedInventory.name} (${unitsToDebit.toLocaleString(undefined, { maximumFractionDigits: selectedInventory.category === 'crypto' ? 6 : 2 })} ${selectedInventory.code})`;
        methodType = selectedInventory.category;
        isExternalCharge = false;
      } else {
        throw new Error('Select a valid payment source.');
      }

      // Reduce stored debt and active USD borrowed loans cleanly
      let storedDebt = deficitBreakdownUSD;
      try {
        const raw = localStorage.getItem(`final_debt_${userId}`);
        if (raw !== null) storedDebt = Math.max(0, Number(raw) || 0);
      } catch {
        // ignore
      }

      const appliedToDeficit = Math.min(storedDebt, paymentAmount);
      const nextStoredDebt = Math.max(0, Math.round((storedDebt - appliedToDeficit) * 100) / 100);
      let remainingPoolForLoans = Math.max(0, Math.round((paymentAmount - appliedToDeficit) * 100) / 100);

      try {
        localStorage.setItem(`final_debt_${userId}`, nextStoredDebt.toString());
        window.dispatchEvent(new CustomEvent('final_debt_updated', { detail: { debt: nextStoredDebt } }));
      } catch {
        // ignore
      }

      if (remainingPoolForLoans > 0 && borrowedLoans.length > 0) {
        for (const loan of borrowedLoans) {
          if (loan.coinSymbol === 'AFNL' || loan.status !== 'active') continue;
          const owed = getLoanRemainingBalance(loan);
          if (owed <= 0) continue;
          const chunk = Math.min(owed, remainingPoolForLoans);
          if (chunk > 0) {
            payAheadLoan(loan.id, chunk);
            remainingPoolForLoans = Math.max(0, Math.round((remainingPoolForLoans - chunk) * 100) / 100);
          }
          if (remainingPoolForLoans <= 0.009) break;
        }
      }

      // Record receipt in Universal Ledger
      try {
        const now = new Date();
        const randomHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
        const ledgerMode: UniversalLedgerItem['mode'] =
          methodType === 'crypto' ? 'crypto' : methodType === 'stable_coin' ? 'stable_coin' : 'fiat';
        const feeText = processingFeeUSD > 0 ? ` (incl. $${processingFeeUSD.toFixed(2)} ${feeDescriptionLabel}, Total $${totalChargedUSD.toFixed(2)})` : '';

        const ledgerItem: UniversalLedgerItem = {
          id: `tx-settle-${Date.now()}`,
          receiptNumber: `REC-${now.getFullYear()}-ST-${Math.floor(100000 + Math.random() * 900000)}`,
          timestamp: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} UTC`,
          dateIso: now.toISOString(),
          type: 'payment_settlement',
          category: 'money_outflow',
          mode: ledgerMode,
          title: 'Liability & Debt Payoff Settlement',
          description: `Paid $${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} toward outstanding obligations using ${sourceLabel}${feeText}${paymentIntentId ? ` [${paymentIntentId}]` : ''}.`,
          amountUSD: paymentAmount,
          feeUSD: processingFeeUSD,
          netAmountUSD: totalChargedUSD,
          sourceOrDestination: sourceLabel,
          counterpartyOrIssuer: 'Final Finance Clearing Desk',
          paymentCoinSymbol: debitedCurrencyCode || 'USD',
          paymentCoinAmount: debitedUnits ? Number(debitedUnits.toFixed(6)) : totalChargedUSD,
          status: 'Audited',
          taxYear: now.getFullYear(),
          taxClassification: {
            taxableEvent: false,
            taxableAmountUSD: 0,
            formMapping: 'Non-Taxable Transfer',
            holdingPeriod: 'N/A',
            irsCategoryNote: 'Principal obligation and liability repayment.',
          },
          cryptographicHash: `0x${randomHex}`,
          clearingNode: paymentIntentId ? `Stripe ${paymentIntentId}` : 'Sovereign Clearing Node #4810-CH',
          signature: `SIG_${Math.floor(100000 + Math.random() * 900000)}_ECDSA`,
        };
        recordLedgerTransaction(userId, ledgerItem);
      } catch {
        // Non-fatal
      }

      dispatchGlobalNotification({
        title: 'Debt Payment Authorized',
        description: `Settled $${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} USD${processingFeeUSD > 0 ? ` + $${processingFeeUSD.toFixed(2)} fee ($${totalChargedUSD.toFixed(2)} total)` : ''} using ${sourceLabel}.`,
        type: 'wallet',
        targetTab: 'asset_inventory',
        amount: totalChargedUSD,
        currency: 'USD',
        showToast: false,
        tone: 'success',
      });

      if (onPaymentCompleted) {
        onPaymentCompleted({
          paymentAmount,
          sourceLabel,
          methodType,
          isExternalCharge,
          debitedCurrencyCode,
          debitedUnits,
          paymentIntentId,
          remainingDebt: Math.max(0, totalDueAmount - paymentAmount),
        });
      } else if (onConfirmPayment) {
        onConfirmPayment(paymentAmount, sourceLabel, methodType);
      }

      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Unable to authorize debt payment.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      id="account-pay-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-xs p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isProcessing) onClose();
      }}
    >
      <div
        id="account-pay-modal-container"
        className="relative w-full max-w-xl rounded-2xl bg-white border border-slate-200 shadow-2xl overflow-hidden my-6 max-h-[92dvh] flex flex-col text-center"
      >
        {/* Header - Centered */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-center relative bg-slate-50 text-center">
          <div className="flex flex-col items-center justify-center gap-1.5 px-8">
            <div className="p-2 rounded-xl bg-rose-50 border border-rose-200 text-rose-700">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                Pay Off Debt &amp; Liabilities
              </h2>
              <p className="text-xs text-slate-500">
                Pay using verified bank accounts, cards, crypto wallets, or held asset balances
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isProcessing}
            className="absolute right-4 top-4 p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handlePaySubmit} className="p-6 space-y-5 overflow-y-auto text-center">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center justify-center gap-2 text-center">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Liability Breakdown Banner */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3 text-center">
            <div className="grid grid-cols-2 gap-3 text-center">
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Total Obligations Due
                </span>
                <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
                  ${totalDueAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <div className="border-l border-slate-200 pl-3">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Remaining After Payment
                </span>
                <span
                  className={`text-lg font-bold font-mono tabular-nums ${
                    projectedRemaining === 0 ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  ${projectedRemaining.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            {(deficitBreakdownUSD > 0 || loansTotalUSD > 0) && (
              <div className="pt-2.5 border-t border-slate-200 grid grid-cols-2 gap-3 text-xs font-mono tabular-nums text-center">
                <div>
                  <span className="text-[10px] font-sans text-slate-500 block">Account Clearing Deficit</span>
                  <span className="font-bold text-slate-800">
                    ${deficitBreakdownUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="border-l border-slate-200 pl-3">
                  <span className="text-[10px] font-sans text-slate-500 block">
                    Borrowed Loans ({borrowedLoans.filter((l) => l.coinSymbol !== 'AFNL').length})
                  </span>
                  <span className="font-bold text-slate-800">
                    ${loansTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Payment Amount Selector */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-800 block text-center">
              1. Payment Amount (USD)
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setPayOption('full')}
                className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                  payOption === 'full'
                    ? 'border-indigo-600 bg-indigo-50/70'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <span className="text-[10px] font-bold text-slate-500 uppercase">Pay Full Debt</span>
                <p className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                  ${totalDueAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </button>

              <button
                type="button"
                onClick={() => setPayOption('custom')}
                className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                  payOption === 'custom'
                    ? 'border-indigo-600 bg-indigo-50/70'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <span className="text-[10px] font-bold text-slate-500 uppercase">Custom Amount</span>
                <p className="text-sm font-bold font-mono text-slate-900 mt-0.5">Enter USD</p>
              </button>
            </div>

            {payOption === 'custom' && (
              <div className="relative">
                <span className="absolute left-4 top-2.5 text-sm font-bold text-slate-500 font-mono">$</span>
                <input
                  type="number"
                  min="0.5"
                  step="any"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  className="w-full px-9 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold font-mono tabular-nums text-slate-900 text-center focus:outline-none focus:border-indigo-600"
                  required
                />
              </div>
            )}
          </div>

          {/* Payment Sources */}
          <div className="space-y-2.5">
            <div className="flex flex-col items-center justify-center gap-2 text-center">
              <label className="text-xs font-bold text-slate-800">
                2. Select Payment Method or Held Currency
              </label>
              {onOpenLinkMethod && (
                <div className="flex items-center justify-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onOpenLinkMethod('bank')}
                    className="px-2 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Bank</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenLinkMethod('card')}
                    className="px-2 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Card</span>
                  </button>
                </div>
              )}
            </div>

            {isLoadingSources ? (
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center gap-2 text-xs text-slate-500">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Loading verified payment methods...</span>
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {/* Verified Bank Accounts */}
                {effectiveBanks.map((bank) => {
                  const id = `stripe-${bank.id}`;
                  return (
                    <label
                      key={bank.id}
                      className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                        selectedSourceId === id
                          ? 'border-emerald-600 bg-emerald-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-3">
                        <input
                          type="radio"
                          name="paymentSource"
                          value={id}
                          checked={selectedSourceId === id}
                          onChange={() => setSelectedSourceId(id)}
                          className="accent-emerald-600"
                        />
                        <div className="p-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-700">
                          <Building2 className="w-4 h-4" />
                        </div>
                        <div className="text-center">
                          <span className="text-xs font-bold text-slate-900 block">
                            {bank.bankName || 'Verified Bank Account'}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">
                            {bank.accountType || 'checking'} ••••{bank.last4} · Direct Bank Debit
                          </span>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-700 font-semibold">
                        Verified Bank
                      </span>
                    </label>
                  );
                })}

                {/* Verified Cards */}
                {effectiveCards.map((card) => {
                  const id = `stripe-${card.id}`;
                  return (
                    <label
                      key={card.id}
                      className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                        selectedSourceId === id
                          ? 'border-emerald-600 bg-emerald-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-3">
                        <input
                          type="radio"
                          name="paymentSource"
                          value={id}
                          checked={selectedSourceId === id}
                          onChange={() => setSelectedSourceId(id)}
                          className="accent-emerald-600"
                        />
                        <div className="p-2 rounded-lg bg-purple-50 border border-purple-200 text-purple-700">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div className="text-center">
                          <span className="text-xs font-bold text-slate-900 block uppercase">
                            {card.brand || 'Card'} {card.funding || ''} ••••{card.last4}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">
                            Exp {String(card.expMonth || 1).padStart(2, '0')}/{card.expYear || '----'}
                          </span>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-700 font-semibold">
                        Verified Card
                      </span>
                    </label>
                  );
                })}

                {/* Held Asset Inventory Balances (Fiat, Stablecoins, Crypto) */}
                {inventorySources.map((src) => {
                  const rowFee = calculateWalletPurchaseFee({
                    category: src.category,
                    subtotalUSD: paymentAmount,
                    symbol: src.code,
                  });
                  const rowTotalUSD = Math.round((paymentAmount + rowFee.feeUSD) * 100) / 100;
                  const neededUnits = rowTotalUSD / Math.max(0.000001, src.unitPriceUSD);
                  const hasEnough = src.units + 1e-6 >= neededUnits;
                  const CategoryIcon =
                    src.category === 'fiat'
                      ? DollarSign
                      : src.category === 'stable_coin'
                      ? Coins
                      : Bitcoin;
                  const iconBg =
                    src.category === 'fiat'
                      ? 'bg-sky-50 border-sky-200 text-sky-700'
                      : src.category === 'stable_coin'
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                      : 'bg-purple-50 border-purple-200 text-purple-700';

                  return (
                    <label
                      key={src.id}
                      className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                        selectedSourceId === src.id
                          ? 'border-emerald-600 bg-emerald-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-3 min-w-0">
                        <input
                          type="radio"
                          name="paymentSource"
                          value={src.id}
                          checked={selectedSourceId === src.id}
                          onChange={() => setSelectedSourceId(src.id)}
                          className="accent-emerald-600 shrink-0"
                        />
                        <div className={`p-2 rounded-lg border shrink-0 ${iconBg}`}>
                          <CategoryIcon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0 text-center">
                          <span className="text-xs font-bold text-slate-900 block truncate">
                            {src.code} · {src.name}
                          </span>
                          <span className="text-[11px] font-mono tabular-nums text-slate-500 block">
                            Held: {src.units.toLocaleString(undefined, { maximumFractionDigits: src.category === 'crypto' ? 4 : 2 })} {src.code} (${src.usdValue.toLocaleString(undefined, { maximumFractionDigits: 2 })})
                          </span>
                        </div>
                      </div>
                      <div className="text-center shrink-0 sm:ml-2 font-mono tabular-nums">
                        <span className={`text-[11px] font-bold block ${hasEnough ? 'text-emerald-700' : 'text-amber-600'}`}>
                          -{neededUnits.toLocaleString(undefined, { maximumFractionDigits: src.category === 'crypto' ? 4 : 2 })} {src.code}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {hasEnough ? 'Sufficient (incl. fee)' : 'Partial / Low'}
                        </span>
                      </div>
                    </label>
                  );
                })}

                {/* Verified Crypto Wallets */}
                {effectiveCryptos.map((wallet) => {
                  const id = `wallet-${wallet.address.toLowerCase()}`;
                  return (
                    <label
                      key={wallet.address}
                      className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                        selectedSourceId === id
                          ? 'border-emerald-600 bg-emerald-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-3">
                        <input
                          type="radio"
                          name="paymentSource"
                          value={id}
                          checked={selectedSourceId === id}
                          onChange={() => setSelectedSourceId(id)}
                          className="accent-emerald-600"
                        />
                        <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-700">
                          <Wallet className="w-4 h-4" />
                        </div>
                        <div className="text-center">
                          <span className="text-xs font-bold text-slate-900 block">
                            {wallet.label}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">
                            {wallet.address.slice(0, 8)}...{wallet.address.slice(-6)} · {wallet.network}
                          </span>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-700 font-semibold">
                        Web3 Wallet
                      </span>
                    </label>
                  );
                })}
              </div>
            )}
          </div>

          {paymentAmount > 0 && selectedSourceId && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs font-mono">
              <div className="flex items-center justify-between text-slate-600">
                <span>Debt Principal Payment</span>
                <span>${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex items-center justify-between text-slate-600">
                <span>{feeDescriptionLabel}</span>
                <span className={processingFeeUSD > 0 ? 'text-amber-700 font-bold' : 'text-emerald-700 font-semibold'}>
                  {processingFeeUSD > 0 ? `+$${processingFeeUSD.toFixed(2)}` : '$0.00 (Free)'}
                </span>
              </div>
              <div className="pt-1.5 border-t border-slate-200 flex items-center justify-between text-slate-900 font-bold text-sm">
                <span>Total Charged</span>
                <span>${totalChargedUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD</span>
              </div>
            </div>
          )}

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center gap-2 text-[11px] text-slate-600 text-center">
            <Lock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>
              External Stripe charges preserve your Asset Inventory balances; internal currency payments convert and deduct exact units atomically.
            </span>
          </div>

          <div className="flex items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing || paymentAmount <= 0 || !selectedSourceId}
              className="flex-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Payment...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Pay Total ${totalChargedUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title="Confirm Debt Payment"
        message={`Authorize a total charge of $${totalChargedUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD ($${paymentAmount.toFixed(2)} toward debt${processingFeeUSD > 0 ? ` + $${processingFeeUSD.toFixed(2)} fee` : ''}) to reduce your outstanding liabilities?`}
        confirmText="Authorize Payment"
        type="warning"
      />
    </div>
  );
};
