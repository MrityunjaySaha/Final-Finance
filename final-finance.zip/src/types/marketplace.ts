export type ListingIntent = 'sell' | 'buy';
export type MarketplaceItemType = 'good' | 'service';
export type PrimaryTradeMode = 'currency' | 'barter';
export type SettlementMethod = 'barter' | 'final_coins' | 'stable_coins' | 'fiat' | 'crypto';
export type ListingStatus = 'draft' | 'uploaded' | 'active' | 'sold';
export type ListingVisibility = 'public' | 'friends' | 'only_me' | 'custom_group';

export interface MediaItem {
  id: string;
  url: string;
  type: 'image' | 'video';
  name?: string;
  size?: number;
}

export interface MarketplaceListing {
  id: string;
  userId: string;
  creatorName: string;
  creatorHandle: string;
  creatorAvatar?: string;
  listingIntent: ListingIntent; // 'sell' (Offering/Selling) vs 'buy' (Seeking/Buying/Request)
  itemType: MarketplaceItemType; // 'good' vs 'service'
  primaryTradeMode: PrimaryTradeMode; // 'currency' (Primary Currency/Cash/Token trade) vs 'barter' (Primary Item/Service Barter)
  title: string;
  category: string;
  description: string;
  status: ListingStatus;

  // Privacy and audience visibility controls
  visibility?: ListingVisibility; // 'public' | 'friends' | 'only_me' | 'custom_group'
  allowedGroupIds?: string[]; // IDs of custom friend groups with access
  allowedGroupNames?: string[]; // Display names of groups for badges
  allowedUserIds?: string[]; // Specific friend user IDs
  
  // What currencies + barter the user is willing to accept (only what they accept)
  acceptedSettlements: SettlementMethod[];
  
  // Specific accepted currency tickers/symbols (e.g. ['USD', 'FNL', 'USDC', 'BTC'])
  acceptedCurrencyList?: string[];
  
  // Primary settlement currency when in currency mode
  primaryCurrency?: string;
  primaryPriceUSD?: number;

  // Cross-transactional terms
  crossTransactionalTerms?: {
    acceptSplitSettlements: boolean;
    splitPreferences?: string;
    customExchangeOffers?: string;
    openToCustomMix?: boolean;
  };

  // Settlement specific pricing
  barterTerms?: {
    desiredTrades: string;
    desiredExchangeType?: 'good' | 'service' | 'any';
    openToOffers: boolean;
    estimatedValueUSD?: number;
  };

  finalCoinsPricing?: {
    symbol: string;
    amount: number;
  };

  stableCoinsPricing?: {
    symbol: string;
    amount: number;
    network: string;
  };

  fiatPricing?: {
    currencyCode: string;
    amount: number;
  };

  cryptoPricing?: {
    symbol: string;
    amount: number;
    network: string;
  };

  // Goods fields
  quantity?: number;
  unitLabel?: string;
  condition?: 'Brand New' | 'Mint' | 'Refurbished' | 'Certified Rare' | 'Good' | 'Fair';
  location?: string;

  // Services fields
  availableUnits?: number;
  unitType?: 'Hours' | 'Sessions' | 'Consultations' | 'Deliverables' | 'Credits';
  turnaroundTime?: string;
  deliverables?: string;
  skills?: string[];

  // Media
  imageUrl?: string;
  videoUrl?: string;
  mediaList?: MediaItem[];
  tags: string[];
  createdAt?: string;
  likes?: number;
  isLiked?: boolean;
}
