import React, { useState, useRef, useEffect } from 'react';
import { 
  LogOut, 
  ChevronDown, 
  LayoutDashboard,
  Upload,
  QrCode,
  Users,
  MessageSquare,
  TrendingUp,
  Landmark,
  Settings,
  Target,
  ShieldCheck,
  Crown,
  ArrowRight,
  Check,
  Briefcase,
  Archive
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { signOut } from '../services/firebaseAuth';

interface UserDropdownProps {
  currentUser: AuthSession;
  onNavigate: (view: 'landing' | 'dashboard' | 'vaults' | 'marketplace' | 'community' | 'social' | 'messages' | 'stocks' | 'subsidies' | 'uploads' | 'qrcodes' | 'wallets' | 'asset_inventory' | 'settings' | 'ai_studio' | 'fundraising' | 'admin' | 'superadmin' | 'portfolio' | 'holdings') => void;
  onViewMyProfile?: () => void;
  onOpenAuthModal?: () => void;
  onSignOut: () => void;
  onOpenVerificationModal?: () => void;
}

export const UserDropdown: React.FC<UserDropdownProps> = ({
  currentUser,
  onNavigate,
  onSignOut,
  onOpenVerificationModal,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedHandle, setCopiedHandle] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const handleSignOut = async () => {
    await signOut();
    setIsOpen(false);
    onSignOut();
    onNavigate('landing');
  };

  const handleNavigate = (view: any) => {
    setIsOpen(false);
    onNavigate(view);
  };

  const handleCopyHandle = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(`@${currentUser.id}`);
    setCopiedHandle(true);
    setTimeout(() => setCopiedHandle(false), 1500);
  };

  const isSuperAdmin = currentUser.role === 'super_admin' || currentUser.email === 'ranmaanimaker@gmail.com';
  const isAdmin = currentUser.role === 'admin' || currentUser.role === 'super_admin' || currentUser.email === 'awesomedbz@gmail.com' || currentUser.email === 'ranmaanimaker@gmail.com';

  return (
    <>
      <div ref={dropdownRef} className="relative inline-block text-left">
        {/* Trigger Button with User Handle & Avatar */}
        <button
          id="user-account-dropdown-trigger"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="min-h-[40px] pl-2 pr-3 py-1.5 rounded-full bg-slate-100/90 hover:bg-slate-200/90 border border-slate-200 text-slate-900 flex items-center gap-2.5 transition-all cursor-pointer shadow-2xs group active:scale-[0.98]"
          aria-haspopup="true"
          aria-expanded={isOpen}
          title="Account Menu"
        >
          {/* Avatar */}
          <div className="relative">
            {currentUser.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-slate-300"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-serif font-bold">
                {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
              </div>
            )}
            {currentUser.isVerified !== false && (
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-white" />
            )}
          </div>

          {/* Handle and Name */}
          <div className="text-left hidden sm:block max-w-[130px]">
            <p className="text-xs font-bold text-slate-900 truncate leading-tight">
              {currentUser.name}
            </p>
            <p className="text-[10px] font-mono text-slate-500 truncate leading-tight">
              @{currentUser.id}
            </p>
          </div>

          <ChevronDown className={`w-3.5 h-3.5 text-slate-400 group-hover:text-slate-900 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Clean, Organized Dropdown Menu Panel */}
        {isOpen && (
          <div
            id="user-account-dropdown-menu"
            className="absolute left-0 top-full mt-2 w-80 max-h-[85vh] overflow-y-auto bg-white/95 backdrop-blur-xl border border-slate-200/90 rounded-3xl shadow-2xl z-[60] text-left py-2 divide-y divide-slate-100/80 animate-in fade-in zoom-in-95 duration-150 origin-top-left scrollbar-thin"
          >
            {/* Header: User Profile Card - Clicking redirects to Marketplace homepage */}
            <div 
              onClick={() => handleNavigate('marketplace')}
              className="p-4 bg-slate-50/80 hover:bg-amber-50/60 transition-colors cursor-pointer group"
              title="Go to Homepage (Marketplace)"
            >
              <div className="flex items-start gap-3">
                <div className="relative shrink-0">
                  {currentUser.avatarUrl ? (
                    <img
                      src={currentUser.avatarUrl}
                      alt={currentUser.name}
                      className="w-11 h-11 rounded-2xl object-cover border border-slate-200 shadow-2xs group-hover:ring-2 group-hover:ring-amber-500/50 transition-all"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-11 h-11 rounded-2xl bg-slate-900 group-hover:bg-amber-700 text-white flex items-center justify-center text-sm font-serif font-bold shadow-2xs transition-colors">
                      {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
                    </div>
                  )}
                  {currentUser.isVerified !== false && (
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-white flex items-center justify-center ring-2 ring-white" title="Verified Member">
                      <ShieldCheck className="w-2.5 h-2.5" />
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="font-bold text-sm text-slate-900 group-hover:text-amber-900 transition-colors truncate">
                      {currentUser.name}
                    </h4>
                    {currentUser.isVerified !== false ? (
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-900 shrink-0 border border-amber-200">
                        Verified
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setIsOpen(false);
                          if (onOpenVerificationModal) onOpenVerificationModal();
                        }}
                        className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-slate-200 hover:bg-amber-100 text-slate-700 hover:text-amber-900 transition-colors cursor-pointer shrink-0"
                      >
                        Get Verified
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 mt-0.5">
                    <button
                      type="button"
                      onClick={handleCopyHandle}
                      className="text-[11px] font-mono text-slate-500 hover:text-slate-800 transition-colors flex items-center gap-1 cursor-pointer truncate"
                      title="Click to copy handle"
                    >
                      <span>@{currentUser.id}</span>
                      {copiedHandle ? (
                        <Check className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                      ) : null}
                    </button>
                  </div>

                  <p className="text-[10px] text-slate-400 truncate mt-0.5">{currentUser.email}</p>
                </div>
              </div>
            </div>

            {/* Section: Administration (If Authorized) */}
            {(isSuperAdmin || isAdmin) && (
              <div className="py-2 px-2 space-y-1 bg-amber-50/40 text-left">
                <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-amber-900/70 font-mono text-left">
                  Administration
                </div>

                {isSuperAdmin && (
                  <button
                    id="dropdown-nav-superadmin"
                    type="button"
                    onClick={() => handleNavigate('superadmin')}
                    className="w-full px-3 py-2 rounded-xl flex items-center justify-between text-xs text-left bg-amber-500/10 text-amber-950 hover:bg-amber-500/20 transition-colors cursor-pointer font-bold border border-amber-300/80"
                  >
                    <div className="flex items-center gap-2.5 text-left">
                      <Crown className="w-4 h-4 text-amber-600 shrink-0" />
                      <span className="text-left">Superadmin Console</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                  </button>
                )}

                {isAdmin && (
                  <button
                    id="dropdown-nav-admin"
                    type="button"
                    onClick={() => handleNavigate('admin')}
                    className="w-full px-3 py-2 rounded-xl flex items-center justify-between text-xs text-left bg-blue-50/80 text-blue-950 hover:bg-blue-100 transition-colors cursor-pointer font-bold border border-blue-200"
                  >
                    <div className="flex items-center gap-2.5 text-left">
                      <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                      <span className="text-left">Admin Portal</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                  </button>
                )}
              </div>
            )}

            {/* Section: Workspace Hub */}
            <div className="py-2 px-2 space-y-0.5 text-left">
              <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono text-left">
                Workspace
              </div>

              <button
                id="dropdown-nav-dashboard"
                type="button"
                onClick={() => handleNavigate('dashboard')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <LayoutDashboard className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="text-left">Dashboard Overview</span>
              </button>

              <button
                id="dropdown-nav-uploads"
                type="button"
                onClick={() => handleNavigate('uploads')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <Upload className="w-4 h-4 text-blue-600 shrink-0" />
                <span className="text-left">My Uploads &amp; Drafts</span>
              </button>

              <button
                id="dropdown-nav-qrcodes"
                type="button"
                onClick={() => handleNavigate('qrcodes')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <QrCode className="w-4 h-4 text-indigo-600 shrink-0" />
                <span className="text-left">QR Codes</span>
              </button>
            </div>

            {/* Section: Financial & Markets */}
            <div className="py-2 px-2 space-y-0.5 text-left">
              <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono text-left">
                Finance &amp; Markets
              </div>

              <button
                id="dropdown-nav-stocks"
                type="button"
                onClick={() => handleNavigate('stocks')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <TrendingUp className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="text-left">Stock Market Exchange</span>
              </button>

              <button
                id="dropdown-nav-portfolio"
                type="button"
                onClick={() => handleNavigate('portfolio')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <Briefcase className="w-4 h-4 text-indigo-600 shrink-0" />
                <span className="text-left">Stock Portfolio</span>
              </button>

              <button
                id="dropdown-nav-subsidies"
                type="button"
                onClick={() => handleNavigate('subsidies')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <Landmark className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="text-left">UBI, Subsidy, &amp; Internal Banking</span>
              </button>

              <button
                id="dropdown-nav-fundraising"
                type="button"
                onClick={() => handleNavigate('fundraising')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <Target className="w-4 h-4 text-teal-600 shrink-0" />
                <span className="text-left">Fundraising &amp; Charity</span>
              </button>
            </div>

            {/* Section: Community & Messages */}
            <div className="py-2 px-2 space-y-0.5 text-left">
              <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono text-left">
                Connect
              </div>

              <button
                id="dropdown-nav-social"
                type="button"
                onClick={() => handleNavigate('social')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <Users className="w-4 h-4 text-purple-600 shrink-0" />
                <span className="text-left">Community &amp; Social Feed</span>
              </button>

              <button
                id="dropdown-nav-messages"
                type="button"
                onClick={() => handleNavigate('messages')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <MessageSquare className="w-4 h-4 text-sky-600 shrink-0" />
                <span className="text-left">Direct Messages</span>
              </button>
            </div>

            {/* Section: Settings & Sign Out */}
            <div className="py-2 px-2 space-y-0.5 text-left">
              <button
                id="dropdown-nav-settings"
                type="button"
                onClick={() => handleNavigate('settings')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer font-medium"
              >
                <Settings className="w-4 h-4 text-slate-600 shrink-0" />
                <span className="text-left">Account &amp; Security Settings</span>
              </button>

              <button
                id="dropdown-signout-btn"
                type="button"
                onClick={handleSignOut}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer font-semibold"
              >
                <LogOut className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="text-left">Sign Out</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
