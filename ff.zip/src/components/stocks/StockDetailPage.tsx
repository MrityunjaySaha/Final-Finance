import React, { useMemo, useState, useEffect } from 'react';
import { StockItem, StockOrder, StockPosition, StockMarketWay, DerivativeType, StockNewsItem } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { AlpacaOptionsChain } from './AlpacaOptionsChain';
import { StockInceptionChart } from './StockInceptionChart';
import {
  DEFAULT_INITIAL_STOCK_ORDERS,
  getAllCombinedStockNews,
  IPO_NEWS_UPDATED_EVENT,
  getStoredIPORequests
} from '../../data/stocksData';
import { formatStockPrice, formatStockMarketCap, formatStockAmount } from '../../utils/stockCurrencyFormatter';
import {
  ArrowLeft,
  ChevronRight,
  Star,
  User,
  CheckCircle2,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  BarChart3,
  Building2,
  Coins,
  Globe,
  Newspaper,
  Clock,
  Layers,
  Zap,
  FileText,
  Download,
  Image as ImageIcon,
  Video,
  Upload,
  Plus,
  Trash2,
  X,
  AlertCircle,
  Eye,
  Twitter,
  Hash,
  Heart,
  Repeat2,
  MessageCircle,
  Bookmark,
  Check,
  Share2
} from 'lucide-react';
import {
  GeneralStockMediaItem,
  getGeneralStockMedia,
  saveGeneralStockMedia,
  deleteGeneralStockMedia,
  readFileAsDataUrl,
  STOCK_GENERAL_MEDIA_UPDATED_EVENT
} from '../../utils/stockMediaStorage';
import { Tweet } from '../../types/tweet';
import {
  getStoredTweets,
  toggleTweetLike,
  toggleTweetRetweet,
  toggleTweetBookmark,
  voteInTweetPoll,
  TWEETS_UPDATED_EVENT
} from '../../services/tweetingService';
import { areUsersBlockedEitherWay, isUserBlockedByTarget } from '../../services/socialService';

interface StockDetailPageProps {
  stock: StockItem;
  stocks: StockItem[];
  watchlist: string[];
  positions: StockPosition[];
  orders?: StockOrder[];
  currentUser?: AuthSession | null;
  selectedMarketWay: StockMarketWay | 'all' | 'social' | 'options' | 'favorites';
  activeMarketTitle?: string;
  portfolioReturnLabel?: string;
  onBackToPortfolioTab?: () => void;
  onBackToMarkets: () => void;
  onSelectStock: (stock: StockItem) => void;
  onToggleWatchlist: (ticker: string) => void;
  onOpenQuickTrade: (stock: StockItem, side: 'buy' | 'sell', initialDerivative?: DerivativeType) => void;
  onOpenAuthModal?: () => void;
  onOrderExecuted?: (order: any) => void;
}

const PERSONAL_STOCK_TICKERS = new Set([
  'ALEX',
  'ELEN',
  'VANC',
  'SLIN',
  'KHAL',
  'SATO',
  'SATOSHI',
  'STRL',
  'STERL',
]);

export const StockDetailPage: React.FC<StockDetailPageProps> = ({
  stock,
  watchlist,
  positions,
  orders,
  currentUser,
  selectedMarketWay,
  activeMarketTitle,
  portfolioReturnLabel,
  onBackToPortfolioTab,
  onBackToMarkets,
  onToggleWatchlist,
  onOpenQuickTrade,
}) => {
  const [copiedShare, setCopiedShare] = useState(false);

  const fullStockShareUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}${window.location.pathname}?stock=${encodeURIComponent(stock.ticker)}`
      : `?stock=${encodeURIComponent(stock.ticker)}`;

  const handleShareStock = async () => {
    try {
      await navigator.clipboard?.writeText(fullStockShareUrl);
    } catch {}
    try {
      if (navigator.share) {
        await navigator.share({ url: fullStockShareUrl });
      }
    } catch {}
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  const isPersonalStock =
    stock.issuanceType === 'personal' ||
    stock.assetCategory === 'personal' ||
    PERSONAL_STOCK_TICKERS.has(stock.ticker.toUpperCase()) ||
    Boolean(stock.name && stock.name.toLowerCase().includes('human equity'));

  const getMarketBadgeUI = (item: StockItem) => {
    switch (item.marketType) {
      case 'final':
        return isPersonalStock
          ? {
              label: 'Personal Stock',
              coin: (item.issuanceCoinSymbol || `$${item.ticker}`).replace(/-FNL/gi, ''),
              bg: 'bg-purple-100 text-purple-900 border-purple-300',
              icon: User,
            }
          : {
              label: 'Business Stock',
              coin: (item.issuanceCoinSymbol || `$${item.ticker}`).replace(/-FNL/gi, ''),
              bg: 'bg-blue-100 text-blue-900 border-blue-300',
              icon: Building2,
            };
      case 'stable':
        return { label: 'Stable Stock', coin: '$USDC', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300', icon: ShieldCheck };
      case 'fiat':
        return { label: 'Fiat Stock', coin: '$USD', bg: 'bg-indigo-100 text-indigo-900 border-indigo-300', icon: Building2 };
      case 'crypto':
        return { label: 'Crypto Stock', coin: '$BTC', bg: 'bg-purple-100 text-purple-900 border-purple-300', icon: Coins };
      case 'global':
        return { label: 'Global Asset', coin: 'Alpaca', bg: 'bg-sky-100 text-sky-900 border-sky-300', icon: Globe };
      default:
        return isPersonalStock
          ? { label: 'Personal Stock', coin: (item.issuanceCoinSymbol || `$${item.ticker}`).replace(/-FNL/gi, ''), bg: 'bg-purple-100 text-purple-900 border-purple-300', icon: User }
          : { label: 'Business Stock', coin: (item.issuanceCoinSymbol || `$${item.ticker}`).replace(/-FNL/gi, ''), bg: 'bg-blue-100 text-blue-900 border-blue-300', icon: Building2 };
    }
  };

  const badge = getMarketBadgeUI(stock);
  const isPos = stock.changeUSD >= 0;
  const tickerUpper = stock.ticker.toUpperCase().replace(/-FNL$/i, '');
  const userPosition = positions.find((p) => p.ticker.toUpperCase() === tickerUpper);
  const isFollowed = watchlist.some((t) => t.toUpperCase() === tickerUpper);

  // Resolve tradable Final Currency (all Final Currencies are 1:1 equal)
  const isFinalMarket = stock.marketType === 'final' || !stock.marketType;
  const cleanIssuanceSymbol = stock.issuanceCoinSymbol?.replace(/^\$/, '').replace(/-FNL$/i, '').trim();
  const primaryTradableCurrency = isFinalMarket
    ? cleanIssuanceSymbol
      ? `$${cleanIssuanceSymbol}`
      : `$${tickerUpper}`
    : badge.coin;
  const stockSpecificFinalCoin = isFinalMarket ? `$${tickerUpper}` : null;
  const tradableCurrencyDisplay = primaryTradableCurrency;

  // Compute live shares + held options & futures for this stock
  const sharesOwned = userPosition?.shares ?? 0;
  const avgCost = userPosition?.avgCostUSD ?? 0;
  const liveSharesValue = Number((sharesOwned * stock.price).toFixed(2));
  const sharesCostBasis = Number((sharesOwned * avgCost).toFixed(2));
  const sharesGain = sharesOwned > 0 ? Number((liveSharesValue - sharesCostBasis).toFixed(2)) : 0;
  const sharesGainPct = sharesCostBasis > 0 ? Number(((sharesGain / sharesCostBasis) * 100).toFixed(2)) : 0;

  const { heldOptions, heldFutures, optionsValue, futuresValue, totalPositionValue } = useMemo(() => {
    const rawList = orders && orders.length > 0 ? orders : DEFAULT_INITIAL_STOCK_ORDERS;
    const sanitized = rawList.map((ord) => {
      const t = (ord.ticker || '').toUpperCase();
      if (t === 'AAPL') {
        return { ...ord, ticker: 'ALEX', strikePrice: 32.0, sector: 'Sovereign Reserves' as const };
      }
      if (t === 'TSLA') {
        return { ...ord, ticker: 'ELEN', strikePrice: 28.0, sector: 'Sovereign Reserves' as const };
      }
      if (t === 'NVDA') {
        return { ...ord, ticker: 'HYPR', sector: 'Energy & Aerospace' as const };
      }
      if (ord.stockName && ord.stockName.includes('₣')) {
        return { ...ord, stockName: ord.stockName.replace(/₣/g, '') };
      }
      return ord;
    });

    const uniqueById = Array.from(new Map(sanitized.map((o) => [o.id, o])).values());
    const tickerDerivatives = uniqueById.filter(
      (ord) =>
        (ord.ticker || '').toUpperCase() === tickerUpper &&
        ord.derivativeType &&
        ord.derivativeType !== 'spot' &&
        ord.status !== 'cancelled'
    );

    const opts = tickerDerivatives.filter(
      (o) => o.derivativeType === 'call_option' || o.derivativeType === 'put_option'
    );
    const futs = tickerDerivatives.filter(
      (o) => o.derivativeType === 'futures_long' || o.derivativeType === 'futures_short'
    );

    const optVal = Number(opts.reduce((sum, o) => sum + (Number(o.totalUSD) || 0), 0).toFixed(2));
    const futVal = Number(futs.reduce((sum, o) => sum + (Number(o.totalUSD) || 0), 0).toFixed(2));

    return {
      heldOptions: opts,
      heldFutures: futs,
      optionsValue: optVal,
      futuresValue: futVal,
      totalPositionValue: Number((liveSharesValue + optVal + futVal).toFixed(2)),
    };
  }, [orders, tickerUpper, liveSharesValue]);

  const hasAnyHoldings = sharesOwned > 0 || heldOptions.length > 0 || heldFutures.length > 0;

  const [allNews, setAllNews] = useState<StockNewsItem[]>(() => getAllCombinedStockNews());

  useEffect(() => {
    const syncNews = () => setAllNews(getAllCombinedStockNews());
    window.addEventListener(IPO_NEWS_UPDATED_EVENT, syncNews);
    window.addEventListener('storage', syncNews);
    return () => {
      window.removeEventListener(IPO_NEWS_UPDATED_EVENT, syncNews);
      window.removeEventListener('storage', syncNews);
    };
  }, []);

  // Strictly match news related ONLY to this particular stock
  const relatedNews = allNews.filter((item) =>
    item.tickers?.some((t) => t.toUpperCase() === tickerUpper) ||
    item.title.toUpperCase().includes(tickerUpper) ||
    (stock.issuerName && item.summary?.toLowerCase().includes(stock.issuerName.toLowerCase()))
  ).slice(0, 8);

  const [activeNewsTab, setActiveNewsTab] = useState<'news' | 'media' | 'tweets'>('news');
  const [selectedTweetHash, setSelectedTweetHash] = useState<string | null>(null);
  const [allTweets, setAllTweets] = useState<Tweet[]>(() => getStoredTweets());
  const [generalMedia, setGeneralMedia] = useState<GeneralStockMediaItem[]>(() => getGeneralStockMedia(stock.ticker));
  const [previewMedia, setPreviewMedia] = useState<{
    type: 'photo' | 'video';
    url: string;
    title: string;
    uploader?: string;
    timestamp?: string;
  } | null>(null);

  useEffect(() => {
    const syncMedia = () => setGeneralMedia(getGeneralStockMedia(stock.ticker));
    const syncTweets = () => setAllTweets(getStoredTweets());
    window.addEventListener(STOCK_GENERAL_MEDIA_UPDATED_EVENT, syncMedia);
    window.addEventListener(TWEETS_UPDATED_EVENT, syncTweets);
    window.addEventListener('storage', syncMedia);
    window.addEventListener('storage', syncTweets);
    return () => {
      window.removeEventListener(STOCK_GENERAL_MEDIA_UPDATED_EVENT, syncMedia);
      window.removeEventListener(TWEETS_UPDATED_EVENT, syncTweets);
      window.removeEventListener('storage', syncMedia);
      window.removeEventListener('storage', syncTweets);
    };
  }, [stock.ticker]);

  const viewerId = currentUser?.uid || currentUser?.id || 'guest_user';
  const viewerHandle = (currentUser?.handle || currentUser?.id || '').replace(/^@/, '');

  const taggedTweets = useMemo(() => {
    const cleanNameTag = stock.name.replace(/[^a-zA-Z0-9_]/g, '').toLowerCase();
    const tagRegex = new RegExp(`(^|\\s)[#$]${tickerUpper}\\b`, 'i');

    return allTweets.filter((t) => {
      if (
        (viewerId && (areUsersBlockedEitherWay(viewerId, t.authorId) || isUserBlockedByTarget(viewerId, t.authorId))) ||
        (viewerHandle && (areUsersBlockedEitherWay(viewerHandle, t.authorHandle) || isUserBlockedByTarget(viewerHandle, t.authorHandle)))
      ) {
        return false;
      }

      const hasTicker = t.tickers?.some((tk) => tk.toUpperCase() === tickerUpper);
      const hasTickerHash = t.hashtags?.some(
        (h) => h.toUpperCase() === tickerUpper || (cleanNameTag && h.toLowerCase() === cleanNameTag)
      );
      const hasInlineTag = tagRegex.test(t.content);
      return Boolean(hasTicker || hasTickerHash || hasInlineTag);
    });
  }, [allTweets, tickerUpper, stock.name, viewerId, viewerHandle]);

  const taggedTweetHashes = useMemo(() => {
    const counts = new Map<string, number>();
    taggedTweets.forEach((t) => {
      t.hashtags.forEach((h) => {
        const existing = Array.from(counts.keys()).find((k) => k.toLowerCase() === h.toLowerCase());
        const key = existing || h;
        counts.set(key, (counts.get(key) || 0) + 1);
      });
    });
    return Array.from(counts.entries())
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count);
  }, [taggedTweets]);

  const displayedTaggedTweets = useMemo(() => {
    if (!selectedTweetHash) return taggedTweets;
    const target = selectedTweetHash.toLowerCase();
    return taggedTweets.filter((t) => t.hashtags.some((h) => h.toLowerCase() === target));
  }, [taggedTweets, selectedTweetHash]);

  // Unified list of all photos & videos for this final stock
  const stockMediaItems = useMemo(() => {
    const list: Array<{
      id: string;
      type: 'photo' | 'video';
      url: string;
      name: string;
      uploaderName?: string;
      timestamp?: string;
    }> = [];
    const seenUrls = new Set<string>();

    const add = (item: {
      id: string;
      type: 'photo' | 'video';
      url: string;
      name: string;
      uploaderName?: string;
      timestamp?: string;
    }) => {
      if (!item.url || seenUrls.has(item.url)) return;
      seenUrls.add(item.url);
      list.push(item);
    };

    // 1. General media items uploaded/stored for this stock
    generalMedia.forEach((m) => {
      add({
        id: m.id,
        type: m.type,
        url: m.url,
        name: m.name,
        uploaderName: m.uploaderName || 'Verified Shareholder',
        timestamp: m.timestamp
      });
    });

    // 2. Photos & videos attached to IPO request / prospectus
    try {
      const ipos = getStoredIPORequests();
      const matchingIpo = ipos.find((i) => i.ticker?.toUpperCase() === tickerUpper);
      if (matchingIpo) {
        matchingIpo.mediaGallery?.forEach((med) => {
          add({
            id: med.id,
            type: med.type,
            url: med.url,
            name: med.title || `${stock.ticker} Prospectus Filing`,
            uploaderName: matchingIpo.issuerName,
            timestamp: 'Official IPO Prospectus'
          });
        });
        matchingIpo.personalDetails?.mediaGallery?.forEach((med) => {
          add({
            id: med.id,
            type: med.type,
            url: med.url,
            name: med.title || `${stock.ticker} Executive Identity`,
            uploaderName: matchingIpo.issuerName,
            timestamp: 'Identity Filing'
          });
        });
        matchingIpo.businessDetails?.mediaGallery?.forEach((med) => {
          add({
            id: med.id,
            type: med.type,
            url: med.url,
            name: med.title || `${stock.ticker} Corporate Media`,
            uploaderName: matchingIpo.issuerName,
            timestamp: 'Corporate Filing'
          });
        });
      }
    } catch {
      // ignore
    }

    // 3. Photos & videos attached to news and issuer reports for this stock
    relatedNews.forEach((n) => {
      n.photos?.forEach((p) => {
        add({
          id: p.id,
          type: 'photo',
          url: p.url,
          name: p.name || n.title,
          uploaderName: n.source,
          timestamp: n.time
        });
      });
      n.videos?.forEach((v) => {
        add({
          id: v.id,
          type: 'video',
          url: v.url,
          name: v.name || n.title,
          uploaderName: n.source,
          timestamp: n.time
        });
      });
    });

    return list;
  }, [generalMedia, relatedNews, tickerUpper, stock.ticker]);

  const marketReturnTargetLabel =
    stock.marketType === 'final' || !stock.marketType
      ? 'Final Stock Market'
      : selectedMarketWay === 'all'
      ? 'All Equities'
      : activeMarketTitle || 'Stock Markets';

  return (
    <div className="max-w-4xl mx-auto space-y-4 text-center">
      {/* 1. Navigation & Controls Bar */}
      <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col items-center justify-center gap-2.5 text-center">
        <div className="flex flex-col items-center justify-center gap-2 w-full">
          {onBackToPortfolioTab && portfolioReturnLabel ? (
            <button
              type="button"
              onClick={onBackToPortfolioTab}
              className={`px-4 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs ${
                portfolioReturnLabel === 'Back to Tweeting'
                  ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-200'
                  : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border-indigo-200'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{portfolioReturnLabel}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onBackToMarkets}
              className="px-4 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to {marketReturnTargetLabel}</span>
            </button>
          )}

          <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 flex-wrap">
            <ChevronRight className="w-3 h-3 text-slate-300" />
            <span className="text-slate-600 font-medium">{badge.label}</span>
            <ChevronRight className="w-3 h-3 text-slate-300" />
            <span className="text-slate-900 font-mono font-bold">${stock.ticker}</span>
          </div>
        </div>

        {/* Action Controls: Favorite + Trade Options */}
        <div className="flex items-center justify-center gap-2 flex-wrap w-full">
          <button
            type="button"
            onClick={() => onToggleWatchlist(stock.ticker)}
            className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              isFollowed
                ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-2xs'
                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <Star className={`w-3.5 h-3.5 ${isFollowed ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`} />
            <span>{isFollowed ? 'Favorited' : 'Add to Favorites'}</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenQuickTrade(stock, 'buy', 'call_option')}
            className="px-4 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Trade Options</span>
          </button>
        </div>

        {/* Share Stock Link Button Centered Directly Below Favorited / Trade Options */}
        <div className="flex items-center justify-center w-full">
          <button
            type="button"
            onClick={handleShareStock}
            title={fullStockShareUrl}
            className="px-4 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-1.5 shadow-2xs"
          >
            {copiedShare ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700">Full Link Copied</span>
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5 text-slate-500" />
                <span>Share</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. Compact Hero Overview & Core Market Data */}
      <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4 text-center">
        <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-slate-100">
          <div className="w-12 h-12 rounded-2xl bg-slate-50 text-slate-800 flex items-center justify-center font-mono font-bold text-sm shadow-sm shrink-0 border border-slate-200">
            {stock.ticker.slice(0, 4)}
          </div>
          <div className="text-center">
            <h1 className="text-xl sm:text-2xl font-mono font-extrabold text-slate-900 tracking-tight leading-none mb-1">
              ${stock.ticker}
            </h1>
            <h2 className="text-sm sm:text-base font-serif font-bold text-slate-700 tracking-tight leading-tight">
              {stock.name}
            </h2>
            <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold border border-slate-200">
                {stock.exchange}
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold border border-slate-200">
                {stock.sector}
              </span>
              <span className={`text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full border inline-flex items-center gap-1 ${badge.bg}`}>
                <badge.icon className="w-3 h-3" />
                <span>{badge.label}</span>
              </span>
              <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full border bg-amber-50 text-amber-900 border-amber-300 inline-flex items-center gap-1">
                <Coins className="w-3 h-3 text-amber-600" />
                <span>Tradable Currency: {tradableCurrencyDisplay}</span>
              </span>
            </div>
            {hasAnyHoldings && (
              <div className="mt-2 inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex-wrap justify-center">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  Owned: {sharesOwned.toLocaleString()} Shares
                  {heldOptions.length > 0 ? ` • ${heldOptions.length} Option${heldOptions.length === 1 ? '' : 's'}` : ''}
                  {heldFutures.length > 0 ? ` • ${heldFutures.length} Future${heldFutures.length === 1 ? '' : 's'}` : ''}
                </span>
              </div>
            )}
          </div>

          <div className="text-center pt-1">
            <div className="flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
              <span className="font-mono font-bold text-2xl sm:text-3xl text-slate-900 tracking-tight">
                {formatStockPrice(stock.price, stock, false)}
              </span>
            </div>
            <div className={`text-xs sm:text-sm font-mono font-bold flex items-center justify-center gap-1 mt-0.5 ${
              isPos ? 'text-emerald-600' : 'text-rose-600'
            }`}>
              {isPos ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              <span>
                {isPos ? '+' : ''}{formatStockAmount(stock.changeUSD, stock, false)} ({isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%)
              </span>
              <span className="text-slate-400 font-normal text-[11px] ml-1">Today</span>
            </div>
          </div>
        </div>

        {/* Essential Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Market Cap</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{formatStockMarketCap(stock)}</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">24h Volume</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.volume || stock.avgVolume || 'N/A'}</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Day Range</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">
              {formatStockPrice(stock.low24h ?? (stock.price * 0.98), stock, false)} - {formatStockPrice(stock.high24h ?? (stock.price * 1.02), stock, false)}
            </span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">52W Range</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">
              {formatStockPrice(stock.fiftyTwoWeekLow ?? (stock.price * 0.75), stock, false)} - {formatStockPrice(stock.fiftyTwoWeekHigh ?? (stock.price * 1.25), stock, false)}
            </span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">P/E Ratio</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.peRatio ? `${stock.peRatio}x` : 'N/A'}</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Div Yield</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.dividendYield || '0.00%'}</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Beta</span>
            <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.beta ? stock.beta.toFixed(2) : '1.00'}</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Target</span>
            <span className="font-mono font-bold text-xs text-emerald-600 block mt-0.5">
              {formatStockPrice(stock.analystTargetUSD || stock.price * 1.1, stock, false)}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Active Position (Shares, Options, Futures & Live Total Value) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-emerald-50/60 border border-emerald-200 shadow-2xs space-y-4 text-center">
        <div className="flex flex-wrap items-center justify-center gap-2 pb-2.5 border-b border-emerald-200/60">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span className="font-serif font-bold text-sm text-emerald-950">Your Active Position</span>
          <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
            {sharesOwned.toLocaleString()} Shares
          </span>
          <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-sky-100 text-sky-800">
            {heldOptions.length} Option{heldOptions.length === 1 ? '' : 's'}
          </span>
          <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
            {heldFutures.length} Future{heldFutures.length === 1 ? '' : 's'}
          </span>
        </div>

        {/* Summary Metrics Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-2.5 rounded-2xl bg-white/80 border border-emerald-100">
            <span className="text-emerald-700/80 block text-[11px]">Shares Owned</span>
            <span className="font-mono font-bold text-slate-900 text-sm block mt-0.5">
              {sharesOwned.toLocaleString()}
            </span>
            <span className="font-mono text-[10px] text-slate-500 block">
              Value: {liveSharesValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="p-2.5 rounded-2xl bg-white/80 border border-emerald-100">
            <span className="text-emerald-700/80 block text-[11px]">Avg Cost</span>
            <span className="font-mono font-bold text-slate-900 text-sm block mt-0.5">
              {sharesOwned > 0 ? avgCost.toFixed(2) : '0.00'}
            </span>
            <span className="font-mono text-[10px] text-slate-500 block">
              Tradable: {primaryTradableCurrency}
            </span>
          </div>
          <div className="p-2.5 rounded-2xl bg-white/80 border border-emerald-100">
            <span className="text-emerald-700/80 block text-[11px]">Total Value</span>
            <span className="font-mono font-bold text-slate-900 text-sm block mt-0.5">
              {totalPositionValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="font-mono text-[10px] text-slate-500 block">
              {optionsValue + futuresValue > 0
                ? `Shares + Derivatives`
                : `${primaryTradableCurrency}`}
            </span>
          </div>
          <div className="p-2.5 rounded-2xl bg-white/80 border border-emerald-100">
            <span className="text-emerald-700/80 block text-[11px]">Shares Return</span>
            <span className={`font-mono font-bold text-sm block mt-0.5 ${sharesGain >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
              {sharesGain >= 0 ? '+' : ''}{sharesGain.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className={`font-mono text-[10px] block ${sharesGainPct >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
              ({sharesGainPct >= 0 ? '+' : ''}{sharesGainPct.toFixed(2)}%)
            </span>
          </div>
        </div>

        {/* Options & Futures Held for this Final Stock */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
          {/* Options Held */}
          <div className="p-3 rounded-2xl bg-white border border-emerald-100 space-y-2 text-center">
            <div className="flex items-center justify-center gap-1.5 font-bold text-slate-800 pb-1.5 border-b border-slate-100">
              <Layers className="w-3.5 h-3.5 text-sky-600" />
              <span>Options Held ({heldOptions.length})</span>
            </div>
            {heldOptions.length === 0 ? (
              <p className="text-[11px] text-slate-400 py-1">
                No call or put options held for ${stock.ticker}.
              </p>
            ) : (
              <div className="space-y-2">
                {heldOptions.map((opt, idx) => {
                  const isCall = opt.derivativeType === 'call_option';
                  return (
                    <div
                      key={`${opt.id}-${idx}`}
                      className="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-1 text-center"
                    >
                      <div className="flex items-center justify-center gap-1.5 flex-wrap">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                            isCall
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : 'bg-rose-50 text-rose-800 border-rose-200'
                          }`}
                        >
                          {isCall ? 'Call Option' : 'Put Option'}
                        </span>
                        <span className="font-mono font-bold text-slate-900">
                          {opt.shares.toLocaleString()} Contracts
                        </span>
                      </div>
                      <div className="text-[10px] font-mono text-slate-500 flex items-center justify-center gap-2 flex-wrap">
                        <span>Strike: {(opt.strikePrice ?? opt.price).toFixed(2)}</span>
                        {opt.expiryDate && <span>• Exp: {opt.expiryDate}</span>}
                      </div>
                      <div className="text-[11px] font-mono font-bold text-slate-800">
                        Value: {(Number(opt.totalUSD) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {opt.paymentSource?.label || primaryTradableCurrency}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Futures Held */}
          <div className="p-3 rounded-2xl bg-white border border-emerald-100 space-y-2 text-center">
            <div className="flex items-center justify-center gap-1.5 font-bold text-slate-800 pb-1.5 border-b border-slate-100">
              <Zap className="w-3.5 h-3.5 text-indigo-600" />
              <span>Futures Held ({heldFutures.length})</span>
            </div>
            {heldFutures.length === 0 ? (
              <p className="text-[11px] text-slate-400 py-1">
                No futures contracts held for ${stock.ticker}.
              </p>
            ) : (
              <div className="space-y-2">
                {heldFutures.map((fut, idx) => {
                  const isLong = fut.derivativeType === 'futures_long';
                  return (
                    <div
                      key={`${fut.id}-${idx}`}
                      className="p-2 rounded-xl bg-slate-50 border border-slate-100 space-y-1 text-center"
                    >
                      <div className="flex items-center justify-center gap-1.5 flex-wrap">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                            isLong
                              ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                              : 'bg-amber-50 text-amber-900 border-amber-200'
                          }`}
                        >
                          {isLong ? 'Long Futures' : 'Short Futures'}
                        </span>
                        <span className="font-mono font-bold text-slate-900">
                          {fut.shares.toLocaleString()} Contracts
                        </span>
                      </div>
                      <div className="text-[10px] font-mono text-slate-500 flex items-center justify-center gap-2 flex-wrap">
                        <span>{fut.leverage || 10}x Leverage</span>
                        {fut.expiryDate && <span>• Exp: {fut.expiryDate}</span>}
                      </div>
                      <div className="text-[11px] font-mono font-bold text-slate-800">
                        Value: {(Number(fut.totalUSD) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {fut.paymentSource?.label || primaryTradableCurrency}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 4. Since Inception Price History Chart */}
      <StockInceptionChart stock={stock} currencyLabel={primaryTradableCurrency} />

      {/* 5. Concise About & Issuance Details */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3 text-center">
        <h3 className="font-serif font-bold text-sm text-slate-900">
          About {stock.name} (${stock.ticker})
        </h3>
        <p className="text-xs text-slate-600 leading-relaxed max-w-2xl mx-auto">
          {stock.description || `${stock.name} (${stock.ticker}) is a ${badge.label.toLowerCase()} in the ${stock.sector} sector.`}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-xs">
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Issuer / Leadership</span>
            <span className="font-semibold text-slate-800 mt-0.5 block">
              {stock.issuerName || stock.ceo || 'Executive Board'}
            </span>
          </div>
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Custody Node</span>
            <span className="font-mono font-bold text-slate-800 mt-0.5 block truncate">
              {(stock as any).custodyVaultNode || '0xFNL-NODE-7729'}
            </span>
          </div>
        </div>
      </div>

      {/* 5. Alpaca Options Chain (when applicable for Global/Fiat equities) */}
      {(stock.marketType === 'global' || stock.marketType === 'fiat') && (
        <div id="options-chain-section" className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4 scroll-mt-6 text-center">
          <div className="flex flex-col items-center justify-center gap-1 pb-3 border-b border-slate-100">
            <h2 className="font-serif font-bold text-base text-slate-900 flex items-center justify-center gap-2">
              <BarChart3 className="w-4 h-4 text-sky-600" />
              <span>Options Chain</span>
            </h2>
            <div className="flex items-center justify-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-tight">
              <Globe className="w-3 h-3" />
              <span>Live Alpaca Data</span>
            </div>
          </div>
          <AlpacaOptionsChain
            symbol={stock.ticker}
            onSelectContract={(c) => {
              onOpenQuickTrade(stock, 'buy', c.type === 'call' ? 'call_option' : 'put_option');
            }}
          />
        </div>
      )}

      {/* 6. Stock-Specific News, Media & Tweets (with Three Equal-Size Centered Tabs) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4 text-center">
        <div className="flex items-center justify-center gap-2 pb-2 border-b border-slate-100">
          <Newspaper className="w-4 h-4 text-amber-600" />
          <h3 className="font-serif font-bold text-sm text-slate-900">
            ${stock.ticker} News &amp; Issuer Updates
          </h3>
        </div>

        {/* Three Equal-Sized Centered Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pb-3 border-b border-slate-100">
          <button
            type="button"
            onClick={() => setActiveNewsTab('news')}
            className={`w-full min-h-[42px] px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 text-center ${
              activeNewsTab === 'news'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Newspaper className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">News &amp; Associated Media ({relatedNews.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveNewsTab('media')}
            className={`w-full min-h-[42px] px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 text-center ${
              activeNewsTab === 'media'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Media ({stockMediaItems.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveNewsTab('tweets')}
            className={`w-full min-h-[42px] px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 text-center ${
              activeNewsTab === 'tweets'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Twitter className={`w-3.5 h-3.5 -scale-x-100 -rotate-12 shrink-0 ${activeNewsTab === 'tweets' ? 'fill-white' : 'text-emerald-600'}`} />
            <span className="truncate">Tweets ({taggedTweets.length})</span>
          </button>
        </div>

        {activeNewsTab === 'news' ? (
          <div className="space-y-3 text-center">
            {relatedNews.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No official news updates reported for ${stock.ticker} yet.
              </div>
            ) : (
              relatedNews.map((item, idx) => (
                <div
                  key={`${item.id}-${idx}`}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2.5 text-center"
                >
                  <div className="flex items-center justify-center gap-2 text-[10px] font-mono text-slate-400 flex-wrap">
                    <span className="font-bold text-slate-600">{item.source}</span>
                    {item.category && (
                      <span className="px-1.5 py-0.5 rounded bg-white border border-slate-200 text-slate-600 font-semibold">
                        {item.category}
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {item.time}
                    </span>
                  </div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900">{item.title}</h4>
                  <p className="text-[11px] sm:text-xs text-slate-600 leading-relaxed whitespace-pre-line max-w-2xl mx-auto">
                    {item.bodyText || item.summary}
                  </p>

                  {item.photos && item.photos.length > 0 && (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 max-w-2xl mx-auto">
                      {item.photos.map((photo) => (
                        <button
                          key={photo.id}
                          type="button"
                          onClick={() => setPreviewMedia({
                            type: 'photo',
                            url: photo.url,
                            title: photo.name || item.title,
                            uploader: item.source,
                            timestamp: item.time
                          })}
                          className="w-full h-28 rounded-xl overflow-hidden border border-slate-200 shadow-2xs group/p cursor-pointer"
                          title={`View ${photo.name}`}
                        >
                          <img
                            src={photo.url}
                            alt={photo.name}
                            className="w-full h-full object-cover group-hover/p:scale-105 transition-transform"
                          />
                        </button>
                      ))}
                    </div>
                  )}

                  {item.videos && item.videos.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 max-w-2xl mx-auto">
                      {item.videos.map((vid) => (
                        <div key={vid.id} className="relative rounded-xl overflow-hidden bg-black border border-slate-200 shadow-2xs">
                          <video
                            src={vid.url}
                            controls
                            playsInline
                            className="w-full max-h-48 object-contain bg-black"
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  {item.documents && item.documents.length > 0 && (
                    <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                      {item.documents.map((doc) => (
                        <a
                          key={doc.id}
                          href={doc.url}
                          download={doc.name}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white border border-indigo-200 text-[11px] font-bold text-indigo-700 hover:bg-indigo-50 shadow-2xs"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span className="truncate max-w-[160px]">{doc.name}</span>
                          <Download className="w-3 h-3" />
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        ) : activeNewsTab === 'media' ? (
          <div className="space-y-4 py-2 text-center">
            <div className="space-y-1">
              <h4 className="font-serif font-bold text-xs sm:text-sm text-slate-900">
                Media Gallery for ${stock.ticker}
              </h4>
              <p className="text-[11px] text-slate-500 max-w-xl mx-auto">
                Photos, videos, and visual reports for {stock.name}. Click any image or video to view in full resolution.
              </p>
            </div>

            {stockMediaItems.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
                <ImageIcon className="w-8 h-8 text-slate-300 mx-auto" />
                <p>No photos or videos uploaded for ${stock.ticker} yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {stockMediaItems.map((m) => (
                  <div
                    key={m.id}
                    onClick={() => setPreviewMedia({
                      type: m.type,
                      url: m.url,
                      title: m.name,
                      uploader: m.uploaderName,
                      timestamp: m.timestamp
                    })}
                    className="rounded-2xl overflow-hidden border border-slate-200 bg-white shadow-2xs group relative cursor-pointer hover:border-amber-400 transition-all text-center"
                  >
                    <div className="relative w-full h-40 bg-slate-950 overflow-hidden flex items-center justify-center">
                      {m.type === 'video' ? (
                        <>
                          <video
                            src={m.url}
                            controls
                            playsInline
                            className="w-full h-full object-cover"
                            onClick={(e) => e.stopPropagation()}
                          />
                          <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 pointer-events-none">
                            <Video className="w-2.5 h-2.5 text-purple-400" />
                            <span>Video</span>
                          </div>
                        </>
                      ) : (
                        <>
                          <img
                            src={m.url}
                            alt={m.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1">
                            <ImageIcon className="w-2.5 h-2.5 text-blue-400" />
                            <span>Photo</span>
                          </div>
                        </>
                      )}
                    </div>
                    <div className="p-2.5 border-t border-slate-100 flex flex-col items-center justify-center gap-1 text-center">
                      <p className="font-bold text-xs text-slate-900 truncate max-w-full">{m.name}</p>
                      <div className="flex items-center justify-center gap-1.5">
                        <p className="text-[10px] text-slate-400 truncate">
                          {m.uploaderName ? `By ${m.uploaderName}` : 'Shareholder'} • {m.timestamp}
                        </p>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setPreviewMedia({
                              type: m.type,
                              url: m.url,
                              title: m.name,
                              uploader: m.uploaderName,
                              timestamp: m.timestamp
                            });
                          }}
                          className="p-1 rounded-lg text-slate-400 hover:text-amber-800 hover:bg-amber-50 cursor-pointer shrink-0 transition-colors"
                          title="View Full Media"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* ================= 3RD SECTION: TWEETS & HASHES TAGGING THIS STOCK ================= */
          <div className="space-y-4 py-2 text-center">
            <div className="space-y-1">
              <h4 className="font-serif font-bold text-xs sm:text-sm text-slate-900 flex items-center justify-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white inline-flex items-center justify-center">
                  <Twitter className="w-3.5 h-3.5 -scale-x-100 -rotate-12 fill-white" />
                </span>
                <span>Tweets &amp; Hashtags Mentioning ${stock.ticker}</span>
              </h4>
              <p className="text-[11px] text-slate-500 max-w-xl mx-auto">
                Real-time community tweets, cashtags (${tickerUpper}), and hashtags where {stock.name} has been tagged.
              </p>
            </div>

            {/* Tagged Hashtags & Cashtags Summary Bar */}
            <div className="p-3 rounded-2xl bg-emerald-50/50 border border-emerald-200/70 space-y-2 text-center">
              <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold text-emerald-900">
                <Hash className="w-3.5 h-3.5 text-emerald-600" />
                <span>Hashes &amp; Tags Associated with ${tickerUpper}</span>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setSelectedTweetHash(null)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-colors ${
                    !selectedTweetHash
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-700 hover:border-emerald-300'
                  }`}
                >
                  All (${tickerUpper} • {taggedTweets.length})
                </button>
                {taggedTweetHashes.map((item) => {
                  const isActive = selectedTweetHash?.toLowerCase() === item.tag.toLowerCase();
                  return (
                    <button
                      key={item.tag}
                      type="button"
                      onClick={() => setSelectedTweetHash(isActive ? null : item.tag)}
                      className={`px-2.5 py-1 rounded-full text-[11px] font-semibold cursor-pointer transition-colors ${
                        isActive
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'bg-white border border-emerald-200 text-emerald-800 hover:bg-emerald-100/70'
                      }`}
                    >
                      #{item.tag} ({item.count})
                    </button>
                  );
                })}
              </div>
            </div>

            {displayedTaggedTweets.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
                <div className="w-9 h-9 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <Twitter className="w-4 h-4 -scale-x-100 -rotate-12" />
                </div>
                <p className="font-semibold text-slate-700">
                  No tweets have tagged ${tickerUpper} or #{tickerUpper} yet.
                </p>
                <p className="text-[11px] text-slate-400 max-w-md mx-auto">
                  Post a tweet mentioning ${tickerUpper} or #{tickerUpper} in Social Interactions &rarr; Tweeting and it will appear right here.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-w-2xl mx-auto">
                {displayedTaggedTweets.map((t) => {
                  const isLiked = t.likedBy.includes(viewerId);
                  const isRetweeted = t.retweetedBy.includes(viewerId);
                  const isBookmarked = t.bookmarkedBy.includes(viewerId);
                  const userVotedOptionId = t.poll?.voterIds[viewerId];

                  return (
                    <div
                      key={t.id}
                      className="p-4 rounded-2xl bg-slate-50/70 border border-slate-200/80 space-y-3 text-center"
                    >
                      {/* Centered Tweet Author */}
                      <div className="flex flex-col items-center justify-center gap-1">
                        <img
                          src={t.authorAvatar}
                          alt={t.authorName}
                          className="w-9 h-9 rounded-full object-cover border border-slate-200"
                        />
                        <div className="flex items-center justify-center gap-1.5 flex-wrap text-xs">
                          <span className="font-bold text-slate-900">{t.authorName}</span>
                          {t.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                          <span className="text-slate-400 font-mono">@{t.authorHandle}</span>
                          <span className="text-slate-300">•</span>
                          <span className="text-slate-400">{t.timestamp}</span>
                        </div>
                      </div>

                      {/* Formatted Tweet Content */}
                      <p className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line max-w-xl mx-auto">
                        {t.content.split(/([@#$][a-zA-Z0-9_]+)/g).map((part, idx) => {
                          if (part.startsWith('#') && part.length > 1) {
                            const tag = part.slice(1);
                            return (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setSelectedTweetHash(selectedTweetHash === tag ? null : tag)}
                                className="text-emerald-700 hover:underline font-semibold cursor-pointer inline"
                              >
                                {part}
                              </button>
                            );
                          }
                          if (part.startsWith('$') && part.length > 1) {
                            return (
                              <span
                                key={idx}
                                className={`font-mono font-bold px-1 rounded inline ${
                                  part.slice(1).toUpperCase() === tickerUpper
                                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                    : 'bg-amber-50 text-amber-800'
                                }`}
                              >
                                {part.toUpperCase()}
                              </span>
                            );
                          }
                          if (part.startsWith('@') && part.length > 1) {
                            return (
                              <span key={idx} className="text-sky-600 font-semibold inline">
                                {part}
                              </span>
                            );
                          }
                          return <span key={idx}>{part}</span>;
                        })}
                      </p>

                      {/* Hashtags & Tickers Pills on Tweet */}
                      {(t.hashtags.length > 0 || (t.tickers && t.tickers.length > 0)) && (
                        <div className="flex flex-wrap items-center justify-center gap-1.5">
                          {t.tickers?.map((tk) => (
                            <span
                              key={`tk-${tk}`}
                              className="px-2 py-0.5 rounded-full bg-emerald-100/80 text-emerald-900 border border-emerald-200 text-[10px] font-mono font-bold"
                            >
                              ${tk}
                            </span>
                          ))}
                          {t.hashtags.map((h) => (
                            <button
                              key={`h-${h}`}
                              type="button"
                              onClick={() => setSelectedTweetHash(selectedTweetHash === h ? null : h)}
                              className="px-2 py-0.5 rounded-full bg-white border border-slate-200 hover:border-emerald-300 text-emerald-700 text-[10px] font-semibold cursor-pointer"
                            >
                              #{h}
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Attached Photos */}
                      {t.photos && t.photos.length > 0 && (
                        <div
                          className={`grid gap-2 rounded-2xl overflow-hidden border border-slate-200 max-w-lg mx-auto ${
                            t.photos.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                          }`}
                        >
                          {t.photos.map((pUrl, pIdx) => (
                            <button
                              key={pIdx}
                              type="button"
                              onClick={() =>
                                setPreviewMedia({
                                  type: 'photo',
                                  url: pUrl,
                                  title: t.content,
                                  uploader: t.authorName,
                                  timestamp: t.timestamp
                                })
                              }
                              className="w-full max-h-64 overflow-hidden bg-slate-900 cursor-pointer"
                            >
                              <img src={pUrl} alt={`Tweet media ${pIdx + 1}`} className="w-full h-full object-cover" />
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Attached Video */}
                      {t.video && (
                        <div className="rounded-2xl overflow-hidden bg-black border border-slate-200 max-w-lg mx-auto">
                          <video src={t.video} controls playsInline className="w-full max-h-60 object-contain" />
                        </div>
                      )}

                      {/* Poll inside Tweet */}
                      {t.poll && (
                        <div className="p-3 rounded-2xl bg-white border border-slate-200/80 space-y-2 max-w-md mx-auto">
                          {t.poll.options.map((opt) => {
                            const isVoted = userVotedOptionId === opt.id;
                            const pct = t.poll!.totalVotes > 0 ? Math.round((opt.votes / t.poll!.totalVotes) * 100) : 0;
                            return (
                              <button
                                key={opt.id}
                                type="button"
                                onClick={() => voteInTweetPoll(t.id, opt.id, viewerId)}
                                className={`w-full relative overflow-hidden rounded-xl p-2 text-xs font-semibold flex items-center justify-between text-left cursor-pointer border ${
                                  isVoted
                                    ? 'border-emerald-500 bg-emerald-50 text-emerald-950 font-bold'
                                    : 'border-slate-200 bg-slate-50 hover:border-slate-300 text-slate-800'
                                }`}
                              >
                                {userVotedOptionId && (
                                  <div
                                    className={`absolute inset-y-0 left-0 ${
                                      isVoted ? 'bg-emerald-200/50' : 'bg-slate-200/40'
                                    }`}
                                    style={{ width: `${pct}%` }}
                                  />
                                )}
                                <span className="relative z-10 flex items-center gap-1.5">
                                  {isVoted && <Check className="w-3 h-3 text-emerald-600" />}
                                  <span>{opt.text}</span>
                                </span>
                                {userVotedOptionId && (
                                  <span className="relative z-10 font-mono text-[10px] text-slate-600">
                                    {pct}% ({opt.votes})
                                  </span>
                                )}
                              </button>
                            );
                          })}
                          <p className="text-[10px] font-mono text-slate-400">
                            {t.poll.totalVotes} votes • {userVotedOptionId ? 'Vote recorded' : 'Tap to vote'}
                          </p>
                        </div>
                      )}

                      {/* Centered Interactive Actions */}
                      <div className="flex items-center justify-center gap-5 flex-wrap pt-2 border-t border-slate-200/70 text-slate-400 text-xs">
                        <span className="inline-flex items-center gap-1">
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span className="font-mono text-[11px]">{t.replies.length}</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleTweetRetweet(t.id, viewerId)}
                          className={`inline-flex items-center gap-1 hover:text-emerald-600 cursor-pointer ${
                            isRetweeted ? 'text-emerald-600 font-bold' : ''
                          }`}
                        >
                          <Repeat2 className="w-3.5 h-3.5" />
                          <span className="font-mono text-[11px]">{t.retweets}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleTweetLike(t.id, viewerId)}
                          className={`inline-flex items-center gap-1 hover:text-rose-600 cursor-pointer ${
                            isLiked ? 'text-rose-600 font-bold' : ''
                          }`}
                        >
                          <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
                          <span className="font-mono text-[11px]">{t.likes}</span>
                        </button>
                        <span className="inline-flex items-center gap-1" title="Views">
                          <Eye className="w-3.5 h-3.5" />
                          <span className="font-mono text-[11px]">
                            {t.views > 999 ? `${(t.views / 1000).toFixed(1)}K` : t.views}
                          </span>
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleTweetBookmark(t.id, viewerId)}
                          className={`hover:text-amber-600 cursor-pointer ${isBookmarked ? 'text-amber-600' : ''}`}
                          title="Bookmark"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-current' : ''}`} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Lightbox / Full Media Preview Modal */}
      {previewMedia && (
        <div
          onClick={() => setPreviewMedia(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-3xl w-full bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl flex flex-col max-h-[90vh]"
          >
            <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50 text-left">
              <div className="min-w-0">
                <h4 className="font-bold text-xs sm:text-sm text-slate-900 truncate">{previewMedia.title}</h4>
                {(previewMedia.uploader || previewMedia.timestamp) && (
                  <p className="text-[10px] text-slate-400 mt-0.5 truncate">
                    {previewMedia.uploader ? `By ${previewMedia.uploader}` : ''}
                    {previewMedia.uploader && previewMedia.timestamp ? ' • ' : ''}
                    {previewMedia.timestamp || ''}
                  </p>
                )}
              </div>
              <button
                type="button"
                onClick={() => setPreviewMedia(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-800 hover:bg-slate-200/70 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="bg-slate-950 flex items-center justify-center p-2 flex-1 min-h-[300px] max-h-[75vh]">
              {previewMedia.type === 'video' ? (
                <video
                  src={previewMedia.url}
                  controls
                  autoPlay
                  playsInline
                  className="max-h-[72vh] w-auto max-w-full object-contain"
                />
              ) : (
                <img
                  src={previewMedia.url}
                  alt={previewMedia.title}
                  className="max-h-[72vh] w-auto max-w-full object-contain"
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
