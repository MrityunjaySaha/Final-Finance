import { AuthSession } from '../types/auth';
import { UserPublicProfile, FriendRequest, RelationshipStatus } from '../types/social';
import { resolveTargetUserVerificationTier } from '../utils/verificationTiers';
import { getDeletedAccounts } from '../utils/accountStatusStorage';
import { getAdminMembers } from './adminGroupService';

const SAMPLE_USERS: UserPublicProfile[] = [
  {
    uid: 'demo-satoshi-nakamoto',
    userId: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    email: 'satoshi@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic ledger consensus.',
    role: 'user',
    createdAt: '2024-01-03T00:00:00.000Z',
    followersCount: 12500,
    followingCount: 21,
    friendsCount: 50
  },
  {
    uid: 'demo-jordan-belfort',
    userId: 'jordan_belfort',
    name: 'Jordan Belfort',
    email: 'jordan@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Founder & Chief Reserve Allocator at Final Finance. Overseeing $4.2B in tokenized reserve vaults and barter liquidity.',
    role: 'admin',
    createdAt: '2024-01-05T00:00:00.000Z',
    followersCount: 8400,
    followingCount: 120,
    friendsCount: 75
  },
  {
    uid: 'demo-alex-morgan',
    userId: 'alex_morgan',
    name: 'Alex Morgan',
    email: 'alex@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Institutional Commodity Desk Arbiter. Swiss Vault & Gold Bullion Reserve specialist.',
    role: 'user',
    createdAt: '2024-01-10T00:00:00.000Z',
    followersCount: 3400,
    followingCount: 210,
    friendsCount: 92
  },
  {
    uid: 'user-gholu653',
    userId: 'gholu653',
    name: 'Gholu',
    email: 'gholu653@gmail.com',
    avatarUrl: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    bio: '',
    role: 'user',
    createdAt: '2024-01-20T00:00:00.000Z',
    followersCount: 0,
    followingCount: 0,
    friendsCount: 0
  },
  {
    uid: 'demo-super-admin',
    userId: 'super_admin_ranma',
    name: 'Ranma Sovereign Master',
    email: 'ranmaanimaker@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Super Admin & Global Escrow Overseer. Sovereign governance across all 5 reserve vaults.',
    role: 'super_admin',
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 1420,
    followingCount: 180,
    friendsCount: 94
  },
  {
    uid: 'demo-admin-officer',
    userId: 'officer_dbz',
    name: 'Chief Audit Officer',
    email: 'awesomedbz@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    bio: 'Custodial Auditing & Vault Verification Officer. Managing reserve asset attestations.',
    role: 'admin',
    createdAt: '2024-01-15T00:00:00.000Z',
    followersCount: 890,
    followingCount: 110,
    friendsCount: 65
  },
  {
    uid: 'user-lord_sterling',
    userId: 'sterling_vault',
    name: 'Lord Sterling',
    email: 'sterling@zurich-escrow.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Swiss Freeport Trustee & 1st Edition Imperial Gold Bullion Syndicate Master.',
    role: 'user',
    createdAt: '2024-02-01T00:00:00.000Z',
    followersCount: 5240,
    followingCount: 310,
    friendsCount: 142
  },
  {
    uid: 'user-elena_rostova',
    userId: 'elena_rostova',
    name: 'Elena Rostova',
    email: 'elena@monaco-yachting.mc',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    bio: 'Global Maritime & Aviation Barter Broker. Swapping luxury charter deeds against Final Coins.',
    role: 'user',
    createdAt: '2024-03-01T00:00:00.000Z',
    followersCount: 3890,
    followingCount: 420,
    friendsCount: 118
  },
  {
    uid: 'user-marcus_vance',
    userId: 'marcus_vance',
    name: 'Marcus Vance',
    email: 'marcus@vance-holdings.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Quantitative Barter Arbitrageur & Cold-Storage Bitcoin Custodian.',
    role: 'user',
    createdAt: '2024-03-10T00:00:00.000Z',
    followersCount: 2150,
    followingCount: 280,
    friendsCount: 88
  },
  {
    uid: 'user-alex_chen',
    userId: 'alex_chen',
    name: 'Alex Chen',
    email: 'alex.chen@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    bio: '',
    role: 'user',
    createdAt: '2024-03-15T00:00:00.000Z',
    followersCount: 0,
    followingCount: 0,
    friendsCount: 0
  },
  {
    uid: 'drv-econ-1',
    userId: 'lukas_meyer',
    name: 'Lukas Meyer',
    email: 'lukas.meyer@rideshare.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Professional Sovereign Ride-Share Driver · VW ID.4 Pro Electric (ZH-412-809). Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 240,
    followingCount: 30,
    friendsCount: 18
  },
  {
    uid: 'drv-ev-1',
    userId: 'elena_vance',
    name: 'Elena Vance',
    email: 'elena.vance@rideshare.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    bio: 'Professional Comfort EV & Courier Driver · Polestar 2 Long Range (ZH-618-334). Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 310,
    followingCount: 45,
    friendsCount: 24
  },
  {
    uid: 'drv-lux-1',
    userId: 'marc_weber',
    name: 'Marc-Antoine Weber',
    email: 'marc.weber@rideshare.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    bio: 'Luxury VIP Chauffeur · Mercedes-Maybach S680 (ZH-100-777). Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 420,
    followingCount: 50,
    friendsCount: 35
  },
  {
    uid: 'drv-rick-1',
    userId: 'aarav_patel',
    name: 'Aarav Patel',
    email: 'aarav.patel@rideshare.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
    bio: 'Eco Transit Specialist · Bajaj RE Electric Three-Wheeler (ZH-R30-218). Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 180,
    followingCount: 25,
    friendsCount: 14
  },
  {
    uid: 'drv-moto-1',
    userId: 'matteo_rossi',
    name: 'Matteo Rossi',
    email: 'matteo.rossi@rideshare.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80',
    bio: 'High-Speed Express Courier & Moto Driver · Zero SR/F Sovereign Moto (ZH-M92-14). Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 290,
    followingCount: 38,
    friendsCount: 20
  },
  {
    uid: 'drv-marco',
    userId: 'driver_marco',
    name: 'Marco Rossi',
    email: 'marco.rossi@courier.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Courier Express Dispatch Driver · Zero SR/F Sovereign Moto. Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 195,
    followingCount: 28,
    friendsCount: 16
  },
  {
    uid: 'drv-sven',
    userId: 'driver_sven',
    name: 'Sven Keller',
    email: 'sven.keller@courier.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    bio: 'Commercial Delivery Specialist · Tesla Model Y Long Range. Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 210,
    followingCount: 32,
    friendsCount: 19
  },
  {
    uid: 'drv-chloe',
    userId: 'driver_chloe',
    name: 'Chloe Dubois',
    email: 'chloe.dubois@courier.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80',
    bio: 'Urban Courier Dispatch · Bajaj RE Electric Three-Wheeler. Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 175,
    followingCount: 22,
    friendsCount: 15
  },
  {
    uid: 'driver-hans',
    userId: 'hansruedi_keller',
    name: 'Hansruedi Keller',
    email: 'hans.keller@rideshare.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Executive Sovereign Transport Driver · Tesla Model Y Sovereign. Tier 2 Verified.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 340,
    followingCount: 40,
    friendsCount: 26
  },
  {
    uid: 'merchant-sovereign',
    userId: 'sovereign_merchant',
    name: 'Sovereign Merchant',
    email: 'freeport.retail@sovereign.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Zurich Freeport Sovereign Retail & Electronics Merchant. Direct Final Currency Clearing.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 620,
    followingCount: 85,
    friendsCount: 42
  },
  {
    uid: 'merchant-satoshi',
    userId: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    email: 'neotokyo@sovereign.jp',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Tokyo Cybernetic Vault Hardware & Neo Tokyo Sovereign Teppanyaki Founder.',
    role: 'user',
    isVerified: true,
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 9850,
    followingCount: 21,
    friendsCount: 12
  }
];

export const FOLLOWING_STORAGE_KEY = 'final_finance_following_map_v2';
export const FRIENDS_STORAGE_KEY = 'final_finance_friends_map_v2';
export const REQ_RECEIVED_STORAGE_KEY = 'final_finance_friend_req_rcv_v2';
export const REQ_SENT_STORAGE_KEY = 'final_finance_friend_req_sent_v2';

function loadMapFromStorage(key: string, defaultInit: Record<string, string[]> = {}): Record<string, Set<string>> {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      const res: Record<string, Set<string>> = {};
      Object.entries(parsed).forEach(([uid, list]) => {
        if (Array.isArray(list)) {
          res[uid] = new Set(list);
        }
      });
      return res;
    }
  } catch (e) {
    console.warn(`Error reading map ${key}:`, e);
  }
  const res: Record<string, Set<string>> = {};
  Object.entries(defaultInit).forEach(([uid, list]) => {
    res[uid] = new Set(list);
  });
  return res;
}

function saveMapToStorage(key: string, map: Record<string, Set<string>>) {
  try {
    const serializable: Record<string, string[]> = {};
    Object.entries(map).forEach(([uid, set]) => {
      serializable[uid] = Array.from(set);
    });
    localStorage.setItem(key, JSON.stringify(serializable));
  } catch (e) {
    console.error(`Error saving map ${key}:`, e);
  }
}

function loadRequestsFromStorage(key: string): Record<string, FriendRequest[]> {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn(`Error reading requests ${key}:`, e);
  }
  return {};
}

function saveRequestsToStorage(key: string, reqs: Record<string, FriendRequest[]>) {
  try {
    localStorage.setItem(key, JSON.stringify(reqs));
  } catch (e) {
    console.error(`Error saving requests ${key}:`, e);
  }
}

let followingMap: Record<string, Set<string>> = loadMapFromStorage(FOLLOWING_STORAGE_KEY, {
  'demo-vip-alex': ['user-lord_sterling', 'user-elena_rostova']
});

let friendsMap: Record<string, Set<string>> = loadMapFromStorage(FRIENDS_STORAGE_KEY, {
  'demo-vip-alex': ['user-lord_sterling', 'user-elena_rostova'],
  'demo-ranma-superadmin': ['user-lord_sterling', 'user-elena_rostova']
});

let friendRequestsReceived: Record<string, FriendRequest[]> = loadRequestsFromStorage(REQ_RECEIVED_STORAGE_KEY);
let friendRequestsSent: Record<string, FriendRequest[]> = loadRequestsFromStorage(REQ_SENT_STORAGE_KEY);

export async function getAllUsers(
  currentUid: string,
  options?: { includeSelf?: boolean }
): Promise<UserPublicProfile[]> {
  const viewerIsAdmin = isAdminAccount(currentUid) || isCurrentSessionAdmin();
  const includeSelf = Boolean(options?.includeSelf);

  const currentAliases = new Set(
    currentUid ? getIdentityAliases(currentUid).map((a) => a.toLowerCase()) : []
  );

  // Exclude permanently deleted accounts from user directories
  const deletedAliasSet = new Set<string>();
  try {
    getDeletedAccounts().forEach((rec) => {
      [rec.uid, rec.userId, rec.email].filter(Boolean).forEach((val) => {
        getIdentityAliases(String(val)).forEach((a) => deletedAliasSet.add(a.toLowerCase()));
      });
    });
  } catch {
    // Ignore storage read error
  }

  const customMap = loadCustomProfiles();
  let regUsers: any[] = [];
  try {
    const rawReg = localStorage.getItem('final_finance_registered_users');
    if (rawReg) {
      const parsed = JSON.parse(rawReg);
      if (parsed && typeof parsed === 'object') {
        regUsers = Object.values(parsed);
      }
    }
  } catch {
    // Ignore storage read error
  }

  let activeSession: any = null;
  try {
    const rawSess = localStorage.getItem('final_finance_auth_session');
    if (rawSess) {
      activeSession = JSON.parse(rawSess);
    }
  } catch {
    // Ignore storage read error
  }

  const adminMembers = getAdminMembers();

  // Deduplicate accounts cleanly across UID/handle/email aliases
  const canonicalBuckets = new Map<string, UserPublicProfile>();
  const aliasToBucketKey = new Map<string, string>();

  const registerAliases = (bucketKey: string, identifiers: Array<string | undefined>) => {
    identifiers.filter(Boolean).forEach((id) => {
      getIdentityAliases(String(id)).forEach((a) => {
        const cleanAlias = a.toLowerCase();
        if (!aliasToBucketKey.has(cleanAlias)) {
          aliasToBucketKey.set(cleanAlias, bucketKey);
        }
      });
    });
  };

  const findBucketKey = (identifiers: Array<string | undefined>): string | undefined => {
    for (const id of identifiers) {
      if (!id) continue;
      for (const a of getIdentityAliases(String(id))) {
        const hit = aliasToBucketKey.get(a.toLowerCase());
        if (hit) return hit;
      }
    }
    return undefined;
  };

  const upsertProfile = (candidate: Partial<UserPublicProfile> & { uid?: string; userId?: string; name?: string }) => {
    const rawId = (candidate.userId || '').trim().replace(/^@/, '');
    const rawUid = (candidate.uid || (rawId ? `user-${rawId}` : '')).trim();
    const rawEmail = (candidate.email || '').trim().toLowerCase();
    const identifiers = [rawUid, rawId, rawEmail].filter(Boolean);
    if (identifiers.length === 0) return;

    if (
      identifiers.some((id) =>
        getIdentityAliases(id).some((a) => deletedAliasSet.has(a.toLowerCase()))
      )
    ) {
      return;
    }

    const existingKey = findBucketKey(identifiers);
    const bucketKey = existingKey || rawUid.toLowerCase() || rawId.toLowerCase() || rawEmail;
    const prev = canonicalBuckets.get(bucketKey);

    const resolvedRole: UserPublicProfile['role'] =
      prev?.role === 'super_admin' || candidate.role === 'super_admin'
        ? 'super_admin'
        : prev?.role === 'admin' || candidate.role === 'admin'
          ? 'admin'
          : candidate.role || prev?.role || 'user';

    const merged: UserPublicProfile = {
      uid: prev?.uid || rawUid || `user-${rawId}`,
      userId: prev?.userId || rawId || rawUid,
      name: candidate.name && candidate.name.trim() ? candidate.name : prev?.name || rawId || 'Member',
      email: candidate.email || prev?.email,
      avatarUrl: candidate.avatarUrl || prev?.avatarUrl,
      coverUrl: candidate.coverUrl || prev?.coverUrl,
      bio: candidate.bio !== undefined && candidate.bio !== '' ? candidate.bio : prev?.bio || '',
      organization: candidate.organization || prev?.organization,
      reputationBadge: candidate.reputationBadge || prev?.reputationBadge,
      role: resolvedRole,
      isPrivate: candidate.isPrivate ?? prev?.isPrivate,
      isVerified: candidate.isVerified ?? prev?.isVerified,
      createdAt: prev?.createdAt || candidate.createdAt || '2024-01-01T00:00:00.000Z',
      followersCount: prev?.followersCount ?? candidate.followersCount ?? 0,
      followingCount: prev?.followingCount ?? candidate.followingCount ?? 0,
      friendsCount: prev?.friendsCount ?? candidate.friendsCount ?? 0,
    };

    canonicalBuckets.set(bucketKey, merged);
    registerAliases(bucketKey, [merged.uid, merged.userId, merged.email, rawUid, rawId, rawEmail]);
  };

  // 1. Base sample users
  SAMPLE_USERS.forEach((u) => upsertProfile(u));

  // 2. Admin directory members (ensures admin display names & custom admins are searchable)
  adminMembers.forEach((m) => {
    const cleanHandle = (m.handle || m.id).replace(/^@/, '');
    upsertProfile({
      uid: `user-${cleanHandle}`,
      userId: cleanHandle,
      name: m.name,
      email: m.email,
      avatarUrl: m.avatarUrl,
      bio: m.jobTitle ? `${m.jobTitle} · Final Finance Governance` : undefined,
      role: m.role,
    });
  });

  // 3. Registered accounts (Google, password, email signups)
  regUsers.forEach((acc) => {
    if (!acc || typeof acc !== 'object') return;
    if (acc.role === 'guest') return;
    const accHandle = (acc.userId || acc.id || (acc.email ? String(acc.email).split('@')[0] : '')).replace(/^@/, '');
    if (!accHandle) return;
    const accEmail = (acc.email || '').toLowerCase();
    const resolvedRole: 'super_admin' | 'admin' | 'user' =
      acc.role === 'super_admin' || accEmail === 'ranmaanimaker@gmail.com'
        ? 'super_admin'
        : acc.role === 'admin' || ADMIN_EMAILS.has(accEmail) || isAdminAccount(accHandle)
          ? 'admin'
          : 'user';
    upsertProfile({
      uid: acc.uid || `user-${accHandle}`,
      userId: accHandle,
      name: acc.name || accHandle,
      email: acc.email,
      avatarUrl: acc.avatarUrl,
      coverUrl: acc.coverUrl,
      bio: acc.bio || '',
      role: resolvedRole,
      isPrivate: acc.isPrivate,
      createdAt: acc.createdAt,
    });
  });

  // 4. Active signed-in session
  if (activeSession && typeof activeSession === 'object' && activeSession.role !== 'guest') {
    const sessHandle = (activeSession.id || activeSession.userId || (activeSession.email ? String(activeSession.email).split('@')[0] : '')).replace(/^@/, '');
    if (sessHandle || activeSession.uid) {
      upsertProfile({
        uid: activeSession.uid || `user-${sessHandle}`,
        userId: sessHandle || activeSession.uid,
        name: activeSession.name || sessHandle,
        email: activeSession.email,
        avatarUrl: activeSession.avatarUrl,
        bio: activeSession.bio,
        role:
          activeSession.role === 'super_admin'
            ? 'super_admin'
            : activeSession.role === 'admin'
              ? 'admin'
              : 'user',
      });
    }
  }

  // 5. Custom edited profile overrides
  Object.values(customMap).forEach((p) => {
    if (!p || typeof p !== 'object') return;
    if ((p as any).role === 'guest') return;
    upsertProfile(p);
  });

  return Array.from(canonicalBuckets.values())
    .filter((u) => {
      const userAliases = [
        ...getIdentityAliases(u.uid),
        ...getIdentityAliases(u.userId),
        ...(u.email ? getIdentityAliases(u.email) : []),
      ].map((a) => a.toLowerCase());

      const isSelf = currentAliases.size > 0 && userAliases.some((a) => currentAliases.has(a));
      if (!includeSelf && isSelf) return false;
      if (
        !viewerIsAdmin &&
        !isSelf &&
        (areUsersBlockedEitherWay(currentUid, u.uid) || areUsersBlockedEitherWay(currentUid, u.userId))
      ) {
        return false;
      }
      return true;
    })
    .map((u) => ({
      ...u,
      avatarUrl:
        u.avatarUrl ||
        `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name || u.userId)}&background=0f172a&color=f8fafc&bold=true&size=128`,
      isPrivate:
        u.isPrivate ??
        getUserProfilePrivacy([u.uid, u.userId, u.email || ''].filter(Boolean)),
      isVerified:
        resolveTargetUserVerificationTier([u.userId, u.uid, u.email], {
          isVerified: u.isVerified,
          role: u.role,
        }) >= 3,
    }));
}

const CUSTOM_PROFILES_STORAGE_KEY = 'final_finance_custom_profiles_map';
const PROFILE_PRIVACY_STORAGE_KEY = 'ff_profile_privacy_map_v1';

function loadProfilePrivacyMap(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(PROFILE_PRIVACY_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn('Error loading profile privacy map:', e);
  }
  return {};
}

export function getUserProfilePrivacy(identifiers: string[]): boolean {
  const map = loadProfilePrivacyMap();
  const expanded = new Set<string>();
  identifiers.filter(Boolean).forEach((id) => {
    getIdentityAliases(id).forEach((a) => expanded.add(a.toLowerCase()));
  });
  for (const key of expanded) {
    if (map[key] === true) return true;
  }
  return false;
}

export function setUserProfilePrivacy(identifiers: string[], isPrivate: boolean): void {
  try {
    const map = loadProfilePrivacyMap();
    const expanded = new Set<string>();
    identifiers.filter(Boolean).forEach((id) => {
      getIdentityAliases(id).forEach((a) => expanded.add(a.toLowerCase()));
    });
    expanded.forEach((key) => {
      map[key] = isPrivate;
    });
    localStorage.setItem(PROFILE_PRIVACY_STORAGE_KEY, JSON.stringify(map));

    // Also keep custom profiles store synchronized across aliases
    const customMap = loadCustomProfiles();
    let customChanged = false;
    expanded.forEach((key) => {
      if (customMap[key]) {
        customMap[key] = { ...customMap[key], isPrivate };
        customChanged = true;
      }
    });
    if (customChanged) {
      saveCustomProfiles(customMap);
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('final_finance_profile_privacy_updated', { detail: { isPrivate, identifiers: Array.from(expanded) } }));
    }
  } catch (e) {
    console.error('Error saving profile privacy setting:', e);
  }
}

function loadCustomProfiles(): Record<string, UserPublicProfile> {
  try {
    const stored = localStorage.getItem(CUSTOM_PROFILES_STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.error('Error loading custom profiles:', e);
  }
  return {};
}

function saveCustomProfiles(map: Record<string, UserPublicProfile>) {
  try {
    localStorage.setItem(CUSTOM_PROFILES_STORAGE_KEY, JSON.stringify(map));
  } catch (e) {
    console.error('Error saving custom profiles:', e);
  }
}

export function getUserSocialCounts(uid: string, baseProfile?: UserPublicProfile | null): {
  followersCount: number;
  followingCount: number;
  friendsCount: number;
} {
  const uidAliases = new Set(getIdentityAliases(uid).map((a) => a.toLowerCase()));
  const canonicalKey = (raw: string) => raw.toLowerCase().replace(/^@/, '').replace(/^user-/, '').replace(/^demo-/, '');

  const followingTargets = new Set<string>();
  Object.entries(followingMap).forEach(([key, set]) => {
    if (uidAliases.has(key.toLowerCase())) {
      set.forEach((t) => followingTargets.add(canonicalKey(t)));
    }
  });

  const friendTargets = new Set<string>();
  Object.entries(friendsMap).forEach(([key, set]) => {
    if (uidAliases.has(key.toLowerCase())) {
      set.forEach((t) => friendTargets.add(canonicalKey(t)));
    } else {
      for (const target of set) {
        if (uidAliases.has(target.toLowerCase())) {
          friendTargets.add(canonicalKey(key));
        }
      }
    }
  });

  const followerSources = new Set<string>();
  Object.entries(followingMap).forEach(([userUid, fSet]) => {
    if (uidAliases.has(userUid.toLowerCase())) return;
    for (const target of fSet) {
      if (uidAliases.has(target.toLowerCase())) {
        followerSources.add(canonicalKey(userUid));
        break;
      }
    }
  });

  const dynamicFollowers = followerSources.size;
  const isDemo = uid.startsWith('demo-') || uid.startsWith('user-lord_') || uid.startsWith('user-elena') || uid.startsWith('user-marcus');

  if (isDemo && baseProfile) {
    return {
      followersCount: (baseProfile.followersCount || 0) + dynamicFollowers,
      followingCount: followingTargets.size > 0 ? followingTargets.size : (baseProfile.followingCount || 0),
      friendsCount: friendTargets.size > 0 ? friendTargets.size : (baseProfile.friendsCount || 0),
    };
  }

  return {
    followersCount: dynamicFollowers,
    followingCount: followingTargets.size,
    friendsCount: friendTargets.size,
  };
}

export async function updateUserPublicProfile(
  userIdOrUid: string, 
  updates: Partial<UserPublicProfile>
): Promise<UserPublicProfile> {
  const current = (await getUserProfile(userIdOrUid)) || {
    uid: `user-${userIdOrUid}`,
    userId: userIdOrUid,
    name: userIdOrUid,
    role: 'user',
    createdAt: new Date().toISOString()
  };

  const updated: UserPublicProfile = {
    ...current,
    ...updates,
  };

  const map = loadCustomProfiles();
  map[updated.uid] = updated;
  map[updated.userId.toLowerCase()] = updated;
  if (userIdOrUid) {
    map[userIdOrUid.toLowerCase()] = updated;
  }
  saveCustomProfiles(map);

  if (updates.isPrivate !== undefined) {
    setUserProfilePrivacy([userIdOrUid, updated.uid, updated.userId, updated.email || ''].filter(Boolean), Boolean(updates.isPrivate));
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('final_finance_profile_updated', { detail: { uid: updated.uid, userId: updated.userId } }));
  }

  return updated;
}

export async function getUserProfile(userIdOrHandle: string): Promise<UserPublicProfile | null> {
  if (!userIdOrHandle) return null;
  const raw = userIdOrHandle.trim();
  const clean = raw.toLowerCase().replace(/^@/, '');
  const cleanNormalized = clean.replace(/[_\-\s]/g, '');
  const aliases = getIdentityAliases(raw).map((a) => a.toLowerCase());
  const aliasSet = new Set(aliases);

  // 0. Check if matches current logged-in user in localStorage
  try {
    const rawCur = localStorage.getItem('final_finance_user');
    if (rawCur) {
      const curUser = JSON.parse(rawCur);
      const curAliases = new Set([
        curUser.id,
        curUser.uid,
        curUser.handle,
        curUser.email,
        curUser.username,
      ].filter(Boolean).flatMap(a => getIdentityAliases(String(a)).map(x => x.toLowerCase())));

      if (curAliases.has(clean) || curAliases.has(raw.toLowerCase()) || aliasSet.has(String(curUser.id || '').toLowerCase()) || aliasSet.has(String(curUser.handle || '').toLowerCase())) {
        if (curUser.avatarUrl) {
          const profile: UserPublicProfile = {
            uid: curUser.uid || curUser.id || `user-${clean}`,
            userId: curUser.handle || curUser.userId || clean,
            name: curUser.name || 'Member',
            email: curUser.email,
            avatarUrl: curUser.avatarUrl,
            coverUrl: curUser.coverUrl,
            bio: curUser.bio || '',
            role: curUser.role || 'user',
            isVerified: Boolean(curUser.verified || curUser.isVerified),
            isPrivate: Boolean(curUser.isPrivate),
            createdAt: curUser.createdAt || '2024-01-01T00:00:00.000Z',
            ...getUserSocialCounts(curUser.uid || curUser.id || `user-${clean}`, null),
          };
          return profile;
        }
      }
    }
  } catch {}

  // 1. Check in custom saved profiles (matching any alias)
  const customMap = loadCustomProfiles();
  let customMatch =
    customMap[clean] ||
    customMap[raw] ||
    customMap[raw.toLowerCase()] ||
    customMap[`user-${clean}`] ||
    customMap[`google-${clean}`] ||
    (clean.startsWith('user-') ? customMap[clean.slice(5)] : undefined) ||
    (clean.startsWith('google-') ? customMap[clean.slice(7)] : undefined);

  if (!customMatch) {
    for (const a of aliases) {
      if (customMap[a]) {
        customMatch = customMap[a];
        break;
      }
    }
  }
  if (!customMatch) {
    customMatch = Object.values(customMap).find((p) => {
      const pUid = (p?.uid || '').toLowerCase();
      const pId = (p?.userId || '').toLowerCase();
      const pEmail = (p?.email || '').toLowerCase();
      return (pUid && aliasSet.has(pUid)) || (pId && aliasSet.has(pId)) || (pEmail && aliasSet.has(pEmail));
    });
  }

  // 2. Check in static sample users (including alias & email matching)
  const sampleMatch = SAMPLE_USERS.find((u) => {
    const uUid = u.uid.toLowerCase();
    const uId = u.userId.toLowerCase();
    const uEmail = (u.email || '').toLowerCase();
    const uName = u.name.toLowerCase();
    return (
      uId === clean ||
      uUid === clean ||
      uUid === raw.toLowerCase() ||
      (uEmail && uEmail === clean) ||
      uName === clean ||
      aliasSet.has(uUid) ||
      aliasSet.has(uId) ||
      (uEmail && aliasSet.has(uEmail)) ||
      uId.replace(/[_\-\s]/g, '') === cleanNormalized ||
      uUid.replace(/[_\-\s]/g, '') === cleanNormalized
    );
  });

  if (customMatch) {
    const mergedCustom: UserPublicProfile = sampleMatch
      ? {
          ...sampleMatch,
          ...customMatch,
          avatarUrl: customMatch.avatarUrl || sampleMatch.avatarUrl,
          role:
            sampleMatch.role === 'super_admin' || customMatch.role === 'super_admin'
              ? 'super_admin'
              : sampleMatch.role === 'admin' || customMatch.role === 'admin'
                ? 'admin'
                : customMatch.role || sampleMatch.role,
        }
      : customMatch;
    const counts = getUserSocialCounts(mergedCustom.uid, mergedCustom);
    const resolvedPrivacy =
      mergedCustom.isPrivate ??
      getUserProfilePrivacy([mergedCustom.uid, mergedCustom.userId, mergedCustom.email || '', raw, clean].filter(Boolean));
    const resolvedVerified = resolveTargetUserVerificationTier(
      [mergedCustom.userId, mergedCustom.uid, mergedCustom.email],
      { isVerified: mergedCustom.isVerified, role: mergedCustom.role }
    ) >= 3;
    return { ...mergedCustom, ...counts, isPrivate: Boolean(resolvedPrivacy), isVerified: resolvedVerified };
  }

  if (sampleMatch) {
    const customOverride =
      customMap[sampleMatch.uid] ||
      customMap[sampleMatch.uid.toLowerCase()] ||
      customMap[sampleMatch.userId.toLowerCase()] ||
      (sampleMatch.email ? customMap[sampleMatch.email.toLowerCase()] : undefined);
    const merged = { ...sampleMatch, ...customOverride };
    const counts = getUserSocialCounts(merged.uid, merged);
    const resolvedPrivacy =
      merged.isPrivate ??
      getUserProfilePrivacy([merged.uid, merged.userId, merged.email || '', raw, clean].filter(Boolean));
    const resolvedVerified = resolveTargetUserVerificationTier(
      [merged.userId, merged.uid, merged.email],
      { isVerified: merged.isVerified, role: merged.role }
    ) >= 3;
    return { ...merged, ...counts, isPrivate: Boolean(resolvedPrivacy), isVerified: resolvedVerified };
  }

  // 3. Check localStorage for dynamically registered users
  try {
    const stored = localStorage.getItem('final_finance_registered_users');
    if (stored) {
      const regMap = JSON.parse(stored);
      for (const account of Object.values<any>(regMap)) {
        const accUid = account.uid ? String(account.uid).toLowerCase() : '';
        const accId = account.userId ? String(account.userId).toLowerCase() : '';
        const accEmail = account.email ? String(account.email).toLowerCase() : '';
        const accName = account.name ? String(account.name).toLowerCase() : '';
        if (
          accId === clean ||
          accEmail === clean ||
          accName === clean ||
          (accUid && aliasSet.has(accUid)) ||
          (accId && aliasSet.has(accId)) ||
          (accEmail && aliasSet.has(accEmail))
        ) {
          const profileUid = account.uid || `user-${account.userId || clean}`;
          const resolvedRole: 'super_admin' | 'admin' | 'user' =
            account.role === 'super_admin' || accEmail === 'ranmaanimaker@gmail.com'
              ? 'super_admin'
              : account.role === 'admin' || ADMIN_EMAILS.has(accEmail) || isAdminAccount(accId)
                ? 'admin'
                : 'user';
          const counts = getUserSocialCounts(profileUid, null);
          const resolvedPrivacy =
            Boolean(account.isPrivate) ||
            getUserProfilePrivacy([profileUid, account.userId || clean, account.email || '', raw, clean].filter(Boolean));
          const resolvedVerified = resolveTargetUserVerificationTier(
            [account.userId, profileUid, account.email],
            { verification: account.verification, isVerified: account.isVerified, role: resolvedRole }
          ) >= 3;
          return {
            uid: profileUid,
            userId: account.userId || clean,
            name: account.name || 'Member',
            email: account.email,
            avatarUrl: account.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(account.name || clean)}&background=0f172a&color=f8fafc&bold=true&size=128`,
            coverUrl: account.coverUrl,
            bio: account.bio || '',
            role: resolvedRole,
            isVerified: resolvedVerified,
            isPrivate: resolvedPrivacy,
            createdAt: account.createdAt || new Date().toISOString(),
            ...counts
          };
        }
      }
    }
  } catch (e) {
    console.error('Error reading registered users for profile:', e);
  }

  // 3b. Check admin directory in localStorage (covers any custom/self-deactivated/deleted admin entry)
  try {
    const rawAdmins = localStorage.getItem('final_finance_admin_directory_v2');
    if (rawAdmins) {
      const adminList = JSON.parse(rawAdmins);
      if (Array.isArray(adminList)) {
        const adm = adminList.find((m: any) => {
          const mId = (m?.id || '').toLowerCase();
          const mHandle = (m?.handle || '').toLowerCase().replace(/^@/, '');
          const mEmail = (m?.email || '').toLowerCase();
          return (
            mId === clean ||
            mHandle === clean ||
            (mEmail && mEmail === clean) ||
            (mId && aliasSet.has(mId)) ||
            (mHandle && aliasSet.has(mHandle)) ||
            (mEmail && aliasSet.has(mEmail))
          );
        });
        if (adm) {
          const admHandle = (adm.handle || clean).replace(/^@/, '');
          const admUid = `user-${admHandle}`;
          const admRole: 'super_admin' | 'admin' = adm.role === 'super_admin' ? 'super_admin' : 'admin';
          const counts = getUserSocialCounts(admUid, null);
          const resolvedVerified = resolveTargetUserVerificationTier([admHandle, admUid, adm.email], { role: admRole }) >= 3;
          return {
            uid: admUid,
            userId: admHandle,
            name: adm.name || admHandle,
            email: adm.email,
            avatarUrl: adm.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(adm.name || admHandle)}&background=0f172a&color=f8fafc&bold=true&size=128`,
            bio: adm.jobTitle ? `${adm.jobTitle} · Final Finance Governance` : '',
            role: admRole,
            isVerified: resolvedVerified,
            isPrivate: getUserProfilePrivacy([admUid, admHandle, adm.email || ''].filter(Boolean)),
            createdAt: '2024-01-01T00:00:00.000Z',
            ...counts,
          };
        }
      }
    }
  } catch {
    // Ignore storage read error
  }

  // 4. Fallback: synthesize profile from handle
  const formattedName = clean
    .split(/[_\-\s]+/)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

  const profileUid = `user-${clean}`;
  const counts = getUserSocialCounts(profileUid, null);
  const resolvedPrivacy = getUserProfilePrivacy([profileUid, clean, raw]);
  const fallbackRole: 'super_admin' | 'admin' | 'user' =
    clean === 'super_admin_ranma' || clean === 'ranmaanimaker@gmail.com' || clean === 'demo-ranma-superadmin'
      ? 'super_admin'
      : isAdminAccount(raw)
        ? 'admin'
        : 'user';
  const resolvedVerified = resolveTargetUserVerificationTier([clean, profileUid], { role: fallbackRole }) >= 3;

  return {
    uid: profileUid,
    userId: clean,
    name: formattedName || 'Member',
    avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(formattedName || clean)}&background=0f172a&color=f8fafc&bold=true&size=128`,
    bio: '',
    role: fallbackRole,
    isVerified: resolvedVerified,
    isPrivate: resolvedPrivacy,
    createdAt: '2024-01-01T00:00:00.000Z',
    ...counts
  };
}

const USER_NOTIF_QUEUE_STORAGE_KEY = 'ff_user_notifications_queue_v1';

export interface QueuedUserNotification {
  id: string;
  title: string;
  description: string;
  type:
    | 'social'
    | 'chat'
    | 'system'
    | 'trade'
    | 'marketplace'
    | 'stocks'
    | 'vault'
    | 'wallet'
    | 'subsidies'
    | 'fundraising'
    | 'security'
    | 'feedback'
    | 'loans';
  targetTab?: string;
  targetId?: string;
  amount?: number;
  currency?: string;
  createdAt: string;
}

function enqueueNotificationForAliases(aliases: string[], notif: Omit<QueuedUserNotification, 'id' | 'createdAt'>) {
  try {
    const raw = localStorage.getItem(USER_NOTIF_QUEUE_STORAGE_KEY);
    const map: Record<string, QueuedUserNotification[]> = raw ? JSON.parse(raw) : {};
    const primaryKey = aliases[0]?.toLowerCase() || 'unknown';
    const entry: QueuedUserNotification = {
      ...notif,
      id: `qnotif-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      createdAt: new Date().toISOString(),
    };
    const normalizedAliases = Array.from(new Set(aliases.map((a) => a.toLowerCase()).filter(Boolean)));
    if (normalizedAliases.length === 0) normalizedAliases.push(primaryKey);
    // Store under canonical handle/uid aliases so whichever alias logs in picks it up once
    const bucketKey = normalizedAliases.join('|');
    if (!map[bucketKey]) map[bucketKey] = [];
    map[bucketKey].unshift(entry);
    localStorage.setItem(USER_NOTIF_QUEUE_STORAGE_KEY, JSON.stringify(map));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('ff_user_notif_queue_updated', { detail: { aliases: normalizedAliases } }));
    }
  } catch (e) {
    console.warn('Could not enqueue user notification:', e);
  }
}

export function enqueueUserNotification(
  recipientIdentifiers: string[],
  notif: Omit<QueuedUserNotification, 'id' | 'createdAt'>
) {
  const expanded = new Set<string>();
  recipientIdentifiers.filter(Boolean).forEach((id) => {
    getIdentityAliases(id).forEach((alias) => expanded.add(alias));
    expanded.add(id);
  });
  enqueueNotificationForAliases(Array.from(expanded), notif);
}

export function consumeQueuedUserNotifications(userIdentifiers: string[]): QueuedUserNotification[] {
  try {
    const raw = localStorage.getItem(USER_NOTIF_QUEUE_STORAGE_KEY);
    if (!raw) return [];
    const map: Record<string, QueuedUserNotification[]> = JSON.parse(raw);
    const myAliases = new Set<string>();
    userIdentifiers.forEach((id) => {
      if (id) getIdentityAliases(id).forEach((a) => myAliases.add(a.toLowerCase()));
    });
    if (myAliases.size === 0) return [];

    const consumed: QueuedUserNotification[] = [];
    let mutated = false;

    Object.keys(map).forEach((bucketKey) => {
      const bucketAliases = bucketKey.split('|').map((s) => s.toLowerCase());
      if (bucketAliases.some((a) => myAliases.has(a))) {
        const items = Array.isArray(map[bucketKey]) ? map[bucketKey] : [];
        consumed.push(...items);
        delete map[bucketKey];
        mutated = true;
      }
    });

    if (mutated) {
      localStorage.setItem(USER_NOTIF_QUEUE_STORAGE_KEY, JSON.stringify(map));
    }
    return consumed;
  } catch (e) {
    console.warn('Could not consume queued notifications:', e);
    return [];
  }
}

function reloadSocialMaps() {
  friendsMap = loadMapFromStorage(FRIENDS_STORAGE_KEY, friendsMap as any);
  followingMap = loadMapFromStorage(FOLLOWING_STORAGE_KEY, followingMap as any);
  friendRequestsReceived = loadRequestsFromStorage(REQ_RECEIVED_STORAGE_KEY);
  friendRequestsSent = loadRequestsFromStorage(REQ_SENT_STORAGE_KEY);
}

function resolveActorSummary(
  actor: AuthSession | { uid: string; userId?: string; name?: string; avatarUrl?: string } | string
): { uid: string; userId: string; name: string; avatarUrl?: string } {
  if (typeof actor !== 'string') {
    const rawUid = actor.uid || (actor as any).id || '';
    const rawHandle = (actor as any).userId || (actor as any).id || rawUid.replace(/^user-/, '');
    const sample = SAMPLE_USERS.find(
      (u) =>
        u.uid.toLowerCase() === rawUid.toLowerCase() ||
        u.userId.toLowerCase() === rawHandle.toLowerCase()
    );
    return {
      uid: rawUid || sample?.uid || `user-${rawHandle}`,
      userId: rawHandle || sample?.userId || rawUid,
      name: actor.name || sample?.name || rawHandle || rawUid,
      avatarUrl: actor.avatarUrl || sample?.avatarUrl,
    };
  }

  const aliases = new Set(getIdentityAliases(actor).map((a) => a.toLowerCase()));
  const sample = SAMPLE_USERS.find(
    (u) => aliases.has(u.uid.toLowerCase()) || aliases.has(u.userId.toLowerCase())
  );
  if (sample) {
    return {
      uid: sample.uid,
      userId: sample.userId,
      name: sample.name,
      avatarUrl: sample.avatarUrl,
    };
  }

  const customMap = loadCustomProfiles();
  const custom = Object.values(customMap).find(
    (p) => aliases.has(p.uid.toLowerCase()) || aliases.has(p.userId.toLowerCase())
  );
  if (custom) {
    return {
      uid: custom.uid,
      userId: custom.userId,
      name: custom.name,
      avatarUrl: custom.avatarUrl,
    };
  }

  try {
    const regRaw = localStorage.getItem('final_finance_registered_users');
    if (regRaw) {
      const regMap = JSON.parse(regRaw);
      for (const acc of Object.values<any>(regMap)) {
        const uId = acc?.userId ? String(acc.userId).toLowerCase() : '';
        const uidVal = acc?.uid ? String(acc.uid).toLowerCase() : '';
        if ((uId && aliases.has(uId)) || (uidVal && aliases.has(uidVal))) {
          return {
            uid: acc.uid || `user-${acc.userId}`,
            userId: acc.userId || actor,
            name: acc.name || acc.userId || actor,
            avatarUrl: acc.avatarUrl,
          };
        }
      }
    }
  } catch {
    // ignore
  }

  const clean = actor.replace(/^@/, '').replace(/^user-/, '');
  return {
    uid: actor.startsWith('user-') || actor.startsWith('demo-') ? actor : `user-${clean}`,
    userId: clean,
    name: clean,
  };
}

export async function getFriendsList(uid: string): Promise<UserPublicProfile[]> {
  reloadSocialMaps();
  const uidAliases = new Set(getIdentityAliases(uid).map((a) => a.toLowerCase()));
  const matched = new Map<string, UserPublicProfile>();

  for (const u of SAMPLE_USERS) {
    if (areUsersFriends(uid, u.uid) || areUsersFriends(uid, u.userId)) {
      matched.set(u.userId.toLowerCase(), u);
    }
  }

  // Also resolve any custom/registered friend IDs not in SAMPLE_USERS
  const candidateIds = new Set<string>();
  Object.entries(friendsMap).forEach(([key, set]) => {
    if (uidAliases.has(key.toLowerCase())) {
      set.forEach((t) => candidateIds.add(t));
    } else {
      for (const t of set) {
        if (uidAliases.has(t.toLowerCase())) {
          candidateIds.add(key);
          break;
        }
      }
    }
  });

  for (const cid of candidateIds) {
    if (areUsersBlockedEitherWay(uid, cid)) continue;
    const cidAliases = getIdentityAliases(cid).map((a) => a.toLowerCase());
    if (cidAliases.some((a) => matched.has(a))) continue;
    const resolved = await getUserProfile(cid);
    if (resolved && !uidAliases.has(resolved.uid.toLowerCase())) {
      matched.set(resolved.userId.toLowerCase(), resolved);
    }
  }

  return Array.from(matched.values());
}

export async function getFollowingList(uid: string): Promise<UserPublicProfile[]> {
  reloadSocialMaps();
  const uidAliases = new Set(getIdentityAliases(uid).map((a) => a.toLowerCase()));
  const matched = new Map<string, UserPublicProfile>();

  // 1. Sample users
  SAMPLE_USERS.forEach((u) => {
    if (
      (isUserFollowing(uid, u.uid) || isUserFollowing(uid, u.userId)) &&
      !areUsersBlockedEitherWay(uid, u.uid) &&
      !areUsersBlockedEitherWay(uid, u.userId)
    ) {
      matched.set(u.userId.toLowerCase(), u);
    }
  });

  // 2. Dynamic / synthesized / custom users from followingMap
  const candidateTargets = new Set<string>();
  Object.entries(followingMap).forEach(([key, set]) => {
    if (uidAliases.has(key.toLowerCase())) {
      set.forEach((target) => candidateTargets.add(target));
    }
  });

  for (const cid of candidateTargets) {
    if (areUsersBlockedEitherWay(uid, cid)) continue;
    const cidAliases = getIdentityAliases(cid).map((a) => a.toLowerCase());
    if (cidAliases.some((a) => matched.has(a))) continue;
    const resolved = await getUserProfile(cid);
    if (resolved && !uidAliases.has(resolved.uid.toLowerCase())) {
      matched.set(resolved.userId.toLowerCase(), resolved);
    }
  }

  return Array.from(matched.values());
}

export async function getFollowersList(uid: string): Promise<UserPublicProfile[]> {
  reloadSocialMaps();
  return SAMPLE_USERS.filter(
    u =>
      (isUserFollowing(u.uid, uid) || isUserFollowing(u.userId, uid)) &&
      !areUsersBlockedEitherWay(uid, u.uid) &&
      !areUsersBlockedEitherWay(uid, u.userId)
  );
}

export async function getFriendRequestsReceived(uid: string): Promise<FriendRequest[]> {
  reloadSocialMaps();
  if (!uid) return [];
  const myAliases = new Set(getIdentityAliases(uid).map((a) => a.toLowerCase()));
  const seenSenders = new Set<string>();
  const results: FriendRequest[] = [];

  Object.entries(friendRequestsReceived).forEach(([key, list]) => {
    const keyMatches = myAliases.has(key.toLowerCase());
    if (!Array.isArray(list)) return;
    list.forEach((req) => {
      const receiverMatches =
        keyMatches ||
        myAliases.has((req.receiverUid || '').toLowerCase()) ||
        myAliases.has((req.receiverHandle || '').toLowerCase());
      if (!receiverMatches) return;
      if (areUsersBlockedEitherWay(uid, req.senderUid) || areUsersBlockedEitherWay(uid, req.senderHandle)) return;
      if (areUsersFriends(uid, req.senderUid) || areUsersFriends(uid, req.senderHandle)) return;

      const senderKey = (req.senderHandle || req.senderUid).toLowerCase().replace(/^@/, '');
      if (seenSenders.has(senderKey)) return;
      seenSenders.add(senderKey);

      const senderInfo = resolveActorSummary({
        uid: req.senderUid,
        userId: req.senderHandle,
        name: req.senderName === req.senderUid ? undefined : req.senderName,
        avatarUrl: req.senderAvatarUrl,
      });

      results.push({
        ...req,
        senderName: senderInfo.name || req.senderName,
        senderHandle: senderInfo.userId || req.senderHandle,
        senderAvatarUrl: req.senderAvatarUrl || senderInfo.avatarUrl,
      });
    });
  });

  return results;
}

export async function getFriendRequestsSent(uid: string): Promise<FriendRequest[]> {
  reloadSocialMaps();
  if (!uid) return [];
  const myAliases = new Set(getIdentityAliases(uid).map((a) => a.toLowerCase()));
  const seenReceivers = new Set<string>();
  const results: FriendRequest[] = [];

  Object.entries(friendRequestsSent).forEach(([key, list]) => {
    const keyMatches = myAliases.has(key.toLowerCase());
    if (!Array.isArray(list)) return;
    list.forEach((req) => {
      const senderMatches =
        keyMatches ||
        myAliases.has((req.senderUid || '').toLowerCase()) ||
        myAliases.has((req.senderHandle || '').toLowerCase());
      if (!senderMatches) return;
      if (areUsersBlockedEitherWay(uid, req.receiverUid) || areUsersBlockedEitherWay(uid, req.receiverHandle)) return;
      if (areUsersFriends(uid, req.receiverUid) || areUsersFriends(uid, req.receiverHandle)) return;

      const receiverKey = (req.receiverHandle || req.receiverUid).toLowerCase().replace(/^@/, '');
      if (seenReceivers.has(receiverKey)) return;
      seenReceivers.add(receiverKey);

      const receiverInfo = resolveActorSummary({
        uid: req.receiverUid,
        userId: req.receiverHandle,
        name: req.receiverName === req.receiverUid ? undefined : req.receiverName,
        avatarUrl: req.receiverAvatarUrl,
      });

      results.push({
        ...req,
        receiverName: receiverInfo.name || req.receiverName,
        receiverHandle: receiverInfo.userId || req.receiverHandle,
        receiverAvatarUrl: req.receiverAvatarUrl || receiverInfo.avatarUrl,
      });
    });
  });

  return results;
}

export async function followUser(
  currentUser: AuthSession | string, 
  target: { uid: string; userId: string } | string
): Promise<void> {
  reloadSocialMaps();
  const currentUid = typeof currentUser === 'string' ? currentUser : (currentUser.uid || currentUser.id);
  const targetUid = typeof target === 'string' ? target : (target.uid || target.userId);
  if (!currentUid || !targetUid) return;
  if (!followingMap[currentUid]) {
    followingMap[currentUid] = new Set();
  }
  followingMap[currentUid].add(targetUid);
  saveMapToStorage(FOLLOWING_STORAGE_KEY, followingMap);
  emitFriendsUpdated(currentUid, targetUid);
}

export async function unfollowUser(currentUid: string, targetUid: string): Promise<void> {
  reloadSocialMaps();
  const currentAliases = new Set(getIdentityAliases(currentUid).map((a) => a.toLowerCase()));
  const targetAliases = new Set(getIdentityAliases(targetUid).map((a) => a.toLowerCase()));
  let changed = false;

  Object.entries(followingMap).forEach(([key, set]) => {
    if (!currentAliases.has(key.toLowerCase())) return;
    Array.from(set).forEach((entry) => {
      if (targetAliases.has(entry.toLowerCase())) {
        set.delete(entry);
        changed = true;
      }
    });
  });

  if (changed || followingMap[currentUid]?.has(targetUid)) {
    followingMap[currentUid]?.delete(targetUid);
    saveMapToStorage(FOLLOWING_STORAGE_KEY, followingMap);
  }
  emitFriendsUpdated(currentUid, targetUid);
}

export async function sendFriendRequest(
  currentUser: AuthSession | { uid: string; userId?: string; name?: string; avatarUrl?: string } | string,
  target: { uid: string; userId?: string; name?: string; avatarUrl?: string } | string
): Promise<'sent' | 'accepted' | 'already_friends' | 'blocked'> {
  reloadSocialMaps();
  const sender = resolveActorSummary(currentUser);
  const receiver = resolveActorSummary(target);

  const senderUid = sender.uid;
  const senderHandle = sender.userId;
  const senderName = sender.name;
  const senderAvatarUrl = sender.avatarUrl;

  const receiverUid = receiver.uid;
  const receiverHandle = receiver.userId;
  const receiverName = receiver.name;
  const receiverAvatarUrl = receiver.avatarUrl;

  const senderAliases = new Set(getIdentityAliases(senderUid).concat(getIdentityAliases(senderHandle)).map((a) => a.toLowerCase()));
  const receiverAliases = new Set(getIdentityAliases(receiverUid).concat(getIdentityAliases(receiverHandle)).map((a) => a.toLowerCase()));

  // Guard against self-request or blocks
  if (Array.from(senderAliases).some((a) => receiverAliases.has(a))) {
    return 'blocked';
  }
  if (areUsersBlockedEitherWay(senderUid, receiverUid) || areUsersBlockedEitherWay(senderHandle, receiverHandle)) {
    return 'blocked';
  }
  if (areUsersFriends(senderUid, receiverUid) || areUsersFriends(senderHandle, receiverHandle)) {
    return 'already_friends';
  }

  // Mutual rule: if the target user ALREADY sent a friend request to us, accepting it fulfills both sides
  const existingIncoming = await getFriendRequestsReceived(senderUid);
  const reciprocal = existingIncoming.find(
    (r) =>
      receiverAliases.has((r.senderUid || '').toLowerCase()) ||
      receiverAliases.has((r.senderHandle || '').toLowerCase())
  );
  if (reciprocal) {
    await acceptFriendRequest(
      { uid: senderUid, userId: senderHandle, name: senderName, avatarUrl: senderAvatarUrl },
      { uid: reciprocal.senderUid, userId: reciprocal.senderHandle, name: reciprocal.senderName, avatarUrl: reciprocal.senderAvatarUrl }
    );
    return 'accepted';
  }

  // Deduplicate existing sent requests from any sender alias to any receiver alias
  const existingSent = await getFriendRequestsSent(senderUid);
  const alreadySent = existingSent.some(
    (r) =>
      receiverAliases.has((r.receiverUid || '').toLowerCase()) ||
      receiverAliases.has((r.receiverHandle || '').toLowerCase())
  );
  if (alreadySent) {
    return 'sent';
  }

  const req: FriendRequest = {
    id: `${senderUid}_${receiverUid}`,
    senderUid,
    senderHandle,
    senderName,
    senderAvatarUrl,
    receiverUid,
    receiverHandle,
    receiverName,
    receiverAvatarUrl,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  if (!friendRequestsSent[senderUid]) friendRequestsSent[senderUid] = [];
  friendRequestsSent[senderUid].push(req);
  saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);

  if (!friendRequestsReceived[receiverUid]) friendRequestsReceived[receiverUid] = [];
  friendRequestsReceived[receiverUid].push(req);
  saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);

  // Queue notification for the receiving account
  enqueueNotificationForAliases(
    [receiverUid, receiverHandle],
    {
      title: '🤝 New Friend Request',
      description: `${senderName} (@${senderHandle}) sent you a friend request. Accept to become mutual friends.`,
      type: 'social',
      targetTab: 'social',
      targetId: senderHandle || senderUid,
    }
  );

  // Record outgoing friend request in the current user's notification center
  window.dispatchEvent(new CustomEvent('ff-app-notification', {
    detail: {
      title: '📤 Friend Request Sent',
      description: `Friend request sent to ${receiverName} (@${receiverHandle}). Both sides must accept to become friends.`,
      type: 'social',
      targetTab: 'social',
      targetId: receiverHandle || receiverUid,
    }
  }));

  emitFriendsUpdated(senderUid, receiverUid);
  return 'sent';
}

export async function cancelFriendRequest(currentUid: string, targetUid: string): Promise<void> {
  reloadSocialMaps();
  const currentAliases = new Set(getIdentityAliases(currentUid).map((a) => a.toLowerCase()));
  const targetAliases = new Set(getIdentityAliases(targetUid).map((a) => a.toLowerCase()));

  Object.keys(friendRequestsSent).forEach((key) => {
    if (currentAliases.has(key.toLowerCase())) {
      friendRequestsSent[key] = friendRequestsSent[key].filter(
        (r) => !targetAliases.has((r.receiverUid || '').toLowerCase()) && !targetAliases.has((r.receiverHandle || '').toLowerCase())
      );
    }
  });
  Object.keys(friendRequestsReceived).forEach((key) => {
    if (targetAliases.has(key.toLowerCase())) {
      friendRequestsReceived[key] = friendRequestsReceived[key].filter(
        (r) => !currentAliases.has((r.senderUid || '').toLowerCase()) && !currentAliases.has((r.senderHandle || '').toLowerCase())
      );
    }
  });

  saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);
  saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);
  emitFriendsUpdated(currentUid, targetUid);
}

export async function acceptFriendRequest(
  currentUser: AuthSession | { uid: string; userId?: string; name?: string; avatarUrl?: string } | string,
  sender: { uid: string; userId?: string; name?: string; avatarUrl?: string } | string
): Promise<void> {
  reloadSocialMaps();
  const accepter = resolveActorSummary(currentUser);
  const requester = resolveActorSummary(sender);

  const currentUid = accepter.uid;
  const senderUid = requester.uid;

  if (!friendsMap[currentUid]) friendsMap[currentUid] = new Set();
  friendsMap[currentUid].add(senderUid);

  if (!friendsMap[senderUid]) friendsMap[senderUid] = new Set();
  friendsMap[senderUid].add(currentUid);
  saveMapToStorage(FRIENDS_STORAGE_KEY, friendsMap);

  const currentAliases = new Set(getIdentityAliases(currentUid).concat(getIdentityAliases(accepter.userId)).map((a) => a.toLowerCase()));
  const senderAliases = new Set(getIdentityAliases(senderUid).concat(getIdentityAliases(requester.userId)).map((a) => a.toLowerCase()));

  Object.keys(friendRequestsReceived).forEach((key) => {
    if (currentAliases.has(key.toLowerCase())) {
      friendRequestsReceived[key] = friendRequestsReceived[key].filter(
        (r) => !senderAliases.has((r.senderUid || '').toLowerCase()) && !senderAliases.has((r.senderHandle || '').toLowerCase())
      );
    }
    if (senderAliases.has(key.toLowerCase())) {
      friendRequestsReceived[key] = friendRequestsReceived[key].filter(
        (r) => !currentAliases.has((r.senderUid || '').toLowerCase()) && !currentAliases.has((r.senderHandle || '').toLowerCase())
      );
    }
  });
  Object.keys(friendRequestsSent).forEach((key) => {
    if (senderAliases.has(key.toLowerCase())) {
      friendRequestsSent[key] = friendRequestsSent[key].filter(
        (r) => !currentAliases.has((r.receiverUid || '').toLowerCase()) && !currentAliases.has((r.receiverHandle || '').toLowerCase())
      );
    }
    if (currentAliases.has(key.toLowerCase())) {
      friendRequestsSent[key] = friendRequestsSent[key].filter(
        (r) => !senderAliases.has((r.receiverUid || '').toLowerCase()) && !senderAliases.has((r.receiverHandle || '').toLowerCase())
      );
    }
  });

  saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);
  saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);

  enqueueNotificationForAliases(
    [senderUid, requester.userId],
    {
      title: '🌟 Friend Request Accepted',
      description: `${accepter.name} (@${accepter.userId}) accepted your friend request. You are now mutual friends!`,
      type: 'social',
      targetTab: 'social',
      targetId: accepter.userId || currentUid,
    }
  );

  window.dispatchEvent(new CustomEvent('ff-app-notification', {
    detail: {
      title: '🌟 Mutual Friendship Confirmed',
      description: `You and ${requester.name} (@${requester.userId}) are now mutual friends.`,
      type: 'social',
      targetTab: 'social',
      targetId: requester.userId || senderUid,
    }
  }));
  emitFriendsUpdated(currentUid, senderUid);
}

// Adding a friend always requires mutual two-sided acceptance via friend request
export async function addFriend(
  currentUser: AuthSession | { uid: string; userId?: string; name?: string; avatarUrl?: string } | string,
  target: { uid: string; userId?: string; name?: string; avatarUrl?: string } | string
): Promise<'sent' | 'accepted' | 'already_friends' | 'blocked'> {
  return sendFriendRequest(currentUser, target);
}

export async function declineFriendRequest(currentUid: string, senderUid: string): Promise<void> {
  reloadSocialMaps();
  const currentAliases = new Set(getIdentityAliases(currentUid).map((a) => a.toLowerCase()));
  const senderAliases = new Set(getIdentityAliases(senderUid).map((a) => a.toLowerCase()));

  Object.keys(friendRequestsReceived).forEach((key) => {
    if (currentAliases.has(key.toLowerCase())) {
      friendRequestsReceived[key] = friendRequestsReceived[key].filter(
        (r) => !senderAliases.has((r.senderUid || '').toLowerCase()) && !senderAliases.has((r.senderHandle || '').toLowerCase())
      );
    }
  });
  Object.keys(friendRequestsSent).forEach((key) => {
    if (senderAliases.has(key.toLowerCase())) {
      friendRequestsSent[key] = friendRequestsSent[key].filter(
        (r) => !currentAliases.has((r.receiverUid || '').toLowerCase()) && !currentAliases.has((r.receiverHandle || '').toLowerCase())
      );
    }
  });

  saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);
  saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);
  emitFriendsUpdated(currentUid, senderUid);
}

export async function removeFriend(currentUid: string, targetUid: string): Promise<void> {
  reloadSocialMaps();
  const currentAliases = new Set(getIdentityAliases(currentUid).map((a) => a.toLowerCase()));
  const targetAliases = new Set(getIdentityAliases(targetUid).map((a) => a.toLowerCase()));

  Object.entries(friendsMap).forEach(([key, set]) => {
    const keyLower = key.toLowerCase();
    if (currentAliases.has(keyLower)) {
      Array.from(set).forEach((entry) => {
        if (targetAliases.has(entry.toLowerCase())) {
          set.delete(entry);
        }
      });
    }
    if (targetAliases.has(keyLower)) {
      Array.from(set).forEach((entry) => {
        if (currentAliases.has(entry.toLowerCase())) {
          set.delete(entry);
        }
      });
    }
  });

  // Also clear any pending requests between aliases so status resets cleanly to 'none'
  Object.keys(friendRequestsSent).forEach((key) => {
    if (currentAliases.has(key.toLowerCase())) {
      friendRequestsSent[key] = friendRequestsSent[key].filter(
        (r) => !targetAliases.has((r.receiverUid || '').toLowerCase()) && !targetAliases.has((r.receiverHandle || '').toLowerCase())
      );
    }
    if (targetAliases.has(key.toLowerCase())) {
      friendRequestsSent[key] = friendRequestsSent[key].filter(
        (r) => !currentAliases.has((r.receiverUid || '').toLowerCase()) && !currentAliases.has((r.receiverHandle || '').toLowerCase())
      );
    }
  });
  Object.keys(friendRequestsReceived).forEach((key) => {
    if (currentAliases.has(key.toLowerCase())) {
      friendRequestsReceived[key] = friendRequestsReceived[key].filter(
        (r) => !targetAliases.has((r.senderUid || '').toLowerCase()) && !targetAliases.has((r.senderHandle || '').toLowerCase())
      );
    }
    if (targetAliases.has(key.toLowerCase())) {
      friendRequestsReceived[key] = friendRequestsReceived[key].filter(
        (r) => !currentAliases.has((r.senderUid || '').toLowerCase()) && !currentAliases.has((r.senderHandle || '').toLowerCase())
      );
    }
  });

  saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);
  saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);
  saveMapToStorage(FRIENDS_STORAGE_KEY, friendsMap);
  emitFriendsUpdated(currentUid, targetUid);
}

const BLOCKED_STORAGE_KEY = 'final_finance_blocked_users_map';

function loadBlockedMap(): Record<string, Set<string>> {
  try {
    const raw = localStorage.getItem(BLOCKED_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const res: Record<string, Set<string>> = {};
      Object.entries(parsed).forEach(([uid, list]) => {
        if (Array.isArray(list)) {
          res[uid] = new Set(list);
        }
      });
      return res;
    }
  } catch (e) {
    console.error('Error reading blocked map:', e);
  }
  return {};
}

function saveBlockedMap(map: Record<string, Set<string>>) {
  try {
    const serializable: Record<string, string[]> = {};
    Object.entries(map).forEach(([uid, set]) => {
      serializable[uid] = Array.from(set);
    });
    localStorage.setItem(BLOCKED_STORAGE_KEY, JSON.stringify(serializable));
  } catch (e) {
    console.error('Error saving blocked map:', e);
  }
}

const KNOWN_UID_ALIAS_GROUPS: string[][] = [
  ['demo-ranma-superadmin', 'demo-super-admin', 'super_admin_ranma', 'ranmaanimaker@gmail.com', 'adm-1', 'ranma'],
  ['demo-dbz-admin', 'demo-admin-officer', 'officer_dbz', 'awesomedbz@gmail.com', 'adm-2', 'awesomedbz'],
  ['demo-alex-morgan', 'demo-vip-alex', 'alex_morgan', 'alex@finalfinance.io'],
  ['demo-satoshi-nakamoto', 'creator_satoshi', 'satoshi_nakamoto', 'satoshi', 'satoshi@finalfinance.io', 'adm-4'],
  ['demo-jordan-belfort', 'demo-jordan', 'jordan_belfort', 'jordan', 'jordan@finalfinance.io', 'adm-3'],
  ['user-elena_rostova', 'creator_elena', 'demo-elena', 'elena_rostova', 'elena_compliance', 'elena', 'elena@monaco-yachting.mc', 'elena.rostova@finalfinance.io', 'adm-5'],
  ['user-alex_chen', 'creator_alex_chen', 'alex_chen', 'alex.chen@finalfinance.io'],
  ['user-marcus_vance', 'demo-marcus', 'quant_trader_mark', 'marcus_vance', 'vance_capital', 'marcus@vance-holdings.com', 'marcus.vance@finalfinance.io', 'adm-6'],
  ['user-lord_sterling', 'lord_sterling', 'sterling_vault', 'sterling@zurich-escrow.ch'],
  ['user-gholu653', 'gholu653', 'gholu653@gmail.com'],
  ['guest', 'guest_user'],
  ['drv-econ-1', 'lukas_meyer', 'lukas meyer', 'user-lukas_meyer'],
  ['drv-ev-1', 'drv-elena', 'elena_vance', 'driver_elena', 'elena vance', 'user-elena_vance'],
  ['drv-lux-1', 'marc_weber', 'marc-antoine weber', 'marc weber', 'user-marc_weber'],
  ['drv-rick-1', 'aarav_patel', 'aarav patel', 'user-aarav_patel'],
  ['drv-moto-1', 'matteo_rossi', 'matteo rossi', 'user-matteo_rossi'],
  ['drv-marco', 'driver_marco', 'marco rossi', 'user-driver_marco'],
  ['drv-sven', 'driver_sven', 'sven keller', 'user-driver_sven'],
  ['drv-chloe', 'driver_chloe', 'chloe dubois', 'user-driver_chloe'],
  ['driver-hans', 'hansruedi_keller', 'hansruedi keller', 'user-hansruedi_keller'],
  ['merchant-sovereign', 'sovereign_merchant', 'merchant', 'user-sovereign_merchant', 'freeport.retail@sovereign.ch', 'sovereign merchant'],
];

export function getIdentityAliases(idOrHandle: string): string[] {
  if (!idOrHandle) return [];
  const raw = idOrHandle.trim();
  const lower = raw.toLowerCase();
  const clean = lower.replace(/^@/, '');
  const aliases = new Set<string>([raw, lower, clean]);

  if (clean.startsWith('user-')) {
    aliases.add(clean.slice(5));
  } else if (clean.startsWith('demo-')) {
    aliases.add(clean.slice(5));
  } else if (clean.startsWith('google-')) {
    const bare = clean.slice(7);
    aliases.add(bare);
    aliases.add(`user-${bare}`);
  } else if (clean.startsWith('creator_')) {
    const bare = clean.slice(8);
    aliases.add(bare);
    aliases.add(`user-${bare}`);
  } else {
    aliases.add(`user-${clean}`);
    aliases.add(`google-${clean}`);
  }

  for (const group of KNOWN_UID_ALIAS_GROUPS) {
    if (group.some((item) => item.toLowerCase() === clean || item.toLowerCase() === lower)) {
      group.forEach((item) => aliases.add(item.toLowerCase()));
    }
  }

  const sampleMatch = SAMPLE_USERS.find(
    (u) =>
      u.uid.toLowerCase() === clean ||
      u.userId.toLowerCase() === clean ||
      (u.email && u.email.toLowerCase() === clean)
  );
  if (sampleMatch) {
    aliases.add(sampleMatch.uid.toLowerCase());
    aliases.add(sampleMatch.userId.toLowerCase());
    aliases.add(`user-${sampleMatch.userId.toLowerCase()}`);
    if (sampleMatch.email) aliases.add(sampleMatch.email.toLowerCase());
  }

  try {
    const storedReg = localStorage.getItem('final_finance_registered_users');
    if (storedReg) {
      const regMap = JSON.parse(storedReg);
      Object.values<any>(regMap).forEach((acc) => {
        const accUid = acc?.uid ? String(acc.uid).toLowerCase() : '';
        const accUserId = acc?.userId ? String(acc.userId).toLowerCase() : '';
        const accEmail = acc?.email ? String(acc.email).toLowerCase() : '';
        if (
          (accUid && aliases.has(accUid)) ||
          (accUserId && (aliases.has(accUserId) || aliases.has(`user-${accUserId}`))) ||
          (accEmail && aliases.has(accEmail))
        ) {
          if (accUid) aliases.add(accUid);
          if (accUserId) {
            aliases.add(accUserId);
            aliases.add(`user-${accUserId}`);
          }
          if (accEmail) aliases.add(accEmail);
        }
      });
    }
  } catch {
    // ignore storage parse error
  }

  return Array.from(aliases).filter(Boolean);
}

const ADMIN_EMAILS = new Set(['ranmaanimaker@gmail.com', 'awesomedbz@gmail.com', 'jordan@finalfinance.io']);
const ADMIN_IDENTIFIERS = new Set([
  'admin',
  'super_admin',
  'super_admin_ranma',
  'demo-super-admin',
  'demo-ranma-superadmin',
  'officer_dbz',
  'demo-admin-officer',
  'demo-dbz-admin',
  'jordan_belfort',
  'demo-jordan-belfort',
  'demo-jordan',
  'jordan',
  'ranmaanimaker@gmail.com',
  'awesomedbz@gmail.com',
  'jordan@finalfinance.io',
]);

export function isAdminAccount(
  identifierOrUser?:
    | string
    | { role?: string; email?: string; uid?: string; id?: string; userId?: string; handle?: string }
    | null
): boolean {
  if (!identifierOrUser) return false;

  if (typeof identifierOrUser === 'object') {
    if (identifierOrUser.role === 'admin' || identifierOrUser.role === 'super_admin') {
      return true;
    }
    if (identifierOrUser.email && ADMIN_EMAILS.has(identifierOrUser.email.trim().toLowerCase())) {
      return true;
    }
    const candidates = [
      identifierOrUser.uid,
      identifierOrUser.id,
      identifierOrUser.userId,
      identifierOrUser.handle,
    ].filter(Boolean) as string[];
    return candidates.some((c) => isAdminAccount(c));
  }

  const raw = identifierOrUser.trim();
  if (!raw) return false;

  const aliases = getIdentityAliases(raw).map((a) => a.toLowerCase());
  if (aliases.some((a) => ADMIN_IDENTIFIERS.has(a) || ADMIN_EMAILS.has(a))) {
    return true;
  }

  const aliasSet = new Set(aliases);

  const sampleAdminMatch = SAMPLE_USERS.find(
    (u) =>
      (u.role === 'admin' || u.role === 'super_admin') &&
      (aliasSet.has(u.uid.toLowerCase()) ||
        aliasSet.has(u.userId.toLowerCase()) ||
        (u.email ? aliasSet.has(u.email.toLowerCase()) : false))
  );
  if (sampleAdminMatch) return true;

  try {
    const customProfiles = loadCustomProfiles();
    const matchedCustom = Object.values(customProfiles).find(
      (p) =>
        (p.role === 'admin' || p.role === 'super_admin') &&
        (aliasSet.has((p.uid || '').toLowerCase()) ||
          aliasSet.has((p.userId || '').toLowerCase()) ||
          (p.email ? aliasSet.has(p.email.toLowerCase()) : false))
    );
    if (matchedCustom) return true;
  } catch {
    // ignore
  }

  try {
    const regRaw = localStorage.getItem('final_finance_registered_users');
    if (regRaw) {
      const regMap = JSON.parse(regRaw);
      const matchedReg = Object.values<any>(regMap).find(
        (acc) =>
          (acc?.role === 'admin' || acc?.role === 'super_admin' || (acc?.email && ADMIN_EMAILS.has(String(acc.email).trim().toLowerCase()))) &&
          (aliasSet.has(String(acc.uid || '').toLowerCase()) ||
            aliasSet.has(String(acc.userId || '').toLowerCase()) ||
            aliasSet.has(String(acc.email || '').toLowerCase()))
      );
      if (matchedReg) return true;
    }
  } catch {
    // ignore
  }

  try {
    const sessRaw = localStorage.getItem('final_finance_auth_session');
    if (sessRaw) {
      const sess = JSON.parse(sessRaw);
      if (
        sess &&
        (sess.role === 'admin' || sess.role === 'super_admin' || (sess.email && ADMIN_EMAILS.has(String(sess.email).trim().toLowerCase()))) &&
        (aliasSet.has(String(sess.uid || '').toLowerCase()) ||
          aliasSet.has(String(sess.id || '').toLowerCase()) ||
          aliasSet.has(String(sess.email || '').toLowerCase()))
      ) {
        return true;
      }
    }
  } catch {
    // ignore
  }

  return false;
}

export function isCurrentSessionAdmin(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const raw = localStorage.getItem('final_finance_auth_session');
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    return isAdminAccount(parsed);
  } catch {
    return false;
  }
}

function hasBlockedEntry(map: Record<string, Set<string>>, blockerId: string, blockedId: string): boolean {
  if (!blockerId || !blockedId) return false;
  // Admins and super admins cannot be blocked
  if (isAdminAccount(blockedId)) return false;

  const blockerAliases = new Set(getIdentityAliases(blockerId));
  const blockedAliases = new Set(getIdentityAliases(blockedId));

  for (const [key, set] of Object.entries(map)) {
    if (!blockerAliases.has(key.toLowerCase())) continue;
    for (const target of set) {
      if (blockedAliases.has(target.toLowerCase())) {
        return true;
      }
    }
  }
  return false;
}

function emitBlockUpdated(currentUid: string, targetUid: string) {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('final_finance_block_updated', { detail: { currentUid, targetUid } }));
  }
}

function emitFriendsUpdated(currentUid: string, targetUid: string) {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('final_finance_friends_updated', { detail: { currentUid, targetUid } }));
  }
}

let blockedMap: Record<string, Set<string>> = loadBlockedMap();

export async function blockUser(currentUid: string, targetUid: string): Promise<void> {
  // Admins and super admins cannot be blocked
  if (isAdminAccount(targetUid)) {
    return;
  }
  blockedMap = loadBlockedMap();
  if (!blockedMap[currentUid]) {
    blockedMap[currentUid] = new Set();
  }
  blockedMap[currentUid].add(targetUid);
  saveBlockedMap(blockedMap);
  // Also unfollow and unfriend if blocked
  await unfollowUser(currentUid, targetUid);
  await removeFriend(currentUid, targetUid);
  emitBlockUpdated(currentUid, targetUid);
}

export async function unblockUser(currentUid: string, targetUid: string): Promise<void> {
  blockedMap = loadBlockedMap();
  const blockerAliases = new Set(getIdentityAliases(currentUid));
  const blockedAliases = new Set(getIdentityAliases(targetUid));
  let changed = false;

  Object.entries(blockedMap).forEach(([key, set]) => {
    if (!blockerAliases.has(key.toLowerCase())) return;
    Array.from(set).forEach((entry) => {
      if (blockedAliases.has(entry.toLowerCase())) {
        set.delete(entry);
        changed = true;
      }
    });
  });

  if (changed) {
    saveBlockedMap(blockedMap);
  }
  emitBlockUpdated(currentUid, targetUid);
}

export async function isUserBlocked(currentUid: string, targetUid: string): Promise<boolean> {
  return isUserBlockedByMe(currentUid, targetUid);
}

export function isUserBlockedByMe(currentUid: string, targetUid: string): boolean {
  if (isAdminAccount(targetUid)) return false;
  const map = loadBlockedMap();
  return hasBlockedEntry(map, currentUid, targetUid);
}

export function isUserBlockedByTarget(currentUid: string, targetUid: string): boolean {
  if (isAdminAccount(currentUid)) return false;
  const map = loadBlockedMap();
  return hasBlockedEntry(map, targetUid, currentUid);
}

export function areUsersBlockedEitherWay(uid1: string, uid2: string): boolean {
  if (!uid1 || !uid2) return false;
  const map = loadBlockedMap();
  return hasBlockedEntry(map, uid1, uid2) || hasBlockedEntry(map, uid2, uid1);
}

export function areUsersFriends(uid1: string, uid2: string): boolean {
  if (!uid1 || !uid2) return false;
  if (areUsersBlockedEitherWay(uid1, uid2)) return false;
  const aliases1 = new Set(getIdentityAliases(uid1));
  const aliases2 = new Set(getIdentityAliases(uid2));

  for (const [key, set] of Object.entries(friendsMap)) {
    if (aliases1.has(key.toLowerCase())) {
      for (const target of set) {
        if (aliases2.has(target.toLowerCase())) return true;
      }
    }
    if (aliases2.has(key.toLowerCase())) {
      for (const target of set) {
        if (aliases1.has(target.toLowerCase())) return true;
      }
    }
  }
  return false;
}

export function isUserFollowing(currentUid: string, targetUidOrHandle: string): boolean {
  if (!currentUid || !targetUidOrHandle) return false;
  reloadSocialMaps();
  if (areUsersBlockedEitherWay(currentUid, targetUidOrHandle)) return false;
  const currentAliases = new Set(getIdentityAliases(currentUid).map(a => a.toLowerCase()));
  const targetAliases = new Set(getIdentityAliases(targetUidOrHandle).map(a => a.toLowerCase()));

  for (const [key, followingSet] of Object.entries(followingMap)) {
    if (currentAliases.has(key.toLowerCase())) {
      for (const item of followingSet) {
        if (targetAliases.has(item.toLowerCase())) return true;
      }
    }
  }
  return false;
}

export function isUserFollowedOrFriend(currentUid: string, targetUidOrHandle: string): boolean {
  if (!currentUid || !targetUidOrHandle) return false;
  if (areUsersBlockedEitherWay(currentUid, targetUidOrHandle)) return false;
  if (areUsersFriends(currentUid, targetUidOrHandle)) return true;
  if (isUserFollowing(currentUid, targetUidOrHandle)) return true;
  return false;
}

export async function getBlockedUsers(currentUid: string): Promise<UserPublicProfile[]> {
  const map = loadBlockedMap();
  const blockerAliases = new Set(getIdentityAliases(currentUid));
  const blockedUids = new Set<string>();

  Object.entries(map).forEach(([key, set]) => {
    if (blockerAliases.has(key.toLowerCase())) {
      set.forEach((uid) => blockedUids.add(uid));
    }
  });

  const list: UserPublicProfile[] = [];
  const seenProfileUids = new Set<string>();

  for (const uid of blockedUids) {
    const profile = await getUserProfile(uid);
    if (profile && !seenProfileUids.has(profile.uid)) {
      seenProfileUids.add(profile.uid);
      list.push(profile);
    }
  }
  return list;
}

export async function getRelationshipStatus(currentUid: string, targetUid: string): Promise<RelationshipStatus> {
  reloadSocialMaps();
  const isFollowing = isUserFollowing(currentUid, targetUid);
  const isFollower = isUserFollowing(targetUid, currentUid);
  const isFriend = areUsersFriends(currentUid, targetUid);

  const isBlockedByMe = isUserBlockedByMe(currentUid, targetUid);
  const isBlockedByTarget = isUserBlockedByTarget(currentUid, targetUid);
  const isBlocked = isBlockedByMe || isBlockedByTarget;

  const currentAliases = new Set(getIdentityAliases(currentUid).map((a) => a.toLowerCase()));
  const targetAliases = new Set(getIdentityAliases(targetUid).map((a) => a.toLowerCase()));

  const hasSentPending = Object.entries(friendRequestsSent).some(([k, list]) =>
    Array.isArray(list) &&
    list.some((r) => {
      const fromMe =
        currentAliases.has(k.toLowerCase()) ||
        currentAliases.has((r.senderUid || '').toLowerCase()) ||
        currentAliases.has((r.senderHandle || '').toLowerCase());
      const toTarget =
        targetAliases.has((r.receiverUid || '').toLowerCase()) ||
        targetAliases.has((r.receiverHandle || '').toLowerCase());
      return fromMe && toTarget;
    })
  );

  const hasReceivedPending = Object.entries(friendRequestsReceived).some(([k, list]) =>
    Array.isArray(list) &&
    list.some((r) => {
      const forMe =
        currentAliases.has(k.toLowerCase()) ||
        currentAliases.has((r.receiverUid || '').toLowerCase()) ||
        currentAliases.has((r.receiverHandle || '').toLowerCase());
      const fromTarget =
        targetAliases.has((r.senderUid || '').toLowerCase()) ||
        targetAliases.has((r.senderHandle || '').toLowerCase());
      return forMe && fromTarget;
    })
  );

  let friendStatus: RelationshipStatus['friendStatus'] = 'none';
  if (isFriend) {
    friendStatus = 'friends';
  } else if (hasSentPending) {
    friendStatus = 'pending_sent';
  } else if (hasReceivedPending) {
    friendStatus = 'pending_received';
  }

  return {
    isFollowing,
    isFollower,
    isFriend,
    friendStatus,
    isBlocked,
    isBlockedByMe,
    isBlockedByTarget
  };
}

const FAVORITES_STORAGE_KEY = 'final_finance_favorited_users_v2';

export function getFavoritedUserIds(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Error reading favorited users:', e);
    return [];
  }
}

export function toggleFavoriteUser(uid: string): string[] {
  try {
    const list = getFavoritedUserIds();
    const index = list.indexOf(uid);
    let updated: string[];
    if (index >= 0) {
      updated = list.filter((id) => id !== uid);
    } else {
      updated = [...list, uid];
    }
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Error toggling favorite user:', e);
    return [];
  }
}

export function isUserFavorited(uid: string): boolean {
  return getFavoritedUserIds().includes(uid);
}

export async function getMutualFriends(currentUid: string): Promise<{ user: UserPublicProfile; mutuals: UserPublicProfile[] }[]> {
  const myFriends = friendsMap[currentUid] || new Set<string>();
  const customMap = loadCustomProfiles();
  const blockedMap = loadBlockedMap();
  const blockedByMe = blockedMap[currentUid] || new Set();

  // Find all uids who have blocked currentUid
  const blockedMe = new Set<string>();
  Object.entries(blockedMap).forEach(([uid, set]) => {
    if (set.has(currentUid)) {
      blockedMe.add(uid);
    }
  });

  // Collect all potential users in the system
  const allUsers = [...SAMPLE_USERS];
  Object.values(customMap).forEach((p) => {
    if (!allUsers.some((u) => u.uid === p.uid)) {
      allUsers.push(p);
    }
  });

  const results: { user: UserPublicProfile; mutuals: UserPublicProfile[] }[] = [];

  for (const user of allUsers) {
    if (user.uid === currentUid) continue;
    if (blockedByMe.has(user.uid) || blockedMe.has(user.uid)) continue;

    // Direct friends of this user
    const userFriends = friendsMap[user.uid] || new Set<string>();
    
    // Intersection of myFriends and userFriends
    const intersection = Array.from(myFriends).filter((uid) => userFriends.has(uid));
    
    if (intersection.length > 0) {
      const mutualProfiles: UserPublicProfile[] = [];
      for (const mUid of intersection) {
        const profile = await getUserProfile(mUid);
        if (profile) {
          mutualProfiles.push(profile);
        }
      }
      results.push({
        user,
        mutuals: mutualProfiles,
      });
    }
  }

  return results;
}

export function registerDriverProfile(driver: { id: string; driverHandle?: string; driverName: string; driverAvatar?: string; carModel?: string }) {
  try {
    const customMap = loadCustomProfiles();
    const handle = (driver.driverHandle || driver.id || '').replace(/^@/, '').toLowerCase();
    const uid = `user-${handle || driver.id}`;
    const profile: UserPublicProfile = {
      uid,
      userId: handle || driver.id,
      name: driver.driverName || 'Sovereign Driver',
      avatarUrl: driver.driverAvatar || 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
      bio: driver.carModel ? `Professional Ride-Share & Delivery Driver · ${driver.carModel}` : 'Professional Sovereign Transport Driver',
      role: 'user',
      isVerified: true,
      isPrivate: false,
      createdAt: '2024-01-01T00:00:00.000Z',
      followersCount: 128,
      followingCount: 42,
      friendsCount: 15,
    };
    if (handle) customMap[handle] = profile;
    if (driver.id) customMap[driver.id.toLowerCase()] = profile;
    customMap[uid.toLowerCase()] = profile;
    saveCustomProfiles(customMap);
  } catch (e) {
    console.error('Error registering driver profile:', e);
  }
}

const KNOWN_MERCHANT_IDENTIFIERS = new Set<string>([
  'merchant-sovereign',
  'sovereign_merchant',
  'merchant-satoshi',
  'satoshi_nakamoto',
  'demo-satoshi-nakamoto',
  'jordan_belfort',
  'demo-jordan-belfort',
  'sterling_vault',
  'user-lord_sterling',
  'alex_morgan',
  'demo-alex-morgan',
  'super_admin_ranma',
  'demo-super-admin',
  'elena_rostova',
  'user-elena_rostova',
  'merchant_tokyo',
]);

export function isMerchantAccount(
  uid?: string | null,
  userId?: string | null
): boolean {
  const candidates = [uid, userId]
    .filter((v): v is string => typeof v === 'string' && v.trim().length > 0)
    .map((v) => v.trim().replace(/^@/, '').toLowerCase());

  if (candidates.length === 0) return false;

  for (const id of candidates) {
    if (KNOWN_MERCHANT_IDENTIFIERS.has(id)) return true;
  }

  try {
    const rawLocs = localStorage.getItem('final_finance_merchant_locations');
    if (rawLocs) {
      const locs = JSON.parse(rawLocs);
      if (Array.isArray(locs)) {
        for (const loc of locs) {
          const ownerIds = [loc?.ownerId, loc?.ownerHandle, loc?.ownerEmail]
            .filter((v): v is string => typeof v === 'string' && v.trim().length > 0)
            .map((v) => v.trim().replace(/^@/, '').toLowerCase());
          if (candidates.some((c) => ownerIds.includes(c))) {
            return true;
          }
        }
      }
    }
  } catch {
    // ignore storage errors
  }

  return false;
}


