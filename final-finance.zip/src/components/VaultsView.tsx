import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ReserveVault, AssetClass, VaultAsset } from '../types';
import { 
  Package, 
  Coins, 
  ShieldCheck, 
  Banknote, 
  Binary, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Search,
  Filter,
  Plus,
  ArrowDownUp
} from 'lucide-react';

interface VaultsViewProps {
  onOpenDepositModal: (vault: ReserveVault) => void;
}

export const VaultsView: React.FC<VaultsViewProps> = ({ onOpenDepositModal }) => {
  const { vaults = [], setCurrentTab, setStagedAssetForDraft } = useApp();
  const [selectedVaultId, setSelectedVaultId] = useState<AssetClass | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const totalEcosystemNAV = vaults.reduce((acc, v) => acc + (v.totalReserveUSD || 0), 0);
  const avgAuditScore = vaults.length > 0 
    ? (vaults.reduce((acc, v) => acc + (v.auditScore || 100), 0) / vaults.length).toFixed(1)
    : '100.0';

  const getVaultIcon = (id: AssetClass) => {
    switch (id) {
      case 'barter':
        return <Package className="h-4 w-4 text-amber-400" />;
      case 'final_coins':
        return <Coins className="h-4 w-4 text-amber-300" />;
      case 'stable_coins':
        return <ShieldCheck className="h-4 w-4 text-emerald-400" />;
      case 'fiat':
        return <Banknote className="h-4 w-4 text-sky-400" />;
      case 'crypto':
        return <Binary className="h-4 w-4 text-purple-400" />;
      default:
        return <Coins className="h-4 w-4 text-amber-400" />;
    }
  };

  const filteredVaults = selectedVaultId === 'all' 
    ? vaults 
    : vaults.filter(v => v.id === selectedVaultId);

  const allAssets: { vault: ReserveVault; asset: VaultAsset }[] = [];
  filteredVaults.forEach(vault => {
    (vault.reserveAssets || []).forEach(asset => {
      if (!searchQuery || (asset.name && asset.name.toLowerCase().includes(searchQuery.toLowerCase())) || (asset.symbol && asset.symbol.toLowerCase().includes(searchQuery.toLowerCase()))) {
        allAssets.push({ vault, asset });
      }
    });
  });

  return (
    <div className="space-y-6 pb-16">
      {/* Top Banner & Metric Header */}
      <div className="border border-neutral-800 bg-neutral-900/60 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold">
                Sovereign Protocol
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                Attested Reserve Ratio: 100%
              </span>
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1.5">
              5 Dedicated Reserve Vaults
            </h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-xl">
              Multi-collateral physical barter inventory, algorithmic Final Coins, sovereign fiat corridors, and cold-storage crypto.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-3 sm:gap-6 border-t md:border-t-0 md:border-l border-neutral-800 pt-3 md:pt-0 md:pl-6">
            <div>
              <span className="text-[10px] font-medium text-neutral-400 uppercase tracking-wider block">
                Total Reserve NAV
              </span>
              <p className="font-mono text-xl font-bold text-white mt-0.5">
                ${(totalEcosystemNAV / 1000000).toFixed(2)}M
              </p>
              <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                <TrendingUp className="h-3 w-3" /> +3.84% (24h)
              </span>
            </div>

            <div>
              <span className="text-[10px] font-medium text-neutral-400 uppercase tracking-wider block">
                Audit Rating
              </span>
              <p className="font-mono text-xl font-bold text-emerald-400 mt-0.5">
                {avgAuditScore}/100
              </p>
              <span className="text-[11px] text-neutral-400">
                AAA Institutional
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 5 Dedicated Vault Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        <button
          type="button"
          onClick={() => setSelectedVaultId('all')}
          className={`px-3 py-2.5 rounded-xl border text-left transition-all ${
            selectedVaultId === 'all'
              ? 'border-amber-500/60 bg-amber-500/10 text-white shadow-xs'
              : 'border-neutral-800 bg-neutral-900/40 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/70'
          }`}
        >
          <span className="text-[10px] font-mono text-neutral-400 block uppercase">All Reserves</span>
          <span className="text-xs font-bold block truncate mt-0.5">Complete Vault</span>
        </button>

        {vaults.map((vault) => {
          const isSelected = selectedVaultId === vault.id;
          const vaultDisplayName = vault.name || vault.shortCode || vault.id || 'Vault';
          const shortLabel = vaultDisplayName.split(' ')[0] || vaultDisplayName;
          
          return (
            <button
              key={vault.id}
              type="button"
              onClick={() => setSelectedVaultId(vault.id)}
              className={`px-3 py-2.5 rounded-xl border text-left transition-all ${
                isSelected
                  ? 'border-amber-500/60 bg-amber-500/10 text-white shadow-xs'
                  : 'border-neutral-800 bg-neutral-900/40 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/70'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-neutral-400 block uppercase truncate">
                  {shortLabel}
                </span>
                {getVaultIcon(vault.id)}
              </div>
              <span className="text-xs font-bold block truncate mt-0.5 text-neutral-200">
                ${((vault.totalReserveUSD || 0) / 1000000).toFixed(2)}M
              </span>
            </button>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-neutral-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search assets, bullion, commodities, or tickers..."
            className="w-full pl-9 pr-3 py-1.5 bg-neutral-900/70 border border-neutral-800 rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCurrentTab('wallets')}
            className="px-3 py-1.5 rounded-xl border border-neutral-700 bg-neutral-900 text-xs font-medium text-neutral-200 hover:text-white transition-colors"
          >
            My Wallets &rarr;
          </button>
        </div>
      </div>

      {/* Vault Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVaults.map((vault) => {
          const vaultName = vault.name || vault.shortCode || vault.id;
          const custodyLabel = vault.tagline || 'Institutional Depository Escrow';
          const backingRatio = vault.backingRatio || 100;
          const assets = vault.reserveAssets || [];

          return (
            <div
              key={vault.id}
              className="border border-neutral-800/90 bg-neutral-900/50 rounded-2xl p-4 flex flex-col justify-between hover:border-neutral-700 transition-all shadow-sm"
            >
              <div>
                <div className="flex items-start justify-between pb-3 border-b border-neutral-800/80">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                      {getVaultIcon(vault.id)}
                    </div>
                    <div>
                      <h3 className="font-serif text-base font-bold text-white tracking-wide">
                        {vaultName}
                      </h3>
                      <p className="text-[11px] text-neutral-400 line-clamp-1">
                        {custodyLabel}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 whitespace-nowrap">
                    {vault.change24h > 0 ? `+${vault.change24h}%` : `${vault.change24h}%`} 24h
                  </span>
                </div>

                {/* Balances & Backing */}
                <div className="grid grid-cols-2 gap-2 my-3 p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/60">
                  <div>
                    <span className="text-[10px] text-neutral-400 block uppercase font-mono">Reserve NAV</span>
                    <span className="text-sm font-bold text-amber-300 font-mono">
                      ${(vault.totalReserveUSD || 0).toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block uppercase font-mono">Backing Ratio</span>
                    <span className="text-sm font-bold text-white font-mono">
                      {backingRatio}%
                    </span>
                  </div>
                </div>

                {/* Asset List Preview */}
                <div className="space-y-1.5 mt-2">
                  <span className="text-[10px] font-mono uppercase text-neutral-400 tracking-wider">
                    Held Assets ({assets.length})
                  </span>
                  {assets.slice(0, 3).map((asset) => (
                    <div 
                      key={asset.id} 
                      className="flex items-center justify-between text-xs py-1 px-2 rounded-lg bg-neutral-900/60 border border-neutral-800/40"
                    >
                      <span className="font-medium text-neutral-200 truncate max-w-[140px]">
                        {asset.name}
                      </span>
                      <span className="font-mono text-neutral-400 text-[11px]">
                        ${(asset.totalValueUSD || 0).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="pt-4 mt-3 border-t border-neutral-800/80 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onOpenDepositModal(vault)}
                  className="flex-1 py-2 px-3 rounded-xl bg-amber-500 text-black text-xs font-bold hover:bg-amber-400 transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <ArrowDownLeft className="h-3.5 w-3.5" />
                  <span>Deposit / Allocate</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentTab('wallets')}
                  className="p-2 rounded-xl border border-neutral-700 bg-neutral-800/80 text-neutral-300 hover:text-white hover:bg-neutral-700 transition-colors"
                  title="View in Wallets"
                >
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
