import React from 'react';
import { AlertTriangle, UserX, X } from 'lucide-react';
import { AdminMember } from '../../services/adminGroupService';

interface AdminDeactivateConfirmModalProps {
  admin: AdminMember;
  onClose: () => void;
  onConfirm: () => void;
}

export const AdminDeactivateConfirmModal: React.FC<AdminDeactivateConfirmModalProps> = ({
  admin,
  onClose,
  onConfirm,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 border-b border-rose-100 flex items-center justify-between bg-rose-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 border border-rose-200">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-base font-bold text-slate-900">
                Confirm Deactivation
              </h3>
              <p className="text-xs text-rose-700 font-medium">
                Administrative security verification
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-rose-200/60 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600 leading-relaxed">
            Are you sure you want to deactivate the administrator account for{' '}
            <strong className="text-slate-900 font-bold">{admin.name}</strong>?
          </p>

          {/* Admin Summary Pill */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-sm">
              {admin.name.charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-slate-900 truncate">{admin.name}</span>
                <span className="font-mono text-[11px] text-amber-600">{admin.handle}</span>
              </div>
              <p className="text-[11px] text-slate-500 truncate mt-0.5">
                {admin.jobTitle || 'Administrator'} • <span className="uppercase font-mono text-[10px]">{admin.role}</span>
              </p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-rose-50/70 border border-rose-200 text-[11px] text-rose-800 leading-relaxed space-y-1">
            <p className="font-bold text-rose-900 flex items-center gap-1.5">
              <UserX className="w-3.5 h-3.5" />
              Access Revocation Notice:
            </p>
            <p>
              Deactivating this administrator suspends their console privileges, revokes access keys, and moves their profile to the Deactivated tab.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-end gap-2.5 bg-slate-50/70">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <UserX className="w-3.5 h-3.5" />
            <span>Confirm Deactivation</span>
          </button>
        </div>
      </div>
    </div>
  );
};
