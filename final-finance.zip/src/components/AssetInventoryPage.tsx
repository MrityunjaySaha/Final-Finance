import React, { useState, useMemo, useEffect } from 'react';
import { PieChart, Wallet, RefreshCw, Coins, Hexagon, DollarSign, Bitcoin, Archive, Briefcase, TrendingUp, CreditCard } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AuthSession } from '../types/auth';
import { UserWalletData, BarterGoodItem, BarterServiceItem, FinalCoinItem, StableCoinItem, FiatCurrencyItem, CryptoCurrencyItem } from '../types/wallet';
import { getStoredUserWallets } from '../data/defaultWallets';
import { INITIAL_STOCKS, INITIAL_USER_STOCK_POSITIONS } from '../data/stocksData';
import { getStoredStockPositions } from '../utils/stockWalletBridge';
import { AccountPayModal } from './dashboard/AccountPayModal';
import { PieChart as RePieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';

interface AssetInventoryPageProps {
  currentUser: AuthSession;
  onNavigateBack?: () => void;
  initialTab?: InventoryTab;
}

type InventoryTab = 'overview' | 'fiat' | 'stable' | 'final' | 'crypto' | 'barter';

export const AssetInventoryPage: React.FC<AssetInventoryPageProps> = ({ currentUser, onNavigateBack, initialTab = 'overview' }) => {
  const [activeTab, setActiveTab] = useState<InventoryTab>(initialTab);
  const [barterSubTab, setBarterSubTab] = useState<'goods' | 'services'>('goods');
  const [walletData] = useState<UserWalletData>(() => getStoredUserWallets(currentUser.id));

  // Load stock positions & stocks to calculate stocks total USD
  const [positions] = useState(() => getStoredStockPositions(currentUser?.id || 'guest', INITIAL_USER_STOCK_POSITIONS));
  const [stocks] = useState(INITIAL_STOCKS);
  const stocksTotalUSD = useMemo(() => {
    return positions.reduce((s, p) => {
      const stk = stocks.find(st => st.ticker === p.ticker);
      return s + p.shares * (stk ? stk.price : p.avgCostUSD);
    }, 0);
  }, [positions, stocks]);

  // Load liabilities/outstanding debt from localStorage to align Net Worth
  const [debt, setDebt] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(`final_debt_${currentUser?.id || 'guest'}`);
      if (stored !== null) return Number(stored);
    } catch {}
    return 140621.03; // Default liability to match initial state
  });

  const [isPayDebtModalOpen, setIsPayDebtModalOpen] = useState(false);

  useEffect(() => {
    const handleDebtUpdate = (e: any) => {
      if (e.detail?.debt !== undefined) {
        setDebt(Number(e.detail.debt));
      }
    };
    window.addEventListener('final_debt_updated', handleDebtUpdate);
    return () => window.removeEventListener('final_debt_updated', handleDebtUpdate);
  }, []);

  const handleDebtPayment = (paymentAmount: number) => {
    const newDebt = Math.max(0, debt - paymentAmount);
    setDebt(newDebt);
    try {
      localStorage.setItem(`final_debt_${currentUser?.id || 'guest'}`, newDebt.toString());
      window.dispatchEvent(new CustomEvent('final_debt_updated', { detail: { debt: newDebt } }));
    } catch (err) {
      console.warn('Failed to save debt from inventory', err);
    }
  };

  // Calculate totals
  const fiatTotalUSD = useMemo(() => walletData.fiatCurrencies.reduce((acc, curr) => acc + (curr.balance * curr.exchangeRateToUSD), 0), [walletData]);
  const fiatTotalUnits = useMemo(() => walletData.fiatCurrencies.reduce((acc, curr) => acc + curr.balance, 0), [walletData]);
  
  const stableTotalUSD = useMemo(() => walletData.stableCoins.reduce((acc, curr) => acc + (curr.balance * curr.unitPriceUSD), 0), [walletData]);
  const stableTotalUnits = useMemo(() => walletData.stableCoins.reduce((acc, curr) => acc + curr.balance, 0), [walletData]);
  
  const finalTotalUnits = useMemo(() => walletData.finalCoins.reduce((acc, curr) => acc + curr.balance, 0), [walletData]);
  
  const cryptoTotalUSD = useMemo(() => walletData.cryptoCurrencies.reduce((acc, curr) => acc + (curr.balance * curr.unitPriceUSD), 0), [walletData]);
  const cryptoTotalUnits = useMemo(() => walletData.cryptoCurrencies.reduce((acc, curr) => acc + curr.balance, 0), [walletData]);

  const barterGoodsTotalUnits = useMemo(() => walletData.barterGoods.reduce((acc, curr) => acc + curr.quantity, 0), [walletData]);
  const barterServicesTotalCount = useMemo(() => walletData.barterServices.length, [walletData]);
  
  const barterGoodsTotalUSD = useMemo(() => (walletData.barterGoods || []).reduce((acc, curr) => acc + (curr.quantity * (curr.estimatedUnitValue || 0)), 0), [walletData]);
  
  const totalVaultCapital = fiatTotalUSD + stableTotalUSD + cryptoTotalUSD + stocksTotalUSD + barterGoodsTotalUSD;
  const totalNetWorth = totalVaultCapital - debt;

  const chartData = [
    { name: 'Fiat', value: fiatTotalUSD, color: '#0ea5e9' },
    { name: 'Stable Coins', value: stableTotalUSD, color: '#10b981' },
    { name: 'Crypto', value: cryptoTotalUSD, color: '#8b5cf6' },
    { name: 'Stocks & Equities', value: stocksTotalUSD, color: '#6366f1' },
    { name: 'Physical Vault / Barter', value: barterGoodsTotalUSD, color: '#f59e0b' },
  ].filter(d => d.value > 0);

  const TABS: { id: InventoryTab; label: string; icon: React.ElementType }[] = [
    { id: 'overview', label: 'Portfolio Overview', icon: PieChart },
    { id: 'crypto', label: 'Crypto-Currency', icon: Bitcoin },
    { id: 'fiat', label: 'Fiat Treasury', icon: DollarSign },
    { id: 'barter', label: 'Goods & Services', icon: RefreshCw },
    { id: 'stable', label: 'Stable Coins', icon: Coins },
    { id: 'final', label: 'Final Coins', icon: Hexagon },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Account Pay Modal */}
      <AccountPayModal
        isOpen={isPayDebtModalOpen}
        onClose={() => setIsPayDebtModalOpen(false)}
        negativeBalance={-debt}
        walletData={walletData}
        onConfirmPayment={handleDebtPayment}
      />

      <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Archive className="w-6 h-6 text-indigo-600" />
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">Asset Inventory</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col lg:flex-row gap-8">
        {/* Sidebar Nav */}
        <div className="lg:w-64 shrink-0">
          <div className="bg-white rounded-3xl border border-slate-200 p-3 shadow-sm sticky top-24">
            <div className="mb-4 p-4 border-b border-slate-100 space-y-2.5 text-left">
              <div className="space-y-0.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Vault Capital</span>
                <p className="text-base font-bold text-slate-800 font-mono">
                  ${totalVaultCapital.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
              
              {debt > 0 && (
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider block">Outstanding Debt</span>
                    <span className="text-[9px] font-bold text-rose-600 bg-rose-50 border border-rose-200/60 px-1.5 py-0.5 rounded">DUE</span>
                  </div>
                  <p className="text-sm font-bold text-rose-600 font-mono">
                    -${debt.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsPayDebtModalOpen(true)}
                    className="w-full mt-1 py-1.5 px-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <CreditCard className="w-3 h-3" />
                    <span>Pay Off Debt</span>
                  </button>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200/60 space-y-0.5">
                <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider block">Total Net Worth</span>
                <p className="text-2xl font-extrabold text-slate-900 font-mono">
                  ${totalNetWorth.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
            <nav className="space-y-1">
              {TABS.map(tab => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all ${
                      isActive
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 space-y-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-8">
                <div className="w-full sm:w-1/2 h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={60}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip 
                        formatter={(value: number) => `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                      />
                      <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '10px' }} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
                <div className="w-full sm:w-1/2 grid grid-cols-2 gap-2">
                  {[
                    { label: 'Fiat', value: fiatTotalUSD, type: 'currency', color: 'text-sky-600' },
                    { label: 'Stable Coins', value: stableTotalUSD, type: 'currency', color: 'text-emerald-600' },
                    { label: 'Crypto', value: cryptoTotalUSD, type: 'currency', color: 'text-purple-600' },
                    { label: 'Stocks & Equities', value: stocksTotalUSD, type: 'currency', color: 'text-indigo-600' },
                    { label: 'Barter Goods', value: barterGoodsTotalUnits, type: 'units', suffix: ' Items', color: 'text-amber-600 font-bold' },
                    { label: 'Barter Services', value: barterServicesTotalCount, type: 'units', suffix: ' Services', color: 'text-amber-600 font-bold' },
                  ].map((stat, i) => (
                    <div key={i} className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-500 mb-0.5">{stat.label}</p>
                      <p className={`text-xs font-bold font-mono ${stat.color}`}>
                        {stat.type === 'currency'
                          ? `$${stat.value.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`
                          : `${stat.value.toLocaleString()}${stat.suffix}`
                        }
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}


          {activeTab === 'fiat' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-slate-900 flex items-center justify-between gap-2 mb-6">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-sky-600" />
                  Fiat Currency Inventory
                </div>
                <span className="text-sm font-mono text-slate-500">${fiatTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ≈ {fiatTotalUnits.toLocaleString()} units</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.fiatCurrencies.map(fiat => (
                  <div key={fiat.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xl">{fiat.symbol}</span>
                        <h3 className="font-bold text-slate-900">{fiat.code}</h3>
                      </div>
                      <p className="text-xs text-slate-500">{fiat.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-bold text-slate-900">{fiat.symbol}{fiat.balance.toLocaleString()}</p>
                      <p className="text-xs text-slate-500">≈ ${(fiat.balance / fiat.exchangeRateToUSD).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'stable' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-slate-900 flex items-center justify-between gap-2 mb-6">
                <div className="flex items-center gap-2">
                  <Coins className="w-5 h-5 text-emerald-600" />
                  Stable Coins Inventory
                </div>
                <span className="text-sm font-mono text-slate-500">${stableTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ≈ {stableTotalUnits.toLocaleString()} units</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.stableCoins.map(coin => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-slate-900">{coin.symbol}</h3>
                        <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-bold uppercase">{coin.network}</span>
                      </div>
                      <p className="text-xs text-slate-500">{coin.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-bold text-slate-900">{coin.balance.toLocaleString()} {coin.symbol}</p>
                      <p className="text-xs text-emerald-600 font-bold">{coin.yieldAPY}% APY</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'final' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-slate-900 flex items-center justify-between gap-2 mb-6">
                <div className="flex items-center gap-2">
                  <Hexagon className="w-5 h-5 text-amber-600" />
                  Final Coins Inventory
                </div>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.finalCoins.map(coin => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-slate-900">{coin.symbol}</h3>
                      </div>
                      <p className="text-xs text-slate-500">{coin.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-bold text-slate-900">{coin.balance.toLocaleString()} {coin.symbol}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'crypto' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-slate-900 flex items-center justify-between gap-2 mb-6">
                <div className="flex items-center gap-2">
                  <Bitcoin className="w-5 h-5 text-purple-600" />
                  Crypto-Currency Inventory
                </div>
                <span className="text-sm font-mono text-slate-500">${cryptoTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ≈ {cryptoTotalUnits.toLocaleString()} units</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.cryptoCurrencies.map(coin => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-slate-900">{coin.symbol}</h3>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${coin.change24h >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                          {coin.change24h > 0 ? '+' : ''}{coin.change24h}%
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">{coin.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-bold text-slate-900">{coin.balance.toLocaleString()} {coin.symbol}</p>
                      <p className="text-xs text-slate-500">≈ ${(coin.balance * coin.unitPriceUSD).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'barter' && (
            <div className="space-y-6">
              <div className="flex justify-center">
                <div className="flex bg-white rounded-2xl p-1 border border-slate-200 w-fit">
                <button
                  onClick={() => setBarterSubTab('goods')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${barterSubTab === 'goods' ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-50'}`}
                >
                  Goods ({barterGoodsTotalUnits})
                </button>
                <button
                  onClick={() => setBarterSubTab('services')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${barterSubTab === 'services' ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-50'}`}
                >
                  Services ({barterServicesTotalCount})
                </button>
              </div>
              </div>

              {barterSubTab === 'goods' && (
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 mb-6">
                    <Briefcase className="w-5 h-5 text-rose-600" />
                    Physical Goods & Assets ({walletData.barterGoods.length})
                  </h2>
                  <div className="grid grid-cols-1 gap-4">
                    {walletData.barterGoods.map(good => (
                      <div key={good.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-4">
                        {good.imageUrl && (
                          <div className="w-full sm:w-32 h-32 rounded-xl overflow-hidden shrink-0 bg-slate-100">
                            <img src={good.imageUrl} alt={good.name} className="w-full h-full object-cover" />
                          </div>
                        )}
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-bold text-slate-900">{good.name}</h3>
                              <p className="text-xs text-slate-500">{good.category} &bull; {good.condition}</p>
                            </div>
                            <div className="text-right shrink-0">
                              <p className="font-mono font-bold text-slate-900">${good.estimatedUnitValue.toLocaleString()} <span className="text-xs text-slate-500 font-sans">/ {good.unitLabel.replace(/s$/, '')}</span></p>
                              <p className="text-xs text-emerald-600 font-bold tracking-wider">{good.quantity} {good.unitLabel} available</p>
                            </div>
                          </div>
                          <p className="text-sm text-slate-600 line-clamp-2 mb-3">{good.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {good.tags?.map((tag, idx) => (
                              <span key={`${good.id}-${tag}-${idx}`} className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-1 rounded-md uppercase tracking-wider">{tag}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {barterSubTab === 'services' && (
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 mb-6">
                    <TrendingUp className="w-5 h-5 text-indigo-600" />
                    Services & Time ({walletData.barterServices.length})
                  </h2>
                  <div className="grid grid-cols-1 gap-4">
                    {walletData.barterServices.map(service => (
                      <div key={service.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-bold text-slate-900">{service.name}</h3>
                              <p className="text-xs text-slate-500">{service.category}</p>
                            </div>
                            <div className="text-right shrink-0">
                              <p className="font-mono font-bold text-slate-900">${service.hourlyRateValue.toLocaleString()} <span className="text-xs text-slate-500 font-sans">/ hr equiv.</span></p>
                              <p className="text-xs text-indigo-600 font-bold tracking-wider">{service.availableUnits} {service.unitType} available</p>
                            </div>
                          </div>
                          <p className="text-sm text-slate-600 mb-3">{service.deliverableDescription}</p>
                          <div className="flex flex-wrap gap-2">
                            {service.skills?.map((skill, idx) => (
                              <span key={`${service.id}-${skill}-${idx}`} className="text-[10px] font-bold bg-indigo-50 text-indigo-600 px-2 py-1 rounded-md uppercase tracking-wider">{skill}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
