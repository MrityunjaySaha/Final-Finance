export interface LoanRecord {
  id: string;
  lenderId: string;
  lenderHandle: string;
  borrowerId: string;
  borrowerHandle: string;
  amount: number;
  coinSymbol: string;
  interestRate: number;
  termDays: number;
  status: 'active' | 'repaid' | 'defaulted';
  timestamp: string; // ISO or human readable
  issuedAtMs: number;
}

const LOANS_KEY = 'ff_global_loans';

function buildIdentityAliases(idOrHandle?: string, extraId?: string): string[] {
  const aliases = new Set<string>();
  const addId = (val?: string) => {
    if (!val) return;
    const raw = val.trim();
    const lower = raw.toLowerCase();
    const clean = lower.replace(/^@/, '');
    if (raw) aliases.add(raw);
    if (lower) aliases.add(lower);
    if (clean) {
      aliases.add(clean);
      aliases.add(`@${clean}`);
      if (clean.startsWith('user-')) aliases.add(clean.slice(5));
      else if (clean.startsWith('demo-')) aliases.add(clean.slice(5));
      else aliases.add(`user-${clean}`);
    }
  };
  addId(idOrHandle);
  addId(extraId);
  return Array.from(aliases).filter(Boolean);
}

export function isRegisteredInternalBank(userIdOrHandle?: string): boolean {
  if (!userIdOrHandle) return false;
  const aliases = buildIdentityAliases(userIdOrHandle);
  const presetMatch = aliases.some((a) => {
    const clean = a.toLowerCase().replace(/^@/, '');
    return (
      clean.includes('satoshi') ||
      clean.includes('sterling') ||
      clean.includes('belfort') ||
      clean.includes('morgan') ||
      clean === 'demo-satoshi-nakamoto' ||
      clean === 'user-lord_sterling' ||
      clean === 'demo-jordan-belfort' ||
      clean === 'demo-alex-morgan'
    );
  });
  if (presetMatch) return true;

  try {
    return aliases.some((a) => {
      const clean = a.replace(/^@/, '');
      return (
        localStorage.getItem(`ff_bank_app_status_${a}`) === 'approved' ||
        localStorage.getItem(`ff_bank_app_status_${clean}`) === 'approved'
      );
    });
  } catch {
    return false;
  }
}

export function isFinalLoanCoin(coinSymbol?: string): boolean {
  if (!coinSymbol) return true;
  const sym = coinSymbol.trim().toUpperCase();
  return (
    sym === 'AFNL' ||
    sym === 'FNL' ||
    sym === 'FINAL' ||
    sym.endsWith('FNL') ||
    sym.includes('FINAL')
  );
}

function emitLoansUpdated() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('final_finance_loans_updated'));
  }
}

export function getAllLoans(): LoanRecord[] {
  const data = localStorage.getItem(LOANS_KEY);
  if (!data) return [];
  try { return JSON.parse(data); } catch { return []; }
}

export function saveAllLoans(loans: LoanRecord[]) {
  localStorage.setItem(LOANS_KEY, JSON.stringify(loans));
}

export function createLoan(loan: LoanRecord) {
  const all = getAllLoans();
  all.unshift(loan);
  saveAllLoans(all);
  emitLoansUpdated();
}

export function updateLoanStatus(loanId: string, status: 'repaid' | 'defaulted') {
  const all = getAllLoans();
  const idx = all.findIndex(l => l.id === loanId);
  if (idx !== -1) {
    all[idx].status = status;
    saveAllLoans(all);

    const loan = all[idx];
    if (
      status === 'defaulted' &&
      isFinalLoanCoin(loan.coinSymbol) &&
      (isRegisteredInternalBank(loan.lenderId) || isRegisteredInternalBank(loan.lenderHandle))
    ) {
      const borrowerId = loan.borrowerId;
      const key = `ff_default_count_${borrowerId}`;
      const current = parseInt(localStorage.getItem(key) || '0', 10);
      localStorage.setItem(key, (current + 1).toString());
    }
    emitLoansUpdated();
  }
}

export function getUserDefaultCount(userId: string, uid?: string): number {
  return getUserFinalLoanDefaultCount(userId, uid);
}

export function getUserFinalLoanDefaultCount(userId: string, uid?: string): number {
  const borrowerAliases = new Set(
    buildIdentityAliases(userId, uid).map((a) => a.toLowerCase().replace(/^@/, ''))
  );

  const allLoans = getAllLoans();
  const defaultedFinalLoansFromBanks = allLoans.filter((loan) => {
    if (loan.status !== 'defaulted') return false;
    if (!isFinalLoanCoin(loan.coinSymbol)) return false;

    const lenderRegistered =
      isRegisteredInternalBank(loan.lenderId) || isRegisteredInternalBank(loan.lenderHandle);
    if (!lenderRegistered) return false;

    const loanBorrowerAliases = buildIdentityAliases(loan.borrowerId, loan.borrowerHandle).map((a) =>
      a.toLowerCase().replace(/^@/, '')
    );
    return loanBorrowerAliases.some((a) => borrowerAliases.has(a));
  });

  let storedCount = 0;
  try {
    buildIdentityAliases(userId, uid).forEach((alias) => {
      const clean = alias.replace(/^@/, '');
      const val = parseInt(localStorage.getItem(`ff_default_count_${clean}`) || '0', 10);
      if (!isNaN(val) && val > storedCount) {
        storedCount = val;
      }
    });
  } catch {
    // ignore storage errors
  }

  return Math.max(defaultedFinalLoansFromBanks.length, storedCount);
}

export function getLoansForUser(userId: string) {
  const all = getAllLoans();
  return {
    issued: all.filter(l => l.lenderId === userId),
    received: all.filter(l => l.borrowerId === userId)
  };
}

