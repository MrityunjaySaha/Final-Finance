import React, { useState, useEffect } from 'react';
import { 
  Layers, 
  Coins, 
  Wallet, 
  FileCheck, 
  Building2, 
  User, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle,
  ArrowUpRight,
  ShieldCheck,
  Landmark,
  Trash2,
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';
import { AdminIPODesk } from './AdminIPODesk';
import { useApp } from '../../context/AppContext';
import { ConfirmModal } from '../common/ConfirmModal';
import { AdminDelistBanksDesk } from './AdminDelistBanksDesk';

interface SubsidyRequest {
  id: string;
  userName: string;
  userHandle: string;
  type: 'grant' | 'subsidy';
  title: string;
  description: string;
  amountAFNL: number;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  attachment?: string;
}

interface BankingRequest {
  id: string;
  institutionName: string;
  userHandle: string;
  capitalReserves: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
}

interface AdminRequestsDeskProps {
  onNotify?: (msg: string, type?: 'success' | 'warning' | 'error') => void;
}

export const AdminRequestsDesk: React.FC<AdminRequestsDeskProps> = ({ onNotify }) => {
  const { transactions, reverseTransaction, addTransaction } = useApp();
  const [activeRequestTab, setActiveRequestTab] = useState<'ipo' | 'subsidy' | 'banking' | 'delist_banks'>('ipo');
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    type: 'info' | 'warning' | 'danger';
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
    type: 'info'
  });
  
  // Mock data for Subsidy Requests
  const [subsidyRequests, setSubsidyRequests] = useState<SubsidyRequest[]>([
    {
      id: 'sub-101',
      userName: 'Elena Rostova',
      userHandle: '@elena_rostova',
      type: 'grant',
      title: 'Regional Node Infrastructure Expansion',
      description: 'Requesting funds to establish a high-availability validator node in Eastern Europe.',
      amountAFNL: 25000,
      status: 'pending',
      submittedAt: '4h ago'
    },
    {
      id: 'sub-102',
      userName: 'Julian Vance',
      userHandle: '@julian_vance',
      type: 'subsidy',
      title: 'Green Energy Mining Credit',
      description: 'Solar-powered protocol maintenance equipment subsidy.',
      amountAFNL: 5000,
      status: 'approved',
      submittedAt: '1d ago'
    }
  ]);

  // Mock data for Banking Requests
  const [bankingRequests, setBankingRequests] = useState<BankingRequest[]>([
    {
      id: 'bank-req-001',
      institutionName: 'Swiss Sovereign Reserve',
      userHandle: '@swiss_reserve',
      capitalReserves: '1,500,000 AFNL',
      reason: 'Institutional liquidity provision and inter-bank clearing services.',
      status: 'pending',
      submittedAt: '2h ago'
    },
    {
      id: 'bank-req-002',
      institutionName: 'Neo Tokyo Trust',
      userHandle: '@tokyo_trust',
      capitalReserves: '800,000 AFNL',
      reason: 'Regional retail banking and consumer credit lines in AFNL.',
      status: 'approved',
      submittedAt: '3d ago'
    }
  ]);

  const handleApproveSubsidy = (id: string) => {
    const req = subsidyRequests.find(r => r.id === id);
    if (!req) return;

    setConfirmModal({
      isOpen: true,
      title: 'Approve Subsidy Disbursement',
      message: `Are you sure you want to approve the ${req.type} for ${req.userName} ($${req.amountAFNL.toLocaleString()} AFNL)? This will immediately release funds from the Sovereign Treasury.`,
      type: 'info',
      onConfirm: () => {
        setSubsidyRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'approved' } : r));
        if (onNotify) onNotify('Subsidy request approved successfully.', 'success');

        addTransaction({
          taxYear: 2024,
          type: 'dividend',
          category: 'transfer',
          mode: 'final_coin',
          title: `Subsidy Disbursement: ${req.title}`,
          description: req.description,
          amountUSD: req.amountAFNL,
          feeUSD: 0,
          netAmountUSD: req.amountAFNL,
          sourceOrDestination: 'SOVEREIGN_TREASURY',
          counterpartyOrIssuer: req.userName,
          issuerHandle: req.userHandle,
          status: 'Settled',
          clearingNode: 'ADMIN-TREASURY-01',
          taxClassification: {
            formMapping: 'Sovereign Grant',
            taxableEvent: false,
            taxableAmountUSD: 0,
            irsCategoryNote: 'Exempt sovereign subsidy'
          }
        });
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleRejectSubsidy = (id: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Reject Subsidy Request',
      message: 'Are you sure you want to reject this funding proposal?',
      type: 'warning',
      onConfirm: () => {
        setSubsidyRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'rejected' } : r));
        if (onNotify) onNotify('Subsidy request rejected.', 'warning');
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleApproveBank = (id: string) => {
    const req = bankingRequests.find(r => r.id === id);
    if (!req) return;

    setConfirmModal({
      isOpen: true,
      title: 'Authorize Banking License',
      message: `Are you sure you want to authorize ${req.institutionName} as a licensed institution? This will grant them sovereign clearing privileges.`,
      type: 'info',
      onConfirm: () => {
        setBankingRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'approved' } : r));
        if (onNotify) onNotify('Banking application approved.', 'success');

        addTransaction({
          taxYear: 2024,
          type: 'p2p_transfer',
          category: 'transfer',
          mode: 'stable_coin',
          title: `Banking License Authorization: ${req.institutionName}`,
          description: `License granted. Capital reserves verified at ${req.capitalReserves}.`,
          amountUSD: 0,
          feeUSD: 25000,
          netAmountUSD: -25000,
          sourceOrDestination: req.userHandle,
          counterpartyOrIssuer: 'Protocol Regulatory Dept',
          issuerHandle: '@regulatory',
          status: 'Settled',
          clearingNode: 'ADMIN-REG-4B',
          taxClassification: {
            formMapping: 'Regulatory Fee',
            taxableEvent: false,
            taxableAmountUSD: 0,
            irsCategoryNote: 'License processing fee'
          }
        });
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleRejectBank = (id: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Deny Banking Application',
      message: 'Are you sure you want to deny this institutional banking license?',
      type: 'warning',
      onConfirm: () => {
        setBankingRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'rejected' } : r));
        if (onNotify) onNotify('Banking application rejected.', 'warning');
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation for Requests */}
      <div className="flex items-center gap-3 bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveRequestTab('ipo')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRequestTab === 'ipo'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>IPO Requests (People & Business)</span>
        </button>
        
        <button
          onClick={() => setActiveRequestTab('subsidy')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRequestTab === 'subsidy'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Subsidy & Grants</span>
        </button>
        
        <button
          onClick={() => setActiveRequestTab('banking')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRequestTab === 'banking'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Landmark className="w-4 h-4" />
          <span>Internal Banking Applications</span>
        </button>

        <button
          onClick={() => setActiveRequestTab('delist_banks')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRequestTab === 'delist_banks'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Trash2 className="w-4 h-4" />
          <span>Delist Banks</span>
        </button>
      </div>

      <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
        {/* IPO SECTION */}
        {activeRequestTab === 'ipo' && (
          <div className="space-y-4">
            <AdminIPODesk onNotify={onNotify} />
          </div>
        )}

        {/* SUBSIDY SECTION */}
        {activeRequestTab === 'subsidy' && (
          <div className="space-y-4">
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="font-serif text-lg font-bold text-slate-900">Protocol Subsidy & Grant Requests</h2>
                  <p className="text-xs text-slate-500">Review community-submitted funding proposals for ecosystem growth.</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold uppercase">
                    {subsidyRequests.filter(r => r.status === 'pending').length} Pending
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                {subsidyRequests.map(req => (
                  <div key={req.id} className="p-5 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors space-y-4 overflow-hidden">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-lg shadow-sm shrink-0">
                          {req.type === 'grant' ? '🎁' : '⚡'}
                        </div>
                        <div className="min-w-0 flex-1">
                          <h3 className="text-sm font-bold text-slate-900 truncate">{req.title}</h3>
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-500 mt-1">
                            <span className="font-semibold text-slate-700 truncate max-w-[120px]">{req.userName}</span>
                            <span>({req.userHandle})</span>
                            <span className="text-slate-300">•</span>
                            <span className="uppercase font-bold text-amber-700 shrink-0">{req.type}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-left sm:text-right shrink-0 pt-0.5">
                        <span className="text-sm font-mono font-bold text-slate-900 block">{req.amountAFNL.toLocaleString()} AFNL</span>
                        <div className="text-[10px] text-slate-400 font-medium">Submitted {req.submittedAt}</div>
                      </div>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-100 text-xs text-slate-600 leading-relaxed italic break-words">
                      "{req.description}"
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                      <div className="flex items-center gap-3">
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider shrink-0 ${
                          req.status === 'approved' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : req.status === 'rejected' 
                            ? 'bg-rose-100 text-rose-800' 
                            : 'bg-slate-200 text-slate-600'
                        }`}>
                          {req.status}
                        </span>
                      </div>

                      {req.status === 'pending' && (
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            onClick={() => handleRejectSubsidy(req.id)}
                            className="px-4 py-1.5 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
                          >
                            Reject
                          </button>
                          <button
                            onClick={() => handleApproveSubsidy(req.id)}
                            className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve Disbursement</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* BANKING SECTION */}
        {activeRequestTab === 'banking' && (
          <div className="space-y-4">
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="font-serif text-lg font-bold text-slate-900">Institutional Banking Applications</h2>
                  <p className="text-xs text-slate-500">Authorize entities to act as Sovereign Clearing Nodes and manage AFNL credit lines.</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold uppercase">
                    {bankingRequests.filter(r => r.status === 'pending').length} Pending
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                {bankingRequests.map(req => (
                  <div key={req.id} className="p-5 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors space-y-4 overflow-hidden">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-700 shadow-sm shrink-0">
                          <Landmark className="w-5 h-5" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <h3 className="text-sm font-bold text-slate-900 truncate">{req.institutionName}</h3>
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-500 mt-1">
                            <span className="font-semibold text-slate-700 truncate max-w-[120px]">{req.userHandle}</span>
                            <span className="text-slate-300">•</span>
                            <span className="text-blue-600 font-bold uppercase shrink-0">Banking License App</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-left sm:text-right shrink-0 pt-0.5">
                        <span className="text-sm font-mono font-bold text-slate-900 block">{req.capitalReserves}</span>
                        <div className="text-[10px] text-slate-400 font-medium uppercase tracking-tight">Reported Reserves</div>
                      </div>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-100 text-xs text-slate-600 leading-relaxed break-words">
                      <span className="font-bold text-slate-400 block text-[9px] uppercase mb-1">Application Intent</span>
                      "{req.reason}"
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                      <div className="flex items-center gap-3">
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider shrink-0 ${
                          req.status === 'approved' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : req.status === 'rejected' 
                            ? 'bg-rose-100 text-rose-800' 
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {req.status}
                        </span>
                        <span className="text-[10px] text-slate-400 whitespace-nowrap">Submitted {req.submittedAt}</span>
                      </div>

                      {req.status === 'pending' && (
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            onClick={() => handleRejectBank(req.id)}
                            className="px-4 py-1.5 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
                          >
                            Deny License
                          </button>
                          <button
                            onClick={() => handleApproveBank(req.id)}
                            className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>Authorize Institution</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* DELIST BANKS SECTION */}
        {activeRequestTab === 'delist_banks' && (
          <div className="space-y-4">
            <AdminDelistBanksDesk />
          </div>
        )}
        {/* FOOTER PADDING */}
        <div className="h-6" />

        <ConfirmModal
          isOpen={confirmModal.isOpen}
          onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
          onConfirm={confirmModal.onConfirm}
          title={confirmModal.title}
          message={confirmModal.message}
          type={confirmModal.type}
        />
      </div>
    </div>
  );
};
