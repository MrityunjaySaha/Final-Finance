import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import {
  Download,
  Smartphone,
  Share,
  PlusSquare,
  MoreVertical,
  Monitor,
  X,
  CheckCircle2,
  ExternalLink,
  Tablet,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'header' | 'menu' | 'banner';
  onActionComplete?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'header',
  onActionComplete,
}) => {
  const {
    isInstallable,
    isInstalled,
    isIOS,
    isAndroid,
    isMac,
    isWindows,
    isLinux,
    isSafariBrowser,
    isFirefox,
    isSamsungInternet,
    inIframe,
    install,
  } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  // Suppress install controls when already running in installed standalone PWA mode
  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        if (onActionComplete) onActionComplete();
        return;
      }
    }
    setShowGuideModal(true);
  };

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '/';

  const renderModal = () => {
    if (!showGuideModal || typeof document === 'undefined') return null;

    return createPortal(
      <div
        className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto"
        onClick={() => setShowGuideModal(false)}
      >
        <div
          className="w-full max-w-md rounded-3xl bg-white border border-slate-200 shadow-2xl overflow-hidden text-left animate-in fade-in zoom-in-95 duration-150 my-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Modal Header */}
          <div className="bg-slate-950 text-white px-5 py-4 flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-3 min-w-0">
              <img
                src="/pwa-192x192.png"
                alt="Final Finance"
                className="w-10 h-10 rounded-xl border border-amber-400/40 shrink-0"
              />
              <div className="min-w-0">
                <h3 className="font-serif text-base font-bold text-white tracking-wide truncate">
                  Add Final Finance to Device
                </h3>
                <p className="text-[11px] text-amber-300/90 font-medium">
                  Install Directly — No App Store or Play Store Needed
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowGuideModal(false)}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
              aria-label="Close install instructions"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Platform-Specific Instructions */}
          <div className="p-5 space-y-4 text-slate-700 text-xs max-h-[75dvh] overflow-y-auto">
            {inIframe && (
              <div className="p-3 rounded-2xl bg-sky-50 border border-sky-200 text-sky-950 space-y-2">
                <p className="font-semibold text-[11px] leading-relaxed">
                  You are currently viewing Final Finance inside an embedded frame. Open it directly in your device browser tab for 1-tap Home Screen / Desktop installation:
                </p>
                <a
                  href={currentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1.5 w-full py-2 px-3 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-bold transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                  <span>Open App in Browser Tab</span>
                </a>
              </div>
            )}

            {isIOS ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <Smartphone className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>iPhone &amp; iPad (iOS / iPadOS)</span>
                </div>
                {!isSafariBrowser && (
                  <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px] font-medium">
                    Tip: For guaranteed Home Screen support on iPhone &amp; iPad, open this link in <strong>Safari</strong> (or tap the Share icon in Chrome/Edge on iOS).
                  </div>
                )}
                <ol className="space-y-2.5">
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">1</span>
                    <div className="flex-1">
                      Tap the <strong className="inline-flex items-center gap-1 text-slate-900"><Share className="w-3.5 h-3.5 text-sky-600 inline" /> Share</strong> button in Safari (bottom toolbar on iPhone, top bar on iPad).
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">2</span>
                    <div className="flex-1">
                      Scroll down and tap <strong className="inline-flex items-center gap-1 text-slate-900"><PlusSquare className="w-3.5 h-3.5 text-slate-800 inline" /> Add to Home Screen</strong>.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">3</span>
                    <div className="flex-1">
                      Tap <strong className="text-slate-900">Add</strong> in the top corner to run Final Finance full-screen from your Home Screen.
                    </div>
                  </li>
                </ol>
              </div>
            ) : isAndroid ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <Tablet className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Android Phone &amp; Tablet</span>
                </div>
                <ol className="space-y-2.5">
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">1</span>
                    <div className="flex-1">
                      {isSamsungInternet ? (
                        <>Tap the <strong className="text-slate-900">Download / Menu (≡)</strong> icon in Samsung Internet.</>
                      ) : isFirefox ? (
                        <>Tap the <strong className="inline-flex items-center gap-1 text-slate-900"><MoreVertical className="w-3.5 h-3.5 inline" /> Menu</strong> icon in Firefox.</>
                      ) : (
                        <>Tap the <strong className="inline-flex items-center gap-1 text-slate-900"><MoreVertical className="w-3.5 h-3.5 inline" /> Menu</strong> button (three dots) in Chrome, Edge, or Brave.</>
                      )}
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">2</span>
                    <div className="flex-1">
                      Select <strong className="text-slate-900">Install app</strong> or <strong className="text-slate-900">Add to Home screen</strong>.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">3</span>
                    <div className="flex-1">
                      Confirm <strong className="text-slate-900">Install</strong> to add Final Finance directly to your Home Screen &amp; App Drawer.
                    </div>
                  </li>
                </ol>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <Monitor className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span>
                    {isMac
                      ? 'macOS Desktop & MacBook'
                      : isWindows
                      ? 'Windows PC & Tablet'
                      : isLinux
                      ? 'Linux Desktop & Chromebook'
                      : 'Desktop & Laptop Browsers'}
                  </span>
                </div>
                <ol className="space-y-2.5">
                  {isMac && (
                    <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">1</span>
                      <div className="flex-1">
                        <strong>Safari (macOS):</strong> Click <strong className="text-slate-900">File &rarr; Add to Dock...</strong> in the top menu bar.
                      </div>
                    </li>
                  )}
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                      {isMac ? '2' : '1'}
                    </span>
                    <div className="flex-1">
                      <strong>Chrome / Edge / Brave:</strong> Click the <strong className="text-slate-900">Install</strong> icon in the address bar, or open menu (<strong className="text-slate-900">⋮</strong>) &rarr; <strong className="text-slate-900">Save and share / Apps &rarr; Install Final Finance</strong>.
                    </div>
                  </li>
                  <li className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                      {isMac ? '3' : '2'}
                    </span>
                    <div className="flex-1">
                      <strong>Windows / Linux / macOS App Window:</strong> Launches in its own native app window pinned to your Start Menu, Taskbar, Dock, or Desktop.
                    </div>
                  </li>
                </ol>
              </div>
            )}

            <div className="flex items-center gap-2 pt-1 text-[11px] text-emerald-700 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span>Works across iOS, Android, Windows, macOS &amp; Linux with offline shell caching.</span>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowGuideModal(false);
                if (onActionComplete) onActionComplete();
              }}
              className="w-full min-h-[42px] py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              Got it
            </button>
          </div>
        </div>
      </div>,
      document.body
    );
  };

  if (variant === 'menu') {
    return (
      <>
        <button
          id="dropdown-install-pwa-btn"
          type="button"
          onClick={handleClick}
          className="w-full px-3 py-2 rounded-xl flex items-center justify-start gap-2.5 text-xs text-left text-amber-900 bg-amber-50/70 hover:bg-amber-100 transition-colors cursor-pointer font-semibold border border-amber-200/70"
        >
          <Download className="w-4 h-4 text-amber-700 shrink-0" />
          <span className="text-left">
            {isInstallable ? 'Install App to Home Screen' : isIOS ? 'Add to Home Screen (iOS)' : 'Install App on Device'}
          </span>
        </button>
        {renderModal()}
      </>
    );
  }

  if (variant === 'banner') {
    return (
      <>
        <button
          id="landing-install-pwa-btn"
          type="button"
          onClick={handleClick}
          className="w-full min-h-[44px] py-2.5 px-4 rounded-2xl bg-amber-50 hover:bg-amber-100 active:scale-[0.99] border border-amber-300/80 text-amber-950 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
        >
          <Download className="w-4 h-4 text-amber-700 shrink-0" />
          <span>Install Web App on Any Device</span>
        </button>
        {renderModal()}
      </>
    );
  }

  return (
    <>
      <button
        id="header-install-pwa-btn"
        type="button"
        onClick={handleClick}
        className="h-9 px-2.5 sm:px-3 flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 active:scale-95 text-slate-800 text-xs font-semibold transition-all shadow-xs cursor-pointer shrink-0"
        title={isInstallable ? 'Install Final Finance App' : 'Add Final Finance to Home Screen'}
        aria-label="Install App"
      >
        <Download className="h-3.5 w-3.5 text-amber-600 shrink-0" />
        <span className="hidden sm:inline whitespace-nowrap">
          {isInstallable ? 'Install App' : isIOS ? 'Add to Home' : 'Install'}
        </span>
      </button>
      {renderModal()}
    </>
  );
};
