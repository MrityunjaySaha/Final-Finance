export interface UserPublicProfile {
  uid: string;
  userId: string; // handle without @
  name: string;
  email?: string;
  avatarUrl?: string;
  coverUrl?: string;
  role: 'super_admin' | 'admin' | 'vip_user' | 'user' | 'guest';
  bio?: string;
  createdAt?: string;
  followersCount?: number;
  followingCount?: number;
  friendsCount?: number;
  isVerified?: boolean;
  reputationBadge?: string;
  organization?: string;
  totalTradeVolumeUSD?: number;
}

export interface ConversationParticipant {
  uid: string;
  userId: string;
  name: string;
  avatarUrl?: string;
  role?: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  name?: string;
  groupAvatarUrl?: string;
  participantIds: string[];
  participants: Record<string, ConversationParticipant>;
  createdBy?: string;
  lastMessageText?: string;
  lastMessageSenderId?: string;
  createdAt?: any;
  updatedAt?: any;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderHandle: string;
  senderAvatarUrl?: string;
  text: string;
  createdAt?: any;
}

export interface FriendRequest {
  id: string;
  senderUid: string;
  senderHandle: string;
  senderName: string;
  senderAvatarUrl?: string;
  receiverUid: string;
  receiverHandle: string;
  receiverName: string;
  receiverAvatarUrl?: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: string;
}

export interface RelationshipStatus {
  isFollowing: boolean;
  isFollower: boolean;
  isFriend: boolean;
  friendStatus: 'none' | 'pending_sent' | 'pending_received' | 'friends';
  isBlocked: boolean;
  isBlockedByMe?: boolean;
  isBlockedByTarget?: boolean;
}

export interface FriendGroup {
  id: string;
  ownerUid: string;
  name: string;
  description?: string;
  color?: string;
  icon?: string;
  memberUids: string[];
  memberHandles?: string[];
  avatarUrl?: string;
  groupType?: 'friend' | 'general'; // 'friend' = with friends, 'general' = without friends / anyone
  createdAt: string;
  updatedAt?: string;
}

export type SocialTab = 'friends' | 'following' | 'followers' | 'discover';
