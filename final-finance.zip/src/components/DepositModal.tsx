import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ReserveVault } from '../types';
import { ConfirmModal } from './common/ConfirmModal';
import { ShieldCheck, ArrowDownLeft, CheckCircle2, Lock } from 'lucide-react';

interface DepositModalProps {
  vault: ReserveVault | null;
  onClose: () => void;
}

export const DepositModal: React.FC<DepositModalProps> = ({ vault, onClose }) => {
  const { depositToVault, withdrawFromVault, currentUser } = useApp();
  const [mode, setMode] = useState<'deposit' | 'withdraw'>('deposit');
  const [amountUSD, setAmountUSD] = useState(100000);
  const [assetTitle, setAssetTitle] = useState('Certified Physical Ingot Allotment');
  const [showConfirm, setShowConfirm] = useState(false);

  if (!vault) return null;

  const currentVaultHolding = currentUser.holdings[vault.id] || 0;

  const handleExecute = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (amountUSD <= 0) return;

    if (mode === 'deposit') {
      depositToVault(vault.id, amountUSD, assetTitle);
      onClose();
    } else {
      const success = withdrawFromVault(vault.id, amountUSD);
      if (success) onClose();
    }
    setShowConfirm(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150">
      <div className="relative w-full max-w-md rounded-2xl border border-amber-500/30 bg-[#0d1017] p-6 shadow-2xl space-y-5">
        
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-amber-400" />
            <h3 className="font-serif text-base font-bold text-white">
              {vault.name} Custody
            </h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white text-xs">✕</button>
        </div>

        {/* Mode Switcher */}
        <div className="flex rounded-xl border border-neutral-800 bg-neutral-900 p-1 gap-1">
          <button
            type="button"
            onClick={() => setMode('deposit')}
            className={`flex-1 rounded-lg py-1.5 text-xs font-semibold transition-all ${
              mode === 'deposit' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Deposit / Allocate
          </button>
          <button
            type="button"
            onClick={() => setMode('withdraw')}
            className={`flex-1 rounded-lg py-1.5 text-xs font-semibold transition-all ${
              mode === 'withdraw' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Withdraw / Settle
          </button>
        </div>

        <form onSubmit={handleExecute} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-white block mb-1">
              {mode === 'deposit' ? 'Deposit Value (USD)' : 'Withdrawal Amount (USD)'}
            </label>
            <input
              type="number"
              min="1000"
              step="1000"
              value={amountUSD}
              onChange={(e) => setAmountUSD(Number(e.target.value))}
              className="w-full rounded-lg border border-neutral-800 bg-neutral-900 p-2.5 text-xs text-white font-mono focus:border-amber-500 focus:outline-none"
            />
            <p className="text-[10px] font-mono text-neutral-400 mt-1">
              Your Current Vault Balance: ${currentVaultHolding.toLocaleString()}
            </p>
          </div>

          {mode === 'deposit' && (
            <div>
              <label className="text-xs font-semibold text-white block mb-1">Collateral Asset Name</label>
              <input
                type="text"
                value={assetTitle}
                onChange={(e) => setAssetTitle(e.target.value)}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 p-2.5 text-xs text-white focus:border-amber-500 focus:outline-none"
              />
            </div>
          )}

          <div className="rounded-xl bg-neutral-900/80 p-3 text-xs text-neutral-400 space-y-1">
            <div className="flex justify-between">
              <span>Vault Short Code:</span>
              <span className="font-mono text-amber-300 font-semibold">{vault.shortCode}</span>
            </div>
            <div className="flex justify-between">
              <span>Audit Attestation:</span>
              <span className="font-mono text-emerald-400">{vault.auditScore}/100 Grade AAA</span>
            </div>
            <div className="flex justify-between">
              <span>Custody Guarantee:</span>
              <span className="font-mono text-neutral-200">100% Backed Cold Storage</span>
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-neutral-800 bg-neutral-900 py-2.5 text-xs font-semibold text-neutral-300 hover:bg-neutral-800"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => setShowConfirm(true)}
              className="flex-1 rounded-xl border border-amber-500 bg-gradient-to-r from-amber-500 to-amber-600 py-2.5 text-xs font-bold text-black hover:opacity-95 transition-opacity shadow-lg shadow-amber-500/20"
            >
              {mode === 'deposit' ? 'Confirm Allocation' : 'Execute Withdrawal'}
            </button>
          </div>
        </form>

        <ConfirmModal
          isOpen={showConfirm}
          onClose={() => setShowConfirm(false)}
          onConfirm={handleExecute}
          title={mode === 'deposit' ? 'Confirm Deposit' : 'Confirm Withdrawal'}
          message={mode === 'deposit' 
            ? `Are you sure you want to deposit $${amountUSD.toLocaleString()} into the ${vault.name}?` 
            : `Are you sure you want to withdraw $${amountUSD.toLocaleString()} from the ${vault.name}?`}
          confirmText={mode === 'deposit' ? 'Confirm Deposit' : 'Confirm Withdrawal'}
          type="warning"
        />
      </div>
    </div>
  );
};
