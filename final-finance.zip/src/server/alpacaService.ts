import * as AlpacaModule from '@alpacahq/alpaca-trade-api';
import dotenv from 'dotenv';

dotenv.config();

let alpacaClient: any = null;

export function hasAlpacaKeys(): boolean {
  return !!(process.env.ALPACA_API_KEY && process.env.ALPACA_SECRET_KEY);
}

export function getAlpacaClient() {
  if (!alpacaClient) {
    const keyId = process.env.ALPACA_API_KEY;
    const secretKey = process.env.ALPACA_SECRET_KEY;

    if (!keyId || !secretKey) {
      throw new Error('ALPACA_API_KEY or ALPACA_SECRET_KEY is not configured');
    }

    // Handle different export patterns in v4.x
    const Alpaca = (AlpacaModule as any).default || (AlpacaModule as any).Alpaca || AlpacaModule;
    
    alpacaClient = new Alpaca({
      keyId,
      secret: secretKey,
      paper: true,
    });
  }
  return alpacaClient;
}

// Highly elegant mock database of popular assets for sandbox simulation
const MOCK_ASSETS = [
  { symbol: 'AAPL', name: 'Apple Inc.', asset_class: 'us_equity', price: 185.30, open: 184.20, high: 186.50, low: 183.80, volume: 52000000 },
  { symbol: 'MSFT', name: 'Microsoft Corporation', asset_class: 'us_equity', price: 415.50, open: 412.30, high: 417.20, low: 410.80, volume: 22800000 },
  { symbol: 'TSLA', name: 'Tesla Inc.', asset_class: 'us_equity', price: 178.20, open: 180.50, high: 181.20, low: 175.90, volume: 88500000 },
  { symbol: 'NVDA', name: 'NVIDIA Corporation', asset_class: 'us_equity', price: 875.12, open: 845.00, high: 882.50, low: 841.10, volume: 45200000 },
  { symbol: 'GOOG', name: 'Alphabet Inc.', asset_class: 'us_equity', price: 152.30, open: 151.20, high: 153.50, low: 150.10, volume: 28400000 },
  { symbol: 'COIN', name: 'Coinbase Global, Inc.', asset_class: 'us_equity', price: 242.50, open: 235.10, high: 245.00, low: 233.20, volume: 12100000 },
  { symbol: 'MSTR', name: 'MicroStrategy Incorporated', asset_class: 'us_equity', price: 1620.00, open: 1510.00, high: 1655.00, low: 1490.00, volume: 3250000 },
  { symbol: 'RIOT', name: 'Riot Platforms, Inc.', asset_class: 'us_equity', price: 11.20, open: 11.45, high: 11.60, low: 11.05, volume: 18200000 },
  { symbol: 'BTCUSD', name: 'Bitcoin / USD', asset_class: 'crypto', price: 64250.00, open: 62800.00, high: 64500.00, low: 62500.00, volume: 3400000000 },
  { symbol: 'ETHUSD', name: 'Ethereum / USD', asset_class: 'crypto', price: 3450.00, open: 3390.00, high: 3480.00, low: 3370.00, volume: 1800000000 },
  { symbol: 'SOLUSD', name: 'Solana / USD', asset_class: 'crypto', price: 142.50, open: 135.20, high: 145.00, low: 134.10, volume: 850000000 },
  { symbol: 'USDCUSD', name: 'USD Coin / USD', asset_class: 'crypto', price: 1.00, open: 1.00, high: 1.00, low: 1.00, volume: 4500000000 }
];

export async function getAccount() {
  if (!hasAlpacaKeys()) {
    return {
      success: true,
      data: {
        id: 'sandbox_alpaca_acct_01',
        status: 'ACTIVE',
        currency: 'USD',
        cash: 100000.00,
        portfolio_value: 100000.00,
        buying_power: 400000.00,
        daytrading_buying_power: 400000.00,
      }
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const account = await alpaca.trading.account.getAccount();
    return {
      success: true,
      data: {
        id: account.id,
        status: account.status,
        currency: account.currency,
        cash: parseFloat(account.cash || '0'),
        portfolio_value: parseFloat(account.portfolioValue || '0'),
        buying_power: parseFloat(account.buyingPower || '0'),
        daytrading_buying_power: parseFloat(account.daytradingBuyingPower || '0'),
      }
    };
  } catch (error: any) {
    console.error('Alpaca getAccount error:', error.message);
    return {
      success: true,
      data: {
        id: 'sandbox_alpaca_acct_01',
        status: 'ACTIVE',
        currency: 'USD',
        cash: 100000.00,
        portfolio_value: 100000.00,
        buying_power: 400000.00,
        daytrading_buying_power: 400000.00,
      }
    };
  }
}

export async function getPositions() {
  if (!hasAlpacaKeys()) {
    return {
      success: true,
      data: []
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const positions = await alpaca.trading.positions.getAllOpenPositions();
    return {
      success: true,
      data: positions.map((p: any) => ({
        symbol: p.symbol,
        asset_class: p.assetClass,
        qty: parseFloat(p.qty || '0'),
        avg_entry_price: parseFloat(p.avgEntryPrice || '0'),
        market_value: parseFloat(p.marketValue || '0'),
        cost_basis: parseFloat(p.costBasis || '0'),
        unrealized_pl: parseFloat(p.unrealizedPl || '0'),
        unrealized_plpc: parseFloat(p.unrealizedPlpc || '0'),
        change_today: parseFloat(p.changeToday || '0'),
      }))
    };
  } catch (error: any) {
    console.error('Alpaca getPositions error:', error.message);
    return {
      success: true,
      data: []
    };
  }
}

export async function getAssets(assetClass?: 'us_equity' | 'crypto' | 'us_option') {
  if (!hasAlpacaKeys()) {
    const filtered = assetClass 
      ? MOCK_ASSETS.filter(a => a.asset_class === assetClass) 
      : MOCK_ASSETS;
    return {
      success: true,
      data: filtered.map((a, idx) => ({
        id: `mock-asset-${idx}`,
        symbol: a.symbol,
        name: a.name,
        exchange: 'NASDAQ',
        asset_class: a.asset_class,
        tradable: true,
        marginable: true,
        shortable: true,
        fractionable: true,
      }))
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const assets = await alpaca.trading.assets.getV2Assets({
      status: 'active',
      assetClass: assetClass,
    });
    return {
      success: true,
      data: assets.map((a: any) => ({
        id: a.id,
        symbol: a.symbol,
        name: a.name,
        exchange: a.exchange,
        asset_class: a._class,
        tradable: a.tradable,
        marginable: a.marginable,
        shortable: a.shortable,
        fractionable: a.fractionable,
      }))
    };
  } catch (error: any) {
    console.error('Alpaca getAssets error:', error.message);
    return { success: false, error: error.message };
  }
}

export async function placeOrder(symbol: string, qty: number, side: 'buy' | 'sell', type: 'market' | 'limit' = 'market', limitPrice?: number) {
  if (!hasAlpacaKeys()) {
    return {
      success: true,
      data: {
        id: 'mock-order-' + Math.random().toString(36).substr(2, 9),
        status: 'filled',
        symbol: symbol.toUpperCase(),
        asset_class: symbol.toUpperCase().endsWith('USD') ? 'crypto' : 'us_equity',
        qty: qty,
        side: side,
        type: type,
      }
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const orderParams: any = {
      symbol: symbol.toUpperCase(),
      qty: qty.toString(),
      side,
      type,
      timeInForce: 'gtc',
    };

    if (type === 'limit' && limitPrice) {
      orderParams.limitPrice = limitPrice.toString();
    }

    const order = await alpaca.trading.orders.postOrder(orderParams);
    return {
      success: true,
      data: {
        id: order.id,
        status: order.status,
        symbol: order.symbol,
        asset_class: order.assetClass,
        qty: parseFloat(order.qty || '0'),
        side: order.side,
        type: order.type,
      }
    };
  } catch (error: any) {
    console.error('Alpaca placeOrder error:', error.message);
    return { success: false, error: error.message };
  }
}

export async function getMarketClock() {
  if (!hasAlpacaKeys()) {
    return {
      success: true,
      data: {
        timestamp: new Date().toISOString(),
        is_open: true,
        next_open: new Date().toISOString(),
        next_close: new Date().toISOString(),
      }
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const clock = await alpaca.trading.clock.getClock();
    return {
      success: true,
      data: {
        timestamp: clock.timestamp,
        is_open: clock.isOpen,
        next_open: clock.nextOpen,
        next_close: clock.nextClose,
      }
    };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

const COMPANY_NAME_TO_TICKER: Record<string, string> = {
  'APPLE': 'AAPL',
  'MICROSOFT': 'MSFT',
  'TESLA': 'TSLA',
  'NVIDIA': 'NVDA',
  'GOOGLE': 'GOOGL',
  'ALPHABET': 'GOOGL',
  'AMAZON': 'AMZN',
  'META': 'META',
  'FACEBOOK': 'META',
  'NETFLIX': 'NFLX',
  'BITCOIN': 'BTC/USD',
  'ETHEREUM': 'ETH/USD',
  'MICROSTRATEGY': 'MSTR',
  'SPDR GOLD': 'GLD',
  'GOLD': 'GLD'
};

export async function getAssetBySymbol(symbol: string) {
  let symUpper = symbol.toUpperCase().trim();
  if (COMPANY_NAME_TO_TICKER[symUpper]) {
    symUpper = COMPANY_NAME_TO_TICKER[symUpper];
  }

  if (!hasAlpacaKeys()) {
    let item = MOCK_ASSETS.find(a => a.symbol === symUpper || a.symbol.replace('/', '') === symUpper);
    if (!item) {
      // Try searching mock assets by name
      item = MOCK_ASSETS.find(a => a.name.toUpperCase().includes(symUpper));
    }
    if (!item) {
      return { success: false, error: `Asset not found for "${symbol}"` };
    }
    return {
      success: true,
      data: {
        id: 'mock-asset-' + item.symbol,
        symbol: item.symbol,
        name: item.name,
        exchange: 'NASDAQ',
        asset_class: item.asset_class,
        tradable: true,
        marginable: true,
        shortable: true,
        fractionable: true,
        status: 'active',
      }
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const asset = await alpaca.trading.assets.getV2AssetsSymbolOrAssetId({ symbolOrAssetId: symUpper });
    return {
      success: true,
      data: {
        id: asset.id,
        symbol: asset.symbol,
        name: asset.name,
        exchange: asset.exchange,
        asset_class: asset._class,
        tradable: asset.tradable,
        marginable: asset.marginable,
        shortable: asset.shortable,
        fractionable: asset.fractionable,
        status: asset.status,
      }
    };
  } catch (error: any) {
    // Fallback: try searching assets by name/query
    try {
      const searchRes = await searchAssets(symbol);
      if (searchRes.success && searchRes.data && searchRes.data.length > 0) {
        const topMatch = searchRes.data[0];
        const asset = await alpaca.trading.assets.getV2AssetsSymbolOrAssetId({ symbolOrAssetId: topMatch.symbol });
        return {
          success: true,
          data: {
            id: asset.id,
            symbol: asset.symbol,
            name: asset.name,
            exchange: asset.exchange,
            asset_class: asset._class,
            tradable: asset.tradable,
            marginable: asset.marginable,
            shortable: asset.shortable,
            fractionable: asset.fractionable,
            status: asset.status,
          }
        };
      }
    } catch (searchErr) {
      // ignore
    }

    console.error('Alpaca getAssetBySymbol error:', error.message);
    return { success: false, error: `Asset not found for "${symbol}". Please check the name or ticker.` };
  }
}

export async function searchAssets(query: string, assetClass?: 'us_equity' | 'crypto' | 'us_option') {
  const searchStr = query.toUpperCase();
  if (!hasAlpacaKeys()) {
    let filtered = MOCK_ASSETS;
    if (assetClass) {
      filtered = filtered.filter(a => a.asset_class === assetClass);
    }
    filtered = filtered.filter(a => 
      a.symbol.includes(searchStr) || 
      a.name.toUpperCase().includes(searchStr)
    );

    return {
      success: true,
      data: filtered.map(a => ({
        symbol: a.symbol,
        name: a.name,
        asset_class: a.asset_class,
      }))
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const assets = await alpaca.trading.assets.getV2Assets({
      status: 'active',
      assetClass: assetClass === 'us_option' ? 'us_equity' : assetClass,
    });
    
    const filtered = assets
      .filter((a: any) => 
        a.symbol.includes(searchStr) || 
        (a.name && a.name.toUpperCase().includes(searchStr))
      )
      .slice(0, 15);

    return {
      success: true,
      data: filtered.map((a: any) => ({
        symbol: a.symbol,
        name: a.name,
        asset_class: a._class,
      }))
    };
  } catch (error: any) {
    console.error('Alpaca searchAssets error:', error.message);
    return { success: false, error: error.message };
  }
}

export async function getOptionsChain(underlyingSymbol: string, expirationDateGte?: string, expirationDateLte?: string) {
  if (!hasAlpacaKeys()) {
    return {
      success: true,
      data: []
    };
  }

  const alpaca = getAlpacaClient();
  try {
    const params: any = {
      underlyingSymbols: underlyingSymbol.toUpperCase(),
      status: 'active',
      limit: 500,
    };

    if (expirationDateGte) params.expirationDateGte = new Date(expirationDateGte);
    if (expirationDateLte) params.expirationDateLte = new Date(expirationDateLte);

    const contracts = await alpaca.trading.collectOptionsContracts(params);

    return {
      success: true,
      data: contracts.map((c: any) => ({
        id: c.id,
        symbol: c.symbol,
        name: c.name,
        type: c.type,
        expiration_date: c.expirationDate,
        strike_price: parseFloat(c.strikePrice),
        underlying_symbol: c.underlyingSymbol,
      }))
    };
  } catch (error: any) {
    console.error('Alpaca getOptionsChain error:', error.message);
    return { success: false, error: error.message };
  }
}

export async function getAssetBars(symbol: string, timeframe: string = '1Day', limit: number = 100, assetClass: 'us_equity' | 'crypto' | 'us_option' = 'us_equity') {
  const sym = symbol.toUpperCase();
  if (!hasAlpacaKeys()) {
    const item = MOCK_ASSETS.find(a => a.symbol === sym || a.symbol.replace('/', '') === sym) || MOCK_ASSETS[0];
    const bars = [];
    let currPrice = item.open;
    const now = new Date();
    
    // Determine step in days/hours
    const daysOffset = timeframe.includes('Hour') ? 1/24 : 1;

    for (let i = limit; i >= 0; i--) {
      const barDate = new Date(now.getTime() - i * daysOffset * 24 * 60 * 60 * 1000);
      const drift = (Math.random() - 0.49) * (currPrice * 0.012);
      currPrice = Math.max(0.1, Number((currPrice + drift).toFixed(2)));
      
      bars.push({
        t: barDate.toISOString(),
        o: currPrice * 0.995,
        h: currPrice * 1.008,
        l: currPrice * 0.991,
        c: currPrice,
        v: Math.floor(item.volume / limit)
      });
    }

    return {
      success: true,
      data: bars
    };
  }

  const alpaca = getAlpacaClient();
  try {
    let bars: any;

    if (assetClass === 'crypto') {
      const result = await alpaca.marketData.crypto.cryptoBars({
        symbols: sym,
        timeframe: timeframe,
        limit: limit,
      });
      bars = result[sym] || [];
    } else if (assetClass === 'us_option') {
      const result = await alpaca.marketData.options.optionBars({
        symbols: sym,
        timeframe: timeframe,
        limit: limit,
      });
      bars = result[sym] || [];
    } else {
      const result = await alpaca.marketData.stocks.stockBars({
        symbols: sym,
        timeframe: timeframe,
        limit: limit,
        adjustment: 'raw',
      });
      bars = result[sym] || [];
    }

    return {
      success: true,
      data: bars
    };
  } catch (error: any) {
    console.error('Alpaca getAssetBars error:', error.message);
    return { success: false, error: error.message };
  }
}

export async function getAssetSnapshot(symbol: string, assetClass: 'us_equity' | 'crypto' | 'us_option' = 'us_equity') {
  const sym = symbol.toUpperCase();
  if (!hasAlpacaKeys()) {
    const item = MOCK_ASSETS.find(a => a.symbol === sym || a.symbol.replace('/', '') === sym) || MOCK_ASSETS[0];
    return {
      success: true,
      data: {
        symbol: sym,
        latestTrade: { p: item.price, s: 100, t: new Date().toISOString() },
        latestQuote: { bp: item.price - 0.05, bs: 10, ap: item.price + 0.05, as: 10 },
        minuteBar: { c: item.price, h: item.high, l: item.low, o: item.open, v: Math.floor(item.volume / 390) },
        dailyBar: { c: item.price, h: item.high, l: item.low, o: item.open, v: item.volume },
        prevDailyBar: { c: item.open, h: item.high, l: item.low, o: item.open * 0.99, v: item.volume }
      }
    };
  }

  const alpaca = getAlpacaClient();
  try {
    let snapshot: any;

    if (assetClass === 'crypto') {
      const result = await alpaca.marketData.crypto.cryptoSnapshots({ symbols: sym });
      snapshot = result[sym];
    } else if (assetClass === 'us_option') {
      const result = await alpaca.marketData.options.optionSnapshots({ symbols: sym });
      snapshot = result[sym];
    } else {
      snapshot = await alpaca.marketData.stocks.stockSnapshotSingle({ symbol: sym });
    }

    if (!snapshot) {
      throw new Error(`Snapshot not found for ${sym}`);
    }

    return {
      success: true,
      data: {
        symbol: sym,
        latestTrade: snapshot.latestTrade,
        latestQuote: snapshot.latestQuote,
        minuteBar: snapshot.minuteBar,
        dailyBar: snapshot.dailyBar,
        prevDailyBar: snapshot.prevDailyBar,
      }
    };
  } catch (error: any) {
    console.error('Alpaca getAssetSnapshot error:', error.message);
    return { success: false, error: error.message };
  }
}
