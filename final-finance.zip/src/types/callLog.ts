export type CallType = 'voice' | 'video';
export type CallScope = 'direct' | 'group';
export type CallDirection = 'outgoing' | 'incoming';
export type CallStatus = 'completed' | 'missed' | 'declined' | 'cancelled';

export interface CallLogParticipant {
  uid: string;
  userId?: string;
  name: string;
  avatarUrl?: string;
  role?: string;
}

export interface CallLog {
  id: string;
  type: CallType;               // 'voice' | 'video'
  scope: CallScope;             // 'direct' | 'group'
  direction: CallDirection;     // 'outgoing' | 'incoming'
  status: CallStatus;           // 'completed' | 'missed' | 'declined' | 'cancelled'
  targetName: string;           // Peer counterparty name or group room name
  targetHandle?: string;        // e.g. 'sterling_vault'
  targetAvatarUrl?: string;
  targetUid?: string;
  groupName?: string;
  participantsCount: number;    // Number of people involved (2 for direct, up to 20 for group)
  participants?: CallLogParticipant[];
  initiatedBy: CallLogParticipant;
  durationSeconds: number;      // Total duration in seconds (0 if missed/cancelled)
  timestamp: string;            // ISO Date string
  notes?: string;
}
