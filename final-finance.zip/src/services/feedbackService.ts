import { AuthSession } from '../types/auth';

export interface AppFeedback {
  id: string;
  userId: string;
  userHandle: string;
  userName: string;
  userAvatar: string;
  rating: number; // 1-5
  category: 'bug' | 'feature' | 'ui' | 'general' | 'other';
  comments: string;
  suggestions?: string;
  timestamp: string;
  isAnonymous: boolean;
  status: 'pending' | 'reviewed' | 'resolved';
  adminNotes?: string;
  reviewMessage?: string;
  reviewedAt?: string;
  resolutionMessage?: string;
  resolvedAt?: string;
}

// Key for local storage persistence
const STORAGE_KEY = 'final_finance_app_feedback_v8';

// Initial mock feedback items for rich administrative demo
const INITIAL_FEEDBACK_ITEMS: AppFeedback[] = [
  {
    id: 'fb-007',
    userId: 'current-user-id',
    userHandle: 'marcus_vance',
    userName: 'Marcus Vance',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    rating: 5,
    category: 'ui',
    comments: 'The vault summary text is a bit too small for my eyes on smaller laptop screens.',
    suggestions: 'Increase the font size or allow for a high-contrast mode.',
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    isAnonymous: false,
    status: 'resolved',
    reviewMessage: 'We have acknowledged your feedback regarding accessibility and font scaling in high-density dashboard areas. Our UX team is currently testing adjusted typography scales.',
    reviewedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    resolutionMessage: 'Accessibility Update Deployed: We have increased the baseline font size for all Vault Summary components by 15% and optimized the contrast ratio to pass WCAG AA standards. Thank you for helping us improve Final Finance!',
    resolvedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'fb-001',
    userId: 'current-user-id',
    userHandle: 'marcus_vance',
    userName: 'Marcus Vance',
    userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    rating: 5,
    category: 'general',
    comments: 'The layout of the sovereign reserve dashboards is masterfully designed. It feels incredibly premium and responsive.',
    suggestions: 'Would love to see interactive charts in the peer loans view.',
    timestamp: new Date(Date.now() - 36 * 60 * 60 * 1000).toISOString(),
    isAnonymous: false,
    status: 'reviewed',
    reviewMessage: 'We have received your feedback regarding the sovereign reserve dashboards. Our design team is already reviewing the possibility of adding interactive charts.',
    reviewedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'fb-002',
    userId: 'current-user-id',
    userHandle: 'marcus_vance',
    userName: 'Marcus Vance',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    rating: 5,
    category: 'feature',
    comments: 'The granular interest rate sliders for peer-to-peer lending are great, but I think we need a "smart auto-calculate" button for optimized returns.',
    suggestions: 'Add an AI-driven toggle that suggests the best rate based on current ecosystem liquidity.',
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    isAnonymous: false,
    status: 'resolved',
    reviewMessage: 'Initial review completed. We agree that an AI-driven smart auto-calculate feature would significantly enhance the lending experience.',
    reviewedAt: new Date(Date.now() - 36 * 60 * 60 * 1000).toISOString(),
    resolutionMessage: 'Feature Implemented: The "Smart Yield Optimization" toggle is now live in the Peer Lending dashboard. It uses real-time liquidity data to suggest ideal interest rates.',
    resolvedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'fb-003',
    userId: 'current-user-id',
    userHandle: 'marcus_vance',
    userName: 'Marcus Vance',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    rating: 5,
    category: 'ui',
    comments: 'Some of the tab switches in mobile device previews had horizontal scrolls that felt tight.',
    suggestions: 'Allow wider slides for statuses.',
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    isAnonymous: false,
    status: 'resolved',
    resolutionMessage: 'We have optimized the horizontal scroll behavior for status filters on mobile devices. Please refresh your app to see the improvements.',
    resolvedAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'fb-004',
    userId: 'current-user-id',
    userHandle: 'marcus_vance',
    userName: 'Marcus Vance',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    rating: 5,
    category: 'bug',
    comments: 'Found a decimal precision error when converting BTC to Swiss Depository gold units in the vault view.',
    suggestions: 'Ensure rounding follows the ISO standard for bullion settlements.',
    timestamp: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString(),
    isAnonymous: false,
    status: 'reviewed',
    reviewMessage: 'Our engineering team has identified the precision mismatch in the cross-asset settlement engine. A patch is currently being tested in the sandbox to ensure compliance with bullion standards.',
    reviewedAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'fb-005',
    userId: 'marcus_vance',
    userHandle: 'marcus_vance',
    userName: 'Marcus Vance',
    userAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    rating: 5,
    category: 'ui',
    comments: 'The dark mode toggle is currently tucked away in the settings menu. It would be better in the top navigation.',
    suggestions: 'Move the theme switcher to the primary app header.',
    timestamp: new Date(Date.now() - 96 * 60 * 60 * 1000).toISOString(),
    isAnonymous: false,
    status: 'resolved',
    reviewMessage: 'Acknowledged. We are evaluating the best placement for a quick-access theme switcher in the global header.',
    reviewedAt: new Date(Date.now() - 70 * 60 * 60 * 1000).toISOString(),
    resolutionMessage: 'UI Update: The Theme Toggle has been promoted to the global navigation bar for all users. You can now switch modes with a single click from any screen.',
    resolvedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'fb-006',
    userId: 'guest',
    userHandle: 'guest',
    userName: 'Guest User',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
    rating: 5,
    category: 'general',
    comments: 'Just exploring the platform as a guest. The interface is very intuitive!',
    timestamp: new Date('2026-09-09T23:32:00').toISOString(),
    isAnonymous: false,
    status: 'reviewed',
    reviewMessage: 'Welcome to the platform! We are glad you find the interface intuitive. Feel free to create an account to unlock full sovereign features.',
    reviewedAt: new Date('2026-09-10T09:00:00').toISOString()
  }
];

export function getFeedbackList(): AppFeedback[] {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_FEEDBACK_ITEMS));
    return INITIAL_FEEDBACK_ITEMS;
  }
  try {
    return JSON.parse(saved);
  } catch (e) {
    return INITIAL_FEEDBACK_ITEMS;
  }
}

export function saveFeedbackList(list: AppFeedback[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

export function submitFeedback(params: {
  rating: number;
  category: AppFeedback['category'];
  comments: string;
  suggestions?: string;
  isAnonymous: boolean;
  user: AuthSession | null;
}): AppFeedback {
  const list = getFeedbackList();
  
  const newFeedback: AppFeedback = {
    id: `fb-user-${Date.now()}`,
    userId: params.isAnonymous ? 'anonymous_user' : (params.user?.id || params.user?.uid || 'guest'),
    userHandle: params.isAnonymous ? 'anonymous' : (params.user?.id || 'guest'),
    userName: params.isAnonymous ? 'Anonymous Peer' : (params.user?.name || 'Guest User'),
    userAvatar: params.isAnonymous 
      ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80' 
      : (params.user?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80'),
    rating: params.rating,
    category: params.category,
    comments: params.comments,
    suggestions: params.suggestions,
    timestamp: new Date().toISOString(),
    isAnonymous: params.isAnonymous,
    status: 'pending'
  };

  list.unshift(newFeedback);
  saveFeedbackList(list);
  return newFeedback;
}

export function updateFeedbackStatus(
  id: string, 
  status?: AppFeedback['status'], 
  adminNotes?: string,
  message?: string
): boolean {
  const list = getFeedbackList();
  const idx = list.findIndex(f => f.id === id);
  if (idx === -1) return false;
  
  if (status) {
    list[idx].status = status;
    if (status === 'reviewed') {
      list[idx].reviewedAt = new Date().toISOString();
      if (message) {
        list[idx].reviewMessage = message;
      }
    } else if (status === 'resolved') {
      list[idx].resolvedAt = new Date().toISOString();
      if (message) {
        list[idx].resolutionMessage = message;
      }
    }
  }
  
  if (adminNotes !== undefined) {
    list[idx].adminNotes = adminNotes;
  }
  
  saveFeedbackList(list);
  return true;
}

export function deleteFeedback(id: string): boolean {
  const list = getFeedbackList();
  const filtered = list.filter(f => f.id !== id);
  if (filtered.length === list.length) return false;
  saveFeedbackList(filtered);
  return true;
}

// ADMIN ESCALATION TO SUPER ADMIN MODEL
export interface AdminEscalation {
  id: string;
  adminId: string;
  adminName: string;
  adminEmail: string;
  subject: string;
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
  status: 'pending' | 'resolved' | 'investigating';
  superAdminNotes?: string;
  investigatingNotes?: string;
  resolvedNotes?: string;
}

const ESCALATIONS_STORAGE_KEY = 'final_finance_admin_escalations_v1';

const INITIAL_ESCALATIONS: AdminEscalation[] = [
  {
    id: 'esc-001',
    adminId: 'adm-2',
    adminName: 'Awesome DBZ',
    adminEmail: 'awesomedbz@gmail.com',
    subject: 'Escrow Liquidity Threshold Check',
    message: 'Requesting permission to increase the Swiss depository physical bullion settlement bounds above $10M for institutional OTC sweeps.',
    severity: 'medium',
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    status: 'resolved',
    superAdminNotes: 'Authorized adjustment to $15M threshold for this quarter.'
  },
  {
    id: 'esc-002',
    adminId: 'adm-5',
    adminName: 'Elena Rostova',
    adminEmail: 'elena.rostova@finalfinance.io',
    subject: 'Compliance Discrepancy Audits',
    message: 'We noticed multiple micro-loans crossing region boundaries without physical notarization. Need root keys audit on compliance protocol.',
    severity: 'high',
    timestamp: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
    status: 'pending'
  }
];

export function getAdminEscalations(): AdminEscalation[] {
  const saved = localStorage.getItem(ESCALATIONS_STORAGE_KEY);
  if (!saved) {
    localStorage.setItem(ESCALATIONS_STORAGE_KEY, JSON.stringify(INITIAL_ESCALATIONS));
    return INITIAL_ESCALATIONS;
  }
  try {
    return JSON.parse(saved);
  } catch (e) {
    return INITIAL_ESCALATIONS;
  }
}

export function saveAdminEscalations(list: AdminEscalation[]): void {
  localStorage.setItem(ESCALATIONS_STORAGE_KEY, JSON.stringify(list));
}

export function submitAdminEscalation(params: {
  admin: AuthSession;
  subject: string;
  message: string;
  severity: AdminEscalation['severity'];
}): AdminEscalation {
  const list = getAdminEscalations();
  const newEsc: AdminEscalation = {
    id: `esc-${Date.now()}`,
    adminId: params.admin.id || params.admin.uid || 'unknown_admin',
    adminName: params.admin.name || 'Admin Officer',
    adminEmail: params.admin.email || 'admin@finalfinance.io',
    subject: params.subject,
    message: params.message,
    severity: params.severity,
    timestamp: new Date().toISOString(),
    status: 'pending'
  };
  list.unshift(newEsc);
  saveAdminEscalations(list);
  return newEsc;
}

export function updateEscalationStatus(
  id: string,
  status?: AdminEscalation['status'],
  superNotes?: string
): boolean {
  const list = getAdminEscalations();
  const idx = list.findIndex(e => e.id === id);
  if (idx === -1) return false;

  if (status) {
    list[idx].status = status;
    if (superNotes !== undefined) {
      if (status === 'investigating') {
        list[idx].investigatingNotes = superNotes;
      } else if (status === 'resolved') {
        list[idx].resolvedNotes = superNotes;
      }
      list[idx].superAdminNotes = superNotes; // fallback/legacy
    }
  }
  saveAdminEscalations(list);
  return true;
}

