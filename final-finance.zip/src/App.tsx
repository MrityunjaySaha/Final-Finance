import React, { useState } from 'react';
import { migrateLoanIdsToLedger } from './utils/ledgerMigration';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { LandingHomePage } from './components/LandingHomePage';
import { UserDashboardView } from './components/UserDashboardView';
import { VaultsView } from './components/VaultsView';
import { MarketplaceView } from './components/MarketplaceView';
import { CommunityView } from './components/CommunityView';
import { MessagesPage } from './components/MessagesPage';
import { SocialPage } from './components/SocialPage';
import { CommunitySearchPage } from './components/CommunitySearchPage';
import { UploadsPage } from './components/UploadsPage';
import { QRCodesPage } from './components/QRCodesPage';
import { WalletsPage } from './components/WalletsPage';
import { PortfolioPage } from './components/PortfolioPage';
import { SettingsPage } from './components/SettingsPage';
import { FundraisingPage } from './components/FundraisingPage';
import { UserProfileView } from './components/UserProfileView';
import { SearchResultsPage } from './components/SearchResultsPage';
import { StockMarketView } from './components/StockMarketView';
import { SubsidiesGrantsPage } from './components/SubsidiesGrantsPage';
import { AdminPage } from './components/AdminPage';
import { SuperAdminPage } from './components/SuperAdminPage';
import { AssetInventoryPage } from './components/AssetInventoryPage';
import { AuthModal } from './components/AuthModal';
import { CallModal } from './components/CallModal';
import { CreateListingDraftModal } from './components/CreateListingDraftModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { DepositModal } from './components/DepositModal';
import { BarterProposalModal } from './components/BarterProposalModal';
import { InstantSwapModal } from './components/InstantSwapModal';
import { VerificationModal } from './components/VerificationModal';
import { ToastContainer } from './components/ToastContainer';
import { ReserveVault } from './types';
import { AuthSession } from './types/auth';
import { SearchableProduct } from './data/searchCatalog';
import { StockItem, StockMarketWay } from './types/stocks';
import { UserPublicProfile } from './types/social';
import { getCurrentSession, signInWithDemoAccount, DEMO_ACCOUNTS, signOut } from './services/firebaseAuth';
import { getOrCreateDirectConversation } from './services/chatService';
import { areUsersBlockedEitherWay } from './services/socialService';
import { DeviceFrame } from './components/common/DeviceFrame';
import { DeviceModeSelector } from './components/common/DeviceModeSelector';

function MainAppContent() {
  console.log('App.tsx: MainAppContent rendering...');
  const { currentTab, setCurrentTab, setCurrentUser, previousTab, setPreviousTab } = useApp();
  console.log('previousTab:', previousTab);

  // Auth session
  const [authSession, setAuthSession] = useState<AuthSession | null>(() => getCurrentSession());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Modals & Active Selections
  const [isNewListingModalOpen, setIsNewListingModalOpen] = useState(false);
  const [selectedVaultForDeposit, setSelectedVaultForDeposit] = useState<ReserveVault | null>(null);

  // Search product detail modal
  const [selectedProduct, setSelectedProduct] = useState<SearchableProduct | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [activeSearchQuery, setActiveSearchQuery] = useState<string>('');

  // Selected Stock for deep-linking
  const [selectedStockForDesk, setSelectedStockForDesk] = useState<StockItem | null>(null);
  const [quickBuyStockForDesk, setQuickBuyStockForDesk] = useState<StockItem | null>(null);
  const [selectedStockMarketWay, setSelectedStockMarketWay] = useState<StockMarketWay | 'all'>('all');

  // Quick Swapper Modal State
  const [isSwapModalOpen, setIsSwapModalOpen] = useState(false);

  // Verification & Subscription Modal State ($2/month with 2 forms of ID)
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);

  // Barter Proposal Modal State
  const [isBarterModalOpen, setIsBarterModalOpen] = useState(false);
  const [barterTargetListing, setBarterTargetListing] = useState<any>(null);

  // Profile View Target
  const [targetProfileUserId, setTargetProfileUserId] = useState<string | null>(null);

  const handleDropdownNavigate = (view: any) => {
    if (view === 'portfolio') {
      setPreviousTab(null); 
    } else {
      setPreviousTab(currentTab);
    }
    setCurrentTab(view);
  };

  // Call Modal State (Voice / Video Conference)
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [callType, setCallType] = useState<'voice' | 'video'>('voice');
  const [callTargetUser, setCallTargetUser] = useState<{
    uid: string;
    userId: string;
    name: string;
    avatarUrl?: string;
  } | null>(null);
  const [callIsGroup, setCallIsGroup] = useState(false);
  const [callGroupParticipants, setCallGroupParticipants] = useState<any[]>([]);

  // Conversation target for messaging
  const [activeChatConversationId, setActiveChatConversationId] = useState<string | null>(null);

  // Sync role-based routing when logged in
  React.useEffect(() => {
    if (authSession && currentTab === 'landing') {
      const email = authSession.email?.trim().toLowerCase();
      if (email === 'ranmaanimaker@gmail.com' || authSession.role === 'super_admin') {
        setCurrentTab('superadmin');
      } else if (email === 'awesomedbz@gmail.com' || authSession.role === 'admin') {
        setCurrentTab('admin');
      } else {
        setCurrentTab('marketplace');
      }
    }
  }, [authSession, currentTab, setCurrentTab]);

  // Scroll to top of page whenever tab changes
  React.useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [currentTab]);

  // Migration: Link legacy loan transactions to loan records
  React.useEffect(() => {
    if (authSession?.id) {
      migrateLoanIdsToLedger(authSession.id);
    }
  }, [authSession?.id]);

  // Sync session changes & route to appropriate portal
  const handleUpdateSession = (updated: AuthSession) => {
    setAuthSession(updated);
    setCurrentUser((prev) => ({
      ...prev,
      name: updated.name,
      handle: `@${updated.id}`,
      avatarUrl: updated.avatarUrl || prev.avatarUrl,
      email: updated.email,
      bio: updated.bio || prev.bio,
    }));
    const email = updated.email?.trim().toLowerCase();
    if (email === 'ranmaanimaker@gmail.com' || updated.role === 'super_admin') {
      setCurrentTab('superadmin');
    } else if (email === 'awesomedbz@gmail.com' || updated.role === 'admin') {
      setCurrentTab('admin');
    } else {
      setCurrentTab('marketplace');
    }
  };

  const handleSignOut = () => {
    signOut();
    setAuthSession(null);
    setCurrentUser((prev) => ({
      ...prev,
      name: 'Guest Explorer',
      handle: '@guest_trader',
      avatarUrl: '',
      email: '',
      bio: '',
    }));
    setCurrentTab('landing');
  };

  const handleSelectDemoAccount = async (key: keyof typeof DEMO_ACCOUNTS) => {
    const res = await signInWithDemoAccount(key);
    if (res.success && res.user) {
      handleUpdateSession(res.user);
    }
  };

  // Open Direct Message from anywhere
  const handleOpenDirectMessage = async (targetUser: UserPublicProfile) => {
    if (!authSession) {
      setIsAuthModalOpen(true);
      return;
    }
    try {
      const conv = await getOrCreateDirectConversation(authSession, targetUser);
      setActiveChatConversationId(conv.id);
      setCurrentTab('messages');
    } catch (err) {
      console.error('Error starting conversation:', err);
    }
  };

  // Trigger Voice Call
  const handleOpenVoiceCall = (
    targetUser: { uid: string; userId: string; name: string; avatarUrl?: string },
    isGroup = false,
    groupParticipants: any[] = []
  ) => {
    if (!isGroup && authSession && areUsersBlockedEitherWay(authSession.uid, targetUser.uid)) {
      alert('Cannot start call: communication is blocked between these accounts.');
      return;
    }
    setCallType('voice');
    setCallTargetUser(targetUser);
    setCallIsGroup(isGroup);
    setCallGroupParticipants(groupParticipants);
    setIsCallModalOpen(true);
  };

  // Trigger Video Call
  const handleOpenVideoCall = (
    targetUser: { uid: string; userId: string; name: string; avatarUrl?: string },
    isGroup = false,
    groupParticipants: any[] = []
  ) => {
    if (!isGroup && authSession && areUsersBlockedEitherWay(authSession.uid, targetUser.uid)) {
      alert('Cannot start call: communication is blocked between these accounts.');
      return;
    }
    setCallType('video');
    setCallTargetUser(targetUser);
    setCallIsGroup(isGroup);
    setCallGroupParticipants(groupParticipants);
    setIsCallModalOpen(true);
  };

  // Handle Search Result Selection
  const handleSelectProduct = (product: SearchableProduct) => {
    setSelectedProduct(product);
    setIsProductModalOpen(true);
  };

  const handleSelectUser = (userIdOrHandle: string) => {
    setPreviousTab(currentTab);
    setTargetProfileUserId(userIdOrHandle);
    setCurrentTab('user_profile');
  };

  const handleSelectStock = (stock: StockItem) => {
    setPreviousTab(currentTab);
    setSelectedStockForDesk(stock);
    setQuickBuyStockForDesk(null);
    if (stock.marketType) {
      setSelectedStockMarketWay(stock.marketType);
    }
    setCurrentTab('stocks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickBuyStock = (stock: StockItem) => {
    setPreviousTab(currentTab);
    setSelectedStockForDesk(stock);
    setQuickBuyStockForDesk(stock);
    if (stock.marketType) {
      setSelectedStockMarketWay(stock.marketType);
    }
    setCurrentTab('stocks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenStockMarketWay = (marketWay?: StockMarketWay | 'all') => {
    setPreviousTab(currentTab);
    setSelectedStockMarketWay(marketWay || 'all');
    setSelectedStockForDesk(null);
    setQuickBuyStockForDesk(null);
    setCurrentTab('stocks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenFullSearch = (query: string) => {
    setPreviousTab(currentTab);
    setActiveSearchQuery(query);
    setCurrentTab('search_results');
  };

  return (
    <div className="w-full">
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-amber-500/30 selection:text-amber-900">
      {/* Top Bar Header */}
      <Header
        currentUserSession={authSession}
        onOpenNewListing={() => {
          if (!authSession) {
            setIsAuthModalOpen(true);
          } else {
            setIsNewListingModalOpen(true);
          }
        }}
        onOpenProfile={() => {
          if (!authSession) {
            setIsAuthModalOpen(true);
          } else {
            setPreviousTab(currentTab);
            setTargetProfileUserId(authSession.id || authSession.uid);
            setCurrentTab('user_profile');
          }
        }}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onSelectProduct={handleSelectProduct}
        onSelectUser={handleSelectUser}
        onSelectStock={handleSelectStock}
        onQuickBuyStock={handleQuickBuyStock}
        onOpenFullSearch={handleOpenFullSearch}
        onSignOut={handleSignOut}
        onOpenInstantSwap={() => setIsSwapModalOpen(true)}
        onUpdateSession={handleUpdateSession}
        onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
      />

      {/* Main View Container */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
        {/* 0. Public Platform Homepage / Landing View */}
        {currentTab === 'landing' && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onAuthSuccess={handleUpdateSession}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => {
              if (authSession) {
                setCurrentTab('marketplace');
              } else {
                setIsAuthModalOpen(true);
              }
            }}
            currentUserSession={authSession}
          />
        )}

        {/* 1. Marketplace Page (Default Home) */}
        {currentTab === 'marketplace' && (
          <MarketplaceView 
            onOpenNewListing={() => {
              if (!authSession) {
                setIsAuthModalOpen(true);
              } else {
                setIsNewListingModalOpen(true);
              }
            }}
            onOpenBarterModal={(item) => {
              if (item) {
                setBarterTargetListing({
                  id: item.id,
                  title: item.title,
                  sellerId: item.sellerId,
                  sellerName: item.sellerName,
                  estimatedValueUSD: item.priceUSD,
                });
              } else {
                setBarterTargetListing(null);
              }
              setIsBarterModalOpen(true);
            }}
            onSelectProduct={handleSelectProduct}
            onSelectUser={handleSelectUser}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
          />
        )}

        {/* 2. User Dashboard */}
        {currentTab === 'dashboard' && authSession && (
          <UserDashboardView
            currentUser={authSession}
            initialActiveTab="overview"
            onOpenNewListing={() => setIsNewListingModalOpen(true)}
            onOpenInstantSwap={() => setIsSwapModalOpen(true)}
            onOpenBarterModal={(item) => {
              if (item) {
                setBarterTargetListing({
                  id: item.id,
                  title: item.title,
                  sellerId: item.sellerId,
                  sellerName: item.sellerName,
                  estimatedValueUSD: item.priceUSD,
                });
              } else {
                setBarterTargetListing(null);
              }
              setIsBarterModalOpen(true);
            }}
            onOpenDepositModal={(vault) => setSelectedVaultForDeposit(vault || null)}
            onOpenVoiceCallDesk={() => {
              handleOpenVoiceCall({
                uid: 'desk-counterparty',
                userId: 'zurich_clearing_desk',
                name: 'Zurich Clearing Desk',
              });
            }}
            onViewPlatformOverview={() => setCurrentTab('landing')}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
          />
        )}

        {/* If user navigates to dashboard without session, show landing */}
        {currentTab === 'dashboard' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onAuthSuccess={handleUpdateSession}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 3. 5 Reserve Vaults */}
        {currentTab === 'vaults' && (
          <VaultsView onOpenDepositModal={(vault) => setSelectedVaultForDeposit(vault)} />
        )}

        {/* 4a. Stock Portfolio (Dedicated clean view: Equities & Stock Portfolio) */}
        {currentTab === 'portfolio' && authSession && (
          <PortfolioPage
            currentUser={authSession}
            initialPrimaryTab="overview"
            onSelectStock={handleSelectStock}
            onOpenStockMarket={handleOpenStockMarketWay}
            onNavigateBack={previousTab === 'dashboard' ? () => setCurrentTab('dashboard') : undefined}
          />
        )}
        {currentTab === 'portfolio' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 4b. Purchased Equity Holdings (Dedicated view: Purchased Stock & Personal Equity Positions) */}
        {currentTab === 'holdings' && authSession && (
          <PortfolioPage
            currentUser={authSession}
            initialPrimaryTab="holdings"
            onSelectStock={handleSelectStock}
            onOpenStockMarket={handleOpenStockMarketWay}
          />
        )}
        {currentTab === 'holdings' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 4c. Asset Inventory */}
        {(currentTab as string) === 'asset_inventory' && authSession && (
          <AssetInventoryPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('dashboard')}
          />
        )}
        {(currentTab as string) === 'asset_inventory' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 4b. My Wallets */}
        {currentTab === 'wallets' && authSession && (
          <UserDashboardView
            currentUser={authSession}
            initialActiveTab="wallets"
            onOpenNewListing={() => setIsNewListingModalOpen(true)}
            onOpenInstantSwap={() => setIsSwapModalOpen(true)}
            onOpenBarterModal={(item) => {
              if (item) {
                setBarterTargetListing({
                  id: item.id || `prop-${Date.now()}`,
                  title: item.title || item.name || 'Barter Proposal',
                  sellerId: item.sellerId,
                  sellerName: item.sellerName,
                  estimatedValueUSD: item.priceUSD || item.estimatedValueUSD || 0,
                });
              } else {
                setBarterTargetListing(null);
              }
              setIsBarterModalOpen(true);
            }}
            onOpenDepositModal={(vault) => setSelectedVaultForDeposit(vault || null)}
            onOpenVoiceCallDesk={() => {
              handleOpenVoiceCall({
                uid: 'desk-counterparty',
                userId: 'zurich_clearing_desk',
                name: 'Zurich Clearing Desk',
              });
            }}
            onViewPlatformOverview={() => setCurrentTab('landing')}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
          />
        )}
        {currentTab === 'wallets' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 5. Uploads & Drafts */}
        {currentTab === 'uploads' && authSession && (
          <UploadsPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('marketplace')}
            onViewListingDetail={(listing) => {
              setSelectedProduct(listing as any);
              setIsProductModalOpen(true);
            }}
          />
        )}
        {currentTab === 'uploads' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* QR Codes Tab */}
        {currentTab === 'qrcodes' && authSession && (
          <QRCodesPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('dashboard')}
            onViewUserProfile={handleSelectUser}
          />
        )}
        {currentTab === 'qrcodes' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 6. Social & Community Hub */}
        {currentTab === 'social' && authSession && (
          <SocialPage
            currentUser={authSession}
            onOpenDirectMessage={handleOpenDirectMessage}
            onOpenVoiceCall={handleOpenVoiceCall}
            onOpenVideoCall={handleOpenVideoCall}
            onOpenCommunitySearch={() => setCurrentTab('community_search')}
            onViewUserProfile={handleSelectUser}
          />
        )}
        {currentTab === 'social' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 7. Community Search & Member Discovery */}
        {currentTab === 'community_search' && authSession && (
          <CommunitySearchPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('social')}
            onOpenDirectMessage={handleOpenDirectMessage}
            onViewUserProfile={handleSelectUser}
            onSelectProduct={handleSelectProduct}
          />
        )}
        {currentTab === 'community_search' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 8. Community Broadcasts & Feed */}
        {currentTab === 'community' && (
          <CommunityView />
        )}

        {/* 9. OTC Messaging & Multi-Conferences */}
        {currentTab === 'messages' && authSession && (
          <MessagesPage
            currentUser={authSession}
            initialConversationId={activeChatConversationId}
            onOpenVoiceCall={handleOpenVoiceCall}
            onOpenVideoCall={handleOpenVideoCall}
            onViewUserProfile={handleSelectUser}
            onNavigateBack={() => setCurrentTab('marketplace')}
          />
        )}
        {currentTab === 'messages' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 10. Sovereign Multi-Asset Fundraising */}
        {currentTab === 'fundraising' && (
          <FundraisingPage
            currentUser={authSession}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {/* Subsidies, Grants & Internal Banking */}
        {currentTab === 'subsidies' && authSession && (
          <SubsidiesGrantsPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('marketplace')}
            onNavigateToSettings={() => setCurrentTab('settings')}
          />
        )}
        {currentTab === 'subsidies' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 11. Full-Fledged Stock Market Page (4 Coin Stock Markets) */}
        {currentTab === 'stocks' && (
          <StockMarketView
            key={selectedStockForDesk ? `stock-${selectedStockForDesk.ticker}` : `stock-market-${selectedStockMarketWay}`}
            currentUser={authSession}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onNavigateBack={() => {
              setSelectedStockForDesk(null);
              setQuickBuyStockForDesk(null);
              setCurrentTab(previousTab as any || (authSession ? 'marketplace' : 'landing'));
            }}
            initialSelectedTicker={selectedStockForDesk?.ticker}
            initialQuickBuyStock={quickBuyStockForDesk}
            initialMarketWay={selectedStockMarketWay}
          />
        )}

        {/* 12. Dedicated Search Results & Universal Recommendations Page */}
        {currentTab === 'search_results' && (
          <SearchResultsPage
            initialQuery={activeSearchQuery}
            currentUser={authSession}
            onNavigateBack={() => {
              setCurrentTab(previousTab as any || 'marketplace');
            }}
            onSelectProduct={handleSelectProduct}
            onSelectUser={handleSelectUser}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
            onOpenDirectMessage={handleOpenDirectMessage}
          />
        )}

        {/* 12. Account & Security Settings (Profile, Security, Verification, Notifications) */}
        {currentTab === 'settings' && authSession && (
          <SettingsPage
            currentUser={authSession}
            onUpdateSession={handleUpdateSession}
            onNavigateBack={() => setCurrentTab('marketplace')}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
            onViewPublicProfile={(userId) => handleSelectUser(userId)}
          />
        )}
        {currentTab === 'settings' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 13. Public User Profile View */}
        {currentTab === 'user_profile' && (
          <UserProfileView
            userIdOrHandle={targetProfileUserId || authSession?.id || 'public'}
            currentUser={authSession || ({
              uid: 'guest',
              id: 'guest',
              name: 'Guest User',
              email: 'guest@finalfinance.io',
              role: 'user',
              provider: 'demo',
              createdAt: new Date().toISOString()
            } as AuthSession)}
            onUpdateSession={handleUpdateSession}
            onOpenDirectMessage={handleOpenDirectMessage}
            onOpenVoiceCall={(user) => handleOpenVoiceCall(user, false)}
            onOpenVideoCall={(user) => handleOpenVideoCall(user, false)}
            onViewListingDetail={(listing) => {
              setSelectedProduct(listing as any);
              setIsProductModalOpen(true);
            }}
            onNavigateBack={() => {
              setCurrentTab(previousTab as any || 'marketplace');
            }}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
          />
        )}

        {/* 14. Admin Portal */}
        {currentTab === 'admin' && authSession && (
          <AdminPage
            currentUser={authSession}
            onNavigateToVaults={() => setCurrentTab('vaults')}
            onNavigateToMarketplace={() => setCurrentTab('marketplace')}
            onNavigateToSuperadmin={() => setCurrentTab('superadmin')}
            onViewProfile={handleSelectUser}
          />
        )}
        {currentTab === 'admin' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 15. Superadmin Master Console */}
        {currentTab === 'superadmin' && authSession && (
          <SuperAdminPage
            currentUser={authSession}
            onNavigateToAdmin={() => setCurrentTab('admin')}
            onNavigateToVaults={() => setCurrentTab('vaults')}
            onNavigateToMarketplace={() => setCurrentTab('marketplace')}
          />
        )}
        {currentTab === 'superadmin' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}
      </main>

      {/* ================= MODALS & OVERLAYS ================= */}

      {/* Verification & $2/month Subscription Modal (2 Forms of ID) */}
      <VerificationModal
        isOpen={isVerificationModalOpen}
        currentUser={authSession}
        onClose={() => setIsVerificationModalOpen(false)}
        onVerificationSuccess={handleUpdateSession}
      />

      {/* Auth Modal (Sign In / Register / Google / Demo Switcher) */}
      <AuthModal
        initialView="signin"
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={handleUpdateSession}
      />

      {/* Voice & Video Conference Modal */}
      <CallModal
        isOpen={isCallModalOpen}
        callType={callType}
        currentUser={authSession}
        remoteUser={callTargetUser as any}
        targetUser={callTargetUser as any}
        isGroup={callIsGroup}
        isGroupCall={callIsGroup}
        groupName={callTargetUser?.name || 'Multi-Conference Group Room'}
        groupParticipants={callGroupParticipants}
        onClose={() => {
          setIsCallModalOpen(false);
          setCallTargetUser(null);
          setCallGroupParticipants([]);
        }}
      />

      {/* Upload Goods/Services & Barter Draft Modal */}
      <CreateListingDraftModal
        isOpen={isNewListingModalOpen}
        currentUser={authSession}
        onClose={() => setIsNewListingModalOpen(false)}
        onSaved={() => setIsNewListingModalOpen(false)}
      />

      {/* Product Detail & Allocation Modal */}
      <ProductDetailModal
        product={selectedProduct}
        currentUser={authSession}
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onSelectAction={() => setIsProductModalOpen(false)}
      />

      {/* Vault Deposit Modal */}
      <DepositModal
        vault={selectedVaultForDeposit}
        onClose={() => setSelectedVaultForDeposit(null)}
      />

      {/* Barter Proposal Modal */}
      <BarterProposalModal
        isOpen={isBarterModalOpen}
        currentUser={authSession}
        targetListing={barterTargetListing}
        onClose={() => {
          setIsBarterModalOpen(false);
          setBarterTargetListing(null);
        }}
      />

      {/* Instant Multi-Vault Swapper Modal */}
      <InstantSwapModal
        isOpen={isSwapModalOpen}
        currentUser={authSession}
        onClose={() => setIsSwapModalOpen(false)}
      />

      {/* Toast Notification Container */}
      <ToastContainer />

      {/* AI Trading Assistant */}
    </div>
  </div>
);
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
