/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Zap,
  ArrowRightLeft,
  Coins,
  Send
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { UserWalletData } from '../../types/wallet';
import { getStoredUserWallets } from '../../data/defaultWallets';
import { FinalCoinMintStudio } from './FinalCoinMintStudio';
import { FinalCoinDetailsModal } from './FinalCoinDetailsModal';
import { FinalCoinTransferModal } from './FinalCoinTransferModal';
import { CoinExchangeTab } from './CoinExchangeTab';
import {
  getStoredCustomCoins,
  isFinalCoinCreatedByUser,
  getCoinRatingSummary
} from '../../data/customCoinsData';
import { getActiveLoanCirculationByCoin } from '../../services/loanService';
import { CustomCoin } from '../../types/coinLaunch';
import {
  clearProfileReturnAnchor,
  getPortfolioTabSnapshot,
  getProfileReturnAnchor,
  isRestoreProfileReturnActive,
  setPendingProfileReturnAnchor,
  updatePortfolioTabSnapshot
} from '../../utils/profileReturnState';

interface CurrenciesDirectoryAndWalletViewProps {
  currentUser: AuthSession | null;
  onOpenExchange?: (payload: { symbol: string; name: string; balance: number; category: string }) => void;
  hideSovereignTools?: boolean;
  sovereignOnly?: boolean;
}

export const CurrenciesDirectoryAndWalletView: React.FC<CurrenciesDirectoryAndWalletViewProps> = ({
  currentUser,
  hideSovereignTools = false,
  sovereignOnly = false
}) => {
  const userId = currentUser?.id || 'guest';
  const userName = currentUser?.name || 'Guest User';

  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(userId));
  const [allCustomCoins, setAllCustomCoins] = useState(() => getStoredCustomCoins());
  const [selectedFinalCoinForDetails, setSelectedFinalCoinForDetails] = useState<CustomCoin | null>(null);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [selectedCoinForTransfer, setSelectedCoinForTransfer] = useState<string | null>(null);
  const [reviewsTick, setReviewsTick] = useState(0);

  // Sync wallet data on window events
  useEffect(() => {
    const handleUpdate = () => {
      setWalletData(getStoredUserWallets(userId));
      setAllCustomCoins(getStoredCustomCoins());
      setReviewsTick(t => t + 1);
    };
    const handleReviewsUpdate = () => {
      setReviewsTick(t => t + 1);
    };

    window.addEventListener('final_finance_wallets_updated', handleUpdate);
    window.addEventListener('final_finance_custom_coins_updated', handleUpdate);
    window.addEventListener('final_finance_loans_updated', handleUpdate);
    window.addEventListener('final_finance_coin_reviews_updated', handleReviewsUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleUpdate);
      window.removeEventListener('final_finance_custom_coins_updated', handleUpdate);
      window.removeEventListener('final_finance_loans_updated', handleUpdate);
      window.removeEventListener('final_finance_coin_reviews_updated', handleReviewsUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [userId]);

  // Main View Toggle: 'final_coins_studio' vs 'swap' vs 'final_list'
  const [activeMainTab, setActiveMainTab] = useState<'final_coins_studio' | 'swap' | 'final_list'>(() => {
    if (hideSovereignTools) return 'final_list';
    if (isRestoreProfileReturnActive()) {
      const snap = getPortfolioTabSnapshot().currenciesMainTab;
      if (snap === 'final_coins_studio' || snap === 'swap' || snap === 'final_list') {
        return snap;
      }
    }
    return 'final_coins_studio';
  });

  useEffect(() => {
    updatePortfolioTabSnapshot({ currenciesMainTab: activeMainTab });
  }, [activeMainTab]);

  // Restore exact card scroll / reopened coin modal when returning via Back button
  useEffect(() => {
    const anchor = getProfileReturnAnchor();
    if (!anchor?.restoreActive) return;

    const targetCoinId = anchor.finalCoinId;
    if (anchor.openFinalCoinModal && targetCoinId) {
      const match = allCustomCoins.find((c) => c.id === targetCoinId);
      if (match) {
        setSelectedFinalCoinForDetails(match);
      }
      clearProfileReturnAnchor();
      return;
    }

    if (targetCoinId) {
      const timer = setTimeout(() => {
        const el = document.querySelector(`[data-final-coin-id="${targetCoinId}"]`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          el.classList.add('ring-4', 'ring-indigo-400', 'transition-all');
          setTimeout(() => {
            el.classList.remove('ring-4', 'ring-indigo-400');
          }, 1800);
        }
        clearProfileReturnAnchor();
      }, 120);
      return () => clearTimeout(timer);
    }

    clearProfileReturnAnchor();
  }, [allCustomCoins]);

  const finalCoinsHoldings = walletData.finalCoins || [];

  const userCreatedFinalCoins = useMemo(() => {
    return allCustomCoins.filter(c => isFinalCoinCreatedByUser(c, currentUser));
  }, [allCustomCoins, currentUser]);

  const userWalletFinalCoins = useMemo(() => {
    return allCustomCoins.filter(coin => {
      if (coin.coinType !== 'final_coin') return false;
      const isMintedByUser = isFinalCoinCreatedByUser(coin, currentUser);
      const userMatch = finalCoinsHoldings.find(
        f => f.symbol.toUpperCase() === coin.symbol.toUpperCase()
      );
      const hasBalance = Boolean(userMatch && Number(userMatch.balance || 0) > 0);
      return isMintedByUser || hasBalance;
    });
  }, [allCustomCoins, currentUser, finalCoinsHoldings]);

  const loanCirculationMap = useMemo(() => {
    void reviewsTick;
    return getActiveLoanCirculationByCoin();
  }, [allCustomCoins, reviewsTick]);

  const handleOpenCreatorProfile = (coin: CustomCoin) => {
    const targetHandle = coin.creatorHandle || coin.creatorId || coin.creatorName;
    if (targetHandle) {
      updatePortfolioTabSnapshot({ currenciesMainTab: activeMainTab });
      setPendingProfileReturnAnchor({
        sourceLabel: 'Back to Final Wallet',
        scrollY: typeof window !== 'undefined' ? window.scrollY : 0,
        finalCoinId: coin.id,
        openFinalCoinModal: false
      });
      window.dispatchEvent(new CustomEvent('open_shared_profile', { detail: targetHandle }));
    }
  };

  return (
    <div className="w-full space-y-6 text-center">
      {/* Top Header Bar with Tabs */}
      <div className="bg-white rounded-3xl p-4 sm:p-6 border border-slate-200 shadow-sm flex flex-col items-center justify-center gap-4 text-center">
        <div className="space-y-1 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-xs font-mono font-bold">
            <Zap className="w-3.5 h-3.5 text-amber-600 fill-current" />
            Sovereign Asset Treasury &amp; Final Currencies
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
            Portfolio &amp; Final Currencies Ecosystem
          </h2>
        </div>

        {/* Tab Switcher & Action buttons - Wrapping cleanly to prevent overflow */}
        <div className="flex flex-wrap items-center justify-center gap-2 w-full">
          <div className="flex flex-wrap items-center justify-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 w-full max-w-3xl">
            {!hideSovereignTools && (
              <>
                <button
                  type="button"
                  onClick={() => setActiveMainTab('final_coins_studio')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 whitespace-nowrap ${
                    activeMainTab === 'final_coins_studio'
                      ? 'bg-amber-600 text-white'
                      : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5 fill-current" />
                  <span>Mint Final Coin ({userCreatedFinalCoins.length}/5)</span>
                </button>

                {!sovereignOnly && (
                  <button
                    type="button"
                    onClick={() => setShowTransferModal(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 whitespace-nowrap"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Transfer</span>
                  </button>
                )}

                <div className="w-px h-6 bg-slate-200 mx-1 shrink-0 hidden sm:block" />

                <button
                  type="button"
                  onClick={() => setActiveMainTab('swap')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 whitespace-nowrap ${
                    activeMainTab === 'swap'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                  }`}
                >
                  <ArrowRightLeft className="w-3.5 h-3.5" />
                  <span>Swap Assets</span>
                </button>
              </>
            )}

            <button
              type="button"
              onClick={() => setActiveMainTab('final_list')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 whitespace-nowrap ${
                activeMainTab === 'final_list'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border border-indigo-200'
              }`}
            >
              <Coins className="w-3.5 h-3.5" />
              <span>Final Wallet</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* VIEW 1: MINT FINAL COIN STUDIO                                            */}
      {/* ========================================================================= */}
      {!hideSovereignTools && activeMainTab === 'final_coins_studio' && (
        <FinalCoinMintStudio
          currentUser={currentUser}
        />
      )}

      {/* ========================================================================= */}
      {/* VIEW 2: SWAP ASSETS                                                       */}
      {/* ========================================================================= */}
      {!hideSovereignTools && activeMainTab === 'swap' && (
        <CoinExchangeTab currentUser={currentUser} />
      )}

      {/* ========================================================================= */}
      {/* VIEW 3: FINAL WALLET                                                      */}
      {/* ========================================================================= */}
      {(hideSovereignTools || activeMainTab === 'final_list') && (
        <div className="space-y-4 text-center">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col items-center justify-center pb-3 border-b border-slate-100 gap-2 text-center">
              <div className="space-y-0.5 text-center">
                <h3 className="text-base font-bold text-slate-900 flex items-center justify-center gap-2">
                  <Coins className="w-5 h-5 text-indigo-600" />
                  Sovereign Final Currencies Directory &amp; Circulation List
                </h3>
              </div>
              <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-900 text-xs font-mono font-bold">
                {userWalletFinalCoins.length} Final {userWalletFinalCoins.length === 1 ? 'Currency' : 'Currencies'}
              </span>
            </div>

            {userWalletFinalCoins.length === 0 ? (
              <div className="bg-slate-50 rounded-3xl p-8 border border-slate-200 text-center space-y-2 max-w-md mx-auto">
                <Coins className="w-8 h-8 text-indigo-400 mx-auto" />
                <p className="text-sm font-bold text-slate-800">No Final Currencies in Your Wallet Yet</p>
                <p className="text-xs text-slate-500">
                  Mint your own Final Coin or receive currencies from other creators to view them here.
                </p>
              </div>
            ) : (
              <div className="flex flex-wrap items-stretch justify-center gap-4 pt-2">
                {userWalletFinalCoins.map(coin => {
                  const userMatch = finalCoinsHoldings.find(
                    f => f.symbol.toUpperCase() === coin.symbol.toUpperCase()
                  );
                  const userBalance = userMatch ? userMatch.balance : 0;
                  const ratingSummary = getCoinRatingSummary(coin.id);
                  void reviewsTick;

                  return (
                    <div
                      key={coin.id}
                      data-final-coin-id={coin.id}
                      className="w-full md:w-[calc(50%-0.5rem)] lg:w-[calc(33.333%-0.75rem)] max-w-md bg-slate-50 border border-slate-200 rounded-3xl p-5 space-y-4 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between text-center"
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3 text-left">
                            {/* Coin symbol / photo logo */}
                            <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${coin.logoBg} flex items-center justify-center text-xl font-bold shadow-md shrink-0`}>
                              {coin.iconSymbol}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-900 leading-tight">{coin.name}</h4>
                              <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-mono text-[10px] font-bold mt-1 inline-block">
                                {coin.symbol}
                              </span>
                            </div>
                          </div>

                          {/* Creator Profile Pic (clickable to open creator profile page) */}
                          <button
                            type="button"
                            onClick={() => handleOpenCreatorProfile(coin)}
                            title={`View ${coin.creatorName || 'creator'}'s profile`}
                            className="flex flex-col items-end group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded-xl p-0.5 shrink-0"
                          >
                            <div className="w-9 h-9 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center shadow-xs text-xs overflow-hidden border border-white group-hover:ring-2 group-hover:ring-indigo-500 transition-all">
                              {coin.creatorAvatar ? (
                                <img src={coin.creatorAvatar} alt={coin.creatorName} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                              ) : (
                                (coin.creatorName || 'A')[0].toUpperCase()
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 group-hover:text-indigo-700 mt-0.5 truncate max-w-[80px] transition-colors">
                              @{coin.creatorHandle || coin.creatorName || 'issuer'}
                            </span>
                          </button>
                        </div>

                        <p className="text-xs text-slate-600 line-clamp-2">
                          {coin.description}
                        </p>

                        {/* Rating Display */}
                        <div className="flex items-center justify-center">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-[11px] font-bold text-amber-900">
                            <span className={ratingSummary.count > 0 ? 'text-amber-500' : 'text-slate-400'}>★</span>
                            <span>
                              {ratingSummary.count > 0
                                ? `${ratingSummary.average.toFixed(1)} / 5 (${ratingSummary.count} ${ratingSummary.count === 1 ? 'review' : 'reviews'})`
                                : 'No ratings yet'}
                            </span>
                          </span>
                        </div>

                        {/* User Balance & Circulation Metrics */}
                        <div className="grid grid-cols-2 gap-2 bg-white p-3 rounded-2xl border border-slate-200 text-xs text-center">
                          <div>
                            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Your Balance</span>
                            <p className="font-bold text-slate-900 font-mono">
                              {userBalance.toLocaleString()} {coin.symbol}
                            </p>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400 uppercase font-mono font-bold block">Circulation</span>
                            <p className="font-bold text-emerald-700 font-mono">
                              {coin.circulatingSupply.toLocaleString()} {coin.symbol}
                            </p>
                            {loanCirculationMap[coin.symbol.toUpperCase()]?.activeRemainingOwed > 0 && (
                              <span className="text-[10px] font-mono text-indigo-600 font-semibold block mt-0.5">
                                Active Loaned: {loanCirculationMap[coin.symbol.toUpperCase()].activeRemainingOwed.toLocaleString()} {coin.symbol}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-2 text-xs">
                        <span className="text-[11px] text-slate-500 font-mono whitespace-nowrap">Total Supply: {coin.totalSupply.toLocaleString()}</span>
                        <button
                          type="button"
                          onClick={() => setSelectedFinalCoinForDetails(coin)}
                          className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs cursor-pointer shrink-0 whitespace-nowrap"
                        >
                          View Details
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Details Modal */}
      {selectedFinalCoinForDetails && (
        <FinalCoinDetailsModal
          coin={selectedFinalCoinForDetails}
          isOpen={!!selectedFinalCoinForDetails}
          onClose={() => setSelectedFinalCoinForDetails(null)}
          currentUser={currentUser}
          onCoinUpdated={(updated) => {
            setSelectedFinalCoinForDetails(updated);
            setAllCustomCoins(getStoredCustomCoins());
          }}
        />
      )}

      {/* Transfer Modal */}
      {showTransferModal && (
        <FinalCoinTransferModal
          userId={userId}
          userName={userName}
          finalCoinsHoldings={finalCoinsHoldings}
          initialCoinSymbol={selectedCoinForTransfer || undefined}
          onClose={() => {
            setShowTransferModal(false);
            setSelectedCoinForTransfer(null);
          }}
        />
      )}
    </div>
  );
};
