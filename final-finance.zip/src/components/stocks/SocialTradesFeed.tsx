import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle2, 
  Star, 
  Clock, 
  Copy, 
  Check, 
  Crown, 
  Eye, 
  Activity, 
  Globe, 
  ChevronRight,
  User,
  Building,
  Search,
  X,
  FileText,
  ExternalLink,
  ShieldCheck,
  Radio
} from 'lucide-react';
import { StockItem, SocialStockTrade, StockMarketWay, PublicDisclosureType } from '../../types/stocks';
import { 
  INITIAL_SOCIAL_TRADES, 
  LIVE_TRADE_TEMPLATES,
  FRIENDS_AND_MUTUALS,
  FriendProfile
} from '../../data/socialTradesData';
import { TARGET_DISCLOSURE_ENTITIES } from '../../services/publicDisclosuresAgent';
import { CelebrityOfficialFilingView } from './CelebrityOfficialFilingView';

export interface ActiveTradeAlertState {
  id: string;
  cardText: string;
  sourceUrl: string | null;
  marketType: StockMarketWay;
  trader: {
    uid: string;
    name: string;
    avatarUrl?: string;
    handle?: string;
    title?: string;
    traderType: 'famous' | 'friend' | 'community';
    isFriend?: boolean;
    friendsCount?: number;
    winRate?: string;
    verified?: boolean;
  };
  ticker: string;
  side: 'buy' | 'sell';
}

export interface SectionCelebrity {
  uid: string;
  name: string;
  handle: string;
  avatarUrl: string;
  title: string;
  verified: boolean;
  winRate: string;
  section: StockMarketWay;
  activeTickers: string[];
}

export const SECTION_CELEBRITIES: SectionCelebrity[] = [
  // --- FIAT CELEBRITIES ---
  {
    uid: 'famous-pelosi',
    name: 'Nancy Pelosi',
    handle: 'pelosi_portfolio',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    title: 'Congressional Disclosures (Sovereign Allocation)',
    verified: true,
    winRate: '89.4%',
    section: 'fiat',
    activeTickers: ['NVDA', 'AAPL']
  },
  {
    uid: 'famous-gates',
    name: 'Bill Gates',
    handle: 'bill_gates',
    avatarUrl: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=300&q=80',
    title: 'Bill & Melinda Gates Foundation Trust / Cascade Investment',
    verified: true,
    winRate: '92.8%',
    section: 'fiat',
    activeTickers: ['MSFT', 'WM']
  },
  {
    uid: 'famous-jim_simons',
    name: 'Jim Simons',
    handle: 'renaissance_tech',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    title: 'Founder, Renaissance Technologies',
    verified: true,
    winRate: '99.1%',
    section: 'fiat',
    activeTickers: ['TSLA']
  },
  {
    uid: 'famous-ackman',
    name: 'Bill Ackman',
    handle: 'bill_ackman',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    title: 'CEO, Pershing Square Capital',
    verified: true,
    winRate: '87.2%',
    section: 'fiat',
    activeTickers: ['NVDA']
  },
  {
    uid: 'famous-buffett',
    name: 'Warren Buffett',
    handle: 'oracle_of_omaha',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: 'Chairman & Sovereign Allocator',
    verified: true,
    winRate: '94.2%',
    section: 'fiat',
    activeTickers: ['AAPL']
  },
  {
    uid: 'famous-elon',
    name: 'Elon Musk',
    handle: 'elonmusk',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    title: 'Technoking, CEO & Director, Tesla, Inc.',
    verified: true,
    winRate: '86.5%',
    section: 'fiat',
    activeTickers: ['TSLA']
  },
  {
    uid: 'famous-jensen',
    name: 'Jensen Huang',
    handle: 'jensen_huang',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: 'President & CEO, NVIDIA Corporation',
    verified: true,
    winRate: '93.7%',
    section: 'fiat',
    activeTickers: ['NVDA']
  },
  {
    uid: 'famous-bezos',
    name: 'Jeff Bezos',
    handle: 'jeffbezos',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    title: 'Executive Chair, Amazon.com, Inc.',
    verified: true,
    winRate: '90.2%',
    section: 'fiat',
    activeTickers: ['AMZN']
  },
  {
    uid: 'famous-tuberville',
    name: 'Tommy Tuberville',
    handle: 'senatortuberville',
    avatarUrl: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=300&q=80',
    title: 'United States Senator (STOCK Act PTR Disclosures)',
    verified: true,
    winRate: '88.1%',
    section: 'fiat',
    activeTickers: ['AAPL', 'NVDA']
  },

  // --- STABLE CELEBRITIES ---
  {
    uid: 'famous-buffett',
    name: 'Warren Buffett',
    handle: 'oracle_of_omaha',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: 'Chairman & Sovereign Allocator',
    verified: true,
    winRate: '94.2%',
    section: 'stable',
    activeTickers: ['BSYN', 'VLT-YLD']
  },
  {
    uid: 'famous-gates',
    name: 'Bill Gates',
    handle: 'bill_gates',
    avatarUrl: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=300&q=80',
    title: 'Bill & Melinda Gates Foundation Trust / Cascade Investment',
    verified: true,
    winRate: '92.8%',
    section: 'stable',
    activeTickers: ['VLT-YLD']
  },
  {
    uid: 'famous-pelosi',
    name: 'Nancy Pelosi',
    handle: 'pelosi_portfolio',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    title: 'Congressional Disclosures (Sovereign Allocation)',
    verified: true,
    winRate: '89.4%',
    section: 'stable',
    activeTickers: ['BSYN']
  },
  {
    uid: 'famous-cathie',
    name: 'Cathie Wood',
    handle: 'cathie_ark',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    title: 'CIO, Disruptive Innovation Fund',
    verified: true,
    winRate: '79.2%',
    section: 'stable',
    activeTickers: ['BSYN']
  },
  {
    uid: 'famous-jim_simons',
    name: 'Jim Simons',
    handle: 'renaissance_tech',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    title: 'Founder, Renaissance Technologies',
    verified: true,
    winRate: '99.1%',
    section: 'stable',
    activeTickers: ['VLT-YLD']
  },

  // --- CRYPTO CELEBRITIES ---
  {
    uid: 'famous-saylor',
    name: 'Michael Saylor',
    handle: 'saylor',
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
    title: 'Executive Chairman & Treasury Strategist',
    verified: true,
    winRate: '91.0%',
    section: 'crypto',
    activeTickers: ['SOLN']
  },
  {
    uid: 'famous-pelosi',
    name: 'Nancy Pelosi',
    handle: 'pelosi_portfolio',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    title: 'Congressional Disclosures (Sovereign Allocation)',
    verified: true,
    winRate: '89.4%',
    section: 'crypto',
    activeTickers: ['SOLN']
  },
  {
    uid: 'famous-elon',
    name: 'Elon Musk',
    handle: 'elonmusk',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    title: 'Technoking & Systems Architect',
    verified: true,
    winRate: '86.5%',
    section: 'crypto',
    activeTickers: ['SOLN']
  },
  {
    uid: 'famous-vitalik',
    name: 'Vitalik Buterin',
    handle: 'vitalik_eth',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    title: 'Ethereum Protocol Architect & Public Disclosures',
    verified: true,
    winRate: '94.5%',
    section: 'crypto',
    activeTickers: ['SOLN']
  },

  // --- FINAL / EQUITY CELEBRITIES ---
  {
    uid: 'famous-pelosi',
    name: 'Nancy Pelosi',
    handle: 'pelosi_portfolio',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    title: 'Congressional Disclosures (Sovereign Allocation)',
    verified: true,
    winRate: '89.4%',
    section: 'final',
    activeTickers: ['HYPR']
  },
  {
    uid: 'famous-dalio',
    name: 'Ray Dalio',
    handle: 'raydalio',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
    title: 'Founder & Macro Strategist',
    verified: true,
    winRate: '92.1%',
    section: 'final',
    activeTickers: ['HYPR']
  },
  {
    uid: 'demo-satoshi-nakamoto',
    name: 'Satoshi Nakamoto',
    handle: 'satoshi_genesis',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    title: 'Sovereign Cash Pioneer',
    verified: true,
    winRate: '98.5%',
    section: 'final',
    activeTickers: ['ALEX']
  }
];

interface SocialTradesFeedProps {
  stocks: StockItem[];
  watchlist: string[];
  selectedMarketFilter?: StockMarketWay | null;
  onSelectStock?: (stock: StockItem) => void;
  onQuickTrade?: (stock: StockItem, side?: 'buy' | 'sell') => void;
  onToggleWatchlist?: (ticker: string) => void;
  viewType?: 'stocks' | 'equity';
  tickerFilter?: string;
}

export const SocialTradesFeed: React.FC<SocialTradesFeedProps> = ({
  stocks,
  watchlist,
  selectedMarketFilter = null,
  onSelectStock,
  onQuickTrade,
  onToggleWatchlist,
  viewType = 'stocks',
  tickerFilter
}) => {
  // Feed state
  const [trades, setTrades] = useState<SocialStockTrade[]>(INITIAL_SOCIAL_TRADES);
  const [traderFilter, setTraderFilter] = useState<'friends' | 'famous' | 'favorite_celebrities' | 'favorite_friends'>('friends');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'personal' | 'business'>('all');
  const [sideFilter, setSideFilter] = useState<'all' | 'buy' | 'sell'>('all');
  const [marketFilter, setMarketFilter] = useState<StockMarketWay | 'all'>(
    viewType === 'equity' ? 'final' : (selectedMarketFilter || 'all')
  );
  const [isLiveStreaming] = useState(true);
  const [copiedTradeId, setCopiedTradeId] = useState<string | null>(null);
  
  // Live notification card alert
  const [activeTradeAlert, setActiveTradeAlert] = useState<ActiveTradeAlertState | null>(null);

  // Initialize market-specific alerts
  useEffect(() => {
    if (activeTradeAlert) return;

    if (marketFilter === 'fiat') {
      setActiveTradeAlert({
        id: 'initial-alert-pelosi',
        cardText: 'New Trade Alert: Nancy Pelosi filed a STOCK Act PTR reporting a BUY of SOLN (2,500 shares ($36,250)) on Execution: 2026-09-23 | Filed: 2026-09-23.',
        sourceUrl: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025287.pdf',
        marketType: 'fiat',
        trader: {
          uid: 'famous-pelosi',
          name: 'Nancy Pelosi',
          avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
          handle: 'pelosi_portfolio',
          title: 'Congressional Disclosures (Sovereign Allocation)',
          traderType: 'famous',
          isFriend: false
        },
        ticker: 'SOLN',
        side: 'buy'
      });
    } else if (marketFilter === 'stable') {
      setActiveTradeAlert({
        id: 'initial-alert-sophia-stable',
        cardText: 'New Trade Alert: Sophia Vance reported a BUY of USDC-AAPL (120 shares (USDC 27,168)) on Execution: 2026-09-23 | Filed: 2026-09-23.',
        sourceUrl: null,
        marketType: 'stable',
        trader: {
          uid: 'user-sophia_vance',
          name: 'Sophia Vance',
          avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
          handle: 'sophiav',
          title: 'Algorithm Designer & Quant',
          traderType: 'friend',
          isFriend: true
        },
        ticker: 'AAPL',
        side: 'buy'
      });
    } else if (marketFilter === 'crypto') {
      setActiveTradeAlert({
        id: 'initial-alert-satoshi-crypto',
        cardText: 'New Trade Alert: Satoshi Nakamoto reported a BUY of BTC-SOLN (25,000 shares (BTC 36.25)) on Execution: 2026-09-23 | Filed: 2026-09-23.',
        sourceUrl: null,
        marketType: 'crypto',
        trader: {
          uid: 'famous-satoshi',
          name: 'Satoshi Nakamoto',
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
          handle: 'satoshi_genesis',
          title: 'Sovereign Cash Pioneer',
          traderType: 'famous',
          isFriend: false
        },
        ticker: 'SOLN',
        side: 'buy'
      });
    }
  }, [marketFilter]);

  // Search box state specifically for finding celebrities in Famous Personalities tab
  const [celebritySearchQuery, setCelebritySearchQuery] = useState('');

  // Active celebrity being viewed in dedicated official filing window
  const [viewingFilingCelebrity, setViewingFilingCelebrity] = useState<{
    uid: string;
    name: string;
    isFriend?: boolean;
  } | null>(null);

  // Favorite celebrities state (persisted to localStorage)
  const [favoriteCelebrityIds, setFavoriteCelebrityIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('final_favorite_celebrities');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return ['famous-pelosi', 'famous-jim_simons'];
  });

  const toggleFavoriteCelebrity = (user: { uid: string; name: string }) => {
    setFavoriteCelebrityIds((prev) => {
      const isFav = prev.includes(user.uid);
      const updated = isFav ? prev.filter((id) => id !== user.uid) : [...prev, user.uid];
      try {
        localStorage.setItem('final_favorite_celebrities', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  // Friend search and favorite friends state
  const [friendSearchQuery, setFriendSearchQuery] = useState('');
  const [favoriteFriendIds, setFavoriteFriendIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('final_favorite_friends');
      if (saved) {
        const parsed: string[] = JSON.parse(saved);
        // Strictly filter to valid friends present in FRIENDS_AND_MUTUALS
        const valid = parsed.filter((id) => FRIENDS_AND_MUTUALS.some((f) => f.uid === id));
        if (valid.length > 0) return valid;
      }
    } catch {}
    // Default initial favorited friend: Elena Rostova (strictly 1 initial favorited friend)
    return ['user-elena_rostova'];
  });

  // Ensure localStorage is cleaned up of any legacy/stale non-friend IDs
  useEffect(() => {
    const valid = favoriteFriendIds.filter((id) =>
      FRIENDS_AND_MUTUALS.some((f) => f.uid === id)
    );
    if (valid.length !== favoriteFriendIds.length) {
      setFavoriteFriendIds(valid);
      try {
        localStorage.setItem('final_favorite_friends', JSON.stringify(valid));
      } catch {}
    }
  }, [favoriteFriendIds]);

  const toggleFavoriteFriend = (friend: { uid: string; name: string }) => {
    setFavoriteFriendIds((prev) => {
      const clean = prev.filter((id) => FRIENDS_AND_MUTUALS.some((f) => f.uid === id));
      const isFav = clean.includes(friend.uid);
      const updated = isFav ? clean.filter((id) => id !== friend.uid) : [...clean, friend.uid];
      try {
        localStorage.setItem('final_favorite_friends', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  // Helper to reliably resolve a trader into the correct view profile
  const resolveTraderTarget = (trader: {
    uid: string;
    name: string;
    isFriend?: boolean;
    traderType?: string;
  }) => {
    // 1. Direct check in FRIENDS_AND_MUTUALS
    const friendObj = FRIENDS_AND_MUTUALS.find(
      (f) => f.uid === trader.uid || f.name.toLowerCase() === trader.name.toLowerCase()
    );
    if (friendObj) {
      return { uid: friendObj.uid, name: friendObj.name, isFriend: true };
    }

    if (trader.isFriend || trader.traderType === 'friend' || trader.uid.startsWith('user-')) {
      return { uid: trader.uid, name: trader.name, isFriend: true };
    }

    // 2. Search SECTION_CELEBRITIES
    const celeb = SECTION_CELEBRITIES.find(
      (c) => c.uid === trader.uid || c.name.toLowerCase() === trader.name.toLowerCase()
    );
    if (celeb) {
      return { uid: celeb.uid, name: celeb.name, isFriend: false };
    }

    // 3. Search TARGET_DISCLOSURE_ENTITIES
    const disclosureEnt = TARGET_DISCLOSURE_ENTITIES.find(
      (t) => t.id === trader.uid || t.name.toLowerCase() === trader.name.toLowerCase()
    );
    if (disclosureEnt) {
      const isFriend = disclosureEnt.sourceAgency === 'Peer Syndicate Network' || disclosureEnt.id.startsWith('user-');
      return { uid: disclosureEnt.id, name: disclosureEnt.name, isFriend };
    }

    return { uid: trader.uid, name: trader.name, isFriend: Boolean(trader.isFriend) };
  };

  const displayedFriends = useMemo(() => {
    if (!friendSearchQuery.trim()) return FRIENDS_AND_MUTUALS;
    const q = friendSearchQuery.toLowerCase().trim();
    const words = q.split(/\s+/).filter(Boolean);
    return FRIENDS_AND_MUTUALS.filter((f) => {
      const text = `${f.name} ${f.handle} ${f.title} ${f.bio} ${f.relationType} ${f.topSectors.join(' ')}`.toLowerCase();
      return words.every((w) => text.includes(w));
    });
  }, [friendSearchQuery]);

  const favoriteFriendsList = useMemo(() => {
    return FRIENDS_AND_MUTUALS.filter((f) => favoriteFriendIds.includes(f.uid));
  }, [favoriteFriendIds]);

  // Determine current active section
  const currentSection: StockMarketWay = useMemo(() => {
    if (viewType === 'equity') return 'final';
    if (marketFilter !== 'all') return marketFilter;
    if (selectedMarketFilter) return selectedMarketFilter;
    return 'fiat';
  }, [viewType, marketFilter, selectedMarketFilter]);

  // Celebrities available for this current section
  const sectionCelebrities = useMemo(() => {
    return SECTION_CELEBRITIES.filter((c) => c.section === currentSection);
  }, [currentSection]);

  // Filtered celebrities in Famous Personalities tab via search query
  const displayedCelebrities = useMemo(() => {
    if (!celebritySearchQuery.trim()) return sectionCelebrities;
    const q = celebritySearchQuery.toLowerCase().trim();
    const words = q.split(/\s+/).filter(Boolean);
    return sectionCelebrities.filter((c) => {
      const text = `${c.name} ${c.handle} ${c.title} ${c.activeTickers.join(' ')}`.toLowerCase();
      return words.every((w) => text.includes(w));
    });
  }, [sectionCelebrities, celebritySearchQuery]);

  // Celebrities favorited by user for this section
  const favoriteCelebritiesForSection = useMemo(() => {
    return sectionCelebrities.filter((c) => favoriteCelebrityIds.includes(c.uid));
  }, [sectionCelebrities, favoriteCelebrityIds]);

  // Celebrities available in this section not yet favorited
  const unfavoritedCelebritiesForSection = useMemo(() => {
    return sectionCelebrities.filter((c) => !favoriteCelebrityIds.includes(c.uid));
  }, [sectionCelebrities, favoriteCelebrityIds]);

  // Sync marketFilter when parent selectedMarketFilter changes
  useEffect(() => {
    if (selectedMarketFilter) {
      setMarketFilter(selectedMarketFilter);
    }
  }, [selectedMarketFilter]);

  // Real-time live trade simulator with strictly valid notifications matching active section
  useEffect(() => {
    if (!isLiveStreaming) return;

    const interval = setInterval(() => {
      // Filter candidate templates strictly for the current section
      const matchingTemplates = LIVE_TRADE_TEMPLATES.filter((template) => {
        // 1. Strict ViewType Rule:
        if (viewType === 'equity') {
          return template.marketType === 'final';
        }
        if (viewType === 'stocks' && template.marketType === 'final') {
          return false;
        }

        // 2. Strict MarketFilter Rule (for regular stock section):
        if (marketFilter === 'fiat') {
          return template.marketType === 'fiat' || template.marketType === 'global';
        }
        if (marketFilter === 'stable') {
          return template.marketType === 'stable';
        }
        if (marketFilter === 'crypto') {
          return template.marketType === 'crypto';
        }
        return template.marketType !== 'final';
      });

      if (matchingTemplates.length === 0) return;

      const randomTemplate = matchingTemplates[Math.floor(Math.random() * matchingTemplates.length)];

      const newTrade: SocialStockTrade = {
        ...randomTemplate,
        id: `live-trade-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toISOString(),
        timestampAgo: 'Just now',
        isRealTimeNew: true
      };

      setTrades((prev) => [newTrade, ...prev.slice(0, 45)]);

      // Notification format:
      // "New Trade Alert: [filer_name] filed a [disclosure_type] reporting a [action] of [ticker] ([share_quantity_or_value]) on [timestamp]."
      if (newTrade.traderType === 'famous') {
        const dType: PublicDisclosureType = newTrade.disclosureType || (newTrade.user.name.includes('Pelosi') ? 'STOCK Act PTR' : 'SEC Form 13F');
        const execDate = newTrade.executionDate || new Date().toISOString().slice(0, 10);
        const filingDate = newTrade.filingDate || new Date().toISOString().slice(0, 10);
        const alertTime = `Execution: ${execDate} | Filed: ${filingDate}`;
        
        let currencySymbol = '$';
        if (newTrade.marketType === 'stable') currencySymbol = 'USDC ';
        if (newTrade.marketType === 'crypto') currencySymbol = 'BTC ';
        
        const valStr = newTrade.shareQuantityOrValue || `${newTrade.shares.toLocaleString()} shares (${currencySymbol}${newTrade.totalValueUSD.toLocaleString()})`;
        
        const cardText = `New Trade Alert: ${newTrade.user.name} filed a ${dType} reporting a ${newTrade.side === 'sell' ? 'SELL' : 'BUY'} of ${newTrade.ticker} (${valStr}) on ${alertTime}.`;
        setActiveTradeAlert({
          id: newTrade.id,
          cardText,
          sourceUrl: newTrade.sourceDocumentUrl || 'https://www.sec.gov/edgar/search/#/forms=4',
          marketType: newTrade.marketType,
          trader: {
            uid: newTrade.user.uid,
            name: newTrade.user.name,
            avatarUrl: newTrade.user.avatarUrl,
            handle: newTrade.user.handle,
            title: newTrade.user.title,
            traderType: newTrade.traderType,
            isFriend: false,
            friendsCount: newTrade.user.friendsCount,
            winRate: newTrade.user.winRate,
            verified: newTrade.user.verified
          },
          ticker: newTrade.ticker,
          side: newTrade.side
        });
      } else {
        const dateStr = new Date().toLocaleDateString();
        let tickerPrefix = '$';
        if (newTrade.marketType === 'stable') tickerPrefix = 'USDC-';
        if (newTrade.marketType === 'crypto') tickerPrefix = 'BTC-';
        
        const cardText = `New Trade Alert: ${newTrade.user.name} reported a ${newTrade.side.toUpperCase()} of ${tickerPrefix}${newTrade.ticker} (${newTrade.shares.toLocaleString()} shares) on ${dateStr}.`;
        setActiveTradeAlert({
          id: newTrade.id,
          cardText,
          sourceUrl: null,
          marketType: newTrade.marketType,
          trader: {
            uid: newTrade.user.uid,
            name: newTrade.user.name,
            avatarUrl: newTrade.user.avatarUrl,
            handle: newTrade.user.handle,
            title: newTrade.user.title,
            traderType: newTrade.traderType,
            isFriend: true,
            friendsCount: newTrade.user.friendsCount,
            winRate: newTrade.user.winRate,
            verified: newTrade.user.verified
          },
          ticker: newTrade.ticker,
          side: newTrade.side
        });
      }

      setTimeout(() => {
        setActiveTradeAlert((curr) => (curr?.id === newTrade.id ? null : curr));
      }, 7000);
    }, 12000);

    return () => clearInterval(interval);
  }, [isLiveStreaming, viewType, marketFilter]);

  // Handle Copy Trade: Copy exact trade valuation to clipboard & prepare trade order
  const handleCopyTrade = (trade: SocialStockTrade) => {
    const isFinalMarket = trade.marketType === 'final';
    const valuationStr = isFinalMarket
      ? `${trade.totalValueUSD.toLocaleString()} ALEX`
      : `$${trade.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    navigator.clipboard.writeText(valuationStr);
    const targetStock = stocks.find((s) => s.ticker === trade.ticker);
    if (targetStock && onQuickTrade) {
      onQuickTrade(targetStock, trade.side);
    }
    setCopiedTradeId(trade.id);
    setTimeout(() => setCopiedTradeId(null), 2500);
  };

  // Filtered trades list (shown under All, Friends, and Famous Personalities)
  const filteredTrades = useMemo(() => {
    const todayStr = new Date().toDateString();

    let list = trades.filter((trade) => {
      // New: Only show trades for the day
      const tradeDateStr = new Date(trade.timestamp).toDateString();
      if (tradeDateStr !== todayStr) return false;

      // 0. Strict ViewType Filtering:
      if (viewType === 'equity' && trade.marketType !== 'final') return false;
      if (viewType === 'stocks' && trade.marketType === 'final') return false;
      if (trade.marketType === 'final' || trade.assetCategory === 'personal') {
        if (viewType !== 'equity' && marketFilter !== 'final') return false;
      }

      // 1. Trader filter (Friends, Famous, Favorite Friends, Favorite Celebrities)
      if (traderFilter === 'friends' && trade.traderType !== 'friend') return false;
      if (traderFilter === 'famous' && trade.traderType !== 'famous') return false;
      if (traderFilter === 'favorite_friends') {
        if (trade.traderType !== 'friend') return false;
        if (!favoriteFriendIds.includes(trade.user.uid)) return false;
      }
      if (traderFilter === 'favorite_celebrities') {
        if (trade.traderType !== 'famous') return false;
        if (!favoriteCelebrityIds.includes(trade.user.uid)) return false;
      }

      // 1.5 If in Famous Personalities tab and user typed a celebrity search query, filter trades
      if (traderFilter === 'famous' && celebritySearchQuery.trim()) {
        const q = celebritySearchQuery.toLowerCase().trim();
        const words = q.split(/\s+/).filter(Boolean);
        const text = `${trade.user.name} ${trade.user.handle} ${trade.ticker} ${trade.stockName} ${trade.commentary}`.toLowerCase();
        if (!words.every((w) => text.includes(w))) return false;
      }

      // 1.6 If in Friends & Mutuals tab and user typed a friend search query, filter trades
      if (traderFilter === 'friends' && friendSearchQuery.trim()) {
        const q = friendSearchQuery.toLowerCase().trim();
        const words = q.split(/\s+/).filter(Boolean);
        const text = `${trade.user.name} ${trade.user.handle} ${trade.ticker} ${trade.stockName} ${trade.commentary || ''}`.toLowerCase();
        if (!words.every((w) => text.includes(w))) return false;
      }

      // 2. Category filter: personal vs business
      if (categoryFilter !== 'all') {
        const cat = trade.assetCategory || (trade.ticker === 'ALEX' ? 'personal' : 'business');
        if (cat !== categoryFilter) return false;
      }

      // 3. Side
      if (sideFilter !== 'all' && trade.side !== sideFilter) return false;

      // 4. Market Way
      if (marketFilter !== 'all' && trade.marketType !== marketFilter) return false;

      // 5. Ticker filter if provided directly as a prop
      if (tickerFilter && trade.ticker.toUpperCase() !== tickerFilter.toUpperCase()) {
        return false;
      }

      return true;
    });

    return list;
  }, [trades, traderFilter, celebritySearchQuery, friendSearchQuery, categoryFilter, sideFilter, marketFilter, tickerFilter, viewType, favoriteFriendIds, favoriteCelebrityIds]);

  const getSectionTitle = (sec: StockMarketWay) => {
    switch (sec) {
      case 'final':
        return 'Sovereign Equity';
      case 'stable':
        return 'Stable Market';
      case 'crypto':
        return 'Crypto Market';
      case 'fiat':
      default:
        return 'Fiat Market';
    }
  };

  const getMarketBadge = (market: StockMarketWay) => {
    switch (market) {
      case 'final':
        return { label: 'Final Market', bg: 'bg-amber-500/10 text-amber-900 border-amber-500/30' };
      case 'stable':
        return { label: 'Stable Market', bg: 'bg-emerald-500/10 text-emerald-900 border-emerald-500/30' };
      case 'fiat':
        return { label: 'Fiat Market', bg: 'bg-indigo-500/10 text-indigo-900 border-indigo-500/30' };
      case 'crypto':
        return { label: 'Crypto Market', bg: 'bg-purple-500/10 text-purple-900 border-purple-500/30' };
      case 'global':
        return { label: 'Global Market', bg: 'bg-slate-500/10 text-slate-900 border-slate-500/30' };
    }
  };

  // Dedicated Official Filing Window with full details and back button
  if (viewingFilingCelebrity) {
    const isFriendEntity = Boolean(viewingFilingCelebrity.isFriend || viewingFilingCelebrity.uid.startsWith('user-'));
    const isFav = isFriendEntity
      ? favoriteFriendIds.includes(viewingFilingCelebrity.uid)
      : favoriteCelebrityIds.includes(viewingFilingCelebrity.uid);
    return (
      <CelebrityOfficialFilingView
        entityId={viewingFilingCelebrity.uid}
        celebrityName={viewingFilingCelebrity.name}
        isFavorited={isFav}
        onToggleFavorite={() => {
          if (isFriendEntity) {
            toggleFavoriteFriend(viewingFilingCelebrity);
          } else {
            toggleFavoriteCelebrity(viewingFilingCelebrity);
          }
        }}
        onBack={() => setViewingFilingCelebrity(null)}
        onQuickTrade={(ticker, side) => {
          const targetStock = stocks.find((s) => s.ticker === ticker);
          if (targetStock && onQuickTrade) {
            onQuickTrade(targetStock, side);
          }
        }}
      />
    );
  }

  return (
    <div className="space-y-6 text-left">
      {/* Front-End Notification Card: Live Alert (Market-Filtered) */}
      {activeTradeAlert && (marketFilter === 'all' || activeTradeAlert.marketType === marketFilter) && (
        <div className={`p-4 rounded-3xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-sm animate-fade-in ${
          activeTradeAlert.trader.isFriend
            ? 'bg-indigo-50/90 border-indigo-200 text-indigo-950'
            : 'bg-amber-50 border-amber-300/80 text-amber-950'
        }`}>
          <div className="flex items-start gap-3 min-w-0">
            <div className="relative mt-0.5 shrink-0">
              <span className={`w-2.5 h-2.5 rounded-full animate-ping absolute inset-0 ${
                activeTradeAlert.trader.isFriend ? 'bg-indigo-500' : 'bg-amber-500'
              }`} />
              <Radio className={`w-4 h-4 relative ${
                activeTradeAlert.trader.isFriend ? 'text-indigo-600' : 'text-amber-600'
              }`} />
            </div>
            <div className="space-y-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className={`font-bold text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-md font-mono ${
                  activeTradeAlert.trader.isFriend
                    ? 'bg-indigo-200 text-indigo-900 border border-indigo-300'
                    : 'bg-amber-200 text-amber-900 font-mono'
                }`}>
                  {activeTradeAlert.trader.isFriend ? 'Peer Trade Alert' : 'Public Disclosure Alert'}
                </span>
                <span className={`text-[11px] font-mono ${
                  activeTradeAlert.trader.isFriend ? 'text-indigo-700 font-semibold' : 'text-amber-800'
                }`}>
                  {activeTradeAlert.trader.isFriend 
                    ? 'Community Peer Feed' 
                    : (activeTradeAlert.marketType === 'fiat' 
                        ? 'Official Gov Feed' 
                        : (activeTradeAlert.marketType === 'stable' 
                            ? 'Stable Clearing Feed' 
                            : 'On-Chain Crypto Feed'))}
                </span>
              </div>
              <p className="font-mono text-xs font-semibold leading-relaxed text-slate-900">
                {activeTradeAlert.cardText.includes(activeTradeAlert.trader.name) ? (
                  <>
                    {activeTradeAlert.cardText.split(activeTradeAlert.trader.name)[0]}
                    <button
                      type="button"
                      onClick={() => {
                        const target = resolveTraderTarget(activeTradeAlert.trader);
                        setViewingFilingCelebrity(target);
                      }}
                      className={`font-bold underline cursor-pointer hover:opacity-80 transition-opacity ${
                        activeTradeAlert.trader.isFriend
                          ? 'text-indigo-900 hover:text-indigo-700'
                          : 'text-amber-900 hover:text-amber-700'
                      }`}
                      title={`View ${activeTradeAlert.trader.isFriend ? 'past month trades' : 'official filing'} for ${activeTradeAlert.trader.name}`}
                    >
                      {activeTradeAlert.trader.name}
                    </button>
                    {activeTradeAlert.cardText.split(activeTradeAlert.trader.name).slice(1).join(activeTradeAlert.trader.name)}
                  </>
                ) : (
                  activeTradeAlert.cardText
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            <button
              type="button"
              onClick={() => {
                const target = resolveTraderTarget(activeTradeAlert.trader);
                setViewingFilingCelebrity(target);
              }}
              className={`px-3 py-1.5 rounded-xl text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs active:scale-95 ${
                activeTradeAlert.trader.isFriend
                  ? 'bg-indigo-900 hover:bg-indigo-800'
                  : 'bg-slate-900 hover:bg-slate-800'
              }`}
              title={`View ${activeTradeAlert.trader.isFriend ? 'past month trades' : 'official filing'} for ${activeTradeAlert.trader.name}`}
            >
              <FileText className={`w-3.5 h-3.5 ${activeTradeAlert.trader.isFriend ? 'text-indigo-300' : 'text-amber-400'}`} />
              <span>
                {activeTradeAlert.trader.isFriend 
                  ? 'Past Month Trades' 
                  : (activeTradeAlert.marketType === 'fiat' 
                      ? 'Official Filing Document' 
                      : (activeTradeAlert.marketType === 'stable' 
                          ? 'Clearing Receipt' 
                          : 'On-Chain Proof'))}
              </span>
            </button>
            {activeTradeAlert.sourceUrl && (
              <a
                href={activeTradeAlert.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-2xs"
              >
                <span>.gov</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
            <button 
              type="button" 
              onClick={() => setActiveTradeAlert(null)}
              className={`cursor-pointer p-1.5 rounded-xl ${
                activeTradeAlert.trader.isFriend
                  ? 'text-indigo-700 hover:text-indigo-950 hover:bg-indigo-200/60'
                  : 'text-amber-800 hover:text-amber-950 hover:bg-amber-200/60'
              }`}
              title="Dismiss notification"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Filter & Persona Controls Bar */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Primary Trader Persona Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <button
              type="button"
              onClick={() => setTraderFilter('friends')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                traderFilter === 'friends'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>Friends &amp; Mutuals</span>
            </button>

            {/* Favorite Friends Tab next to Friends & Mutuals */}
            <button
              type="button"
              onClick={() => setTraderFilter('favorite_friends')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                traderFilter === 'favorite_friends'
                  ? 'bg-amber-500 text-slate-950 shadow-xs font-extrabold'
                  : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200/60'
              }`}
            >
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span>Favorite Friends ({favoriteFriendsList.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setTraderFilter('famous')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                traderFilter === 'famous'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-amber-500" />
              <span>Famous Personalities</span>
            </button>

            {/* Favorite Celebrities Tab next to Famous Personalities */}
            <button
              type="button"
              onClick={() => setTraderFilter('favorite_celebrities')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                traderFilter === 'favorite_celebrities'
                  ? 'bg-amber-500 text-slate-950 shadow-xs font-extrabold'
                  : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200/60'
              }`}
            >
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span>Favorite Celebrities ({favoriteCelebritiesForSection.length})</span>
            </button>
          </div>

          {/* Secondary Sub-filters: Side Filter (hidden in favorite tabs) */}
          {traderFilter !== 'favorite_celebrities' && traderFilter !== 'favorite_friends' && (
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400 font-medium text-[11px]">Side:</span>
              <button
                type="button"
                onClick={() => setSideFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  sideFilter === 'all' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setSideFilter('buy')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  sideFilter === 'buy' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                }`}
              >
                Buys
              </button>
              <button
                type="button"
                onClick={() => setSideFilter('sell')}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                  sideFilter === 'sell' ? 'bg-rose-600 text-white' : 'bg-rose-50 text-rose-800 hover:bg-rose-100'
                }`}
              >
                Sells
              </button>
            </div>
          )}
        </div>

        {/* Equity Category Filter (Personal vs Business) if applicable */}
        {viewType !== 'stocks' && (
          <div className="pt-3 border-t border-slate-100 flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl w-fit">
            <button
              type="button"
              onClick={() => setCategoryFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                categoryFilter === 'all' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Types
            </button>
            <button
              type="button"
              onClick={() => setCategoryFilter('business')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1 ${
                categoryFilter === 'business' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building className="w-3 h-3" />
              <span>Business</span>
            </button>
            <button
              type="button"
              onClick={() => setCategoryFilter('personal')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1 ${
                categoryFilter === 'personal' ? 'bg-purple-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <User className="w-3 h-3" />
              <span>Personal</span>
            </button>
          </div>
        )}
      </div>

      {/* ================= FRIENDS & MUTUALS TAB: SEARCH BAR ONLY ================= */}
      {traderFilter === 'friends' && (
        <div className="space-y-3">
          <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-amber-500" />
              <span className="font-bold text-xs text-slate-900 uppercase font-mono">Search Friends &amp; Mutuals Trades (Past Month):</span>
            </div>
            {/* Friend Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={friendSearchQuery}
                onChange={(e) => setFriendSearchQuery(e.target.value)}
                placeholder="Search friends & mutuals..."
                className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-amber-500 font-sans"
              />
              {friendSearchQuery && (
                <button
                  type="button"
                  onClick={() => setFriendSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= FAVORITE FRIENDS TAB VIEW ================= */}
      {traderFilter === 'favorite_friends' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                <span>Favorite Friends &amp; Mutuals</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Friends and mutual peers you have favorited for quick trade alerts.
              </p>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 font-bold">
              {favoriteFriendsList.length} Favorited
            </span>
          </div>

          {favoriteFriendsList.length === 0 ? (
            <div className="p-8 text-center rounded-3xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 text-amber-500 flex items-center justify-center mx-auto shadow-2xs">
                <Star className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">No Favorite Friends Yet</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                You haven't favorited any friends yet. Switch to Friends &amp; Mutuals tab to favorite peers:
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setTraderFilter('friends')}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <Users className="w-3.5 h-3.5 text-amber-400" />
                  <span>Browse Friends &amp; Mutuals</span>
                </button>
                {FRIENDS_AND_MUTUALS.slice(0, 3).map((friend) => (
                  <button
                    key={friend.uid}
                    type="button"
                    onClick={() => toggleFavoriteFriend(friend)}
                    className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 hover:border-amber-400 text-slate-800 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-2xs"
                  >
                    <img src={friend.avatarUrl} alt={friend.name} className="w-5 h-5 rounded-full object-cover" />
                    <span>★ Favorite {friend.name}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {favoriteFriendsList.map((friend) => (
                <div 
                  key={friend.uid}
                  className="p-4 rounded-3xl bg-amber-50/40 border border-amber-300 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between gap-3.5"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={friend.avatarUrl}
                          alt={friend.name}
                          onClick={() => setViewingFilingCelebrity(friend)}
                          className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shrink-0 shadow-2xs cursor-pointer hover:ring-2 hover:ring-indigo-400 transition-all"
                          title={`View trades in the past month for ${friend.name}`}
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span 
                              onClick={() => setViewingFilingCelebrity(friend)}
                              className="font-bold text-sm text-slate-900 truncate hover:text-indigo-600 cursor-pointer transition-colors"
                              title={`View trades in the past month for ${friend.name}`}
                            >
                              {friend.name}
                            </span>
                            {friend.verified && <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />}
                          </div>
                          <p className="text-xs font-mono text-slate-400 mt-0.5">
                            @{friend.handle} &bull; <span className="text-amber-700 font-semibold">{friend.relationType}</span>
                          </p>
                        </div>
                      </div>

                      <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 shrink-0">
                        {friend.winRate} Win
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed font-medium">
                      {friend.title}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setViewingFilingCelebrity(friend)}
                      className="flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer bg-slate-900 hover:bg-slate-800 text-white shadow-2xs active:scale-95 whitespace-nowrap"
                      title={`View trades in the past month for ${friend.name}`}
                    >
                      <FileText className="w-3.5 h-3.5 text-indigo-300 shrink-0" />
                      <span>Past Month Trades</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleFavoriteFriend(friend)}
                      className="py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200 shadow-2xs"
                    >
                      <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      <span>Favorited</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ================= FAMOUS PERSONALITIES TAB: SEARCH BAR ONLY ================= */}
      {traderFilter === 'famous' && (
        <div className="space-y-3">
          <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Crown className="w-4 h-4 text-amber-500" />
              <span className="font-bold text-xs text-slate-900 uppercase font-mono">Search Famous Personalities Trades (Past Month):</span>
            </div>
            {/* Celebrity Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={celebritySearchQuery}
                onChange={(e) => setCelebritySearchQuery(e.target.value)}
                placeholder="Search celebrities..."
                className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-amber-500 font-sans"
              />
              {celebritySearchQuery && (
                <button
                  type="button"
                  onClick={() => setCelebritySearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= FAVORITE CELEBRITIES TAB VIEW ================= */}
      {traderFilter === 'favorite_celebrities' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                <span>Favorite Celebrities in {getSectionTitle(currentSection)}</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Celebrities you have favorited in the {getSectionTitle(currentSection)} market.
              </p>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 font-bold">
              {favoriteCelebritiesForSection.length} Favorited
            </span>
          </div>

          {favoriteCelebritiesForSection.length === 0 ? (
            <div className="p-8 text-center rounded-3xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 text-amber-500 flex items-center justify-center mx-auto shadow-2xs">
                <Star className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm">No Favorite Celebrities in {getSectionTitle(currentSection)}</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                You haven't favorited any celebrities in the {getSectionTitle(currentSection)} section yet. Switch to Famous Personalities to search and favorite celebrities:
              </p>
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setTraderFilter('famous')}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Browse &amp; Search Famous Personalities</span>
                </button>
                {unfavoritedCelebritiesForSection.slice(0, 3).map((celeb) => (
                  <button
                    key={celeb.uid}
                    type="button"
                    onClick={() => toggleFavoriteCelebrity(celeb)}
                    className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 hover:border-amber-400 text-slate-800 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-2xs"
                  >
                    <img src={celeb.avatarUrl} alt={celeb.name} className="w-5 h-5 rounded-full object-cover" />
                    <span>★ Favorite {celeb.name}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {favoriteCelebritiesForSection.map((celeb) => (
                <div 
                  key={celeb.uid}
                  className="p-4 rounded-3xl bg-amber-50/40 border border-amber-300 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between gap-3.5"
                >
                  {/* Top: Identity, Handle & Win Rate */}
                  <div className="space-y-2.5">
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={celeb.avatarUrl}
                          alt={celeb.name}
                          className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shadow-2xs shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-sm text-slate-900 truncate">{celeb.name}</span>
                            {celeb.verified && <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />}
                          </div>
                          <p className="text-xs font-mono text-slate-400 mt-0.5">@{celeb.handle}</p>
                        </div>
                      </div>

                      {/* Win Rate Badge */}
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 shrink-0">
                        {celeb.winRate} Win
                      </span>
                    </div>

                    {/* Title / Role */}
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed font-medium">
                      {celeb.title}
                    </p>

                    {/* Active Tickers */}
                    <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                      <span className="text-[11px] text-slate-400 font-mono font-medium">Active in:</span>
                      {celeb.activeTickers.map((tick) => (
                        <span key={tick} className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-lg bg-slate-100 text-slate-800 border border-slate-200/80">
                          ${tick}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Bottom Action Footer: Dedicated, Non-Overlapping Buttons */}
                  <div className="pt-3 border-t border-amber-200/60 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setViewingFilingCelebrity(celeb)}
                      className="flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer bg-slate-900 hover:bg-slate-800 text-white shadow-2xs active:scale-95 whitespace-nowrap"
                      title={`Open official filing details window for ${celeb.name}`}
                    >
                      <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>Official Filing</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleFavoriteCelebrity(celeb)}
                      className="py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer bg-amber-100 hover:bg-rose-100 text-amber-950 hover:text-rose-900 border border-amber-300 hover:border-rose-300 shrink-0 active:scale-95 shadow-2xs"
                      title="Click to remove from favorites"
                    >
                      <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      <span>Favorited</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ================= TRADES STREAM LIST (Shown under All, Friends, and Famous Personalities) ================= */}
      {traderFilter !== 'favorite_celebrities' && traderFilter !== 'favorite_friends' && (
        <div className="space-y-4">
          {filteredTrades.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 text-slate-400 flex items-center justify-center mx-auto shadow-2xs">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="font-serif font-bold text-slate-900 text-base">No Matching Social Trades</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No trades match your current filters in the {getSectionTitle(currentSection)} section.
              </p>
              <button
                type="button"
                onClick={() => {
                  setTraderFilter('friends');
                  setCategoryFilter('all');
                  setSideFilter('all');
                  setCelebritySearchQuery('');
                }}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-2xs"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredTrades.map((trade) => {
                const isBuy = trade.side === 'buy';
                const mBadge = getMarketBadge(trade.marketType);
                const isPersonal = (trade.assetCategory || (trade.ticker === 'ALEX' ? 'personal' : 'business')) === 'personal';
                const isWatchlisted = watchlist.includes(trade.ticker);
                const isFavCelebrity = favoriteCelebrityIds.includes(trade.user.uid);
                const isFavFriend = favoriteFriendIds.includes(trade.user.uid);
                const foundStock = stocks.find((s) => s.ticker === trade.ticker);
                const isCopied = copiedTradeId === trade.id;
                const isFinalMarket = trade.marketType === 'final';
                const isFamous = trade.traderType === 'famous';

                return (
                  <div
                    key={trade.id}
                    className={`p-5 sm:p-6 rounded-3xl bg-white border transition-all hover:shadow-md space-y-4 ${
                      trade.isRealTimeNew ? 'border-amber-400 ring-1 ring-amber-400/30' : 'border-slate-200 shadow-2xs'
                    }`}
                  >
                    {/* Header: Trader Profile + Timestamp + Equity Category + Market Way + Favorite Option */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                      <div className="flex items-center gap-3">
                        <div 
                          className="relative cursor-pointer group"
                          onClick={() => setViewingFilingCelebrity(trade.user)}
                          title={`View ${isFamous ? 'official filing' : 'past month trades'} for ${trade.user.name}`}
                        >
                          <img
                            src={trade.user.avatarUrl}
                            alt={trade.user.name}
                            className="w-11 h-11 rounded-2xl object-cover border border-slate-200 shadow-2xs group-hover:ring-2 group-hover:ring-amber-400 transition-all"
                          />
                          {trade.traderType === 'famous' ? (
                            <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-2xs text-[10px]" title="Famous Personality">
                              👑
                            </span>
                          ) : (
                            <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-2xs text-[10px]" title="Mutual Friend">
                              🤝
                            </span>
                          )}
                        </div>

                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 
                              onClick={() => setViewingFilingCelebrity(trade.user)}
                              className="font-bold text-sm text-slate-900 hover:text-amber-600 cursor-pointer transition-colors"
                              title={`View ${isFamous ? 'official filing' : 'past month trades'} for ${trade.user.name}`}
                            >
                              {trade.user.name}
                            </h3>
                            <span className="text-xs font-mono text-slate-400">
                              @{trade.user.handle}
                            </span>
                            {trade.user.verified && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                            )}
                            {trade.user.isFriend && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                                Friend ({trade.user.friendsCount} mutual)
                              </span>
                            )}
                            {trade.user.winRate && (
                              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                                {trade.user.winRate} Win
                              </span>
                            )}

                            {/* Official Filing & Favorite Celebrity Options on Card */}
                            {trade.traderType === 'famous' && (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <button
                                  type="button"
                                  onClick={() => setViewingFilingCelebrity(trade.user)}
                                  className="px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer bg-slate-900 hover:bg-slate-800 text-white shadow-2xs active:scale-95 whitespace-nowrap"
                                  title={`Open official filing details window for ${trade.user.name}`}
                                >
                                  <FileText className="w-3 h-3 text-amber-400" />
                                  <span>Official Filing</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => toggleFavoriteCelebrity(trade.user)}
                                  className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 ${
                                    isFavCelebrity
                                      ? 'bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs'
                                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 border border-slate-200'
                                  }`}
                                  title={isFavCelebrity ? `Favorited ${trade.user.name} - click to remove from favorites` : `Favorite ${trade.user.name}`}
                                >
                                  <Star className={`w-3 h-3 ${isFavCelebrity ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`} />
                                  <span>{isFavCelebrity ? 'Favorited' : 'Favorite'}</span>
                                </button>
                              </div>
                            )}

                            {/* Past Month Trades & Favorite Friend Options for Friends */}
                            {trade.traderType === 'friend' && (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <button
                                  type="button"
                                  onClick={() => setViewingFilingCelebrity(trade.user)}
                                  className="px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer bg-indigo-900 hover:bg-indigo-800 text-white shadow-2xs active:scale-95 whitespace-nowrap"
                                  title={`View trades in the past month for ${trade.user.name}`}
                                >
                                  <FileText className="w-3 h-3 text-indigo-300" />
                                  <span>Past Month Trades</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => toggleFavoriteFriend(trade.user)}
                                  className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 ${
                                    isFavFriend
                                      ? 'bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs'
                                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 border border-slate-200'
                                  }`}
                                  title={isFavFriend ? `Favorited ${trade.user.name} - click to remove from favorites` : `Favorite ${trade.user.name}`}
                                >
                                  <Star className={`w-3 h-3 ${isFavFriend ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`} />
                                  <span>{isFavFriend ? 'Favorited' : 'Favorite'}</span>
                                </button>
                              </div>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                            {trade.user.title}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 sm:self-center flex-wrap">
                        {/* Category Badge: Personal vs Business */}
                        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          isPersonal 
                            ? 'bg-purple-50 text-purple-800 border-purple-200' 
                            : 'bg-blue-50 text-blue-800 border-blue-200'
                        }`}>
                          {isPersonal ? <User className="w-2.5 h-2.5" /> : <Building className="w-2.5 h-2.5" />}
                          <span>{isPersonal ? 'Personal Stock' : 'Business Stock'}</span>
                        </span>

                        <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${mBadge.bg}`}>
                          {mBadge.label}
                        </span>

                        <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {trade.timestampAgo}
                        </span>
                      </div>
                    </div>

                    {/* Official Disclosure Banner for Famous Trades */}
                    {isFamous && (
                      <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="px-2 py-0.5 rounded-md bg-amber-200/80 font-mono font-bold text-[10px] uppercase text-amber-900 border border-amber-300">
                            {trade.disclosureType || 'STOCK Act PTR'}
                          </span>
                          <span className="font-mono text-slate-700 text-[11px]">
                            Execution: {trade.executionDate || trade.timestamp.slice(0, 10)} | Filed: {trade.filingDate || trade.timestamp.slice(0, 10)}
                          </span>
                          {trade.cikOrMemberId && (
                            <span className="text-[10px] font-mono text-slate-500">
                              &bull; {trade.cikOrMemberId}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setViewingFilingCelebrity(trade.user)}
                            className="text-[11px] font-bold text-amber-900 hover:text-amber-950 flex items-center gap-1 cursor-pointer underline"
                            title="Open stylized in-app official regulatory filing document"
                          >
                            <FileText className="w-3.5 h-3.5 text-amber-700" />
                            <span>Official Filing Document</span>
                          </button>

                          {trade.sourceDocumentUrl && (
                            <a
                              href={trade.sourceDocumentUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] font-bold text-amber-900 hover:text-amber-950 flex items-center gap-1 underline"
                            >
                              <span>Source .gov</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Trade Execution Box */}
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white shrink-0 shadow-2xs ${
                          isBuy ? 'bg-emerald-600' : 'bg-rose-600'
                        }`}>
                          {isBuy ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-xs font-bold uppercase px-2 py-0.5 rounded ${
                              isBuy ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {trade.side.toUpperCase()}
                            </span>
                            <span className="font-mono font-bold text-base text-slate-900">
                              {isFinalMarket ? '' : '$'}{trade.ticker}
                            </span>
                            <span className="text-xs text-slate-500 font-medium">
                              {trade.stockName}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 font-mono">
                            {trade.shares.toLocaleString()} shares @ {isFinalMarket ? '' : '$'}{isFinalMarket ? trade.priceUSD.toLocaleString() : trade.priceUSD.toFixed(2)} &bull; Settlement: {trade.settlementMethod}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-col items-center justify-center gap-3 py-2 w-full">
                        <div className="text-center">
                          <span className="text-[10px] text-slate-400 uppercase font-mono block">
                            Trade Valuation
                          </span>
                          <span className="font-mono font-bold text-lg text-slate-900">
                            {isFinalMarket ? '' : '$'}{trade.totalValueUSD.toLocaleString(undefined, isFinalMarket ? { minimumFractionDigits: 0, maximumFractionDigits: 0 } : { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        </div>

                        {/* Copy Trade is Trade Valuation */}
                        <button
                          type="button"
                          onClick={() => handleCopyTrade(trade)}
                          className={`px-8 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-2 cursor-pointer shadow-2xs whitespace-nowrap active:scale-95 ${
                            isCopied 
                              ? 'bg-emerald-600 text-white' 
                              : 'bg-slate-900 hover:bg-slate-800 text-white'
                          }`}
                          title={`Copy Trade Valuation (${isFinalMarket ? '' : '$'}${trade.totalValueUSD.toLocaleString()}) to clipboard & prepare order`}
                        >
                          {isCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-200" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-amber-400" />
                              <span>Copy Trade</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Trader Commentary & Rationale */}
                    <div className="p-3.5 rounded-2xl bg-amber-500/5 border border-amber-500/20 text-xs text-slate-700 leading-relaxed flex items-start gap-2.5">
                      <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-slate-600">{trade.commentary}</p>
                      </div>
                    </div>

                    {/* Card Footer Actions */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs">
                      <div className="flex items-center gap-2">
                        {onSelectStock && foundStock && (
                          <button
                            type="button"
                            onClick={() => onSelectStock(foundStock)}
                            className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Inspect {isFinalMarket ? '' : '$'}{trade.ticker} Fundamentals</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {trade.traderType === 'famous' && (
                          <button
                            type="button"
                            onClick={() => toggleFavoriteCelebrity(trade.user)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
                              isFavCelebrity 
                                ? 'bg-amber-50 border-amber-300 text-amber-900' 
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <Star className={`w-3.5 h-3.5 ${isFavCelebrity ? 'fill-amber-400 text-amber-500' : 'text-slate-400'}`} />
                            <span>{isFavCelebrity ? `Favorited (${trade.user.name.split(' ')[0]})` : `Favorite ${trade.user.name.split(' ')[0]}`}</span>
                          </button>
                        )}

                        {onToggleWatchlist && (
                          <button
                            type="button"
                            onClick={() => onToggleWatchlist(trade.ticker)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
                              isWatchlisted 
                                ? 'bg-amber-50 border-amber-300 text-amber-800' 
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <Star className={`w-3.5 h-3.5 ${isWatchlisted ? 'fill-amber-400 text-amber-400' : 'text-slate-400'}`} />
                            <span>{isWatchlisted ? 'Following Ticker' : `Follow $${trade.ticker}`}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
