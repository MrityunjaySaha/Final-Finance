export type VerifiedCardBrand = 'visa' | 'mastercard' | 'amex' | 'discover';

export interface CardValidationInput {
  cardholderName: string;
  email: string;
  phone?: string;
  cardNumber: string;
  expMonth: string;
  expYear: string;
  cvc: string;
  country: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
}

export interface BankValidationInput {
  accountHolderName: string;
  routingNumber: string;
  accountNumber: string;
  accountType?: string;
}

export function isValidLuhn(digits: string): boolean {
  if (!/^\d+$/.test(digits) || digits.length < 13 || digits.length > 19) {
    return false;
  }
  let sum = 0;
  let shouldDouble = false;
  for (let i = digits.length - 1; i >= 0; i -= 1) {
    let digit = Number(digits[i]);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return sum % 10 === 0;
}

export function isDummyOrSequentialDigits(digits: string): boolean {
  if (!digits) return true;
  // All identical digits (e.g. 000000, 111111, 44444444)
  if (/^(\d)\1+$/.test(digits)) return true;

  // Ascending or descending run across the entire number
  let asc = true;
  let desc = true;
  for (let i = 1; i < digits.length; i += 1) {
    const prev = Number(digits[i - 1]);
    const curr = Number(digits[i]);
    if ((prev + 1) % 10 !== curr) asc = false;
    if ((prev + 9) % 10 !== curr) desc = false;
  }
  if (asc || desc) return true;

  return false;
}

export function detectVerifiedCardBrand(digits: string): VerifiedCardBrand | null {
  if (/^4\d{12}(\d{3})?(\d{3})?$/.test(digits)) return 'visa';
  if (/^(5[1-5]\d{14}|2(22[1-9]|2[3-9]\d|[3-6]\d{2}|7[01]\d|720)\d{12})$/.test(digits)) {
    return 'mastercard';
  }
  if (/^3[47]\d{13}$/.test(digits)) return 'amex';
  if (/^(6011\d{12}|65\d{14}|64[4-9]\d{13})$/.test(digits)) return 'discover';
  return null;
}

export interface BillingValidationResult {
  valid: boolean;
  error?: string;
}

export interface CardValidationResult {
  valid: boolean;
  error?: string;
  brand?: VerifiedCardBrand;
  last4?: string;
  expMonth?: number;
  expYear?: number;
}

export interface RoutingValidationResult {
  valid: boolean;
  error?: string;
  routing?: string;
}

export interface BankValidationResult {
  valid: boolean;
  error?: string;
  routingNumber?: string;
  accountNumber?: string;
  last4?: string;
}

export function validateBillingDetailsInput(input: {
  fullName: string;
  email: string;
  phone?: string;
  country: string;
  addressLine1: string;
  city: string;
  state: string;
  postalCode: string;
}): BillingValidationResult {
  const name = input.fullName.trim();
  const nameParts = name.split(/\s+/).filter(Boolean);
  if (name.length < 4 || nameParts.length < 2 || !/^[a-zA-ZÀ-ÿ'.,\-\s]+$/.test(name)) {
    return { valid: false, error: 'Enter the cardholder\'s full legal name (first and last name).' };
  }

  const email = input.email.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    return { valid: false, error: 'Enter a valid billing email address.' };
  }

  if (input.phone && input.phone.trim()) {
    const phoneDigits = input.phone.replace(/\D/g, '');
    if (phoneDigits.length < 7 || phoneDigits.length > 15) {
      return { valid: false, error: 'Enter a valid phone number (7–15 digits) or leave it blank.' };
    }
  }

  const country = input.country.trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(country)) {
    return { valid: false, error: 'Select a valid billing country.' };
  }

  const line1 = input.addressLine1.trim();
  if (line1.length < 5) {
    return { valid: false, error: 'Enter a complete billing street address.' };
  }

  const city = input.city.trim();
  if (city.length < 2) {
    return { valid: false, error: 'Enter a valid billing city.' };
  }

  const state = input.state.trim();
  if (state.length < 2) {
    return { valid: false, error: 'Enter a valid state or province.' };
  }

  const postal = input.postalCode.trim();
  if (country === 'US' && !/^\d{5}(-\d{4})?$/.test(postal)) {
    return { valid: false, error: 'Enter a valid 5-digit US ZIP code (e.g. 10001).' };
  }
  if (country === 'CA' && !/^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/.test(postal)) {
    return { valid: false, error: 'Enter a valid Canadian postal code (e.g. M5V 2T6).' };
  }
  if (country !== 'US' && country !== 'CA' && postal.length < 3) {
    return { valid: false, error: 'Enter a valid postal/ZIP code.' };
  }

  return { valid: true };
}

export function validatePaymentCardInput(input: CardValidationInput): CardValidationResult {
  const billingCheck = validateBillingDetailsInput({
    fullName: input.cardholderName,
    email: input.email,
    phone: input.phone,
    country: input.country,
    addressLine1: input.addressLine1,
    city: input.city,
    state: input.state,
    postalCode: input.postalCode,
  });
  if (!billingCheck.valid) {
    return { valid: false, error: billingCheck.error };
  }

  const digits = input.cardNumber.replace(/\D/g, '');
  if (digits.length < 13 || digits.length > 19) {
    return { valid: false, error: 'Enter a valid debit or credit card number.' };
  }

  if (isDummyOrSequentialDigits(digits)) {
    return { valid: false, error: 'This card number is invalid and cannot be verified.' };
  }

  const brand = detectVerifiedCardBrand(digits);
  if (!brand) {
    return {
      valid: false,
      error: 'Card number does not match a valid Visa, Mastercard, American Express, or Discover card.',
    };
  }

  if (!isValidLuhn(digits)) {
    return {
      valid: false,
      error: 'Invalid card number (failed card checksum). Please double-check every digit.',
    };
  }

  const monthNum = Number(input.expMonth.replace(/\D/g, ''));
  const rawYearDigits = input.expYear.replace(/\D/g, '');
  if (!Number.isInteger(monthNum) || monthNum < 1 || monthNum > 12) {
    return { valid: false, error: 'Enter a valid expiration month (01–12).' };
  }
  if (rawYearDigits.length !== 2 && rawYearDigits.length !== 4) {
    return { valid: false, error: 'Enter a valid expiration year (MM/YY).' };
  }
  const fullYear = rawYearDigits.length === 2 ? Number(`20${rawYearDigits}`) : Number(rawYearDigits);
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  if (fullYear < currentYear || (fullYear === currentYear && monthNum < currentMonth)) {
    return { valid: false, error: 'This card is expired. Please use a valid active card.' };
  }
  if (fullYear > currentYear + 20) {
    return { valid: false, error: 'Expiration year is invalid.' };
  }

  const cvcDigits = input.cvc.replace(/\D/g, '');
  const expectedCvcLen = brand === 'amex' ? 4 : 3;
  if (cvcDigits.length !== expectedCvcLen) {
    return {
      valid: false,
      error:
        brand === 'amex'
          ? 'American Express cards require a 4-digit security code (CID).'
          : 'Enter the 3-digit security code (CVC/CVV) from your card.',
    };
  }

  return {
    valid: true,
    brand,
    last4: digits.slice(-4),
    expMonth: monthNum,
    expYear: fullYear,
  };
}

export function validateUsRoutingNumber(rawRouting: string): RoutingValidationResult {
  const routing = rawRouting.replace(/\D/g, '');
  if (!/^\d{9}$/.test(routing)) {
    return { valid: false, error: 'Routing number must be exactly 9 digits.' };
  }
  if (/^0+$/.test(routing) || isDummyOrSequentialDigits(routing)) {
    return { valid: false, error: 'This routing number is not a real bank routing number.' };
  }

  // Federal Reserve routing symbol prefixes: 01-12, 21-32, 61-72, 80
  const prefix = Number(routing.slice(0, 2));
  const validPrefix =
    (prefix >= 1 && prefix <= 12) ||
    (prefix >= 21 && prefix <= 32) ||
    (prefix >= 61 && prefix <= 72) ||
    prefix === 80;
  if (!validPrefix) {
    return { valid: false, error: 'Invalid Federal Reserve bank routing prefix.' };
  }

  const d = routing.split('').map(Number);
  const checksum =
    3 * (d[0] + d[3] + d[6]) +
    7 * (d[1] + d[4] + d[7]) +
    (d[2] + d[5] + d[8]);
  if (checksum % 10 !== 0) {
    return {
      valid: false,
      error: 'Invalid bank routing number (failed ABA bank routing checksum).',
    };
  }

  return { valid: true, routing };
}

export function validateUsBankAccountInput(input: BankValidationInput): BankValidationResult {
  const holder = input.accountHolderName.trim();
  const holderParts = holder.split(/\s+/).filter(Boolean);
  if (holder.length < 4 || holderParts.length < 2) {
    return { valid: false, error: 'Enter the account holder\'s full legal name (first and last name).' };
  }

  const routingCheck = validateUsRoutingNumber(input.routingNumber);
  if (!routingCheck.valid || !routingCheck.routing) {
    return { valid: false, error: routingCheck.error };
  }

  const accountNumber = input.accountNumber.replace(/\D/g, '');
  if (!/^\d{6,17}$/.test(accountNumber)) {
    return { valid: false, error: 'Bank account number must be 6 to 17 digits.' };
  }
  if (isDummyOrSequentialDigits(accountNumber)) {
    return {
      valid: false,
      error: 'This bank account number appears invalid and cannot be verified.',
    };
  }

  return {
    valid: true,
    routingNumber: routingCheck.routing,
    accountNumber,
    last4: accountNumber.slice(-4),
  };
}
