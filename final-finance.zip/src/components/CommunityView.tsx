import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AssetClass, CommunityPost } from '../types';
import { 
  Heart, 
  MessageSquare, 
  Share2, 
  Sparkles, 
  CheckCircle2, 
  Send, 
  Image as ImageIcon, 
  TrendingUp, 
  UserPlus, 
  Users, 
  ShieldCheck,
  Tag
} from 'lucide-react';
import { areUsersBlockedEitherWay } from '../services/socialService';

export const CommunityView: React.FC = () => {
  const { 
    posts, 
    currentUser, 
    createPost, 
    toggleLikePost, 
    addCommentToPost, 
    toggleFollowUser,
    setCurrentTab,
    setStagedAssetForDraft,
    imageHistory 
  } = useApp();

  const [postContent, setPostContent] = useState('');
  const [selectedImageAttachment, setSelectedImageAttachment] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [activeCommentsPostId, setActiveCommentsPostId] = useState<string | null>(null);

  const handlePublishPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postContent.trim() && !selectedImageAttachment) return;

    createPost(
      postContent, 
      selectedImageAttachment || undefined,
      selectedImageAttachment ? { model: 'gemini-3-pro-image-preview', resolution: '4K', prompt: postContent } : undefined
    );
    setPostContent('');
    setSelectedImageAttachment(null);
  };

  const handleCommentSubmit = (postId: string) => {
    const text = commentInputs[postId];
    if (!text || !text.trim()) return;
    addCommentToPost(postId, text);
    setCommentInputs(prev => ({ ...prev, [postId]: '' }));
  };

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 pb-20">
      {/* Main Social Feed Column (8 cols) */}
      <div className="space-y-6 lg:col-span-8">
        
        {/* Create Post Broadcast Box */}
        <div className="rounded-2xl border border-neutral-800 bg-[#0b0e14] p-5 shadow-xl space-y-4">
          <div className="flex items-start gap-3">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="h-10 w-10 rounded-full object-cover border border-amber-500/30 shrink-0"
            />
            <div className="flex-1 space-y-3">
              <textarea
                rows={3}
                value={postContent}
                onChange={(e) => setPostContent(e.target.value)}
                placeholder="Broadcast sovereign allocations, barter proposals, or AI asset prototypes..."
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900/80 p-3 text-xs text-white placeholder-neutral-500 focus:border-amber-500/60 focus:outline-none leading-relaxed"
              />

              {/* Attached Image Preview */}
              {selectedImageAttachment && (
                <div className="relative h-44 w-full rounded-xl border border-neutral-800 bg-black overflow-hidden group">
                  <img src={selectedImageAttachment} alt="Attachment" className="h-full w-full object-cover" />
                  <button
                    onClick={() => setSelectedImageAttachment(null)}
                    className="absolute top-2 right-2 rounded-full bg-black/80 p-1 text-xs text-white hover:bg-rose-600 transition-colors"
                  >
                    ✕
                  </button>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-neutral-800/60">
                <div className="flex items-center gap-2">
                  {/* Select from AI Studio History */}
                  {imageHistory.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedImageAttachment(imageHistory[0].imageUrl)}
                      className="flex items-center gap-1.5 rounded-lg border border-neutral-800 bg-neutral-900 px-2.5 py-1.5 text-xs text-neutral-300 hover:border-amber-500/40 hover:text-white transition-colors"
                    >
                      <Sparkles className="h-3.5 w-3.5 text-amber-400" />
                      <span>Attach Recent AI Render</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setCurrentTab('ai_studio')}
                    className="text-xs text-amber-400 hover:underline flex items-center gap-1"
                  >
                    <span>Open AI Studio</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handlePublishPost}
                  disabled={!postContent.trim() && !selectedImageAttachment}
                  className="flex items-center gap-1.5 rounded-xl border border-amber-500/50 bg-gradient-to-r from-amber-500 to-amber-600 px-4 py-2 text-xs font-bold text-black hover:opacity-95 transition-opacity disabled:opacity-50"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>Broadcast Post</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Feed Posts */}
        <div className="space-y-5">
          {posts
            .filter((post) => {
              const currentViewerUid = currentUser ? (currentUser.id?.startsWith('user-') ? currentUser.id : `user-${currentUser.id}`) : '';
              const authorUid = post.authorHandle?.startsWith('user-') ? post.authorHandle : `user-${post.authorHandle?.replace(/^@/, '')}`;
              const authorCleanHandle = post.authorHandle?.replace(/^@/, '');
              const viewerCleanHandle = currentUser.handle?.replace(/^@/, '');

              if (currentViewerUid && (
                areUsersBlockedEitherWay(currentViewerUid, authorUid) ||
                areUsersBlockedEitherWay(currentUser.id, post.authorHandle) ||
                areUsersBlockedEitherWay(viewerCleanHandle, authorCleanHandle)
              )) {
                return false;
              }
              return true;
            })
            .map((post) => (
            <div
              key={post.id}
              className="rounded-2xl border border-neutral-800 bg-[#0b0e14] p-5 shadow-lg space-y-4 transition-all hover:border-neutral-700/80"
            >
              {/* Post Author Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={post.authorAvatar}
                    alt={post.authorName}
                    className="h-10 w-10 rounded-full object-cover border border-amber-500/40"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-serif text-sm font-bold text-white">{post.authorName}</h4>
                      {post.authorVerified && <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />}
                      <span className="rounded bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.2 text-[9px] font-mono text-amber-300 font-semibold">
                        {post.authorTier}
                      </span>
                    </div>
                    <p className="text-[11px] font-mono text-neutral-400">{post.authorHandle} • {post.createdAt}</p>
                  </div>
                </div>

                {post.authorHandle !== currentUser.handle && (
                  <button
                    onClick={() => toggleFollowUser(post.authorHandle)}
                    className="flex items-center gap-1 rounded-lg border border-neutral-800 bg-neutral-900/80 px-2.5 py-1 text-xs text-neutral-300 hover:border-amber-500/40 hover:text-amber-300 transition-colors"
                  >
                    <UserPlus className="h-3 w-3" />
                    <span>Follow</span>
                  </button>
                )}
              </div>

              {/* Content Body */}
              <p className="text-xs text-neutral-200 leading-relaxed whitespace-pre-line">
                {post.content}
              </p>

              {/* Attached Asset Tag Badge */}
              {post.assetTag && (
                <div className="inline-flex items-center gap-2 rounded-lg border border-amber-500/20 bg-amber-500/5 px-3 py-1.5 text-xs text-amber-300 font-mono">
                  <Tag className="h-3.5 w-3.5 text-amber-400" />
                  <span>{post.assetTag.name}</span>
                  <span className="text-neutral-400">•</span>
                  <span>${post.assetTag.valuation.toLocaleString()} USD</span>
                </div>
              )}

              {/* Image Asset Attachment */}
              {post.imageUrl && (
                <div className="relative overflow-hidden rounded-xl border border-neutral-800 bg-neutral-950 max-h-96">
                  <img
                    src={post.imageUrl}
                    alt="Post Asset"
                    className="w-full h-full object-cover hover:scale-101 transition-transform duration-300"
                  />
                  {post.imageMeta && (
                    <div className="absolute bottom-2 left-2 flex gap-1">
                      <span className="rounded bg-black/80 px-2 py-0.5 text-[9px] font-mono font-bold text-amber-300 border border-neutral-800">
                        {post.imageMeta.model}
                      </span>
                      <span className="rounded bg-black/80 px-2 py-0.5 text-[9px] font-mono text-neutral-300 border border-neutral-800">
                        {post.imageMeta.resolution}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Interaction Bar */}
              <div className="flex items-center justify-between border-t border-neutral-800/80 pt-3 text-xs text-neutral-400">
                <button
                  onClick={() => toggleLikePost(post.id)}
                  className={`flex items-center gap-1.5 transition-colors ${
                    post.isLiked ? 'text-rose-400 font-semibold' : 'hover:text-white'
                  }`}
                >
                  <Heart className={`h-4 w-4 ${post.isLiked ? 'fill-current' : ''}`} />
                  <span>{post.likes}</span>
                </button>

                <button
                  onClick={() => setActiveCommentsPostId(activeCommentsPostId === post.id ? null : post.id)}
                  className="flex items-center gap-1.5 hover:text-white transition-colors"
                >
                  <MessageSquare className="h-4 w-4 text-neutral-400" />
                  <span>{post.commentsCount || 0} Comments</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <Share2 className="h-4 w-4 text-neutral-400" />
                  <span>{post.shares || 0} Shares</span>
                </div>
              </div>

              {/* Expandable Comments Section */}
              {activeCommentsPostId === post.id && (
                <div className="border-t border-neutral-800/80 pt-3 space-y-3 animate-in fade-in duration-100">
                  <div className="space-y-2">
                    {post.comments && post.comments.length > 0 ? (
                      post.comments.map((c) => (
                        <div key={c.id} className="flex items-start gap-2.5 rounded-lg bg-neutral-900/60 p-2.5 text-xs">
                          <img src={c.authorAvatar} alt={c.authorName} className="h-6 w-6 rounded-full object-cover mt-0.5" />
                          <div className="flex-1">
                            <div className="flex items-baseline justify-between">
                              <span className="font-semibold text-white">{c.authorName}</span>
                              <span className="text-[10px] text-neutral-500 font-mono">{c.createdAt}</span>
                            </div>
                            <p className="text-neutral-300 mt-0.5">{c.content}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-[11px] text-neutral-500 py-2">No comments yet. Start the discussion!</p>
                    )}
                  </div>

                  {/* Add Comment Input */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Write a comment or OTC inquiry..."
                      value={commentInputs[post.id] || ''}
                      onChange={(e) => setCommentInputs(prev => ({ ...prev, [post.id]: e.target.value }))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleCommentSubmit(post.id);
                      }}
                      className="flex-1 rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500/50 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => handleCommentSubmit(post.id)}
                      className="rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-black hover:bg-amber-400 transition-colors"
                    >
                      Reply
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Sidebar Column (4 cols) */}
      <div className="space-y-6 lg:col-span-4">
        
        {/* User Profile Mini Summary Card */}
        <div className="rounded-2xl border border-neutral-800 bg-[#0b0e14] p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="h-12 w-12 rounded-full object-cover border-2 border-amber-500/40"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-serif text-sm font-bold text-white">{currentUser.name}</h3>
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
              </div>
              <p className="text-[11px] font-mono text-neutral-400">{currentUser.handle}</p>
              <span className="inline-block mt-1 rounded bg-amber-500/20 px-2 py-0.5 text-[9px] font-mono font-bold text-amber-300 border border-amber-500/30">
                {currentUser.tier} Sovereign Member
              </span>
            </div>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed">
            {currentUser.bio}
          </p>

          <div className="grid grid-cols-2 gap-2 border-t border-neutral-800/80 pt-3 text-center">
            <div className="rounded-lg bg-neutral-900/80 p-2">
              <span className="text-[10px] text-neutral-400 font-mono uppercase">Followers</span>
              <p className="font-mono text-sm font-bold text-white mt-0.5">{currentUser.followersCount}</p>
            </div>
            <div className="rounded-lg bg-neutral-900/80 p-2">
              <span className="text-[10px] text-neutral-400 font-mono uppercase">Following</span>
              <p className="font-mono text-sm font-bold text-white mt-0.5">{currentUser.followingCount}</p>
            </div>
          </div>
        </div>

        {/* Trending Sovereign Topics */}
        <div className="rounded-2xl border border-neutral-800 bg-[#0b0e14] p-5 shadow-xl space-y-3">
          <h3 className="font-serif text-sm font-bold text-white flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-amber-400" />
            <span>Trending Reserve Topics</span>
          </h3>

          <div className="space-y-2.5 pt-1 text-xs">
            <div className="rounded-lg bg-neutral-900/60 p-2.5 border border-neutral-800/80">
              <p className="font-mono text-amber-300 font-semibold">#ZurichGoldAudit</p>
              <p className="text-[11px] text-neutral-400 mt-0.5">620 allocated bars certified in Vault 1 (BGS-01).</p>
            </div>
            <div className="rounded-lg bg-neutral-900/60 p-2.5 border border-neutral-800/80">
              <p className="font-mono text-amber-300 font-semibold">#ProImage4KMint</p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Over 1,200 4K asset drafts generated this week.</p>
            </div>
            <div className="rounded-lg bg-neutral-900/60 p-2.5 border border-neutral-800/80">
              <p className="font-mono text-amber-300 font-semibold">#FinalCoinsBurn</p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Algorithmic burn mechanic triggered at $285M NAV.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
