import React, { useState } from 'react';
import { useApp, DeviceMode } from '../../context/AppContext';
import { Monitor, Smartphone, Apple, Tablet, Download, Check, Sparkles, X, Share } from 'lucide-react';

export const DeviceModeSelector: React.FC = () => {
  const { deviceMode, setDeviceMode } = useApp();
  const [showInstallModal, setShowInstallModal] = useState(false);

  return (
    <>
      <div className="flex items-center gap-1 bg-slate-900/90 text-slate-200 p-1 rounded-2xl border border-amber-500/30 shadow-lg backdrop-blur-md">
        <button
          onClick={() => setDeviceMode('web')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            deviceMode === 'web'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
          title="Desktop Web Mode"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Desktop</span>
        </button>

        <button
          onClick={() => setDeviceMode('ios')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            deviceMode === 'ios'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
          title="Native iOS iPhone View"
        >
          <Apple className="w-3.5 h-3.5" />
          <span>iOS</span>
        </button>

        <button
          onClick={() => setDeviceMode('android')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            deviceMode === 'android'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
          title="Native Android Pixel View"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Android</span>
        </button>

        <button
          onClick={() => setDeviceMode('tablet')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            deviceMode === 'tablet'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
          title="Tablet iPad View"
        >
          <Tablet className="w-3.5 h-3.5" />
          <span>Tablet</span>
        </button>

        <button
          onClick={() => setShowInstallModal(true)}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium text-amber-400 hover:bg-amber-500/10 transition-colors ml-0.5 cursor-pointer"
          title="Install Native App"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Install App</span>
        </button>
      </div>

      {/* PWA / Native App Install Modal */}
      {showInstallModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl relative space-y-5">
            <button
              onClick={() => setShowInstallModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-linear-to-tr from-amber-500 to-amber-300 text-slate-950 flex items-center justify-center font-serif font-black text-xl shadow-lg">
                FF
              </div>
              <div>
                <h3 className="text-lg font-bold font-serif text-white">Final Finance Mobile App</h3>
                <p className="text-xs text-amber-400 font-mono">Native iOS &amp; Android Progressive Experience</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-white">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Real Native Mobile Features Built-In:</span>
              </div>
              <ul className="text-xs text-slate-300 space-y-2 pl-2">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong>Native Device Frame Simulation</strong>: Switch instantly between iOS iPhone 16 Pro and Android Pixel 9 views.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong>Full Screen PWA Installation</strong>: Add to your mobile home screen to run as a standalone app without browser chrome.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong>Native Touch &amp; Haptics</strong>: Mobile-first bottom bar, pull-to-refresh, and quick gesture-friendly desk controls.</span>
                </li>
              </ul>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs text-white">
                  <Apple className="w-4 h-4 text-slate-300" />
                  <span>iOS (iPhone &amp; iPad)</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Open in <strong>Safari</strong> on iOS, tap the <Share className="w-3 h-3 inline text-amber-400" /> <strong>Share</strong> button, then select <strong>"Add to Home Screen"</strong>.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs text-white">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span>Android (Chrome &amp; Edge)</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Open in <strong>Chrome</strong> on Android, tap the <strong>3 dots menu</strong>, and select <strong>"Install App"</strong> or <strong>"Add to Home Screen"</strong>.
                </p>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setShowInstallModal(false)}
                className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors shadow-lg cursor-pointer"
              >
                Got It • Continue Testing
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
