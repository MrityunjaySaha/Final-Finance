import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertCircle,
  ArrowRightLeft,
  Award,
  Banknote,
  Binary,
  Briefcase,
  Check,
  CheckCircle2,
  Clock,
  Coins,
  Gavel,
  History,
  Lock,
  Package,
  Repeat,
  ShieldCheck,
  Sparkles,
  Trophy,
  X,
  Zap,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { AuctionBid, SettlementMethod } from '../types/marketplace';
import { UserWalletData } from '../types/wallet';
import { AssetClass } from '../types';
import { getStoredUserWallets } from '../data/defaultWallets';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from './common/ConfirmModal';
import { formatInsufficientCurrencyError } from '../utils/transactionFees';
import { checkRestrictedMarketplaceItem } from '../data/restrictedItemsPolicy';
import {
  getAllMarketplaceListings,
  getAuctionBids,
  getAuctionRemainingLabel,
  getCurrentAuctionPriceUSD,
  getMinimumNextBidUSD,
} from '../services/marketplaceService';
import {
  CURRENCY_TYPE_META,
  CurrencyTypeId,
  SettlementCoinOption,
  SettlementModeId,
  TargetListingForTrade,
  acceptAuctionBid,
  buyNowAuctionListing,
  getAllowedSettlementModes,
  getCurrencyOptionsForType,
  placeAuctionBid,
} from '../services/marketplaceSettlementService';

interface AuctionBidModalProps {
  isOpen: boolean;
  currentUser?: AuthSession | null;
  targetListing?: TargetListingForTrade | null;
  onClose: () => void;
  onAuctionUpdated?: () => void;
}

const ALL_FIVE_MODES: SettlementModeId[] = [
  'final_coins',
  'stable_coins',
  'fiat',
  'crypto',
  'barter',
];

const CURRENCY_TYPES_ORDER: CurrencyTypeId[] = [
  'final_coins',
  'stable_coins',
  'fiat',
  'crypto',
];

const MODE_LABELS: Record<SettlementModeId, string> = {
  final_coins: 'Final Coins',
  stable_coins: 'Stablecoins',
  fiat: 'Fiat Currency',
  crypto: 'Cryptocurrency',
  barter: 'Direct Barter',
};

export const AuctionBidModal: React.FC<AuctionBidModalProps> = ({
  isOpen,
  currentUser,
  targetListing,
  onClose,
  onAuctionUpdated,
}) => {
  const { addToast, addNotification, setListings, setCurrentUser, addTransaction } = useApp();
  const activeUserId = currentUser?.id || 'guest';

  // Keep a live snapshot of targetListing synced from marketplaceService
  const [liveListing, setLiveListing] = useState<TargetListingForTrade | null>(targetListing || null);
  const [bids, setBids] = useState<AuctionBid[]>([]);
  const [userWallets, setUserWallets] = useState<UserWalletData>(() =>
    getStoredUserWallets(activeUserId)
  );
  const [nowTick, setNowTick] = useState<number>(() => Date.now());

  const refreshAuctionState = () => {
    if (!targetListing?.id) return;
    const svcMatch = getAllMarketplaceListings().find((l) => l.id === targetListing.id);
    if (svcMatch) {
      setLiveListing((prev) => ({
        ...(prev || targetListing),
        ...svcMatch,
        priceUSD:
          svcMatch.auctionConfig?.highestBidUSD ??
          svcMatch.primaryPriceUSD ??
          prev?.priceUSD ??
          targetListing.priceUSD,
        estimatedValueUSD:
          svcMatch.auctionConfig?.highestBidUSD ??
          svcMatch.primaryPriceUSD ??
          prev?.estimatedValueUSD ??
          targetListing.estimatedValueUSD,
        auctionConfig: svcMatch.auctionConfig || prev?.auctionConfig || targetListing.auctionConfig,
        status: svcMatch.status === 'sold' ? 'sold' : svcMatch.status,
      }));
    } else {
      setLiveListing(targetListing);
    }
    setBids(getAuctionBids(targetListing.id));
    setUserWallets(getStoredUserWallets(activeUserId));
  };

  useEffect(() => {
    if (!isOpen) return;
    setLiveListing(targetListing || null);
    refreshAuctionState();
  }, [isOpen, targetListing?.id, activeUserId]);

  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  const effectiveListing = liveListing || targetListing || null;

  const isOwner = useMemo(() => {
    if (!currentUser || !effectiveListing) return false;
    const userClean = (currentUser.id || '').replace(/^user-/, '').replace(/^@/, '').toLowerCase();
    const uidClean = (currentUser.uid || '').replace(/^user-/, '').replace(/^@/, '').toLowerCase();
    const sellerClean = (effectiveListing.sellerId || '').replace(/^user-/, '').replace(/^@/, '').toLowerCase();
    const handleClean = (effectiveListing.sellerHandle || '').replace(/^@/, '').toLowerCase();
    return Boolean(
      (userClean && (userClean === sellerClean || userClean === handleClean)) ||
      (uidClean && (uidClean === sellerClean || uidClean === handleClean))
    );
  }, [currentUser, effectiveListing]);

  const allowedModes = useMemo(
    () => getAllowedSettlementModes(effectiveListing),
    [effectiveListing]
  );

  const auctionCfg = effectiveListing?.auctionConfig;
  const currentPriceUSD = getCurrentAuctionPriceUSD(effectiveListing as any);
  const minIncrementUSD = Number(auctionCfg?.minIncrementUSD || 100);
  const minNextBidUSD = getMinimumNextBidUSD(effectiveListing as any);
  const reservePriceUSD = Number(auctionCfg?.reservePriceUSD || 0);
  const buyNowPriceUSD = Number(auctionCfg?.buyNowPriceUSD || 0);
  const hasHighestBid = Boolean(auctionCfg?.highestBidUSD && auctionCfg.highestBidUSD > 0);
  const reserveMet = reservePriceUSD <= 0 || (hasHighestBid && currentPriceUSD >= reservePriceUSD);

  const countdown = useMemo(() => {
    void nowTick;
    return getAuctionRemainingLabel(auctionCfg?.endTimeIso);
  }, [auctionCfg?.endTimeIso, nowTick]);

  const isSettled = effectiveListing?.status === 'sold' || auctionCfg?.status === 'settled';
  const isEnded = isSettled || auctionCfg?.status === 'ended' || countdown.isEnded;

  const [activeTab, setActiveTab] = useState<'place_bid' | 'bids'>('place_bid');
  const [selectedMode, setSelectedMode] = useState<SettlementModeId>('final_coins');
  const [bidAmountUSD, setBidAmountUSD] = useState<number>(minNextBidUSD || 1000);
  const [selectedCoinSymbol, setSelectedCoinSymbol] = useState<string>('');

  // Barter bid (#5) state
  const [offeringType, setOfferingType] = useState<'inventory' | 'custom'>('inventory');
  const [inventoryKind, setInventoryKind] = useState<'good' | 'service'>('good');
  const [selectedGoodId, setSelectedGoodId] = useState<string>(userWallets.barterGoods[0]?.id || '');
  const [selectedServiceId, setSelectedServiceId] = useState<string>(userWallets.barterServices[0]?.id || '');
  const [offeredUnits, setOfferedUnits] = useState<number>(1);
  const [customOfferText, setCustomOfferText] = useState<string>('');
  const [includeSweetener, setIncludeSweetener] = useState<boolean>(false);
  const [sweetenerCurrencyType, setSweetenerCurrencyType] = useState<CurrencyTypeId>('final_coins');
  const [sweetenerCoinSymbol, setSweetenerCoinSymbol] = useState<string>('AFNL');
  const [sweetenerAmountUSD, setSweetenerAmountUSD] = useState<number>(250);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<
    | null
    | { type: 'bid' }
    | { type: 'buy_now' }
    | { type: 'accept_bid'; bid: AuctionBid }
  >(null);

  useEffect(() => {
    if (!isOpen || !effectiveListing) return;
    setErrorMsg(null);
    setConfirmAction(null);
    setBidAmountUSD(getMinimumNextBidUSD(effectiveListing as any));
    if (isOwner || isEnded) {
      setActiveTab('bids');
    } else {
      setActiveTab('place_bid');
    }
    const firstAllowed = allowedModes[0] || 'final_coins';
    setSelectedMode(firstAllowed);
    const freshWallets = getStoredUserWallets(activeUserId);
    setUserWallets(freshWallets);
    setSelectedGoodId(freshWallets.barterGoods[0]?.id || '');
    setSelectedServiceId(freshWallets.barterServices[0]?.id || '');
    setOfferedUnits(1);
    setCustomOfferText('');
    setIncludeSweetener(false);
  }, [isOpen, targetListing?.id]);

  // Auto-calculate estimated USD valuation if user selects an inventory barter item
  const selectedGood = userWallets.barterGoods.find((g) => g.id === selectedGoodId);
  const selectedService = userWallets.barterServices.find((s) => s.id === selectedServiceId);

  const inventoryEstimatedUSD = useMemo(() => {
    if (selectedMode !== 'barter' || offeringType !== 'inventory') return 0;
    const base =
      inventoryKind === 'good'
        ? (selectedGood?.estimatedUnitValue || 0) * Math.max(1, offeredUnits)
        : (selectedService?.hourlyRateValue || 0) * Math.max(1, offeredUnits);
    return base + (includeSweetener ? Math.max(0, sweetenerAmountUSD || 0) : 0);
  }, [
    selectedMode,
    offeringType,
    inventoryKind,
    selectedGood,
    selectedService,
    offeredUnits,
    includeSweetener,
    sweetenerAmountUSD,
  ]);

  const coinOptions = useMemo<SettlementCoinOption[]>(() => {
    if (!effectiveListing || selectedMode === 'barter') return [];
    const targetVal = Math.max(1, Number(bidAmountUSD) || minNextBidUSD);
    return getCurrencyOptionsForType(activeUserId, effectiveListing, selectedMode, targetVal);
  }, [activeUserId, effectiveListing, selectedMode, bidAmountUSD, minNextBidUSD, userWallets]);

  useEffect(() => {
    if (coinOptions.length === 0) {
      setSelectedCoinSymbol('');
      return;
    }
    if (!coinOptions.some((c) => c.symbol === selectedCoinSymbol)) {
      const preferred =
        coinOptions.find((c) => c.isSellerPreferred && c.hasSufficientBalance) ||
        coinOptions.find((c) => c.hasSufficientBalance) ||
        coinOptions[0];
      setSelectedCoinSymbol(preferred.symbol);
    }
  }, [coinOptions, selectedCoinSymbol]);

  const activeCoinOption = useMemo(
    () => coinOptions.find((c) => c.symbol === selectedCoinSymbol) || coinOptions[0] || null,
    [coinOptions, selectedCoinSymbol]
  );

  const sweetenerCoinOptions = useMemo<SettlementCoinOption[]>(() => {
    return getCurrencyOptionsForType(
      activeUserId,
      effectiveListing,
      sweetenerCurrencyType,
      Math.max(1, sweetenerAmountUSD || 0)
    );
  }, [activeUserId, effectiveListing, sweetenerCurrencyType, sweetenerAmountUSD, userWallets]);

  useEffect(() => {
    if (sweetenerCoinOptions.length === 0) return;
    if (!sweetenerCoinOptions.some((c) => c.symbol === sweetenerCoinSymbol)) {
      const funded = sweetenerCoinOptions.find((c) => c.hasSufficientBalance) || sweetenerCoinOptions[0];
      setSweetenerCoinSymbol(funded.symbol);
    }
  }, [sweetenerCoinOptions, sweetenerCoinSymbol]);

  const activeSweetenerCoin = useMemo(
    () => sweetenerCoinOptions.find((c) => c.symbol === sweetenerCoinSymbol) || sweetenerCoinOptions[0] || null,
    [sweetenerCoinOptions, sweetenerCoinSymbol]
  );

  if (!isOpen || !effectiveListing) return null;

  const sortedBids = [...bids].sort((a, b) => {
    if (a.status === 'accepted') return -1;
    if (b.status === 'accepted') return 1;
    return b.amountUSD - a.amountUSD;
  });

  const buildBarterDescription = (): string => {
    if (offeringType === 'inventory') {
      if (inventoryKind === 'good' && selectedGood) {
        return `${offeredUnits}x ${selectedGood.name} (${selectedGood.condition})`;
      }
      if (inventoryKind === 'service' && selectedService) {
        return `${offeredUnits} ${selectedService.unitType} of ${selectedService.name}`;
      }
    }
    return customOfferText.trim();
  };

  const syncContextAfterSettlement = (
    dealType: 'currency' | 'barter',
    amountUSD: number,
    vaultKey: AssetClass,
    ledgerItem: any,
    winningBidderId?: string
  ) => {
    setListings((prev) =>
      prev.map((item) =>
        item.id === effectiveListing.id
          ? {
              ...item,
              status: 'sold',
              priceUSD: amountUSD,
              auctionConfig: item.auctionConfig
                ? { ...item.auctionConfig, highestBidUSD: amountUSD, status: 'settled' }
                : undefined,
            }
          : item
      )
    );

    const isBuyerCurrentUser =
      !winningBidderId || winningBidderId === activeUserId || winningBidderId === currentUser?.uid;

    if (isBuyerCurrentUser && dealType === 'currency') {
      setCurrentUser((prev) => {
        const nextHoldings = { ...prev.holdings };
        nextHoldings[vaultKey] = Math.max(0, (nextHoldings[vaultKey] || 0) - amountUSD);
        const cat = (effectiveListing.category || 'barter') as AssetClass;
        if (cat in nextHoldings) {
          nextHoldings[cat] = (nextHoldings[cat] || 0) + amountUSD;
        } else {
          nextHoldings.barter = (nextHoldings.barter || 0) + amountUSD;
        }
        return { ...prev, holdings: nextHoldings };
      });
    }

    if (ledgerItem) {
      addTransaction({
        ...(ledgerItem as any),
        taxYear: ledgerItem.taxYear || new Date().getFullYear(),
        type: ledgerItem.type,
        category: ledgerItem.category,
        mode: ledgerItem.mode,
        title: ledgerItem.title,
        description: ledgerItem.description,
        amountUSD: ledgerItem.amountUSD,
        feeUSD: ledgerItem.feeUSD || 0,
        netAmountUSD: ledgerItem.netAmountUSD,
        sourceOrDestination: ledgerItem.sourceOrDestination,
        counterpartyOrIssuer: ledgerItem.counterpartyOrIssuer,
        issuerHandle: ledgerItem.issuerHandle,
        status: 'Settled',
        clearingNode: ledgerItem.clearingNode,
        taxClassification: ledgerItem.taxClassification,
      });
    }
  };

  const validateBidBeforeConfirm = (targetUSD: number): boolean => {
    setErrorMsg(null);
    if (!currentUser || activeUserId === 'guest') {
      setErrorMsg('Please sign in first to participate in this auction.');
      return false;
    }
    if (!allowedModes.includes(selectedMode)) {
      setErrorMsg(`${MODE_LABELS[selectedMode]} is not enabled on this auction.`);
      return false;
    }
    const targetRestriction = checkRestrictedMarketplaceItem({
      title: effectiveListing.title,
      description: effectiveListing.description,
      category: effectiveListing.category,
    });
    if (targetRestriction.restricted) {
      setErrorMsg(
        targetRestriction.reason ||
          'This auction involves a prohibited item under our U.S. & Oregon marketplace restriction policy.'
      );
      return false;
    }
    if (selectedMode === 'barter') {
      if (offeringType === 'inventory') {
        if (inventoryKind === 'good' && !selectedGood) {
          setErrorMsg('Select a good from your barter inventory or enter a Custom Barter Offer.');
          return false;
        }
        if (inventoryKind === 'service' && !selectedService) {
          setErrorMsg('Select a service retainer from your inventory or enter a Custom Barter Offer.');
          return false;
        }
      } else if (!customOfferText.trim()) {
        setErrorMsg('Please describe the goods or services you are offering for this barter bid.');
        return false;
      }
      const offerRestriction = checkRestrictedMarketplaceItem({
        title:
          offeringType === 'inventory'
            ? inventoryKind === 'good'
              ? selectedGood?.name
              : selectedService?.name
            : undefined,
        description:
          offeringType === 'inventory'
            ? inventoryKind === 'good'
              ? selectedGood?.description
              : selectedService?.deliverableDescription
            : undefined,
        customOfferText: offeringType === 'custom' ? customOfferText : undefined,
      });
      if (offerRestriction.restricted) {
        setErrorMsg(
          offerRestriction.reason ||
            'Your barter offer includes a prohibited item under our U.S. & Oregon marketplace restriction policy.'
        );
        return false;
      }
      if (includeSweetener && sweetenerAmountUSD > 0 && activeSweetenerCoin && !activeSweetenerCoin.hasSufficientBalance) {
        setErrorMsg(
          formatInsufficientCurrencyError({
            symbol: activeSweetenerCoin.symbol,
            name: activeSweetenerCoin.name,
            available: activeSweetenerCoin.totalAvailableUnits,
            required: activeSweetenerCoin.requiredUnits,
            maxDecimals: activeSweetenerCoin.decimals,
          })
        );
        return false;
      }
    } else {
      if (!activeCoinOption) {
        setErrorMsg(`Please select a valid ${MODE_LABELS[selectedMode]} asset.`);
        return false;
      }
      const optsAtTarget = getCurrencyOptionsForType(activeUserId, effectiveListing, selectedMode, targetUSD);
      const matched = optsAtTarget.find((c) => c.symbol === activeCoinOption.symbol) || activeCoinOption;
      if (!matched.hasSufficientBalance) {
        setErrorMsg(
          formatInsufficientCurrencyError({
            symbol: matched.symbol,
            name: matched.name,
            available: matched.totalAvailableUnits,
            required: matched.requiredUnits,
            maxDecimals: matched.decimals,
          })
        );
        return false;
      }
    }
    return true;
  };

  const handleRequestPlaceBid = (e: React.FormEvent) => {
    e.preventDefault();
    const effectiveUSD =
      selectedMode === 'barter' && offeringType === 'inventory' && inventoryEstimatedUSD > bidAmountUSD
        ? inventoryEstimatedUSD
        : bidAmountUSD;

    if (effectiveUSD < minNextBidUSD) {
      setErrorMsg(`Minimum next bid is $${minNextBidUSD.toLocaleString()} USD.`);
      return;
    }
    if (!validateBidBeforeConfirm(effectiveUSD)) return;
    setConfirmAction({ type: 'bid' });
  };

  const handleRequestBuyNow = () => {
    if (buyNowPriceUSD <= 0) return;
    if (!validateBidBeforeConfirm(buyNowPriceUSD)) return;
    setConfirmAction({ type: 'buy_now' });
  };

  const handleExecuteConfirmedAction = () => {
    if (!confirmAction || !effectiveListing) return;
    const action = confirmAction;
    setConfirmAction(null);
    setErrorMsg(null);

    if (action.type === 'bid') {
      const effectiveUSD =
        selectedMode === 'barter' && offeringType === 'inventory' && inventoryEstimatedUSD > bidAmountUSD
          ? inventoryEstimatedUSD
          : bidAmountUSD;

      const res = placeAuctionBid({
        bidderId: activeUserId,
        bidderUid: currentUser?.uid,
        bidderName: currentUser?.name || 'Member',
        bidderHandle: currentUser?.handle || activeUserId,
        bidderAvatar: currentUser?.avatarUrl,
        listing: effectiveListing,
        amountUSD: effectiveUSD,
        mode: selectedMode as SettlementMethod,
        coinOption: selectedMode === 'barter' ? null : activeCoinOption,
        barterOfferingType: offeringType,
        barterInventoryKind: inventoryKind,
        barterSelectedItemId: inventoryKind === 'good' ? selectedGoodId : selectedServiceId,
        barterOfferedUnits: offeredUnits,
        barterOfferDescription: selectedMode === 'barter' ? buildBarterDescription() : undefined,
        sweetenerCoin: includeSweetener && sweetenerAmountUSD > 0 ? activeSweetenerCoin : null,
        sweetenerAmountUSD: includeSweetener ? sweetenerAmountUSD : 0,
      });

      if (!res.success) {
        setErrorMsg(res.error || 'Could not place auction bid.');
        addToast({ type: 'error', title: 'Bid Rejected', message: res.error || 'Unable to place bid.' });
        return;
      }

      refreshAuctionState();
      setBidAmountUSD((res.updatedConfig?.highestBidUSD || effectiveUSD) + minIncrementUSD);
      addToast({
        type: 'gold',
        title: 'Auction Bid Recorded',
        message: `You are now the highest bidder on "${effectiveListing.title}" at $${effectiveUSD.toLocaleString()} USD (${MODE_LABELS[selectedMode]}).`,
      });
      addNotification({
        title: `Bid Placed: $${effectiveUSD.toLocaleString()} USD`,
        description: `Your ${MODE_LABELS[selectedMode]} bid on "${effectiveListing.title}" is now leading.`,
        type: 'trade',
        targetTab: 'marketplace',
        targetId: effectiveListing.id,
        amount: effectiveUSD,
      });
      setActiveTab('bids');
      if (onAuctionUpdated) onAuctionUpdated();
      return;
    }

    if (action.type === 'buy_now') {
      const buyNowOptions =
        selectedMode === 'barter'
          ? []
          : getCurrencyOptionsForType(activeUserId, effectiveListing, selectedMode as CurrencyTypeId, buyNowPriceUSD);
      const buyNowCoin =
        buyNowOptions.find((c) => c.symbol === activeCoinOption?.symbol) || buyNowOptions[0] || null;

      const res = buyNowAuctionListing({
        buyerId: activeUserId,
        buyerName: currentUser?.name || 'Member',
        buyerHandle: currentUser?.handle || activeUserId,
        listing: effectiveListing,
        mode: selectedMode as SettlementMethod,
        coinOption: buyNowCoin,
        barterOfferingType: offeringType,
        barterInventoryKind: inventoryKind,
        barterSelectedItemId: inventoryKind === 'good' ? selectedGoodId : selectedServiceId,
        barterOfferedUnits: offeredUnits,
        barterCustomOfferText: selectedMode === 'barter' ? buildBarterDescription() : undefined,
        sweetenerCoin: includeSweetener && sweetenerAmountUSD > 0 ? activeSweetenerCoin : null,
        sweetenerAmountUSD: includeSweetener ? sweetenerAmountUSD : 0,
      });

      if (!res.success) {
        setErrorMsg(res.error || 'Buy Now settlement failed.');
        addToast({ type: 'error', title: 'Settlement Failed', message: res.error || 'Could not execute Buy Now.' });
        return;
      }

      refreshAuctionState();
      syncContextAfterSettlement(
        selectedMode === 'barter' ? 'barter' : 'currency',
        res.amountUSD,
        (selectedMode === 'barter' ? 'barter' : selectedMode) as AssetClass,
        res.ledgerItem,
        activeUserId
      );
      addToast({
        type: 'gold',
        title: res.barterIouCode
          ? `Auction Won via Barter · IOU ${res.barterIouCode}`
          : 'Auction Won via Buy Now',
        message: `Settled "${effectiveListing.title}" for $${res.amountUSD.toLocaleString()} USD via ${MODE_LABELS[selectedMode]}.${res.barterIouCode ? ` Mutual Barter IOU ${res.barterIouCode} created for both parties.` : ''}`,
      });
      addNotification({
        title: res.barterIouCode
          ? `⚡ Auction Barter IOU Ready (${res.barterIouCode})`
          : '⚡ Auction Won via Buy Now',
        description: `Acquired "${effectiveListing.title}" for $${res.amountUSD.toLocaleString()} USD via ${MODE_LABELS[selectedMode]}.${res.barterIouCode ? ' Track & confirm fulfillment in Barter IOUs.' : ''}`,
        type: 'trade',
        targetTab: res.barterIouCode ? 'qrcodes' : 'listing_detail',
        targetId: res.barterIouId || effectiveListing.id,
        amount: res.amountUSD,
        showToast: false,
        tone: 'gold',
      });
      if (onAuctionUpdated) onAuctionUpdated();
      return;
    }

    if (action.type === 'accept_bid') {
      const bid = action.bid;
      const res = acceptAuctionBid({
        sellerId: activeUserId,
        sellerName: currentUser?.name || 'Seller',
        listing: effectiveListing,
        bidId: bid.id,
      });

      if (!res.success) {
        setErrorMsg(res.error || 'Could not settle selected bid.');
        addToast({ type: 'error', title: 'Settlement Failed', message: res.error || 'Unable to settle bid.' });
        return;
      }

      refreshAuctionState();
      syncContextAfterSettlement(
        bid.mode === 'barter' ? 'barter' : 'currency',
        res.amountUSD,
        (bid.mode === 'barter' ? 'barter' : bid.mode) as AssetClass,
        res.ledgerItem,
        bid.bidderId
      );
      addToast({
        type: 'gold',
        title: res.barterIouCode
          ? `Barter Auction Awarded · IOU ${res.barterIouCode}`
          : 'Auction Awarded & Settled',
        message: `Accepted ${bid.bidderName}'s $${bid.amountUSD.toLocaleString()} USD bid (${MODE_LABELS[bid.mode]}).${res.barterIouCode ? ` Mutual Barter IOU ${res.barterIouCode} issued to both parties.` : ' Funds & ownership settled.'}`,
      });
      addNotification({
        title: res.barterIouCode
          ? `Auction Settled · Barter IOU (${res.barterIouCode})`
          : `Auction Settled: "${effectiveListing.title}"`,
        description: `Awarded to ${bid.bidderName} for $${bid.amountUSD.toLocaleString()} USD via ${MODE_LABELS[bid.mode]}.${res.barterIouCode ? ' Track & confirm in Barter IOUs.' : ''}`,
        type: 'trade',
        targetTab: res.barterIouCode ? 'qrcodes' : 'uploads',
        targetId: res.barterIouId || effectiveListing.id,
        amount: bid.amountUSD,
      });
      if (onAuctionUpdated) onAuctionUpdated();
    }
  };

  const renderModeIcon = (mode: SettlementModeId) => {
    if (mode === 'final_coins') return <Sparkles className="w-3.5 h-3.5" />;
    if (mode === 'stable_coins') return <ShieldCheck className="w-3.5 h-3.5" />;
    if (mode === 'fiat') return <Banknote className="w-3.5 h-3.5" />;
    if (mode === 'crypto') return <Binary className="w-3.5 h-3.5" />;
    return <Repeat className="w-3.5 h-3.5" />;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/65 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 12 }}
        transition={{ duration: 0.22, ease: 'easeOut' }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-2xl text-left text-slate-900 my-auto max-h-[92dvh] flex flex-col relative"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-amber-300 bg-amber-50 text-amber-700">
              <Gavel className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-serif text-lg font-bold text-slate-900 truncate">
                  {isOwner ? 'Manage Auction & Award Bids' : 'Live 5-Mode Auction Desk'}
                </h2>
                <span
                  className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full font-bold ${
                    isSettled
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : isEnded
                      ? 'bg-slate-200 text-slate-700'
                      : 'bg-amber-500 text-slate-950'
                  }`}
                >
                  {isSettled ? 'Settled' : isEnded ? 'Ended' : countdown.text}
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate">
                {effectiveListing.title} • Seller: {effectiveListing.sellerName}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Metrics Summary Strip */}
        <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center">
          <div>
            <span className="text-[10px] font-mono uppercase text-slate-500 block">
              {hasHighestBid ? 'Current High Bid' : 'Starting Bid'}
            </span>
            <span className="font-mono text-sm sm:text-base font-black text-amber-700">
              ${currentPriceUSD.toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-mono uppercase text-slate-500 block">Min Next Bid</span>
            <span className="font-mono text-sm sm:text-base font-bold text-slate-900">
              ${minNextBidUSD.toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-mono uppercase text-slate-500 block">Reserve Status</span>
            <span
              className={`text-xs font-bold inline-block mt-0.5 ${
                reservePriceUSD <= 0
                  ? 'text-slate-700'
                  : reserveMet
                  ? 'text-emerald-700'
                  : 'text-amber-700'
              }`}
            >
              {reservePriceUSD <= 0
                ? 'No Reserve'
                : reserveMet
                ? 'Reserve Met'
                : `Reserve $${reservePriceUSD.toLocaleString()}`}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-mono uppercase text-slate-500 block">Total Bids</span>
            <span className="font-mono text-sm sm:text-base font-bold text-slate-900">
              {sortedBids.length} {sortedBids.length === 1 ? 'bid' : 'bids'}
            </span>
          </div>
        </div>

        {/* Modal Tabs */}
        <div className="mt-3 flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 shrink-0">
          {!isOwner && (
            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setActiveTab('place_bid');
              }}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'place_bid'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Gavel className="w-3.5 h-3.5" />
              <span>Place Bid (5 Modes)</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setErrorMsg(null);
              setActiveTab('bids');
            }}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'bids'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>
              {isOwner ? `Incoming Bids (${sortedBids.length})` : `Bid History (${sortedBids.length})`}
            </span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="mt-3 flex-1 overflow-y-auto pr-1 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* TAB 1: PLACE BID */}
          {activeTab === 'place_bid' && !isOwner && (
            <>
              {isSettled ? (
                <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-2">
                  <Trophy className="w-8 h-8 text-emerald-700 mx-auto" />
                  <h4 className="text-sm font-bold text-emerald-950">Auction Settled &amp; Closed</h4>
                  <p className="text-xs text-emerald-800">
                    This {effectiveListing.itemType === 'service' ? 'service' : 'asset'} was awarded at $
                    {currentPriceUSD.toLocaleString()} USD.
                  </p>
                </div>
              ) : isEnded ? (
                <div className="p-6 rounded-2xl bg-slate-100 border border-slate-200 text-center space-y-2">
                  <Clock className="w-8 h-8 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-slate-900">Bidding Window Has Closed</h4>
                  <p className="text-xs text-slate-600">
                    Bidding time has expired. Check the Bid History tab while the seller finalizes settlement.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleRequestPlaceBid} className="space-y-4">
                  {/* Bid Amount (USD equivalent) */}
                  <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2.5">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <label className="text-xs font-bold text-amber-950 uppercase tracking-wide">
                        Your Bid Valuation (USD Equivalent)
                      </label>
                      <span className="text-[11px] font-mono text-amber-800">
                        Min increment: +${minIncrementUSD.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono font-bold text-sm">
                          $
                        </span>
                        <input
                          type="number"
                          min={minNextBidUSD}
                          step="any"
                          value={bidAmountUSD}
                          onChange={(e) => setBidAmountUSD(Math.max(0, Number(e.target.value)))}
                          className="w-full pl-8 pr-4 py-2.5 rounded-xl bg-white border border-amber-300 font-mono text-base font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>
                      <div className="flex items-center gap-1.5">
                        {[1, 2, 5].map((mult) => (
                          <button
                            key={mult}
                            type="button"
                            onClick={() =>
                              setBidAmountUSD(
                                (hasHighestBid ? currentPriceUSD : Number(auctionCfg?.startingBidUSD || 0)) +
                                  minIncrementUSD * mult
                              )
                            }
                            className="px-2.5 py-2 rounded-xl bg-white border border-amber-300 hover:bg-amber-100 text-amber-950 font-mono text-xs font-bold cursor-pointer"
                          >
                            +{mult}x (${(minIncrementUSD * mult).toLocaleString()})
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* All 5 Transaction Mode Selector */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                        Select Transaction Mode (5 Rails)
                      </span>
                      <span className="text-[11px] text-slate-500 font-mono">
                        {allowedModes.length}/5 modes accepted
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {ALL_FIVE_MODES.map((mode) => {
                        const enabled = allowedModes.includes(mode);
                        const selected = selectedMode === mode;
                        return (
                          <button
                            key={mode}
                            type="button"
                            disabled={!enabled}
                            onClick={() => setSelectedMode(mode)}
                            className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                              !enabled
                                ? 'bg-slate-50 border-slate-200 text-slate-300 cursor-not-allowed opacity-60'
                                : selected
                                ? 'bg-slate-900 border-slate-900 text-white shadow-sm cursor-pointer'
                                : 'bg-white border-slate-200 text-slate-700 hover:border-amber-400 cursor-pointer'
                            }`}
                          >
                            {renderModeIcon(mode)}
                            <span className="text-[11px] font-bold leading-tight">{MODE_LABELS[mode]}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Mode 1-4: Currency Coin Picker & Wallet Balance */}
                  {selectedMode !== 'barter' && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-700">
                          Choose {MODE_LABELS[selectedMode]} Asset to Back Bid
                        </span>
                        {activeCoinOption && (
                          <span className="text-[11px] font-mono text-slate-600">
                            Required: <strong>{activeCoinOption.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} {activeCoinOption.symbol}</strong>
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                        {coinOptions.map((coin) => {
                          const isSelected = activeCoinOption?.symbol === coin.symbol;
                          return (
                            <button
                              key={coin.symbol}
                              type="button"
                              onClick={() => setSelectedCoinSymbol(coin.symbol)}
                              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                                isSelected
                                  ? 'border-amber-500 bg-amber-50/70 ring-1 ring-amber-400'
                                  : 'border-slate-200 bg-white hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <div>
                                  <span className="text-xs font-bold text-slate-900">{coin.symbol}</span>
                                  <span className="text-[11px] text-slate-500 ml-1.5">{coin.name}</span>
                                </div>
                                {coin.hasSufficientBalance ? (
                                  <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                                    Ready
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-mono font-bold text-red-600 bg-red-50 px-1.5 py-0.5 rounded">
                                    Low Bal
                                  </span>
                                )}
                              </div>
                              <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono text-slate-600">
                                <span>
                                  Total: {coin.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: coin.decimals })} {coin.symbol}
                                  {coin.feeUSD > 0 ? ` (+$${coin.feeUSD.toFixed(2)})` : ''}
                                </span>
                                <span>
                                  Avail: {coin.totalAvailableUnits.toLocaleString(undefined, { maximumFractionDigits: coin.decimals })}
                                </span>
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      {activeCoinOption && (
                        <div className="p-3 rounded-2xl bg-slate-900 text-white space-y-1.5 text-xs font-mono">
                          <div className="flex items-center justify-between text-slate-300">
                            <span>Bid Valuation ({activeCoinOption.walletProviderLabel})</span>
                            <span>
                              {activeCoinOption.baseUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} {activeCoinOption.symbol} (${bidAmountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD)
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-slate-300">
                            <span>{activeCoinOption.feeLabel}</span>
                            <span className={activeCoinOption.feeUSD > 0 ? 'text-amber-300 font-semibold' : 'text-emerald-300 font-semibold'}>
                              {activeCoinOption.feeUSD > 0
                                ? `+$${activeCoinOption.feeUSD.toFixed(2)} USD (+${activeCoinOption.feeUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} ${activeCoinOption.symbol})`
                                : '$0.00 (Free)'}
                            </span>
                          </div>
                          <div className="pt-1.5 border-t border-slate-800 flex items-center justify-between font-bold text-white">
                            <span>Total Settlement Due (incl. Wallet Fee)</span>
                            <span>
                              {activeCoinOption.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} {activeCoinOption.symbol} (${activeCoinOption.totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD)
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Mode 5: Direct Barter Proposal (Goods / Services + Optional Sweetener) */}
                  {selectedMode === 'barter' && (
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                          <Repeat className="w-3.5 h-3.5 text-amber-700" />
                          <span>Barter Bid Composition</span>
                        </span>
                        <div className="flex items-center gap-1 bg-white border border-slate-200 p-0.5 rounded-lg text-[11px]">
                          <button
                            type="button"
                            onClick={() => setOfferingType('inventory')}
                            className={`px-2.5 py-1 rounded-md font-bold cursor-pointer ${
                              offeringType === 'inventory'
                                ? 'bg-slate-900 text-white'
                                : 'text-slate-600'
                            }`}
                          >
                            From Inventory
                          </button>
                          <button
                            type="button"
                            onClick={() => setOfferingType('custom')}
                            className={`px-2.5 py-1 rounded-md font-bold cursor-pointer ${
                              offeringType === 'custom'
                                ? 'bg-slate-900 text-white'
                                : 'text-slate-600'
                            }`}
                          >
                            Custom Offer
                          </button>
                        </div>
                      </div>

                      {offeringType === 'inventory' ? (
                        <div className="space-y-2.5">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setInventoryKind('good')}
                              className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                                inventoryKind === 'good'
                                  ? 'bg-amber-100 border-amber-400 text-amber-950'
                                  : 'bg-white border-slate-200 text-slate-600'
                              }`}
                            >
                              <Package className="w-3.5 h-3.5" />
                              <span>Goods ({userWallets.barterGoods.length})</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setInventoryKind('service')}
                              className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                                inventoryKind === 'service'
                                  ? 'bg-indigo-100 border-indigo-400 text-indigo-950'
                                  : 'bg-white border-slate-200 text-slate-600'
                              }`}
                            >
                              <Briefcase className="w-3.5 h-3.5" />
                              <span>Services ({userWallets.barterServices.length})</span>
                            </button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <div className="sm:col-span-2">
                              {inventoryKind === 'good' ? (
                                <select
                                  value={selectedGoodId}
                                  onChange={(e) => setSelectedGoodId(e.target.value)}
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-medium text-slate-900"
                                >
                                  {userWallets.barterGoods.length === 0 && (
                                    <option value="">No physical goods in inventory</option>
                                  )}
                                  {userWallets.barterGoods.map((g) => (
                                    <option key={g.id} value={g.id}>
                                      {g.name} (${g.estimatedUnitValue.toLocaleString()}/unit • {g.quantity} avail)
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <select
                                  value={selectedServiceId}
                                  onChange={(e) => setSelectedServiceId(e.target.value)}
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-medium text-slate-900"
                                >
                                  {userWallets.barterServices.length === 0 && (
                                    <option value="">No service retainers in inventory</option>
                                  )}
                                  {userWallets.barterServices.map((s) => (
                                    <option key={s.id} value={s.id}>
                                      {s.name} (${s.hourlyRateValue.toLocaleString()}/{s.unitType} • {s.availableUnits} avail)
                                    </option>
                                  ))}
                                </select>
                              )}
                            </div>
                            <div>
                              <input
                                type="number"
                                min={1}
                                value={offeredUnits}
                                onChange={(e) => setOfferedUnits(Math.max(1, Number(e.target.value)))}
                                className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono font-bold text-slate-900"
                                placeholder="Units"
                              />
                            </div>
                          </div>

                          {inventoryEstimatedUSD > 0 && (
                            <div className="flex items-center justify-between text-[11px] font-mono bg-white p-2 rounded-xl border border-slate-200">
                              <span className="text-slate-500">Estimated Inventory Value:</span>
                              <button
                                type="button"
                                onClick={() => setBidAmountUSD(Math.max(minNextBidUSD, inventoryEstimatedUSD))}
                                className="font-bold text-amber-700 hover:underline cursor-pointer"
                              >
                                ${inventoryEstimatedUSD.toLocaleString()} USD (Use as Bid)
                              </button>
                            </div>
                          )}
                        </div>
                      ) : (
                        <textarea
                          rows={2}
                          value={customOfferText}
                          onChange={(e) => setCustomOfferText(e.target.value)}
                          placeholder="Describe your offered goods, real assets, or professional service deliverables for this auction bid..."
                          className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      )}

                      {/* Optional Balancing Sweetener in any of the 4 Currency Types */}
                      <div className="pt-2 border-t border-slate-200 space-y-2">
                        <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={includeSweetener}
                            onChange={(e) => setIncludeSweetener(e.target.checked)}
                            className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                          />
                          <span>Add optional currency sweetener (AFNL, Stablecoins, Fiat, or Crypto)</span>
                        </label>

                        {includeSweetener && (
                          <div className="space-y-2">
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                              <select
                                value={sweetenerCurrencyType}
                                onChange={(e) => setSweetenerCurrencyType(e.target.value as CurrencyTypeId)}
                                className="px-2.5 py-2 rounded-xl bg-white border border-slate-200 text-xs font-semibold"
                              >
                                {CURRENCY_TYPES_ORDER.map((ct) => (
                                  <option key={ct} value={ct}>
                                    {CURRENCY_TYPE_META[ct].shortLabel}
                                  </option>
                                ))}
                              </select>
                              <select
                                value={sweetenerCoinSymbol}
                                onChange={(e) => setSweetenerCoinSymbol(e.target.value)}
                                className="px-2.5 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono font-bold"
                              >
                                {sweetenerCoinOptions.map((c) => (
                                  <option key={c.symbol} value={c.symbol}>
                                    {c.symbol} (Avail: {c.totalAvailableUnits.toLocaleString(undefined, { maximumFractionDigits: c.decimals })})
                                  </option>
                                ))}
                              </select>
                              <input
                                type="number"
                                min={1}
                                value={sweetenerAmountUSD}
                                onChange={(e) => setSweetenerAmountUSD(Math.max(0, Number(e.target.value)))}
                                className="px-2.5 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono font-bold"
                                placeholder="Sweetener USD"
                              />
                            </div>
                            {activeSweetenerCoin && sweetenerAmountUSD > 0 && (
                              <div className="flex flex-wrap items-center justify-between gap-2 p-2 rounded-xl bg-white border border-slate-200 text-[11px] font-mono text-slate-600">
                                <span>
                                  {activeSweetenerCoin.feeUSD > 0
                                    ? `${activeSweetenerCoin.feeLabel}: +$${activeSweetenerCoin.feeUSD.toFixed(2)}`
                                    : 'Protocol Fee: $0.00'}
                                </span>
                                <span className="font-bold text-slate-900">
                                  Total Sweetener: {activeSweetenerCoin.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeSweetenerCoin.decimals })} {activeSweetenerCoin.symbol} ($
                                  {activeSweetenerCoin.totalUSD.toFixed(2)} USD)
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Submit & Optional Buy Now Buttons */}
                  <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                    <button
                      type="submit"
                      className="flex-1 py-3 px-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Gavel className="w-4 h-4" />
                      <span>
                        Submit Bid ($
                        {(
                          selectedMode === 'barter' &&
                          offeringType === 'inventory' &&
                          inventoryEstimatedUSD > bidAmountUSD
                            ? inventoryEstimatedUSD
                            : bidAmountUSD
                        ).toLocaleString()}{' '}
                        • {MODE_LABELS[selectedMode]})
                      </span>
                    </button>

                    {buyNowPriceUSD > 0 && (
                      <button
                        type="button"
                        onClick={handleRequestBuyNow}
                        className="py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <Zap className="w-4 h-4 text-amber-400" />
                        <span>Buy Now (${buyNowPriceUSD.toLocaleString()})</span>
                      </button>
                    )}
                  </div>
                </form>
              )}
            </>
          )}

          {/* TAB 2: BID HISTORY & SELLER AWARDING */}
          {activeTab === 'bids' && (
            <div className="space-y-2.5">
              {sortedBids.length === 0 ? (
                <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-2">
                  <Gavel className="w-7 h-7 text-slate-400 mx-auto" />
                  <p className="text-xs font-semibold text-slate-700">No bids placed yet.</p>
                  <p className="text-[11px] text-slate-500">
                    Starting bid is ${Number(auctionCfg?.startingBidUSD || currentPriceUSD).toLocaleString()} USD across{' '}
                    {allowedModes.map((m) => MODE_LABELS[m]).join(', ')}.
                  </p>
                </div>
              ) : (
                sortedBids.map((bid, idx) => {
                  const isLeading = bid.status === 'active';
                  const isAccepted = bid.status === 'accepted';
                  const isDeclined = bid.status === 'declined';
                  return (
                    <div
                      key={bid.id}
                      className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        isAccepted
                          ? 'bg-emerald-50 border-emerald-300'
                          : isLeading
                          ? 'bg-amber-50/70 border-amber-300'
                          : 'bg-white border-slate-200'
                      }`}
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-xs font-black text-slate-900">
                            ${bid.amountUSD.toLocaleString()} USD
                          </span>
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-900 text-white text-[10px] font-mono font-bold">
                            {renderModeIcon(bid.mode)}
                            <span>
                              {bid.mode === 'barter'
                                ? 'Barter'
                                : `${bid.nativeAmount?.toLocaleString() || ''} ${bid.currencySymbol || MODE_LABELS[bid.mode]}`}
                            </span>
                          </span>
                          {isAccepted ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
                              <Trophy className="w-3 h-3" /> Accepted &amp; Won
                            </span>
                          ) : isLeading ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-bold">
                              <Award className="w-3 h-3" /> Leading #{idx + 1}
                            </span>
                          ) : isDeclined ? (
                            <span className="px-2 py-0.5 rounded-full bg-slate-200 text-slate-600 text-[10px] font-semibold">
                              Closed
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-semibold">
                              Outbid
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-slate-700">
                          <span className="font-semibold">{bid.bidderName}</span>{' '}
                          <span className="text-slate-500 font-mono">@{bid.bidderHandle}</span>
                          <span className="text-slate-400 mx-1.5">•</span>
                          <span className="text-slate-400 font-mono text-[11px]">
                            {new Date(bid.createdAt).toLocaleString()}
                          </span>
                        </p>

                        {bid.mode === 'barter' && bid.barterOfferDescription && (
                          <p className="text-[11px] text-amber-900 bg-amber-100/70 px-2.5 py-1 rounded-lg border border-amber-200/80">
                            <strong>Barter Offer:</strong> {bid.barterOfferDescription}
                            {bid.sweetenerCoinSymbol && bid.sweetenerAmountUSD
                              ? ` + $${bid.sweetenerAmountUSD.toLocaleString()} ${bid.sweetenerCoinSymbol} sweetener`
                              : ''}
                          </p>
                        )}
                      </div>

                      {isOwner && !isSettled && !isDeclined && (
                        <button
                          type="button"
                          onClick={() => setConfirmAction({ type: 'accept_bid', bid })}
                          className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Accept &amp; Settle Bid</span>
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>

        {/* Confirmation Dialog */}
        <ConfirmModal
          isOpen={Boolean(confirmAction)}
          title={
            confirmAction?.type === 'accept_bid'
              ? 'Award Auction & Execute Settlement'
              : confirmAction?.type === 'buy_now'
              ? 'Confirm Instant Buy Now Settlement'
              : 'Confirm Auction Bid'
          }
          message={
            confirmAction?.type === 'accept_bid'
              ? `Award "${effectiveListing.title}" to ${confirmAction.bid.bidderName} (@${confirmAction.bid.bidderHandle}) for $${confirmAction.bid.amountUSD.toLocaleString()} USD via ${MODE_LABELS[confirmAction.bid.mode]}? Wallets, asset inventory, and the Universal Ledger will be updated immediately.`
              : confirmAction?.type === 'buy_now'
              ? `Execute instant Buy Now for "${effectiveListing.title}" at $${buyNowPriceUSD.toLocaleString()} USD${selectedMode !== 'barter' && activeCoinOption && activeCoinOption.feeUSD > 0 ? ` + ${activeCoinOption.walletProviderLabel} fee` : ''} via ${MODE_LABELS[selectedMode]}? Your wallet/barter commitment will settle immediately.`
              : `Place a binding ${MODE_LABELS[selectedMode]} bid of $${(selectedMode === 'barter' && offeringType === 'inventory' && inventoryEstimatedUSD > bidAmountUSD ? inventoryEstimatedUSD : bidAmountUSD).toLocaleString()} USD${selectedMode !== 'barter' && activeCoinOption && activeCoinOption.feeUSD > 0 ? ` (Total $${activeCoinOption.totalUSD.toFixed(2)} USD incl. $${activeCoinOption.feeUSD.toFixed(2)} ${activeCoinOption.walletProviderLabel} fee)` : ''} on "${effectiveListing.title}"?`
          }
          confirmText={
            confirmAction?.type === 'accept_bid'
              ? 'Settle & Award'
              : confirmAction?.type === 'buy_now'
              ? 'Execute Buy Now'
              : 'Confirm Bid'
          }
          type={confirmAction?.type === 'accept_bid' ? 'info' : 'warning'}
          onClose={() => setConfirmAction(null)}
          onConfirm={handleExecuteConfirmedAction}
        />
      </motion.div>
    </div>
  );
};
