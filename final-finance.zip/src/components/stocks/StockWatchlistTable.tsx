import React, { useState } from 'react';
import { StockItem, StockSector, StockPosition, StockMarketWay } from '../../types/stocks';
import { 
  Search, 
  Star, 
  TrendingUp, 
  TrendingDown, 
  ChevronRight,
  ShieldCheck,
  Zap,
  Building2,
  Coins
} from 'lucide-react';
import { matchStockSearch } from '../../utils/stockWalletBridge';
import { formatStockPrice, formatStockMarketCap } from '../../utils/stockCurrencyFormatter';

interface StockWatchlistTableProps {
  stocks: StockItem[];
  selectedTicker: string;
  watchlist: string[];
  positions?: StockPosition[];
  selectedMarketWay?: StockMarketWay | 'all';
  onSelectStock: (stock: StockItem) => void;
  onToggleWatchlist: (ticker: string) => void;
  onQuickBuyStock?: (stock: StockItem) => void;
  onQuickTradeStock?: (stock: StockItem, side: 'buy' | 'sell') => void;
}

export const StockWatchlistTable: React.FC<StockWatchlistTableProps> = ({
  stocks,
  selectedTicker,
  watchlist,
  positions = [],
  selectedMarketWay = 'all',
  onSelectStock,
  onToggleWatchlist,
  onQuickBuyStock,
  onQuickTradeStock,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSector, setSelectedSector] = useState<StockSector | 'Favorites'>('All');
  const [sortBy, setSortBy] = useState<'volume' | 'gainers' | 'losers' | 'marketCap'>('volume');

  const sectors: (StockSector | 'Favorites')[] = [
    'All',
    'Favorites',
    'Technology & AI',
    'Semiconductors',
    'Gold & Commodities',
    'Banking & Finance',
    'Treasuries & Yield',
    'Crypto Treasuries & Mining',
    'Consumer Staples & Defensive',
    'Energy & Aerospace',
    'ETFs & Indices'
  ];

  // Filter stocks
  const filteredStocks = stocks.filter((stock) => {
    // Market way filter
    if (selectedMarketWay !== 'all' && stock.marketType !== selectedMarketWay) {
      return false;
    }

    // Search filter (supports ticker, company name, personal/business category, and issuance coin like AFNL, USDC, BTC, USD)
    if (!matchStockSearch(stock, searchQuery)) {
      return false;
    }

    // Sector or Favorites filter
    if (selectedSector === 'Favorites') {
      return watchlist.some((t) => t.toUpperCase() === stock.ticker.toUpperCase());
    }
    if (selectedSector !== 'All') {
      return stock.sector === selectedSector;
    }
    return true;
  });

  // Sort
  const sortedStocks = [...filteredStocks].sort((a, b) => {
    if (sortBy === 'gainers') return b.changePercent - a.changePercent;
    if (sortBy === 'losers') return a.changePercent - b.changePercent;
    if (sortBy === 'marketCap') {
      const getCapVal = (c: string) => {
        if (c.includes('T')) return parseFloat(c.replace('$', '').replace('T', '')) * 1000;
        if (c.includes('B')) return parseFloat(c.replace('$', '').replace('B', ''));
        if (c.includes('M')) return parseFloat(c.replace('$', '').replace('M', '')) / 1000;
        return 0;
      };
      return getCapVal(b.marketCap) - getCapVal(a.marketCap);
    }
    // Default by 24h change magnitude or volume
    return Math.abs(b.changePercent) - Math.abs(a.changePercent);
  });

  const getMarketBadge = (marketType?: StockMarketWay) => {
    switch (marketType) {
      case 'final':
        return {
          label: 'Final',
          icon: Zap,
          bg: 'bg-amber-500/10 text-amber-800 dark:text-amber-400 border-amber-500/30'
        };
      case 'stable':
        return {
          label: 'Stable',
          icon: ShieldCheck,
          bg: 'bg-emerald-500/10 text-emerald-800 dark:text-emerald-400 border-emerald-500/30'
        };
      case 'crypto':
        return {
          label: 'Crypto',
          icon: Coins,
          bg: 'bg-purple-500/10 text-purple-800 dark:text-purple-400 border-purple-500/30'
        };
      case 'fiat':
      default:
        return {
          label: 'Fiat',
          icon: Building2,
          bg: 'bg-indigo-500/10 text-indigo-800 dark:text-indigo-400 border-indigo-500/30'
        };
    }
  };

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-4 sm:p-6 shadow-sm">
      {/* Search & Sort Controls Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search equities, tickers, or settlement methods..."
            className="w-full h-10 pl-9 pr-3.5 rounded-xl border border-slate-200 bg-slate-50/50 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
          />
        </div>

        {/* Sort Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          <span className="text-xs text-slate-400 font-semibold shrink-0">Sort:</span>
          {(
            [
              { id: 'volume', label: 'Most Active' },
              { id: 'gainers', label: 'Top Gainers' },
              { id: 'losers', label: 'Top Dip/Decline' },
              { id: 'marketCap', label: 'Market Cap' },
            ] as const
          ).map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setSortBy(s.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                sortBy === s.id
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sector Filter Chips */}
      <div className="flex items-center gap-1.5 py-3 overflow-x-auto scrollbar-none">
        {sectors.map((sec) => (
          <button
            key={sec}
            type="button"
            onClick={() => setSelectedSector(sec)}
            className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 ${
              selectedSector === sec
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {sec === 'Favorites' && <Star className="w-3 h-3 fill-current text-amber-400" />}
            <span>{sec}</span>
          </button>
        ))}
      </div>

      {/* Stocks Table / List */}
      <div className="overflow-x-auto mt-2">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <th className="py-2.5 px-3 w-8"></th>
              <th className="py-2.5 px-3">Asset / Symbol</th>
              <th className="py-2.5 px-3 hidden md:table-cell">Market Way / Settlement</th>
              <th className="py-2.5 px-3 text-right">Price</th>
              <th className="py-2.5 px-3 text-right">24h Change</th>
              <th className="py-2.5 px-3 text-center hidden lg:table-cell">Intraday Sparkline</th>
              <th className="py-2.5 px-3 text-right hidden sm:table-cell">Market Cap</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50 text-xs sm:text-sm">
            {sortedStocks.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-12 text-center text-slate-400 text-xs">
                  No stocks match your query or market criteria.
                </td>
              </tr>
            ) : (
              sortedStocks.map((stock) => {
                const isSelected = stock.ticker === selectedTicker;
                const isWatched = watchlist.some((t) => t.toUpperCase() === stock.ticker.toUpperCase());
                const isPos = stock.changeUSD >= 0;
                const userHolding = positions.find(p => p.ticker === stock.ticker);
                const hasHoldings = userHolding && userHolding.shares > 0;
                const mBadge = getMarketBadge(stock.marketType);
                const BadgeIcon = mBadge.icon;

                // Sparkline coordinates
                const minS = Math.min(...stock.sparkline);
                const maxS = Math.max(...stock.sparkline);
                const rangeS = maxS - minS || 1;
                const sparkPoints = stock.sparkline
                  .map((val, idx) => {
                    const x = (idx / (stock.sparkline.length - 1)) * 65;
                    const y = 20 - ((val - minS) / rangeS) * 16;
                    return `${x},${y}`;
                  })
                  .join(' ');

                return (
                  <tr
                    key={stock.ticker}
                    onClick={() => onSelectStock(stock)}
                    className={`group cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-amber-50/70 font-semibold'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    {/* Favorites Star */}
                    <td className="py-3 px-3">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWatchlist(stock.ticker);
                        }}
                        className="p-1 rounded-md text-slate-400 hover:text-amber-500 cursor-pointer"
                        title={isWatched ? 'Remove from Favorites' : 'Add to Favorites'}
                      >
                        <Star
                          className={`w-3.5 h-3.5 ${
                            isWatched
                              ? 'text-amber-500 fill-amber-500'
                              : 'hover:fill-amber-200'
                          }`}
                        />
                      </button>
                    </td>

                    {/* Asset Name & Ticker */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-mono font-bold text-xs text-slate-900 group-hover:bg-white group-hover:border-amber-400 transition-colors">
                          {(stock.ticker || '').slice(0, 3)}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-mono font-bold text-xs sm:text-sm text-slate-900">
                              ${stock.ticker}
                            </span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded border flex items-center gap-0.5 ${mBadge.bg}`}>
                              <BadgeIcon className="w-2.5 h-2.5" />
                              <span>{mBadge.label}</span>
                            </span>
                            {hasHoldings && (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                                {userHolding.shares} Owned
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 truncate max-w-[140px] sm:max-w-[220px]">
                            {stock.name}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Market Way & Settlement Route */}
                    <td className="py-3 px-3 hidden md:table-cell">
                      <div className="text-xs">
                        <span className="font-medium text-slate-800 block truncate max-w-[200px]">
                          {stock.sector}
                        </span>
                        <span className="text-[10px] text-slate-400 block truncate max-w-[200px]">
                          {stock.settlementMethod || 'Direct Clearing'}
                        </span>
                      </div>
                    </td>

                    {/* Price */}
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                      {formatStockPrice(stock.price, stock)}
                    </td>

                    {/* 24h Change Pill */}
                    <td className="py-3 px-3 text-right">
                      <span
                        className={`inline-flex items-center gap-0.5 px-2 py-1 rounded-lg text-xs font-mono font-bold ${
                          isPos
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                            : 'bg-rose-50 text-rose-700 border border-rose-200/60'
                        }`}
                      >
                        {isPos ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%
                      </span>
                    </td>

                    {/* Sparkline */}
                    <td className="py-3 px-3 text-center hidden lg:table-cell">
                      <svg width="70" height="24" className="mx-auto overflow-visible">
                        <polyline
                          fill="none"
                          stroke={isPos ? '#10b981' : '#f43f5e'}
                          strokeWidth="1.8"
                          points={sparkPoints}
                        />
                      </svg>
                    </td>

                    {/* Market Cap */}
                    <td className="py-3 px-3 text-right font-mono text-xs text-slate-600 hidden sm:table-cell">
                      {formatStockMarketCap(stock)}
                    </td>

                    {/* Quick Trade CTAs */}
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onQuickTradeStock) {
                              onQuickTradeStock(stock, 'buy');
                            } else if (onQuickBuyStock) {
                              onQuickBuyStock(stock);
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition-colors cursor-pointer"
                          title={`Buy ${stock.ticker}`}
                        >
                          Buy
                        </button>

                        {hasHoldings && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (onQuickTradeStock) {
                                onQuickTradeStock(stock, 'sell');
                              } else if (onQuickBuyStock) {
                                onQuickBuyStock(stock);
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold transition-colors cursor-pointer"
                            title={`Sell your ${userHolding.shares} shares of ${stock.ticker}`}
                          >
                            Sell
                          </button>
                        )}
                        <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-700 transition-colors" />
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
