import React, { useState } from 'react';
import { StockPosition, StockOrder, StockSector } from '../../types/stocks';
import { 
  TrendingUp, 
  TrendingDown, 
  Briefcase, 
  Clock, 
  CheckCircle2, 
  ArrowUpRight, 
  ArrowDownRight,
  ShieldCheck,
  Zap,
  Building2,
  Building,
  User,
  CreditCard,
  Wallet,
  Download,
  Filter,
  PieChart,
  Layers,
  FileText,
  DollarSign,
  Plus,
  ChevronRight
} from 'lucide-react';
import { calculateSectorAllocations } from '../../utils/stockWalletBridge';

interface StockPositionsViewProps {
  positions: StockPosition[];
  orders: StockOrder[];
  onSelectStockByTicker: (ticker: string) => void;
  onOpenTradeModal: (ticker: string, side: 'buy' | 'sell') => void;
  onViewTradeSlip?: (order: StockOrder) => void;
}

export const StockPositionsView: React.FC<StockPositionsViewProps> = ({
  positions,
  orders,
  onSelectStockByTicker,
  onOpenTradeModal,
  onViewTradeSlip,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'positions' | 'orders' | 'allocation'>('positions');
  const [selectedSectorFilter, setSelectedSectorFilter] = useState<StockSector>('All');

  const totalPortfolioValue = positions.reduce((acc, p) => acc + p.totalValueUSD, 0);
  const totalGainUSD = positions.reduce((acc, p) => acc + p.totalGainUSD, 0);
  const totalCostBasis = positions.reduce((acc, p) => acc + (p.shares * p.avgCostUSD), 0);
  const totalGainPercent = totalCostBasis > 0 ? (totalGainUSD / totalCostBasis) * 100 : 0;
  const totalDailyGainUSD = positions.reduce((acc, p) => acc + p.dailyGainUSD, 0);

  // Sector allocation data
  const sectorAllocations = calculateSectorAllocations(positions);

  // Filtered positions based on chosen sector
  const filteredPositions = selectedSectorFilter === 'All'
    ? positions
    : positions.filter(p => p.sector === selectedSectorFilter);

  // Available unique sectors in portfolio
  const uniqueSectors: StockSector[] = ['All', ...(Array.from(new Set(positions.map(p => p.sector))) as StockSector[])];

  const handleExportCSV = () => {
    const headers = ['Order ID,Ticker,Company,Side,Shares,Price USD,Total USD,Payment Method,Timestamp,Status'];
    const rows = orders.map(o => 
      `"${o.id}","${o.ticker}","${o.stockName}","${o.side.toUpperCase()}","${o.shares}","${o.price}","${o.totalUSD}","${o.paymentSource?.label || 'Wallet'}","${o.timestamp}","${o.status}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Final_Finance_Stock_Trades_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Portfolio Summary Card */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-amber-600" />
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Total Equities Portfolio NAV
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-slate-900 mt-1">
              ${totalPortfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              Invested Capital: ${totalCostBasis.toLocaleString(undefined, { minimumFractionDigits: 2 })} • {positions.length} Active Positions
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200/60">
              <span className="text-[10px] font-semibold text-emerald-800 uppercase block">
                Total Unrealized Profit
              </span>
              <div className="flex items-center gap-1 font-mono font-bold text-sm sm:text-base text-emerald-700 mt-0.5">
                <TrendingUp className="w-4 h-4" />
                <span>+${totalGainUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                <span className="text-xs font-semibold">({totalGainPercent.toFixed(2)}%)</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-500 uppercase block">
                Today's Day Gain
              </span>
              <div className="font-mono font-bold text-sm sm:text-base text-slate-900 mt-0.5">
                +${totalDailyGainUSD.toFixed(2)}
              </div>
            </div>
          </div>
        </div>

        {/* Visual Multi-Type Asset Allocation Ribbon */}
        {positions.length > 0 && (
          <div className="pt-4 pb-2">
            <div className="flex items-center justify-between mb-2 text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-slate-500" />
                <span>Portfolio Stock Types &amp; Sector Allocation</span>
              </span>
              <span className="text-slate-400 font-mono text-[11px]">
                {sectorAllocations.length} Stock Sectors Held
              </span>
            </div>

            {/* Allocation Stacked Bar */}
            <div className="w-full h-3 rounded-full bg-slate-100 flex overflow-hidden gap-0.5 p-0.5">
              {sectorAllocations.map((sec) => (
                <div
                  key={sec.sector}
                  style={{ width: `${Math.max(sec.percentage, 4)}%`, backgroundColor: sec.color }}
                  className="h-full rounded-full transition-all"
                  title={`${sec.sector}: ${sec.percentage}% ($${sec.totalValueUSD.toLocaleString()})`}
                />
              ))}
            </div>

            {/* Allocation Chips */}
            <div className="flex items-center gap-2 overflow-x-auto pt-2.5 pb-1 scrollbar-none">
              {sectorAllocations.map((sec) => (
                <button
                  key={sec.sector}
                  type="button"
                  onClick={() => {
                    setSelectedSectorFilter(sec.sector);
                    setActiveSubTab('positions');
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold flex items-center gap-1.5 whitespace-nowrap border transition-all cursor-pointer ${
                    selectedSectorFilter === sec.sector
                      ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: sec.color }} />
                  <span>{sec.sector}</span>
                  <span className="font-mono font-bold">{sec.percentage}%</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* View Subtabs Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-4 pt-4 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveSubTab('positions')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'positions'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Held Positions ({positions.length})
            </button>

            <button
              type="button"
              onClick={() => setActiveSubTab('orders')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'orders'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Order Activity &amp; Receipts ({orders.length})
            </button>

            <button
              type="button"
              onClick={() => setActiveSubTab('allocation')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'allocation'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Types Analysis
            </button>
          </div>

          {activeSubTab === 'orders' && (
            <button
              type="button"
              onClick={handleExportCSV}
              className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Subtab Content */}
      {activeSubTab === 'positions' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-4 sm:p-6 shadow-sm">
          {/* Sector Filter Chips */}
          <div className="flex items-center gap-1.5 pb-4 mb-3 border-b border-slate-100 overflow-x-auto scrollbar-none">
            <span className="text-xs font-bold text-slate-500 mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3" />
              <span>Filter Type:</span>
            </span>
            {uniqueSectors.map((sec) => (
              <button
                key={sec}
                type="button"
                onClick={() => setSelectedSectorFilter(sec)}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  selectedSectorFilter === sec
                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {sec}
              </button>
            ))}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Stock &amp; Category</th>
                  <th className="py-2.5 px-3 text-right">Shares Held</th>
                  <th className="py-2.5 px-3 text-right">Avg Cost</th>
                  <th className="py-2.5 px-3 text-right">Market Price</th>
                  <th className="py-2.5 px-3 text-right">Total Value</th>
                  <th className="py-2.5 px-3 text-right">Total Return</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-xs sm:text-sm">
                {filteredPositions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      No stock positions in this category. Use the Trade Desk or Watchlist to buy shares.
                    </td>
                  </tr>
                ) : (
                  filteredPositions.map((pos) => {
                    const isPos = pos.totalGainUSD >= 0;
                    return (
                      <tr
                        key={pos.ticker}
                        className="hover:bg-slate-50/80 transition-colors"
                      >
                        <td className="py-3.5 px-3">
                          <div 
                            className="flex items-center gap-2.5 cursor-pointer"
                            onClick={() => onSelectStockByTicker(pos.ticker)}
                          >
                            <div className="w-8 h-8 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center font-mono font-bold text-xs text-amber-900">
                              {(pos.ticker || '').slice(0, 3)}
                            </div>
                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-mono font-bold text-slate-900">{pos.ticker}</span>
                                {pos.ticker === 'ALEX' || pos.sector === 'Sovereign Reserves' || pos.name.toLowerCase().includes('human equity') || pos.name.toLowerCase().includes('personal') ? (
                                  <span className="text-[10px] bg-purple-100 text-purple-800 border border-purple-200 px-1.5 py-0.2 rounded font-semibold inline-flex items-center gap-0.5">
                                    <User className="w-2.5 h-2.5 text-purple-600" />
                                    <span>Personal</span>
                                  </span>
                                ) : (
                                  <span className="text-[10px] bg-blue-100 text-blue-800 border border-blue-200 px-1.5 py-0.2 rounded font-semibold inline-flex items-center gap-0.5">
                                    <Building className="w-2.5 h-2.5 text-blue-600" />
                                    <span>Business</span>
                                  </span>
                                )}
                                <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-semibold">
                                  {pos.sector}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-500 truncate max-w-[150px]">
                                {pos.name}
                              </div>
                              {pos.primaryFundingSourceLabel && (
                                <div className="text-[9px] text-slate-400 mt-0.5">
                                  Funded: {pos.primaryFundingSourceLabel}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-3 text-right font-mono font-bold text-slate-900">
                          {pos.shares}
                        </td>

                        <td className="py-3.5 px-3 text-right font-mono text-slate-600">
                          ${pos.avgCostUSD.toFixed(2)}
                        </td>

                        <td className="py-3.5 px-3 text-right font-mono font-bold text-slate-900">
                          ${pos.currentPriceUSD.toFixed(2)}
                        </td>

                        <td className="py-3.5 px-3 text-right font-mono font-bold text-slate-900">
                          ${pos.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        <td className="py-3.5 px-3 text-right font-mono">
                          <div className={`font-bold ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPos ? '+' : ''}${pos.totalGainUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </div>
                          <div className={`text-[10px] font-semibold ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPos ? '+' : ''}{pos.totalGainPercent.toFixed(2)}%
                          </div>
                        </td>

                        <td className="py-3.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenTradeModal(pos.ticker, 'buy')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Plus className="w-3 h-3" />
                              <span>Buy More</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => onOpenTradeModal(pos.ticker, 'sell')}
                              className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-bold transition-colors cursor-pointer"
                            >
                              Sell
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Orders & Trade Receipts Subtab */}
      {activeSubTab === 'orders' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-4 sm:p-6 shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Time &amp; Ref</th>
                  <th className="py-2.5 px-3">Stock / Category</th>
                  <th className="py-2.5 px-3">Side &amp; Type</th>
                  <th className="py-2.5 px-3 text-right">Shares</th>
                  <th className="py-2.5 px-3 text-right">Filled Price</th>
                  <th className="py-2.5 px-3 text-right">Total Settled</th>
                  <th className="py-2.5 px-3">Trade P&amp;L / Cost Basis</th>
                  <th className="py-2.5 px-3">Payment Source</th>
                  <th className="py-2.5 px-3 text-right">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-xs">
                {orders.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                      No order execution history found.
                    </td>
                  </tr>
                ) : (
                  orders.map((order) => {
                    const isBuy = order.side === 'buy';
                    const isPersonal = order.isPersonalStock ?? (order.ticker === 'ALEX' || order.stockName.toLowerCase().includes('personal') || order.stockName.toLowerCase().includes('sovereign'));
                    const isBusiness = !isPersonal;
                    const gainLoss = order.realizedGainLossUSD;
                    const gainLossPct = order.realizedGainLossPercent;

                    return (
                      <tr key={order.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3">
                          <div className="font-mono font-bold text-slate-800">{order.timestamp}</div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {order.tradeSlipId || (order.id ? order.id.slice(-8) : 'ORDER')}
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5">
                            <span 
                              onClick={() => onSelectStockByTicker(order.ticker)}
                              className="font-mono font-bold text-slate-900 hover:text-amber-800 cursor-pointer"
                            >
                              ${order.ticker}
                            </span>
                            <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                              isPersonal ? 'bg-purple-50 text-purple-700 border-purple-200' : 'bg-indigo-50 text-indigo-700 border-indigo-200'
                            }`}>
                              {isPersonal ? 'Personal' : 'Corporate'}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-500 block truncate max-w-[130px]">
                            {order.stockName}
                          </span>
                        </td>

                        <td className="py-3 px-3">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                              isBuy
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : 'bg-rose-50 text-rose-800 border border-rose-200'
                            }`}
                          >
                            {order.side.toUpperCase()} • {order.orderType}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                          {order.shares}
                        </td>

                        <td className="py-3 px-3 text-right font-mono text-slate-700">
                          ${order.price.toFixed(2)}
                        </td>

                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                          ${order.totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* Trade P&L / Cost Basis */}
                        <td className="py-3 px-3 font-mono">
                          {order.side === 'sell' ? (
                            gainLoss !== undefined ? (
                              gainLoss >= 0 ? (
                                <div className="text-emerald-700 font-bold text-[11px]">
                                  +${gainLoss.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                  {gainLossPct !== undefined ? ` (+${gainLossPct.toFixed(1)}%)` : ''}
                                </div>
                              ) : (
                                <div className="text-rose-700 font-bold text-[11px]">
                                  -${Math.abs(gainLoss).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                  {gainLossPct !== undefined ? ` (${gainLossPct.toFixed(1)}%)` : ''}
                                </div>
                              )
                            ) : (
                              <div className="text-emerald-700 font-bold text-[11px]">
                                Realized on Sale
                              </div>
                            )
                          ) : (
                            <div className="text-slate-600 text-[11px]">
                              Basis: ${order.costBasisUSD ? order.costBasisUSD.toLocaleString(undefined, { minimumFractionDigits: 2 }) : `$${order.totalUSD.toFixed(2)}`}
                            </div>
                          )}
                        </td>

                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5">
                            {order.paymentSource?.type === 'bank_account' ? (
                              <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                            ) : order.paymentSource?.type === 'card' ? (
                              <CreditCard className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                            ) : (
                              <Wallet className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                            )}
                            <span className="text-[11px] text-slate-700 font-semibold truncate max-w-[150px]">
                              {order.paymentSource?.label || 'Wallet Balance'}
                            </span>
                          </div>
                        </td>

                        <td className="py-3 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => onViewTradeSlip && onViewTradeSlip(order)}
                            className="px-2.5 py-1 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-1"
                          >
                            <FileText className="w-3 h-3 text-slate-500" />
                            <span>Slip</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Types & Asset Allocation Breakdown Analysis Subtab */}
      {activeSubTab === 'allocation' && (
        <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-serif font-bold text-base text-slate-900 flex items-center gap-2">
              <PieChart className="w-4 h-4 text-amber-600" />
              <span>Types of Stocks Held: Sector &amp; Asset Class Analytics</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Comprehensive analysis of your portfolio diversification across all equity categories.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sectorAllocations.map((sec) => (
              <div
                key={sec.sector}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: sec.color }} />
                    <span className="font-bold text-xs text-slate-900">{sec.sector}</span>
                  </div>
                  <span className="font-mono font-bold text-xs text-slate-800 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                    {sec.percentage}%
                  </span>
                </div>

                <div className="space-y-1 text-xs">
                  <div className="flex items-center justify-between text-slate-500">
                    <span>Total Valuation</span>
                    <span className="font-mono font-bold text-slate-900">
                      ${sec.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-500">
                    <span>Positions Count</span>
                    <span className="font-mono text-slate-700">{sec.positionsCount} holdings</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-500">
                    <span>Sector Unrealized Profit</span>
                    <span className={`font-mono font-bold ${sec.totalGainUSD >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {sec.totalGainUSD >= 0 ? '+' : ''}${sec.totalGainUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} ({sec.totalGainPercent}%)
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
