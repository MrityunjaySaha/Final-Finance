import React, { useState, useRef, useEffect } from 'react';
import { StockItem, StockPricePoint } from '../../types/stocks';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Layers, 
  Maximize2,
  BarChart2,
  Eye,
  Calendar
} from 'lucide-react';

interface StockChartProps {
  stock: StockItem;
  activeTimeframe: '1D' | '1W' | '1M' | '1Y' | '5Y';
  onTimeframeChange: (tf: '1D' | '1W' | '1M' | '1Y' | '5Y') => void;
}

export const StockChart: React.FC<StockChartProps> = ({
  stock,
  activeTimeframe,
  onTimeframeChange,
}) => {
  const [chartType, setChartType] = useState<'area' | 'line' | 'candlestick'>('area');
  const [showSMA50, setShowSMA50] = useState(true);
  const [showVolume, setShowVolume] = useState(true);
  const [hoveredPoint, setHoveredPoint] = useState<StockPricePoint | null>(null);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 700, height: 360 });

  // Update dimensions with ResizeObserver
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0) {
          setDimensions({
            width: Math.max(300, entry.contentRect.width),
            height: window.innerWidth < 640 ? 280 : 360,
          });
        }
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  const historyPoints = stock.history[activeTimeframe] || stock.history['1D'];
  const prices = historyPoints.map((p) => p.price);
  const minPrice = Math.min(...prices) * 0.995;
  const maxPrice = Math.max(...prices) * 1.005;
  const priceRange = maxPrice - minPrice || 1;

  const isPositive = stock.changeUSD >= 0;
  const strokeColor = isPositive ? '#10b981' : '#f43f5e';
  const fillColor = isPositive ? 'rgba(16, 185, 129, 0.12)' : 'rgba(244, 63, 94, 0.12)';

  // Chart padding
  const paddingLeft = 12;
  const paddingRight = 60;
  const paddingTop = 25;
  const paddingBottom = showVolume ? 60 : 35;
  const plotWidth = dimensions.width - paddingLeft - paddingRight;
  const plotHeight = dimensions.height - paddingTop - paddingBottom;
  const volumeHeight = showVolume ? 35 : 0;

  // Convert points to SVG coords
  const points = historyPoints.map((p, i) => {
    const x = paddingLeft + (i / Math.max(1, historyPoints.length - 1)) * plotWidth;
    const y = paddingTop + (1 - (p.price - minPrice) / priceRange) * plotHeight;
    return { x, y, data: p, index: i };
  });

  const maxVolume = Math.max(...historyPoints.map((p) => p.volume || 1), 1);

  // SVG Area path
  const pathD = points.reduce((acc, curr, idx) => {
    return idx === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`;
  }, '');

  const areaD = points.length > 0
    ? `${pathD} L ${points[points.length - 1].x} ${paddingTop + plotHeight} L ${points[0].x} ${paddingTop + plotHeight} Z`
    : '';

  // Calculate 50 SMA points
  const smaPeriod = 5;
  const smaPoints: { x: number; y: number }[] = [];
  if (showSMA50 && points.length > smaPeriod) {
    for (let i = smaPeriod - 1; i < points.length; i++) {
      const slice = points.slice(i - smaPeriod + 1, i + 1);
      const avgPrice = slice.reduce((sum, pt) => sum + pt.data.price, 0) / smaPeriod;
      const y = paddingTop + (1 - (avgPrice - minPrice) / priceRange) * plotHeight;
      smaPoints.push({ x: points[i].x, y });
    }
  }

  const smaPathD = smaPoints.reduce((acc, curr, idx) => {
    return idx === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`;
  }, '');

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current || points.length === 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    
    // Find closest point
    let closestIndex = 0;
    let minDiff = Infinity;
    points.forEach((pt, idx) => {
      const diff = Math.abs(pt.x - mouseX);
      if (diff < minDiff) {
        minDiff = diff;
        closestIndex = idx;
      }
    });

    setHoverIndex(closestIndex);
    setHoveredPoint(points[closestIndex].data);
  };

  const handleMouseLeave = () => {
    setHoverIndex(null);
    setHoveredPoint(null);
  };

  const currentDisplayPoint = hoveredPoint || historyPoints[historyPoints.length - 1];
  const displayPrice = currentDisplayPoint ? currentDisplayPoint.price : stock.price;
  const initialPointPrice = historyPoints[0]?.price || stock.openPrice;
  const periodDiff = displayPrice - initialPointPrice;
  const periodPercent = initialPointPrice > 0 ? (periodDiff / initialPointPrice) * 100 : 0;

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-4 sm:p-6 shadow-sm">
      {/* Top Header & Live Quote Info */}
      <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 border border-slate-200">
              {stock.exchange}: {stock.ticker}
            </span>
            <span className="text-xs font-medium text-slate-500 hidden sm:inline">
              {stock.subSector || stock.sector}
            </span>
          </div>

          <h2 className="text-lg sm:text-2xl font-serif font-bold text-slate-900 mt-1">
            {stock.name}
          </h2>

          <div className="flex items-baseline gap-3 mt-1">
            <span className="text-2xl sm:text-3xl font-mono font-bold text-slate-900 tracking-tight">
              ${displayPrice.toFixed(2)}
            </span>
            <div className={`flex items-center gap-1 text-sm sm:text-base font-bold ${
              periodDiff >= 0 ? 'text-emerald-600' : 'text-rose-600'
            }`}>
              {periodDiff >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              <span>
                {periodDiff >= 0 ? '+' : ''}${periodDiff.toFixed(2)} ({periodDiff >= 0 ? '+' : ''}{periodPercent.toFixed(2)}%)
              </span>
              <span className="text-[11px] font-normal text-slate-400 ml-1">
                {hoveredPoint ? `(${hoveredPoint.time})` : `(${activeTimeframe})`}
              </span>
            </div>
          </div>
        </div>

        {/* Timeframe & Chart Style Toggles */}
        <div className="flex flex-col sm:items-end gap-2.5">
          {/* Timeframe selector pills */}
          <div className="flex items-center rounded-xl bg-slate-100 p-1 border border-slate-200">
            {(['1D', '1W', '1M', '1Y', '5Y'] as const).map((tf) => (
              <button
                key={tf}
                type="button"
                onClick={() => onTimeframeChange(tf)}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  activeTimeframe === tf
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          {/* Technical Controls (Indicators, SMA, Chart type) */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowSMA50(!showSMA50)}
              className={`text-[11px] font-medium px-2 py-1 rounded-lg border transition-colors cursor-pointer flex items-center gap-1 ${
                showSMA50
                  ? 'bg-amber-50 text-amber-900 border-amber-300 font-semibold'
                  : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
              }`}
              title="Toggle 50-period Moving Average"
            >
              <Activity className="w-3 h-3" />
              <span>SMA (50)</span>
            </button>

            <button
              type="button"
              onClick={() => setShowVolume(!showVolume)}
              className={`text-[11px] font-medium px-2 py-1 rounded-lg border transition-colors cursor-pointer flex items-center gap-1 ${
                showVolume
                  ? 'bg-indigo-50 text-indigo-900 border-indigo-300 font-semibold'
                  : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
              }`}
              title="Toggle Volume Subplot"
            >
              <BarChart2 className="w-3 h-3" />
              <span>Volume</span>
            </button>
          </div>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div 
        ref={containerRef} 
        className="relative w-full mt-4 select-none"
        style={{ height: `${dimensions.height}px` }}
      >
        <svg
          width={dimensions.width}
          height={dimensions.height}
          className="overflow-visible cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          <defs>
            <linearGradient id={`gradient-${stock.ticker}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={strokeColor} stopOpacity="0.28" />
              <stop offset="90%" stopColor={strokeColor} stopOpacity="0.01" />
            </linearGradient>
          </defs>

          {/* Horizontal Grid lines & Price Labels */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = paddingTop + ratio * plotHeight;
            const priceVal = maxPrice - ratio * priceRange;
            return (
              <g key={ratio}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={dimensions.width - paddingRight}
                  y2={y}
                  stroke="#e2e8f0"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={dimensions.width - paddingRight + 6}
                  y={y + 3.5}
                  fontSize="10"
                  fontFamily="monospace"
                  fill="#94a3b8"
                >
                  ${priceVal.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Volume bars (at bottom of chart) */}
          {showVolume &&
            points.map((pt, i) => {
              const v = pt.data.volume || 1;
              const barH = (v / maxVolume) * volumeHeight;
              const barY = dimensions.height - 20 - barH;
              const isUp = i > 0 ? pt.data.price >= points[i - 1].data.price : true;
              return (
                <rect
                  key={`vol-${i}`}
                  x={pt.x - 2}
                  y={barY}
                  width={Math.max(1.5, plotWidth / (points.length * 1.6))}
                  height={barH}
                  fill={isUp ? '#10b981' : '#f43f5e'}
                  opacity={hoverIndex === i ? 0.8 : 0.3}
                  rx="1"
                />
              );
            })}

          {/* Filled Gradient Area */}
          {chartType === 'area' && areaD && (
            <path
              d={areaD}
              fill={`url(#gradient-${stock.ticker})`}
            />
          )}

          {/* Primary Price Line */}
          <path
            d={pathD}
            fill="none"
            stroke={strokeColor}
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* 50 SMA Line */}
          {showSMA50 && smaPathD && (
            <path
              d={smaPathD}
              fill="none"
              stroke="#d97706"
              strokeWidth="1.6"
              strokeDasharray="4 2"
            />
          )}

          {/* Active Hover Crosshair Line & Indicator Dot */}
          {hoverIndex !== null && points[hoverIndex] && (
            <g>
              {/* Vertical Crosshair */}
              <line
                x1={points[hoverIndex].x}
                y1={paddingTop}
                x2={points[hoverIndex].x}
                y2={dimensions.height - 20}
                stroke="#64748b"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
              {/* Horizontal Crosshair */}
              <line
                x1={paddingLeft}
                y1={points[hoverIndex].y}
                x2={dimensions.width - paddingRight}
                y2={points[hoverIndex].y}
                stroke="#64748b"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
              {/* Center Dot */}
              <circle
                cx={points[hoverIndex].x}
                cy={points[hoverIndex].y}
                r="5"
                fill="#ffffff"
                stroke={strokeColor}
                strokeWidth="3"
                className="animate-pulse"
              />
            </g>
          )}

          {/* Time axis ticks */}
          {points
            .filter((_, idx) => idx % Math.max(1, Math.floor(points.length / 5)) === 0)
            .map((pt, i) => (
              <text
                key={`time-${i}`}
                x={pt.x}
                y={dimensions.height - 4}
                textAnchor="middle"
                fontSize="10"
                fontFamily="sans-serif"
                fill="#94a3b8"
              >
                {pt.data.time}
              </text>
            ))}
        </svg>

        {/* Hover Tooltip Box */}
        {hoverIndex !== null && points[hoverIndex] && (
          <div
            className="absolute pointer-events-none z-10 px-3 py-2 bg-slate-900/95 text-white text-xs rounded-xl shadow-lg border border-slate-700 backdrop-blur-sm transform -translate-x-1/2 -translate-y-full"
            style={{
              left: `${Math.min(Math.max(60, points[hoverIndex].x), dimensions.width - 60)}px`,
              top: `${Math.max(10, points[hoverIndex].y - 12)}px`,
            }}
          >
            <div className="font-mono font-bold text-sm text-amber-400">
              ${points[hoverIndex].data.price.toFixed(2)}
            </div>
            <div className="text-[10px] text-slate-300 flex items-center justify-between gap-3 mt-0.5">
              <span>{points[hoverIndex].data.time}</span>
              {points[hoverIndex].data.volume && (
                <span className="text-slate-400 font-mono">
                  Vol: {(points[hoverIndex].data.volume / 1000).toFixed(0)}k
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Quick Intraday Low / High Range Bar */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-3 text-xs">
        <div className="text-slate-500 flex items-center gap-1.5 font-mono">
          <span>Day Low</span>
          <span className="font-bold text-slate-800">${stock.low24h.toFixed(2)}</span>
        </div>

        <div className="flex-1 max-w-xs mx-2">
          <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden relative">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full"
              style={{
                width: `${Math.min(
                  100,
                  Math.max(
                    0,
                    ((stock.price - stock.low24h) / (stock.high24h - stock.low24h || 1)) * 100
                  )
                )}%`,
              }}
            />
          </div>
        </div>

        <div className="text-slate-500 flex items-center gap-1.5 font-mono">
          <span>Day High</span>
          <span className="font-bold text-slate-800">${stock.high24h.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
};
