import React, { useState, useEffect, useMemo, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  Store, 
  UtensilsCrossed, 
  ShoppingBag, 
  QrCode, 
  Receipt, 
  Coins, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Search, 
  RefreshCw,
  Clock,
  Copy,
  MapPin,
  ShoppingBasket,
  Globe,
  Image as ImageIcon,
  Video,
  Upload,
  AlertTriangle,
  Lock,
  ChevronDown,
  Boxes,
  PlusCircle,
  Star,
  Mail,
  Phone,
  Building2,
  Pencil,
  ShoppingCart,
  User,
  ArrowLeft,
  ScanBarcode,
  Barcode,
  Camera,
  FileText,
  X,
  Car
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import {
  recordLedgerTransaction,
  createLedgerItemFromPOSSale,
  createLedgerItemFromPOSCancellation,
  markLedgerItemReversedByReceipt,
  LEDGER_UPDATED_EVENT
} from '../utils/universalLedgerBridge';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { getStoredCustomCoins } from '../data/customCoinsData';
import { getStoredUserWallets } from '../data/defaultWallets';
import { applyCurrencyWalletDelta, getWalletCurrencyBalance } from '../utils/walletBalanceUpdater';
import { areUsersBlockedEitherWay } from '../services/socialService';

interface PointOfSaleViewProps {
  currentUser: AuthSession | null;
  onNavigateBack?: () => void;
  onViewQRCodes?: () => void;
}

export interface POSItemQRCode {
  type: 'one-time' | 'inventory';
  payload: string;
  createdAt: string;
  label?: string;
}

export interface CatalogItem {
  id: string;
  name: string;
  category: string;
  price: number;
  currency: string;
  acceptedCurrencies?: string[]; // Up to 5 Final Currency symbols
  type: 'retail' | 'restaurant';
  image?: string;
  photos?: string[];
  videos?: string[];
  stock?: number;
  barcode?: string;
  description?: string;
  qrCodes?: POSItemQRCode[];
}

interface CartItem extends CatalogItem {
  quantity: number;
  notes?: string;
}

interface SalesTransaction {
  id: string;
  receiptNumber: string;
  timestamp: string;
  mode: 'retail' | 'restaurant';
  txChannel?: 'in_store' | 'in_restaurant' | 'online';
  locationId?: string;
  tableOrRegister: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  tip: number;
  total: number;
  currency: string;
  paymentMethod: string;
  customerHandle?: string;
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
  fulfillmentType?: 'pickup' | 'delivery' | 'dine_in';
  deliveryAddress?: DeliveryAddress;
  status?: 'settled' | 'cancelled';
  cancelledAt?: string;
  ledgerEntryId?: string;
}

export interface MerchantLocation {
  id: string;
  name: string;
  type: 'retail' | 'restaurant';
  phone: string;
  email: string;
  address: string;
  cuisineOrCategory: string;
  tagline: string;
  prepTimeMinutes?: string;
  openingTime?: string;
  closingTime?: string;
  operatingDays?: string;
  isOpenForTakeout?: boolean;
  allowsDelivery?: boolean;
  deliveryFeeRate?: number;
  deliveryFeeCurrency?: string;
  deliveryFeeUnit?: 'mile' | 'km';
  ownerId: string;
  ownerHandle: string;
  ownerName: string;
}

export interface StoreReview {
  id: string;
  storeId: string;
  userId: string;
  userHandle: string;
  userName: string;
  rating: number; // 1 to 5
  comment: string;
  updatedAt: string;
}

export interface DeliveryAddress {
  id: string;
  label?: string;
  fullName: string;
  phone?: string;
  email?: string;
  address: string;
  isDefault?: boolean;
}

export interface TakeoutOrder {
  id: string;
  orderNumber: string;
  restaurantId: string;
  restaurantName: string;
  customerHandle: string;
  customerName: string;
  customerPhone?: string;
  customerEmail?: string;
  fulfillmentType?: 'pickup' | 'delivery';
  orderChannel?: 'in_store' | 'in_restaurant' | 'online';
  items: { item: CatalogItem; quantity: number }[];
  subtotal: number;
  tax: number;
  tip: number;
  total: number;
  currency: string;
  pickupTime: string;
  status: 'received' | 'in_kitchen' | 'ready_for_pickup' | 'completed' | 'cancelled';
  createdAt: string;
  notes?: string;
  deliveryAddress?: DeliveryAddress;
  deliveryFee?: number;
  deliveryFeeCurrency?: string;
  deliveryDistance?: number;
  deliveryDistanceUnit?: 'mile' | 'km';
  cancelledAt?: string;
  cancelledReason?: string;
  ledgerEntryId?: string;
  dispatchedToDriver?: boolean;
  dispatchedContractId?: string;
  driverAccepted?: boolean;
  driverAcceptedAt?: string;
  driverHandle?: string;
  driverName?: string;
  driverRatePerMile?: number;
  driverRateCurrency?: string;
  storeRatePerMile?: number;
  originalDeliveryFee?: number;
  originalDeliveryFeeCurrency?: string;
  updatedDeliveryFee?: number;
  originalTotal?: number;
  customerWalletUserId?: string;
  walletDeducted?: boolean;
  walletRefunded?: boolean;
}

export interface FinalCurrencyOption {
  symbol: string;
  name: string;
  icon: string;
  creatorHandle?: string;
  creatorName?: string;
  isDefault?: boolean;
}

export const BASE_FINAL_CURRENCIES: FinalCurrencyOption[] = [
  { symbol: 'AFNL', name: 'Final Admin Coin (Sovereign Standard)', icon: '⚡', isDefault: true, creatorHandle: 'protocol_admin' },
  { symbol: 'FNL-GOLD', name: 'Imperial Gold Bullion Coin', icon: '🏆', creatorHandle: 'zurich_vault' },
  { symbol: 'FNL-SILVER', name: 'Fine Silver Sovereign Coin', icon: '🪙', creatorHandle: 'sovereign_mint' },
  { symbol: 'FNL-SWISS', name: 'Zurich Reserve Sovereign Coin', icon: '🇨🇭', creatorHandle: 'swiss_freeport' },
  { symbol: 'FNL-TECH', name: 'AI & Quantum Compute Coin', icon: '💻', creatorHandle: 'alpha_compute' },
  { symbol: 'FNL-ALPHA', name: 'Alpha Liquid Reserve Coin', icon: '💎', creatorHandle: 'liquid_alpha' },
];

const LEGACY_MOCK_ITEM_IDS = new Set([
  'ret-1', 'ret-2', 'ret-3', 'ret-4', 'ret-5', 'ret-6',
  'res-1', 'res-2', 'res-3', 'res-4', 'res-5', 'res-6',
]);

const DEFAULT_RETAIL_BARCODE_BY_ID: Record<string, string> = {
  'ex-ret-1': '7612345000018',
  'ex-ret-2': '7612345000025',
  'ex-ret-3': '7612345000032',
  'ex-ret-4': '7612345000049',
  'ex-ret-5': '7612345000056',
};

const EXAMPLE_RETAIL_CATALOG_BY_LOC: Record<string, { instore: CatalogItem[]; online: CatalogItem[] }> = {
  'loc-retail-1': {
    instore: [
      {
        id: 'ex-ret-1',
        name: 'PAMP Suisse 10g Fine Gold Veriscan Bar',
        category: 'Bullion & Metals',
        price: 1480,
        currency: 'FNL-GOLD',
        acceptedCurrencies: ['FNL-GOLD', 'AFNL', 'FNL-SWISS'],
        type: 'retail',
        stock: 18,
        barcode: '7612345000018',
        image: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1610375461246-83df859d849d?w=500&auto=format&fit=crop&q=80'],
        description: '999.9 fine Swiss minted 10g gold bullion bar sealed in tamper-evident Veriscan assay packaging. Includes unique serial number verification, Zurich Freeport custody certificate, and instant cryptographic settlement in Final Currency.',
        qrCodes: [
          { type: 'inventory', payload: 'ff:pos:inventory:FNL-GOLD:1480:ex-ret-1:pamp_10g_gold', createdAt: '2026-03-01', label: 'PAMP 10g Gold Bar (Inventory Tag)' }
        ]
      }
    ],
    online: [
      {
        id: 'ex-ret-1',
        name: 'PAMP Suisse 10g Fine Gold Veriscan Bar',
        category: 'Bullion & Metals',
        price: 1480,
        currency: 'FNL-GOLD',
        acceptedCurrencies: ['FNL-GOLD', 'AFNL', 'FNL-SWISS'],
        type: 'retail',
        stock: 18,
        barcode: '7612345000018',
        image: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1610375461246-83df859d849d?w=500&auto=format&fit=crop&q=80'],
        description: '999.9 fine Swiss minted 10g gold bullion bar sealed in tamper-evident Veriscan assay packaging. Includes unique serial number verification, Zurich Freeport custody certificate, and instant cryptographic settlement in Final Currency.',
        qrCodes: [
          { type: 'inventory', payload: 'ff:pos:inventory:FNL-GOLD:1480:ex-ret-1:pamp_10g_gold', createdAt: '2026-03-01', label: 'PAMP 10g Gold Bar (Inventory Tag)' }
        ]
      },
      {
        id: 'ex-ret-2',
        name: 'Coldcard Q1 Air-Gapped Sovereign Signer',
        category: 'Hardware Security',
        price: 320,
        currency: 'FNL-TECH',
        acceptedCurrencies: ['FNL-TECH', 'AFNL'],
        type: 'retail',
        stock: 32,
        barcode: '7612345000025',
        image: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=500&auto=format&fit=crop&q=80'],
        description: 'Dedicated air-gapped cryptographic hardware signing device featuring dual secure elements, full QWERTY tactile keypad, QR-based PSBT signing, and tamper-evident polycarbonate casing for cold vault multi-currency custody.',
        qrCodes: [
          { type: 'one-time', payload: 'ff:pos:onetime:FNL-TECH:320:ex-ret-2:coldcard_q1', createdAt: '2026-03-01', label: 'Coldcard Q1 (One-Time Invoice)' }
        ]
      },
      {
        id: 'ex-ret-3',
        name: 'Alpine Titanium Mechanical Field Watch',
        category: 'Luxury Horology',
        price: 4250,
        currency: 'FNL-SWISS',
        acceptedCurrencies: ['FNL-SWISS', 'FNL-GOLD', 'AFNL'],
        type: 'retail',
        stock: 6,
        barcode: '7612345000032',
        image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=500&auto=format&fit=crop&q=80'],
        description: 'Grade-5 brushed titanium 39mm chronometer crafted in Geneva with anti-magnetic soft-iron inner cage, sapphire exhibition caseback, 72-hour power reserve, and numbered traveler presentation box.',
      }
    ]
  },
  'loc-retail-2': {
    instore: [
      {
        id: 'ex-ret-4',
        name: 'Air-Gapped Sovereign Keycard Enclave',
        category: 'Hardware Enclaves',
        price: 185,
        currency: 'FNL-TECH',
        acceptedCurrencies: ['FNL-TECH', 'AFNL'],
        type: 'retail',
        stock: 40,
        barcode: '7612345000049',
        image: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1591488320449-011701bb6704?w=500&auto=format&fit=crop&q=80'],
        description: 'NFC and optical QR dual-interface sovereign keycard enclave rated EAL6+, packaged in an anodized aluminum protective sleeve with seed backup titanium plate.',
      }
    ],
    online: [
      {
        id: 'ex-ret-4',
        name: 'Air-Gapped Sovereign Keycard Enclave',
        category: 'Hardware Enclaves',
        price: 185,
        currency: 'FNL-TECH',
        acceptedCurrencies: ['FNL-TECH', 'AFNL'],
        type: 'retail',
        stock: 40,
        barcode: '7612345000049',
        image: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1591488320449-011701bb6704?w=500&auto=format&fit=crop&q=80'],
        description: 'NFC and optical QR dual-interface sovereign keycard enclave rated EAL6+, packaged in an anodized aluminum protective sleeve with seed backup titanium plate.',
      },
      {
        id: 'ex-ret-5',
        name: 'Faraday Sovereign Vault Travel Sleeve',
        category: 'Security Gear',
        price: 95,
        currency: 'AFNL',
        acceptedCurrencies: ['AFNL', 'FNL-TECH'],
        type: 'retail',
        stock: 55,
        barcode: '7612345000056',
        image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=500&auto=format&fit=crop&q=80'],
        description: 'Ballistic nylon RF-shielded travel organizer lined with triple-layer nickel-copper Faraday fabric. Blocks cellular, Wi-Fi, Bluetooth, GPS, and RFID signals up to 90 dB attenuation.',
      }
    ]
  }
};

const EXAMPLE_RESTAURANT_CATALOG_BY_LOC: Record<string, { instore: CatalogItem[]; online: CatalogItem[] }> = {
  'loc-rest-1': {
    instore: [
      {
        id: 'ex-res-1',
        name: 'Binchotan Seared Miyazaki A5 Striploin',
        category: 'Entrees',
        price: 265,
        currency: 'AFNL',
        acceptedCurrencies: ['AFNL', 'FNL-SWISS'],
        type: 'restaurant',
        stock: 25,
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80'],
        description: '250g certified Miyazaki A5 Japanese Wagyu striploin seared over Kishu white binchotan charcoal, finished with aged Alpine herb compound butter, Maldon smoked sea salt, and blistered heirloom cherry tomatoes.',
        qrCodes: [
          { type: 'inventory', payload: 'ff:pos:inventory:AFNL:265:ex-res-1:miyazaki_striploin', createdAt: '2026-03-01', label: 'Miyazaki A5 Striploin (Inventory Tag)' }
        ]
      }
    ],
    online: [
      {
        id: 'ex-res-1',
        name: 'Binchotan Seared Miyazaki A5 Striploin',
        category: 'Entrees',
        price: 265,
        currency: 'AFNL',
        acceptedCurrencies: ['AFNL', 'FNL-SWISS'],
        type: 'restaurant',
        stock: 25,
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80'],
        description: '250g certified Miyazaki A5 Japanese Wagyu striploin seared over Kishu white binchotan charcoal, finished with aged Alpine herb compound butter, Maldon smoked sea salt, and blistered heirloom cherry tomatoes.',
        qrCodes: [
          { type: 'inventory', payload: 'ff:pos:inventory:AFNL:265:ex-res-1:miyazaki_striploin', createdAt: '2026-03-01', label: 'Miyazaki A5 Striploin (Inventory Tag)' }
        ]
      },
      {
        id: 'ex-res-2',
        name: 'Black Winter Truffle Gruyère Fondue',
        category: 'Appetizers',
        price: 145,
        currency: 'FNL-SWISS',
        acceptedCurrencies: ['FNL-SWISS', 'AFNL'],
        type: 'restaurant',
        stock: 30,
        image: 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?w=500&auto=format&fit=crop&q=80'],
        description: 'Aged 24-month cave-ripened Swiss Gruyère and Vacherin Fribourgeois folded with Périgord black truffle shavings and dry Valais white wine. Packed in insulated thermal pot with artisan sourdough cubes.',
      },
      {
        id: 'ex-res-3',
        name: 'Zurich Dark Chocolate & Hazelnut Mille-Feuille',
        category: 'Desserts',
        price: 55,
        currency: 'AFNL',
        acceptedCurrencies: ['AFNL', 'FNL-SWISS'],
        type: 'restaurant',
        stock: 20,
        image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=500&auto=format&fit=crop&q=80'],
        description: 'Caramelized flaky puff pastry layered with 72% single-origin Swiss dark chocolate ganache, roasted Piedmont hazelnut praline cream, and delicate gold-dusted cocoa tuile.',
      }
    ]
  },
  'loc-rest-2': {
    instore: [
      {
        id: 'ex-res-4',
        name: 'Kobe Wagyu & Hokkaido Uni Donburi',
        category: 'Signatures',
        price: 310,
        currency: 'AFNL',
        type: 'restaurant',
        stock: 15,
        image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=500&auto=format&fit=crop&q=80'],
        description: 'Torched A5 Kobe beef ribbons and fresh Hokkaido Bafun sea urchin over seasoned Koshihikari Akazu sushi rice, garnished with Ikura ikra pearls and freshly grated Shizuoka wasabi root.',
      }
    ],
    online: [
      {
        id: 'ex-res-4',
        name: 'Kobe Wagyu & Hokkaido Uni Donburi',
        category: 'Signatures',
        price: 310,
        currency: 'AFNL',
        type: 'restaurant',
        stock: 15,
        image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=500&auto=format&fit=crop&q=80'],
        description: 'Torched A5 Kobe beef ribbons and fresh Hokkaido Bafun sea urchin over seasoned Koshihikari Akazu sushi rice, garnished with Ikura ikra pearls and freshly grated Shizuoka wasabi root.',
      },
      {
        id: 'ex-res-5',
        name: 'Kyoto Matcha Yuzu Cheesecake',
        category: 'Desserts',
        price: 48,
        currency: 'FNL-GOLD',
        type: 'restaurant',
        stock: 28,
        image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500&auto=format&fit=crop&q=80',
        photos: ['https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500&auto=format&fit=crop&q=80'],
        description: 'Velvety Uji ceremonial matcha baked Basque cheesecake infused with aromatic Kochi yuzu zest, served chilled with house-made black sesame shortbread crumble.',
      }
    ]
  }
};


const RETAIL_CATEGORY_PRESETS = [
  'Bullion & Metals',
  'Electronics',
  'Luxury Horology',
  'Hardware Nodes',
  'Apparel & Accessories',
  'Jewelry & Gems',
  'Collectibles',
  'Home & Living',
  'Health & Wellness',
  'General Retail'
];

const RESTAURANT_CATEGORY_PRESETS = [
  'Appetizers',
  'Entrees',
  'Steaks & Grill',
  'Seafood',
  'Pasta & Risotto',
  'Soups & Salads',
  'Desserts',
  'Beverages & Wine',
  'Cocktails & Bar',
  'Sides & Extras'
];

const DEFAULT_LOCATIONS: MerchantLocation[] = [
  {
    id: 'loc-retail-1',
    name: 'Zurich Freeport Sovereign Bullion & Electronics',
    type: 'retail',
    phone: '+41 44 211 4050',
    email: 'freeport.retail@sovereign.ch',
    address: 'Zurich Freeport Depository Vault 4B, 8048 Zürich',
    cuisineOrCategory: 'Bullion, Horology & Hardware',
    tagline: 'High-value sovereign hardware & precious bullion settlement in Final Currency.',
    deliveryFeeRate: 2.5,
    deliveryFeeCurrency: 'AFNL',
    deliveryFeeUnit: 'mile',
    ownerId: 'merchant',
    ownerHandle: 'sovereign_merchant',
    ownerName: 'Sovereign Merchant'
  },
  {
    id: 'loc-rest-1',
    name: "Ranma's Sovereign Dining",
    type: 'restaurant',
    phone: '+41 44 211 4055',
    email: 'ranma.dining@sovereign.ch',
    address: 'Zurich Freeport Terminal 4B, Sovereign District',
    cuisineOrCategory: 'Swiss Haute Cuisine & Steaks',
    tagline: 'Online Takeout & Final Currency Direct Clearing',
    prepTimeMinutes: '15-25',
    openingTime: '10:00',
    closingTime: '22:00',
    operatingDays: 'Daily (Mon - Sun)',
    isOpenForTakeout: true,
    allowsDelivery: true,
    deliveryFeeRate: 2.5,
    deliveryFeeCurrency: 'AFNL',
    deliveryFeeUnit: 'mile',
    ownerId: 'merchant',
    ownerHandle: 'sovereign_merchant',
    ownerName: 'Sovereign Merchant'
  },
  {
    id: 'loc-rest-2',
    name: 'Neo Tokyo Sovereign Teppanyaki',
    type: 'restaurant',
    phone: '+81 3 5550 1900',
    email: 'neotokyo@sovereign.jp',
    address: 'Neo Tokyo Tower Floor 42, Sovereign District',
    cuisineOrCategory: 'Japanese Wagyu & Haute Teppan',
    tagline: 'Private Dining, A5 Wagyu & Cryptographic Reserve Barter',
    prepTimeMinutes: '20-30',
    openingTime: '11:00',
    closingTime: '23:00',
    operatingDays: 'Daily (Mon - Sun)',
    isOpenForTakeout: true,
    allowsDelivery: true,
    deliveryFeeRate: 3,
    deliveryFeeCurrency: 'AFNL',
    deliveryFeeUnit: 'mile',
    ownerId: 'satoshi_nakamoto',
    ownerHandle: 'satoshi_nakamoto',
    ownerName: 'Satoshi Nakamoto'
  },
  {
    id: 'loc-retail-2',
    name: 'Tokyo Cybernetic Vault Hardware',
    type: 'retail',
    phone: '+81 3 5550 8820',
    email: 'hardware@tokyovault.jp',
    address: 'Akihabara Tech District Level 9, Tokyo',
    cuisineOrCategory: 'Hardware Nodes & Enclaves',
    tagline: 'Quantum hardware modules and air-gapped ledger devices.',
    deliveryFeeRate: 1.5,
    deliveryFeeCurrency: 'FNL-TECH',
    deliveryFeeUnit: 'km',
    ownerId: 'satoshi_nakamoto',
    ownerHandle: 'satoshi_nakamoto',
    ownerName: 'Satoshi Nakamoto'
  }
];

const DEFAULT_REVIEWS: StoreReview[] = [
  {
    id: 'rev-1',
    storeId: 'loc-rest-2',
    userId: 'user_marcus',
    userHandle: 'marcus_vance',
    userName: 'Dr. Marcus Vance',
    rating: 5,
    comment: 'Exceptional A5 Kobe beef. Unmatched private teppanyaki and instant Final Currency clearing.',
    updatedAt: '2026-02-15'
  },
  {
    id: 'rev-2',
    storeId: 'loc-rest-1',
    userId: 'user_sarah',
    userHandle: 'sarah_lin',
    userName: 'Dr. Sarah Lin',
    rating: 5,
    comment: 'The Perigord truffle fondue is outstanding. Flawless sovereign reserve dining experience.',
    updatedAt: '2026-02-18'
  },
  {
    id: 'rev-3',
    storeId: 'loc-retail-1',
    userId: 'user_satoshi',
    userHandle: 'satoshi_nakamoto',
    userName: 'Satoshi Nakamoto',
    rating: 5,
    comment: 'Hallmarked gold bars certified on-chain. Air-gapped terminal transaction completed smoothly.',
    updatedAt: '2026-02-19'
  }
];

const DEFAULT_TABLES = [
  'Table 1 (VIP)', 
  'Table 2', 
  'Table 3', 
  'Table 4 (Patio)', 
  'Bar Counter', 
  'Takeout Counter', 
  'Delivery Node'
];

function formatTime12h(timeStr: string): string {
  if (!timeStr) return '';
  const parts = timeStr.split(':');
  if (parts.length < 2) return timeStr;
  const hours = parseInt(parts[0], 10);
  const mins = parts[1];
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const h12 = hours % 12 || 12;
  return `${h12}:${mins} ${ampm}`;
}

function checkLocationOpenStatus(loc: MerchantLocation): {
  isOpen: boolean;
  statusText: string;
  badgeClass: string;
} {
  if (loc.type === 'retail') {
    return {
      isOpen: true,
      statusText: 'Open for Orders',
      badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200'
    };
  }

  if (loc.isOpenForTakeout === false) {
    return {
      isOpen: false,
      statusText: 'Kitchen Closed by Owner',
      badgeClass: 'bg-rose-50 text-rose-700 border-rose-200'
    };
  }

  const openTime = loc.openingTime || '10:00';
  const closeTime = loc.closingTime || '22:00';

  const [openH, openM] = openTime.split(':').map(Number);
  const [closeH, closeM] = closeTime.split(':').map(Number);

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const openMinutes = openH * 60 + (openM || 0);
  const closeMinutes = closeH * 60 + (closeM || 0);

  let isCurrentlyOpen = false;
  if (openMinutes <= closeMinutes) {
    isCurrentlyOpen = currentMinutes >= openMinutes && currentMinutes <= closeMinutes;
  } else {
    isCurrentlyOpen = currentMinutes >= openMinutes || currentMinutes <= closeMinutes;
  }

  if (isCurrentlyOpen) {
    return {
      isOpen: true,
      statusText: `Open Now • Closes at ${formatTime12h(closeTime)}`,
      badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200'
    };
  } else {
    return {
      isOpen: false,
      statusText: `Closed • Opens at ${formatTime12h(openTime)}`,
      badgeClass: 'bg-amber-50 text-amber-900 border-amber-300'
    };
  }
}

export const PointOfSaleView: React.FC<PointOfSaleViewProps> = ({
  currentUser
}) => {
  const merchantId = currentUser?.id || currentUser?.uid || 'merchant';
  const ledgerUserId = currentUser?.id || 'guest';

  // Multi-location State (Up to 10 stores / restaurants per user with separate details)
  const [locations, setLocations] = useState<MerchantLocation[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_merchant_locations');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_LOCATIONS;
  });

  const [activeLocationId, setActiveLocationId] = useState<string>(() => {
    return DEFAULT_LOCATIONS[0].id;
  });

  const activeLocation = useMemo(() => {
    return locations.find(l => l.id === activeLocationId) || locations[0] || DEFAULT_LOCATIONS[0];
  }, [locations, activeLocationId]);

  // TOP-LEVEL 3 TABS:
  // 1. "directory": Look up food / retail products, restaurants (their menus), retail stores & inventories
  // 2. "retail": Retail Store POS, Inventory, Add Items, Sales Log
  // 3. "restaurant": Restaurant POS & Tables, In-House Menu, Online Menu, Takeout Orders, Sales Log
  const [mainTab, setMainTab] = useState<'directory' | 'retail' | 'restaurant'>('directory');

  // Sub-tabs for Retail tab (including Online Store for each retail location)
  const [retailSubTab, setRetailSubTab] = useState<'checkout' | 'add_item' | 'inventory_dir' | 'online_store' | 'history'>('checkout');

  // Sub-tabs for Restaurant tab
  const [restaurantSubTab, setRestaurantSubTab] = useState<'checkout' | 'add_item' | 'restaurant_menu' | 'online_menu' | 'takeout_orders' | 'history'>('checkout');

  // Customer Reviews State (Strictly 1 review per user per location, editable)
  const [reviewsList, setReviewsList] = useState<StoreReview[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_store_reviews');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_REVIEWS;
  });

  // Table Service State & Per-Location Merchant Cart/Currency
  const [selectedTable, setSelectedTable] = useState<string>('Table 1 (VIP)');
  const [merchantCartsByLoc, setMerchantCartsByLoc] = useState<Record<string, CartItem[]>>({});
  const merchantCartKey = activeLocation.type === 'restaurant' ? `${activeLocationId}::${selectedTable}` : activeLocationId;
  const cart = useMemo(() => merchantCartsByLoc[merchantCartKey] || [], [merchantCartsByLoc, merchantCartKey]);
  const setCart = (updater: CartItem[] | ((prev: CartItem[]) => CartItem[])) => {
    setMerchantCartsByLoc(prevMap => {
      const current = prevMap[merchantCartKey] || [];
      const next = typeof updater === 'function' ? updater(current) : updater;
      return { ...prevMap, [merchantCartKey]: next };
    });
  };
  const [tipPercentage, setTipPercentage] = useState<number>(15);
  const [customTip, setCustomTip] = useState<string>('');
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [merchantCurrencyByLoc, setMerchantCurrencyByLoc] = useState<Record<string, string>>({});
  const [customerQrInput, setCustomerQrInput] = useState<string>('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [transactionsHistory, setTransactionsHistory] = useState<SalesTransaction[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_pos_transactions_${merchantId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  // Searchable Currency Modal State
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);
  const [currencyModalSearch, setCurrencyModalSearch] = useState('');
  const [currencyTarget, setCurrencyTarget] = useState<
    | 'inventory_add'
    | 'checkout'
    | 'takeout'
    | 'online_menu_add'
    | 'online_retail_add'
    | 'loc_checkout'
    | 'retail_delivery_fee'
    | 'restaurant_delivery_fee'
    | 'new_loc_delivery_fee'
    | 'item_edit_currencies'
  >('checkout');
  const [currencyTargetLocId, setCurrencyTargetLocId] = useState<string | null>(null);

  // Dynamic Final Currencies Directory (Standard + Peer/User Custom Final Coins)
  const [allFinalCurrencies] = useState<FinalCurrencyOption[]>(() => {
    try {
      const stored = getStoredCustomCoins();
      const customFinals: FinalCurrencyOption[] = stored
        .filter(c => c.coinType === 'final_coin' && !BASE_FINAL_CURRENCIES.some(b => b.symbol === c.symbol))
        .map(c => ({
          symbol: c.symbol,
          name: c.name,
          icon: c.iconSymbol || '⚡',
          creatorHandle: c.creatorHandle,
          creatorName: c.creatorName,
          isDefault: false
        }));
      return [...BASE_FINAL_CURRENCIES, ...customFinals];
    } catch {
      return BASE_FINAL_CURRENCIES;
    }
  });

  const getItemAcceptedCurrencies = (item: CatalogItem): string[] => {
    const raw = item.acceptedCurrencies && item.acceptedCurrencies.length > 0
      ? item.acceptedCurrencies
      : [item.currency];
    const deduped = Array.from(new Set(raw.filter(Boolean)));
    if (!deduped.includes(item.currency) && item.currency) {
      deduped.unshift(item.currency);
    }
    return deduped.slice(0, 5);
  };

  const getRelevantCurrenciesForItems = (items: CatalogItem[], fallbackLocId?: string): FinalCurrencyOption[] => {
    let symbols: string[] = [];
    if (items.length === 0) {
      const fallbackSym = fallbackLocId ? getDefaultLocationCurrency(fallbackLocId) : 'AFNL';
      symbols = [fallbackSym];
    } else {
      const itemSets = items.map(it => getItemAcceptedCurrencies(it));
      const intersection = itemSets[0].filter(sym => itemSets.every(list => list.includes(sym)));
      symbols = intersection.length > 0
        ? intersection
        : Array.from(new Set(itemSets.flat()));
    }
    return symbols.map(sym => {
      const match = allFinalCurrencies.find(c => c.symbol === sym);
      return match || { symbol: sym, name: `${sym} Final Currency`, icon: '⚡' };
    });
  };

  const toggleCurrencyInList = (current: string[], symbol: string, max: number = 5): string[] => {
    if (current.includes(symbol)) {
      if (current.length <= 1) return current; // Keep at least 1 currency selected
      return current.filter(s => s !== symbol);
    }
    if (current.length >= max) {
      dispatchGlobalNotification({
        title: `Max ${max} Final Currencies`,
        description: `Each product or dish can accept up to ${max} Final Currency types.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return current;
    }
    return [...current, symbol];
  };

  // Tables List Per Restaurant (Up to 100 tables per restaurant)
  const [tablesByLoc, setTablesByLoc] = useState<Record<string, string[]>>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_pos_tables_map_${merchantId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });

  const tablesList = useMemo(() => {
    return tablesByLoc[activeLocationId] || DEFAULT_TABLES;
  }, [tablesByLoc, activeLocationId]);

  const [isAddTableModalOpen, setIsAddTableModalOpen] = useState(false);
  const [newTableName, setNewTableName] = useState('');
  const [newTableNumber, setNewTableNumber] = useState('');
  const [tableError, setTableError] = useState('');

  // Item QR Code & Media Modal State (Centered & Well-fitted)
  const [selectedItemForModal, setSelectedItemForModal] = useState<CatalogItem | null>(null);
  const [selectedItemScope, setSelectedItemScope] = useState<'instore' | 'online'>('instore');
  const [activeQrPreview, setActiveQrPreview] = useState<POSItemQRCode | null>(null);
  const [modalMediaUrl, setModalMediaUrl] = useState('');
  const modalFileInputRef = useRef<HTMLInputElement>(null);

  // Per-Location Catalog Maps (Separate In-Store Inventory/Menu AND Online Store/Menu for EACH store/restaurant)
  const filterLegacySeedItems = (items: CatalogItem[]): CatalogItem[] =>
    Array.isArray(items) ? items.filter(item => item && !LEGACY_MOCK_ITEM_IDS.has(item.id)) : [];

  const getInitialRetailForLoc = (locId: string): CatalogItem[] => {
    const example = EXAMPLE_RETAIL_CATALOG_BY_LOC[locId]?.instore || [];
    try {
      const saved = localStorage.getItem(`final_finance_pos_retail_cat_${merchantId}_${locId}`);
      if (saved) {
        const parsed = filterLegacySeedItems(JSON.parse(saved));
        if (parsed.length > 0 || localStorage.getItem(`final_finance_pos_ex_v2_${merchantId}_${locId}`)) {
          return parsed;
        }
      }
      if (example.length > 0) {
        localStorage.setItem(`final_finance_pos_ex_v2_${merchantId}_${locId}`, '1');
        return example;
      }
    } catch {}
    return example;
  };

  const getInitialOnlineRetailForLoc = (locId: string): CatalogItem[] => {
    const example = EXAMPLE_RETAIL_CATALOG_BY_LOC[locId]?.online || [];
    try {
      const saved = localStorage.getItem(`final_finance_online_retail_${merchantId}_${locId}`);
      if (saved) {
        const parsed = filterLegacySeedItems(JSON.parse(saved));
        if (parsed.length > 0 || localStorage.getItem(`final_finance_pos_ex_onl_ret_v2_${merchantId}_${locId}`)) {
          return parsed;
        }
      }
      if (example.length > 0) {
        localStorage.setItem(`final_finance_pos_ex_onl_ret_v2_${merchantId}_${locId}`, '1');
        return example;
      }
    } catch {}
    return example;
  };

  const getInitialRestaurantForLoc = (locId: string): CatalogItem[] => {
    const example = EXAMPLE_RESTAURANT_CATALOG_BY_LOC[locId]?.instore || [];
    try {
      const saved = localStorage.getItem(`final_finance_pos_restaurant_cat_${merchantId}_${locId}`);
      if (saved) {
        const parsed = filterLegacySeedItems(JSON.parse(saved));
        if (parsed.length > 0 || localStorage.getItem(`final_finance_pos_ex_res_v2_${merchantId}_${locId}`)) {
          return parsed;
        }
      }
      if (example.length > 0) {
        localStorage.setItem(`final_finance_pos_ex_res_v2_${merchantId}_${locId}`, '1');
        return example;
      }
    } catch {}
    return example;
  };

  const getInitialOnlineMenuForLoc = (locId: string): CatalogItem[] => {
    const example = EXAMPLE_RESTAURANT_CATALOG_BY_LOC[locId]?.online || [];
    try {
      const saved = localStorage.getItem(`final_finance_online_dishes_${merchantId}_${locId}`);
      if (saved) {
        const parsed = filterLegacySeedItems(JSON.parse(saved));
        if (parsed.length > 0 || localStorage.getItem(`final_finance_pos_ex_onl_res_v2_${merchantId}_${locId}`)) {
          return parsed;
        }
      }
      if (example.length > 0) {
        localStorage.setItem(`final_finance_pos_ex_onl_res_v2_${merchantId}_${locId}`, '1');
        return example;
      }
    } catch {}
    return example;
  };

  const [retailInventoriesByLoc, setRetailInventoriesByLoc] = useState<Record<string, CatalogItem[]>>(() => {
    const map: Record<string, CatalogItem[]> = {};
    DEFAULT_LOCATIONS.filter(l => l.type === 'retail').forEach(l => {
      map[l.id] = getInitialRetailForLoc(l.id);
    });
    return map;
  });

  const [onlineRetailByLoc, setOnlineRetailByLoc] = useState<Record<string, CatalogItem[]>>(() => {
    const map: Record<string, CatalogItem[]> = {};
    DEFAULT_LOCATIONS.filter(l => l.type === 'retail').forEach(l => {
      map[l.id] = getInitialOnlineRetailForLoc(l.id);
    });
    return map;
  });

  const [restaurantMenusByLoc, setRestaurantMenusByLoc] = useState<Record<string, CatalogItem[]>>(() => {
    const map: Record<string, CatalogItem[]> = {};
    DEFAULT_LOCATIONS.filter(l => l.type === 'restaurant').forEach(l => {
      map[l.id] = getInitialRestaurantForLoc(l.id);
    });
    return map;
  });

  const [onlineMenusByLoc, setOnlineMenusByLoc] = useState<Record<string, CatalogItem[]>>(() => {
    const map: Record<string, CatalogItem[]> = {};
    DEFAULT_LOCATIONS.filter(l => l.type === 'restaurant').forEach(l => {
      map[l.id] = getInitialOnlineMenuForLoc(l.id);
    });
    return map;
  });

  // Ensure any dynamically loaded or created locations have initialized map entries
  useEffect(() => {
    setRetailInventoriesByLoc(prev => {
      let changed = false;
      const next = { ...prev };
      locations.filter(l => l.type === 'retail').forEach(l => {
        if (!(l.id in next)) {
          next[l.id] = getInitialRetailForLoc(l.id);
          changed = true;
        }
      });
      return changed ? next : prev;
    });
    setOnlineRetailByLoc(prev => {
      let changed = false;
      const next = { ...prev };
      locations.filter(l => l.type === 'retail').forEach(l => {
        if (!(l.id in next)) {
          next[l.id] = getInitialOnlineRetailForLoc(l.id);
          changed = true;
        }
      });
      return changed ? next : prev;
    });
    setRestaurantMenusByLoc(prev => {
      let changed = false;
      const next = { ...prev };
      locations.filter(l => l.type === 'restaurant').forEach(l => {
        if (!(l.id in next)) {
          next[l.id] = getInitialRestaurantForLoc(l.id);
          changed = true;
        }
      });
      return changed ? next : prev;
    });
    setOnlineMenusByLoc(prev => {
      let changed = false;
      const next = { ...prev };
      locations.filter(l => l.type === 'restaurant').forEach(l => {
        if (!(l.id in next)) {
          next[l.id] = getInitialOnlineMenuForLoc(l.id);
          changed = true;
        }
      });
      return changed ? next : prev;
    });
  }, [locations]);

  // Active Location Derived Catalogs (reacts immediately when switching locations!)
  const retailCatalog = useMemo(() => {
    return retailInventoriesByLoc[activeLocationId] ?? getInitialRetailForLoc(activeLocationId);
  }, [retailInventoriesByLoc, activeLocationId]);

  const onlineRetailCatalog = useMemo(() => {
    return onlineRetailByLoc[activeLocationId] ?? getInitialOnlineRetailForLoc(activeLocationId);
  }, [onlineRetailByLoc, activeLocationId]);

  const restaurantCatalog = useMemo(() => {
    return restaurantMenusByLoc[activeLocationId] ?? getInitialRestaurantForLoc(activeLocationId);
  }, [restaurantMenusByLoc, activeLocationId]);

  const onlineMenuDishes = useMemo(() => {
    return onlineMenusByLoc[activeLocationId] ?? getInitialOnlineMenuForLoc(activeLocationId);
  }, [onlineMenusByLoc, activeLocationId]);

  // Dedicated "Add Item to Inventory / Menu" Form State
  const [newItemTitle, setNewItemTitle] = useState('');
  const [newItemType, setNewItemType] = useState('');
  const [newItemCost, setNewItemCost] = useState('');
  const [newItemCurrencies, setNewItemCurrencies] = useState<string[]>(['AFNL']);
  const newItemCurrency = newItemCurrencies[0] || 'AFNL';
  const [newItemStock, setNewItemStock] = useState('25');
  const [newItemBarcode, setNewItemBarcode] = useState('');
  const [newItemDescription, setNewItemDescription] = useState('');
  const [newItemPhotos, setNewItemPhotos] = useState<string[]>([]);
  const [newItemVideos, setNewItemVideos] = useState<string[]>([]);
  const [newItemAddOneTimeQR, setNewItemAddOneTimeQR] = useState(true);
  const [newItemAddInventoryQR, setNewItemAddInventoryQR] = useState(true);
  const [newItemIncludeInStore, setNewItemIncludeInStore] = useState(true);
  const [newItemIncludeOnline, setNewItemIncludeOnline] = useState(true);
  const [newItemMediaUrlInput, setNewItemMediaUrlInput] = useState('');
  const inventoryFileInputRef = useRef<HTMLInputElement>(null);

  // Online Retail Store Add Item Form State (in Retail -> Online Store tab)
  const [onlineRetailTitle, setOnlineRetailTitle] = useState('');
  const [onlineRetailCategory, setOnlineRetailCategory] = useState('Electronics');
  const [onlineRetailPrice, setOnlineRetailPrice] = useState('');
  const [onlineRetailCurrencies, setOnlineRetailCurrencies] = useState<string[]>(['AFNL']);
  const onlineRetailCurrency = onlineRetailCurrencies[0] || 'AFNL';
  const [onlineRetailStock, setOnlineRetailStock] = useState('25');
  const [onlineRetailBarcode, setOnlineRetailBarcode] = useState('');
  const [onlineRetailDescription, setOnlineRetailDescription] = useState('');
  const [onlineRetailPhotos, setOnlineRetailPhotos] = useState<string[]>([]);
  const [onlineRetailVideos, setOnlineRetailVideos] = useState<string[]>([]);
  const [onlineRetailMediaUrl, setOnlineRetailMediaUrl] = useState('');
  const onlineRetailFileInputRef = useRef<HTMLInputElement>(null);

  // Create Location Modal State (Up to 10 retail stores & up to 10 restaurants)
  const [isAddLocationModalOpen, setIsAddLocationModalOpen] = useState(false);
  const [newLocName, setNewLocName] = useState('');
  const [newLocType, setNewLocType] = useState<'retail' | 'restaurant'>('retail');
  const [newLocPhone, setNewLocPhone] = useState('');
  const [newLocEmail, setNewLocEmail] = useState('');
  const [newLocAddress, setNewLocAddress] = useState('');
  const [newLocCategory, setNewLocCategory] = useState('');
  const [newLocTagline, setNewLocTagline] = useState('');
  const [newLocAllowsDelivery, setNewLocAllowsDelivery] = useState(false);
  const [newLocDeliveryFeeRate, setNewLocDeliveryFeeRate] = useState('2');
  const [newLocDeliveryFeeCurrency, setNewLocDeliveryFeeCurrency] = useState('AFNL');
  const [newLocDeliveryFeeUnit, setNewLocDeliveryFeeUnit] = useState<'mile' | 'km'>('mile');

  // Online Dish add form state (in Restaurant -> Online Menu tab)
  const [onlineDishTitle, setOnlineDishTitle] = useState('');
  const [onlineDishCategory, setOnlineDishCategory] = useState('Entrees');
  const [onlineDishPrice, setOnlineDishPrice] = useState('');
  const [onlineDishCurrencies, setOnlineDishCurrencies] = useState<string[]>(['AFNL']);
  const onlineDishCurrency = onlineDishCurrencies[0] || 'AFNL';
  const [onlineDishDescription, setOnlineDishDescription] = useState('');
  const [onlineDishPhotos, setOnlineDishPhotos] = useState<string[]>([]);
  const [onlineDishVideos, setOnlineDishVideos] = useState<string[]>([]);
  const [onlineDishMediaUrl, setOnlineDishMediaUrl] = useState('');
  const [onlineDishAddOneTimeQR, setOnlineDishAddOneTimeQR] = useState(true);
  const [onlineDishAddInventoryQR, setOnlineDishAddInventoryQR] = useState(true);
  const onlineDishFileInputRef = useRef<HTMLInputElement>(null);

  // Incoming Takeout Orders (Pre-populated with multiple retail & restaurant online examples)
  const [takeoutOrders, setTakeoutOrders] = useState<TakeoutOrder[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_takeout_orders');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    const nowIso = new Date().toISOString();
    const defaultExamples: TakeoutOrder[] = [
      {
        id: 'ord-ex-ret-1',
        orderNumber: 'ORD-RET-884210',
        restaurantId: 'loc-retail-1',
        restaurantName: 'Zurich Freeport Sovereign Bullion & Electronics',
        customerHandle: currentUser?.id || 'guest',
        customerName: currentUser?.name || 'Sovereign Explorer',
        customerPhone: '+41 44 211 4050',
        customerEmail: currentUser?.email || 'explorer@sovereign.ch',
        fulfillmentType: 'delivery',
        orderChannel: 'online',
        items: [
          {
            item: {
              id: 'ex-ret-1',
              name: 'PAMP Suisse 10g Fine Gold Veriscan Bar',
              category: 'Bullion & Metals',
              price: 1480,
              currency: 'FNL-GOLD',
              type: 'retail',
              image: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?w=500&auto=format&fit=crop&q=80'
            },
            quantity: 1
          }
        ],
        subtotal: 1480,
        tax: 0,
        tip: 0,
        total: 1490,
        currency: 'FNL-GOLD',
        pickupTime: 'Delivery to Zurich Freeport Vault 4B',
        status: 'received', // Retail order in 'received' status - cancellable before retail owner accepts/finalizes!
        createdAt: nowIso,
        deliveryAddress: {
          id: 'addr-ex-1',
          fullName: currentUser?.name || 'Sovereign Explorer',
          address: 'Zurich Freeport Vault 4B, 8048 Zürich',
          phone: '+41 44 211 4050'
        },
        deliveryFee: 10,
        deliveryFeeCurrency: 'FNL-GOLD',
        deliveryDistance: 4,
        deliveryDistanceUnit: 'mile'
      },
      {
        id: 'ord-ex-ret-2',
        orderNumber: 'ORD-RET-773105',
        restaurantId: 'loc-retail-1',
        restaurantName: 'Zurich Freeport Sovereign Bullion & Electronics',
        customerHandle: currentUser?.id || 'guest',
        customerName: currentUser?.name || 'Sovereign Explorer',
        customerPhone: '+41 44 211 4050',
        fulfillmentType: 'pickup',
        orderChannel: 'online',
        items: [
          {
            item: {
              id: 'ex-ret-2',
              name: 'Coldcard Q1 Air-Gapped Sovereign Signer',
              category: 'Hardware Security',
              price: 320,
              currency: 'FNL-TECH',
              type: 'retail',
              image: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=500&auto=format&fit=crop&q=80'
            },
            quantity: 1
          }
        ],
        subtotal: 320,
        tax: 0,
        tip: 0,
        total: 320,
        currency: 'FNL-TECH',
        pickupTime: 'In-Store Pickup — ASAP',
        status: 'in_kitchen', // Accepted / Preparing by retail owner
        createdAt: nowIso
      },
      {
        id: 'ord-ex-res-1',
        orderNumber: 'ORD-TK-554109',
        restaurantId: 'loc-rest-1',
        restaurantName: "Ranma's Sovereign Dining",
        customerHandle: currentUser?.id || 'guest',
        customerName: currentUser?.name || 'Sovereign Explorer',
        customerPhone: '+41 44 211 4055',
        fulfillmentType: 'delivery',
        orderChannel: 'online',
        items: [
          {
            item: {
              id: 'ex-res-1',
              name: 'Binchotan Seared Miyazaki A5 Striploin',
              category: 'Entrees',
              price: 265,
              currency: 'AFNL',
              type: 'restaurant',
              image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&auto=format&fit=crop&q=80'
            },
            quantity: 1
          }
        ],
        subtotal: 265,
        tax: 0,
        tip: 25,
        total: 295,
        currency: 'AFNL',
        pickupTime: 'Delivery in 25 min',
        status: 'received', // Restaurant order within 10-minute cancellation window with countdown clock
        createdAt: nowIso,
        deliveryAddress: {
          id: 'addr-ex-1',
          fullName: currentUser?.name || 'Sovereign Explorer',
          address: 'Zurich Freeport Vault 4B, 8048 Zürich',
          phone: '+41 44 211 4050'
        },
        deliveryFee: 5,
        deliveryFeeCurrency: 'AFNL',
        deliveryDistance: 2,
        deliveryDistanceUnit: 'mile'
      },
      {
        id: 'ord-ex-res-2',
        orderNumber: 'ORD-TK-992144',
        restaurantId: 'loc-rest-1',
        restaurantName: "Ranma's Sovereign Dining",
        customerHandle: currentUser?.id || 'guest',
        customerName: currentUser?.name || 'Sovereign Explorer',
        customerPhone: '+41 44 211 4055',
        fulfillmentType: 'pickup',
        orderChannel: 'online',
        items: [
          {
            item: {
              id: 'ex-res-2',
              name: 'Black Winter Truffle Gruyère Fondue',
              category: 'Appetizers',
              price: 145,
              currency: 'FNL-SWISS',
              type: 'restaurant',
              image: 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?w=500&auto=format&fit=crop&q=80'
            },
            quantity: 1
          }
        ],
        subtotal: 145,
        tax: 0,
        tip: 15,
        total: 160,
        currency: 'FNL-SWISS',
        pickupTime: 'Pickup in 15 min',
        status: 'received',
        createdAt: new Date(Date.now() - 3 * 60 * 1000).toISOString() // 3 minutes ago -> 7 minutes left on 10-min countdown clock!
      }
    ];
    try {
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(defaultExamples));
    } catch {}
    return defaultExamples;
  });

  // Sync takeoutOrders when RideShareView updates driver acceptance or completion
  useEffect(() => {
    const syncOrdersFromStorage = () => {
      try {
        const saved = localStorage.getItem('final_finance_takeout_orders');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            setTakeoutOrders(parsed);
          }
        }
      } catch {}
    };
    window.addEventListener('final_finance_takeout_orders_updated', syncOrdersFromStorage);
    window.addEventListener('storage', syncOrdersFromStorage);
    return () => {
      window.removeEventListener('final_finance_takeout_orders_updated', syncOrdersFromStorage);
      window.removeEventListener('storage', syncOrdersFromStorage);
    };
  }, []);

  // Universal Search State: by Store/Restaurant Name, or by Particular Dish / Product
  const [universalSearchQuery, setUniversalSearchQuery] = useState('');
  const [customerSubTab, setCustomerSubTab] = useState<'restaurants' | 'retail'>('retail');
  const [explorerSectionView, setExplorerSectionView] = useState<'browse' | 'checkout' | 'online_orders' | 'delivery_address'>('browse');
  const [customerOrderStatusFilter, setCustomerOrderStatusFilter] = useState<'all' | 'active' | 'received' | 'in_kitchen' | 'ready_for_pickup' | 'completed' | 'cancelled'>('all');
  const [explorerRetailChannelTab, setExplorerRetailChannelTab] = useState<'instore' | 'online'>('online');
  const [explorerRestaurantChannelTab, setExplorerRestaurantChannelTab] = useState<'inhouse' | 'online'>('online');
  const [modalChannelTab, setModalChannelTab] = useState<'online' | 'instore'>('online');
  const [storePageSearchQuery, setStorePageSearchQuery] = useState('');
  const [storePageCategory, setStorePageCategory] = useState('All');
  const [merchantCatalogSearch, setMerchantCatalogSearch] = useState('');
  const [merchantCatalogCategory, setMerchantCatalogCategory] = useState('All');

  // Customer Delivery Addresses (Up to 5 different addresses with name, phone, email)
  const [deliveryAddresses, setDeliveryAddresses] = useState<DeliveryAddress[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_pos_delivery_addresses_${merchantId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);
  const [addrLabel, setAddrLabel] = useState('');
  const [addrFullName, setAddrFullName] = useState('');
  const [addrPhone, setAddrPhone] = useState('');
  const [addrEmail, setAddrEmail] = useState('');
  const [addrStreet, setAddrStreet] = useState('');
  const [addrError, setAddrError] = useState('');
  const [selectedDeliveryAddressIdByLoc, setSelectedDeliveryAddressIdByLoc] = useState<Record<string, string>>({});

  // Customer Store / Restaurant Per-Location Carts, Currencies, Tips & Modal State
  const [viewingLocation, setViewingLocation] = useState<MerchantLocation | null>(null);
  const [expandedExplorerItemKey, setExpandedExplorerItemKey] = useState<string | null>(null);
  const [expandedModalItemId, setExpandedModalItemId] = useState<string | null>(null);
  const [expandedMerchantItemId, setExpandedMerchantItemId] = useState<string | null>(null);
  const [reviewsModalLocation, setReviewsModalLocation] = useState<MerchantLocation | null>(null);
  const [customerCartsByLoc, setCustomerCartsByLoc] = useState<Record<string, { item: CatalogItem; quantity: number }[]>>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_pos_customer_carts_${merchantId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });
  const [customerCurrencyByLoc, setCustomerCurrencyByLoc] = useState<Record<string, string>>({});
  const [customerTipPctByLoc, setCustomerTipPctByLoc] = useState<Record<string, number>>({});
  const [customerCustomTipByLoc, setCustomerCustomTipByLoc] = useState<Record<string, string>>({});
  const [customerNotesByLoc, setCustomerNotesByLoc] = useState<Record<string, string>>({});
  const [customerPickupTimeByLoc, setCustomerPickupTimeByLoc] = useState<Record<string, string>>({});
  const [customerDistanceByLoc, setCustomerDistanceByLoc] = useState<Record<string, string>>({});
  const [customerFulfillmentByLoc, setCustomerFulfillmentByLoc] = useState<Record<string, 'pickup' | 'delivery'>>({});
  const [customerNameByLoc, setCustomerNameByLoc] = useState<Record<string, string>>({});
  const [customerPhoneByLoc, setCustomerPhoneByLoc] = useState<Record<string, string>>({});
  const [customerEmailByLoc, setCustomerEmailByLoc] = useState<Record<string, string>>({});
  const [inlineAddrFormByLoc, setInlineAddrFormByLoc] = useState<Record<string, { open: boolean; label: string; fullName: string; phone: string; email: string; address: string; error: string }>>({});
  const [posInventorySearch, setPosInventorySearch] = useState<string>('');
  const [posMenuCategory, setPosMenuCategory] = useState<string>('All');
  const [onlineOrdersSearch, setOnlineOrdersSearch] = useState<string>('');
  const [onlineOrdersLocationScope, setOnlineOrdersLocationScope] = useState<'all_locations' | 'active_location'>('all_locations');
  const [posWalkInItemId, setPosWalkInItemId] = useState<string>('');
  const [posWalkInCustomerName, setPosWalkInCustomerName] = useState<string>('');
  const [posWalkInCustomerPhone, setPosWalkInCustomerPhone] = useState<string>('');
  const [posWalkInCustomerEmail, setPosWalkInCustomerEmail] = useState<string>('');
  const [posWalkInFulfillment, setPosWalkInFulfillment] = useState<'pickup' | 'delivery'>('pickup');
  const [posWalkInAddressId, setPosWalkInAddressId] = useState<string>('');
  const [posWalkInShowAddAddr, setPosWalkInShowAddAddr] = useState<boolean>(false);
  const [posWalkInNewAddrLabel, setPosWalkInNewAddrLabel] = useState<string>('');
  const [posWalkInNewAddrName, setPosWalkInNewAddrName] = useState<string>('');
  const [posWalkInNewAddrPhone, setPosWalkInNewAddrPhone] = useState<string>('');
  const [posWalkInNewAddrEmail, setPosWalkInNewAddrEmail] = useState<string>('');
  const [posWalkInNewAddrStreet, setPosWalkInNewAddrStreet] = useState<string>('');
  const [posWalkInError, setPosWalkInError] = useState<string>('');
  const [merchantOrderStatusFilter, setMerchantOrderStatusFilter] = useState<'all' | 'active' | 'received' | 'in_kitchen' | 'ready_for_pickup' | 'completed' | 'cancelled'>('all');
  const [retailCheckoutSectionTab, setRetailCheckoutSectionTab] = useState<'in_store' | 'online_orders'>('in_store');
  const [restaurantCheckoutSectionTab, setRestaurantCheckoutSectionTab] = useState<'in_restaurant' | 'online_orders'>('in_restaurant');
  const [retailSalesLogTab, setRetailSalesLogTab] = useState<'in_store' | 'online'>('in_store');
  const [restaurantSalesLogTab, setRestaurantSalesLogTab] = useState<'in_restaurant' | 'online'>('in_restaurant');
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [isBarcodeScannerOpen, setIsBarcodeScannerOpen] = useState(false);
  const [barcodeScanInput, setBarcodeScanInput] = useState('');
  const [barcodeScanFeedback, setBarcodeScanFeedback] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const [isCameraScanning, setIsCameraScanning] = useState(false);
  const [cameraScanError, setCameraScanError] = useState('');
  const barcodeVideoRef = useRef<HTMLVideoElement | null>(null);
  const barcodeStreamRef = useRef<MediaStream | null>(null);
  const [isTakeoutSuccessModalOpen, setIsTakeoutSuccessModalOpen] = useState(false);
  const [lastTakeoutOrder, setLastTakeoutOrder] = useState<TakeoutOrder | null>(null);

  useEffect(() => {
    if (mainTab !== 'directory' || explorerSectionView !== 'online_orders') return;
    setNowMs(Date.now());
    const id = window.setInterval(() => setNowMs(Date.now()), 5000);
    return () => window.clearInterval(id);
  }, [mainTab, explorerSectionView]);

  const persistCustomerCarts = (next: Record<string, { item: CatalogItem; quantity: number }[]>) => {
    setCustomerCartsByLoc(next);
    try {
      localStorage.setItem(`final_finance_pos_customer_carts_${merchantId}`, JSON.stringify(next));
    } catch {}
  };

  const getCustomerLocCart = (locId: string) => customerCartsByLoc[locId] || [];

  const getDefaultLocationCurrency = (locId: string): string => {
    const loc = locations.find(l => l.id === locId);
    if (!loc) return 'AFNL';
    const items = loc.type === 'retail'
      ? [...(retailInventoriesByLoc[locId] ?? getInitialRetailForLoc(locId)), ...(onlineRetailByLoc[locId] ?? getInitialOnlineRetailForLoc(locId))]
      : [...(restaurantMenusByLoc[locId] ?? getInitialRestaurantForLoc(locId)), ...(onlineMenusByLoc[locId] ?? getInitialOnlineMenuForLoc(locId))];
    return items[0]?.currency || 'AFNL';
  };

  const relevantMerchantCurrencies = useMemo(() => {
    return getRelevantCurrenciesForItems(cart, activeLocationId);
  }, [cart, activeLocationId, allFinalCurrencies]);

  const checkoutCurrency = (() => {
    const saved = merchantCurrencyByLoc[activeLocationId];
    if (saved && relevantMerchantCurrencies.some(c => c.symbol === saved)) {
      return saved;
    }
    return relevantMerchantCurrencies[0]?.symbol || cart[0]?.currency || getDefaultLocationCurrency(activeLocationId);
  })();
  const setCheckoutCurrency = (symbol: string) => {
    setMerchantCurrencyByLoc(prev => ({ ...prev, [activeLocationId]: symbol }));
  };

  const getCustomerRelevantCurrenciesForLoc = (loc: MerchantLocation): FinalCurrencyOption[] => {
    const locCart = getCustomerLocCart(loc.id);
    return getRelevantCurrenciesForItems(locCart.map(entry => entry.item), loc.id);
  };

  const getCustomerCurrencyForLoc = (loc: MerchantLocation): string => {
    const relevant = getCustomerRelevantCurrenciesForLoc(loc);
    const saved = customerCurrencyByLoc[loc.id];
    if (saved && relevant.some(c => c.symbol === saved)) {
      return saved;
    }
    if (relevant.length > 0) return relevant[0].symbol;
    const locCart = getCustomerLocCart(loc.id);
    if (locCart.length > 0) return locCart[0].item.currency;
    return getDefaultLocationCurrency(loc.id);
  };

  const takeoutBag = viewingLocation ? (customerCartsByLoc[viewingLocation.id] || []) : [];
  const setTakeoutBag = (updater: { item: CatalogItem; quantity: number }[] | ((prev: { item: CatalogItem; quantity: number }[]) => { item: CatalogItem; quantity: number }[])) => {
    if (!viewingLocation) return;
    const current = customerCartsByLoc[viewingLocation.id] || [];
    const next = typeof updater === 'function' ? updater(current) : updater;
    persistCustomerCarts({ ...customerCartsByLoc, [viewingLocation.id]: next });
  };
  const takeoutPickupTime = viewingLocation ? (customerPickupTimeByLoc[viewingLocation.id] || 'ASAP (15-20 min)') : 'ASAP (15-20 min)';
  const setTakeoutPickupTime = (val: string) => {
    if (!viewingLocation) return;
    setCustomerPickupTimeByLoc(prev => ({ ...prev, [viewingLocation.id]: val }));
  };
  const takeoutNotes = viewingLocation ? (customerNotesByLoc[viewingLocation.id] || '') : '';
  const setTakeoutNotes = (val: string) => {
    if (!viewingLocation) return;
    setCustomerNotesByLoc(prev => ({ ...prev, [viewingLocation.id]: val }));
  };
  const takeoutPaymentCurrency = viewingLocation ? getCustomerCurrencyForLoc(viewingLocation) : 'AFNL';
  const setTakeoutPaymentCurrency = (symbol: string) => {
    if (!viewingLocation) return;
    setCustomerCurrencyByLoc(prev => ({ ...prev, [viewingLocation.id]: symbol }));
  };
  const takeoutTipPercentage = viewingLocation ? (customerTipPctByLoc[viewingLocation.id] ?? (viewingLocation.type === 'retail' ? 0 : 15)) : 15;
  const setTakeoutTipPercentage = (pct: number) => {
    if (!viewingLocation) return;
    setCustomerTipPctByLoc(prev => ({ ...prev, [viewingLocation.id]: pct }));
  };
  const takeoutCustomTip = viewingLocation ? (customerCustomTipByLoc[viewingLocation.id] || '') : '';
  const setTakeoutCustomTip = (val: string) => {
    if (!viewingLocation) return;
    setCustomerCustomTipByLoc(prev => ({ ...prev, [viewingLocation.id]: val }));
  };

  const addItemToCustomerLocCart = (locId: string, item: CatalogItem) => {
    setCustomerCartsByLoc(prev => {
      const current = prev[locId] || [];
      const existing = current.find(i => i.item.id === item.id);
      const nextList = existing
        ? current.map(i => i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)
        : [...current, { item, quantity: 1 }];
      const nextMap = { ...prev, [locId]: nextList };
      try {
        localStorage.setItem(`final_finance_pos_customer_carts_${merchantId}`, JSON.stringify(nextMap));
      } catch {}
      return nextMap;
    });
  };

  const updateCustomerLocCartQty = (locId: string, itemId: string, delta: number) => {
    const current = customerCartsByLoc[locId] || [];
    const next = current
      .map(i => i.item.id === itemId ? { ...i, quantity: i.quantity + delta } : i)
      .filter(i => i.quantity > 0);
    persistCustomerCarts({ ...customerCartsByLoc, [locId]: next });
  };

  const removeCustomerLocCartItem = (locId: string, itemId: string) => {
    const current = customerCartsByLoc[locId] || [];
    persistCustomerCarts({ ...customerCartsByLoc, [locId]: current.filter(i => i.item.id !== itemId) });
  };

  const clearCustomerLocCart = (locId: string) => {
    persistCustomerCarts({ ...customerCartsByLoc, [locId]: [] });
  };

  const persistDeliveryAddresses = (next: DeliveryAddress[]) => {
    setDeliveryAddresses(next);
    try {
      localStorage.setItem(`final_finance_pos_delivery_addresses_${merchantId}`, JSON.stringify(next));
    } catch {}
  };

  const handleSaveDeliveryAddress = (e: React.FormEvent) => {
    e.preventDefault();
    setAddrError('');
    if (!addrFullName.trim() || !addrStreet.trim()) {
      setAddrError('Please enter your full name and delivery address.');
      return;
    }
    if (!editingAddressId && deliveryAddresses.length >= 5) {
      setAddrError('Maximum 5 delivery addresses allowed. Edit or remove an existing address.');
      return;
    }

    if (editingAddressId) {
      const updated = deliveryAddresses.map(a => a.id === editingAddressId ? {
        ...a,
        label: addrLabel.trim() || a.label || 'Saved Address',
        fullName: addrFullName.trim(),
        phone: addrPhone.trim() || undefined,
        email: addrEmail.trim() || undefined,
        address: addrStreet.trim()
      } : a);
      persistDeliveryAddresses(updated);
      setEditingAddressId(null);
      dispatchGlobalNotification({
        title: 'Delivery Address Updated',
        description: `Updated "${addrFullName.trim()}" address details.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'success'
      });
    } else {
      const newAddr: DeliveryAddress = {
        id: `addr-${Date.now()}`,
        label: addrLabel.trim() || `Address ${deliveryAddresses.length + 1}`,
        fullName: addrFullName.trim(),
        phone: addrPhone.trim() || undefined,
        email: addrEmail.trim() || undefined,
        address: addrStreet.trim(),
        isDefault: deliveryAddresses.length === 0
      };
      persistDeliveryAddresses([...deliveryAddresses, newAddr]);
      dispatchGlobalNotification({
        title: 'Delivery Address Saved',
        description: `Added delivery address (${deliveryAddresses.length + 1}/5).`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'success'
      });
    }

    setAddrLabel('');
    setAddrFullName('');
    setAddrPhone('');
    setAddrEmail('');
    setAddrStreet('');
  };

  // User Review Submission inside Store Modal & Reviews Modal (Rate 1-5 & comment, updates if existing)
  const [userRatingScore, setUserRatingScore] = useState<number>(5);
  const [userReviewComment, setUserReviewComment] = useState<string>('');

  const saveCatalog = (mode: 'retail' | 'restaurant', updated: CatalogItem[], locId: string = activeLocationId, scope: 'instore' | 'online' = 'instore') => {
    if (mode === 'retail') {
      if (scope === 'online') {
        setOnlineRetailByLoc(prev => ({ ...prev, [locId]: updated }));
        try {
          localStorage.setItem(`final_finance_online_retail_${merchantId}_${locId}`, JSON.stringify(updated));
        } catch {}
      } else {
        setRetailInventoriesByLoc(prev => ({ ...prev, [locId]: updated }));
        try {
          localStorage.setItem(`final_finance_pos_retail_cat_${merchantId}_${locId}`, JSON.stringify(updated));
        } catch {}
      }
    } else {
      if (scope === 'online') {
        setOnlineMenusByLoc(prev => ({ ...prev, [locId]: updated }));
        try {
          localStorage.setItem(`final_finance_online_dishes_${merchantId}_${locId}`, JSON.stringify(updated));
        } catch {}
      } else {
        setRestaurantMenusByLoc(prev => ({ ...prev, [locId]: updated }));
        try {
          localStorage.setItem(`final_finance_pos_restaurant_cat_${merchantId}_${locId}`, JSON.stringify(updated));
        } catch {}
      }
    }
  };

  const saveLocations = (locs: MerchantLocation[]) => {
    setLocations(locs);
    try {
      localStorage.setItem('final_finance_merchant_locations', JSON.stringify(locs));
    } catch {}
  };

  const updateActiveLocationField = (patch: Partial<MerchantLocation>) => {
    const updated = locations.map(l => l.id === activeLocationId ? { ...l, ...patch } : l);
    saveLocations(updated);
  };

  const saveReviews = (revs: StoreReview[]) => {
    setReviewsList(revs);
    try {
      localStorage.setItem('final_finance_store_reviews', JSON.stringify(revs));
    } catch {}
  };

  // Helper for file uploads (Photos & Videos)
  const handleReadMediaFiles = (
    files: FileList | null,
    onAddPhoto: (dataUrl: string) => void,
    onAddVideo: (dataUrl: string) => void
  ) => {
    if (!files || files.length === 0) return;
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = () => {
        const res = reader.result as string;
        if (file.type.startsWith('video/')) {
          onAddVideo(res);
        } else {
          onAddPhoto(res);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Add a new location (Up to 10 retail stores AND up to 10 restaurants)
  const handleCreateLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocName.trim() || !newLocAddress.trim()) return;

    const currentTypeCount = locations.filter(l => l.type === newLocType).length;
    if (currentTypeCount >= 10) {
      alert(`Maximum capacity reached: You can create up to 10 ${newLocType === 'retail' ? 'retail stores' : 'restaurants'}.`);
      return;
    }

    const newLoc: MerchantLocation = {
      id: `loc-${newLocType}-${Date.now()}`,
      name: newLocName.trim(),
      type: newLocType,
      phone: newLocPhone.trim() || '+1 555 019 2834',
      email: newLocEmail.trim() || `${newLocName.toLowerCase().replace(/\s+/g, '')}@sovereign.net`,
      address: newLocAddress.trim(),
      cuisineOrCategory: newLocCategory.trim() || (newLocType === 'retail' ? 'General Retail Goods' : 'Artisanal Cuisine'),
      tagline: newLocTagline.trim() || 'Settlement powered by Final Currency.',
      ownerId: merchantId,
      ownerHandle: currentUser?.id || 'merchant',
      ownerName: currentUser?.name || 'Store Owner',
      prepTimeMinutes: '15-25',
      openingTime: '10:00',
      closingTime: '22:00',
      operatingDays: 'Daily (Mon - Sun)',
      isOpenForTakeout: true,
      ...(newLocType === 'retail'
        ? {
            allowsDelivery: true,
            deliveryFeeRate: Math.max(0, parseFloat(newLocDeliveryFeeRate || '0') || 0),
            deliveryFeeCurrency: newLocDeliveryFeeCurrency || 'AFNL',
            deliveryFeeUnit: newLocDeliveryFeeUnit
          }
        : {
            allowsDelivery: newLocAllowsDelivery,
            ...(newLocAllowsDelivery
              ? {
                  deliveryFeeRate: Math.max(0, parseFloat(newLocDeliveryFeeRate || '0') || 0),
                  deliveryFeeCurrency: newLocDeliveryFeeCurrency || 'AFNL',
                  deliveryFeeUnit: newLocDeliveryFeeUnit
                }
              : {})
          })
    };

    const updated = [...locations, newLoc];
    saveLocations(updated);
    if (newLoc.type === 'retail') {
      saveCatalog('retail', [], newLoc.id, 'instore');
      saveCatalog('retail', [], newLoc.id, 'online');
      setMainTab('retail');
      setRetailSubTab('checkout');
    } else {
      saveCatalog('restaurant', [], newLoc.id, 'instore');
      saveCatalog('restaurant', [], newLoc.id, 'online');
      setMainTab('restaurant');
      setRestaurantSubTab('checkout');
    }
    setActiveLocationId(newLoc.id);
    setCart([]);
    setIsAddLocationModalOpen(false);

    setNewLocName('');
    setNewLocPhone('');
    setNewLocEmail('');
    setNewLocAddress('');
    setNewLocCategory('');
    setNewLocTagline('');
    setNewLocAllowsDelivery(false);
    setNewLocDeliveryFeeRate('2');
    setNewLocDeliveryFeeCurrency('AFNL');
    setNewLocDeliveryFeeUnit('mile');

    dispatchGlobalNotification({
      title: newLoc.type === 'retail' ? 'Retail Store Created' : 'Restaurant Created',
      description: `Added "${newLoc.name}" (${currentTypeCount + 1}/10 ${newLoc.type === 'retail' ? 'retail stores' : 'restaurants'}).`,
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'success'
    });
  };

  // Add Item to Inventory / Menu Section (Supports In-Store, Online, or Both per store/restaurant)
  const handleAddNewInventoryItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemTitle.trim() || !newItemCost) return;
    if (!newItemIncludeInStore && !newItemIncludeOnline) {
      dispatchGlobalNotification({
        title: 'Select Destination',
        description: 'Please select at least one destination (In-Store Inventory/Menu or Online).',
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }
    const priceNum = parseFloat(newItemCost);
    if (isNaN(priceNum) || priceNum <= 0) return;

    const acceptedList = newItemCurrencies.length > 0 ? newItemCurrencies.slice(0, 5) : ['AFNL'];
    const primaryCurrency = acceptedList[0];

    const currentMode = mainTab === 'retail' ? 'retail' : 'restaurant';
    const itemId = `${currentMode === 'retail' ? 'ret' : 'res'}-${Date.now()}`;
    const generatedQrs: POSItemQRCode[] = [];

    if (newItemAddOneTimeQR) {
      generatedQrs.push({
        type: 'one-time',
        payload: `ff:pos:onetime:${primaryCurrency}:${priceNum}:${itemId}:${Date.now()}:${merchantId}`,
        createdAt: new Date().toISOString().split('T')[0],
        label: `${newItemTitle.trim()} (One-Time Invoice)`
      });
    }
    if (newItemAddInventoryQR) {
      generatedQrs.push({
        type: 'inventory',
        payload: `ff:pos:inventory:${primaryCurrency}:${priceNum}:${itemId}:${merchantId}`,
        createdAt: new Date().toISOString().split('T')[0],
        label: `${newItemTitle.trim()} (Inventory Tag)`
      });
    }

    const newItem: CatalogItem = {
      id: itemId,
      name: newItemTitle.trim(),
      category: newItemType.trim() || (currentMode === 'retail' ? 'General Retail' : 'Entrees'),
      price: priceNum,
      currency: primaryCurrency,
      acceptedCurrencies: acceptedList,
      type: currentMode,
      stock: parseInt(newItemStock, 10) || 20,
      barcode: currentMode === 'retail' ? (newItemBarcode.trim() || undefined) : undefined,
      description: newItemDescription.trim() || undefined,
      image: newItemPhotos[0] || undefined,
      photos: [...newItemPhotos],
      videos: [...newItemVideos],
      qrCodes: generatedQrs
    };

    if (currentMode === 'retail') {
      if (newItemIncludeInStore) {
        saveCatalog('retail', [newItem, ...retailCatalog], activeLocationId, 'instore');
      }
      if (newItemIncludeOnline) {
        saveCatalog('retail', [newItem, ...onlineRetailCatalog], activeLocationId, 'online');
      }
    } else {
      if (newItemIncludeInStore) {
        saveCatalog('restaurant', [newItem, ...restaurantCatalog], activeLocationId, 'instore');
      }
      if (newItemIncludeOnline) {
        if (onlineMenuDishes.length >= 100) {
          dispatchGlobalNotification({
            title: 'Menu Limit Reached',
            description: 'Online menu reached 100 dishes maximum.',
            type: 'pos',
            targetTab: 'point_of_sale',
            showToast: true,
            tone: 'alert'
          });
        } else {
          saveCatalog('restaurant', [newItem, ...onlineMenuDishes], activeLocationId, 'online');
        }
      }
    }

    setNewItemTitle('');
    setNewItemType('');
    setNewItemCost('');
    setNewItemBarcode('');
    setNewItemDescription('');
    setNewItemPhotos([]);
    setNewItemVideos([]);
    setNewItemMediaUrlInput('');

    dispatchGlobalNotification({
      title: '📦 Item Saved',
      description: `Saved "${newItem.name}" (${priceNum} ${acceptedList.join(' / ')}) to ${activeLocation.name}.`,
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'success'
    });
  };

  // Add Item Directly to Online Retail Store (for currently selected retail store)
  const handleAddOnlineRetailItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onlineRetailTitle.trim() || !onlineRetailPrice) return;
    const priceNum = parseFloat(onlineRetailPrice);
    if (isNaN(priceNum) || priceNum <= 0) return;

    if (onlineRetailCatalog.length >= 100) {
      dispatchGlobalNotification({
        title: 'Store Limit Reached',
        description: 'Maximum 100 online items per retail store.',
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const acceptedList = onlineRetailCurrencies.length > 0 ? onlineRetailCurrencies.slice(0, 5) : ['AFNL'];
    const primaryCurrency = acceptedList[0];

    const itemId = `ret-onl-${Date.now()}`;
    const newItem: CatalogItem = {
      id: itemId,
      name: onlineRetailTitle.trim(),
      category: onlineRetailCategory.trim() || 'General Retail',
      price: priceNum,
      currency: primaryCurrency,
      acceptedCurrencies: acceptedList,
      type: 'retail',
      stock: parseInt(onlineRetailStock, 10) || 25,
      barcode: onlineRetailBarcode.trim() || undefined,
      description: onlineRetailDescription.trim() || undefined,
      image: onlineRetailPhotos[0] || undefined,
      photos: [...onlineRetailPhotos],
      videos: [...onlineRetailVideos],
      qrCodes: [
        {
          type: 'one-time',
          payload: `ff:pos:onetime:${primaryCurrency}:${priceNum}:${itemId}:${Date.now()}:${merchantId}`,
          createdAt: new Date().toISOString().split('T')[0],
          label: `${onlineRetailTitle.trim()} (Online One-Time Invoice)`
        },
        {
          type: 'inventory',
          payload: `ff:pos:inventory:${primaryCurrency}:${priceNum}:${itemId}:${merchantId}`,
          createdAt: new Date().toISOString().split('T')[0],
          label: `${onlineRetailTitle.trim()} (Online Inventory Tag)`
        }
      ]
    };

    const nextItems = [newItem, ...onlineRetailCatalog];
    saveCatalog('retail', nextItems, activeLocationId, 'online');

    setOnlineRetailTitle('');
    setOnlineRetailPrice('');
    setOnlineRetailBarcode('');
    setOnlineRetailDescription('');
    setOnlineRetailPhotos([]);
    setOnlineRetailVideos([]);
    setOnlineRetailMediaUrl('');

    dispatchGlobalNotification({
      title: '🛍️ Added to Online Store',
      description: `Published "${newItem.name}" (${acceptedList.join(' / ')}) online for ${activeLocation.name}.`,
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'success'
    });
  };

  const handleSyncRetailInventoryToOnline = () => {
    const merged = [...retailCatalog];
    saveCatalog('retail', merged, activeLocationId, 'online');

    dispatchGlobalNotification({
      title: 'Synchronized Retail Inventory Online',
      description: `Published ${merged.length} retail items online for ${activeLocation.name}.`,
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'success'
    });
  };

  const handleDeleteInventoryItem = (itemId: string, mode: 'retail' | 'restaurant', scope: 'instore' | 'online' = 'instore') => {
    if (mode === 'retail') {
      const source = scope === 'online' ? onlineRetailCatalog : retailCatalog;
      saveCatalog('retail', source.filter(i => i.id !== itemId), activeLocationId, scope);
    } else {
      const source = scope === 'online' ? onlineMenuDishes : restaurantCatalog;
      saveCatalog('restaurant', source.filter(i => i.id !== itemId), activeLocationId, scope);
    }
    dispatchGlobalNotification({
      title: 'Item Removed',
      description: scope === 'online' ? 'Item removed from online store/menu.' : 'Item removed from inventory.',
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'alert'
    });
  };

  // Add QR Code to an Item in Modal
  const handleAddQrCodeToItem = (item: CatalogItem, type: 'one-time' | 'inventory') => {
    const existing = item.qrCodes || [];
    const hasType = existing.some(q => q.type === type);
    if (hasType || existing.length >= 2) return;

    const payload = type === 'one-time'
      ? `ff:pos:onetime:${item.currency}:${item.price}:${item.id}:${Date.now()}:${merchantId}`
      : `ff:pos:inventory:${item.currency}:${item.price}:${item.id}:${merchantId}`;

    const newQr: POSItemQRCode = {
      type,
      payload,
      createdAt: new Date().toISOString().split('T')[0],
      label: type === 'one-time' ? `${item.name} (One-Time Invoice)` : `${item.name} (Inventory Tag)`
    };

    const source = item.type === 'retail'
      ? (selectedItemScope === 'online' ? onlineRetailCatalog : retailCatalog)
      : (selectedItemScope === 'online' ? onlineMenuDishes : restaurantCatalog);
    const updated = source.map(i => i.id === item.id ? { ...i, qrCodes: [...(i.qrCodes || []), newQr] } : i);
    saveCatalog(item.type, updated, activeLocationId, selectedItemScope);

    if (selectedItemForModal?.id === item.id) {
      setSelectedItemForModal({
        ...selectedItemForModal,
        qrCodes: [...existing, newQr]
      });
      setActiveQrPreview(newQr);
    }
  };

  const handleRemoveQrCodeFromItem = (item: CatalogItem, type: 'one-time' | 'inventory') => {
    const source = item.type === 'retail'
      ? (selectedItemScope === 'online' ? onlineRetailCatalog : retailCatalog)
      : (selectedItemScope === 'online' ? onlineMenuDishes : restaurantCatalog);
    const updated = source.map(i => i.id === item.id ? { ...i, qrCodes: (i.qrCodes || []).filter(q => q.type !== type) } : i);
    saveCatalog(item.type, updated, activeLocationId, selectedItemScope);

    if (selectedItemForModal?.id === item.id) {
      const nextQrs = (selectedItemForModal.qrCodes || []).filter(q => q.type !== type);
      setSelectedItemForModal({
        ...selectedItemForModal,
        qrCodes: nextQrs
      });
      if (activeQrPreview?.type === type) {
        setActiveQrPreview(nextQrs[0] || null);
      }
    }
  };

  // Media Attachment in Item Modal
  const handleAddMediaToModalItem = (item: CatalogItem, mediaUrl: string, isVideo: boolean = false) => {
    if (!mediaUrl.trim()) return;
    const url = mediaUrl.trim();

    const targetCatalog = item.type === 'retail'
      ? (selectedItemScope === 'online' ? onlineRetailCatalog : retailCatalog)
      : (selectedItemScope === 'online' ? onlineMenuDishes : restaurantCatalog);
    const updated = targetCatalog.map(i => {
      if (i.id === item.id) {
        const nextPhotos = isVideo ? (i.photos || []) : [...(i.photos || []), url];
        const nextVideos = isVideo ? [...(i.videos || []), url] : (i.videos || []);
        return {
          ...i,
          image: i.image || (!isVideo ? url : i.image),
          photos: nextPhotos,
          videos: nextVideos
        };
      }
      return i;
    });

    saveCatalog(item.type, updated, activeLocationId, selectedItemScope);

    if (selectedItemForModal?.id === item.id) {
      const nextPhotos = isVideo ? (selectedItemForModal.photos || []) : [...(selectedItemForModal.photos || []), url];
      const nextVideos = isVideo ? [...(selectedItemForModal.videos || []), url] : (selectedItemForModal.videos || []);
      setSelectedItemForModal({
        ...selectedItemForModal,
        image: selectedItemForModal.image || (!isVideo ? url : selectedItemForModal.image),
        photos: nextPhotos,
        videos: nextVideos
      });
    }
    setModalMediaUrl('');
  };

  // Cart & POS Checkout actions
  const addToCart = (item: CatalogItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.id === id) {
        const nextQ = i.quantity + delta;
        return nextQ > 0 ? { ...i, quantity: nextQ } : null;
      }
      return i;
    }).filter(Boolean) as CartItem[]);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const subtotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [cart]);

  const tax = subtotal * 0.05;

  const rawTip = useMemo(() => {
    if (customTip !== '' && !isNaN(parseFloat(customTip))) {
      return Math.max(0, parseFloat(customTip));
    }
    return (subtotal * tipPercentage) / 100;
  }, [subtotal, tipPercentage, customTip]);

  const tip = activeLocation.type === 'restaurant' ? rawTip : 0;

  const total = subtotal + tax + tip;

  const handleToggleModalItemCurrency = (item: CatalogItem, symbol: string) => {
    const current = getItemAcceptedCurrencies(item);
    const next = toggleCurrencyInList(current, symbol, 5);
    if (next === current) return;
    const primary = next[0] || item.currency;
    const targetCatalog = item.type === 'retail'
      ? (selectedItemScope === 'online' ? onlineRetailCatalog : retailCatalog)
      : (selectedItemScope === 'online' ? onlineMenuDishes : restaurantCatalog);
    const updated = targetCatalog.map(i => i.id === item.id ? { ...i, currency: primary, acceptedCurrencies: next } : i);
    saveCatalog(item.type, updated, activeLocationId, selectedItemScope);
    if (selectedItemForModal?.id === item.id) {
      setSelectedItemForModal({ ...selectedItemForModal, currency: primary, acceptedCurrencies: next });
    }
  };

  const isOrderRetail = (order: TakeoutOrder): boolean => {
    const loc = locations.find(l => l.id === order.restaurantId);
    if (loc) return loc.type === 'retail';
    return order.orderNumber.startsWith('ORD-RET-');
  };

  const getCustomerCancellationStatus = (order: TakeoutOrder, currentMs: number = nowMs): {
    canCancel: boolean;
    reasonLabel: string;
    remainingMs: number;
    isDriverPriceWindow?: boolean;
  } => {
    if (order.status === 'cancelled') {
      return { canCancel: false, reasonLabel: 'Order Cancelled', remainingMs: 0 };
    }
    if (order.status === 'completed') {
      return { canCancel: false, reasonLabel: 'Order Completed', remainingMs: 0 };
    }

    // When a driver accepts delivery and updates the price per mile, grant a 5-minute cancellation window
    if (order.driverAccepted && order.driverAcceptedAt) {
      const acceptedMs = new Date(order.driverAcceptedAt).getTime();
      const fiveMinutesMs = 5 * 60 * 1000;
      const elapsedDriverMs = isNaN(acceptedMs) ? fiveMinutesMs : Math.max(0, currentMs - acceptedMs);
      const remainingDriverMs = Math.max(0, fiveMinutesMs - elapsedDriverMs);
      if (remainingDriverMs > 0) {
        const mins = Math.floor(remainingDriverMs / 60000);
        const secs = Math.floor((remainingDriverMs % 60000) / 1000);
        return {
          canCancel: true,
          reasonLabel: `Cancel (${mins}:${secs.toString().padStart(2, '0')} left)`,
          remainingMs: remainingDriverMs,
          isDriverPriceWindow: true
        };
      }
      return {
        canCancel: false,
        reasonLabel: '5-Min Cancel Window Expired',
        remainingMs: 0,
        isDriverPriceWindow: true
      };
    }

    const retailOrder = isOrderRetail(order);
    if (retailOrder) {
      if (order.status === 'received') {
        return {
          canCancel: true,
          reasonLabel: 'Cancel Before Store Accepts',
          remainingMs: 0
        };
      }
      return {
        canCancel: false,
        reasonLabel: 'Store Accepted / Preparing — Cannot Cancel',
        remainingMs: 0
      };
    }

    // Restaurant order: cancellable within 10 minutes of placing
    const createdMs = new Date(order.createdAt).getTime();
    const tenMinutesMs = 10 * 60 * 1000;
    const elapsedMs = isNaN(createdMs) ? tenMinutesMs : Math.max(0, currentMs - createdMs);
    const remainingMs = Math.max(0, tenMinutesMs - elapsedMs);
    if (remainingMs > 0) {
      const mins = Math.floor(remainingMs / 60000);
      const secs = Math.floor((remainingMs % 60000) / 1000);
      return {
        canCancel: true,
        reasonLabel: `Cancel (${mins}m ${secs.toString().padStart(2, '0')}s left)`,
        remainingMs
      };
    }
    return {
      canCancel: false,
      reasonLabel: '10-Min Cancel Window Expired',
      remainingMs: 0
    };
  };

  const recordLedgerToAll = (entry: any) => {
    recordLedgerTransaction(ledgerUserId, entry);
    if (merchantId && merchantId !== ledgerUserId) {
      recordLedgerTransaction(merchantId, entry);
    }
    recordLedgerTransaction('admin', entry);
    recordLedgerTransaction('super_admin', entry);
    recordLedgerTransaction('global', entry);
  };

  const handleMerchantCancelOrder = (orderId: string) => {
    const targetOrder = takeoutOrders.find(o => o.id === orderId);
    if (!targetOrder || targetOrder.status === 'cancelled' || targetOrder.status === 'completed') return;

    const retailOrder = isOrderRetail(targetOrder);
    const cancelledAtIso = new Date().toISOString();
    const reason = retailOrder
      ? 'Cancelled by retail store owner from merchant end'
      : 'Cancelled by restaurant owner from merchant end';

    const updated = takeoutOrders.map(o =>
      o.id === orderId
        ? {
            ...o,
            status: 'cancelled' as const,
            cancelledAt: cancelledAtIso,
            cancelledReason: reason,
            ...(o.walletDeducted && !o.walletRefunded ? { walletRefunded: true } : {})
          }
        : o
    );
    setTakeoutOrders(updated);
    if (targetOrder.walletDeducted && !targetOrder.walletRefunded) {
      const payerId = targetOrder.customerWalletUserId || ledgerUserId;
      applyCurrencyWalletDelta({
        userId: payerId,
        currencySymbol: targetOrder.currency,
        delta: targetOrder.total,
        utilityNote: `Refund for cancelled order #${targetOrder.orderNumber} (${targetOrder.restaurantName})`
      });
      const loc = locations.find(l => l.id === targetOrder.restaurantId);
      if (loc?.ownerId && loc.ownerId !== payerId) {
        applyCurrencyWalletDelta({
          userId: loc.ownerId,
          currencySymbol: targetOrder.currency,
          delta: -targetOrder.total
        });
      }
    }
    try {
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(updated));
      window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
      const rawContracts = localStorage.getItem('final_finance_delivery_contracts');
      if (rawContracts) {
        const parsedContracts = JSON.parse(rawContracts);
        const nextContracts = parsedContracts.map((c: any) =>
          (c.takeoutOrderId === targetOrder.id || c.orderNumber === targetOrder.orderNumber) && c.status !== 'delivered'
            ? { ...c, status: 'cancelled' }
            : c
        );
        localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(nextContracts));
        window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));
      }
    } catch {}

    const updatedTxs = transactionsHistory.map(t =>
      t.receiptNumber === targetOrder.orderNumber
        ? { ...t, status: 'cancelled' as const, cancelledAt: cancelledAtIso }
        : t
    );
    setTransactionsHistory(updatedTxs);
    try {
      localStorage.setItem(`final_finance_pos_transactions_${merchantId}`, JSON.stringify(updatedTxs));
    } catch {}

    markLedgerItemReversedByReceipt(ledgerUserId, targetOrder.orderNumber);
    const cancellationLedgerEntry = createLedgerItemFromPOSCancellation({
      orderNumber: targetOrder.orderNumber,
      locationName: targetOrder.restaurantName,
      businessType: retailOrder ? 'retail' : 'restaurant',
      customerName: targetOrder.customerName,
      customerHandle: targetOrder.customerHandle,
      total: targetOrder.total,
      currency: targetOrder.currency,
      reason
    });
    recordLedgerToAll(cancellationLedgerEntry);
    window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

    dispatchGlobalNotification({
      title: `🛑 Order #${targetOrder.orderNumber} Cancelled by Owner`,
      description: `${targetOrder.restaurantName} owner cancelled order #${targetOrder.orderNumber} (${targetOrder.total.toLocaleString()} ${targetOrder.currency}). Reversal synced to Tax Ledger.`,
      type: 'pos',
      targetTab: 'dash_ledger',
      amount: targetOrder.total,
      currency: targetOrder.currency,
      showToast: true,
      tone: 'alert'
    });
  };

  const handleDispatchToDriver = (order: TakeoutOrder) => {
    try {
      const retailOrder = isOrderRetail(order);
      const businessType: 'retail' | 'restaurant' = retailOrder ? 'retail' : 'restaurant';
      const loc = locations.find(l => l.id === order.restaurantId);
      const pickupAddr =
        loc?.address ||
        (retailOrder ? 'Zurich Freeport Hub, Sector 4, 8048 Zürich' : 'Gessnerallee 28, 8001 Zürich');
      const deliveryAddr = order.deliveryAddress?.address || 'Zurich Freeport Vault 4B, 8048 Zürich';
      const distVal = Number(order.deliveryDistance ?? 4) || 4;
      const distUnit = order.deliveryDistanceUnit || loc?.deliveryFeeUnit || 'mile';
      const distMiles = distUnit === 'km' ? Math.max(0.5, Math.round(distVal * 0.621371 * 10) / 10) : distVal;
      const storeRate = loc?.deliveryFeeRate ?? 2.5;
      const storeFee = Number(order.deliveryFee ?? Math.round(storeRate * distVal * 100) / 100) || 10;
      const feeCurrency = order.deliveryFeeCurrency || loc?.deliveryFeeCurrency || order.currency || 'AFNL';

      const existingContractsRaw = localStorage.getItem('final_finance_delivery_contracts');
      const existingContracts: any[] = existingContractsRaw ? JSON.parse(existingContractsRaw) : [];

      const existingMatch = existingContracts.find(
        c => c.takeoutOrderId === order.id || c.orderNumber === order.orderNumber
      );

      if (existingMatch && existingMatch.status === 'accepted') {
        dispatchGlobalNotification({
          title: `🚗 Driver Already Assigned (#${order.orderNumber})`,
          description: `${existingMatch.driverName || 'A sovereign driver'} has already accepted this delivery.`,
          type: 'delivery',
          targetTab: 'ride_share',
          showToast: true,
          tone: 'default'
        });
        return;
      }

      const contractId = existingMatch?.id || `del-ord-${order.id}-${Date.now()}`;
      const newContract = {
        id: contractId,
        takeoutOrderId: order.id,
        orderNumber: order.orderNumber,
        merchantId: order.restaurantId,
        merchantName: order.restaurantName,
        businessType,
        pickupAddress: pickupAddr,
        deliveryAddress: deliveryAddr,
        customerName: order.customerName,
        deliveryFee: storeFee,
        originalStoreFee: storeFee,
        storeRatePerMile: storeRate,
        currency: feeCurrency,
        originalCurrency: feeCurrency,
        orderCurrency: order.currency,
        orderTotalBefore: order.originalTotal ?? order.total,
        status: 'available',
        createdAt: new Date().toISOString(),
        estimatedTime: `~${Math.max(8, Math.round(distMiles * 3.2))} mins`,
        distance: `${distVal} ${distUnit === 'km' ? 'km' : 'miles'}`,
        distanceMiles: distMiles
      };

      const nextContracts = existingMatch
        ? existingContracts.map(c => (c.id === existingMatch.id ? newContract : c))
        : [newContract, ...existingContracts];

      localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(nextContracts));

      // Push an explicit Delivery Dispatch Notification for the Driver's Delivery Dispatches tab
      const existingNotifs = JSON.parse(localStorage.getItem('final_finance_driver_delivery_notifications') || '[]');
      const driverNotif = {
        id: `drv-notif-${order.id}-${Date.now()}`,
        contractId,
        orderNumber: order.orderNumber,
        merchantName: order.restaurantName,
        businessType,
        pickupAddress: pickupAddr,
        deliveryAddress: deliveryAddr,
        customerName: order.customerName,
        distance: `${distVal} ${distUnit === 'km' ? 'km' : 'miles'}`,
        distanceMiles: distMiles,
        storeFee,
        storeFeeCurrency: feeCurrency,
        storeRatePerMile: storeRate,
        createdAt: new Date().toISOString(),
        read: false
      };
      const dedupedNotifs = [
        driverNotif,
        ...existingNotifs.filter((n: any) => n.orderNumber !== order.orderNumber)
      ].slice(0, 20);
      localStorage.setItem('final_finance_driver_delivery_notifications', JSON.stringify(dedupedNotifs));

      const updated = takeoutOrders.map(o =>
        o.id === order.id
          ? {
              ...o,
              dispatchedToDriver: true,
              dispatchedContractId: contractId,
              storeRatePerMile: storeRate,
              originalDeliveryFee: o.originalDeliveryFee ?? storeFee,
              originalDeliveryFeeCurrency: o.originalDeliveryFeeCurrency ?? feeCurrency,
              originalTotal: o.originalTotal ?? o.total
            }
          : o
      );
      setTakeoutOrders(updated);
      try {
        localStorage.setItem('final_finance_takeout_orders', JSON.stringify(updated));
      } catch {}

      window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));
      window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));

      dispatchGlobalNotification({
        title: `📦 New Delivery Dispatch Sent (#${order.orderNumber})`,
        description: `${order.restaurantName} (${businessType === 'retail' ? 'Online Retail' : 'Restaurant'}) requested a Ride-Share driver to deliver to ${deliveryAddr}. Drivers notified in Delivery Dispatches.`,
        type: 'delivery',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'success'
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateOrderStatus = (orderId: string, nextStatus: TakeoutOrder['status']) => {
    const targetOrder = takeoutOrders.find(o => o.id === orderId);
    if (!targetOrder || targetOrder.status === 'cancelled' || targetOrder.status === nextStatus) return;

    const updated = takeoutOrders.map(o => o.id === orderId ? { ...o, status: nextStatus } : o);
    setTakeoutOrders(updated);
    try {
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(updated));
    } catch {}

    const retailOrder = isOrderRetail(targetOrder);
    const isDelivery = targetOrder.fulfillmentType === 'delivery' || !!targetOrder.deliveryAddress;

    if (nextStatus === 'in_kitchen') {
      dispatchGlobalNotification({
        title: retailOrder
          ? `📦 Order #${targetOrder.orderNumber} Accepted & Preparing`
          : `👨‍🍳 Food Order #${targetOrder.orderNumber} Is In Kitchen`,
        description: retailOrder
          ? `${targetOrder.restaurantName} accepted your retail order for ${targetOrder.customerName} and started preparing your items.`
          : `${targetOrder.restaurantName} received your food order for ${targetOrder.customerName} and started cooking it in the kitchen.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'default'
      });
    } else if (nextStatus === 'ready_for_pickup') {
      const storeKind = retailOrder ? 'Store' : 'Restaurant';
      const hasDriverPriceUpdate = isDelivery && targetOrder.driverAccepted;
      const driverRateText = hasDriverPriceUpdate
        ? `${targetOrder.driverRatePerMile ?? 6} ${targetOrder.driverRateCurrency || targetOrder.deliveryFeeCurrency || targetOrder.currency}/mi`
        : '';
      const storeRateText = hasDriverPriceUpdate
        ? `${targetOrder.storeRatePerMile ?? 2.5} ${targetOrder.originalDeliveryFeeCurrency || targetOrder.currency}/mi`
        : '';

      dispatchGlobalNotification({
        title: retailOrder
          ? `🛍️ Retail Order #${targetOrder.orderNumber} Is Out for Delivery / Ready!`
          : `🍽️ Food Order #${targetOrder.orderNumber} Is Out for Delivery / Ready!`,
        description: hasDriverPriceUpdate
          ? `Out for delivery to ${targetOrder.deliveryAddress?.address || 'your saved address'}. Updated price: Driver Rate ${driverRateText} vs ${storeKind} Rate ${storeRateText} (Total: ${(targetOrder.originalTotal ?? targetOrder.total).toLocaleString()} → ${targetOrder.total.toLocaleString()} ${targetOrder.currency}). 5-minute cancel window active.`
          : isDelivery
            ? `Your order from ${targetOrder.restaurantName} is packed and out for delivery to ${targetOrder.deliveryAddress?.address || 'your saved address'}.`
            : `Your order at ${targetOrder.restaurantName} is ready for pickup (${targetOrder.total.toLocaleString()} ${targetOrder.currency}).`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'success'
      });
    } else if (nextStatus === 'completed') {
      dispatchGlobalNotification({
        title: retailOrder
          ? `✅ Retail Order #${targetOrder.orderNumber} Completed`
          : `✅ Food Order #${targetOrder.orderNumber} Completed`,
        description: `Completed ${targetOrder.restaurantName} order for ${targetOrder.customerName} (${targetOrder.total.toLocaleString()} ${targetOrder.currency}). Recorded in Tax Ledger.`,
        type: 'pos',
        targetTab: 'dash_ledger',
        amount: targetOrder.total,
        currency: targetOrder.currency,
        showToast: true,
        tone: 'success'
      });
    }
  };

  const handleCancelOnlineOrder = (orderId: string) => {
    const targetOrder = takeoutOrders.find(o => o.id === orderId);
    if (!targetOrder) return;

    const check = getCustomerCancellationStatus(targetOrder, Date.now());
    const retailOrder = isOrderRetail(targetOrder);
    if (!check.canCancel) {
      dispatchGlobalNotification({
        title: 'Cancellation Not Available',
        description: retailOrder
          ? `${targetOrder.restaurantName} has already accepted, prepared, or completed order #${targetOrder.orderNumber}.`
          : `Restaurant order #${targetOrder.orderNumber} can only be cancelled within 10 minutes of placing or before completion.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const cancelledAtIso = new Date().toISOString();
    const reason = retailOrder
      ? 'Cancelled by customer before retail store accepted/completed order'
      : 'Cancelled by customer within 10-minute restaurant window';

    const updatedOrders = takeoutOrders.map(o =>
      o.id === orderId
        ? {
            ...o,
            status: 'cancelled' as const,
            cancelledAt: cancelledAtIso,
            cancelledReason: reason,
            ...(o.walletDeducted && !o.walletRefunded ? { walletRefunded: true } : {})
          }
        : o
    );
    setTakeoutOrders(updatedOrders);
    if (targetOrder.walletDeducted && !targetOrder.walletRefunded) {
      const payerId = targetOrder.customerWalletUserId || ledgerUserId;
      applyCurrencyWalletDelta({
        userId: payerId,
        currencySymbol: targetOrder.currency,
        delta: targetOrder.total,
        utilityNote: `Refund for cancelled order #${targetOrder.orderNumber} (${targetOrder.restaurantName})`
      });
      const loc = locations.find(l => l.id === targetOrder.restaurantId);
      if (loc?.ownerId && loc.ownerId !== payerId) {
        applyCurrencyWalletDelta({
          userId: loc.ownerId,
          currencySymbol: targetOrder.currency,
          delta: -targetOrder.total
        });
      }
    }
    try {
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(updatedOrders));
      window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
      const rawContracts = localStorage.getItem('final_finance_delivery_contracts');
      if (rawContracts) {
        const parsedContracts = JSON.parse(rawContracts);
        const nextContracts = parsedContracts.map((c: any) =>
          (c.takeoutOrderId === targetOrder.id || c.orderNumber === targetOrder.orderNumber) && c.status !== 'delivered'
            ? { ...c, status: 'cancelled' }
            : c
        );
        localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(nextContracts));
        window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));
      }
    } catch {}

    const updatedTxs = transactionsHistory.map(t =>
      t.receiptNumber === targetOrder.orderNumber
        ? { ...t, status: 'cancelled' as const, cancelledAt: cancelledAtIso }
        : t
    );
    setTransactionsHistory(updatedTxs);
    try {
      localStorage.setItem(`final_finance_pos_transactions_${merchantId}`, JSON.stringify(updatedTxs));
    } catch {}

    // Reverse original Tax Ledger entry & record offsetting refund entry
    markLedgerItemReversedByReceipt(ledgerUserId, targetOrder.orderNumber);
    const cancellationLedgerEntry = createLedgerItemFromPOSCancellation({
      orderNumber: targetOrder.orderNumber,
      locationName: targetOrder.restaurantName,
      businessType: retailOrder ? 'retail' : 'restaurant',
      customerName: targetOrder.customerName,
      customerHandle: targetOrder.customerHandle,
      total: targetOrder.total,
      currency: targetOrder.currency,
      reason
    });
    recordLedgerToAll(cancellationLedgerEntry);
    window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

    dispatchGlobalNotification({
      title: `🛑 Order #${targetOrder.orderNumber} Cancelled & Refunded`,
      description: `Cancelled ${targetOrder.restaurantName} order (${targetOrder.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${targetOrder.currency}). Reversal recorded in Tax Ledger.`,
      type: 'pos',
      targetTab: 'dash_ledger',
      amount: targetOrder.total,
      currency: targetOrder.currency,
      showToast: true,
      tone: 'alert'
    });
  };

  const handleProcessPayment = () => {
    if (cart.length === 0) return;
    setPosWalkInError('');

    let chosenAddress: DeliveryAddress | undefined = undefined;
    if (posWalkInFulfillment === 'delivery') {
      const targetAddrId = posWalkInAddressId || deliveryAddresses.find(a => a.isDefault)?.id || deliveryAddresses[0]?.id;
      chosenAddress = deliveryAddresses.find(a => a.id === targetAddrId);
      if (!chosenAddress) {
        setPosWalkInError('Please select or add & save a delivery address before settling a delivery order.');
        dispatchGlobalNotification({
          title: 'Saved Delivery Address Required',
          description: 'Please add or select one of the saved delivery addresses for delivery.',
          type: 'pos',
          targetTab: 'point_of_sale',
          showToast: true,
          tone: 'alert'
        });
        return;
      }
    }

    setIsProcessingPayment(true);

    setTimeout(() => {
      const dateObj = new Date();
      const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
      const receiptNo = `REC-POS-${Math.floor(100000 + Math.random() * 900000)}`;

      const currentMode = mainTab === 'retail' ? 'retail' : 'restaurant';
      const resolvedName = posWalkInCustomerName.trim() || chosenAddress?.fullName || customerQrInput.trim() || 'Walk-in Customer';
      const resolvedPhone = posWalkInCustomerPhone.trim() || chosenAddress?.phone || undefined;
      const resolvedEmail = posWalkInCustomerEmail.trim() || chosenAddress?.email || undefined;

      const ledgerEntry = createLedgerItemFromPOSSale({
        receiptNumber: receiptNo,
        locationName: activeLocation.name,
        businessType: currentMode,
        channel: currentMode === 'restaurant' ? 'in_restaurant' : 'in_store',
        fulfillmentType: posWalkInFulfillment === 'delivery' ? 'delivery' : (currentMode === 'restaurant' ? 'dine_in' : 'pickup'),
        customerName: resolvedName,
        customerHandle: customerQrInput.trim() || resolvedName,
        itemsSummary: cart.map(c => `${c.quantity}x ${c.name}`).join(', '),
        itemCount: cart.reduce((s, c) => s + c.quantity, 0),
        subtotal,
        tax,
        tip,
        total,
        currency: checkoutCurrency
      });

      const tx: SalesTransaction = {
        id: `pos-tx-${Date.now()}`,
        receiptNumber: receiptNo,
        timestamp: dateStr,
        mode: currentMode,
        txChannel: currentMode === 'restaurant' ? 'in_restaurant' : 'in_store',
        locationId: activeLocationId,
        tableOrRegister: currentMode === 'restaurant' ? selectedTable : 'Register Terminal 01',
        items: [...cart],
        subtotal,
        tax,
        tip,
        total,
        currency: checkoutCurrency,
        paymentMethod: `${checkoutCurrency} (Final Currency)`,
        customerHandle: customerQrInput.trim() || resolvedName,
        customerName: resolvedName,
        customerPhone: resolvedPhone,
        customerEmail: resolvedEmail,
        fulfillmentType: posWalkInFulfillment === 'delivery' ? 'delivery' : (currentMode === 'restaurant' ? 'dine_in' : 'pickup'),
        deliveryAddress: chosenAddress,
        status: 'settled',
        ledgerEntryId: ledgerEntry.id
      };

      // Also log into active location orders so full customer info (address & phone) appears directly in Checkout
      const posOrder: TakeoutOrder = {
        id: `pos-ord-${Date.now()}`,
        orderNumber: receiptNo,
        restaurantId: activeLocationId,
        restaurantName: activeLocation.name,
        customerHandle: customerQrInput.trim() || resolvedName,
        customerName: resolvedName,
        customerPhone: resolvedPhone,
        customerEmail: resolvedEmail,
        fulfillmentType: posWalkInFulfillment,
        orderChannel: currentMode === 'restaurant' ? 'in_restaurant' : 'in_store',
        items: cart.map(c => ({ item: c, quantity: c.quantity })),
        subtotal,
        tax,
        tip,
        total,
        currency: checkoutCurrency,
        pickupTime: posWalkInFulfillment === 'delivery' && chosenAddress
          ? `Delivery to ${chosenAddress.address}`
          : currentMode === 'restaurant'
            ? `${selectedTable} — Counter / Table`
            : `In-Store Pickup — ${activeLocation.address}`,
        status: 'completed',
        createdAt: dateObj.toISOString(),
        deliveryAddress: chosenAddress,
        ledgerEntryId: ledgerEntry.id
      };
      setTakeoutOrders(prev => {
        const nextOrders = [posOrder, ...prev];
        try {
          localStorage.setItem('final_finance_takeout_orders', JSON.stringify(nextOrders));
        } catch {}
        return nextOrders;
      });

      const cleanCustomerQr = customerQrInput.trim().replace(/^@/, '');
      if (cleanCustomerQr && cleanCustomerQr !== merchantId) {
        try {
          if (localStorage.getItem(`final_finance_wallets_${cleanCustomerQr}`)) {
            applyCurrencyWalletDelta({
              userId: cleanCustomerQr,
              currencySymbol: checkoutCurrency,
              delta: -total
            });
          }
        } catch {}
      }
      applyCurrencyWalletDelta({
        userId: merchantId,
        currencySymbol: checkoutCurrency,
        delta: total,
        utilityNote: `POS register settlement at ${activeLocation.name} (${receiptNo})`
      });

      recordLedgerToAll(ledgerEntry);
      window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

      dispatchGlobalNotification({
        title: `🛍️ POS Sale Completed (${receiptNo})`,
        description: `Successfully collected ${total.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 2})} ${checkoutCurrency} at ${activeLocation.name}. Synced to Tax Ledger.`,
        type: 'pos',
        targetTab: 'dash_ledger',
        amount: total,
        currency: checkoutCurrency,
        showToast: true,
        tone: 'success'
      });

      const updatedTxs = [tx, ...transactionsHistory];
      setTransactionsHistory(updatedTxs);
      try {
        localStorage.setItem(`final_finance_pos_transactions_${merchantId}`, JSON.stringify(updatedTxs));
      } catch {}

      setCart([]);
      setCustomerQrInput('');
      setCustomTip('');
      setPosWalkInCustomerName('');
      setPosWalkInCustomerPhone('');
      setPosWalkInCustomerEmail('');
      setPosWalkInFulfillment('pickup');
      setIsProcessingPayment(false);
      setIsCheckoutModalOpen(false);
    }, 600);
  };

  // Add Dish to Online Takeout Menu (Up to 100 dishes per restaurant)
  const handleAddOnlineMenuDish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onlineDishTitle.trim() || !onlineDishPrice) return;
    const priceNum = parseFloat(onlineDishPrice);
    if (isNaN(priceNum) || priceNum <= 0) return;

    if (onlineMenuDishes.length >= 100) {
      dispatchGlobalNotification({
        title: 'Menu Limit Reached',
        description: 'Maximum 100 dishes online per restaurant.',
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const acceptedList = onlineDishCurrencies.length > 0 ? onlineDishCurrencies.slice(0, 5) : ['AFNL'];
    const primaryCurrency = acceptedList[0];

    const dishId = `dish-onl-${Date.now()}`;
    const generatedQrs: POSItemQRCode[] = [];

    if (onlineDishAddOneTimeQR) {
      generatedQrs.push({
        type: 'one-time',
        payload: `ff:pos:onetime:${primaryCurrency}:${priceNum}:${dishId}:${Date.now()}:${merchantId}`,
        createdAt: new Date().toISOString().split('T')[0],
        label: `${onlineDishTitle.trim()} (Online One-Time Invoice)`
      });
    }
    if (onlineDishAddInventoryQR) {
      generatedQrs.push({
        type: 'inventory',
        payload: `ff:pos:inventory:${primaryCurrency}:${priceNum}:${dishId}:${merchantId}`,
        createdAt: new Date().toISOString().split('T')[0],
        label: `${onlineDishTitle.trim()} (Online Inventory Tag)`
      });
    }

    const newDish: CatalogItem = {
      id: dishId,
      name: onlineDishTitle.trim(),
      category: onlineDishCategory.trim() || 'Entrees',
      price: priceNum,
      currency: primaryCurrency,
      acceptedCurrencies: acceptedList,
      type: 'restaurant',
      stock: 50,
      description: onlineDishDescription.trim() || undefined,
      image: onlineDishPhotos[0] || undefined,
      photos: [...onlineDishPhotos],
      videos: [...onlineDishVideos],
      qrCodes: generatedQrs
    };

    const nextDishes = [newDish, ...onlineMenuDishes];
    saveCatalog('restaurant', nextDishes, activeLocationId, 'online');

    setOnlineDishTitle('');
    setOnlineDishPrice('');
    setOnlineDishDescription('');
    setOnlineDishPhotos([]);
    setOnlineDishVideos([]);
    setOnlineDishMediaUrl('');

    dispatchGlobalNotification({
      title: '🍽️ Dish Added to Online Menu',
      description: `Added "${newDish.name}" (${acceptedList.join(' / ')}) for ${activeLocation.name}. Now ${nextDishes.length}/100 dishes online.`,
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'success'
    });
  };

  const handleSyncRestaurantCatalogToOnline = () => {
    const merged = [...restaurantCatalog];
    saveCatalog('restaurant', merged, activeLocationId, 'online');

    dispatchGlobalNotification({
      title: 'Synchronized All Dishes Online',
      description: `Published ${merged.length} items from ${activeLocation.name} menu to online takeout menu.`,
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'success'
    });
  };

  const preloadUserReviewForLoc = (locId: string) => {
    const existing = reviewsList.find(r => r.storeId === locId && r.userId === (currentUser?.id || 'you'));
    if (existing) {
      setUserRatingScore(existing.rating);
      setUserReviewComment(existing.comment);
    } else {
      setUserRatingScore(5);
      setUserReviewComment('');
    }
  };

  // Open Dedicated Reviews & Ratings Modal for a store or restaurant
  const handleOpenReviewsModal = (loc: MerchantLocation) => {
    setReviewsModalLocation(loc);
    preloadUserReviewForLoc(loc.id);
  };

  // Open Dedicated Store / Restaurant Separate Page (Shows Online & In-Store/In-Restaurant Tabs + Tailored Search & Categories)
  const handleOpenStoreModal = (loc: MerchantLocation, initialTab: 'online' | 'instore' = 'online') => {
    setMainTab('directory');
    setCustomerSubTab(loc.type === 'restaurant' ? 'restaurants' : 'retail');
    setViewingLocation(loc);
    setModalChannelTab(initialTab);
    setExpandedModalItemId(null);
    setStorePageSearchQuery('');
    setStorePageCategory('All');
    preloadUserReviewForLoc(loc.id);
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Submit / Update User Rating & Review (Strictly updates existing review if already left one)
  const handleSaveStoreReview = (e: React.FormEvent, targetLoc: MerchantLocation | null = viewingLocation || reviewsModalLocation) => {
    e.preventDefault();
    if (!targetLoc) return;
    const currentUserId = currentUser?.id || 'you';
    const currentUserHandle = currentUser?.id || 'sovereign_guest';
    const currentUserName = currentUser?.name || 'Sovereign Patron';

    const existingIdx = reviewsList.findIndex(r => r.storeId === targetLoc.id && r.userId === currentUserId);
    const dateStr = new Date().toISOString().split('T')[0];

    let updatedReviews: StoreReview[];
    if (existingIdx !== -1) {
      updatedReviews = reviewsList.map((r, idx) => {
        if (idx === existingIdx) {
          return {
            ...r,
            rating: userRatingScore,
            comment: userReviewComment.trim(),
            updatedAt: dateStr
          };
        }
        return r;
      });
    } else {
      const newReview: StoreReview = {
        id: `rev-${Date.now()}`,
        storeId: targetLoc.id,
        userId: currentUserId,
        userHandle: currentUserHandle,
        userName: currentUserName,
        rating: userRatingScore,
        comment: userReviewComment.trim(),
        updatedAt: dateStr
      };
      updatedReviews = [newReview, ...reviewsList];
    }

    saveReviews(updatedReviews);
    dispatchGlobalNotification({
      title: existingIdx !== -1 ? 'Review Updated' : 'Review Submitted',
      description: `Rated ${userRatingScore} ★ for ${targetLoc.name}.`,
      type: 'pos',
      targetTab: 'point_of_sale',
      showToast: true,
      tone: 'success'
    });
  };

  const isLocationDeliveryActive = (loc: MerchantLocation): boolean => {
    const canDeliver = loc.type === 'retail' || !!loc.allowsDelivery;
    return canDeliver && customerFulfillmentByLoc[loc.id] === 'delivery';
  };

  const getInlineAddrForm = (locId: string) => {
    return inlineAddrFormByLoc[locId] || {
      open: deliveryAddresses.length === 0,
      label: '',
      fullName: currentUser?.name || '',
      phone: customerPhoneByLoc[locId] || '',
      email: '',
      address: '',
      error: ''
    };
  };

  const updateInlineAddrForm = (
    locId: string,
    patch: Partial<{ open: boolean; label: string; fullName: string; phone: string; email: string; address: string; error: string }>
  ) => {
    setInlineAddrFormByLoc(prev => {
      const curr = prev[locId] || {
        open: deliveryAddresses.length === 0,
        label: '',
        fullName: currentUser?.name || '',
        phone: customerPhoneByLoc[locId] || '',
        email: '',
        address: '',
        error: ''
      };
      return { ...prev, [locId]: { ...curr, ...patch } };
    });
  };

  // Per-Location Totals Helper (Used inside Store/Restaurant Modal & Customer Checkout Section)
  const computeLocCartTotals = (loc: MerchantLocation) => {
    const locBag = getCustomerLocCart(loc.id);
    const sub = locBag.reduce((sum, i) => sum + (i.item.price * i.quantity), 0);
    const locTax = sub * 0.05;
    const customTipStr = customerCustomTipByLoc[loc.id] || '';
    const tipPct = customerTipPctByLoc[loc.id] ?? (loc.type === 'retail' ? 0 : 15);
    const locTip = customTipStr !== '' && !isNaN(parseFloat(customTipStr))
      ? Math.max(0, parseFloat(customTipStr))
      : (sub * tipPct) / 100;
    const locCurrency = getCustomerCurrencyForLoc(loc);

    const isDelivery = isLocationDeliveryActive(loc);
    const feeRate = isDelivery ? Math.max(0, loc.deliveryFeeRate ?? 0) : 0;
    const feeCurrency = loc.deliveryFeeCurrency || locCurrency;
    const feeUnit: 'mile' | 'km' = loc.deliveryFeeUnit || 'mile';
    const rawDist = customerDistanceByLoc[loc.id];
    const distance = isDelivery
      ? Math.max(0, rawDist !== undefined ? (parseFloat(rawDist) || 0) : 5)
      : 0;
    const deliveryFee = isDelivery ? feeRate * distance : 0;
    const deliveryFeeMatchesCurrency = feeCurrency === locCurrency;
    const locTotal = sub + locTax + locTip + (isDelivery && deliveryFeeMatchesCurrency ? deliveryFee : 0);

    return {
      locBag,
      sub,
      locTax,
      locTip,
      locTotal,
      locCurrency,
      tipPct,
      customTipStr,
      isDelivery,
      feeRate,
      feeCurrency,
      feeUnit,
      distance,
      deliveryFee,
      deliveryFeeMatchesCurrency
    };
  };

  // Customer Cart & Order Settlement inside Store/Restaurant Modal
  const takeoutSubtotal = useMemo(() => {
    return takeoutBag.reduce((sum, i) => sum + (i.item.price * i.quantity), 0);
  }, [takeoutBag]);

  const takeoutTax = takeoutSubtotal * 0.05;

  const takeoutTip = useMemo(() => {
    if (takeoutCustomTip !== '' && !isNaN(parseFloat(takeoutCustomTip))) {
      return Math.max(0, parseFloat(takeoutCustomTip));
    }
    return (takeoutSubtotal * takeoutTipPercentage) / 100;
  }, [takeoutSubtotal, takeoutTipPercentage, takeoutCustomTip]);

  const takeoutTotal = viewingLocation ? computeLocCartTotals(viewingLocation).locTotal : (takeoutSubtotal + takeoutTax + takeoutTip);

  const handleSaveInlineAddressForLoc = (locId: string): DeliveryAddress | null => {
    const form = getInlineAddrForm(locId);
    const fallbackName = form.fullName.trim() || customerNameByLoc[locId]?.trim() || '';
    if (!fallbackName || !form.address.trim()) {
      updateInlineAddrForm(locId, { error: 'Please enter Recipient Full Name and Full Delivery Street Address.' });
      return null;
    }
    const phoneToSave = (form.phone.trim() || customerPhoneByLoc[locId]?.trim() || '') || undefined;
    const emailToSave = (form.email.trim() || customerEmailByLoc[locId]?.trim() || '') || undefined;
    const newAddr: DeliveryAddress = {
      id: `addr-${Date.now()}`,
      label: form.label.trim() || `Address ${deliveryAddresses.length + 1}`,
      fullName: fallbackName,
      phone: phoneToSave,
      email: emailToSave,
      address: form.address.trim(),
      isDefault: deliveryAddresses.length === 0
    };
    if (deliveryAddresses.length < 20) {
      persistDeliveryAddresses([...deliveryAddresses, newAddr]);
      setSelectedDeliveryAddressIdByLoc(prev => ({ ...prev, [locId]: newAddr.id }));
      dispatchGlobalNotification({
        title: 'Delivery Address Saved',
        description: `Saved "${newAddr.label}" for ${newAddr.fullName} and selected for checkout.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'success'
      });
    }
    updateInlineAddrForm(locId, { open: false, label: '', fullName: '', phone: '', email: '', address: '', error: '' });
    return newAddr;
  };

  const handlePlaceTakeoutOrder = (targetLoc: MerchantLocation | null = viewingLocation) => {
    if (!targetLoc) return;

    const customerId = currentUser?.id || currentUser?.uid || 'guest';
    if (targetLoc.ownerId && areUsersBlockedEitherWay(customerId, targetLoc.ownerId)) {
      dispatchGlobalNotification({
        title: 'Online Order Blocked',
        description: 'Online orders are disabled because your account is blocked by this store/restaurant owner. You may still place an order in person by visiting the retail store or dining in at the restaurant.',
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const {
      locBag,
      sub,
      locTax,
      locTip,
      locTotal,
      locCurrency,
      isDelivery,
      feeCurrency,
      feeUnit,
      distance,
      deliveryFee
    } = computeLocCartTotals(targetLoc);

    if (locBag.length === 0) return;

    const userId = currentUser?.id || currentUser?.uid || 'guest';
    const availableBalance = getWalletCurrencyBalance(userId, locCurrency);

    if (availableBalance < locTotal) {
      dispatchGlobalNotification({
        title: 'Insufficient Settlement Balance',
        description: `You do not have enough ${locCurrency} in your wallet (Required: ${locTotal.toLocaleString()} ${locCurrency}, Available: ${availableBalance.toLocaleString()} ${locCurrency}).`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    if (targetLoc.type === 'restaurant' && targetLoc.isOpenForTakeout === false) {
      dispatchGlobalNotification({
        title: 'Restaurant Ordering Paused',
        description: `${targetLoc.name} has paused takeout & online orders.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    let chosenAddress: DeliveryAddress | undefined = undefined;
    if (isDelivery) {
      const selectedAddrId = selectedDeliveryAddressIdByLoc[targetLoc.id];
      chosenAddress = deliveryAddresses.find(a => a.id === selectedAddrId) || deliveryAddresses.find(a => a.isDefault) || deliveryAddresses[0];

      const inlineForm = getInlineAddrForm(targetLoc.id);
      const hasInlineEntry = !!(inlineForm.address.trim() || (inlineForm.open && inlineForm.fullName.trim()));
      if (!chosenAddress || (inlineForm.open && hasInlineEntry)) {
        const saved = handleSaveInlineAddressForLoc(targetLoc.id);
        if (!saved && !chosenAddress) {
          updateInlineAddrForm(targetLoc.id, { open: true, error: 'Please enter Recipient Full Name and Full Delivery Street Address.' });
          dispatchGlobalNotification({
            title: 'Delivery Address Required',
            description: 'Please enter or select a delivery address before placing a delivery order.',
            type: 'pos',
            targetTab: 'point_of_sale',
            showToast: true,
            tone: 'alert'
          });
          return;
        }
        if (saved) chosenAddress = saved;
      }

      if (!chosenAddress) {
        updateInlineAddrForm(targetLoc.id, { open: true, error: 'Please add or select a saved delivery address to continue.' });
        dispatchGlobalNotification({
          title: 'Saved Delivery Address Required',
          description: 'Please add or select a delivery address before placing a delivery order.',
          type: 'pos',
          targetTab: 'point_of_sale',
          showToast: true,
          tone: 'alert'
        });
        return;
      }
    }

    const locNotes = customerNotesByLoc[targetLoc.id] || '';
    const locPickupTime = customerPickupTimeByLoc[targetLoc.id] || 'ASAP (15-20 min)';
    const explicitCustomerName = customerNameByLoc[targetLoc.id]?.trim();
    const customerNameResolved = explicitCustomerName || chosenAddress?.fullName || currentUser?.name || 'Customer';
    const optionalPhone = (customerPhoneByLoc[targetLoc.id]?.trim() || chosenAddress?.phone?.trim() || '') || undefined;
    const customerEmailResolved = (customerEmailByLoc[targetLoc.id]?.trim() || chosenAddress?.email?.trim() || '') || undefined;
    const customerHandleResolved = explicitCustomerName
      ? explicitCustomerName.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'customer'
      : (currentUser?.id || chosenAddress?.fullName?.toLowerCase().replace(/[^a-z0-9]+/g, '_') || 'guest_buyer');

    const orderId = targetLoc.type === 'retail'
      ? `ORD-RET-${Math.floor(100000 + Math.random() * 900000)}`
      : `ORD-TK-${Math.floor(100000 + Math.random() * 900000)}`;

    const ledgerEntry = createLedgerItemFromPOSSale({
      receiptNumber: orderId,
      locationName: targetLoc.name,
      businessType: targetLoc.type,
      channel: 'online',
      fulfillmentType: isDelivery ? 'delivery' : 'pickup',
      customerName: customerNameResolved,
      customerHandle: customerHandleResolved,
      itemsSummary: locBag.map(b => `${b.quantity}x ${b.item.name}`).join(', '),
      itemCount: locBag.reduce((s, b) => s + b.quantity, 0),
      subtotal: sub,
      tax: locTax,
      tip: locTip,
      deliveryFee: isDelivery ? deliveryFee : 0,
      total: locTotal,
      currency: locCurrency
    });

    const debitRes = applyCurrencyWalletDelta({
      userId,
      currencySymbol: locCurrency,
      delta: -locTotal,
      requireSufficientBalance: true
    });
    if (!debitRes.success) {
      dispatchGlobalNotification({
        title: 'Insufficient Settlement Balance',
        description: debitRes.error || `You do not have enough ${locCurrency} in your wallet.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'alert'
      });
      return;
    }
    if (targetLoc.ownerId && targetLoc.ownerId !== userId) {
      applyCurrencyWalletDelta({
        userId: targetLoc.ownerId,
        currencySymbol: locCurrency,
        delta: locTotal,
        utilityNote: `Online order #${orderId} settlement from ${customerNameResolved}`
      });
    }

    const newOrder: TakeoutOrder = {
      id: `tk-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      orderNumber: orderId,
      restaurantId: targetLoc.id,
      restaurantName: targetLoc.name,
      customerHandle: customerHandleResolved,
      customerName: customerNameResolved,
      customerPhone: optionalPhone,
      customerEmail: customerEmailResolved,
      fulfillmentType: isDelivery ? 'delivery' : 'pickup',
      orderChannel: 'online',
      items: [...locBag],
      subtotal: sub,
      tax: locTax,
      tip: locTip,
      total: locTotal,
      currency: locCurrency,
      pickupTime: isDelivery && chosenAddress
        ? `Online Delivery to ${chosenAddress.address}`
        : targetLoc.type === 'retail'
          ? `In-Store Pickup (${locPickupTime}) — ${targetLoc.address}`
          : `Takeout Counter Pickup (${locPickupTime}) — ${targetLoc.address}`,
      status: 'received',
      createdAt: new Date().toISOString(),
      notes: locNotes.trim() || undefined,
      deliveryAddress: isDelivery ? chosenAddress : undefined,
      ledgerEntryId: ledgerEntry.id,
      customerWalletUserId: userId,
      walletDeducted: true,
      walletRefunded: false,
      ...(isDelivery ? {
        deliveryFee,
        deliveryFeeCurrency: feeCurrency,
        deliveryDistance: distance,
        deliveryDistanceUnit: feeUnit
      } : {})
    };

    setTakeoutOrders(prev => {
      const updatedOrders = [newOrder, ...prev];
      try {
        localStorage.setItem('final_finance_takeout_orders', JSON.stringify(updatedOrders));
        window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
      } catch {}
      return updatedOrders;
    });

    // Record settlement in sales history for the target store/restaurant
    const tx: SalesTransaction = {
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      receiptNumber: orderId,
      timestamp: new Date().toLocaleString(),
      mode: targetLoc.type,
      txChannel: 'online',
      locationId: targetLoc.id,
      tableOrRegister: targetLoc.type === 'retail'
        ? isDelivery
          ? `Online Retail Delivery (${targetLoc.name})`
          : `Online Retail Pickup (${targetLoc.name})`
        : isDelivery
          ? `Online Restaurant Delivery (${targetLoc.name})`
          : `Online Takeout Checkout (${targetLoc.name})`,
      items: locBag.map(b => ({
        id: b.item.id,
        name: b.item.name,
        category: b.item.category,
        price: b.item.price,
        currency: b.item.currency,
        acceptedCurrencies: b.item.acceptedCurrencies,
        type: b.item.type,
        quantity: b.quantity
      })),
      subtotal: sub,
      tax: locTax,
      tip: locTip,
      total: locTotal,
      currency: locCurrency,
      paymentMethod: `${locCurrency} Direct Settlement`,
      customerHandle: customerHandleResolved,
      customerName: customerNameResolved,
      customerPhone: optionalPhone,
      customerEmail: customerEmailResolved,
      fulfillmentType: isDelivery ? 'delivery' : 'pickup',
      deliveryAddress: isDelivery ? chosenAddress : undefined,
      status: 'settled',
      ledgerEntryId: ledgerEntry.id
    };
    setTransactionsHistory(prev => {
      const updatedTxs = [tx, ...prev];
      try {
        localStorage.setItem(`final_finance_pos_transactions_${merchantId}`, JSON.stringify(updatedTxs));
      } catch {}
      return updatedTxs;
    });

    // Sync Online Retail & Restaurant order with Universal Tax Ledger
    recordLedgerToAll(ledgerEntry);
    window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

    dispatchGlobalNotification({
      title: targetLoc.type === 'retail'
        ? (isDelivery ? `🚚 Retail Delivery Received (${orderId})` : `🛍️ Store Pickup Received (${orderId})`)
        : isDelivery
          ? `🚗 Food Delivery Received (${orderId})`
          : `🍱 Takeout Order Received (${orderId})`,
      description: `Status: Received • ${customerNameResolved} (${locTotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${locCurrency}) at ${targetLoc.name}. Track live status in Online Orders & Tax Ledger.`,
      type: 'pos',
      targetTab: 'dash_ledger',
      amount: locTotal,
      currency: locCurrency,
      showToast: true,
      tone: 'success'
    });

    setLastTakeoutOrder(newOrder);
    setIsTakeoutSuccessModalOpen(true);
    clearCustomerLocCart(targetLoc.id);
    setCustomerNameByLoc(prev => ({ ...prev, [targetLoc.id]: '' }));
    setCustomerPhoneByLoc(prev => ({ ...prev, [targetLoc.id]: '' }));
    setCustomerEmailByLoc(prev => ({ ...prev, [targetLoc.id]: '' }));
    setCustomerNotesByLoc(prev => ({ ...prev, [targetLoc.id]: '' }));
    setCustomerCustomTipByLoc(prev => ({ ...prev, [targetLoc.id]: '' }));
  };

  // Shared Fulfillment & Saved Delivery Address Picker (Available for BOTH Restaurant & Retail)
  const renderLocationFulfillmentControls = (
    loc: MerchantLocation,
    totals: ReturnType<typeof computeLocCartTotals>,
    isInModal: boolean = false
  ) => {
    const selectedAddrId = selectedDeliveryAddressIdByLoc[loc.id]
      || deliveryAddresses.find(a => a.isDefault)?.id
      || deliveryAddresses[0]?.id
      || '';
    const isRestaurant = loc.type === 'restaurant';
    const canDeliver = loc.type === 'retail' || !!loc.allowsDelivery;
    const fulfillment = canDeliver && customerFulfillmentByLoc[loc.id] === 'delivery' ? 'delivery' : 'pickup';
    const deliveryFeeDisplayRate = Math.max(0, loc.deliveryFeeRate ?? 0);
    const deliveryFeeDisplayCurrency = loc.deliveryFeeCurrency || totals.locCurrency;
    const deliveryFeeDisplayUnit: 'mile' | 'km' = loc.deliveryFeeUnit || 'mile';
    const inlineForm = getInlineAddrForm(loc.id);

    return (
      <div className="space-y-2.5 text-center">
        {/* Customer Name + Optional Phone & Email for Multiple Different Customers */}
        <div className="space-y-1.5 text-center">
          <label className="text-[10px] font-bold text-neutral-600 uppercase font-mono block text-center">
            Customer Contact Details
          </label>
          <input
            type="text"
            placeholder="Customer Name (e.g. Alice Vance)"
            value={customerNameByLoc[loc.id] ?? (currentUser?.name || '')}
            onChange={(e) => setCustomerNameByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
            className="w-full px-3 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 text-center"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            <input
              type="tel"
              placeholder="Phone Number (Optional)"
              value={customerPhoneByLoc[loc.id] || ''}
              onChange={(e) => setCustomerPhoneByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
              className="w-full px-3 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 text-center"
            />
            <input
              type="email"
              placeholder="Email (Optional)"
              value={customerEmailByLoc[loc.id] || ''}
              onChange={(e) => setCustomerEmailByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
              className="w-full px-3 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 text-center"
            />
          </div>
        </div>

        {/* Fulfillment Mode Toggle (BOTH Retail & Restaurant when delivery enabled) */}
        {canDeliver ? (
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-neutral-600 uppercase font-mono block text-center">
              Choose Order Fulfillment
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setCustomerFulfillmentByLoc(prev => ({ ...prev, [loc.id]: 'pickup' }))}
                className={`px-2.5 py-2 rounded-xl text-[11px] font-bold border transition-all cursor-pointer text-center ${
                  fulfillment === 'pickup'
                    ? (isRestaurant ? 'bg-amber-600 text-white border-amber-600 shadow-2xs' : 'bg-indigo-600 text-white border-indigo-600 shadow-2xs')
                    : 'bg-white hover:bg-neutral-50 text-neutral-800 border-neutral-200'
                }`}
              >
                {isRestaurant ? 'Takeout Pickup (Free)' : 'In-Store Pickup (Free)'}
              </button>
              <button
                type="button"
                onClick={() => setCustomerFulfillmentByLoc(prev => ({ ...prev, [loc.id]: 'delivery' }))}
                className={`px-2.5 py-2 rounded-xl text-[11px] font-bold border transition-all cursor-pointer text-center ${
                  fulfillment === 'delivery'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                    : 'bg-white hover:bg-emerald-50 text-neutral-800 border-neutral-200'
                }`}
              >
                Delivery ({deliveryFeeDisplayRate > 0 ? `${deliveryFeeDisplayRate} ${deliveryFeeDisplayCurrency}/${deliveryFeeDisplayUnit}` : 'Free'})
              </button>
            </div>
          </div>
        ) : (
          <label className="text-[10px] font-bold text-neutral-600 uppercase font-mono block text-center">
            Takeout Pickup Only (Pick Up In Person)
          </label>
        )}

        {/* Saved Delivery Address Selection / Inline Save Required for Delivery */}
        {fulfillment === 'delivery' ? (
          <div className="space-y-2 text-center">
              <div className="flex flex-wrap items-center justify-center gap-2">
              <label className="text-[10px] font-bold text-neutral-600 uppercase font-mono">
                Select Saved Delivery Address *
              </label>
              {deliveryAddresses.length > 0 && (
                <button
                  type="button"
                  onClick={() => updateInlineAddrForm(loc.id, { open: !inlineForm.open, error: '' })}
                  className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 cursor-pointer"
                >
                  {inlineForm.open ? 'Use Saved Address' : `+ Add New Address (${deliveryAddresses.length})`}
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  if (isInModal) setViewingLocation(null);
                  setMainTab('directory');
                  setCustomerSubTab(loc.type === 'retail' ? 'retail' : 'restaurants');
                  setExplorerSectionView('delivery_address');
                }}
                className="text-[10px] font-bold text-indigo-700 hover:underline cursor-pointer"
              >
                Manage Saved ({deliveryAddresses.length})
              </button>
            </div>

            {deliveryAddresses.length > 0 && !inlineForm.open ? (
              <div className="space-y-1.5">
                <select
                  value={selectedAddrId}
                  onChange={(e) => setSelectedDeliveryAddressIdByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 font-medium cursor-pointer text-center"
                >
                  {deliveryAddresses.map(addr => (
                    <option key={addr.id} value={addr.id}>
                      {addr.label ? `${addr.label}: ` : ''}{addr.fullName} • {addr.address}{addr.phone ? ` (${addr.phone})` : ''}
                    </option>
                  ))}
                </select>
                {(() => {
                  const chosen = deliveryAddresses.find(a => a.id === selectedAddrId);
                  if (!chosen) return null;
                  return (
                    <p className="text-[10px] text-neutral-500 text-center">
                      Recipient: <span className="font-semibold text-neutral-800">{chosen.fullName}</span>
                      {chosen.phone ? ` • ${chosen.phone}` : ''}
                      {chosen.email ? ` • ${chosen.email}` : ''}
                    </p>
                  );
                })()}
              </div>
            ) : (
              <div className="p-3 rounded-2xl bg-white border border-indigo-200 space-y-2 text-center">
                <p className="text-[10px] font-bold text-indigo-900 uppercase font-mono">
                  {deliveryAddresses.length === 0 ? 'Add & Save a Delivery Address to Order' : 'Add New Delivery Address'}
                </p>
                {inlineForm.error && (
                  <p className="text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-2 py-1">
                    {inlineForm.error}
                  </p>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  <input
                    type="text"
                    placeholder="Recipient Full Name *"
                    value={inlineForm.fullName}
                    onChange={(e) => updateInlineAddrForm(loc.id, { fullName: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-center text-neutral-900"
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number (Optional)"
                    value={inlineForm.phone}
                    onChange={(e) => updateInlineAddrForm(loc.id, { phone: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-center text-neutral-900"
                  />
                  <input
                    type="email"
                    placeholder="Email (Optional)"
                    value={inlineForm.email}
                    onChange={(e) => updateInlineAddrForm(loc.id, { email: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-center text-neutral-900"
                  />
                  <input
                    type="text"
                    placeholder="Label (e.g. Home, Office)"
                    value={inlineForm.label}
                    onChange={(e) => updateInlineAddrForm(loc.id, { label: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-center text-neutral-900"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Full Delivery Street Address, City, Postal Code *"
                  value={inlineForm.address}
                  onChange={(e) => updateInlineAddrForm(loc.id, { address: e.target.value })}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-center text-neutral-900"
                />
                <button
                  type="button"
                  onClick={() => handleSaveInlineAddressForLoc(loc.id)}
                  className="w-full py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold cursor-pointer"
                >
                  Save &amp; Select Delivery Address
                </button>
              </div>
            )}

            {/* Distance + Clear Rate & Total Impact */}
            <div className="p-2.5 rounded-xl bg-indigo-50/70 border border-indigo-200/80 space-y-1 text-center">
              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="text-[10px] font-bold text-indigo-950 whitespace-nowrap">
                  Distance ({totals.feeUnit === 'km' ? 'km' : 'miles'}):
                </span>
                <input
                  type="number"
                  min={0}
                  step="any"
                  value={customerDistanceByLoc[loc.id] ?? '5'}
                  onChange={(e) => setCustomerDistanceByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
                  className="w-20 px-2 py-1 rounded-lg bg-white border border-indigo-200 text-xs font-mono font-bold text-neutral-900 text-center"
                />
              </div>
              <p className="text-[11px] font-mono font-bold text-indigo-900">
                Delivery Fee: {totals.feeRate > 0 ? `${totals.feeRate} ${totals.feeCurrency} per ${totals.feeUnit}` : `0 ${totals.feeCurrency}`}
                {totals.deliveryFee > 0 ? ` = ${totals.deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${totals.feeCurrency}` : ''}
              </p>
              <p className="text-[11px] font-mono font-extrabold text-emerald-800">
                New Total: {totals.locTotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {totals.locCurrency}
                {totals.deliveryFee > 0 && !totals.deliveryFeeMatchesCurrency
                  ? ` + ${totals.deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${totals.feeCurrency}`
                  : ''}
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-2 text-center">
            <div className="px-3 py-2 rounded-xl bg-amber-50/80 border border-amber-200 text-[11px] text-amber-950 space-y-0.5 text-center">
              <p className="font-bold">{isRestaurant ? 'Counter Pickup' : 'In-Store Pickup'} at {loc.name}</p>
              <p className="text-[10px] text-amber-800">{loc.address}</p>
            </div>
            <select
              value={customerPickupTimeByLoc[loc.id] || 'ASAP (15-20 min)'}
              onChange={(e) => setCustomerPickupTimeByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
              className="w-full px-3 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 font-medium cursor-pointer text-center"
            >
              <option value="ASAP (15-20 min)">Pickup: ASAP (15-20 min)</option>
              <option value="In 30 min">Pickup: In 30 min</option>
              <option value="In 45 min">Pickup: In 45 min</option>
              <option value="In 1 hour">Pickup: In 1 hour</option>
            </select>
          </div>
        )}
      </div>
    );
  };

  // Multi-Final Currency selector (up to 5 currencies per product or dish)
  const renderMultiCurrencySelector = (
    selectedList: string[],
    onToggle: (symbol: string) => void,
    targetKey: 'inventory_add' | 'online_retail_add' | 'online_menu_add' | 'item_edit_currencies',
    accent: 'indigo' | 'amber' = 'indigo'
  ) => {
    const activeBorder = accent === 'amber' ? 'bg-amber-600 text-white border-amber-600' : 'bg-indigo-600 text-white border-indigo-600';
    const quickCoins = allFinalCurrencies.slice(0, 6);
    const extraSelected = selectedList.filter(sym => !quickCoins.some(q => q.symbol === sym));
    return (
      <div className="w-full p-3 rounded-2xl bg-neutral-50 border border-neutral-200/90 space-y-2 text-center">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-[11px] font-bold text-neutral-800 font-mono uppercase">
            Accepted Final Currencies ({selectedList.length}/5)
          </span>
          <button
            type="button"
            onClick={() => {
              setCurrencyTarget(targetKey);
              setCurrencyModalSearch('');
              setIsCurrencyModalOpen(true);
            }}
            className="text-[11px] font-bold text-indigo-700 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Search className="w-3 h-3" />
            <span>Browse All ({allFinalCurrencies.length})</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-1.5">
          {quickCoins.map(coin => {
            const isSelected = selectedList.includes(coin.symbol);
            return (
              <button
                key={`${targetKey}-${coin.symbol}`}
                type="button"
                onClick={() => onToggle(coin.symbol)}
                className={`px-2.5 py-1.5 rounded-xl text-[11px] font-mono font-bold border transition-all flex items-center gap-1 cursor-pointer ${
                  isSelected
                    ? `${activeBorder} shadow-2xs`
                    : 'bg-white hover:bg-neutral-100 text-neutral-700 border-neutral-200'
                }`}
              >
                <span>{coin.icon}</span>
                <span>{coin.symbol}</span>
                {isSelected && <CheckCircle2 className="w-3 h-3 shrink-0" />}
              </button>
            );
          })}
          {extraSelected.map(sym => {
            const coin = allFinalCurrencies.find(c => c.symbol === sym);
            return (
              <button
                key={`${targetKey}-extra-${sym}`}
                type="button"
                onClick={() => onToggle(sym)}
                className={`px-2.5 py-1.5 rounded-xl text-[11px] font-mono font-bold border transition-all flex items-center gap-1 cursor-pointer ${activeBorder}`}
              >
                <span>{coin?.icon || '⚡'}</span>
                <span>{sym}</span>
                <CheckCircle2 className="w-3 h-3 shrink-0" />
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  const getItemBarcode = (item: CatalogItem): string =>
    (item.barcode?.trim() || DEFAULT_RETAIL_BARCODE_BY_ID[item.id] || '').trim();

  const stopBarcodeCamera = () => {
    if (barcodeStreamRef.current) {
      barcodeStreamRef.current.getTracks().forEach(track => {
        try { track.stop(); } catch {}
      });
      barcodeStreamRef.current = null;
    }
    if (barcodeVideoRef.current) {
      try { barcodeVideoRef.current.srcObject = null; } catch {}
    }
    setIsCameraScanning(false);
  };

  const handleProcessScannedBarcode = (rawCode: string): boolean => {
    const clean = rawCode.trim();
    if (!clean) return false;
    const mergedEntries = getMergedLocationItems(activeLocation);
    const lower = clean.toLowerCase();
    const matched = mergedEntries.find(({ item }) => {
      const bc = getItemBarcode(item).toLowerCase();
      const qrMatch = (item.qrCodes || []).some(qr => qr.payload.toLowerCase() === lower);
      return (bc && bc === lower) || qrMatch || item.id.toLowerCase() === lower;
    });

    if (matched) {
      addToCart(matched.item);
      setBarcodeScanFeedback({
        type: 'success',
        message: `Added 1x "${matched.item.name}" (${matched.item.price.toLocaleString()} ${matched.item.currency}) to ticket.`
      });
      setBarcodeScanInput('');
      dispatchGlobalNotification({
        title: 'Barcode Scanned',
        description: `Added "${matched.item.name}" to ${activeLocation.name} checkout ticket.`,
        type: 'pos',
        targetTab: 'point_of_sale',
        showToast: true,
        tone: 'success'
      });
      return true;
    }

    setBarcodeScanFeedback({
      type: 'error',
      message: `No product found in ${activeLocation.name} with barcode/QR "${clean}".`
    });
    return false;
  };

  const startBarcodeCamera = async () => {
    setCameraScanError('');
    setBarcodeScanFeedback(null);
    if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraScanError('Camera access is not available in this browser. Use a USB barcode scanner or type/paste the barcode below.');
      return;
    }
    try {
      stopBarcodeCamera();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } }
      });
      barcodeStreamRef.current = stream;
      setIsCameraScanning(true);
      setTimeout(() => {
        if (barcodeVideoRef.current) {
          barcodeVideoRef.current.srcObject = stream;
          barcodeVideoRef.current.play().catch(() => {});
        }
      }, 60);
    } catch {
      setCameraScanError('Unable to access camera. Check camera permissions or enter/scan the barcode with a USB scanner below.');
      setIsCameraScanning(false);
    }
  };

  useEffect(() => {
    if (!isBarcodeScannerOpen) {
      stopBarcodeCamera();
      return;
    }
    if (!isCameraScanning) return;

    const DetectorCtor = typeof window !== 'undefined' ? (window as unknown as { BarcodeDetector?: new (opts?: { formats?: string[] }) => { detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue?: string }>> } }).BarcodeDetector : undefined;
    if (!DetectorCtor) {
      setCameraScanError('Live optical BarcodeDetector is not built into this browser. Use the auto-focused USB/manual barcode box below.');
      return;
    }

    let cancelled = false;
    let lastCode = '';
    let lastScanAt = 0;
    const detector = new DetectorCtor({
      formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'qr_code']
    });

    const intervalId = window.setInterval(async () => {
      if (cancelled || !barcodeVideoRef.current || barcodeVideoRef.current.readyState < 2) return;
      try {
        const codes = await detector.detect(barcodeVideoRef.current);
        if (codes && codes.length > 0 && codes[0].rawValue) {
          const val = codes[0].rawValue.trim();
          const now = Date.now();
          if (val && (val !== lastCode || now - lastScanAt > 2000)) {
            lastCode = val;
            lastScanAt = now;
            handleProcessScannedBarcode(val);
          }
        }
      } catch {}
    }, 350);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [isBarcodeScannerOpen, isCameraScanning, activeLocationId]);

  useEffect(() => {
    return () => {
      stopBarcodeCamera();
    };
  }, []);

  // Shared Merchant Checkout View (Two Side-by-Side Tabs: In-Store/In-Restaurant Checkout + Online Orders)
  const renderMerchantCheckoutOrdersAndTerminal = (mode: 'retail' | 'restaurant') => {
    const isRestaurant = mode === 'restaurant';
    const mergedEntries = getMergedLocationItems(activeLocation);
    const invQ = posInventorySearch.trim().toLowerCase();

    // Dynamic menu categories for Restaurant Dine-In table ordering
    const menuCategories = isRestaurant
      ? Array.from(new Set(mergedEntries.map(({ item }) => (item.category || 'General').trim()).filter(Boolean)))
      : [];
    const activeMenuCategory = isRestaurant && posMenuCategory !== 'All' && menuCategories.includes(posMenuCategory)
      ? posMenuCategory
      : 'All';

    const categoryScopedEntries = isRestaurant && activeMenuCategory !== 'All'
      ? mergedEntries.filter(({ item }) => (item.category || 'General').trim() === activeMenuCategory)
      : mergedEntries;

    const matchedInventoryEntries = invQ
      ? categoryScopedEntries.filter(({ item }) => {
          const nameMatch = item.name.toLowerCase().includes(invQ);
          const catMatch = item.category.toLowerCase().includes(invQ);
          const idMatch = item.id.toLowerCase().includes(invQ);
          const bc = getItemBarcode(item).toLowerCase();
          const barcodeMatch = !!bc && bc.includes(invQ);
          const descMatch = !!item.description && item.description.toLowerCase().includes(invQ);
          const qrMatch = (item.qrCodes || []).some(qr =>
            qr.payload.toLowerCase().includes(invQ) ||
            (qr.label && qr.label.toLowerCase().includes(invQ))
          );
          return nameMatch || catMatch || idMatch || barcodeMatch || descMatch || qrMatch;
        })
      : categoryScopedEntries;

    const exactScanMatchedEntry = invQ
      ? mergedEntries.find(({ item }) => {
          const bc = getItemBarcode(item).toLowerCase();
          const qrExact = (item.qrCodes || []).some(qr => qr.payload.toLowerCase() === invQ);
          return (bc && bc === invQ) || qrExact;
        })
      : undefined;

    const isOnlineOrder = (o: TakeoutOrder) =>
      o.orderChannel ? o.orderChannel === 'online' : !o.orderNumber.startsWith('REC-POS-');

    const typeLocations = locations.filter(l => l.type === mode);
    const typeLocationIds = new Set(typeLocations.map(l => l.id));
    const matchesBusinessMode = (o: TakeoutOrder) => {
      if (typeLocationIds.has(o.restaurantId)) return true;
      return isRestaurant
        ? o.orderNumber.startsWith('ORD-TK-')
        : o.orderNumber.startsWith('ORD-RET-');
    };

    const allTypeOnlineOrders = takeoutOrders.filter(o => isOnlineOrder(o) && matchesBusinessMode(o));
    const activeLocOnlineOrders = allTypeOnlineOrders.filter(o => o.restaurantId === activeLocationId);
    const onlineOrders = onlineOrdersLocationScope === 'active_location'
      ? activeLocOnlineOrders
      : allTypeOnlineOrders;

    const pendingOnlineOrdersCount = onlineOrders.filter(o => o.status !== 'completed' && o.status !== 'cancelled').length;
    const inPersonOrders = takeoutOrders.filter(o => o.restaurantId === activeLocationId && !isOnlineOrder(o));
    const isOnlineTabActive = isRestaurant
      ? restaurantCheckoutSectionTab === 'online_orders'
      : retailCheckoutSectionTab === 'online_orders';
    const sectionOrders = isOnlineTabActive ? onlineOrders : inPersonOrders;
    const statusFilteredOrders = merchantOrderStatusFilter === 'all'
      ? sectionOrders
      : merchantOrderStatusFilter === 'active'
        ? sectionOrders.filter(o => o.status !== 'completed' && o.status !== 'cancelled')
        : sectionOrders.filter(o => o.status === merchantOrderStatusFilter);

    const ordSearch = isOnlineTabActive ? onlineOrdersSearch.trim().toLowerCase() : '';
    const filteredOrders = ordSearch
      ? statusFilteredOrders.filter(o =>
          o.customerName.toLowerCase().includes(ordSearch) ||
          o.customerHandle.toLowerCase().includes(ordSearch) ||
          (o.customerPhone && o.customerPhone.toLowerCase().includes(ordSearch)) ||
          (o.customerEmail && o.customerEmail.toLowerCase().includes(ordSearch)) ||
          o.orderNumber.toLowerCase().includes(ordSearch) ||
          o.restaurantName.toLowerCase().includes(ordSearch) ||
          (o.deliveryAddress && (
            o.deliveryAddress.fullName.toLowerCase().includes(ordSearch) ||
            o.deliveryAddress.address.toLowerCase().includes(ordSearch)
          )) ||
          o.items.some(i => i.item.name.toLowerCase().includes(ordSearch))
        )
      : statusFilteredOrders;

    const uniqueCustomerNamesCount = new Set(
      onlineOrders.map(o => `${o.customerName.trim().toLowerCase()}::${(o.customerPhone || o.deliveryAddress?.address || '').trim().toLowerCase()}`)
    ).size;

    const canDeliver = !isRestaurant || !!activeLocation.allowsDelivery;
    const selectedAddrId = posWalkInAddressId || deliveryAddresses.find(a => a.isDefault)?.id || deliveryAddresses[0]?.id || '';
    const chosenWalkInAddress = deliveryAddresses.find(a => a.id === selectedAddrId);

    const handleSavePosWalkInAddress = () => {
      if (!posWalkInNewAddrName.trim() || !posWalkInNewAddrStreet.trim()) {
        setPosWalkInError('Please enter Recipient Full Name and Full Delivery Address.');
        return;
      }
      const newAddr: DeliveryAddress = {
        id: `addr-${Date.now()}`,
        label: posWalkInNewAddrLabel.trim() || `Address ${deliveryAddresses.length + 1}`,
        fullName: posWalkInNewAddrName.trim(),
        phone: (posWalkInNewAddrPhone.trim() || posWalkInCustomerPhone.trim()) || undefined,
        email: (posWalkInNewAddrEmail.trim() || posWalkInCustomerEmail.trim()) || undefined,
        address: posWalkInNewAddrStreet.trim(),
        isDefault: deliveryAddresses.length === 0
      };
      if (deliveryAddresses.length < 20) {
        persistDeliveryAddresses([...deliveryAddresses, newAddr]);
      }
      setPosWalkInAddressId(newAddr.id);
      setPosWalkInShowAddAddr(false);
      setPosWalkInNewAddrLabel('');
      setPosWalkInNewAddrName('');
      setPosWalkInNewAddrPhone('');
      setPosWalkInNewAddrEmail('');
      setPosWalkInNewAddrStreet('');
      setPosWalkInError('');
    };

    const renderOrderCardsList = () => (
      <div className="space-y-4 max-h-[560px] overflow-y-auto pr-1 text-center">
        {filteredOrders.length === 0 ? (
          <p className="text-xs text-neutral-500 text-center py-4 bg-neutral-50 rounded-2xl border border-neutral-200/70">
            {isOnlineTabActive
              ? (ordSearch ? `No online orders matching "${onlineOrdersSearch}".` : 'No online orders yet.')
              : `No ${isRestaurant ? 'in-restaurant' : 'in-store'} checkouts yet.`}
          </p>
        ) : (
          filteredOrders.map(order => {
            const isDelivery = order.fulfillmentType === 'delivery' || !!order.deliveryAddress;
            const displayPhone = order.customerPhone || order.deliveryAddress?.phone;
            const displayEmail = order.customerEmail || order.deliveryAddress?.email;
            return (
              <div key={order.id} className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200/90 space-y-4 text-center">
                <div className="flex flex-col items-center justify-center gap-2 pb-3 border-b border-neutral-200/70 text-center">
                  <div className="space-y-1.5 flex flex-col items-center justify-center">
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      <span className="text-xs font-extrabold text-neutral-900 font-mono">{order.orderNumber}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                        isRestaurant
                          ? 'bg-amber-50 text-amber-900 border-amber-200'
                          : 'bg-indigo-50 text-indigo-900 border-indigo-200'
                      }`}>
                        {order.restaurantName}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase border ${
                        order.status === 'cancelled'
                          ? 'bg-rose-50 text-rose-800 border-rose-200'
                          : order.status === 'completed'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : order.status === 'ready_for_pickup'
                              ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                              : 'bg-amber-50 text-amber-900 border-amber-200'
                      }`}>
                        {order.status === 'in_kitchen'
                          ? (isRestaurant ? 'In Kitchen' : 'Preparing')
                          : order.status === 'ready_for_pickup'
                            ? 'Ready'
                            : order.status.replace(/_/g, ' ')}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                        isDelivery
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-neutral-100 text-neutral-700 border-neutral-200'
                      }`}>
                        {isDelivery ? 'Delivery Order' : (isOnlineTabActive ? 'Online Pickup' : (isRestaurant ? 'In-Restaurant' : 'In-Store'))}
                      </span>
                    </div>
                    <p className="text-[10px] text-neutral-400 font-mono text-center">
                      Placed: {new Date(order.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="text-center pt-1">
                    {order.driverAccepted ? (
                      <div className="space-y-0.5">
                        <p className="text-[11px] font-mono text-neutral-500 line-through">
                          Before: {(order.originalTotal ?? order.total).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                        </p>
                        <p className="text-sm font-extrabold text-emerald-700 font-mono">
                          After: {order.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                          {order.deliveryFeeCurrency && order.deliveryFeeCurrency !== order.currency && order.updatedDeliveryFee
                            ? ` + ${order.updatedDeliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${order.deliveryFeeCurrency}`
                            : ''}
                        </p>
                        <p className="text-[10px] text-emerald-700 font-mono font-bold">
                          Driver Rate Applied ({order.driverName})
                        </p>
                      </div>
                    ) : (
                      <>
                        <p className="text-sm font-extrabold text-emerald-700 font-mono">
                          {order.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                        </p>
                        <p className="text-[10px] text-neutral-500 font-mono">
                          Settled in {order.currency}
                        </p>
                      </>
                    )}
                  </div>
                </div>

                {/* Full Customer Information Card - Centered */}
                <div className="p-3.5 rounded-xl bg-white border border-neutral-200/80 flex flex-col items-center justify-center text-center gap-3 text-xs">
                  <div className="space-y-1.5 w-full flex flex-col items-center justify-center">
                    <span className="text-[10px] font-bold uppercase font-mono text-neutral-400 block">Customer</span>
                    <p className="font-bold text-neutral-900 flex items-center justify-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      <span>{order.customerName}</span>
                      {order.customerHandle && (
                        <span className="text-[11px] font-mono text-neutral-500 font-normal">@{order.customerHandle}</span>
                      )}
                    </p>
                    <p className="text-neutral-700 flex items-center justify-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      <span className="font-mono">{displayPhone || 'Phone not provided (Optional)'}</span>
                    </p>
                    {displayEmail && (
                      <p className="text-neutral-700 flex items-center justify-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                        <span>{displayEmail}</span>
                      </p>
                    )}
                  </div>

                  <div className="space-y-1.5 w-full flex flex-col items-center justify-center pt-2 border-t border-neutral-100">
                    <span className="text-[10px] font-bold uppercase font-mono text-neutral-400 block">
                      {isDelivery ? 'Delivery Address & Recipient' : 'Pickup / Service Details'}
                    </span>
                    {order.deliveryAddress ? (
                      <div className="space-y-0.5 text-neutral-700 flex flex-col items-center justify-center text-center">
                        <p className="font-bold text-indigo-900">
                          {order.deliveryAddress.label ? `[${order.deliveryAddress.label}] ` : ''}{order.deliveryAddress.fullName}
                        </p>
                        <p className="flex items-start justify-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                          <span>{order.deliveryAddress.address}</span>
                        </p>
                        {order.deliveryFee !== undefined && order.deliveryFee > 0 && (
                          <div className="text-[11px] font-mono text-indigo-800 text-center space-y-0.5">
                            <p>
                              Distance: {order.deliveryDistance ?? 0} {order.deliveryDistanceUnit || 'mile'} •{' '}
                              {order.driverAccepted ? (
                                <>
                                  <span className="line-through text-neutral-500 mr-1.5">
                                    Store: {(order.originalDeliveryFee ?? order.deliveryFee).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.originalDeliveryFeeCurrency || order.currency}
                                  </span>
                                  <span className="font-bold text-emerald-700">
                                    Driver: {(order.updatedDeliveryFee ?? order.deliveryFee).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.deliveryFeeCurrency || order.currency}
                                  </span>
                                </>
                              ) : (
                                <span>
                                  Fee: {order.deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.deliveryFeeCurrency || order.currency}
                                </span>
                              )}
                            </p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-neutral-700 flex items-start justify-center gap-1.5 text-center">
                        <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span>{order.pickupTime}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Clear Itemized Breakdown: What This Customer Bought - Centered */}
                <div className="p-3.5 rounded-xl bg-white border border-neutral-200/80 space-y-2 text-xs text-center">
                  <div className="flex flex-col items-center justify-center gap-0.5 pb-1 border-b border-neutral-100">
                    <span className="text-[10px] font-bold uppercase font-mono text-neutral-500">
                      Purchased by {order.customerName}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-neutral-500">
                      {order.items.reduce((s, i) => s + i.quantity, 0)} item(s)
                    </span>
                  </div>
                  <div className="divide-y divide-neutral-100 space-y-1">
                    {order.items.map((line, idx) => (
                      <div key={`${order.id}-it-${idx}`} className="py-1.5 flex flex-col sm:flex-row items-center justify-between gap-1 text-center">
                        <div className="min-w-0 flex-1 text-center">
                          <span className="font-bold text-neutral-900">{line.quantity}x {line.item.name}</span>
                          <span className="text-[10px] text-neutral-500 ml-1.5">({line.item.category})</span>
                        </div>
                        <span className="font-mono font-semibold text-neutral-800 shrink-0 text-center">
                          {(line.item.price * line.quantity).toLocaleString()} {line.item.currency}
                        </span>
                      </div>
                    ))}
                  </div>
                  {order.notes && (
                    <p className="text-[11px] text-neutral-600 bg-amber-50/70 border border-amber-200/70 rounded-lg px-2.5 py-1 text-center">
                      Customer Notes: {order.notes}
                    </p>
                  )}
                </div>

                {order.status === 'cancelled' && (
                  <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-[11px] text-rose-800 flex flex-wrap items-center justify-between gap-2">
                    <span className="font-bold flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                      <span>{order.cancelledReason || 'Order cancelled by customer'}</span>
                    </span>
                    {order.cancelledAt && (
                      <span className="font-mono text-[10px] text-rose-700">
                        {new Date(order.cancelledAt).toLocaleString()} • Tax Ledger Reversed
                      </span>
                    )}
                  </div>
                )}

                    {/* Status Controls (Order stays active until Mark Completed is clicked or Cancelled by customer) */}
                {order.status !== 'completed' && order.status !== 'cancelled' && (
                  <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                    {order.status === 'received' && (
                      <button
                        type="button"
                        onClick={() => handleUpdateOrderStatus(order.id, 'in_kitchen')}
                        className="px-2.5 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 text-[11px] font-bold cursor-pointer"
                      >
                        {isRestaurant ? 'Mark In Kitchen' : 'Mark Preparing'}
                      </button>
                    )}
                    {(order.status === 'received' || order.status === 'in_kitchen' || (order.status === 'ready_for_pickup' && isDelivery)) && (
                      <div className="flex items-center gap-1.5 flex-wrap justify-center">
                        {(order.status === 'received' || order.status === 'in_kitchen') && (
                          <button
                            type="button"
                            onClick={() => handleUpdateOrderStatus(order.id, 'ready_for_pickup')}
                            className="px-2.5 py-1 rounded-lg bg-indigo-100 hover:bg-indigo-200 text-indigo-900 text-[11px] font-bold cursor-pointer"
                          >
                            {isDelivery ? 'Out for Delivery / Ready' : 'Ready for Pickup'}
                          </button>
                        )}
                        {isDelivery && (
                          order.driverAccepted ? (
                            <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300 text-[11px] font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                              <span>Driver Accepted: {order.driverName}</span>
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleDispatchToDriver(order)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer flex items-center gap-1 transition-colors ${
                                order.dispatchedToDriver
                                  ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                                  : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900'
                              }`}
                            >
                              <Car className="w-3 h-3" />
                              <span>{order.dispatchedToDriver ? 'Driver Pinged ✓' : 'Driver'}</span>
                            </button>
                          )
                        )}
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => handleUpdateOrderStatus(order.id, 'completed')}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer"
                    >
                      Mark Completed
                    </button>
                    <button
                      type="button"
                      onClick={() => handleMerchantCancelOrder(order.id)}
                      className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 border border-rose-300 text-[11px] font-bold cursor-pointer transition-colors"
                    >
                      Cancel Order
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    );

    return (
      <div className="space-y-4">
        {/* TWO SIDE-BY-SIDE SECTION TABS: (1) In-Store / In-Restaurant Checkout | (2) Online Orders */}
        <div className="grid grid-cols-2 gap-2 p-1.5 bg-neutral-100 border border-neutral-200/80 rounded-2xl max-w-3xl mx-auto">
          <button
            type="button"
            onClick={() => {
              if (isRestaurant) setRestaurantCheckoutSectionTab('in_restaurant');
              else setRetailCheckoutSectionTab('in_store');
              setMerchantOrderStatusFilter('all');
            }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              !isOnlineTabActive
                ? (isRestaurant ? 'bg-amber-600 text-white shadow-xs' : 'bg-indigo-600 text-white shadow-xs')
                : 'text-neutral-700 hover:text-neutral-900 hover:bg-white/60'
            }`}
          >
            <Receipt className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{isRestaurant ? 'In-Restaurant Checkout' : 'In-Store Checkout'}</span>
            <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono ${
              !isOnlineTabActive ? 'bg-white/20 text-white' : 'bg-neutral-200/80 text-neutral-700'
            }`}>
              {inPersonOrders.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (isRestaurant) setRestaurantCheckoutSectionTab('online_orders');
              else setRetailCheckoutSectionTab('online_orders');
              setMerchantOrderStatusFilter('all');
            }}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              isOnlineTabActive
                ? (isRestaurant ? 'bg-amber-600 text-white shadow-xs' : 'bg-indigo-600 text-white shadow-xs')
                : 'text-neutral-700 hover:text-neutral-900 hover:bg-white/60'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Online Orders</span>
            <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono ${
              isOnlineTabActive ? 'bg-white/20 text-white' : 'bg-neutral-200/80 text-neutral-700'
            }`}>
              {allTypeOnlineOrders.length}
            </span>
          </button>
        </div>

        {/* ONE UNIFIED DISPLAY PER TAB (CENTER ALIGNED) */}
        <div className="max-w-3xl mx-auto bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5 text-center">
          {isOnlineTabActive ? (
            <>
              <div className="flex flex-col items-center justify-center text-center gap-2 pb-3 border-b border-neutral-100">
                <div className="flex items-center justify-center gap-2">
                  <ShoppingBag className={`w-4 h-4 shrink-0 ${isRestaurant ? 'text-amber-600' : 'text-indigo-600'}`} />
                  <h3 className="font-serif-lux text-base sm:text-lg font-bold text-neutral-900">
                    {onlineOrdersLocationScope === 'all_locations'
                      ? (isRestaurant ? 'All Restaurants — Online Orders' : 'All Retail Stores — Online Orders')
                      : `${activeLocation.name} — Online Orders`}
                  </h3>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-xl ${
                    isRestaurant ? 'bg-amber-50 text-amber-900 border border-amber-200' : 'bg-indigo-50 text-indigo-900 border border-indigo-200'
                  }`}>
                    {uniqueCustomerNamesCount} {uniqueCustomerNamesCount === 1 ? 'Customer' : 'Customers'} • {onlineOrders.length} {onlineOrders.length === 1 ? 'Order' : 'Orders'}
                  </span>
                  {pendingOnlineOrdersCount > 0 && (
                    <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-amber-100 text-amber-900 border border-amber-300">
                      {pendingOnlineOrdersCount} Pending Until Done
                    </span>
                  )}
                </div>
              </div>

              {/* Centered Location Scope & Customer Search */}
              <div className="flex flex-col items-center justify-center gap-2.5">
                <div className="flex flex-wrap items-center justify-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setOnlineOrdersLocationScope('all_locations')}
                    className={`px-3 py-1 rounded-xl text-[11px] font-bold border cursor-pointer transition-colors ${
                      onlineOrdersLocationScope === 'all_locations'
                        ? 'bg-neutral-900 text-white border-neutral-900'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    All {isRestaurant ? 'Restaurants' : 'Stores'} ({allTypeOnlineOrders.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setOnlineOrdersLocationScope('active_location')}
                    className={`px-3 py-1 rounded-xl text-[11px] font-bold border cursor-pointer transition-colors truncate max-w-[240px] ${
                      onlineOrdersLocationScope === 'active_location'
                        ? 'bg-neutral-900 text-white border-neutral-900'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    {activeLocation.name} ({activeLocOnlineOrders.length})
                  </button>
                </div>

                <div className="relative w-full max-w-md mx-auto">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Filter by customer, item, or order #..."
                    value={onlineOrdersSearch}
                    onChange={(e) => setOnlineOrdersSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-1.5">
                {([
                  { id: 'all', label: `All (${onlineOrders.length})` },
                  { id: 'active', label: `Active (${pendingOnlineOrdersCount})` },
                  { id: 'received', label: 'Received' },
                  { id: 'in_kitchen', label: isRestaurant ? 'In Kitchen' : 'Preparing' },
                  { id: 'ready_for_pickup', label: 'Ready' },
                  { id: 'completed', label: 'Completed' },
                  { id: 'cancelled', label: 'Cancelled' },
                ] as const).map(st => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setMerchantOrderStatusFilter(st.id)}
                    className={`px-3 py-1 rounded-xl text-[11px] font-bold border cursor-pointer transition-colors ${
                      merchantOrderStatusFilter === st.id
                        ? (isRestaurant ? 'bg-amber-600 text-white border-amber-600' : 'bg-indigo-600 text-white border-indigo-600')
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>

              {renderOrderCardsList()}
            </>
          ) : (
            <>
              {/* Single Unified Centered Header */}
              <div className="flex flex-col items-center justify-center text-center gap-2 pb-3 border-b border-neutral-100">
                <div className="flex items-center justify-center gap-2">
                  <Receipt className="w-4 h-4 text-emerald-600 shrink-0" />
                  <h3 className="font-serif-lux text-base sm:text-lg font-bold text-neutral-900">
                    {activeLocation.name} — {isRestaurant ? 'In-Restaurant Checkout' : 'In-Store Checkout'}
                  </h3>
                </div>
                <span className={`text-xs font-mono font-bold px-3 py-1 rounded-lg ${
                  isRestaurant ? 'bg-amber-50 text-amber-800 border border-amber-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                }`}>
                  {isRestaurant ? selectedTable : 'Register Terminal 01'}
                </span>
              </div>

              {/* Inventory / Menu Picker */}
              <div className="space-y-3">
                {mergedEntries.length === 0 ? (
                  <button
                    type="button"
                    onClick={() => isRestaurant ? setRestaurantSubTab('add_item') : setRetailSubTab('add_item')}
                    className="w-full max-w-sm mx-auto py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-xs font-bold text-neutral-800 cursor-pointer block"
                  >
                    + Add First {isRestaurant ? 'Dish' : 'Product'}
                  </button>
                ) : (
                  <div className="space-y-3">
                    {/* Restaurant: Category Pills for Dine-In Table Menu Ordering */}
                    {isRestaurant && menuCategories.length > 0 && (
                      <div className="flex flex-wrap items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPosMenuCategory('All')}
                          className={`px-3 py-1 rounded-xl text-[11px] font-bold border cursor-pointer transition-colors ${
                            activeMenuCategory === 'All'
                              ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                              : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-amber-50'
                          }`}
                        >
                          All Categories ({mergedEntries.length})
                        </button>
                        {menuCategories.map(cat => {
                          const catCount = mergedEntries.filter(({ item }) => (item.category || 'General').trim() === cat).length;
                          return (
                            <button
                              key={`pos-cat-${cat}`}
                              type="button"
                              onClick={() => setPosMenuCategory(cat)}
                              className={`px-3 py-1 rounded-xl text-[11px] font-bold border cursor-pointer transition-colors ${
                                activeMenuCategory === cat
                                  ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                                  : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-amber-50'
                              }`}
                            >
                              {cat} ({catCount})
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* Search Bar + Retail Scan Barcode Button */}
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-2 max-w-xl mx-auto">
                      <div className="relative flex-1 w-full">
                        <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="text"
                          placeholder={isRestaurant
                            ? (activeMenuCategory === 'All'
                              ? `Search dish to add to ${selectedTable}...`
                              : `Search ${activeMenuCategory} to add to ${selectedTable}...`)
                            : 'Type product name, barcode, or QR code (ff:pos:...)'}
                          value={posInventorySearch}
                          onChange={(e) => setPosInventorySearch(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              if (exactScanMatchedEntry) {
                                addToCart(exactScanMatchedEntry.item);
                                setPosInventorySearch('');
                              } else if (matchedInventoryEntries.length === 1) {
                                addToCart(matchedInventoryEntries[0].item);
                                setPosInventorySearch('');
                              }
                            }
                          }}
                          className="w-full pl-8 pr-8 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center"
                        />
                        {posInventorySearch && (
                          <button
                            type="button"
                            onClick={() => setPosInventorySearch('')}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[11px] font-bold text-neutral-400 hover:text-neutral-700 cursor-pointer"
                            aria-label="Clear inventory search"
                          >
                            ✕
                          </button>
                        )}
                      </div>

                      {!isRestaurant && (
                        <button
                          type="button"
                          onClick={() => {
                            setBarcodeScanInput('');
                            setBarcodeScanFeedback(null);
                            setCameraScanError('');
                            setIsBarcodeScannerOpen(true);
                          }}
                          className="w-full sm:w-auto px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shrink-0 cursor-pointer shadow-2xs"
                        >
                          <ScanBarcode className="w-4 h-4 shrink-0" />
                          <span>Scan Barcode</span>
                        </button>
                      )}

                      {exactScanMatchedEntry && (
                        <button
                          type="button"
                          onClick={() => {
                            addToCart(exactScanMatchedEntry.item);
                            setPosInventorySearch('');
                          }}
                          className="w-full sm:w-auto px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shrink-0 cursor-pointer"
                        >
                          Match + Add
                        </button>
                      )}
                    </div>

                    <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1 text-left">
                      {matchedInventoryEntries.length === 0 ? (
                        <p className="text-xs text-neutral-500 text-center py-3 bg-neutral-50 rounded-xl border border-neutral-200/70">
                          No matching {isRestaurant ? 'dishes' : 'products'} found{posInventorySearch ? ` for "${posInventorySearch}"` : ''}.
                        </p>
                      ) : (
                        matchedInventoryEntries.map(({ item, channelLabel, badgeClass }) => {
                          const inCartQty = cart.find(c => c.id === item.id)?.quantity || 0;
                          const itemBarcode = !isRestaurant ? getItemBarcode(item) : '';
                          const matchedQr = invQ
                            ? (item.qrCodes || []).find(qr => qr.payload.toLowerCase().includes(invQ) || (qr.label && qr.label.toLowerCase().includes(invQ)))
                            : undefined;
                          const matchedBarcode = !!invQ && !!itemBarcode && itemBarcode.toLowerCase().includes(invQ);
                          return (
                            <div
                              key={`inv-pick-${item.id}`}
                              className={`p-2.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 transition-colors ${
                                matchedQr || matchedBarcode
                                  ? 'bg-emerald-50/70 border-emerald-300'
                                  : 'bg-neutral-50 border-neutral-200/80 hover:border-neutral-300'
                              }`}
                            >
                              <div className="min-w-0 flex-1 space-y-0.5 text-center sm:text-left">
                                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5">
                                  <span className="text-xs font-bold text-neutral-900 truncate">{item.name}</span>
                                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${badgeClass}`}>
                                    {channelLabel}
                                  </span>
                                  {matchedBarcode && (
                                    <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-indigo-600 text-white">
                                      Barcode Matched
                                    </span>
                                  )}
                                  {matchedQr && (
                                    <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-600 text-white">
                                      QR Matched
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-[10px] text-neutral-500 font-mono">
                                  <span>{item.category}</span>
                                  <span>•</span>
                                  <span className="font-bold text-emerald-700">
                                    {item.price.toLocaleString()} {item.currency}
                                  </span>
                                  {item.stock !== undefined && (
                                    <>
                                      <span>•</span>
                                      <span>{isRestaurant ? `${item.stock} avail` : `${item.stock} in stock`}</span>
                                    </>
                                  )}
                                  {itemBarcode && (
                                    <>
                                      <span>•</span>
                                      <span className="text-neutral-700 font-semibold flex items-center gap-0.5">
                                        <Barcode className="w-3 h-3 text-neutral-500" />
                                        {itemBarcode}
                                      </span>
                                    </>
                                  )}
                                  {item.qrCodes && item.qrCodes.length > 0 && (
                                    <>
                                      <span>•</span>
                                      <span className="text-indigo-700 truncate max-w-[200px]" title={item.qrCodes[0].payload}>
                                        QR: {item.qrCodes[0].payload}
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => addToCart(item)}
                                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shrink-0 cursor-pointer"
                              >
                                {isRestaurant
                                  ? (inCartQty > 0 ? `+ Add to ${selectedTable} (${inCartQty})` : `+ Add to ${selectedTable}`)
                                  : (inCartQty > 0 ? `+ Add (${inCartQty})` : '+ Add')}
                              </button>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Customer Info */}
              <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-2.5 text-center">
                <span className="text-[10px] font-bold uppercase font-mono text-neutral-500 block text-center">
                  Customer Info
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="Customer Name (or Walk-in)"
                    value={posWalkInCustomerName}
                    onChange={(e) => setPosWalkInCustomerName(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 text-center"
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number (Optional)"
                    value={posWalkInCustomerPhone}
                    onChange={(e) => setPosWalkInCustomerPhone(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 text-center"
                  />
                  <input
                    type="email"
                    placeholder="Email (Optional)"
                    value={posWalkInCustomerEmail}
                    onChange={(e) => setPosWalkInCustomerEmail(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 text-center"
                  />
                </div>

                {canDeliver && (
                  <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                    <button
                      type="button"
                      onClick={() => { setPosWalkInFulfillment('pickup'); setPosWalkInError(''); }}
                      className={`py-1.5 rounded-xl text-[11px] font-bold border cursor-pointer ${
                        posWalkInFulfillment === 'pickup'
                          ? (isRestaurant ? 'bg-amber-600 text-white border-amber-600' : 'bg-indigo-600 text-white border-indigo-600')
                          : 'bg-white text-neutral-700 border-neutral-200'
                      }`}
                    >
                      {isRestaurant ? 'Dine-In / Pickup' : 'In-Store Pickup'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setPosWalkInFulfillment('delivery')}
                      className={`py-1.5 rounded-xl text-[11px] font-bold border cursor-pointer ${
                        posWalkInFulfillment === 'delivery'
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white text-neutral-700 border-neutral-200'
                      }`}
                    >
                      Delivery
                    </button>
                  </div>
                )}

                {posWalkInFulfillment === 'delivery' && (
                  <div className="space-y-2 pt-1 max-w-lg mx-auto text-center">
                    <div className="flex items-center justify-center gap-3">
                      <span className="text-[10px] font-bold uppercase font-mono text-neutral-600">
                        Saved Delivery Address *
                      </span>
                      <button
                        type="button"
                        onClick={() => { setPosWalkInShowAddAddr(prev => !prev); setPosWalkInError(''); }}
                        className="text-[10px] font-bold text-indigo-700 hover:underline cursor-pointer"
                      >
                        {posWalkInShowAddAddr ? 'Select Saved' : `+ Add & Save (${deliveryAddresses.length})`}
                      </button>
                    </div>

                    {posWalkInError && (
                      <p className="text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-2 py-1">
                        {posWalkInError}
                      </p>
                    )}

                    {deliveryAddresses.length > 0 && !posWalkInShowAddAddr ? (
                      <div className="space-y-1">
                        <select
                          value={selectedAddrId}
                          onChange={(e) => setPosWalkInAddressId(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-neutral-200 text-xs text-neutral-900 text-center"
                        >
                          {deliveryAddresses.map(addr => (
                            <option key={addr.id} value={addr.id}>
                              {addr.label ? `${addr.label}: ` : ''}{addr.fullName} • {addr.address}
                            </option>
                          ))}
                        </select>
                        {chosenWalkInAddress && (
                          <p className="text-[10px] text-neutral-500">
                            {chosenWalkInAddress.fullName}
                            {chosenWalkInAddress.phone ? ` • ${chosenWalkInAddress.phone}` : ''}
                            {' • '}{chosenWalkInAddress.address}
                          </p>
                        )}
                      </div>
                    ) : (
                      <div className="p-2.5 rounded-xl bg-white border border-indigo-200 space-y-1.5">
                        <input
                          type="text"
                          placeholder="Recipient Full Name *"
                          value={posWalkInNewAddrName}
                          onChange={(e) => setPosWalkInNewAddrName(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center"
                        />
                        <div className="grid grid-cols-2 gap-1.5">
                          <input
                            type="tel"
                            placeholder="Phone (Optional)"
                            value={posWalkInNewAddrPhone}
                            onChange={(e) => setPosWalkInNewAddrPhone(e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center"
                          />
                          <input
                            type="text"
                            placeholder="Label (Home, Work)"
                            value={posWalkInNewAddrLabel}
                            onChange={(e) => setPosWalkInNewAddrLabel(e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center"
                          />
                        </div>
                        <input
                          type="text"
                          placeholder="Full Delivery Address *"
                          value={posWalkInNewAddrStreet}
                          onChange={(e) => setPosWalkInNewAddrStreet(e.target.value)}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center"
                        />
                        <button
                          type="button"
                          onClick={handleSavePosWalkInAddress}
                          className="w-full py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold cursor-pointer"
                        >
                          Save &amp; Select Address
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Ticket Items */}
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {cart.length === 0 ? (
                  <p className="text-xs text-neutral-400 text-center py-3">
                    No items added to ticket yet.
                  </p>
                ) : (
                  cart.map(item => (
                    <div key={item.id} className="p-2.5 rounded-2xl bg-neutral-50 border border-neutral-200/60 flex items-center justify-between gap-2 text-left">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-neutral-900 truncate">{item.name}</p>
                        <p className="text-[10px] font-mono text-emerald-700 font-semibold">
                          {item.price.toLocaleString()} {item.currency}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button type="button" onClick={() => updateQuantity(item.id, -1)} className="w-6 h-6 rounded-lg bg-white border border-neutral-200 text-xs font-bold cursor-pointer">-</button>
                        <span className="text-xs font-mono font-bold w-5 text-center">{item.quantity}</span>
                        <button type="button" onClick={() => updateQuantity(item.id, 1)} className="w-6 h-6 rounded-lg bg-white border border-neutral-200 text-xs font-bold cursor-pointer">+</button>
                        <button type="button" onClick={() => removeFromCart(item.id)} className="p-1 text-neutral-400 hover:text-rose-600 cursor-pointer"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Tip & Totals + Charge (Centered) */}
              <div className="space-y-3 pt-3 border-t border-neutral-200 text-center">
                {isRestaurant && (
                  <div className="space-y-1.5 max-w-md mx-auto">
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 font-mono">Tip Value</span>
                      {customTip && (
                        <span className="text-[10px] font-bold text-emerald-700 font-mono">Custom: {parseFloat(customTip || '0').toLocaleString()} {checkoutCurrency}</span>
                      )}
                    </div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[0, 15, 18, 20].map(p => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => { setTipPercentage(p); setCustomTip(''); }}
                          className={`py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                            tipPercentage === p && customTip === '' ? 'bg-amber-600 text-white' : 'bg-neutral-100 text-neutral-700'
                          }`}
                        >
                          {p}%
                        </button>
                      ))}
                    </div>
                    <input
                      type="number"
                      placeholder="Or Custom Tip..."
                      min={0}
                      step="any"
                      value={customTip}
                      onChange={(e) => setCustomTip(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl border border-neutral-200 bg-neutral-50 text-xs font-mono font-bold text-center"
                    />
                  </div>
                )}

                <div className="space-y-1.5 text-xs max-w-sm mx-auto">
                  <div className="flex items-center justify-between text-neutral-600">
                    <span>Subtotal</span>
                    <span className="font-mono font-bold">{subtotal.toLocaleString()} {checkoutCurrency}</span>
                  </div>
                  <div className="flex items-center justify-between text-neutral-600">
                    <span>Commerce Tax (5%)</span>
                    <span className="font-mono font-bold">{tax.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {checkoutCurrency}</span>
                  </div>
                  {isRestaurant && (
                    <div className="flex items-center justify-between text-neutral-600">
                      <span>Tip</span>
                      <span className="font-mono font-bold">{tip.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {checkoutCurrency}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between pt-2 border-t border-neutral-200 text-sm font-extrabold">
                    <span>Total Due</span>
                    <span className="font-mono text-emerald-700 text-base">
                      {total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {checkoutCurrency}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={cart.length === 0}
                  onClick={() => setIsCheckoutModalOpen(true)}
                  className="w-full max-w-md mx-auto py-3 rounded-2xl text-xs font-extrabold flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer shadow-md disabled:opacity-50"
                >
                  <Coins className="w-4 h-4 shrink-0" />
                  <span>Charge {total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {checkoutCurrency} (Settle)</span>
                </button>
              </div>

              {/* Recent In-Store / In-Restaurant Checkouts Inside Same Single Display */}
              <div className="pt-4 border-t border-neutral-100 space-y-3 text-center">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-xs font-bold text-neutral-800">
                    {isRestaurant ? 'Recent In-Restaurant Checkouts' : 'Recent In-Store Checkouts'}
                  </span>
                  <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700">
                    {inPersonOrders.length}
                  </span>
                </div>
                {renderOrderCardsList()}
              </div>
            </>
          )}
        </div>
      </div>
    );
  };

  // Shared Sales Log Renderer with Two Side-by-Side Tabs (In-Store/In-Restaurant Sales vs Online Sales) & Full Invoice/Receipt Cards
  const renderSalesLogWithInvoices = (mode: 'retail' | 'restaurant') => {
    const isRestaurant = mode === 'restaurant';
    const isOnlineTx = (tx: SalesTransaction) =>
      tx.txChannel ? tx.txChannel === 'online' : (tx.receiptNumber.startsWith('ORD-') || tx.tableOrRegister.startsWith('Online '));

    const allLocTxs = transactionsHistory.filter(
      t => t.mode === mode && (!t.locationId || t.locationId === activeLocationId)
    );
    const inPersonTxs = allLocTxs.filter(t => !isOnlineTx(t));
    const onlineTxs = allLocTxs.filter(t => isOnlineTx(t));
    const activeTab = isRestaurant ? restaurantSalesLogTab : retailSalesLogTab;
    const isOnlineLogTab = activeTab === 'online';
    const displayedTxs = isOnlineLogTab ? onlineTxs : inPersonTxs;

    return (
      <div className="space-y-4 max-w-3xl mx-auto">
        {/* Two Side-by-Side Tabs: In-Store/In-Restaurant Sales vs Online Sales */}
        <div className="grid grid-cols-2 gap-2 p-1.5 bg-neutral-100 border border-neutral-200/80 rounded-2xl">
          <button
            type="button"
            onClick={() => isRestaurant ? setRestaurantSalesLogTab('in_restaurant') : setRetailSalesLogTab('in_store')}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              !isOnlineLogTab
                ? (isRestaurant ? 'bg-amber-600 text-white shadow-xs' : 'bg-indigo-600 text-white shadow-xs')
                : 'text-neutral-700 hover:text-neutral-900 hover:bg-white/60'
            }`}
          >
            <Receipt className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{isRestaurant ? 'In-Restaurant Sales' : 'In-Store Sales'}</span>
            <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono ${
              !isOnlineLogTab ? 'bg-white/20 text-white' : 'bg-neutral-200/80 text-neutral-700'
            }`}>
              {inPersonTxs.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => isRestaurant ? setRestaurantSalesLogTab('online') : setRetailSalesLogTab('online')}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              isOnlineLogTab
                ? (isRestaurant ? 'bg-amber-600 text-white shadow-xs' : 'bg-indigo-600 text-white shadow-xs')
                : 'text-neutral-700 hover:text-neutral-900 hover:bg-white/60'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Online Sales</span>
            <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono ${
              isOnlineLogTab ? 'bg-white/20 text-white' : 'bg-neutral-200/80 text-neutral-700'
            }`}>
              {onlineTxs.length}
            </span>
          </button>
        </div>

        <div className="bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
          <div className="flex flex-col items-center justify-center text-center gap-1.5 pb-3 border-b border-neutral-100">
            <h3 className="font-serif-lux text-base sm:text-lg font-bold text-neutral-900">
              {activeLocation.name} — {isOnlineLogTab ? 'Online Sales Invoices' : (isRestaurant ? 'In-Restaurant Sales Invoices' : 'In-Store Sales Invoices')}
            </h3>
            <span className="text-xs font-mono px-3 py-1 bg-emerald-100 text-emerald-900 font-bold rounded-xl">
              {displayedTxs.length} {displayedTxs.length === 1 ? 'Invoice / Receipt' : 'Invoices / Receipts'}
            </span>
          </div>

          <div className="space-y-4">
            {displayedTxs.length === 0 ? (
              <p className="text-xs text-neutral-500 text-center py-6 bg-neutral-50 rounded-2xl border border-neutral-200/70">
                No {isOnlineLogTab ? 'online' : (isRestaurant ? 'in-restaurant' : 'in-store')} invoices recorded for {activeLocation.name} yet.
              </p>
            ) : displayedTxs.map(tx => {
              const displayPhone = tx.customerPhone || tx.deliveryAddress?.phone;
              const displayEmail = tx.customerEmail || tx.deliveryAddress?.email;
              const isDelivery = tx.fulfillmentType === 'delivery' || !!tx.deliveryAddress;
              return (
                <div key={tx.id} className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200/90 space-y-3 text-left">
                  {/* Invoice / Receipt Header */}
                  <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-neutral-200/80">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-900 text-white font-mono uppercase flex items-center gap-1">
                          <FileText className="w-3 h-3" />
                          <span>Invoice / Receipt</span>
                        </span>
                        <span className="text-xs font-extrabold text-neutral-900 font-mono">{tx.receiptNumber}</span>
                        {tx.status === 'cancelled' && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-50 text-rose-800 border border-rose-200 font-mono uppercase">
                            Cancelled / Refunded
                          </span>
                        )}
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                          isOnlineLogTab
                            ? (isDelivery ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-indigo-50 text-indigo-800 border-indigo-200')
                            : (isRestaurant ? 'bg-amber-50 text-amber-900 border-amber-200' : 'bg-indigo-50 text-indigo-900 border-indigo-200')
                        }`}>
                          {isOnlineLogTab ? (isDelivery ? 'Online Delivery' : 'Online Pickup') : tx.tableOrRegister}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-500 font-mono">
                        Issued: {tx.timestamp} • {activeLocation.name}
                        {tx.status === 'cancelled' && tx.cancelledAt ? ` • Reversed ${new Date(tx.cancelledAt).toLocaleString()}` : ''}
                      </p>
                    </div>

                    <div className="text-right">
                      <p className={`text-sm font-extrabold font-mono ${tx.status === 'cancelled' ? 'text-rose-700 line-through' : 'text-emerald-700'}`}>
                        {tx.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {tx.currency}
                      </p>
                      <p className="text-[10px] text-neutral-500 font-mono">
                        {tx.status === 'cancelled' ? 'Tax Ledger Reversed' : tx.paymentMethod}
                      </p>
                    </div>
                  </div>

                  {/* Customer / Bill To Details */}
                  <div className="p-3 rounded-xl bg-white border border-neutral-200/80 grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-bold uppercase font-mono text-neutral-400 block">Billed To Customer</span>
                      <p className="font-bold text-neutral-900">
                        {tx.customerName || 'Walk-in Customer'}
                        {tx.customerHandle ? <span className="font-mono font-normal text-neutral-500 ml-1">@{tx.customerHandle}</span> : null}
                      </p>
                      {displayPhone && (
                        <p className="text-[11px] text-neutral-600 font-mono">Phone: {displayPhone}</p>
                      )}
                      {displayEmail && (
                        <p className="text-[11px] text-neutral-600">Email: {displayEmail}</p>
                      )}
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-bold uppercase font-mono text-neutral-400 block">
                        {tx.deliveryAddress ? 'Delivery Address' : 'Fulfillment Channel'}
                      </span>
                      {tx.deliveryAddress ? (
                        <div className="text-[11px] text-indigo-900 space-y-0.5">
                          <p className="font-bold">
                            {tx.deliveryAddress.label ? `[${tx.deliveryAddress.label}] ` : ''}{tx.deliveryAddress.fullName}
                          </p>
                          <p>{tx.deliveryAddress.address}</p>
                        </div>
                      ) : (
                        <p className="text-[11px] text-neutral-700 font-medium">{tx.tableOrRegister}</p>
                      )}
                    </div>
                  </div>

                  {/* Itemized Invoice Lines */}
                  <div className="p-3 rounded-xl bg-white border border-neutral-200/80 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-[10px] font-bold uppercase font-mono text-neutral-400 pb-1 border-b border-neutral-100">
                      <span>Itemized Invoice ({tx.items.reduce((s, i) => s + i.quantity, 0)} units)</span>
                      <span>Amount</span>
                    </div>
                    <div className="divide-y divide-neutral-100">
                      {tx.items.map((line, lIdx) => (
                        <div key={`${tx.id}-ln-${lIdx}`} className="py-1.5 flex items-center justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <span className="font-bold text-neutral-900">{line.quantity}x {line.name}</span>
                            <span className="text-[10px] text-neutral-500 font-mono ml-1.5">
                              @ {line.price.toLocaleString()} {line.currency} each
                            </span>
                          </div>
                          <span className="font-mono font-bold text-neutral-800 shrink-0">
                            {(line.price * line.quantity).toLocaleString()} {line.currency}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Invoice Totals Breakdown */}
                    <div className="pt-2 border-t border-neutral-200 space-y-1 text-[11px] font-mono">
                      <div className="flex items-center justify-between text-neutral-600">
                        <span>Subtotal</span>
                        <span>{tx.subtotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {tx.currency}</span>
                      </div>
                      <div className="flex items-center justify-between text-neutral-600">
                        <span>Commerce Tax (5%)</span>
                        <span>{tx.tax.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {tx.currency}</span>
                      </div>
                      {tx.tip > 0 && (
                        <div className="flex items-center justify-between text-neutral-600">
                          <span>Tip</span>
                          <span>{tx.tip.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {tx.currency}</span>
                        </div>
                      )}
                      <div className="flex items-center justify-between pt-1.5 border-t border-neutral-200 text-xs font-extrabold text-emerald-700">
                        <span>Total Paid</span>
                        <span>{tx.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {tx.currency}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  // Channel membership helpers for Retail Products & Restaurant Dishes
  const getRetailChannelInfo = (locId: string, itemId: string) => {
    const inStoreList = retailInventoriesByLoc[locId] ?? getInitialRetailForLoc(locId);
    const onlineList = onlineRetailByLoc[locId] ?? getInitialOnlineRetailForLoc(locId);
    const inStore = inStoreList.some(i => i.id === itemId);
    const online = onlineList.some(i => i.id === itemId);
    if (inStore && online) {
      return {
        inStore: true,
        online: true,
        label: 'In-Store & Online Store',
        badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      };
    }
    if (online) {
      return {
        inStore: false,
        online: true,
        label: 'Online Store',
        badgeClass: 'bg-indigo-50 text-indigo-800 border-indigo-200',
      };
    }
    return {
      inStore: true,
      online: false,
      label: 'In-Store',
      badgeClass: 'bg-neutral-100 text-neutral-700 border-neutral-200',
    };
  };

  const getRestaurantChannelInfo = (locId: string, itemId: string) => {
    const inHouseList = restaurantMenusByLoc[locId] ?? getInitialRestaurantForLoc(locId);
    const onlineList = onlineMenusByLoc[locId] ?? getInitialOnlineMenuForLoc(locId);
    const inHouse = inHouseList.some(i => i.id === itemId);
    const online = onlineList.some(i => i.id === itemId);
    if (inHouse && online) {
      return {
        inHouse: true,
        online: true,
        label: 'In Restaurant & Online Menu',
        badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      };
    }
    if (online) {
      return {
        inHouse: false,
        online: true,
        label: 'Online Menu',
        badgeClass: 'bg-amber-50 text-amber-800 border-amber-200',
      };
    }
    return {
      inHouse: true,
      online: false,
      label: 'In Restaurant',
      badgeClass: 'bg-neutral-100 text-neutral-700 border-neutral-200',
    };
  };

  const mergeQrLists = (a?: POSItemQRCode[], b?: POSItemQRCode[]): POSItemQRCode[] | undefined => {
    const combined = [...(a || []), ...(b || [])];
    if (combined.length === 0) return undefined;
    const seen = new Set<string>();
    return combined.filter(q => {
      if (seen.has(q.payload)) return false;
      seen.add(q.payload);
      return true;
    });
  };

  const getMergedLocationItems = (loc: MerchantLocation) => {
    if (loc.type === 'restaurant') {
      const inHouse = restaurantMenusByLoc[loc.id] ?? getInitialRestaurantForLoc(loc.id);
      const online = onlineMenusByLoc[loc.id] ?? getInitialOnlineMenuForLoc(loc.id);
      const map = new Map<string, { item: CatalogItem; inHouse: boolean; online: boolean }>();
      inHouse.forEach(item => map.set(item.id, { item, inHouse: true, online: false }));
      online.forEach(item => {
        const existing = map.get(item.id);
        if (existing) {
          existing.online = true;
          existing.item = {
            ...existing.item,
            qrCodes: mergeQrLists(existing.item.qrCodes, item.qrCodes)
          };
        } else {
          map.set(item.id, { item, inHouse: false, online: true });
        }
      });
      return Array.from(map.values()).map(entry => ({
        item: entry.item,
        isInstore: entry.inHouse,
        isOnline: entry.online,
        channelLabel: entry.inHouse && entry.online
          ? 'In Restaurant & Online Menu'
          : entry.online
            ? 'Online Menu'
            : 'In Restaurant',
        badgeClass: entry.inHouse && entry.online
          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
          : entry.online
            ? 'bg-amber-50 text-amber-800 border-amber-200'
            : 'bg-neutral-100 text-neutral-700 border-neutral-200',
      }));
    } else {
      const inStore = retailInventoriesByLoc[loc.id] ?? getInitialRetailForLoc(loc.id);
      const online = onlineRetailByLoc[loc.id] ?? getInitialOnlineRetailForLoc(loc.id);
      const map = new Map<string, { item: CatalogItem; inStore: boolean; online: boolean }>();
      inStore.forEach(item => map.set(item.id, {
        item: { ...item, barcode: item.barcode || DEFAULT_RETAIL_BARCODE_BY_ID[item.id] },
        inStore: true,
        online: false
      }));
      online.forEach(item => {
        const existing = map.get(item.id);
        if (existing) {
          existing.online = true;
          existing.item = {
            ...existing.item,
            barcode: existing.item.barcode || item.barcode || DEFAULT_RETAIL_BARCODE_BY_ID[item.id],
            qrCodes: mergeQrLists(existing.item.qrCodes, item.qrCodes)
          };
        } else {
          map.set(item.id, {
            item: { ...item, barcode: item.barcode || DEFAULT_RETAIL_BARCODE_BY_ID[item.id] },
            inStore: false,
            online: true
          });
        }
      });
      return Array.from(map.values()).map(entry => ({
        item: entry.item,
        isInstore: entry.inStore,
        isOnline: entry.online,
        channelLabel: entry.inStore && entry.online
          ? 'In-Store & Online Store'
          : entry.online
            ? 'Online Store'
            : 'In-Store',
        badgeClass: entry.inStore && entry.online
          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
          : entry.online
            ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
            : 'bg-neutral-100 text-neutral-700 border-neutral-200',
      }));
    }
  };

  // Customer Discovery Search Results (Separated strictly into In-Store/Dine-In View-Only vs Online Orderable, without mixing retail & restaurant!)
  const universalSearchResults = useMemo(() => {
    const q = universalSearchQuery.toLowerCase().trim();
    const matchesItem = (item: CatalogItem) =>
      !q ||
      item.name.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q) ||
      (item.description && item.description.toLowerCase().includes(q));
    const matchesLocationMeta = (l: MerchantLocation) =>
      !q ||
      l.name.toLowerCase().includes(q) ||
      l.address.toLowerCase().includes(q) ||
      l.cuisineOrCategory.toLowerCase().includes(q) ||
      (l.tagline && l.tagline.toLowerCase().includes(q));

    const matchedLocations: MerchantLocation[] = [];
    const matchedInHouseDishes: { dish: CatalogItem; location: MerchantLocation }[] = [];
    const matchedOnlineDishes: { dish: CatalogItem; location: MerchantLocation }[] = [];
    const matchedInStoreProducts: { product: CatalogItem; location: MerchantLocation }[] = [];
    const matchedOnlineProducts: { product: CatalogItem; location: MerchantLocation }[] = [];

    if (customerSubTab === 'restaurants') {
      const restLocations = locations.filter(l => l.type === 'restaurant');
      restLocations.forEach(loc => {
        const inHouse = restaurantMenusByLoc[loc.id] ?? getInitialRestaurantForLoc(loc.id);
        const online = onlineMenusByLoc[loc.id] ?? getInitialOnlineMenuForLoc(loc.id);
        const locMetaMatch = matchesLocationMeta(loc);
        const matchingInHouse = inHouse.filter(matchesItem);
        const matchingOnline = online.filter(matchesItem);

        if (!q || locMetaMatch || matchingInHouse.length > 0 || matchingOnline.length > 0) {
          matchedLocations.push(loc);
        }

        const inHouseToShow = !q || locMetaMatch ? inHouse : matchingInHouse;
        const onlineToShow = !q || locMetaMatch ? online : matchingOnline;
        inHouseToShow.forEach(d => matchedInHouseDishes.push({ dish: d, location: loc }));
        onlineToShow.forEach(d => matchedOnlineDishes.push({ dish: d, location: loc }));
      });
    } else {
      const retailLocations = locations.filter(l => l.type === 'retail');
      retailLocations.forEach(loc => {
        const inStore = retailInventoriesByLoc[loc.id] ?? getInitialRetailForLoc(loc.id);
        const online = onlineRetailByLoc[loc.id] ?? getInitialOnlineRetailForLoc(loc.id);
        const locMetaMatch = matchesLocationMeta(loc);
        const matchingInStore = inStore.filter(matchesItem);
        const matchingOnline = online.filter(matchesItem);

        if (!q || locMetaMatch || matchingInStore.length > 0 || matchingOnline.length > 0) {
          matchedLocations.push(loc);
        }

        const inStoreToShow = !q || locMetaMatch ? inStore : matchingInStore;
        const onlineToShow = !q || locMetaMatch ? online : matchingOnline;
        inStoreToShow.forEach(p => matchedInStoreProducts.push({ product: p, location: loc }));
        onlineToShow.forEach(p => matchedOnlineProducts.push({ product: p, location: loc }));
      });
    }

    return {
      matchedLocations,
      matchedInHouseDishes,
      matchedOnlineDishes,
      matchedInStoreProducts,
      matchedOnlineProducts
    };
  }, [locations, universalSearchQuery, customerSubTab, retailInventoriesByLoc, onlineRetailByLoc, restaurantMenusByLoc, onlineMenusByLoc]);

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6 text-left space-y-6">
      {/* Top Header - No back button next to Point of Sale (POS) */}
      <div className="flex flex-col items-center justify-center text-center gap-2 pb-4 border-b border-neutral-200">
        <h1 className="font-serif-lux text-2xl sm:text-3xl font-semibold text-black tracking-tight flex items-center justify-center gap-2.5">
          <Store className="w-6 h-6 text-neutral-800" />
          <span>Point of Sale</span>
        </h1>

        {/* THE 3 PRIMARY TABS - Fitted cleanly on a single line */}
        <div className="grid grid-cols-3 gap-1 sm:gap-1.5 p-1 sm:p-1.5 bg-neutral-200/80 rounded-2xl mx-auto mt-2 max-w-2xl w-full">
          {/* Tab 1: Customer Discovery */}
          <button
            type="button"
            onClick={() => {
              setMainTab('directory');
              setViewingLocation(null);
            }}
            className={`w-full py-2 px-1.5 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer whitespace-nowrap min-w-0 ${
              mainTab === 'directory' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Search className="w-3.5 h-3.5 text-amber-500 shrink-0" />
            <span className="truncate">Customer Explorer</span>
          </button>

          {/* Tab 2: Retail Store (Merchant) */}
          <button
            type="button"
            onClick={() => {
              setMainTab('retail');
              setViewingLocation(null);
              setMerchantCatalogSearch('');
              setMerchantCatalogCategory('All');
              const firstRetail = locations.find(l => l.type === 'retail');
              if (firstRetail && activeLocation.type !== 'retail') {
                setActiveLocationId(firstRetail.id);
              }
            }}
            className={`w-full py-2 px-1.5 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer whitespace-nowrap min-w-0 ${
              mainTab === 'retail' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span className="truncate">Retail Store</span>
          </button>

          {/* Tab 3: Restaurant & Bar (Merchant) */}
          <button
            type="button"
            onClick={() => {
              setMainTab('restaurant');
              setViewingLocation(null);
              setMerchantCatalogSearch('');
              setMerchantCatalogCategory('All');
              const firstRest = locations.find(l => l.type === 'restaurant');
              if (firstRest && activeLocation.type !== 'restaurant') {
                setActiveLocationId(firstRest.id);
              }
            }}
            className={`w-full py-2 px-1.5 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer whitespace-nowrap min-w-0 ${
              mainTab === 'restaurant' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <UtensilsCrossed className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="truncate">Restaurant &amp; Bar</span>
          </button>
        </div>

        {/* SUB-TABS FOR TAB 1: CUSTOMER DISCOVERY (RETAIL STORES FIRST, THEN RESTAURANTS & MENUS) */}
        {mainTab === 'directory' && !viewingLocation && (
          <div className="flex items-center justify-center p-1 bg-neutral-100 rounded-2xl mx-auto mt-2 max-w-md w-full">
            <button
              type="button"
              onClick={() => {
                setCustomerSubTab('retail');
                setExplorerSectionView('browse');
                setUniversalSearchQuery('');
              }}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap ${
                customerSubTab === 'retail' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <ShoppingBag className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>Retail Stores &amp; Items</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setCustomerSubTab('restaurants');
                setExplorerSectionView('browse');
                setUniversalSearchQuery('');
              }}
              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap ${
                customerSubTab === 'restaurants' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <UtensilsCrossed className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Restaurants &amp; Menus</span>
            </button>
          </div>
        )}

        {/* RETAIL LOCATION SWITCHER & SUB-TABS (UNDER RETAIL BUTTON - RETAIL ONLY) */}
        {mainTab === 'retail' && (() => {
          const activeRetailReviews = reviewsList.filter(r => r.storeId === activeLocation.id);
          const activeRetailAvg = activeRetailReviews.length > 0
            ? (activeRetailReviews.reduce((s, r) => s + r.rating, 0) / activeRetailReviews.length).toFixed(1)
            : 'No ratings';
          return (
          <div className="w-full space-y-2 mt-2">
            <div className="w-full max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-2 px-2">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-white border border-neutral-300 shadow-2xs max-w-full sm:max-w-lg w-full sm:w-auto min-w-0">
                <Building2 className="w-4 h-4 text-indigo-600 shrink-0" />
                <span className="text-xs font-bold text-neutral-500 whitespace-nowrap shrink-0">
                  Active Store ({locations.filter(l => l.type === 'retail').length}/10):
                </span>
                <select
                  value={activeLocation.type === 'retail' ? activeLocationId : (locations.find(l => l.type === 'retail')?.id || activeLocationId)}
                  onChange={(e) => {
                    setActiveLocationId(e.target.value);
                  }}
                  className="bg-transparent text-xs font-bold text-neutral-900 border-none outline-hidden cursor-pointer truncate flex-1 min-w-0"
                >
                  {locations.filter(l => l.type === 'retail').map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} (Retail)
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-center gap-2 flex-nowrap shrink-0">
                <button
                  type="button"
                  onClick={() => handleOpenReviewsModal(activeLocation)}
                  title="Click to view all ratings & comments or add/update your review"
                  className="px-3 py-1.5 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs whitespace-nowrap shrink-0"
                >
                  <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500 shrink-0" />
                  <span>{activeRetailAvg}</span>
                  <span className="text-amber-700 font-normal">({activeRetailReviews.length} {activeRetailReviews.length === 1 ? 'review' : 'reviews'})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setNewLocType('retail');
                    setNewLocAllowsDelivery(true);
                    setIsAddLocationModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 rounded-2xl bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-300 text-xs font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-2xs whitespace-nowrap shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Store</span>
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-neutral-600 px-2 text-center">
              <span className="font-semibold text-neutral-800">{activeLocation.name}</span>
              <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-neutral-400 shrink-0" /> {activeLocation.phone}</span>
              <span className="flex items-center gap-1"><Mail className="w-3 h-3 text-neutral-400 shrink-0" /> {activeLocation.email}</span>
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-neutral-400 shrink-0" /> {activeLocation.address}</span>
            </div>
          </div>
          );
        })()}

        {/* RESTAURANT LOCATION SWITCHER & SUB-TABS (UNDER RESTAURANT BUTTON - RESTAURANTS ONLY) */}
        {mainTab === 'restaurant' && (() => {
          const activeRestReviews = reviewsList.filter(r => r.storeId === activeLocation.id);
          const activeRestAvg = activeRestReviews.length > 0
            ? (activeRestReviews.reduce((s, r) => s + r.rating, 0) / activeRestReviews.length).toFixed(1)
            : 'No ratings';
          return (
          <div className="w-full space-y-2 mt-2">
            <div className="w-full max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-2 px-2">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-white border border-neutral-300 shadow-2xs max-w-full sm:max-w-lg w-full sm:w-auto min-w-0">
                <Building2 className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="text-xs font-bold text-neutral-500 whitespace-nowrap shrink-0">
                  Active Restaurant ({locations.filter(l => l.type === 'restaurant').length}/10):
                </span>
                <select
                  value={activeLocation.type === 'restaurant' ? activeLocationId : (locations.find(l => l.type === 'restaurant')?.id || activeLocationId)}
                  onChange={(e) => {
                    setActiveLocationId(e.target.value);
                  }}
                  className="bg-transparent text-xs font-bold text-neutral-900 border-none outline-hidden cursor-pointer truncate flex-1 min-w-0"
                >
                  {locations.filter(l => l.type === 'restaurant').map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} (Restaurant)
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-center gap-2 flex-nowrap shrink-0">
                <button
                  type="button"
                  onClick={() => handleOpenReviewsModal(activeLocation)}
                  title="Click to view all ratings & comments or add/update your review"
                  className="px-3 py-1.5 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-2xs whitespace-nowrap shrink-0"
                >
                  <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500 shrink-0" />
                  <span>{activeRestAvg}</span>
                  <span className="text-amber-700 font-normal">({activeRestReviews.length} {activeRestReviews.length === 1 ? 'review' : 'reviews'})</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setNewLocType('restaurant');
                    setNewLocAllowsDelivery(false);
                    setIsAddLocationModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 rounded-2xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-2xs whitespace-nowrap shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Restaurant</span>
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-neutral-600 px-2 text-center">
              <span className="font-semibold text-neutral-800">{activeLocation.name}</span>
              <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-neutral-400 shrink-0" /> {activeLocation.phone}</span>
              <span className="flex items-center gap-1"><Mail className="w-3 h-3 text-neutral-400 shrink-0" /> {activeLocation.email}</span>
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-neutral-400 shrink-0" /> {activeLocation.address}</span>
            </div>
          </div>
          );
        })()}

        {/* SUB-TABS FOR RETAIL STORE */}
        {mainTab === 'retail' && (
          <div className="flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-2xl mx-auto mt-2">
            <button
              type="button"
              onClick={() => setRetailSubTab('checkout')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                retailSubTab === 'checkout' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <span>Checkout</span>
              {(() => {
                const retailLocIds = new Set(locations.filter(l => l.type === 'retail').map(l => l.id));
                const count = takeoutOrders.filter(o =>
                  o.status !== 'completed' &&
                  o.status !== 'cancelled' &&
                  (o.orderChannel ? o.orderChannel === 'online' : !o.orderNumber.startsWith('REC-POS-')) &&
                  (retailLocIds.has(o.restaurantId) || o.orderNumber.startsWith('ORD-RET-'))
                ).length;
                return count > 0 ? (
                  <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono ${
                    retailSubTab === 'checkout' ? 'bg-indigo-500 text-white' : 'bg-indigo-100 text-indigo-800'
                  }`}>
                    {count}
                  </span>
                ) : null;
              })()}
            </button>
            <button
              type="button"
              onClick={() => setRetailSubTab('add_item')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                retailSubTab === 'add_item' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Add Item to Retail Inventory
            </button>
            <button
              type="button"
              onClick={() => setRetailSubTab('inventory_dir')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                retailSubTab === 'inventory_dir' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Retail Store Inventory ({retailCatalog.length})
            </button>
            <button
              type="button"
              onClick={() => setRetailSubTab('online_store')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                retailSubTab === 'online_store' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Online Store ({onlineRetailCatalog.length})
            </button>
            <button
              type="button"
              onClick={() => setRetailSubTab('history')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                retailSubTab === 'history' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Sales Log ({transactionsHistory.filter(t => t.mode === 'retail' && (!t.locationId || t.locationId === activeLocationId)).length})
            </button>
          </div>
        )}

        {/* SUB-TABS FOR RESTAURANT & BAR */}
        {mainTab === 'restaurant' && (
          <div className="flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-2xl mx-auto mt-2">
            <button
              type="button"
              onClick={() => setRestaurantSubTab('checkout')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                restaurantSubTab === 'checkout' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <span>Checkout</span>
              {(() => {
                const restLocIds = new Set(locations.filter(l => l.type === 'restaurant').map(l => l.id));
                const count = takeoutOrders.filter(o =>
                  o.status !== 'completed' &&
                  o.status !== 'cancelled' &&
                  (o.orderChannel ? o.orderChannel === 'online' : !o.orderNumber.startsWith('REC-POS-')) &&
                  (restLocIds.has(o.restaurantId) || o.orderNumber.startsWith('ORD-TK-'))
                ).length;
                return count > 0 ? (
                  <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono ${
                    restaurantSubTab === 'checkout' ? 'bg-amber-500 text-white' : 'bg-amber-100 text-amber-900'
                  }`}>
                    {count}
                  </span>
                ) : null;
              })()}
            </button>
            <button
              type="button"
              onClick={() => setRestaurantSubTab('add_item')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                restaurantSubTab === 'add_item' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Add Item to Restaurant Menu
            </button>
            <button
              type="button"
              onClick={() => setRestaurantSubTab('restaurant_menu')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                restaurantSubTab === 'restaurant_menu' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Restaurant Menu ({restaurantCatalog.length})
            </button>
            <button
              type="button"
              onClick={() => setRestaurantSubTab('online_menu')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                restaurantSubTab === 'online_menu' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Online Menu ({onlineMenuDishes.length})
            </button>
            <button
              type="button"
              onClick={() => setRestaurantSubTab('takeout_orders')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                restaurantSubTab === 'takeout_orders' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Takeout Orders ({takeoutOrders.filter(o => o.restaurantId === activeLocationId).length})
            </button>
            <button
              type="button"
              onClick={() => setRestaurantSubTab('history')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                restaurantSubTab === 'history' ? 'bg-neutral-900 text-white shadow-xs' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Sales Log ({transactionsHistory.filter(t => t.mode === 'restaurant' && (!t.locationId || t.locationId === activeLocationId)).length})
            </button>
          </div>
        )}

        {/* Table Station for In-Restaurant Checkout */}
        {mainTab === 'restaurant' && restaurantSubTab === 'checkout' && restaurantCheckoutSectionTab === 'in_restaurant' && (
          <div className="w-full max-w-3xl p-3 bg-amber-50/70 border border-amber-200/80 rounded-2xl flex flex-col items-center justify-center text-center gap-2.5 mx-auto mt-2">
            <div className="flex items-center justify-center gap-2">
              <UtensilsCrossed className="w-4 h-4 text-amber-700" />
              <span className="text-xs font-bold text-amber-900 uppercase tracking-wide">
                Table Service Station ({tablesList.length}/100 tables):
              </span>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-1.5 max-h-36 overflow-y-auto px-2">
              {tablesList.map(t => {
                const tblCount = (merchantCartsByLoc[`${activeLocationId}::${t}`] || []).reduce((s, c) => s + c.quantity, 0);
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setSelectedTable(t)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                      selectedTable === t
                        ? 'bg-amber-600 text-white shadow-2xs'
                        : 'bg-white hover:bg-amber-100/75 text-amber-900 border border-amber-300/60'
                    }`}
                  >
                    {tblCount > 0 ? `${t} (${tblCount})` : t}
                  </button>
                );
              })}

              <button
                type="button"
                onClick={() => { setTableError(''); setIsAddTableModalOpen(true); }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300/80 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Table</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* =========================================================
          TAB 1: CUSTOMER EXPLORER (RETAIL STORES & ITEMS vs RESTAURANTS & MENUS)
          ========================================================= */}
      {mainTab === 'directory' && !viewingLocation && (() => {
        const retailCartCount = locations
          .filter(l => l.type === 'retail')
          .reduce((sum, l) => sum + (customerCartsByLoc[l.id] || []).reduce((s, i) => s + i.quantity, 0), 0);
        const restaurantCartCount = locations
          .filter(l => l.type === 'restaurant')
          .reduce((sum, l) => sum + (customerCartsByLoc[l.id] || []).reduce((s, i) => s + i.quantity, 0), 0);
        const activeRetailCartLocations = locations.filter(l => l.type === 'retail' && (customerCartsByLoc[l.id] || []).length > 0);
        const activeRestaurantCartLocations = locations.filter(l => l.type === 'restaurant' && (customerCartsByLoc[l.id] || []).length > 0);

        const isOnlineExplorerOrder = (o: TakeoutOrder) =>
          o.orderChannel ? o.orderChannel === 'online' : !o.orderNumber.startsWith('REC-POS-');
        const retailOnlineOrders = takeoutOrders.filter(o => isOnlineExplorerOrder(o) && isOrderRetail(o));
        const restaurantOnlineOrders = takeoutOrders.filter(o => isOnlineExplorerOrder(o) && !isOrderRetail(o));
        const activeRetailOnlineCount = retailOnlineOrders.filter(o => o.status !== 'completed' && o.status !== 'cancelled').length;
        const activeRestaurantOnlineCount = restaurantOnlineOrders.filter(o => o.status !== 'completed' && o.status !== 'cancelled').length;

        const renderSectionNavBar = (isRetail: boolean) => (
          <div className="space-y-2.5 max-w-2xl mx-auto w-full">
            {/* Row 1: Checkout, Online Orders & Delivery Address strictly on the same line */}
            <div className="flex items-center justify-center gap-2 flex-nowrap w-full">
              <button
                type="button"
                onClick={() => setExplorerSectionView(prev => prev === 'checkout' ? 'browse' : 'checkout')}
                className={`flex-1 min-w-0 px-2 sm:px-3.5 py-2 rounded-2xl border text-[11px] sm:text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-2xs whitespace-nowrap overflow-hidden ${
                  explorerSectionView === 'checkout'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-white hover:bg-emerald-50 text-emerald-900 border-emerald-300'
                }`}
              >
                <ShoppingCart className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Checkout</span>
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold shrink-0 ${
                  explorerSectionView === 'checkout' ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {isRetail ? retailCartCount : restaurantCartCount}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCustomerOrderStatusFilter('all');
                  setExplorerSectionView(prev => prev === 'online_orders' ? 'browse' : 'online_orders');
                }}
                className={`flex-1 min-w-0 px-2 sm:px-3.5 py-2 rounded-2xl border text-[11px] sm:text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-2xs whitespace-nowrap overflow-hidden ${
                  explorerSectionView === 'online_orders'
                    ? (isRetail ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-amber-600 text-white border-amber-600')
                    : (isRetail ? 'bg-white hover:bg-indigo-50 text-indigo-900 border-indigo-300' : 'bg-white hover:bg-amber-50 text-amber-900 border-amber-300')
                }`}
              >
                <Clock className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Online Orders</span>
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold shrink-0 ${
                  explorerSectionView === 'online_orders'
                    ? 'bg-white/20 text-white'
                    : (isRetail ? 'bg-indigo-100 text-indigo-800' : 'bg-amber-100 text-amber-900')
                }`}>
                  {isRetail ? activeRetailOnlineCount : activeRestaurantOnlineCount}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setExplorerSectionView(prev => prev === 'delivery_address' ? 'browse' : 'delivery_address')}
                className={`flex-1 min-w-0 px-2 sm:px-3.5 py-2 rounded-2xl border text-[11px] sm:text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-2xs whitespace-nowrap overflow-hidden ${
                  explorerSectionView === 'delivery_address'
                    ? 'bg-neutral-900 text-white border-neutral-900'
                    : 'bg-white hover:bg-neutral-100 text-neutral-900 border-neutral-300'
                }`}
              >
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Delivery Address</span>
                <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold shrink-0 ${
                  explorerSectionView === 'delivery_address' ? 'bg-white/20 text-white' : 'bg-neutral-100 text-neutral-800'
                }`}>
                  {deliveryAddresses.length}/5
                </span>
              </button>
            </div>

            {/* Row 2: Separate Channel Tabs (In-Store vs Online Inventory / In-Restaurant vs Online Order) */}
            {isRetail ? (
              <div className="grid grid-cols-2 gap-1.5 p-1.5 bg-neutral-100 rounded-2xl w-full">
                <button
                  type="button"
                  onClick={() => {
                    setExplorerRetailChannelTab('instore');
                    setExplorerSectionView('browse');
                    setExpandedExplorerItemKey(null);
                  }}
                  className={`min-w-0 w-full py-2 px-2 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center leading-tight overflow-hidden ${
                    explorerSectionView === 'browse' && explorerRetailChannelTab === 'instore'
                      ? 'bg-white text-neutral-900 shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <span className="truncate max-w-full">In-Store Inventory</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-200/80 text-neutral-700 shrink-0 whitespace-nowrap">
                    View Only
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setExplorerRetailChannelTab('online');
                    setExplorerSectionView('browse');
                    setExpandedExplorerItemKey(null);
                  }}
                  className={`min-w-0 w-full py-2 px-2 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center leading-tight overflow-hidden ${
                    explorerSectionView === 'browse' && explorerRetailChannelTab === 'online'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <span className="truncate max-w-full">Online Inventory</span>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded shrink-0 whitespace-nowrap ${
                    explorerSectionView === 'browse' && explorerRetailChannelTab === 'online'
                      ? 'bg-white/20 text-white'
                      : 'bg-indigo-100 text-indigo-800'
                  }`}>
                    {universalSearchResults.matchedOnlineProducts.length}
                  </span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-1.5 p-1.5 bg-neutral-100 rounded-2xl w-full">
                <button
                  type="button"
                  onClick={() => {
                    setExplorerRestaurantChannelTab('inhouse');
                    setExplorerSectionView('browse');
                    setExpandedExplorerItemKey(null);
                  }}
                  className={`min-w-0 w-full py-2 px-2 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center leading-tight overflow-hidden ${
                    explorerSectionView === 'browse' && explorerRestaurantChannelTab === 'inhouse'
                      ? 'bg-white text-neutral-900 shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <span className="truncate max-w-full">In-Restaurant Menu</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-200/80 text-neutral-700 shrink-0 whitespace-nowrap">
                    View Only
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setExplorerRestaurantChannelTab('online');
                    setExplorerSectionView('browse');
                    setExpandedExplorerItemKey(null);
                  }}
                  className={`min-w-0 w-full py-2 px-2 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center leading-tight overflow-hidden ${
                    explorerSectionView === 'browse' && explorerRestaurantChannelTab === 'online'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <span className="truncate max-w-full">Online Order Menu</span>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded shrink-0 whitespace-nowrap ${
                    explorerSectionView === 'browse' && explorerRestaurantChannelTab === 'online'
                      ? 'bg-white/20 text-white'
                      : 'bg-amber-100 text-amber-900'
                  }`}>
                    {universalSearchResults.matchedOnlineDishes.length}
                  </span>
                </button>
              </div>
            )}
          </div>
        );

        const renderCustomerOnlineOrdersSection = (mode: 'retail' | 'restaurants') => {
          const isRetailMode = mode === 'retail';
          const orders = isRetailMode ? retailOnlineOrders : restaurantOnlineOrders;
          const activeCount = orders.filter(o => o.status !== 'completed' && o.status !== 'cancelled').length;
          const filtered = customerOrderStatusFilter === 'all'
            ? orders
            : customerOrderStatusFilter === 'active'
              ? orders.filter(o => o.status !== 'completed' && o.status !== 'cancelled')
              : orders.filter(o => o.status === customerOrderStatusFilter);

          const statusSteps: { key: 'received' | 'in_kitchen' | 'ready_for_pickup' | 'completed'; label: string }[] = [
            { key: 'received', label: 'Received' },
            { key: 'in_kitchen', label: isRetailMode ? 'Preparing' : 'In Kitchen' },
            { key: 'ready_for_pickup', label: 'Ready' },
            { key: 'completed', label: 'Completed' },
          ];
          const stepIndexMap: Record<string, number> = {
            received: 0,
            in_kitchen: 1,
            ready_for_pickup: 2,
            completed: 3,
          };

          return (
            <div className="max-w-3xl mx-auto bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5 text-center">
              <div className="flex flex-col items-center justify-center gap-2 pb-3 border-b border-neutral-100">
                <div className="flex items-center justify-center gap-2">
                  {isRetailMode ? (
                    <ShoppingBag className="w-5 h-5 text-indigo-600 shrink-0" />
                  ) : (
                    <UtensilsCrossed className="w-5 h-5 text-amber-600 shrink-0" />
                  )}
                  <h4 className="font-serif-lux text-lg sm:text-xl font-bold text-neutral-900">
                    {isRetailMode ? 'Online Retail Orders' : 'Online Restaurant Orders'}
                  </h4>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-xl border ${
                    isRetailMode ? 'bg-indigo-50 text-indigo-900 border-indigo-200' : 'bg-amber-50 text-amber-900 border-amber-200'
                  }`}>
                    Active ({activeCount}) • Total ({orders.length})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (isRetailMode) setExplorerRetailChannelTab('online');
                      else setExplorerRestaurantChannelTab('online');
                      setExplorerSectionView('browse');
                    }}
                    className="text-xs font-bold px-3 py-1 rounded-xl bg-neutral-900 hover:bg-black text-white cursor-pointer"
                  >
                    + Place Another Online Order
                  </button>
                </div>
              </div>

              {/* Status Filter Pills */}
              <div className="flex flex-wrap items-center justify-center gap-1.5">
                {([
                  { id: 'all', label: `All (${orders.length})` },
                  { id: 'active', label: `Active (${activeCount})` },
                  { id: 'received', label: 'Received' },
                  { id: 'in_kitchen', label: isRetailMode ? 'Preparing' : 'In Kitchen' },
                  { id: 'ready_for_pickup', label: 'Ready' },
                  { id: 'completed', label: 'Completed' },
                  { id: 'cancelled', label: 'Cancelled' },
                ] as const).map(st => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setCustomerOrderStatusFilter(st.id)}
                    className={`px-3 py-1 rounded-xl text-[11px] font-bold border cursor-pointer transition-colors ${
                      customerOrderStatusFilter === st.id
                        ? (isRetailMode ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-amber-600 text-white border-amber-600')
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>

              {/* Orders List */}
              {filtered.length === 0 ? (
                <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200/70 text-center space-y-2">
                  <p className="text-xs font-bold text-neutral-800">
                    No {customerOrderStatusFilter === 'all' ? '' : `${customerOrderStatusFilter.replace(/_/g, ' ')} `}
                    {isRetailMode ? 'retail' : 'restaurant'} online orders yet.
                  </p>
                  <p className="text-[11px] text-neutral-500">
                    Add items from Online {isRetailMode ? 'Inventory' : 'Order Menu'} and complete checkout to track live order status notifications here.
                  </p>
                </div>
              ) : (
                <div className="space-y-4 text-center">
                  {filtered.map(order => {
                    const isDelivery = order.fulfillmentType === 'delivery' || !!order.deliveryAddress;
                    const cancelStatus = getCustomerCancellationStatus(order, nowMs);
                    const currentStepIdx = stepIndexMap[order.status] ?? 0;

                    return (
                      <div key={order.id} className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200/90 space-y-3.5 text-center">
                        <div className="flex flex-col items-center justify-center gap-2 pb-2.5 border-b border-neutral-200/70 text-center">
                          <div className="space-y-1 flex flex-col items-center justify-center">
                            <div className="flex flex-wrap items-center justify-center gap-1.5">
                              <span className="text-xs font-extrabold text-neutral-900 font-mono">{order.orderNumber}</span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                                isRetailMode ? 'bg-indigo-50 text-indigo-900 border-indigo-200' : 'bg-amber-50 text-amber-900 border-amber-200'
                              }`}>
                                {order.restaurantName}
                              </span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase border ${
                                order.status === 'cancelled'
                                  ? 'bg-rose-50 text-rose-800 border-rose-200'
                                  : order.status === 'completed'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : order.status === 'ready_for_pickup'
                                      ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                                      : 'bg-amber-50 text-amber-900 border-amber-200'
                              }`}>
                                {order.status === 'in_kitchen'
                                  ? (isRetailMode ? 'Preparing' : 'In Kitchen')
                                  : order.status === 'ready_for_pickup'
                                    ? 'Ready'
                                    : order.status.replace(/_/g, ' ')}
                              </span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                                isDelivery ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-neutral-100 text-neutral-700 border-neutral-200'
                              }`}>
                                {isDelivery ? 'Delivery' : 'Pickup'}
                              </span>
                            </div>
                            <p className="text-[10px] text-neutral-500 font-mono text-center">
                              Placed: {new Date(order.createdAt).toLocaleString()}
                            </p>
                          </div>

                          <div className="text-center pt-1">
                            {order.driverAccepted ? (
                              <div className="space-y-0.5">
                                <p className="text-[11px] font-mono text-neutral-500 line-through">
                                  Before: {(order.originalTotal ?? order.total).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                                </p>
                                <p className={`text-sm font-extrabold font-mono ${order.status === 'cancelled' ? 'text-rose-700 line-through' : 'text-emerald-700'}`}>
                                  After: {order.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                                  {order.deliveryFeeCurrency && order.deliveryFeeCurrency !== order.currency && order.updatedDeliveryFee
                                    ? ` + ${order.updatedDeliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${order.deliveryFeeCurrency}`
                                    : ''}
                                </p>
                                <p className="text-[10px] font-mono text-emerald-700 font-semibold">
                                  Updated with Driver Coin Rate
                                </p>
                              </div>
                            ) : (
                              <>
                                <p className={`text-sm font-extrabold font-mono ${order.status === 'cancelled' ? 'text-rose-700 line-through' : 'text-emerald-700'}`}>
                                  {order.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                                </p>
                                <p className="text-[10px] font-mono text-neutral-500">
                                  {order.status === 'cancelled' ? 'Tax Ledger Reversed' : 'Synced to Tax Ledger'}
                                </p>
                              </>
                            )}
                          </div>
                        </div>

                        {/* Live 4-Stage Status Progress Bar (unless cancelled) */}
                        {order.status === 'cancelled' ? (
                          <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex flex-col items-center justify-center gap-1 text-center">
                            <span className="font-bold flex items-center justify-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                              <span>{order.cancelledReason || 'Order cancelled & reversed in Tax Ledger'}</span>
                            </span>
                            {order.cancelledAt && (
                              <span className="text-[10px] font-mono text-rose-700">
                                {new Date(order.cancelledAt).toLocaleString()}
                              </span>
                            )}
                          </div>
                        ) : (
                          <div className="grid grid-cols-4 gap-1.5">
                            {statusSteps.map((step, sIdx) => {
                              const isDoneOrCurrent = sIdx <= currentStepIdx;
                              const isCurrent = sIdx === currentStepIdx;
                              return (
                                <div
                                  key={step.key}
                                  className={`px-2 py-1.5 rounded-xl border text-center transition-colors ${
                                    isDoneOrCurrent
                                      ? (isCurrent && step.key !== 'completed'
                                          ? (isRetailMode ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-amber-600 text-white border-amber-600')
                                          : 'bg-emerald-600 text-white border-emerald-600')
                                      : 'bg-white text-neutral-400 border-neutral-200'
                                  }`}
                                >
                                  <p className="text-[10px] font-bold truncate">{step.label}</p>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* Before and After Driver Pricing Notice + 5-Min Countdown Clock */}
                        {order.driverAccepted && (
                          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 space-y-2 text-center font-mono">
                            <p className="font-bold">
                              Sovereign Driver Accepted Delivery ({order.driverName})
                            </p>
                            <div className="flex flex-wrap items-center justify-center gap-2 text-[11px]">
                              <span className="px-2 py-0.5 rounded-md bg-white border border-neutral-200 text-neutral-700">
                                {isRetailMode ? 'Store' : 'Restaurant'} Rate:{' '}
                                <strong className="line-through">
                                  {(order.storeRatePerMile ?? 2.5).toLocaleString()} {order.originalDeliveryFeeCurrency || order.currency}/mi
                                </strong>
                              </span>
                              <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white font-bold">
                                Driver Rate:{' '}
                                {(order.driverRatePerMile ?? 6).toLocaleString()} {order.driverRateCurrency || order.deliveryFeeCurrency || order.currency}/mi
                              </span>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] pt-0.5">
                              <div className="p-2 rounded-lg bg-white/80 border border-emerald-200/70">
                                <span className="block text-[10px] uppercase text-neutral-500">Delivery Fee (Before → After)</span>
                                <span className="text-neutral-500 line-through mr-1.5">
                                  {(order.originalDeliveryFee ?? 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.originalDeliveryFeeCurrency || order.currency}
                                </span>
                                <span className="font-bold text-emerald-800">
                                  → {(order.updatedDeliveryFee ?? order.deliveryFee ?? 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.deliveryFeeCurrency || order.currency}
                                </span>
                              </div>
                              <div className="p-2 rounded-lg bg-white/80 border border-emerald-200/70">
                                <span className="block text-[10px] uppercase text-neutral-500">Order Total (Before → After)</span>
                                <span className="text-neutral-500 line-through mr-1.5">
                                  {(order.originalTotal ?? order.total).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                                </span>
                                <span className="font-bold text-emerald-800">
                                  → {order.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {order.currency}
                                  {order.deliveryFeeCurrency && order.deliveryFeeCurrency !== order.currency && order.updatedDeliveryFee
                                    ? ` + ${order.updatedDeliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${order.deliveryFeeCurrency}`
                                    : ''}
                                </span>
                              </div>
                            </div>
                            {order.status !== 'cancelled' && order.status !== 'completed' && cancelStatus.isDriverPriceWindow && (
                              <div className={`p-2 rounded-lg border text-[11px] font-bold flex flex-wrap items-center justify-center gap-2 ${
                                cancelStatus.canCancel
                                  ? 'bg-amber-50 border-amber-300 text-amber-950'
                                  : 'bg-neutral-100 border-neutral-200 text-neutral-600'
                              }`}>
                                <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                {cancelStatus.canCancel ? (
                                  <span>
                                    5-Min Price Update Cancel Window:{' '}
                                    <span className="px-2 py-0.5 rounded bg-amber-600 text-white tabular-nums">
                                      {Math.floor(cancelStatus.remainingMs / 60000)}:
                                      {Math.floor((cancelStatus.remainingMs % 60000) / 1000).toString().padStart(2, '0')}
                                    </span>{' '}
                                    remaining
                                  </span>
                                ) : (
                                  <span>5-Minute Price Update Cancellation Window Expired</span>
                                )}
                              </div>
                            )}
                          </div>
                        )}

                        {/* Customer & Fulfillment Info - Centered */}
                        <div className="p-3.5 rounded-xl bg-white border border-neutral-200/80 flex flex-col items-center justify-center text-center gap-3 text-xs">
                          <div className="space-y-1 w-full flex flex-col items-center justify-center">
                            <span className="text-[10px] font-bold uppercase font-mono text-neutral-400 block">Customer</span>
                            <p className="font-bold text-neutral-900">{order.customerName}</p>
                            {order.customerPhone && <p className="text-[11px] font-mono text-neutral-600">{order.customerPhone}</p>}
                            {order.customerEmail && <p className="text-[11px] text-neutral-600">{order.customerEmail}</p>}
                          </div>
                          <div className="space-y-1 w-full flex flex-col items-center justify-center pt-2 border-t border-neutral-100">
                            <span className="text-[10px] font-bold uppercase font-mono text-neutral-400 block">
                              {order.deliveryAddress ? 'Delivery Address' : 'Pickup Instructions'}
                            </span>
                            {order.deliveryAddress ? (
                              <div className="text-[11px] text-indigo-950 flex flex-col items-center justify-center text-center">
                                <p className="font-bold">
                                  {order.deliveryAddress.label ? `[${order.deliveryAddress.label}] ` : ''}{order.deliveryAddress.fullName}
                                </p>
                                <p>{order.deliveryAddress.address}</p>
                              </div>
                            ) : (
                              <p className="text-[11px] text-neutral-700">{order.pickupTime}</p>
                            )}
                          </div>
                        </div>

                        {/* Itemized Breakdown - Centered */}
                        <div className="p-3.5 rounded-xl bg-white border border-neutral-200/80 space-y-1.5 text-xs text-center">
                          {order.items.map((line, lIdx) => (
                            <div key={`${order.id}-cust-it-${lIdx}`} className="flex flex-col sm:flex-row items-center justify-between gap-1 text-[11px]">
                              <span className="font-semibold text-neutral-900 text-center">{line.quantity}x {line.item.name}</span>
                              <span className="font-mono text-neutral-700 shrink-0 text-center">
                                {(line.item.price * line.quantity).toLocaleString()} {line.item.currency}
                              </span>
                            </div>
                          ))}
                          {order.notes && (
                            <p className="text-[11px] text-neutral-600 pt-1 border-t border-neutral-100 text-center">Notes: {order.notes}</p>
                          )}
                        </div>

                        {/* Customer Cancellation Policy & Action - Centered */}
                        {order.status !== 'cancelled' && order.status !== 'completed' && (
                          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-1 text-center">
                            <span className="text-[11px] text-neutral-600 flex items-center justify-center gap-1">
                              {cancelStatus.canCancel ? (
                                <>
                                  <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                  <span>
                                    {cancelStatus.isDriverPriceWindow
                                      ? '5-minute window to cancel after driver price update'
                                      : isRetailMode
                                        ? 'Cancellable until store accepts or completes order'
                                        : 'Cancellable under 10 minutes from order placement'}
                                  </span>
                                </>
                              ) : (
                                <>
                                  <Lock className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                                  <span className="text-neutral-500">{cancelStatus.reasonLabel}</span>
                                </>
                              )}
                            </span>

                            {cancelStatus.canCancel ? (
                              <button
                                type="button"
                                onClick={() => handleCancelOnlineOrder(order.id)}
                                className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 border border-rose-300 text-[11px] font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5 tabular-nums"
                              >
                                <X className="w-3.5 h-3.5 shrink-0" />
                                <span>{cancelStatus.reasonLabel}</span>
                              </button>
                            ) : (
                              <span className="px-2.5 py-1 rounded-xl bg-neutral-100 text-neutral-500 border border-neutral-200 text-[10px] font-bold">
                                Cancellation Locked
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        };

        const renderCustomerCheckoutSection = (mode: 'retail' | 'restaurants') => {
          const targetLocations = mode === 'retail' ? activeRetailCartLocations : activeRestaurantCartLocations;
          return (
          <div className="space-y-6">
            <div className="text-center space-y-1">
              <h4 className="font-serif-lux text-lg sm:text-xl font-bold text-neutral-900 flex items-center justify-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{mode === 'retail' ? 'Store Checkout' : 'Restaurant Checkout'}</span>
              </h4>
            </div>

            {targetLocations.length === 0 ? (
              <div className="bg-white border border-neutral-200 rounded-3xl p-8 text-center space-y-2 max-w-2xl mx-auto">
                <ShoppingBag className="w-10 h-10 text-neutral-300 mx-auto" />
                <p className="text-sm font-bold text-neutral-900">
                  {mode === 'retail' ? 'Your store cart is empty' : 'Your restaurant takeout order is empty'}
                </p>
                <p className="text-xs text-neutral-500">
                  {mode === 'retail'
                    ? 'Add items from any retail store’s Online Store inventory to deliver to your saved address and settle in their Final Currency.'
                    : 'Add dishes from any restaurant’s Online Menu to place an online takeout pickup order.'}
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {targetLocations.map(loc => {
                  const totals = computeLocCartTotals(loc);
                  const {
                    locBag,
                    sub,
                    locTax,
                    locTip,
                    locTotal,
                    locCurrency,
                    tipPct,
                    customTipStr,
                    isDelivery,
                    feeRate,
                    feeCurrency,
                    feeUnit,
                    distance,
                    deliveryFee,
                    deliveryFeeMatchesCurrency
                  } = totals;
                  const locMerged = getMergedLocationItems(loc);
                  const openStatus = checkLocationOpenStatus(loc);

                  return (
                    <div
                      key={`co-loc-${loc.id}`}
                      className={`bg-white rounded-3xl p-5 sm:p-6 shadow-xs border space-y-5 text-center ${
                        loc.type === 'retail' ? 'border-indigo-200' : 'border-amber-200'
                      }`}
                    >
                      {/* Store / Restaurant Checkout Header (Centered) */}
                      <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-neutral-100 text-center">
                        <div className="space-y-1.5 text-center">
                          <div className="flex flex-wrap items-center justify-center gap-2">
                            <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono border ${
                              loc.type === 'retail'
                                ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}>
                              {loc.type === 'retail' ? 'RETAIL STORE & ONLINE' : 'RESTAURANT & ONLINE MENU'}
                            </span>
                            <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${openStatus.badgeClass}`}>
                              {openStatus.statusText}
                            </span>
                            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono">
                              Currency: {locCurrency}
                            </span>
                          </div>
                          <h5 className="font-serif-lux text-lg font-bold text-neutral-900 text-center">{loc.name}</h5>
                          <p className="text-xs text-neutral-500 text-center">{loc.address} • {loc.phone} • {loc.email}</p>
                        </div>

                        <div className="flex flex-wrap items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenStoreModal(loc)}
                            className="px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold cursor-pointer"
                          >
                            + Add More Items
                          </button>
                          <button
                            type="button"
                            onClick={() => clearCustomerLocCart(loc.id)}
                            className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                          >
                            Clear Cart
                          </button>
                        </div>
                      </div>

                      {/* Items in this Store/Restaurant's Cart (Centered) */}
                      <div className="space-y-2.5">
                        {locBag.map(({ item, quantity }) => {
                          const match = locMerged.find(m => m.item.id === item.id);
                          return (
                            <div
                              key={`co-item-${loc.id}-${item.id}`}
                              className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/70 flex flex-col items-center justify-center gap-2.5 text-center"
                            >
                              <div className="flex flex-col items-center justify-center gap-2 text-center">
                                {item.image && (
                                  <img
                                    src={item.image}
                                    alt=""
                                    onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                    className="w-14 h-14 rounded-xl object-cover shrink-0 bg-neutral-200"
                                  />
                                )}
                                <div className="space-y-1 text-center">
                                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                                    {match && (
                                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md border font-mono ${match.badgeClass}`}>
                                        {match.channelLabel}
                                      </span>
                                    )}
                                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-200/70 text-neutral-700 font-mono">
                                      {item.category}
                                    </span>
                                  </div>
                                  <p className="text-xs font-bold text-neutral-900 text-center">{item.name}</p>
                                  <p className="text-[11px] font-mono text-emerald-700 font-semibold text-center">
                                    {item.price.toLocaleString()} {item.currency} each
                                  </p>
                                </div>
                              </div>

                              <div className="flex flex-wrap items-center justify-center gap-3">
                                <div className="flex items-center gap-1.5 bg-white border border-neutral-200 rounded-xl px-2 py-1">
                                  <button
                                    type="button"
                                    onClick={() => updateCustomerLocCartQty(loc.id, item.id, -1)}
                                    className="w-6 h-6 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-xs font-bold cursor-pointer"
                                  >
                                    -
                                  </button>
                                  <span className="text-xs font-mono font-bold w-6 text-center">{quantity}</span>
                                  <button
                                    type="button"
                                    onClick={() => updateCustomerLocCartQty(loc.id, item.id, 1)}
                                    className="w-6 h-6 rounded-lg bg-emerald-600 text-white text-xs font-bold cursor-pointer"
                                  >
                                    +
                                  </button>
                                </div>
                                <span className="text-xs font-mono font-extrabold text-emerald-700">
                                  {(item.price * quantity).toLocaleString()} {item.currency}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => removeCustomerLocCartItem(loc.id, item.id)}
                                  className="p-1.5 text-neutral-400 hover:text-rose-600 cursor-pointer"
                                  aria-label="Remove item"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Fulfillment (Saved / On-the-Spot Delivery Address + Fee or Counter Pickup), Final Currency & Tip (Centered) */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-neutral-100 text-center">
                        <div>{renderLocationFulfillmentControls(loc, totals, false)}</div>

                        {/* Relevant Final Currencies Selector for THIS Store/Restaurant ONLY */}
                        <div className="space-y-1.5 text-center">
                          <label className="text-[10px] font-bold text-neutral-600 uppercase font-mono block text-center">
                            Settlement Final Currency ({loc.name})
                          </label>
                          {(() => {
                            const relevantCoins = getCustomerRelevantCurrenciesForLoc(loc);
                            return (
                              <div className="space-y-1.5">
                                <div className="flex flex-wrap items-center justify-center gap-1.5">
                                  {relevantCoins.map(coin => (
                                    <button
                                      key={`loc-cur-${loc.id}-${coin.symbol}`}
                                      type="button"
                                      onClick={() => setCustomerCurrencyByLoc(prev => ({ ...prev, [loc.id]: coin.symbol }))}
                                      className={`px-2.5 py-1.5 rounded-xl text-[11px] font-mono font-bold border flex items-center gap-1 cursor-pointer transition-all ${
                                        locCurrency === coin.symbol
                                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                          : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-800 border-neutral-200'
                                      }`}
                                    >
                                      <span>{coin.icon}</span>
                                      <span>{coin.symbol}</span>
                                    </button>
                                  ))}
                                </div>
                                <p className="text-[10px] text-neutral-500">
                                  Showing {relevantCoins.length} accepted Final {relevantCoins.length === 1 ? 'Currency' : 'Currencies'} for cart items
                                </p>
                              </div>
                            );
                          })()}
                        </div>

                        {/* Tip Input (Optional for Retail / Custom % or Value for Restaurant) */}
                        <div className="space-y-1.5 text-center">
                          <label className="text-[10px] font-bold text-neutral-600 uppercase font-mono block text-center">
                            {loc.type === 'retail' ? 'Optional Tip (Final Coins)' : `Tip (${customTipStr !== '' ? 'Custom' : `${tipPct}%`})`}
                          </label>
                          <div className="flex flex-wrap items-center justify-center gap-1.5">
                            {loc.type === 'restaurant' && [0, 15, 18, 20].map(pct => (
                              <button
                                key={pct}
                                type="button"
                                onClick={() => {
                                  setCustomerTipPctByLoc(prev => ({ ...prev, [loc.id]: pct }));
                                  setCustomerCustomTipByLoc(prev => ({ ...prev, [loc.id]: '' }));
                                }}
                                className={`px-2 py-1.5 rounded-lg text-[10px] font-bold cursor-pointer ${
                                  tipPct === pct && customTipStr === '' ? 'bg-amber-600 text-white' : 'bg-neutral-100 text-neutral-700'
                                }`}
                              >
                                {pct}%
                              </button>
                            ))}
                            <input
                              type="number"
                              min={0}
                              step="any"
                              placeholder={loc.type === 'retail' ? '0.00 (Optional)' : 'Custom'}
                              value={customTipStr}
                              onChange={(e) => setCustomerCustomTipByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
                              className="w-full px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-center"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Order Notes + Summary + Independent Settle Button (Centered) */}
                      <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3 text-center">
                        <input
                          type="text"
                          placeholder={isDelivery ? 'Delivery instructions, gate code, or packaging notes...' : 'Dietary notes, allergies, or takeout counter pickup notes...'}
                          value={customerNotesByLoc[loc.id] || ''}
                          onChange={(e) => setCustomerNotesByLoc(prev => ({ ...prev, [loc.id]: e.target.value }))}
                          className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs text-center"
                        />

                        <div className="space-y-1.5 text-xs text-center max-w-md mx-auto">
                          <div className="flex items-center justify-center gap-2 text-neutral-600">
                            <span>Subtotal ({locBag.reduce((s, i) => s + i.quantity, 0)} items):</span>
                            <span className="font-mono font-bold text-neutral-900">{sub.toLocaleString()} {locCurrency}</span>
                          </div>
                          <div className="flex items-center justify-center gap-2 text-neutral-600">
                            <span>Commerce Tax (5%):</span>
                            <span className="font-mono font-bold text-neutral-900">{locTax.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {locCurrency}</span>
                          </div>
                          {isDelivery && (
                            <div className="flex items-center justify-center gap-2 text-neutral-600">
                              <span>
                                Delivery Fee ({distance} {feeUnit === 'km' ? 'km' : 'mi'} &times; {feeRate} {feeCurrency}/{feeUnit}):
                              </span>
                              <span className="font-mono font-bold text-indigo-800">
                                {deliveryFee > 0 ? `${deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${feeCurrency}` : `0 ${feeCurrency}`}
                              </span>
                            </div>
                          )}
                          {locTip > 0 && (
                            <div className="flex items-center justify-center gap-2 text-neutral-600">
                              <span>Tip:</span>
                              <span className="font-mono font-bold text-neutral-900">{locTip.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {locCurrency}</span>
                            </div>
                          )}
                          <div className="flex items-center justify-center gap-2 pt-2 border-t border-neutral-200 text-sm font-extrabold font-mono">
                            <span>Total Due for {loc.name}:</span>
                            <span className="text-emerald-700">
                              {locTotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {locCurrency}
                              {isDelivery && deliveryFee > 0 && !deliveryFeeMatchesCurrency
                                ? ` + ${deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${feeCurrency}`
                                : ''}
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handlePlaceTakeoutOrder(loc)}
                          className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold cursor-pointer shadow-xs flex items-center justify-center gap-2"
                        >
                          <Coins className="w-4 h-4 shrink-0" />
                          <span>
                            Checkout &amp; Settle with {loc.name} ({locTotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {locCurrency}
                            {isDelivery && deliveryFee > 0 && !deliveryFeeMatchesCurrency
                              ? ` + ${deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${feeCurrency}`
                              : ''})
                          </span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          );
        };

        const renderDeliveryAddressSection = () => (
          <div className="space-y-6 max-w-4xl mx-auto text-center flex flex-col items-center">
            <div className="text-center space-y-1 w-full">
              <h4 className="font-serif-lux text-lg sm:text-xl font-bold text-neutral-900 flex items-center justify-center gap-2">
                <MapPin className="w-5 h-5 text-indigo-600 shrink-0" />
                <span>Saved Delivery Addresses ({deliveryAddresses.length}/5)</span>
              </h4>
            </div>

            {deliveryAddresses.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {deliveryAddresses.map((addr, idx) => (
                  <div
                    key={addr.id}
                    className={`bg-white rounded-2xl p-4 border shadow-2xs space-y-2.5 ${
                      addr.isDefault ? 'border-indigo-500 ring-1 ring-indigo-500/20' : 'border-neutral-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-800 font-mono truncate">
                          {addr.label || `Address ${idx + 1}`}
                        </span>
                        {addr.isDefault && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200">
                            Default
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {!addr.isDefault && (
                          <button
                            type="button"
                            onClick={() => persistDeliveryAddresses(deliveryAddresses.map(a => ({ ...a, isDefault: a.id === addr.id })))}
                            className="text-[10px] font-bold text-indigo-700 hover:underline cursor-pointer px-1.5"
                          >
                            Set Default
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setEditingAddressId(addr.id);
                            setAddrLabel(addr.label || '');
                            setAddrFullName(addr.fullName);
                            setAddrPhone(addr.phone);
                            setAddrEmail(addr.email);
                            setAddrStreet(addr.address);
                            setAddrError('');
                          }}
                          className="p-1.5 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-700 cursor-pointer"
                          title="Edit address"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const filtered = deliveryAddresses.filter(a => a.id !== addr.id);
                            if (filtered.length > 0 && !filtered.some(a => a.isDefault)) {
                              filtered[0] = { ...filtered[0], isDefault: true };
                            }
                            persistDeliveryAddresses(filtered);
                            if (editingAddressId === addr.id) {
                              setEditingAddressId(null);
                              setAddrLabel('');
                              setAddrFullName('');
                              setAddrPhone('');
                              setAddrEmail('');
                              setAddrStreet('');
                            }
                          }}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                          title="Delete address"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1 text-xs text-neutral-700">
                      <p className="font-bold text-neutral-900 flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                        <span>{addr.fullName}</span>
                      </p>
                      {addr.phone && (
                        <p className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                          <span>{addr.phone}</span>
                        </p>
                      )}
                      {addr.email && (
                        <p className="flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                          <span>{addr.email}</span>
                        </p>
                      )}
                      <p className="flex items-start gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                        <span>{addr.address}</span>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Add / Edit Delivery Address Form */}
            <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
              <div className="text-center pb-3 border-b border-neutral-100">
                <h5 className="font-serif-lux text-base font-bold text-neutral-900">
                  {editingAddressId ? 'Edit Delivery Address' : `Add Delivery Address (${deliveryAddresses.length}/5)`}
                </h5>
              </div>

              {deliveryAddresses.length >= 5 && !editingAddressId ? (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-center space-y-1">
                  <p className="text-xs font-bold text-amber-900">Maximum of 5 delivery addresses saved (5/5).</p>
                  <p className="text-[11px] text-amber-800">Edit or delete one of the saved addresses above to add a different address.</p>
                </div>
              ) : (
                <form onSubmit={handleSaveDeliveryAddress} className="space-y-3.5 max-w-xl mx-auto">
                  {addrError && (
                    <p className="text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 px-3 py-2 rounded-xl text-center">
                      {addrError}
                    </p>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-neutral-700 block">Address Label (Optional)</label>
                      <input
                        type="text"
                        placeholder="e.g. Home, Office, Zurich Suite"
                        value={addrLabel}
                        onChange={(e) => setAddrLabel(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-neutral-700 block">Recipient Full Name *</label>
                      <input
                        type="text"
                        placeholder="Full name"
                        value={addrFullName}
                        onChange={(e) => setAddrFullName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-neutral-700 block">Phone Number (Optional)</label>
                      <input
                        type="tel"
                        placeholder="e.g. +41 44 555 0199"
                        value={addrPhone}
                        onChange={(e) => setAddrPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-neutral-700 block">Email Address (Optional)</label>
                      <input
                        type="email"
                        placeholder="recipient@example.com"
                        value={addrEmail}
                        onChange={(e) => setAddrEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-neutral-700 block">Full Delivery Address *</label>
                    <textarea
                      rows={3}
                      placeholder="Street address, apartment/suite, city, postal code, and country..."
                      value={addrStreet}
                      onChange={(e) => setAddrStreet(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                      required
                    />
                  </div>

                  <div className="flex items-center justify-center gap-2 pt-1">
                    {editingAddressId && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingAddressId(null);
                          setAddrLabel('');
                          setAddrFullName('');
                          setAddrPhone('');
                          setAddrEmail('');
                          setAddrStreet('');
                          setAddrError('');
                        }}
                        className="px-4 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-bold cursor-pointer"
                      >
                        Cancel
                      </button>
                    )}
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                    >
                      {editingAddressId ? 'Update Delivery Address' : `Save Delivery Address (${deliveryAddresses.length}/5)`}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        );

        return (
        <div className="space-y-6">
          {/* 1A. RESTAURANTS & FOOD MENUS SUB-TAB */}
          {customerSubTab === 'restaurants' && (
            <div className="space-y-6">
              {/* Search Header for Restaurants & Dishes */}
              <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
                <div className="flex flex-col items-center justify-center gap-3">
                  <h3 className="font-serif-lux text-base sm:text-lg font-bold text-neutral-900 flex items-center justify-center gap-2 whitespace-nowrap text-center">
                    <UtensilsCrossed className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600 shrink-0" />
                    <span>Restaurants &amp; Online Menus</span>
                  </h3>

                  <div className="relative w-full max-w-md mx-auto">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      placeholder="Search restaurant or dish..."
                      value={universalSearchQuery}
                      onChange={(e) => {
                        setUniversalSearchQuery(e.target.value);
                        if (explorerSectionView !== 'browse') setExplorerSectionView('browse');
                      }}
                      className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Checkout, Online Orders & Delivery Address Tab Bar */}
              {renderSectionNavBar(false)}

              {explorerSectionView === 'checkout' && renderCustomerCheckoutSection('restaurants')}
              {explorerSectionView === 'online_orders' && renderCustomerOnlineOrdersSection('restaurants')}
              {explorerSectionView === 'delivery_address' && renderDeliveryAddressSection()}

              {/* Matched Dishes Section (Filtered strictly by In-Restaurant View Only vs Online Order Menu) */}
              {explorerSectionView === 'browse' && (() => {
                const isOnlineTab = explorerRestaurantChannelTab === 'online';
                const displayedDishes = isOnlineTab
                  ? universalSearchResults.matchedOnlineDishes
                  : universalSearchResults.matchedInHouseDishes;
                const otherTabCount = isOnlineTab
                  ? universalSearchResults.matchedInHouseDishes.length
                  : universalSearchResults.matchedOnlineDishes.length;
                if (displayedDishes.length === 0) {
                  return (
                    <div className="bg-white border border-neutral-200 rounded-2xl p-6 text-center space-y-2 max-w-xl mx-auto">
                      <p className="text-xs font-bold text-neutral-800">
                        {isOnlineTab ? 'No online order dishes found.' : 'No in-restaurant menu dishes found.'}
                      </p>
                      <p className="text-[11px] text-neutral-500">
                        {isOnlineTab
                          ? 'Switch to In-Restaurant Menu or adjust your search.'
                          : 'Switch to Online Order Menu to browse dishes available for takeout or delivery.'}
                      </p>
                      {otherTabCount > 0 && (
                        <button
                          type="button"
                          onClick={() => setExplorerRestaurantChannelTab(isOnlineTab ? 'inhouse' : 'online')}
                          className="inline-flex items-center justify-center px-3.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-[11px] font-bold cursor-pointer"
                        >
                          {isOnlineTab
                            ? `View ${otherTabCount} matching dish(es) in In-Restaurant Menu (View Only)`
                            : `View ${otherTabCount} matching dish(es) in Online Order Menu`}
                        </button>
                      )}
                    </div>
                  );
                }
                return (
                <div className="space-y-3">
                  <div className="flex flex-col items-center justify-center text-center gap-1">
                    <h4 className="text-xs font-bold text-neutral-900 uppercase font-mono tracking-wide flex items-center justify-center gap-1.5 text-center">
                      <UtensilsCrossed className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>
                        {isOnlineTab
                          ? `Online Order Dishes Found (${displayedDishes.length}):`
                          : `In-Restaurant Menu Dishes — View Only (${displayedDishes.length}):`}
                      </span>
                    </h4>
                    <p className="text-[11px] text-neutral-500">
                      {isOnlineTab
                        ? 'Order online for takeout pickup or delivery (delivery address required when choosing delivery).'
                        : 'Displayed for dine-in viewing only — customers cannot order from the in-restaurant menu online.'}
                    </p>
                    {universalSearchQuery && (
                      <button
                        type="button"
                        onClick={() => setUniversalSearchQuery('')}
                        className="text-[11px] text-amber-700 hover:underline cursor-pointer"
                      >
                        Clear search
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {displayedDishes.map(({ dish, location }) => {
                      const itemKey = `${location.id}-rest-${explorerRestaurantChannelTab}-${dish.id}`;
                      const isExpanded = expandedExplorerItemKey === itemKey;
                      const inLocCartQty = getCustomerLocCart(location.id).find(i => i.item.id === dish.id)?.quantity || 0;
                      const channelLabel = isOnlineTab ? 'Online Menu' : 'In-Restaurant (View Only)';
                      const badgeClass = isOnlineTab
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-neutral-100 text-neutral-700 border-neutral-200';
                      return (
                      <div
                        key={itemKey}
                        onClick={() => setExpandedExplorerItemKey(prev => prev === itemKey ? null : itemKey)}
                        className={`rounded-2xl bg-white border transition-all cursor-pointer ${
                          isExpanded
                            ? 'col-span-full p-5 sm:p-6 border-amber-500 shadow-lg space-y-4 text-center'
                            : 'p-3.5 border-neutral-200 hover:border-amber-400 hover:shadow-md flex items-center justify-between gap-3 group'
                        }`}
                      >
                        {!isExpanded ? (
                          <>
                            <div className="flex items-center gap-3 min-w-0 flex-1">
                              {dish.image && (
                                <img
                                  src={dish.image}
                                  alt=""
                                  onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                  className="w-14 h-14 rounded-xl object-cover shrink-0 bg-neutral-100"
                                />
                              )}
                              <div className="min-w-0 flex-1 space-y-0.5">
                                <span className={`inline-block text-[9px] font-bold px-2 py-0.5 rounded-md border font-mono ${badgeClass}`}>
                                  {channelLabel}
                                </span>
                                <p className="text-xs font-bold text-neutral-900 truncate">{dish.name}</p>
                                <p className="text-xs font-mono font-bold text-emerald-700">{dish.price.toLocaleString()} {dish.currency}</p>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenStoreModal(location, isOnlineTab ? 'online' : 'instore');
                                  }}
                                  className="text-[10px] text-amber-900 font-medium truncate hover:underline cursor-pointer block text-left max-w-full"
                                >
                                  Served at: {location.name}
                                </button>
                              </div>
                            </div>

                            {isOnlineTab ? (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  addItemToCustomerLocCart(location.id, dish);
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-600 hover:text-white text-amber-900 border border-amber-300 text-[10px] font-bold cursor-pointer transition-colors shrink-0"
                              >
                                {inLocCartQty > 0 ? `+ Add (${inLocCartQty})` : '+ Order'}
                              </button>
                            ) : (
                              <span className="px-2.5 py-1 rounded-xl bg-neutral-100 text-neutral-600 border border-neutral-200 text-[10px] font-bold shrink-0">
                                View Only
                              </span>
                            )}
                          </>
                        ) : (
                          <div className="space-y-4 text-center">
                            <div className="flex flex-col items-center justify-center gap-2 border-b border-neutral-100 pb-3 text-center">
                              <div className="flex flex-wrap items-center justify-center gap-1.5">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border font-mono ${badgeClass}`}>{channelLabel}</span>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-700 font-mono">{dish.category}</span>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-mono">
                                  {dish.stock !== undefined ? `${dish.stock} Portions Available` : 'Available'}
                                </span>
                              </div>
                              <h4 className="font-serif-lux text-lg font-bold text-neutral-900 text-center">{dish.name}</h4>
                              <p className="text-sm font-mono font-extrabold text-emerald-700 text-center">
                                {dish.price.toLocaleString()} {dish.currency} (Final Currency)
                              </p>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setExpandedExplorerItemKey(null);
                                }}
                                className="px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-bold cursor-pointer"
                              >
                                Collapse &times;
                              </button>
                            </div>

                            {/* Photos & Videos Gallery */}
                            {((dish.photos && dish.photos.length > 0) || dish.image || (dish.videos && dish.videos.length > 0)) && (
                              <div className="flex flex-wrap items-center justify-center gap-3">
                                {(dish.photos && dish.photos.length > 0 ? dish.photos : (dish.image ? [dish.image] : [])).map((photoUrl, idx) => (
                                  <img
                                    key={`exp-dp-${idx}`}
                                    src={photoUrl}
                                    alt=""
                                    onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                    className="w-36 h-28 sm:w-44 sm:h-32 rounded-2xl object-cover border border-neutral-200 bg-neutral-100"
                                  />
                                ))}
                                {dish.videos?.map((vidUrl, idx) => (
                                  <video
                                    key={`exp-dv-${idx}`}
                                    src={vidUrl}
                                    controls
                                    onClick={(e) => e.stopPropagation()}
                                    className="w-52 h-32 rounded-2xl border border-neutral-200 bg-black object-cover"
                                  />
                                ))}
                              </div>
                            )}

                            {/* Full Detailed Description */}
                            <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/70 space-y-1 text-center">
                              <span className="text-[10px] font-bold text-neutral-500 uppercase font-mono block text-center">Full Dish Details &amp; Ingredients</span>
                              <p className="text-xs text-neutral-800 whitespace-pre-wrap leading-relaxed text-center max-w-2xl mx-auto">
                                {dish.description || 'Prepared fresh to order and settled directly in Final Currency.'}
                              </p>
                            </div>

                            {/* QR Codes if attached */}
                            {dish.qrCodes && dish.qrCodes.length > 0 && (
                              <div className="flex flex-wrap items-center justify-center gap-3">
                                {dish.qrCodes.map((qr, qIdx) => (
                                  <div key={`exp-dqr-${qIdx}`} className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col items-center gap-2 text-center">
                                    <div className="p-1.5 bg-white rounded-xl border border-neutral-200 shrink-0">
                                      <QRCodeSVG value={qr.payload} size={56} level="M" />
                                    </div>
                                    <div className="text-center">
                                      <p className="text-[11px] font-bold text-neutral-900">
                                        {qr.type === 'one-time' ? '⚡ One-Time Invoice QR' : '📦 Inventory Catalog QR'}
                                      </p>
                                      <p className="text-[10px] font-mono text-neutral-500 break-all max-w-[240px]">{qr.payload}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Store Info & Action Row */}
                            <div className="flex flex-col items-center justify-center gap-3 pt-3 border-t border-neutral-100 text-center">
                              <div className="text-xs text-neutral-600 space-y-0.5 text-center">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenStoreModal(location, isOnlineTab ? 'online' : 'instore');
                                  }}
                                  className="font-bold text-neutral-900 hover:text-amber-700 hover:underline cursor-pointer"
                                >
                                  Served at: {location.name}
                                </button>
                                <p className="text-[11px]">{location.address} • {location.phone} • Hours: {formatTime12h(location.openingTime || '10:00')} – {formatTime12h(location.closingTime || '22:00')}</p>
                              </div>
                              {isOnlineTab ? (
                                <div className="space-y-2 text-center">
                                  <p className="text-[11px] font-semibold text-amber-800">
                                    {location.allowsDelivery
                                      ? `Takeout Pickup at ${location.name} OR Delivery (Address required, ${(location.deliveryFeeRate ?? 0) > 0 ? `${location.deliveryFeeRate} ${location.deliveryFeeCurrency || dish.currency} per ${location.deliveryFeeUnit || 'mile'}` : 'Free Delivery'})`
                                      : `Online Takeout Pickup Only — Pick up at ${location.name} (${location.address})`}
                                  </p>
                                  <div className="flex flex-wrap items-center justify-center gap-2">
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        addItemToCustomerLocCart(location.id, dish);
                                        setExplorerSectionView('checkout');
                                        if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' });
                                      }}
                                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                                    >
                                      + Add to Order &amp; Checkout ({location.name})
                                    </button>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        addItemToCustomerLocCart(location.id, dish);
                                      }}
                                      className="px-4 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold cursor-pointer"
                                    >
                                      {inLocCartQty > 0 ? `Added (${inLocCartQty} in order)` : '+ Add Only'}
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="px-4 py-2 rounded-xl bg-neutral-100 border border-neutral-200 text-xs font-semibold text-neutral-700 text-center">
                                  In-Restaurant Menu Only (View Only) — Available for dine-in viewing at {location.name}. Switch to Online Order Menu to place an order.
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                      );
                    })}
                  </div>
                </div>
                );
              })()}

              {/* Restaurants Directory */}
              {explorerSectionView === 'browse' && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-neutral-900 uppercase font-mono tracking-wide flex items-center justify-center gap-1.5 text-center">
                    <Store className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Restaurants Directory ({universalSearchResults.matchedLocations.length}):</span>
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {universalSearchResults.matchedLocations.map(loc => {
                      const openStatus = checkLocationOpenStatus(loc);
                      const storeRevs = reviewsList.filter(r => r.storeId === loc.id);
                      const avgRating = storeRevs.length > 0
                        ? (storeRevs.reduce((s, r) => s + r.rating, 0) / storeRevs.length).toFixed(1)
                        : '5.0';
                      const qLower = universalSearchQuery.toLowerCase().trim();
                      const isOnlineChannel = explorerRestaurantChannelTab === 'online';
                      const channelDishes = isOnlineChannel
                        ? (onlineMenusByLoc[loc.id] ?? getInitialOnlineMenuForLoc(loc.id))
                        : (restaurantMenusByLoc[loc.id] ?? getInitialRestaurantForLoc(loc.id));
                      const matchingChannelDishes = qLower
                        ? channelDishes.filter(d =>
                            d.name.toLowerCase().includes(qLower) ||
                            d.category.toLowerCase().includes(qLower) ||
                            (d.description && d.description.toLowerCase().includes(qLower))
                          )
                        : [];
                      const previewDishes = (matchingChannelDishes.length > 0 ? matchingChannelDishes : channelDishes).slice(0, 2);
                      const previewChannelLabel = isOnlineChannel ? 'Online Menu' : 'In-Restaurant (View Only)';
                      const previewBadgeClass = isOnlineChannel
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-neutral-100 text-neutral-700 border-neutral-200';

                      return (
                        <div
                          key={loc.id}
                          className="bg-white border border-neutral-200 rounded-3xl p-5 shadow-xs hover:border-amber-500/50 hover:shadow-md transition-all flex flex-col justify-between space-y-4 text-center"
                        >
                          <div className="space-y-3 text-center">
                            <div className="flex flex-wrap items-center justify-center gap-2">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-900 font-mono">
                                {loc.cuisineOrCategory}
                              </span>
                              <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${openStatus.badgeClass}`}>
                                <span className="w-1.5 h-1.5 rounded-full bg-current" />
                                <span>{openStatus.statusText}</span>
                              </span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border font-mono ${
                                loc.allowsDelivery ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-neutral-50 text-neutral-700 border-neutral-200'
                              }`}>
                                {loc.allowsDelivery ? 'Takeout & Delivery' : 'Takeout Only'}
                              </span>
                            </div>

                            <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                              <h4
                                onClick={() => handleOpenStoreModal(loc, isOnlineChannel ? 'online' : 'instore')}
                                className="text-base font-bold text-neutral-900 font-serif-lux text-center cursor-pointer hover:text-amber-700 hover:underline transition-colors"
                              >
                                {loc.name}
                              </h4>
                              <button
                                type="button"
                                onClick={() => handleOpenReviewsModal(loc)}
                                className="inline-flex items-center justify-center gap-1 text-xs font-bold text-amber-700 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 px-2.5 py-0.5 rounded-lg border border-amber-200 cursor-pointer"
                              >
                                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                                <span>{avgRating} ({storeRevs.length})</span>
                              </button>
                              <p className="text-xs text-neutral-500 mt-0.5 line-clamp-2 text-center">{loc.tagline}</p>
                            </div>

                            {/* Channel-separated dish preview */}
                            {previewDishes.length > 0 && (
                              <div className="pt-2 border-t border-neutral-100 space-y-1.5 text-center">
                                <p className="text-[10px] font-bold text-neutral-400 uppercase font-mono text-center">
                                  {isOnlineChannel ? 'Online Order Preview:' : 'In-Restaurant Menu Preview:'}
                                </p>
                                <div className="space-y-1">
                                  {previewDishes.map(d => (
                                    <div key={d.id} className="flex flex-col items-center justify-center gap-1 text-xs py-1.5 px-2.5 rounded-xl bg-neutral-50 text-center">
                                      <span className="text-neutral-800 font-medium text-[11px] text-center">{d.name}</span>
                                      <div className="flex flex-wrap items-center justify-center gap-1.5">
                                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border shrink-0 ${previewBadgeClass}`}>{previewChannelLabel}</span>
                                        <span className="font-mono font-bold text-emerald-700 text-[11px] shrink-0">{d.price.toLocaleString()} {d.currency}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            <div className="space-y-1 text-xs text-neutral-600 pt-2 border-t border-neutral-100 text-center">
                              <div className="flex items-center justify-center gap-1.5"><Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" /> <span>{loc.phone}</span></div>
                              <div className="flex items-center justify-center gap-1.5"><Clock className="w-3.5 h-3.5 text-neutral-400 shrink-0" /> <span>{loc.operatingDays || 'Daily'} • {loc.openingTime || '10:00'} - {loc.closingTime || '22:00'}</span></div>
                              <div className="flex items-center justify-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" /> <span>{loc.address}</span></div>
                              {loc.allowsDelivery && (
                                <p className="text-[11px] font-mono font-semibold text-emerald-800 pt-0.5">
                                  Delivery Fee: {(loc.deliveryFeeRate ?? 0) > 0 ? `${loc.deliveryFeeRate} ${loc.deliveryFeeCurrency || 'AFNL'} per ${loc.deliveryFeeUnit || 'mile'}` : 'Free'}
                                </p>
                              )}
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleOpenStoreModal(loc)}
                            className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                          >
                            <UtensilsCrossed className="w-4 h-4 text-amber-400" />
                            <span>{loc.allowsDelivery ? 'View Menu & Order Online' : 'View Menu & Order Takeout'}</span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 1B. RETAIL STORES & PRODUCTS SUB-TAB */}
          {customerSubTab === 'retail' && (
            <div className="space-y-6">
              {/* Search Header for Retail Stores & Products */}
              <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
                <div className="flex flex-col items-center justify-center gap-3">
                  <h3 className="font-serif-lux text-base sm:text-lg font-bold text-neutral-900 flex items-center justify-center gap-2 whitespace-nowrap text-center">
                    <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600 shrink-0" />
                    <span>Retail Stores &amp; Online Inventories</span>
                  </h3>

                  <div className="relative w-full max-w-md mx-auto">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      placeholder="Search retail store or product..."
                      value={universalSearchQuery}
                      onChange={(e) => {
                        setUniversalSearchQuery(e.target.value);
                        if (explorerSectionView !== 'browse') setExplorerSectionView('browse');
                      }}
                      className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              </div>

              {/* Checkout, Online Orders & Delivery Address Tab Bar */}
              {renderSectionNavBar(true)}

              {explorerSectionView === 'checkout' && renderCustomerCheckoutSection('retail')}
              {explorerSectionView === 'online_orders' && renderCustomerOnlineOrdersSection('retail')}
              {explorerSectionView === 'delivery_address' && renderDeliveryAddressSection()}

              {/* Matched Products Section (Filtered strictly by In-Store View Only vs Online Inventory) */}
              {explorerSectionView === 'browse' && (() => {
                const isOnlineTab = explorerRetailChannelTab === 'online';
                const displayedProducts = isOnlineTab
                  ? universalSearchResults.matchedOnlineProducts
                  : universalSearchResults.matchedInStoreProducts;
                const otherTabCount = isOnlineTab
                  ? universalSearchResults.matchedInStoreProducts.length
                  : universalSearchResults.matchedOnlineProducts.length;
                if (displayedProducts.length === 0) {
                  return (
                    <div className="bg-white border border-neutral-200 rounded-2xl p-6 text-center space-y-2 max-w-xl mx-auto">
                      <p className="text-xs font-bold text-neutral-800">
                        {isOnlineTab ? 'No online inventory products found.' : 'No in-store inventory products found.'}
                      </p>
                      <p className="text-[11px] text-neutral-500">
                        {isOnlineTab
                          ? 'Switch to In-Store Inventory or adjust your search.'
                          : 'Switch to Online Inventory to browse items available for online delivery order.'}
                      </p>
                      {otherTabCount > 0 && (
                        <button
                          type="button"
                          onClick={() => setExplorerRetailChannelTab(isOnlineTab ? 'instore' : 'online')}
                          className="inline-flex items-center justify-center px-3.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 text-[11px] font-bold cursor-pointer"
                        >
                          {isOnlineTab
                            ? `View ${otherTabCount} matching product(s) in In-Store Inventory (View Only)`
                            : `View ${otherTabCount} matching product(s) in Online Inventory`}
                        </button>
                      )}
                    </div>
                  );
                }
                return (
                <div className="space-y-3">
                  <div className="flex flex-col items-center justify-center text-center gap-1">
                    <h4 className="text-xs font-bold text-neutral-900 uppercase font-mono tracking-wide flex items-center justify-center gap-1.5 text-center">
                      <ShoppingBag className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span>
                        {isOnlineTab
                          ? `Online Inventory Products Found (${displayedProducts.length}):`
                          : `In-Store Inventory Products — View Only (${displayedProducts.length}):`}
                      </span>
                    </h4>
                    <p className="text-[11px] text-neutral-500">
                      {isOnlineTab
                        ? 'Order online for delivery (delivery address required at checkout).'
                        : 'Displayed for in-store browsing only — customers cannot order from the in-store inventory online.'}
                    </p>
                    {universalSearchQuery && (
                      <button
                        type="button"
                        onClick={() => setUniversalSearchQuery('')}
                        className="text-[11px] text-indigo-700 hover:underline cursor-pointer"
                      >
                        Clear search
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {displayedProducts.map(({ product, location }) => {
                      const itemKey = `${location.id}-ret-${explorerRetailChannelTab}-${product.id}`;
                      const isExpanded = expandedExplorerItemKey === itemKey;
                      const inLocCartQty = getCustomerLocCart(location.id).find(i => i.item.id === product.id)?.quantity || 0;
                      const channelLabel = isOnlineTab ? 'Online Store' : 'In-Store (View Only)';
                      const badgeClass = isOnlineTab
                        ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                        : 'bg-neutral-100 text-neutral-700 border-neutral-200';
                      return (
                      <div
                        key={itemKey}
                        onClick={() => setExpandedExplorerItemKey(prev => prev === itemKey ? null : itemKey)}
                        className={`rounded-2xl bg-white border transition-all cursor-pointer ${
                          isExpanded
                            ? 'col-span-full p-5 sm:p-6 border-indigo-500 shadow-lg space-y-4 text-center'
                            : 'p-3.5 border-neutral-200 hover:border-indigo-400 hover:shadow-md flex items-center justify-between gap-3 group'
                        }`}
                      >
                        {!isExpanded ? (
                          <>
                            <div className="flex items-center gap-3 min-w-0 flex-1">
                              {product.image && (
                                <img
                                  src={product.image}
                                  alt=""
                                  onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                  className="w-14 h-14 rounded-xl object-cover shrink-0 bg-neutral-100"
                                />
                              )}
                              <div className="min-w-0 flex-1 space-y-0.5">
                                <span className={`inline-block text-[9px] font-bold px-2 py-0.5 rounded-md border font-mono ${badgeClass}`}>
                                  {channelLabel}
                                </span>
                                <p className="text-xs font-bold text-neutral-900 truncate">{product.name}</p>
                                <p className="text-xs font-mono font-bold text-emerald-700">{product.price.toLocaleString()} {product.currency}</p>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenStoreModal(location, isOnlineTab ? 'online' : 'instore');
                                  }}
                                  className="text-[10px] text-indigo-900 font-medium truncate hover:underline cursor-pointer block text-left max-w-full"
                                >
                                  Sold at: {location.name} • {product.stock ?? 20} in stock
                                </button>
                              </div>
                            </div>

                            {isOnlineTab ? (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  addItemToCustomerLocCart(location.id, product);
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-900 border border-indigo-300 text-[10px] font-bold cursor-pointer transition-colors shrink-0"
                              >
                                {inLocCartQty > 0 ? `+ Add (${inLocCartQty})` : '+ Order'}
                              </button>
                            ) : (
                              <span className="px-2.5 py-1 rounded-xl bg-neutral-100 text-neutral-600 border border-neutral-200 text-[10px] font-bold shrink-0">
                                View Only
                              </span>
                            )}
                          </>
                        ) : (
                          <div className="space-y-4 text-center">
                            <div className="flex flex-col items-center justify-center gap-2 border-b border-neutral-100 pb-3 text-center">
                              <div className="flex flex-wrap items-center justify-center gap-1.5">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border font-mono ${badgeClass}`}>{channelLabel}</span>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-700 font-mono">{product.category}</span>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-mono">
                                  {product.stock ?? 20} Units in Stock
                                </span>
                              </div>
                              <h4 className="font-serif-lux text-lg font-bold text-neutral-900 text-center">{product.name}</h4>
                              <p className="text-sm font-mono font-extrabold text-emerald-700 text-center">
                                {product.price.toLocaleString()} {product.currency} (Final Currency)
                              </p>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setExpandedExplorerItemKey(null);
                                }}
                                className="px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-bold cursor-pointer"
                              >
                                Collapse &times;
                              </button>
                            </div>

                            {/* Photos & Videos Gallery */}
                            {((product.photos && product.photos.length > 0) || product.image || (product.videos && product.videos.length > 0)) && (
                              <div className="flex flex-wrap items-center justify-center gap-3">
                                {(product.photos && product.photos.length > 0 ? product.photos : (product.image ? [product.image] : [])).map((photoUrl, idx) => (
                                  <img
                                    key={`exp-rp-${idx}`}
                                    src={photoUrl}
                                    alt=""
                                    onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                    className="w-36 h-28 sm:w-44 sm:h-32 rounded-2xl object-cover border border-neutral-200 bg-neutral-100"
                                  />
                                ))}
                                {product.videos?.map((vidUrl, idx) => (
                                  <video
                                    key={`exp-rv-${idx}`}
                                    src={vidUrl}
                                    controls
                                    onClick={(e) => e.stopPropagation()}
                                    className="w-52 h-32 rounded-2xl border border-neutral-200 bg-black object-cover"
                                  />
                                ))}
                              </div>
                            )}

                            {/* Full Detailed Description */}
                            <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/70 space-y-1 text-center">
                              <span className="text-[10px] font-bold text-neutral-500 uppercase font-mono block text-center">Full Product Specifications &amp; Details</span>
                              <p className="text-xs text-neutral-800 whitespace-pre-wrap leading-relaxed text-center max-w-2xl mx-auto">
                                {product.description || 'Verified retail inventory item settled directly in Final Currency.'}
                              </p>
                            </div>

                            {/* QR Codes if attached */}
                            {product.qrCodes && product.qrCodes.length > 0 && (
                              <div className="flex flex-wrap items-center justify-center gap-3">
                                {product.qrCodes.map((qr, qIdx) => (
                                  <div key={`exp-rqr-${qIdx}`} className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col items-center gap-2 text-center">
                                    <div className="p-1.5 bg-white rounded-xl border border-neutral-200 shrink-0">
                                      <QRCodeSVG value={qr.payload} size={56} level="M" />
                                    </div>
                                    <div className="text-center">
                                      <p className="text-[11px] font-bold text-neutral-900">
                                        {qr.type === 'one-time' ? '⚡ One-Time Invoice QR' : '📦 Inventory Catalog QR'}
                                      </p>
                                      <p className="text-[10px] font-mono text-neutral-500 break-all max-w-[240px]">{qr.payload}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Store Info & Action Row */}
                            <div className="flex flex-col items-center justify-center gap-3 pt-3 border-t border-neutral-100 text-center">
                              <div className="text-xs text-neutral-600 space-y-0.5 text-center">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenStoreModal(location, isOnlineTab ? 'online' : 'instore');
                                  }}
                                  className="font-bold text-neutral-900 hover:text-indigo-700 hover:underline cursor-pointer"
                                >
                                  Sold at: {location.name}
                                </button>
                                <p className="text-[11px]">{location.address} • {location.phone} • {location.email}</p>
                                {(location.deliveryFeeRate ?? 0) > 0 && (
                                  <p className="text-[11px] font-mono font-semibold text-indigo-700">
                                    Online Delivery Fee: {location.deliveryFeeRate} {location.deliveryFeeCurrency || product.currency} per {location.deliveryFeeUnit || 'mile'}
                                  </p>
                                )}
                              </div>
                              {isOnlineTab ? (
                                <div className="space-y-2 text-center">
                                  <p className="text-[11px] font-semibold text-indigo-800">
                                    Delivery Address Required at Checkout
                                  </p>
                                  <div className="flex flex-wrap items-center justify-center gap-2">
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        addItemToCustomerLocCart(location.id, product);
                                        setExplorerSectionView('checkout');
                                        if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' });
                                      }}
                                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                                    >
                                      + Add to Cart &amp; Checkout ({location.name})
                                    </button>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        addItemToCustomerLocCart(location.id, product);
                                      }}
                                      className="px-4 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-300 text-xs font-bold cursor-pointer"
                                    >
                                      {inLocCartQty > 0 ? `Added (${inLocCartQty} in cart)` : '+ Add Only'}
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="px-4 py-2 rounded-xl bg-neutral-100 border border-neutral-200 text-xs font-semibold text-neutral-700 text-center">
                                  In-Store Inventory Only (View Only) — Available for in-person viewing at {location.name}. Switch to Online Inventory to order for delivery.
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                      );
                    })}
                  </div>
                </div>
                );
              })()}

              {/* Retail Stores Directory */}
              {explorerSectionView === 'browse' && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-neutral-900 uppercase font-mono tracking-wide flex items-center justify-center gap-1.5 text-center">
                    <Store className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>Retail Stores Directory ({universalSearchResults.matchedLocations.length}):</span>
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {universalSearchResults.matchedLocations.map(loc => {
                      const storeRevs = reviewsList.filter(r => r.storeId === loc.id);
                      const avgRating = storeRevs.length > 0
                        ? (storeRevs.reduce((s, r) => s + r.rating, 0) / storeRevs.length).toFixed(1)
                        : '5.0';
                      const qLower = universalSearchQuery.toLowerCase().trim();
                      const isOnlineChannel = explorerRetailChannelTab === 'online';
                      const channelProducts = isOnlineChannel
                        ? (onlineRetailByLoc[loc.id] ?? getInitialOnlineRetailForLoc(loc.id))
                        : (retailInventoriesByLoc[loc.id] ?? getInitialRetailForLoc(loc.id));
                      const matchingChannelProducts = qLower
                        ? channelProducts.filter(p =>
                            p.name.toLowerCase().includes(qLower) ||
                            p.category.toLowerCase().includes(qLower) ||
                            (p.description && p.description.toLowerCase().includes(qLower))
                          )
                        : [];
                      const previewProducts = (matchingChannelProducts.length > 0 ? matchingChannelProducts : channelProducts).slice(0, 2);
                      const previewChannelLabel = isOnlineChannel ? 'Online Store' : 'In-Store (View Only)';
                      const previewBadgeClass = isOnlineChannel
                        ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                        : 'bg-neutral-100 text-neutral-700 border-neutral-200';

                      return (
                        <div
                          key={loc.id}
                          className="bg-white border border-neutral-200 rounded-3xl p-5 shadow-xs hover:border-indigo-500/50 hover:shadow-md transition-all flex flex-col justify-between space-y-4 text-center"
                        >
                          <div className="space-y-3 text-center">
                            <div className="flex flex-wrap items-center justify-center gap-2">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-900 font-mono">
                                {loc.cuisineOrCategory}
                              </span>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                                Verified Merchant
                              </span>
                            </div>

                            <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                              <h4
                                onClick={() => handleOpenStoreModal(loc, isOnlineChannel ? 'online' : 'instore')}
                                className="text-base font-bold text-neutral-900 font-serif-lux text-center cursor-pointer hover:text-indigo-700 hover:underline transition-colors"
                              >
                                {loc.name}
                              </h4>
                              <button
                                type="button"
                                onClick={() => handleOpenReviewsModal(loc)}
                                className="inline-flex items-center justify-center gap-1 text-xs font-bold text-amber-700 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 px-2.5 py-0.5 rounded-lg border border-amber-200 cursor-pointer"
                              >
                                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                                <span>{avgRating} ({storeRevs.length})</span>
                              </button>
                              <p className="text-xs text-neutral-500 mt-0.5 line-clamp-2 text-center">{loc.tagline}</p>
                            </div>

                            {/* Channel-separated retail preview */}
                            {previewProducts.length > 0 && (
                              <div className="pt-2 border-t border-neutral-100 space-y-1.5 text-center">
                                <p className="text-[10px] font-bold text-neutral-400 uppercase font-mono text-center">
                                  {isOnlineChannel ? 'Online Store Preview:' : 'In-Store Catalog Preview:'}
                                </p>
                                <div className="space-y-1">
                                  {previewProducts.map(p => (
                                    <div key={p.id} className="flex flex-col items-center justify-center gap-1 text-xs py-1.5 px-2.5 rounded-xl bg-neutral-50 text-center">
                                      <span className="text-neutral-800 font-medium text-[11px] text-center">{p.name}</span>
                                      <div className="flex flex-wrap items-center justify-center gap-1.5">
                                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border shrink-0 ${previewBadgeClass}`}>{previewChannelLabel}</span>
                                        <span className="font-mono font-bold text-emerald-700 text-[11px] shrink-0">{p.price.toLocaleString()} {p.currency}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            <div className="space-y-1 text-xs text-neutral-600 pt-2 border-t border-neutral-100 text-center">
                              <div className="flex items-center justify-center gap-1.5"><Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" /> <span>{loc.phone}</span></div>
                              <div className="flex items-center justify-center gap-1.5"><Mail className="w-3.5 h-3.5 text-neutral-400 shrink-0" /> <span>{loc.email}</span></div>
                              <div className="flex items-center justify-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" /> <span>{loc.address}</span></div>
                              {(loc.deliveryFeeRate ?? 0) > 0 && (
                                <p className="text-[11px] font-mono font-semibold text-indigo-800 pt-0.5">
                                  Delivery Fee: {loc.deliveryFeeRate} {loc.deliveryFeeCurrency || 'AFNL'} per {loc.deliveryFeeUnit || 'mile'}
                                </p>
                              )}
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleOpenStoreModal(loc)}
                            className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                          >
                            <ShoppingBag className="w-4 h-4 text-indigo-400" />
                            <span>Browse Store &amp; Online Menu</span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        );
      })()}

      {/* =========================================================
          DEDICATED STORE / RESTAURANT SEPARATE PAGE VIEW (NO POPUP)
          Shows only Online & In-Store Inventories or In-Restaurant & Online Menus,
          tailored search bar, category filters, and per-location cart checkout.
          ========================================================= */}
      {mainTab === 'directory' && viewingLocation && (() => {
        const pageTotals = computeLocCartTotals(viewingLocation);
        const isRestaurantPage = viewingLocation.type === 'restaurant';
        const onlineItems = isRestaurantPage
          ? (onlineMenusByLoc[viewingLocation.id] ?? getInitialOnlineMenuForLoc(viewingLocation.id))
          : (onlineRetailByLoc[viewingLocation.id] ?? getInitialOnlineRetailForLoc(viewingLocation.id));
        const inHouseItems = isRestaurantPage
          ? (restaurantMenusByLoc[viewingLocation.id] ?? getInitialRestaurantForLoc(viewingLocation.id))
          : (retailInventoriesByLoc[viewingLocation.id] ?? getInitialRetailForLoc(viewingLocation.id));
        const isOnlinePageTab = modalChannelTab === 'online';
        const activeChannelItems = isOnlinePageTab ? onlineItems : inHouseItems;
        const otherChannelItems = isOnlinePageTab ? inHouseItems : onlineItems;
        const channelLabel = isRestaurantPage
          ? (isOnlinePageTab ? 'Online Order Menu' : 'In-Restaurant Menu (View Only)')
          : (isOnlinePageTab ? 'Online Inventory' : 'In-Store Inventory (View Only)');
        const badgeClass = isOnlinePageTab
          ? (isRestaurantPage ? 'bg-amber-50 text-amber-800 border-amber-200' : 'bg-indigo-50 text-indigo-800 border-indigo-200')
          : 'bg-neutral-100 text-neutral-700 border-neutral-200';

        const qStore = storePageSearchQuery.toLowerCase().trim();
        const matchesStoreSearch = (it: CatalogItem) =>
          !qStore ||
          it.name.toLowerCase().includes(qStore) ||
          it.category.toLowerCase().includes(qStore) ||
          (it.description && it.description.toLowerCase().includes(qStore));

        const searchMatchedItems = activeChannelItems.filter(matchesStoreSearch);
        const otherTabMatchCount = qStore ? otherChannelItems.filter(matchesStoreSearch).length : 0;

        const categoryCounts = new Map<string, number>();
        searchMatchedItems.forEach(it => {
          const cat = (it.category || (isRestaurantPage ? 'Entrees' : 'General Retail')).trim();
          categoryCounts.set(cat, (categoryCounts.get(cat) || 0) + 1);
        });
        const uniqueCategories = Array.from(categoryCounts.keys());
        const effectiveCategory = storePageCategory !== 'All' && uniqueCategories.includes(storePageCategory)
          ? storePageCategory
          : 'All';

        const filteredPageItems = effectiveCategory === 'All'
          ? searchMatchedItems
          : searchMatchedItems.filter(it => (it.category || (isRestaurantPage ? 'Entrees' : 'General Retail')).trim() === effectiveCategory);

        const groupedByCategory: { category: string; items: CatalogItem[] }[] = [];
        if (effectiveCategory === 'All') {
          uniqueCategories.forEach(cat => {
            groupedByCategory.push({
              category: cat,
              items: filteredPageItems.filter(it => (it.category || (isRestaurantPage ? 'Entrees' : 'General Retail')).trim() === cat)
            });
          });
        } else {
          groupedByCategory.push({ category: effectiveCategory, items: filteredPageItems });
        }

        const storeRevs = reviewsList.filter(r => r.storeId === viewingLocation.id);
        const avgRating = storeRevs.length > 0
          ? (storeRevs.reduce((s, r) => s + r.rating, 0) / storeRevs.length).toFixed(1)
          : '5.0';
        const bagItemCount = takeoutBag.reduce((s, i) => s + i.quantity, 0);

        return (
          <div className="space-y-6 max-w-5xl mx-auto">
            {/* Top Navigation Bar with Back Button to Previous Page */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setViewingLocation(null)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white hover:bg-neutral-100 border border-neutral-200 text-xs font-bold text-neutral-900 cursor-pointer shadow-2xs transition-colors"
              >
                <ArrowLeft className="w-4 h-4 text-neutral-700" />
                <span>Back to {isRestaurantPage ? 'Restaurants' : 'Retail Stores'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenReviewsModal(viewingLocation)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-xs font-bold text-amber-800 cursor-pointer"
                >
                  <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  <span>{avgRating} ({storeRevs.length})</span>
                </button>
                {bagItemCount > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const el = document.getElementById('store-page-checkout-section');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>Cart ({bagItemCount})</span>
                  </button>
                )}
              </div>
            </div>

            {/* Store / Restaurant Identity Header Card */}
            <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-2.5 text-center">
              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md font-mono ${
                  isRestaurantPage ? 'bg-amber-50 text-amber-900' : 'bg-indigo-50 text-indigo-900'
                }`}>
                  {isRestaurantPage ? 'RESTAURANT' : 'RETAIL STORE'} • {viewingLocation.cuisineOrCategory}
                </span>
                {isRestaurantPage && (
                  <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${checkLocationOpenStatus(viewingLocation).badgeClass}`}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current" />
                    <span>{checkLocationOpenStatus(viewingLocation).statusText}</span>
                  </span>
                )}
              </div>
              <h2 className="font-serif-lux text-2xl sm:text-3xl font-bold text-neutral-900 text-center">
                {viewingLocation.name}
              </h2>
              {viewingLocation.tagline && (
                <p className="text-xs text-neutral-500 max-w-2xl mx-auto text-center">{viewingLocation.tagline}</p>
              )}
              <p className="text-xs text-neutral-600 text-center">
                {viewingLocation.address} • {viewingLocation.phone}{viewingLocation.email ? ` • ${viewingLocation.email}` : ''}
              </p>
              {isRestaurantPage && (
                <p className="text-[11px] font-medium text-amber-800 text-center">
                  Hours: {formatTime12h(viewingLocation.openingTime || '10:00')} – {formatTime12h(viewingLocation.closingTime || '22:00')} ({viewingLocation.operatingDays || 'Daily'})
                </p>
              )}
              {(viewingLocation.type === 'retail' || viewingLocation.allowsDelivery) && (viewingLocation.deliveryFeeRate ?? 0) > 0 && (
                <p className="text-[11px] font-mono font-semibold text-indigo-800 text-center">
                  Delivery Fee: {viewingLocation.deliveryFeeRate} {viewingLocation.deliveryFeeCurrency || pageTotals.locCurrency} per {viewingLocation.deliveryFeeUnit || 'mile'}
                </p>
              )}
            </div>

            {/* Channel Tabs + Store/Restaurant-Specific Search Bar + Category Navigation */}
            <div className="bg-white border border-neutral-200 rounded-3xl p-4 sm:p-6 shadow-xs space-y-4">
              {/* Two Separate Channel Tabs */}
              <div className="grid grid-cols-2 gap-1.5 p-1.5 bg-neutral-100 rounded-2xl max-w-xl mx-auto w-full">
                <button
                  type="button"
                  onClick={() => {
                    setModalChannelTab('instore');
                    setExpandedModalItemId(null);
                    setStorePageCategory('All');
                  }}
                  className={`min-w-0 w-full py-2 px-2 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center leading-tight overflow-hidden ${
                    modalChannelTab === 'instore'
                      ? 'bg-white text-neutral-900 shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <span className="truncate max-w-full">
                    {isRestaurantPage ? 'In-Restaurant Menu' : 'In-Store Inventory'}
                  </span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-200/80 text-neutral-700 shrink-0 whitespace-nowrap">
                    View Only
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setModalChannelTab('online');
                    setExpandedModalItemId(null);
                    setStorePageCategory('All');
                  }}
                  className={`min-w-0 w-full py-2 px-2 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center leading-tight overflow-hidden ${
                    modalChannelTab === 'online'
                      ? (isRestaurantPage ? 'bg-amber-600 text-white shadow-xs' : 'bg-indigo-600 text-white shadow-xs')
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <span className="truncate max-w-full">
                    {isRestaurantPage ? 'Online Order Menu' : 'Online Inventory'}
                  </span>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded shrink-0 whitespace-nowrap ${
                    modalChannelTab === 'online'
                      ? 'bg-white/20 text-white'
                      : (isRestaurantPage ? 'bg-amber-100 text-amber-900' : 'bg-indigo-100 text-indigo-800')
                  }`}>
                    {onlineItems.length}
                  </span>
                </button>
              </div>

              <p className="text-[11px] font-semibold text-neutral-600 text-center">
                {isOnlinePageTab
                  ? (isRestaurantPage
                      ? (viewingLocation.allowsDelivery
                          ? 'Orderable Online Menu (Takeout Pickup or Delivery with address) • Click any item for full details'
                          : 'Orderable Online Takeout Menu (Pickup in Person) • Click any item for full details')
                      : 'Orderable Online Inventory (Delivery address required at checkout) • Click any item for full details')
                  : (isRestaurantPage
                      ? 'In-Restaurant Menu (View Only — Display only, cannot be ordered online)'
                      : 'In-Store Inventory (View Only — Display only, cannot be ordered online)')}
              </p>

              {/* Tailored Search Bar specifically for THIS Store / Restaurant */}
              <div className="relative max-w-lg mx-auto w-full">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                <input
                  type="text"
                  placeholder={
                    isRestaurantPage
                      ? `Search ${viewingLocation.name} dishes, categories, or ingredients...`
                      : `Search ${viewingLocation.name} products, categories, or details...`
                  }
                  value={storePageSearchQuery}
                  onChange={(e) => setStorePageSearchQuery(e.target.value)}
                  className={`w-full pl-10 pr-9 py-2.5 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none ${
                    isRestaurantPage ? 'focus:border-amber-500' : 'focus:border-indigo-500'
                  }`}
                />
                {storePageSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setStorePageSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-400 hover:text-neutral-700 cursor-pointer"
                    aria-label="Clear store search"
                  >
                    &times;
                  </button>
                )}
              </div>

              {/* Category Filter Pills for Easy Navigation */}
              {uniqueCategories.length > 0 && (
                <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => setStorePageCategory('All')}
                    className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer ${
                      effectiveCategory === 'All'
                        ? (isRestaurantPage ? 'bg-amber-600 text-white border-amber-600 shadow-2xs' : 'bg-indigo-600 text-white border-indigo-600 shadow-2xs')
                        : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-700 border-neutral-200'
                    }`}
                  >
                    All Categories ({searchMatchedItems.length})
                  </button>
                  {uniqueCategories.map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setStorePageCategory(cat)}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer ${
                        effectiveCategory === cat
                          ? (isRestaurantPage ? 'bg-amber-600 text-white border-amber-600 shadow-2xs' : 'bg-indigo-600 text-white border-indigo-600 shadow-2xs')
                          : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-700 border-neutral-200'
                      }`}
                    >
                      {cat} ({categoryCounts.get(cat) || 0})
                    </button>
                  ))}
                </div>
              )}

              {/* Cross-channel match indicator if search finds items on the other tab of this store/restaurant */}
              {qStore && otherTabMatchCount > 0 && (
                <div className="flex justify-center">
                  <button
                    type="button"
                    onClick={() => {
                      setModalChannelTab(isOnlinePageTab ? 'instore' : 'online');
                      setStorePageCategory('All');
                    }}
                    className={`px-3.5 py-1.5 rounded-xl text-[11px] font-bold border cursor-pointer ${
                      isRestaurantPage
                        ? 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-200'
                        : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-200'
                    }`}
                  >
                    {isOnlinePageTab
                      ? `Also found ${otherTabMatchCount} match(es) in ${isRestaurantPage ? 'In-Restaurant Menu (View Only)' : 'In-Store Inventory (View Only)'}`
                      : `Also found ${otherTabMatchCount} match(es) in ${isRestaurantPage ? 'Online Order Menu' : 'Online Inventory'}`}
                  </button>
                </div>
              )}

              {/* Categorized Items List */}
              <div className="space-y-6 pt-2">
                {filteredPageItems.length === 0 ? (
                  <div className="py-10 px-4 bg-neutral-50 rounded-2xl border border-neutral-200/70 text-center space-y-2">
                    <p className="text-xs font-bold text-neutral-700">
                      {qStore
                        ? `No matching ${isRestaurantPage ? 'dishes' : 'products'} found in ${viewingLocation.name}'s ${channelLabel}.`
                        : `No ${isRestaurantPage ? 'dishes' : 'products'} added to ${channelLabel} yet.`}
                    </p>
                    {qStore && (
                      <button
                        type="button"
                        onClick={() => {
                          setStorePageSearchQuery('');
                          setStorePageCategory('All');
                        }}
                        className="text-xs font-bold text-indigo-700 hover:underline cursor-pointer"
                      >
                        Reset search &amp; filters
                      </button>
                    )}
                  </div>
                ) : (
                  groupedByCategory.map(group => (
                    <div key={group.category} className="space-y-3">
                      <div className="flex items-center justify-center gap-2 pb-1.5 border-b border-neutral-100">
                        <span className={`text-xs font-bold uppercase font-mono tracking-wide ${
                          isRestaurantPage ? 'text-amber-900' : 'text-indigo-900'
                        }`}>
                          {group.category}
                        </span>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-700">
                          {group.items.length}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                        {group.items.map(item => {
                          const isExpanded = expandedModalItemId === `${modalChannelTab}-${item.id}`;
                          const inBagItem = takeoutBag.find(b => b.item.id === item.id);
                          return (
                            <div
                              key={`${modalChannelTab}-${item.id}`}
                              onClick={() => setExpandedModalItemId(prev => prev === `${modalChannelTab}-${item.id}` ? null : `${modalChannelTab}-${item.id}`)}
                              className={`rounded-2xl border transition-all cursor-pointer text-center ${
                                isExpanded
                                  ? 'md:col-span-2 p-5 bg-white border-emerald-500 shadow-md space-y-3.5'
                                  : 'p-4 bg-neutral-50 border-neutral-200/80 hover:border-neutral-300 flex flex-col items-center justify-between gap-3'
                              }`}
                            >
                              {!isExpanded ? (
                                <>
                                  <div className="flex flex-col items-center justify-center gap-2.5 text-center w-full">
                                    {item.image && (
                                      <img
                                        src={item.image}
                                        alt=""
                                        onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                        className="w-20 h-20 rounded-xl object-cover shrink-0 bg-neutral-200"
                                      />
                                    )}
                                    <div className="space-y-1 text-center w-full">
                                      <div className="flex flex-wrap items-center justify-center gap-1.5">
                                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md border font-mono ${badgeClass}`}>
                                          {channelLabel}
                                        </span>
                                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-200/80 text-neutral-700 font-mono">
                                          {item.category}
                                        </span>
                                      </div>
                                      <p className="text-sm font-bold text-neutral-900 break-words text-center">{item.name}</p>
                                      {item.description && (
                                        <p className="text-[11px] text-neutral-500 line-clamp-2 max-w-md mx-auto text-center">{item.description}</p>
                                      )}
                                      <p className="text-xs font-mono font-bold text-emerald-700 pt-0.5 text-center">
                                        {item.price.toLocaleString()} {item.currency}
                                        {getItemAcceptedCurrencies(item).length > 1
                                          ? ` • Accepts: ${getItemAcceptedCurrencies(item).join(', ')}`
                                          : ' (Final Currency)'}
                                      </p>
                                    </div>
                                  </div>

                                  <div className="flex items-center justify-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                                    {!isOnlinePageTab ? (
                                      <span className="px-3 py-1 rounded-xl bg-neutral-200/70 text-neutral-600 border border-neutral-300 text-[10px] font-bold shrink-0">
                                        View Only
                                      </span>
                                    ) : inBagItem ? (
                                      <div className="flex items-center gap-1.5 bg-white border border-emerald-300 rounded-xl px-2 py-1">
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setTakeoutBag(prev =>
                                              prev
                                                .map(i => i.item.id === item.id ? { ...i, quantity: i.quantity - 1 } : i)
                                                .filter(i => i.quantity > 0)
                                            );
                                          }}
                                          className="w-6 h-6 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-xs font-bold cursor-pointer"
                                        >
                                          -
                                        </button>
                                        <span className="text-xs font-mono font-bold w-5 text-center">{inBagItem.quantity}</span>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setTakeoutBag(prev =>
                                              prev.map(i => i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)
                                            );
                                          }}
                                          className="w-6 h-6 rounded-lg bg-emerald-600 text-white text-xs font-bold cursor-pointer"
                                        >
                                          +
                                        </button>
                                      </div>
                                    ) : (
                                      <button
                                        type="button"
                                        onClick={() => setTakeoutBag(prev => [...prev, { item, quantity: 1 }])}
                                        className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer shrink-0"
                                      >
                                        + Add
                                      </button>
                                    )}
                                  </div>
                                </>
                              ) : (
                                <div className="space-y-3.5 text-center">
                                  <div className="flex flex-col items-center justify-center gap-2 border-b border-neutral-100 pb-3 text-center">
                                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md border font-mono ${badgeClass}`}>{channelLabel}</span>
                                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-700 font-mono">{item.category}</span>
                                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-mono">
                                        {item.stock !== undefined ? `${item.stock} available` : 'Available'}
                                      </span>
                                    </div>
                                    <h5 className="text-base font-bold text-neutral-900 font-serif-lux text-center">{item.name}</h5>
                                    <p className="text-sm font-mono font-extrabold text-emerald-700 text-center">
                                      {item.price.toLocaleString()} {item.currency}
                                      {getItemAcceptedCurrencies(item).length > 1
                                        ? ` • Accepts: ${getItemAcceptedCurrencies(item).join(', ')}`
                                        : ' (Final Currency)'}
                                    </p>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setExpandedModalItemId(null);
                                      }}
                                      className="px-3 py-1 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-[11px] font-bold cursor-pointer shrink-0"
                                    >
                                      Collapse &times;
                                    </button>
                                  </div>

                                  {((item.photos && item.photos.length > 0) || item.image || (item.videos && item.videos.length > 0)) && (
                                    <div className="flex flex-wrap items-center justify-center gap-2.5">
                                      {(item.photos && item.photos.length > 0 ? item.photos : (item.image ? [item.image] : [])).map((photoUrl, idx) => (
                                        <img
                                          key={`pg-p-${idx}`}
                                          src={photoUrl}
                                          alt=""
                                          onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                          className="w-32 h-24 rounded-xl object-cover border border-neutral-200 bg-neutral-100"
                                        />
                                      ))}
                                      {item.videos?.map((vidUrl, idx) => (
                                        <video
                                          key={`pg-v-${idx}`}
                                          src={vidUrl}
                                          controls
                                          onClick={(e) => e.stopPropagation()}
                                          className="w-44 h-24 rounded-xl border border-neutral-200 bg-black object-cover"
                                        />
                                      ))}
                                    </div>
                                  )}

                                  <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200/70 space-y-1 text-center">
                                    <span className="text-[10px] font-bold text-neutral-500 uppercase font-mono block text-center">
                                      {isRestaurantPage ? 'Dish Details & Ingredients' : 'Full Product Specifications'}
                                    </span>
                                    <p className="text-xs text-neutral-800 whitespace-pre-wrap leading-relaxed text-center max-w-lg mx-auto">
                                      {item.description || 'Verified item available for instant settlement in Final Currency.'}
                                    </p>
                                  </div>

                                  {item.qrCodes && item.qrCodes.length > 0 && (
                                    <div className="flex flex-wrap items-center justify-center gap-2.5">
                                      {item.qrCodes.map((qr, qIdx) => (
                                        <div key={`pg-qr-${qIdx}`} className="p-2.5 rounded-xl bg-neutral-50 border border-neutral-200 flex flex-col items-center gap-1.5 text-center">
                                          <div className="p-1 bg-white rounded-lg border border-neutral-200 shrink-0">
                                            <QRCodeSVG value={qr.payload} size={48} level="M" />
                                          </div>
                                          <div className="text-center">
                                            <p className="text-[10px] font-bold text-neutral-900">
                                              {qr.type === 'one-time' ? '⚡ One-Time Invoice QR' : '📦 Inventory Tag QR'}
                                            </p>
                                            <p className="text-[9px] font-mono text-neutral-500 break-all max-w-[180px]">{qr.payload}</p>
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  )}

                                  <div className="flex flex-col items-center justify-center gap-2 pt-2 border-t border-neutral-100 text-center" onClick={(e) => e.stopPropagation()}>
                                    <span className="text-[11px] text-neutral-500 text-center">
                                      Fulfilled by <span className="font-bold text-neutral-800">{viewingLocation.name}</span>
                                    </span>
                                    {isOnlinePageTab ? (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setTakeoutBag(prev => {
                                            const existing = prev.find(i => i.item.id === item.id);
                                            if (existing) {
                                              return prev.map(i => i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
                                            }
                                            return [...prev, { item, quantity: 1 }];
                                          });
                                        }}
                                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer"
                                      >
                                        + Add to Cart {inBagItem ? `(${inBagItem.quantity} in cart)` : ''}
                                      </button>
                                    ) : (
                                      <span className="px-3 py-1.5 rounded-xl bg-neutral-100 border border-neutral-200 text-[11px] font-semibold text-neutral-600">
                                        {isRestaurantPage ? 'In-Restaurant Menu Only (View Only)' : 'In-Store Inventory Only (View Only)'}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Store / Restaurant Cart & Checkout Card (Shown when items from Online Inventory / Menu are in cart) */}
            {takeoutBag.length > 0 && (
              <div id="store-page-checkout-section" className="p-5 sm:p-6 rounded-3xl bg-amber-50/70 border border-amber-200/80 space-y-4 text-center shadow-xs">
                <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                  <h4 className="text-xs font-bold text-amber-950 uppercase font-mono text-center">
                    {viewingLocation.type === 'retail' ? `Cart — ${viewingLocation.name}` : `Order — ${viewingLocation.name}`} ({bagItemCount} items)
                  </h4>
                  <button
                    type="button"
                    onClick={() => setTakeoutBag([])}
                    className="text-[10px] font-bold text-rose-700 hover:underline cursor-pointer"
                  >
                    Clear Cart
                  </button>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto px-1 max-w-xl mx-auto">
                  {takeoutBag.map(({ item, quantity }) => (
                    <div key={item.id} className="flex flex-col items-center justify-center gap-1.5 text-xs bg-white/90 px-3 py-2 rounded-xl border border-amber-200/50 text-center">
                      <span className="font-semibold text-neutral-900 text-center">{item.name}</span>
                      <div className="flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setTakeoutBag(prev =>
                              prev
                                .map(i => i.item.id === item.id ? { ...i, quantity: i.quantity - 1 } : i)
                                .filter(i => i.quantity > 0)
                            );
                          }}
                          className="w-6 h-6 rounded-lg bg-neutral-100 hover:bg-neutral-200 font-bold text-xs cursor-pointer"
                        >
                          -
                        </button>
                        <span className="font-mono font-bold w-5 text-center">{quantity}</span>
                        <button
                          type="button"
                          onClick={() => {
                            setTakeoutBag(prev =>
                              prev.map(i => i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)
                            );
                          }}
                          className="w-6 h-6 rounded-lg bg-neutral-100 hover:bg-neutral-200 font-bold text-xs cursor-pointer"
                        >
                          +
                        </button>
                        <span className="font-mono font-bold text-emerald-700 ml-1">
                          {(item.price * quantity).toLocaleString()} {item.currency}
                        </span>
                        <button
                          type="button"
                          onClick={() => setTakeoutBag(prev => prev.filter(i => i.item.id !== item.id))}
                          className="text-neutral-400 hover:text-rose-600 p-0.5 cursor-pointer"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-amber-200/60 space-y-3 text-center max-w-xl mx-auto">
                  {renderLocationFulfillmentControls(viewingLocation, pageTotals, true)}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-amber-200/60 text-center">
                    <div className="space-y-1 text-center">
                      <label className="text-[10px] font-bold text-amber-950 uppercase block text-center">
                        {viewingLocation.type === 'retail' ? 'Optional Tip (Final Coins)' : 'Custom Tip (Final Coins)'}
                      </label>
                      {viewingLocation.type === 'restaurant' && (
                        <div className="flex items-center justify-center gap-1 pb-1">
                          {[0, 15, 18, 20].map(pct => (
                            <button
                              key={pct}
                              type="button"
                              onClick={() => {
                                setTakeoutTipPercentage(pct);
                                setTakeoutCustomTip('');
                              }}
                              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold cursor-pointer ${
                                takeoutTipPercentage === pct && takeoutCustomTip === '' ? 'bg-amber-600 text-white' : 'bg-white text-neutral-700 border border-amber-200'
                              }`}
                            >
                              {pct}%
                            </button>
                          ))}
                        </div>
                      )}
                      <input
                        type="number"
                        min={0}
                        step="any"
                        placeholder={viewingLocation.type === 'retail' ? '0.00 (Optional)' : `Auto (${takeoutTipPercentage}%)`}
                        value={takeoutCustomTip}
                        onChange={(e) => setTakeoutCustomTip(e.target.value)}
                        className="w-full px-3 py-1.5 rounded-xl bg-white border border-amber-200 text-xs font-mono font-bold text-center"
                      />
                    </div>
                    <div className="space-y-1.5 text-center">
                      <label className="text-[10px] font-bold text-amber-950 uppercase block text-center">
                        Settlement Final Currency ({viewingLocation.name})
                      </label>
                      {(() => {
                        const relevantCoins = getCustomerRelevantCurrenciesForLoc(viewingLocation);
                        return (
                          <div className="flex flex-wrap items-center justify-center gap-1.5">
                            {relevantCoins.map(coin => (
                              <button
                                key={`pg-cur-${coin.symbol}`}
                                type="button"
                                onClick={() => setTakeoutPaymentCurrency(coin.symbol)}
                                className={`px-2.5 py-1.5 rounded-xl text-[11px] font-mono font-bold border flex items-center gap-1 cursor-pointer transition-all ${
                                  takeoutPaymentCurrency === coin.symbol
                                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                                    : 'bg-white hover:bg-neutral-50 text-neutral-800 border-amber-200'
                                }`}
                              >
                                <span>{coin.icon}</span>
                                <span>{coin.symbol}</span>
                              </button>
                            ))}
                          </div>
                        );
                      })()}
                    </div>
                  </div>

                  <div className="space-y-1 pt-2 border-t border-amber-200 text-xs text-center">
                    <div className="flex items-center justify-center gap-2 text-neutral-700">
                      <span>Subtotal:</span>
                      <span className="font-mono font-bold">{pageTotals.sub.toLocaleString()} {takeoutPaymentCurrency}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2 text-neutral-700">
                      <span>Commerce Tax (5%):</span>
                      <span className="font-mono font-bold">{pageTotals.locTax.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {takeoutPaymentCurrency}</span>
                    </div>
                    {pageTotals.isDelivery && (
                      <div className="flex items-center justify-center gap-2 text-neutral-700">
                        <span>Delivery Fee ({pageTotals.distance} {pageTotals.feeUnit === 'km' ? 'km' : 'mi'} &times; {pageTotals.feeRate} {pageTotals.feeCurrency}/{pageTotals.feeUnit}):</span>
                        <span className="font-mono font-bold text-indigo-800">
                          {pageTotals.deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {pageTotals.feeCurrency}
                        </span>
                      </div>
                    )}
                    {pageTotals.locTip > 0 && (
                      <div className="flex items-center justify-center gap-2 text-neutral-700">
                        <span>Tip:</span>
                        <span className="font-mono font-bold">{pageTotals.locTip.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {takeoutPaymentCurrency}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-center gap-2 pt-1.5 border-t border-amber-200/80 text-sm font-extrabold font-mono">
                      <span>Total Due:</span>
                      <span className="text-emerald-700">
                        {pageTotals.locTotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {takeoutPaymentCurrency}
                        {pageTotals.isDelivery && pageTotals.deliveryFee > 0 && !pageTotals.deliveryFeeMatchesCurrency
                          ? ` + ${pageTotals.deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${pageTotals.feeCurrency}`
                          : ''}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handlePlaceTakeoutOrder(viewingLocation)}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-sm"
                  >
                    {viewingLocation.type === 'retail' ? 'Store Checkout' : 'Restaurant Checkout'} — {viewingLocation.name} ({pageTotals.locTotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {takeoutPaymentCurrency}
                    {pageTotals.isDelivery && pageTotals.deliveryFee > 0 && !pageTotals.deliveryFeeMatchesCurrency
                      ? ` + ${pageTotals.deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ${pageTotals.feeCurrency}`
                      : ''})
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* =========================================================
          TAB 2: RETAIL STORE MANAGEMENT
          ========================================================= */}
      {mainTab === 'retail' && (
        <div className="space-y-6">
          {/* Sub-view: Checkout */}
          {retailSubTab === 'checkout' && renderMerchantCheckoutOrdersAndTerminal('retail')}

          {/* Sub-view: Add Item to Retail Inventory / Online Store */}
          {retailSubTab === 'add_item' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-xs max-w-3xl mx-auto space-y-6 text-center">
              <div className="pb-4 border-b border-neutral-100 flex flex-col items-center justify-center text-center space-y-2">
                <h3 className="font-serif-lux text-lg sm:text-xl font-bold text-neutral-900 text-center">Add Item to Retail Inventory</h3>
                <div className="flex items-center justify-center gap-2 text-xs font-mono font-bold text-neutral-700">
                  <span className="px-2.5 py-1 bg-neutral-100 rounded-lg">In-Store: {retailCatalog.length} items</span>
                  <span className="text-neutral-300">•</span>
                  <span className="px-2.5 py-1 bg-indigo-50 text-indigo-800 rounded-lg">Online Store: {onlineRetailCatalog.length} items</span>
                </div>
              </div>

              <form onSubmit={handleAddNewInventoryItem} className="space-y-4 max-w-xl mx-auto flex flex-col items-center text-center">
                <div className="w-full p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-200/80 space-y-2 text-center">
                  <span className="text-xs font-bold text-indigo-950 font-mono uppercase">Publish Destination ({activeLocation.name})</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left">
                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-indigo-200 cursor-pointer">
                      <input type="checkbox" checked={newItemIncludeInStore} onChange={(e) => setNewItemIncludeInStore(e.target.checked)} className="w-4 h-4 accent-indigo-600" />
                      <span className="text-xs font-bold text-neutral-900">Retail Store Inventory</span>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-indigo-200 cursor-pointer">
                      <input type="checkbox" checked={newItemIncludeOnline} onChange={(e) => setNewItemIncludeOnline(e.target.checked)} className="w-4 h-4 accent-indigo-600" />
                      <span className="text-xs font-bold text-neutral-900">Retail Online Store</span>
                    </label>
                  </div>
                </div>

                <div className="w-full space-y-1 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Item Title / Name *</label>
                  <input
                    type="text"
                    placeholder="e.g. Gold Bullion, Hardware Wallet"
                    value={newItemTitle}
                    onChange={(e) => setNewItemTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 text-center"
                    required
                  />
                </div>

                <div className="w-full space-y-2 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Category (Pick or Type Custom)</label>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {Array.from(new Set([...RETAIL_CATEGORY_PRESETS, ...retailCatalog.map(i => i.category), ...onlineRetailCatalog.map(i => i.category)].filter(Boolean))).map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setNewItemType(cat)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                          newItemType.trim().toLowerCase() === cat.toLowerCase()
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-neutral-50 hover:bg-indigo-50 text-neutral-700 border-neutral-200'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    placeholder="e.g. Bullion & Metals, Electronics, Apparel"
                    value={newItemType}
                    onChange={(e) => setNewItemType(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 text-center"
                  />
                </div>

                <div className="w-full space-y-2 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Cost / Price *</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    min={0}
                    step="any"
                    value={newItemCost}
                    onChange={(e) => setNewItemCost(e.target.value)}
                    className="w-48 mx-auto px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center"
                    required
                  />
                  {renderMultiCurrencySelector(
                    newItemCurrencies,
                    (sym) => setNewItemCurrencies(prev => toggleCurrencyInList(prev, sym, 5)),
                    'inventory_add',
                    'indigo'
                  )}
                </div>

                <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
                  <div className="space-y-1 text-center">
                    <label className="text-xs font-bold text-neutral-700 block text-center">Stock / Units Available</label>
                    <input
                      type="number"
                      placeholder="25"
                      min={0}
                      value={newItemStock}
                      onChange={(e) => setNewItemStock(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 font-mono text-center"
                    />
                  </div>
                  <div className="space-y-1 text-center">
                    <label className="text-xs font-bold text-neutral-700 block text-center">Barcode / UPC / EAN (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. 7612345000099"
                      value={newItemBarcode}
                      onChange={(e) => setNewItemBarcode(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 font-mono text-center"
                    />
                  </div>
                </div>

                <div className="w-full space-y-1 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Detailed Description / Specifications</label>
                  <textarea
                    placeholder="Write a comprehensive description of item specifications, materials, serial authenticity, dimensions, provenance, warranty, or included accessories..."
                    value={newItemDescription}
                    onChange={(e) => setNewItemDescription(e.target.value)}
                    rows={4}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                  />
                </div>

                {/* Upload Photos & Videos */}
                <div className="w-full p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3 text-center">
                  <div className="flex flex-col items-center justify-center">
                    <span className="text-xs font-bold text-neutral-900 flex items-center gap-1.5 font-mono uppercase">
                      <ImageIcon className="w-4 h-4 text-indigo-600" />
                      <span>Upload Photos &amp; Videos ({newItemPhotos.length + newItemVideos.length})</span>
                    </span>
                    <span className="text-[11px] text-neutral-500">Shown in both in-store POS and online retail store</span>
                  </div>

                  <input
                    ref={inventoryFileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      handleReadMediaFiles(
                        e.target.files,
                        (url) => setNewItemPhotos(prev => [...prev, url]),
                        (url) => setNewItemVideos(prev => [...prev, url])
                      );
                      e.target.value = '';
                    }}
                  />

                  <div className="flex flex-col sm:flex-row items-center gap-2">
                    <button
                      type="button"
                      onClick={() => inventoryFileInputRef.current?.click()}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Upload className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Browse Photo / Video</span>
                    </button>
                    <div className="flex items-center gap-1.5 w-full">
                      <input
                        type="url"
                        placeholder="Or paste photo/video URL..."
                        value={newItemMediaUrlInput}
                        onChange={(e) => setNewItemMediaUrlInput(e.target.value)}
                        className="flex-1 px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs min-w-0"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const url = newItemMediaUrlInput.trim();
                          if (!url) return;
                          if (/\.(mp4|webm|mov|ogg)(\?|$)/i.test(url)) {
                            setNewItemVideos(prev => [...prev, url]);
                          } else {
                            setNewItemPhotos(prev => [...prev, url]);
                          }
                          setNewItemMediaUrlInput('');
                        }}
                        className="px-3 py-2 rounded-xl bg-neutral-900 text-white text-xs font-bold cursor-pointer shrink-0"
                      >
                        Attach
                      </button>
                    </div>
                  </div>

                  {(newItemPhotos.length > 0 || newItemVideos.length > 0) && (
                    <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                      {newItemPhotos.map((p, idx) => (
                        <div key={`np-${idx}`} className="relative w-14 h-14 rounded-xl overflow-hidden border border-neutral-300 bg-white">
                          <img src={p} alt="" className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => setNewItemPhotos(prev => prev.filter((_, i) => i !== idx))}
                            className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/70 text-white text-[10px] flex items-center justify-center cursor-pointer"
                          >
                            &times;
                          </button>
                        </div>
                      ))}
                      {newItemVideos.map((_, idx) => (
                        <div key={`nv-${idx}`} className="relative px-2.5 py-1.5 rounded-xl bg-indigo-100 text-indigo-900 text-[10px] font-bold flex items-center gap-1">
                          <Video className="w-3 h-3" />
                          <span>Video {idx + 1}</span>
                          <button
                            type="button"
                            onClick={() => setNewItemVideos(prev => prev.filter((_, i) => i !== idx))}
                            className="ml-1 text-rose-600 cursor-pointer"
                          >
                            &times;
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="w-full p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-2.5 text-center">
                  <div className="flex flex-col items-center justify-center">
                    <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5 font-mono uppercase">
                      <QrCode className="w-4 h-4 text-amber-700" />
                      <span>Attach QR Codes (Max 1 of each, 2 Total)</span>
                    </span>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded mt-0.5">Strict Limit: 2 Total</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-left">
                    <label className="flex items-start gap-2 p-3 rounded-xl bg-white border border-amber-200 cursor-pointer">
                      <input type="checkbox" checked={newItemAddOneTimeQR} onChange={(e) => setNewItemAddOneTimeQR(e.target.checked)} className="mt-0.5 w-4 h-4 accent-amber-600" />
                      <div><span className="text-xs font-bold text-amber-950 block">⚡ One-Time QR Code</span><span className="text-[11px] text-amber-800">Generate a unique single-use invoice QR for instant settlement.</span></div>
                    </label>
                    <label className="flex items-start gap-2 p-3 rounded-xl bg-white border border-indigo-200 cursor-pointer">
                      <input type="checkbox" checked={newItemAddInventoryQR} onChange={(e) => setNewItemAddInventoryQR(e.target.checked)} className="mt-0.5 w-4 h-4 accent-indigo-600" />
                      <div><span className="text-xs font-bold text-indigo-950 block">📦 Inventory List QR Code</span><span className="text-[11px] text-indigo-800">Generate a permanent catalog inventory tag QR code.</span></div>
                    </label>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full max-w-md py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-sm flex items-center justify-center gap-2 mx-auto"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Save Item to Retail Store</span>
                </button>
              </form>
            </div>
          )}

          {/* Sub-view: Retail Store Inventory Directory */}
          {retailSubTab === 'inventory_dir' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-8 shadow-xs max-w-4xl mx-auto space-y-6 text-center">
              <div className="pb-4 border-b border-neutral-100 flex flex-col items-center justify-center text-center space-y-2">
                <h3 className="font-serif-lux text-lg sm:text-xl font-bold text-neutral-900 text-center">
                  {activeLocation.name} — In-Store Inventory
                </h3>
                <span className="text-xs font-mono font-bold px-3 py-1 bg-neutral-100 text-neutral-800 rounded-xl">{retailCatalog.length} Total Items</span>
              </div>

              {(() => {
                const qM = merchantCatalogSearch.toLowerCase().trim();
                const cats = Array.from(new Set(retailCatalog.map(i => (i.category || 'General Retail').trim())));
                const effCat = merchantCatalogCategory !== 'All' && cats.includes(merchantCatalogCategory) ? merchantCatalogCategory : 'All';
                const filteredMerchantRetail = retailCatalog.filter(it => {
                  const matchesCat = effCat === 'All' || (it.category || 'General Retail').trim() === effCat;
                  const matchesQ = !qM || it.name.toLowerCase().includes(qM) || it.category.toLowerCase().includes(qM) || (it.description && it.description.toLowerCase().includes(qM));
                  return matchesCat && matchesQ;
                });
                return (
                <div className="space-y-4">
                  <div className="relative max-w-md mx-auto">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      placeholder={`Search ${activeLocation.name} in-store inventory...`}
                      value={merchantCatalogSearch}
                      onChange={(e) => setMerchantCatalogSearch(e.target.value)}
                      className="w-full pl-10 pr-8 py-2 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-indigo-500"
                    />
                  </div>
                  {cats.length > 0 && (
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setMerchantCatalogCategory('All')}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                          effCat === 'All' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                        }`}
                      >
                        All ({retailCatalog.length})
                      </button>
                      {cats.map(cat => (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setMerchantCatalogCategory(cat)}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                            effCat === cat ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                          }`}
                        >
                          {cat} ({retailCatalog.filter(i => (i.category || 'General Retail').trim() === cat).length})
                        </button>
                      ))}
                    </div>
                  )}

              <div className="space-y-3 text-left">
                {filteredMerchantRetail.length === 0 ? (
                  <p className="text-xs text-neutral-500 text-center py-6">
                    {retailCatalog.length === 0 ? `No items in ${activeLocation.name}'s in-store inventory yet.` : 'No matching items in this category/search.'}
                  </p>
                ) : filteredMerchantRetail.map(item => {
                  const ch = getRetailChannelInfo(activeLocationId, item.id);
                  const mKey = `ret-in-${item.id}`;
                  const isExp = expandedMerchantItemId === mKey;
                  return (
                  <div
                    key={item.id}
                    onClick={() => setExpandedMerchantItemId(prev => prev === mKey ? null : mKey)}
                    className={`p-3.5 sm:p-4 rounded-2xl border transition-all cursor-pointer overflow-hidden space-y-3 ${
                      isExp ? 'bg-white border-indigo-400 shadow-sm' : 'bg-neutral-50 border-neutral-200/90 hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start sm:items-center gap-3 min-w-0 flex-1">
                        {item.image ? (
                          <img
                            src={item.image}
                            alt=""
                            onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                            className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl object-cover border border-neutral-200 shrink-0 bg-neutral-200"
                          />
                        ) : (
                          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-neutral-200 flex items-center justify-center text-neutral-400 shrink-0">
                            <Boxes className="w-5 h-5" />
                          </div>
                        )}
                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-200 text-neutral-800 font-mono shrink-0">
                              {item.category}
                            </span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border font-mono shrink-0 ${ch.badgeClass}`}>
                              {ch.label}
                            </span>
                            <span className="text-xs font-bold text-neutral-900 break-words leading-snug">
                              {item.name}
                            </span>
                          </div>
                          <p className="text-xs font-mono font-bold text-emerald-700 break-words">
                            {item.price.toLocaleString()} {item.currency}
                            {getItemAcceptedCurrencies(item).length > 1
                              ? ` • Accepts (${getItemAcceptedCurrencies(item).length}/5): ${getItemAcceptedCurrencies(item).join(', ')}`
                              : ' (Final Currency)'}
                          </p>
                          <p className="text-[11px] text-neutral-500">
                            Stock: {item.stock ?? 20} • Media: {(item.photos?.length || 0) + (item.videos?.length || 0)} files
                            {getItemBarcode(item) ? ` • Barcode: ${getItemBarcode(item)}` : ''}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-neutral-200/70 w-full sm:w-auto" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedItemScope('instore');
                            setSelectedItemForModal(item);
                            setActiveQrPreview(item.qrCodes?.[0] || null);
                          }}
                          className="px-3 py-1.5 rounded-xl border border-neutral-200 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs whitespace-nowrap"
                        >
                          <QrCode className="w-3.5 h-3.5 text-neutral-600 shrink-0" />
                          <span>QR &amp; Media ({item.qrCodes?.length || 0}/2)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteInventoryItem(item.id, 'retail', 'instore')}
                          className="p-2 text-neutral-400 hover:text-rose-600 cursor-pointer shrink-0"
                          aria-label="Delete item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {isExp && (
                      <div className="pt-3 border-t border-neutral-200 space-y-3">
                        <p className="text-xs text-neutral-700 whitespace-pre-wrap leading-relaxed">
                          {item.description || 'No additional description provided.'}
                        </p>
                        {((item.photos && item.photos.length > 0) || (item.videos && item.videos.length > 0)) && (
                          <div className="flex flex-wrap gap-2">
                            {item.photos?.map((pUrl, pIdx) => (
                              <img key={`m-rp-${pIdx}`} src={pUrl} alt="" className="w-24 h-20 rounded-xl object-cover border border-neutral-200" />
                            ))}
                            {item.videos?.map((vUrl, vIdx) => (
                              <video key={`m-rv-${vIdx}`} src={vUrl} controls onClick={(e) => e.stopPropagation()} className="w-36 h-20 rounded-xl border border-neutral-200 bg-black object-cover" />
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  );
                })}
              </div>
                </div>
                );
              })()}
            </div>
          )}

          {/* Sub-view: Retail Store Online Store (Separate online catalog per retail store) */}
          {retailSubTab === 'online_store' && (
            <div className="space-y-6 max-w-4xl mx-auto text-center">
              <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-8 shadow-xs space-y-6 text-center">
                <div className="pb-4 border-b border-neutral-100 flex flex-col items-center justify-center">
                  <h3 className="font-serif-lux text-2xl font-bold text-neutral-900 text-center">
                    {activeLocation.name} — Online Store
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1 max-w-md text-center">
                    Manage separate online inventory &amp; pricing for {activeLocation.name}.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
                    <span className="text-xs font-mono font-bold px-3 py-1 bg-indigo-50 text-indigo-900 rounded-xl">
                      {onlineRetailCatalog.length}/100 Items Online
                    </span>
                    <button
                      type="button"
                      onClick={handleSyncRetailInventoryToOnline}
                      className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 rounded-xl text-xs font-bold cursor-pointer transition-colors"
                    >
                      Sync from Retail Inventory ({retailCatalog.length})
                    </button>
                  </div>
                </div>

                {/* Retailer Delivery Fee Configuration (How many of which Final Currency per mile/km) */}
                <div className="p-4 sm:p-5 rounded-2xl bg-indigo-50/60 border border-indigo-200/80 space-y-3 text-center max-w-xl mx-auto">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-indigo-950 block font-mono uppercase">
                      Online Delivery Fee Settings ({activeLocation.name})
                    </span>
                    <p className="text-[11px] text-indigo-900/75">
                      Set your delivery fee per mile or kilometer in any Final Currency for online orders.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
                    <div className="sm:col-span-4 space-y-1 text-left">
                      <label className="text-[10px] font-bold text-indigo-950 uppercase font-mono block text-center">Fee Amount</label>
                      <input
                        type="number"
                        min={0}
                        step="any"
                        placeholder="0.00"
                        value={activeLocation.deliveryFeeRate ?? 0}
                        onChange={(e) => updateActiveLocationField({ deliveryFeeRate: Math.max(0, parseFloat(e.target.value) || 0) })}
                        className="w-full px-3 py-2 bg-white rounded-xl border border-indigo-200 text-xs font-mono font-bold text-center text-neutral-900"
                      />
                    </div>

                    <div className="sm:col-span-5 space-y-1 text-left">
                      <label className="text-[10px] font-bold text-indigo-950 uppercase font-mono block text-center">Final Currency</label>
                      <button
                        type="button"
                        onClick={() => {
                          setCurrencyTarget('retail_delivery_fee');
                          setCurrencyModalSearch('');
                          setIsCurrencyModalOpen(true);
                        }}
                        className="w-full px-3 py-2 bg-white hover:bg-neutral-50 rounded-xl border border-indigo-200 text-xs font-mono font-bold flex items-center justify-between cursor-pointer"
                      >
                        <span className="truncate">{activeLocation.deliveryFeeCurrency || 'AFNL'}</span>
                        <ChevronDown className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                      </button>
                    </div>

                    <div className="sm:col-span-3 space-y-1 text-left">
                      <label className="text-[10px] font-bold text-indigo-950 uppercase font-mono block text-center">Per Unit</label>
                      <select
                        value={activeLocation.deliveryFeeUnit || 'mile'}
                        onChange={(e) => updateActiveLocationField({ deliveryFeeUnit: e.target.value as 'mile' | 'km' })}
                        className="w-full px-2.5 py-2 bg-white rounded-xl border border-indigo-200 text-xs font-bold text-center text-neutral-900 cursor-pointer"
                      >
                        <option value="mile">per mile</option>
                        <option value="km">per km</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Add Item Directly to Online Retail Store */}
                <form onSubmit={handleAddOnlineRetailItem} className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3 text-center max-w-xl mx-auto">
                  <span className="text-xs font-bold text-neutral-900 block font-mono uppercase">+ Add Item to Online Store</span>
                  <input
                    type="text"
                    placeholder="Item Name (e.g. Sovereign Gold Ingot 10g)"
                    value={onlineRetailTitle}
                    onChange={(e) => setOnlineRetailTitle(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs text-center"
                    required
                  />

                  <div className="space-y-1.5 text-center">
                    <label className="text-[11px] font-bold text-neutral-700 block text-center">Category (Pick or Type Custom)</label>
                    <div className="flex flex-wrap items-center justify-center gap-1">
                      {Array.from(new Set([...RETAIL_CATEGORY_PRESETS, ...retailCatalog.map(i => i.category), ...onlineRetailCatalog.map(i => i.category)].filter(Boolean))).map(cat => (
                        <button
                          key={`onl-ret-${cat}`}
                          type="button"
                          onClick={() => setOnlineRetailCategory(cat)}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                            onlineRetailCategory.trim().toLowerCase() === cat.toLowerCase()
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-white hover:bg-indigo-50 text-neutral-700 border-neutral-200'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input
                      type="text"
                      placeholder="Category"
                      value={onlineRetailCategory}
                      onChange={(e) => setOnlineRetailCategory(e.target.value)}
                      className="w-full px-3 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs text-center"
                    />
                    <input
                      type="number"
                      placeholder="Price *"
                      min={0}
                      step="any"
                      value={onlineRetailPrice}
                      onChange={(e) => setOnlineRetailPrice(e.target.value)}
                      className="w-full px-3 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs font-mono font-bold text-center"
                      required
                    />
                  </div>
                  {renderMultiCurrencySelector(
                    onlineRetailCurrencies,
                    (sym) => setOnlineRetailCurrencies(prev => toggleCurrencyInList(prev, sym, 5)),
                    'online_retail_add',
                    'indigo'
                  )}

                  <div className="space-y-2.5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <input
                        type="number"
                        placeholder="Stock Quantity"
                        min={0}
                        value={onlineRetailStock}
                        onChange={(e) => setOnlineRetailStock(e.target.value)}
                        className="w-full px-3 py-2 bg-white rounded-xl border border-neutral-200 text-xs font-mono text-center"
                      />
                      <input
                        type="text"
                        placeholder="Barcode / UPC (Optional)"
                        value={onlineRetailBarcode}
                        onChange={(e) => setOnlineRetailBarcode(e.target.value)}
                        className="w-full px-3 py-2 bg-white rounded-xl border border-neutral-200 text-xs font-mono text-center"
                      />
                    </div>
                    <div className="space-y-1 text-left">
                      <label className="text-[11px] font-bold text-neutral-700 block text-center">Detailed Description / Specifications</label>
                      <textarea
                        placeholder="Write a detailed product description including materials, dimensions, certification, provenance, condition, and shipping or vault pickup notes..."
                        value={onlineRetailDescription}
                        onChange={(e) => setOnlineRetailDescription(e.target.value)}
                        rows={4}
                        className="w-full px-3.5 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs text-neutral-900"
                      />
                    </div>
                  </div>

                  {/* Upload Photos & Videos for Online Retail Item */}
                  <div className="p-3 rounded-xl bg-white border border-neutral-200 space-y-2">
                    <input
                      ref={onlineRetailFileInputRef}
                      type="file"
                      accept="image/*,video/*"
                      multiple
                      className="hidden"
                      onChange={(e) => {
                        handleReadMediaFiles(
                          e.target.files,
                          (url) => setOnlineRetailPhotos(prev => [...prev, url]),
                          (url) => setOnlineRetailVideos(prev => [...prev, url])
                        );
                        e.target.value = '';
                      }}
                    />
                    <div className="flex flex-col sm:flex-row items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onlineRetailFileInputRef.current?.click()}
                        className="w-full sm:w-auto px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-xs font-bold text-neutral-800 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <Upload className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Upload Photo / Video ({onlineRetailPhotos.length + onlineRetailVideos.length})</span>
                      </button>
                      <div className="flex items-center gap-1.5 w-full">
                        <input
                          type="url"
                          placeholder="Or paste photo/video URL..."
                          value={onlineRetailMediaUrl}
                          onChange={(e) => setOnlineRetailMediaUrl(e.target.value)}
                          className="flex-1 px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs min-w-0"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const url = onlineRetailMediaUrl.trim();
                            if (!url) return;
                            if (/\.(mp4|webm|mov|ogg)(\?|$)/i.test(url)) {
                              setOnlineRetailVideos(prev => [...prev, url]);
                            } else {
                              setOnlineRetailPhotos(prev => [...prev, url]);
                            }
                            setOnlineRetailMediaUrl('');
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-neutral-900 text-white text-xs font-bold cursor-pointer shrink-0"
                        >
                          Attach
                        </button>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Save Item to Online Store
                  </button>
                </form>

                {/* Online Retail Items Directory with Tailored Search & Category Filter */}
                {(() => {
                  const qM = merchantCatalogSearch.toLowerCase().trim();
                  const cats = Array.from(new Set(onlineRetailCatalog.map(i => (i.category || 'General Retail').trim())));
                  const effCat = merchantCatalogCategory !== 'All' && cats.includes(merchantCatalogCategory) ? merchantCatalogCategory : 'All';
                  const filteredOnlineRetail = onlineRetailCatalog.filter(it => {
                    const matchesCat = effCat === 'All' || (it.category || 'General Retail').trim() === effCat;
                    const matchesQ = !qM || it.name.toLowerCase().includes(qM) || it.category.toLowerCase().includes(qM) || (it.description && it.description.toLowerCase().includes(qM));
                    return matchesCat && matchesQ;
                  });
                  return (
                <div className="space-y-3">
                  <div className="relative max-w-md mx-auto">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      placeholder={`Search ${activeLocation.name} online store...`}
                      value={merchantCatalogSearch}
                      onChange={(e) => setMerchantCatalogSearch(e.target.value)}
                      className="w-full pl-10 pr-8 py-2 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-indigo-500"
                    />
                  </div>
                  {cats.length > 0 && (
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setMerchantCatalogCategory('All')}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                          effCat === 'All' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                        }`}
                      >
                        All ({onlineRetailCatalog.length})
                      </button>
                      {cats.map(cat => (
                        <button
                          key={`onl-f-${cat}`}
                          type="button"
                          onClick={() => setMerchantCatalogCategory(cat)}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                            effCat === cat ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                          }`}
                        >
                          {cat} ({onlineRetailCatalog.filter(i => (i.category || 'General Retail').trim() === cat).length})
                        </button>
                      ))}
                    </div>
                  )}

                <div className="space-y-2.5 max-h-96 overflow-y-auto text-left pr-1">
                  {filteredOnlineRetail.length === 0 ? (
                    <p className="text-xs text-neutral-500 text-center py-6">
                      {onlineRetailCatalog.length === 0 ? `No items published online for ${activeLocation.name} yet.` : 'No matching items in this category/search.'}
                    </p>
                  ) : filteredOnlineRetail.map((item, idx) => {
                    const ch = getRetailChannelInfo(activeLocationId, item.id);
                    const mKey = `ret-onl-${item.id}`;
                    const isExp = expandedMerchantItemId === mKey;
                    return (
                    <div
                      key={item.id}
                      onClick={() => setExpandedMerchantItemId(prev => prev === mKey ? null : mKey)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                        isExp ? 'bg-white border-indigo-400 shadow-sm' : 'bg-neutral-50 border-neutral-200 hover:border-neutral-300'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <span className="text-xs font-mono font-bold text-neutral-400 shrink-0">#{idx + 1}</span>
                          {item.image && (
                            <img
                              src={item.image}
                              alt=""
                              onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                              className="w-12 h-12 rounded-xl object-cover shrink-0 bg-neutral-200"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-900 font-mono">{item.category}</span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border font-mono ${ch.badgeClass}`}>{ch.label}</span>
                              <span className="text-xs font-bold text-neutral-900 break-words">{item.name}</span>
                            </div>
                            <p className="text-[11px] font-mono text-emerald-700 font-bold mt-0.5">
                              {item.price.toLocaleString()} {item.currency}
                              {getItemAcceptedCurrencies(item).length > 1
                                ? ` • Accepts (${getItemAcceptedCurrencies(item).length}/5): ${getItemAcceptedCurrencies(item).join(', ')}`
                                : ' (Final Currency)'}
                            </p>
                            <p className="text-[11px] text-neutral-500">Stock: {item.stock ?? 20} • Media: {(item.photos?.length || 0) + (item.videos?.length || 0)} files</p>
                          </div>
                        </div>
                        <div className="flex items-center justify-end gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedItemScope('online');
                              setSelectedItemForModal(item);
                              setActiveQrPreview(item.qrCodes?.[0] || null);
                            }}
                            className="px-3 py-1.5 rounded-xl border border-neutral-200 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                          >
                            <QrCode className="w-3.5 h-3.5 text-neutral-600" />
                            <span>QR &amp; Media ({item.qrCodes?.length || 0}/2)</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteInventoryItem(item.id, 'retail', 'online')}
                            className="p-1.5 text-neutral-400 hover:text-rose-600 cursor-pointer"
                            aria-label="Delete online item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      {isExp && (
                        <div className="pt-3 border-t border-neutral-200 space-y-3">
                          <p className="text-xs text-neutral-700 whitespace-pre-wrap leading-relaxed">
                            {item.description || 'No additional description provided.'}
                          </p>
                          {((item.photos && item.photos.length > 0) || (item.videos && item.videos.length > 0)) && (
                            <div className="flex flex-wrap gap-2">
                              {item.photos?.map((pUrl, pIdx) => (
                                <img key={`m-orp-${pIdx}`} src={pUrl} alt="" className="w-24 h-20 rounded-xl object-cover border border-neutral-200" />
                              ))}
                              {item.videos?.map((vUrl, vIdx) => (
                                <video key={`m-orv-${vIdx}`} src={vUrl} controls onClick={(e) => e.stopPropagation()} className="w-36 h-20 rounded-xl border border-neutral-200 bg-black object-cover" />
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    );
                  })}
                </div>
                </div>
                  );
                })()}
              </div>
            </div>
          )}

          {/* Sub-view: Retail Sales History (Two Tabs: In-Store Sales & Online Sales with Full Invoices) */}
          {retailSubTab === 'history' && renderSalesLogWithInvoices('retail')}
        </div>
      )}

      {/* =========================================================
          TAB 3: RESTAURANT & BAR MANAGEMENT
          ========================================================= */}
      {mainTab === 'restaurant' && (
        <div className="space-y-6">
          {/* Sub-view: Checkout */}
          {restaurantSubTab === 'checkout' && renderMerchantCheckoutOrdersAndTerminal('restaurant')}

          {/* Sub-view: Add Item to Restaurant Menu / Online Menu */}
          {restaurantSubTab === 'add_item' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-xs max-w-3xl mx-auto space-y-6 text-center">
              <div className="pb-4 border-b border-neutral-100 flex flex-col items-center justify-center text-center space-y-2">
                <h3 className="font-serif-lux text-lg sm:text-xl font-bold text-neutral-900 text-center">Add Dish to Restaurant Menu</h3>
                <div className="flex items-center justify-center gap-2 text-xs font-mono font-bold text-neutral-700">
                  <span className="px-2.5 py-1 bg-neutral-100 rounded-lg">In-House: {restaurantCatalog.length} dishes</span>
                  <span className="text-neutral-300">•</span>
                  <span className="px-2.5 py-1 bg-amber-50 text-amber-800 rounded-lg">Online Menu: {onlineMenuDishes.length} dishes</span>
                </div>
              </div>

              <form onSubmit={handleAddNewInventoryItem} className="space-y-4 max-w-xl mx-auto flex flex-col items-center text-center">
                <div className="w-full p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-2 text-center">
                  <span className="text-xs font-bold text-amber-950 font-mono uppercase">Menu Destination ({activeLocation.name})</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left">
                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-amber-200 cursor-pointer">
                      <input type="checkbox" checked={newItemIncludeInStore} onChange={(e) => setNewItemIncludeInStore(e.target.checked)} className="w-4 h-4 accent-amber-600" />
                      <span className="text-xs font-bold text-neutral-900">In-House Restaurant Menu</span>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-amber-200 cursor-pointer">
                      <input type="checkbox" checked={newItemIncludeOnline} onChange={(e) => setNewItemIncludeOnline(e.target.checked)} className="w-4 h-4 accent-amber-600" />
                      <span className="text-xs font-bold text-neutral-900">Online Takeout Menu</span>
                    </label>
                  </div>
                </div>

                <div className="w-full space-y-1 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Dish Title / Name *</label>
                  <input
                    type="text"
                    placeholder="e.g. Miyazaki Wagyu Ribeye Steak (A5)"
                    value={newItemTitle}
                    onChange={(e) => setNewItemTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 text-center"
                    required
                  />
                </div>

                <div className="w-full space-y-2 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Category (Pick or Type Custom)</label>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {Array.from(new Set([...RESTAURANT_CATEGORY_PRESETS, ...restaurantCatalog.map(i => i.category), ...onlineMenuDishes.map(i => i.category)].filter(Boolean))).map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setNewItemType(cat)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                          newItemType.trim().toLowerCase() === cat.toLowerCase()
                            ? 'bg-amber-600 text-white border-amber-600'
                            : 'bg-neutral-50 hover:bg-amber-50 text-neutral-700 border-neutral-200'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                  <input
                    type="text"
                    placeholder="e.g. Entrees, Appetizers, Beverages & Wine, Desserts"
                    value={newItemType}
                    onChange={(e) => setNewItemType(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 text-center"
                  />
                </div>

                <div className="w-full space-y-2 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Cost / Price *</label>
                  <input
                    type="number"
                    placeholder="0.00"
                    min={0}
                    step="any"
                    value={newItemCost}
                    onChange={(e) => setNewItemCost(e.target.value)}
                    className="w-48 mx-auto px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs font-mono font-bold text-neutral-900 text-center"
                    required
                  />
                  {renderMultiCurrencySelector(
                    newItemCurrencies,
                    (sym) => setNewItemCurrencies(prev => toggleCurrencyInList(prev, sym, 5)),
                    'inventory_add',
                    'amber'
                  )}
                </div>

                <div className="w-full space-y-1 text-center">
                  <label className="text-xs font-bold text-neutral-700 block text-center">Detailed Description / Ingredients &amp; Notes</label>
                  <textarea
                    placeholder="Write a full description of the dish including cuts, key ingredients, cooking style, portion size, seasoning, allergens, and pairing recommendations..."
                    value={newItemDescription}
                    onChange={(e) => setNewItemDescription(e.target.value)}
                    rows={4}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                  />
                </div>

                {/* Upload Photos & Videos for Dish */}
                <div className="w-full p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3 text-center">
                  <div className="flex flex-col items-center justify-center">
                    <span className="text-xs font-bold text-neutral-900 flex items-center gap-1.5 font-mono uppercase">
                      <ImageIcon className="w-4 h-4 text-amber-600" />
                      <span>Upload Photos &amp; Videos ({newItemPhotos.length + newItemVideos.length})</span>
                    </span>
                    <span className="text-[11px] text-neutral-500">Shown on in-house POS &amp; online takeout menu</span>
                  </div>

                  <input
                    ref={inventoryFileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      handleReadMediaFiles(
                        e.target.files,
                        (url) => setNewItemPhotos(prev => [...prev, url]),
                        (url) => setNewItemVideos(prev => [...prev, url])
                      );
                      e.target.value = '';
                    }}
                  />

                  <div className="flex flex-col sm:flex-row items-center gap-2">
                    <button
                      type="button"
                      onClick={() => inventoryFileInputRef.current?.click()}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <Upload className="w-3.5 h-3.5 text-amber-600" />
                      <span>Browse Photo / Video</span>
                    </button>
                    <div className="flex items-center gap-1.5 w-full">
                      <input
                        type="url"
                        placeholder="Or paste photo/video URL..."
                        value={newItemMediaUrlInput}
                        onChange={(e) => setNewItemMediaUrlInput(e.target.value)}
                        className="flex-1 px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs min-w-0"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const url = newItemMediaUrlInput.trim();
                          if (!url) return;
                          if (/\.(mp4|webm|mov|ogg)(\?|$)/i.test(url)) {
                            setNewItemVideos(prev => [...prev, url]);
                          } else {
                            setNewItemPhotos(prev => [...prev, url]);
                          }
                          setNewItemMediaUrlInput('');
                        }}
                        className="px-3 py-2 rounded-xl bg-neutral-900 text-white text-xs font-bold cursor-pointer shrink-0"
                      >
                        Attach
                      </button>
                    </div>
                  </div>

                  {(newItemPhotos.length > 0 || newItemVideos.length > 0) && (
                    <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                      {newItemPhotos.map((p, idx) => (
                        <div key={`dp-${idx}`} className="relative w-14 h-14 rounded-xl overflow-hidden border border-neutral-300 bg-white">
                          <img src={p} alt="" className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => setNewItemPhotos(prev => prev.filter((_, i) => i !== idx))}
                            className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/70 text-white text-[10px] flex items-center justify-center cursor-pointer"
                          >
                            &times;
                          </button>
                        </div>
                      ))}
                      {newItemVideos.map((_, idx) => (
                        <div key={`dv-${idx}`} className="relative px-2.5 py-1.5 rounded-xl bg-amber-100 text-amber-900 text-[10px] font-bold flex items-center gap-1">
                          <Video className="w-3 h-3" />
                          <span>Video {idx + 1}</span>
                          <button
                            type="button"
                            onClick={() => setNewItemVideos(prev => prev.filter((_, i) => i !== idx))}
                            className="ml-1 text-rose-600 cursor-pointer"
                          >
                            &times;
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="w-full p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-2.5 text-center">
                  <div className="flex flex-col items-center justify-center">
                    <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5 font-mono uppercase">
                      <QrCode className="w-4 h-4 text-amber-700" />
                      <span>Attach QR Codes (Max 1 of each, 2 Total)</span>
                    </span>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded mt-0.5">Strict Limit: 2 Total</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-left">
                    <label className="flex items-start gap-2 p-3 rounded-xl bg-white border border-amber-200 cursor-pointer">
                      <input type="checkbox" checked={newItemAddOneTimeQR} onChange={(e) => setNewItemAddOneTimeQR(e.target.checked)} className="mt-0.5 w-4 h-4 accent-amber-600" />
                      <div><span className="text-xs font-bold text-amber-950 block">⚡ One-Time QR Code</span><span className="text-[11px] text-amber-800">Generate a unique single-use invoice QR for instant settlement.</span></div>
                    </label>
                    <label className="flex items-start gap-2 p-3 rounded-xl bg-white border border-indigo-200 cursor-pointer">
                      <input type="checkbox" checked={newItemAddInventoryQR} onChange={(e) => setNewItemAddInventoryQR(e.target.checked)} className="mt-0.5 w-4 h-4 accent-indigo-600" />
                      <div><span className="text-xs font-bold text-indigo-950 block">📦 Inventory List QR Code</span><span className="text-[11px] text-indigo-800">Generate a permanent catalog inventory tag QR code.</span></div>
                    </label>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full max-w-md py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-sm flex items-center justify-center gap-2 mx-auto"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Save Dish to Restaurant Menu</span>
                </button>
              </form>
            </div>
          )}

          {/* Sub-view: Restaurant Menu Directory (In-House) */}
          {restaurantSubTab === 'restaurant_menu' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-8 shadow-xs max-w-4xl mx-auto space-y-6 text-center">
              <div className="pb-4 border-b border-neutral-100 flex flex-col items-center justify-center text-center space-y-2">
                <h3 className="font-serif-lux text-lg sm:text-xl font-bold text-neutral-900 text-center">
                  {activeLocation.name} — Restaurant Menu
                </h3>
                <span className="text-xs font-mono font-bold px-3 py-1 bg-neutral-100 text-neutral-800 rounded-xl">{restaurantCatalog.length} Total Dishes</span>
              </div>

              {(() => {
                const qM = merchantCatalogSearch.toLowerCase().trim();
                const cats = Array.from(new Set(restaurantCatalog.map(i => (i.category || 'Entrees').trim())));
                const effCat = merchantCatalogCategory !== 'All' && cats.includes(merchantCatalogCategory) ? merchantCatalogCategory : 'All';
                const filteredMerchantDishes = restaurantCatalog.filter(it => {
                  const matchesCat = effCat === 'All' || (it.category || 'Entrees').trim() === effCat;
                  const matchesQ = !qM || it.name.toLowerCase().includes(qM) || it.category.toLowerCase().includes(qM) || (it.description && it.description.toLowerCase().includes(qM));
                  return matchesCat && matchesQ;
                });
                return (
                <div className="space-y-4">
                  <div className="relative max-w-md mx-auto">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      placeholder={`Search ${activeLocation.name} in-restaurant menu...`}
                      value={merchantCatalogSearch}
                      onChange={(e) => setMerchantCatalogSearch(e.target.value)}
                      className="w-full pl-10 pr-8 py-2 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-amber-500"
                    />
                  </div>
                  {cats.length > 0 && (
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setMerchantCatalogCategory('All')}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                          effCat === 'All' ? 'bg-amber-600 text-white border-amber-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                        }`}
                      >
                        All ({restaurantCatalog.length})
                      </button>
                      {cats.map(cat => (
                        <button
                          key={`res-in-${cat}`}
                          type="button"
                          onClick={() => setMerchantCatalogCategory(cat)}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                            effCat === cat ? 'bg-amber-600 text-white border-amber-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                          }`}
                        >
                          {cat} ({restaurantCatalog.filter(i => (i.category || 'Entrees').trim() === cat).length})
                        </button>
                      ))}
                    </div>
                  )}

              <div className="space-y-3 text-left">
                {filteredMerchantDishes.length === 0 ? (
                  <p className="text-xs text-neutral-500 text-center py-6">
                    {restaurantCatalog.length === 0 ? `No dishes in ${activeLocation.name}'s in-house menu yet.` : 'No matching dishes in this category/search.'}
                  </p>
                ) : filteredMerchantDishes.map(item => {
                  const ch = getRestaurantChannelInfo(activeLocationId, item.id);
                  const mKey = `res-in-${item.id}`;
                  const isExp = expandedMerchantItemId === mKey;
                  return (
                  <div
                    key={item.id}
                    onClick={() => setExpandedMerchantItemId(prev => prev === mKey ? null : mKey)}
                    className={`p-3.5 sm:p-4 rounded-2xl border transition-all cursor-pointer overflow-hidden space-y-3 ${
                      isExp ? 'bg-white border-amber-400 shadow-sm' : 'bg-neutral-50 border-neutral-200/90 hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start sm:items-center gap-3 min-w-0 flex-1">
                        {item.image && (
                          <img
                            src={item.image}
                            alt=""
                            onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                            className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl object-cover border border-neutral-200 shrink-0 bg-neutral-200"
                          />
                        )}
                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-200 text-neutral-800 font-mono shrink-0">{item.category}</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border font-mono shrink-0 ${ch.badgeClass}`}>{ch.label}</span>
                            <span className="text-xs font-bold text-neutral-900 break-words leading-snug">{item.name}</span>
                          </div>
                          <p className="text-xs font-mono font-bold text-emerald-700 break-words">
                            {item.price.toLocaleString()} {item.currency}
                            {getItemAcceptedCurrencies(item).length > 1
                              ? ` • Accepts (${getItemAcceptedCurrencies(item).length}/5): ${getItemAcceptedCurrencies(item).join(', ')}`
                              : ' (Final Currency)'}
                          </p>
                          <p className="text-[11px] text-neutral-500">Media: {(item.photos?.length || 0) + (item.videos?.length || 0)} files</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-neutral-200/70 w-full sm:w-auto" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedItemScope('instore');
                            setSelectedItemForModal(item);
                            setActiveQrPreview(item.qrCodes?.[0] || null);
                          }}
                          className="px-3 py-1.5 rounded-xl border border-neutral-200 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs whitespace-nowrap"
                        >
                          <QrCode className="w-3.5 h-3.5 text-neutral-600 shrink-0" />
                          <span>QR &amp; Media ({item.qrCodes?.length || 0}/2)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteInventoryItem(item.id, 'restaurant', 'instore')}
                          className="p-2 text-neutral-400 hover:text-rose-600 cursor-pointer shrink-0"
                          aria-label="Delete dish"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    {isExp && (
                      <div className="pt-3 border-t border-neutral-200 space-y-3">
                        <p className="text-xs text-neutral-700 whitespace-pre-wrap leading-relaxed">
                          {item.description || 'No additional dish description provided.'}
                        </p>
                        {((item.photos && item.photos.length > 0) || (item.videos && item.videos.length > 0)) && (
                          <div className="flex flex-wrap gap-2">
                            {item.photos?.map((pUrl, pIdx) => (
                              <img key={`m-dp-${pIdx}`} src={pUrl} alt="" className="w-24 h-20 rounded-xl object-cover border border-neutral-200" />
                            ))}
                            {item.videos?.map((vUrl, vIdx) => (
                              <video key={`m-dv-${vIdx}`} src={vUrl} controls onClick={(e) => e.stopPropagation()} className="w-36 h-20 rounded-xl border border-neutral-200 bg-black object-cover" />
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  );
                })}
              </div>
                </div>
                );
              })()}
            </div>
          )}

          {/* Sub-view: Online Menu & Takeout Timings */}
          {restaurantSubTab === 'online_menu' && (
            <div className="space-y-6 max-w-4xl mx-auto text-center">
              <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-8 shadow-xs space-y-6 text-center">
                <div className="pb-4 border-b border-neutral-100 flex flex-col items-center justify-center">
                  <h3 className="font-serif-lux text-2xl font-bold text-neutral-900 text-center">
                    {activeLocation.name} — Online Menu &amp; Timings
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1 max-w-md text-center">
                    Configure takeout operating hours and manage dishes published online for this restaurant.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
                    <span className="text-xs font-mono font-bold px-3 py-1 bg-blue-50 text-blue-900 rounded-xl">{onlineMenuDishes.length}/100 Dishes Online</span>
                    <button
                      type="button"
                      onClick={handleSyncRestaurantCatalogToOnline}
                      className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 rounded-xl text-xs font-bold cursor-pointer transition-colors"
                    >
                      Sync from Restaurant Menu ({restaurantCatalog.length})
                    </button>
                  </div>
                </div>

                {/* Editable Takeout Timings Selector */}
                <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/70 border border-amber-200/80 max-w-xl mx-auto space-y-3 text-center">
                  <span className="text-xs font-bold text-amber-950 uppercase tracking-wide flex items-center justify-center gap-1.5 font-mono">
                    <Clock className="w-4 h-4 text-amber-700" />
                    <span>Takeout Operating Timings</span>
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-left">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-amber-950 block">Opens At</label>
                      <input
                        type="time"
                        value={activeLocation.openingTime || '10:00'}
                        onChange={(e) => updateActiveLocationField({ openingTime: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-amber-200 text-xs font-mono font-bold text-neutral-900"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-amber-950 block">Closes At</label>
                      <input
                        type="time"
                        value={activeLocation.closingTime || '22:00'}
                        onChange={(e) => updateActiveLocationField({ closingTime: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-amber-200 text-xs font-mono font-bold text-neutral-900"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-amber-950 block">Operating Days</label>
                      <input
                        type="text"
                        value={activeLocation.operatingDays || 'Daily (Mon - Sun)'}
                        onChange={(e) => updateActiveLocationField({ operatingDays: e.target.value })}
                        placeholder="Daily (Mon - Sun)"
                        className="w-full px-3 py-2 rounded-xl bg-white border border-amber-200 text-xs font-semibold text-neutral-900"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
                    <span className="text-xs text-amber-900">
                      Active Window: <span className="font-bold">{formatTime12h(activeLocation.openingTime || '10:00')}</span> – <span className="font-bold">{formatTime12h(activeLocation.closingTime || '22:00')}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => updateActiveLocationField({ isOpenForTakeout: activeLocation.isOpenForTakeout === false ? true : false })}
                      className={`px-3 py-1 rounded-xl text-[11px] font-bold cursor-pointer border transition-colors ${
                        activeLocation.isOpenForTakeout === false
                          ? 'bg-rose-100 text-rose-800 border-rose-300'
                          : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      }`}
                    >
                      {activeLocation.isOpenForTakeout === false ? 'Online Orders: Paused' : 'Online Orders: Accepting Orders'}
                    </button>
                  </div>
                </div>

                {/* Restaurant Fulfillment Option: Takeout Pickup Only vs Takeout & Delivery + Fee Settings */}
                <div className="p-4 sm:p-5 rounded-2xl bg-indigo-50/60 border border-indigo-200/80 max-w-xl mx-auto space-y-3 text-center">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-indigo-950 block font-mono uppercase">
                      Online Fulfillment &amp; Delivery Settings ({activeLocation.name})
                    </span>
                    <p className="text-[11px] text-indigo-900/75">
                      Choose whether customers can only pick up takeout in person or also request delivery with a per mile/km fee.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => updateActiveLocationField({ allowsDelivery: false })}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        !activeLocation.allowsDelivery
                          ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                          : 'bg-white hover:bg-neutral-50 text-neutral-800 border-neutral-200'
                      }`}
                    >
                      Takeout Pickup Only
                    </button>
                    <button
                      type="button"
                      onClick={() => updateActiveLocationField({
                        allowsDelivery: true,
                        deliveryFeeRate: activeLocation.deliveryFeeRate ?? 2.5,
                        deliveryFeeCurrency: activeLocation.deliveryFeeCurrency || 'AFNL',
                        deliveryFeeUnit: activeLocation.deliveryFeeUnit || 'mile'
                      })}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                        activeLocation.allowsDelivery
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                          : 'bg-white hover:bg-neutral-50 text-neutral-800 border-neutral-200'
                      }`}
                    >
                      Offer Takeout &amp; Delivery
                    </button>
                  </div>

                  {activeLocation.allowsDelivery && (
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center pt-1">
                      <div className="sm:col-span-4 space-y-1 text-center">
                        <label className="text-[10px] font-bold text-indigo-950 uppercase font-mono block text-center">Fee Amount</label>
                        <input
                          type="number"
                          min={0}
                          step="any"
                          placeholder="0.00"
                          value={activeLocation.deliveryFeeRate ?? 0}
                          onChange={(e) => updateActiveLocationField({ deliveryFeeRate: Math.max(0, parseFloat(e.target.value) || 0) })}
                          className="w-full px-3 py-2 bg-white rounded-xl border border-indigo-200 text-xs font-mono font-bold text-center text-neutral-900"
                        />
                      </div>

                      <div className="sm:col-span-5 space-y-1 text-center">
                        <label className="text-[10px] font-bold text-indigo-950 uppercase font-mono block text-center">Final Currency</label>
                        <button
                          type="button"
                          onClick={() => {
                            setCurrencyTarget('restaurant_delivery_fee');
                            setCurrencyModalSearch('');
                            setIsCurrencyModalOpen(true);
                          }}
                          className="w-full px-3 py-2 bg-white hover:bg-neutral-50 rounded-xl border border-indigo-200 text-xs font-mono font-bold flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <span className="truncate">{activeLocation.deliveryFeeCurrency || 'AFNL'}</span>
                          <ChevronDown className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                        </button>
                      </div>

                      <div className="sm:col-span-3 space-y-1 text-center">
                        <label className="text-[10px] font-bold text-indigo-950 uppercase font-mono block text-center">Per Unit</label>
                        <select
                          value={activeLocation.deliveryFeeUnit || 'mile'}
                          onChange={(e) => updateActiveLocationField({ deliveryFeeUnit: e.target.value as 'mile' | 'km' })}
                          className="w-full px-2.5 py-2 bg-white rounded-xl border border-indigo-200 text-xs font-bold text-center text-neutral-900 cursor-pointer"
                        >
                          <option value="mile">per mile</option>
                          <option value="km">per km</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>

                {/* Add Dish Online Form - Cleanly Fitted Responsive Layout */}
                <form onSubmit={handleAddOnlineMenuDish} className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3 text-center max-w-xl mx-auto">
                  <span className="text-xs font-bold text-neutral-900 block font-mono uppercase">+ Add Dish to Online Takeout Menu</span>
                  <input
                    type="text"
                    placeholder="Dish Name (e.g. Lobster Bisque)"
                    value={onlineDishTitle}
                    onChange={(e) => setOnlineDishTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs text-center"
                    required
                  />
                  <div className="space-y-1.5 text-center">
                    <label className="text-[11px] font-bold text-neutral-700 block text-center">Category (Pick or Type Custom)</label>
                    <div className="flex flex-wrap items-center justify-center gap-1">
                      {Array.from(new Set([...RESTAURANT_CATEGORY_PRESETS, ...restaurantCatalog.map(i => i.category), ...onlineMenuDishes.map(i => i.category)].filter(Boolean))).map(cat => (
                        <button
                          key={`onl-res-${cat}`}
                          type="button"
                          onClick={() => setOnlineDishCategory(cat)}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                            onlineDishCategory.trim().toLowerCase() === cat.toLowerCase()
                              ? 'bg-amber-600 text-white border-amber-600'
                              : 'bg-white hover:bg-amber-50 text-neutral-700 border-neutral-200'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-bold text-neutral-500 uppercase px-1 block">Category</label>
                      <input
                        type="text"
                        placeholder="Entrees"
                        value={onlineDishCategory}
                        onChange={(e) => setOnlineDishCategory(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs text-center"
                      />
                    </div>
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-bold text-neutral-500 uppercase px-1 block">Price *</label>
                      <input
                        type="number"
                        placeholder="0.00"
                        min={0}
                        step="any"
                        value={onlineDishPrice}
                        onChange={(e) => setOnlineDishPrice(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs font-mono font-bold text-center"
                        required
                      />
                    </div>
                  </div>
                  {renderMultiCurrencySelector(
                    onlineDishCurrencies,
                    (sym) => setOnlineDishCurrencies(prev => toggleCurrencyInList(prev, sym, 5)),
                    'online_menu_add',
                    'amber'
                  )}

                  <div className="space-y-1 text-left">
                    <label className="text-[11px] font-bold text-neutral-700 block text-center">Detailed Description / Ingredients &amp; Preparation</label>
                    <textarea
                      placeholder="Write a detailed dish description including ingredients, cooking technique, portion size, allergen details, and recommended pairings..."
                      value={onlineDishDescription}
                      onChange={(e) => setOnlineDishDescription(e.target.value)}
                      rows={4}
                      className="w-full px-3.5 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs text-neutral-900"
                    />
                  </div>

                  {/* Upload Photos & Videos for Online Dish */}
                  <div className="p-3 rounded-xl bg-white border border-neutral-200 space-y-2">
                    <input
                      ref={onlineDishFileInputRef}
                      type="file"
                      accept="image/*,video/*"
                      multiple
                      className="hidden"
                      onChange={(e) => {
                        handleReadMediaFiles(
                          e.target.files,
                          (url) => setOnlineDishPhotos(prev => [...prev, url]),
                          (url) => setOnlineDishVideos(prev => [...prev, url])
                        );
                        e.target.value = '';
                      }}
                    />
                    <div className="flex flex-col sm:flex-row items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onlineDishFileInputRef.current?.click()}
                        className="w-full sm:w-auto px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-xs font-bold text-neutral-800 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <Upload className="w-3.5 h-3.5 text-amber-600" />
                        <span>Upload Photo / Video ({onlineDishPhotos.length + onlineDishVideos.length})</span>
                      </button>
                      <div className="flex items-center gap-1.5 w-full">
                        <input
                          type="url"
                          placeholder="Or paste photo/video URL..."
                          value={onlineDishMediaUrl}
                          onChange={(e) => setOnlineDishMediaUrl(e.target.value)}
                          className="flex-1 px-2.5 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs min-w-0"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const url = onlineDishMediaUrl.trim();
                            if (!url) return;
                            if (/\.(mp4|webm|mov|ogg)(\?|$)/i.test(url)) {
                              setOnlineDishVideos(prev => [...prev, url]);
                            } else {
                              setOnlineDishPhotos(prev => [...prev, url]);
                            }
                            setOnlineDishMediaUrl('');
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-neutral-900 text-white text-xs font-bold cursor-pointer shrink-0"
                        >
                          Attach
                        </button>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors"
                  >
                    Save Dish to Online Takeout Menu
                  </button>
                </form>

                {(() => {
                  const qM = merchantCatalogSearch.toLowerCase().trim();
                  const cats = Array.from(new Set(onlineMenuDishes.map(i => (i.category || 'Entrees').trim())));
                  const effCat = merchantCatalogCategory !== 'All' && cats.includes(merchantCatalogCategory) ? merchantCatalogCategory : 'All';
                  const filteredOnlineDishes = onlineMenuDishes.filter(it => {
                    const matchesCat = effCat === 'All' || (it.category || 'Entrees').trim() === effCat;
                    const matchesQ = !qM || it.name.toLowerCase().includes(qM) || it.category.toLowerCase().includes(qM) || (it.description && it.description.toLowerCase().includes(qM));
                    return matchesCat && matchesQ;
                  });
                  return (
                <div className="space-y-3">
                  <div className="relative max-w-md mx-auto">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      placeholder={`Search ${activeLocation.name} online menu...`}
                      value={merchantCatalogSearch}
                      onChange={(e) => setMerchantCatalogSearch(e.target.value)}
                      className="w-full pl-10 pr-8 py-2 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-amber-500"
                    />
                  </div>
                  {cats.length > 0 && (
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setMerchantCatalogCategory('All')}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                          effCat === 'All' ? 'bg-amber-600 text-white border-amber-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                        }`}
                      >
                        All ({onlineMenuDishes.length})
                      </button>
                      {cats.map(cat => (
                        <button
                          key={`onl-df-${cat}`}
                          type="button"
                          onClick={() => setMerchantCatalogCategory(cat)}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border cursor-pointer ${
                            effCat === cat ? 'bg-amber-600 text-white border-amber-600' : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                          }`}
                        >
                          {cat} ({onlineMenuDishes.filter(i => (i.category || 'Entrees').trim() === cat).length})
                        </button>
                      ))}
                    </div>
                  )}

                <div className="space-y-2.5 max-h-96 overflow-y-auto text-left pr-1">
                  {filteredOnlineDishes.length === 0 ? (
                    <p className="text-xs text-neutral-500 text-center py-6">
                      {onlineMenuDishes.length === 0 ? 'No dishes published to online takeout menu yet.' : 'No matching dishes in this category/search.'}
                    </p>
                  ) : filteredOnlineDishes.map((dish, idx) => {
                    const ch = getRestaurantChannelInfo(activeLocationId, dish.id);
                    const mKey = `res-onl-${dish.id}`;
                    const isExp = expandedMerchantItemId === mKey;
                    return (
                    <div
                      key={dish.id}
                      onClick={() => setExpandedMerchantItemId(prev => prev === mKey ? null : mKey)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                        isExp ? 'bg-white border-amber-400 shadow-sm' : 'bg-neutral-50 border-neutral-200 hover:border-neutral-300'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <span className="text-xs font-mono font-bold text-neutral-400 shrink-0">#{idx + 1}</span>
                          {dish.image && (
                            <img
                              src={dish.image}
                              alt=""
                              onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                              className="w-12 h-12 rounded-xl object-cover shrink-0 bg-neutral-200"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-mono">{dish.category}</span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border font-mono ${ch.badgeClass}`}>{ch.label}</span>
                              <span className="text-xs font-bold text-neutral-900 break-words">{dish.name}</span>
                            </div>
                            <p className="text-[11px] font-mono text-emerald-700 font-bold mt-0.5">
                              {dish.price.toLocaleString()} {dish.currency}
                              {getItemAcceptedCurrencies(dish).length > 1
                                ? ` • Accepts (${getItemAcceptedCurrencies(dish).length}/5): ${getItemAcceptedCurrencies(dish).join(', ')}`
                                : ' (Final Currency)'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center justify-end gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedItemScope('online');
                              setSelectedItemForModal(dish);
                              setActiveQrPreview(dish.qrCodes?.[0] || null);
                            }}
                            className="px-3 py-1.5 rounded-xl border border-neutral-200 bg-white hover:bg-neutral-100 text-neutral-800 text-xs font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                          >
                            <QrCode className="w-3.5 h-3.5 text-neutral-600" />
                            <span>QR &amp; Media ({dish.qrCodes?.length || 0}/2)</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteInventoryItem(dish.id, 'restaurant', 'online')}
                            className="p-1.5 text-neutral-400 hover:text-rose-600 cursor-pointer"
                            aria-label="Delete online dish"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      {isExp && (
                        <div className="pt-3 border-t border-neutral-200 space-y-3">
                          <p className="text-xs text-neutral-700 whitespace-pre-wrap leading-relaxed">
                            {dish.description || 'No additional dish description provided.'}
                          </p>
                          {((dish.photos && dish.photos.length > 0) || (dish.videos && dish.videos.length > 0)) && (
                            <div className="flex flex-wrap gap-2">
                              {dish.photos?.map((pUrl, pIdx) => (
                                <img key={`m-odp-${pIdx}`} src={pUrl} alt="" className="w-24 h-20 rounded-xl object-cover border border-neutral-200" />
                              ))}
                              {dish.videos?.map((vUrl, vIdx) => (
                                <video key={`m-odv-${vIdx}`} src={vUrl} controls onClick={(e) => e.stopPropagation()} className="w-36 h-20 rounded-xl border border-neutral-200 bg-black object-cover" />
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    );
                  })}
                </div>
                </div>
                  );
                })()}
              </div>
            </div>
          )}

          {/* Sub-view: Takeout & Delivery Orders */}
          {restaurantSubTab === 'takeout_orders' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
                <h3 className="font-bold text-sm text-neutral-900">Incoming Takeout &amp; Delivery Orders — {activeLocation.name}</h3>
                <span className="text-xs font-mono px-3 py-1 bg-emerald-100 text-emerald-900 font-bold rounded-xl">
                  {takeoutOrders.filter(o => o.restaurantId === activeLocationId).length} Orders
                </span>
              </div>
              <div className="space-y-3">
                {takeoutOrders.filter(o => o.restaurantId === activeLocationId).map(order => {
                  const displayPhone = order.customerPhone || order.deliveryAddress?.phone;
                  const displayEmail = order.customerEmail || order.deliveryAddress?.email;
                  return (
                  <div key={order.id} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-extrabold text-neutral-900 font-mono">{order.orderNumber}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase ${
                          order.status === 'cancelled'
                            ? 'bg-rose-100 text-rose-900'
                            : order.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-900'
                              : order.status === 'ready_for_pickup'
                                ? 'bg-indigo-100 text-indigo-900'
                                : 'bg-amber-100 text-amber-900'
                        }`}>
                          {order.status === 'in_kitchen' ? 'In Kitchen' : order.status === 'ready_for_pickup' ? 'Ready' : order.status.replace(/_/g, ' ')}
                        </span>
                        {order.deliveryAddress && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900">Delivery</span>
                        )}
                      </div>
                      <p className="text-xs text-neutral-700">
                        Customer: <span className="font-bold">{order.customerName}</span> (@{order.customerHandle})
                        {displayPhone ? ` • Phone: ${displayPhone}` : ''}
                        {displayEmail ? ` • ${displayEmail}` : ''}
                      </p>
                      {order.deliveryAddress ? (
                        <p className="text-xs text-indigo-900">
                          Delivery Address: <span className="font-semibold">{order.deliveryAddress.fullName}</span> — {order.deliveryAddress.address}
                        </p>
                      ) : (
                        <p className="text-[10px] text-neutral-500 font-mono">Pickup: {order.pickupTime}</p>
                      )}
                      <p className="text-xs text-neutral-600">Items: {order.items.map(i => `${i.quantity}x ${i.item.name}`).join(', ')}</p>
                      {order.notes && <p className="text-[11px] text-neutral-500">Notes: {order.notes}</p>}
                      {order.status === 'cancelled' && order.cancelledReason && (
                        <p className="text-[11px] text-rose-700 font-semibold">{order.cancelledReason}</p>
                      )}
                    </div>
                    <div className="text-right shrink-0 space-y-2">
                      {order.driverAccepted ? (
                        <div>
                          <p className="text-[11px] font-mono text-neutral-500 line-through">
                            Before: {(order.originalTotal ?? order.total).toLocaleString()} {order.currency}
                          </p>
                          <p className="text-sm font-extrabold font-mono text-emerald-700">
                            After: {order.total.toLocaleString()} {order.currency}
                          </p>
                        </div>
                      ) : (
                        <p className={`text-sm font-extrabold font-mono ${order.status === 'cancelled' ? 'text-rose-700 line-through' : 'text-emerald-700'}`}>
                          {order.total.toLocaleString()} {order.currency}
                        </p>
                      )}
                      {order.status !== 'completed' && order.status !== 'cancelled' && (
                        <div className="flex flex-wrap items-center justify-end gap-1.5">
                          {(order.status === 'received' || order.status === 'in_kitchen') && (
                            <button
                              type="button"
                              onClick={() => handleUpdateOrderStatus(order.id, 'ready_for_pickup')}
                              className="px-2.5 py-1 rounded-lg bg-indigo-100 hover:bg-indigo-200 text-indigo-900 text-[11px] font-bold cursor-pointer"
                            >
                              {(order.fulfillmentType === 'delivery' || !!order.deliveryAddress) ? 'Out for Delivery / Ready' : 'Ready for Pickup'}
                            </button>
                          )}
                          {(order.fulfillmentType === 'delivery' || !!order.deliveryAddress) && (
                            order.driverAccepted ? (
                              <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 text-[11px] font-bold">
                                Driver: {order.driverName} ✓
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleDispatchToDriver(order)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-[11px] font-bold cursor-pointer flex items-center gap-1"
                              >
                                <Car className="w-3 h-3" />
                                <span>{order.dispatchedToDriver ? 'Driver Pinged ✓' : 'Driver'}</span>
                              </button>
                            )
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Sub-view: Restaurant Sales History (Two Tabs: In-Restaurant Sales & Online Sales with Full Invoices) */}
          {restaurantSubTab === 'history' && renderSalesLogWithInvoices('restaurant')}
        </div>
      )}

      {/* =========================================================
          MODALS & OVERLAYS
          ========================================================= */}


      {/* 1B. DEDICATED STORE / RESTAURANT RATINGS & REVIEWS MODAL (OPENED FROM HEADER RATING PILL OR CARDS) */}
      {reviewsModalLocation && (() => {
        const modalReviews = reviewsList.filter(r => r.storeId === reviewsModalLocation.id);
        const modalAvg = modalReviews.length > 0
          ? (modalReviews.reduce((s, r) => s + r.rating, 0) / modalReviews.length).toFixed(1)
          : '0.0';
        const hasExistingReview = modalReviews.some(r => r.userId === (currentUser?.id || 'you'));
        return (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-5 text-left my-8 animate-in fade-in zoom-in-95 duration-200 max-h-[88vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-3 border-b border-neutral-100 gap-3">
              <div className="min-w-0">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-900 font-mono uppercase">
                  {reviewsModalLocation.type} Ratings &amp; Reviews
                </span>
                <h3 className="font-serif-lux text-lg font-bold text-neutral-900 mt-1">{reviewsModalLocation.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1 text-amber-600 font-bold text-sm">
                    <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                    <span>{modalReviews.length > 0 ? `${modalAvg} / 5.0` : 'No ratings yet'}</span>
                  </div>
                  <span className="text-xs text-neutral-500">({modalReviews.length} {modalReviews.length === 1 ? 'review' : 'reviews'})</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setReviewsModalLocation(null)}
                className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600 cursor-pointer shrink-0"
              >
                &times;
              </button>
            </div>

            {/* Add / Update Rating & Comment Form */}
            <form onSubmit={(e) => handleSaveStoreReview(e, reviewsModalLocation)} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-800">
                  {hasExistingReview ? 'Update Your Rating:' : 'Add Your Rating:'}
                </span>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setUserRatingScore(star)}
                      className="p-1 cursor-pointer"
                    >
                      <Star className={`w-5 h-5 ${star <= userRatingScore ? 'fill-amber-500 text-amber-500' : 'text-neutral-300'}`} />
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                placeholder={`Share or update your comment about ${reviewsModalLocation.name}...`}
                value={userReviewComment}
                onChange={(e) => setUserReviewComment(e.target.value)}
                rows={3}
                className="w-full px-3 py-2.5 bg-white rounded-xl border border-neutral-200 text-xs text-neutral-900"
                required
              />

              <button
                type="submit"
                className="w-full py-2.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                {hasExistingReview ? 'Update Rating & Comment' : 'Submit Rating & Comment'}
              </button>
            </form>

            {/* All Ratings & Comments List */}
            <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
              <h4 className="text-[11px] font-bold text-neutral-500 uppercase font-mono">
                All Ratings &amp; Comments ({modalReviews.length})
              </h4>
              {modalReviews.length === 0 ? (
                <p className="text-xs text-neutral-500 text-center py-4 bg-neutral-50 rounded-xl">No reviews yet. Be the first to rate and comment!</p>
              ) : modalReviews.map(rev => (
                <div key={rev.id} className="p-3.5 rounded-2xl bg-white border border-neutral-200 space-y-1.5">
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-bold text-neutral-900 truncate">
                      @{rev.userHandle} ({rev.userName})
                      {rev.userId === (currentUser?.id || 'you') && (
                        <span className="ml-1.5 text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">You</span>
                      )}
                    </span>
                    <div className="flex items-center text-amber-500 shrink-0">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-neutral-700 whitespace-pre-wrap">{rev.comment}</p>
                  <span className="text-[10px] text-neutral-400 font-mono block">{rev.updatedAt}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        );
      })()}

      {/* 2. CREATE RETAIL STORE OR RESTAURANT MODAL (STRICTLY LOCKED TO INVOKING TAB, NO TYPE SWITCHER) */}
      {isAddLocationModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-left animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                {newLocType === 'retail' ? (
                  <ShoppingBag className="w-4 h-4 text-indigo-600 shrink-0" />
                ) : (
                  <UtensilsCrossed className="w-4 h-4 text-amber-600 shrink-0" />
                )}
                <h3 className="font-serif-lux text-base font-bold text-neutral-900">
                  {newLocType === 'retail'
                    ? `+ Create Retail Store (${locations.filter(l => l.type === 'retail').length}/10)`
                    : `+ Create Restaurant (${locations.filter(l => l.type === 'restaurant').length}/10)`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddLocationModalOpen(false)}
                className="w-7 h-7 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateLocation} className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-700">
                  {newLocType === 'retail' ? 'Retail Store Name *' : 'Restaurant Name *'}
                </label>
                <input
                  type="text"
                  placeholder={newLocType === 'retail' ? 'e.g. Alpha Bullion Vault' : 'e.g. Monaco Maritime Grill'}
                  value={newLocName}
                  onChange={(e) => setNewLocName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-700">Phone</label>
                  <input
                    type="text"
                    placeholder="+41 44 211 4050"
                    value={newLocPhone}
                    onChange={(e) => setNewLocPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-neutral-700">Email</label>
                  <input
                    type="email"
                    placeholder="store@domain.com"
                    value={newLocEmail}
                    onChange={(e) => setNewLocEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-700">Address *</label>
                <input
                  type="text"
                  placeholder="e.g. Zurich Freeport Vault 4B, 8048 Zürich"
                  value={newLocAddress}
                  onChange={(e) => setNewLocAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-700">
                  {newLocType === 'retail' ? 'Store Category' : 'Cuisine Style'}
                </label>
                <input
                  type="text"
                  placeholder={newLocType === 'retail' ? 'e.g. Bullion, Electronics, Apparel' : 'e.g. Haute Teppanyaki, Swiss Steakhouse'}
                  value={newLocCategory}
                  onChange={(e) => setNewLocCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                />
              </div>

              {newLocType === 'retail' ? (
                <div className="p-3 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2">
                  <label className="text-[11px] font-bold text-indigo-950 block">Online Delivery Fee (Per Mile / Km)</label>
                  <div className="grid grid-cols-12 gap-2">
                    <input
                      type="number"
                      min={0}
                      step="any"
                      placeholder="Rate"
                      value={newLocDeliveryFeeRate}
                      onChange={(e) => setNewLocDeliveryFeeRate(e.target.value)}
                      className="col-span-4 px-2.5 py-2 rounded-xl bg-white border border-indigo-200 text-xs font-mono font-bold text-neutral-900"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setCurrencyTarget('new_loc_delivery_fee');
                        setCurrencyModalSearch('');
                        setIsCurrencyModalOpen(true);
                      }}
                      className="col-span-5 px-2.5 py-2 rounded-xl bg-white hover:bg-neutral-50 border border-indigo-200 text-xs font-mono font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span className="truncate">{newLocDeliveryFeeCurrency}</span>
                      <ChevronDown className="w-3 h-3 text-neutral-400 shrink-0" />
                    </button>
                    <select
                      value={newLocDeliveryFeeUnit}
                      onChange={(e) => setNewLocDeliveryFeeUnit(e.target.value as 'mile' | 'km')}
                      className="col-span-3 px-2 py-2 rounded-xl bg-white border border-indigo-200 text-xs font-bold text-neutral-900"
                    >
                      <option value="mile">/ mi</option>
                      <option value="km">/ km</option>
                    </select>
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2.5">
                  <label className="text-[11px] font-bold text-amber-950 block">Online Fulfillment Option</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setNewLocAllowsDelivery(false)}
                      className={`px-2.5 py-2 rounded-xl text-[11px] font-bold border cursor-pointer ${
                        !newLocAllowsDelivery
                          ? 'bg-amber-600 text-white border-amber-600'
                          : 'bg-white text-neutral-800 border-amber-200'
                      }`}
                    >
                      Takeout Pickup Only
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewLocAllowsDelivery(true)}
                      className={`px-2.5 py-2 rounded-xl text-[11px] font-bold border cursor-pointer ${
                        newLocAllowsDelivery
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white text-neutral-800 border-amber-200'
                      }`}
                    >
                      Takeout &amp; Delivery
                    </button>
                  </div>
                  {newLocAllowsDelivery && (
                    <div className="grid grid-cols-12 gap-2 pt-1">
                      <input
                        type="number"
                        min={0}
                        step="any"
                        placeholder="Rate"
                        value={newLocDeliveryFeeRate}
                        onChange={(e) => setNewLocDeliveryFeeRate(e.target.value)}
                        className="col-span-4 px-2.5 py-2 rounded-xl bg-white border border-amber-200 text-xs font-mono font-bold text-neutral-900"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setCurrencyTarget('new_loc_delivery_fee');
                          setCurrencyModalSearch('');
                          setIsCurrencyModalOpen(true);
                        }}
                        className="col-span-5 px-2.5 py-2 rounded-xl bg-white hover:bg-neutral-50 border border-amber-200 text-xs font-mono font-bold flex items-center justify-between cursor-pointer"
                      >
                        <span className="truncate">{newLocDeliveryFeeCurrency}</span>
                        <ChevronDown className="w-3 h-3 text-neutral-400 shrink-0" />
                      </button>
                      <select
                        value={newLocDeliveryFeeUnit}
                        onChange={(e) => setNewLocDeliveryFeeUnit(e.target.value as 'mile' | 'km')}
                        className="col-span-3 px-2 py-2 rounded-xl bg-white border border-amber-200 text-xs font-bold text-neutral-900"
                      >
                        <option value="mile">/ mi</option>
                        <option value="km">/ km</option>
                      </select>
                    </div>
                  )}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                {newLocType === 'retail' ? 'Create Retail Store (Saved to Account)' : 'Create Restaurant (Saved to Account)'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 3. ITEM QR & MEDIA MODAL */}
      {selectedItemForModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 text-center my-auto max-h-[88vh] overflow-y-auto border border-neutral-200">
            <div className="relative pb-3 border-b border-neutral-100 flex flex-col items-center justify-center">
              <button
                type="button"
                onClick={() => {
                  setSelectedItemForModal(null);
                  setActiveQrPreview(null);
                }}
                className="absolute top-0 right-0 w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600 cursor-pointer"
              >
                &times;
              </button>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-700 font-mono mb-1">
                {selectedItemForModal.category}
              </span>
              <h3 className="font-bold text-base text-neutral-900 text-center px-6">{selectedItemForModal.name}</h3>
              <p className="text-xs font-mono font-bold text-emerald-700 text-center">
                {selectedItemForModal.price.toLocaleString()} {selectedItemForModal.currency}
                {getItemAcceptedCurrencies(selectedItemForModal).length > 1
                  ? ` • Accepts (${getItemAcceptedCurrencies(selectedItemForModal).length}/5): ${getItemAcceptedCurrencies(selectedItemForModal).join(', ')}`
                  : ' (Final Currency)'}
              </p>
            </div>

            {/* Accepted Final Currencies Editor (Up to 5 Final Currencies per Item/Dish) */}
            {renderMultiCurrencySelector(
              getItemAcceptedCurrencies(selectedItemForModal),
              (sym) => handleToggleModalItemCurrency(selectedItemForModal, sym),
              'item_edit_currencies',
              selectedItemForModal.type === 'restaurant' ? 'amber' : 'indigo'
            )}

            {/* QR Codes Section */}
            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3 text-center">
              <div className="flex flex-col items-center justify-center text-center">
                <h4 className="text-xs font-bold text-neutral-900 font-mono flex items-center justify-center gap-1.5 uppercase">
                  <QrCode className="w-4 h-4 text-emerald-600" />
                  <span>QR Codes ({(selectedItemForModal.qrCodes || []).length}/2)</span>
                </h4>
                <p className="text-[11px] text-neutral-500">Max 1 of each: One-Time Settlement QR &amp; Inventory List QR</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {selectedItemForModal.qrCodes?.some(q => q.type === 'one-time') ? (
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                    <div 
                      className="cursor-pointer hover:underline text-left"
                      onClick={() => {
                        const found = selectedItemForModal.qrCodes?.find(q => q.type === 'one-time');
                        if (found) setActiveQrPreview(found);
                      }}
                    >
                      <span className="text-xs font-bold text-amber-900">⚡ One-Time QR</span>
                      <p className="text-[10px] text-amber-700">Click to view/scan</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveQrCodeFromItem(selectedItemForModal, 'one-time')}
                      className="p-1 text-amber-600 hover:text-rose-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleAddQrCodeToItem(selectedItemForModal, 'one-time')}
                    className="p-3 rounded-xl bg-white hover:bg-amber-50 border border-dashed border-amber-300 text-center transition-colors cursor-pointer group"
                  >
                    <p className="text-xs font-bold text-amber-900 flex items-center justify-center gap-1">
                      <Plus className="w-3.5 h-3.5 text-amber-600" />
                      <span>One-Time QR</span>
                    </p>
                  </button>
                )}

                {selectedItemForModal.qrCodes?.some(q => q.type === 'inventory') ? (
                  <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-between">
                    <div 
                      className="cursor-pointer hover:underline text-left"
                      onClick={() => {
                        const found = selectedItemForModal.qrCodes?.find(q => q.type === 'inventory');
                        if (found) setActiveQrPreview(found);
                      }}
                    >
                      <span className="text-xs font-bold text-indigo-900">📦 Inventory QR</span>
                      <p className="text-[10px] text-indigo-700">Click to view/scan</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveQrCodeFromItem(selectedItemForModal, 'inventory')}
                      className="p-1 text-indigo-600 hover:text-rose-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleAddQrCodeToItem(selectedItemForModal, 'inventory')}
                    className="p-3 rounded-xl bg-white hover:bg-indigo-50 border border-dashed border-indigo-300 text-center transition-colors cursor-pointer group"
                  >
                    <p className="text-xs font-bold text-indigo-900 flex items-center justify-center gap-1">
                      <Plus className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Inventory QR</span>
                    </p>
                  </button>
                )}
              </div>

              {activeQrPreview && (
                <div className="p-3 bg-white rounded-xl border border-neutral-200 text-center space-y-2 mx-auto max-w-sm">
                  <div className="flex items-center justify-between text-[11px] font-bold text-neutral-700 border-b border-neutral-100 pb-1.5">
                    <span>Preview: {activeQrPreview.type === 'one-time' ? '⚡ One-Time Invoice' : '📦 Inventory Tag'}</span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(activeQrPreview.payload);
                        dispatchGlobalNotification({
                          title: 'Copied QR Payload',
                          description: 'Payload copied to clipboard.',
                          type: 'pos',
                          targetTab: 'point_of_sale',
                          showToast: true,
                          tone: 'success'
                        });
                      }}
                      className="text-neutral-500 hover:text-neutral-900 flex items-center gap-1 cursor-pointer"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copy Payload</span>
                    </button>
                  </div>
                  <div className="p-2 inline-block bg-white rounded-xl shadow-2xs border border-neutral-100">
                    <QRCodeSVG value={activeQrPreview.payload} size={130} level="M" />
                  </div>
                </div>
              )}
            </div>

            {/* Photos & Videos Attachment Section inside QR & Media Popup */}
            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3 text-center">
              <div className="flex flex-col items-center justify-center text-center">
                <h4 className="text-xs font-bold text-neutral-900 font-mono flex items-center justify-center gap-1.5 uppercase">
                  <ImageIcon className="w-4 h-4 text-indigo-600" />
                  <span>Photos &amp; Videos ({(selectedItemForModal.photos?.length || 0) + (selectedItemForModal.videos?.length || 0)})</span>
                </h4>
                <p className="text-[11px] text-neutral-500">Upload photos and video clips for in-house POS &amp; online storefront</p>
              </div>

              <input
                ref={modalFileInputRef}
                type="file"
                accept="image/*,video/*"
                multiple
                className="hidden"
                onChange={(e) => {
                  handleReadMediaFiles(
                    e.target.files,
                    (url) => handleAddMediaToModalItem(selectedItemForModal, url, false),
                    (url) => handleAddMediaToModalItem(selectedItemForModal, url, true)
                  );
                  e.target.value = '';
                }}
              />

              <div className="flex flex-col sm:flex-row items-center gap-2">
                <button
                  type="button"
                  onClick={() => modalFileInputRef.current?.click()}
                  className="w-full sm:w-auto px-3.5 py-2 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Upload className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Upload Photo / Video</span>
                </button>
                <div className="flex items-center gap-1.5 w-full">
                  <input
                    type="url"
                    placeholder="Or paste image / video URL..."
                    value={modalMediaUrl}
                    onChange={(e) => setModalMediaUrl(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs min-w-0"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const url = modalMediaUrl.trim();
                      if (!url) return;
                      const isVid = /\.(mp4|webm|mov|ogg)(\?|$)/i.test(url);
                      handleAddMediaToModalItem(selectedItemForModal, url, isVid);
                    }}
                    className="px-3 py-2 rounded-xl bg-neutral-900 text-white text-xs font-bold cursor-pointer shrink-0"
                  >
                    Attach
                  </button>
                </div>
              </div>

              {((selectedItemForModal.photos && selectedItemForModal.photos.length > 0) ||
                (selectedItemForModal.videos && selectedItemForModal.videos.length > 0)) && (
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  {selectedItemForModal.photos?.map((photoUrl, idx) => (
                    <div key={`mp-${idx}`} className="w-16 h-16 rounded-xl overflow-hidden border border-neutral-200 bg-white">
                      <img src={photoUrl} alt="" className="w-full h-full object-cover" />
                    </div>
                  ))}
                  {selectedItemForModal.videos?.map((_, idx) => (
                    <div key={`mv-${idx}`} className="px-2.5 py-1.5 rounded-xl bg-indigo-100 text-indigo-900 text-[10px] font-bold flex items-center gap-1">
                      <Video className="w-3.5 h-3.5" />
                      <span>Video {idx + 1}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                setSelectedItemForModal(null);
                setActiveQrPreview(null);
              }}
              className="w-full max-w-xs py-2.5 bg-neutral-900 hover:bg-black text-white text-xs font-bold rounded-xl cursor-pointer mx-auto"
            >
              Close &amp; Save
            </button>
          </div>
        </div>
      )}

      {/* 4. SEARCHABLE FINAL CURRENCY MODAL */}
      {isCurrencyModalOpen && (() => {
        const isMultiCurrencyTarget =
          currencyTarget === 'inventory_add' ||
          currencyTarget === 'online_retail_add' ||
          currencyTarget === 'online_menu_add' ||
          currencyTarget === 'item_edit_currencies';

        const activeMultiSelectedList: string[] =
          currencyTarget === 'inventory_add'
            ? newItemCurrencies
            : currencyTarget === 'online_retail_add'
              ? onlineRetailCurrencies
              : currencyTarget === 'online_menu_add'
                ? onlineDishCurrencies
                : currencyTarget === 'item_edit_currencies' && selectedItemForModal
                  ? getItemAcceptedCurrencies(selectedItemForModal)
                  : [];

        let candidateCurrencies = allFinalCurrencies;
        if (currencyTarget === 'checkout') {
          candidateCurrencies = relevantMerchantCurrencies;
        } else if (currencyTarget === 'takeout' && viewingLocation) {
          candidateCurrencies = getCustomerRelevantCurrenciesForLoc(viewingLocation);
        } else if (currencyTarget === 'loc_checkout' && currencyTargetLocId) {
          const targetLoc = locations.find(l => l.id === currencyTargetLocId);
          if (targetLoc) {
            candidateCurrencies = getCustomerRelevantCurrenciesForLoc(targetLoc);
          }
        }

        return (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-left animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-500" />
                <div>
                  <h3 className="font-serif-lux text-base font-bold text-neutral-900">
                    {isMultiCurrencyTarget
                      ? `Select Up to 5 Final Currencies (${activeMultiSelectedList.length}/5)`
                      : 'Select Settlement Final Currency'}
                  </h3>
                  {!isMultiCurrencyTarget && (currencyTarget === 'checkout' || currencyTarget === 'takeout' || currencyTarget === 'loc_checkout') && (
                    <p className="text-[11px] text-neutral-500">
                      Showing only relevant currencies accepted by cart items
                    </p>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCurrencyModalOpen(false)}
                className="w-7 h-7 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                placeholder="Search symbol (e.g. AFNL, NEBL), name, or creator..."
                value={currencyModalSearch}
                onChange={(e) => setCurrencyModalSearch(e.target.value)}
                autoFocus
                className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900"
              />
            </div>

            <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
              {candidateCurrencies
                .filter(c =>
                  c.symbol.toLowerCase().includes(currencyModalSearch.toLowerCase()) ||
                  c.name.toLowerCase().includes(currencyModalSearch.toLowerCase()) ||
                  (c.creatorHandle && c.creatorHandle.toLowerCase().includes(currencyModalSearch.toLowerCase()))
                )
                .map(coin => {
                  const isChecked = isMultiCurrencyTarget && activeMultiSelectedList.includes(coin.symbol);
                  return (
                  <button
                    key={coin.symbol}
                    type="button"
                    onClick={() => {
                      if (currencyTarget === 'inventory_add') {
                        setNewItemCurrencies(prev => toggleCurrencyInList(prev, coin.symbol, 5));
                        return;
                      }
                      if (currencyTarget === 'online_retail_add') {
                        setOnlineRetailCurrencies(prev => toggleCurrencyInList(prev, coin.symbol, 5));
                        return;
                      }
                      if (currencyTarget === 'online_menu_add') {
                        setOnlineDishCurrencies(prev => toggleCurrencyInList(prev, coin.symbol, 5));
                        return;
                      }
                      if (currencyTarget === 'item_edit_currencies' && selectedItemForModal) {
                        handleToggleModalItemCurrency(selectedItemForModal, coin.symbol);
                        return;
                      }
                      if (currencyTarget === 'checkout') setCheckoutCurrency(coin.symbol);
                      else if (currencyTarget === 'takeout') setTakeoutPaymentCurrency(coin.symbol);
                      else if (currencyTarget === 'loc_checkout' && currencyTargetLocId) {
                        setCustomerCurrencyByLoc(prev => ({ ...prev, [currencyTargetLocId]: coin.symbol }));
                        setCurrencyTargetLocId(null);
                      }
                      else if (currencyTarget === 'retail_delivery_fee' || currencyTarget === 'restaurant_delivery_fee') {
                        updateActiveLocationField({ deliveryFeeCurrency: coin.symbol });
                      }
                      else if (currencyTarget === 'new_loc_delivery_fee') {
                        setNewLocDeliveryFeeCurrency(coin.symbol);
                      }
                      setIsCurrencyModalOpen(false);
                    }}
                    className={`w-full p-3 rounded-2xl border flex items-center justify-between text-left transition-colors cursor-pointer ${
                      isChecked
                        ? 'border-indigo-500 bg-indigo-50/70'
                        : 'border-neutral-200/80 hover:border-amber-400 hover:bg-amber-50/50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xl p-1.5 rounded-xl bg-neutral-100">{coin.icon}</span>
                      <div>
                        <span className="font-bold text-xs text-neutral-900 font-mono">{coin.symbol} (Final Currency)</span>
                        <p className="text-[11px] text-neutral-500">
                          {coin.name}{coin.creatorHandle ? ` • Issued by @${coin.creatorHandle}` : ''}
                        </p>
                      </div>
                    </div>
                    {isMultiCurrencyTarget ? (
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md ${
                        isChecked ? 'bg-indigo-600 text-white' : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        {isChecked ? 'Selected' : '+ Add'}
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                        1:1 Parity
                      </span>
                    )}
                  </button>
                  );
                })}
            </div>

            {isMultiCurrencyTarget && (
              <button
                type="button"
                onClick={() => setIsCurrencyModalOpen(false)}
                className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-bold cursor-pointer"
              >
                Done ({activeMultiSelectedList.length}/5 Selected)
              </button>
            )}
          </div>
        </div>
        );
      })()}

      {/* 5. CHECKOUT SETTLEMENT MODAL */}
      {isCheckoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6 text-left animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <h3 className="font-serif-lux text-lg font-bold text-neutral-900">Final Currency Settlement</h3>
              <button
                type="button"
                onClick={() => setIsCheckoutModalOpen(false)}
                className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-600">
                  <span>Order Items ({cart.reduce((s, i) => s + i.quantity, 0)} items)</span>
                  <span className="font-mono font-bold text-neutral-900">{subtotal.toLocaleString()} FC</span>
                </div>
                <div className="flex items-center justify-between text-xs text-neutral-600">
                  <span>Tax &amp; Tip</span>
                  <span className="font-mono font-bold text-neutral-900">{(tax + tip).toLocaleString()} FC</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-neutral-200 text-base font-extrabold text-neutral-900">
                  <span>Total Amount Due</span>
                  <span className="font-mono text-emerald-700">
                    {total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} Final Coins
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-700">Choose Settlement Final Currency:</label>
                  <span className="text-[11px] font-mono font-bold text-emerald-700">
                    {relevantMerchantCurrencies.length} Relevant {relevantMerchantCurrencies.length === 1 ? 'Currency' : 'Currencies'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {relevantMerchantCurrencies.map(c => (
                    <button
                      key={c.symbol}
                      type="button"
                      onClick={() => setCheckoutCurrency(c.symbol)}
                      className={`p-3 rounded-2xl border text-xs font-bold flex items-center gap-2 cursor-pointer ${
                        checkoutCurrency === c.symbol ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-neutral-800 border-neutral-200 hover:bg-neutral-50'
                      }`}
                    >
                      <span>{c.icon}</span>
                      <span className="truncate">{c.symbol} (Final Currency)</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCheckoutModalOpen(false)}
                  className="flex-1 py-3 bg-neutral-100 text-neutral-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isProcessingPayment}
                  onClick={handleProcessPayment}
                  className="flex-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isProcessingPayment ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  <span>Confirm &amp; Settle ({total.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 2})} {checkoutCurrency})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. TAKEOUT ORDER CONFIRMED MODAL */}
      {isTakeoutSuccessModalOpen && lastTakeoutOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl space-y-5 text-center">
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-2xl">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="font-serif-lux text-xl font-bold text-neutral-900">Order Received!</h3>
              <p className="text-xs text-neutral-500 font-mono">Order #{lastTakeoutOrder.orderNumber} • Synced to Tax Ledger</p>
              <p className="text-xs text-neutral-600 mt-2">
                {lastTakeoutOrder.deliveryAddress
                  ? <>Your online order is confirmed with <span className="font-bold">{lastTakeoutOrder.restaurantName}</span> for delivery to your selected address. You will receive live notifications at every stage.</>
                  : <>Your online order is confirmed with <span className="font-bold">{lastTakeoutOrder.restaurantName}</span>. Show this pickup QR code when picking up at the counter.</>}
              </p>
            </div>

            <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-2xl inline-block mx-auto">
              <QRCodeSVG
                value={`ff:takeout:order:${lastTakeoutOrder.orderNumber}:${lastTakeoutOrder.restaurantId}:${lastTakeoutOrder.total}:${lastTakeoutOrder.currency}`}
                size={160}
                level="M"
              />
            </div>

            <div className="p-3 bg-neutral-50 rounded-xl text-xs text-neutral-600 space-y-1">
              <p>Fulfillment: <span className="font-bold text-neutral-900">{lastTakeoutOrder.pickupTime}</span></p>
              {lastTakeoutOrder.customerPhone && (
                <p className="text-[11px] text-neutral-500">
                  Contact Phone: <span className="font-mono font-semibold text-neutral-800">{lastTakeoutOrder.customerPhone}</span>
                </p>
              )}
              {lastTakeoutOrder.deliveryAddress && (
                <p className="text-[11px] text-neutral-500">
                  Recipient: <span className="font-semibold text-neutral-800">{lastTakeoutOrder.deliveryAddress.fullName}</span>
                  {lastTakeoutOrder.deliveryAddress.phone ? ` • ${lastTakeoutOrder.deliveryAddress.phone}` : ''}
                  {lastTakeoutOrder.deliveryAddress.email ? ` • ${lastTakeoutOrder.deliveryAddress.email}` : ''}
                </p>
              )}
              {lastTakeoutOrder.deliveryFee !== undefined && lastTakeoutOrder.deliveryFee > 0 && (
                <p className="text-[11px] text-neutral-600">
                  Delivery Fee ({lastTakeoutOrder.deliveryDistance ?? 0} {lastTakeoutOrder.deliveryDistanceUnit || 'mile'}):{' '}
                  <span className="font-bold font-mono text-indigo-700">
                    {lastTakeoutOrder.deliveryFee.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {lastTakeoutOrder.deliveryFeeCurrency || lastTakeoutOrder.currency}
                  </span>
                </p>
              )}
              <p>Amount Paid: <span className="font-bold font-mono text-emerald-700">{lastTakeoutOrder.total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} {lastTakeoutOrder.currency}</span></p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  const isRet = lastTakeoutOrder.orderNumber.startsWith('ORD-RET-');
                  setIsTakeoutSuccessModalOpen(false);
                  setViewingLocation(null);
                  setMainTab('directory');
                  setCustomerSubTab(isRet ? 'retail' : 'restaurants');
                  setCustomerOrderStatusFilter('all');
                  setExplorerSectionView('online_orders');
                }}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Track Online Orders
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsTakeoutSuccessModalOpen(false);
                  setViewingLocation(null);
                }}
                className="w-full py-2.5 bg-neutral-900 hover:bg-black text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. ADD TABLE MODAL */}
      {isAddTableModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-4 text-left">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
              <h3 className="font-bold text-sm text-neutral-900">Add Table Station ({tablesList.length}/100)</h3>
              <button
                type="button"
                onClick={() => setIsAddTableModalOpen(false)}
                className="w-7 h-7 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600 cursor-pointer"
              >
                &times;
              </button>
            </div>

            {tableError && <p className="text-xs text-rose-600 font-bold bg-rose-50 p-2 rounded-xl">{tableError}</p>}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newTableName.trim()) return;
                if (tablesList.length >= 100) {
                  setTableError('Maximum 100 tables reached for this restaurant.');
                  return;
                }
                const formatted = newTableNumber.trim() ? `Table ${newTableNumber.trim()} (${newTableName.trim()})` : newTableName.trim();
                const updated = [...tablesList, formatted];
                setTablesByLoc(prev => {
                  const nextMap = { ...prev, [activeLocationId]: updated };
                  try { localStorage.setItem(`final_finance_pos_tables_map_${merchantId}`, JSON.stringify(nextMap)); } catch {}
                  return nextMap;
                });
                setSelectedTable(formatted);
                setNewTableName('');
                setNewTableNumber('');
                setIsAddTableModalOpen(false);
              }}
              className="space-y-3"
            >
              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-700">Table Number</label>
                <input
                  type="number"
                  placeholder="e.g. 5, 12, 42 (up to 100)"
                  min={1}
                  max={100}
                  value={newTableNumber}
                  onChange={(e) => setNewTableNumber(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-neutral-700">Table Name / Area *</label>
                <input
                  type="text"
                  placeholder="e.g. Patio Booth, Rooftop VIP"
                  value={newTableName}
                  onChange={(e) => setNewTableName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs text-neutral-900"
                  required
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddTableModalOpen(false)}
                  className="flex-1 py-2 rounded-xl bg-neutral-100 text-neutral-700 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer"
                >
                  Save Table
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. RETAIL BARCODE SCANNER MODAL (Camera BarcodeDetector + USB/Manual Barcode Entry) */}
      {isBarcodeScannerOpen && (() => {
        const storeItemsWithBarcodes = getMergedLocationItems(activeLocation)
          .map(({ item }) => ({ item, bc: getItemBarcode(item) }))
          .filter(entry => !!entry.bc);
        return (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-center animate-in fade-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
                <div className="flex items-center gap-2">
                  <ScanBarcode className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-serif-lux text-base font-bold text-neutral-900">
                    Scan Product Barcode
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    stopBarcodeCamera();
                    setIsBarcodeScannerOpen(false);
                  }}
                  className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600 cursor-pointer"
                  aria-label="Close barcode scanner"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-neutral-600">
                Scan a retail item barcode with your device camera or USB/Bluetooth barcode scanner to add it directly to{' '}
                <span className="font-bold text-neutral-900">{activeLocation.name}</span> checkout.
              </p>

              {/* Camera Live Scan Box */}
              <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2.5">
                {isCameraScanning ? (
                  <div className="space-y-2">
                    <div className="relative rounded-xl overflow-hidden bg-black aspect-video border border-neutral-300">
                      <video
                        ref={barcodeVideoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 h-0.5 bg-emerald-400/80 shadow-xs" />
                    </div>
                    <button
                      type="button"
                      onClick={stopBarcodeCamera}
                      className="w-full py-2 rounded-xl bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold cursor-pointer"
                    >
                      Stop Camera
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={startBarcodeCamera}
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Start Camera Barcode Scanner</span>
                  </button>
                )}

                {cameraScanError && (
                  <p className="text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
                    {cameraScanError}
                  </p>
                )}
              </div>

              {/* USB / Keyboard Wedge / Manual Barcode Input */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleProcessScannedBarcode(barcodeScanInput);
                }}
                className="space-y-2"
              >
                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block">
                  USB Scanner / Manual Barcode Entry
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    autoFocus
                    placeholder="Scan or enter barcode (e.g. 7612345000018)"
                    value={barcodeScanInput}
                    onChange={(e) => setBarcodeScanInput(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-300 text-xs font-mono text-neutral-900 text-center"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shrink-0"
                  >
                    Add
                  </button>
                </div>
              </form>

              {barcodeScanFeedback && (
                <div className={`text-xs font-bold px-3 py-2 rounded-xl border ${
                  barcodeScanFeedback.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : barcodeScanFeedback.type === 'error'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : 'bg-indigo-50 text-indigo-800 border-indigo-200'
                }`}>
                  {barcodeScanFeedback.message}
                </div>
              )}

              {/* Quick Store Inventory Barcodes */}
              {storeItemsWithBarcodes.length > 0 && (
                <div className="pt-2 border-t border-neutral-100 space-y-2 text-left">
                  <span className="text-[10px] font-bold uppercase font-mono text-neutral-400 block text-center">
                    Active Store Item Barcodes (Tap to Scan &amp; Add)
                  </span>
                  <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                    {storeItemsWithBarcodes.map(({ item, bc }) => (
                      <button
                        key={`qs-bc-${item.id}`}
                        type="button"
                        onClick={() => handleProcessScannedBarcode(bc)}
                        className="w-full p-2 rounded-xl bg-neutral-50 hover:bg-indigo-50 border border-neutral-200 hover:border-indigo-300 flex items-center justify-between gap-2 text-xs cursor-pointer transition-colors"
                      >
                        <span className="font-bold text-neutral-900 truncate">{item.name}</span>
                        <span className="font-mono text-[11px] font-bold text-indigo-700 shrink-0 flex items-center gap-1">
                          <Barcode className="w-3.5 h-3.5" />
                          {bc}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={() => {
                  stopBarcodeCamera();
                  setIsBarcodeScannerOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-black text-white text-xs font-bold cursor-pointer"
              >
                Done Scanning ({cart.reduce((s, c) => s + c.quantity, 0)} in ticket)
              </button>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
