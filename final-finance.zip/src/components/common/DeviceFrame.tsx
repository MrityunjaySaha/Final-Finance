import React, { useState, useEffect } from 'react';
import { useApp, DeviceMode } from '../../context/AppContext';
import { 
  Wifi, 
  Battery, 
  Signal, 
  Apple, 
  Smartphone, 
  Tablet,
  RefreshCw, 
  Lock, 
  Unlock, 
  Bell, 
  Info,
  Sparkles,
  QrCode,
  Zap,
  HelpCircle,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DeviceFrameProps {
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children }) => {
  const { deviceMode, setDeviceMode } = useApp();
  const [systemTime, setSystemTime] = useState('09:41');
  const [batteryLevel, setBatteryLevel] = useState(88);
  const [isFaceIDVerifying, setIsFaceIDVerifying] = useState(false);
  const [faceIDStatus, setFaceIDStatus] = useState<'idle' | 'success' | 'failed'>('idle');
  const [notifications, setNotifications] = useState<{ id: string; title: string; text: string }[]>([]);
  const [showHapticIndicator, setShowHapticIndicator] = useState(false);
  const [hapticMessage, setHapticMessage] = useState('Tactile feedback');
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');

  // Live system clock synchronization
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12; // 12-hour format
      setSystemTime(`${hours}:${minutes} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000); // Update every 30s
    return () => clearInterval(interval);
  }, []);

  const triggerHaptic = (msg: string) => {
    setHapticMessage(msg);
    setShowHapticIndicator(true);
    if ('vibrate' in navigator) {
      navigator.vibrate(60);
    }
    setTimeout(() => setShowHapticIndicator(false), 1200);
  };

  const simulateFaceID = () => {
    if (isFaceIDVerifying) return;
    setIsFaceIDVerifying(true);
    setFaceIDStatus('idle');
    triggerHaptic('Initializing Secure Enclave Biometrics...');
    
    setTimeout(() => {
      // Simulate success 90% of the time
      const success = Math.random() > 0.1;
      if (success) {
        setFaceIDStatus('success');
        triggerHaptic('Biometrics Authenticated!');
        sendPushNotification('Secure Enclave', 'Biometric login succeeded. Token refreshed.');
      } else {
        setFaceIDStatus('failed');
        triggerHaptic('Biometrics failed. Please enter PIN.');
      }
      setIsFaceIDVerifying(false);
      setTimeout(() => setFaceIDStatus('idle'), 2500);
    }, 1500);
  };

  const sendPushNotification = (title: string, text: string) => {
    const newNotif = { id: String(Date.now()), title, text };
    setNotifications((prev) => [newNotif, ...prev].slice(0, 3));
    triggerHaptic('New Push Notification Received');
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter(n => n.id !== id));
  };

  if (deviceMode === 'web') {
    return <>{children}</>;
  }

  const isIOS = deviceMode === 'ios';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col lg:flex-row relative overflow-x-hidden selection:bg-amber-500/30 selection:text-amber-300">
      
      {/* BACKGROUND DECORATIONS */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(245,158,11,0.08),transparent_50%)] pointer-events-none" />
      <div className="absolute top-0 left-0 right-0 h-px bg-linear-to-r from-transparent via-slate-800 to-transparent pointer-events-none" />
      
      {/* 1. COMPREHENSIVE TESTING LAB DASHBOARD (Left panel on Desktop, stacked on mobile) */}
      <div className="w-full lg:w-[420px] shrink-0 border-b lg:border-b-0 lg:border-r border-slate-800/80 bg-slate-900/40 p-6 flex flex-col justify-between relative z-10 backdrop-blur-xs">
        <div className="space-y-6">
          {/* Logo Brand Header */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-linear-to-tr from-amber-500 to-amber-300 text-slate-950 flex items-center justify-center font-serif font-black text-lg shadow-amber-500/10 shadow-lg">
              FF
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-serif text-sm font-bold tracking-wider text-white">FINAL FINANCE</span>
                <span className="px-1.5 py-0.5 rounded-md bg-amber-500/15 text-[9px] font-bold text-amber-400 border border-amber-500/20 font-mono">LAB</span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono">Native App Simulation Sandbox v3.5</p>
            </div>
          </div>

          <div className="h-px bg-slate-800/60" />

          {/* Quick Config Toggles */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest font-mono">Device Framework</span>
              <span className="text-[10px] text-emerald-400 font-semibold font-mono flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Simulating Native Container
              </span>
            </div>

            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => {
                  setDeviceMode('ios');
                  triggerHaptic('Switched to Apple iPhone Frame');
                }}
                className={`flex flex-col items-center justify-center gap-1.5 py-2.5 rounded-xl border text-[10px] font-semibold transition-all cursor-pointer ${
                  deviceMode === 'ios'
                    ? 'bg-white text-slate-950 border-white font-bold shadow-md'
                    : 'bg-slate-900/60 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <Apple className="w-3.5 h-3.5" />
                <span>iPhone</span>
              </button>

              <button
                onClick={() => {
                  setDeviceMode('tablet');
                  triggerHaptic('Switched to Apple iPad Frame');
                }}
                className={`flex flex-col items-center justify-center gap-1.5 py-2.5 rounded-xl border text-[10px] font-semibold transition-all cursor-pointer ${
                  deviceMode === 'tablet'
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-md'
                    : 'bg-slate-900/60 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <Tablet className="w-3.5 h-3.5" />
                <span>iPad</span>
              </button>

              <button
                onClick={() => {
                  setDeviceMode('android');
                  triggerHaptic('Switched to Google Pixel Frame');
                }}
                className={`flex flex-col items-center justify-center gap-1.5 py-2.5 rounded-xl border text-[10px] font-semibold transition-all cursor-pointer ${
                  deviceMode === 'android'
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold shadow-md'
                    : 'bg-slate-900/60 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Pixel</span>
              </button>
            </div>
          </div>

          {/* Core Testing Commands */}
          <div className="space-y-3 p-4 rounded-2xl bg-slate-950/40 border border-slate-800/80">
            <h4 className="text-[11px] font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Simulate Native Features</span>
            </h4>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={simulateFaceID}
                disabled={isFaceIDVerifying}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-[10px] text-left transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Lock className="w-3 h-3 text-amber-400" />
                <span>{isFaceIDVerifying ? 'Scanning...' : 'Trigger FaceID'}</span>
              </button>

              <button
                onClick={() => {
                  const prices = ['$AAPL rally', 'Gold vault confirmed', 'BTC premium increase', 'Zurich collateral settled'];
                  const rand = prices[Math.floor(Math.random() * prices.length)];
                  sendPushNotification('Market Bulletin', `System Notice: ${rand}`);
                }}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-[10px] text-left transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Bell className="w-3 h-3 text-blue-400" />
                <span>Push Alert</span>
              </button>

              <button
                onClick={() => {
                  setBatteryLevel(prev => prev > 15 ? prev - 12 : 99);
                  triggerHaptic('Battery status altered');
                }}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-[10px] text-left transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Battery className="w-3 h-3 text-emerald-400" />
                <span>Drain Battery</span>
              </button>

              <button
                onClick={() => {
                  setOrientation(prev => prev === 'portrait' ? 'portrait' : 'portrait');
                  triggerHaptic('Device frame locked in portrait view');
                }}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-[10px] text-left transition-colors flex items-center gap-2 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3 text-slate-400" />
                <span>Lock Portrait</span>
              </button>
            </div>
          </div>

          {/* QR Code and App Installer Module */}
          <div className="p-4 rounded-2xl bg-amber-500/5 border border-amber-500/10 space-y-3">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 shrink-0 border border-amber-500/20">
                <QrCode className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-amber-400 font-serif">Capacitor Mobile Native</h4>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-0.5">
                  Build native binaries directly! The source is 100% compiled with Capacitor iOS &amp; Android.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 font-mono text-[9px] text-slate-400">
              <span className="text-amber-500 font-bold">npx cap sync</span>
              <span className="text-slate-500">•</span>
              <span>npm run build</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
              <Info className="w-3.5 h-3.5 text-slate-400" />
              <span>Developer Diagnostics</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Touch haptics and swipe gestures are actively simulated on click triggers. Scroll and pull actions trigger simulated tactile feedback in the console.
            </p>
          </div>
        </div>

        {/* Lab Footer */}
        <div className="pt-6 mt-6 lg:mt-0 border-t border-slate-800/50 flex items-center justify-between text-[10px] text-slate-500 font-mono">
          <span>Final Finance Lab</span>
          <button
            onClick={() => {
              setDeviceMode('web');
              triggerHaptic('Returned to Desktop Web view');
            }}
            className="text-amber-500 hover:underline flex items-center gap-1 cursor-pointer font-bold"
          >
            <span>Exit Lab</span>
            <span>&rarr;</span>
          </button>
        </div>
      </div>

      {/* 2. THE MAIN SIMULATOR VIEW (Centered) */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-8 bg-slate-950 relative min-h-[600px] lg:min-h-screen">
        
        {/* Floating Switch Back To Desktop Button */}
        <div className="absolute top-4 right-4 z-40 hidden md:flex items-center gap-2">
          <button
            onClick={() => setDeviceMode('web')}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold rounded-xl border border-slate-800 flex items-center gap-1.5 shadow-lg transition-all cursor-pointer"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Switch to Desktop Web</span>
          </button>
        </div>

        {/* IN-VIEW SIMULATED HAPTIC Tactile Flash Overlay */}
        <AnimatePresence>
          {showHapticIndicator && (
            <motion.div 
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full bg-amber-500 text-slate-950 text-xs font-bold font-mono shadow-xl flex items-center gap-2 border border-amber-300"
            >
              <Zap className="w-3.5 h-3.5 fill-slate-950 animate-pulse" />
              <span>{hapticMessage}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ACTIVE SIMULATOR SHELL */}
        <div className="relative select-none transition-all duration-300">
          
          {/* HARDWARE BEZELS AND INNER SCREEN FRAME */}
          {deviceMode === 'tablet' ? (
            /* ================= APPLE iPAD PRO SIMULATOR SHELL ================= */
            <div className="w-[720px] h-[960px] rounded-[36px] bg-slate-900 border-[12px] border-slate-800 ring-4 ring-slate-700/40 shadow-[0_25px_65px_-12px_rgba(0,0,0,0.85)] relative flex flex-col overflow-hidden">
              {/* iPad top ambient light sensor / front camera hole */}
              <div className="absolute top-[5px] left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-slate-950 border border-slate-900/60 z-50 pointer-events-none" />
              
              {/* iPad status bar */}
              <div className="h-8 bg-white border-b border-slate-100 flex items-center justify-between px-6 text-slate-900 font-bold text-[10px] z-40 select-none shrink-0">
                <span className="tracking-tight">{systemTime.split(' ')[0]}</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] font-semibold text-slate-400 font-mono">iPad Pro</span>
                  <Signal className="w-3 h-3" />
                  <Wifi className="w-3 h-3" />
                  <div className="flex items-center gap-0.5">
                    <span>{batteryLevel}%</span>
                    <Battery className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>

              {/* ACTIVE APPLICATION EMBED VIEW */}
              <div className="flex-1 w-full bg-slate-50 overflow-hidden relative flex flex-col">
                <div className="flex-1 overflow-y-auto overflow-x-hidden mobile-scroll-container">
                  {children}
                </div>
              </div>

              {/* APPLE HOME INDICATOR BAR */}
              <div className="h-4 bg-white flex items-center justify-center z-40 shrink-0">
                <div className="w-[140px] h-[4px] bg-slate-950 rounded-full" />
              </div>
            </div>
          ) : isIOS ? (
            /* ================= APPLE IPHONE 16 PRO SIMULATOR SHELL ================= */
            <div className="w-[393px] h-[835px] rounded-[58px] bg-slate-900 border-[10px] border-slate-800 ring-4 ring-slate-700/50 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] relative flex flex-col overflow-hidden">
              
              {/* iPhone Hardware Silent Switch, Volume & Side Action buttons */}
              <div className="absolute -left-[13px] top-[140px] w-[3px] h-[28px] bg-slate-800 rounded-r-lg border-r border-slate-700" />
              <div className="absolute -left-[13px] top-[190px] w-[3px] h-[55px] bg-slate-800 rounded-r-lg border-r border-slate-700" />
              <div className="absolute -left-[13px] top-[260px] w-[3px] h-[55px] bg-slate-800 rounded-r-lg border-r border-slate-700" />
              <div className="absolute -right-[13px] top-[210px] w-[3px] h-[75px] bg-slate-800 rounded-l-lg border-l border-slate-700" />

              {/* DYNAMIC ISLAND NOTCH */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-[110px] h-[30px] rounded-full bg-black z-50 flex items-center justify-between px-3.5 shadow-inner">
                {/* Dynamic island interactive camera lens / sensors */}
                <div className="w-3 h-3 rounded-full bg-slate-950/80 border border-slate-900/40" />
                
                {/* FaceID animation micro-trigger or status icon */}
                <AnimatePresence mode="wait">
                  {isFaceIDVerifying ? (
                    <motion.div 
                      key="verifying"
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                      className="w-4 h-4 rounded-full border border-dashed border-amber-400"
                    />
                  ) : faceIDStatus === 'success' ? (
                    <motion.span key="success" initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-[10px] text-emerald-400 font-bold">✓</motion.span>
                  ) : faceIDStatus === 'failed' ? (
                    <motion.span key="failed" initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-[10px] text-rose-400 font-bold">✕</motion.span>
                  ) : (
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />
                  )}
                </AnimatePresence>
              </div>

              {/* APPLE STATUS BAR */}
              <div className="h-11 bg-white border-b border-slate-100 flex items-end justify-between px-7 pb-1.5 text-slate-950 font-semibold text-xs z-40 select-none shrink-0">
                <span className="font-semibold text-[11px] tracking-tight">{systemTime.split(' ')[0]}</span>
                <div className="flex items-center gap-1.5">
                  <Signal className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-mono font-bold">5G</span>
                  <Wifi className="w-3.5 h-3.5" />
                  <div className="flex items-center gap-0.5">
                    <span className="text-[9px] font-bold font-mono">{batteryLevel}%</span>
                    <Battery className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* NATIVE PUSH NOTIFICATION SIMULATOR SHELL (Floating over app) */}
              <div className="absolute top-12 left-2 right-2 z-50 pointer-events-none space-y-1.5">
                <AnimatePresence>
                  {notifications.map((notif) => (
                    <motion.div
                      key={notif.id}
                      initial={{ opacity: 0, y: -50, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      onClick={() => dismissNotification(notif.id)}
                      className="pointer-events-auto bg-slate-900/95 border border-slate-800 text-white rounded-2xl p-3 shadow-2xl flex items-start gap-2.5 backdrop-blur-md cursor-pointer hover:bg-slate-850 transition-colors"
                    >
                      <div className="w-7 h-7 rounded-lg bg-linear-to-tr from-amber-500 to-amber-300 text-slate-950 flex items-center justify-center font-serif font-black text-xs shrink-0 shadow-sm">
                        FF
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[10px] font-bold text-amber-400 font-serif">{notif.title}</span>
                          <span className="text-[8px] text-slate-500 font-mono">now</span>
                        </div>
                        <p className="text-[10px] text-slate-300 font-medium leading-normal mt-0.5">{notif.text}</p>
                      </div>
                      <button className="text-slate-500 hover:text-white p-0.5">
                        <X className="w-3 h-3" />
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* ACTIVE APPLICATION EMBED VIEW */}
              <div className="flex-1 w-full bg-slate-50 overflow-hidden relative flex flex-col">
                <div className="flex-1 overflow-y-auto overflow-x-hidden mobile-scroll-container">
                  {children}
                </div>
              </div>

              {/* APPLE HOME INDICATOR */}
              <div className="h-6 bg-white flex items-center justify-center z-40 shrink-0">
                <div className="w-[130px] h-[5px] bg-slate-950 rounded-full" />
              </div>

            </div>
          ) : (
            /* ================= GOOGLE PIXEL 9 PRO SIMULATOR SHELL ================= */
            <div className="w-[393px] h-[835px] rounded-[44px] bg-slate-950 border-[10px] border-slate-900 ring-4 ring-emerald-950/20 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.85)] relative flex flex-col overflow-hidden">
              
              {/* Pixel Hardware Power & Volume Rockers */}
              <div className="absolute -right-[13px] top-[140px] w-[3px] h-[45px] bg-slate-900 rounded-l-md border-l border-slate-800" />
              <div className="absolute -right-[13px] top-[200px] w-[3px] h-[65px] bg-slate-900 rounded-l-md border-l border-slate-800" />

              {/* PIXEL PUNCH HOLE CAMERA */}
              <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-[16px] h-[16px] rounded-full bg-black z-50 border border-slate-900/60" />

              {/* GOOGLE ANDROID STATUS BAR */}
              <div className="h-9 bg-white border-b border-slate-100 flex items-center justify-between px-6 text-slate-900 font-medium text-xs z-40 shrink-0 select-none">
                <span className="font-bold text-[10px] font-mono tracking-tight">{systemTime}</span>
                <div className="flex items-center gap-1.5">
                  <Signal className="w-3.5 h-3.5" />
                  <span className="text-[9px] font-mono font-bold">LTE</span>
                  <Wifi className="w-3.5 h-3.5" />
                  <div className="flex items-center gap-0.5">
                    <span className="text-[9px] font-bold font-mono">{batteryLevel}%</span>
                    <Battery className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* GOOGLE ANDROID PUSH NOTIFICATION SIMULATOR SHELL */}
              <div className="absolute top-10 left-2 right-2 z-50 pointer-events-none space-y-1.5">
                <AnimatePresence>
                  {notifications.map((notif) => (
                    <motion.div
                      key={notif.id}
                      initial={{ opacity: 0, x: 100 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -100 }}
                      onClick={() => dismissNotification(notif.id)}
                      className="pointer-events-auto bg-slate-900 text-white rounded-xl p-3 shadow-xl flex items-start gap-3 border border-slate-800 cursor-pointer"
                    >
                      <div className="w-6 h-6 rounded-md bg-emerald-500 text-slate-950 flex items-center justify-center font-serif font-black text-[10px] shrink-0">
                        FF
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[10px] font-bold text-emerald-400 font-mono tracking-wide uppercase">{notif.title}</span>
                          <span className="text-[8px] text-slate-500 font-mono">1m</span>
                        </div>
                        <p className="text-[10px] text-slate-300 leading-normal mt-0.5">{notif.text}</p>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* ACTIVE APPLICATION EMBED VIEW */}
              <div className="flex-1 w-full bg-slate-50 overflow-hidden relative flex flex-col">
                <div className="flex-1 overflow-y-auto overflow-x-hidden mobile-scroll-container">
                  {children}
                </div>
              </div>

              {/* ANDROID NAVIGATION BAR BUTTONS */}
              <div className="h-11 bg-white border-t border-slate-100 flex items-center justify-around px-12 z-40 shrink-0">
                <button 
                  onClick={() => {
                    triggerHaptic('Android Back gesture simulated');
                    window.history.back();
                  }}
                  className="p-1 text-slate-400 hover:text-slate-900 active:scale-95 cursor-pointer"
                  title="Simulate Back"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M15 19l-7-7 7-7" /></svg>
                </button>
                <button 
                  onClick={() => {
                    triggerHaptic('Android Home button clicked');
                  }}
                  className="w-3.5 h-3.5 rounded-full border-[2.5px] border-slate-400 hover:border-slate-900 active:scale-95 cursor-pointer"
                  title="Simulate Home"
                />
                <button 
                  onClick={() => {
                    triggerHaptic('Android Recents panel simulated');
                  }}
                  className="w-3.5 h-3.5 rounded-[3px] border-[2.5px] border-slate-400 hover:border-slate-900 active:scale-95 cursor-pointer"
                  title="Simulate Recents"
                />
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};

interface MonitorProps {
  className?: string;
}

const Monitor: React.FC<MonitorProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="14" x="2" y="3" rx="2" />
    <line x1="8" x2="16" y1="21" y2="21" />
    <line x1="12" x2="12" y1="17" y2="21" />
  </svg>
);
