import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  X, 
  ShieldCheck, 
  Download, 
  ExternalLink, 
  ArrowUpRight, 
  ArrowDownRight,
  Briefcase,
  Building2,
  CreditCard,
  Wallet,
  Clock,
  Printer
} from 'lucide-react';
import { StockOrder } from '../../types/stocks';

interface TradeConfirmationModalProps {
  order: StockOrder | null;
  onClose: () => void;
  onViewPortfolio: () => void;
}

export const TradeConfirmationModal: React.FC<TradeConfirmationModalProps> = ({
  order,
  onClose,
  onViewPortfolio,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!order) return null;

  const isBuy = order.side === 'buy';
  const tradeSlipId = order.tradeSlipId || `SLIP-${(order.id || Date.now().toString()).slice(-8).toUpperCase()}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      <div 
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-lg rounded-3xl bg-white border border-slate-200 shadow-2xl overflow-hidden p-6 sm:p-8 my-auto"
        >
          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer z-10"
            title="Close (Esc)"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Success Header */}
          <div className="text-center pb-5 border-b border-slate-100">
            <div className="w-14 h-14 rounded-full bg-emerald-100 border-4 border-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold mb-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>SIPC Insured • Direct Market Execution</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-serif font-bold text-slate-900">
              {isBuy ? 'Stock Purchase Executed' : 'Stock Sale Executed'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Your order has been routed and cleared with zero brokerage commissions.
            </p>
          </div>

          {/* Formal Trade Confirmation Slip */}
          <div className="my-5 rounded-2xl bg-slate-50 border border-slate-200/80 p-4 sm:p-5 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 text-slate-500 font-sans">
              <span className="font-bold text-[11px] uppercase tracking-wider text-slate-700">Official Trade Confirmation</span>
              <span className="font-mono text-[10px] text-slate-400">Ref #{tradeSlipId}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-sans">Asset &amp; Ticker:</span>
              <div className="text-right">
                <span className="font-bold text-slate-900 font-sans block">{order.stockName}</span>
                <span className="text-[11px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded font-bold">${order.ticker}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-sans">Order Type &amp; Side:</span>
              <span className={`font-bold uppercase ${isBuy ? 'text-emerald-700' : 'text-rose-700'}`}>
                {order.side.toUpperCase()} ({order.orderType.toUpperCase()} ORDER)
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-sans">Shares Quantity:</span>
              <span className="font-bold text-slate-900">{order.shares} SHARES</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-sans">Execution Price:</span>
              <span className="font-bold text-slate-900">${order.price.toFixed(2)} USD</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-sans">Brokerage Commission:</span>
              <span className="font-bold text-emerald-700">$0.00 (100% Free)</span>
            </div>

            {/* Linked Bank / Card Payment Source */}
            <div className="pt-2 border-t border-slate-200 flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200">
              <div className="flex items-center gap-2">
                {order.paymentSource.type === 'bank_account' ? (
                  <Building2 className="w-4 h-4 text-blue-600" />
                ) : order.paymentSource.type === 'card' ? (
                  <CreditCard className="w-4 h-4 text-purple-600" />
                ) : (
                  <Wallet className="w-4 h-4 text-amber-600" />
                )}
                <div>
                  <span className="font-sans font-bold text-[11px] text-slate-800 block">
                    {order.paymentSource.label}
                  </span>
                  <span className="font-sans text-[10px] text-slate-400 block">
                    {order.paymentSource.subtitle}
                  </span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full uppercase">
                Debited
              </span>
            </div>

            <div className="pt-2 border-t border-slate-200 flex items-center justify-between font-bold text-sm text-slate-900">
              <span className="font-sans">Total Settled Amount:</span>
              <span className="text-base text-slate-900">
                ${order.totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
              </span>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400 font-sans pt-1">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Execution Time: {order.timestamp}</span>
              </span>
              <span>Clearing: Instant Continuous Net Settlement</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onViewPortfolio();
              }}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <Briefcase className="w-4 h-4" />
              <span>View in My Portfolio</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="w-full py-3 px-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.99] text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-slate-500" />
              <span>Print Trade Slip</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
