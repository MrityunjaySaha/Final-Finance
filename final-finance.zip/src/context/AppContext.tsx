import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  ReserveVault, 
  MarketplaceListing, 
  UserProfile, 
  CommunityPost, 
  Conversation, 
  Message, 
  GeneratedImageHistory,
  AssetClass,
  UniversalLedgerItem
} from '../types';
import { 
  INITIAL_VAULTS, 
  INITIAL_LISTINGS, 
  INITIAL_POSTS, 
  CURRENT_USER, 
  INITIAL_CONVERSATIONS, 
  INITIAL_MESSAGES,
  INITIAL_TRANSACTIONS
} from '../data/mockData';
import {
  recordLedgerTransaction,
  createLedgerItemFromVaultDeposit,
  createLedgerItemFromVaultWithdrawal
} from '../utils/universalLedgerBridge';
import {
  NotificationPreferences,
  getNotificationPreferences,
  saveNotificationPreferences,
  playNotificationChime,
  sendBrowserPushNotification,
  isCategoryEnabled,
  UniversalNotificationEventDetail,
  ChimeTone
} from '../utils/notificationService';

export type NavTab = 
  | 'landing'
  | 'dashboard'
  | 'vaults' 
  | 'ai_studio' 
  | 'marketplace' 
  | 'community' 
  | 'messages' 
  | 'social' 
  | 'stocks'
  | 'subsidies'
  | 'uploads' 
  | 'qrcodes'
  | 'wallets' 
  | 'settings' 
  | 'fundraising'
  | 'community_search' 
  | 'search_results'
  | 'user_profile'
  | 'admin'
  | 'superadmin'
  | 'portfolio'
  | 'holdings';

export type NotificationType = 
  | 'trade' 
  | 'stocks' 
  | 'vault' 
  | 'wallet' 
  | 'marketplace' 
  | 'social' 
  | 'chat' 
  | 'subsidies' 
  | 'fundraising' 
  | 'security' 
  | 'system' 
  | 'feedback'
  | 'loans';

export interface NotificationItem {
  id: string;
  title: string;
  description: string;
  time: string;
  read: boolean;
  type: NotificationType;
  targetTab?: string;
  targetId?: string;
  amount?: number;
  currency?: string;
  timestampIso?: string;
}

interface Toast {
  id: string;
  type: 'success' | 'info' | 'error' | 'gold';
  title: string;
  message: string;
}

export type DeviceMode = 'web' | 'ios' | 'android' | 'tablet';

interface AppContextType {
  deviceMode: DeviceMode;
  setDeviceMode: (mode: DeviceMode) => void;
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  currentUser: UserProfile;
  setCurrentUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  vaults: ReserveVault[];
  setVaults: React.Dispatch<React.SetStateAction<ReserveVault[]>>;
  listings: MarketplaceListing[];
  setListings: React.Dispatch<React.SetStateAction<MarketplaceListing[]>>;
  posts: CommunityPost[];
  setPosts: React.Dispatch<React.SetStateAction<CommunityPost[]>>;
  conversations: Conversation[];
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  messages: Record<string, Message[]>;
  imageHistory: GeneratedImageHistory[];
  addImageToHistory: (item: Omit<GeneratedImageHistory, 'id' | 'createdAt'>) => GeneratedImageHistory;
  transactions: UniversalLedgerItem[];
  addTransaction: (tx: Omit<UniversalLedgerItem, 'id' | 'timestamp' | 'dateIso' | 'cryptographicHash' | 'signature' | 'receiptNumber'>) => void;
  reverseTransaction: (id: string) => void;
  createListing: (listing: Omit<MarketplaceListing, 'id' | 'createdAt' | 'likes' | 'sellerId' | 'sellerName' | 'sellerHandle' | 'sellerAvatar' | 'sellerVerified'>) => MarketplaceListing;
  publishDraft: (draftId: string) => void;
  deleteListing: (id: string) => void;
  toggleLikeListing: (id: string) => void;
  buyOrSwapListing: (listing: MarketplaceListing, paymentVault: AssetClass) => boolean;
  createPost: (content: string, imageUrl?: string, imageMeta?: CommunityPost['imageMeta'], assetTag?: CommunityPost['assetTag']) => void;
  toggleLikePost: (postId: string) => void;
  addCommentToPost: (postId: string, commentText: string) => void;
  toggleFollowUser: (handle: string) => void;
  sendMessage: (conversationId: string, text: string, imageUrl?: string) => void;
  respondToTradeProposal: (conversationId: string, messageId: string, status: 'accepted' | 'declined') => void;
  startDirectConversation: (recipientName: string, recipientAvatar?: string, initialMessage?: string) => string;
  depositToVault: (vaultId: AssetClass, amountUSD: number, assetName: string) => void;
  withdrawFromVault: (vaultId: AssetClass, amountUSD: number) => boolean;
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
  stagedAssetForDraft: {
    imageUrl: string;
    title: string;
    description: string;
    category: AssetClass;
    imageResolution?: string;
    modelUsed?: string;
  } | null;
  setStagedAssetForDraft: (staged: {
    imageUrl: string;
    title: string;
    description: string;
    category: AssetClass;
    imageResolution?: string;
    modelUsed?: string;
  } | null) => void;
  notifications: NotificationItem[];
  setNotifications: React.Dispatch<React.SetStateAction<NotificationItem[]>>;
  addNotification: (
    notification: 
      | (Omit<Partial<NotificationItem>, 'id' | 'time' | 'read'> & { title: string; description: string; type?: NotificationType; showToast?: boolean; toastType?: 'success' | 'info' | 'error' | 'gold'; tone?: ChimeTone })
      | string,
    legacyTypeOrToast?: any
  ) => void;
  deleteNotification: (id: string) => void;
  clearAllNotifications: () => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  notificationPrefs: NotificationPreferences;
  updateNotificationPrefs: (prefs: Partial<NotificationPreferences>) => void;
  triggerTestNotification: (type?: NotificationType) => void;
  previousTab: NavTab | null;
  setPreviousTab: (tab: NavTab | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('web');
  const [currentTab, setCurrentTab] = useState<NavTab>(() => {
    console.log('AppProvider: Initializing currentTab');
    try {
      // Check if user has an active session -> route to appropriate landing/dashboard
      const hasSession = localStorage.getItem('final_finance_auth_session');
      if (hasSession) {
        const parsed = JSON.parse(hasSession);
        const email = parsed.email?.trim().toLowerCase();
        if (email === 'ranmaanimaker@gmail.com') return 'superadmin';
        if (email === 'awesomedbz@gmail.com') return 'admin';
        return 'marketplace';
      }
    } catch (e) {
      console.warn('AppProvider: Failed to parse auth session', e);
    }
    return 'landing';
  });
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    console.log('AppProvider: Initializing currentUser');
    try {
      const saved = localStorage.getItem('final_finance_user');
      return saved ? JSON.parse(saved) : CURRENT_USER;
    } catch (e) {
      console.warn('AppProvider: Failed to parse user profile', e);
      return CURRENT_USER;
    }
  });

  const [vaults, setVaults] = useState<ReserveVault[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_vaults');
      return saved ? JSON.parse(saved) : INITIAL_VAULTS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse vaults', e);
      return INITIAL_VAULTS;
    }
  });

  const [listings, setListings] = useState<MarketplaceListing[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_listings');
      return saved ? JSON.parse(saved) : INITIAL_LISTINGS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse listings', e);
      return INITIAL_LISTINGS;
    }
  });

  const [posts, setPosts] = useState<CommunityPost[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_posts');
      return saved ? JSON.parse(saved) : INITIAL_POSTS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse posts', e);
      return INITIAL_POSTS;
    }
  });

  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_convs');
      return saved ? JSON.parse(saved) : INITIAL_CONVERSATIONS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse conversations', e);
      return INITIAL_CONVERSATIONS;
    }
  });

  const [activeConversationId, setActiveConversationId] = useState<string>(() => {
    return INITIAL_CONVERSATIONS[0]?.id || 'conv-1';
  });

  const [messages, setMessages] = useState<Record<string, Message[]>>(() => {
    try {
      const saved = localStorage.getItem('final_finance_msgs');
      return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
    } catch (e) {
      console.warn('AppProvider: Failed to parse messages', e);
      return INITIAL_MESSAGES;
    }
  });

  const [imageHistory, setImageHistory] = useState<GeneratedImageHistory[]>(() => {
    const saved = localStorage.getItem('final_finance_image_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return [
      {
        id: 'img-hist-1',
        imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=1000&q=80',
        prompt: 'A monolithic 100oz pure 24k gold ingot engraved with Final Finance emblem, resting on dark titanium podium with soft amber studio lighting',
        model: 'gemini-3-pro-image-preview',
        aspectRatio: '1:1',
        imageSize: '4K',
        createdAt: '2 hours ago',
        category: 'final_coins'
      },
      {
        id: 'img-hist-2',
        imageUrl: 'https://images.unsplash.com/photo-1567899378494-47b22a2ae96a?auto=format&fit=crop&w=1000&q=80',
        prompt: 'Luxury 65m black-hulled megayacht moored in Monaco harbor at twilight with golden illuminated deck',
        model: 'gemini-3-pro-image-preview',
        aspectRatio: '16:9',
        imageSize: '2K',
        createdAt: '4 hours ago',
        category: 'barter'
      },
      {
        id: 'img-hist-3',
        imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1000&q=80',
        prompt: 'Futuristic cryptographic sovereign reserve token with embedded glowing emerald neon circuits and physical gold bezel',
        model: 'gemini-3.1-flash-image-preview',
        aspectRatio: '1:1',
        imageSize: '1K',
        createdAt: '8 hours ago',
        category: 'crypto'
      }
    ];
  });

  const [stagedAssetForDraft, setStagedAssetForDraft] = useState<{
    imageUrl: string;
    title: string;
    description: string;
    category: AssetClass;
    imageResolution?: string;
    modelUsed?: string;
  } | null>(null);

  const [toasts, setToasts] = useState<Toast[]>([]);

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('final_finance_notifications');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'notif-1',
        title: 'OTC Trade Proposal Received',
        description: 'Counterparty proposed 100oz Fine Gold for Switzerland Vault Allocation.',
        time: '12m ago',
        read: false,
        type: 'trade',
        targetTab: 'marketplace',
      },
      {
        id: 'notif-2',
        title: 'Vault Settlement Confirmed',
        description: 'Physical bullion reserve verified by Zurich Depository.',
        time: '1h ago',
        read: false,
        type: 'vault',
        targetTab: 'vaults',
      },
      {
        id: 'notif-3',
        title: 'Marketplace Listing Viewed',
        description: 'Your GPU cluster node listing received 4 new inquiries.',
        time: '3h ago',
        read: true,
        type: 'system',
        targetTab: 'uploads',
      },
    ];
  });

  const [previousTab, setPreviousTab] = useState<NavTab | null>(null);

  const [transactions, setTransactions] = useState<UniversalLedgerItem[]>(() => {
    const saved = localStorage.getItem('final_finance_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  // Sync with ledger update events
  useEffect(() => {
    const syncGlobalTransactions = () => {
      try {
        const saved = localStorage.getItem('final_finance_transactions');
        if (saved) {
          const parsed = JSON.parse(saved);
          setTransactions(parsed);
        }
      } catch (err) {
        console.warn('Failed to sync global transactions in AppContext', err);
      }
    };

    window.addEventListener('final_finance_global_transactions_updated', syncGlobalTransactions);
    window.addEventListener('final_finance_ledger_updated', syncGlobalTransactions);

    const handleAppNotificationEvent = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        addNotification(customEvent.detail);
      }
    };
    window.addEventListener('ff-app-notification', handleAppNotificationEvent);

    return () => {
      window.removeEventListener('final_finance_global_transactions_updated', syncGlobalTransactions);
      window.removeEventListener('final_finance_ledger_updated', syncGlobalTransactions);
      window.removeEventListener('ff-app-notification', handleAppNotificationEvent);
    };
  }, []);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('final_finance_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('final_finance_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('final_finance_vaults', JSON.stringify(vaults));
  }, [vaults]);

  useEffect(() => {
    localStorage.setItem('final_finance_listings', JSON.stringify(listings));
  }, [listings]);

  useEffect(() => {
    localStorage.setItem('final_finance_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('final_finance_convs', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem('final_finance_msgs', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('final_finance_image_history', JSON.stringify(imageHistory));
  }, [imageHistory]);

  useEffect(() => {
    localStorage.setItem('final_finance_notifications', JSON.stringify(notifications));
  }, [notifications]);

  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(() => {
    return getNotificationPreferences();
  });

  const updateNotificationPrefs = (newPrefs: Partial<NotificationPreferences>) => {
    const updated = { ...notificationPrefs, ...newPrefs };
    setNotificationPrefs(updated);
    saveNotificationPreferences(updated);
  };

  const addToast = useCallback((toast: Omit<Toast, 'id'>) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const addImageToHistory = (item: Omit<GeneratedImageHistory, 'id' | 'createdAt'>) => {
    const newEntry: GeneratedImageHistory = {
      ...item,
      id: 'img-' + Date.now(),
      createdAt: 'Just now',
    };
    setImageHistory((prev) => [newEntry, ...prev]);
    return newEntry;
  };

  const addNotification = useCallback((
    input: 
      | (Omit<Partial<NotificationItem>, 'id' | 'time' | 'read'> & { title: string; description: string; type?: NotificationType; showToast?: boolean; toastType?: 'success' | 'info' | 'error' | 'gold'; tone?: ChimeTone })
      | string,
    legacyArg?: any
  ) => {
    let title = '';
    let description = '';
    let type: NotificationType = 'system';
    let targetTab: string | undefined = undefined;
    let showToastBanner = true;
    let toastType: 'success' | 'info' | 'error' | 'gold' = 'info';
    let tone: ChimeTone | undefined = undefined;
    let targetId: string | undefined = undefined;
    let amount: number | undefined = undefined;
    let currency: string | undefined = undefined;

    if (typeof input === 'string') {
      title = input;
      description = typeof legacyArg === 'string' ? legacyArg : input;
      if (typeof legacyArg === 'string' && (legacyArg === 'error' || legacyArg === 'success' || legacyArg === 'info' || legacyArg === 'gold')) {
        toastType = legacyArg as any;
        description = input;
      }
    } else {
      title = input.title;
      description = input.description;
      type = input.type || 'system';
      targetTab = input.targetTab;
      targetId = input.targetId;
      amount = input.amount;
      currency = input.currency;
      showToastBanner = input.showToast !== false;
      toastType = input.toastType || (
        type === 'stocks' || type === 'trade' || type === 'vault' ? 'gold'
        : type === 'security' ? 'error'
        : 'info'
      );
      tone = input.tone;
    }

    // Check if category is enabled in notification preferences
    if (!isCategoryEnabled(type)) {
      return;
    }

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title,
      description,
      time: 'Just now',
      read: false,
      type,
      targetTab,
      targetId,
      amount,
      currency,
      timestampIso: new Date().toISOString(),
    };

    setNotifications((prev) => [newNotif, ...prev]);

    // Play synthesized Web Audio chime
    playNotificationChime(tone || (
      type === 'stocks' || type === 'trade' || type === 'vault' ? 'trade'
      : type === 'chat' || type === 'social' ? 'message'
      : type === 'security' ? 'alert'
      : 'default'
    ));

    // Send Browser Push Notification if permission is granted & enabled
    sendBrowserPushNotification(title, description, type);

    // Show floating toast banner if enabled
    if (showToastBanner && notificationPrefs.inAppBannerEnabled) {
      addToast({
        type: toastType,
        title,
        message: description,
      });
    }
  }, [addToast, notificationPrefs.inAppBannerEnabled]);

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const triggerTestNotification = (category: NotificationType = 'stocks') => {
    const testSamples: Record<NotificationType, { title: string; description: string; targetTab: string }> = {
      stocks: {
        title: '📈 Stock Order Executed: $HYPR',
        description: 'Successfully purchased 50 shares of Hyperion Energy at $142.50 via Final Coin settlement.',
        targetTab: 'stocks',
      },
      trade: {
        title: '🤝 OTC Barter Proposal Accepted',
        description: 'Titan Vaults accepted your physical 100oz Silver Bullion transfer offer.',
        targetTab: 'marketplace',
      },
      vault: {
        title: '🏦 Zurich Gold Reserve Deposited',
        description: 'Allocated +$25,000 to Physical Gold Depository with audited provenance.',
        targetTab: 'vaults',
      },
      wallet: {
        title: '💳 Final Coin Transfer Received',
        description: 'Received +5,000 $AFNL ($5,000.00 USD) from Sovereign Staking Pool.',
        targetTab: 'wallets',
      },
      marketplace: {
        title: '🛍️ Marketplace Asset Sold',
        description: 'Your listing "NVIDIA H100 GPU Cluster Lease" was purchased for $12,500.',
        targetTab: 'uploads',
      },
      social: {
        title: '🌟 New Follower on Final Finance',
        description: '@elena_quant started following your equity portfolio and trades.',
        targetTab: 'social',
      },
      chat: {
        title: '💬 Direct Message Received',
        description: 'Institutional Desk: "Your OTC settlement allocation has been confirmed."',
        targetTab: 'messages',
      },
      subsidies: {
        title: '🏛️ Sovereign Subsidy Disbursed',
        description: 'Grant claim #SUB-902 approved for $3,500.00 clean energy research allowance.',
        targetTab: 'subsidies',
      },
      fundraising: {
        title: '🚀 Campaign Goal Milestone Reached',
        description: 'Your project "Quantum Silicon Foundry" reached 85% of funding target.',
        targetTab: 'fundraising',
      },
      security: {
        title: '🛡️ Security Verification Notice',
        description: 'Biometric multi-factor key authenticated from verified workstation.',
        targetTab: 'settings',
      },
      feedback: {
        title: '✨ Platform Feedback Acknowledged',
        description: 'Thank you for your rating! Development ticket has been scheduled.',
        targetTab: 'settings',
      },
      loans: {
        title: '📄 Sovereign Credit Line Approved',
        description: 'Collateralized vault credit line of $50,000 ready for deployment.',
        targetTab: 'wallets',
      },
      system: {
        title: '⚡ Final Finance Engine Operational',
        description: 'Global multi-currency network latency optimal across all 4 stock market ways.',
        targetTab: 'dashboard',
      },
    };

    const sample = testSamples[category] || testSamples.stocks;
    addNotification({
      title: sample.title,
      description: sample.description,
      type: category,
      targetTab: sample.targetTab,
      showToast: true,
    });
  };

  // Global event listener for custom notification events fired anywhere in the app
  useEffect(() => {
    const handleGlobalNotifEvent = (e: Event) => {
      const customEvt = e as CustomEvent<UniversalNotificationEventDetail>;
      if (customEvt.detail) {
        addNotification({
          title: customEvt.detail.title,
          description: customEvt.detail.description,
          type: customEvt.detail.type as NotificationType,
          targetTab: customEvt.detail.targetTab,
          targetId: customEvt.detail.targetId,
          amount: customEvt.detail.amount,
          currency: customEvt.detail.currency,
          showToast: customEvt.detail.showToast,
          toastType: customEvt.detail.toastType,
          tone: customEvt.detail.tone,
        });
      }
    };

    const handlePrefsChanged = (e: Event) => {
      const customEvt = e as CustomEvent<NotificationPreferences>;
      if (customEvt.detail) {
        setNotificationPrefs(customEvt.detail);
      }
    };

    window.addEventListener('final_finance_notification_event', handleGlobalNotifEvent);
    window.addEventListener('final_finance_prefs_changed', handlePrefsChanged);
    return () => {
      window.removeEventListener('final_finance_notification_event', handleGlobalNotifEvent);
      window.removeEventListener('final_finance_prefs_changed', handlePrefsChanged);
    };
  }, [addNotification]);

  const addTransaction = (data: Partial<UniversalLedgerItem> & Omit<UniversalLedgerItem, 'id' | 'timestamp' | 'dateIso' | 'cryptographicHash' | 'signature' | 'receiptNumber'>) => {
    const newTx: UniversalLedgerItem = {
      id: `TX-${Math.floor(1000 + Math.random() * 9000)}`,
      receiptNumber: `REC-${Math.floor(100 + Math.random() * 899)}-FF`,
      timestamp: 'Just now',
      dateIso: new Date().toISOString(),
      cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}...${Math.random().toString(16).slice(2, 6)}`,
      signature: `sig_${Math.random().toString(16).slice(2, 12)}`,
      ...data,
    };

    setTransactions((prev) => [newTx, ...prev]);
  };

  const reverseTransaction = (id: string) => {
    const targetTx = transactions.find(t => t.id === id);
    
    setTransactions((prev) => 
      prev.map((tx) => tx.id === id ? { ...tx, status: 'Reversed' } : tx)
    );
    
    if (targetTx) {
      // Check if this transaction involved the current user and reverse the balance impact
      if (targetTx.issuerHandle === currentUser.handle || targetTx.sourceOrDestination === currentUser.handle) {
        const isOutgoing = targetTx.netAmountUSD < 0;
        const reversalAmount = -targetTx.netAmountUSD; // If it was -100, we add +100. If it was +100, we add -100.
        
        setCurrentUser((prev) => ({
          ...prev,
          portfolioNAV: prev.portfolioNAV + reversalAmount,
          holdings: {
            ...prev.holdings,
            [targetTx.mode || 'fiat_currency']: (prev.holdings[targetTx.mode || 'fiat_currency'] || 0) + reversalAmount
          }
        }));
      }
    }

    addToast({
      type: 'error',
      title: 'Transaction Control',
      message: `Transaction ${id} has been successfully reversed and funds restored to origin.`
    });
  };

  const createListing = (data: Omit<MarketplaceListing, 'id' | 'createdAt' | 'likes' | 'sellerId' | 'sellerName' | 'sellerHandle' | 'sellerAvatar' | 'sellerVerified'>) => {
    const newListing: MarketplaceListing = {
      ...data,
      id: 'mkt-' + Date.now(),
      sellerId: currentUser.id,
      sellerName: currentUser.name,
      sellerHandle: currentUser.handle,
      sellerAvatar: currentUser.avatarUrl,
      sellerVerified: currentUser.verified,
      createdAt: 'Just now',
      likes: 0,
      isLiked: false,
    };

    setListings((prev) => [newListing, ...prev]);
    addToast({
      type: 'gold',
      title: data.status === 'draft' ? 'Draft Saved' : 'Asset Listed',
      message: data.status === 'draft' 
        ? `"${data.title}" saved to your private marketplace drafts.`
        : `"${data.title}" is now live on the multi-asset marketplace.`
    });
    addNotification({
      title: data.status === 'draft' ? 'Draft Saved' : 'Asset Listed on Marketplace',
      description: data.status === 'draft'
        ? `"${data.title}" was saved to your drafts.`
        : `"${data.title}" is now active in ${data.category.toUpperCase()} category for $${data.priceUSD.toLocaleString()}.`,
      type: 'marketplace',
      targetTab: 'marketplace',
    });
    return newListing;
  };

  const publishDraft = (draftId: string) => {
    setListings((prev) => 
      prev.map((item) => item.id === draftId ? { ...item, status: 'active', createdAt: 'Just now' } : item)
    );
    addToast({
      type: 'success',
      title: 'Draft Published',
      message: 'Your asset draft is now live in the global reserve marketplace.'
    });
  };

  const deleteListing = (id: string) => {
    setListings((prev) => prev.filter((item) => item.id !== id));
    addToast({
      type: 'info',
      title: 'Listing Removed',
      message: 'The asset has been withdrawn from the marketplace.'
    });
  };

  const toggleLikeListing = (id: string) => {
    setListings((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const isLiked = !item.isLiked;
          return {
            ...item,
            isLiked,
            likes: isLiked ? item.likes + 1 : Math.max(0, item.likes - 1)
          };
        }
        return item;
      })
    );
  };

  const buyOrSwapListing = (listing: MarketplaceListing, paymentVault: AssetClass) => {
    const userBalance = currentUser.holdings[paymentVault] || 0;
    if (userBalance < listing.priceUSD) {
      addToast({
        type: 'error',
        title: 'Insufficient Vault Balance',
        message: `Your ${paymentVault.replace('_', ' ')} vault balance is $${userBalance.toLocaleString()}, but this asset requires $${listing.priceUSD.toLocaleString()}.`
      });
      return false;
    }

    // Deduct payment and add asset
    setCurrentUser((prev) => ({
      ...prev,
      portfolioNAV: prev.portfolioNAV,
      holdings: {
        ...prev.holdings,
        [paymentVault]: prev.holdings[paymentVault] - listing.priceUSD,
        [listing.category]: prev.holdings[listing.category] + listing.priceUSD
      }
    }));

    // Mark listing as sold or update status
    setListings((prev) =>
      prev.map((item) => item.id === listing.id ? { ...item, status: 'sold' } : item)
    );

    addToast({
      type: 'gold',
      title: 'Settlement Executed',
      message: `Successfully acquired "${listing.title}" for $${listing.priceUSD.toLocaleString()} settled via ${paymentVault.toUpperCase()}.`
    });

    addNotification({
      title: 'Settlement Executed',
      description: `Successfully acquired "${listing.title}" for $${listing.priceUSD.toLocaleString()} settled via ${paymentVault.toUpperCase()} Vault.`,
      type: 'trade',
      targetTab: 'portfolio',
    });

    return true;
  };

  const createPost = (content: string, imageUrl?: string, imageMeta?: CommunityPost['imageMeta'], assetTag?: CommunityPost['assetTag']) => {
    const newPost: CommunityPost = {
      id: 'post-' + Date.now(),
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorHandle: currentUser.handle,
      authorAvatar: currentUser.avatarUrl,
      authorTier: currentUser.tier,
      authorVerified: currentUser.verified,
      content,
      imageUrl,
      imageMeta,
      assetTag,
      likes: 0,
      isLiked: false,
      commentsCount: 0,
      comments: [],
      shares: 0,
      createdAt: 'Just now'
    };

    setPosts((prev) => [newPost, ...prev]);
    addToast({
      type: 'success',
      title: 'Post Published',
      message: 'Your broadcast was shared to the Final Finance community.'
    });

    addNotification({
      title: 'Post Published',
      description: `Your broadcast "${content.slice(0, 40)}${content.length > 40 ? '...' : ''}" was successfully posted to the community feed.`,
      type: 'system',
      targetTab: 'community',
    });
  };

  const toggleLikePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const isLiked = !post.isLiked;
          return {
            ...post,
            isLiked,
            likes: isLiked ? post.likes + 1 : Math.max(0, post.likes - 1)
          };
        }
        return post;
      })
    );
  };

  const addCommentToPost = (postId: string, commentText: string) => {
    const newComment = {
      id: 'c-' + Date.now(),
      authorName: currentUser.name,
      authorHandle: currentUser.handle,
      authorAvatar: currentUser.avatarUrl,
      content: commentText,
      createdAt: 'Just now'
    };

    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            commentsCount: post.commentsCount + 1,
            comments: [...(post.comments || []), newComment]
          };
        }
        return post;
      })
    );
  };

  const toggleFollowUser = (handle: string) => {
    setCurrentUser((prev) => ({
      ...prev,
      followingCount: prev.followingCount + 1
    }));

    addToast({
      type: 'info',
      title: 'Network Updated',
      message: `You are now following ${handle}.`
    });

    addNotification({
      title: 'Network Follow Updated',
      description: `You are now following ${handle}. Real-time trading updates enabled.`,
      type: 'social',
      targetTab: 'social',
    });
  };

  const sendMessage = (conversationId: string, text: string, imageUrl?: string) => {
    const newMsg: Message = {
      id: 'm-' + Date.now(),
      conversationId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatarUrl,
      text,
      imageUrl,
      createdAt: 'Just now'
    };

    setMessages((prev) => ({
      ...prev,
      [conversationId]: [...(prev[conversationId] || []), newMsg]
    }));

    setConversations((prev) =>
      prev.map((conv) =>
        conv.id === conversationId
          ? {
              ...conv,
              lastMessageText: text || (imageUrl ? 'Shared an image asset' : ''),
              lastMessageTime: 'Just now'
            }
          : conv
      )
    );

    // Simulate smart auto-reply from desk after 2.5 seconds
    setTimeout(() => {
      const activeConv = conversations.find((c) => c.id === conversationId);
      if (activeConv && activeConv.type === 'direct') {
        const replyText = `Confirmed Marcus. Our institutional settlement desk has logged your request regarding "${text.substring(0, 40)}...". Processing verification hash.`;
        const autoReply: Message = {
          id: 'm-auto-' + Date.now(),
          conversationId,
          senderId: 'desk-agent',
          senderName: activeConv.name,
          senderAvatar: activeConv.avatar,
          text: replyText,
          createdAt: 'Just now'
        };

        setMessages((prev) => ({
          ...prev,
          [conversationId]: [...(prev[conversationId] || []), autoReply]
        }));

        setConversations((prev) =>
          prev.map((conv) =>
            conv.id === conversationId
              ? {
                  ...conv,
                  lastMessageText: replyText,
                  lastMessageTime: 'Just now'
                }
              : conv
          )
        );

        addNotification({
          title: `New Message from ${activeConv.name}`,
          description: replyText,
          type: 'chat',
          targetTab: 'messages',
          tone: 'message',
        });
      }
    }, 2800);
  };

  const respondToTradeProposal = (conversationId: string, messageId: string, status: 'accepted' | 'declined') => {
    setMessages((prev) => ({
      ...prev,
      [conversationId]: (prev[conversationId] || []).map((msg) => {
        if (msg.id === messageId && msg.tradeProposal) {
          return {
            ...msg,
            tradeProposal: {
              ...msg.tradeProposal,
              status
            }
          };
        }
        return msg;
      })
    }));

    addToast({
      type: status === 'accepted' ? 'gold' : 'info',
      title: status === 'accepted' ? 'Trade Swap Accepted' : 'Trade Declined',
      message: status === 'accepted' 
        ? 'Escrow contracts deployed and asset titles transferred.' 
        : 'Counterparty informed of decision.'
    });

    addNotification({
      title: status === 'accepted' ? '🤝 Trade Proposal Accepted' : 'Trade Proposal Declined',
      description: status === 'accepted'
        ? 'Atomic escrow settlement confirmed. Assets credited to your portfolio holdings.'
        : 'The exchange proposal was declined and escrow holds released.',
      type: 'trade',
      targetTab: 'marketplace',
    });
  };

  const startDirectConversation = (recipientName: string, recipientAvatar?: string, initialMessage?: string) => {
    const existing = conversations.find((c) => c.name.toLowerCase() === recipientName.toLowerCase());
    if (existing) {
      setActiveConversationId(existing.id);
      setCurrentTab('messages');
      if (initialMessage) {
        sendMessage(existing.id, initialMessage);
      }
      return existing.id;
    }

    const newId = 'conv-' + Date.now();
    const newConv: Conversation = {
      id: newId,
      type: 'direct',
      name: recipientName,
      avatar: recipientAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      participantIds: [currentUser.id, 'temp-' + Date.now()],
      lastMessageText: initialMessage || 'Conversation opened',
      lastMessageTime: 'Just now',
      unreadCount: 0,
      isVerifiedDesk: true
    };

    setConversations((prev) => [newConv, ...prev]);
    setMessages((prev) => ({
      ...prev,
      [newId]: initialMessage ? [
        {
          id: 'm-init-' + Date.now(),
          conversationId: newId,
          senderId: currentUser.id,
          senderName: currentUser.name,
          senderAvatar: currentUser.avatarUrl,
          text: initialMessage,
          createdAt: 'Just now'
        }
      ] : []
    }));

    setActiveConversationId(newId);
    setCurrentTab('messages');
    return newId;
  };

  const depositToVault = (vaultId: AssetClass, amountUSD: number, assetName: string) => {
    setVaults((prev) =>
      prev.map((vault) => {
        if (vault.id === vaultId) {
          return {
            ...vault,
            totalReserveUSD: vault.totalReserveUSD + amountUSD
          };
        }
        return vault;
      })
    );

    setCurrentUser((prev) => ({
      ...prev,
      portfolioNAV: prev.portfolioNAV + amountUSD,
      holdings: {
        ...prev.holdings,
        [vaultId]: prev.holdings[vaultId] + amountUSD
      }
    }));

    // Record in Universal Ledger
    const vaultObj = vaults.find(v => v.id === vaultId);
    const vaultName = vaultObj?.name || vaultId.replace('_', ' ').toUpperCase();
    let mode: 'gold_bullion' | 'stable_coin' | 'fiat' | 'crypto' | 'final_coin' = 'gold_bullion';
    if (vaultId.includes('stable') || vaultId.includes('liquidity')) mode = 'stable_coin';
    else if (vaultId.includes('fiat') || vaultId.includes('treasury')) mode = 'fiat';
    else if (vaultId.includes('crypto') || vaultId.includes('btc') || vaultId.includes('eth')) mode = 'crypto';
    else if (vaultId.includes('final')) mode = 'final_coin';

    const ledgerItem = createLedgerItemFromVaultDeposit({
      vaultId,
      vaultName,
      amountUSD,
      assetName,
      mode
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    addToast({
      type: 'gold',
      title: 'Vault Allocation Confirmed',
      message: `Deposited $${amountUSD.toLocaleString()} (${assetName}) into ${vaultId.replace('_', ' ').toUpperCase()} Reserve Vault.`
    });

    addNotification({
      title: 'Vault Allocation Confirmed',
      description: `Allocated $${amountUSD.toLocaleString()} (${assetName}) into ${vaultId.replace('_', ' ').toUpperCase()} Reserve Vault.`,
      type: 'vault',
      targetTab: 'vaults',
    });
  };

  const withdrawFromVault = (vaultId: AssetClass, amountUSD: number) => {
    const currentBalance = currentUser.holdings[vaultId] || 0;
    if (currentBalance < amountUSD) {
      addToast({
        type: 'error',
        title: 'Exceeds Vault Balance',
        message: `Your available balance in ${vaultId.replace('_', ' ')} is $${currentBalance.toLocaleString()}.`
      });
      return false;
    }

    setVaults((prev) =>
      prev.map((vault) => {
        if (vault.id === vaultId) {
          return {
            ...vault,
            totalReserveUSD: Math.max(0, vault.totalReserveUSD - amountUSD)
          };
        }
        return vault;
      })
    );

    setCurrentUser((prev) => ({
      ...prev,
      portfolioNAV: Math.max(0, prev.portfolioNAV - amountUSD),
      holdings: {
        ...prev.holdings,
        [vaultId]: Math.max(0, prev.holdings[vaultId] - amountUSD)
      }
    }));

    // Record in Universal Ledger
    const vaultObj = vaults.find(v => v.id === vaultId);
    const vaultName = vaultObj?.name || vaultId.replace('_', ' ').toUpperCase();
    let mode: 'gold_bullion' | 'stable_coin' | 'fiat' | 'crypto' | 'final_coin' = 'gold_bullion';
    if (vaultId.includes('stable') || vaultId.includes('liquidity')) mode = 'stable_coin';
    else if (vaultId.includes('fiat') || vaultId.includes('treasury')) mode = 'fiat';
    else if (vaultId.includes('crypto') || vaultId.includes('btc') || vaultId.includes('eth')) mode = 'crypto';
    else if (vaultId.includes('final')) mode = 'final_coin';

    const ledgerItem = createLedgerItemFromVaultWithdrawal({
      vaultId,
      vaultName,
      amountUSD,
      mode
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    addToast({
      type: 'info',
      title: 'Settlement Withdrawn',
      message: `Withdrew $${amountUSD.toLocaleString()} from ${vaultId.replace('_', ' ').toUpperCase()} Vault to external custody.`
    });

    addNotification({
      title: 'Settlement Withdrawn',
      description: `Withdrew $${amountUSD.toLocaleString()} from ${vaultId.replace('_', ' ').toUpperCase()} Vault to external custody.`,
      type: 'vault',
      targetTab: 'vaults',
    });

    return true;
  };

  return (
    <AppContext.Provider
      value={{
        deviceMode,
        setDeviceMode,
        currentTab,
        setCurrentTab,
        currentUser,
        setCurrentUser,
        vaults,
        setVaults,
        listings,
        setListings,
        posts,
        setPosts,
        conversations,
        activeConversationId,
        setActiveConversationId,
        messages,
        imageHistory,
        addImageToHistory,
        transactions,
        addTransaction,
        reverseTransaction,
        createListing,
        publishDraft,
        deleteListing,
        toggleLikeListing,
        buyOrSwapListing,
        createPost,
        toggleLikePost,
        addCommentToPost,
        toggleFollowUser,
        sendMessage,
        respondToTradeProposal,
        startDirectConversation,
        depositToVault,
        withdrawFromVault,
        toasts,
        addToast,
        removeToast,
        stagedAssetForDraft,
        setStagedAssetForDraft,
        notifications,
        setNotifications,
        addNotification,
        deleteNotification,
        clearAllNotifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        notificationPrefs,
        updateNotificationPrefs,
        triggerTestNotification,
        previousTab,
        setPreviousTab,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
