import React, { useState } from 'react';
import { Compass, ArrowRight, Shield, LogOut, Loader2, UserPlus } from 'lucide-react';
import { AuthSession } from '../types/auth';
import { signOut, signInWithGoogle, getRegisteredUsers } from '../services/firebaseAuth';
import { GoogleAccountChooserModal } from './GoogleAccountChooserModal';

interface LandingHomePageProps {
  onOpenAuthModal: () => void;
  onEnterApp: () => void;
  onAuthSuccess?: (user: AuthSession) => void;
  currentUserSession: AuthSession | null;
  onSelectDemoAccount?: (key: any) => void;
}

export const LandingHomePage: React.FC<LandingHomePageProps> = ({
  onEnterApp,
  onAuthSuccess,
  currentUserSession,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isDifferentAccountModalOpen, setIsDifferentAccountModalOpen] = useState(false);

  const handleGoogleAuth = async () => {
    setIsLoading(true);
    try {
      await new Promise((r) => setTimeout(r, 600));
      const registered = getRegisteredUsers();
      const userAccount = registered['gholu653@gmail.com'] || Object.values(registered)[0];
      const res = await signInWithGoogle(userAccount.email, userAccount.passwordHash, false);
      if (res.success && res.user && onAuthSuccess) {
        onAuthSuccess(res.user);
      }
    } catch (e) {
      console.error('Google Auth Error:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    window.location.reload();
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center px-4 py-8 text-center">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-left">
        {/* Title Header without 'F' box */}
        <div className="text-center space-y-2">
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">
            Welcome to Final Finance
          </h1>
          <p className="text-xs text-slate-500">
            Everything Finance!
          </p>
        </div>

        {/* Active Session Zone or Regular Google Sign In / Sign Up */}
        {currentUserSession ? (
          <div className="space-y-4 pt-2">
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {currentUserSession.avatarUrl ? (
                  <img
                    src={currentUserSession.avatarUrl}
                    alt={currentUserSession.name}
                    className="w-10 h-10 rounded-full object-cover border border-slate-300 shrink-0"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm font-serif font-bold shrink-0">
                    {currentUserSession.name?.charAt(0) || 'U'}
                  </div>
                )}
                <div className="min-w-0 text-center">
                  <p className="text-[11px] text-emerald-600 font-semibold uppercase tracking-wider text-center">Signed In</p>
                  <p className="text-sm font-bold text-slate-900 truncate">
                    {currentUserSession.name}
                  </p>
                  <p className="text-xs text-slate-500 truncate">
                    {currentUserSession.email}
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={onEnterApp}
                className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Compass className="w-4 h-4" />
                <span>Enter Marketplace Page</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleSignOut}
                className="w-full min-h-[40px] py-2.5 px-4 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5 text-slate-500" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        ) : (
          /* Google Sign In / Sign Up Zone */
          <div className="space-y-3 pt-2">
            <button
              type="button"
              id="google-auth-main-btn"
              disabled={isLoading}
              onClick={handleGoogleAuth}
              className="w-full min-h-[48px] py-3 px-4 rounded-2xl bg-white border border-slate-300 hover:border-slate-400 hover:bg-slate-50 active:scale-[0.99] transition-all flex items-center justify-center gap-3 shadow-xs cursor-pointer group disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 text-blue-600 animate-spin shrink-0" />
                  <span className="text-sm font-medium text-slate-700">Connecting to Google...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span className="text-sm font-medium text-slate-800 group-hover:text-slate-950">
                    Sign in / Sign up with Google
                  </span>
                </>
              )}
            </button>

            {/* Option to sign in with a different Gmail account */}
            <button
              type="button"
              onClick={() => setIsDifferentAccountModalOpen(true)}
              className="w-full py-2.5 px-3 rounded-xl hover:bg-slate-100 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5 text-slate-400" />
              <span>Use a different Gmail / Google account</span>
            </button>

            {/* Google security badge */}
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-1">
              <Shield className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Protected by Google Secure Sign-In</span>
            </div>
          </div>
        )}

        {/* Modal for logging in with a different Gmail account */}
        <GoogleAccountChooserModal
          isOpen={isDifferentAccountModalOpen}
          onClose={() => setIsDifferentAccountModalOpen(false)}
          onSelectAccount={(user) => {
            if (onAuthSuccess) {
              onAuthSuccess(user);
            }
            setIsDifferentAccountModalOpen(false);
          }}
        />
      </div>
    </div>
  );
};
