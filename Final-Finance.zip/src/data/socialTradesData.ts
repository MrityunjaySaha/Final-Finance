import { SocialStockTrade } from '../types/stocks';

export interface FamousPersonality {
  uid: string;
  name: string;
  handle: string;
  avatarUrl: string;
  title: string;
  verified: boolean;
  winRate: string;
  bio: string;
  topSectors: string[];
}

export const FAMOUS_PERSONALITIES: FamousPersonality[] = [
  {
    uid: 'famous-pelosi',
    name: 'Nancy Pelosi',
    handle: 'pelosi_portfolio',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    title: 'Congressional Disclosures (Sovereign Allocation)',
    verified: true,
    winRate: '89.4%',
    bio: 'Former Speaker of the House & sovereign portfolio allocator with high-conviction tech and energy positions.',
    topSectors: ['Semiconductors', 'Artificial Intelligence', 'Clean Energy']
  },
  {
    uid: 'famous-jim_simons',
    name: 'Jim Simons',
    handle: 'renaissance_tech',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    title: 'Founder, Renaissance Technologies',
    verified: true,
    winRate: '99.1%',
    bio: 'Legendary mathematician and quant fund pioneer. Medallion model quantitative signals and mean-reversion.',
    topSectors: ['Autonomous Systems', 'Macro Equities', 'Statistical Arbitrage']
  },
  {
    uid: 'famous-buffett',
    name: 'Warren Buffett',
    handle: 'oracle_of_omaha',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: 'Chairman & Sovereign Allocator',
    verified: true,
    winRate: '94.2%',
    bio: 'Value investor focused on durable economic moats, cashflow yield, and perpetual capital compounders.',
    topSectors: ['Treasury Yield', 'Life Sciences', 'Consumer Franchises']
  },
  {
    uid: 'famous-elon',
    name: 'Elon Musk',
    handle: 'elonmusk',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    title: 'Technoking & Systems Architect',
    verified: true,
    winRate: '86.5%',
    bio: 'Leading innovations in electric mobility, humanoid robotics perception, and decentralized infrastructure.',
    topSectors: ['Robotics', 'Space & Energy', 'Compute Networks']
  },
  {
    uid: 'famous-cathie',
    name: 'Cathie Wood',
    handle: 'cathie_ark',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    title: 'CIO, Disruptive Innovation Fund',
    verified: true,
    winRate: '79.2%',
    bio: 'Investing in technological transformation across genomics, multi-omic sequencing, and artificial intelligence.',
    topSectors: ['Genomics', 'Autonomous Tech', 'Fintech Protocols']
  },
  {
    uid: 'famous-ackman',
    name: 'Bill Ackman',
    handle: 'bill_ackman',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    title: 'CEO, Pershing Square Capital',
    verified: true,
    winRate: '87.2%',
    bio: 'Concentrated activist investing in high-quality market-leading large-cap global franchises.',
    topSectors: ['Enterprise Cloud', 'Semiconductors', 'Large Cap Tech']
  },
  {
    uid: 'famous-saylor',
    name: 'Michael Saylor',
    handle: 'saylor',
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
    title: 'Executive Chairman & Treasury Strategist',
    verified: true,
    winRate: '91.0%',
    bio: 'Pioneer of digital reserve assets and institutional sovereign microgrid treasury balance sheets.',
    topSectors: ['Bitcoin Protocols', 'Energy Microgrids', 'Treasury Systems']
  },
  {
    uid: 'famous-dalio',
    name: 'Ray Dalio',
    handle: 'raydalio',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
    title: 'Founder & Macro Strategist',
    verified: true,
    winRate: '92.1%',
    bio: 'Principles-driven macroeconomic diversification and systemic debt cycle risk parity allocation.',
    topSectors: ['Quantum Compute', 'Energy Grids', 'Commodities']
  }
];

export interface FriendProfile {
  uid: string;
  name: string;
  handle: string;
  avatarUrl: string;
  title: string;
  verified: boolean;
  friendsCount: number;
  winRate: string;
  bio: string;
  relationType: 'Friend' | 'Mutual Friend' | 'Syndicate Peer';
  topSectors: string[];
}

export const FRIENDS_AND_MUTUALS: FriendProfile[] = [
  {
    uid: 'user-elena_rostova',
    name: 'Elena Rostova',
    handle: 'elena_rostova',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    title: 'Lead Plasma Magnetics & Sovereign Trustee',
    verified: true,
    friendsCount: 118,
    winRate: '83.7%',
    bio: 'Specialist in high-energy plasma magnetic containment and sovereign grid assets.',
    relationType: 'Friend',
    topSectors: ['Fusion Energy', 'Superconductors', 'Grid Infrastructure']
  },
  {
    uid: 'user-lord_sterling',
    name: 'Lord Sterling',
    handle: 'sterling_vault',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: 'Swiss Freeport Trustee & Sovereign Syndicate',
    verified: true,
    friendsCount: 84,
    winRate: '88.2%',
    bio: 'Managing sovereign bullion vaults and private equity syndicates across Zurich and Singapore.',
    relationType: 'Mutual Friend',
    topSectors: ['Freeport Vaults', 'Precious Metals', 'Private Equity']
  },
  {
    uid: 'user-marcus_vance',
    name: 'Dr. Marcus Vance',
    handle: 'marcus_vance',
    avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
    title: 'Founder & Chief Scientist, Hyperion Fusion',
    verified: true,
    friendsCount: 96,
    winRate: '91.4%',
    bio: 'Developing stellar-grade magnetic confinement fusion reactors and quantum accelerators.',
    relationType: 'Friend',
    topSectors: ['Quantum Compute', 'Fusion Power', 'Advanced Materials']
  },
  {
    uid: 'user-sophia_vance',
    name: 'Sophia Vance',
    handle: 'sophiav',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
    title: 'Algorithm Designer & Quant',
    verified: true,
    friendsCount: 72,
    winRate: '85.9%',
    bio: 'High-frequency statistical arbitrage and neural portfolio weighting algorithms.',
    relationType: 'Mutual Friend',
    topSectors: ['Quant Trading', 'Neural Networks', 'Algorithmic Execution']
  }
];

export const INITIAL_SOCIAL_TRADES: SocialStockTrade[] = [
  // Nancy Pelosi Trades across Fiat, Stable, Crypto, and Final
  {
    id: 'soc-trade-pelosi-nvda',
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures (Sovereign Allocation)',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 10000,
    priceUSD: 118.50,
    totalValueUSD: 1185000,
    timestamp: new Date(Date.now() - 1000 * 60 * 2).toISOString(),
    timestampAgo: '2h ago',
    commentary: 'Periodic Congressional Transaction Report: Exercised 50 call options (strike $100) and acquired 10,000 shares of Quantum Compute Sovereign Trust.',
    settlementMethod: 'USD Fiat Direct Clearing',
    gainLossPercent: 18.5,
    disclosureType: 'STOCK Act PTR',
    executionDate: '2024-06-26',
    filingDate: '2024-07-02',
    shareQuantityOrValue: '$1,000,001 - $5,000,000 (50 Call options)',
    assetClass: 'Option (Call)',
    sourceDocumentUrl: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025368.pdf',
    cikOrMemberId: 'House Member ID: P000197'
  },
  {
    id: 'soc-trade-elena-alex-final',
    traderType: 'friend',
    user: {
      uid: 'user-elena_rostova',
      name: 'Elena Rostova',
      handle: 'elena_rostova',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
      title: 'Lead Plasma Magnetics & Sovereign Trustee',
      verified: true,
      isFriend: true,
      friendsCount: 118,
      winRate: '83.7%'
    },
    ticker: 'ALEX',
    stockName: 'Alex Chen Sovereign Human Equity',
    marketType: 'final',
    assetCategory: 'personal',
    side: 'buy',
    shares: 320,
    priceUSD: 26.92,
    totalValueUSD: 8614.40,
    timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    timestampAgo: '30m ago',
    commentary: 'Shared trade: Added Alex Chen personal equity in Final Coin clearing ($ALEX) for long-term sovereign alignment.',
    settlementMethod: '$ALEX',
    finalCoinSymbol: '$ALEX'
  },
  {
    id: 'soc-trade-elena-hypr-prev',
    traderType: 'friend',
    user: {
      uid: 'user-elena_rostova',
      name: 'Elena Rostova',
      handle: 'elena_rostova',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
      title: 'Lead Plasma Magnetics & Sovereign Trustee',
      verified: true,
      isFriend: true,
      friendsCount: 118,
      winRate: '83.7%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion Dynamics Inc.',
    marketType: 'final',
    assetCategory: 'business',
    side: 'sell',
    shares: 85,
    priceUSD: 55.78,
    totalValueUSD: 4741.30,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 19).toISOString(),
    timestampAgo: '19d ago',
    commentary: 'Previous shared trade: Realized partial gains on Hyperion business equity settled in $HYPR.',
    settlementMethod: '$HYPR',
    finalCoinSymbol: '$HYPR'
  },
  {
    id: 'soc-trade-marcus-hypr-final',
    traderType: 'friend',
    user: {
      uid: 'user-marcus_vance',
      name: 'Dr. Marcus Vance',
      handle: 'marcus_vance',
      avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Chief Scientist, Hyperion Fusion',
      verified: true,
      isFriend: true,
      friendsCount: 96,
      winRate: '91.4%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion Dynamics Inc.',
    marketType: 'final',
    assetCategory: 'business',
    side: 'buy',
    shares: 150,
    priceUSD: 55.78,
    totalValueUSD: 8367.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    timestampAgo: '1h ago',
    commentary: 'Shared trade: Accumulated Hyperion business equity settled via $HYPR.',
    settlementMethod: '$HYPR',
    finalCoinSymbol: '$HYPR'
  },
  {
    id: 'soc-trade-marcus-alex-prev',
    traderType: 'friend',
    user: {
      uid: 'user-marcus_vance',
      name: 'Dr. Marcus Vance',
      handle: 'marcus_vance',
      avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Chief Scientist, Hyperion Fusion',
      verified: true,
      isFriend: true,
      friendsCount: 96,
      winRate: '91.4%'
    },
    ticker: 'ALEX',
    stockName: 'Alex Chen Sovereign Human Equity',
    marketType: 'final',
    assetCategory: 'personal',
    side: 'sell',
    shares: 110,
    priceUSD: 26.92,
    totalValueUSD: 2961.20,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 38).toISOString(),
    timestampAgo: '1mo ago',
    commentary: 'Previous shared trade: Rebalanced part of Alex Chen personal equity into $ALEX reserves.',
    settlementMethod: '$ALEX',
    finalCoinSymbol: '$ALEX'
  },
  {
    id: 'soc-trade-sophia-elen-final',
    traderType: 'friend',
    user: {
      uid: 'user-sophia_vance',
      name: 'Sophia Vance',
      handle: 'sophiav',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
      title: 'Algorithm Designer & Quant',
      verified: true,
      isFriend: true,
      friendsCount: 72,
      winRate: '85.9%'
    },
    ticker: 'ELEN',
    stockName: 'Dr. Elena Rostova Plasma Physics Equity',
    marketType: 'final',
    assetCategory: 'personal',
    side: 'sell',
    shares: 180,
    priceUSD: 21.00,
    totalValueUSD: 3780.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    timestampAgo: '3h ago',
    commentary: 'Shared trade: Trimmed part of Dr. Elena Rostova personal equity tranche into $ELEN.',
    settlementMethod: '$ELEN',
    finalCoinSymbol: '$ELEN'
  },
  {
    id: 'soc-trade-sophia-afnl-prev',
    traderType: 'friend',
    user: {
      uid: 'user-sophia_vance',
      name: 'Sophia Vance',
      handle: 'sophiav',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
      title: 'Algorithm Designer & Quant',
      verified: true,
      isFriend: true,
      friendsCount: 72,
      winRate: '85.9%'
    },
    ticker: 'AFNL-EQ',
    stockName: 'Final Network Treasury Equity',
    marketType: 'final',
    assetCategory: 'business',
    side: 'buy',
    shares: 25,
    priceUSD: 345.00,
    totalValueUSD: 8625.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 62).toISOString(),
    timestampAgo: '2mo ago',
    commentary: 'Previous shared trade: Acquired Final Network Treasury Equity settled in $AFNL.',
    settlementMethod: 'Final Coin Clearing ($AFNL)',
    finalCoinSymbol: '$AFNL'
  },
  {
    id: 'soc-trade-sterling-afnl-final',
    traderType: 'friend',
    user: {
      uid: 'user-lord_sterling',
      name: 'Lord Sterling',
      handle: 'sterling_vault',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Swiss Freeport Trustee & Sovereign Syndicate',
      verified: true,
      isFriend: true,
      friendsCount: 84,
      winRate: '88.2%'
    },
    ticker: 'AFNL-EQ',
    stockName: 'Final Network Treasury Equity',
    marketType: 'final',
    assetCategory: 'business',
    side: 'buy',
    shares: 40,
    priceUSD: 345.00,
    totalValueUSD: 13800.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
    timestampAgo: '4h ago',
    commentary: 'Shared trade: Core treasury allocation in Final Network Equity backed by $AFNL.',
    settlementMethod: 'Final Coin Clearing ($AFNL)',
    finalCoinSymbol: '$AFNL'
  },
  {
    id: 'soc-trade-sterling-elen-prev',
    traderType: 'friend',
    user: {
      uid: 'user-lord_sterling',
      name: 'Lord Sterling',
      handle: 'sterling_vault',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Swiss Freeport Trustee & Sovereign Syndicate',
      verified: true,
      isFriend: true,
      friendsCount: 84,
      winRate: '88.2%'
    },
    ticker: 'ELEN',
    stockName: 'Dr. Elena Rostova Plasma Physics Equity',
    marketType: 'final',
    assetCategory: 'personal',
    side: 'buy',
    shares: 210,
    priceUSD: 21.00,
    totalValueUSD: 4410.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 125).toISOString(),
    timestampAgo: '4mo ago',
    commentary: 'Previous shared trade: Backed Dr. Elena Rostova personal sovereign equity in $ELEN.',
    settlementMethod: '$ELEN',
    finalCoinSymbol: '$ELEN',
    instrumentCategory: 'equity',
    derivativeType: 'spot'
  },
  {
    id: 'soc-trade-elena-alex-call-deriv',
    traderType: 'friend',
    user: {
      uid: 'user-elena_rostova',
      name: 'Elena Rostova',
      handle: 'elena_rostova',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
      title: 'Lead Plasma Magnetics & Sovereign Trustee',
      verified: true,
      isFriend: true,
      friendsCount: 118,
      winRate: '83.7%'
    },
    ticker: 'ALEX',
    stockName: 'Alex Chen Sovereign Human Equity',
    marketType: 'final',
    assetCategory: 'personal',
    side: 'buy',
    shares: 150,
    priceUSD: 3.45,
    totalValueUSD: 517.50,
    timestamp: new Date(Date.now() - 1000 * 60 * 50).toISOString(),
    timestampAgo: '50m ago',
    commentary: 'Shared Call Option contract on $ALEX ($ALEX) on Derivatives. Bullish upside call ahead of sovereign personal index rebalance.',
    settlementMethod: '$ALEX',
    finalCoinSymbol: '$ALEX',
    gainLossPercent: 14.2,
    instrumentCategory: 'derivatives',
    derivativeType: 'call_option',
    strikePrice: 30.00,
    expiryDate: 'Oct 18, 2026'
  },
  {
    id: 'soc-trade-elena-hypr-short-deriv',
    traderType: 'friend',
    user: {
      uid: 'user-elena_rostova',
      name: 'Elena Rostova',
      handle: 'elena_rostova',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
      title: 'Lead Plasma Magnetics & Sovereign Trustee',
      verified: true,
      isFriend: true,
      friendsCount: 118,
      winRate: '83.7%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion Dynamics Inc.',
    marketType: 'final',
    assetCategory: 'business',
    side: 'sell',
    shares: 60,
    priceUSD: 55.78,
    totalValueUSD: 3346.80,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 8).toISOString(),
    timestampAgo: '8h ago',
    commentary: 'Closed Short Futures hedge contract on $HYPR ($HYPR) on Derivatives at 3x leverage.',
    settlementMethod: '$HYPR',
    finalCoinSymbol: '$HYPR',
    gainLossPercent: 6.8,
    instrumentCategory: 'derivatives',
    derivativeType: 'futures_short',
    leverage: 3
  },
  {
    id: 'soc-trade-marcus-hypr-long-deriv',
    traderType: 'friend',
    user: {
      uid: 'user-marcus_vance',
      name: 'Dr. Marcus Vance',
      handle: 'marcus_vance',
      avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Chief Scientist, Hyperion Fusion',
      verified: true,
      isFriend: true,
      friendsCount: 96,
      winRate: '91.4%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion Dynamics Inc.',
    marketType: 'final',
    assetCategory: 'business',
    side: 'buy',
    shares: 100,
    priceUSD: 55.78,
    totalValueUSD: 5578.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 140).toISOString(),
    timestampAgo: '2h ago',
    commentary: 'Shared Long Futures contract on $HYPR ($HYPR) on Derivatives with 5x leverage.',
    settlementMethod: '$HYPR',
    finalCoinSymbol: '$HYPR',
    gainLossPercent: 11.4,
    instrumentCategory: 'derivatives',
    derivativeType: 'futures_long',
    leverage: 5
  },
  {
    id: 'soc-trade-sophia-elen-put-deriv',
    traderType: 'friend',
    user: {
      uid: 'user-sophia_vance',
      name: 'Sophia Vance',
      handle: 'sophiav',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
      title: 'Algorithm Designer & Quant',
      verified: true,
      isFriend: true,
      friendsCount: 72,
      winRate: '85.9%'
    },
    ticker: 'ELEN',
    stockName: 'Dr. Elena Rostova Plasma Physics Equity',
    marketType: 'final',
    assetCategory: 'personal',
    side: 'sell',
    shares: 120,
    priceUSD: 2.15,
    totalValueUSD: 258.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 210).toISOString(),
    timestampAgo: '3h ago',
    commentary: 'Closed Put Option protective contract on $ELEN ($ELEN) on Derivatives after volatility crush.',
    settlementMethod: '$ELEN',
    finalCoinSymbol: '$ELEN',
    gainLossPercent: 9.2,
    instrumentCategory: 'derivatives',
    derivativeType: 'put_option',
    strikePrice: 19.50,
    expiryDate: 'Nov 20, 2026'
  },
  {
    id: 'soc-trade-sterling-afnl-call-deriv',
    traderType: 'friend',
    user: {
      uid: 'user-lord_sterling',
      name: 'Lord Sterling',
      handle: 'sterling_vault',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Swiss Freeport Trustee & Sovereign Syndicate',
      verified: true,
      isFriend: true,
      friendsCount: 84,
      winRate: '88.2%'
    },
    ticker: 'AFNL-EQ',
    stockName: 'Final Network Treasury Equity',
    marketType: 'final',
    assetCategory: 'business',
    side: 'buy',
    shares: 35,
    priceUSD: 28.50,
    totalValueUSD: 997.50,
    timestamp: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
    timestampAgo: '5h ago',
    commentary: 'Shared Call Option contract on $AFNL-EQ ($AFNL) on Derivatives for sovereign clearing upside.',
    settlementMethod: '$AFNL',
    finalCoinSymbol: '$AFNL',
    gainLossPercent: 16.5,
    instrumentCategory: 'derivatives',
    derivativeType: 'call_option',
    strikePrice: 360.00,
    expiryDate: 'Dec 18, 2026'
  },
  {
    id: 'soc-trade-sophia-bsyn-today',
    traderType: 'friend',
    user: {
      uid: 'user-sophia_vance',
      name: 'Sophia Vance',
      handle: 'sophiav',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
      title: 'Algorithm Designer & Quant',
      verified: true,
      winRate: '85.9%'
    },
    ticker: 'BSYN',
    stockName: 'BioSynthetica Genomics',
    marketType: 'stable',
    assetCategory: 'business',
    side: 'buy',
    shares: 1200,
    priceUSD: 32.40,
    totalValueUSD: 38880,
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    timestampAgo: '45m ago',
    commentary: 'Allocating stable treasury into genomics infrastructure. Settlement via USDC direct clearing.',
    settlementMethod: '1:1 USD Stablecoin'
  },
  {
    id: 'soc-trade-marcus-qbit-today',
    traderType: 'friend',
    user: {
      uid: 'user-marcus_vance',
      name: 'Dr. Marcus Vance',
      handle: 'marcus_vance',
      avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Chief Scientist',
      verified: true,
      winRate: '91.4%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Dynamics Core',
    marketType: 'crypto',
    assetCategory: 'business',
    side: 'buy',
    shares: 800,
    priceUSD: 88.50,
    totalValueUSD: 70800,
    timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    timestampAgo: '2h ago',
    commentary: 'Systematic buy into Quantum Trust. High-resonance compute lattice demand remains elevated.',
    settlementMethod: 'Crypto Custody Ledger (BTC)'
  },
  {
    id: 'soc-trade-pelosi-aapl',
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures (Sovereign Allocation)',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 5000,
    priceUSD: 226.40,
    totalValueUSD: 1132000,
    timestamp: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
    timestampAgo: '1d ago',
    commentary: 'Periodic disclosure: Acquired 5,000 shares of Hyperion Quantum Fusion ahead of AI enterprise integration and consumer device replacement cycle.',
    settlementMethod: 'USD Fiat Direct Clearing',
    gainLossPercent: 4.8,
    disclosureType: 'STOCK Act PTR',
    executionDate: '2024-07-26',
    filingDate: '2024-07-30',
    shareQuantityOrValue: '$1,000,001 - $5,000,000 (20,000 shares)',
    assetClass: 'Stock',
    sourceDocumentUrl: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025535.pdf',
    cikOrMemberId: 'House Member ID: P000197'
  },
  {
    id: 'soc-trade-pelosi-bsyn',
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures (Sovereign Allocation)',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'BSYN',
    stockName: 'BioSynthetica Genomics International',
    marketType: 'stable',
    assetCategory: 'business',
    side: 'buy',
    shares: 4500,
    priceUSD: 32.00,
    totalValueUSD: 144000,
    timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    timestampAgo: '3d ago',
    commentary: 'Congressional disclosure: Capital allocation into BioSynthetica Genomics enterprise stock settled with 1:1 USD stablecoins.',
    settlementMethod: '1:1 USD Stablecoin',
    gainLossPercent: 6.4,
    disclosureType: 'STOCK Act PTR',
    executionDate: '2024-08-10',
    filingDate: '2024-08-16',
    shareQuantityOrValue: '$100,001 - $250,000',
    assetClass: 'Stock',
    sourceDocumentUrl: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025368.pdf',
    cikOrMemberId: 'House Member ID: P000197'
  },
  {
    id: 'soc-trade-pelosi-soln',
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures (Sovereign Allocation)',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol Ltd.',
    marketType: 'crypto',
    assetCategory: 'business',
    side: 'buy',
    shares: 6000,
    priceUSD: 14.50,
    totalValueUSD: 87000,
    timestamp: new Date(Date.now() - 1000 * 60 * 22).toISOString(),
    timestampAgo: '7d ago',
    commentary: 'Congressional disclosure: Acquired issued business shares in SolarNode microgrid energy infrastructure via crypto custody clearing.',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    gainLossPercent: 8.6,
    disclosureType: 'STOCK Act PTR',
    executionDate: '2024-07-14',
    filingDate: '2024-07-22',
    shareQuantityOrValue: '$50,001 - $100,000',
    assetClass: 'Stock',
    sourceDocumentUrl: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025368.pdf',
    cikOrMemberId: 'House Member ID: P000197'
  },
  {
    id: 'soc-trade-1',
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures (Sovereign Allocation)',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 1000,
    priceUSD: 128.50,
    totalValueUSD: 128500,
    timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    timestampAgo: '12d ago',
    commentary: 'Periodic disclosure report filed: Acquired 1,000 shares of Quantum Compute Sovereign Trust pursuant to personal portfolio asset allocation.',
    settlementMethod: 'USD Institutional Clearing (Fedwire / DTC)',
    gainLossPercent: 11.75
  },
  {
    id: 'soc-trade-2',
    traderType: 'famous',
    user: {
      uid: 'famous-buffett',
      name: 'Warren Buffett',
      handle: 'oracle_of_omaha',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Chairman & Sovereign Allocator',
      verified: true,
      winRate: '94.2%'
    },
    sourceDocumentUrl: 'https://www.sec.gov/Archives/edgar/data/1067983/000119312526352200/xslForm13F_X02/primary_doc.xml',
    ticker: 'VLT-YLD',
    stockName: 'Global Vault Yield & Treasury Corp',
    marketType: 'stable',
    assetCategory: 'business',
    side: 'buy',
    shares: 12000,
    priceUSD: 102.40,
    totalValueUSD: 1228800,
    timestamp: new Date(Date.now() - 1000 * 60 * 11).toISOString(),
    timestampAgo: '18d ago',
    commentary: 'Parked surplus capital into issued enterprise business stock with verifiable 5.2% cashflow yield and zero counterparty risk.',
    settlementMethod: '1:1 USD Stablecoin Wire',
    gainLossPercent: 2.15
  },
  {
    id: 'soc-trade-3',
    traderType: 'famous',
    disclosureType: 'On-Chain Proof of Reserve',
    user: {
      uid: 'demo-satoshi-nakamoto',
      name: 'Satoshi Nakamoto',
      handle: 'satoshi_nakamoto',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Pioneer of Sovereign Digital Cash',
      verified: true,
      winRate: '98.5%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 250,
    priceUSD: 128.50,
    totalValueUSD: 32125.00,
    timestamp: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
    timestampAgo: '24d ago',
    commentary: 'Allocated treasury reserve into Quantum Compute Sovereign Trust. Hardware acceleration layer powering sovereign computational intelligence.',
    settlementMethod: 'USD Institutional Clearing (Fedwire / DTC)',
    gainLossPercent: 15.00
  },
  {
    id: 'soc-trade-4',
    traderType: 'famous',
    sourceDocumentUrl: 'https://www.sec.gov/Archives/edgar/data/1050446/000119312526398168/xslF345X06/ownership.xml',
    user: {
      uid: 'famous-saylor',
      name: 'Michael Saylor',
      handle: 'saylor',
      avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
      title: 'Executive Chairman & Treasury Strategist',
      verified: true,
      winRate: '91.0%'
    },
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol Ltd.',
    marketType: 'crypto',
    assetCategory: 'business',
    side: 'buy',
    shares: 3500,
    priceUSD: 14.50,
    totalValueUSD: 50750,
    timestamp: new Date(Date.now() - 1000 * 60 * 27).toISOString(),
    timestampAgo: '29d ago',
    commentary: 'Acquired issued business stock shares in SolarNode. High-frequency decentralized microgrid routing backed by cryptographic proof-of-power.',
    settlementMethod: '1:1 Crypto Custody Ledger',
    gainLossPercent: 8.6
  },
  {
    id: 'soc-trade-5',
    traderType: 'friend',
    user: {
      uid: 'user-elena_rostova',
      name: 'Elena Rostova',
      handle: 'elena_rostova',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
      title: 'Lead Plasma Magnetics & Sovereign Trustee',
      verified: true,
      isFriend: true,
      friendsCount: 118,
      winRate: '83.7%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 400,
    priceUSD: 310.50,
    totalValueUSD: 124200,
    timestamp: new Date(Date.now() - 1000 * 60 * 42).toISOString(),
    timestampAgo: '2h ago',
    commentary: 'Acquired core position in Hyperion Quantum Fusion Robust balance sheet depth, ecosystem retention, and sovereign silicon performance.',
    settlementMethod: 'USD Automated Clearing House (ACH)',
    gainLossPercent: 8.95
  },
  {
    id: 'soc-trade-6',
    traderType: 'famous',
    user: {
      uid: 'famous-cathie',
      name: 'Cathie Wood',
      handle: 'cathie_ark',
      avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
      title: 'CIO, Disruptive Innovation Fund',
      verified: true,
      winRate: '79.2%'
    },
    ticker: 'BSYN',
    stockName: 'BioSynthetica Genomics International',
    marketType: 'stable',
    assetCategory: 'business',
    side: 'buy',
    shares: 2800,
    priceUSD: 32.00,
    totalValueUSD: 89600,
    timestamp: new Date(Date.now() - 1000 * 60 * 55).toISOString(),
    timestampAgo: '1d ago',
    commentary: 'Adding to disruptive life sciences position in BioSynthetica IPO. Tensor-accelerated enzyme engineering compresses clinical discovery timelines.',
    settlementMethod: '1:1 USD Stablecoin',
    gainLossPercent: 6.4
  },
  {
    id: 'soc-trade-7',
    traderType: 'famous',
    user: {
      uid: 'famous-elon',
      name: 'Elon Musk',
      handle: 'elonmusk',
      avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
      title: 'Technoking & Systems Architect',
      verified: true,
      winRate: '86.5%'
    },
    ticker: 'NEXA',
    stockName: 'Nexa Sovereign Robotics & AI Inc.',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 1800,
    priceUSD: 68.50,
    totalValueUSD: 123300,
    timestamp: new Date(Date.now() - 1000 * 60 * 75).toISOString(),
    timestampAgo: '3d ago',
    commentary: 'Secured primary equity stake in Nexa Robotics IPO. Superconducting actuators and humanoid spatial perception compute clusters.',
    settlementMethod: 'USD Fiat Direct Clearing',
    gainLossPercent: 7.8
  },
  {
    id: 'soc-trade-8',
    traderType: 'friend',
    user: {
      uid: 'user-lord_sterling',
      name: 'Lord Sterling',
      handle: 'sterling_vault',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Swiss Freeport Trustee & Sovereign Syndicate',
      verified: true,
      isFriend: true,
      friendsCount: 142,
      winRate: '88.9%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 500,
    priceUSD: 28.75,
    totalValueUSD: 14375,
    timestamp: new Date(Date.now() - 1000 * 60 * 95).toISOString(),
    timestampAgo: '7d ago',
    commentary: 'Direct syndicated backing into Alex Chen personal IPO. Verified 5-mode net worth audit confirmed at $25M NAV.',
    settlementMethod: 'Final Coin Sovereign Vault (AFNL)',
    gainLossPercent: 15.00
  },
  {
    id: 'soc-trade-9',
    traderType: 'friend',
    user: {
      uid: 'user-marcus_vance',
      name: 'Dr. Marcus Vance',
      handle: 'marcus_vance',
      avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Chief Scientist, Hyperion Fusion',
      verified: true,
      isFriend: true,
      friendsCount: 88,
      winRate: '81.2%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'crypto',
    assetCategory: 'business',
    side: 'buy',
    shares: 650,
    priceUSD: 84.20,
    totalValueUSD: 54730,
    timestamp: new Date(Date.now() - 1000 * 60 * 130).toISOString(),
    timestampAgo: '12d ago',
    commentary: 'Synergistic enterprise allocation into Quantum Compute trust to support real-time plasma simulation neural networks.',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    gainLossPercent: 5.4
  },
  {
    id: 'soc-trade-10',
    traderType: 'famous',
    user: {
      uid: 'famous-dalio',
      name: 'Ray Dalio',
      handle: 'raydalio',
      avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Macro Strategist',
      verified: true,
      winRate: '92.1%'
    },
    ticker: 'GLD-STBL',
    stockName: 'Sovereign Gold-Back Reserve Inc.',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 350,
    priceUSD: 552.00,
    totalValueUSD: 193200,
    timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    timestampAgo: '18d ago',
    commentary: 'Strategic All-Weather equity allocation into SPDR S&P 500 ETF Trust representing diversified broad market economic depth.',
    settlementMethod: 'USD Institutional Clearing (Fedwire / DTC)',
    gainLossPercent: 11.75
  },
  {
    id: 'soc-trade-11',
    traderType: 'famous',
    user: {
      uid: 'famous-ackman',
      name: 'Bill Ackman',
      handle: 'bill_ackman',
      avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
      title: 'CEO, Pershing Square Capital',
      verified: true,
      winRate: '87.2%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'global',
    side: 'buy',
    shares: 450,
    priceUSD: 118.50,
    totalValueUSD: 53325,
    timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    timestampAgo: '24d ago',
    commentary: 'Executing high-conviction buy on Quantum Compute. AI compute demand remains structurally undersupplied. Integrated execution via sovereign final clearing.',
    settlementMethod: 'Final Coin Clearing ($AFNL)',
    gainLossPercent: 4.2
  },
  {
    id: 'soc-trade-12',
    traderType: 'friend',
    user: {
      uid: 'user-sophia_vance',
      name: 'Sophia Vance',
      handle: 'sophiav',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
      title: 'Algorithm Designer & Quant',
      verified: true,
      isFriend: true,
      friendsCount: 245,
      winRate: '82.5%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion',
    marketType: 'global',
    side: 'buy',
    shares: 120,
    priceUSD: 226.40,
    totalValueUSD: 27168,
    timestamp: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
    timestampAgo: '29d ago',
    commentary: 'Scaling into Hyperion Quantum Fusion. Energy grid deployment and fusion contracts provide significant margin expansion.',
    settlementMethod: '$HYPR',
    gainLossPercent: 1.8
  },
  {
    id: 'soc-trade-13',
    traderType: 'famous',
    user: {
      uid: 'famous-jim_simons',
      name: 'Jim Simons',
      handle: 'renaissance_tech',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
      title: 'Founder, Renaissance Technologies',
      verified: true,
      winRate: '99.1%'
    },
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol',
    marketType: 'global',
    side: 'sell',
    shares: 800,
    priceUSD: 242.10,
    totalValueUSD: 193680,
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    timestampAgo: '2h ago',
    commentary: 'Algorithmic rebalancing: Trimming SolarNode position. Momentum signals suggest near-term consolidation after microgrid rollout.',
    settlementMethod: '$SOLN',
    gainLossPercent: -0.5
  }
];

export const LIVE_TRADE_TEMPLATES: Omit<SocialStockTrade, 'id' | 'timestamp' | 'timestampAgo'>[] = [
  // --- FIAT TRADES ---
  {
    traderType: 'famous',
    user: {
      uid: 'famous-jim_simons',
      name: 'Jim Simons',
      handle: 'renaissance_tech',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
      title: 'Founder, Renaissance Technologies',
      verified: true,
      winRate: '99.1%'
    },
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol',
    marketType: 'fiat',
    side: 'buy',
    shares: 500,
    priceUSD: 242.10,
    totalValueUSD: 121050,
    commentary: 'Quantitative signal detection: Re-accumulating SolarNode on local support levels. Clean microgrid licensing potential is high.',
    settlementMethod: '$SOLN',
    gainLossPercent: 1.2
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    side: 'buy',
    shares: 1200,
    priceUSD: 118.50,
    totalValueUSD: 142200,
    commentary: 'Periodic Congressional Disclosure: Added to Quantum Compute position following compute cluster expansion.',
    settlementMethod: '$QBIT',
    gainLossPercent: 14.2
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-ackman',
      name: 'Bill Ackman',
      handle: 'bill_ackman',
      avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
      title: 'CEO, Pershing Square Capital',
      verified: true,
      winRate: '87.2%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    side: 'buy',
    shares: 200,
    priceUSD: 118.50,
    totalValueUSD: 23700,
    commentary: 'Increased stake in Quantum Compute. Structural shift in sovereign ledger compute architecture is a multi-year tailwind.',
    settlementMethod: '$QBIT',
    gainLossPercent: 4.2
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion',
    marketType: 'fiat',
    side: 'buy',
    shares: 800,
    priceUSD: 226.40,
    totalValueUSD: 181120,
    commentary: 'Periodic transaction report: Added to Hyperion Quantum Fusion equity allocation as clean fusion deployment accelerates.',
    settlementMethod: '$HYPR',
    gainLossPercent: 3.5
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-elon',
      name: 'Elon Musk',
      handle: 'elonmusk',
      avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
      title: 'Technoking & Systems Architect',
      verified: true,
      winRate: '86.5%'
    },
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol',
    marketType: 'fiat',
    side: 'buy',
    shares: 1000,
    priceUSD: 242.10,
    totalValueUSD: 242100,
    commentary: 'Increased equity stake in SolarNode. Autonomous renewable microgrid rollout approaching critical scale.',
    settlementMethod: '$SOLN',
    gainLossPercent: 6.8
  },

  // --- STABLE TRADES ---
  {
    traderType: 'famous',
    user: {
      uid: 'famous-buffett',
      name: 'Warren Buffett',
      handle: 'oracle_of_omaha',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Chairman & Sovereign Allocator',
      verified: true,
      winRate: '94.2%'
    },
    ticker: 'BSYN',
    stockName: 'BioSynthetica Genomics International',
    marketType: 'stable',
    assetCategory: 'business',
    side: 'buy',
    shares: 3000,
    priceUSD: 32.00,
    totalValueUSD: 96000,
    commentary: 'Acquired issued enterprise shares in BioSynthetica. High return on invested capital and Swiss regulatory clearance.',
    settlementMethod: '1:1 USD Stablecoin',
    gainLossPercent: 6.4
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'BSYN',
    stockName: 'BioSynthetica Genomics International',
    marketType: 'stable',
    assetCategory: 'business',
    side: 'buy',
    shares: 2200,
    priceUSD: 32.00,
    totalValueUSD: 70400,
    commentary: 'Periodic disclosure: Allocated stablecoin treasury into BioSynthetica genomic diagnostics backlog.',
    settlementMethod: '1:1 USD Stablecoin',
    gainLossPercent: 5.1
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-buffett',
      name: 'Warren Buffett',
      handle: 'oracle_of_omaha',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Chairman & Sovereign Allocator',
      verified: true,
      winRate: '94.2%'
    },
    sourceDocumentUrl: 'https://www.sec.gov/Archives/edgar/data/1067983/000119312526352200/xslForm13F_X02/primary_doc.xml',
    ticker: 'VLT-YLD',
    stockName: 'Global Vault Yield & Treasury Corp',
    marketType: 'stable',
    assetCategory: 'business',
    side: 'buy',
    shares: 5000,
    priceUSD: 102.40,
    totalValueUSD: 512000,
    commentary: 'Parked surplus capital into issued enterprise business stock with verifiable 5.2% cashflow yield.',
    settlementMethod: '1:1 USD Stablecoin Wire',
    gainLossPercent: 2.15
  },

  // --- CRYPTO TRADES ---
  {
    traderType: 'famous',
    user: {
      uid: 'famous-saylor',
      name: 'Michael Saylor',
      handle: 'saylor',
      avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
      title: 'Executive Chairman & Treasury Strategist',
      verified: true,
      winRate: '91.0%'
    },
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol Ltd.',
    marketType: 'crypto',
    assetCategory: 'business',
    side: 'buy',
    shares: 2000,
    priceUSD: 14.50,
    totalValueUSD: 29000,
    commentary: 'Allocated to SolarNode business stock. High-efficiency decentralized energy settlement backed by crypto reserves.',
    settlementMethod: '1:1 Crypto Custody Ledger',
    gainLossPercent: 8.6
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol Ltd.',
    marketType: 'crypto',
    assetCategory: 'business',
    side: 'buy',
    shares: 2500,
    priceUSD: 14.50,
    totalValueUSD: 36250,
    commentary: 'Congressional disclosure: Reinvested into decentralized clean grid protocol SolarNode via crypto escrow.',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    gainLossPercent: 7.9
  },
  {
    traderType: 'friend',
    user: {
      uid: 'user-marcus_vance',
      name: 'Dr. Marcus Vance',
      handle: 'marcus_vance',
      avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Chief Scientist, Hyperion Fusion',
      verified: true,
      isFriend: true,
      friendsCount: 88,
      winRate: '81.2%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'crypto',
    assetCategory: 'business',
    side: 'buy',
    shares: 500,
    priceUSD: 84.20,
    totalValueUSD: 42100,
    commentary: 'Quantum compute enterprise routing allocation to support distributed neural lattice simulations.',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    gainLossPercent: 5.4
  },

  // --- FINAL / EQUITY TRADES ---
  {
    traderType: 'famous',
    user: {
      uid: 'famous-pelosi',
      name: 'Nancy Pelosi',
      handle: 'pelosi_portfolio',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      title: 'Congressional Disclosures',
      verified: true,
      winRate: '89.4%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 500,
    priceUSD: 128.50,
    totalValueUSD: 64250,
    commentary: 'Acquired additional common stock shares in Quantum Compute Sovereign Trust. High-performance enterprise compute market dominance.',
    settlementMethod: 'USD Institutional Clearing (Fedwire / DTC)',
    gainLossPercent: 11.75
  },
  {
    traderType: 'famous',
    disclosureType: 'On-Chain Proof of Reserve',
    user: {
      uid: 'demo-satoshi-nakamoto',
      name: 'Satoshi Nakamoto',
      handle: 'satoshi_nakamoto',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Pioneer of Sovereign Digital Cash',
      verified: true,
      winRate: '98.5%'
    },
    ticker: 'DEFI-S',
    stockName: 'DeFi Sovereign Prime Ledger',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 100,
    priceUSD: 440.00,
    totalValueUSD: 44000,
    commentary: 'Allocated sovereign treasury assets into DeFi Sovereign Prime Ledger. Cloud infrastructure resiliency and long-term capital stability.',
    settlementMethod: 'USD Institutional Clearing (Fedwire / DTC)',
    gainLossPercent: 15.00
  },
  {
    traderType: 'famous',
    user: {
      uid: 'famous-dalio',
      name: 'Ray Dalio',
      handle: 'raydalio',
      avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
      title: 'Founder & Macro Strategist',
      verified: true,
      winRate: '92.1%'
    },
    ticker: 'GLD-STBL',
    stockName: 'Sovereign Gold-Back Reserve Inc.',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 200,
    priceUSD: 552.00,
    totalValueUSD: 110400,
    commentary: 'Strategic All-Weather equity allocation into core index equities for institutional diversification.',
    settlementMethod: 'USD Institutional Clearing (Fedwire / DTC)',
    gainLossPercent: 11.75
  },
  {
    traderType: 'friend',
    user: {
      uid: 'user-elena_rostova',
      name: 'Elena Rostova',
      handle: 'elena_rostova',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
      title: 'Lead Plasma Magnetics & Sovereign Trustee',
      verified: true,
      isFriend: true,
      friendsCount: 118,
      winRate: '83.7%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'buy',
    shares: 350,
    priceUSD: 310.50,
    totalValueUSD: 108675,
    commentary: 'Reinforced holding in Final Network Treasury Equity. Zero-debt liquidity clearing backbone.',
    settlementMethod: 'USD Automated Clearing House (ACH)',
    gainLossPercent: 8.95
  },
  {
    traderType: 'famous',
    disclosureType: 'On-Chain Proof of Reserve',
    user: {
      uid: 'demo-satoshi-nakamoto',
      name: 'Satoshi Nakamoto',
      handle: 'satoshi_nakamoto',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      title: 'Pioneer of Sovereign Digital Cash',
      verified: true,
      winRate: '98.5%'
    },
    ticker: 'QBIT',
    stockName: 'Quantum Compute Sovereign Trust',
    marketType: 'fiat',
    assetCategory: 'business',
    side: 'sell',
    shares: 300,
    priceUSD: 29.50,
    totalValueUSD: 8850,
    commentary: 'Profit taking on Alex Chen personal equity tranche. Reallocating to base crypto vault reserves.',
    settlementMethod: 'Final Coin Sovereign Vault (AFNL)',
    gainLossPercent: 12.4
  },
  {
    traderType: 'friend',
    user: {
      uid: 'user-sophia_vance',
      name: 'Sophia Vance',
      handle: 'sophiav',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
      title: 'Algorithm Designer & Quant',
      verified: true,
      isFriend: true,
      friendsCount: 72,
      winRate: '85.9%'
    },
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion',
    marketType: 'global',
    assetCategory: 'business',
    side: 'sell',
    shares: 200,
    priceUSD: 228.10,
    totalValueUSD: 45620,
    commentary: 'Algorithmic signal: Trimming Hyperion position following short-term mean-reversion target achievement.',
    settlementMethod: '$HYPR',
    gainLossPercent: 4.5
  }
];

export const SHARED_SOCIAL_TRADES_KEY = 'final_finance_shared_social_trades';
export const SHARED_SOCIAL_TRADES_EVENT = 'final_finance_shared_social_trades_updated';

export function sanitizeSocialTrade(trade: SocialStockTrade): SocialStockTrade {
  const cleanFinalCoin = (trade.finalCoinSymbol || `$${trade.ticker}`)
    .replace(/-FNL/gi, '')
    .trim();
  const rawSettlement = trade.settlementMethod || '';
  const cleanSettlement = rawSettlement
    .replace(/Final Coin Clearing\s*[:\-\(]*/gi, '')
    .replace(/Final Coin Sovereign Vault\s*[:\-\(]*/gi, '')
    .replace(/-FNL/gi, '')
    .replace(/^\(|\)$/g, '')
    .trim();
  const cleanCommentary = (trade.commentary || '')
    .replace(/\(\$([A-Z]+)-FNL\)/gi, '($$$1)')
    .replace(/-FNL/gi, '');

  const text = `${trade.commentary || ''} ${trade.stockName || ''}`.toLowerCase();
  const inferredDeriv =
    trade.instrumentCategory === 'derivatives' ||
    (trade.derivativeType && trade.derivativeType !== 'spot') ||
    text.includes('on derivatives') ||
    text.includes('call option') ||
    text.includes('put option') ||
    text.includes('futures long') ||
    text.includes('futures short');

  return {
    ...trade,
    finalCoinSymbol: cleanFinalCoin.startsWith('$') ? cleanFinalCoin : `$${cleanFinalCoin}`,
    settlementMethod: cleanSettlement ? (cleanSettlement.startsWith('$') ? cleanSettlement : `$${cleanSettlement}`) : cleanFinalCoin,
    commentary: cleanCommentary,
    instrumentCategory: trade.instrumentCategory || (inferredDeriv ? 'derivatives' : 'equity'),
  };
}

export function getStoredSharedSocialTrades(): SocialStockTrade[] {
  try {
    const saved = localStorage.getItem(SHARED_SOCIAL_TRADES_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed.map((t: SocialStockTrade) => sanitizeSocialTrade(t));
      }
    }
  } catch (err) {
    console.warn('Failed to load shared social trades from localStorage', err);
  }
  return [];
}

export function saveSharedSocialTrade(trade: SocialStockTrade): SocialStockTrade[] {
  const sanitized = sanitizeSocialTrade(trade);
  const existing = getStoredSharedSocialTrades();
  const next = [sanitized, ...existing.filter((t) => t.id !== sanitized.id)].slice(0, 100);
  try {
    localStorage.setItem(SHARED_SOCIAL_TRADES_KEY, JSON.stringify(next));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(SHARED_SOCIAL_TRADES_EVENT, { detail: { trade, trades: next } }));
    }
  } catch (err) {
    console.warn('Failed to save shared social trade to localStorage', err);
  }
  return next;
}

export function removeSharedSocialTrade(tradeId: string): SocialStockTrade[] {
  const existing = getStoredSharedSocialTrades();
  const next = existing.filter((t) => t.id !== tradeId);
  try {
    localStorage.setItem(SHARED_SOCIAL_TRADES_KEY, JSON.stringify(next));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(SHARED_SOCIAL_TRADES_EVENT, { detail: { trades: next } }));
    }
  } catch (err) {
    console.warn('Failed to remove shared social trade from localStorage', err);
  }
  return next;
}

