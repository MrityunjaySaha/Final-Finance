import React, { useState } from 'react';
import { 
  X, 
  CreditCard, 
  Building2, 
  Coins, 
  ShieldAlert, 
  CheckCircle2, 
  Lock, 
  ArrowRight,
  AlertTriangle,
  Receipt,
  Sparkles
} from 'lucide-react';
import { UserWalletData } from '../../types/wallet';
import { ConfirmModal } from '../common/ConfirmModal';

interface AccountPayModalProps {
  isOpen: boolean;
  onClose: () => void;
  negativeBalance: number; // e.g. -1450 (or positive number representing debt)
  walletData: UserWalletData;
  onConfirmPayment: (paymentAmount: number, sourceLabel: string, methodType: string) => void;
}

export const AccountPayModal: React.FC<AccountPayModalProps> = ({
  isOpen,
  onClose,
  negativeBalance,
  walletData,
  onConfirmPayment,
}) => {
  const deficitAmount = Math.abs(negativeBalance);

  // Pay options: 'full' | 'cushion' | 'custom'
  const [payOption, setPayOption] = useState<'full' | 'cushion' | 'custom'>('full');
  const [customAmount, setCustomAmount] = useState<string>(deficitAmount.toString());
  const [selectedMethodId, setSelectedMethodId] = useState<string>('bank-primary');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [showConfirm, setShowConfirm] = useState(false);

  if (!isOpen) return null;

  const getEffectivePaymentAmount = () => {
    if (payOption === 'full') return deficitAmount;
    if (payOption === 'cushion') return deficitAmount + 500;
    return parseFloat(customAmount) || 0;
  };

  const paymentAmount = getEffectivePaymentAmount();
  const projectedBalance = negativeBalance + paymentAmount;

  const linkedBanks = walletData.linkedBankAccounts || [];
  const linkedCards = walletData.linkedCards || [];

  const handlePaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (paymentAmount <= 0) return;

    setShowConfirm(true);
  };

  const processExecution = () => {
    setIsProcessing(true);
    setTimeout(() => {
      let sourceLabel = 'Linked Bank Wire';
      let methodType = 'bank';

      if (selectedMethodId.startsWith('bank-')) {
        const found = linkedBanks.find(b => b.id === selectedMethodId.replace('bank-', ''));
        sourceLabel = found ? `${found.bankName} (•••• ${found.accountNumberLast4})` : 'JPMorgan Chase (•••• 8920)';
        methodType = 'bank';
      } else if (selectedMethodId.startsWith('card-')) {
        const found = linkedCards.find(c => c.id === selectedMethodId.replace('card-', ''));
        sourceLabel = found ? `${found.brand.toUpperCase()} (•••• ${found.cardNumberLast4})` : 'Visa Signature (•••• 4242)';
        methodType = 'card';
      } else if (selectedMethodId === 'fnl-treasury') {
        sourceLabel = 'Final Coin (AFNL) Treasury Settlement';
        methodType = 'crypto';
      } else if (selectedMethodId === 'usdc-instant') {
        sourceLabel = 'USDC Instant Settlement';
        methodType = 'crypto';
      }

      onConfirmPayment(paymentAmount, sourceLabel, methodType);
      setIsProcessing(false);
      onClose();
    }, 600);
  };

  return (
    <div 
      id="account-pay-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="account-pay-modal-container"
        className="relative w-full max-w-lg rounded-3xl bg-white border border-rose-200 shadow-2xl overflow-hidden my-8 animate-in zoom-in-95 duration-200"
      >
        {/* Top Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900 leading-tight">
                Settle Account Balance
              </h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handlePaySubmit} className="p-6 space-y-6">
          {/* Balance Summary Card */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Total Due
              </span>
              <span className="text-3xl font-bold font-mono text-slate-900 mt-0.5 block">
                ${deficitAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Balance After
              </span>
              <span className={`text-xl font-bold font-mono ${projectedBalance >= 0 ? 'text-emerald-600' : 'text-rose-600'} mt-0.5 block`}>
                ${projectedBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* Payment Options */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-900 block">
              Payment Amount
            </label>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPayOption('full')}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                  payOption === 'full'
                    ? 'border-indigo-500 bg-indigo-50 shadow-inner'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <span className="text-[11px] font-bold text-slate-500 uppercase">Pay Full</span>
                <p className="text-sm font-bold font-mono text-slate-900 mt-1">${deficitAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
              </button>

              <button
                type="button"
                onClick={() => setPayOption('custom')}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                  payOption === 'custom'
                    ? 'border-indigo-500 bg-indigo-50 shadow-inner'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <span className="text-[11px] font-bold text-slate-500 uppercase">Custom</span>
                <p className="text-sm font-bold font-mono text-slate-900 mt-1">Enter Amount</p>
              </button>
            </div>

            {payOption === 'custom' && (
              <div className="relative">
                <span className="absolute left-4 top-3 text-sm font-bold text-slate-500 font-mono">$</span>
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  className="w-full pl-9 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-bold font-mono text-slate-900 focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>
            )}
          </div>


          {/* Payment Method Selector */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-900 block">
              Payment Source
            </label>

            <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
              {/* Linked Banks */}
              {linkedBanks.map((bank) => (
                <label
                  key={bank.id}
                  className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedMethodId === `bank-${bank.id}`
                      ? 'border-emerald-500 bg-emerald-50/50 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentSource"
                      value={`bank-${bank.id}`}
                      checked={selectedMethodId === `bank-${bank.id}`}
                      onChange={() => setSelectedMethodId(`bank-${bank.id}`)}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <div className="p-2 rounded-xl bg-blue-50 border border-blue-200 text-blue-700">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        {bank.bankName}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        {bank.accountType} •••• {bank.accountNumberLast4}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Instant Clearing
                  </span>
                </label>
              ))}

              {/* Linked Cards */}
              {linkedCards.map((card) => (
                <label
                  key={card.id}
                  className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedMethodId === `card-${card.id}`
                      ? 'border-emerald-500 bg-emerald-50/50 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentSource"
                      value={`card-${card.id}`}
                      checked={selectedMethodId === `card-${card.id}`}
                      onChange={() => setSelectedMethodId(`card-${card.id}`)}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-700">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900 block capitalize">
                        {card.brand} {card.cardType}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        •••• {card.cardNumberLast4}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                    Debit / Credit
                  </span>
                </label>
              ))}

              {/* Stablecoin USDC option */}
              <label
                className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                  selectedMethodId === 'usdc-instant'
                    ? 'border-emerald-500 bg-emerald-50/50 shadow-2xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="paymentSource"
                    value="usdc-instant"
                    checked={selectedMethodId === 'usdc-instant'}
                    onChange={() => setSelectedMethodId('usdc-instant')}
                    className="text-emerald-600 focus:ring-emerald-500"
                  />
                  <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700">
                    <Coins className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      USD Coin (USDC)
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      Direct Escrow Pay
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Instant Par
                </span>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-2xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing || paymentAmount <= 0}
              className="flex-2 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              {isProcessing ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Processing Payment...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Authorize Payment of ${paymentAmount.toLocaleString()}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title="Confirm Payment"
        message={`Are you sure you want to authorize a payment of $${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} to settle your account deficit?`}
        confirmText="Confirm Payment"
        type="warning"
      />
    </div>
  );
};
