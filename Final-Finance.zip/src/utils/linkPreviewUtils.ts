export interface ExternalLinkPreviewData {
  url: string;
  finalUrl?: string;
  domain: string;
  title: string;
  description: string;
  imageUrl?: string;
  fallbackImageUrl?: string;
  siteName?: string;
  authorName?: string;
  mediaType?: 'video' | 'audio' | 'article' | 'website';
  videoId?: string;
  faviconUrl?: string;
  resolved?: boolean;
  isLoading?: boolean;
}

const CACHE_STORAGE_KEY = 'final_finance_link_preview_cache_v1';
const CACHE_TTL_MS = 30 * 60 * 1000;
const memoryCache = new Map<string, { data: ExternalLinkPreviewData; expiresAt: number }>();
const inflightRequests = new Map<string, Promise<ExternalLinkPreviewData>>();

function loadStoredCache(): Record<string, { data: ExternalLinkPreviewData; expiresAt: number }> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(CACHE_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function saveToCache(url: string, data: ExternalLinkPreviewData): void {
  const entry = { data: { ...data, isLoading: false }, expiresAt: Date.now() + CACHE_TTL_MS };
  memoryCache.set(url, entry);
  if (typeof window === 'undefined') return;
  try {
    const current = loadStoredCache();
    const now = Date.now();
    const cleaned: Record<string, { data: ExternalLinkPreviewData; expiresAt: number }> = {};
    const keys = Object.keys(current).filter((k) => current[k]?.expiresAt > now).slice(-120);
    for (const k of keys) {
      cleaned[k] = current[k];
    }
    cleaned[url] = entry;
    localStorage.setItem(CACHE_STORAGE_KEY, JSON.stringify(cleaned));
  } catch {}
}

export function getCachedExternalLinkPreview(url: string): ExternalLinkPreviewData | null {
  const mem = memoryCache.get(url);
  if (mem && Date.now() < mem.expiresAt) {
    return mem.data;
  }
  const stored = loadStoredCache();
  const entry = stored[url];
  if (entry && Date.now() < entry.expiresAt && entry.data) {
    memoryCache.set(url, entry);
    return entry.data;
  }
  return null;
}

export function extractYouTubeVideoId(urlStr: string): string | null {
  try {
    const u = new URL(urlStr);
    const host = u.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'youtu.be') {
      const id = u.pathname.split('/').filter(Boolean)[0];
      return id && /^[a-zA-Z0-9_-]{6,20}$/.test(id) ? id : null;
    }
    if (host.endsWith('youtube.com') || host === 'youtube-nocookie.com') {
      const v = u.searchParams.get('v');
      if (v && /^[a-zA-Z0-9_-]{6,20}$/.test(v)) return v;
      const segments = u.pathname.split('/').filter(Boolean);
      if (segments.length >= 2 && ['shorts', 'live', 'embed', 'v', 'watch'].includes(segments[0])) {
        const id = segments[1];
        if (id && /^[a-zA-Z0-9_-]{6,20}$/.test(id)) return id;
      }
    }
  } catch {}
  return null;
}

function cleanMatchedUrl(raw: string): string {
  let cleaned = raw.trim();
  // Strip trailing punctuation often typed after a URL in sentences
  while (cleaned.length > 0 && /[.,!?;:'"\]>]$/.test(cleaned)) {
    cleaned = cleaned.slice(0, -1);
  }
  // Balance trailing parentheses if unbalanced
  while (cleaned.endsWith(')')) {
    const openCount = (cleaned.match(/\(/g) || []).length;
    const closeCount = (cleaned.match(/\)/g) || []).length;
    if (closeCount > openCount) {
      cleaned = cleaned.slice(0, -1);
    } else {
      break;
    }
  }
  return cleaned;
}

function isInternalAppDeepLink(parsed: URL): boolean {
  const hasInternalParam =
    parsed.searchParams.has('listing') ||
    parsed.searchParams.has('stock') ||
    parsed.searchParams.has('profile') ||
    parsed.searchParams.has('user') ||
    parsed.searchParams.has('tweet') ||
    parsed.searchParams.has('community');

  if (hasInternalParam) {
    if (typeof window === 'undefined') return true;
    const sameHost = parsed.hostname === window.location.hostname;
    if (sameHost || parsed.hostname.endsWith('.run.app') || parsed.hostname === 'localhost') {
      return true;
    }
  }
  return false;
}

function buildReadableSlugTitle(parsed: URL, domain: string): string {
  const segments = parsed.pathname
    .split('/')
    .map((s) => s.trim())
    .filter(Boolean);
  if (segments.length === 0) return domain;
  const last = decodeURIComponent(segments[segments.length - 1])
    .replace(/\.(html?|php|aspx?|jsp)$/i, '')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!last || last.length < 2) return domain;
  return last.charAt(0).toUpperCase() + last.slice(1);
}

export function extractExternalUrls(text: string): string[] {
  if (!text) return [];
  const urlRegex = /https?:\/\/[^\s<>"'`]+/gi;
  const matches = text.match(urlRegex);
  if (!matches) return [];

  const urls: string[] = [];
  const seen = new Set<string>();

  for (const raw of matches) {
    const cleaned = cleanMatchedUrl(raw);
    if (!cleaned || seen.has(cleaned)) continue;
    try {
      const parsed = new URL(cleaned);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') continue;
      if (isInternalAppDeepLink(parsed)) continue;
      seen.add(cleaned);
      urls.push(cleaned);
    } catch {}
  }
  return urls;
}

export function buildInitialLinkPreview(rawUrl: string): ExternalLinkPreviewData {
  const cached = getCachedExternalLinkPreview(rawUrl);
  if (cached) {
    return { ...cached, isLoading: false };
  }

  try {
    const parsed = new URL(rawUrl);
    const domain = parsed.hostname.replace(/^www\./, '').toLowerCase();
    const ytId = extractYouTubeVideoId(rawUrl);

    if (ytId) {
      return {
        url: rawUrl,
        domain,
        title: `Loading YouTube video title…`,
        description: parsed.pathname.includes('/shorts/') ? 'YouTube Shorts' : 'YouTube Video',
        imageUrl: `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg`,
        fallbackImageUrl: `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`,
        siteName: 'YouTube',
        mediaType: 'video',
        videoId: ytId,
        faviconUrl: 'https://www.youtube.com/favicon.ico',
        resolved: false,
        isLoading: true,
      };
    }

    if (domain === 'github.com') {
      const parts = parsed.pathname.split('/').filter(Boolean);
      const repoLabel = parts.length >= 2 ? `${parts[0]}/${parts[1]}` : buildReadableSlugTitle(parsed, domain);
      const ogImg =
        parts.length >= 2
          ? `https://opengraph.githubassets.com/1/${encodeURIComponent(parts[0])}/${encodeURIComponent(parts[1])}`
          : undefined;
      return {
        url: rawUrl,
        domain,
        title: repoLabel,
        description: `github.com${parsed.pathname}`,
        imageUrl: ogImg,
        siteName: 'GitHub',
        mediaType: 'website',
        faviconUrl: 'https://github.com/favicon.ico',
        resolved: false,
        isLoading: true,
      };
    }

    const isLikelyVideo =
      domain.includes('vimeo.com') ||
      domain.includes('tiktok.com') ||
      domain.includes('twitch.tv') ||
      domain.includes('dailymotion.com') ||
      domain === 'dai.ly';

    return {
      url: rawUrl,
      domain,
      title: buildReadableSlugTitle(parsed, domain),
      description: parsed.pathname && parsed.pathname !== '/' ? `${domain}${parsed.pathname}` : rawUrl,
      siteName: domain,
      mediaType: isLikelyVideo ? 'video' : 'website',
      faviconUrl: `${parsed.origin}/favicon.ico`,
      resolved: false,
      isLoading: true,
    };
  } catch {
    return {
      url: rawUrl,
      domain: 'external',
      title: rawUrl,
      description: rawUrl,
      resolved: false,
      isLoading: false,
    };
  }
}

export function extractExternalLinks(
  text: string,
  savedPreviews?: Record<string, ExternalLinkPreviewData>
): ExternalLinkPreviewData[] {
  const urls = extractExternalUrls(text);
  return urls.map((url) => {
    const saved = savedPreviews?.[url];
    if (saved && saved.title) {
      return { ...saved, isLoading: false };
    }
    return buildInitialLinkPreview(url);
  });
}

export async function fetchExternalLinkPreview(rawUrl: string): Promise<ExternalLinkPreviewData> {
  const cached = getCachedExternalLinkPreview(rawUrl);
  if (cached && cached.resolved) {
    return cached;
  }

  const existingInflight = inflightRequests.get(rawUrl);
  if (existingInflight) return existingInflight;

  const promise = (async (): Promise<ExternalLinkPreviewData> => {
    const fallbackInitial = buildInitialLinkPreview(rawUrl);
    try {
      const resp = await fetch(`/api/link-preview?url=${encodeURIComponent(rawUrl)}`);
      if (resp.ok) {
        const json = await resp.json();
        if (json?.success && json?.data) {
          const resolvedData: ExternalLinkPreviewData = {
            ...json.data,
            url: rawUrl,
            isLoading: false,
          };
          saveToCache(rawUrl, resolvedData);
          return resolvedData;
        }
      }
    } catch {}

    // Client fallback: if YouTube oEmbed wasn't reached via server, try public YouTube oEmbed / noembed directly
    const ytId = extractYouTubeVideoId(rawUrl);
    if (ytId) {
      try {
        const ytRes = await fetch(
          `https://www.youtube.com/oembed?url=${encodeURIComponent(rawUrl)}&format=json`
        );
        if (ytRes.ok) {
          const ytJson = await ytRes.json();
          const result: ExternalLinkPreviewData = {
            ...fallbackInitial,
            title: ytJson.title || `YouTube Video (${ytId})`,
            authorName: ytJson.author_name || undefined,
            description: ytJson.author_name ? `YouTube · ${ytJson.author_name}` : 'YouTube Video',
            imageUrl: `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg`,
            fallbackImageUrl: ytJson.thumbnail_url || `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`,
            siteName: 'YouTube',
            mediaType: 'video',
            videoId: ytId,
            resolved: true,
            isLoading: false,
          };
          saveToCache(rawUrl, result);
          return result;
        }
      } catch {}
    }

    const finalFallback: ExternalLinkPreviewData = {
      ...fallbackInitial,
      title: fallbackInitial.title.startsWith('Loading YouTube')
        ? `YouTube Video (${ytId})`
        : fallbackInitial.title,
      isLoading: false,
    };
    return finalFallback;
  })().finally(() => {
    inflightRequests.delete(rawUrl);
  });

  inflightRequests.set(rawUrl, promise);
  return promise;
}
