import React from 'react';
import { AuthSession } from '../types/auth';
import { UserPublicProfile } from '../types/social';
import { SocialPage, SocialTab } from './SocialPage';

interface CommunitySearchPageProps {
  currentUser?: AuthSession | null;
  initialTab?: SocialTab;
  onViewProfile?: (userIdOrHandle: string) => void;
  onViewUserProfile?: (userIdOrHandle: string) => void;
  onOpenDirectMessage: (targetUser: UserPublicProfile) => void;
  onCreateGroupChat?: () => void;
  onNavigateBack?: () => void;
  onSelectProduct?: any;
}

export const CommunitySearchPage: React.FC<CommunitySearchPageProps> = ({
  currentUser,
  initialTab = 'discover',
  onViewProfile,
  onViewUserProfile,
  onOpenDirectMessage,
  onNavigateBack,
}) => {
  return (
    <SocialPage
      currentUser={currentUser}
      initialTab={initialTab}
      onViewProfile={onViewProfile || onViewUserProfile || (() => {})}
      onOpenDirectMessage={onOpenDirectMessage}
      onNavigateBack={onNavigateBack}
    />
  );
};
