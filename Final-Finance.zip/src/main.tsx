import {createRoot} from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import './index.css';

if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  registerSW({
    immediate: true,
    onRegisterError(error) {
      console.warn('Service worker registration warning:', error);
    },
  });
}

console.log('Main.tsx: Application starting...');
const rootElement = document.getElementById('root');
if (!rootElement) {
  console.error('CRITICAL: Root element not found!');
}
createRoot(rootElement!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>,
);
console.log('Main.tsx: Render called');

