export interface GeneralStockMediaItem {
  id: string;
  ticker: string;
  type: 'photo' | 'video';
  url: string;
  name: string;
  uploaderName?: string;
  timestamp: string;
}

export const STOCK_GENERAL_MEDIA_STORAGE_KEY = 'final_finance_stock_general_media_v2';
export const STOCK_GENERAL_MEDIA_UPDATED_EVENT = 'final_finance_stock_general_media_updated';

export function getDefaultGeneralMedia(ticker: string): GeneralStockMediaItem[] {
  const upper = ticker.toUpperCase();
  return [
    {
      id: `gm-${upper}-1`,
      ticker: upper,
      type: 'photo',
      url: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&q=80&w=800',
      name: `${upper} Executive Sovereign Headquarters & Secure Reserve Vault`,
      uploaderName: 'Sovereign Custody Desk',
      timestamp: '2 hours ago'
    },
    {
      id: `gm-${upper}-2`,
      ticker: upper,
      type: 'photo',
      url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800',
      name: `${upper} Algorithmic High-Frequency Liquidity & Proof-of-Solvency Engine`,
      uploaderName: 'Quant Operations',
      timestamp: 'Yesterday'
    }
  ];
}

export function getGeneralStockMedia(ticker: string): GeneralStockMediaItem[] {
  try {
    const raw = localStorage.getItem(STOCK_GENERAL_MEDIA_STORAGE_KEY);
    const upper = ticker.toUpperCase();
    if (!raw) return getDefaultGeneralMedia(upper);
    const parsed = JSON.parse(raw) as GeneralStockMediaItem[];
    const tickerItems = parsed.filter((item) => item.ticker?.toUpperCase() === upper);
    return tickerItems.length > 0 ? tickerItems : getDefaultGeneralMedia(upper);
  } catch {
    return getDefaultGeneralMedia(ticker);
  }
}

export function saveGeneralStockMedia(item: GeneralStockMediaItem): void {
  try {
    const raw = localStorage.getItem(STOCK_GENERAL_MEDIA_STORAGE_KEY);
    const parsed = raw ? (JSON.parse(raw) as GeneralStockMediaItem[]) : [];
    // Ensure ticker is uppercase
    const toSave = { ...item, ticker: item.ticker.toUpperCase() };
    parsed.unshift(toSave);
    localStorage.setItem(STOCK_GENERAL_MEDIA_STORAGE_KEY, JSON.stringify(parsed));
    window.dispatchEvent(new CustomEvent(STOCK_GENERAL_MEDIA_UPDATED_EVENT, { detail: toSave }));
  } catch (err) {
    console.error('Failed saving general stock media:', err);
  }
}

export function deleteGeneralStockMedia(id: string): void {
  try {
    const raw = localStorage.getItem(STOCK_GENERAL_MEDIA_STORAGE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw) as GeneralStockMediaItem[];
    const next = parsed.filter((item) => item.id !== id);
    localStorage.setItem(STOCK_GENERAL_MEDIA_STORAGE_KEY, JSON.stringify(next));
    window.dispatchEvent(new CustomEvent(STOCK_GENERAL_MEDIA_UPDATED_EVENT));
  } catch (err) {
    console.error('Failed deleting general stock media:', err);
  }
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Failed to read ${file.name}.`));
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(file);
  });
}
