import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Sparkles, 
  MessageSquare, 
  UserPlus, 
  UserCheck, 
  Clock, 
  Check, 
  Ban,
  Shield,
  ShieldCheck,
  Package, 
  Loader2, 
  Phone, 
  Video, 
  Share2, 
  CheckCircle2, 
  Camera, 
  Upload, 
  X, 
  Globe, 
  Users, 
  Lock, 
  Unlock,
  ShieldAlert,
  ChevronRight, 
  ArrowLeft,
  ArrowRight,
  UserMinus,
  AlertTriangle,
  Coins,
  DollarSign,
  Tag,
  AlertCircle,
  Edit3,
  AtSign,
  Mail,
  FileText,
  Send,
  ArrowRightLeft,
  Receipt,
  HandCoins,
  Star,
  LayoutGrid,
  Building2,
  FolderHeart,
  Twitter,
  Heart,
  Repeat2,
  MessageCircle,
  Bookmark,
  Eye,
  Trash2,
  BarChart2,
  Hash,
  Gavel
} from 'lucide-react';
import { ProvideLoanModal } from './ProvideLoanModal';
import { ConfirmModal } from './common/ConfirmModal';
import { getUserFinalLoanDefaultCount, isRegisteredInternalBank } from '../services/loanService';
import { AuthSession } from '../types/auth';
import { UserPublicProfile, RelationshipStatus, FriendGroup, GroupMemberAssignment } from '../types/social';
import { Tweet } from '../types/tweet';
import { MAX_CUSTOM_GROUP_MEMBERS, getUserFriendGroups, updateFriendGroup } from '../services/friendGroupService';
import { MarketplaceListing } from '../types/marketplace';
import { StockItem } from '../types/stocks';
import { TweetRichEmbeds } from './social/TweetRichEmbeds';
import { UniversalLedgerItem } from '../types/ledger';
import { 
  getUserProfile, 
  getRelationshipStatus, 
  followUser, 
  unfollowUser, 
  sendFriendRequest, 
  cancelFriendRequest, 
  acceptFriendRequest, 
  removeFriend, 
  blockUser, 
  unblockUser,
  updateUserPublicProfile,
  getUserSocialCounts,
  areUsersBlockedEitherWay,
  isUserBlockedByTarget,
  getIdentityAliases,
  enqueueUserNotification,
  isAdminAccount
} from '../services/socialService';
import { dispatchGlobalNotification } from '../utils/notificationService';
import {
  getStoredTweets,
  toggleTweetLike,
  toggleTweetRetweet,
  toggleTweetBookmark,
  voteInTweetPoll,
  addTweetReply,
  toggleTweetReplyLike,
  deleteTweet,
  extractMentions,
  createTweet,
  TWEETS_UPDATED_EVENT
} from '../services/tweetingService';
import { updateUserAccountProfile, checkUserIdAvailability, checkEmailAvailability } from '../services/firebaseAuth';
import {
  getUserListings,
  incrementMarketplaceListingViews,
  getAllMarketplaceListings,
  ensureSampleAuctionsForUser,
  getAuctionRemainingLabel,
  getCurrentAuctionPriceUSD
} from '../services/marketplaceService';
import {
  getSellerPostsAverageRating,
  getReviewsForListing,
  getAverageRatingForListing,
  getUserReviewForListing,
  savePostReview,
  canUserRateListing,
  isUserListingOwner,
  POST_RATINGS_UPDATED_EVENT
} from '../services/postRatingService';
import { PeerTransferModal } from './profile/PeerTransferModal';
import { getTransfersBetweenUsers, executeAdminTransfer } from '../utils/transferService';
import { recordLedgerTransaction } from '../utils/universalLedgerBridge';
import { UserRatingSection } from './profile/UserRatingSection';
import { getAverageRating } from '../services/ratingService';

interface UserProfileViewProps {
  userIdOrHandle: string;
  currentUser?: AuthSession | null;
  onUpdateSession?: (user: AuthSession) => void;
  onOpenDirectMessage: (targetUser: UserPublicProfile) => void;
  onOpenVoiceCall?: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }) => void;
  onOpenVideoCall?: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }) => void;
  onNavigateBack?: () => void;
  backLabel?: string;
  onViewListingDetail?: (listing: MarketplaceListing) => void;
  onOpenVerificationModal?: () => void;
  onOpenSharedListing?: (listingId: string) => void;
  onSelectStock?: (stock: StockItem) => void;
  returnListingId?: string | null;
  onListingFocusRestored?: () => void;
}

const PRESET_COVERS = [
  {
    id: 'gold-bullion',
    name: 'Gold Bullion Reserve',
    url: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'financial-district',
    name: 'Global Financial Center',
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'zurich-vault',
    name: 'Zurich Secure Depository',
    url: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'crypto-ledger',
    name: 'Quantum Ledger Core',
    url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dark-obsidian',
    name: 'Obsidian Silk Carbon',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80'
  }
];

const getBankInfo = (userId: string) => {
  const normId = userId.toLowerCase();
  if (normId.includes('satoshi')) {
    return {
      bankName: 'Neo Tokyo Trust',
      capacity: '125,000,000 AFNL',
      role: 'Sovereign Protocol Pioneer',
      description: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic ledger consensus and decentralized consumer banking.'
    };
  }
  if (normId.includes('sterling') || normId.includes('swiss')) {
    return {
      bankName: 'Swiss Sovereign Reserve',
      capacity: '500,000,000 AFNL',
      role: 'Swiss Freeport Trustee',
      description: 'Sovereign Inter-Bank Clearing Node. Direct physical gold depository bullion backing, multi-signature trust structures.'
    };
  }
  if (normId.includes('jordan') || normId.includes('belfort')) {
    return {
      bankName: 'Wall Street Liquidity Partners',
      capacity: '250,000,000 AFNL',
      role: 'Escrow Lead & Vault Allocator',
      description: 'Active reserve market-making vault and bilateral sovereign escrow authority. Specializing in high-velocity liquidity allocation.'
    };
  }
  if (normId.includes('alex') || normId.includes('morgan')) {
    return {
      bankName: 'Zurich Freeport Clearing',
      capacity: '150,000,000 AFNL',
      role: 'Institutional Commodity Desk Arbiter',
      description: 'Precious metal clearing vault. Fully licensed and certified for gold bullion allocations, settlement audits, and sovereign clearing.'
    };
  }
  
  // Dynamic user-approved bank from localStorage
  const localBankName = localStorage.getItem(`ff_bank_app_name_${userId}`);
  if (localBankName) {
    return {
      bankName: localBankName,
      capacity: '100,000,000 AFNL',
      role: 'Approved Clearing Bank',
      description: 'Your authorized Clearing Bank. Authorized by Protocol Admin to issue sovereign credit, provide AFNL loans, and process settlement clearances.'
    };
  }

  return {
    bankName: 'Sovereign Reserve Vault',
    capacity: '50,000,000 AFNL',
    role: 'Licensed Banking Node',
    description: 'Licensed sovereign settlement node backed by multi-signature digital asset custody accounts.'
  };
};

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  userIdOrHandle,
  currentUser,
  onUpdateSession,
  onOpenDirectMessage,
  onOpenVoiceCall,
  onOpenVideoCall,
  onNavigateBack,
  backLabel,
  onViewListingDetail,
  onOpenVerificationModal,
  onOpenSharedListing,
  onSelectStock,
  returnListingId,
  onListingFocusRestored,
}) => {
  const [profile, setProfile] = useState<UserPublicProfile | null>(null);
  const [userListings, setUserListings] = useState<MarketplaceListing[]>([]);

  useEffect(() => {
    if (!returnListingId) return;
    setActiveTab('posts');

    const targetListing = userListings.find(l => l.id === returnListingId);
    if (targetListing) {
      const done = isListingDone(targetListing);
      if (done) {
        setPostsStatusFilter('done');
      } else {
        setPostsStatusFilter('active');
      }
    }

    let attempts = 0;
    const tryScroll = () => {
      const el = document.querySelector(`[data-listing-id="${returnListingId}"]`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.add('ring-4', 'ring-blue-500', 'transition-all', 'duration-500');
        setTimeout(() => {
          el.classList.remove('ring-4', 'ring-blue-500');
          if (onListingFocusRestored) {
            onListingFocusRestored();
          }
        }, 2000);
      } else if (attempts < 15) {
        attempts++;
        setTimeout(tryScroll, 100);
      }
    };

    const timer = setTimeout(tryScroll, 150);
    return () => clearTimeout(timer);
  }, [returnListingId, userListings, onListingFocusRestored]);
  const [relationship, setRelationship] = useState<RelationshipStatus>({
    isFollowing: false,
    isFollower: false,
    isFriend: false,
    friendStatus: 'none',
    isBlocked: false,
    isBlockedByMe: false,
    isBlockedByTarget: false,
  });
  const [followersCount, setFollowersCount] = useState<number>(0);
  const [followingCount, setFollowingCount] = useState<number>(0);
  const [friendsCount, setFriendsCount] = useState<number>(0);
  const [defaultCount, setDefaultCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isActionLoading, setIsActionLoading] = useState(false);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [showUnfriendConfirm, setShowUnfriendConfirm] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [saveToastMessage, setSaveToastMessage] = useState<string | null>(null);

  // Photo customization modal states
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [isCoverModalOpen, setIsCoverModalOpen] = useState(false);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [customCoverUrl, setCustomCoverUrl] = useState('');
  const [isSavingPhoto, setIsSavingPhoto] = useState(false);

  // Full Profile Edit Modal State
  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  const [editFullName, setEditFullName] = useState('');
  const [editUserId, setEditUserId] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');
  const [editCoverUrl, setEditCoverUrl] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [editErrorMessage, setEditErrorMessage] = useState('');
  const [userIdStatus, setUserIdStatus] = useState<{ available: boolean; message?: string }>({ available: true });
  const [emailStatus, setEmailStatus] = useState<{ available: boolean; message?: string }>({ available: true });

  // Peer-to-Peer Transfer Modal and Ledger History State
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [userTransfers, setUserTransfers] = useState<UniversalLedgerItem[]>([]);

  // Admin Transfer Modal State
  const [isAdminTransferModalOpen, setIsAdminTransferModalOpen] = useState(false);
  const [adminTransferAction, setAdminTransferAction] = useState<'add' | 'deduct'>('add');
  const [adminTransferSymbol, setAdminTransferSymbol] = useState<string>('AFNL');
  const [adminTransferAmount, setAdminTransferAmount] = useState<string>('1000');
  const [adminTransferReason, setAdminTransferReason] = useState<string>('Protocol Admin Sovereign Reserve Transfer');
  const [adminTransferSuccessMsg, setAdminTransferSuccessMsg] = useState<string | null>(null);
  const [adminTransferErrorMsg, setAdminTransferErrorMsg] = useState<string | null>(null);
  const [isAdminTransferLoading, setIsAdminTransferLoading] = useState<boolean>(false);
  const [showAdminTransferConfirm, setShowAdminTransferConfirm] = useState<boolean>(false);

  // General / Friend Group Management State for Profile
  const [profileGroups, setProfileGroups] = useState<FriendGroup[]>([]);
  const [isGroupManagementModalOpen, setIsGroupManagementModalOpen] = useState(false);

  useEffect(() => {
    if (profile) {
      const activeU = currentUser?.uid || currentUser?.id || 'guest';
      setProfileGroups(getUserFriendGroups(activeU));
    }
  }, [profile, currentUser]);

  const selectableProfileGroups = useMemo(() => {
    if (relationship.friendStatus === 'friends') {
      return profileGroups;
    }
    // If not friends, only show general groups
    return profileGroups.filter(g => g.groupType === 'general');
  }, [profileGroups, relationship.friendStatus]);

  const [groupErrorMsg, setGroupErrorMsg] = useState('');

  const handleToggleGroupMembership = (group: FriendGroup) => {
    if (!profile) return;
    const isMember = group.memberUids.includes(profile.uid);
    
    if (!isMember) {
      if (group.groupType === 'friend' && relationship.friendStatus !== 'friends') {
        setGroupErrorMsg('Non-friends can only be added to General Groups.');
        return;
      }
      
      if (group.memberUids.length >= MAX_CUSTOM_GROUP_MEMBERS) {
        setGroupErrorMsg(`Custom groups are limited to ${MAX_CUSTOM_GROUP_MEMBERS} people.`);
        return;
      }
    }
    
    setGroupErrorMsg('');
    const updatedUids = isMember
      ? group.memberUids.filter(id => id !== profile.uid)
      : [...group.memberUids, profile.uid];
    
    const updated = updateFriendGroup(group.id, { memberUids: updatedUids });
    if (updated) {
      const activeU = currentUser?.uid || currentUser?.id || 'guest';
      setProfileGroups(getUserFriendGroups(activeU));
    }
  };

  const handleUpdateGroupMemberAssignment = (
    group: FriendGroup,
    field: 'number' | 'role',
    rawValue: string
  ) => {
    if (!profile) return;
    const prevAssignments = group.memberAssignments || {};
    const current = prevAssignments[profile.uid] || {};
    const nextForMember: GroupMemberAssignment = { ...current };

    if (field === 'number') {
      const trimmed = rawValue.trim();
      const parsed = trimmed !== '' ? Number(trimmed) : NaN;
      if (trimmed !== '' && Number.isFinite(parsed)) {
        nextForMember.number = parsed;
      } else {
        delete nextForMember.number;
      }
    } else {
      if (rawValue.trim()) {
        nextForMember.role = rawValue;
      } else {
        delete nextForMember.role;
      }
    }

    const updated = updateFriendGroup(group.id, {
      memberAssignments: {
        ...prevAssignments,
        [profile.uid]: nextForMember
      }
    });
    if (updated) {
      const activeU = currentUser?.uid || currentUser?.id || 'guest';
      setProfileGroups(getUserFriendGroups(activeU));
    }
  };

  const handleExecuteAdminTransfer = () => {
    if (!profile) return;
    if (!viewerIsAdmin) {
      setAdminTransferErrorMsg('Unauthorized. Only Admins and Super Admins can execute Admin Transfers.');
      setShowAdminTransferConfirm(false);
      return;
    }
    const numAmt = parseFloat(adminTransferAmount);
    if (isNaN(numAmt) || numAmt <= 0) {
      setAdminTransferErrorMsg('Please enter a valid transfer amount greater than 0.');
      setShowAdminTransferConfirm(false);
      return;
    }

    if (!showAdminTransferConfirm) {
      setAdminTransferErrorMsg(null);
      setShowAdminTransferConfirm(true);
      return;
    }

    setIsAdminTransferLoading(true);
    setAdminTransferErrorMsg(null);
    setAdminTransferSuccessMsg(null);

    const symbolToUse = (adminTransferSymbol || 'AFNL').trim().toUpperCase();

    try {
      const res = executeAdminTransfer({
        adminId: currentUser?.uid || currentUser?.id || 'admin_operator',
        adminName: currentUser?.name || 'Protocol Admin',
        adminHandle: currentUser?.id || 'admin',
        targetUserId: profile.userId || profile.uid || 'guest_trader',
        targetName: profile.name,
        targetHandle: profile.userId,
        action: adminTransferAction,
        coinSymbol: symbolToUse,
        coinName: `${symbolToUse} Final Coin`,
        amount: numAmt,
        unitPriceUSD: 0,
        reason: adminTransferReason || 'Admin Sovereign Reserve Transfer'
      });

      if (!res.success) {
        setAdminTransferErrorMsg(res.error || 'Failed to execute admin transfer.');
        setIsAdminTransferLoading(false);
        setShowAdminTransferConfirm(false);
        return;
      }

      setAdminTransferSuccessMsg(
        `Successfully ${adminTransferAction === 'add' ? 'minted & credited' : 'deducted'} ${numAmt.toLocaleString()} ${symbolToUse} ${adminTransferAction === 'add' ? 'to' : 'from'} @${profile.userId}'s account balance. Recorded in Universal Ledger!`
      );
      
      if (currentUser) {
        const updatedTx = getTransfersBetweenUsers(currentUser.uid || currentUser.id || 'admin', profile.userId);
        setUserTransfers(updatedTx);
      }

      setShowAdminTransferConfirm(false);
      setTimeout(() => {
        setIsAdminTransferLoading(false);
      }, 300);
    } catch (err) {
      setAdminTransferErrorMsg('An error occurred while executing the admin transfer.');
      setIsAdminTransferLoading(false);
      setShowAdminTransferConfirm(false);
    }
  };

  // Quick Post Preview Modal (fallback when parent doesn't override)
  const [selectedPostPreview, setSelectedPostPreview] = useState<MarketplaceListing | null>(null);

  // Inter-Bank Loan State
  const [isProvideLoanModalOpen, setIsProvideLoanModalOpen] = useState(false);
  const [loanModalMode, setLoanModalMode] = useState<'provide' | 'ask'>('provide');

  // Rating State
  const [avgRating, setAvgRating] = useState({ average: 0, count: 0 });
  // Posts & Listings specific Average Rating (Separate from Peer Rating)
  const [sellerPostsAvg, setSellerPostsAvg] = useState<{ average: number; count: number }>({ average: 0, count: 0 });
  const [postRatingsTrigger, setPostRatingsTrigger] = useState(0);
  const [postRatingInputs, setPostRatingInputs] = useState<Record<string, { rating: number; comment: string }>>({});
  const [postsSubTab, setPostsSubTab] = useState<'accepted_rated' | 'all'>('all');
  const [postsStatusFilter, setPostsStatusFilter] = useState<'all' | 'active' | 'done'>('all');

  const [activeTab, setActiveTab] = useState<'profile' | 'posts' | 'tweets'>('profile');

  // Tweets State for the Profile's Tweets Tab
  const [allTweets, setAllTweets] = useState<Tweet[]>(() => getStoredTweets());
  const [tweetFilter, setTweetFilter] = useState<'all' | 'polls' | 'media'>('all');
  const [selectedTweetTag, setSelectedTweetTag] = useState<string | null>(null);
  const [replyingTweetId, setReplyingTweetId] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [expandedThreadId, setExpandedThreadId] = useState<string | null>(null);
  const [copiedTweetId, setCopiedTweetId] = useState<string | null>(null);
  const [tweetLightboxMedia, setTweetLightboxMedia] = useState<{ type: 'photo' | 'video'; url: string; title?: string } | null>(null);

  const avatarFileInputRef = useRef<HTMLInputElement>(null);
  const coverFileInputRef = useRef<HTMLInputElement>(null);

  const [isDeactivated, setIsDeactivated] = useState<boolean>(false);

  const viewerIsAdmin = isAdminAccount(currentUser);
  const isTargetAdminOrSuper = isAdminAccount(profile);

  const handleDeactivateAccount = () => {
    if (!profile) return;
    if (!viewerIsAdmin) {
      showToast('Unauthorized. Only Admins and Super Admins can deactivate user accounts.');
      return;
    }
    localStorage.setItem(`ff_user_deactivated_${profile.userId}`, 'true');
    localStorage.setItem(`ff_user_deactivated_${profile.uid}`, 'true');
    setIsDeactivated(true);

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-DEACT-${Math.floor(1000 + Math.random() * 9000)}`;

    const deactItem = {
      id: `rec-deact-${Date.now()}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'dividend',
      category: 'transfer',
      mode: 'final_coin',
      title: `Account Suspended by Protocol Guard`,
      description: `Clearing status deactivated on profile @${profile.userId} by System Administrator (@${currentUser?.id || 'admin'}). All ecosystem allocations are temporarily locked.`,
      amountUSD: 0,
      feeUSD: 0.00,
      netAmountUSD: 0.00,
      sourceOrDestination: `Sovereign Guard Security Desk`,
      counterpartyOrIssuer: `@${profile.userId}`,
      paymentCoinSymbol: 'AFNL',
      paymentCoinAmount: 0,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Administrative compliance suspension.'
      },
      signature: `SIG-DEACT-${Math.floor(100000 + Math.random() * 900000)}`
    };

    // Log to target user's ledger
    recordLedgerTransaction(profile.userId, deactItem as any);
    // Log to admin/super_admin ledgers
    recordLedgerTransaction('admin', deactItem as any);
    recordLedgerTransaction('super_admin', deactItem as any);

    // Notify components of ledger modifications
    window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

    dispatchGlobalNotification({
      title: `Account Suspended: @${profile.userId}`,
      description: `Administrative security hold placed on @${profile.userId}.`,
      type: 'security',
      targetTab: 'user_profile',
      targetId: profile.userId,
      showToast: false,
      tone: 'alert',
    });
    enqueueUserNotification([profile.uid, profile.userId], {
      title: '⚠️ Account Suspended',
      description: 'Your account clearing privileges have been suspended by Protocol Guard.',
      type: 'security',
      targetTab: 'user_profile',
      targetId: profile.userId,
    });

    showToast(`Account of @${profile.userId} has been suspended.`);
  };

  const handleReactivateAccount = () => {
    if (!profile) return;
    if (!viewerIsAdmin) {
      showToast('Unauthorized. Only Admins and Super Admins can reactivate user accounts.');
      return;
    }
    localStorage.removeItem(`ff_user_deactivated_${profile.userId}`);
    localStorage.removeItem(`ff_user_deactivated_${profile.uid}`);
    setIsDeactivated(false);

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-REACT-${Math.floor(1000 + Math.random() * 9000)}`;

    const reactItem = {
      id: `rec-react-${Date.now()}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'deposit',
      category: 'transfer',
      mode: 'final_coin',
      title: `Account Reinstate Approved by Protocol Guard`,
      description: `Suspension revoked. Clearing status reactivated on profile @${profile.userId} by System Administrator (@${currentUser?.id || 'admin'}). All settlement privileges restored.`,
      amountUSD: 0,
      feeUSD: 0.00,
      netAmountUSD: 0.00,
      sourceOrDestination: `Sovereign Guard Security Desk`,
      counterpartyOrIssuer: `@${profile.userId}`,
      paymentCoinSymbol: 'AFNL',
      paymentCoinAmount: 0,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Administrative compliance reinstatement.'
      },
      signature: `SIG-REACT-${Math.floor(100000 + Math.random() * 900000)}`
    };

    // Log to target user's ledger
    recordLedgerTransaction(profile.userId, reactItem as any);
    // Log to admin/super_admin ledgers
    recordLedgerTransaction('admin', reactItem as any);
    recordLedgerTransaction('super_admin', reactItem as any);

    // Notify components of ledger modifications
    window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

    dispatchGlobalNotification({
      title: `Account Reinstated: @${profile.userId}`,
      description: `Clearing status and privileges restored for @${profile.userId}.`,
      type: 'security',
      targetTab: 'user_profile',
      targetId: profile.userId,
      showToast: false,
      tone: 'success',
    });
    enqueueUserNotification([profile.uid, profile.userId], {
      title: '✅ Account Reinstated',
      description: 'Your account clearing privileges have been restored by Protocol Guard.',
      type: 'security',
      targetTab: 'user_profile',
      targetId: profile.userId,
    });

    showToast(`Account of @${profile.userId} has been reactivated.`);
  };

  const activeUid = currentUser?.uid || currentUser?.id || 'guest';
  const isMe = profile ? profile.uid === activeUid || profile.userId.toLowerCase() === activeUid.toLowerCase() || (currentUser && currentUser.id.toLowerCase() === profile.userId.toLowerCase()) : false;
  const isBlockedOrDeactivated = relationship.isBlocked || isDeactivated;

  const isListingDone = (item: MarketplaceListing) => {
    if (item.status === 'sold') return true;
    if (item.auctionConfig?.status === 'settled' || item.auctionConfig?.status === 'ended') return true;
    if (item.listingIntent === 'auction' && item.auctionConfig?.endTimeIso) {
      return getAuctionRemainingLabel(item.auctionConfig.endTimeIso).isEnded;
    }
    return false;
  };

  const visibleUserListings = useMemo(() => {
    if (!profile) return [];
    const normStr = (s?: string) => (s || '').trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '').split('@')[0].replace(/[_\-\s]/g, '');
    const aliasNorms = new Set([
      normStr(profile.userId),
      normStr(profile.uid),
      ...getIdentityAliases(profile.userId).map(normStr),
      ...getIdentityAliases(profile.uid).map(normStr),
    ].filter(Boolean));
    const allListings = getAllMarketplaceListings();

    const matchesOwner = (item: MarketplaceListing) => {
      const candidates = [item.sellerId, item.userId, item.creatorHandle, item.sellerHandle].filter(Boolean) as string[];
      return candidates.some((c) => aliasNorms.has(normStr(c)));
    };

    const map = new Map<string, MarketplaceListing>();
    userListings.forEach(item => {
      if (isMe || viewerIsAdmin || item.status !== 'draft') {
        map.set(item.id, item);
      }
    });
    allListings.forEach(item => {
      if (!matchesOwner(item)) return;
      if (!isMe && !viewerIsAdmin && item.status === 'draft') return;
      const vis = item.visibility || 'public';
      const canView = isMe || viewerIsAdmin || vis === 'public' || (vis === 'friends' && relationship.isFriend);
      if (canView && !map.has(item.id)) {
        map.set(item.id, item);
      }
    });

    return Array.from(map.values());
  }, [userListings, profile, relationship, isMe, viewerIsAdmin, postRatingsTrigger]);

  // Filter posts made by this profile that were accepted by others and rated
  const acceptedAndRatedPosts = useMemo(() => {
    return visibleUserListings.filter(item => {
      const reviews = getReviewsForListing(item.id);
      const isAccepted = isListingDone(item) || reviews.length > 0;
      return isAccepted && reviews.length > 0;
    });
  }, [visibleUserListings, postRatingsTrigger]);

  const activeUserListings = useMemo(
    () => visibleUserListings.filter(item => item.status !== 'draft' && !isListingDone(item)),
    [visibleUserListings]
  );

  const doneUserListings = useMemo(
    () => visibleUserListings.filter(item => item.status !== 'draft' && isListingDone(item)),
    [visibleUserListings]
  );

  const draftUserListings = useMemo(
    () => visibleUserListings.filter(item => item.status === 'draft'),
    [visibleUserListings]
  );

  const handleRateProfilePost = (listing: MarketplaceListing, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!currentUser) {
      showToast('Please sign in to rate this post');
      return;
    }

    const eligibility = canUserRateListing(listing, currentUser.id || activeUid, currentUser.uid);
    if (!eligibility.canRate) {
      if (eligibility.reason === 'own_listing') {
        showToast('You cannot rate or comment on your own listing.');
      } else if (eligibility.reason === 'already_rated') {
        showToast('Finalized listing ratings can only be submitted once.');
      } else if (eligibility.reason === 'not_winner') {
        showToast('Only the auction winner can submit a rating and comment.');
      } else if (eligibility.reason === 'not_purchaser') {
        showToast('Only the final purchaser can submit a rating and comment.');
      } else {
        showToast('Only finalized purchases and settled auctions can be rated.');
      }
      return;
    }

    const input = postRatingInputs[listing.id];
    const ratingValue = input?.rating ?? 5;
    const commentValue = input?.comment !== undefined ? input.comment : '';

    const res = savePostReview({
      listing,
      listingId: listing.id,
      listingTitle: listing.title,
      sellerId: listing.sellerId || listing.userId || profile?.userId || 'seller',
      sellerHandle: listing.sellerHandle || listing.creatorHandle || profile?.userId,
      reviewerId: currentUser.id || activeUid,
      reviewerUid: currentUser.uid,
      reviewerName: currentUser.name || 'Verified Trader',
      reviewerAvatar: currentUser.avatarUrl,
      rating: ratingValue,
      comment: commentValue,
    });

    if (res.rejectedReason) {
      showToast(
        res.rejectedReason === 'already_rated'
          ? 'You have already submitted your one-time rating for this listing.'
          : 'You are not eligible to rate this listing.'
      );
      return;
    }

    showToast('Final rating and comment submitted!');
    dispatchGlobalNotification({
      title: `Rated "${listing.title}" (${ratingValue}/5)`,
      description: commentValue ? `"${commentValue.slice(0, 90)}"` : `Submitted a ${ratingValue}-star review.`,
      type: 'marketplace',
      targetTab: 'listing_detail',
      targetId: listing.id,
      showToast: false,
    });
    const sellerIds = [listing.sellerId || profile?.uid || '', listing.sellerHandle || profile?.userId || ''].filter(
      (id) => id && id !== activeUid && id !== currentUser.id
    );
    if (sellerIds.length > 0) {
      enqueueUserNotification(sellerIds, {
        title: `⭐ New ${ratingValue}/5 Rating on "${listing.title}"`,
        description: `${currentUser.name || 'A buyer'} rated your listing ${ratingValue}/5${commentValue ? `: "${commentValue.slice(0, 80)}"` : '.'}`,
        type: 'marketplace',
        targetTab: 'listing_detail',
        targetId: listing.id,
      });
    }
    setPostRatingsTrigger(prev => prev + 1);
    if (profile) {
      setSellerPostsAvg(getSellerPostsAverageRating(profile.userId));
    }
  };

  const handleSharePostTweet = (listing: MarketplaceListing, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!currentUser) return;
    if (listing.status === 'draft') {
      showToast('Drafts cannot be shared on Tweeting. Publish your listing first.');
      return;
    }
    const avg = getAverageRatingForListing(listing.id);
    const reviews = getReviewsForListing(listing.id);
    const userReview = getUserReviewForListing(listing.id, currentUser.id || activeUid, currentUser.uid);
    const pendingInput = postRatingInputs[listing.id];
    const effectiveUserRating = pendingInput?.rating ?? userReview?.rating;
    const effectiveUserComment = pendingInput?.comment !== undefined ? pendingInput.comment : userReview?.comment;
    const sellerHandle = (profile?.userId || listing.creatorHandle || listing.sellerId || 'member').replace(/^@/, '');
    const priceUSD = listing.primaryPriceUSD || listing.priceUSD || 0;

    const ratingBadge = avg.count > 0 ? ` ⭐ ${avg.average.toFixed(1)}/5 (${avg.count} ${avg.count === 1 ? 'rating' : 'ratings'})` : '';
    const topComment = effectiveUserComment
      ? ` 💬 "${effectiveUserComment.slice(0, 80)}"`
      : reviews.length > 0
      ? ` 💬 "${reviews[0].comment.slice(0, 80)}"`
      : '';

    const content = `Shared listing by @${sellerHandle}: "${listing.title}" ($${priceUSD.toLocaleString()} USD).${ratingBadge}${topComment} #marketplace #accepted #review`;

    const statusLabel =
      listing.listingIntent === 'auction'
        ? isListingDone(listing)
          ? 'AUCTION SETTLED'
          : 'LIVE AUCTION'
        : listing.status === 'sold'
        ? reviews.length > 0
          ? 'ACCEPTED & RATED'
          : 'TRANSACTED'
        : 'LIVE';

    const createdTweet = createTweet({
      authorId: currentUser.uid || currentUser.id,
      authorName: currentUser.name,
      authorHandle: currentUser.id,
      authorAvatar: currentUser.avatarUrl || '',
      content: content.slice(0, 480),
      extraHashtags: ['marketplace', 'accepted', 'review', 'ratings'],
      sharedPost: {
        listingId: listing.id,
        title: listing.title,
        description: listing.description || '',
        category: listing.category || 'Marketplace',
        itemType: listing.listingIntent === 'auction' ? 'auction' : (listing.itemType || 'good'),
        statusLabel,
        sellerHandle,
        sellerName: listing.creatorName || profile?.name,
        priceUSD,
        imageUrl: listing.imageUrl,
        averageRating: avg.count > 0 ? avg.average : 0,
        ratingCount: avg.count,
        userRating: effectiveUserRating,
        userComment: effectiveUserComment,
        comments: reviews.map((r) => ({
          reviewerName: r.reviewerName,
          reviewerAvatar: r.reviewerAvatar,
          rating: r.rating,
          comment: r.comment,
          timestamp: r.updatedAt || r.timestamp,
        })),
      },
    });

    showToast('Successfully shared post with ratings & comments to Tweeting!');
    window.dispatchEvent(
      new CustomEvent('open_tweeting_feed', {
        detail: {
          tweetId: createdTweet.id,
          listingId: listing.id,
          listingTitle: listing.title,
          sourceTab: 'user_profile',
          profileUserId: profile?.userId || userIdOrHandle,
        },
      })
    );
  };

  const myBankId = currentUser?.id || 'guest_trader';
  const targetBankId = profile?.userId || 'guest_trader';
  const amIABank = isRegisteredInternalBank(myBankId) || isRegisteredInternalBank(currentUser?.uid);
  const isViewedUserABank = profile ? (isRegisteredInternalBank(targetBankId) || isRegisteredInternalBank(profile.uid)) : false;

  const reloadData = async () => {
    if (!userIdOrHandle) return;
    setIsLoading(true);
    let resolvedProfile = await getUserProfile(userIdOrHandle);

    if (!resolvedProfile && currentUser && (
      userIdOrHandle === currentUser.uid ||
      userIdOrHandle === currentUser.id ||
      userIdOrHandle.toLowerCase() === currentUser.id.toLowerCase()
    )) {
      const cleanBio = (currentUser.bio === 'Verified Google participant in Final Finance.' ? '' : currentUser.bio) || '';
      resolvedProfile = {
        uid: currentUser.uid || `user-${currentUser.id}`,
        userId: currentUser.id,
        name: currentUser.name,
        email: currentUser.email,
        avatarUrl: currentUser.avatarUrl,
        coverUrl: currentUser.coverUrl,
        bio: cleanBio,
        role: (currentUser.role as any) || 'user',
        createdAt: currentUser.createdAt || new Date().toISOString(),
        followersCount: 0,
        followingCount: 0,
        friendsCount: 0,
      };
    }

    if (resolvedProfile) {
      if (resolvedProfile.bio === 'Verified Google participant in Final Finance.') {
        resolvedProfile.bio = '';
      }
      const socialStats = getUserSocialCounts(resolvedProfile.uid, resolvedProfile);
      resolvedProfile.followersCount = socialStats.followersCount;
      resolvedProfile.followingCount = socialStats.followingCount;
      resolvedProfile.friendsCount = socialStats.friendsCount;

      setProfile(resolvedProfile);
      setCustomAvatarUrl(resolvedProfile.avatarUrl || '');
      setCustomCoverUrl(resolvedProfile.coverUrl || '');
      setFollowersCount(socialStats.followersCount);
      setFollowingCount(socialStats.followingCount);
      setFriendsCount(socialStats.friendsCount);

      const rel = await getRelationshipStatus(activeUid, resolvedProfile.uid);
      const blockedByTargetExtra =
        isUserBlockedByTarget(activeUid, resolvedProfile.uid) ||
        isUserBlockedByTarget(activeUid, resolvedProfile.userId) ||
        (currentUser?.id ? isUserBlockedByTarget(currentUser.id, resolvedProfile.uid) || isUserBlockedByTarget(currentUser.id, resolvedProfile.userId) : false);

      const finalRel: RelationshipStatus = {
        ...rel,
        isBlockedByTarget: rel.isBlockedByTarget || blockedByTargetExtra,
        isBlocked: rel.isBlocked || blockedByTargetExtra,
      };
      setRelationship(finalRel);

      const viewerIsMe =
        resolvedProfile.uid === activeUid ||
        resolvedProfile.userId.toLowerCase() === activeUid.toLowerCase() ||
        Boolean(currentUser && currentUser.id.toLowerCase() === resolvedProfile.userId.toLowerCase());

      if (finalRel.isBlockedByTarget && !viewerIsMe && !viewerIsAdmin) {
        setUserListings([]);
        setUserTransfers([]);
        setAvgRating({ average: 0, count: 0 });
        setSellerPostsAvg({ average: 0, count: 0 });
      } else {
        if (viewerIsMe && currentUser) {
          ensureSampleAuctionsForUser(resolvedProfile.userId, resolvedProfile.uid, resolvedProfile.name);
        }
        // Fetch visible listings for this viewer
        const listings = getUserListings(
          resolvedProfile.userId,
          activeUid,
          finalRel.isFriend,
          currentUser?.id || currentUser?.uid
        );
        setUserListings(listings);

        // Load Peer Transfers from Universal Ledger
        const transfers = getTransfersBetweenUsers(activeUid, resolvedProfile.userId);
        setUserTransfers(transfers);

        // Load Ratings
        setAvgRating(getAverageRating(resolvedProfile.userId));
        setSellerPostsAvg(getSellerPostsAverageRating(resolvedProfile.userId));
      }

      // Load Final Loan Defaults issued by registered internal banks
      setDefaultCount(getUserFinalLoanDefaultCount(resolvedProfile.userId, resolvedProfile.uid));

      // Load Deactivation Status
      const deac = localStorage.getItem(`ff_user_deactivated_${resolvedProfile.userId}`) === 'true' || 
                   localStorage.getItem(`ff_user_deactivated_${resolvedProfile.uid}`) === 'true';
      setIsDeactivated(deac);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    setActiveTab('profile');
    setTweetFilter('all');
    setSelectedTweetTag(null);
    reloadData();
  }, [userIdOrHandle, activeUid, currentUser]);

  // Listen to ledger, tweets, and block updates across the entire applet
  useEffect(() => {
    const handleLedgerUpdated = () => {
      if (profile) {
        setUserTransfers(getTransfersBetweenUsers(activeUid, profile.userId));
      }
    };
    const handleTweetsUpdated = () => {
      setAllTweets(getStoredTweets());
    };
    const handleBlockUpdated = () => {
      reloadData();
    };
    const handleFriendsUpdated = () => {
      reloadData();
    };
    const handleLoansUpdated = () => {
      if (profile) {
        setDefaultCount(getUserFinalLoanDefaultCount(profile.userId, profile.uid));
      }
    };
    const handlePostRatingsUpdated = () => {
      setPostRatingsTrigger(prev => prev + 1);
      if (profile) {
        setSellerPostsAvg(getSellerPostsAverageRating(profile.userId));
      }
    };
    const handleListingsUpdated = () => {
      reloadData();
    };

    window.addEventListener('final_finance_ledger_updated', handleLedgerUpdated);
    window.addEventListener(TWEETS_UPDATED_EVENT, handleTweetsUpdated);
    window.addEventListener('storage', handleTweetsUpdated);
    window.addEventListener('final_finance_block_updated', handleBlockUpdated);
    window.addEventListener('final_finance_friends_updated', handleFriendsUpdated);
    window.addEventListener('final_finance_loans_updated', handleLoansUpdated);
    window.addEventListener(POST_RATINGS_UPDATED_EVENT, handlePostRatingsUpdated);
    window.addEventListener('final_finance_listings_updated', handleListingsUpdated);
    window.addEventListener('storage', handlePostRatingsUpdated);

    return () => {
      window.removeEventListener('final_finance_ledger_updated', handleLedgerUpdated);
      window.removeEventListener(TWEETS_UPDATED_EVENT, handleTweetsUpdated);
      window.removeEventListener('storage', handleTweetsUpdated);
      window.removeEventListener('final_finance_block_updated', handleBlockUpdated);
      window.removeEventListener('final_finance_friends_updated', handleFriendsUpdated);
      window.removeEventListener('final_finance_loans_updated', handleLoansUpdated);
      window.removeEventListener(POST_RATINGS_UPDATED_EVENT, handlePostRatingsUpdated);
      window.removeEventListener('final_finance_listings_updated', handleListingsUpdated);
      window.removeEventListener('storage', handlePostRatingsUpdated);
    };
  }, [activeUid, profile]);

  const userTweets = useMemo(() => {
    if (!profile) return [];
    if (relationship.isBlocked && !isMe && !viewerIsAdmin) return [];

    const targetUid = profile.uid.toLowerCase();
    const targetHandle = profile.userId.toLowerCase().replace(/^@/, '');
    const targetName = (profile.name || '').trim().toLowerCase();
    const knownSeedHandles: Record<string, string> = {
      'satoshi nakamoto': 'satoshi',
      'elena rostova': 'elena',
      'marcus vance': 'vance_capital',
      'alex chen': 'alex_chen',
    };
    const seedHandle = knownSeedHandles[targetName];

    const myCurrentIds = isMe
      ? [
          currentUser?.uid?.toLowerCase(),
          currentUser?.id?.toLowerCase(),
          currentUser?.handle?.toLowerCase().replace(/^@/, ''),
          currentUser?.email?.split('@')[0]?.toLowerCase()
        ].filter(Boolean)
      : [];

    return allTweets.filter((t) => {
      const aId = (t.authorId || '').toLowerCase();
      const aHandle = (t.authorHandle || '').toLowerCase().replace(/^@/, '');
      const aName = (t.authorName || '').trim().toLowerCase();

      if (aId === targetUid || aId === targetHandle || aHandle === targetHandle) return true;
      if (seedHandle && (aHandle === seedHandle || aName === targetName)) return true;
      if (isMe && myCurrentIds.some((id) => id === aId || id === aHandle)) return true;
      return false;
    });
  }, [allTweets, profile, relationship.isBlocked, isMe, currentUser]);

  const userTweetSummary = useMemo(() => {
    const hashtags = Array.from(new Set(userTweets.flatMap((t) => t.hashtags || [])));
    const tickers = Array.from(new Set(userTweets.flatMap((t) => t.tickers || [])));
    const mentions = Array.from(new Set(userTweets.flatMap((t) => t.mentions || [])));
    const pollsCount = userTweets.filter((t) => Boolean(t.poll)).length;
    const mediaCount = userTweets.filter((t) => (t.photos && t.photos.length > 0) || Boolean(t.video)).length;
    const totalLikes = userTweets.reduce((sum, t) => sum + (t.likes || 0), 0);
    const totalViews = userTweets.reduce((sum, t) => sum + (t.views || 0), 0);
    return { hashtags, tickers, mentions, pollsCount, mediaCount, totalLikes, totalViews };
  }, [userTweets]);

  const displayedUserTweets = useMemo(() => {
    let list = userTweets;
    if (tweetFilter === 'polls') {
      list = list.filter((t) => Boolean(t.poll));
    } else if (tweetFilter === 'media') {
      list = list.filter((t) => (t.photos && t.photos.length > 0) || Boolean(t.video));
    }
    if (selectedTweetTag) {
      const lowerTag = selectedTweetTag.toLowerCase();
      if (lowerTag.startsWith('#')) {
        const bare = lowerTag.slice(1);
        list = list.filter(
          (t) =>
            t.hashtags.some((h) => h.toLowerCase() === bare) ||
            t.content.toLowerCase().includes(lowerTag)
        );
      } else if (lowerTag.startsWith('$')) {
        const bare = lowerTag.slice(1).toUpperCase();
        list = list.filter(
          (t) =>
            (t.tickers && t.tickers.some((tk) => tk.toUpperCase() === bare)) ||
            t.content.toLowerCase().includes(lowerTag)
        );
      } else if (lowerTag.startsWith('@')) {
        const bare = lowerTag.slice(1);
        list = list.filter(
          (t) =>
            t.mentions.some((m) => m.toLowerCase() === bare) ||
            t.content.toLowerCase().includes(lowerTag)
        );
      }
    }
    return list;
  }, [userTweets, tweetFilter, selectedTweetTag]);

  const showToast = (msg: string) => {
    setSaveToastMessage(msg);
    setTimeout(() => {
      setSaveToastMessage(null);
    }, 3000);
  };

  const handleToggleFollow = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      if (relationship.isFollowing) {
        await unfollowUser(activeUid, profile.uid);
        setRelationship(prev => ({ ...prev, isFollowing: false }));
        setFollowersCount(prev => Math.max(0, prev - 1));
        showToast(`Unfollowed @${profile.userId}`);
      } else {
        await followUser(activeUid, profile.uid);
        setRelationship(prev => ({ ...prev, isFollowing: true }));
        setFollowersCount(prev => prev + 1);
        showToast(`Following @${profile.userId}`);
        enqueueUserNotification([profile.uid, profile.userId], {
          title: '🌟 New Follower',
          description: `${currentUser.name || `@${currentUser.id}`} started following you.`,
          type: 'social',
          targetTab: 'user_profile',
          targetId: currentUser.id,
        });
      }
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleSendFriendRequest = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      const outcome = await sendFriendRequest(currentUser, {
        uid: profile.uid,
        userId: profile.userId,
        name: profile.name,
        avatarUrl: profile.avatarUrl,
      });
      if (outcome === 'accepted') {
        setRelationship(prev => ({ ...prev, friendStatus: 'friends', isFriend: true }));
        setFriendsCount(prev => prev + 1);
        showToast('Mutual friendship confirmed');
        reloadData();
      } else {
        setRelationship(prev => ({ ...prev, friendStatus: 'pending_sent' }));
        showToast('Friend request sent');
      }
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleCancelFriendRequest = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await cancelFriendRequest(activeUid, profile.uid);
      setRelationship(prev => ({ ...prev, friendStatus: 'none' }));
      showToast('Friend request withdrawn');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleAcceptFriendRequest = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await acceptFriendRequest(currentUser, {
        uid: profile.uid,
        userId: profile.userId,
        name: profile.name,
        avatarUrl: profile.avatarUrl,
      });
      setRelationship(prev => ({ ...prev, friendStatus: 'friends', isFriend: true }));
      setFriendsCount(prev => prev + 1);
      showToast('Friend request accepted');
      // Reload listings since friends-only posts become visible
      reloadData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleRemoveFriend = () => {
    if (!profile || isActionLoading || !currentUser) return;
    setShowUnfriendConfirm(true);
  };

  const confirmRemoveFriend = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await removeFriend(activeUid, profile.uid);
      setRelationship(prev => ({ ...prev, friendStatus: 'none', isFriend: false }));
      setFriendsCount(prev => Math.max(0, prev - 1));
      showToast(`Unfriended ${profile.name}`);
      reloadData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleBlockUser = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    if (isTargetAdminOrSuper || isAdminAccount(profile)) {
      setShowBlockModal(false);
      showToast('Administrators and Super Admins cannot be blocked.');
      return;
    }
    setIsActionLoading(true);
    try {
      await blockUser(activeUid, profile.uid);
      setRelationship(prev => ({
        ...prev,
        isBlocked: true,
        isBlockedByMe: true,
        isFollowing: false,
        isFriend: false,
        friendStatus: 'none',
      }));
      setShowBlockModal(false);
      showToast(`${profile.name} has been blocked`);
      dispatchGlobalNotification({
        title: `Blocked @${profile.userId}`,
        description: `All direct messaging and interactions with @${profile.userId} are now restricted.`,
        type: 'security',
        targetTab: 'social',
        showToast: false,
        tone: 'alert',
      });
      reloadData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleUnblockUser = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await unblockUser(activeUid, profile.uid);
      setRelationship(prev => ({
        ...prev,
        isBlocked: false,
        isBlockedByMe: false,
      }));
      showToast(`${profile.name} unblocked`);
      reloadData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleShareProfile = async () => {
    const profileKey = profile?.userId || userIdOrHandle;
    const shareUrl = `${window.location.origin}${window.location.pathname}?profile=${encodeURIComponent(profileKey)}`;
    try {
      await navigator.clipboard?.writeText(shareUrl);
    } catch {}
    try {
      if (navigator.share) {
        await navigator.share({ url: shareUrl });
      }
    } catch {}
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setCustomAvatarUrl(reader.result);
          setEditAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCoverFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setCustomCoverUrl(reader.result);
          setEditCoverUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setEditAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setEditCoverUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveAvatar = async () => {
    if (!profile || !customAvatarUrl) return;
    setIsSavingPhoto(true);
    try {
      updateUserPublicProfile(profile.uid, { avatarUrl: customAvatarUrl });
      if (currentUser && isMe && onUpdateSession) {
        const res = await updateUserAccountProfile({
          fullName: currentUser.name || profile.name,
          userId: currentUser.id || profile.userId,
          avatarUrl: customAvatarUrl,
        });
        if (res.success && res.user) onUpdateSession(res.user);
      }
      setProfile(prev => prev ? { ...prev, avatarUrl: customAvatarUrl } : null);
      setIsAvatarModalOpen(false);
      showToast('Profile photo updated');
    } finally {
      setIsSavingPhoto(false);
    }
  };

  const handleSaveCover = async () => {
    if (!profile || !customCoverUrl) return;
    setIsSavingPhoto(true);
    try {
      updateUserPublicProfile(profile.uid, { coverUrl: customCoverUrl });
      if (currentUser && isMe && onUpdateSession) {
        const res = await updateUserAccountProfile({
          fullName: currentUser.name || profile.name,
          userId: currentUser.id || profile.userId,
          coverUrl: customCoverUrl,
        });
        if (res.success && res.user) onUpdateSession(res.user);
      }
      setProfile(prev => prev ? { ...prev, coverUrl: customCoverUrl } : null);
      setIsCoverModalOpen(false);
      showToast('Cover photo updated');
    } finally {
      setIsSavingPhoto(false);
    }
  };

  const openEditProfileModal = () => {
    if (!profile) return;
    const currentName = profile.name || currentUser?.name || '';
    const currentId = profile.userId || currentUser?.id || '';
    const currentMail = profile.email || currentUser?.email || '';
    const currentBioText = profile.bio || currentUser?.bio || '';
    const currentAv = profile.avatarUrl || currentUser?.avatarUrl || '';
    const currentCov = profile.coverUrl || currentUser?.coverUrl || '';

    setEditFullName(currentName);
    setEditUserId(currentId);
    setEditEmail(currentMail);
    setEditBio(currentBioText);
    setEditAvatarUrl(currentAv);
    setEditCoverUrl(currentCov);
    setEditErrorMessage('');
    setUserIdStatus(checkUserIdAvailability(currentId, currentUser?.id));
    setEmailStatus(checkEmailAvailability(currentMail, currentUser?.email));
    setIsEditProfileModalOpen(true);
  };

  const handleEditUserIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const clean = e.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, '');
    setEditUserId(clean);
    const res = checkUserIdAvailability(clean, currentUser?.id);
    setUserIdStatus(res);
  };

  const handleEditEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.trim();
    setEditEmail(val);
    const res = checkEmailAvailability(val, currentUser?.email);
    setEmailStatus(res);
  };

  const handleSaveProfileChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editFullName.trim()) {
      setEditErrorMessage('Full Name is required.');
      return;
    }
    if (!editUserId.trim()) {
      setEditErrorMessage('User ID handle is required.');
      return;
    }
    
    // Check User ID availability
    const idCheck = checkUserIdAvailability(editUserId, currentUser?.id);
    if (!idCheck.available) {
      setEditErrorMessage(idCheck.message || 'User ID is unavailable.');
      return;
    }

    // Check Email availability if entered
    if (editEmail.trim()) {
      const emailCheck = checkEmailAvailability(editEmail, currentUser?.email);
      if (!emailCheck.available) {
        setEditErrorMessage(emailCheck.message || 'Email address is unavailable.');
        return;
      }
    }

    setIsSavingProfile(true);
    setEditErrorMessage('');

    try {
      const cleanUid = profile?.uid || (currentUser ? (currentUser.uid || `user-${currentUser.id}`) : `user-${editUserId}`);
      const cleanHandle = editUserId.trim().toLowerCase().replace(/^@/, '');
      const cleanMail = editEmail.trim().toLowerCase();

      // 1. Update public social profile in directory
      const updatedPublic = await updateUserPublicProfile(cleanUid, {
        name: editFullName.trim(),
        userId: cleanHandle,
        email: cleanMail,
        bio: editBio, // Unlimited bio text
        avatarUrl: editAvatarUrl.trim(),
        coverUrl: editCoverUrl.trim(),
      });

      // 2. Update account session & registry
      if (isMe) {
        const res = await updateUserAccountProfile({
          fullName: editFullName.trim(),
          userId: cleanHandle,
          email: cleanMail,
          bio: editBio, // Unlimited bio text
          avatarUrl: editAvatarUrl.trim(),
          coverUrl: editCoverUrl.trim(),
        });

        if (res.success && res.user) {
          if (onUpdateSession) {
            onUpdateSession(res.user);
          }
          setProfile(prev => prev ? {
            ...prev,
            name: res.user!.name,
            userId: res.user!.id,
            email: res.user!.email,
            bio: res.user!.bio || '',
            avatarUrl: res.user!.avatarUrl || '',
            coverUrl: res.user!.coverUrl || '',
          } : updatedPublic);
          setCustomAvatarUrl(res.user.avatarUrl || '');
          setCustomCoverUrl(res.user.coverUrl || '');
        } else if (!res.success) {
          setEditErrorMessage(res.error || 'Failed to update user profile.');
          return;
        }
      } else {
        setProfile(updatedPublic);
      }

      setIsEditProfileModalOpen(false);
      showToast('Profile updated successfully');
    } catch (err: any) {
      setEditErrorMessage(err?.message || 'Error saving profile modifications');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleCardClick = (listing: MarketplaceListing) => {
    const nextViews = incrementMarketplaceListingViews(listing.id) || ((listing.views ?? 0) + 1);
    const updatedListing: MarketplaceListing = { ...listing, views: nextViews };
    setUserListings((prev) => prev.map((l) => (l.id === listing.id ? updatedListing : l)));

    if (onViewListingDetail) {
      onViewListingDetail(updatedListing);
    } else {
      setSelectedPostPreview(updatedListing);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
        <Loader2 className="w-8 h-8 animate-spin text-neutral-900" />
        <p className="text-sm font-medium text-neutral-500">Loading sovereign profile...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="bg-white border border-neutral-200/90 rounded-3xl p-8 sm:p-12 text-center max-w-lg mx-auto space-y-4 shadow-sm">
        <div className="w-12 h-12 rounded-full bg-neutral-100 text-neutral-400 flex items-center justify-center mx-auto">
          <User className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-bold text-neutral-900">Member Not Found</h2>
        <p className="text-xs text-neutral-500">
          The requested member handle "@{userIdOrHandle}" does not exist in the depository network.
        </p>
        {onNavigateBack && (
          <div className="pt-2">
            <button
              type="button"
              onClick={onNavigateBack}
              className="px-4 py-2 bg-neutral-900 hover:bg-black text-white text-xs font-semibold rounded-xl cursor-pointer transition-colors"
            >
              Go Back
            </button>
          </div>
        )}
      </div>
    );
  }

  const coverImage = profile.coverUrl || customCoverUrl;

  // If this user has blocked the current viewer or if profile is private (and viewer is not owner), ONLY show name, profile photo, and cover photo
  if ((relationship.isBlockedByTarget || profile?.isPrivate) && !isMe) {
    const isPrivateOnly = !relationship.isBlockedByTarget && profile?.isPrivate;
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className="space-y-6 max-w-4xl mx-auto pb-12"
      >
        {onNavigateBack && (
          <div className="flex items-center justify-start">
            <button
              type="button"
              onClick={onNavigateBack}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-200 text-neutral-800 text-xs font-semibold shadow-2xs transition-all cursor-pointer group"
            >
              <ArrowLeft className="w-4 h-4 text-neutral-500 group-hover:-translate-x-0.5 group-hover:text-black transition-transform" />
              <span>Back</span>
            </button>
          </div>
        )}

        <div className="bg-white border border-neutral-200/90 rounded-3xl overflow-hidden shadow-2xs">
          {/* Cover Photo Only */}
          <div
            className="relative h-44 sm:h-56 w-full bg-neutral-900 bg-cover bg-center"
            style={{
              backgroundImage: coverImage
                ? `linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0.7)), url(${coverImage})`
                : 'linear-gradient(to right, #171717, #262626, #0a0a0a)'
            }}
          />

          {/* Photo & Name Only */}
          <div className="px-4 sm:px-8 pb-8 pt-0 relative flex flex-col items-center text-center">
            <div className="-mt-16 sm:-mt-20 mb-4 flex justify-center">
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-neutral-950 border-4 border-white shadow-md overflow-hidden flex items-center justify-center text-white text-4xl font-bold font-serif-lux">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl}
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  profile.name.charAt(0).toUpperCase()
                )}
              </div>
            </div>

            <h1 className="text-xl sm:text-2xl font-black text-neutral-900 tracking-tight font-serif-lux text-center">
              {profile.name}
            </h1>

            {isPrivateOnly ? (
              <div className="mt-5 p-4 bg-amber-50/80 border border-amber-200 rounded-2xl max-w-md w-full flex flex-col items-center text-center gap-2">
                <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
                  <Lock className="w-4 h-4" />
                </div>
                <p className="text-xs font-bold text-amber-900">Private Profile</p>
                <p className="text-xs text-amber-700 leading-relaxed">
                  {profile.name} has set their profile to private. Other users can only view their name, profile photo, and cover photo.
                </p>
              </div>
            ) : (
              <div className="mt-5 p-4 bg-red-50/80 border border-red-200 rounded-2xl max-w-md w-full flex flex-col items-center text-center gap-2">
                <div className="w-9 h-9 rounded-full bg-red-100 text-red-600 flex items-center justify-center">
                  <Ban className="w-4 h-4" />
                </div>
                <p className="text-xs font-bold text-red-900">Profile Access Restricted</p>
                <p className="text-xs text-red-700 leading-relaxed">
                  You have been blocked by {profile.name}. You can only view their name, profile photo, and cover photo. All other profile details, posts, listings, and tweets are hidden.
                </p>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-6 max-w-5xl mx-auto pb-12"
    >
      {/* Top Navigation Row: Back Button & Rating Star for Posts & Listings */}
      {(onNavigateBack || activeTab === 'posts') && (
        <div className="relative flex items-center justify-between min-h-[40px]">
          <div className="flex items-center gap-3">
            {onNavigateBack && (
              <button
                type="button"
                onClick={onNavigateBack}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-200 text-neutral-800 text-xs font-semibold shadow-2xs transition-all hover:shadow-xs cursor-pointer group z-10"
              >
                <ArrowLeft className="w-4 h-4 text-neutral-500 group-hover:-translate-x-0.5 group-hover:text-black transition-transform" />
                <span>{backLabel || 'Back'}</span>
              </button>
            )}

            {/* Rating star on Posts & Listings page, on the top, next to back, indented right */}
            {activeTab === 'posts' && (
              <div
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-neutral-200/90 shadow-2xs text-xs font-semibold text-neutral-800 ml-2"
                title={`${profile?.name || 'Member'}'s Posts & Listings Rating: ${sellerPostsAvg.count > 0 ? sellerPostsAvg.average.toFixed(1) : '0.0'} / 5.0 (${sellerPostsAvg.count} ratings) — Separate from Peer Rating`}
              >
                <div className="flex items-center gap-1.5 text-amber-500">
                  <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                  <span className="font-bold text-neutral-900 font-mono text-sm">
                    {sellerPostsAvg.count > 0 ? sellerPostsAvg.average.toFixed(1) : '0.0'}
                  </span>
                </div>
                <span className="text-neutral-400 font-mono text-[11px]">
                  ({sellerPostsAvg.count} {sellerPostsAvg.count === 1 ? 'Rating' : 'Ratings'})
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                  Posts Rating
                </span>
              </div>
            )}
          </div>

          <div className="w-16" aria-hidden="true" />
        </div>
      )}

      {/* Toast Notification */}
      <AnimatePresence>
        {saveToastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 bg-neutral-950 text-white border border-neutral-800 px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-medium"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{saveToastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ================= TABS NAVIGATION (CENTERED, SINGLE LINE) ================= */}
      <div className="flex flex-nowrap items-center justify-center gap-1 p-1 bg-neutral-100 rounded-2xl w-fit max-w-full mx-auto mb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('profile')}
          className={`h-9 sm:h-10 px-3 sm:px-5 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-white text-neutral-950 shadow-sm'
              : 'text-neutral-500 hover:text-neutral-700 font-medium'
          }`}
        >
          <User className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
          <span>Profile</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('posts')}
          className={`h-9 sm:h-10 px-3 sm:px-5 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'posts'
              ? 'bg-white text-neutral-950 shadow-sm'
              : 'text-neutral-500 hover:text-neutral-700 font-medium'
          }`}
        >
          <LayoutGrid className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
          <span>Posts &amp; Listings</span>
          {userListings.length > 0 && (
            <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono ${
              activeTab === 'posts' ? 'bg-neutral-100 text-neutral-900' : 'bg-neutral-200 text-neutral-600'
            }`}>
              {userListings.length}
            </span>
          )}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('tweets')}
          className={`h-9 sm:h-10 px-3 sm:px-5 rounded-xl text-[11px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'tweets'
              ? 'bg-white text-emerald-800 shadow-sm'
              : 'text-neutral-500 hover:text-emerald-700 font-medium'
          }`}
        >
          <Twitter className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 -scale-x-100 -rotate-12 shrink-0" />
          <span>Tweets</span>
          {userTweets.length > 0 && (
            <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono ${
              activeTab === 'tweets' ? 'bg-emerald-50 text-emerald-800' : 'bg-neutral-200 text-neutral-600'
            }`}>
              {userTweets.length}
            </span>
          )}
        </button>
      </div>

      {activeTab === 'profile' ? (
        <div className="space-y-6">
          {/* ================= PROFILE HERO BANNER & AVATAR ================= */}
          <div className="bg-white border border-neutral-200/90 rounded-3xl overflow-hidden shadow-2xs">
        {/* Cover Backdrop */}
        <div 
          className="relative h-44 sm:h-56 w-full bg-neutral-900 bg-cover bg-center transition-all duration-300"
          style={{
            backgroundImage: coverImage
              ? `linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0.7)), url(${coverImage})`
              : 'linear-gradient(to right, #171717, #262626, #0a0a0a)'
          }}
        >
          {/* Cover Edit Button (Owner Only) */}
          {isMe && (
            <button
              type="button"
              onClick={() => setIsCoverModalOpen(true)}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 h-8 px-3 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white text-[11px] font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm active:scale-[0.98]"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Edit Cover</span>
            </button>
          )}
        </div>

        {/* Profile Card Main Info */}
        <div className="px-4 sm:px-8 pb-6 pt-0 relative flex flex-col items-center text-center">
          <div className="-mt-16 sm:-mt-20 mb-4 flex justify-center">
            {/* Avatar */}
            <div className="relative inline-block">
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-neutral-950 border-4 border-white shadow-md overflow-hidden flex items-center justify-center text-white text-4xl font-bold font-serif-lux group">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl}
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  profile.name.charAt(0).toUpperCase()
                )}
              </div>

              {/* Avatar Edit Overlay (Owner Only) */}
              {isMe && (
                <button
                  type="button"
                  onClick={() => setIsAvatarModalOpen(true)}
                  className="absolute bottom-1 right-1 p-2 rounded-full bg-neutral-900 text-white border-2 border-white shadow-md hover:bg-black transition-colors cursor-pointer"
                  title="Change avatar"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* User Identity Details (Centered) */}
          <div className="space-y-3 w-full flex flex-col items-center text-center">
            {/* Name on top, User ID underneath, both indented in the center */}
            <div className="flex flex-col items-center text-center w-full space-y-1">
              <div className="flex items-center justify-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-neutral-900 tracking-tight font-serif-lux text-center">
                  {profile.name}
                </h1>
                {profile.isVerified && (
                  <span title="Verified" className="inline-flex items-center">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-100 shrink-0" />
                  </span>
                )}
              </div>
              <span className="text-xs sm:text-sm font-mono text-neutral-500 font-medium text-center">
                @{profile.userId}
              </span>
            </div>

            {/* Share Profile, Edit Profile, and Verified Status Buttons (Centered, No Transfer Money on own profile) */}
            <div className="flex flex-wrap items-center justify-center gap-2.5 pt-0.5">
              {/* Edit Profile Button (For Profile Owner) */}
              {isMe && (
                <button
                  type="button"
                  onClick={openEditProfileModal}
                  className="h-9 px-3.5 rounded-full bg-neutral-950 hover:bg-black text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs whitespace-nowrap active:scale-[0.98]"
                >
                  <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Edit Profile</span>
                </button>
              )}

              {/* Share Profile Button */}
              <button
                type="button"
                onClick={handleShareProfile}
                className="h-9 px-3.5 rounded-full bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 text-neutral-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap active:scale-[0.98]"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Link Copied</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5 text-neutral-600 shrink-0" />
                    <span>Share Profile</span>
                  </>
                )}
              </button>

              {/* Verified Status Button */}
              {isMe ? (
                currentUser?.isVerified ? (
                  <button
                    type="button"
                    onClick={onOpenVerificationModal}
                    className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer shadow-2xs whitespace-nowrap"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 fill-emerald-100 shrink-0" />
                    <span>Verified</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onOpenVerificationModal}
                    className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-50 text-amber-900 text-xs font-semibold border border-amber-300 hover:bg-amber-100 transition-colors cursor-pointer shadow-2xs whitespace-nowrap"
                  >
                    <Shield className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Get Verified ($2/mo)</span>
                  </button>
                )
              ) : (
                <>
                  <div className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-neutral-100 text-neutral-600 text-xs font-semibold border border-neutral-200 whitespace-nowrap">
                    <ShieldCheck className="w-4 h-4 text-neutral-400 shrink-0" />
                    <span>Member</span>
                  </div>

                  {relationship.isFriend && (
                    <div className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold border border-blue-200 whitespace-nowrap">
                      <UserCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span>Mutual Friend</span>
                    </div>
                  )}

                  {relationship.isBlocked && (
                    <div className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-red-50 text-red-700 text-xs font-semibold border border-red-200 whitespace-nowrap">
                      <Ban className="w-3.5 h-3.5 text-red-600 shrink-0" />
                      <span>User Blocked</span>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Bio (Supports full descriptions with no arbitrary limit, Centered) */}
            {profile.bio ? (
              <p className="text-xs sm:text-sm text-neutral-700 max-w-2xl mx-auto leading-relaxed pt-1 whitespace-pre-wrap text-center">
                {profile.bio}
              </p>
            ) : isMe ? (
              <button
                type="button"
                onClick={openEditProfileModal}
                className="text-xs text-neutral-400 hover:text-neutral-700 italic pt-1 flex items-center justify-center gap-1.5 cursor-pointer transition-colors mx-auto"
              >
                <Edit3 className="w-3.5 h-3.5 text-amber-600" />
                <span>Add a bio about yourself...</span>
              </button>
            ) : null}

            {/* Blocked Notification Banner */}
            {relationship.isBlocked && !isMe && (
              <div className="p-3.5 bg-red-50/90 border border-red-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs text-red-800 text-left w-full">
                <div className="flex items-center gap-2">
                  <Ban className="w-4 h-4 text-red-600 shrink-0" />
                  <span>
                    {relationship.isBlockedByMe
                      ? `You have blocked @${profile.userId}. Communication, calls, and direct messaging are disabled.`
                      : `@${profile.userId} has blocked communication with you. You cannot call, video call, or chat with this user.`}
                  </span>
                </div>
                {relationship.isBlockedByMe && (
                  <button
                    type="button"
                    onClick={handleUnblockUser}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shrink-0 cursor-pointer transition-colors"
                  >
                    Unblock Member
                  </button>
                )}
              </div>
            )}

            {/* Social Network Counters (Centered) */}
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 pt-2.5 text-xs text-neutral-600 border-t border-neutral-100 w-full">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-neutral-900 font-mono text-sm">
                  {friendsCount.toLocaleString()}
                </span>
                <span>Friends</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-neutral-900 font-mono text-sm">
                  {followersCount.toLocaleString()}
                </span>
                <span>Followers</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-neutral-900 font-mono text-sm">
                  {followingCount.toLocaleString()}
                </span>
                <span>Following</span>
              </div>
            </div>

            {/* Action Rows For Other Users (MOVED UP) */}
            {!isMe && (
              <div className="mt-6 pt-4 border-t border-neutral-100 space-y-3 flex flex-col items-center">
                {/* Line 1: Follow, Friend status, and Block / Unblock Member */}
                <div className="flex flex-wrap items-center justify-center gap-2.5 w-full">
                  {/* Follow / Unfollow */}
                  <button
                    type="button"
                    onClick={handleToggleFollow}
                    disabled={isActionLoading || isBlockedOrDeactivated}
                    title={relationship.isFollowing ? `Click to unfollow @${profile.userId}` : `Follow @${profile.userId}`}
                    className={`group min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all ${
                      isBlockedOrDeactivated
                        ? 'bg-neutral-100 text-neutral-400 border-neutral-200 cursor-not-allowed opacity-50'
                        : relationship.isFollowing
                        ? 'bg-neutral-100 hover:bg-red-50 hover:text-red-700 hover:border-red-200 border-neutral-300 text-neutral-800 cursor-pointer active:scale-[0.98]'
                        : 'bg-white hover:bg-neutral-50 border-neutral-300 text-neutral-900 cursor-pointer active:scale-[0.98]'
                    }`}
                  >
                    {relationship.isFollowing ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600 group-hover:hidden" />
                        <UserMinus className="w-3.5 h-3.5 text-red-600 hidden group-hover:inline" />
                        <span className="group-hover:hidden">Following</span>
                        <span className="hidden group-hover:inline">Unfollow</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5 text-neutral-600" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>

                  {/* Friend Actions (disabled if blocked or deactivated) */}
                  {!isBlockedOrDeactivated && (
                    <>
                      {relationship.friendStatus === 'none' && (
                        <button
                          type="button"
                          onClick={handleSendFriendRequest}
                          disabled={isActionLoading}
                          className="min-h-[40px] px-4 py-2 rounded-xl bg-white hover:bg-neutral-50 border border-neutral-300 text-neutral-900 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all active:scale-[0.98]"
                        >
                          <UserPlus className="w-3.5 h-3.5 text-blue-600" />
                          <span>Add Friend</span>
                        </button>
                      )}

                      {relationship.friendStatus === 'pending_sent' && (
                        <button
                          type="button"
                          onClick={handleCancelFriendRequest}
                          disabled={isActionLoading}
                          className="min-h-[40px] px-4 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                        >
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>Request Sent</span>
                        </button>
                      )}

                      {relationship.friendStatus === 'pending_received' && (
                        <button
                          type="button"
                          onClick={handleAcceptFriendRequest}
                          disabled={isActionLoading}
                          className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Accept Request</span>
                        </button>
                      )}

                      {relationship.friendStatus === 'friends' && (
                        <button
                          type="button"
                          onClick={handleRemoveFriend}
                          disabled={isActionLoading}
                          className="group min-h-[40px] px-3.5 py-2 rounded-xl bg-neutral-100 hover:bg-red-50 hover:text-red-700 hover:border-red-200 border border-neutral-200 text-neutral-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                          title={`Click to unfriend ${profile.name}`}
                        >
                          <UserCheck className="w-3.5 h-3.5 text-blue-600 group-hover:hidden" />
                          <UserMinus className="w-3.5 h-3.5 text-red-600 hidden group-hover:inline" />
                          <span className="group-hover:hidden">Friends</span>
                          <span className="hidden group-hover:inline">Unfriend</span>
                        </button>
                      )}
                    </>
                  )}

                  {/* Block / Unblock Member (Admins & Super Admins cannot be blocked) */}
                  {isTargetAdminOrSuper ? (
                    <span
                      className="min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-amber-200 bg-amber-50/70 text-amber-800 cursor-not-allowed select-none"
                      title="Admins and Super Admins cannot be blocked"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                      <span>Admin Protected</span>
                    </span>
                  ) : relationship.isBlockedByMe ? (
                    <button
                      type="button"
                      onClick={handleUnblockUser}
                      disabled={isActionLoading}
                      className="min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer text-red-700 bg-red-50 hover:bg-red-100 border border-red-200"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Unblock</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowBlockModal(true)}
                      disabled={isActionLoading}
                      className="min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer text-neutral-600 hover:text-red-600 hover:bg-red-50 border border-neutral-200 bg-white"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Block</span>
                    </button>
                  )}
                </div>

                {/* Line 2: Loan, Transfer, Message, Voice, Video */}
                <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1 w-full">
                  {/* Provide Loan (Admin/SuperAdmin Only) */}
                  {viewerIsAdmin && (
                    <button
                      type="button"
                      onClick={() => !isDeactivated && setIsProvideLoanModalOpen(true)}
                      disabled={isDeactivated}
                      className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        isDeactivated
                          ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                          : 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-2xs active:scale-[0.98]'
                      }`}
                      title={isDeactivated ? 'Sovereign clearing deactivated' : `Provide loan to @${profile.userId}`}
                    >
                      <HandCoins className="w-3.5 h-3.5" />
                      <span>Provide Loan</span>
                    </button>
                  )}

                  {/* Transfer Money Button */}
                  <button
                    type="button"
                    onClick={() => (!isBlockedOrDeactivated || viewerIsAdmin) && setIsTransferModalOpen(true)}
                    disabled={isBlockedOrDeactivated && !viewerIsAdmin}
                    className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                      isBlockedOrDeactivated && !viewerIsAdmin
                        ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer shadow-2xs active:scale-[0.98]'
                    }`}
                    title={isDeactivated && !viewerIsAdmin ? 'Sovereign clearing deactivated' : relationship.isBlocked && !viewerIsAdmin ? 'Transfers disabled (Blocked)' : `Transfer funds to @${profile.userId}`}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Transfer Money</span>
                  </button>

                  {/* Direct Message (Icon Only) */}
                  <button
                    type="button"
                    onClick={() => (!isBlockedOrDeactivated || viewerIsAdmin) && onOpenDirectMessage(profile)}
                    disabled={isBlockedOrDeactivated && !viewerIsAdmin}
                    title={isDeactivated && !viewerIsAdmin ? 'Sovereign actor deactivated' : relationship.isBlocked && !viewerIsAdmin ? 'Messaging disabled (Blocked)' : `Message @${profile.userId}`}
                    aria-label={`Send direct message to ${profile.name}`}
                    className={`min-h-[40px] min-w-[40px] px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center transition-all ${
                      isBlockedOrDeactivated && !viewerIsAdmin
                        ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed border border-neutral-200 opacity-50'
                        : 'bg-neutral-950 hover:bg-neutral-800 text-white cursor-pointer shadow-2xs active:scale-[0.98]'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>

                  {/* Voice Call (Friends Only, Unrestricted for Admins) */}
                  {onOpenVoiceCall && (() => {
                    const canVoiceCall = viewerIsAdmin || (!isBlockedOrDeactivated && relationship.isFriend);
                    return (
                      <button
                        type="button"
                        onClick={() => canVoiceCall && onOpenVoiceCall({ uid: profile.uid, userId: profile.userId, name: profile.name, avatarUrl: profile.avatarUrl })}
                        disabled={!canVoiceCall}
                        className={`min-h-[40px] px-4 py-2 rounded-xl border text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                          !canVoiceCall
                            ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                            : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800 cursor-pointer active:scale-[0.98]'
                        }`}
                        title={
                          viewerIsAdmin
                            ? `Admin Voice Call (${profile.name})`
                            : isDeactivated
                              ? 'Voice call disabled (Deactivated)'
                              : relationship.isBlocked
                                ? 'Voice call disabled (Blocked)'
                                : !relationship.isFriend
                                  ? 'Friends only: Add as friend to place voice calls'
                                  : 'Voice Call'
                        }
                      >
                        <Phone className="w-3.5 h-3.5 text-neutral-600" />
                        <span>Voice</span>
                      </button>
                    );
                  })()}

                  {/* Video Call (Friends Only, Unrestricted for Admins) */}
                  {onOpenVideoCall && (() => {
                    const canVideoCall = viewerIsAdmin || (!isBlockedOrDeactivated && relationship.isFriend);
                    return (
                      <button
                        type="button"
                        onClick={() => canVideoCall && onOpenVideoCall({ uid: profile.uid, userId: profile.userId, name: profile.name, avatarUrl: profile.avatarUrl })}
                        disabled={!canVideoCall}
                        className={`min-h-[40px] px-4 py-2 rounded-xl border text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                          !canVideoCall
                            ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                            : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800 cursor-pointer active:scale-[0.98]'
                        }`}
                        title={
                          viewerIsAdmin
                            ? `Admin Video Call (${profile.name})`
                            : isDeactivated
                              ? 'Video call disabled (Deactivated)'
                              : relationship.isBlocked
                                ? 'Video call disabled (Blocked)'
                                : !relationship.isFriend
                                  ? 'Friends only: Add as friend to place video calls'
                                  : 'Video Call'
                        }
                      >
                        <Video className="w-3.5 h-3.5 text-neutral-600" />
                        <span>Video</span>
                      </button>
                    );
                  })()}
                </div>

                {/* Group Button & Final Loan Default Counter (from Registered Internal Banks) */}
                <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1.5 w-full">
                  <button
                    type="button"
                    onClick={() => setIsGroupManagementModalOpen(true)}
                    className="min-h-[38px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer border border-neutral-200 transition-colors shadow-2xs active:scale-[0.98]"
                    title="Group assignment (no friendship required)"
                  >
                    <FolderHeart className="w-3.5 h-3.5 text-emerald-600" />
                    <span>General Group</span>
                    {profileGroups.filter(g => g.memberUids.includes(profile.uid)).length > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-mono font-bold">
                        {profileGroups.filter(g => g.memberUids.includes(profile.uid)).length}
                      </span>
                    )}
                  </button>

                  {/* Final Loan Default Count (Registered Internal Banking Loans) */}
                  <div
                    className={`min-h-[38px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 border shadow-2xs ${
                      defaultCount > 0
                        ? 'bg-red-50 text-red-900 border-red-200'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200'
                    }`}
                    title="Number of times defaulted on Final Loans provided by registered internal banking users"
                  >
                    {defaultCount > 0 ? (
                      <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                    ) : (
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    )}
                    <span>
                      Final Loan Defaults:{' '}
                      <span className="font-mono">{defaultCount}</span>{' '}
                      <span className="font-normal opacity-80">
                        ({defaultCount === 1 ? '1 Time' : `${defaultCount} Times`})
                      </span>
                    </span>
                  </div>
                </div>

                {/* Line 3: Banking Operations */}
                {(!relationship.isBlocked && amIABank) && (
                  <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1 w-full border-t border-neutral-100 mt-2">
                    <button
                      type="button"
                      disabled={isBlockedOrDeactivated}
                      onClick={() => { setLoanModalMode('provide'); setIsProvideLoanModalOpen(true); }}
                      className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                        isBlockedOrDeactivated
                          ? 'opacity-45 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                          : 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300 cursor-pointer shadow-sm active:scale-[0.98]'
                      }`}
                      title={isDeactivated ? 'Sovereign clearing deactivated' : `Issue Final Coin loan to @${profile.userId}`}
                    >
                      <HandCoins className="w-3.5 h-3.5 text-amber-700" />
                      <span>Provide Loan</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Admin Transfer Section (ABOVE Licensed Internal Bank Node) */}
            {viewerIsAdmin && !isMe && (
              <div className="mt-5 p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-50 to-orange-50/80 border border-amber-300/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shrink-0 shadow-xs">
                    <Coins className="w-5 h-5 text-slate-950" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold text-amber-800 uppercase tracking-wider">
                        Admin Sovereign Authority
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-amber-200 text-amber-900 border border-amber-300/70">
                        Ledger System Mint
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mt-0.5">
                      Admin Coin Transfer &amp; Money Supply Control
                    </h4>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setAdminTransferSuccessMsg(null);
                    setAdminTransferErrorMsg(null);
                    setShowAdminTransferConfirm(false);
                    setIsAdminTransferModalOpen(true);
                  }}
                  className="w-full sm:w-auto min-h-[42px] px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all shadow-xs active:scale-[0.98] shrink-0"
                >
                  <Coins className="w-4 h-4 text-amber-100" />
                  <span>Admin Transfer</span>
                </button>
              </div>
            )}

            {/* Internal Bank Credentials card (KEPT IN MIDDLE) */}
            {isViewedUserABank && (
              <div className="mt-5 p-5 rounded-2xl bg-indigo-50/40 border border-indigo-100/70 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Building2 className="w-5 h-5 text-indigo-50" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono font-bold text-indigo-700 tracking-wider uppercase block">
                      Licensed Internal Bank Node
                    </span>
                    <h3 className="font-serif text-base font-bold text-slate-900 mt-0.5">
                      {getBankInfo(targetBankId).bankName}
                    </h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1 border-t border-indigo-100/40">
                  <div className="p-3 bg-white rounded-xl border border-indigo-100/30">
                    <span className="text-slate-500 font-mono block mb-1">Reserve &amp; Credit Capacity:</span>
                    <span className="font-mono font-bold text-indigo-800 text-sm">
                      {getBankInfo(targetBankId).capacity}
                    </span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-indigo-100/30">
                    <span className="text-slate-500 font-mono block mb-1">Clearing Role Profile:</span>
                    <span className="font-sans font-bold text-slate-800 text-xs">
                      {getBankInfo(targetBankId).role}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-indigo-100/30">
                  <span className="text-slate-500 font-mono text-[10px] block mb-1 uppercase tracking-wider">Institution Overview:</span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {getBankInfo(targetBankId).description}
                  </p>
                </div>

                 {/* Ask for Loan Action Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    disabled={isDeactivated}
                    onClick={() => { setLoanModalMode('ask'); setIsProvideLoanModalOpen(true); }}
                    className={`w-full min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      isDeactivated
                        ? 'bg-neutral-100 border border-neutral-205 text-neutral-400 cursor-not-allowed opacity-60'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs active:scale-[0.98] cursor-pointer'
                    }`}
                    title={isDeactivated ? 'Institution is currently deactivated' : `Request credit/loan from ${getBankInfo(targetBankId).bankName}`}
                  >
                    <HandCoins className="w-4 h-4" />
                    <span>Ask For Loan</span>
                  </button>
                </div>
              </div>
            )}

            {/* Protocol Operator Actions Panel (Admin Operator Console KEPT BELOW) */}
            {viewerIsAdmin && !isMe && (
              <div className="mt-5 p-5 rounded-2xl bg-slate-900 border border-slate-850 text-white space-y-3.5 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                    🛡️
                  </div>
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-400 tracking-wider uppercase block">
                      Admin Operator Console
                    </span>
                    <h4 className="font-serif text-sm font-bold text-white mt-0.5">
                      Sovereign Guard Actions
                    </h4>
                  </div>
                </div>

                <div className="pt-1 flex flex-wrap gap-2.5">
                  {isDeactivated ? (
                    <button
                      type="button"
                      onClick={handleReactivateAccount}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all active:scale-[0.98] cursor-pointer flex items-center gap-1.5"
                    >
                      <Unlock className="w-4 h-4 text-emerald-100" />
                      <span>Reactivate Account</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleDeactivateAccount}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all active:scale-[0.98] cursor-pointer flex items-center gap-1.5"
                    >
                      <Lock className="w-4 h-4 text-rose-100" />
                      <span>Deactivate Account</span>
                    </button>
                  )}
                </div>
              </div>
            )}
        </div>
      </div>
    </div>

        {/* ================= USER RATING SECTION ================= */}
        {(!relationship.isBlocked || viewerIsAdmin) && (
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-7 shadow-2xs">
            <UserRatingSection
              targetUserId={profile.userId}
              currentUser={currentUser}
              onRatingSubmitted={() => {
                if (profile) {
                  setAvgRating(getAverageRating(profile.userId));
                }
              }}
            />
          </div>
        )}
      </div>
    ) : activeTab === 'posts' ? (
      /* ================= POSTS & VAULT LISTINGS SECTION ================= */
        <div className="bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-7 shadow-2xs space-y-6 text-left">
          {/* Section Header */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3.5 border-b border-neutral-100 pb-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0">
                <Package className="w-5 h-5 text-amber-400" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-base sm:text-lg font-bold text-neutral-900 tracking-tight font-serif-lux">
                    {profile.name}&apos;s Posts &amp; Listings
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full bg-neutral-100 text-neutral-700 text-xs font-mono font-bold border border-neutral-200">
                    {visibleUserListings.length}
                  </span>
                </div>
                <p className="text-xs text-neutral-500">
                  {viewerIsAdmin && !isMe
                    ? 'Admin Oversight: Showing all user posts & listings (public, friends-only, custom group, private Only Me, and drafts).'
                    : relationship.isFriend
                    ? 'Showing all active and completed trade posts & listings visible to you (public and mutual friends-only).'
                    : 'Showing all active and completed public trade posts & listings visible to you.'}
                </p>
              </div>
            </div>

            {/* Sub-Tabs: All Posts & Listings (Active & Done) vs Accepted & Rated Posts */}
            <div className="inline-flex flex-nowrap items-center gap-1 bg-neutral-100 p-1 rounded-2xl shrink-0 w-fit max-w-full overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setPostsSubTab('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                  postsSubTab === 'all'
                    ? 'bg-neutral-900 text-white shadow-2xs'
                    : 'text-neutral-600 hover:text-black'
                }`}
              >
                <Package className="w-3.5 h-3.5 shrink-0" />
                <span>All Listings ({visibleUserListings.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setPostsSubTab('accepted_rated')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                  postsSubTab === 'accepted_rated'
                    ? 'bg-neutral-900 text-white shadow-2xs'
                    : 'text-neutral-600 hover:text-black'
                }`}
              >
                <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400 shrink-0" />
                <span>Accepted &amp; Rated Posts ({acceptedAndRatedPosts.length})</span>
              </button>
            </div>
          </div>

          {/* Listings Content */}
          {relationship.isBlocked && !viewerIsAdmin ? (
            <div className="p-8 text-center rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
              <Ban className="w-6 h-6 text-neutral-400 mx-auto" />
              <p className="text-xs font-semibold text-neutral-700">Posts Hidden</p>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Posts and trade listings are hidden while this member is blocked.
              </p>
            </div>
            ) : (() => {
              const renderProfilePostCard = (listing: MarketplaceListing, badgeVariant: 'accepted_rated' | 'status') => {
                const visibility = listing.visibility || 'public';
                const postAvg = getAverageRatingForListing(listing.id);
                const postReviews = getReviewsForListing(listing.id);
                const isAuction = listing.listingIntent === 'auction';
                const done = isListingDone(listing);
                const displayPrice = isAuction
                  ? getCurrentAuctionPriceUSD(listing)
                  : (listing.primaryPriceUSD || listing.priceUSD || 0);
                const auctionTiming = isAuction ? getAuctionRemainingLabel(listing.auctionConfig?.endTimeIso) : null;
                const bidCount = listing.auctionConfig?.bidCount ?? 0;

                const isOwnListing =
                  isMe || isUserListingOwner(listing, currentUser?.id || activeUid, currentUser?.uid);
                const eligibility = canUserRateListing(
                  listing,
                  currentUser?.id || activeUid,
                  currentUser?.uid
                );
                const userReview = currentUser
                  ? getUserReviewForListing(listing.id, currentUser.id || activeUid, currentUser.uid)
                  : null;
                const currentRating = postRatingInputs[listing.id]?.rating ?? 5;
                const currentComment = postRatingInputs[listing.id]?.comment ?? '';

                return (
                  <div
                    key={listing.id}
                    data-listing-id={listing.id}
                    onClick={() => handleCardClick(listing)}
                    className={`group bg-white border rounded-3xl overflow-hidden transition-all duration-200 cursor-pointer flex flex-col justify-between shadow-2xs hover:shadow-md ${
                      returnListingId === listing.id
                        ? 'border-blue-500 ring-2 ring-blue-500/50 bg-blue-50/20'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    <div>
                      {/* Image Preview & Badges */}
                      <div className="relative h-44 w-full bg-neutral-900 overflow-hidden">
                        {listing.imageUrl ? (
                          <img
                            src={listing.imageUrl}
                            alt={listing.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-neutral-500 bg-neutral-900">
                            {isAuction ? <Gavel className="w-10 h-10 text-amber-400" /> : <Package className="w-10 h-10" />}
                          </div>
                        )}

                        {/* Status & Type Badges */}
                        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 flex-wrap">
                          {badgeVariant === 'accepted_rated' ? (
                            <span className="px-2 py-0.5 rounded-lg bg-emerald-600 text-white text-[10px] font-mono font-bold border border-emerald-400 shadow-2xs">
                              {isAuction ? 'AUCTION SETTLED & RATED' : 'ACCEPTED & RATED'}
                            </span>
                          ) : (
                            <span
                              className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold border shadow-2xs ${
                                done
                                  ? 'bg-emerald-600 text-white border-emerald-400'
                                  : isAuction
                                  ? 'bg-amber-500 text-neutral-950 border-amber-300'
                                  : 'bg-neutral-900/90 text-emerald-300 border-neutral-700'
                              }`}
                            >
                              {isAuction
                                ? done
                                  ? 'AUCTION DONE / SETTLED'
                                  : 'LIVE AUCTION'
                                : done
                                ? 'DONE / TRANSACTED'
                                : 'ACTIVE / LIVE'}
                            </span>
                          )}
                          <span className="px-2 py-0.5 rounded-lg bg-white/95 text-neutral-900 text-[10px] font-mono font-bold uppercase shadow-2xs inline-flex items-center gap-1">
                            {isAuction && <Gavel className="w-2.5 h-2.5 text-amber-600" />}
                            <span>
                              {isAuction
                                ? 'Auction'
                                : listing.listingIntent === 'buy'
                                ? 'Wanted'
                                : listing.itemType === 'service'
                                ? 'Service'
                                : 'Good'}
                            </span>
                          </span>
                        </div>

                        {/* Visibility Badge */}
                        <div className="absolute top-2.5 right-2.5">
                          {visibility === 'public' && (
                            <span className="px-2 py-0.5 rounded-full bg-black/75 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-white/20 shadow-2xs">
                              <Globe className="w-3 h-3 text-emerald-400" />
                              <span>Public</span>
                            </span>
                          )}
                          {visibility === 'friends' && (
                            <span className="px-2 py-0.5 rounded-full bg-blue-950/85 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-blue-400/30 shadow-2xs">
                              <Users className="w-3 h-3 text-blue-300" />
                              <span>Friends Only</span>
                            </span>
                          )}
                          {visibility === 'custom_group' && (
                            <span className="px-2 py-0.5 rounded-full bg-purple-950/85 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-purple-400/30 shadow-2xs">
                              <Lock className="w-3 h-3 text-purple-300" />
                              <span>Custom Group</span>
                            </span>
                          )}
                          {visibility === 'only_me' && (
                            <span className="px-2 py-0.5 rounded-full bg-neutral-950/85 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-neutral-400/30 shadow-2xs">
                              <Lock className="w-3 h-3 text-neutral-300" />
                              <span>Only Me</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Card Body */}
                      <div className="p-4 space-y-3">
                        <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono">
                          <span className="truncate uppercase font-bold text-neutral-700">{listing.category || 'General'}</span>
                          <span className="text-emerald-700 font-bold">
                            {isAuction ? (done ? 'Final: ' : 'Bid: ') : ''}
                            ${displayPrice.toLocaleString()} USD
                          </span>
                        </div>

                        <div className="space-y-1">
                          <h3 className="font-bold text-sm text-neutral-900 group-hover:text-black line-clamp-1">
                            {listing.title}
                          </h3>
                          {listing.description && (
                            <p className="text-xs text-neutral-600 line-clamp-2 leading-relaxed">
                              {listing.description}
                            </p>
                          )}
                        </div>

                        {/* Auction Telemetry Strip */}
                        {isAuction && (
                          <div className="p-2 rounded-xl bg-amber-50/70 border border-amber-200/80 flex items-center justify-between gap-2 text-[11px] font-mono">
                            <div className="flex items-center gap-1.5 text-amber-900 font-bold">
                              <Gavel className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                              <span>{bidCount} {bidCount === 1 ? 'Bid' : 'Bids'}</span>
                            </div>
                            <span className="text-amber-800 font-semibold truncate">
                              {done
                                ? listing.auctionConfig?.highestBidderHandle
                                  ? `Winner: @${listing.auctionConfig.highestBidderHandle.replace(/^@/, '')}`
                                  : 'Auction Settled'
                                : auctionTiming?.text || 'Live'}
                            </span>
                          </div>
                        )}

                        {/* Pricing & Views */}
                        <div className="pt-2 border-t border-neutral-200/70 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 min-w-0">
                            {listing.finalCoinsPricing && (
                              <div className="text-xs font-bold text-amber-700 font-mono flex items-center gap-1 shrink-0">
                                <Coins className="w-3.5 h-3.5 text-amber-600" />
                                <span>{listing.finalCoinsPricing.amount.toLocaleString()} {listing.finalCoinsPricing.symbol}</span>
                              </div>
                            )}
                            {listing.location && (
                              <span className="text-[10px] text-neutral-500 truncate max-w-[140px]">📍 {listing.location}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-1 text-[11px] font-mono text-neutral-500 shrink-0">
                            <Eye className="w-3.5 h-3.5 text-neutral-400" />
                            <span>{(listing.views ?? 0).toLocaleString()} views</span>
                          </div>
                        </div>

                        {/* Post Rating Summary */}
                        <div className="p-2.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="flex items-center text-amber-500">
                              {[1, 2, 3, 4, 5].map((s) => (
                                <Star
                                  key={s}
                                  className={`w-3.5 h-3.5 ${
                                    postAvg.count > 0 && s <= Math.round(postAvg.average)
                                      ? 'fill-amber-400 text-amber-400'
                                      : 'text-neutral-300'
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="font-mono text-xs font-bold text-neutral-900">
                              {postAvg.count > 0 ? postAvg.average.toFixed(1) : '0.0'}
                            </span>
                            <span className="text-[11px] text-neutral-500 font-mono">
                              ({postAvg.count} {postAvg.count === 1 ? 'rating' : 'ratings'})
                            </span>
                          </div>
                          <span className="text-[10px] font-mono text-amber-900 font-bold">
                            Post Rating
                          </span>
                        </div>

                        {/* Review Comments (always visible to viewers) */}
                        {postReviews.length > 0 ? (
                          <div className="space-y-1.5 pt-1">
                            <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-700">
                              <MessageSquare className="w-3.5 h-3.5 text-neutral-500" />
                              <span>Reviews &amp; Comments ({postReviews.length})</span>
                            </div>
                            <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1 no-scrollbar">
                              {postReviews.map((rev) => (
                                <div key={rev.id} className="p-2 rounded-xl bg-neutral-50 border border-neutral-100 text-xs">
                                  <div className="flex items-center justify-between gap-1 mb-1">
                                    <div className="flex items-center gap-1.5">
                                      {rev.reviewerAvatar ? (
                                        <img src={rev.reviewerAvatar} alt="" className="w-4 h-4 rounded-full object-cover" />
                                      ) : (
                                        <div className="w-4 h-4 rounded-full bg-neutral-300 text-[9px] flex items-center justify-center font-bold">
                                          {rev.reviewerName.charAt(0)}
                                        </div>
                                      )}
                                      <span className="font-bold text-[11px] text-neutral-800">{rev.reviewerName}</span>
                                    </div>
                                    <div className="flex items-center text-amber-500 text-[10px]">
                                      {[1, 2, 3, 4, 5].map((s) => (
                                        <Star
                                          key={s}
                                          className={`w-2.5 h-2.5 ${s <= rev.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-200'}`}
                                        />
                                      ))}
                                    </div>
                                  </div>
                                  {rev.comment && (
                                    <p className="text-[11px] text-neutral-600 italic">
                                      &ldquo;{rev.comment}&rdquo;
                                    </p>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <p className="text-[11px] text-neutral-400 italic">
                            No ratings or comments on this post yet.
                          </p>
                        )}

                        {/* Strict Final Buyer / Auction Winner One-Time Rating Section (NEVER shown on own listings) */}
                        {!isOwnListing && listing.status !== 'draft' && (
                          userReview ? (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1.5"
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                                  <Lock className="w-3.5 h-3.5 text-emerald-600" />
                                  <span>Your Final Rating Submitted</span>
                                </span>
                                <span className="text-[10px] font-mono text-emerald-800 bg-white px-2 py-0.5 rounded-md border border-emerald-200 font-bold">
                                  {userReview.rating} / 5 ★ (Locked)
                                </span>
                              </div>
                              {userReview.comment && (
                                <p className="text-[11px] text-emerald-900/90 italic">
                                  &ldquo;{userReview.comment}&rdquo;
                                </p>
                              )}
                              <p className="text-[10px] text-emerald-700 font-medium">
                                One-time rating recorded for this finalized {isAuction ? 'auction win' : 'purchase'}.
                              </p>
                            </div>
                          ) : eligibility.canRate ? (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2.5"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-neutral-800">
                                  {isAuction ? 'Rate your Auction Win' : 'Rate this Finalized Purchase'}
                                </span>
                                <span className="text-[10px] font-mono text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 font-semibold">
                                  1-Time Final Review
                                </span>
                              </div>

                              <div className="flex items-center gap-1">
                                {[1, 2, 3, 4, 5].map((starVal) => (
                                  <button
                                    key={starVal}
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setPostRatingInputs(prev => ({
                                        ...prev,
                                        [listing.id]: {
                                          rating: starVal,
                                          comment: prev[listing.id]?.comment !== undefined ? prev[listing.id].comment : currentComment,
                                        }
                                      }));
                                    }}
                                    className="p-1 text-amber-400 hover:scale-115 transition-transform cursor-pointer"
                                    title={`Rate ${starVal} star${starVal > 1 ? 's' : ''}`}
                                  >
                                    <Star
                                      className={`w-5 h-5 ${
                                        starVal <= currentRating
                                          ? 'fill-amber-400 text-amber-400'
                                          : 'text-neutral-300 hover:text-amber-300'
                                      }`}
                                    />
                                  </button>
                                ))}
                                <span className="text-xs font-mono font-bold text-neutral-700 ml-2">
                                  {currentRating} / 5 Stars
                                </span>
                              </div>

                              <textarea
                                value={currentComment}
                                onClick={(e) => e.stopPropagation()}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setPostRatingInputs(prev => ({
                                    ...prev,
                                    [listing.id]: {
                                      rating: prev[listing.id]?.rating ?? currentRating,
                                      comment: val,
                                    }
                                  }));
                                }}
                                placeholder={
                                  isAuction
                                    ? 'Leave your one-time review on this auction win...'
                                    : 'Leave your one-time review on this finalized purchase...'
                                }
                                rows={2}
                                className="w-full p-2.5 bg-white border border-neutral-200 rounded-xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                              />

                              <div className="flex items-center justify-between gap-2 pt-1">
                                <span className="text-[10px] text-neutral-500">
                                  One-time rating per finalized purchase
                                </span>
                                <button
                                  type="button"
                                  onClick={(e) => handleRateProfilePost(listing, e)}
                                  className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold transition-colors cursor-pointer"
                                >
                                  Submit Final Rating
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200/80 flex items-center gap-2 text-[11px] text-neutral-500"
                            >
                              <Lock className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                              <span>
                                {!done
                                  ? 'Rating & comment unlock only for the final buyer or auction winner after settlement.'
                                  : isAuction
                                  ? 'Only the auction winner can submit the one-time rating and comment.'
                                  : 'Only the verified final purchaser can submit the one-time rating and comment.'}
                              </span>
                            </div>
                          )
                        )}
                      </div>
                    </div>

                    {/* Share on Tweeting button on every non-draft listing */}
                    {listing.status !== 'draft' && (
                      <div className="p-4 pt-2 border-t border-neutral-100 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={(e) => handleSharePostTweet(listing, e)}
                          className="w-full py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Share on Tweeting</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              };

              return postsSubTab === 'accepted_rated' ? (
                acceptedAndRatedPosts.length === 0 ? (
                  <div className="p-10 text-center rounded-2xl bg-neutral-50/70 border border-neutral-200/80 space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-white border border-neutral-200 shadow-2xs text-neutral-400 flex items-center justify-center mx-auto">
                      <Star className="w-6 h-6 text-amber-400" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-neutral-800">No Accepted &amp; Rated Posts Yet</h4>
                      <p className="text-xs text-neutral-500 max-w-md mx-auto">
                        When postings or auctions created by {profile.name} are finalized and rated by their final buyer or auction winner, they will appear here.
                      </p>
                    </div>
                    {visibleUserListings.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setPostsSubTab('all')}
                        className="text-xs font-bold text-neutral-900 underline cursor-pointer"
                      >
                        View All Listings ({visibleUserListings.length})
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {acceptedAndRatedPosts.map((listing) => renderProfilePostCard(listing, 'accepted_rated'))}
                  </div>
                )
              ) : visibleUserListings.length === 0 ? (
                <div className="p-10 text-center rounded-2xl bg-neutral-50/70 border border-neutral-200/80 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-white border border-neutral-200 shadow-2xs text-neutral-400 flex items-center justify-center mx-auto">
                    <Package className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-neutral-800">No Visible Posts</h4>
                    <p className="text-xs text-neutral-500 max-w-md mx-auto">
                      {isMe
                        ? "You haven't published any active or completed listings yet."
                        : `${profile.name} does not have any posts, auctions, or listings visible for your current session permissions.`}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Active vs Done Filter Strip */}
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                    <button
                      type="button"
                      onClick={() => setPostsStatusFilter('all')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        postsStatusFilter === 'all'
                          ? 'bg-neutral-900 text-white shadow-2xs'
                          : 'bg-neutral-100 text-neutral-600 hover:text-black'
                      }`}
                    >
                      All Active &amp; Done ({visibleUserListings.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setPostsStatusFilter('active')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        postsStatusFilter === 'active'
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'bg-neutral-100 text-neutral-600 hover:text-black'
                      }`}
                    >
                      Active ({activeUserListings.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setPostsStatusFilter('done')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        postsStatusFilter === 'done'
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'bg-neutral-100 text-neutral-600 hover:text-black'
                      }`}
                    >
                      Done / Transacted ({doneUserListings.length})
                    </button>
                  </div>

                  {/* Subsection 1: Active Listings & Auctions */}
                  {(postsStatusFilter === 'all' || postsStatusFilter === 'active') && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between border-b border-neutral-100 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                          <h3 className="text-sm font-bold text-neutral-900">
                            Active Listings &amp; Live Auctions ({activeUserListings.length})
                          </h3>
                        </div>
                        <span className="text-[11px] text-neutral-500">
                          Open goods, services &amp; live auctions
                        </span>
                      </div>

                      {activeUserListings.length === 0 ? (
                        <div className="p-6 text-center rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-500">
                          No active listings or live auctions right now.
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                          {activeUserListings.map((listing) => renderProfilePostCard(listing, 'status'))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Subsection 2: Done / Transacted Listings & Settled Auctions */}
                  {(postsStatusFilter === 'all' || postsStatusFilter === 'done') && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between border-b border-neutral-100 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                          <h3 className="text-sm font-bold text-neutral-900">
                            Done / Transacted &amp; Settled Auctions ({doneUserListings.length})
                          </h3>
                        </div>
                        <span className="text-[11px] text-neutral-500">
                          Completed trades &amp; settled auctions
                        </span>
                      </div>

                      {doneUserListings.length === 0 ? (
                        <div className="p-6 text-center rounded-2xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-500">
                          No completed listings or settled auctions yet.
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                          {doneUserListings.map((listing) => renderProfilePostCard(listing, 'status'))}
                        </div>
                      )}
                    </div>
                  )}
                  {/* Subsection 3: Private / Draft Listings (Visible to Owner & Admins) */}
                  {(viewerIsAdmin || isMe) && postsStatusFilter === 'all' && draftUserListings.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between border-b border-neutral-100 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                          <h3 className="text-sm font-bold text-neutral-900">
                            Private &amp; Draft Listings ({draftUserListings.length})
                          </h3>
                        </div>
                        <span className="text-[11px] text-neutral-500">
                          Unpublished drafts &amp; private items
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {draftUserListings.map((listing) => renderProfilePostCard(listing, 'status'))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}
        </div>
      ) : (
        /* ================= USER TWEETS, POLLS & HASHTAGS SECTION ================= */
        <div className="bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-7 shadow-2xs space-y-6 text-center">
          {/* Section Header */}
          <div className="flex flex-col items-center justify-center gap-2 border-b border-neutral-100 pb-5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-green-600 text-white flex items-center justify-center shadow-md ring-4 ring-emerald-50">
              <Twitter className="w-6 h-6 -scale-x-100 -rotate-12 fill-white" />
            </div>
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-neutral-900 tracking-tight font-serif-lux">
                {profile.name}&apos;s Tweets, Polls &amp; Hashtags
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-xs font-mono font-bold border border-emerald-200">
                {userTweets.length}
              </span>
            </div>
            <p className="text-xs text-neutral-500 max-w-lg mx-auto">
              Complete archive of every tweet, poll, media share, #hashtag, $stock tag, and @mention created by @{profile.userId}.
            </p>
          </div>

          {relationship.isBlocked ? (
            <div className="p-8 text-center rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
              <Ban className="w-6 h-6 text-neutral-400 mx-auto" />
              <p className="text-xs font-semibold text-neutral-700">Tweets Hidden</p>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Tweets, polls, and hashtags are hidden while this member is blocked.
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Summary Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 max-w-3xl mx-auto">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <p className="font-mono font-bold text-sm text-slate-900">{userTweets.length}</p>
                  <p className="text-[11px] text-slate-500">Total Tweets</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <p className="font-mono font-bold text-sm text-emerald-700">{userTweetSummary.pollsCount}</p>
                  <p className="text-[11px] text-slate-500">Polls Created</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <p className="font-mono font-bold text-sm text-sky-700">{userTweetSummary.mediaCount}</p>
                  <p className="text-[11px] text-slate-500">Media Posts</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <p className="font-mono font-bold text-sm text-rose-600">{userTweetSummary.totalLikes}</p>
                  <p className="text-[11px] text-slate-500">Total Likes</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 col-span-2 sm:col-span-1">
                  <p className="font-mono font-bold text-sm text-slate-900">
                    {userTweetSummary.totalViews > 999 ? `${(userTweetSummary.totalViews / 1000).toFixed(1)}K` : userTweetSummary.totalViews}
                  </p>
                  <p className="text-[11px] text-slate-500">Total Views</p>
                </div>
              </div>

              {/* All Created Hashtags, Stock Tags & Mentions */}
              {(userTweetSummary.hashtags.length > 0 || userTweetSummary.tickers.length > 0 || userTweetSummary.mentions.length > 0) && (
                <div className="p-4 rounded-2xl bg-emerald-50/40 border border-emerald-200/70 space-y-2.5 max-w-3xl mx-auto">
                  <p className="text-[11px] font-mono uppercase tracking-wider font-bold text-emerald-900 flex items-center justify-center gap-1.5">
                    <Hash className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Hashtags, Stock Tags &amp; Mentions Created</span>
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {userTweetSummary.hashtags.map((tag) => {
                      const token = `#${tag}`;
                      const isSelected = selectedTweetTag === token;
                      return (
                        <button
                          key={`ut-h-${tag}`}
                          type="button"
                          onClick={() => setSelectedTweetTag(isSelected ? null : token)}
                          className={`px-2.5 py-1 rounded-full text-xs font-semibold cursor-pointer transition-colors border ${
                            isSelected
                              ? 'bg-emerald-600 text-white border-emerald-700'
                              : 'bg-white text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                          }`}
                        >
                          #{tag}
                        </button>
                      );
                    })}
                    {userTweetSummary.tickers.map((tk) => {
                      const token = `$${tk}`;
                      const isSelected = selectedTweetTag === token;
                      return (
                        <button
                          key={`ut-tk-${tk}`}
                          type="button"
                          onClick={() => setSelectedTweetTag(isSelected ? null : token)}
                          className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold cursor-pointer transition-colors border ${
                            isSelected
                              ? 'bg-amber-600 text-white border-amber-700'
                              : 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
                          }`}
                        >
                          ${tk}
                        </button>
                      );
                    })}
                    {userTweetSummary.mentions.map((m) => {
                      const token = `@${m}`;
                      const isSelected = selectedTweetTag === token;
                      return (
                        <button
                          key={`ut-m-${m}`}
                          type="button"
                          onClick={() => setSelectedTweetTag(isSelected ? null : token)}
                          className={`px-2.5 py-1 rounded-full text-xs font-semibold cursor-pointer transition-colors border ${
                            isSelected
                              ? 'bg-sky-600 text-white border-sky-700'
                              : 'bg-sky-50 text-sky-800 border-sky-200 hover:bg-sky-100'
                          }`}
                        >
                          @{m}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Sub-filter Bar */}
              <div className="flex flex-wrap items-center justify-center gap-1.5">
                {[
                  { id: 'all', label: `All Tweets (${userTweets.length})` },
                  { id: 'polls', label: `Polls (${userTweetSummary.pollsCount})` },
                  { id: 'media', label: `Media (${userTweetSummary.mediaCount})` }
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setTweetFilter(f.id as 'all' | 'polls' | 'media')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                      tweetFilter === f.id
                        ? 'bg-neutral-950 text-white shadow-2xs'
                        : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
                {selectedTweetTag && (
                  <button
                    type="button"
                    onClick={() => setSelectedTweetTag(null)}
                    className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer flex items-center gap-1"
                  >
                    <span>Tag: {selectedTweetTag}</span>
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Tweets List */}
              {displayedUserTweets.length === 0 ? (
                <div className="p-10 text-center rounded-2xl bg-neutral-50/70 border border-neutral-200/80 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto">
                    <Twitter className="w-6 h-6 -scale-x-100 -rotate-12" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-neutral-800">No Tweets Found</h4>
                    <p className="text-xs text-neutral-500 max-w-md mx-auto">
                      {isMe
                        ? "You haven't posted any tweets matching this filter yet."
                        : `${profile.name} hasn't posted any tweets matching this filter yet.`}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 max-w-2xl mx-auto">
                  {displayedUserTweets.map((t) => {
                    const isLiked = t.likedBy.includes(activeUid);
                    const isRetweeted = t.retweetedBy.includes(activeUid);
                    const isBookmarked = t.bookmarkedBy.includes(activeUid);
                    const isReplying = replyingTweetId === t.id;
                    const isThreadExpanded = expandedThreadId === t.id;
                    const userVotedOptionId = t.poll?.voterIds[activeUid];
                    const visibleReplies = viewerIsAdmin
                      ? t.replies
                      : t.replies.filter(
                          (rep) =>
                            !areUsersBlockedEitherWay(activeUid, rep.authorId) &&
                            !areUsersBlockedEitherWay(activeUid, rep.authorHandle)
                        );

                    return (
                      <div
                        key={t.id}
                        className="p-4 sm:p-5 rounded-3xl bg-slate-50/60 border border-slate-200 space-y-3.5 text-center relative overflow-hidden"
                      >
                        {isMe && (
                          <button
                            type="button"
                            onClick={() => deleteTweet(t.id)}
                            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Delete Tweet"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Author Header */}
                        <div className="flex flex-col items-center justify-center gap-1.5">
                          <img
                            src={t.authorAvatar || profile.avatarUrl || ''}
                            alt={t.authorName}
                            className="w-10 h-10 rounded-full object-cover border border-slate-200"
                          />
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            <span className="font-bold text-xs sm:text-sm text-slate-900">{t.authorName}</span>
                            {t.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                            <span className="text-xs text-slate-400 font-mono">@{t.authorHandle}</span>
                            <span className="text-slate-300">•</span>
                            <span className="text-xs text-slate-400">{t.timestamp}</span>
                          </div>
                        </div>

                        {/* Formatted Tweet Body */}
                        {t.content && (
                          <p className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line text-center max-w-xl mx-auto">
                            {t.content.split(/(https?:\/\/[^\s]+|[@#$][a-zA-Z0-9_]+)/g).map((part, idx) => {
                              if (/^https?:\/\/[^\s]+$/i.test(part)) {
                                let listingId: string | null = null;
                                let profileParam: string | null = null;
                                let stockParam: string | null = null;
                                try {
                                  const u = new URL(part);
                                  listingId = u.searchParams.get('listing');
                                  profileParam = u.searchParams.get('profile') || u.searchParams.get('user');
                                  stockParam = u.searchParams.get('stock');
                                } catch {}
                                if (listingId) {
                                  return (
                                    <button
                                      key={idx}
                                      type="button"
                                      onClick={() => {
                                        if (onOpenSharedListing) {
                                          onOpenSharedListing(listingId!);
                                        } else {
                                          window.dispatchEvent(new CustomEvent('open_shared_listing', { detail: listingId }));
                                        }
                                      }}
                                      className="text-emerald-700 hover:underline font-semibold cursor-pointer inline break-all"
                                    >
                                      {part}
                                    </button>
                                  );
                                }
                                if (profileParam) {
                                  return (
                                    <button
                                      key={idx}
                                      type="button"
                                      onClick={() => {
                                        window.dispatchEvent(new CustomEvent('open_shared_profile', { detail: profileParam }));
                                      }}
                                      className="text-sky-700 hover:underline font-semibold cursor-pointer inline break-all"
                                    >
                                      {part}
                                    </button>
                                  );
                                }
                                if (stockParam) {
                                  return (
                                    <button
                                      key={idx}
                                      type="button"
                                      onClick={() => {
                                        window.dispatchEvent(new CustomEvent('open_shared_stock', { detail: stockParam!.toUpperCase() }));
                                      }}
                                      className="text-emerald-700 hover:underline font-semibold cursor-pointer inline break-all"
                                    >
                                      {part}
                                    </button>
                                  );
                                }
                                return (
                                  <a
                                    key={idx}
                                    href={part}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-sky-600 hover:underline font-medium break-all"
                                  >
                                    {part}
                                  </a>
                                );
                              }
                              if (part.startsWith('#') && part.length > 1) {
                                return (
                                  <button
                                    key={idx}
                                    type="button"
                                    onClick={() => setSelectedTweetTag(part)}
                                    className="text-emerald-700 hover:underline font-semibold cursor-pointer inline"
                                  >
                                    {part}
                                  </button>
                                );
                              }
                              if (part.startsWith('$') && part.length > 1) {
                                return (
                                  <button
                                    key={idx}
                                    type="button"
                                    onClick={() => setSelectedTweetTag(part.toUpperCase())}
                                    className="text-amber-900 font-mono font-bold bg-amber-50 border border-amber-200 px-1 rounded inline cursor-pointer"
                                  >
                                    {part.toUpperCase()}
                                  </button>
                                );
                              }
                              if (part.startsWith('@') && part.length > 1) {
                                return (
                                  <button
                                    key={idx}
                                    type="button"
                                    onClick={() => setSelectedTweetTag(part)}
                                    className="text-sky-600 hover:underline font-semibold cursor-pointer inline"
                                  >
                                    {part}
                                  </button>
                                );
                              }
                              return <span key={idx}>{part}</span>;
                            })}
                          </p>
                        )}

                        {/* Hashtags, Cashtags & Mentions Tags Row */}
                        {(t.hashtags.length > 0 || (t.tickers && t.tickers.length > 0) || t.mentions.length > 0) && (
                          <div className="flex flex-wrap items-center justify-center gap-1.5 max-w-xl mx-auto">
                            {t.hashtags.map((h) => (
                              <button
                                key={`ptag-h-${h}`}
                                type="button"
                                onClick={() => setSelectedTweetTag(`#${h}`)}
                                className="px-2.5 py-0.5 rounded-full bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-[11px] font-semibold cursor-pointer"
                              >
                                #{h}
                              </button>
                            ))}
                            {t.tickers?.map((tk) => (
                              <button
                                key={`ptag-tk-${tk}`}
                                type="button"
                                onClick={() => setSelectedTweetTag(`$${tk.toUpperCase()}`)}
                                className="px-2.5 py-0.5 rounded-full bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 font-mono text-[11px] font-bold cursor-pointer"
                              >
                                ${tk.toUpperCase()}
                              </button>
                            ))}
                            {t.mentions.map((m) => (
                              <button
                                key={`ptag-m-${m}`}
                                type="button"
                                onClick={() => setSelectedTweetTag(`@${m}`)}
                                className="px-2.5 py-0.5 rounded-full bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-700 text-[11px] font-semibold cursor-pointer"
                              >
                                @{m}
                              </button>
                            ))}
                          </div>
                        )}

                        {/* Rich Link & Tag Cards (Product/Service, $Stock, @User) */}
                        <TweetRichEmbeds
                          content={t.content}
                          mentions={t.mentions}
                          tickers={t.tickers}
                          sharedPost={t.sharedPost}
                          currentUserId={activeUid}
                          onOpenSharedListing={onOpenSharedListing}
                          onSelectStock={onSelectStock}
                          onViewUserProfile={(u) => setSelectedTweetTag(typeof u === 'string' ? `@${u}` : `@${u.userId}`)}
                        />

                        {/* All Photos (Uncropped) */}
                        {t.photos && t.photos.length > 0 && (
                          <div
                            className={`grid gap-2 rounded-2xl overflow-hidden border border-slate-200 max-w-xl mx-auto ${
                              t.photos.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                            }`}
                          >
                            {t.photos.map((pUrl, pIdx) => (
                              <div
                                key={pIdx}
                                onClick={() => setTweetLightboxMedia({ type: 'photo', url: pUrl, title: t.content })}
                                className="relative overflow-hidden bg-slate-950 cursor-pointer flex items-center justify-center"
                              >
                                <img
                                  src={pUrl}
                                  alt={`Tweet media ${pIdx + 1}`}
                                  className={
                                    t.photos!.length === 1
                                      ? 'w-full max-h-[460px] object-contain hover:scale-[1.02] transition-transform duration-300'
                                      : 'w-full h-52 object-contain bg-slate-950 hover:scale-[1.02] transition-transform duration-300'
                                  }
                                />
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Video */}
                        {t.video && (
                          <div className="rounded-2xl overflow-hidden bg-black border border-slate-200 max-w-xl mx-auto">
                            <video src={t.video} controls playsInline preload="metadata" className="w-full max-h-[400px] object-contain" />
                          </div>
                        )}

                        {/* Poll */}
                        {t.poll && (
                          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-2.5 max-w-lg mx-auto">
                            <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold text-emerald-800">
                              <BarChart2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Poll</span>
                            </div>
                            <div className="space-y-2">
                              {t.poll.options.map((opt) => {
                                const isVoted = userVotedOptionId === opt.id;
                                const pct = t.poll!.totalVotes > 0 ? Math.round((opt.votes / t.poll!.totalVotes) * 100) : 0;
                                return (
                                  <button
                                    key={opt.id}
                                    type="button"
                                    onClick={() => voteInTweetPoll(t.id, opt.id, activeUid)}
                                    className={`w-full relative overflow-hidden rounded-xl p-2.5 text-xs font-semibold flex items-center justify-between text-left transition-all cursor-pointer border ${
                                      isVoted
                                        ? 'border-emerald-500 bg-emerald-50 text-emerald-950 font-bold'
                                        : 'border-slate-200 bg-slate-50 hover:border-slate-300 text-slate-800'
                                    }`}
                                  >
                                    {userVotedOptionId && (
                                      <div
                                        className={`absolute inset-y-0 left-0 ${isVoted ? 'bg-emerald-200/50' : 'bg-slate-200/40'}`}
                                        style={{ width: `${pct}%` }}
                                      />
                                    )}
                                    <span className="relative z-10 flex items-center gap-2">
                                      {isVoted && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                                      <span>{opt.text}</span>
                                    </span>
                                    {userVotedOptionId && (
                                      <span className="relative z-10 font-mono font-bold text-[11px] text-slate-600">
                                        {pct}% ({opt.votes})
                                      </span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>
                            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                              <span>{t.poll.totalVotes} total votes</span>
                              <span>{userVotedOptionId ? 'Vote Recorded' : 'Click to vote'}</span>
                            </div>
                          </div>
                        )}

                        {/* Engagement Row */}
                        <div className="flex items-center justify-center gap-4 sm:gap-7 flex-wrap pt-2.5 border-t border-slate-200/70 text-slate-400 text-xs">
                          <button
                            type="button"
                            onClick={() => {
                              setReplyingTweetId(isReplying ? null : t.id);
                              setExpandedThreadId(t.id);
                            }}
                            className="flex items-center gap-1 hover:text-sky-600 cursor-pointer"
                          >
                            <MessageCircle className="w-4 h-4" />
                            <span className="font-mono text-[11px]">{visibleReplies.length}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => toggleTweetRetweet(t.id, activeUid)}
                            className={`flex items-center gap-1 hover:text-emerald-600 cursor-pointer ${
                              isRetweeted ? 'text-emerald-600 font-bold' : ''
                            }`}
                          >
                            <Repeat2 className="w-4 h-4" />
                            <span className="font-mono text-[11px]">{t.retweets}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => toggleTweetLike(t.id, activeUid)}
                            className={`flex items-center gap-1 hover:text-rose-600 cursor-pointer ${
                              isLiked ? 'text-rose-600 font-bold' : ''
                            }`}
                          >
                            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                            <span className="font-mono text-[11px]">{t.likes}</span>
                          </button>

                          <div className="flex items-center gap-1 text-slate-400">
                            <Eye className="w-4 h-4" />
                            <span className="font-mono text-[11px]">{t.views > 999 ? `${(t.views / 1000).toFixed(1)}K` : t.views}</span>
                          </div>

                          <button
                            type="button"
                            onClick={() => toggleTweetBookmark(t.id, activeUid)}
                            className={`p-1 rounded-full hover:text-amber-600 cursor-pointer ${
                              isBookmarked ? 'text-amber-600' : ''
                            }`}
                          >
                            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                          </button>

                          <button
                            type="button"
                            onClick={async () => {
                              const shareUrl = `${window.location.origin}${window.location.pathname}?tweet=${encodeURIComponent(t.id)}`;
                              try {
                                await navigator.clipboard?.writeText(shareUrl);
                              } catch {}
                              try {
                                if (navigator.share) {
                                  await navigator.share({ url: shareUrl });
                                }
                              } catch {}
                              setCopiedTweetId(t.id);
                              setTimeout(() => setCopiedTweetId(null), 2000);
                            }}
                            title="Copy Tweet Link"
                            className="p-1 rounded-full hover:text-slate-800 cursor-pointer"
                          >
                            {copiedTweetId === t.id ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
                          </button>
                        </div>

                        {/* Inline Reply Input */}
                        {isReplying && (
                          <div className="pt-2.5 border-t border-slate-200/70 flex flex-wrap items-center justify-center gap-2 max-w-lg mx-auto">
                            <input
                              type="text"
                              maxLength={280}
                              value={replyContent}
                              onChange={(e) => setReplyContent(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  const clean = replyContent.trim();
                                  if (!clean) return;
                                  const blockedMentions = extractMentions(clean).filter(
                                    (h) => areUsersBlockedEitherWay(activeUid, h) || isUserBlockedByTarget(activeUid, h)
                                  );
                                  if (blockedMentions.length > 0) {
                                    showToast(`Cannot tag @${blockedMentions[0]} due to account block settings.`);
                                    return;
                                  }
                                  addTweetReply({
                                    tweetId: t.id,
                                    authorId: activeUid,
                                    authorName: currentUser?.name || 'Member',
                                    authorHandle: (currentUser?.handle || currentUser?.id || 'member').replace(/^@/, ''),
                                    authorAvatar: currentUser?.avatarUrl || '',
                                    content: clean
                                  });
                                  setReplyContent('');
                                  setReplyingTweetId(null);
                                  setExpandedThreadId(t.id);
                                }
                              }}
                              placeholder={`Reply to @${t.authorHandle}...`}
                              className="flex-1 min-w-[180px] px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-center"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                const clean = replyContent.trim();
                                if (!clean) return;
                                const blockedMentions = extractMentions(clean).filter(
                                  (h) => areUsersBlockedEitherWay(activeUid, h) || isUserBlockedByTarget(activeUid, h)
                                );
                                if (blockedMentions.length > 0) {
                                  showToast(`Cannot tag @${blockedMentions[0]} due to account block settings.`);
                                  return;
                                }
                                addTweetReply({
                                  tweetId: t.id,
                                  authorId: activeUid,
                                  authorName: currentUser?.name || 'Member',
                                  authorHandle: (currentUser?.handle || currentUser?.id || 'member').replace(/^@/, ''),
                                  authorAvatar: currentUser?.avatarUrl || '',
                                  content: clean
                                });
                                setReplyContent('');
                                setReplyingTweetId(null);
                                setExpandedThreadId(t.id);
                              }}
                              disabled={!replyContent.trim()}
                              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs cursor-pointer"
                            >
                              Reply
                            </button>
                          </div>
                        )}

                        {/* Replies Thread */}
                        {visibleReplies.length > 0 && (
                          <div className="pt-2.5 border-t border-slate-200/70 space-y-2 max-w-lg mx-auto">
                            {(!isThreadExpanded ? visibleReplies.slice(0, 1) : visibleReplies).map((rep) => {
                              const isReplyLiked = rep.likedBy.includes(activeUid);
                              return (
                                <div key={rep.id} className="p-3 rounded-2xl bg-white border border-slate-100 flex flex-col items-center gap-1 text-xs text-center">
                                  <div className="flex items-center justify-center gap-1.5 flex-wrap">
                                    <span className="font-bold text-slate-900">{rep.authorName}</span>
                                    <span className="text-[10px] text-slate-400 font-mono">@{rep.authorHandle}</span>
                                    <span className="text-[10px] text-slate-400">• {rep.timestamp}</span>
                                  </div>
                                  <p className="text-slate-700 leading-relaxed">{rep.content}</p>
                                  <button
                                    type="button"
                                    onClick={() => toggleTweetReplyLike(t.id, rep.id, activeUid)}
                                    className={`inline-flex items-center gap-1 text-[10px] font-mono cursor-pointer ${
                                      isReplyLiked ? 'text-rose-600 font-bold' : 'text-slate-400 hover:text-rose-600'
                                    }`}
                                  >
                                    <Heart className={`w-3 h-3 ${isReplyLiked ? 'fill-current' : ''}`} />
                                    <span>{rep.likes}</span>
                                  </button>
                                </div>
                              );
                            })}
                            {visibleReplies.length > 1 && (
                              <button
                                type="button"
                                onClick={() => setExpandedThreadId(isThreadExpanded ? null : t.id)}
                                className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer pt-1"
                              >
                                {isThreadExpanded ? 'Hide replies' : `View all ${visibleReplies.length} replies`}
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Tweet Media Lightbox Modal */}
          {tweetLightboxMedia && (
            <div
              onClick={() => setTweetLightboxMedia(null)}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
            >
              <div
                onClick={(e) => e.stopPropagation()}
                className="max-w-4xl w-full bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl flex flex-col max-h-[90vh]"
              >
                <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                  <span className="font-bold text-xs text-slate-900 truncate mx-auto">
                    {tweetLightboxMedia.title || 'Tweet Media'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setTweetLightboxMedia(null)}
                    className="p-1 rounded-lg text-slate-400 hover:text-slate-800 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="bg-slate-950 flex items-center justify-center p-2 flex-1 min-h-[300px]">
                  <img
                    src={tweetLightboxMedia.url}
                    alt="Tweet enlarged photo"
                    className="max-h-[75vh] w-auto max-w-full object-contain"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= MODAL: AVATAR CUSTOMIZATION ================= */}
      <AnimatePresence>
        {isAvatarModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-md w-full shadow-2xl space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <h3 className="font-bold text-sm text-neutral-900">Update Profile Avatar</h3>
                <button
                  type="button"
                  onClick={() => setIsAvatarModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Preview */}
              <div className="flex justify-center py-2">
                <div className="w-24 h-24 rounded-full bg-neutral-900 border-4 border-neutral-100 overflow-hidden flex items-center justify-center text-white text-2xl font-bold font-serif-lux shadow-sm">
                  {customAvatarUrl ? (
                    <img src={customAvatarUrl} alt="Avatar preview" className="w-full h-full object-cover" />
                  ) : (
                    profile.name.charAt(0).toUpperCase()
                  )}
                </div>
              </div>

              {/* Upload Input */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-neutral-700 block">Avatar Image URL</label>
                <input
                  type="text"
                  value={customAvatarUrl}
                  onChange={(e) => setCustomAvatarUrl(e.target.value)}
                  placeholder="https://example.com/avatar.jpg"
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />

                <div className="pt-2">
                  <input
                    type="file"
                    ref={avatarFileInputRef}
                    onChange={handleAvatarFileUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => avatarFileInputRef.current?.click()}
                    className="w-full py-2 px-3 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-semibold text-neutral-700 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Local Image File</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsAvatarModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveAvatar}
                  disabled={isSavingPhoto || !customAvatarUrl}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors disabled:opacity-50"
                >
                  {isSavingPhoto ? 'Saving...' : 'Save Avatar'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: COVER PHOTO CUSTOMIZATION ================= */}
      <AnimatePresence>
        {isCoverModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-lg w-full shadow-2xl space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <h3 className="font-bold text-sm text-neutral-900">Customize Depository Cover Photo</h3>
                <button
                  type="button"
                  onClick={() => setIsCoverModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Presets */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-700 block">Select Vault Reserve Theme</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {PRESET_COVERS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setCustomCoverUrl(preset.url)}
                      className={`relative h-16 rounded-xl overflow-hidden border-2 cursor-pointer transition-all ${
                        customCoverUrl === preset.url
                          ? 'border-neutral-950 ring-2 ring-neutral-900/20'
                          : 'border-transparent opacity-80 hover:opacity-100'
                      }`}
                    >
                      <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center p-1">
                        <span className="text-[10px] font-bold text-white text-center leading-tight">
                          {preset.name}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Upload Input */}
              <div className="space-y-2 pt-2 border-t border-neutral-100">
                <label className="text-xs font-semibold text-neutral-700 block">Or Custom Image URL</label>
                <input
                  type="text"
                  value={customCoverUrl}
                  onChange={(e) => setCustomCoverUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />

                <div>
                  <input
                    type="file"
                    ref={coverFileInputRef}
                    onChange={handleCoverFileUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => coverFileInputRef.current?.click()}
                    className="w-full py-2 px-3 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-semibold text-neutral-700 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Local Cover File</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsCoverModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveCover}
                  disabled={isSavingPhoto || !customCoverUrl}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors disabled:opacity-50"
                >
                  {isSavingPhoto ? 'Saving...' : 'Apply Cover'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: BLOCK MEMBER ================= */}
      <AnimatePresence>
        {showBlockModal && profile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-sm w-full shadow-2xl space-y-4 text-left"
            >
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto">
                <Ban className="w-6 h-6" />
              </div>
              <div className="text-center space-y-1">
                <h3 className="font-bold text-base text-neutral-900">
                  {relationship.isBlocked ? `Unblock ${profile.name}?` : `Block ${profile.name}?`}
                </h3>
                <p className="text-xs text-neutral-500">
                  {relationship.isBlocked
                    ? 'Unblocking will allow them to view your public profile, listings, and message you.'
                    : 'Blocked users cannot view your profile, send you direct messages, call you, or see your posts.'}
                </p>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBlockModal(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={relationship.isBlocked ? handleUnblockUser : handleBlockUser}
                  className={`flex-1 min-h-[40px] px-4 py-2 rounded-xl text-white text-xs font-semibold cursor-pointer transition-colors ${
                    relationship.isBlocked ? 'bg-neutral-900 hover:bg-black' : 'bg-red-600 hover:bg-red-700'
                  }`}
                >
                  {relationship.isBlocked ? 'Confirm Unblock' : 'Confirm Block'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: EDIT ALL PROFILE INFORMATION ================= */}
      <AnimatePresence>
        {isEditProfileModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 sm:p-7 max-w-lg w-full shadow-2xl space-y-5 text-left max-h-[92vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shadow-2xs">
                    <Edit3 className="w-4 h-4 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-neutral-900 font-serif-lux">Edit Profile</h3>
                    <p className="text-[11px] text-neutral-500">Update your sovereign profile identity and details</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsEditProfileModalOpen(false)}
                  className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {editErrorMessage && (
                <div className="p-3 rounded-2xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{editErrorMessage}</span>
                </div>
              )}

              <form onSubmit={handleSaveProfileChanges} className="space-y-4">
                {/* Full Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-neutral-500" />
                    <span>Full Name / Display Name</span>
                  </label>
                  <input
                    type="text"
                    value={editFullName}
                    onChange={(e) => setEditFullName(e.target.value)}
                    placeholder="e.g. Satoshi Nakamoto"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 focus:outline-hidden focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 bg-white"
                  />
                </div>

                {/* User ID / Handle with Live Availability Status */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                      <AtSign className="w-3.5 h-3.5 text-neutral-500" />
                      <span>User ID Handle</span>
                    </label>
                    {editUserId && (
                      <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                        userIdStatus.available ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {userIdStatus.available ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{userIdStatus.message || 'Available'}</span>
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-3 h-3" />
                            <span>{userIdStatus.message || 'Unavailable'}</span>
                          </>
                        )}
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-xs">@</span>
                    <input
                      type="text"
                      value={editUserId}
                      onChange={handleEditUserIdChange}
                      placeholder="username"
                      required
                      className={`w-full pl-8 pr-3.5 py-2.5 rounded-xl border text-xs font-mono text-neutral-900 focus:outline-hidden ${
                        !userIdStatus.available
                          ? 'border-red-300 focus:border-red-500 focus:ring-1 focus:ring-red-500 bg-red-50/20'
                          : 'border-neutral-200 focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 bg-white'
                      }`}
                    />
                  </div>
                  <p className="text-[10px] text-neutral-400">Unique public handle across directory and barter queries.</p>
                </div>

                {/* Email Address with Live Availability Status */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-neutral-500" />
                      <span>Email Address</span>
                    </label>
                    {editEmail && (
                      <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                        emailStatus.available ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {emailStatus.available ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{emailStatus.message || 'Available'}</span>
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-3 h-3" />
                            <span>{emailStatus.message || 'Unavailable'}</span>
                          </>
                        )}
                      </span>
                    )}
                  </div>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={handleEditEmailChange}
                    placeholder="name@example.com"
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs text-neutral-900 focus:outline-hidden ${
                      !emailStatus.available
                        ? 'border-red-300 focus:border-red-500 focus:ring-1 focus:ring-red-500 bg-red-50/20'
                        : 'border-neutral-200 focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 bg-white'
                    }`}
                  />
                  <p className="text-[10px] text-neutral-400">Used for account security and authentication recovery.</p>
                </div>

                {/* Bio - No limit! */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-neutral-500" />
                      <span>Bio / About Yourself</span>
                    </label>
                    <span className="text-[10px] text-emerald-600 font-semibold px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200">
                      No Character Limit
                    </span>
                  </div>
                  <textarea
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    placeholder="Tell the community about yourself, your sovereign reserve allocations, trading interests, specialties, and goals..."
                    rows={4}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 focus:outline-hidden focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 leading-relaxed resize-y min-h-[100px] bg-white"
                  />
                  <p className="text-[10px] text-neutral-400">Write whatever you want about yourself — detailed description, background, or multi-asset trade terms.</p>
                </div>

                {/* Direct Photo Upload Controls (Avatar & Cover) */}
                <div className="pt-3 border-t border-neutral-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-neutral-800">Profile Photos</span>
                    <span className="text-[10px] text-neutral-400">Upload directly or select themes</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Avatar Upload in Edit Form */}
                    <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center gap-3">
                      <div className="w-11 h-11 rounded-full bg-black text-white shrink-0 overflow-hidden flex items-center justify-center text-sm font-bold border border-neutral-300">
                        {editAvatarUrl ? (
                          <img src={editAvatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                        ) : (
                          (editFullName ? editFullName.charAt(0).toUpperCase() : 'U')
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <label className="text-[11px] font-semibold text-neutral-700 block truncate">Avatar Photo</label>
                        <div className="flex items-center gap-2 mt-1">
                          <input
                            type="file"
                            id="edit-modal-avatar-file"
                            onChange={handleEditAvatarUpload}
                            accept="image/*"
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => document.getElementById('edit-modal-avatar-file')?.click()}
                            className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-black text-white text-[10px] font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Upload</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setIsEditProfileModalOpen(false);
                              setIsAvatarModalOpen(true);
                            }}
                            className="text-[10px] text-neutral-600 hover:text-black cursor-pointer underline"
                          >
                            More
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Cover Upload in Edit Form */}
                    <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center gap-3">
                      <div className="w-14 h-11 rounded-xl bg-neutral-900 text-white shrink-0 overflow-hidden flex items-center justify-center text-xs border border-neutral-300">
                        {editCoverUrl ? (
                          <img src={editCoverUrl} alt="Cover" className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-[9px] text-neutral-400">Default</span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <label className="text-[11px] font-semibold text-neutral-700 block truncate">Cover Banner</label>
                        <div className="flex items-center gap-2 mt-1">
                          <input
                            type="file"
                            id="edit-modal-cover-file"
                            onChange={handleEditCoverUpload}
                            accept="image/*"
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => document.getElementById('edit-modal-cover-file')?.click()}
                            className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-black text-white text-[10px] font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Upload</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setIsEditProfileModalOpen(false);
                              setIsCoverModalOpen(true);
                            }}
                            className="text-[10px] text-neutral-600 hover:text-black cursor-pointer underline"
                          >
                            Themes
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="pt-3 border-t border-neutral-100 flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setIsEditProfileModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100 cursor-pointer transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingProfile || !userIdStatus.available || (editEmail.trim() ? !emailStatus.available : false)}
                    className="px-5 py-2.5 rounded-xl bg-neutral-950 hover:bg-black disabled:bg-neutral-300 text-white text-xs font-bold transition-all shadow-sm cursor-pointer disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {isSavingProfile && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    <span>Save Changes</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: POST QUICK PREVIEW (FALLBACK) ================= */}
      <AnimatePresence>
        {selectedPostPreview && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-lg w-full shadow-2xl space-y-4 text-left max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-neutral-500">{selectedPostPreview.category || 'Listing Preview'}</span>
                  <span className="flex items-center gap-1 text-[11px] font-mono text-neutral-500">
                    <Eye className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{(selectedPostPreview.views ?? 0).toLocaleString()} views</span>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedPostPreview(null)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {selectedPostPreview.imageUrl && (
                <div className="rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-200">
                  <img
                    src={selectedPostPreview.imageUrl}
                    alt={selectedPostPreview.title}
                    className="w-full max-h-80 object-contain"
                  />
                </div>
              )}

              {selectedPostPreview.mediaList && selectedPostPreview.mediaList.length > 0 && (
                <div className="space-y-2">
                  {selectedPostPreview.mediaList
                    .filter((m) => m.type === 'image' && m.url !== selectedPostPreview.imageUrl)
                    .map((m) => (
                      <div key={m.id} className="rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-200">
                        <img src={m.url} alt={m.name} className="w-full max-h-64 object-contain" />
                      </div>
                    ))}
                  {selectedPostPreview.mediaList
                    .filter((m) => m.type === 'video')
                    .map((m) => (
                      <div key={m.id} className="rounded-2xl overflow-hidden bg-black border border-neutral-200">
                        <video src={m.url} controls playsInline preload="metadata" className="w-full max-h-64 object-contain" />
                      </div>
                    ))}
                </div>
              )}

              {selectedPostPreview.videoUrl && !selectedPostPreview.mediaList?.some((m) => m.url === selectedPostPreview.videoUrl) && (
                <div className="rounded-2xl overflow-hidden bg-black border border-neutral-200">
                  <video src={selectedPostPreview.videoUrl} controls playsInline preload="metadata" className="w-full max-h-64 object-contain" />
                </div>
              )}

              <div className="space-y-2">
                <h3 className="font-bold text-lg text-neutral-900 font-serif-lux">
                  {selectedPostPreview.title}
                </h3>
                {selectedPostPreview.description && (
                  <p className="text-xs text-neutral-600 leading-relaxed whitespace-pre-line">
                    {selectedPostPreview.description}
                  </p>
                )}
                {selectedPostPreview.tags && selectedPostPreview.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {selectedPostPreview.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 rounded-full bg-neutral-100 border border-neutral-200 text-[11px] font-medium text-neutral-700"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {selectedPostPreview.finalCoinsPricing && (
                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                  <span className="text-xs font-semibold text-amber-900">Final Coins Valuation</span>
                  <span className="text-sm font-bold text-amber-800 font-mono">
                    {selectedPostPreview.finalCoinsPricing.amount.toLocaleString()} {selectedPostPreview.finalCoinsPricing.symbol}
                  </span>
                </div>
              )}

              <div className="pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setSelectedPostPreview(null)}
                  className="w-full min-h-[40px] px-4 py-2 rounded-xl bg-neutral-950 text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer transition-colors"
                >
                  Close Preview
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* ================= MODAL: ADMIN TRANSFER (MINT / BURN) ================= */}
      <AnimatePresence>
        {isAdminTransferModalOpen && profile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 p-6 max-w-lg w-full shadow-2xl space-y-5 text-left text-slate-900 max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold shadow-2xs shrink-0">
                    <Coins className="w-5 h-5 text-amber-800" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-700 tracking-wider uppercase block">
                      Admin Sovereign Authority
                    </span>
                    <h3 className="font-serif text-base font-bold text-slate-900">
                      Final Admin Coin Transfer &amp; System Mint
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAdminTransferModalOpen(false)}
                  className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Target User Banner */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-amber-100 border border-amber-200 flex items-center justify-center font-bold text-amber-800 text-xs">
                    {profile.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">{profile.name}</span>
                    <span className="text-[11px] font-mono text-slate-500">@{profile.userId}</span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-800">
                  Target Account
                </span>
              </div>

              {/* Action Selection Tabs */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-slate-700 block">
                  Select Admin Action Mode
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => { setAdminTransferAction('add'); setAdminTransferErrorMsg(null); setShowAdminTransferConfirm(false); }}
                    className={`min-h-[40px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      adminTransferAction === 'add'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                    }`}
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Add Final Coins (Mint / Credit)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAdminTransferAction('deduct'); setAdminTransferErrorMsg(null); setShowAdminTransferConfirm(false); }}
                    className={`min-h-[40px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      adminTransferAction === 'deduct'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                    }`}
                  >
                    <Ban className="w-4 h-4" />
                    <span>Deduct Final Coins (Burn / Slash)</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 italic px-1 pt-0.5">
                  {adminTransferAction === 'add'
                    ? '⚡ System Mint Mode: Creates unlimited new Final Coins in the system directly for the user.'
                    : '🔥 System Burn Mode: Takes Final Coins directly out of the user\'s account.'}
                </p>
              </div>

              {/* Final Coin Symbol Selection / Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-slate-700 flex items-center justify-between">
                  <span>Select or Enter Final Coin Symbol</span>
                  <span className="text-[10px] text-amber-700 font-normal">Any Final Coin Supported</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <select
                    value={['AFNL', 'USDCF', 'GOLDF', 'EUROF'].includes(adminTransferSymbol) ? adminTransferSymbol : 'CUSTOM'}
                    onChange={(e) => {
                      if (e.target.value !== 'CUSTOM') {
                        setAdminTransferSymbol(e.target.value);
                      }
                      setShowAdminTransferConfirm(false);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white font-mono font-bold text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="AFNL">AFNL (Final Admin Coin)</option>
                    <option value="USDCF">USDCF (USD Final Coin)</option>
                    <option value="GOLDF">GOLDF (Gold Final Coin)</option>
                    <option value="EUROF">EUROF (Euro Final Coin)</option>
                    <option value="CUSTOM">Custom Final Coin Symbol...</option>
                  </select>

                  <input
                    type="text"
                    value={adminTransferSymbol}
                    onChange={(e) => {
                      setAdminTransferSymbol(e.target.value.toUpperCase());
                      setShowAdminTransferConfirm(false);
                    }}
                    placeholder="e.g. SOLF"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 font-mono font-bold text-xs text-slate-900 uppercase focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Amount Input & Presets */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono font-bold text-slate-700 block">
                    Coin Amount ({adminTransferSymbol || 'AFNL'})
                  </label>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold">
                    Unlimited Issuance Enabled
                  </span>
                </div>
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={adminTransferAmount}
                  onChange={(e) => {
                    setAdminTransferAmount(e.target.value);
                    setShowAdminTransferConfirm(false);
                  }}
                  placeholder="Enter amount..."
                  className="w-full min-h-[42px] px-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 font-mono font-bold text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  {['100', '1,000', '5,000', '25,000', '100,000', '1,000,000'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => {
                        setAdminTransferAmount(val.replace(/,/g, ''));
                        setShowAdminTransferConfirm(false);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-200 text-[10px] font-mono font-bold text-slate-700 cursor-pointer transition-colors"
                    >
                      +{val}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reason / Note */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-slate-700 block">
                  Admin Audit Reason / Note
                </label>
                <input
                  type="text"
                  value={adminTransferReason}
                  onChange={(e) => {
                    setAdminTransferReason(e.target.value);
                    setShowAdminTransferConfirm(false);
                  }}
                  placeholder="Reason for admin balance adjustment..."
                  className="w-full min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* CONFIRMATION STEP OVERLAY / BOX */}
              {showAdminTransferConfirm && (
                <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-900 space-y-3 shadow-sm animate-fade-in">
                  <div className="flex items-center gap-2 text-amber-800 font-bold text-xs uppercase tracking-wider">
                    <AlertCircle className="w-4 h-4 text-amber-700" />
                    <span>Confirmation Required Before Finalizing</span>
                  </div>
                  <p className="text-xs leading-relaxed text-slate-700">
                    Are you sure you want to {adminTransferAction === 'add' ? 'mint and credit' : 'deduct'} <strong className="font-mono font-bold">{parseFloat(adminTransferAmount || '0').toLocaleString()} {adminTransferSymbol || 'AFNL'}</strong> {adminTransferAction === 'add' ? 'to' : 'from'} <strong className="font-bold">@{profile.userId}</strong>?
                  </p>
                  {adminTransferSuccessMsg && (
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                      {adminTransferSuccessMsg}
                    </div>
                  )}
                  {adminTransferErrorMsg && (
                    <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                      {adminTransferErrorMsg}
                    </div>
                  )}
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowAdminTransferConfirm(false)}
                      className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={isAdminTransferLoading}
                      onClick={handleExecuteAdminTransfer}
                      className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition-all shadow-sm cursor-pointer disabled:opacity-50"
                    >
                      {isAdminTransferLoading ? 'Executing...' : 'Confirm Execution'}
                    </button>
                  </div>
                </div>
              )}

              {/* Success / Error Messages when not in confirm */}
              {!showAdminTransferConfirm && adminTransferSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                  {adminTransferSuccessMsg}
                </div>
              )}
              {!showAdminTransferConfirm && adminTransferErrorMsg && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                  {adminTransferErrorMsg}
                </div>
              )}

              {/* Footer buttons */}
              {!showAdminTransferConfirm && (
                <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsAdminTransferModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    disabled={isAdminTransferLoading}
                    onClick={handleExecuteAdminTransfer}
                    className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    {isAdminTransferLoading ? 'Processing...' : (adminTransferAction === 'add' ? 'Execute Mint & Credit' : 'Execute Deduction')}
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Peer-to-Peer Transfer Modal */}
      {profile && (
        <PeerTransferModal
          isOpen={isTransferModalOpen}
          onClose={() => setIsTransferModalOpen(false)}
          recipient={{
            uid: profile.userId,
            userId: profile.userId,
            name: profile.name,
            avatarUrl: profile.avatarUrl,
            isVerified: true
          }}
          currentUser={currentUser}
        />
      )}

      {/* Provide/Ask Loan Modal */}
      {profile && (
        <ProvideLoanModal
          isOpen={isProvideLoanModalOpen}
          onClose={() => setIsProvideLoanModalOpen(false)}
          currentUser={currentUser}
          targetUser={profile}
          mode={loanModalMode}
          onSuccess={(msg) => showToast(msg)}
        />
      )}

      {/* ================= GROUP MANAGEMENT MODAL ================= */}
      {isGroupManagementModalOpen && profile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-md w-full overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl}
                    alt={profile.name}
                    className="w-10 h-10 rounded-full object-cover shrink-0 border border-neutral-200"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-neutral-900 text-white font-bold flex items-center justify-center shrink-0">
                    {profile.name.charAt(0)}
                  </div>
                )}
                <div className="min-w-0">
                  <h3 className="font-bold text-sm text-black truncate">
                    Assign Groups for {profile.name}
                  </h3>
                  <p className="text-[11px] text-neutral-400 font-mono truncate">
                    @{profile.userId}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsGroupManagementModalOpen(false)}
                className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-3 text-xs text-emerald-900 leading-relaxed">
                <strong>Group Assignment:</strong> Group individuals into multiple custom or friend groups instantly without requiring friendship connection.
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-neutral-700">
                  Select Groups
                </label>

                {groupErrorMsg && (
                  <div className="p-2 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100 flex items-center justify-between">
                    <span>{groupErrorMsg}</span>
                    <button type="button" onClick={() => setGroupErrorMsg('')} className="p-0.5 hover:bg-red-100 rounded-full text-red-700">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {selectableProfileGroups.length === 0 ? (
                  <div className="p-6 bg-neutral-50 border border-neutral-200/80 rounded-2xl text-center space-y-2">
                    <p className="text-xs text-neutral-500">
                      {relationship.friendStatus === 'friends' 
                        ? "You haven't created any groups yet." 
                        : "You haven't created any General Groups yet."}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {selectableProfileGroups.map((group) => {
                      const isInGroup = group.memberUids.includes(profile.uid);
                      const assign = group.memberAssignments?.[profile.uid];
                      return (
                        <div
                          key={group.id}
                          className={`p-3 rounded-2xl border transition-all space-y-2 ${
                            isInGroup
                              ? 'bg-emerald-50/80 border-emerald-300 shadow-2xs'
                              : 'bg-white border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                          }`}
                        >
                          <div
                            onClick={() => handleToggleGroupMembership(group)}
                            className="flex items-center justify-between cursor-pointer"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className="w-3.5 h-3.5 rounded-full shrink-0 border border-black/10"
                                style={{ backgroundColor: group.color || '#f59e0b' }}
                              />
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-black truncate">{group.name}</p>
                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] text-neutral-500 truncate">{group.description || 'Custom Group'}</span>
                                  <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${group.groupType === 'general' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
                                    {group.groupType === 'general' ? 'General Group' : 'Friend Group'}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-[10px] font-mono text-neutral-400">
                                {group.memberUids.length}/{MAX_CUSTOM_GROUP_MEMBERS}
                              </span>
                              <input
                                type="checkbox"
                                checked={isInGroup}
                                onChange={() => {}}
                                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                              />
                            </div>
                          </div>

                          {isInGroup && (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="pt-2 border-t border-emerald-200/60 flex items-center gap-2"
                            >
                              <input
                                type="number"
                                step="1"
                                value={typeof assign?.number === 'number' ? String(assign.number) : ''}
                                onChange={(e) => handleUpdateGroupMemberAssignment(group, 'number', e.target.value)}
                                placeholder="# (opt)"
                                className="w-20 px-2 py-1 rounded-lg bg-white border border-emerald-200 text-xs font-mono text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                              <input
                                type="text"
                                value={assign?.role || ''}
                                onChange={(e) => handleUpdateGroupMemberAssignment(group, 'role', e.target.value)}
                                placeholder="Role in this group (optional)"
                                className="flex-1 px-2.5 py-1 rounded-lg bg-white border border-emerald-200 text-xs text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setIsGroupManagementModalOpen(false)}
                className="px-5 py-2 rounded-full bg-black text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer shadow-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unfriend Confirmation Modal */}
      <ConfirmModal
        isOpen={showUnfriendConfirm}
        onClose={() => setShowUnfriendConfirm(false)}
        onConfirm={confirmRemoveFriend}
        title="Unfriend Member"
        message={`Are you sure you want to remove ${profile?.name || 'this user'} from your friends? You will no longer be able to place friend-only voice or video calls until you reconnect.`}
        confirmText="Unfriend"
        cancelText="Cancel"
        type="danger"
      />
    </motion.div>
  );
};
