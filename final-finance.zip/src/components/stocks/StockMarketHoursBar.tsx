import React from 'react';
import { Clock, Globe, ShieldCheck, AlertCircle } from 'lucide-react';
import { getLocalStockMarketStatus } from '../../utils/marketHours';

export const StockMarketHoursBar: React.FC = () => {
  const marketStatus = getLocalStockMarketStatus();

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-left">
      <div className="flex items-center gap-3.5">
        <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
          marketStatus.isOpen 
            ? 'bg-emerald-50 text-emerald-600 border border-emerald-200' 
            : 'bg-amber-50 text-amber-600 border border-amber-200'
        }`}>
          <Clock className="w-5 h-5" />
        </div>

        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className={`px-2.5 py-0.5 rounded-full text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1.5 border ${
              marketStatus.isOpen 
                ? 'bg-emerald-100/70 border-emerald-300 text-emerald-900' 
                : 'bg-rose-100/70 border-rose-300 text-rose-900'
            }`}>
              <span className={`w-2 h-2 rounded-full ${marketStatus.isOpen ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
              <span>{marketStatus.statusText}</span>
            </div>

            <span className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-md">
              {marketStatus.formattedLocalTime}
            </span>
          </div>

          <div className="text-xs font-semibold text-slate-800 mt-1 flex items-center gap-1.5">
            <span>{marketStatus.nextOpeningText}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:items-end justify-center text-left sm:text-right border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100">
        <div className="text-xs font-mono text-slate-600 font-medium flex items-center sm:justify-end gap-1">
          <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>Local Timezone: <strong className="text-slate-900 font-mono">{marketStatus.timeZone}</strong></span>
        </div>
        <div className="text-[11px] text-slate-400 mt-0.5 font-sans">
          Regular Trading Hours: Mon–Fri 9:30 AM – 4:00 PM
        </div>
      </div>
    </div>
  );
};
