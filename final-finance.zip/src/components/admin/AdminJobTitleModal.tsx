import React, { useState } from 'react';
import { Briefcase, Check, X, Tag, Shield } from 'lucide-react';
import { AdminMember } from '../../services/adminGroupService';

interface AdminJobTitleModalProps {
  admin: AdminMember;
  onClose: () => void;
  onSave: (title: string) => void;
}

const TITLE_SUGGESTIONS = [
  'Compliance Lead',
  'Senior Officer',
  'Senior Investment Officer',
  'Chief Risk Officer',
  'Treasury Custodian',
  'Cryptographic Reserve Officer',
  'VIP Liquidity Desk Lead',
  'Audit & Reserve Inspector',
  'Dispute Resolution Officer',
  'Security & Operations Manager',
  'Junior Operations Admin',
];

export const AdminJobTitleModal: React.FC<AdminJobTitleModalProps> = ({
  admin,
  onClose,
  onSave,
}) => {
  const [jobTitle, setJobTitle] = useState(admin.jobTitle || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(jobTitle.trim() || 'Administrator');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600 shrink-0">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-base font-bold text-slate-900">
                Assign Job Title
              </h3>
              <p className="text-xs text-slate-500">
                Super Admin administrative title authorization
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
          <div className="p-5 space-y-4 flex-1 overflow-y-auto min-h-0">
            {/* Target Admin Card */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-sm border border-amber-200 shrink-0">
                {admin.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-slate-900 truncate">{admin.name}</span>
                  <span className="font-mono text-[11px] text-amber-600">{admin.handle}</span>
                </div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200">
                    {admin.role === 'super_admin' ? 'Super Admin' : 'Admin'}
                  </span>
                  <span className="text-[11px] text-slate-500 truncate">
                    Current: {admin.jobTitle || 'None'}
                  </span>
                </div>
              </div>
            </div>

            {/* Job Title Input */}
            <div>
              <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider font-semibold mb-1.5">
                Admin Job Title *
              </label>
              <input
                type="text"
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                placeholder="e.g. Compliance Lead, Senior Officer, Treasury Custodian..."
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-slate-900 font-medium"
                required
                autoFocus
              />
            </div>

            {/* Suggested Titles */}
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-2 font-semibold flex items-center gap-1">
                <Tag className="w-3 h-3 text-slate-400" />
                Quick Suggested Titles:
              </span>
              <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto pr-1">
                {TITLE_SUGGESTIONS.map((title) => (
                  <button
                    key={title}
                    type="button"
                    onClick={() => setJobTitle(title)}
                    className={`px-2.5 py-1 rounded-lg text-xs transition-colors cursor-pointer border ${
                      jobTitle === title
                        ? 'bg-indigo-600 text-white border-indigo-600 font-bold'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200 font-medium'
                    }`}
                  >
                    {title}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/80 flex items-center justify-end gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-800 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Save Job Title</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
