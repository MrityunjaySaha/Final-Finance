import React, { useState, useRef, useMemo, useEffect } from 'react';
import {
  X,
  Newspaper,
  FileText,
  Image as ImageIcon,
  Video,
  Upload,
  Trash2,
  TrendingUp,
  TrendingDown,
  Minus,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Plus,
  Link as LinkIcon,
  FileSpreadsheet
} from 'lucide-react';
import {
  IPORequest,
  StockNewsItem,
  StockNewsDocumentAttachment,
  StockNewsMediaAttachment
} from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { addIPONewsItem, isIPOInheritedByUser } from '../../data/stocksData';

interface PostIPONewsModalProps {
  isOpen: boolean;
  onClose: () => void;
  ipos: IPORequest[];
  initialIpo?: IPORequest | null;
  currentUser?: AuthSession | null;
  onPublished?: (item: StockNewsItem) => void;
}

const NEWS_CATEGORIES = [
  'Earnings',
  'Financial Filing',
  'Product & Operations',
  'Corporate Update',
  'Dividend & Treasury'
] as const;

function formatFileSize(bytes?: number): string {
  if (!bytes || bytes <= 0) return 'File';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function compressImageToDataUrl(file: File, maxDim = 1280, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.onload = () => {
      const rawUrl = reader.result as string;
      if (file.size < 220 * 1024) {
        resolve(rawUrl);
        return;
      }
      const img = new Image();
      img.onerror = () => resolve(rawUrl);
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            const ratio = Math.min(maxDim / width, maxDim / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(rawUrl);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', quality);
          resolve(compressed.length < rawUrl.length ? compressed : rawUrl);
        } catch {
          resolve(rawUrl);
        }
      };
      img.src = rawUrl;
    };
    reader.readAsDataURL(file);
  });
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Failed to read ${file.name}.`));
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(file);
  });
}

export const PostIPONewsModal: React.FC<PostIPONewsModalProps> = ({
  isOpen,
  onClose,
  ipos,
  initialIpo,
  currentUser,
  onPublished
}) => {
  const orderedIPOs = useMemo(() => {
    const owned: IPORequest[] = [];
    const others: IPORequest[] = [];
    ipos.forEach((ipo) => {
      if (isIPOInheritedByUser(ipo, currentUser)) {
        owned.push(ipo);
      } else {
        others.push(ipo);
      }
    });
    return [...owned, ...others];
  }, [ipos, currentUser]);

  const [selectedIpoId, setSelectedIpoId] = useState<string>(() => {
    return initialIpo?.id || orderedIPOs[0]?.id || '';
  });

  useEffect(() => {
    if (isOpen) {
      if (initialIpo?.id) {
        setSelectedIpoId(initialIpo.id);
      } else if (!selectedIpoId && orderedIPOs[0]?.id) {
        setSelectedIpoId(orderedIPOs[0].id);
      }
    }
  }, [isOpen, initialIpo?.id, orderedIPOs, selectedIpoId]);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<string>('Earnings');
  const [sentiment, setSentiment] = useState<'bullish' | 'neutral' | 'bearish'>('bullish');
  const [impact, setImpact] = useState<'High Impact' | 'Medium Impact' | 'Macro Trend'>('High Impact');
  const [keyTakeaway, setKeyTakeaway] = useState('');
  const [bodyText, setBodyText] = useState('');

  const [documents, setDocuments] = useState<StockNewsDocumentAttachment[]>([]);
  const [photos, setPhotos] = useState<StockNewsMediaAttachment[]>([]);
  const [videos, setVideos] = useState<StockNewsMediaAttachment[]>([]);

  const [photoUrlInput, setPhotoUrlInput] = useState('');
  const [videoUrlInput, setVideoUrlInput] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const docInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const selectedIpo = orderedIPOs.find((i) => i.id === selectedIpoId) || orderedIPOs[0] || null;

  const handleDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    try {
      const uploaded: StockNewsDocumentAttachment[] = [];
      for (const file of files) {
        if (file.size > 3 * 1024 * 1024) {
          setErrorMsg(`Document "${file.name}" exceeds the 3MB browser storage limit. Please upload a smaller file.`);
          continue;
        }
        const dataUrl = await readFileAsDataUrl(file);
        uploaded.push({
          id: `doc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          name: file.name,
          mimeType: file.type || 'application/octet-stream',
          sizeBytes: file.size,
          url: dataUrl,
          uploadedAt: new Date().toISOString()
        });
      }
      if (uploaded.length > 0) {
        setDocuments((prev) => [...prev, ...uploaded]);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to upload document.');
    } finally {
      if (docInputRef.current) docInputRef.current.value = '';
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    try {
      const uploaded: StockNewsMediaAttachment[] = [];
      for (const file of files) {
        if (!file.type.startsWith('image/')) {
          setErrorMsg(`"${file.name}" is not a valid image file.`);
          continue;
        }
        if (file.size > 12 * 1024 * 1024) {
          setErrorMsg(`Photo "${file.name}" exceeds 12MB.`);
          continue;
        }
        const dataUrl = await compressImageToDataUrl(file);
        uploaded.push({
          id: `pho_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          type: 'photo',
          name: file.name,
          url: dataUrl,
          sizeBytes: file.size,
          uploadedAt: new Date().toISOString()
        });
      }
      if (uploaded.length > 0) {
        setPhotos((prev) => [...prev, ...uploaded]);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to upload photo.');
    } finally {
      if (photoInputRef.current) photoInputRef.current.value = '';
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    try {
      const uploaded: StockNewsMediaAttachment[] = [];
      for (const file of files) {
        if (!file.type.startsWith('video/')) {
          setErrorMsg(`"${file.name}" is not a valid video file.`);
          continue;
        }
        if (file.size > 3.5 * 1024 * 1024) {
          setErrorMsg(
            `Video "${file.name}" (${formatFileSize(file.size)}) is larger than 3.5MB browser storage limit. Use a smaller clip or paste a direct video URL below.`
          );
          continue;
        }
        const dataUrl = await readFileAsDataUrl(file);
        uploaded.push({
          id: `vid_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          type: 'video',
          name: file.name,
          url: dataUrl,
          sizeBytes: file.size,
          uploadedAt: new Date().toISOString()
        });
      }
      if (uploaded.length > 0) {
        setVideos((prev) => [...prev, ...uploaded]);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to upload video.');
    } finally {
      if (videoInputRef.current) videoInputRef.current.value = '';
    }
  };

  const handleAddPhotoUrl = () => {
    if (!photoUrlInput.trim()) return;
    setErrorMsg(null);
    const trimmed = photoUrlInput.trim();
    setPhotos((prev) => [
      ...prev,
      {
        id: `pho_url_${Date.now()}`,
        type: 'photo',
        name: trimmed.split('/').pop()?.split('?')[0] || 'Linked Photo',
        url: trimmed,
        uploadedAt: new Date().toISOString()
      }
    ]);
    setPhotoUrlInput('');
  };

  const handleAddVideoUrl = () => {
    if (!videoUrlInput.trim()) return;
    setErrorMsg(null);
    const trimmed = videoUrlInput.trim();
    setVideos((prev) => [
      ...prev,
      {
        id: `vid_url_${Date.now()}`,
        type: 'video',
        name: trimmed.split('/').pop()?.split('?')[0] || 'Linked Video',
        url: trimmed,
        uploadedAt: new Date().toISOString()
      }
    ]);
    setVideoUrlInput('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!selectedIpo) {
      setErrorMsg('Please select or create an IPO before posting an update.');
      return;
    }

    if (!title.trim()) {
      setErrorMsg('Please enter a headline for your IPO news or earnings report.');
      return;
    }

    if (!bodyText.trim() && documents.length === 0 && photos.length === 0 && videos.length === 0) {
      setErrorMsg('Please write a report update or attach at least one document, photo, or video.');
      return;
    }

    setIsSubmitting(true);
    const res = addIPONewsItem(selectedIpo, {
      title: title.trim(),
      bodyText: bodyText.trim() || `Official ${category} update published for $${selectedIpo.ticker} (${selectedIpo.equityName}).`,
      category,
      sentiment,
      impact,
      keyTakeaway: keyTakeaway.trim() || undefined,
      documents,
      photos,
      videos,
      authorId: currentUser?.id,
      authorName: currentUser?.name || selectedIpo.issuerName,
      authorHandle: currentUser?.handle || selectedIpo.issuerHandle,
      authorAvatar: currentUser?.avatarUrl || selectedIpo.issuerAvatar
    });
    setIsSubmitting(false);

    if (!res.success || !res.item) {
      setErrorMsg(res.error || 'Could not publish IPO update.');
      return;
    }

    if (onPublished) onPublished(res.item);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto text-left">
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-3xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400 shrink-0">
              <Newspaper className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="font-serif text-base sm:text-lg font-bold text-white truncate">
                Publish IPO News &amp; Earnings Update
              </h3>
              <p className="text-xs text-slate-300 truncate">
                Post reports, documents, photos, videos &amp; text updates to Trending Stock News.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 max-h-[75vh] overflow-y-auto space-y-5 text-xs">
          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span className="leading-relaxed font-medium">{errorMsg}</span>
            </div>
          )}

          {/* 1. Target IPO Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
              Select IPO Equity
            </label>
            {orderedIPOs.length === 0 ? (
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900">
                No IPOs found yet. Release an IPO first in Portfolio &rarr; Equity &rarr; My IPOs &amp; Issues.
              </div>
            ) : (
              <select
                value={selectedIpo?.id || ''}
                onChange={(e) => setSelectedIpoId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              >
                {orderedIPOs.map((ipo) => {
                  const mine = isIPOInheritedByUser(ipo, currentUser);
                  return (
                    <option key={ipo.id} value={ipo.id}>
                      ${ipo.ticker} — {ipo.equityName} {mine ? '(Your IPO)' : ''} [{ipo.status === 'active' ? 'Live' : 'Pending'}]
                    </option>
                  );
                })}
              </select>
            )}
          </div>

          {/* 2. Headline & Category */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2 space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
                Headline / Report Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Q3 Earnings Report: Revenue Up 48% & Product Milestone"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500 font-semibold"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
                Update Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 font-semibold focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              >
                {NEWS_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 3. Sentiment & Impact */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
                Signal / Sentiment
              </label>
              <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-100">
                <button
                  type="button"
                  onClick={() => setSentiment('bullish')}
                  className={`py-1.5 rounded-lg font-bold flex items-center justify-center gap-1 cursor-pointer transition-all ${
                    sentiment === 'bullish' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Bullish</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSentiment('neutral')}
                  className={`py-1.5 rounded-lg font-bold flex items-center justify-center gap-1 cursor-pointer transition-all ${
                    sentiment === 'neutral' ? 'bg-slate-800 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Minus className="w-3.5 h-3.5" />
                  <span>Neutral</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSentiment('bearish')}
                  className={`py-1.5 rounded-lg font-bold flex items-center justify-center gap-1 cursor-pointer transition-all ${
                    sentiment === 'bearish' ? 'bg-rose-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <TrendingDown className="w-3.5 h-3.5" />
                  <span>Bearish</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
                Market Impact Tag
              </label>
              <select
                value={impact}
                onChange={(e) => setImpact(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 font-semibold focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              >
                <option value="High Impact">High Impact</option>
                <option value="Medium Impact">Medium Impact</option>
                <option value="Macro Trend">Macro Trend</option>
              </select>
            </div>
          </div>

          {/* 4. Key Takeaway (Optional) */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-600" />
              <span>Key Takeaway / Highlight (Optional)</span>
            </label>
            <input
              type="text"
              value={keyTakeaway}
              onChange={(e) => setKeyTakeaway(e.target.value)}
              placeholder="e.g. Q3 net revenue reached $4.2M (+48% YoY); guidance raised for Q4."
              className="w-full px-3.5 py-2 rounded-xl bg-amber-50/40 border border-amber-200/80 text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* 5. Normal Text Update Body */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
              Update / Earnings Report Text
            </label>
            <textarea
              rows={5}
              value={bodyText}
              onChange={(e) => setBodyText(e.target.value)}
              placeholder="Write your normal text update here: share quarterly earnings numbers, operational progress, milestones, customer growth, or upcoming product launches so shareholders can follow your IPO..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500 leading-relaxed resize-y"
            />
          </div>

          {/* 6. Multimedia & Document Uploads */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h4 className="font-bold text-slate-900 text-xs">
                  Attach Documents, Photos &amp; Videos
                </h4>
                <p className="text-[11px] text-slate-500">
                  Upload earnings PDFs, spreadsheets, images, or video updates directly into your report.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <input
                  ref={docInputRef}
                  type="file"
                  multiple
                  accept=".pdf,.doc,.docx,.txt,.csv,.xls,.xlsx,.ppt,.pptx,application/pdf,text/plain,text/csv"
                  onChange={handleDocumentUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => docInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-slate-800 font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                >
                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                  <span>+ Document</span>
                </button>

                <input
                  ref={photoInputRef}
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => photoInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 text-slate-800 font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>+ Photo</span>
                </button>

                <input
                  ref={videoInputRef}
                  type="file"
                  multiple
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => videoInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-purple-50 border border-slate-200 hover:border-purple-300 text-slate-800 font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                >
                  <Video className="w-3.5 h-3.5 text-purple-600" />
                  <span>+ Video</span>
                </button>
              </div>
            </div>

            {/* Optional Direct Media URLs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 border-t border-slate-200/70">
              <div className="flex items-center gap-1.5">
                <div className="relative flex-1">
                  <LinkIcon className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="url"
                    value={photoUrlInput}
                    onChange={(e) => setPhotoUrlInput(e.target.value)}
                    placeholder="Or paste Photo URL (https://...)"
                    className="w-full pl-7 pr-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-[11px] text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleAddPhotoUrl}
                  className="px-2.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] cursor-pointer shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                <div className="relative flex-1">
                  <LinkIcon className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="url"
                    value={videoUrlInput}
                    onChange={(e) => setVideoUrlInput(e.target.value)}
                    placeholder="Or paste Video URL (https://...mp4)"
                    className="w-full pl-7 pr-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-[11px] text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-purple-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleAddVideoUrl}
                  className="px-2.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-[11px] cursor-pointer shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Attached Documents List */}
            {documents.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 font-mono block">
                  Attached Documents ({documents.length})
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="px-3 py-2 rounded-xl bg-white border border-indigo-200/80 flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <FileSpreadsheet className="w-4 h-4 text-indigo-600 shrink-0" />
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 truncate text-[11px]">{doc.name}</p>
                          <p className="text-[10px] font-mono text-slate-400">{formatFileSize(doc.sizeBytes)}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setDocuments((prev) => prev.filter((d) => d.id !== doc.id))}
                        className="p-1 rounded-lg text-rose-500 hover:bg-rose-50 cursor-pointer shrink-0"
                        title="Remove document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Attached Photos Preview */}
            {photos.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 font-mono block">
                  Attached Photos ({photos.length})
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {photos.map((photo) => (
                    <div
                      key={photo.id}
                      className="relative rounded-xl overflow-hidden border border-slate-200 bg-white group"
                    >
                      <img src={photo.url} alt={photo.name} className="w-full h-24 object-cover" />
                      <button
                        type="button"
                        onClick={() => setPhotos((prev) => prev.filter((p) => p.id !== photo.id))}
                        className="absolute top-1.5 right-1.5 p-1 rounded-lg bg-slate-900/80 text-white hover:bg-rose-600 cursor-pointer"
                        title="Remove photo"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                      <div className="px-2 py-1 text-[10px] text-slate-600 truncate bg-white border-t border-slate-100">
                        {photo.name}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Attached Videos Preview */}
            {videos.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 font-mono block">
                  Attached Videos ({videos.length})
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {videos.map((vid) => (
                    <div
                      key={vid.id}
                      className="rounded-xl overflow-hidden border border-purple-200 bg-slate-950"
                    >
                      <video src={vid.url} controls className="w-full h-36 object-contain bg-black" />
                      <div className="px-2.5 py-1.5 bg-white flex items-center justify-between gap-2">
                        <span className="text-[11px] font-semibold text-slate-700 truncate">{vid.name}</span>
                        <button
                          type="button"
                          onClick={() => setVideos((prev) => prev.filter((v) => v.id !== vid.id))}
                          className="p-1 rounded-lg text-rose-500 hover:bg-rose-50 cursor-pointer shrink-0"
                          title="Remove video"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Appears immediately in Final Stock Exchange &rarr; Trending Stock News.</span>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !selectedIpo}
                className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Upload className="w-3.5 h-3.5 text-amber-400" />
                <span>{isSubmitting ? 'Publishing...' : 'Publish IPO News'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
