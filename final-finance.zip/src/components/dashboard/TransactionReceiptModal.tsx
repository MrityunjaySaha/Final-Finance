import React, { useState } from 'react';
import { 
  X, 
  Receipt, 
  ShieldCheck, 
  Copy, 
  Check, 
  Printer, 
  Download, 
  ExternalLink, 
  Coins, 
  Building2, 
  Banknote, 
  Sparkles, 
  Binary, 
  User, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CreditCard, 
  FileText,
  Lock,
  QrCode,
  TrendingUp,
  TrendingDown,
  Repeat,
  ShoppingBag,
  Briefcase
} from 'lucide-react';
import { UniversalLedgerItem, TransactionMode } from '../../types/ledger';

interface TransactionReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: UniversalLedgerItem | null;
}

export const TransactionReceiptModal: React.FC<TransactionReceiptModalProps> = ({
  isOpen,
  onClose,
  transaction
}) => {
  const [copiedHash, setCopiedHash] = useState(false);

  if (!isOpen || !transaction) return null;

  const handleCopyHash = () => {
    navigator.clipboard.writeText(transaction.cryptographicHash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const getModeBadge = (mode: TransactionMode) => {
    switch (mode) {
      case 'final_coin':
        return {
          label: 'Mode 1: Final Coin ($AFNL)',
          icon: <Coins className="w-3.5 h-3.5 text-amber-500" />,
          style: 'bg-amber-50 text-amber-800 border-amber-200'
        };
      case 'fiat':
        return {
          label: 'Mode 2: Fiat Cash ($USD Fedwire)',
          icon: <Banknote className="w-3.5 h-3.5 text-sky-600" />,
          style: 'bg-sky-50 text-sky-800 border-sky-200'
        };
      case 'stable_coin':
        return {
          label: 'Mode 3: Stablecoin ($USDC Escrow)',
          icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />,
          style: 'bg-emerald-50 text-emerald-800 border-emerald-200'
        };
      case 'crypto':
        return {
          label: 'Mode 4: Crypto ($BTC / $ETH / $SOL)',
          icon: <Binary className="w-3.5 h-3.5 text-indigo-600" />,
          style: 'bg-indigo-50 text-indigo-800 border-indigo-200'
        };
      case 'gold_bullion':
        return {
          label: 'Mode 5: Gold Bullion (Zurich Vault)',
          icon: <Sparkles className="w-3.5 h-3.5 text-amber-600" />,
          style: 'bg-amber-100/70 text-amber-900 border-amber-300'
        };
      default:
        return {
          label: 'Sovereign Clearing Settlement',
          icon: <Coins className="w-3.5 h-3.5 text-slate-500" />,
          style: 'bg-slate-50 text-slate-800 border-slate-200'
        };
    }
  };

  const modeBadge = getModeBadge(transaction.mode) || {
    label: 'Sovereign Clearing Settlement',
    icon: <Coins className="w-3.5 h-3.5 text-slate-500" />,
    style: 'bg-slate-50 text-slate-800 border-slate-200'
  };
  const isPositive = transaction.type === 'deposit' || transaction.type === 'dividend' || transaction.type === 'staking_reward' || transaction.type === 'barter_swap' || transaction.type === 'stock_sell';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200 text-left">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
        {/* Receipt Header Banner */}
        <div className="bg-slate-900 text-white p-6 relative flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700 text-amber-400">
              <Receipt className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold tracking-widest uppercase text-amber-400 bg-amber-950/50 px-2 py-0.5 rounded border border-amber-900">
                  Transaction Receipt
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {transaction.receiptNumber}
                </span>
              </div>
              <h2 className="text-2xl font-serif text-white mt-0.5">
                {transaction.title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer border border-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Body */}
        <div className="p-8 space-y-8 overflow-y-auto flex-1 text-slate-800 text-xs bg-slate-50/50">
          {/* Top Key Specs */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-1">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Date & Time</span>
              <span className="block font-mono font-bold text-slate-900 text-sm">{transaction.timestamp}</span>
            </div>
            <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-1">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Mode</span>
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold border ${modeBadge.style}`}>
                {modeBadge.icon}
                {modeBadge.label}
              </span>
            </div>
          </div>

          {/* Asset & Transaction Details Box */}
          <div className="space-y-4">
            <h3 className="font-serif text-xs font-bold text-slate-500 uppercase tracking-widest">
              Transaction Details
            </h3>

            <div className="p-6 rounded-3xl border border-slate-200 bg-white shadow-sm space-y-4">
              <div className="flex items-start justify-between pb-4 border-b border-slate-100">
                <div className="space-y-1">
                  <h4 className="font-bold text-base text-slate-900">{transaction.title}</h4>
                  <p className="text-slate-600 text-xs leading-relaxed">{transaction.description}</p>
                </div>
              </div>

              {/* Specific Stock Attributes if applicable */}
              {(transaction.stockTicker || transaction.isPersonalStock || transaction.isBusinessStock) && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[11px]">
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Ticker</span>
                    <span className="font-bold text-slate-900">${transaction.stockTicker || 'SOV'}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Equity Type</span>
                    <span className={`font-bold ${transaction.isPersonalStock ? 'text-purple-700' : 'text-indigo-700'}`}>
                      {transaction.isPersonalStock ? 'Personal Stock' : 'Corporate Stock'}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Quantity</span>
                    <span className="font-bold text-slate-900">{transaction.shares ? `${transaction.shares} shares` : '1 Allocation'}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Price / Share</span>
                    <span className="font-bold text-slate-900">${transaction.unitPriceUSD?.toFixed(2) || 'N/A'}</span>
                  </div>
                </div>
              )}

              {/* Specific Loan Attributes if applicable */}
              {(transaction.category === 'loan' || transaction.type === 'loan_issued' || transaction.type === 'loan_received' || transaction.type === 'loan_repaid') && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 font-mono text-[11px]">
                  <div className="p-2 rounded-xl bg-teal-50/80 border border-teal-200">
                    <span className="text-[10px] text-teal-700 block uppercase font-bold">Credit Facility Type</span>
                    <span className="font-bold text-teal-900">
                      {transaction.type === 'loan_issued' ? 'Disbursed Loan (Lending)' : transaction.type === 'loan_repaid' ? 'Principal Repayment' : 'Credit Facility (Borrowing)'}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Denomination Asset</span>
                    <span className="font-bold text-slate-900">{transaction.paymentCoinSymbol || 'USD'}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Principal Value</span>
                    <span className="font-bold text-slate-900">${transaction.amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              )}

              {/* Specific Barter Trade Attributes if applicable */}
              {(transaction.category === 'barter' || transaction.type === 'barter_swap') && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 font-mono text-[11px]">
                  <div className="p-2 rounded-xl bg-amber-50/80 border border-amber-200">
                    <span className="text-[10px] text-amber-800 block uppercase font-bold">Settlement Method</span>
                    <span className="font-bold text-amber-950">Atomic Barter Swap</span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">IRS Form 1099-B</span>
                    <span className="font-bold text-slate-900">Reportable Barter Exchange</span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Fair Market Value</span>
                    <span className="font-bold text-slate-900">${transaction.amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              )}

              {/* Specific Product & Service Attributes if applicable */}
              {(transaction.category === 'product_service' || transaction.type === 'product_purchase' || transaction.type === 'service_payment' || transaction.type === 'marketplace_sale') && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 font-mono text-[11px]">
                  <div className="p-2 rounded-xl bg-cyan-50/80 border border-cyan-200">
                    <span className="text-[10px] text-cyan-800 block uppercase font-bold">Commercial Item Type</span>
                    <span className="font-bold text-cyan-950">
                      {transaction.type === 'service_payment' ? 'Professional Service' : transaction.type === 'marketplace_sale' ? 'Marketplace Sale' : 'Commercial Equipment'}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Accounting Classification</span>
                    <span className="font-bold text-slate-900">
                      {transaction.taxClassification.taxDeductible ? 'Schedule C Business Expense' : 'Gross Sales Revenue'}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-150">
                    <span className="text-[10px] text-slate-400 block uppercase">Invoiced Net</span>
                    <span className="font-bold text-slate-900">${transaction.amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-500 font-medium">Source / Settlement Channel</span>
                <span className="font-mono font-bold text-slate-900">{transaction.sourceOrDestination}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Counterparty / Issuer</span>
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  {transaction.isPersonalStock ? <User className="w-3.5 h-3.5 text-purple-600" /> : <Building2 className="w-3.5 h-3.5 text-slate-600" />}
                  {transaction.counterpartyOrIssuer}
                  {transaction.issuerHandle && (
                    <span className="text-slate-400 font-mono text-[10px] font-normal">{transaction.issuerHandle}</span>
                  )}
                </span>
              </div>
            </div>
          </div>

          {/* Realized Profit / Loss & Cost Basis Analysis (for Stock Transactions) */}
          {(transaction.type === 'stock_sell' || transaction.type === 'stock_buy' || transaction.realizedGainLossUSD !== undefined || transaction.costBasisUSD !== undefined) && (
            <div className={`p-4 rounded-2xl border space-y-3 ${
              transaction.realizedGainLossUSD !== undefined 
                ? (transaction.realizedGainLossUSD >= 0 ? 'bg-emerald-50/70 border-emerald-200' : 'bg-rose-50/70 border-rose-200')
                : 'bg-indigo-50/60 border-indigo-200'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {transaction.realizedGainLossUSD !== undefined ? (
                    transaction.realizedGainLossUSD >= 0 
                      ? <TrendingUp className="w-4 h-4 text-emerald-700" />
                      : <TrendingDown className="w-4 h-4 text-rose-700" />
                  ) : (
                    <Building2 className="w-4 h-4 text-indigo-700" />
                  )}
                  <span className={`font-serif text-xs font-bold uppercase tracking-wider ${
                    transaction.realizedGainLossUSD !== undefined 
                      ? (transaction.realizedGainLossUSD >= 0 ? 'text-emerald-950' : 'text-rose-950')
                      : 'text-indigo-950'
                  }`}>
                    {transaction.type === 'stock_sell' ? 'Realized Profit / Loss on Sale (IRS Form 8949)' : 'Capital Cost Basis & Position Detail'}
                  </span>
                </div>

                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                  transaction.isPersonalStock 
                    ? 'bg-purple-100/80 text-purple-900 border-purple-200' 
                    : 'bg-indigo-100/80 text-indigo-900 border-indigo-200'
                }`}>
                  {transaction.isPersonalStock ? 'Personal Human Capital' : 'Corporate Equity'}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
                {transaction.buyPriceUSD !== undefined && (
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/80">
                    <span className="text-[10px] text-slate-400 block uppercase font-sans">Buy Price / Sh</span>
                    <span className="font-bold text-slate-900">${transaction.buyPriceUSD.toFixed(2)}</span>
                  </div>
                )}

                <div className="p-2.5 rounded-xl bg-white border border-slate-200/80">
                  <span className="text-[10px] text-slate-400 block uppercase font-sans">
                    {transaction.type === 'stock_sell' ? 'Sale Price / Sh' : 'Acquisition Price'}
                  </span>
                  <span className="font-bold text-slate-900">${transaction.unitPriceUSD?.toFixed(2) || 'N/A'}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-white border border-slate-200/80">
                  <span className="text-[10px] text-slate-400 block uppercase font-sans">Total Cost Basis</span>
                  <span className="font-bold text-slate-900">
                    ${transaction.costBasisUSD ? transaction.costBasisUSD.toLocaleString(undefined, { minimumFractionDigits: 2 }) : `$${transaction.netAmountUSD.toFixed(2)}`}
                  </span>
                </div>

                {transaction.realizedGainLossUSD !== undefined ? (
                  <div className={`p-2.5 rounded-xl border ${
                    transaction.realizedGainLossUSD >= 0 
                      ? 'bg-emerald-100/60 border-emerald-300 text-emerald-950' 
                      : 'bg-rose-100/60 border-rose-300 text-rose-950'
                  }`}>
                    <span className="text-[10px] block uppercase font-sans font-bold">
                      {transaction.realizedGainLossUSD >= 0 ? 'Realized Profit' : 'Realized Loss'}
                    </span>
                    <span className="font-bold text-xs">
                      {transaction.realizedGainLossUSD >= 0 ? '+' : ''}${transaction.realizedGainLossUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      {transaction.realizedGainLossPercent !== undefined ? ` (${(transaction.realizedGainLossPercent >= 0 ? '+' : '') + transaction.realizedGainLossPercent.toFixed(1)}%)` : ''}
                    </span>
                  </div>
                ) : (
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200/80">
                    <span className="text-[10px] text-slate-400 block uppercase font-sans">Position Status</span>
                    <span className="font-bold text-indigo-900">Holding (Active)</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Financial Calculation Breakdown */}
          <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-2.5 font-mono">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Gross Transaction Amount</span>
              <span>${transaction.amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Clearing &amp; Network Fee (0.05%)</span>
              <span>${transaction.feeUSD.toFixed(2)}</span>
            </div>
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-sm font-bold">
              <span className="text-slate-200">Net Settled Total</span>
              <span className={`text-lg ${isPositive ? 'text-emerald-400' : 'text-white'}`}>
                {isPositive ? '+' : '-'}${transaction.netAmountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
              </span>
            </div>
            {transaction.paymentCoinSymbol && transaction.paymentCoinAmount && (
              <div className="text-[11px] text-amber-400 text-right font-normal">
                Equivalent: {transaction.paymentCoinAmount.toLocaleString()} ${transaction.paymentCoinSymbol}
              </div>
            )}
          </div>

          {/* Tax Classification Box */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-800" />
                <span className="font-bold text-amber-900">IRS / Tax Authority Classification</span>
              </div>
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-amber-200/80 text-amber-900 border border-amber-300">
                {transaction.taxClassification.formMapping}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-amber-800/80 block">Taxable Event:</span>
                <span className="font-bold text-slate-900">
                  {transaction.taxClassification.taxableEvent ? `YES ($${transaction.taxClassification.taxableAmountUSD.toFixed(2)})` : 'NO (Cost Basis Recorded)'}
                </span>
              </div>
              <div>
                <span className="text-amber-800/80 block">Holding Period:</span>
                <span className="font-bold text-slate-900">{transaction.taxClassification.holdingPeriod || 'N/A'}</span>
              </div>
            </div>

            <p className="text-[11px] text-amber-950/80 leading-relaxed pt-1 border-t border-amber-200/60">
              <strong>Audit Note:</strong> {transaction.taxClassification.irsCategoryNote}
            </p>
          </div>

          {/* Cryptographic Security Hash & Node */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
              <span className="flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-slate-400" />
                Cryptographic Proof Hash
              </span>
              <button
                type="button"
                onClick={handleCopyHash}
                className="text-amber-700 hover:text-amber-800 font-bold flex items-center gap-1 cursor-pointer"
              >
                {copiedHash ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copiedHash ? 'Copied' : 'Copy Hash'}</span>
              </button>
            </div>
            <div className="p-2 rounded-xl bg-white border border-slate-200 font-mono text-[10px] text-slate-600 break-all select-all">
              {transaction.cryptographicHash}
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>Node: {transaction.clearingNode}</span>
              <span>Sig: {transaction.signature}</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="py-2 px-4 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Print Tax Proof</span>
            </button>
            <button
              type="button"
              onClick={handleCopyHash}
              className="py-2 px-4 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <Copy className="w-3.5 h-3.5 text-slate-600" />
              <span>Copy Receipt Ref</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Close Receipt
          </button>
        </div>
      </div>
    </div>
  );
};
