import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { AssetClass, MarketplaceListing } from '../types';
import { 
  Plus, 
  Search, 
  Heart, 
  MessageSquare, 
  Repeat,
  Users,
  Package,
  Briefcase,
  Coins,
  Banknote,
  Binary,
  ArrowRight,
  Sparkles,
  TrendingUp,
  X,
  ChevronRight,
  Building2
} from 'lucide-react';
import { SEARCHABLE_PRODUCTS, SearchableProduct } from '../data/searchCatalog';
import { INITIAL_STOCKS } from '../data/stocksData';
import { StockItem } from '../types/stocks';
import { DEMO_ACCOUNTS } from '../services/firebaseAuth';
import { areUsersBlockedEitherWay } from '../services/socialService';
import { getAverageRating } from '../services/ratingService';
import { Star } from 'lucide-react';

interface MarketplaceViewProps {
  onOpenNewListing: () => void;
  onOpenBarterModal?: (listing: MarketplaceListing) => void;
  onSelectProduct?: (product: SearchableProduct) => void;
  onSelectUser?: (userIdOrHandle: string) => void;
  onSelectStock?: (stock: StockItem) => void;
  onQuickBuyStock?: (stock: StockItem) => void;
}

type SearchFilterType = 'all' | 'people' | 'products' | 'services' | 'barter' | 'fiat' | 'crypto';

interface DirectoryUser {
  id: string;
  name: string;
  role: string;
  avatarUrl: string;
  bio: string;
  reputationScore?: number;
  tradesCompleted?: number;
}

const DIRECTORY_USERS: DirectoryUser[] = [
  {
    id: 'jordan_belfort',
    name: 'Jordan Belfort',
    role: 'Escrow Lead & Vault Allocator',
    avatarUrl: DEMO_ACCOUNTS.jordan?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Founder & Chief Reserve Allocator. Overseeing $4.2B in tokenized reserve vaults and physical bullion settlement.',
    reputationScore: 99.8,
    tradesCompleted: 342,
  },
  {
    id: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    role: 'Sovereign Protocol Pioneer',
    avatarUrl: DEMO_ACCOUNTS.satoshi?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic cold storage.',
    reputationScore: 100.0,
    tradesCompleted: 890,
  },
  {
    id: 'alex_morgan',
    name: 'Alex Morgan',
    role: 'Institutional Commodity Arbiter',
    avatarUrl: DEMO_ACCOUNTS.alex?.avatarUrl || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Swiss Vault & Gold Bullion Reserve specialist. Zurich Freeport certified custodian and counter-trade broker.',
    reputationScore: 98.9,
    tradesCompleted: 215,
  },
  {
    id: 'elena_rostova',
    name: 'Elena Rostova',
    role: 'Smart Contract Auditor',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    bio: 'Senior Security Architect offering formal verification and bytecode audits in exchange for gold allocations or AFNL tokens.',
    reputationScore: 99.4,
    tradesCompleted: 180,
  },
  {
    id: 'marcus_vance',
    name: 'Marcus Vance',
    role: 'Geneva Horology & Luxury Custodian',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    bio: 'Curator of vintage Patek Philippe, Audemars Piguet, and investment-grade fine timepieces for bilateral barter.',
    reputationScore: 99.1,
    tradesCompleted: 140,
  },
];

export const MarketplaceView: React.FC<MarketplaceViewProps> = ({ 
  onOpenNewListing,
  onOpenBarterModal,
  onSelectProduct,
  onSelectUser,
  onSelectStock,
  onQuickBuyStock,
}) => {
  const { 
    listings = [], 
    currentUser, 
    toggleLikeListing, 
    startDirectConversation,
    setCurrentTab,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'my_listings'>('all');
  const [selectedCategory, setSelectedCategory] = useState<AssetClass | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilterType, setActiveFilterType] = useState<SearchFilterType>('all');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [showBanks, setShowBanks] = useState(false);
  const [bankSearchQuery, setBankSearchQuery] = useState('');

  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter stocks matching query
  const matchingStocks = INITIAL_STOCKS.filter((stock) => {
    if (!searchQuery.trim()) return false;
    const q = searchQuery.toLowerCase().trim().replace(/^\$/, '');
    return (
      stock.ticker.toLowerCase().includes(q) ||
      stock.name.toLowerCase().includes(q) ||
      stock.sector.toLowerCase().includes(q) ||
      (stock.subSector && stock.subSector.toLowerCase().includes(q))
    );
  });

  // Filter people matching query
  const currentViewerUid = currentUser ? (currentUser.id?.startsWith('user-') ? currentUser.id : `user-${currentUser.id}`) : '';
  const currentViewerHandle = currentUser?.handle?.replace(/^@/, '') || '';

  const matchingPeople = DIRECTORY_USERS.filter((user) => {
    if (!searchQuery.trim()) return false;
    const userUid = user.id.startsWith('user-') ? user.id : `user-${user.id}`;
    if (currentViewerUid && (areUsersBlockedEitherWay(currentViewerUid, userUid) || areUsersBlockedEitherWay(currentUser.id, user.id) || areUsersBlockedEitherWay(currentViewerHandle, user.id))) {
      return false;
    }
    const q = searchQuery.toLowerCase().trim();
    return (
      user.name.toLowerCase().includes(q) ||
      user.id.toLowerCase().includes(q) ||
      user.role.toLowerCase().includes(q) ||
      (user.bio && user.bio.toLowerCase().includes(q))
    );
  });

  // Filter products / reserve catalog matching query
  const matchingCatalogProducts = SEARCHABLE_PRODUCTS.filter((prod) => {
    if (!searchQuery.trim()) return false;
    const q = searchQuery.toLowerCase().trim();
    return (
      prod.name.toLowerCase().includes(q) ||
      prod.description.toLowerCase().includes(q) ||
      prod.category.toLowerCase().includes(q) ||
      prod.tags.some((t) => t.toLowerCase().includes(q))
    );
  });

  // Filter listings based on tab, category, search query, and filter type
  const filteredListings = listings.filter((item) => {
    // Exclude drafts completely from the public marketplace
    if (item.status === 'draft') return false;

    // Filter out items from blocked users
    const sellerUid = item.sellerId?.startsWith('user-') ? item.sellerId : `user-${item.sellerId}`;
    const sellerHandle = item.sellerHandle?.replace(/^@/, '') || '';
    if (currentViewerUid && (
      areUsersBlockedEitherWay(currentViewerUid, sellerUid) ||
      areUsersBlockedEitherWay(currentUser.id, item.sellerId) ||
      areUsersBlockedEitherWay(currentViewerHandle, sellerHandle)
    )) {
      return false;
    }

    // Tab filter
    if (activeTab === 'my_listings' && item.sellerId !== currentUser.id) return false;

    // Category filter
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;

    // Filter type
    if (activeFilterType === 'people') return false; // Handled in dedicated people section
    if (activeFilterType === 'products' && item.category !== 'barter' && item.category !== 'final_coins') return false;
    if (activeFilterType === 'services' && !item.title.toLowerCase().includes('service') && !item.description.toLowerCase().includes('hour') && !item.description.toLowerCase().includes('audit')) return false;
    if (activeFilterType === 'barter' && item.category !== 'barter') return false;
    if (activeFilterType === 'fiat' && item.category !== 'fiat') return false;
    if (activeFilterType === 'crypto' && item.category !== 'crypto' && item.category !== 'stable_coins' && item.category !== 'final_coins') return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return (
        (item.title && item.title.toLowerCase().includes(q)) ||
        (item.description && item.description.toLowerCase().includes(q)) ||
        (item.sellerName && item.sellerName.toLowerCase().includes(q)) ||
        (item.sellerHandle && item.sellerHandle.toLowerCase().includes(q)) ||
        (item.category && item.category.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const isCurrentUserBank = currentUser && localStorage.getItem(`ff_bank_app_status_${currentUser.id}`) === 'approved';

  const defaultBanks = [
    {
      id: 'demo-satoshi-nakamoto',
      name: 'Satoshi Nakamoto',
      handle: 'satoshi_nakamoto',
      avatarUrl: DEMO_ACCOUNTS.satoshi?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      role: 'Sovereign Protocol Pioneer',
      bankName: 'Neo Tokyo Trust',
      capacityUSD: '125,000,000 AFNL',
      bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic ledger consensus and decentralized consumer banking.',
    },
    {
      id: 'user-lord_sterling',
      name: 'Lord Sterling',
      handle: 'sterling_vault',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      role: 'Swiss Freeport Trustee',
      bankName: 'Swiss Sovereign Reserve',
      capacityUSD: '500,000,000 AFNL',
      bio: 'Sovereign Inter-Bank Clearing Node. Direct physical gold depository bullion backing, multi-signature trust structures.',
    },
    {
      id: 'demo-jordan-belfort',
      name: 'Jordan Belfort',
      handle: 'jordan_belfort',
      avatarUrl: DEMO_ACCOUNTS.jordan?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      role: 'Escrow Lead & Vault Allocator',
      bankName: 'Wall Street Liquidity Partners',
      capacityUSD: '250,000,000 AFNL',
      bio: 'Active reserve market-making vault and bilateral sovereign escrow authority. Specializing in high-velocity liquidity allocation.',
    },
    {
      id: 'demo-alex-morgan',
      name: 'Alex Morgan',
      handle: 'alex_morgan',
      avatarUrl: DEMO_ACCOUNTS.alex?.avatarUrl || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
      role: 'Institutional Commodity Desk Arbiter',
      bankName: 'Zurich Freeport Clearing',
      capacityUSD: '150,000,000 AFNL',
      bio: 'Precious metal clearing vault. Fully licensed and certified for gold bullion allocations, settlement audits, and sovereign clearing.',
    }
  ];

  const bankingCapacityUsers = [...defaultBanks];

  if (isCurrentUserBank) {
    bankingCapacityUsers.unshift({
      id: currentUser.id,
      name: currentUser.name || 'You (Sovereign Custodian)',
      handle: currentUser.handle || 'user',
      avatarUrl: currentUser.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
      role: 'Approved Clearing Bank',
      bankName: 'Your Sovereign Treasury Node',
      capacityUSD: '100,000,000 AFNL',
      bio: 'Your authorized Clearing Bank. Authorized by Protocol Admin to issue sovereign credit, provide AFNL loans, and process settlement clearances.',
    });
  }

  const filteredBankingCapacityUsers = bankingCapacityUsers.filter((user) => {
    if (!bankSearchQuery) return true;
    const q = bankSearchQuery.toLowerCase();
    return (
      user.name.toLowerCase().includes(q) ||
      user.handle.toLowerCase().includes(q) ||
      user.bankName.toLowerCase().includes(q) ||
      user.role.toLowerCase().includes(q) ||
      user.bio.toLowerCase().includes(q)
    );
  });

  const filterPills: { id: SearchFilterType; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'All Listings', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'people', label: 'People & Traders', icon: <Users className="w-3.5 h-3.5 text-blue-600" /> },
    { id: 'products', label: 'Products & Bullion', icon: <Package className="w-3.5 h-3.5 text-amber-600" /> },
    { id: 'services', label: 'Services & Capacity', icon: <Briefcase className="w-3.5 h-3.5 text-indigo-600" /> },
    { id: 'barter', label: 'Barter & Counter-Trade', icon: <Repeat className="w-3.5 h-3.5 text-amber-700" /> },
    { id: 'fiat', label: 'Fiat (USD / EUR / CHF)', icon: <Banknote className="w-3.5 h-3.5 text-sky-600" /> },
    { id: 'crypto', label: 'Crypto & Stablecoins', icon: <Binary className="w-3.5 h-3.5 text-purple-600" /> },
  ];

  const categories: { id: AssetClass | 'all'; label: string }[] = [
    { id: 'all', label: 'All Categories' },
    { id: 'barter', label: 'Physical Goods & Services' },
    { id: 'final_coins', label: 'Final Coins (AFNL)' },
    { id: 'stable_coins', label: 'Stablecoins' },
    { id: 'fiat', label: 'Fiat Reserves' },
    { id: 'crypto', label: 'Cryptocurrency' },
  ];

  return (
    <div className="space-y-6 pb-20 text-center">
      {/* ================= HERO SEARCH BAR (MOVED TO VERY TOP OF HOMEPAGE) ================= */}
      <div className="border border-slate-200 bg-white rounded-3xl p-5 sm:p-7 shadow-xs">
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="text-center">
            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight text-center">
              Marketplace
            </h1>
          </div>

          {/* Search Bar Input Container */}
          <div ref={searchContainerRef} className="relative w-full mx-auto">
            <div className="relative flex items-center justify-center">
              <Search className="absolute left-4 h-5 w-5 text-slate-400 pointer-events-none" />
              <input
                id="homepage-universal-search-input"
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchOpen(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIsSearchOpen(true);
                }}
                placeholder="Search people, products, services, or tickers ($HYPR)..."
                className="w-full pl-12 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm text-slate-900 placeholder:text-slate-400 text-center focus:outline-none focus:border-amber-500 focus:bg-white transition-all shadow-xs font-sans"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
                  title="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Instant Search Results Dropdown */}
            {isSearchOpen && searchQuery.trim().length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 overflow-hidden divide-y divide-slate-100 max-h-[70vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                {/* Stocks & Equities Results */}
                {matchingStocks.length > 0 && (
                  <div className="p-3 bg-slate-50/50">
                    <div className="flex items-center justify-between px-2 mb-1.5">
                      <span className="text-[10px] font-mono uppercase text-slate-700 font-bold flex items-center gap-1.5">
                        <TrendingUp className="w-3 h-3 text-emerald-600" />
                        Equities &amp; Stocks ({matchingStocks.length})
                      </span>
                      <span className="text-[10px] text-emerald-700 font-mono font-semibold">Live NYSE/NASDAQ</span>
                    </div>
                    <div className="space-y-1">
                      {matchingStocks.slice(0, 4).map((stock) => {
                        const isPos = stock.changeUSD >= 0;
                        return (
                          <div
                            key={stock.ticker}
                            onClick={() => {
                              setIsSearchOpen(false);
                              if (onSelectStock) {
                                onSelectStock(stock);
                              } else {
                                setCurrentTab('stocks');
                              }
                            }}
                            className="p-2.5 rounded-xl hover:bg-slate-100/80 flex items-center justify-between transition-all border border-transparent hover:border-slate-200 shadow-2xs group cursor-pointer"
                            title={`Open ${stock.name} (${stock.ticker}) page`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0 flex-1 text-left">
                              <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs shrink-0 group-hover:bg-amber-600 transition-colors">
                                {(stock.ticker || '').slice(0, 4)}
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-xs font-bold text-slate-900 font-mono">${stock.ticker}</span>
                                  <span className="text-[10px] text-slate-400 font-mono">• {stock.sector}</span>
                                </div>
                                <p className="text-[11px] text-slate-600 truncate">{stock.name}</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2.5 shrink-0">
                              <div className="text-right font-mono">
                                <span className="text-xs font-bold text-slate-900">${stock.price.toFixed(2)}</span>
                                <span className={`block text-[10px] font-bold ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                                  {isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%
                                </span>
                              </div>
                              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-all" />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* People Results */}
                {matchingPeople.length > 0 && (
                  <div className="p-3">
                    <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold px-2 block mb-1.5">
                      People &amp; Verified Traders ({matchingPeople.length})
                    </span>
                    <div className="space-y-1">
                      {matchingPeople.slice(0, 4).map((user) => (
                        <div
                          key={user.id}
                          onClick={() => {
                            setIsSearchOpen(false);
                            if (onSelectUser) {
                              onSelectUser(user.id);
                            }
                          }}
                          className="p-2 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            {user.avatarUrl ? (
                              <img
                                src={user.avatarUrl}
                                alt={user.name}
                                className="w-8 h-8 rounded-full object-cover border border-slate-200"
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold font-serif">
                                {user.name.charAt(0)}
                              </div>
                            )}
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 truncate">{user.name}</p>
                              <div className="flex items-center gap-2">
                                <p className="text-[11px] text-slate-500 font-mono truncate">@{user.id}</p>
                                {(() => {
                                  const avgRating = getAverageRating(user.id);
                                  return avgRating.count > 0 ? (
                                    <div className="flex items-center gap-1">
                                      <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                      <span className="text-[10px] font-bold text-slate-700">{avgRating.average}</span>
                                    </div>
                                  ) : null;
                                })()}
                              </div>
                            </div>
                          </div>
                          <span className="text-[11px] font-semibold text-amber-700 flex items-center gap-1">
                            <span>View Profile</span>
                            <ArrowRight className="w-3 h-3" />
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Catalog & Reserve Products Results */}
                {matchingCatalogProducts.length > 0 && (
                  <div className="p-3">
                    <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold px-2 block mb-1.5">
                      Depository Reserve Assets &amp; Services ({matchingCatalogProducts.length})
                    </span>
                    <div className="space-y-1">
                      {matchingCatalogProducts.slice(0, 4).map((prod) => (
                        <div
                          key={prod.id}
                          onClick={() => {
                            setIsSearchOpen(false);
                            if (onSelectProduct) {
                              onSelectProduct(prod);
                            }
                          }}
                          className="p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                        >
                          <div className="min-w-0 flex-1 pr-3">
                            <div className="flex items-center gap-2">
                              <p className="text-xs font-bold text-slate-900 truncate">{prod.name}</p>
                              {prod.badge && (
                                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                                  {prod.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 line-clamp-1">{prod.description}</p>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="font-mono text-xs font-bold text-amber-700">{prod.price}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Direct Marketplace Listings Matching */}
                {filteredListings.length > 0 && (
                  <div className="p-3">
                    <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold px-2 block mb-1.5">
                      Marketplace Listings ({filteredListings.length})
                    </span>
                    <div className="space-y-1">
                      {filteredListings.slice(0, 4).map((listing) => (
                        <div
                          key={listing.id}
                          onClick={() => {
                            setIsSearchOpen(false);
                            if (onOpenBarterModal) {
                              onOpenBarterModal(listing);
                            }
                          }}
                          className="p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0 flex-1 pr-3">
                            {listing.imageUrl && (
                              <img
                                src={listing.imageUrl}
                                alt={listing.title}
                                className="w-8 h-8 rounded-lg object-cover border border-slate-200 shrink-0"
                              />
                            )}
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 truncate">{listing.title}</p>
                              <div className="flex items-center gap-2">
                                <p className="text-[11px] text-slate-500 font-mono">by @{listing.sellerHandle}</p>
                                {(() => {
                                  const avgRating = getAverageRating(listing.sellerHandle || '');
                                  return avgRating.count > 0 ? (
                                    <div className="flex items-center gap-1">
                                      <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                      <span className="text-[10px] font-bold text-slate-700">{avgRating.average}</span>
                                    </div>
                                  ) : null;
                                })()}
                              </div>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="font-mono text-xs font-bold text-amber-700">
                              ${(listing.priceUSD || 0).toLocaleString()} USD
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {matchingPeople.length === 0 && matchingCatalogProducts.length === 0 && filteredListings.length === 0 && (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No matching people, products, services, or barter terms found for "{searchQuery}".
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ================= PEOPLE DIRECTORY (WHEN 'PEOPLE' IS FILTERED) ================= */}
      {activeFilterType === 'people' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                SOVEREIGN DIRECTORY
              </span>
              <h2 className="font-serif text-xl font-bold text-slate-900 mt-1">
                People &amp; Certified Traders
              </h2>
            </div>
            <span className="text-xs text-slate-500 font-mono">
              {DIRECTORY_USERS.length} Members
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {DIRECTORY_USERS.map((user) => (
              <div
                key={user.id}
                className="border border-slate-200 bg-white rounded-2xl p-4 flex flex-col justify-between hover:border-slate-300 transition-all shadow-xs"
              >
                <div className="flex items-start gap-3">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      className="w-12 h-12 rounded-full object-cover border border-slate-200"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center text-base font-serif font-bold">
                      {user.name.charAt(0)}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-semibold text-sm text-slate-900 truncate">{user.name}</h3>
                      {(() => {
                        const avgRating = getAverageRating(user.id);
                        return avgRating.count > 0 ? (
                          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-amber-50 border border-amber-100">
                            <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                            <span className="text-[10px] font-bold text-amber-800">{avgRating.average}</span>
                          </div>
                        ) : null;
                      })()}
                    </div>
                    <p className="text-xs font-mono text-slate-500">@{user.id}</p>
                    <p className="text-[11px] font-medium text-amber-800 mt-0.5">{user.role}</p>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2">{user.bio}</p>
                  </div>
                </div>

                <div className="pt-3 mt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onSelectUser && onSelectUser(user.id)}
                    className="flex-1 py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-semibold transition-colors cursor-pointer text-center"
                  >
                    View Profile
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      startDirectConversation(user.id);
                      setCurrentTab('messages');
                    }}
                    className="py-1.5 px-3 rounded-xl bg-amber-500 text-slate-950 hover:bg-amber-400 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>OTC Desk</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= MARKETPLACE LISTINGS & CATEGORY CONTROLS ================= */}
      {activeFilterType !== 'people' && (
        <div className="space-y-6">
          {/* Header & Sub-Tabs */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-slate-900">
                Marketplace &amp; Barter Exchange
              </h2>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <div className="flex items-center rounded-xl bg-slate-100 p-1 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab('all')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    activeTab === 'all'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All Listings
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('my_listings')}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    activeTab === 'my_listings'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  My Listings ({listings.filter((l) => l.sellerId === currentUser?.id && l.status !== 'draft').length})
                </button>
              </div>

              <button
                type="button"
                onClick={() => setShowBanks(!showBanks)}
                className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition-colors shadow-xs cursor-pointer ${
                  showBanks
                    ? 'bg-indigo-600 text-white hover:bg-indigo-500'
                    : 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                }`}
              >
                <Building2 className="h-4 w-4" />
                <span>Internal Bank</span>
              </button>
            </div>
          </div>


          {showBanks ? (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="p-6 rounded-3xl bg-indigo-50/50 border border-indigo-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="font-serif text-lg font-bold text-slate-900 mt-2">
                    Sovereign Clearing Banks &amp; Providers
                  </h3>
                </div>
                <div className="px-4 py-2 bg-indigo-50 border border-indigo-100 rounded-xl self-start md:self-auto shrink-0">
                  <span className="text-xs font-bold text-indigo-700">Clearing Partners: {bankingCapacityUsers.length}</span>
                </div>
              </div>

              {/* Banks Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={bankSearchQuery}
                  onChange={(e) => setBankSearchQuery(e.target.value)}
                  placeholder="Search clearing banks by node name, owner @handle, capacity, or role..."
                  className="w-full pl-10 pr-10 py-2.5 text-xs rounded-2xl border border-slate-200 bg-white text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400/30 transition-all"
                />
                {bankSearchQuery && (
                  <button
                    onClick={() => setBankSearchQuery('')}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                    title="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {filteredBankingCapacityUsers.length === 0 ? (
                <div className="border border-dashed border-slate-300 rounded-3xl p-12 text-center bg-white">
                  <Building2 className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <h3 className="font-serif text-base font-bold text-slate-800">No Banks Found</h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                    No authorized clearing nodes match "{bankSearchQuery}". Try looking up by other names, capacities or roles.
                  </p>
                  <button
                    type="button"
                    onClick={() => setBankSearchQuery('')}
                    className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Clear Search
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {filteredBankingCapacityUsers.map((user) => (
                    <div
                      key={user.id}
                      className="border-2 border-indigo-100/80 bg-white rounded-3xl p-5 flex flex-col justify-between hover:border-indigo-300 hover:shadow-md transition-all text-left"
                    >
                      <div>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            {user.avatarUrl ? (
                              <img src={user.avatarUrl} alt={user.name} className="w-12 h-12 rounded-full object-cover border border-slate-200 shrink-0 animate-fade-in" referrerPolicy="no-referrer" />
                            ) : (
                              <div className="w-12 h-12 rounded-full bg-slate-950 text-white flex items-center justify-center text-lg font-serif font-bold shrink-0">
                                {user.name.charAt(0)}
                              </div>
                            )}
                            <div className="min-w-0">
                              <h3 className="font-bold text-sm text-slate-900 truncate">{user.name}</h3>
                              <p className="text-xs text-slate-500 font-mono">@{user.handle}</p>
                            </div>
                          </div>
                          <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 uppercase shrink-0">
                            LICENSED
                          </span>
                        </div>

                        <div className="mt-4 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-slate-500 font-mono">Clearing Node:</span>
                            <span className="font-bold text-slate-900 font-serif truncate max-w-[150px]">{user.bankName}</span>
                          </div>
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-slate-500 font-mono">Reserve Capacity:</span>
                            <span className="font-mono font-bold text-indigo-700">{user.capacityUSD}</span>
                          </div>
                        </div>

                        <p className="text-xs text-slate-600 mt-4 line-clamp-3 leading-relaxed">
                          {user.bio}
                        </p>
                      </div>

                      <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onSelectUser && onSelectUser(user.id)}
                          className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-semibold transition-colors cursor-pointer text-center"
                        >
                          View Profile
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <>
              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {categories.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                        isSelected
                          ? 'bg-amber-50 text-amber-900 border border-amber-300 shadow-xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {cat.label}
                    </button>
                  );
                })}
              </div>

              {/* Listings Grid */}
              {filteredListings.length === 0 ? (
                <div className="border border-dashed border-slate-300 rounded-3xl p-12 text-center bg-white">
                  <Package className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <h3 className="font-serif text-base font-bold text-slate-800">No Listings Match Your Search</h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                    Try refining your keyword query or clear category filters to view available reserve inventory.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                      setActiveFilterType('all');
                    }}
                    className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {filteredListings.map((item) => {
                    return (
                      <div
                        key={item.id}
                        className="border border-slate-200 bg-white rounded-3xl p-5 flex flex-col justify-between hover:border-slate-300 hover:shadow-sm transition-all text-left"
                      >
                        <div>
                          {/* Image Preview */}
                          <div className="h-48 rounded-2xl bg-slate-100 overflow-hidden mb-4 relative">
                            {item.imageUrl ? (
                              <img
                                src={item.imageUrl}
                                alt={item.title}
                                className="h-full w-full object-cover hover:scale-105 transition-transform duration-300"
                              />
                            ) : (
                              <div className="h-full w-full flex items-center justify-center text-slate-400 text-xs">
                                No image available
                              </div>
                            )}
                            <span className="absolute top-3 left-3 text-[10px] font-mono uppercase px-2.5 py-1 rounded-full bg-slate-900/80 text-white backdrop-blur-xs font-semibold">
                              {item.category.replace('_', ' ')}
                            </span>
                          </div>

                          {/* Seller Tag */}
                          <div className="flex items-center justify-between text-xs text-slate-500 font-mono pb-2">
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => onSelectUser && onSelectUser(item.sellerId)}
                                className="hover:text-amber-800 transition-colors font-medium cursor-pointer"
                              >
                                @{item.sellerHandle || 'merchant'}
                              </button>
                              {(() => {
                                const avgRating = getAverageRating(item.sellerHandle || '');
                                return avgRating.count > 0 ? (
                                  <div className="flex items-center gap-1">
                                    <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                    <span className="text-[10px] font-bold text-slate-700">{avgRating.average}</span>
                                  </div>
                                ) : null;
                              })()}
                            </div>
                            <span className="text-[11px] text-slate-400">
                              Zurich Depository
                            </span>
                          </div>

                          {/* Title & Description */}
                          <h3 className="font-serif text-base font-bold text-slate-900 mt-1 line-clamp-1">
                            {item.title}
                          </h3>
                          <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                            {item.description}
                          </p>

                          {/* Payment & Barter Accepted Badge */}
                          <div className="mt-3 p-2 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-[11px] font-mono">
                            <span className="text-slate-500">Settlement:</span>
                            <span className="font-semibold text-slate-800">
                              USD &bull; AFNL &bull; Crypto &bull; Barter
                            </span>
                          </div>
                        </div>

                        {/* Bottom Pricing & Actions */}
                        <div className="pt-4 mt-4 border-t border-slate-100">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <span className="text-[10px] font-mono text-slate-500 uppercase block">Valuation</span>
                              <span className="font-mono text-base font-bold text-amber-700">
                                ${(item.priceUSD || 0).toLocaleString()} USD
                              </span>
                            </div>

                            {/* Likes counter */}
                            <button
                              type="button"
                              onClick={() => toggleLikeListing(item.id)}
                              className="flex items-center gap-1 text-xs text-slate-500 hover:text-red-500 transition-colors cursor-pointer"
                            >
                              <Heart className="w-4 h-4 text-slate-400" />
                              <span>{(item as any).likesCount ?? item.likes ?? 0}</span>
                            </button>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => onOpenBarterModal && onOpenBarterModal(item)}
                              className="flex-1 py-2 px-3 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold hover:bg-amber-400 transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <Repeat className="h-3.5 w-3.5" />
                              <span>Propose Barter</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                startDirectConversation(item.sellerId);
                                setCurrentTab('messages');
                              }}
                              className="p-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
                              title="Message Trader"
                            >
                              <MessageSquare className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};
