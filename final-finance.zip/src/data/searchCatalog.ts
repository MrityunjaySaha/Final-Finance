export interface SearchableProduct {
  id: string;
  name: string;
  category: string;
  price: string;
  description: string;
  iconName: string;
  badge?: string;
  features: string[];
  tags: string[];
}

export const SEARCHABLE_PRODUCTS: SearchableProduct[] = [
  {
    id: 'prod-1',
    name: '100oz Imperial Gold Bullion (999.9)',
    category: 'Reserve Barter Assets',
    price: '$288,000 USD / 14,400 AFNL',
    description: 'Physically allocated 100oz fine gold ingot in Zurich Freeport with dual cryptographic RFID audit seal.',
    iconName: 'Coins',
    badge: 'VAULT 1',
    features: ['LBMA 99.99% Certified', 'Swiss Freeport Escrow', '1:1 Instant Barter Redeemable'],
    tags: ['gold', 'bullion', 'barter', 'zurich', 'commodity', 'vault1']
  },
  {
    id: 'prod-2',
    name: 'Final Coin Sovereign Staking Tranche',
    category: 'Algorithmic Yield',
    price: '20.00 USD / AFNL',
    description: 'Native treasury coin providing 12.8% APY base yield and protocol governance voting rights.',
    iconName: 'TrendingUp',
    badge: 'YIELD 12.8%',
    features: ['Auto-compounding rewards', 'Governance voting weight', 'Zero-slippage swap fee'],
    tags: ['fnl', 'staking', 'yield', 'finalcoins', 'treasury', 'vault2']
  },
  {
    id: 'prod-3',
    name: 'Institutional USDC / EURS Liquidity Corridor',
    category: 'Stable Coins',
    price: '1.00 USD Parity',
    description: 'Over-collateralized stable assets backed 1:1 by monthly Deloitte attestations with instant cross-currency conversion.',
    iconName: 'Lock',
    badge: 'AUDITED AAA',
    features: ['Monthly Deloitte Attestation', 'Instant multi-network clearance', 'Sub-second finality'],
    tags: ['usdc', 'eurs', 'stablecoin', 'parity', 'deloitte', 'vault3']
  },
  {
    id: 'prod-4',
    name: 'Swiss Franc (CHF) Sovereign RTGS Rail',
    category: 'Fiat Currency',
    price: '1.15 USD / CHF',
    description: 'Direct central bank master account cash deposits facilitating high-velocity institutional wire clearance.',
    iconName: 'CreditCard',
    badge: 'FEDWIRE / SIC',
    features: ['Direct SWIFT / SIC clearance', 'Zero FX markup on wholesale lots', 'JPMorgan & UBS custody'],
    tags: ['fiat', 'chf', 'usd', 'bankwire', 'sovereign', 'vault4']
  },
  {
    id: 'prod-5',
    name: 'Bitcoin Air-Gapped Glacier Vault (BTC)',
    category: 'Cryptocurrency',
    price: '$94,800 USD / BTC',
    description: 'Deep cold-storage multi-sig custody located in sub-surface Swiss alpine military bunker with $500M Lloyd’s indemnity.',
    iconName: 'BarChart3',
    badge: 'COLD MPC',
    features: ['Alpine sub-surface custody', 'MPC Multi-Party Computation', 'Insurance coverage by Lloyd’s'],
    tags: ['btc', 'crypto', 'bitcoin', 'coldstorage', 'vault5']
  },
  {
    id: 'prod-6',
    name: 'Smart Contract & Blockchain Security Audit',
    category: 'Professional Services',
    price: '$15,000 USD / 750 AFNL',
    description: 'Comprehensive static analysis, symbolic execution, and formal verification by senior security researchers.',
    iconName: 'Calculator',
    badge: 'SERVICE',
    features: ['Formal verification report', 'Zero-day vulnerability testing', '2-3 Business day turnaround'],
    tags: ['audit', 'security', 'service', 'smartcontract', 'barter']
  }
];
