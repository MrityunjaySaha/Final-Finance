import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useApp, NavTab, NotificationType } from '../context/AppContext';
import { 
  Plus, 
  Bell,
  BellRing,
  BellOff,
  Check,
  CheckCheck,
  Clock,
  ExternalLink,
  Trash2,
  Volume2,
  VolumeX,
  TrendingUp,
  Wallet,
  Landmark,
  ShoppingBag,
  MessageSquare,
  Users,
  Award,
  Rocket,
  Zap,
  Sparkles,
  X,
  Radio,
  ShieldAlert,
  UserPlus,
  UserCheck,
  Car,
  Package,
  Store
} from 'lucide-react';
import { UserDropdown } from './UserDropdown';
import { SearchableProduct } from '../data/searchCatalog';
import { AuthSession } from '../types/auth';
import { FriendRequest } from '../types/social';
import {
  getFriendRequestsReceived,
  getFriendRequestsSent,
  acceptFriendRequest,
  declineFriendRequest,
  cancelFriendRequest,
} from '../services/socialService';
import { requestBrowserNotificationPermission, getBrowserNotificationPermission } from '../utils/notificationService';

interface HeaderProps {
  currentUserSession: AuthSession | null;
  onOpenNewListing: () => void;
  onOpenProfile: () => void;
  onOpenAuthModal: () => void;
  onSelectProduct: (product: SearchableProduct) => void;
  onSelectUser: (userIdOrHandle: string) => void;
  onSelectStock?: (stock: any) => void;
  onQuickBuyStock?: (stock: any) => void;
  onOpenFullSearch?: (query: string) => void;
  onSignOut: () => void;
  onOpenInstantSwap?: () => void;
  onUpdateSession?: (user: AuthSession) => void;
  onOpenVerificationModal?: () => void;
  onNavigateFromDropdown?: (view: NavTab) => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  currentUserSession,
  onOpenNewListing, 
  onOpenProfile,
  onOpenAuthModal,
  onSelectUser,
  onSignOut,
  onOpenVerificationModal,
  onNavigateFromDropdown,
}) => {
  const { 
    currentTab, 
    setCurrentTab,
    notifications,
    deleteNotification,
    clearAllNotifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    notificationPrefs,
    updateNotificationPrefs,
    triggerTestNotification,
    setPreviousTab,
  } = useApp();

  // Helper for dropdown navigation
  const handleDropdownNavigate = (view: NavTab) => {
    if (onNavigateFromDropdown) {
      onNavigateFromDropdown(view);
      return;
    }
    if (view === 'portfolio') {
      setPreviousTab(null);
    } else {
      setPreviousTab(currentTab);
    }
    setCurrentTab(view);
  };

  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'unread' | 'stocks_trades' | 'finance' | 'ride_share' | 'social' | 'system'>('all');
  const [browserPermission, setBrowserPermission] = useState<NotificationPermission>('default');
  const [pendingReceivedRequests, setPendingReceivedRequests] = useState<FriendRequest[]>([]);
  const [pendingSentRequests, setPendingSentRequests] = useState<FriendRequest[]>([]);
  const [friendActionBusyId, setFriendActionBusyId] = useState<string | null>(null);

  const notificationsRef = useRef<HTMLDivElement>(null);

  const loadHeaderFriendRequests = async () => {
    const activeId = currentUserSession?.uid || currentUserSession?.id;
    if (!activeId) {
      setPendingReceivedRequests([]);
      setPendingSentRequests([]);
      return;
    }
    try {
      const [rcv, sent] = await Promise.all([
        getFriendRequestsReceived(activeId),
        getFriendRequestsSent(activeId),
      ]);
      setPendingReceivedRequests(rcv);
      setPendingSentRequests(sent);
    } catch (e) {
      console.warn('Error loading header friend requests:', e);
    }
  };

  useEffect(() => {
    setBrowserPermission(getBrowserNotificationPermission());
    loadHeaderFriendRequests();
  }, [isNotificationsOpen, currentUserSession?.uid, currentUserSession?.id]);

  useEffect(() => {
    const refresh = () => loadHeaderFriendRequests();
    window.addEventListener('final_finance_friends_updated', refresh);
    window.addEventListener('final_finance_block_updated', refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener('final_finance_friends_updated', refresh);
      window.removeEventListener('final_finance_block_updated', refresh);
      window.removeEventListener('storage', refresh);
    };
  }, [currentUserSession?.uid, currentUserSession?.id]);

  // Close notifications dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notificationsRef.current && !notificationsRef.current.contains(e.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const receivedSenderKeys = useMemo(
    () => new Set(pendingReceivedRequests.map((r) => (r.senderHandle || r.senderUid).toLowerCase())),
    [pendingReceivedRequests]
  );

  // Deduplicate static queued 'New Friend Request' cards when the live interactive card is shown
  const dedupedNotifications = useMemo(() => {
    return notifications.filter((n) => {
      if (
        n.title === '🤝 New Friend Request' &&
        n.targetId &&
        receivedSenderKeys.has(n.targetId.toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [notifications, receivedSenderKeys]);

  const unreadCount =
    dedupedNotifications.filter((n) => !n.read).length + pendingReceivedRequests.length;

  const handleRequestPush = async () => {
    const perm = await requestBrowserNotificationPermission();
    setBrowserPermission(perm);
  };

  const filteredNotifications = useMemo(() => {
    return dedupedNotifications.filter((n) => {
      if (selectedFilter === 'unread') return !n.read;
      if (selectedFilter === 'stocks_trades') return n.type === 'stocks' || n.type === 'trade' || n.type === 'marketplace' || n.type === 'pos';
      if (selectedFilter === 'finance') return n.type === 'wallet' || n.type === 'vault' || n.type === 'loans' || n.type === 'subsidies';
      if (selectedFilter === 'ride_share') return n.type === 'ride_share' || n.type === 'delivery';
      if (selectedFilter === 'social') return n.type === 'chat' || n.type === 'social';
      if (selectedFilter === 'system') return n.type === 'security' || n.type === 'system' || n.type === 'fundraising' || n.type === 'feedback';
      return true;
    });
  }, [dedupedNotifications, selectedFilter]);

  const showFriendRequestsInFilter =
    selectedFilter === 'all' || selectedFilter === 'unread' || selectedFilter === 'social';
  const showSentRequestsInFilter =
    selectedFilter === 'all' || selectedFilter === 'social';

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'stocks':
        return <TrendingUp className="w-4 h-4 text-emerald-600" />;
      case 'trade':
        return <Sparkles className="w-4 h-4 text-amber-600" />;
      case 'vault':
        return <Landmark className="w-4 h-4 text-amber-700" />;
      case 'wallet':
        return <Wallet className="w-4 h-4 text-sky-600" />;
      case 'marketplace':
        return <ShoppingBag className="w-4 h-4 text-purple-600" />;
      case 'pos':
        return <Store className="w-4 h-4 text-indigo-600" />;
      case 'ride_share':
        return <Car className="w-4 h-4 text-emerald-600" />;
      case 'delivery':
        return <Package className="w-4 h-4 text-amber-600" />;
      case 'social':
        return <Users className="w-4 h-4 text-pink-600" />;
      case 'chat':
        return <MessageSquare className="w-4 h-4 text-indigo-600" />;
      case 'subsidies':
        return <Award className="w-4 h-4 text-teal-600" />;
      case 'fundraising':
        return <Rocket className="w-4 h-4 text-orange-600" />;
      case 'security':
        return <ShieldAlert className="w-4 h-4 text-rose-600" />;
      case 'loans':
        return <Landmark className="w-4 h-4 text-emerald-600" />;
      case 'feedback':
        return <MessageSquare className="w-4 h-4 text-indigo-500" />;
      default:
        return <Zap className="w-4 h-4 text-slate-600" />;
    }
  };

  if (currentTab === 'landing' && !currentUserSession) {
    return null;
  }

  return (
    <header 
      className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur-md"
      style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
    >
      {/* Top Single Row Contract with Centered Title (non-overlapping on narrow mobile, centered on sm+) */}
      <div className="relative mx-auto flex h-16 max-w-7xl items-center justify-between gap-2 px-3 sm:px-6 lg:px-8">
        
        {/* Left Side: User Dropdown Menu */}
        <div className="flex items-center gap-2 sm:gap-3 z-10 shrink-0 min-w-0">
          {currentUserSession && (
            <UserDropdown 
              currentUser={currentUserSession}
              onNavigate={handleDropdownNavigate as any}
              onViewMyProfile={onOpenProfile}
              onOpenAuthModal={onOpenAuthModal}
              onSignOut={onSignOut}
              onOpenVerificationModal={onOpenVerificationModal}
            />
          )}
        </div>

        {/* Center: FINAL FINANCE Title (hidden on the welcome page) */}
        {currentTab !== 'landing' && (
          <div className="min-w-0 flex-1 flex justify-center sm:flex-none sm:block sm:absolute sm:left-1/2 sm:top-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 z-10">
            <button 
              type="button"
              onClick={() => {
                if (currentUserSession) {
                  setCurrentTab('marketplace');
                } else {
                  setCurrentTab('landing');
                }
              }}
              className="flex items-center justify-center group focus:outline-none cursor-pointer min-w-0"
              title="Final Finance - Home"
            >
              <span className="font-serif text-base sm:text-xl font-bold tracking-wider text-slate-900 group-hover:text-amber-700 transition-colors whitespace-nowrap truncate">
                FINAL FINANCE
              </span>
            </button>
          </div>
        )}

        {/* Right Side: Notification Bell & Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 z-10 shrink-0">
          {currentUserSession ? (
            <>
              {/* Icon 1: Notification Bell Dropdown */}
              <div ref={notificationsRef} className="relative inline-block text-left">
                <button
                  type="button"
                  onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                  className={`relative h-9 w-9 flex items-center justify-center rounded-xl border transition-all cursor-pointer shadow-xs ${
                    isNotificationsOpen 
                      ? 'border-amber-400 bg-amber-50 text-amber-900 ring-2 ring-amber-400/20' 
                      : 'border-slate-200 bg-white hover:bg-slate-100 text-slate-700 hover:text-slate-900 active:scale-95'
                  }`}
                  aria-label="Notifications"
                  title="Notifications & Live Alerts"
                >
                  {unreadCount > 0 ? (
                    <BellRing className="h-4 w-4 text-amber-600 animate-pulse" />
                  ) : (
                    <Bell className="h-4 w-4" />
                  )}
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-slate-950 shadow-xs ring-2 ring-white">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Popover */}
                {isNotificationsOpen && (
                  <div className="fixed sm:absolute left-3 right-3 sm:left-auto sm:right-0 top-16 sm:top-full mt-2 w-auto sm:w-104 max-w-md mx-auto bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden z-50 text-left divide-y divide-slate-100 animate-in fade-in zoom-in-95 duration-150">
                    
                    {/* Header Bar */}
                    <div className="px-4 py-3 bg-slate-50/80 flex items-center justify-between gap-2 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <div className="p-1 rounded-lg bg-amber-500/10 text-amber-700">
                          <Bell className="w-3.5 h-3.5" />
                        </div>
                        <h3 className="font-bold text-xs text-slate-900">Notifications</h3>
                        {unreadCount > 0 ? (
                          <span className="inline-flex flex-col items-center justify-center text-center leading-tight px-2.5 py-0.5 rounded-xl bg-amber-500 text-slate-950 shadow-xs shrink-0">
                            <span className="text-[11px] font-extrabold">{unreadCount}</span>
                            <span className="text-[9px] font-bold">unread</span>
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400 font-medium text-center">All caught up</span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5">
                        {/* Audio Chime Toggle */}
                        <button
                          type="button"
                          onClick={() => updateNotificationPrefs({ soundEnabled: !notificationPrefs.soundEnabled })}
                          title={notificationPrefs.soundEnabled ? 'Mute Notification Chimes' : 'Enable Notification Chimes'}
                          className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                            notificationPrefs.soundEnabled
                              ? 'bg-amber-100/70 border-amber-200 text-amber-900'
                              : 'bg-slate-100 border-slate-200 text-slate-400'
                          }`}
                        >
                          {notificationPrefs.soundEnabled ? (
                            <Volume2 className="w-3 h-3" />
                          ) : (
                            <VolumeX className="w-3 h-3" />
                          )}
                        </button>

                        {/* Mark All Read */}
                        {unreadCount > 0 && (
                          <button
                            type="button"
                            onClick={markAllNotificationsAsRead}
                            className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-[11px] font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                            title="Mark all notifications as read"
                          >
                            <CheckCheck className="w-3 h-3 text-emerald-600" />
                            <span>Read All</span>
                          </button>
                        )}

                        {/* Clear All */}
                        {notifications.length > 0 && (
                          <button
                            type="button"
                            onClick={clearAllNotifications}
                            className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Clear all notifications"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Filter Pills */}
                    <div className="px-3 py-2 bg-white flex items-center gap-1 overflow-x-auto no-scrollbar text-[11px] font-medium border-b border-slate-100">
                      {[
                        { id: 'all', label: 'All' },
                        { id: 'unread', label: `Unread (${unreadCount})` },
                        { id: 'stocks_trades', label: '📈 Trading & POS' },
                        { id: 'ride_share', label: '🚗 Ride-Share' },
                        { id: 'finance', label: '💳 Wallets' },
                        { id: 'social', label: '💬 Social' },
                        { id: 'system', label: '🛡️ System' },
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setSelectedFilter(tab.id as any)}
                          className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                            selectedFilter === tab.id
                              ? 'bg-slate-900 text-white font-bold'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    {/* Desktop Push Banner prompt if not enabled */}
                    {browserPermission !== 'granted' && (
                      <div className="px-3.5 py-2 bg-amber-50/70 border-b border-amber-100 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Radio className="w-3.5 h-3.5 text-amber-700 shrink-0 animate-pulse" />
                          <span className="text-[11px] text-amber-950 font-medium truncate">
                            Enable desktop push alerts for instant trade fills
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleRequestPush}
                          className="px-2.5 py-0.5 rounded-md bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-bold shrink-0 cursor-pointer shadow-2xs transition-colors"
                        >
                          Allow Push
                        </button>
                      </div>
                    )}

                    {/* Notifications List */}
                    <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                      {/* Live Incoming Friend Requests (Require Mutual Acceptance) */}
                      {showFriendRequestsInFilter && pendingReceivedRequests.map((req) => (
                        <div
                          key={`freq-in-${req.id}`}
                          className="p-3.5 bg-amber-50/40 hover:bg-amber-50/70 transition-colors flex items-start gap-3"
                        >
                          <button
                            type="button"
                            onClick={() => {
                              setIsNotificationsOpen(false);
                              onSelectUser(req.senderHandle || req.senderUid);
                            }}
                            className="mt-0.5 shrink-0 cursor-pointer"
                            title={`View @${req.senderHandle}`}
                          >
                            {req.senderAvatarUrl ? (
                              <img
                                src={req.senderAvatarUrl}
                                alt={req.senderName}
                                className="w-9 h-9 rounded-full object-cover border border-amber-200"
                              />
                            ) : (
                              <div className="w-9 h-9 rounded-full bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center">
                                {(req.senderName || 'U').charAt(0).toUpperCase()}
                              </div>
                            )}
                          </button>

                          <div className="min-w-0 flex-1 space-y-2">
                            <div
                              onClick={() => {
                                setIsNotificationsOpen(false);
                                onSelectUser(req.senderHandle || req.senderUid);
                              }}
                              className="cursor-pointer"
                            >
                              <div className="flex items-center justify-between gap-1">
                                <p className="text-xs font-bold text-slate-950 truncate flex items-center gap-1">
                                  <UserPlus className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                  <span>Friend Request</span>
                                </p>
                                <span className="text-[10px] font-mono text-amber-700 font-semibold shrink-0">
                                  Action Needed
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-700 mt-0.5 leading-relaxed">
                                <span className="font-semibold">{req.senderName}</span> (@{req.senderHandle}) sent you a friend request. Both sides must accept to become friends.
                              </p>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                disabled={friendActionBusyId === req.id}
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  if (!currentUserSession) return;
                                  setFriendActionBusyId(req.id);
                                  try {
                                    await acceptFriendRequest(currentUserSession, {
                                      uid: req.senderUid,
                                      userId: req.senderHandle,
                                      name: req.senderName,
                                      avatarUrl: req.senderAvatarUrl,
                                    });
                                    await loadHeaderFriendRequests();
                                  } finally {
                                    setFriendActionBusyId(null);
                                  }
                                }}
                                className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                              >
                                <UserCheck className="w-3 h-3" />
                                <span>Accept</span>
                              </button>
                              <button
                                type="button"
                                disabled={friendActionBusyId === req.id}
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  if (!currentUserSession) return;
                                  setFriendActionBusyId(req.id);
                                  try {
                                    await declineFriendRequest(currentUserSession.uid || currentUserSession.id, req.senderUid);
                                    await loadHeaderFriendRequests();
                                  } finally {
                                    setFriendActionBusyId(null);
                                  }
                                }}
                                className="px-3 py-1 rounded-lg bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-slate-700 hover:text-rose-700 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer transition-colors"
                              >
                                <X className="w-3 h-3" />
                                <span>Decline</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}

                      {/* Live Pending Outgoing Friend Requests */}
                      {showSentRequestsInFilter && pendingSentRequests.map((req) => (
                        <div
                          key={`freq-out-${req.id}`}
                          className="p-3 bg-slate-50/70 hover:bg-slate-50 transition-colors flex items-center justify-between gap-2.5"
                        >
                          <div
                            onClick={() => {
                              setIsNotificationsOpen(false);
                              onSelectUser(req.receiverHandle || req.receiverUid);
                            }}
                            className="flex items-center gap-2.5 min-w-0 cursor-pointer flex-1"
                          >
                            <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 shrink-0">
                              <Clock className="w-3.5 h-3.5" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 truncate">
                                Friend Request Sent to {req.receiverName}
                              </p>
                              <p className="text-[11px] text-slate-500 truncate">
                                @{req.receiverHandle} • Awaiting their acceptance
                              </p>
                            </div>
                          </div>
                          <button
                            type="button"
                            disabled={friendActionBusyId === req.id}
                            onClick={async (e) => {
                              e.stopPropagation();
                              if (!currentUserSession) return;
                              setFriendActionBusyId(req.id);
                              try {
                                await cancelFriendRequest(currentUserSession.uid || currentUserSession.id, req.receiverUid);
                                await loadHeaderFriendRequests();
                              } finally {
                                setFriendActionBusyId(null);
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 text-[10px] font-semibold text-slate-600 cursor-pointer shrink-0"
                          >
                            Cancel
                          </button>
                        </div>
                      ))}

                      {filteredNotifications.length === 0 &&
                      (!showFriendRequestsInFilter || pendingReceivedRequests.length === 0) &&
                      (!showSentRequestsInFilter || pendingSentRequests.length === 0) ? (
                        <div className="p-8 text-center space-y-2">
                          <div className="w-10 h-10 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400">
                            <BellOff className="w-5 h-5" />
                          </div>
                          <p className="text-xs font-semibold text-slate-800">No notifications in this filter</p>
                          <p className="text-[11px] text-slate-500">
                            You will receive instant alerts for friend requests, trades, transfers, and community updates.
                          </p>
                          <button
                            type="button"
                            onClick={() => triggerTestNotification('stocks')}
                            className="mt-2 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                            <span>Send Test Alert</span>
                          </button>
                        </div>
                      ) : (
                        filteredNotifications.map((n, idx) => (
                          <div
                            key={`${n.id}-${idx}`}
                            className={`p-3.5 transition-colors flex items-start gap-3 hover:bg-slate-50 group cursor-pointer relative ${
                              !n.read ? 'bg-amber-50/30' : ''
                            }`}
                            onClick={() => {
                              markNotificationAsRead(n.id);
                              if (n.targetTab) {
                                setIsNotificationsOpen(false);
                                if (n.targetTab === 'listing_detail' && n.targetId) {
                                  window.dispatchEvent(new CustomEvent('open_shared_listing', { detail: n.targetId }));
                                } else if (n.targetTab === 'marketplace' && n.targetId && (n.targetId.startsWith('mkt-') || n.targetId.startsWith('lst-') || n.targetId.startsWith('listing'))) {
                                  window.dispatchEvent(new CustomEvent('open_shared_listing', { detail: n.targetId }));
                                } else if (n.targetTab === 'stocks' && n.targetId) {
                                  window.dispatchEvent(new CustomEvent('open_shared_stock', { detail: n.targetId }));
                                } else if (n.targetTab === 'user_profile' && n.targetId) {
                                  onSelectUser(n.targetId);
                                } else if (n.targetTab === 'messages' && n.targetId) {
                                  window.dispatchEvent(new CustomEvent('open_direct_conversation', { detail: n.targetId }));
                                  setCurrentTab('messages');
                                } else if (n.targetTab === 'dash_ledger') {
                                  try { sessionStorage.setItem('final_finance_open_ledger_tab', '1'); } catch {}
                                  setCurrentTab('dashboard');
                                  window.dispatchEvent(new CustomEvent('final_finance_open_ledger_tab'));
                                } else if (n.targetTab === 'loans') {
                                  setCurrentTab('subsidies');
                                } else if (n.targetTab === 'feedback') {
                                  setCurrentTab('settings');
                                } else if (n.targetTab === 'superadmin' && n.targetId === 'grants_subsidies') {
                                  try { sessionStorage.setItem('final_finance_open_superadmin_grants', '1'); } catch {}
                                  setCurrentTab('superadmin');
                                  window.dispatchEvent(new CustomEvent('final_finance_open_superadmin_grants'));
                                } else {
                                  setCurrentTab(n.targetTab as any);
                                }
                              }
                            }}
                          >
                            <div className="mt-0.5 p-2 rounded-xl bg-slate-100 group-hover:bg-white group-hover:shadow-xs text-slate-700 shrink-0 transition-all border border-slate-200/50">
                              {getNotificationIcon(n.type)}
                            </div>

                            <div className="min-w-0 flex-1 pr-6">
                              <div className="flex items-center justify-between gap-1">
                                <p className={`text-xs font-bold truncate ${!n.read ? 'text-slate-950' : 'text-slate-800'}`}>
                                  {n.title}
                                </p>
                                <span className="text-[10px] text-slate-400 shrink-0 flex items-center gap-0.5">
                                  <Clock className="w-2.5 h-2.5" />
                                  {n.time}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed line-clamp-2">
                                {n.description}
                              </p>
                              {n.targetTab && (
                                <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-semibold text-amber-800 hover:underline">
                                  <span>View in {n.targetTab.replace(/_/g, ' ').toUpperCase()}</span>
                                  <ExternalLink className="w-2.5 h-2.5" />
                                </span>
                              )}
                            </div>

                            {/* Delete single notification button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteNotification(n.id);
                              }}
                              className="absolute right-2.5 top-3 p-1 rounded-md text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                              title="Delete notification"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>

                            {/* Unread indicator dot */}
                            {!n.read && (
                              <span className="absolute right-3 top-4 w-2 h-2 rounded-full bg-amber-500 ring-2 ring-white group-hover:hidden" />
                            )}
                          </div>
                        ))
                      )}
                    </div>

                    {/* Footer Quick Links & Live Simulator */}
                    <div className="p-2.5 bg-slate-50 flex items-center justify-between gap-2 px-3.5 border-t border-slate-100">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            const categories: NotificationType[] = ['stocks', 'trade', 'vault', 'wallet', 'pos', 'ride_share', 'delivery', 'chat', 'subsidies', 'loans'];
                            const randomCat = categories[Math.floor(Math.random() * categories.length)];
                            triggerTestNotification(randomCat);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-[11px] font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-100 inline-flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                          title="Generate a real-time notification to test delivery"
                        >
                          <Sparkles className="w-3 h-3 text-amber-500" />
                          <span>Test Alert</span>
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setIsNotificationsOpen(false);
                          setCurrentTab('settings');
                        }}
                        className="text-[11px] font-bold text-slate-700 hover:text-slate-900 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <span>Alert Preferences</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Icon 2: '+' Upload Button, cleanly aligned in the top right corner */}
              <button
                type="button"
                onClick={onOpenNewListing}
                className="h-9 w-9 flex items-center justify-center rounded-xl border border-amber-300 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 transition-all shadow-xs cursor-pointer"
                aria-label="Upload Asset"
                title="Upload Asset"
              >
                <Plus className="h-4 w-4 stroke-[2.5]" />
              </button>
            </>
          ) : null}
        </div>
      </div>
    </header>
  );
};
