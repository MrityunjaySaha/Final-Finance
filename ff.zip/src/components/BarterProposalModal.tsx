import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Repeat,
  Package,
  Briefcase,
  Coins,
  Check,
  Sparkles,
  Send,
  ShieldCheck,
  Banknote,
  Binary,
  AlertCircle,
  Lock,
  ArrowRightLeft,
  Wallet
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { UserWalletData } from '../types/wallet';
import { getStoredUserWallets } from '../data/defaultWallets';
import { ConfirmModal } from './common/ConfirmModal';
import { useApp } from '../context/AppContext';
import { AssetClass } from '../types';
import { enqueueUserNotification } from '../services/socialService';
import {
  CurrencyTypeId,
  CURRENCY_TYPE_META,
  SettlementCoinOption,
  TargetListingForTrade,
  executeBarterListingDeal,
  executeCurrencyListingDeal,
  getAllowedSettlementModes,
  getCurrencyOptionsForType,
  getListingValuationUSD,
} from '../services/marketplaceSettlementService';

interface BarterProposalModalProps {
  isOpen: boolean;
  currentUser?: AuthSession | null;
  targetListing?: TargetListingForTrade | null;
  onClose: () => void;
  onProposalSent?: (proposal: any) => void;
}

const CURRENCY_TYPES_ORDER: CurrencyTypeId[] = ['final_coins', 'stable_coins', 'fiat', 'crypto'];

export const BarterProposalModal: React.FC<BarterProposalModalProps> = ({
  isOpen,
  currentUser,
  targetListing,
  onClose,
  onProposalSent,
}) => {
  const { addToast, addNotification, setListings, setCurrentUser, addTransaction } = useApp();
  const activeUserId = currentUser?.id || 'guest';

  const [userWallets, setUserWallets] = useState<UserWalletData>(() =>
    getStoredUserWallets(activeUserId)
  );

  useEffect(() => {
    setUserWallets(getStoredUserWallets(activeUserId));
  }, [activeUserId, isOpen, targetListing?.id]);

  const allowedModes = useMemo(
    () => getAllowedSettlementModes(targetListing),
    [targetListing]
  );

  const allowedCurrencyTypes = useMemo(
    () => CURRENCY_TYPES_ORDER.filter((ct) => allowedModes.includes(ct)),
    [allowedModes]
  );

  const acceptsBarter = allowedModes.includes('barter');
  const acceptsAnyCurrency = allowedCurrencyTypes.length > 0;
  const valuationUSD = getListingValuationUSD(targetListing);
  const isBuyIntent = targetListing?.listingIntent === 'buy';

  // Determine default currency type from listing preference
  const pickInitialCurrencyType = (): CurrencyTypeId => {
    if (allowedCurrencyTypes.length === 0) return 'final_coins';
    const prim = (targetListing?.primaryCurrency || '').toUpperCase();
    if (prim === 'AFNL' && allowedCurrencyTypes.includes('final_coins')) return 'final_coins';
    if (['USDC', 'USDT', 'PAXG', 'EURC', 'EURS'].includes(prim) && allowedCurrencyTypes.includes('stable_coins')) {
      return 'stable_coins';
    }
    if (['USD', 'EUR', 'GBP', 'CHF'].includes(prim) && allowedCurrencyTypes.includes('fiat')) return 'fiat';
    if (['BTC', 'ETH', 'SOL'].includes(prim) && allowedCurrencyTypes.includes('crypto')) return 'crypto';
    return allowedCurrencyTypes[0];
  };

  // Modal main tab: 'currency' | 'barter' | 'portfolio'
  const [activeModalTab, setActiveModalTab] = useState<'currency' | 'barter' | 'portfolio'>(() => {
    if (!targetListing) return 'portfolio';
    if (targetListing.primaryTradeMode === 'barter' && !acceptsAnyCurrency) return 'barter';
    return acceptsAnyCurrency ? 'currency' : 'barter';
  });

  const [selectedCurrencyType, setSelectedCurrencyType] = useState<CurrencyTypeId>(pickInitialCurrencyType);
  const [selectedCoinSymbol, setSelectedCoinSymbol] = useState<string>('');

  // Barter state
  const [offeringType, setOfferingType] = useState<'inventory' | 'custom'>('inventory');
  const [inventoryKind, setInventoryKind] = useState<'good' | 'service'>('good');
  const [selectedGoodId, setSelectedGoodId] = useState<string>(userWallets.barterGoods[0]?.id || '');
  const [selectedServiceId, setSelectedServiceId] = useState<string>(userWallets.barterServices[0]?.id || '');
  const [offeredUnits, setOfferedUnits] = useState<number>(1);
  const [customOfferText, setCustomOfferText] = useState('');

  // Balancing sweetener across ANY of the 4 currency types
  const [includeSweetener, setIncludeSweetener] = useState(false);
  const [sweetenerCurrencyType, setSweetenerCurrencyType] = useState<CurrencyTypeId>('final_coins');
  const [sweetenerCoinSymbol, setSweetenerCoinSymbol] = useState<string>('AFNL');
  const [sweetenerAmountUSD, setSweetenerAmountUSD] = useState<number>(500);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [confirmMode, setConfirmMode] = useState<'currency' | 'barter'>('currency');

  // Reset modal state cleanly whenever listing changes
  useEffect(() => {
    if (!isOpen) return;
    setErrorMsg(null);
    setIsSuccess(false);
    setIsSubmitting(false);
    setShowConfirm(false);
    const freshWallets = getStoredUserWallets(activeUserId);
    setUserWallets(freshWallets);
    setSelectedGoodId(freshWallets.barterGoods[0]?.id || '');
    setSelectedServiceId(freshWallets.barterServices[0]?.id || '');
    setOfferedUnits(1);
    setCustomOfferText('');
    setIncludeSweetener(false);

    if (!targetListing) {
      setActiveModalTab('portfolio');
      return;
    }

    const nextCurrencyType = pickInitialCurrencyType();
    setSelectedCurrencyType(nextCurrencyType);
    if (allowedCurrencyTypes.length > 0 && !(targetListing.primaryTradeMode === 'barter' && !acceptsAnyCurrency)) {
      setActiveModalTab('currency');
    } else if (acceptsBarter) {
      setActiveModalTab('barter');
    } else {
      setActiveModalTab('portfolio');
    }
  }, [isOpen, targetListing?.id, activeUserId]);

  // Available coin options for selected currency type (Tab 1)
  const currencyCoinOptions = useMemo<SettlementCoinOption[]>(() => {
    if (!targetListing) return [];
    return getCurrencyOptionsForType(activeUserId, targetListing, selectedCurrencyType);
  }, [activeUserId, targetListing, selectedCurrencyType, userWallets]);

  useEffect(() => {
    if (currencyCoinOptions.length === 0) {
      setSelectedCoinSymbol('');
      return;
    }
    const stillExists = currencyCoinOptions.some((c) => c.symbol === selectedCoinSymbol);
    if (!stillExists) {
      const best =
        currencyCoinOptions.find((c) => c.isSellerPreferred && c.hasSufficientBalance) ||
        currencyCoinOptions.find((c) => c.isSellerPreferred) ||
        currencyCoinOptions.find((c) => c.hasSufficientBalance) ||
        currencyCoinOptions[0];
      setSelectedCoinSymbol(best.symbol);
    }
  }, [currencyCoinOptions, selectedCoinSymbol]);

  const activeCoinOption = useMemo(
    () => currencyCoinOptions.find((c) => c.symbol === selectedCoinSymbol) || currencyCoinOptions[0] || null,
    [currencyCoinOptions, selectedCoinSymbol]
  );

  // Available coin options for balancing sweetener (Tab 2)
  const sweetenerCoinOptions = useMemo<SettlementCoinOption[]>(() => {
    return getCurrencyOptionsForType(
      activeUserId,
      targetListing || null,
      sweetenerCurrencyType,
      Math.max(1, sweetenerAmountUSD || 0)
    );
  }, [activeUserId, targetListing, sweetenerCurrencyType, sweetenerAmountUSD, userWallets]);

  useEffect(() => {
    if (sweetenerCoinOptions.length === 0) return;
    if (!sweetenerCoinOptions.some((c) => c.symbol === sweetenerCoinSymbol)) {
      const funded = sweetenerCoinOptions.find((c) => c.hasSufficientBalance) || sweetenerCoinOptions[0];
      setSweetenerCoinSymbol(funded.symbol);
    }
  }, [sweetenerCoinOptions, sweetenerCoinSymbol]);

  const activeSweetenerCoin = useMemo(
    () => sweetenerCoinOptions.find((c) => c.symbol === sweetenerCoinSymbol) || sweetenerCoinOptions[0] || null,
    [sweetenerCoinOptions, sweetenerCoinSymbol]
  );

  if (!isOpen) return null;

  const selectedGood = userWallets.barterGoods.find((g) => g.id === selectedGoodId);
  const selectedService = userWallets.barterServices.find((s) => s.id === selectedServiceId);

  const handleOpenConfirmCurrency = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!currentUser || activeUserId === 'guest') {
      setErrorMsg('Please sign in first to execute a marketplace transaction.');
      return;
    }
    if (!targetListing || !activeCoinOption) {
      setErrorMsg('Please select a valid currency and coin to execute this deal.');
      return;
    }
    if (!allowedCurrencyTypes.includes(selectedCurrencyType)) {
      setErrorMsg(`${CURRENCY_TYPE_META[selectedCurrencyType].label} is not accepted on this listing.`);
      return;
    }
    if (!isBuyIntent && !activeCoinOption.hasSufficientBalance) {
      setErrorMsg(
        `Insufficient ${activeCoinOption.symbol} balance. Need ${activeCoinOption.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} ${activeCoinOption.symbol}, available ${activeCoinOption.totalAvailableUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} ${activeCoinOption.symbol}.`
      );
      return;
    }
    setConfirmMode('currency');
    setShowConfirm(true);
  };

  const handleOpenConfirmBarter = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!currentUser || activeUserId === 'guest') {
      setErrorMsg('Please sign in first to execute a barter trade.');
      return;
    }
    if (!acceptsBarter) {
      setErrorMsg('The seller does not accept barter trades for this listing.');
      return;
    }
    if (offeringType === 'inventory') {
      if (inventoryKind === 'good' && !selectedGood) {
        setErrorMsg('Select a physical asset from your reserves or switch to Custom Barter Offer.');
        return;
      }
      if (inventoryKind === 'service' && !selectedService) {
        setErrorMsg('Select a service retainer from your reserves or switch to Custom Barter Offer.');
        return;
      }
    } else if (!customOfferText.trim()) {
      setErrorMsg('Please enter your custom barter offer details.');
      return;
    }
    if (includeSweetener && sweetenerAmountUSD > 0 && activeSweetenerCoin && !activeSweetenerCoin.hasSufficientBalance) {
      setErrorMsg(
        `Insufficient ${activeSweetenerCoin.symbol} balance for sweetener (${activeSweetenerCoin.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeSweetenerCoin.decimals })} ${activeSweetenerCoin.symbol} needed).`
      );
      return;
    }
    setConfirmMode('barter');
    setShowConfirm(true);
  };

  const syncContextAfterDeal = (
    dealType: 'currency' | 'barter',
    amountUSD: number,
    vaultKey: AssetClass,
    ledgerItem: any,
    markedSold?: boolean,
    remainingQty?: number
  ) => {
    // Sync listing state in AppContext
    if (targetListing) {
      setListings((prev) =>
        prev.map((item) => {
          if (item.id !== targetListing.id) return item;
          if (markedSold) {
            return { ...item, status: 'sold', quantity: 0 };
          }
          if (typeof remainingQty === 'number' && typeof item.quantity === 'number') {
            return { ...item, quantity: remainingQty };
          }
          return item;
        })
      );
    }

    // Sync holdings in AppContext
    setCurrentUser((prev) => {
      const nextHoldings = { ...prev.holdings };
      if (dealType === 'currency') {
        if (!isBuyIntent) {
          nextHoldings[vaultKey] = Math.max(0, (nextHoldings[vaultKey] || 0) - amountUSD);
          const targetCat = (targetListing?.category || 'barter') as AssetClass;
          if (targetCat in nextHoldings) {
            nextHoldings[targetCat] = (nextHoldings[targetCat] || 0) + amountUSD;
          } else {
            nextHoldings.barter = (nextHoldings.barter || 0) + amountUSD;
          }
        } else {
          nextHoldings[vaultKey] = (nextHoldings[vaultKey] || 0) + amountUSD;
        }
      }
      return {
        ...prev,
        holdings: nextHoldings,
      };
    });

    if (ledgerItem) {
      addTransaction({
        taxYear: ledgerItem.taxYear || new Date().getFullYear(),
        type: ledgerItem.type,
        category: ledgerItem.category,
        mode: ledgerItem.mode,
        title: ledgerItem.title,
        description: ledgerItem.description,
        amountUSD: ledgerItem.amountUSD,
        feeUSD: ledgerItem.feeUSD || 0,
        netAmountUSD: ledgerItem.netAmountUSD,
        sourceOrDestination: ledgerItem.sourceOrDestination,
        counterpartyOrIssuer: ledgerItem.counterpartyOrIssuer,
        issuerHandle: ledgerItem.issuerHandle,
        status: 'Settled',
        clearingNode: ledgerItem.clearingNode,
        taxClassification: ledgerItem.taxClassification,
      });
    }
  };

  const processExecution = () => {
    if (!targetListing) return;
    setShowConfirm(false);
    setErrorMsg(null);
    setIsSubmitting(true);

    if (confirmMode === 'currency' && activeCoinOption) {
      const res = executeCurrencyListingDeal({
        buyerId: activeUserId,
        buyerName: currentUser?.name || 'Member',
        buyerHandle: currentUser?.id,
        listing: targetListing,
        coinOption: activeCoinOption,
      });

      if (!res.success) {
        setIsSubmitting(false);
        setErrorMsg(res.error || 'Transaction could not be executed.');
        addToast({
          title: 'Settlement Failed',
          message: res.error || 'Unable to execute transaction.',
          type: 'error',
        });
        return;
      }

      setUserWallets(getStoredUserWallets(activeUserId));
      syncContextAfterDeal(
        'currency',
        res.amountUSD,
        activeCoinOption.currencyType as AssetClass,
        res.ledgerItem,
        res.markedSold,
        res.remainingQuantity
      );

      addToast({
        title: isBuyIntent ? 'Order Fulfilled & Settled' : 'Purchase Executed',
        message: `${isBuyIntent ? 'Received' : 'Paid'} ${res.paidUnits?.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} ${res.coinSymbol} ($${res.amountUSD.toLocaleString()} USD) for "${targetListing.title}".`,
        type: 'gold',
      });

      addNotification({
        title: isBuyIntent ? `Deal Fulfilled in ${res.coinSymbol}` : `Acquired "${targetListing.title}"`,
        description: `${res.paidUnits?.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} ${res.coinSymbol} ($${res.amountUSD.toLocaleString()} USD) settled via ${CURRENCY_TYPE_META[activeCoinOption.currencyType].label}.`,
        type: 'trade',
        targetTab: 'listing_detail',
        targetId: targetListing.id,
        amount: res.amountUSD,
        currency: res.coinSymbol,
      });

      const sellerTargets = [targetListing.sellerId, targetListing.sellerHandle || ''].filter(
        (id) => id && id !== activeUserId
      );
      if (sellerTargets.length > 0) {
        enqueueUserNotification(sellerTargets, {
          title: isBuyIntent ? `🛍️ Buy Request Fulfilled: "${targetListing.title}"` : `💰 Listing Sold: "${targetListing.title}"`,
          description: `${currentUser?.name || 'A member'} settled ${res.paidUnits?.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} ${res.coinSymbol} ($${res.amountUSD.toLocaleString()} USD).`,
          type: 'marketplace',
          targetTab: 'listing_detail',
          targetId: targetListing.id,
          amount: res.amountUSD,
          currency: res.coinSymbol,
        });
      }

      setTimeout(() => {
        setIsSubmitting(false);
        setIsSuccess(true);
        if (onProposalSent) onProposalSent(res);
        setTimeout(() => {
          setIsSuccess(false);
          onClose();
        }, 1400);
      }, 650);
      return;
    }

    // Barter execution
    const res = executeBarterListingDeal({
      buyerId: activeUserId,
      buyerName: currentUser?.name || 'Member',
      listing: targetListing,
      offeringType,
      inventoryKind,
      selectedGoodId,
      selectedServiceId,
      offeredUnits,
      customOfferText,
      sweetenerCoin: includeSweetener && sweetenerAmountUSD > 0 ? activeSweetenerCoin : null,
      sweetenerAmountUSD: includeSweetener ? sweetenerAmountUSD : 0,
    });

    if (!res.success) {
      setIsSubmitting(false);
      setErrorMsg(res.error || 'Barter transaction could not be executed.');
      addToast({
        title: 'Barter Execution Failed',
        message: res.error || 'Unable to submit barter trade.',
        type: 'error',
      });
      return;
    }

    setUserWallets(getStoredUserWallets(activeUserId));
    syncContextAfterDeal('barter', res.amountUSD, 'barter', res.ledgerItem, false);

    addToast({
      title: 'Barter Trade Executed & Logged',
      message: `Formal barter deal for "${targetListing.title}" recorded in Universal Ledger.`,
      type: 'gold',
    });

    addNotification({
      title: 'Barter Trade Dispatched',
      description: `Barter offer for "${targetListing.title}" ($${res.amountUSD.toLocaleString()} USD eq.) recorded.`,
      type: 'trade',
      targetTab: 'listing_detail',
      targetId: targetListing.id,
      amount: res.amountUSD,
      currency: res.coinSymbol || 'USD',
    });

    const barterSellerTargets = [targetListing.sellerId, targetListing.sellerHandle || ''].filter(
      (id) => id && id !== activeUserId
    );
    if (barterSellerTargets.length > 0) {
      enqueueUserNotification(barterSellerTargets, {
        title: `🤝 New Barter Trade: "${targetListing.title}"`,
        description: `${currentUser?.name || 'A member'} executed a barter exchange worth ~$${res.amountUSD.toLocaleString()} USD.`,
        type: 'trade',
        targetTab: 'listing_detail',
        targetId: targetListing.id,
        amount: res.amountUSD,
        currency: res.coinSymbol || 'USD',
      });
    }

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      if (onProposalSent) onProposalSent(res);
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
      }, 1400);
    }, 650);
  };

  // Portfolio Totals
  const goodsTotalUSD = userWallets.barterGoods.reduce((sum, g) => sum + g.quantity * g.estimatedUnitValue, 0);
  const servicesTotalUSD = userWallets.barterServices.reduce((sum, s) => sum + s.availableUnits * s.hourlyRateValue, 0);
  const finalCoinsTotalUSD = userWallets.finalCoins.reduce(
    (sum, c) => sum + c.balance * (c.unitPriceUSD > 0 ? c.unitPriceUSD : c.symbol === 'AFNL' ? 20 : 0),
    0
  );
  const stableCoinsTotalUSD = userWallets.stableCoins.reduce((sum, s) => sum + s.balance * s.unitPriceUSD, 0);
  const fiatTotalUSD = userWallets.fiatCurrencies.reduce((sum, f) => sum + f.balance * f.exchangeRateToUSD, 0);
  const cryptoTotalUSD = userWallets.cryptoCurrencies.reduce((sum, c) => sum + c.balance * c.unitPriceUSD, 0);

  const currencyTypeIcon = (ct: CurrencyTypeId) => {
    if (ct === 'final_coins') return <Sparkles className="w-4 h-4" />;
    if (ct === 'stable_coins') return <ShieldCheck className="w-4 h-4" />;
    if (ct === 'fiat') return <Banknote className="w-4 h-4" />;
    return <Binary className="w-4 h-4" />;
  };

  return (
    <div
      id="barter-proposal-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl text-left text-slate-900 my-auto max-h-[92vh] flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-amber-300 bg-amber-50 text-amber-800">
              <ArrowRightLeft className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg sm:text-xl font-bold text-slate-900 tracking-wide">
                {targetListing ? 'Trade, Buy & Barter Settlement' : 'Asset Vault & Settlement'}
              </h2>
              <p className="text-xs text-slate-500">
                Settle with Final Coins, Stablecoins, Fiat, Cryptocurrency, or Peer Barter.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Target Listing Summary Banner */}
        {targetListing && (
          <div className="mt-3 p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[10px] font-mono uppercase text-slate-500 font-semibold">
                {isBuyIntent ? 'Wanted / Buyer Request' : 'Listing Settlement Target'}
              </p>
              <h4 className="text-sm font-bold text-slate-900 truncate">{targetListing.title}</h4>
              <p className="text-xs text-slate-500">
                Counterparty: <span className="font-semibold text-slate-800">{targetListing.sellerName}</span>
                {targetListing.status === 'sold' && (
                  <span className="ml-2 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                    SETTLED / SOLD
                  </span>
                )}
              </p>
            </div>
            {valuationUSD > 0 && (
              <div className="text-right shrink-0">
                <p className="text-[10px] text-slate-500 uppercase font-mono">Valuation</p>
                <p className="text-sm font-black font-mono text-amber-700">${valuationUSD.toLocaleString()} USD</p>
              </div>
            )}
          </div>
        )}

        {/* Modal Main Tab Switcher */}
        <div className={`mt-3 grid ${targetListing ? 'grid-cols-3' : 'grid-cols-2'} gap-1.5 p-1 bg-slate-100 rounded-2xl border border-slate-200`}>
          {targetListing && (
            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setActiveModalTab('currency');
              }}
              className={`py-2 px-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeModalTab === 'currency'
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span className="truncate">{isBuyIntent ? 'Settle Currency' : 'Buy with Currency'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              setErrorMsg(null);
              setActiveModalTab('barter');
            }}
            className={`py-2 px-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeModalTab === 'barter'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Repeat className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="truncate">Propose Barter</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setErrorMsg(null);
              setActiveModalTab('portfolio');
            }}
            className={`py-2 px-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeModalTab === 'portfolio'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Wallet className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="truncate">My Asset Vault</span>
          </button>
        </div>

        {/* Error Banner */}
        {errorMsg && (
          <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* TAB 1: BUY / SETTLE WITH ANY OF THE 4 ALLOWED CURRENCY TYPES & COINS */}
        {activeModalTab === 'currency' && targetListing && (
          <form onSubmit={handleOpenConfirmCurrency} className="mt-4 flex-1 overflow-y-auto space-y-4 pr-1">
            {!acceptsAnyCurrency ? (
              <div className="p-6 rounded-2xl bg-amber-50 border border-amber-200 text-center space-y-2">
                <Repeat className="w-7 h-7 text-amber-700 mx-auto" />
                <p className="text-sm font-bold text-slate-900">Barter-Only Listing</p>
                <p className="text-xs text-slate-600">
                  The seller only accepts peer barter / counter-trade for this item. Switch to the Propose Barter tab to execute a trade.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveModalTab('barter')}
                  className="mt-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Go to Propose Barter
                </button>
              </div>
            ) : (
              <>
                {/* Step 1: Choose Currency Type (4 Currency Types) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800">
                      1. Select Currency Type
                    </label>
                    <span className="text-[11px] font-mono text-slate-500">
                      {allowedCurrencyTypes.length} of 4 types accepted by seller
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {CURRENCY_TYPES_ORDER.map((ct) => {
                      const isAllowed = allowedModes.includes(ct);
                      const isSelected = selectedCurrencyType === ct;
                      const meta = CURRENCY_TYPE_META[ct];
                      return (
                        <button
                          key={ct}
                          type="button"
                          disabled={!isAllowed}
                          onClick={() => {
                            setErrorMsg(null);
                            setSelectedCurrencyType(ct);
                          }}
                          className={`p-2.5 rounded-2xl border text-left transition-all relative ${
                            !isAllowed
                              ? 'bg-slate-50 border-slate-200 text-slate-400 opacity-60 cursor-not-allowed'
                              : isSelected
                              ? 'bg-amber-50 border-amber-500 text-slate-950 ring-2 ring-amber-400/30 shadow-xs cursor-pointer'
                              : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-50 cursor-pointer'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className={isSelected ? 'text-amber-700' : isAllowed ? 'text-slate-600' : 'text-slate-400'}>
                              {currencyTypeIcon(ct)}
                            </span>
                            {!isAllowed ? (
                              <Lock className="w-3 h-3 text-slate-400" />
                            ) : isSelected ? (
                              <Check className="w-3.5 h-3.5 text-amber-700" />
                            ) : null}
                          </div>
                          <p className="text-xs font-bold leading-tight">{meta.shortLabel}</p>
                          <p className="text-[10px] font-mono mt-0.5 text-slate-500">
                            {isAllowed ? 'Accepted' : 'Not Accepted'}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Step 2: Select Particular Coin or Currency */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800">
                      2. Select Coin / Currency ({CURRENCY_TYPE_META[selectedCurrencyType].label})
                    </label>
                    <span className="text-[11px] font-mono text-slate-500">
                      {currencyCoinOptions.length} options
                    </span>
                  </div>

                  {currencyCoinOptions.length === 0 ? (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 text-center">
                      No coins available in this category.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {currencyCoinOptions.map((opt) => {
                        const isChosen = activeCoinOption?.symbol === opt.symbol;
                        return (
                          <button
                            key={opt.symbol}
                            type="button"
                            onClick={() => {
                              setErrorMsg(null);
                              setSelectedCoinSymbol(opt.symbol);
                            }}
                            className={`w-full p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between gap-3 ${
                              isChosen
                                ? 'border-amber-500 bg-amber-50/70 ring-1 ring-amber-400/50 shadow-2xs'
                                : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-mono font-bold text-xs text-slate-900">{opt.symbol}</span>
                                <span className="text-xs text-slate-700 truncate">{opt.name}</span>
                                {opt.isSellerPreferred && (
                                  <span className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                                    Seller Listed
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-slate-500 mt-0.5 truncate">
                                Available: <span className="font-mono font-semibold text-slate-700">
                                  {opt.totalAvailableUnits.toLocaleString(undefined, { maximumFractionDigits: opt.decimals })} {opt.symbol}
                                </span>
                                {opt.linkedBankBalanceUnits > 0 && opt.linkedBankName && (
                                  <span className="text-slate-400"> (incl. {opt.linkedBankName})</span>
                                )}
                              </p>
                            </div>

                            <div className="text-right shrink-0">
                              <p className="font-mono text-xs font-bold text-slate-900">
                                {opt.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: opt.decimals })} {opt.symbol}
                              </p>
                              <span
                                className={`inline-block text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full mt-0.5 ${
                                  isBuyIntent || opt.hasSufficientBalance
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                                }`}
                              >
                                {isBuyIntent ? 'Payout Asset' : opt.hasSufficientBalance ? 'Sufficient' : 'Insufficient'}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Settlement Breakdown */}
                {activeCoinOption && (
                  <div className="p-3.5 rounded-2xl bg-slate-900 text-white space-y-2 text-xs">
                    <div className="flex items-center justify-between text-slate-300">
                      <span>Settlement Rail</span>
                      <span className="font-mono font-bold text-amber-300">
                        {CURRENCY_TYPE_META[activeCoinOption.currencyType].label} ({activeCoinOption.symbol})
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300">{isBuyIntent ? 'Estimated Payout' : 'Total Payment Due'}</span>
                      <span className="font-mono font-black text-sm text-white">
                        {activeCoinOption.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} {activeCoinOption.symbol}
                        <span className="text-slate-400 font-normal ml-1.5">
                          (${valuationUSD.toLocaleString()} USD)
                        </span>
                      </span>
                    </div>
                    {!isBuyIntent && (
                      <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800 text-slate-400">
                        <span>Remaining {activeCoinOption.symbol} After Purchase</span>
                        <span className="font-mono font-semibold text-emerald-300">
                          {Math.max(0, activeCoinOption.totalAvailableUnits - activeCoinOption.requiredUnits).toLocaleString(undefined, {
                            maximumFractionDigits: activeCoinOption.decimals,
                          })}{' '}
                          {activeCoinOption.symbol}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {/* Action Footer */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={
                      isSubmitting ||
                      isSuccess ||
                      targetListing.status === 'sold' ||
                      !activeCoinOption ||
                      (!isBuyIntent && !activeCoinOption.hasSufficientBalance)
                    }
                    className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-xs cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSuccess ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Transaction Executed!</span>
                      </>
                    ) : isSubmitting ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>Executing Settlement...</span>
                      </>
                    ) : targetListing.status === 'sold' ? (
                      <span>Already Settled / Sold</span>
                    ) : (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>
                          {isBuyIntent
                            ? `Fulfill & Receive ${activeCoinOption?.symbol || ''}`
                            : `Execute Purchase (${activeCoinOption?.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption?.decimals || 2 })} ${activeCoinOption?.symbol || ''})`}
                        </span>
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </form>
        )}

        {/* TAB 2: PROPOSE BARTER FORM */}
        {activeModalTab === 'barter' && (
          <form onSubmit={handleOpenConfirmBarter} className="mt-4 flex-1 overflow-y-auto space-y-4 pr-1">
            {targetListing && !acceptsBarter ? (
              <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-2">
                <Lock className="w-7 h-7 text-slate-400 mx-auto" />
                <p className="text-sm font-bold text-slate-900">Barter Not Accepted on This Listing</p>
                <p className="text-xs text-slate-600">
                  The seller configured this listing for currency settlement only. Switch to Buy with Currency to complete the purchase.
                </p>
                {acceptsAnyCurrency && (
                  <button
                    type="button"
                    onClick={() => setActiveModalTab('currency')}
                    className="mt-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    Switch to Buy with Currency
                  </button>
                )}
              </div>
            ) : (
              <>
                {(targetListing?.barterDesired || targetListing?.barterTerms?.desiredTrades) && (
                  <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs">
                    <span className="text-[10px] font-mono uppercase text-amber-800 font-bold block mb-0.5">
                      Seller&apos;s Desired Barter / Counter-Trade Items
                    </span>
                    <p className="text-amber-950 font-medium">
                      {targetListing.barterDesired || targetListing.barterTerms?.desiredTrades}
                    </p>
                  </div>
                )}

                {/* Mode Switcher */}
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setOfferingType('inventory')}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      offeringType === 'inventory'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    From My Verified Reserves
                  </button>
                  <button
                    type="button"
                    onClick={() => setOfferingType('custom')}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      offeringType === 'custom'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Custom Barter Offer
                  </button>
                </div>

                {offeringType === 'inventory' ? (
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setInventoryKind('good');
                          setOfferedUnits(1);
                        }}
                        className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer ${
                          inventoryKind === 'good'
                            ? 'border-amber-500 bg-amber-50 text-amber-900 font-semibold'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <Package className="w-3.5 h-3.5" />
                        <span>Physical Goods ({userWallets.barterGoods.length})</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setInventoryKind('service');
                          setOfferedUnits(1);
                        }}
                        className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer ${
                          inventoryKind === 'service'
                            ? 'border-amber-500 bg-amber-50 text-amber-900 font-semibold'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <Briefcase className="w-3.5 h-3.5" />
                        <span>Services ({userWallets.barterServices.length})</span>
                      </button>
                    </div>

                    {inventoryKind === 'good' ? (
                      <div className="space-y-2.5">
                        <label className="block text-xs font-semibold text-slate-700">Select Physical Asset to Offer</label>
                        {userWallets.barterGoods.length === 0 ? (
                          <p className="text-xs text-slate-500 py-3 bg-slate-50 rounded-xl text-center border border-slate-200">
                            No physical goods in your depository wallet. Switch to Custom Offer.
                          </p>
                        ) : (
                          <>
                            <select
                              value={selectedGoodId}
                              onChange={(e) => {
                                setSelectedGoodId(e.target.value);
                                setOfferedUnits(1);
                              }}
                              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-amber-500"
                            >
                              {userWallets.barterGoods.map((good) => (
                                <option key={good.id} value={good.id}>
                                  {good.quantity}x {good.name} (${good.estimatedUnitValue.toLocaleString()}/{good.unitLabel})
                                </option>
                              ))}
                            </select>

                            {selectedGood && (
                              <div className="grid grid-cols-2 gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200 items-center">
                                <div>
                                  <label className="block text-[10px] font-mono uppercase text-slate-500 mb-1">
                                    Quantity to Offer (Max {selectedGood.quantity})
                                  </label>
                                  <input
                                    type="number"
                                    min={1}
                                    max={selectedGood.quantity}
                                    value={offeredUnits}
                                    onChange={(e) =>
                                      setOfferedUnits(
                                        Math.max(1, Math.min(selectedGood.quantity, Number(e.target.value) || 1))
                                      )
                                    }
                                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-900"
                                  />
                                </div>
                                <div className="text-right">
                                  <span className="block text-[10px] font-mono uppercase text-slate-500">
                                    Offered Barter Value
                                  </span>
                                  <span className="font-mono text-sm font-bold text-amber-700">
                                    ${(offeredUnits * selectedGood.estimatedUnitValue).toLocaleString()} USD
                                  </span>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        <label className="block text-xs font-semibold text-slate-700">Select Service Retainer to Offer</label>
                        {userWallets.barterServices.length === 0 ? (
                          <p className="text-xs text-slate-500 py-3 bg-slate-50 rounded-xl text-center border border-slate-200">
                            No service retainers registered. Switch to Custom Offer.
                          </p>
                        ) : (
                          <>
                            <select
                              value={selectedServiceId}
                              onChange={(e) => {
                                setSelectedServiceId(e.target.value);
                                setOfferedUnits(1);
                              }}
                              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-amber-500"
                            >
                              {userWallets.barterServices.map((srv) => (
                                <option key={srv.id} value={srv.id}>
                                  {srv.availableUnits} {srv.unitType} of {srv.name} (${srv.hourlyRateValue.toLocaleString()}/{srv.unitType})
                                </option>
                              ))}
                            </select>

                            {selectedService && (
                              <div className="grid grid-cols-2 gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200 items-center">
                                <div>
                                  <label className="block text-[10px] font-mono uppercase text-slate-500 mb-1">
                                    {selectedService.unitType} to Offer (Max {selectedService.availableUnits})
                                  </label>
                                  <input
                                    type="number"
                                    min={1}
                                    max={selectedService.availableUnits}
                                    value={offeredUnits}
                                    onChange={(e) =>
                                      setOfferedUnits(
                                        Math.max(1, Math.min(selectedService.availableUnits, Number(e.target.value) || 1))
                                      )
                                    }
                                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-900"
                                  />
                                </div>
                                <div className="text-right">
                                  <span className="block text-[10px] font-mono uppercase text-slate-500">
                                    Offered Service Value
                                  </span>
                                  <span className="font-mono text-sm font-bold text-blue-700">
                                    ${(offeredUnits * selectedService.hourlyRateValue).toLocaleString()} USD
                                  </span>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-700">Describe Your Barter Offer</label>
                    <textarea
                      rows={3}
                      value={customOfferText}
                      onChange={(e) => setCustomOfferText(e.target.value)}
                      placeholder="e.g., 500g LBMA certified silver bullion bar + 10 hours smart contract architecture audit..."
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-amber-500 resize-none"
                    />
                  </div>
                )}

                {/* Sweetener Toggle Supporting All 4 Currency Types */}
                <div className="pt-2 border-t border-slate-100">
                  <label className="flex items-center justify-between text-xs font-medium text-slate-700 cursor-pointer">
                    <span className="flex items-center gap-1.5">
                      <Coins className="w-4 h-4 text-amber-600" />
                      <span>Add Cash / Coin Balancing Sweetener (Any of 4 Currency Types)</span>
                    </span>
                    <input
                      type="checkbox"
                      checked={includeSweetener}
                      onChange={(e) => setIncludeSweetener(e.target.checked)}
                      className="rounded border-slate-300 text-amber-600 focus:ring-amber-500 w-4 h-4 cursor-pointer"
                    />
                  </label>

                  {includeSweetener && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase font-mono mb-1">Currency Type</label>
                        <select
                          value={sweetenerCurrencyType}
                          onChange={(e) => setSweetenerCurrencyType(e.target.value as CurrencyTypeId)}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900"
                        >
                          <option value="final_coins">Final Coins</option>
                          <option value="stable_coins">Stablecoins</option>
                          <option value="fiat">Fiat Currency</option>
                          <option value="crypto">Cryptocurrency</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase font-mono mb-1">Coin / Currency</label>
                        <select
                          value={sweetenerCoinSymbol}
                          onChange={(e) => setSweetenerCoinSymbol(e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900"
                        >
                          {sweetenerCoinOptions.map((c) => (
                            <option key={c.symbol} value={c.symbol}>
                              {c.symbol} (Avail: {c.totalAvailableUnits.toLocaleString(undefined, { maximumFractionDigits: c.decimals })})
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase font-mono mb-1">Sweetener ($USD)</label>
                        <input
                          type="number"
                          min={1}
                          value={sweetenerAmountUSD}
                          onChange={(e) => setSweetenerAmountUSD(Math.max(1, Number(e.target.value) || 0))}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono"
                        />
                        {activeSweetenerCoin && (
                          <span className="block text-[10px] font-mono text-slate-500 mt-0.5">
                            = {activeSweetenerCoin.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeSweetenerCoin.decimals })} {activeSweetenerCoin.symbol}
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setActiveModalTab('portfolio')}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                  >
                    &larr; View Asset Vault
                  </button>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting || isSuccess || targetListing?.status === 'sold'}
                      className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-xs cursor-pointer disabled:opacity-50"
                    >
                      {isSuccess ? (
                        <>
                          <Check className="w-4 h-4 text-slate-950" />
                          <span>Barter Executed!</span>
                        </>
                      ) : isSubmitting ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                          <span>Executing Barter...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          <span>Execute Barter Offer</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </>
            )}
          </form>
        )}

        {/* TAB 3: PORTFOLIO & ASSET SUMMARY */}
        {activeModalTab === 'portfolio' && (
          <div className="mt-4 flex-1 overflow-y-auto space-y-5 pr-1 text-left">
            {/* 1. Barter Goods Inventory */}
            <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-amber-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Physical Goods Inventory ({userWallets.barterGoods.length})</h3>
                </div>
                <span className="text-xs font-mono font-bold text-amber-800">${goodsTotalUSD.toLocaleString()} USD</span>
              </div>
              {userWallets.barterGoods.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No physical goods registered in inventory.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {userWallets.barterGoods.map((good) => (
                    <div key={good.id} className="p-3 bg-white rounded-xl border border-amber-200/80 space-y-1 shadow-2xs">
                      <div className="flex justify-between items-start gap-2">
                        <span className="font-bold text-xs text-slate-900">{good.name}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-semibold shrink-0">{good.condition}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{good.description}</p>
                      <div className="flex justify-between items-center text-[11px] pt-1 font-mono">
                        <span className="text-slate-600">Qty: {good.quantity} {good.unitLabel}</span>
                        <span className="font-bold text-amber-700">${(good.quantity * good.estimatedUnitValue).toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 2. Barter Services Inventory */}
            <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-blue-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Service Retainers &amp; Capacity ({userWallets.barterServices.length})</h3>
                </div>
                <span className="text-xs font-mono font-bold text-blue-800">${servicesTotalUSD.toLocaleString()} USD</span>
              </div>
              {userWallets.barterServices.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No service retainers registered.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {userWallets.barterServices.map((srv) => (
                    <div key={srv.id} className="p-3 bg-white rounded-xl border border-blue-200/80 space-y-1 shadow-2xs">
                      <div className="flex justify-between items-start gap-2">
                        <span className="font-bold text-xs text-slate-900">{srv.name}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-100 text-blue-900 font-semibold shrink-0">{srv.turnaroundTime}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{srv.deliverableDescription}</p>
                      <div className="flex justify-between items-center text-[11px] pt-1 font-mono">
                        <span className="text-slate-600">{srv.availableUnits} {srv.unitType}</span>
                        <span className="font-bold text-blue-700">${(srv.availableUnits * srv.hourlyRateValue).toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 3. Final Coins (AFNL) */}
            <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3 shadow-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Coins className="w-4 h-4 text-amber-400" />
                  <h3 className="font-bold text-xs uppercase tracking-wider text-amber-300">Final Coins (AFNL) Holdings</h3>
                </div>
                <span className="text-xs font-mono font-bold text-amber-400">${finalCoinsTotalUSD.toLocaleString()} USD eq.</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.finalCoins.map((coin) => {
                  const rate = coin.unitPriceUSD > 0 ? coin.unitPriceUSD : coin.symbol === 'AFNL' ? 20 : 0;
                  return (
                    <div key={coin.id} className="p-3 bg-slate-800/90 rounded-xl border border-slate-700 space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-xs text-white">{coin.name} ({coin.symbol})</span>
                      </div>
                      <div className="flex justify-between items-center text-xs font-mono pt-1">
                        <span className="text-amber-300 font-bold">{coin.balance.toLocaleString()} {coin.symbol}</span>
                        <span className="text-slate-400">${(coin.balance * rate).toLocaleString()}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 4. Stablecoins */}
            <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Stablecoins &amp; Escrow Liquidity</h3>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-800">${stableCoinsTotalUSD.toLocaleString()} USD</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.stableCoins.map((sc) => (
                  <div key={sc.id} className="p-3 bg-white rounded-xl border border-emerald-200/80 space-y-1 shadow-2xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-slate-900">{sc.name} ({sc.symbol})</span>
                      <span className="text-[10px] font-mono text-emerald-700 font-semibold">{sc.yieldAPY}% APY</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono pt-1">
                      <span className="font-bold text-emerald-800">{sc.balance.toLocaleString()} {sc.symbol}</span>
                      <span className="text-slate-500">${(sc.balance * sc.unitPriceUSD).toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5. Fiat */}
            <div className="p-4 rounded-2xl bg-sky-50/50 border border-sky-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Banknote className="w-4 h-4 text-sky-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Fiat Balances (USD / CHF / GBP)</h3>
                </div>
                <span className="text-xs font-mono font-bold text-sky-800">${fiatTotalUSD.toLocaleString()} USD</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.fiatCurrencies.map((fiat) => (
                  <div key={fiat.id} className="p-3 bg-white rounded-xl border border-sky-200/80 space-y-1 shadow-2xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-slate-900">{fiat.name} ({fiat.code})</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono pt-1">
                      <span className="font-bold text-sky-900">{fiat.symbol}{fiat.balance.toLocaleString()}</span>
                      <span className="text-slate-500">${(fiat.balance * fiat.exchangeRateToUSD).toLocaleString()} USD</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 6. Crypto */}
            <div className="p-4 rounded-2xl bg-purple-50/50 border border-purple-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Binary className="w-4 h-4 text-purple-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Cryptocurrencies (BTC / ETH / SOL)</h3>
                </div>
                <span className="text-xs font-mono font-bold text-purple-800">${cryptoTotalUSD.toLocaleString()} USD</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.cryptoCurrencies.map((crypto) => (
                  <div key={crypto.id} className="p-3 bg-white rounded-xl border border-purple-200/80 space-y-1 shadow-2xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-slate-900">{crypto.name} ({crypto.symbol})</span>
                      <span className="text-[10px] font-mono text-purple-700 font-semibold">{crypto.network}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono pt-1">
                      <span className="font-bold text-purple-900">{crypto.balance} {crypto.symbol}</span>
                      <span className="text-slate-500">${(crypto.balance * crypto.unitPriceUSD).toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {targetListing && (
              <div className="pt-2 flex justify-end gap-2">
                {acceptsAnyCurrency && (
                  <button
                    type="button"
                    onClick={() => setActiveModalTab('currency')}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-sm cursor-pointer flex items-center gap-2"
                  >
                    <span>Buy with Currency</span>
                    <Coins className="w-3.5 h-3.5" />
                  </button>
                )}
                {acceptsBarter && (
                  <button
                    type="button"
                    onClick={() => setActiveModalTab('barter')}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all shadow-sm cursor-pointer flex items-center gap-2"
                  >
                    <span>Propose Barter</span>
                    <Repeat className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </motion.div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title={confirmMode === 'currency' ? 'Confirm Settlement Execution' : 'Confirm Barter Trade Execution'}
        message={
          confirmMode === 'currency' && activeCoinOption
            ? `${isBuyIntent ? 'Fulfill this listing and receive' : 'Pay'} ${activeCoinOption.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: activeCoinOption.decimals })} ${activeCoinOption.symbol} ($${valuationUSD.toLocaleString()} USD) via ${CURRENCY_TYPE_META[activeCoinOption.currencyType].label} for "${targetListing?.title}"?`
            : `Execute this barter trade proposal for "${targetListing?.title}"? Offered reserves and any balancing sweetener will be committed to the peer ledger.`
        }
        confirmText={confirmMode === 'currency' ? 'Confirm & Execute Deal' : 'Confirm & Execute Barter'}
        type="warning"
      />
    </div>
  );
};
