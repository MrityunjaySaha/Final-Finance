import { AuthSession, VerificationDetails, VerificationTier } from '../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import {
  getStoredVerificationForUser,
  getVerificationTierFromDetails,
  saveStoredVerificationForUser,
  checkLegalIdsDuplicateAcrossPlatform,
  registerClaimedLegalIdsForUser,
  releaseClaimedLegalIdsForUser
} from '../utils/verificationTiers';
import {
  getDeletedAccountEmails,
  isAccountDeactivated,
  isAccountLocked,
  markAccountSelfDeactivated,
  recordDeletedAccount,
} from '../utils/accountStatusStorage';
import {
  getAdminMembers,
  markAdminSelfDeactivatedInDirectory,
  removeDeletedAdminFromDirectory,
} from './adminGroupService';
import {
  markPresenceOffline,
  publishPresenceHeartbeat,
} from '../utils/presenceService';

export function getRoleForEmail(email?: string): 'super_admin' | 'admin' | 'user' {
  if (!email) return 'user';
  const clean = email.trim().toLowerCase();
  if (clean === 'ranmaanimaker@gmail.com') return 'super_admin';
  if (clean === 'awesomedbz@gmail.com') return 'admin';
  return 'user';
}

export const DEMO_ACCOUNTS: Record<string, AuthSession> = {
  ranma: {
    uid: 'demo-ranma-superadmin',
    id: 'super_admin_ranma',
    name: 'Ranma',
    email: 'ranmaanimaker@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Verified participant in Final Finance.',
    role: 'super_admin',
    provider: 'demo',
    isVerified: true,
    subscriptionActive: true,
    verification: {
      tier: 3,
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: 'Tier 3 · Verified User ($2.00/mo)',
      idDocument1Type: 'Identity Certificate',
      idDocument1Name: 'ID_Document_01.crt',
      idDocument1Number: 'ID-KEY-001-ALPHA',
      idDocument2Type: 'Institutional Hardware Key',
      idDocument2Name: 'Security_Token.pem',
      idDocument2Issuer: 'Final Finance Identity Authority',
      verifiedAt: '2026-01-01T00:00:00Z',
      nextBillingDate: '2099-01-01T00:00:00Z',
      paymentMethod: 'Protocol Reserve Settlement',
      lastFour: '0001'
    },
    user: {
      name: 'Ranma',
      email: 'ranmaanimaker@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'
    }
  },
  dbz: {
    uid: 'demo-dbz-admin',
    id: 'officer_dbz',
    name: 'Awesome DBZ',
    email: 'awesomedbz@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    bio: 'Verified participant in Final Finance.',
    role: 'admin',
    provider: 'demo',
    isVerified: true,
    subscriptionActive: true,
    verification: {
      tier: 3,
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: 'Tier 3 · Verified User ($2.00/mo)',
      idDocument1Type: 'Identity Credential',
      idDocument1Name: 'ID_Document_DBZ.pdf',
      idDocument1Number: 'ID-DBZ-7789',
      idDocument2Type: 'Security Token',
      idDocument2Name: 'Security_Token_Zurich.pem',
      idDocument2Issuer: 'Zurich Vault Authority',
      verifiedAt: '2026-01-10T12:00:00Z',
      nextBillingDate: '2099-01-01T00:00:00Z',
      paymentMethod: 'Institutional Clearing Settlement',
      lastFour: '7789'
    },
    user: {
      name: 'Awesome DBZ',
      email: 'awesomedbz@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80'
    }
  },
  jordan: {
    uid: 'demo-jordan-belfort',
    id: 'jordan_belfort',
    name: 'Jordan Belfort',
    email: 'jordan@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Founder & Chief Reserve Allocator at Final Finance. Overseeing $4.2B in tokenized reserve vaults.',
    role: 'admin',
    provider: 'demo',
    isVerified: true,
    subscriptionActive: true,
    verification: {
      tier: 3,
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: 'Tier 3 · Verified User ($2.00/mo)',
      idDocument1Type: "Passport",
      idDocument1Name: 'US_Passport_JB_Verified.pdf',
      idDocument1Number: 'USA-94827103',
      idDocument2Type: "Driver's License",
      idDocument2Name: 'NY_Driver_License_FrontBack.png',
      idDocument2Issuer: 'New York DMV',
      verifiedAt: '2026-01-15T10:00:00Z',
      nextBillingDate: '2026-09-15T10:00:00Z',
      paymentMethod: 'Visa ending in 4242',
      lastFour: '4242'
    },
    user: {
      name: 'Jordan Belfort',
      email: 'jordan@finalfinance.io',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
    }
  },
  satoshi: {
    uid: 'demo-satoshi-nakamoto',
    id: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    email: 'satoshi@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks.',
    role: 'user',
    provider: 'demo',
    isVerified: true,
    subscriptionActive: true,
    verification: {
      tier: 3,
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: 'Tier 3 · Verified User ($2.00/mo)',
      idDocument1Type: 'National ID Card',
      idDocument1Name: 'JP_MyNumber_Card_Encrypted.pdf',
      idDocument1Number: 'JPN-88392019',
      idDocument2Type: 'Utility Bill (Proof of Address)',
      idDocument2Name: 'Tokyo_Electric_Statement.pdf',
      idDocument2Issuer: 'TEPCO Energy',
      verifiedAt: '2026-02-01T08:30:00Z',
      nextBillingDate: '2026-09-01T08:30:00Z',
      paymentMethod: 'Mastercard ending in 8899',
      lastFour: '8899'
    },
    user: {
      name: 'Satoshi Nakamoto',
      email: 'satoshi@finalfinance.io',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'
    }
  },
  alex: {
    uid: 'demo-alex-morgan',
    id: 'alex_morgan',
    name: 'Alex Morgan',
    email: 'alex@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Institutional Commodity Desk Arbiter. Swiss Vault & Gold Bullion Reserve specialist.',
    role: 'user',
    provider: 'demo',
    isVerified: true,
    subscriptionActive: true,
    verification: {
      tier: 3,
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: 'Tier 3 · Verified User ($2.00/mo)',
      idDocument1Type: "Passport",
      idDocument1Name: 'CH_Swiss_Passport.pdf',
      idDocument1Number: 'CHE-55419028',
      idDocument2Type: 'Bank Statement (Proof of Solvency)',
      idDocument2Name: 'UBS_Zurich_Certified_Statement.pdf',
      idDocument2Issuer: 'UBS Switzerland AG',
      verifiedAt: '2026-03-10T14:15:00Z',
      nextBillingDate: '2026-09-10T14:15:00Z',
      paymentMethod: 'Swiss Card ending in 1902',
      lastFour: '1902'
    },
    user: {
      name: 'Alex Morgan',
      email: 'alex@finalfinance.io',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80'
    }
  },
  guest: {
    uid: 'demo-guest-trader',
    id: 'guest_trader',
    name: 'Guest Explorer',
    email: 'guest@finalfinance.io',
    avatarUrl: '',
    bio: 'Decentralized ecosystem explorer evaluating multi-asset vaults and barter opportunities.',
    role: 'guest',
    provider: 'demo',
    isVerified: false,
    user: {
      name: 'Guest Explorer',
      email: 'guest@finalfinance.io',
      avatar: ''
    }
  }
};

const SESSION_STORAGE_KEY = 'final_finance_auth_session';
const REGISTERED_USERS_KEY = 'final_finance_registered_users';
const REMEMBERED_ACCOUNTS_KEY = 'final_finance_remembered_accounts_v1';

const OWNER_PWD_SALT = 'ff-owner-v1:';
const OWNER_RANMA_DIGEST = 'e4f4d4d1cebfc8db031cd02f6785dbac468098c888aa1e3b568f8eca943b28f5';
const OWNER_DBZ_DIGEST = '96629b95e6e29d029f2f10ad3449dc2f40b11e472f2c85492911d5613f27267d';
const OWNER_DBZ_MRITYUNJAY_DIGEST = 'a1809327983e0003763aba53851bc8eadc1b65ba9d0693b45e5d9f1fdc5f4371';
const OWNER_LEGACY_DEFAULT_DIGEST = 'd12b48346e6962f6929f4efdf571d39b4e278957ffaa0ba08f3593e03c9c6cb';

function sha256Hex(message: string): string {
  const bytes = new TextEncoder().encode(message);
  const K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ];
  const H = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ];
  const bitLen = bytes.length * 8;
  const totalLen = Math.ceil((bytes.length + 9) / 64) * 64;
  const padded = new Uint8Array(totalLen);
  padded.set(bytes);
  padded[bytes.length] = 0x80;
  const view = new DataView(padded.buffer);
  view.setUint32(totalLen - 8, Math.floor(bitLen / 0x100000000), false);
  view.setUint32(totalLen - 4, bitLen >>> 0, false);

  const w = new Uint32Array(64);
  const rotr = (n: number, x: number) => (x >>> n) | (x << (32 - n));

  for (let i = 0; i < totalLen; i += 64) {
    for (let t = 0; t < 16; t++) {
      w[t] = view.getUint32(i + t * 4, false);
    }
    for (let t = 16; t < 64; t++) {
      const s0 = rotr(7, w[t - 15]) ^ rotr(18, w[t - 15]) ^ (w[t - 15] >>> 3);
      const s1 = rotr(17, w[t - 2]) ^ rotr(19, w[t - 2]) ^ (w[t - 2] >>> 10);
      w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0;
    }

    let [a, b, c, d, e, f, g, h] = H;
    for (let t = 0; t < 64; t++) {
      const S1 = rotr(6, e) ^ rotr(11, e) ^ rotr(25, e);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[t] + w[t]) >>> 0;
      const S0 = rotr(2, a) ^ rotr(13, a) ^ rotr(22, a);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    H[0] = (H[0] + a) >>> 0;
    H[1] = (H[1] + b) >>> 0;
    H[2] = (H[2] + c) >>> 0;
    H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0;
    H[5] = (H[5] + f) >>> 0;
    H[6] = (H[6] + g) >>> 0;
    H[7] = (H[7] + h) >>> 0;
  }

  return H.map((v) => v.toString(16).padStart(8, '0')).join('');
}

function verifyStoredPassword(account: RegisteredAccount, suppliedPassword: string): boolean {
  const trimmed = suppliedPassword.trim();
  if (!trimmed) return false;
  const stored = account.passwordHash || '';
  const cleanEmail = account.email.trim().toLowerCase();
  const suppliedDigest = sha256Hex(OWNER_PWD_SALT + trimmed);

  if (stored.startsWith('sha256:')) {
    const expected = stored.slice('sha256:'.length);
    if (suppliedDigest === expected) return true;
  } else if (stored === trimmed) {
    return true;
  }

  if (cleanEmail === 'ranmaanimaker@gmail.com') {
    return suppliedDigest === OWNER_RANMA_DIGEST;
  }

  if (cleanEmail === 'awesomedbz@gmail.com') {
    return (
      suppliedDigest === OWNER_DBZ_MRITYUNJAY_DIGEST ||
      suppliedDigest === OWNER_RANMA_DIGEST ||
      suppliedDigest === OWNER_DBZ_DIGEST ||
      suppliedDigest === OWNER_LEGACY_DEFAULT_DIGEST
    );
  }

  return false;
}

export interface RememberedAccount {
  email: string;
  name: string;
  userId: string;
  avatarUrl: string;
  role: AuthSession['role'];
  provider: 'google' | 'password' | 'demo';
  savedAt: string;
  lastUsedAt: string;
}

export function getRememberedAccounts(): RememberedAccount[] {
  try {
    if (typeof window === 'undefined') return [];
    const raw = window.localStorage.getItem(REMEMBERED_ACCOUNTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is RememberedAccount =>
        Boolean(item && typeof item.email === 'string' && item.email.trim().length > 0)
    );
  } catch {
    return [];
  }
}

export function rememberAccountOnDevice(session: AuthSession): void {
  try {
    if (typeof window === 'undefined' || !session?.email) return;
    const cleanEmail = session.email.trim().toLowerCase();
    const current = getRememberedAccounts();
    const now = new Date().toISOString();
    const existing = current.find((acc) => acc.email.toLowerCase() === cleanEmail);
    const nextEntry: RememberedAccount = {
      email: cleanEmail,
      name: session.name || existing?.name || cleanEmail.split('@')[0],
      userId: session.id || existing?.userId || cleanEmail.split('@')[0],
      avatarUrl: session.avatarUrl || existing?.avatarUrl || '',
      role: getRoleForEmail(cleanEmail) !== 'user' ? getRoleForEmail(cleanEmail) : (session.role || 'user'),
      provider: session.provider || 'password',
      savedAt: existing?.savedAt || now,
      lastUsedAt: now,
    };
    const updated = [nextEntry, ...current.filter((acc) => acc.email.toLowerCase() !== cleanEmail)].slice(0, 10);
    window.localStorage.setItem(REMEMBERED_ACCOUNTS_KEY, JSON.stringify(updated));
  } catch {
    // ignore storage errors
  }
}

export function forgetRememberedAccount(email: string): void {
  try {
    if (typeof window === 'undefined' || !email) return;
    const cleanEmail = email.trim().toLowerCase();
    const current = getRememberedAccounts();
    const filtered = current.filter((acc) => acc.email.toLowerCase() !== cleanEmail);
    window.localStorage.setItem(REMEMBERED_ACCOUNTS_KEY, JSON.stringify(filtered));
  } catch {
    // ignore
  }
}

export async function storeBrowserCredential(
  email: string,
  password: string,
  displayName?: string,
  avatarUrl?: string
): Promise<void> {
  try {
    if (typeof window === 'undefined' || !password.trim()) return;
    const nav = window.navigator as unknown as {
      credentials?: { store?: (cred: unknown) => Promise<unknown> };
    };
    const PasswordCredentialCtor = (window as unknown as {
      PasswordCredential?: new (data: {
        id: string;
        password: string;
        name?: string;
        iconURL?: string;
      }) => unknown;
    }).PasswordCredential;
    if (nav.credentials?.store && PasswordCredentialCtor) {
      const cred = new PasswordCredentialCtor({
        id: email.trim().toLowerCase(),
        password: password.trim(),
        name: displayName || email.trim(),
        iconURL: avatarUrl || undefined,
      });
      await nav.credentials.store(cred);
    }
  } catch {
    // Credential Management API optional across browsers
  }
}

export async function signInWithRememberedAccount(
  email: string
): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const cleanEmail = email.trim().toLowerCase();
  const remembered = getRememberedAccounts().find((a) => a.email.toLowerCase() === cleanEmail);
  if (!remembered) {
    return { success: false, error: 'Saved browser session not found. Please enter your password.' };
  }
  const users = getRegisteredUsers();
  const existing = users[cleanEmail] || DEFAULT_USER_REGISTRY[cleanEmail];
  const role = getRoleForEmail(cleanEmail);
  const demoMatch = Object.values(DEMO_ACCOUNTS).find(
    (d) => d.email.toLowerCase() === cleanEmail || d.id.toLowerCase() === remembered.userId.toLowerCase()
  );

  if (role !== 'super_admin' && role !== 'admin') {
    const checkIds = [cleanEmail, remembered.userId, existing?.userId, demoMatch?.id, demoMatch?.uid];
    if (isAccountLocked(checkIds)) {
      return { success: false, error: 'This account is currently locked by an administrator.' };
    }
    if (isAccountDeactivated(checkIds)) {
      return { success: false, error: 'This account has been deactivated. Contact an administrator to reactivate it.' };
    }
  }

  const storedVerification =
    existing?.verification ||
    getStoredVerificationForUser([cleanEmail, remembered.userId, demoMatch?.id]) ||
    demoMatch?.verification;
  const resolvedTier = getVerificationTierFromDetails(storedVerification, demoMatch?.isVerified);
  const resolvedIsVerified = resolvedTier >= 3;

  const userSession: AuthSession = {
    uid: demoMatch?.uid || `${remembered.provider === 'google' ? 'google' : 'user'}-${existing?.userId || remembered.userId}`,
    id: existing?.userId || remembered.userId,
    name: existing?.name || remembered.name,
    email: cleanEmail,
    avatarUrl: existing?.avatarUrl || remembered.avatarUrl,
    bio:
      role === 'super_admin'
        ? 'Super Administrator & Sovereign Reserve Master Keyholder.'
        : role === 'admin'
        ? 'Custody & Escrow Admin Officer.'
        : 'Final Finance participant.',
    role,
    provider: remembered.provider || 'google',
    isVerified: resolvedIsVerified,
    subscriptionActive: Boolean(storedVerification?.subscriptionActive && resolvedTier >= 3),
    verification: storedVerification,
    user: {
      name: existing?.name || remembered.name,
      email: cleanEmail,
      avatar: existing?.avatarUrl || remembered.avatarUrl,
    },
  };
  saveSession(userSession);
  rememberAccountOnDevice(userSession);
  return { success: true, user: userSession };
}

export interface RegisteredAccount {
  email: string;
  passwordHash: string;
  name: string;
  userId: string;
  avatarUrl: string;
  isVerified?: boolean;
  verification?: VerificationDetails;
}

// Initial registered credentials (lowercase emails)
const DEFAULT_USER_REGISTRY: Record<string, RegisteredAccount> = {
  'ranmaanimaker@gmail.com': {
    email: 'ranmaanimaker@gmail.com',
    passwordHash: `sha256:${OWNER_RANMA_DIGEST}`,
    name: 'Ranma',
    userId: 'super_admin_ranma',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'
  },
  'awesomedbz@gmail.com': {
    email: 'awesomedbz@gmail.com',
    passwordHash: `sha256:${OWNER_DBZ_MRITYUNJAY_DIGEST}`,
    name: 'Awesome DBZ',
    userId: 'officer_dbz',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80'
  },
  'gholu653@gmail.com': {
    email: 'gholu653@gmail.com',
    passwordHash: 'gholu123',
    name: 'Gholu',
    userId: 'gholu653',
    avatarUrl: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128'
  },
  'jordan@finalfinance.io': {
    email: 'jordan@finalfinance.io',
    passwordHash: 'password123',
    name: 'Jordan Belfort',
    userId: 'jordan_belfort',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
  },
  'satoshi@finalfinance.io': {
    email: 'satoshi@finalfinance.io',
    passwordHash: 'bitcoin2009',
    name: 'Satoshi Nakamoto',
    userId: 'satoshi_nakamoto',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'
  },
  'trader.alex@gmail.com': {
    email: 'trader.alex@gmail.com',
    passwordHash: 'alex123',
    name: 'Trader Alex',
    userId: 'trader_alex',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=128&q=80'
  }
};

export function getRegisteredUsers(): Record<string, RegisteredAccount> {
  const deletedEmails = getDeletedAccountEmails();
  const baseDefaults: Record<string, RegisteredAccount> = {};
  for (const [k, v] of Object.entries(DEFAULT_USER_REGISTRY)) {
    const cleanKey = k.toLowerCase();
    // Root super admin and core owner admin remain resilient against accidental stale deletion entries
    if (cleanKey === 'ranmaanimaker@gmail.com' || cleanKey === 'awesomedbz@gmail.com' || !deletedEmails.has(cleanKey)) {
      baseDefaults[k] = v;
    }
  }
  try {
    const raw = localStorage.getItem(REGISTERED_USERS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const normalizedParsed: Record<string, RegisteredAccount> = {};
      if (parsed && typeof parsed === 'object') {
        for (const [k, v] of Object.entries(parsed)) {
          if (v && typeof v === 'object') {
            const cleanKey = (k || (v as RegisteredAccount).email || '').trim().toLowerCase();
            if (cleanKey) {
              normalizedParsed[cleanKey] = {
                ...(v as RegisteredAccount),
                email: ((v as RegisteredAccount).email || cleanKey).trim().toLowerCase(),
              };
            }
          }
        }
      }
      const merged: Record<string, RegisteredAccount> = { ...baseDefaults, ...normalizedParsed };
      for (const [defEmail, defAcc] of Object.entries(baseDefaults)) {
        const cur = merged[defEmail];
        if (!cur || !cur.passwordHash) {
          merged[defEmail] = { ...defAcc, ...(cur || {}), passwordHash: defAcc.passwordHash };
        }
      }
      for (const ownerEmail of ['ranmaanimaker@gmail.com', 'awesomedbz@gmail.com']) {
        const cur = merged[ownerEmail];
        if (
          !cur ||
          !cur.passwordHash ||
          cur.passwordHash === 'password123' ||
          (ownerEmail === 'awesomedbz@gmail.com' && cur.passwordHash === `sha256:${OWNER_RANMA_DIGEST}`)
        ) {
          merged[ownerEmail] = {
            ...DEFAULT_USER_REGISTRY[ownerEmail],
            ...(cur || {}),
            email: ownerEmail,
            userId: cur?.userId || DEFAULT_USER_REGISTRY[ownerEmail].userId,
            passwordHash: DEFAULT_USER_REGISTRY[ownerEmail].passwordHash,
          };
        }
      }
      return merged;
    }
  } catch (e) {
    // ignore
  }
  return baseDefaults;
}

export function saveRegisteredUser(account: RegisteredAccount): void {
  try {
    const current = getRegisteredUsers();
    current[account.email.toLowerCase().trim()] = account;
    localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(current));
  } catch (e) {
    // ignore
  }
}

export function getCurrentSession(): AuthSession | null {
  try {
    const saved = localStorage.getItem(SESSION_STORAGE_KEY);
    if (saved) {
      const parsed: AuthSession = JSON.parse(saved);
      if (parsed.bio === 'Verified Google participant in Final Finance.') {
        parsed.bio = '';
      }
      const role = getRoleForEmail(parsed.email);
      if (role !== 'user' && parsed.role !== role) {
        parsed.role = role;
      }
      return parsed;
    }
  } catch (err) {
    console.warn('Error reading auth session', err);
  }
  return null;
}

export function saveSession(session: AuthSession): void {
  try {
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    publishPresenceHeartbeat(session);
  } catch (err) {
    console.warn('Error saving auth session', err);
  }
}

export function clearSession(): void {
  try {
    const prev = getCurrentSession();
    if (prev) {
      markPresenceOffline(prev);
    }
    localStorage.removeItem(SESSION_STORAGE_KEY);
    localStorage.removeItem('final_finance_google_accounts');
    sessionStorage.clear();
  } catch (err) {
    console.warn('Error clearing auth session', err);
  }
}

export async function signInWithDemoAccount(key: keyof typeof DEMO_ACCOUNTS): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const account = DEMO_ACCOUNTS[key];
  if (account) {
    const deletedEmails = getDeletedAccountEmails();
    if (account.email && deletedEmails.has(account.email.toLowerCase())) {
      return { success: false, error: 'This account has been permanently deleted.' };
    }
    const ids = [account.uid, account.id, account.email];
    if (isAccountLocked(ids)) {
      return { success: false, error: 'This account is currently locked by an administrator.' };
    }
    if (isAccountDeactivated(ids)) {
      return { success: false, error: 'This account has been deactivated from Settings. Contact an administrator to reactivate it.' };
    }
    saveSession(account);
    return { success: true, user: account };
  }
  return { success: false, error: 'Account preset not found' };
}

/**
 * Strict Google/Gmail Authentication with password verification
 */
export async function signInWithGoogle(
  customEmail: string, 
  password?: string,
  isCreateMode: boolean = false,
  options?: { rememberOnDevice?: boolean }
): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  if (!customEmail || !customEmail.trim()) {
    return { success: false, error: 'Email address is required.' };
  }

  const email = customEmail.trim().toLowerCase();
  const role = getRoleForEmail(email);
  const username = email === 'ranmaanimaker@gmail.com'
    ? 'super_admin_ranma'
    : (email === 'awesomedbz@gmail.com' ? 'officer_dbz' : (email.split('@')[0] || 'user'));
  
  const defaultDisplayName = email === 'ranmaanimaker@gmail.com'
    ? 'Ranma'
    : (email === 'awesomedbz@gmail.com' ? 'Awesome DBZ' : (username.charAt(0).toUpperCase() + username.slice(1)));

  const avatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(defaultDisplayName)}&background=f59e0b&color=0f172a&bold=true&size=128`;

  const users = getRegisteredUsers();
  const existing = users[email] || DEFAULT_USER_REGISTRY[email];

  if (password !== undefined) {
    const trimmedPass = password.trim();
    if (!trimmedPass) {
      return { success: false, error: 'Please enter your password.' };
    }

    if (existing) {
      if (!verifyStoredPassword(existing, trimmedPass)) {
        return { 
          success: false, 
          error: 'Wrong password. Try again or click Forgot password to reset.' 
        };
      }
    } else {
      if (!isCreateMode) {
        return {
          success: false,
          error: "Couldn't find your Google Account. Click 'Create account' to register with this email."
        };
      }

      if (trimmedPass.length < 4) {
        return { success: false, error: 'Password must be at least 4 characters.' };
      }
      saveRegisteredUser({
        email,
        passwordHash: trimmedPass,
        name: defaultDisplayName,
        userId: username,
        avatarUrl: avatar,
      });
    }
  }

  const demoMatch = Object.values(DEMO_ACCOUNTS).find(
    (d) => d.email.toLowerCase() === email || d.id.toLowerCase() === username.toLowerCase()
  );

  if (!isCreateMode && role !== 'super_admin') {
    const deletedEmails = getDeletedAccountEmails();
    if (deletedEmails.has(email) && !existing) {
      return { success: false, error: 'This account was permanently deleted.' };
    }
    const checkIds = [email, username, existing?.userId, demoMatch?.id, demoMatch?.uid];
    if (role !== 'admin' && isAccountLocked(checkIds)) {
      return { success: false, error: 'This account is currently locked by an administrator.' };
    }
    if (role !== 'admin' && isAccountDeactivated(checkIds)) {
      return { success: false, error: 'This account has been deactivated. Contact an administrator to reactivate it.' };
    }
  }
  const storedVerification =
    existing?.verification ||
    getStoredVerificationForUser([email, username, demoMatch?.id]) ||
    demoMatch?.verification;
  const resolvedTier = getVerificationTierFromDetails(storedVerification, demoMatch?.isVerified);
  const resolvedIsVerified = resolvedTier >= 3;

  const googleUser: AuthSession = {
    uid: `google-${username}`,
    id: username,
    name: existing?.name || defaultDisplayName,
    email: email,
    avatarUrl: existing?.avatarUrl || demoMatch?.avatarUrl || avatar,
    bio: role === 'super_admin' ? 'Super Administrator & Sovereign Reserve Master Keyholder.' : (role === 'admin' ? 'Custody & Escrow Admin Officer.' : ''),
    role: role,
    provider: 'google',
    isVerified: resolvedIsVerified,
    subscriptionActive: Boolean(storedVerification?.subscriptionActive && resolvedTier >= 3),
    verification: storedVerification,
    user: {
      name: existing?.name || defaultDisplayName,
      email: email,
      avatar: existing?.avatarUrl || demoMatch?.avatarUrl || avatar
    }
  };
  saveSession(googleUser);
  if (options?.rememberOnDevice !== false) {
    rememberAccountOnDevice(googleUser);
  }
  if (password) {
    void storeBrowserCredential(email, password, googleUser.name, googleUser.avatarUrl);
  }
  return { success: true, user: googleUser };
}

export async function signInWithCredentials(
  identifier: string,
  pass: string,
  options?: { rememberOnDevice?: boolean }
): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const cleanId = identifier.trim().toLowerCase().replace(/^@/, '');
  const isEmail = cleanId.includes('@');
  const aliasedEmail =
    cleanId === 'awesomedbz'
      ? 'awesomedbz@gmail.com'
      : cleanId === 'ranma' || cleanId === 'ranmaanimaker'
      ? 'ranmaanimaker@gmail.com'
      : '';
  const candidateEmail = isEmail ? cleanId : (aliasedEmail || `${cleanId}@finalfinance.io`);

  if (!pass || pass.trim().length === 0) {
    return { success: false, error: 'Please enter your password.' };
  }

  const users = getRegisteredUsers();
  const gmailCandidate = isEmail ? cleanId : `${cleanId}@gmail.com`;
  const existing =
    users[candidateEmail] ||
    DEFAULT_USER_REGISTRY[candidateEmail] ||
    users[gmailCandidate] ||
    DEFAULT_USER_REGISTRY[gmailCandidate] ||
    Object.values(users).find((u) => u.email?.trim().toLowerCase() === candidateEmail || u.email?.trim().toLowerCase() === gmailCandidate || u.userId?.toLowerCase() === cleanId) ||
    Object.values(DEFAULT_USER_REGISTRY).find((u) => u.email?.trim().toLowerCase() === candidateEmail || u.email?.trim().toLowerCase() === gmailCandidate || u.userId?.toLowerCase() === cleanId);

  if (existing) {
    if (!verifyStoredPassword(existing, pass)) {
      return { success: false, error: 'Wrong password. Try again or click Forgot password.' };
    }
  } else {
    return { success: false, error: 'No account found with this User ID or Email.' };
  }

  const resolvedEmail = existing.email.trim().toLowerCase();
  const resolvedHandle = existing.userId || cleanId;
  const role = getRoleForEmail(resolvedEmail);
  const demoMatch = Object.values(DEMO_ACCOUNTS).find(
    (d) => d.email.toLowerCase() === resolvedEmail || d.id.toLowerCase() === resolvedHandle.toLowerCase()
  );
  if (role !== 'super_admin' && role !== 'admin') {
    const checkIds = [resolvedEmail, resolvedHandle, cleanId, demoMatch?.id, demoMatch?.uid];
    if (isAccountLocked(checkIds)) {
      return { success: false, error: 'This account is currently locked by an administrator.' };
    }
    if (isAccountDeactivated(checkIds)) {
      return { success: false, error: 'This account has been deactivated. Contact an administrator to reactivate it.' };
    }
  }
  const storedVerification =
    existing?.verification ||
    getStoredVerificationForUser([resolvedEmail, resolvedHandle, cleanId, demoMatch?.id]) ||
    demoMatch?.verification;
  const resolvedTier = getVerificationTierFromDetails(storedVerification, demoMatch?.isVerified);
  const resolvedIsVerified = resolvedTier >= 3;

  const user: AuthSession = {
    uid: demoMatch?.uid || 'user-' + resolvedHandle,
    id: resolvedHandle,
    name: existing?.name || (isEmail ? resolvedEmail.split('@')[0] : cleanId),
    email: resolvedEmail,
    avatarUrl: existing?.avatarUrl || demoMatch?.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(resolvedHandle)}&background=f1f5f9&color=0f172a&size=128`,
    bio: role === 'super_admin' ? 'Super Administrator & Sovereign Reserve Master Keyholder.' : (role === 'admin' ? 'Custody & Escrow Admin Officer.' : 'Final Finance participant.'),
    role: role,
    provider: 'password',
    isVerified: resolvedIsVerified,
    subscriptionActive: Boolean(storedVerification?.subscriptionActive && resolvedTier >= 3),
    verification: storedVerification,
    user: {
      name: existing?.name || (isEmail ? resolvedEmail.split('@')[0] : cleanId),
      email: resolvedEmail,
      avatar: existing?.avatarUrl || demoMatch?.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(resolvedHandle)}&background=f1f5f9&color=0f172a&size=128`
    }
  };
  saveSession(user);
  if (options?.rememberOnDevice !== false) {
    rememberAccountOnDevice(user);
  }
  void storeBrowserCredential(resolvedEmail, pass, user.name, user.avatarUrl);
  return { success: true, user };
}

export async function registerWithCredentials(data: {
  fullName: string;
  userId: string;
  email: string;
  password?: string;
}): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const email = data.email.trim().toLowerCase();
  const pass = (data.password || '').trim();

  if (!pass || pass.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters long.' };
  }

  const initialVerification: VerificationDetails = {
    tier: 0,
    verified: false,
    status: 'unverified',
    monthlyFee: 0,
    subscriptionActive: false,
    subscriptionPlan: 'Unverified (Tier 0)',
    idDocument1Type: '',
    idDocument1Name: '',
    idDocument2Type: '',
    idDocument2Name: ''
  };

  saveRegisteredUser({
    email,
    passwordHash: pass,
    name: data.fullName.trim(),
    userId: data.userId.trim().toLowerCase(),
    avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.fullName)}&background=f1f5f9&color=0f172a&size=128`,
    isVerified: false,
    verification: initialVerification,
  });

  const role = getRoleForEmail(email);

  const user: AuthSession = {
    uid: 'user-' + data.userId,
    id: data.userId,
    name: data.fullName,
    email: email,
    avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.fullName)}&background=f1f5f9&color=0f172a&size=128`,
    bio: role === 'super_admin' ? 'Super Administrator & Sovereign Reserve Master Keyholder.' : (role === 'admin' ? 'Custody & Escrow Admin Officer.' : 'Ecosystem participant.'),
    role: role,
    provider: 'password',
    isVerified: false,
    subscriptionActive: false,
    verification: initialVerification,
    user: {
      name: data.fullName,
      email: email,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.fullName)}&background=f1f5f9&color=0f172a&size=128`
    }
  };
  saveSession(user);

  // Initialize user wallet store cleanly (signup AFNL grant requires Tier 1+ ID verification)
  try {
    const wallet = getStoredUserWallets(data.userId);
    saveStoredUserWallets(data.userId, wallet);
  } catch (err) {
    console.warn('Failed to initialize wallet', err);
  }

  return { success: true, user };
}

export async function requestPasswordReset(identifier: string): Promise<{ success: boolean; emailSentTo?: string; error?: string }> {
  return { success: true, emailSentTo: identifier.includes('@') ? identifier : `${identifier}@domain.com` };
}

export function checkUserIdAvailability(
  newUserId: string,
  currentUserId?: string
): { available: boolean; message?: string } {
  const clean = (newUserId || '').trim().toLowerCase().replace(/^@/, '');
  const cleanCurrent = (currentUserId || '').trim().toLowerCase().replace(/^@/, '');

  if (!clean) {
    return { available: false, message: 'User ID handle is required.' };
  }
  if (clean.length < 3) {
    return { available: false, message: 'User ID must be at least 3 characters.' };
  }
  if (!/^[a-z0-9_.-]+$/.test(clean)) {
    return { available: false, message: 'User ID can only contain letters, numbers, underscores, dashes, and periods.' };
  }
  if (clean === cleanCurrent) {
    return { available: true, message: 'Current User ID' };
  }

  // Check registered accounts
  const registered = getRegisteredUsers();
  for (const acc of Object.values(registered)) {
    if (acc.userId && acc.userId.toLowerCase().replace(/^@/, '') === clean) {
      return { available: false, message: `@${clean} is already taken.` };
    }
  }

  // Check demo accounts
  for (const acc of Object.values(DEMO_ACCOUNTS)) {
    if (acc.id && acc.id.toLowerCase().replace(/^@/, '') === clean) {
      return { available: false, message: `@${clean} is already taken.` };
    }
  }

  // Check known sample handles
  const knownHandles = [
    'jordan_belfort',
    'satoshi_nakamoto',
    'alex_morgan',
    'guest_trader',
    'super_admin_ranma',
    'officer_dbz',
    'sterling_vault',
    'elena_rostova',
    'marcus_vance'
  ];
  if (knownHandles.includes(clean)) {
    return { available: false, message: `@${clean} is already taken.` };
  }

  return { available: true, message: `@${clean} is available!` };
}

export function checkEmailAvailability(
  newEmail: string,
  currentEmail?: string
): { available: boolean; message?: string } {
  const clean = (newEmail || '').trim().toLowerCase();
  const cleanCurrent = (currentEmail || '').trim().toLowerCase();

  if (!clean) {
    return { available: false, message: 'Email address is required.' };
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean)) {
    return { available: false, message: 'Invalid email address format.' };
  }
  if (clean === cleanCurrent) {
    return { available: true, message: 'Current Email' };
  }

  // Check registered accounts
  const registered = getRegisteredUsers();
  if (registered[clean]) {
    return { available: false, message: 'This email is already registered.' };
  }

  // Check demo accounts
  for (const acc of Object.values(DEMO_ACCOUNTS)) {
    if (acc.email && acc.email.toLowerCase() === clean) {
      return { available: false, message: 'This email is already registered.' };
    }
  }

  return { available: true, message: 'Email is available!' };
}

export async function updateUserAccountProfile(data: {
  fullName?: string;
  userId?: string;
  avatarUrl?: string;
  coverUrl?: string;
  bio?: string;
  gender?: 'male' | 'female' | 'other' | '';
  email?: string;
  newPassword?: string;
  isPrivate?: boolean;
}): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const current = getCurrentSession();
  const cleanUserId = (data.userId !== undefined ? data.userId : (current?.id || '')).trim().toLowerCase().replace(/^@/, '');
  const cleanEmail = (data.email !== undefined ? data.email : (current?.email || '')).trim().toLowerCase();

  // Validate User ID availability if changed
  if (current && cleanUserId && cleanUserId !== current.id.toLowerCase().replace(/^@/, '')) {
    const idCheck = checkUserIdAvailability(cleanUserId, current.id);
    if (!idCheck.available) {
      return { success: false, error: idCheck.message || 'User ID is unavailable.' };
    }
  }

  // Validate Email availability if changed
  if (current && cleanEmail && current.email && cleanEmail !== current.email.toLowerCase()) {
    const emailCheck = checkEmailAvailability(cleanEmail, current.email);
    if (!emailCheck.available) {
      return { success: false, error: emailCheck.message || 'Email is unavailable.' };
    }
  }

  const updated: AuthSession = {
    ...current,
    name: data.fullName !== undefined ? (data.fullName.trim() || current?.name || 'Citizen') : (current?.name || 'Citizen'),
    id: cleanUserId || current?.id || 'citizen',
    avatarUrl: data.avatarUrl !== undefined ? data.avatarUrl : (current?.avatarUrl || ''),
    coverUrl: data.coverUrl !== undefined ? data.coverUrl : (current?.coverUrl || ''),
    bio: data.bio !== undefined ? data.bio : (current?.bio || ''),
    gender: data.gender !== undefined ? data.gender : (current?.gender || ''),
    email: cleanEmail || current?.email || '',
    isPrivate: data.isPrivate !== undefined ? data.isPrivate : (current?.isPrivate || false),
    user: {
      name: data.fullName !== undefined ? (data.fullName.trim() || current?.name || 'Citizen') : (current?.name || 'Citizen'),
      email: cleanEmail || current?.email || '',
      avatar: data.avatarUrl !== undefined ? data.avatarUrl : (current?.avatarUrl || '')
    }
  };

  // Sync with registered users
  const registered = getRegisteredUsers();
  const oldEmail = current?.email?.toLowerCase() || '';
  if (oldEmail && registered[oldEmail]) {
    const existing = registered[oldEmail];
    delete registered[oldEmail];
    registered[cleanEmail] = {
      ...existing,
      email: cleanEmail,
      name: updated.name,
      userId: updated.id,
      avatarUrl: updated.avatarUrl || '',
      passwordHash: data.newPassword ? data.newPassword.trim() : existing.passwordHash,
    };
    try {
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(registered));
    } catch {}
  } else if (cleanEmail) {
    saveRegisteredUser({
      email: cleanEmail,
      passwordHash: data.newPassword ? data.newPassword.trim() : 'password123',
      name: updated.name,
      userId: updated.id,
      avatarUrl: updated.avatarUrl || '',
    });
  }

  saveSession(updated);
  return { success: true, user: updated };
}

export async function verifyUserWithTier(data: {
  targetTier: 1 | 2 | 3;
  idDocument1Type: string;
  idDocument1Name: string;
  idDocument1Number?: string;
  idDocument2Type?: string;
  idDocument2Name?: string;
  idDocument2Number?: string;
  idDocument2Issuer?: string;
  paymentMethod?: string;
  lastFour?: string;
}): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found. Please sign in.' };
  }

  const prev = current.verification;
  const doc1Type = data.idDocument1Type || prev?.idDocument1Type || '';
  const doc1Name = data.idDocument1Name || prev?.idDocument1Name || '';
  const doc1Number = data.idDocument1Number || prev?.idDocument1Number || '';
  const doc2Type = data.targetTier >= 2 ? (data.idDocument2Type || prev?.idDocument2Type || '') : '';
  const doc2Name = data.targetTier >= 2 ? (data.idDocument2Name || prev?.idDocument2Name || '') : '';
  const doc2Number = data.targetTier >= 2 ? (data.idDocument2Number || prev?.idDocument2Number || '') : '';
  const doc2Issuer = data.targetTier >= 2 ? (data.idDocument2Issuer || prev?.idDocument2Issuer || '') : '';

  if (!doc1Type || !doc1Name || !doc1Number.trim()) {
    return { success: false, error: 'Tier 1 requires Legal ID #1 document, ID number, and uploaded file.' };
  }
  if (data.targetTier >= 2 && (!doc2Type || !doc2Name || !doc2Number.trim())) {
    return { success: false, error: 'Tier 2 and Tier 3 require 2 distinct Legal IDs with valid ID numbers.' };
  }

  const duplicateCheck = checkLegalIdsDuplicateAcrossPlatform({
    currentIdentifiers: [current.id, current.uid, current.handle, current.email],
    doc1Number,
    doc1Type,
    doc2Number: data.targetTier >= 2 ? doc2Number : undefined,
    doc2Type: data.targetTier >= 2 ? doc2Type : undefined
  });
  if (duplicateCheck.isDuplicate) {
    return {
      success: false,
      error:
        duplicateCheck.error ||
        'Verification blocked: That user already exists in our platform. Users cannot have multiple accounts.'
    };
  }

  const nextMonth = new Date();
  nextMonth.setMonth(nextMonth.getMonth() + 1);

  const isTier3 = data.targetTier === 3;
  const tierStatus: VerificationDetails['status'] =
    data.targetTier === 3 ? 'verified' : data.targetTier === 2 ? 'tier2' : 'tier1';
  const planName =
    data.targetTier === 3
      ? 'Tier 3 · Verified User ($2.00/month)'
      : data.targetTier === 2
      ? 'Tier 2 · 2 Legal IDs (Driver & Merchant Owner)'
      : 'Tier 1 · 1 Legal ID (Admin Final Coin Eligible)';

  const verificationDetails: VerificationDetails = {
    tier: data.targetTier as VerificationTier,
    verified: isTier3,
    status: tierStatus,
    monthlyFee: isTier3 ? 2 : 0,
    subscriptionActive: isTier3,
    subscriptionPlan: planName,
    idDocument1Type: doc1Type,
    idDocument1Name: doc1Name,
    idDocument1Number: doc1Number.trim(),
    idDocument2Type: doc2Type,
    idDocument2Name: doc2Name,
    idDocument2Number: doc2Number.trim() || undefined,
    idDocument2Issuer: doc2Issuer || (doc2Name ? 'Issued & Authenticated' : ''),
    verifiedAt: new Date().toISOString(),
    nextBillingDate: isTier3 ? nextMonth.toISOString() : undefined,
    subscriptionExpiresAt: isTier3 ? nextMonth.toISOString() : undefined,
    subscriptionCancelled: false,
    paymentMethod: isTier3 ? (data.paymentMethod || 'Visa ending in 4242') : undefined,
    lastFour: isTier3 ? (data.lastFour || '4242') : undefined
  };

  const updated: AuthSession = {
    ...current,
    isVerified: isTier3,
    subscriptionActive: isTier3,
    verification: verificationDetails
  };

  // Persist into registered users map as well
  const registered = getRegisteredUsers();
  const cleanEmail = current.email?.toLowerCase().trim();
  if (cleanEmail && registered[cleanEmail]) {
    saveRegisteredUser({
      ...registered[cleanEmail],
      isVerified: isTier3,
      verification: verificationDetails
    });
  }

  registerClaimedLegalIdsForUser(
    [current.id, current.uid, current.handle, current.email],
    verificationDetails
  );
  saveStoredVerificationForUser(
    [current.id, current.uid, current.handle, current.email],
    verificationDetails
  );
  saveSession(updated);
  return { success: true, user: updated };
}

export async function verifyUserWithSubscription(data: {
  idDocument1Type: string;
  idDocument1Name: string;
  idDocument1Number?: string;
  idDocument2Type: string;
  idDocument2Name: string;
  idDocument2Issuer?: string;
  paymentMethod: string;
  lastFour?: string;
}): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  return verifyUserWithTier({
    targetTier: 3,
    ...data
  });
}

export async function cancelUserSubscription(): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found.' };
  }

  const currentVerif = current.verification;
  const verifiedTime = currentVerif?.verifiedAt ? new Date(currentVerif.verifiedAt).getTime() : Date.now();
  const defaultExpires = new Date(verifiedTime + 30 * 24 * 60 * 60 * 1000);
  const expiresAt = currentVerif?.subscriptionExpiresAt ? new Date(currentVerif.subscriptionExpiresAt) : defaultExpires;

  const cancelledVerification: VerificationDetails = currentVerif
    ? {
        ...currentVerif,
        tier: 3,
        verified: true,
        status: 'verified',
        monthlyFee: 2,
        subscriptionActive: true,
        subscriptionCancelled: true,
        subscriptionExpiresAt: expiresAt.toISOString(),
        subscriptionPlan: 'Tier 3 · Verified User (Subscription Cancelled - Active until expiry)'
      }
    : {
        tier: 3,
        verified: true,
        status: 'verified',
        monthlyFee: 2,
        subscriptionActive: true,
        subscriptionCancelled: true,
        subscriptionExpiresAt: defaultExpires.toISOString(),
        subscriptionPlan: 'Tier 3 · Verified User (Subscription Cancelled - Active until expiry)',
        idDocument1Type: 'Legal ID',
        idDocument1Name: current.name,
        idDocument2Type: 'Secondary ID',
        idDocument2Name: current.name
      };

  const updated: AuthSession = {
    ...current,
    isVerified: true,
    subscriptionActive: true,
    verification: cancelledVerification
  };

  saveStoredVerificationForUser(
    [current.id, current.uid, current.handle, current.email],
    cancelledVerification
  );
  const registered = getRegisteredUsers();
  const cleanEmail = current.email?.toLowerCase().trim();
  if (cleanEmail && registered[cleanEmail]) {
    saveRegisteredUser({
      ...registered[cleanEmail],
      isVerified: true,
      verification: cancelledVerification
    });
  }

  saveSession(updated);
  return { success: true, user: updated };
}

export async function resumeUserSubscription(): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found.' };
  }

  const currentVerif = current.verification;
  const resumedVerification: VerificationDetails = currentVerif
    ? {
        ...currentVerif,
        tier: 3,
        verified: true,
        status: 'verified',
        monthlyFee: 2,
        subscriptionActive: true,
        subscriptionCancelled: false,
        subscriptionPlan: 'Tier 3 · Verified User ($2.00/month)'
      }
    : {
        tier: 3,
        verified: true,
        status: 'verified',
        monthlyFee: 2,
        subscriptionActive: true,
        subscriptionCancelled: false,
        subscriptionPlan: 'Tier 3 · Verified User ($2.00/month)',
        idDocument1Type: 'Legal ID',
        idDocument1Name: current.name,
        idDocument2Type: 'Secondary ID',
        idDocument2Name: current.name
      };

  const updated: AuthSession = {
    ...current,
    isVerified: true,
    subscriptionActive: true,
    verification: resumedVerification
  };

  saveStoredVerificationForUser(
    [current.id, current.uid, current.handle, current.email],
    resumedVerification
  );
  const registered = getRegisteredUsers();
  const cleanEmail = current.email?.toLowerCase().trim();
  if (cleanEmail && registered[cleanEmail]) {
    saveRegisteredUser({
      ...registered[cleanEmail],
      isVerified: true,
      verification: resumedVerification
    });
  }

  saveSession(updated);
  return { success: true, user: updated };
}

export async function signOut(): Promise<void> {
  clearSession();
}

export async function deactivateUserAccount(): Promise<{ success: boolean; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found.' };
  }
  const email = (current.email || '').toLowerCase().trim();
  const adminMatches = getAdminMembers().find(
    (m) =>
      (email && m.email.toLowerCase() === email) ||
      m.handle.toLowerCase().replace(/^@/, '') === (current.id || '').toLowerCase().replace(/^@/, '')
  );
  const resolvedRole: 'user' | 'admin' | 'super_admin' | 'guest' =
    current.role === 'super_admin' || current.role === 'admin'
      ? current.role
      : adminMatches
      ? adminMatches.role
      : getRoleForEmail(email);

  markAccountSelfDeactivated({
    uid: current.uid,
    id: current.id,
    userId: current.id,
    name: current.name,
    email,
    avatarUrl: current.avatarUrl,
    role: resolvedRole,
  });

  if (resolvedRole === 'admin' || resolvedRole === 'super_admin') {
    markAdminSelfDeactivatedInDirectory({
      id: current.id,
      uid: current.uid,
      userId: current.id,
      name: current.name,
      email,
      role: resolvedRole,
    });
  }

  markPresenceOffline(current);
  const registered = getRegisteredUsers();
  if (email && registered[email]) {
    registered[email] = {
      ...registered[email],
    };
    try {
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(registered));
    } catch {}
  }
  clearSession();
  return { success: true };
}

export async function deleteUserAccount(): Promise<{ success: boolean; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found.' };
  }
  const email = (current.email || '').toLowerCase().trim();
  const adminMatches = getAdminMembers().find(
    (m) =>
      (email && m.email.toLowerCase() === email) ||
      m.handle.toLowerCase().replace(/^@/, '') === (current.id || '').toLowerCase().replace(/^@/, '')
  );
  const resolvedRole: 'user' | 'admin' | 'super_admin' | 'guest' =
    current.role === 'super_admin' || current.role === 'admin'
      ? current.role
      : adminMatches
      ? adminMatches.role
      : getRoleForEmail(email);

  recordDeletedAccount({
    uid: current.uid,
    id: current.id,
    userId: current.id,
    name: current.name,
    email,
    avatarUrl: current.avatarUrl,
    role: resolvedRole,
    jobTitle: adminMatches?.jobTitle,
  });

  if (resolvedRole === 'admin' || resolvedRole === 'super_admin') {
    removeDeletedAdminFromDirectory({
      id: current.id,
      userId: current.id,
      email,
    });
  }

  markPresenceOffline(current);
  const registered = getRegisteredUsers();
  if (email && registered[email]) {
    delete registered[email];
    try {
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(registered));
    } catch {}
  }
  releaseClaimedLegalIdsForUser([current.id, current.uid, current.handle, current.email]);
  try {
    localStorage.removeItem(`final_finance_wallets_${current.id}`);
  } catch {}
  clearSession();
  return { success: true };
}

