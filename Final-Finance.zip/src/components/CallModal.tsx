import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  PhoneOff,
  Video,
  VideoOff,
  Mic,
  MicOff,
  Maximize2,
  Minimize2,
  Monitor,
  Sparkles,
  ShieldCheck,
  AlertCircle,
  MessageSquare,
  Send,
  Hand,
  X,
  Check,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { addCallLog } from '../services/callLogService';
import { areUsersBlockedEitherWay, areUsersFriends, isMerchantAccount } from '../services/socialService';

export type CallType = 'voice' | 'video';
export type CallStatus = 'ringing' | 'connected' | 'ended';

export interface CallParticipant {
  uid: string;
  userId: string;
  name: string;
  avatarUrl?: string;
  isMuted?: boolean;
  isSpeaking?: boolean;
  handRaised?: boolean;
  role?: string;
}

export interface InCallChatMessage {
  id: string;
  senderName: string;
  senderUid: string;
  text: string;
  time: string;
}

interface CallModalProps {
  isOpen: boolean;
  callType: CallType;
  currentUser?: AuthSession | null;
  // 1-on-1 Direct Call
  remoteUser?: CallParticipant;
  targetUser?: CallParticipant;
  // Multi-Conference Group Call
  isGroupCall?: boolean;
  isGroup?: boolean;
  groupName?: string;
  groupParticipants?: CallParticipant[];
  voiceOnly?: boolean;
  allowNonFriend?: boolean;
  backLabel?: string;
  onClose: (durationSeconds?: number) => void;
}

const VIRTUAL_BACKGROUNDS = [
  { id: 'none', label: 'Default', icon: '🌆' },
  { id: 'blur', label: 'Studio Blur', icon: '✨' },
  { id: 'zurich', label: 'Zurich Vault', icon: '🏛️' },
  { id: 'gold', label: 'Gold Depository', icon: '🪙' },
  { id: 'cyber', label: 'AI Compute Pod', icon: '⚡' },
];

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  callType: initialCallType,
  currentUser,
  remoteUser: propRemoteUser,
  targetUser: propTargetUser,
  voiceOnly = false,
  allowNonFriend = false,
  backLabel,
  onClose,
}) => {
  const remoteUser = propRemoteUser || propTargetUser;

  const effectiveInitialType: CallType = voiceOnly ? 'voice' : initialCallType;
  const [callType, setCallType] = useState<CallType>(effectiveInitialType);
  const [status, setStatus] = useState<CallStatus>('ringing');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(effectiveInitialType === 'voice');
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [duration, setDuration] = useState(0);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  // In-Call Chat Drawer State
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [inCallMessages, setInCallMessages] = useState<InCallChatMessage[]>([
    {
      id: 'ic-1',
      senderName: 'System Bot',
      senderUid: 'system',
      text: 'Encrypted 1-on-1 call established. Only one person can be called at a time.',
      time: 'Just now',
    }
  ]);
  const [inCallInput, setInCallInput] = useState('');

  // Virtual Background Filter
  const [selectedBackground, setSelectedBackground] = useState('none');
  const [showBgMenu, setShowBgMenu] = useState(false);

  // Raise Hand
  const [isHandRaised, setIsHandRaised] = useState(false);

  // Live Floating Reactions
  const [floatingReactions, setFloatingReactions] = useState<Array<{ id: number; emoji: string; left: number }>>([]);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const ringOscillatorRef = useRef<{ stop: () => void } | null>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Keyboard shortcut listener (ESC to end call)
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleEndCall();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, duration]);

  const activeUid = currentUser?.uid || currentUser?.id || 'guest';

  // Sync initial call type
  useEffect(() => {
    const resolvedType: CallType = voiceOnly ? 'voice' : initialCallType;
    setCallType(resolvedType);
    setIsVideoOff(resolvedType === 'voice');
  }, [initialCallType, voiceOnly]);

  // Ringtone generator
  const playRingtone = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      
      const ctx = new AudioContextClass();
      audioContextRef.current = ctx;

      let isRunning = true;
      const ringCycle = () => {
        if (!isRunning || ctx.state === 'closed') return;
        try {
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gain = ctx.createGain();

          osc1.type = 'sine';
          osc2.type = 'sine';
          osc1.frequency.setValueAtTime(440, ctx.currentTime);
          osc2.frequency.setValueAtTime(480, ctx.currentTime);

          gain.gain.setValueAtTime(0.04, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.8);

          osc1.connect(gain);
          osc2.connect(gain);
          gain.connect(ctx.destination);

          osc1.start();
          osc2.start();
          osc1.stop(ctx.currentTime + 1.8);
          osc2.stop(ctx.currentTime + 1.8);
        } catch {
          // ignore
        }
      };

      ringCycle();
      const interval = setInterval(ringCycle, 3500);

      ringOscillatorRef.current = {
        stop: () => {
          isRunning = false;
          clearInterval(interval);
          try {
            ctx.close();
          } catch {
            // ignore
          }
        }
      };
    } catch {
      // Audio restricted before gesture
    }
  };

  const stopRingtone = () => {
    if (ringOscillatorRef.current) {
      ringOscillatorRef.current.stop();
      ringOscillatorRef.current = null;
    }
  };

  // Start media stream (Camera/Mic)
  const initLocalMedia = async (needVideo: boolean) => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setPermissionError('Camera/Microphone not available in this browser environment');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: needVideo ? { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' } : false,
      });

      localStreamRef.current = stream;
      if (localVideoRef.current && needVideo) {
        localVideoRef.current.srcObject = stream;
      }
      setPermissionError(null);
    } catch (err: unknown) {
      const e = err as Error;
      setPermissionError(e?.message || 'Camera/Mic running in interactive simulation mode.');
    }
  };

  // Setup Call Flow on open
  useEffect(() => {
    if (!isOpen) {
      stopRingtone();
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((t) => t.stop());
        localStreamRef.current = null;
      }
      setStatus('ringing');
      setDuration(0);
      setPermissionError(null);
      return;
    }

    if (currentUser && remoteUser) {
      const isBlocked =
        areUsersBlockedEitherWay(currentUser.uid, remoteUser.uid) ||
        areUsersBlockedEitherWay(currentUser.id, remoteUser.userId) ||
        areUsersBlockedEitherWay(currentUser.uid, remoteUser.userId) ||
        areUsersBlockedEitherWay(currentUser.id, remoteUser.uid);
      const isDirectFriend =
        areUsersFriends(currentUser.uid, remoteUser.uid) ||
        areUsersFriends(currentUser.id, remoteUser.userId) ||
        areUsersFriends(currentUser.uid, remoteUser.userId) ||
        areUsersFriends(currentUser.id, remoteUser.uid);
      const isExplicitNonFriendVoiceAllowed =
        initialCallType === 'voice' &&
        (allowNonFriend || isMerchantAccount(remoteUser.uid, remoteUser.userId));
      const isFriendOrAllowed =
        isDirectFriend ||
        isExplicitNonFriendVoiceAllowed;
      if (isBlocked || !isFriendOrAllowed) {
        stopRingtone();
        onClose(0);
        return;
      }
    }

    setStatus('ringing');
    setDuration(0);
    setPermissionError(null);
    playRingtone();

    initLocalMedia(!voiceOnly && initialCallType === 'video');

    const connectTimer = setTimeout(() => {
      stopRingtone();
      setStatus('connected');
    }, 2200);

    return () => {
      clearTimeout(connectTimer);
      stopRingtone();
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((t) => t.stop());
        localStreamRef.current = null;
      }
    };
  }, [isOpen, initialCallType, voiceOnly, allowNonFriend]);

  // Duration Timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (status === 'connected') {
      timer = setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [status]);

  // Scroll in-call chat to bottom
  useEffect(() => {
    chatScrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [inCallMessages]);

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const handleToggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      if (localStreamRef.current) {
        localStreamRef.current.getAudioTracks().forEach((t) => {
          t.enabled = !next;
        });
      }
      return next;
    });
  };

  const handleToggleVideo = async () => {
    if (voiceOnly) return;
    if (isVideoOff) {
      setIsVideoOff(false);
      setCallType('video');
      if (!localStreamRef.current || localStreamRef.current.getVideoTracks().length === 0) {
        await initLocalMedia(true);
      } else {
        localStreamRef.current.getVideoTracks().forEach((t) => {
          t.enabled = true;
        });
      }
    } else {
      setIsVideoOff(true);
      if (localStreamRef.current) {
        localStreamRef.current.getVideoTracks().forEach((t) => {
          t.enabled = false;
        });
      }
    }
  };

  const handleToggleScreenShare = async () => {
    if (voiceOnly) return;
    if (!isScreenSharing) {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
          const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
          setIsScreenSharing(true);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = screenStream;
          }
          screenStream.getVideoTracks()[0].onended = () => {
            setIsScreenSharing(false);
            if (localStreamRef.current && localVideoRef.current) {
              localVideoRef.current.srcObject = localStreamRef.current;
            }
          };
        }
      } catch {
        // User cancelled
      }
    } else {
      setIsScreenSharing(false);
      if (localStreamRef.current && localVideoRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
      }
    }
  };

  const handleSendReaction = (emoji: string) => {
    const id = Date.now();
    const left = Math.floor(Math.random() * 80) + 10;
    setFloatingReactions((prev) => [...prev, { id, emoji, left }]);
    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((r) => r.id !== id));
    }, 2200);
  };

  const handleSendInCallMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inCallInput.trim()) return;

    const newMsg: InCallChatMessage = {
      id: `ic-${Date.now()}`,
      senderName: currentUser?.name || 'You',
      senderUid: activeUid,
      text: inCallInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setInCallMessages((prev) => [...prev, newMsg]);
    setInCallInput('');
  };

  const handleEndCall = () => {
    stopRingtone();
    const prevStatus = status;
    setStatus('ended');
    const finalDuration = duration;

    // Record 1-on-1 Call in Persistent Call Log Store
    try {
      const finalCallStatus = finalDuration > 0 ? 'completed' : (prevStatus === 'ringing' ? 'cancelled' : 'declined');
      const targetDisplayName = remoteUser?.name || 'Peer Counterparty';

      addCallLog({
        type: callType,
        scope: 'direct',
        direction: 'outgoing',
        status: finalCallStatus,
        targetName: targetDisplayName,
        targetHandle: remoteUser?.userId || remoteUser?.uid,
        targetAvatarUrl: remoteUser?.avatarUrl,
        targetUid: remoteUser?.uid,
        participantsCount: 2,
        participants: [
          { uid: currentUser?.uid || 'me', name: currentUser?.name || 'You', avatarUrl: currentUser?.avatarUrl },
          { uid: remoteUser?.uid || 'peer', name: remoteUser?.name || 'Peer', avatarUrl: remoteUser?.avatarUrl }
        ],
        initiatedBy: {
          uid: currentUser?.uid || 'me',
          name: currentUser?.name || 'You',
          avatarUrl: currentUser?.avatarUrl
        },
        durationSeconds: finalDuration,
      });
    } catch (err) {
      console.error('Failed to log call entry:', err);
    }

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => {
        t.stop();
      });
      localStreamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch {
        // ignore
      }
    }
    onClose(finalDuration);
  };

  if (!isOpen) return null;

  return (
    <div
      id="call-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className={`w-full ${
          isFullscreen ? 'fixed inset-0 rounded-none' : 'max-w-6xl rounded-3xl'
        } bg-neutral-950 border border-neutral-800 text-white shadow-2xl overflow-hidden flex flex-col relative aspect-[16/10] max-h-[94vh] transition-all`}
      >
        {/* ================= TOP COMMAND BAR ================= */}
        <div className="absolute top-0 left-0 right-0 p-3 sm:p-4 flex items-center justify-between z-30 bg-gradient-to-b from-black/90 via-black/50 to-transparent">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={handleEndCall}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
              title={backLabel || 'Back'}
            >
              <span className="truncate max-w-[160px]">{backLabel || 'Back'}</span>
              <ArrowRight className="w-3.5 h-3.5 shrink-0" />
            </button>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] text-neutral-300">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span className="hidden sm:inline">E2E Sovereign Encrypted</span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* In-Call Chat Button */}
            <button
              type="button"
              onClick={() => setIsChatOpen(!isChatOpen)}
              className={`p-2 rounded-xl border transition-colors cursor-pointer relative ${
                isChatOpen
                  ? 'bg-blue-600 border-blue-500 text-white'
                  : 'bg-white/10 border-white/10 hover:bg-white/20 text-white'
              }`}
              title="Open In-Call Messenger"
            >
              <MessageSquare className="w-4 h-4" />
              {inCallMessages.length > 1 && !isChatOpen && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping" />
              )}
            </button>

            {/* Fullscreen */}
            <button
              type="button"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white transition-colors cursor-pointer"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Direct End Call Button (Always accessible at top right) */}
            <button
              id="btn-top-end-call"
              type="button"
              onClick={handleEndCall}
              className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md ml-1 active:scale-95"
              title="End Call"
            >
              <PhoneOff className="w-3.5 h-3.5" />
              <span>End Call</span>
            </button>
          </div>
        </div>

        {/* Floating Reactions Overlay */}
        <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
          <AnimatePresence>
            {floatingReactions.map((r) => (
              <motion.div
                key={r.id}
                initial={{ opacity: 1, y: 300, scale: 0.8 }}
                animate={{ opacity: 0, y: -160, scale: 1.6 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 2, ease: 'easeOut' }}
                style={{ left: `${r.left}%` }}
                className="absolute bottom-20 text-5xl select-none"
              >
                {r.emoji}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* ================= MAIN CALL AREA WITH SIDEBAR CHAT ================= */}
        <div className="flex-1 flex overflow-hidden relative">
          {/* VIDEO / AUDIO STAGE */}
          <div className="flex-1 relative flex items-center justify-center bg-neutral-900 overflow-hidden p-2 sm:p-4">
            {permissionError && (
              <div className="absolute bottom-24 left-4 z-30 max-w-xs sm:max-w-sm px-3 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs flex items-center gap-2 backdrop-blur-md shadow-lg">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                <span className="truncate flex-1">{permissionError}</span>
                <button
                  type="button"
                  onClick={() => setPermissionError(null)}
                  className="p-0.5 rounded-md hover:bg-amber-500/20 text-amber-300 hover:text-white cursor-pointer shrink-0"
                  title="Dismiss notice"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* 1-ON-1 DIRECT CALL */}
            <div className="relative w-full h-full flex items-center justify-center pt-12 pb-20">
              {callType === 'video' && status === 'connected' && (
                <div className="absolute inset-0 flex items-center justify-center bg-neutral-950">
                  {/* Simulated Remote Video Feed with Studio Backdrop */}
                  <div className="w-full h-full relative overflow-hidden flex flex-col items-center justify-center bg-gradient-to-b from-neutral-800 to-neutral-950">
                    {remoteUser?.avatarUrl ? (
                      <img
                        src={remoteUser.avatarUrl}
                        alt={remoteUser.name}
                        className="w-32 h-32 sm:w-40 sm:h-40 rounded-full object-cover border-4 border-white/20 shadow-2xl"
                      />
                    ) : (
                      <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full bg-neutral-800 text-white flex items-center justify-center text-4xl font-serif border-4 border-white/20 shadow-2xl">
                        {remoteUser?.name ? remoteUser.name.charAt(0).toUpperCase() : 'U'}
                      </div>
                    )}
                    <span className="text-lg font-bold text-white mt-4">{remoteUser?.name}</span>
                    <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 mt-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      HD 1080p Live Stream
                    </span>
                    <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs font-medium">
                      <span className={`w-2 h-2 rounded-full ${status === 'connected' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400 animate-ping'}`} />
                      <span className="capitalize font-semibold">{callType} Call (1-on-1)</span>
                      <span className="text-neutral-300 font-mono">
                        {status === 'connected' ? formatDuration(duration) : 'Connecting...'}
                      </span>
                    </div>
                  </div>

                  {/* Local PiP Tile */}
                  <div className="absolute bottom-24 right-4 w-28 sm:w-36 aspect-[4/3] rounded-2xl bg-neutral-900 border-2 border-white/20 shadow-2xl overflow-hidden z-20">
                    {!isVideoOff ? (
                      <video
                        ref={localVideoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover -scale-x-100"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs text-neutral-400">
                        Camera Off
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Voice Call Avatar View */}
              {(callType === 'voice' || status === 'ringing') && (
                <div className="flex flex-col items-center justify-center text-center space-y-4">
                  <div className="relative">
                    {remoteUser?.avatarUrl ? (
                      <img
                        src={remoteUser.avatarUrl}
                        alt={remoteUser.name}
                        className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-white/20 shadow-2xl"
                      />
                    ) : (
                      <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-neutral-800 text-white flex items-center justify-center text-3xl font-serif border-4 border-white/20 shadow-2xl">
                        {remoteUser?.name ? remoteUser.name.charAt(0).toUpperCase() : 'U'}
                      </div>
                    )}
                    {status === 'ringing' && (
                      <span className="absolute inset-0 rounded-full border-4 border-emerald-400/50 animate-ping pointer-events-none" />
                    )}
                  </div>

                  <div>
                    <h3 className="text-lg sm:text-xl font-serif font-bold text-white">
                      {remoteUser?.name || 'Ecosystem Member'}
                    </h3>
                    <p className="text-xs font-mono text-neutral-400 mt-0.5">
                      @{remoteUser?.userId || 'member'}
                    </p>
                    <p className="text-xs font-medium text-emerald-400 mt-2">
                      {status === 'ringing' ? 'Ringing sovereign peer...' : 'Voice connected'}
                    </p>
                    <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs font-medium">
                      <span className={`w-2 h-2 rounded-full ${status === 'connected' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400 animate-ping'}`} />
                      <span className="capitalize font-semibold">{callType} Call (1-on-1)</span>
                      <span className="text-neutral-300 font-mono">
                        {status === 'connected' ? formatDuration(duration) : 'Connecting...'}
                      </span>
                    </div>

                    {/* Explicit Ringing Cancel / Decline Button */}
                    {status === 'ringing' && (
                      <div className="mt-4 flex items-center justify-center gap-3">
                        <button
                          id="btn-cancel-ringing-call"
                          type="button"
                          onClick={handleEndCall}
                          className="px-5 py-2.5 rounded-full bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-red-600/40 hover:scale-105 active:scale-95"
                        >
                          <PhoneOff className="w-4 h-4" />
                          <span>Cancel Call</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ================= IN-CALL MESSENGER DRAWER ================= */}
          <AnimatePresence>
            {isChatOpen && (
              <motion.div
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 320, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                className="h-full bg-neutral-900 border-l border-neutral-800 flex flex-col z-30 shrink-0"
              >
                {/* Chat Header */}
                <div className="p-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold text-white">In-Call Messages</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsChatOpen(false)}
                    className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Messages Feed */}
                <div className="flex-1 p-3 overflow-y-auto space-y-2.5">
                  {inCallMessages.map((msg) => {
                    const isMe = msg.senderUid === activeUid;
                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <span className="text-[10px] text-neutral-400 px-1 mb-0.5">
                          {msg.senderName} • {msg.time}
                        </span>
                        <div
                          className={`max-w-[85%] px-3 py-1.5 rounded-2xl text-xs ${
                            isMe
                              ? 'bg-emerald-600 text-white rounded-br-xs'
                              : 'bg-neutral-800 text-neutral-200 rounded-bl-xs'
                          }`}
                        >
                          {msg.text}
                        </div>
                      </div>
                    );
                  })}
                  <div ref={chatScrollRef} />
                </div>

                {/* Chat Input */}
                <form onSubmit={handleSendInCallMessage} className="p-2.5 border-t border-neutral-800 bg-neutral-950 flex items-center gap-2">
                  <input
                    type="text"
                    value={inCallInput}
                    onChange={(e) => setInCallInput(e.target.value)}
                    placeholder="Message counterparty..."
                    className="flex-1 px-3 py-1.5 rounded-xl bg-neutral-800 border border-neutral-700 text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="submit"
                    className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ================= BOTTOM CONTROL DOCK (Facebook Messenger Style) ================= */}
        <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 bg-gradient-to-t from-black/95 via-black/80 to-transparent flex items-center justify-between z-40">
          {/* Left: Quick Emoji Reactions Bar */}
          <div className="flex items-center gap-1 sm:gap-1.5">
            {['❤️', '😆', '😮', '👏', '🔥', '🎉', '👍'].map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => handleSendReaction(emoji)}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white/10 hover:bg-white/20 hover:scale-125 active:scale-95 text-base sm:text-lg flex items-center justify-center transition-all cursor-pointer"
                title={`Send ${emoji}`}
              >
                {emoji}
              </button>
            ))}
          </div>

          {/* Center: Main Calling Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Mic Toggle */}
            <button
              type="button"
              onClick={handleToggleMute}
              className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-white transition-all cursor-pointer shadow-lg ${
                isMuted ? 'bg-red-500 hover:bg-red-600' : 'bg-white/15 hover:bg-white/25'
              }`}
              title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Video Toggle (hidden in Voice-Only calls) */}
            {!voiceOnly && (
              <button
                type="button"
                onClick={handleToggleVideo}
                className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-white transition-all cursor-pointer shadow-lg ${
                  isVideoOff ? 'bg-neutral-700 hover:bg-neutral-600' : 'bg-white/15 hover:bg-white/25 text-emerald-400'
                }`}
                title={isVideoOff ? 'Turn Video On' : 'Turn Video Off'}
              >
                {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
              </button>
            )}

            {/* Screen Share (hidden in Voice-Only calls) */}
            {!voiceOnly && (
              <button
                type="button"
                onClick={handleToggleScreenShare}
                className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-white transition-all cursor-pointer shadow-lg ${
                  isScreenSharing ? 'bg-blue-600 hover:bg-blue-500' : 'bg-white/15 hover:bg-white/25'
                }`}
                title={isScreenSharing ? 'Stop Screen Sharing' : 'Share Screen'}
              >
                <Monitor className="w-5 h-5" />
              </button>
            )}

            {/* Raise Hand Toggle */}
            <button
              type="button"
              onClick={() => setIsHandRaised(!isHandRaised)}
              className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-white transition-all cursor-pointer shadow-lg ${
                isHandRaised ? 'bg-amber-500 text-neutral-950 font-bold' : 'bg-white/15 hover:bg-white/25'
              }`}
              title={isHandRaised ? 'Lower Hand' : 'Raise Hand'}
            >
              <Hand className="w-5 h-5" />
            </button>

            {/* Hang Up / End Call Button */}
            <button
              id="btn-bottom-hangup-call"
              type="button"
              onClick={handleEndCall}
              className="h-11 sm:h-12 px-4 sm:px-5 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center gap-2 font-bold text-xs sm:text-sm transition-all cursor-pointer shadow-xl shadow-red-600/40 hover:scale-105 active:scale-95 ml-2"
              title="End Call"
            >
              <PhoneOff className="w-5 h-5" />
              <span>End Call</span>
            </button>
          </div>

          {/* Right: Background Filters Toggle */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowBgMenu(!showBgMenu)}
              className="px-3 py-2 rounded-full bg-white/10 hover:bg-white/20 text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Effects</span>
            </button>

            {showBgMenu && (
              <div className="absolute bottom-12 right-0 w-48 p-2 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-2xl space-y-1">
                <span className="text-[10px] font-mono uppercase text-neutral-400 px-2 block mb-1">
                  Virtual Backdrops
                </span>
                {VIRTUAL_BACKGROUNDS.map((bg) => (
                  <button
                    key={bg.id}
                    type="button"
                    onClick={() => {
                      setSelectedBackground(bg.id);
                      setShowBgMenu(false);
                    }}
                    className={`w-full p-1.5 rounded-xl text-xs flex items-center justify-between cursor-pointer transition-colors ${
                      selectedBackground === bg.id
                        ? 'bg-emerald-600 text-white'
                        : 'hover:bg-neutral-800 text-neutral-300'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span>{bg.icon}</span>
                      <span>{bg.label}</span>
                    </span>
                    {selectedBackground === bg.id && <Check className="w-3 h-3" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

      </motion.div>
    </div>
  );
};
