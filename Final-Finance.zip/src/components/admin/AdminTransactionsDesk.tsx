import React, { useState } from 'react';
import { 
  Database, 
  Search, 
  RefreshCw, 
  RotateCcw, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Coins, 
  Landmark, 
  History,
  ShieldAlert,
  Download,
  ShoppingBag,
  Car,
  Truck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ConfirmModal } from '../common/ConfirmModal';
import { exportLedgerToCSV } from '../../utils/universalLedgerBridge';

interface AdminTransactionsDeskProps {
  onNotify?: (msg: string, type?: 'success' | 'warning' | 'error') => void;
}

export const AdminTransactionsDesk: React.FC<AdminTransactionsDeskProps> = ({ onNotify }) => {
  const { transactions, reverseTransaction } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, txId: '' });

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      if (onNotify) onNotify('Transactions ledger synchronized with mainnet.', 'success');
    }, 800);
  };

  const handleExportCSV = () => {
    exportLedgerToCSV(filteredTransactions, 'Sovereign_Global_System_Ledger.csv');
    if (onNotify) onNotify('Exported Global System Ledger to CSV.', 'success');
  };

  const handleReverse = (txId: string) => {
    setConfirmModal({ isOpen: true, txId });
  };

  const executeReverse = () => {
    reverseTransaction(confirmModal.txId);
    setConfirmModal({ ...confirmModal, isOpen: false });
  };

  const isDividendTx = (tx: any) =>
    (tx.type === 'dividend' && tx.category !== 'transfer' && tx.taxClassification?.formMapping !== 'Sovereign Grant') ||
    tx.category === 'income_yield' ||
    tx.taxClassification?.formMapping === 'Form 1099-DIV';

  const getTxTimeMs = (tx: any): number => {
    if (tx.timestamp === 'Just now') return Date.now();
    const iso = tx.dateIso ? new Date(tx.dateIso).getTime() : NaN;
    if (!isNaN(iso)) return iso;
    const ts = tx.timestamp ? new Date(String(tx.timestamp).replace(' UTC', 'Z')).getTime() : NaN;
    return !isNaN(ts) ? ts : 0;
  };

  const filteredTransactions = [...transactions]
    .sort((a, b) => getTxTimeMs(b) - getTxTimeMs(a))
    .filter(tx => {
      const q = searchQuery.toLowerCase();
      return (
        (tx.id || '').toLowerCase().includes(q) ||
        (tx.receiptNumber || '').toLowerCase().includes(q) ||
        (tx.category || '').toLowerCase().includes(q) ||
        (tx.counterpartyOrIssuer || '').toLowerCase().includes(q) ||
        (tx.issuerHandle || '').toLowerCase().includes(q) ||
        (tx.sourceOrDestination || '').toLowerCase().includes(q) ||
        (tx.title || '').toLowerCase().includes(q) ||
        (tx.description || '').toLowerCase().includes(q) ||
        (tx.stockTicker || '').toLowerCase().includes(q) ||
        (tx.type || '').toLowerCase().includes(q) ||
        (tx.taxClassification?.formMapping || '').toLowerCase().includes(q)
      );
    });

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'Settled': 
      case 'Confirmed': 
      case 'Audited':
      case 'completed':
        return 'bg-emerald-100 text-emerald-800';
      case 'Reversed':
      case 'reversed':
        return 'bg-rose-100 text-rose-800';
      case 'pending': 
      case 'Pending Open':
        return 'bg-amber-100 text-amber-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'dividend':
      case 'staking_reward':
        return <Coins className="w-4 h-4 text-emerald-600" />;
      case 'p2p_transfer':
      case 'transfer': 
      case 'deposit':
      case 'crypto_deposit':
      case 'card_topup':
      case 'vault_deposit':
        return <ArrowDownLeft className="w-4 h-4 text-blue-500" />;
      case 'bank_withdraw':
      case 'vault_withdrawal':
      case 'payment_settlement':
        return <ArrowUpRight className="w-4 h-4 text-sky-600" />;
      case 'stock_buy':
      case 'stock_sell':
      case 'trade': 
        return <Coins className="w-4 h-4 text-amber-500" />;
      case 'grant_subsidy':
      case 'grant_claim':
      case 'subsidy':
      case 'campaign_donation':
      case 'charity_donation':
        return <ArrowDownLeft className="w-4 h-4 text-emerald-500" />;
      case 'loan':
      case 'loan_issued':
      case 'loan_received':
      case 'loan_repaid':
      case 'loan_defaulted':
      case 'loan_written_off':
        return <Landmark className="w-4 h-4 text-indigo-500" />;
      case 'ipo': return <ArrowUpRight className="w-4 h-4 text-purple-500" />;
      case 'barter_swap':
      case 'vault_swap':
        return <RefreshCw className="w-4 h-4 text-amber-600" />;
      case 'marketplace_sale':
      case 'product_purchase':
      case 'service_payment':
        return <ShoppingBag className="w-4 h-4 text-emerald-600" />;
      case 'ride_share_booking':
      case 'ride_share_payout':
        return <Car className="w-4 h-4 text-indigo-600" />;
      case 'delivery_payout':
        return <Truck className="w-4 h-4 text-teal-600" />;
      case 'ride_share_cancellation':
      case 'correction':
        return <RotateCcw className="w-4 h-4 text-rose-500" />;
      case 'escrow': return <ShieldAlert className="w-4 h-4 text-orange-500" />;
      default: return <Database className="w-4 h-4 text-amber-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-6 shadow-xs">
        <div className="flex flex-col items-center justify-center text-center gap-4 mb-6">
          <div className="flex flex-col items-center justify-center text-center gap-1.5">
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              <h2 className="font-serif text-xl font-bold text-slate-900 text-center">Transaction Control</h2>
              <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-700 text-[10px] font-bold uppercase tracking-wider border border-blue-200">
                Mainnet Synced
              </span>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 w-full">
            <div className="relative w-full sm:w-64">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search txid, handles, notes..."
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:ring-1 focus:ring-blue-600 focus:border-blue-600 bg-slate-50"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            </div>
            
            <button
              onClick={handleRefresh}
              title="Synchronize Ledger"
              className={`p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-all cursor-pointer ${isRefreshing ? 'animate-spin' : ''}`}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            
            <button 
              onClick={handleExportCSV}
              className="flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold transition-all cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              <span>Export Ledger</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="py-4 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Transaction ID</th>
                <th className="py-4 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Type</th>
                <th className="py-4 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Parties</th>
                <th className="py-4 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Asset / Amount</th>
                <th className="py-4 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Status</th>
                <th className="py-4 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider text-right">Administrative Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredTransactions.map(tx => (
                <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 px-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-slate-100 text-slate-500">
                        <History className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="text-xs font-mono font-bold text-slate-900">{tx.id}</span>
                        <div className="text-[10px] text-slate-400">{tx.timestamp}</div>
                        {tx.title && (
                          <div className="text-[11px] text-slate-600 font-medium line-clamp-1 max-w-xs mt-0.5" title={tx.description}>
                            {tx.title}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-3">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(tx.type)}
                        <span className="text-xs font-bold text-slate-700 capitalize">{tx.type.replace(/_/g, ' ')}</span>
                      </div>
                      {isDividendTx(tx) && (
                        <span className="inline-flex w-fit items-center px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-mono font-bold">
                          {tx.taxClassification?.formMapping || 'Form 1099-DIV'}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-3">
                    <div className="flex items-center gap-2">
                      <div className="text-xs">
                        <div className="font-bold text-slate-800">{tx.sourceOrDestination || 'System Mint'}</div>
                        <div className="text-slate-300 text-center text-[10px] my-0.5">▼</div>
                        <div className="font-bold text-blue-600">{tx.counterpartyOrIssuer || tx.issuerHandle || 'Recipient Node'}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-3">
                    <div>
                      {tx.paymentCoinSymbol && tx.paymentCoinAmount !== undefined ? (
                        <>
                          <span className="text-sm font-mono font-bold text-amber-700">
                            {tx.paymentCoinAmount.toLocaleString()}
                          </span>
                          <span className="ml-1 text-[11px] font-mono font-bold text-amber-600">
                            {tx.paymentCoinSymbol}
                          </span>
                          <div className="text-[10px] text-slate-400 font-mono">
                            ≈ ${(tx.amountUSD || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                          </div>
                        </>
                      ) : (
                        <>
                          <span className="text-sm font-mono font-bold text-slate-900">
                            ${(tx.amountUSD || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                          <span className="ml-1.5 text-[10px] font-bold text-slate-400 uppercase">USD</span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-3">
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider ${getStatusStyle(tx.status)}`}>
                      {tx.status}
                    </span>
                  </td>
                  <td className="py-4 px-3 text-right">
                    {tx.status !== 'Reversed' && (tx.status as string) !== 'reversed' ? (
                      <button
                        onClick={() => handleReverse(tx.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-[11px] font-bold transition-all cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reverse Transaction</span>
                      </button>
                    ) : (
                      <span className="text-[11px] font-bold text-rose-400 italic">Ledger Rollback Complete</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {filteredTransactions.length === 0 && (
            <div className="py-20 text-center">
              <Search className="w-10 h-10 text-slate-200 mx-auto mb-3" />
              <p className="text-sm text-slate-400">No transactions found in the global system ledger matching your query.</p>
            </div>
          )}
        </div>
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ ...confirmModal, isOpen: false })}
        onConfirm={executeReverse}
        title="Confirm Transaction Reversal"
        message={`CRITICAL ACTION: Are you sure you want to reverse transaction ${confirmModal.txId}? This will roll back the entire ledger state for this entry across all participating nodes and restore funds to the origin.`}
        confirmText="Execute Reversal"
        type="danger"
      />
    </div>
  );
};
