import { FriendGroup } from '../types/social';

const FRIEND_GROUPS_STORAGE_KEY = 'final_finance_custom_friend_groups_v1';

const DEFAULT_FRIEND_GROUPS: FriendGroup[] = [
  {
    id: 'grp-bullion-syndicate',
    ownerUid: 'demo-vip-alex',
    name: 'Swiss Bullion Syndicate',
    description: 'Private circle for allocated precious metals and vault bullion swap deals.',
    color: '#f59e0b',
    icon: 'Shield',
    memberUids: ['user-lord_sterling', 'user-elena_rostova'],
    memberHandles: ['sterling_vault', 'elena_rostova'],
    createdAt: '2024-02-15T10:00:00.000Z'
  },
  {
    id: 'grp-crypto-whales',
    ownerUid: 'demo-vip-alex',
    name: 'Pioneer Liquidity Guild',
    description: 'Exclusive tier group for large scale AFNL & Bitcoin cold storage settlements.',
    color: '#8b5cf6',
    icon: 'Coins',
    memberUids: ['demo-satoshi-nakamoto', 'user-lord_sterling'],
    memberHandles: ['satoshi_nakamoto', 'sterling_vault'],
    createdAt: '2024-03-01T12:00:00.000Z'
  },
  {
    id: 'grp-gholu-inner-circle',
    ownerUid: 'user-gholu653',
    name: 'Close Friends & Trade Partners',
    description: 'Trusted direct barter network for private allocations.',
    color: '#10b981',
    icon: 'Users',
    memberUids: ['demo-satoshi-nakamoto', 'demo-jordan-belfort'],
    memberHandles: ['satoshi_nakamoto', 'jordan_belfort'],
    createdAt: '2024-03-10T09:00:00.000Z'
  }
];

function loadFriendGroups(): FriendGroup[] {
  try {
    const raw = localStorage.getItem(FRIEND_GROUPS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Error reading friend groups from storage:', e);
  }
  // Initialize with defaults
  saveFriendGroups(DEFAULT_FRIEND_GROUPS);
  return DEFAULT_FRIEND_GROUPS;
}

function saveFriendGroups(groups: FriendGroup[]) {
  try {
    localStorage.setItem(FRIEND_GROUPS_STORAGE_KEY, JSON.stringify(groups));
  } catch (e) {
    console.error('Error saving friend groups to storage:', e);
  }
}

export function getUserFriendGroups(ownerUid: string): FriendGroup[] {
  const all = loadFriendGroups();
  const cleanOwner = (ownerUid || '').trim().toLowerCase();
  return all.filter(g => 
    g.ownerUid.toLowerCase() === cleanOwner ||
    g.ownerUid.toLowerCase() === `user-${cleanOwner}` ||
    cleanOwner.includes(g.ownerUid.toLowerCase())
  );
}

export function getFriendGroupById(groupId: string): FriendGroup | null {
  const all = loadFriendGroups();
  return all.find(g => g.id === groupId) || null;
}

export function createFriendGroup(
  ownerUid: string,
  name: string,
  memberUids: string[],
  description?: string,
  color?: string,
  memberHandles?: string[],
  groupType: 'friend' | 'general' = 'friend',
  avatarUrl?: string
): FriendGroup {
  const all = loadFriendGroups();
  const newGroup: FriendGroup = {
    id: `grp-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    ownerUid: ownerUid || 'current_user',
    name: name.trim(),
    description: description?.trim() || '',
    color: color || '#f59e0b',
    icon: 'Users',
    avatarUrl: avatarUrl,
    memberUids: Array.from(new Set(memberUids)),
    memberHandles: memberHandles || [],
    groupType: groupType || 'friend',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const updated = [newGroup, ...all];
  saveFriendGroups(updated);
  return newGroup;
}

export function updateFriendGroup(
  groupId: string,
  updates: Partial<FriendGroup>
): FriendGroup | null {
  const all = loadFriendGroups();
  const index = all.findIndex(g => g.id === groupId);
  if (index === -1) return null;

  const updated: FriendGroup = {
    ...all[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };

  all[index] = updated;
  saveFriendGroups(all);
  return updated;
}

export function deleteFriendGroup(groupId: string): boolean {
  const all = loadFriendGroups();
  const filtered = all.filter(g => g.id !== groupId);
  if (filtered.length !== all.length) {
    saveFriendGroups(filtered);
    return true;
  }
  return false;
}

export function isUserInAnyGroup(
  userUidOrHandle: string,
  groupIds: string[]
): boolean {
  if (!userUidOrHandle || !groupIds || groupIds.length === 0) return false;
  const all = loadFriendGroups();
  const raw = userUidOrHandle.trim().toLowerCase();
  const clean = raw.replace(/^@/, '').replace(/^user-/, '');

  for (const gid of groupIds) {
    const grp = all.find(g => g.id === gid);
    if (grp) {
      const inMembers = grp.memberUids.some(u => {
        const uRaw = u.trim().toLowerCase();
        const uClean = uRaw.replace(/^@/, '').replace(/^user-/, '');
        return uRaw === raw || uClean === clean || uClean === raw || uRaw === clean;
      });
      const inHandles = grp.memberHandles?.some(h => {
        const hRaw = h.trim().toLowerCase();
        const hClean = hRaw.replace(/^@/, '').replace(/^user-/, '');
        return hRaw === raw || hClean === clean || hClean === raw || hRaw === clean;
      });

      if (inMembers || inHandles) {
        return true;
      }
    }
  }
  return false;
}
