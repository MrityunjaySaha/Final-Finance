import { FriendGroup, GroupMemberAssignment, UserPublicProfile } from '../types/social';

export const MAX_CUSTOM_GROUP_MEMBERS = 20;

const FRIEND_GROUPS_STORAGE_KEY = 'final_finance_custom_friend_groups_v1';

export function sanitizeMemberAssignments(
  memberUids: string[],
  assignments?: Record<string, GroupMemberAssignment>
): Record<string, GroupMemberAssignment> {
  if (!assignments) return {};
  const allowedSet = new Set(memberUids);
  const result: Record<string, GroupMemberAssignment> = {};

  for (const [uid, raw] of Object.entries(assignments)) {
    if (!allowedSet.has(uid) || !raw) continue;
    const cleaned: GroupMemberAssignment = {};
    if (typeof raw.number === 'number' && Number.isFinite(raw.number)) {
      cleaned.number = raw.number;
    }
    const trimmedRole = typeof raw.role === 'string' ? raw.role.trim() : '';
    if (trimmedRole) {
      cleaned.role = trimmedRole;
    }
    if (cleaned.number !== undefined || cleaned.role !== undefined) {
      result[uid] = cleaned;
    }
  }
  return result;
}

export function sortGroupMembers<T extends { uid: string; name?: string; userId?: string }>(
  members: T[],
  memberAssignments?: Record<string, GroupMemberAssignment>
): T[] {
  return [...members].sort((a, b) => {
    const aAssign = memberAssignments?.[a.uid];
    const bAssign = memberAssignments?.[b.uid];

    const aNum = typeof aAssign?.number === 'number' && Number.isFinite(aAssign.number) ? aAssign.number : null;
    const bNum = typeof bAssign?.number === 'number' && Number.isFinite(bAssign.number) ? bAssign.number : null;

    // Numbered members go to the top, unnumbered to the bottom
    if (aNum !== null && bNum === null) return -1;
    if (aNum === null && bNum !== null) return 1;

    // Both numbered: sort ascending by number, tie-break alphabetically
    if (aNum !== null && bNum !== null && aNum !== bNum) {
      return aNum - bNum;
    }

    // Both unnumbered (or tied numbers): sort alphabetically by name or handle
    const aLabel = (a.name || a.userId || a.uid).trim();
    const bLabel = (b.name || b.userId || b.uid).trim();
    return aLabel.localeCompare(bLabel, undefined, { sensitivity: 'base' });
  });
}

export function resolveAndSortGroupMembers(
  group: FriendGroup,
  availableUsers: UserPublicProfile[]
): UserPublicProfile[] {
  const userByUid = new Map<string, UserPublicProfile>();
  availableUsers.forEach((u) => {
    if (u && u.uid) {
      userByUid.set(u.uid, u);
    }
  });

  const resolved: UserPublicProfile[] = group.memberUids.map((uid, idx) => {
    const found = userByUid.get(uid);
    if (found) return found;

    const fallbackHandle =
      group.memberHandles?.[idx] ||
      uid.replace(/^user-/, '').replace(/^demo-/, '');
    return {
      uid,
      userId: fallbackHandle,
      name: fallbackHandle
        .split(/[_-]/)
        .filter(Boolean)
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ') || 'Member',
      role: 'user',
    };
  });

  return sortGroupMembers(resolved, group.memberAssignments);
}

const DEFAULT_FRIEND_GROUPS: FriendGroup[] = [
  {
    id: 'grp-bullion-syndicate',
    ownerUid: 'demo-vip-alex',
    name: 'Swiss Bullion Syndicate',
    description: 'Private circle for allocated precious metals and vault bullion swap deals.',
    color: '#f59e0b',
    icon: 'Shield',
    memberUids: ['user-lord_sterling', 'user-elena_rostova'],
    memberHandles: ['sterling_vault', 'elena_rostova'],
    memberAssignments: {
      'user-elena_rostova': { number: 1, role: 'Lead Strategist' },
      'user-lord_sterling': { number: 2, role: 'Vault Custodian' }
    },
    createdAt: '2024-02-15T10:00:00.000Z'
  },
  {
    id: 'grp-crypto-whales',
    ownerUid: 'demo-vip-alex',
    name: 'Pioneer Liquidity Guild',
    description: 'Exclusive tier group for large scale AFNL & Bitcoin cold storage settlements.',
    color: '#8b5cf6',
    icon: 'Coins',
    memberUids: ['demo-satoshi-nakamoto', 'user-lord_sterling'],
    memberHandles: ['satoshi_nakamoto', 'sterling_vault'],
    memberAssignments: {
      'demo-satoshi-nakamoto': { number: 1, role: 'Protocol Architect' },
      'user-lord_sterling': { role: 'Liquidity Partner' }
    },
    createdAt: '2024-03-01T12:00:00.000Z'
  },
  {
    id: 'grp-gholu-inner-circle',
    ownerUid: 'user-gholu653',
    name: 'Close Friends & Trade Partners',
    description: 'Trusted direct barter network for private allocations.',
    color: '#10b981',
    icon: 'Users',
    memberUids: ['demo-satoshi-nakamoto', 'demo-jordan-belfort'],
    memberHandles: ['satoshi_nakamoto', 'jordan_belfort'],
    createdAt: '2024-03-10T09:00:00.000Z'
  }
];

function loadFriendGroups(): FriendGroup[] {
  try {
    const raw = localStorage.getItem(FRIEND_GROUPS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Error reading friend groups from storage:', e);
  }
  // Initialize with defaults
  saveFriendGroups(DEFAULT_FRIEND_GROUPS);
  return DEFAULT_FRIEND_GROUPS;
}

function saveFriendGroups(groups: FriendGroup[]) {
  try {
    localStorage.setItem(FRIEND_GROUPS_STORAGE_KEY, JSON.stringify(groups));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('final_finance_friend_groups_updated'));
    }
  } catch (e) {
    console.error('Error saving friend groups to storage:', e);
  }
}

export function getUserFriendGroups(ownerUid: string): FriendGroup[] {
  const all = loadFriendGroups();
  const cleanOwner = (ownerUid || '').trim().toLowerCase();
  return all.filter(g => 
    g.ownerUid.toLowerCase() === cleanOwner ||
    g.ownerUid.toLowerCase() === `user-${cleanOwner}` ||
    cleanOwner.includes(g.ownerUid.toLowerCase())
  );
}

export function getFriendGroupById(groupId: string): FriendGroup | null {
  const all = loadFriendGroups();
  return all.find(g => g.id === groupId) || null;
}

export function createFriendGroup(
  ownerUid: string,
  name: string,
  memberUids: string[],
  description?: string,
  color?: string,
  memberHandles?: string[],
  groupType: 'friend' | 'general' = 'friend',
  avatarUrl?: string,
  memberAssignments?: Record<string, GroupMemberAssignment>
): FriendGroup {
  const all = loadFriendGroups();
  const uniqueUids = Array.from(new Set(memberUids)).slice(0, MAX_CUSTOM_GROUP_MEMBERS);
  const newGroup: FriendGroup = {
    id: `grp-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    ownerUid: ownerUid || 'current_user',
    name: name.trim(),
    description: description?.trim() || '',
    color: color || '#f59e0b',
    icon: 'Users',
    avatarUrl: avatarUrl,
    memberUids: uniqueUids,
    memberHandles: memberHandles || [],
    memberAssignments: sanitizeMemberAssignments(uniqueUids, memberAssignments),
    groupType: groupType || 'friend',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const updated = [newGroup, ...all];
  saveFriendGroups(updated);
  return newGroup;
}

export function updateFriendGroup(
  groupId: string,
  updates: Partial<FriendGroup>
): FriendGroup | null {
  const all = loadFriendGroups();
  const index = all.findIndex(g => g.id === groupId);
  if (index === -1) return null;

  const existing = all[index];
  const nextMemberUids = updates.memberUids
    ? Array.from(new Set(updates.memberUids)).slice(0, MAX_CUSTOM_GROUP_MEMBERS)
    : existing.memberUids;

  const rawAssignments =
    updates.memberAssignments !== undefined
      ? updates.memberAssignments
      : existing.memberAssignments;

  const updated: FriendGroup = {
    ...existing,
    ...updates,
    memberUids: nextMemberUids,
    memberAssignments: sanitizeMemberAssignments(nextMemberUids, rawAssignments),
    updatedAt: new Date().toISOString()
  };

  all[index] = updated;
  saveFriendGroups(all);
  return updated;
}

export function deleteFriendGroup(groupId: string): boolean {
  const all = loadFriendGroups();
  const filtered = all.filter(g => g.id !== groupId);
  if (filtered.length !== all.length) {
    saveFriendGroups(filtered);
    return true;
  }
  return false;
}

export function isUserInAnyGroup(
  userUidOrHandle: string,
  groupIds: string[]
): boolean {
  if (!userUidOrHandle || !groupIds || groupIds.length === 0) return false;
  const all = loadFriendGroups();
  const raw = userUidOrHandle.trim().toLowerCase();
  const clean = raw.replace(/^@/, '').replace(/^user-/, '');

  for (const gid of groupIds) {
    const grp = all.find(g => g.id === gid);
    if (grp) {
      const inMembers = grp.memberUids.some(u => {
        const uRaw = u.trim().toLowerCase();
        const uClean = uRaw.replace(/^@/, '').replace(/^user-/, '');
        return uRaw === raw || uClean === clean || uClean === raw || uRaw === clean;
      });
      const inHandles = grp.memberHandles?.some(h => {
        const hRaw = h.trim().toLowerCase();
        const hClean = hRaw.replace(/^@/, '').replace(/^user-/, '');
        return hRaw === raw || hClean === clean || hClean === raw || hRaw === clean;
      });

      if (inMembers || inHandles) {
        return true;
      }
    }
  }
  return false;
}
