import React, { useState } from 'react';
import { X, AlertTriangle, ShieldAlert, Send, FileText } from 'lucide-react';
import { IPORequest } from '../../types/stocks';
import { requestDelistIPO } from '../../data/stocksData';

interface DelistIPOModalProps {
  isOpen: boolean;
  onClose: () => void;
  ipo: IPORequest | null;
  onSuccess?: () => void;
}

export const DelistIPOModal: React.FC<DelistIPOModalProps> = ({
  isOpen,
  onClose,
  ipo,
  onSuccess
}) => {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !ipo) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim() || reason.trim().length < 10) {
      setErrorMsg('Please provide a detailed rationale for requesting stock delisting (minimum 10 characters).');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const ok = requestDelistIPO(ipo.id, reason.trim());
      setIsSubmitting(false);
      if (ok) {
        if (onSuccess) onSuccess();
        onClose();
      } else {
        setErrorMsg('Failed submitting delist request.');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || 'Error requesting delist.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden text-left">
        
        {/* HEADER */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-rose-50/50 dark:bg-rose-950/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-600 dark:text-rose-400 font-bold">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-slate-900 dark:text-white">
                Request Delisting (${ipo.ticker})
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Submit an equity delisting application to Protocol Admin
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ERROR */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 text-rose-700 text-xs">
            {errorMsg}
          </div>
        )}

        {/* FORM */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1">
            <div className="font-bold text-slate-900 dark:text-white">
              {ipo.equityName} (${ipo.ticker})
            </div>
            <div className="text-slate-500 font-mono text-[11px]">
              Type: {ipo.ipoType === 'personal' ? '👤 Personal Sovereign Equity' : '🏢 Business Corporate IPO'} • Market Cap: ${(ipo.targetValuationUSD / 1e6).toFixed(2)}M USD
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Delisting Justification &amp; Escrow Liquidation Strategy *
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
              placeholder="Detail reasons for delisting (e.g. corporate buyout, private consortium reorganization, sovereign buyback at par value)..."
              required
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-rose-500/30"
            />
          </div>

          <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-300 text-xs flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
            <span>
              <strong>Admin Delisting Policy:</strong> Delisting is subject to Admin approval to ensure public shareholders and liquidity providers are protected or refunded via buyback escrow.
            </span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition-all shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Submitting...' : 'Submit Delist Request to Admin'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
