import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, 
  X, 
  TrendingUp, 
  TrendingDown, 
  Briefcase, 
  ShieldCheck, 
  Search, 
  ArrowRight, 
  BarChart3, 
  Check, 
  Coins, 
  ExternalLink,
  Layers,
  ArrowUpRight,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { StockItem, StockMarketWay, StockPosition } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { EnrichedStockPosition } from './PurchasedEquityHoldingsView';
import { useApp } from '../../context/AppContext';
import { 
  getStoredStockPositions, 
  saveStoredStockPositions, 
  getStoredStockOrders, 
  saveStoredStockOrders, 
  processStockPayment,
  getAvailableStockPaymentSources
} from '../../utils/stockWalletBridge';
import { INITIAL_USER_STOCK_POSITIONS } from '../../data/stocksData';

interface FinalStocksTradeOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  stocks: StockItem[];
  enrichedPositions: EnrichedStockPosition[];
  currentUser?: AuthSession | null;
  onOpenTradeModal: (tickerOrStock: string | StockItem, side: 'buy' | 'sell') => void;
  onSelectStock?: (stock: StockItem) => void;
  onOpenStockMarket?: (marketWay?: StockMarketWay | 'all') => void;
  onSwitchToDerivativesTab?: () => void;
}

export const FinalStocksTradeOptionsModal: React.FC<FinalStocksTradeOptionsModalProps> = ({
  isOpen,
  onClose,
  stocks,
  enrichedPositions,
  currentUser,
  onOpenTradeModal,
  onSelectStock,
  onOpenStockMarket,
  onSwitchToDerivativesTab,
}) => {
  const { addTransaction } = useApp();
  const [activeFilterTab, setActiveFilterTab] = useState<'all' | 'owned' | 'derivatives'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStockForQuickTrade, setSelectedStockForQuickTrade] = useState<StockItem | null>(null);
  const [quickTradeSide, setQuickTradeSide] = useState<'buy' | 'sell'>('buy');
  const [quickTradeType, setQuickTradeType] = useState<'spot' | 'call_option' | 'put_option'>('spot');
  const [tradeAmountUSD, setTradeAmountUSD] = useState<string>('500');
  const [isExecutingInModal, setIsExecutingInModal] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const userId = currentUser?.id || 'guest';

  // Identify all Final Stocks (marketType 'final', settlement in Final Coin AFNL, or sovereign equity tickers)
  const finalStocks = useMemo(() => {
    const knownFinalTickers = ['ALEX', 'ELEN', 'HYPR', 'AFNL-EQ', 'FNL-RES', 'FNL-AERO', 'FNL-GOV', 'FNL-TECH', 'SATOSHI', 'STERL', 'STRL'];
    return stocks.filter(s => 
      s.marketType === 'final' || 
      s.settlementMethod?.toLowerCase().includes('final') ||
      s.issuanceCoinSymbol === 'AFNL' ||
      knownFinalTickers.includes(s.ticker.toUpperCase())
    );
  }, [stocks]);

  // Owned final positions map
  const ownedPositionsMap = useMemo(() => {
    const map = new Map<string, EnrichedStockPosition>();
    enrichedPositions.forEach(p => {
      if (p.marketType === 'final' || finalStocks.some(fs => fs.ticker.toUpperCase() === p.ticker.toUpperCase())) {
        map.set(p.ticker.toUpperCase(), p);
      }
    });
    return map;
  }, [enrichedPositions, finalStocks]);

  // Filtered final stocks based on tab and search
  const displayedFinalStocks = useMemo(() => {
    return finalStocks.filter(stock => {
      const isOwned = ownedPositionsMap.has(stock.ticker.toUpperCase());
      if (activeFilterTab === 'owned' && !isOwned) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTicker = stock.ticker.toLowerCase().includes(q);
        const matchName = stock.name.toLowerCase().includes(q);
        const matchSector = stock.sector?.toLowerCase().includes(q) || false;
        if (!matchTicker && !matchName && !matchSector) return false;
      }
      return true;
    });
  }, [finalStocks, ownedPositionsMap, activeFilterTab, searchQuery]);

  // Total Final Stock holdings statistics
  const finalTotalValue = useMemo(() => {
    let sum = 0;
    ownedPositionsMap.forEach(pos => {
      sum += pos.totalValueUSD;
    });
    return sum;
  }, [ownedPositionsMap]);

  if (!isOpen) return null;

  // Handle direct trade execution in modal fallback
  const handleExecuteTrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStockForQuickTrade) return;

    const amount = parseFloat(tradeAmountUSD);
    if (!amount || amount <= 0) return;

    const price = Math.max(0.01, selectedStockForQuickTrade.price);
    const shares = Number((amount / price).toFixed(4));
    setIsExecutingInModal(true);

    setTimeout(() => {
      try {
        const storedPositions = getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS);
        const ticker = selectedStockForQuickTrade.ticker.toUpperCase();
        const existingIdx = storedPositions.findIndex(p => p.ticker.toUpperCase() === ticker);

        let nextPositions = [...storedPositions];
        if (quickTradeSide === 'buy') {
          if (existingIdx >= 0) {
            const existing = nextPositions[existingIdx];
            const newShares = existing.shares + shares;
            const newCostBasis = (existing.shares * existing.avgCostUSD) + amount;
            nextPositions[existingIdx] = {
              ...existing,
              shares: newShares,
              avgCostUSD: newCostBasis / newShares,
              currentPriceUSD: price,
              totalValueUSD: newShares * price,
              marketType: 'final',
            };
          } else {
            nextPositions.push({
              ticker: selectedStockForQuickTrade.ticker,
              name: selectedStockForQuickTrade.name,
              shares,
              avgCostUSD: price,
              currentPriceUSD: price,
              totalValueUSD: amount,
              totalGainUSD: 0,
              totalGainPercent: 0,
              dailyGainUSD: 0,
              marketType: 'final',
              settlementMethod: 'Final Coin (AFNL)',
              sector: selectedStockForQuickTrade.sector || 'Sovereign Reserves',
            });
          }
        } else {
          // Sell
          if (existingIdx >= 0) {
            const existing = nextPositions[existingIdx];
            const remainingShares = Math.max(0, existing.shares - shares);
            if (remainingShares === 0) {
              nextPositions.splice(existingIdx, 1);
            } else {
              nextPositions[existingIdx] = {
                ...existing,
                shares: remainingShares,
                totalValueUSD: remainingShares * price,
              };
            }
          }
        }

        saveStoredStockPositions(userId, nextPositions);

        // Add ledger record
        const paymentSources = getAvailableStockPaymentSources(userId);
        const source: any = paymentSources[0] || {
          id: 'final-vault',
          type: 'wallet_final',
          label: 'Final Coin Sovereign Vault ($AFNL)',
          subtitle: 'Direct Settlement',
          balanceUSD: 500000,
          iconType: 'wallet',
          isDefault: true,
        };
        processStockPayment(userId, source, amount, quickTradeSide);

        addTransaction({
          taxYear: new Date().getFullYear(),
          type: quickTradeSide === 'buy' ? 'stock_buy' : 'stock_sell',
          category: 'trade',
          mode: 'final_coin',
          title: `${quickTradeSide.toUpperCase()} ${selectedStockForQuickTrade.ticker} (${quickTradeType === 'spot' ? 'Spot' : quickTradeType === 'call_option' ? 'Call Option' : 'Put Option'})`,
          description: `Final Coin ($AFNL) settled trade for ${shares} shares of ${selectedStockForQuickTrade.name} at $${price.toFixed(2)}.`,
          amountUSD: amount,
          feeUSD: 0,
          netAmountUSD: quickTradeSide === 'buy' ? -amount : amount,
          sourceOrDestination: currentUser?.name || 'Sovereign Trader',
          counterpartyOrIssuer: selectedStockForQuickTrade.name,
          issuerHandle: `@${selectedStockForQuickTrade.ticker.toLowerCase()}`,
          status: 'Settled',
          clearingNode: 'FINAL-SOVEREIGN-NODE-1',
          taxClassification: {
            formMapping: 'Securities Transaction',
            taxableEvent: true,
            taxableAmountUSD: amount,
            irsCategoryNote: `Final Stock ${quickTradeSide} execution`
          }
        });

        // Trigger parent trade modal event if available to keep all states in sync
        window.dispatchEvent(new CustomEvent('final_finance_stock_positions_updated'));

        setSuccessToast(`Successfully executed ${quickTradeSide.toUpperCase()} for $${selectedStockForQuickTrade.ticker}!`);
        setTimeout(() => setSuccessToast(null), 3500);
        setSelectedStockForQuickTrade(null);
      } catch (err) {
        console.error('Execution error:', err);
      } finally {
        setIsExecutingInModal(false);
      }
    }, 400);
  };

  return (
    <AnimatePresence>
      <div 
        id="final-stocks-trade-options-modal-backdrop"
        onClick={(e) => {
          if (e.target === e.currentTarget && !isExecutingInModal) {
            onClose();
          }
        }}
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 backdrop-blur-md overflow-y-auto"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.97, y: 14 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.97, y: 14 }}
          transition={{ duration: 0.18 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-4xl rounded-3xl bg-white border border-slate-200 shadow-2xl p-5 sm:p-7 text-left max-h-[90vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-700 flex items-center justify-center shadow-xs border border-amber-200">
                <Zap className="w-5 h-5 text-amber-600 fill-amber-500/20" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="font-serif text-lg sm:text-xl font-bold text-slate-900">
                    Final Stocks Trade Options
                  </h2>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200 flex items-center gap-1">
                    <Coins className="w-3 h-3 text-amber-700" />
                    <span>Settled in Final Coins ($AFNL)</span>
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Spot equities, options derivatives, and sovereign trade options for Final Stocks.
                </p>
              </div>
            </div>

            <button
              type="button"
              id="close-final-trade-options-modal-btn"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Success Toast */}
          {successToast && (
            <div className="my-3 px-4 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 shadow-xs">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{successToast}</span>
            </div>
          )}

          {/* Top Quick Stats & Global Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4 shrink-0">
            <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-left">
              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-800 font-bold block">
                Final Equities
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-slate-900 mt-0.5">
                {finalStocks.length} Verified Tickers
              </div>
              <span className="text-[11px] text-amber-700">100% Backed by Final Reserve</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-left">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold block">
                Your Final Holdings
              </span>
              <div className="text-base sm:text-lg font-mono font-extrabold text-slate-900 mt-0.5">
                {ownedPositionsMap.size} {ownedPositionsMap.size === 1 ? 'Position' : 'Positions'}
              </div>
              <span className="text-[11px] font-mono text-slate-600">
                NAV: ${finalTotalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>

            <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-left flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-800 font-bold block">
                  Settlement Asset
                </span>
                <div className="text-base sm:text-lg font-mono font-extrabold text-slate-900 mt-0.5 flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-emerald-600" />
                  <span>Final Coin ($AFNL)</span>
                </div>
              </div>
              <span className="text-[11px] text-emerald-700 font-medium">Peg: 1.00 USD • 0% Fee</span>
            </div>
          </div>

          {/* Filter Tabs & Search */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pb-3 border-b border-slate-100 shrink-0">
            <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              <button
                type="button"
                onClick={() => {
                  setActiveFilterTab('all');
                  setSelectedStockForQuickTrade(null);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  activeFilterTab === 'all'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All Final Stocks ({finalStocks.length})
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveFilterTab('owned');
                  setSelectedStockForQuickTrade(null);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  activeFilterTab === 'owned'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                My Holdings ({ownedPositionsMap.size})
              </button>

              <button
                type="button"
                onClick={() => {
                  if (onSwitchToDerivativesTab) {
                    onSwitchToDerivativesTab();
                    onClose();
                  } else {
                    setActiveFilterTab('derivatives');
                  }
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  activeFilterTab === 'derivatives'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Options Desk</span>
              </button>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search ticker, name..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
              />
            </div>
          </div>

          {/* Scrollable Content: List of Final Stocks & Trade Action Handlers */}
          <div className="flex-1 overflow-y-auto py-3 space-y-3">
            {/* Inline Quick Trade Execution Drawer if user selected a stock */}
            {selectedStockForQuickTrade && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-4 rounded-2xl bg-amber-50/90 border border-amber-300 shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-extrabold text-sm text-slate-900 bg-white px-2 py-0.5 rounded-lg border border-amber-200">
                      ${selectedStockForQuickTrade.ticker}
                    </span>
                    <span className="text-xs font-bold text-slate-800">
                      {selectedStockForQuickTrade.name}
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-600">
                      (${selectedStockForQuickTrade.price.toFixed(2)})
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedStockForQuickTrade(null)}
                    className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleExecuteTrade} className="space-y-3">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {/* Buy vs Sell side */}
                    <div className="col-span-2 flex rounded-xl bg-white border border-slate-200 p-1">
                      <button
                        type="button"
                        onClick={() => setQuickTradeSide('buy')}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          quickTradeSide === 'buy' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Buy (Long)
                      </button>
                      <button
                        type="button"
                        onClick={() => setQuickTradeSide('sell')}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          quickTradeSide === 'sell' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Sell (Close)
                      </button>
                    </div>

                    {/* Order Type */}
                    <div className="col-span-2 flex rounded-xl bg-white border border-slate-200 p-1">
                      <button
                        type="button"
                        onClick={() => setQuickTradeType('spot')}
                        className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                          quickTradeType === 'spot' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Spot Equity
                      </button>
                      <button
                        type="button"
                        onClick={() => setQuickTradeType('call_option')}
                        className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                          quickTradeType === 'call_option' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Call Option
                      </button>
                      <button
                        type="button"
                        onClick={() => setQuickTradeType('put_option')}
                        className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                          quickTradeType === 'put_option' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Put Option
                      </button>
                    </div>
                  </div>

                  {/* Trade Amount & Execution */}
                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <div className="relative flex-1 w-full">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-slate-400">
                        USD / AFNL
                      </span>
                      <input
                        type="number"
                        min="1"
                        step="10"
                        value={tradeAmountUSD}
                        onChange={(e) => setTradeAmountUSD(e.target.value)}
                        className="w-full pl-24 pr-4 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                      />
                    </div>

                    <div className="text-xs font-mono text-slate-600 whitespace-nowrap">
                      ≈ {(parseFloat(tradeAmountUSD) / Math.max(0.01, selectedStockForQuickTrade.price)).toFixed(2)} shares
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <button
                        type="submit"
                        disabled={isExecutingInModal || !tradeAmountUSD}
                        className="flex-1 sm:flex-none px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-all shadow-xs cursor-pointer disabled:opacity-50"
                      >
                        {isExecutingInModal ? 'Executing...' : `Confirm ${quickTradeSide.toUpperCase()} Order`}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onOpenTradeModal(selectedStockForQuickTrade, quickTradeSide);
                          onClose();
                        }}
                        className="px-3 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs transition-all cursor-pointer whitespace-nowrap flex items-center gap-1"
                        title="Open Advanced Full Trade Modal"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Advanced Slip</span>
                      </button>
                    </div>
                  </div>
                </form>
              </motion.div>
            )}

            {/* List of Final Stocks */}
            {displayedFinalStocks.length === 0 ? (
              <div className="p-8 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-2">
                <Briefcase className="w-8 h-8 text-slate-400 mx-auto" />
                <h4 className="text-sm font-bold text-slate-700">No Final Stocks Found</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {searchQuery ? `No Final Stocks match "${searchQuery}".` : 'No holdings in this category.'}
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {displayedFinalStocks.map((stk) => {
                  const owned = ownedPositionsMap.get(stk.ticker.toUpperCase());
                  const changePct = stk.changePercent || 0;
                  const isPositive = changePct >= 0;

                  return (
                    <div
                      key={stk.ticker}
                      className="p-3.5 sm:p-4 rounded-2xl bg-white border border-slate-200 hover:border-amber-300 hover:shadow-xs transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left"
                    >
                      {/* Left: Info */}
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-center font-mono font-bold text-xs shrink-0">
                          {stk.ticker.slice(0, 4)}
                        </div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="font-mono font-extrabold text-sm text-slate-900">
                              ${stk.ticker}
                            </h4>
                            <span className="text-xs font-semibold text-slate-700 truncate max-w-[200px] sm:max-w-[260px]">
                              {stk.name}
                            </span>
                            <span className="text-[10px] font-mono px-2 py-0.2 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                              {stk.sector || 'Sovereign Reserves'}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-3 mt-1 text-xs font-mono">
                            <span className="font-bold text-slate-900">
                              ${stk.price.toFixed(2)}
                            </span>
                            <span className="text-slate-400">•</span>
                            <span className={`font-bold flex items-center gap-0.5 ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {isPositive ? '+' : ''}{changePct.toFixed(2)}%
                            </span>
                            {owned && (
                              <>
                                <span className="text-slate-400">•</span>
                                <span className="text-amber-800 font-semibold bg-amber-50 px-2 py-0.2 rounded-md border border-amber-200">
                                  Owned: {owned.shares.toLocaleString()} sh (${owned.totalValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })})
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Trade Option Action Buttons */}
                      <div className="flex flex-wrap items-center gap-1.5 sm:justify-end">
                        {/* Quick Buy Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedStockForQuickTrade(stk);
                            setQuickTradeSide('buy');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center gap-1 cursor-pointer shadow-2xs whitespace-nowrap"
                        >
                          <TrendingUp className="w-3.5 h-3.5" />
                          <span>Buy</span>
                        </button>

                        {/* Quick Sell Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedStockForQuickTrade(stk);
                            setQuickTradeSide('sell');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 font-bold text-xs transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap"
                        >
                          <TrendingDown className="w-3.5 h-3.5" />
                          <span>Sell</span>
                        </button>

                        {/* Trade Options / Call-Put */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedStockForQuickTrade(stk);
                            setQuickTradeType('call_option');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-200 font-bold text-xs transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap"
                        >
                          <BarChart3 className="w-3.5 h-3.5 text-amber-700" />
                          <span>Options</span>
                        </button>

                        {/* Deep View Stock */}
                        {onSelectStock && (
                          <button
                            type="button"
                            onClick={() => {
                              onSelectStock(stk);
                              onClose();
                            }}
                            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                            title="View Stock Detail & Chart"
                          >
                            <ArrowUpRight className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer Shortcuts */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
            <div className="text-xs text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>All Final Stocks are secured and audited on Final Sovereign Ledger.</span>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              {onOpenStockMarket && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenStockMarket('final');
                    onClose();
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open Full Market</span>
                </button>
              )}

              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all cursor-pointer whitespace-nowrap"
              >
                Done
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
