import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, 
  Send, 
  Search, 
  Phone, 
  Video, 
  Users, 
  UserPlus, 
  UserMinus,
  Plus, 
  Check, 
  CheckCheck, 
  MoreVertical, 
  Paperclip, 
  Smile, 
  ShieldCheck, 
  Loader2, 
  X, 
  ArrowLeft,
  Crown,
  Shield,
  Gem,
  Compass,
  Sparkles,
  Info,
  Mic,
  Image as ImageIcon,
  Play,
  Pause,
  ThumbsUp,
  Heart,
  SmilePlus,
  User,
  Trash2,
  LogOut,
  AlertTriangle,
  Clock,
  FolderHeart,
  Tag
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { Conversation, ChatMessage, UserPublicProfile, ConversationParticipant, FriendGroup } from '../types/social';
import { getUserFriendGroups } from '../services/friendGroupService';
import { 
  subscribeToUserConversations, 
  subscribeToMessages, 
  sendChatMessage, 
  createGroupConversation,
  getOrCreateDirectConversation,
  addMemberToGroup,
  removeMemberFromGroup,
  deleteGroupConversation,
  leaveGroupConversation,
  MAX_GROUP_MEMBERS 
} from '../services/chatService';
import { getAllUsers, getUserProfile, areUsersBlockedEitherWay, getFriendsList, getFollowingList } from '../services/socialService';
import { CallLogsView } from './CallLogsView';

interface MessagesPageProps {
  currentUser?: AuthSession | null;
  initialConversationId?: string | null;
  onOpenVoiceCall: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }, isGroup?: boolean, groupParticipants?: any[]) => void;
  onOpenVideoCall: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }, isGroup?: boolean, groupParticipants?: any[]) => void;
  onViewUserProfile: (userIdOrHandle: string) => void;
  onNavigateBack?: () => void;
}

const EMOJI_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥', '🚀'];

export const MessagesPage: React.FC<MessagesPageProps> = ({
  currentUser,
  initialConversationId,
  onOpenVoiceCall,
  onOpenVideoCall,
  onViewUserProfile,
  onNavigateBack,
}) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [conversationFilter, setConversationFilter] = useState<'all' | 'direct' | 'group' | 'calls'>('all');
  const [mainViewMode, setMainViewMode] = useState<'chats' | 'call_logs'>('chats');
  const [isSending, setIsSending] = useState(false);

  // Group info panel toggle
  const [showGroupInfo, setShowGroupInfo] = useState(false);

  // Message Reactions local store
  const [messageReactions, setMessageReactions] = useState<Record<string, Record<string, number>>>({});
  const [activeReactionMsgId, setActiveReactionMsgId] = useState<string | null>(null);

  // Voice Note Recording Simulator
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);

  // Unified New Chat / New Group Modal State
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [chatModalTab, setChatModalTab] = useState<'direct' | 'group'>('direct');
  const [directUserSearch, setDirectUserSearch] = useState('');

  // Group creation modal state
  const [groupNameInput, setGroupNameInput] = useState('');
  const [groupMemberSearch, setGroupMemberSearch] = useState('');
  const [availableUsers, setAvailableUsers] = useState<UserPublicProfile[]>([]);
  const [selectedGroupMemberUids, setSelectedGroupMemberUids] = useState<Set<string>>(new Set());
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [groupCreateError, setGroupCreateError] = useState('');

  // Add member modal state for active group
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [addMemberSearch, setAddMemberSearch] = useState('');

  // Group Creator & Member Controls (Eject, End Group, Leave Group)
  const [memberToEject, setMemberToEject] = useState<ConversationParticipant | null>(null);
  const [isEjecting, setIsEjecting] = useState(false);
  const [showEndGroupConfirm, setShowEndGroupConfirm] = useState(false);
  const [isEndingGroup, setIsEndingGroup] = useState(false);
  const [showLeaveGroupConfirm, setShowLeaveGroupConfirm] = useState(false);
  const [isLeavingGroup, setIsLeavingGroup] = useState(false);
  const [groupActionError, setGroupActionError] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeUid = currentUser?.uid || currentUser?.id || 'guest';

  // Check if current user is creator of the selected group
  const isSelectedGroupCreator = 
    selectedConversation?.type === 'group' && 
    (selectedConversation.createdBy === activeUid || currentUser?.role === 'super_admin');

  // 1. Subscribe to current user's conversations
  useEffect(() => {
    const unsubscribe = subscribeToUserConversations(activeUid, (convList) => {
      setConversations(convList);

      if (initialConversationId) {
        const found = convList.find((c) => c.id === initialConversationId);
        if (found) setSelectedConversation(found);
      } else if (!selectedConversation && convList.length > 0) {
        setSelectedConversation(convList[0]);
      } else if (selectedConversation) {
        const updated = convList.find((c) => c.id === selectedConversation.id);
        if (updated) {
          setSelectedConversation(updated);
        } else {
          // Conversation was deleted or user was removed
          setSelectedConversation(convList[0] || null);
        }
      }
    });

    return () => unsubscribe();
  }, [activeUid, initialConversationId]);

  // 2. Subscribe to messages when selectedConversation changes
  useEffect(() => {
    if (!selectedConversation) {
      setMessages([]);
      return;
    }

    const unsubscribe = subscribeToMessages(selectedConversation.id, (msgList) => {
      setMessages(msgList);
    });

    return () => unsubscribe();
  }, [selectedConversation?.id]);

  // 3. Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const [friendsList, setFriendsList] = useState<UserPublicProfile[]>([]);
  const [followingList, setFollowingList] = useState<UserPublicProfile[]>([]);
  const [customGroupsMade, setCustomGroupsMade] = useState<FriendGroup[]>([]);

  // Load available users, friends, following, and custom groups made
  useEffect(() => {
    getAllUsers(activeUid).then(setAvailableUsers).catch(console.error);
    if (activeUid) {
      getFriendsList(activeUid).then(setFriendsList).catch(console.error);
      getFollowingList(activeUid).then(setFollowingList).catch(console.error);
      setCustomGroupsMade(getUserFriendGroups(activeUid));
    }
  }, [activeUid]);

  // Voice note timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecordingVoice) {
      interval = setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } else {
      setRecordSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isRecordingVoice]);

  // Direct 1-on-1 actions with a single person
  const handleStartDirectChat = async (targetUser: UserPublicProfile) => {
    if (!currentUser) return;
    try {
      const conv = await getOrCreateDirectConversation(currentUser, targetUser);
      setSelectedConversation(conv);
      setShowNewChatModal(false);
    } catch (err) {
      console.error('Error starting direct conversation:', err);
    }
  };

  const handleStartDirectVoiceCall = (targetUser: UserPublicProfile) => {
    setShowNewChatModal(false);
    onOpenVoiceCall(
      { uid: targetUser.uid, userId: targetUser.userId, name: targetUser.name, avatarUrl: targetUser.avatarUrl },
      false
    );
  };

  const handleStartDirectVideoCall = (targetUser: UserPublicProfile) => {
    setShowNewChatModal(false);
    onOpenVideoCall(
      { uid: targetUser.uid, userId: targetUser.userId, name: targetUser.name, avatarUrl: targetUser.avatarUrl },
      false
    );
  };

  // Send message
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !selectedConversation || isSending || !currentUser) return;

    const textToSend = inputText.trim();
    setInputText('');
    setIsSending(true);

    try {
      await sendChatMessage(selectedConversation.id, currentUser, textToSend);
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setIsSending(false);
    }
  };

  // Send simulated voice note
  const handleFinishVoiceNote = async () => {
    if (!selectedConversation || !currentUser) return;
    const durationStr = `${Math.floor(recordSeconds / 60)}:${(recordSeconds % 60).toString().padStart(2, '0')}`;
    setIsRecordingVoice(false);
    
    try {
      await sendChatMessage(
        selectedConversation.id,
        currentUser,
        `🎤 Voice Message (${durationStr})`
      );
    } catch (err) {
      console.error('Error sending voice note:', err);
    }
  };

  // Handle Photo Attachment
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedConversation || !currentUser) return;

    try {
      await sendChatMessage(
        selectedConversation.id,
        currentUser,
        `📷 Shared Photo: ${file.name}`
      );
    } catch (err) {
      console.error('Error uploading photo:', err);
    }
  };

  // Message reaction handler
  const handleReactToMessage = (messageId: string, emoji: string) => {
    setMessageReactions((prev) => {
      const msgMap = { ...(prev[messageId] || {}) };
      msgMap[emoji] = (msgMap[emoji] || 0) + 1;
      return { ...prev, [messageId]: msgMap };
    });
    setActiveReactionMsgId(null);
  };

  // Get recipient profile for direct conversation
  const getDirectRecipient = (conv: Conversation) => {
    const otherUid = conv.participantIds.find((id) => id !== activeUid) || conv.participantIds[0];
    return conv.participants[otherUid] || {
      uid: otherUid,
      userId: 'user',
      name: 'Ecosystem Member',
      avatarUrl: undefined,
    };
  };

  // Handle Call Triggers
  const handleTriggerVoiceCall = () => {
    if (!selectedConversation) return;
    if (selectedConversation.type === 'group') {
      const allParticipants = Object.values(selectedConversation.participants);
      onOpenVoiceCall(
        { uid: selectedConversation.id, userId: selectedConversation.id, name: selectedConversation.name || 'Multi-Conference Group Room' },
        true,
        allParticipants
      );
    } else {
      const recipient = getDirectRecipient(selectedConversation);
      onOpenVoiceCall(recipient, false);
    }
  };

  const handleTriggerVideoCall = () => {
    if (!selectedConversation) return;
    if (selectedConversation.type === 'group') {
      const allParticipants = Object.values(selectedConversation.participants);
      onOpenVideoCall(
        { uid: selectedConversation.id, userId: selectedConversation.id, name: selectedConversation.name || 'Multi-Conference Group Room' },
        true,
        allParticipants
      );
    } else {
      const recipient = getDirectRecipient(selectedConversation);
      onOpenVideoCall(recipient, false);
    }
  };

  // Create Group Conference (Up to 20 People)
  const handleCreateGroupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupNameInput.trim()) {
      setGroupCreateError('Please enter a group conference name.');
      return;
    }
    if (selectedGroupMemberUids.size === 0) {
      setGroupCreateError('Please select at least 1 member to invite.');
      return;
    }
    if (selectedGroupMemberUids.size + 1 > MAX_GROUP_MEMBERS) {
      setGroupCreateError(`Cannot exceed maximum limit of ${MAX_GROUP_MEMBERS} members.`);
      return;
    }

    setIsCreatingGroup(true);
    setGroupCreateError('');

    try {
      const selectedMembers = availableUsers.filter((u) => selectedGroupMemberUids.has(u.uid));
      const res = await createGroupConversation(currentUser!, groupNameInput.trim(), selectedMembers);
      if (res.success && res.conversation) {
        setSelectedConversation(res.conversation);
        setShowNewChatModal(false);
        setGroupNameInput('');
        setSelectedGroupMemberUids(new Set());
      } else {
        setGroupCreateError(res.error || 'Failed to initialize group');
      }
    } catch (err: any) {
      setGroupCreateError(err?.message || 'Error creating group');
    } finally {
      setIsCreatingGroup(false);
    }
  };

  // Add Member to existing group
  const handleAddMemberToActiveGroup = async (user: UserPublicProfile) => {
    if (!selectedConversation || selectedConversation.type !== 'group') return;
    try {
      await addMemberToGroup(selectedConversation.id, user);
      setShowAddMemberModal(false);
    } catch (err) {
      console.error('Error adding member:', err);
    }
  };

  // Eject member from group (Creator only)
  const handleConfirmEjectMember = async () => {
    if (!selectedConversation || !memberToEject || !currentUser) return;
    setIsEjecting(true);
    setGroupActionError('');

    try {
      const res = await removeMemberFromGroup(selectedConversation.id, memberToEject.uid, currentUser);
      if (res.success) {
        setMemberToEject(null);
      } else {
        setGroupActionError(res.error || 'Failed to eject member');
      }
    } catch (err: any) {
      setGroupActionError(err?.message || 'Error ejecting member');
    } finally {
      setIsEjecting(false);
    }
  };

  // End & Delete group room (Creator only)
  const handleConfirmEndGroup = async () => {
    if (!selectedConversation || !currentUser) return;
    setIsEndingGroup(true);
    setGroupActionError('');

    try {
      const res = await deleteGroupConversation(selectedConversation.id, currentUser);
      if (res.success) {
        setShowEndGroupConfirm(false);
        setShowGroupInfo(false);
        setSelectedConversation(null);
      } else {
        setGroupActionError(res.error || 'Failed to end group room');
      }
    } catch (err: any) {
      setGroupActionError(err?.message || 'Error ending group');
    } finally {
      setIsEndingGroup(false);
    }
  };

  // Leave group room (Non-creator or any member)
  const handleConfirmLeaveGroup = async () => {
    if (!selectedConversation || !currentUser) return;
    setIsLeavingGroup(true);
    setGroupActionError('');

    try {
      const res = await leaveGroupConversation(selectedConversation.id, currentUser);
      if (res.success) {
        setShowLeaveGroupConfirm(false);
        setShowGroupInfo(false);
        setSelectedConversation(null);
      } else {
        setGroupActionError(res.error || 'Failed to leave group room');
      }
    } catch (err: any) {
      setGroupActionError(err?.message || 'Error leaving group');
    } finally {
      setIsLeavingGroup(false);
    }
  };

  // Filter conversations
  const filteredConversations = conversations.filter((c) => {
    if (conversationFilter === 'direct' && c.type !== 'direct') return false;
    if (conversationFilter === 'group' && c.type !== 'group') return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    if (c.type === 'group') {
      return (c.name || '').toLowerCase().includes(q);
    }
    const other = getDirectRecipient(c);
    return other.name.toLowerCase().includes(q) || other.userId.toLowerCase().includes(q);
  });

  return (
    <div
      id="messages-page-root"
      className="w-full max-w-6xl mx-auto h-[calc(100vh-140px)] min-h-[600px] max-h-[860px] bg-white border border-neutral-200/90 rounded-3xl shadow-sm overflow-hidden flex flex-col md:flex-row text-left"
    >
      {/* ================= LEFT SIDEBAR: CONVERSATIONS LIST ================= */}
      <div className={`w-full md:w-80 lg:w-96 border-r border-neutral-200/90 flex flex-col bg-neutral-50/50 ${selectedConversation || mainViewMode === 'call_logs' ? 'hidden md:flex' : 'flex'}`}>
        {/* Header */}
        <div className="p-3.5 sm:p-4 border-b border-neutral-200/90 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <h2 className="font-serif-lux text-xl font-light text-black tracking-tight">
              {mainViewMode === 'call_logs' ? 'Call Logs' : 'Messages'}
            </h2>
          </div>

          {/* Top Actions: 1-on-1 Direct Chat, Group Room & Call Logs toggle */}
          <div className="flex items-center gap-1.5">
            {/* Call Logs Toggle Button */}
            <button
              id="btn-sidebar-call-logs"
              type="button"
              onClick={() => {
                setMainViewMode(mainViewMode === 'call_logs' ? 'chats' : 'call_logs');
                if (mainViewMode !== 'call_logs') {
                  setConversationFilter('calls');
                } else {
                  setConversationFilter('all');
                }
              }}
              className={`min-h-[34px] px-2.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors ${
                mainViewMode === 'call_logs'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-800'
              }`}
              title="View Audio & Video Call Logs (Peer-to-Peer & Group Conferences)"
            >
              <Phone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Call Logs</span>
            </button>

            {/* New 1-on-1 Message Button */}
            <button
              id="btn-new-direct-message"
              type="button"
              onClick={() => {
                setChatModalTab('direct');
                setShowNewChatModal(true);
                setGroupCreateError('');
                setMainViewMode('chats');
              }}
              className="min-h-[34px] px-3 py-1.5 rounded-full bg-black hover:bg-neutral-800 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer shadow-xs transition-colors"
              title="Start 1-on-1 Direct Message, Voice Call, or Video Call"
            >
              <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
              <span>New</span>
            </button>

            {/* New Group Button */}
            <button
              id="btn-new-group-modal"
              type="button"
              onClick={() => {
                setChatModalTab('group');
                setShowNewChatModal(true);
                setGroupCreateError('');
                setMainViewMode('chats');
              }}
              className="min-h-[34px] p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-800 flex items-center justify-center cursor-pointer transition-colors"
              title="Create Group Room (Up to 20 People)"
            >
              <Users className="w-4 h-4 text-emerald-600" />
            </button>
          </div>
        </div>

        {/* Filter Pills: All | 1-on-1 Direct | Groups | Call Logs */}
        <div className="px-3 pt-2.5 pb-1 flex items-center gap-1 bg-white border-b border-neutral-100 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => {
              setConversationFilter('all');
              setMainViewMode('chats');
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              conversationFilter === 'all' && mainViewMode === 'chats'
                ? 'bg-black text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            All
          </button>
          <button
            type="button"
            onClick={() => {
              setConversationFilter('direct');
              setMainViewMode('chats');
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              conversationFilter === 'direct' && mainViewMode === 'chats'
                ? 'bg-black text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            Direct
          </button>
          <button
            type="button"
            onClick={() => {
              setConversationFilter('group');
              setMainViewMode('chats');
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer flex items-center gap-1 whitespace-nowrap ${
              conversationFilter === 'group' && mainViewMode === 'chats'
                ? 'bg-black text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <span>Groups</span>
            <span className="text-[10px] opacity-75 font-mono">(20)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setConversationFilter('calls');
              setMainViewMode('call_logs');
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer flex items-center gap-1 whitespace-nowrap ${
              mainViewMode === 'call_logs'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <Phone className="w-3 h-3" />
            <span>Call Logs</span>
          </button>
        </div>

        {/* Search Conversations */}
        <div className="p-3 border-b border-neutral-100 bg-white">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search conversations..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-100/80 border border-neutral-200/80 text-xs text-black placeholder:text-neutral-400 focus:outline-none focus:bg-white focus:ring-1 focus:ring-black transition-all"
            />
          </div>
        </div>

        {/* Conversations Scrollable List */}
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-100">
          {filteredConversations.length === 0 ? (
            <div className="p-8 text-center text-neutral-400 text-xs space-y-3">
              <MessageSquare className="w-8 h-8 mx-auto text-neutral-300 stroke-1" />
              <p className="font-semibold text-neutral-700">No active conversations found</p>
              <p className="text-[11px] text-neutral-500">
                Click <strong>"New Message"</strong> above to text or call any individual, or <strong>"Groups"</strong> to host up to 20 people.
              </p>
              <button
                type="button"
                onClick={() => {
                  setChatModalTab('direct');
                  setShowNewChatModal(true);
                }}
                className="mt-2 px-4 py-2 rounded-xl bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-colors inline-flex items-center gap-1.5 shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Start Direct Chat</span>
              </button>
            </div>
          ) : (
            filteredConversations.map((conv) => {
              const isSelected = selectedConversation?.id === conv.id;
              const isGroup = conv.type === 'group';
              const recipient = isGroup ? null : getDirectRecipient(conv);

              return (
                <button
                  key={conv.id}
                  type="button"
                  onClick={() => {
                    setSelectedConversation(conv);
                    setMainViewMode('chats');
                  }}
                  className={`w-full p-3.5 flex items-start gap-3 text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-neutral-100/90 font-medium'
                      : 'hover:bg-neutral-100/50 bg-white'
                  }`}
                >
                  {/* Avatar */}
                  <div className="relative shrink-0">
                    {isGroup ? (
                      conv.groupAvatarUrl ? (
                        <img
                          src={conv.groupAvatarUrl}
                          alt={conv.name}
                          className="w-11 h-11 rounded-2xl object-cover border border-neutral-200"
                        />
                      ) : (
                        <div className="w-11 h-11 rounded-2xl bg-neutral-900 text-white flex items-center justify-center text-xs font-mono">
                          <Users className="w-5 h-5 text-emerald-400" />
                        </div>
                      )
                    ) : recipient?.avatarUrl ? (
                      <img
                        src={recipient.avatarUrl}
                        alt={recipient.name}
                        className="w-11 h-11 rounded-full object-cover border border-neutral-200"
                      />
                    ) : (
                      <div className="w-11 h-11 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                        {recipient?.name ? recipient.name.charAt(0).toUpperCase() : 'U'}
                      </div>
                    )}

                    {isGroup && (
                      <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded-full bg-emerald-700 text-white text-[9px] font-mono border border-white">
                        {conv.participantIds.length}
                      </span>
                    )}
                  </div>

                  {/* Content Preview */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <h4 className="text-xs font-semibold text-black truncate flex items-center gap-1.5">
                        <span>{isGroup ? conv.name : recipient?.name}</span>
                        {!isGroup && (
                          <span className="text-[10px] font-mono text-neutral-400 font-normal">
                            @{recipient?.userId}
                          </span>
                        )}
                      </h4>
                      <span className="text-[10px] text-neutral-400 font-mono shrink-0">
                        {conv.updatedAt ? new Date(conv.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                      </span>
                    </div>

                    <p className="text-[11px] text-neutral-500 truncate">
                      {conv.lastMessageText || 'Direct channel opened'}
                    </p>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* ================= RIGHT: CHAT CONVERSATION VIEW OR CALL LOGS ================= */}
      {mainViewMode === 'call_logs' ? (
        <div className="flex-1 flex flex-col bg-white h-full relative overflow-hidden">
          <CallLogsView
            currentUser={currentUser}
            onOpenVoiceCall={onOpenVoiceCall}
            onOpenVideoCall={onOpenVideoCall}
            onViewUserProfile={onViewUserProfile}
            onBackToMessages={() => {
              setMainViewMode('chats');
              setConversationFilter('all');
            }}
            onOpenChatWithUser={async (uid) => {
              const targetUser = availableUsers.find((u) => u.uid === uid);
              if (targetUser && currentUser) {
                const res = await getOrCreateDirectConversation(currentUser, targetUser);
                if (res) {
                  setSelectedConversation(res);
                  setMainViewMode('chats');
                }
              }
            }}
          />
        </div>
      ) : selectedConversation ? (
        <div className="flex-1 flex flex-col bg-white h-full relative overflow-hidden">
          {/* Active Conversation Top Bar */}
          <div className="p-3 sm:p-4 border-b border-neutral-200/90 flex items-center justify-between bg-white z-10 shadow-2xs">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setSelectedConversation(null)}
                className="p-1.5 rounded-full text-neutral-500 hover:text-black hover:bg-neutral-100 transition-colors md:hidden cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>

              {/* Header Profile / Group details */}
              {selectedConversation.type === 'group' ? (
                <div
                  onClick={() => setShowGroupInfo(!showGroupInfo)}
                  className="flex items-center gap-3 min-w-0 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Users className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-sm text-black truncate group-hover:underline">
                        {selectedConversation.name}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-mono font-bold shrink-0">
                        {selectedConversation.participantIds.length} / 20 Max
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-500 truncate">
                      {isSelectedGroupCreator ? '👑 You are the room creator' : 'Click to view participants & actions'}
                    </p>
                  </div>
                </div>
              ) : (
                (() => {
                  const recipient = getDirectRecipient(selectedConversation);
                  return (
                    <div
                      onClick={() => onViewUserProfile(recipient.userId || recipient.uid)}
                      className="flex items-center gap-3 min-w-0 cursor-pointer group"
                    >
                      {recipient.avatarUrl ? (
                        <img
                          src={recipient.avatarUrl}
                          alt={recipient.name}
                          className="w-10 h-10 rounded-full object-cover border border-neutral-200 shrink-0 group-hover:scale-105 transition-transform"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center text-sm font-serif-lux shrink-0">
                          {recipient.name ? recipient.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                      )}
                      <div className="min-w-0">
                        <h3 className="font-semibold text-sm text-black group-hover:underline truncate">
                          {recipient.name}
                        </h3>
                        <p className="text-[11px] font-mono text-neutral-400 truncate">
                          @{recipient.userId} • Active Now (1-on-1)
                        </p>
                      </div>
                    </div>
                  );
                })()
              )}
            </div>

            {/* Top Right Action Icons: 1-on-1 Voice/Video Call or Group Video/Voice & Actions */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {selectedConversation.type === 'group' && (
                <button
                  id="btn-add-group-member"
                  type="button"
                  onClick={() => setShowAddMemberModal(true)}
                  className="min-h-[36px] px-3 py-1 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Invite Member to Group (Up to 20)"
                >
                  <UserPlus className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="hidden sm:inline">Invite ({selectedConversation.participantIds.length}/20)</span>
                </button>
              )}

              {/* 1-on-1 / Group Voice Call Button */}
              {(() => {
                const isDirectBlocked = selectedConversation.type === 'direct' && (() => {
                  const recipient = getDirectRecipient(selectedConversation);
                  return recipient && currentUser ? areUsersBlockedEitherWay(currentUser.uid, recipient.uid) : false;
                })();

                return (
                  <>
                    <button
                      id="btn-trigger-voice-call"
                      type="button"
                      onClick={handleTriggerVoiceCall}
                      disabled={isDirectBlocked}
                      className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                        isDirectBlocked
                          ? 'opacity-40 cursor-not-allowed bg-neutral-100 text-neutral-400'
                          : 'bg-neutral-100 hover:bg-black hover:text-white text-neutral-800 cursor-pointer'
                      }`}
                      title={isDirectBlocked ? 'Calls disabled due to block' : (selectedConversation.type === 'group' ? 'Start Group Voice Call (Up to 20 people)' : 'Start 1-on-1 Voice Call')}
                    >
                      <Phone className="w-4 h-4" />
                    </button>

                    {/* 1-on-1 / Group Video Call Button */}
                    <button
                      id="btn-trigger-video-call"
                      type="button"
                      onClick={handleTriggerVideoCall}
                      disabled={isDirectBlocked}
                      className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                        isDirectBlocked
                          ? 'opacity-40 cursor-not-allowed bg-neutral-100 text-neutral-400'
                          : 'bg-neutral-100 hover:bg-emerald-600 hover:text-white text-neutral-800 cursor-pointer'
                      }`}
                      title={isDirectBlocked ? 'Calls disabled due to block' : (selectedConversation.type === 'group' ? 'Start Group Video Call (Up to 20 people)' : 'Start 1-on-1 Video Call')}
                    >
                      <Video className="w-4 h-4" />
                    </button>
                  </>
                );
              })()}

              {/* 1-on-1 View Profile Button */}
              {selectedConversation.type !== 'group' && (
                <button
                  id="btn-conv-view-profile"
                  type="button"
                  onClick={() => {
                    const recipient = getDirectRecipient(selectedConversation);
                    onViewUserProfile(recipient.userId || recipient.uid);
                  }}
                  className="w-9 h-9 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 hover:text-black flex items-center justify-center transition-all cursor-pointer"
                  title="View Profile"
                >
                  <User className="w-4 h-4" />
                </button>
              )}

              {/* View Call Logs */}
              <button
                id="btn-conv-call-logs"
                type="button"
                onClick={() => setMainViewMode('call_logs')}
                className="w-9 h-9 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 flex items-center justify-center transition-all cursor-pointer"
                title="View All Sovereign Audio & Video Call Logs"
              >
                <Clock className="w-4 h-4" />
              </button>

              {selectedConversation.type === 'group' && (
                <button
                  type="button"
                  onClick={() => setShowGroupInfo(!showGroupInfo)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                    showGroupInfo ? 'bg-black text-white' : 'bg-neutral-100 text-neutral-800 hover:bg-neutral-200'
                  }`}
                  title="Group Info, Members & Admin Controls"
                >
                  <Users className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Main Area: Message Feed + Optional Group Members Drawer */}
          <div className="flex-1 flex overflow-hidden">
            {/* Messages Feed */}
            <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4 bg-neutral-50/40">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-neutral-400 text-center py-10 space-y-2">
                  <ShieldCheck className="w-8 h-8 text-emerald-600" />
                  <p className="text-xs font-semibold text-black">Channel Established</p>
                  <p className="text-[11px] text-neutral-400 max-w-xs">
                    Start chatting or trigger an instant voice or video call (1-on-1 or multi-party rooms up to 20 people).
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isMe = msg.senderId === currentUser?.uid;
                  const isSystem = msg.senderId === 'system';
                  const reactions = messageReactions[msg.id] || {};

                  if (isSystem) {
                    return (
                      <div key={msg.id} className="w-full flex justify-center py-1">
                        <div className="px-3 py-1 rounded-full bg-neutral-200/70 border border-neutral-300/60 text-[11px] text-neutral-700 font-medium shadow-2xs">
                          {msg.text}
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={msg.id}
                      className={`flex items-end gap-2.5 group relative ${isMe ? 'justify-end' : 'justify-start'}`}
                    >
                      {!isMe && (
                        <div
                          onClick={() => onViewUserProfile(msg.senderHandle || msg.senderId)}
                          className="cursor-pointer shrink-0"
                        >
                          {msg.senderAvatarUrl ? (
                            <img
                              src={msg.senderAvatarUrl}
                              alt={msg.senderName}
                              className="w-7 h-7 rounded-full object-cover border border-neutral-200"
                            />
                          ) : (
                            <div className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center text-[10px] font-serif-lux">
                              {msg.senderName ? msg.senderName.charAt(0).toUpperCase() : 'U'}
                            </div>
                          )}
                        </div>
                      )}

                      <div className={`max-w-[78%] sm:max-w-md ${isMe ? 'items-end' : 'items-start'} flex flex-col relative`}>
                        {!isMe && selectedConversation.type === 'group' && (
                          <span className="text-[10px] font-medium text-neutral-500 mb-1 ml-1">
                            {msg.senderName} <span className="font-mono text-neutral-400">@{msg.senderHandle}</span>
                          </span>
                        )}

                        {/* Message Bubble */}
                        <div
                          className={`relative px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-2xs ${
                            isMe
                              ? 'bg-black text-white rounded-br-xs'
                              : 'bg-white text-neutral-900 border border-neutral-200/80 rounded-bl-xs'
                          }`}
                        >
                          <p className="whitespace-pre-wrap break-words">{msg.text}</p>

                          {/* Quick Reaction Button on Hover */}
                          <button
                            type="button"
                            onClick={() => setActiveReactionMsgId(activeReactionMsgId === msg.id ? null : msg.id)}
                            className="absolute -top-3 right-0 opacity-0 group-hover:opacity-100 p-1 rounded-full bg-white border border-neutral-200 shadow-md text-neutral-600 hover:text-black cursor-pointer transition-opacity z-10"
                            title="React"
                          >
                            <SmilePlus className="w-3.5 h-3.5" />
                          </button>

                          {/* Reaction Picker Popover */}
                          {activeReactionMsgId === msg.id && (
                            <div className="absolute -top-10 right-0 bg-white border border-neutral-200 rounded-full px-2 py-1 shadow-xl flex items-center gap-1.5 z-20 animate-in fade-in zoom-in-95">
                              {EMOJI_REACTIONS.map((em) => (
                                <button
                                  key={em}
                                  type="button"
                                  onClick={() => handleReactToMessage(msg.id, em)}
                                  className="text-base hover:scale-125 transition-transform cursor-pointer"
                                >
                                  {em}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Reaction Badges below message */}
                        {Object.keys(reactions).length > 0 && (
                          <div className="flex items-center gap-1 mt-1 px-1">
                            {Object.entries(reactions).map(([em, count]) => (
                              <span
                                key={em}
                                className="px-1.5 py-0.5 rounded-full bg-neutral-100 border border-neutral-200 text-[10px] flex items-center gap-1 shadow-2xs font-medium"
                              >
                                <span>{em}</span>
                                <span>{count}</span>
                              </span>
                            ))}
                          </div>
                        )}

                        <span className="text-[9px] font-mono text-neutral-400 mt-1 px-1">
                          {msg.createdAt?.toDate ? new Date(msg.createdAt.toDate()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'just now'}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Group Members & Admin Controls Drawer */}
            <AnimatePresence>
              {showGroupInfo && selectedConversation.type === 'group' && (
                <motion.div
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 310, opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  className="h-full bg-white border-l border-neutral-200 flex flex-col z-20 shrink-0 shadow-lg"
                >
                  {/* Drawer Header */}
                  <div className="p-3.5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
                    <div className="flex items-center gap-2 min-w-0">
                      <Users className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-xs font-bold text-black block truncate">Room Settings</span>
                        <span className="text-[10px] font-mono text-neutral-500">
                          {selectedConversation.participantIds.length} / {MAX_GROUP_MEMBERS} Members
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowGroupInfo(false)}
                      className="p-1 rounded-lg hover:bg-neutral-200 text-neutral-500 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Members List */}
                  <div className="flex-1 overflow-y-auto p-2 space-y-1 divide-y divide-neutral-100">
                    {(Object.values(selectedConversation.participants) as ConversationParticipant[]).map((p) => {
                      const isMe = p.uid === activeUid;
                      const isCreator = p.uid === selectedConversation.createdBy;

                      return (
                        <div key={p.uid} className="pt-2.5 pb-2 px-2 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 min-w-0">
                            {p.avatarUrl ? (
                              <img src={p.avatarUrl} alt={p.name} className="w-8 h-8 rounded-full object-cover border border-neutral-200 shrink-0" />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-neutral-900 text-white flex items-center justify-center text-xs font-serif shrink-0">
                                {p.name.charAt(0)}
                              </div>
                            )}
                            <div className="min-w-0">
                              <div className="flex items-center gap-1">
                                <span className="text-xs font-bold text-black truncate">
                                  {p.name} {isMe && '(You)'}
                                </span>
                                {isCreator && (
                                  <span className="px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800 text-[9px] font-bold flex items-center gap-0.5 shrink-0 border border-amber-200" title="Room Creator / Host">
                                    <Crown className="w-2.5 h-2.5 text-amber-600" />
                                    <span>Host</span>
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] font-mono text-neutral-400 block truncate">@{p.userId}</span>
                            </div>
                          </div>

                          {/* Member actions */}
                          <div className="flex items-center gap-1 shrink-0">
                            {!isMe && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => onOpenVoiceCall(p, false)}
                                  className="p-1 rounded-full hover:bg-neutral-100 text-neutral-600 hover:text-black cursor-pointer"
                                  title={`1-on-1 Voice Call ${p.name}`}
                                >
                                  <Phone className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => onOpenVideoCall(p, false)}
                                  className="p-1 rounded-full hover:bg-neutral-100 text-neutral-600 hover:text-emerald-600 cursor-pointer"
                                  title={`1-on-1 Video Call ${p.name}`}
                                >
                                  <Video className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}

                            {/* Creator Eject Option */}
                            {isSelectedGroupCreator && !isMe && !isCreator && (
                              <button
                                type="button"
                                onClick={() => {
                                  setMemberToEject(p);
                                  setGroupActionError('');
                                }}
                                className="p-1.5 rounded-full hover:bg-red-50 text-neutral-400 hover:text-red-600 transition-colors cursor-pointer"
                                title={`Eject ${p.name} from group`}
                              >
                                <UserMinus className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Drawer Footer: Invite Member + End Group / Leave Group */}
                  <div className="p-3 border-t border-neutral-200 bg-neutral-50 space-y-2">
                    {/* Invite Button */}
                    <button
                      type="button"
                      onClick={() => setShowAddMemberModal(true)}
                      disabled={selectedConversation.participantIds.length >= MAX_GROUP_MEMBERS}
                      className="w-full py-2 rounded-xl bg-black hover:bg-neutral-800 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                    >
                      <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Invite Member ({selectedConversation.participantIds.length}/20)</span>
                    </button>

                    {/* End Group (Creator) or Leave Group (Member) */}
                    {isSelectedGroupCreator ? (
                      <button
                        type="button"
                        onClick={() => {
                          setShowEndGroupConfirm(true);
                          setGroupActionError('');
                        }}
                        className="w-full py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-600" />
                        <span>End &amp; Disband Group Room</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setShowLeaveGroupConfirm(true);
                          setGroupActionError('');
                        }}
                        className="w-full py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <LogOut className="w-3.5 h-3.5 text-neutral-600" />
                        <span>Leave Group Room</span>
                      </button>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Bottom Message Input Bar */}
          <div className="p-3 sm:p-4 border-t border-neutral-200/90 bg-white">
            {(() => {
              const isDirectBlocked = selectedConversation.type === 'direct' && (() => {
                const recipient = getDirectRecipient(selectedConversation);
                return recipient && currentUser ? areUsersBlockedEitherWay(currentUser.uid, recipient.uid) : false;
              })();

              if (isDirectBlocked) {
                return (
                  <div className="p-3 bg-red-50/90 border border-red-200 rounded-2xl flex items-center justify-center gap-2 text-xs text-red-800 font-medium">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                    <span>Direct messaging and calls are disabled due to a block between these accounts.</span>
                  </div>
                );
              }

              if (isRecordingVoice) {
                return (
                  <div className="flex items-center justify-between p-2 rounded-2xl bg-red-50 border border-red-200 animate-pulse">
                    <div className="flex items-center gap-2 text-red-600 text-xs font-bold pl-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
                      <span>Recording Voice Note... ({recordSeconds}s)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setIsRecordingVoice(false)}
                        className="px-3 py-1 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-200 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleFinishVoiceNote}
                        className="px-4 py-1.5 rounded-xl bg-red-600 text-white text-xs font-bold cursor-pointer hover:bg-red-700 flex items-center gap-1"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Send Voice</span>
                      </button>
                    </div>
                  </div>
                );
              }

              return (
                <form
                  onSubmit={handleSendMessage}
                  className="flex items-center gap-2"
                >
                  {/* Photo upload */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handlePhotoUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2.5 rounded-2xl bg-neutral-100 hover:bg-neutral-200 text-neutral-600 hover:text-black transition-colors cursor-pointer"
                    title="Share Photo"
                  >
                    <ImageIcon className="w-4 h-4" />
                  </button>

                  {/* Voice Note Trigger */}
                  <button
                    type="button"
                    onClick={() => setIsRecordingVoice(true)}
                    className="p-2.5 rounded-2xl bg-neutral-100 hover:bg-neutral-200 text-neutral-600 hover:text-black transition-colors cursor-pointer"
                    title="Record Voice Note"
                  >
                    <Mic className="w-4 h-4" />
                  </button>

                  <input
                    type="text"
                    id="chat-message-input"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder={`Message ${selectedConversation.type === 'group' ? selectedConversation.name : getDirectRecipient(selectedConversation).name}...`}
                    className="flex-1 min-h-[44px] px-4 py-2.5 rounded-2xl bg-neutral-100/80 border border-neutral-200/80 text-xs sm:text-sm text-black placeholder:text-neutral-400 focus:outline-none focus:bg-white focus:ring-1 focus:ring-black transition-all"
                  />

                  <button
                    type="submit"
                    id="send-message-submit-btn"
                    disabled={!inputText.trim() || isSending}
                    className="min-h-[44px] min-w-[44px] px-4 rounded-2xl bg-black hover:bg-neutral-800 disabled:opacity-50 text-white flex items-center justify-center transition-all cursor-pointer shadow-xs"
                    title="Send Message"
                  >
                    {isSending ? (
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </button>
                </form>
              );
            })()}
          </div>
        </div>
      ) : (
        /* Empty Right Slate with Quick 1-on-1 Contact Cards */
        <div className="hidden md:flex flex-1 flex-col overflow-y-auto p-6 sm:p-8 bg-neutral-50/30 text-left">
          <div className="max-w-xl mx-auto w-full space-y-6">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 mx-auto rounded-3xl bg-white shadow-xs flex items-center justify-center text-neutral-800 border border-neutral-200">
                <MessageSquare className="w-7 h-7" />
              </div>
              <h3 className="font-serif-lux text-2xl text-black font-light">
                Direct &amp; Group Communications
              </h3>
              <p className="text-xs text-neutral-500">
                Text, voice call, or video call any single individual 1-on-1, or host synchronized multi-party conference rooms for up to 20 people.
              </p>
            </div>

            {/* Quick 1-on-1 Contacts Roster */}
            <div className="bg-white rounded-3xl border border-neutral-200 p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
                <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Direct 1-on-1 Quick Start</span>
                </h4>
                <button
                  type="button"
                  onClick={() => {
                    setChatModalTab('direct');
                    setShowNewChatModal(true);
                  }}
                  className="text-xs font-semibold text-black hover:underline cursor-pointer"
                >
                  View All
                </button>
              </div>

              <div className="divide-y divide-neutral-100">
                {availableUsers.slice(0, 4).map((user) => (
                  <div key={user.uid} className="py-2.5 flex items-center justify-between gap-3">
                    <div 
                      onClick={() => onViewUserProfile(user.userId || user.uid)}
                      className="flex items-center gap-3 min-w-0 cursor-pointer group"
                    >
                      {user.avatarUrl ? (
                        <img src={user.avatarUrl} alt={user.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200 group-hover:scale-105 transition-transform" />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux group-hover:scale-105 transition-transform">
                          {user.name.charAt(0)}
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-black group-hover:underline truncate">{user.name}</p>
                        <p className="text-[11px] font-mono text-neutral-400 truncate">@{user.userId}</p>
                      </div>
                    </div>

                    {/* 3 Direct 1-on-1 Action Buttons */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Message 1-on-1 */}
                      <button
                        type="button"
                        onClick={() => handleStartDirectChat(user)}
                        className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer shadow-2xs transition-colors"
                        title={`Message ${user.name}`}
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>Chat</span>
                      </button>

                      {/* Call 1-on-1 */}
                      <button
                        type="button"
                        onClick={() => handleStartDirectVoiceCall(user)}
                        className="p-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 hover:text-black cursor-pointer transition-colors"
                        title={`Call ${user.name}`}
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </button>

                      {/* Video Call 1-on-1 */}
                      <button
                        type="button"
                        onClick={() => handleStartDirectVideoCall(user)}
                        className="p-1.5 rounded-xl bg-neutral-100 hover:bg-emerald-50 text-neutral-700 hover:text-emerald-700 cursor-pointer transition-colors"
                        title={`Video Call ${user.name}`}
                      >
                        <Video className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Group Room Launcher */}
            <div className="bg-neutral-900 rounded-3xl p-5 text-white flex items-center justify-between gap-4 shadow-sm">
              <div className="space-y-1 min-w-0">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                    Group Rooms (Up to 20 People)
                  </h4>
                </div>
                <p className="text-xs text-neutral-300">
                  Host synchronized group conference rooms with live camera feeds, screen sharing &amp; in-call chat.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setChatModalTab('group');
                  setShowNewChatModal(true);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs shrink-0 cursor-pointer transition-colors shadow-xs"
              >
                Create Group
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: UNIFIED NEW MESSAGE / GROUP MODAL ================= */}
      {showNewChatModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] flex flex-col"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setChatModalTab('direct')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                    chatModalTab === 'direct'
                      ? 'bg-black text-white'
                      : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  Direct (1-on-1)
                </button>
                <button
                  type="button"
                  onClick={() => setChatModalTab('group')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors flex items-center gap-1 ${
                    chatModalTab === 'group'
                      ? 'bg-black text-white'
                      : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  <Users className="w-3 h-3" />
                  <span>Group Room (Max 20)</span>
                </button>
              </div>
              <button
                type="button"
                onClick={() => setShowNewChatModal(false)}
                className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* TAB 1: DIRECT & GROUPS PICKER */}
            {chatModalTab === 'direct' && (
              <div className="space-y-4 flex-1 flex flex-col overflow-hidden">
                <p className="text-xs text-neutral-500">
                  Select a friend, followed person, or your custom group:
                </p>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={directUserSearch}
                    onChange={(e) => setDirectUserSearch(e.target.value)}
                    placeholder="Search by name, handle, or group..."
                    className="w-full pl-8 pr-3 py-2 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
                  />
                </div>

                <div className="flex-1 overflow-y-auto space-y-4 pr-1">
                  {/* 1. FRIENDS */}
                  <div>
                    <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2 px-1">
                      Friends ({friendsList.length})
                    </h4>
                    {friendsList.length === 0 ? (
                      <p className="text-xs text-neutral-400 px-1 italic">No friends added yet.</p>
                    ) : (
                      <div className="border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                        {friendsList
                          .filter((u) => !directUserSearch.trim() || u.name.toLowerCase().includes(directUserSearch.toLowerCase()) || u.userId.toLowerCase().includes(directUserSearch.toLowerCase()))
                          .map((u) => (
                            <div key={u.uid} className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors">
                              <div className="flex items-center gap-2.5 min-w-0">
                                {u.avatarUrl ? (
                                  <img src={u.avatarUrl} alt={u.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200" />
                                ) : (
                                  <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                                    {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                                  </div>
                                )}
                                <div className="min-w-0">
                                  <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                                  <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectChat(u)}
                                  className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer"
                                >
                                  <MessageSquare className="w-3 h-3" />
                                  <span>Chat</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectVoiceCall(u)}
                                  className="p-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 cursor-pointer"
                                  title="Voice Call"
                                >
                                  <Phone className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectVideoCall(u)}
                                  className="p-1.5 rounded-xl bg-neutral-100 hover:bg-emerald-50 text-neutral-700 hover:text-emerald-700 cursor-pointer"
                                  title="Video Call"
                                >
                                  <Video className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>

                  {/* 2. PEOPLE THEY FOLLOW */}
                  <div>
                    <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2 px-1">
                      People You Follow ({followingList.length})
                    </h4>
                    {followingList.length === 0 ? (
                      <p className="text-xs text-neutral-400 px-1 italic">Not following anyone yet.</p>
                    ) : (
                      <div className="border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                        {followingList
                          .filter((u) => !directUserSearch.trim() || u.name.toLowerCase().includes(directUserSearch.toLowerCase()) || u.userId.toLowerCase().includes(directUserSearch.toLowerCase()))
                          .map((u) => (
                            <div key={u.uid} className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors">
                              <div className="flex items-center gap-2.5 min-w-0">
                                {u.avatarUrl ? (
                                  <img src={u.avatarUrl} alt={u.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200" />
                                ) : (
                                  <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                                    {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                                  </div>
                                )}
                                <div className="min-w-0">
                                  <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                                  <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectChat(u)}
                                  className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer"
                                >
                                  <MessageSquare className="w-3 h-3" />
                                  <span>Chat</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectVoiceCall(u)}
                                  className="p-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 cursor-pointer"
                                  title="Voice Call"
                                >
                                  <Phone className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectVideoCall(u)}
                                  className="p-1.5 rounded-xl bg-neutral-100 hover:bg-emerald-50 text-neutral-700 hover:text-emerald-700 cursor-pointer"
                                  title="Video Call"
                                >
                                  <Video className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>

                  {/* 3. THE GROUPS THEY HAVE MADE */}
                  <div>
                    <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2 px-1">
                      Groups You Have Made ({customGroupsMade.length})
                    </h4>
                    {customGroupsMade.length === 0 ? (
                      <p className="text-xs text-neutral-400 px-1 italic">No custom groups created yet. Group individuals in the Social hub.</p>
                    ) : (
                      <div className="border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                        {customGroupsMade
                          .filter((g) => !directUserSearch.trim() || g.name.toLowerCase().includes(directUserSearch.toLowerCase()) || (g.description && g.description.toLowerCase().includes(directUserSearch.toLowerCase())))
                          .map((group) => (
                            <div key={group.id} className="p-3 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors">
                              <div className="flex items-center gap-3 min-w-0">
                                <div
                                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 border border-black/10 shadow-2xs text-white text-xs font-bold"
                                  style={{ backgroundColor: group.color || '#f59e0b' }}
                                >
                                  {group.name.charAt(0).toUpperCase()}
                                </div>
                                <div className="min-w-0">
                                  <p className="text-xs font-semibold text-black truncate">{group.name}</p>
                                  <p className="text-[10px] text-neutral-500 truncate">{group.memberUids.length} members assigned</p>
                                </div>
                              </div>
                              <span className="text-[10px] px-2 py-1 rounded-full bg-neutral-100 font-medium text-neutral-700 shrink-0">
                                Custom Group
                              </span>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: GROUP CREATION (MAX 20) */}
            {chatModalTab === 'group' && (
              <form onSubmit={handleCreateGroupSubmit} className="space-y-4 flex-1 flex flex-col overflow-hidden">
                {groupCreateError && (
                  <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs flex items-center gap-2">
                    <Info className="w-4 h-4 shrink-0" />
                    <span>{groupCreateError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Group Room Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Zurich Freeport Syndicate / Sovereign Alpha"
                    value={groupNameInput}
                    onChange={(e) => setGroupNameInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs sm:text-sm focus:outline-none focus:border-black"
                    required
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-neutral-700">
                      Select Members ({selectedGroupMemberUids.size}/{MAX_GROUP_MEMBERS - 1} Selected)
                    </label>
                  </div>

                  <div className="relative mb-2">
                    <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={groupMemberSearch}
                      onChange={(e) => setGroupMemberSearch(e.target.value)}
                      placeholder="Search people to add..."
                      className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
                    />
                  </div>

                  <div className="max-h-44 overflow-y-auto border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                    {availableUsers
                      .filter((u) => u.name.toLowerCase().includes(groupMemberSearch.toLowerCase()) || u.userId.toLowerCase().includes(groupMemberSearch.toLowerCase()))
                      .map((u) => {
                        const isSelected = selectedGroupMemberUids.has(u.uid);
                        return (
                          <button
                            key={u.uid}
                            type="button"
                            onClick={() => {
                              setSelectedGroupMemberUids((prev) => {
                                const next = new Set(prev);
                                if (next.has(u.uid)) next.delete(u.uid);
                                else {
                                  if (next.size >= MAX_GROUP_MEMBERS - 1) {
                                    alert(`Maximum ${MAX_GROUP_MEMBERS} members allowed`);
                                    return next;
                                  }
                                  next.add(u.uid);
                                }
                                return next;
                              });
                            }}
                            className={`w-full p-2 rounded-xl flex items-center justify-between text-left transition-colors cursor-pointer ${
                              isSelected ? 'bg-neutral-100 font-medium' : 'hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              {u.avatarUrl ? (
                                <img src={u.avatarUrl} alt={u.name} className="w-7 h-7 rounded-full object-cover" />
                              ) : (
                                <div className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                                  {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                                </div>
                              )}
                              <div className="min-w-0">
                                <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                                <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                              </div>
                            </div>

                            <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                              isSelected ? 'bg-black text-white border-black' : 'border-neutral-300'
                            }`}>
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                          </button>
                        );
                      })}
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowNewChatModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isCreatingGroup}
                    className="min-h-[38px] px-5 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer shadow-xs disabled:opacity-50 flex items-center gap-1.5"
                  >
                    {isCreatingGroup ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <>
                        <Users className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Start Group Room</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: ADD MEMBER TO ACTIVE GROUP ================= */}
      {showAddMemberModal && selectedConversation?.type === 'group' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <div>
                <h3 className="font-serif-lux text-xl font-normal text-black">
                  Invite Member to Room
                </h3>
                <p className="text-xs text-neutral-500">
                  {selectedConversation.participantIds.length} / {MAX_GROUP_MEMBERS} active participants
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddMemberModal(false)}
                className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={addMemberSearch}
                onChange={(e) => setAddMemberSearch(e.target.value)}
                placeholder="Search community member..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
              />
            </div>

            <div className="max-h-60 overflow-y-auto border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
              {availableUsers
                .filter((u) => !selectedConversation.participantIds.includes(u.uid))
                .filter((u) => u.name.toLowerCase().includes(addMemberSearch.toLowerCase()) || u.userId.toLowerCase().includes(addMemberSearch.toLowerCase()))
                .map((u) => (
                  <div
                    key={u.uid}
                    className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {u.avatarUrl ? (
                        <img
                          src={u.avatarUrl}
                          alt={u.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                          {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                        <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={selectedConversation.participantIds.length >= MAX_GROUP_MEMBERS}
                      onClick={() => handleAddMemberToActiveGroup(u)}
                      className="min-h-[32px] px-3.5 py-1 rounded-full bg-black hover:bg-neutral-800 disabled:opacity-50 text-white text-xs font-medium cursor-pointer shadow-2xs"
                    >
                      Add
                    </button>
                  </div>
                ))}
            </div>
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: EJECT MEMBER CONFIRMATION (CREATOR ONLY) ================= */}
      {memberToEject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-left border border-neutral-200"
          >
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
              <UserMinus className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif-lux text-xl text-black font-normal">
                Eject Member from Group?
              </h3>
              <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                Are you sure you want to eject <strong>{memberToEject.name}</strong> (@{memberToEject.userId}) from <strong>{selectedConversation?.name}</strong>? They will be removed from this text chat and disconnected from all active conference calls.
              </p>
            </div>

            {groupActionError && (
              <div className="p-2.5 rounded-xl bg-red-50 text-red-700 text-xs flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{groupActionError}</span>
              </div>
            )}

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setMemberToEject(null)}
                disabled={isEjecting}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmEjectMember}
                disabled={isEjecting}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                {isEjecting ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <UserMinus className="w-3.5 h-3.5" />
                    <span>Eject Member</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: END & DISBAND GROUP ROOM (CREATOR ONLY) ================= */}
      {showEndGroupConfirm && selectedConversation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-left border border-neutral-200"
          >
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif-lux text-xl text-black font-normal">
                End &amp; Disband Group Room?
              </h3>
              <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                As the room creator, ending <strong>"{selectedConversation.name}"</strong> will permanently delete this group room and terminate all active text threads and audio/video conference calls for all <strong>{selectedConversation.participantIds.length} members</strong>. This action cannot be undone.
              </p>
            </div>

            {groupActionError && (
              <div className="p-2.5 rounded-xl bg-red-50 text-red-700 text-xs flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{groupActionError}</span>
              </div>
            )}

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowEndGroupConfirm(false)}
                disabled={isEndingGroup}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmEndGroup}
                disabled={isEndingGroup}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                {isEndingGroup ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>End Group Room</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: LEAVE GROUP ROOM (MEMBER) ================= */}
      {showLeaveGroupConfirm && selectedConversation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-left border border-neutral-200"
          >
            <div className="w-12 h-12 rounded-2xl bg-neutral-100 text-neutral-700 flex items-center justify-center">
              <LogOut className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif-lux text-xl text-black font-normal">
                Leave Group Room?
              </h3>
              <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                Are you sure you want to leave <strong>"{selectedConversation.name}"</strong>? You will no longer receive messages or be able to join conference calls in this group.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowLeaveGroupConfirm(false)}
                disabled={isLeavingGroup}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmLeaveGroup}
                disabled={isLeavingGroup}
                className="px-5 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-bold cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                {isLeavingGroup ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Leave Room</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
