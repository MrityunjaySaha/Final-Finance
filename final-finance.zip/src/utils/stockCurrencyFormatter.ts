import { StockItem } from '../types/stocks';

export interface StockCurrencyInfo {
  code: string;
  isFinal: boolean;
  isUSD: boolean;
  isStable: boolean;
  isCrypto: boolean;
  cryptoRateUSD: number;
}

/**
 * Standard exchange rates in USD for cryptocurrencies.
 */
export const CRYPTO_RATES_USD: Record<string, number> = {
  BTC: 65000.0,  // 1 BTC = $65,000.00 USD
  ETH: 3400.0,   // 1 ETH = $3,400.00 USD
  SOL: 180.0,    // 1 SOL = $180.00 USD
};

/**
 * Inspects a stock item and determines its currency code, market category, and exchange rate.
 */
export function getStockCurrencyInfo(stock?: StockItem | null): StockCurrencyInfo {
  if (!stock) {
    return { code: 'USD', isFinal: false, isUSD: true, isStable: false, isCrypto: false, cryptoRateUSD: 1.0 };
  }

  const rawSymbol = stock.issuanceCoinSymbol || '';
  const cleanedSymbol = rawSymbol.replace('$', '').trim();
  const marketType = stock.marketType;

  // 1. Stablecoins (1:1 USD Pegged)
  const isStable =
    marketType === 'stable' ||
    cleanedSymbol === 'USDC' ||
    cleanedSymbol === 'USDT';

  // 2. Cryptocurrencies (Convertible to USD)
  const isCrypto =
    marketType === 'crypto' ||
    cleanedSymbol === 'BTC' ||
    cleanedSymbol === 'ETH' ||
    cleanedSymbol === 'SOL';

  // 3. Fiat (US Equities / US Dollar)
  const isUSD =
    marketType === 'fiat' ||
    marketType === 'global' ||
    cleanedSymbol === 'USD' ||
    stock.exchange === 'NASDAQ' ||
    stock.exchange === 'NYSE';

  // 4. Final Coins (Unpegged Sovereign Assets)
  const isFinal =
    !isStable &&
    !isCrypto &&
    !isUSD &&
    (marketType === 'final' ||
     cleanedSymbol === 'AFNL' ||
     cleanedSymbol === 'AFNL' ||
     stock.exchange === 'SOVEREIGN_NODE');

  if (isFinal) {
    return {
      code: cleanedSymbol || 'AFNL',
      isFinal: true,
      isUSD: false,
      isStable: false,
      isCrypto: false,
      cryptoRateUSD: 1.0,
    };
  }

  if (isStable) {
    return {
      code: cleanedSymbol || 'USDC',
      isFinal: false,
      isUSD: false,
      isStable: true,
      isCrypto: false,
      cryptoRateUSD: 1.0,
    };
  }

  if (isCrypto) {
    const code = cleanedSymbol || 'BTC';
    const cryptoRateUSD = CRYPTO_RATES_USD[code] || 65000.0;
    return {
      code,
      isFinal: false,
      isUSD: false,
      isStable: false,
      isCrypto: true,
      cryptoRateUSD,
    };
  }

  // Fallback to USD Fiat
  return {
    code: 'USD',
    isFinal: false,
    isUSD: true,
    isStable: false,
    isCrypto: false,
    cryptoRateUSD: 1.0,
  };
}

/**
 * Checks if a stock is a Final Stock (settled in Final Coins like AFNL/AFNL).
 */
export function isFinalStock(stock: StockItem): boolean {
  return getStockCurrencyInfo(stock).isFinal;
}

/**
 * Returns the currency symbol or ticker code for a given stock.
 */
export function getStockCurrencyCode(stock: StockItem): string {
  return getStockCurrencyInfo(stock).code;
}

/**
 * Returns the US Dollar equivalent string for stable coins and crypto.
 * Returns null for Final Coins (unpegged sovereign assets) and US Dollar itself.
 */
export function getUSDEquivalentString(amountUSD: number, stock?: StockItem | null): string | null {
  if (amountUSD === undefined || amountUSD === null || isNaN(amountUSD)) return null;
  const info = getStockCurrencyInfo(stock);

  // Final coins are unpegged and non-derivable to USD; USD itself is natively in USD
  if (info.isFinal || info.isUSD) {
    return null;
  }

  const formattedUSD = amountUSD.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return `≈ $${formattedUSD} USD`;
}

/**
 * Formats a numerical stock price:
 * - Final Stock: "125.00 AFNL" (Unpegged sovereign coin, native units only)
 * - Fiat Stock (US Market): "$125.00"
 * - Stable Coins (1:1 Pegged): "30.00 USDC (≈ $30.00 USD)"
 * - Cryptocurrencies (e.g. 1 BTC = $25 USD, 1 BTC = $65k):
 *     "0.67 BTC (≈ $16.68 USD)"
 *     "0.000257 BTC (≈ $16.68 USD)"
 */
export function formatStockPrice(priceUSD: number, stock: StockItem, showEquivalent: boolean = true): string {
  if (priceUSD === undefined || priceUSD === null || isNaN(priceUSD)) return '0.00';

  const info = getStockCurrencyInfo(stock);

  if (info.isFinal) {
    const formattedNum = priceUSD.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return `${formattedNum} ${info.code}`;
  }

  if (info.isUSD) {
    const formattedNum = priceUSD.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return `$${formattedNum}`;
  }

  if (info.isCrypto) {
    // Convert USD price to native crypto units based on exchange rate
    const nativeCryptoAmount = priceUSD / info.cryptoRateUSD;

    // Determine precision: high precision for BTC/ETH, standard for BTC/SOL
    let decimals = 4;
    if (nativeCryptoAmount < 0.01) decimals = 6;
    else if (nativeCryptoAmount >= 100) decimals = 2;

    const formattedCrypto = nativeCryptoAmount.toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });

    const eqStr = showEquivalent ? getUSDEquivalentString(priceUSD, stock) : null;
    return eqStr ? `${formattedCrypto} ${info.code} (${eqStr})` : `${formattedCrypto} ${info.code}`;
  }

  // Stable Coins (1:1 USD peg)
  const formattedStable = priceUSD.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  const eqStr = showEquivalent ? getUSDEquivalentString(priceUSD, stock) : null;
  return eqStr ? `${formattedStable} ${info.code} (${eqStr})` : `${formattedStable} ${info.code}`;
}

/**
 * Formats market cap / valuation strings:
 * - Final Stock: "148.5B AFNL"
 * - Fiat Stock: "$46.8T"
 * - Stable Coins: "2.15T USDC (≈ $2.15T USD)"
 * - Cryptocurrencies: "1.85T BTC (≈ $1.85T USD)"
 */
export function formatStockMarketCap(stock: StockItem, showEquivalent: boolean = true): string {
  if (!stock) return 'N/A';
  const info = getStockCurrencyInfo(stock);
  const rawCap = stock.marketCap || 'N/A';

  if (info.isFinal) {
    const cleanCap = rawCap.replace(/^\$/, '').trim();
    return cleanCap.includes(info.code) ? cleanCap : `${cleanCap} ${info.code}`;
  }

  if (info.isUSD) {
    return rawCap.startsWith('$') ? rawCap : `$${rawCap}`;
  }

  const cleanCap = rawCap.replace(/^\$/, '').trim();
  const capWithCode = cleanCap.includes(info.code) ? cleanCap : `${cleanCap} ${info.code}`;

  if (showEquivalent) {
    return `${capWithCode} (≈ $${cleanCap} USD)`;
  }
  return capWithCode;
}

/**
 * Formats an order or trade amount in USD, Final Coin, Stable Coin, or Crypto depending on the stock type:
 * - Final Stock: "334.68 AFNL"
 * - Fiat Stock: "$334.68"
 * - Stable Coins: "334.68 USDC (≈ $334.68 USD)"
 * - Cryptocurrencies (e.g. 1 BTC = $25 USD): "13.39 BTC (≈ $334.68 USD)"
 */
export function formatStockAmount(amountUSD: number, stock?: StockItem | null, showEquivalent: boolean = true): string {
  if (amountUSD === undefined || amountUSD === null || isNaN(amountUSD)) return '0.00';

  const info = getStockCurrencyInfo(stock);

  if (info.isFinal) {
    const formattedNum = amountUSD.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return `${formattedNum} ${info.code}`;
  }

  if (info.isUSD) {
    const formattedNum = amountUSD.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return `$${formattedNum}`;
  }

  if (info.isCrypto) {
    const nativeCryptoAmount = amountUSD / info.cryptoRateUSD;
    let decimals = 4;
    if (nativeCryptoAmount < 0.01) decimals = 6;
    else if (nativeCryptoAmount >= 100) decimals = 2;

    const formattedCrypto = nativeCryptoAmount.toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });

    const eqStr = showEquivalent ? getUSDEquivalentString(amountUSD, stock) : null;
    return eqStr ? `${formattedCrypto} ${info.code} (${eqStr})` : `${formattedCrypto} ${info.code}`;
  }

  // Stablecoins
  const formattedNum = amountUSD.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  const eqStr = showEquivalent ? getUSDEquivalentString(amountUSD, stock) : null;
  return eqStr ? `${formattedNum} ${info.code} (${eqStr})` : `${formattedNum} ${info.code}`;
}



