import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Twitter,
  Tag,
  Upload,
  Image as ImageIcon,
  Video,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { getCurrentSession } from '../services/firebaseAuth';
import { TweetLinkPreview, TWEETING_MAX_CHARS } from '../types/tweet';
import { ExternalLinkPreviewData, extractExternalUrls } from '../utils/linkPreviewUtils';
import { TweetRichEmbeds } from './social/TweetRichEmbeds';

export interface TweetingComposerSubmitPayload {
  content: string;
  photos: string[];
  videos: string[];
  linkPreviews?: Record<string, TweetLinkPreview>;
}

interface TweetingComposerModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  badgeText?: string;
  initialDescription?: string;
  placeholder?: string;
  suggestedHashtags?: string[];
  existingPhotos?: string[];
  existingVideos?: string[];
  existingMediaLabel?: string;
  topControls?: React.ReactNode;
  previewCard?: React.ReactNode;
  previewLabel?: string;
  submitLabel?: string;
  currentUser?: AuthSession | null;
  onPost: (payload: TweetingComposerSubmitPayload) => void | Promise<void>;
}

export const TweetingComposerModal: React.FC<TweetingComposerModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle = 'Add your description, photos, and videos to broadcast on Tweet',
  badgeText = 'Share on Tweet',
  initialDescription = '',
  placeholder = 'Write your description for Tweet...',
  suggestedHashtags = ['#FinalFinance', '#SovereignMarkets'],
  existingPhotos = [],
  existingVideos = [],
  existingMediaLabel,
  topControls,
  previewCard,
  previewLabel = 'Embedded Post Preview',
  submitLabel = 'Post to Tweet',
  currentUser,
  onPost,
}) => {
  const [description, setDescription] = useState(() =>
    initialDescription.slice(0, TWEETING_MAX_CHARS)
  );
  const [extraPhotos, setExtraPhotos] = useState<string[]>([]);
  const [extraVideos, setExtraVideos] = useState<string[]>([]);
  const [mediaUrlInput, setMediaUrlInput] = useState('');
  const [includeExistingMedia, setIncludeExistingMedia] = useState(true);
  const [isPosting, setIsPosting] = useState(false);
  const [linkPreviews, setLinkPreviews] = useState<Record<string, ExternalLinkPreviewData>>({});
  const [linkOverrides, setLinkOverrides] = useState<Record<string, Partial<ExternalLinkPreviewData>>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const mergedLinkPreviews = useMemo(() => {
    const urls = extractExternalUrls(description);
    if (urls.length === 0) return undefined;
    const out: Record<string, TweetLinkPreview> = {};
    for (const url of urls) {
      const base = linkPreviews[url];
      const override = linkOverrides[url];
      if (base || override) {
        out[url] = {
          ...(base || {
            url,
            domain: (() => {
              try {
                return new URL(url).hostname.replace(/^www\./, '');
              } catch {
                return 'external';
              }
            })(),
            title: url,
            description: '',
          }),
          ...(override || {}),
          url,
          resolved: Boolean(base?.resolved || override),
        };
      }
    }
    return Object.keys(out).length > 0 ? out : undefined;
  }, [description, linkPreviews, linkOverrides]);

  useEffect(() => {
    if (isOpen) {
      setDescription(initialDescription.slice(0, TWEETING_MAX_CHARS));
      setExtraPhotos([]);
      setExtraVideos([]);
      setMediaUrlInput('');
      setIncludeExistingMedia(true);
      setLinkPreviews({});
      setLinkOverrides({});
    }
  }, [isOpen, initialDescription]);

  if (!isOpen) return null;

  const session = currentUser || getCurrentSession();
  const authorName = session?.name || 'Ranma';
  const authorHandle = (
    session?.handle ||
    session?.id ||
    (session?.email ? session.email.split('@')[0] : '') ||
    'super_admin_ranma'
  ).replace(/^@/, '');
  const authorAvatar =
    session?.avatarUrl ||
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80';

  const cleanExistingPhotos = existingPhotos.filter(Boolean);
  const cleanExistingVideos = existingVideos.filter(Boolean);

  const toggleHashtag = (tag: string) => {
    if (description.includes(tag)) {
      setDescription((prev) =>
        prev.replace(tag, '').replace(/\s{2,}/g, ' ').trim()
      );
    } else {
      setDescription((prev) => {
        const next = prev ? `${prev} ${tag}` : tag;
        return next.slice(0, TWEETING_MAX_CHARS);
      });
    }
  };

  const handleFilePick = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          if (file.type.startsWith('video/')) {
            setExtraVideos((prev) => [...prev, reader.result as string]);
          } else if (file.type.startsWith('image/')) {
            setExtraPhotos((prev) => [...prev, reader.result as string]);
          }
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleAttachMediaUrl = () => {
    const url = mediaUrlInput.trim();
    if (!url) return;
    if (/\.(mp4|webm|mov|ogg)(\?|$)/i.test(url) || url.startsWith('data:video/')) {
      setExtraVideos((prev) => [...prev, url]);
    } else {
      setExtraPhotos((prev) => [...prev, url]);
    }
    setMediaUrlInput('');
  };

  const handleSubmit = async () => {
    if (isPosting) return;
    setIsPosting(true);
    try {
      const finalPhotos = Array.from(
        new Set([
          ...(includeExistingMedia ? cleanExistingPhotos : []),
          ...extraPhotos,
        ])
      );
      const finalVideos = Array.from(
        new Set([
          ...(includeExistingMedia ? cleanExistingVideos : []),
          ...extraVideos,
        ])
      );

      await onPost({
        content: description.trim().slice(0, TWEETING_MAX_CHARS),
        photos: finalPhotos,
        videos: finalVideos,
        linkPreviews: mergedLinkPreviews,
      });
      onClose();
    } finally {
      setIsPosting(false);
    }
  };

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full max-h-[92vh] overflow-hidden flex flex-col items-center text-center mx-auto my-auto relative"
        >
          {/* Fundraiser-style Dark Header */}
          <div className="relative w-full bg-neutral-950 text-white pt-5 pb-4 px-6 border-b border-neutral-800 flex flex-col items-center text-center">
            <button
              type="button"
              onClick={onClose}
              className="absolute right-4 top-4 p-2 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold uppercase tracking-wider mb-1.5">
              <span className="w-4 h-4 rounded bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Twitter className="w-2.5 h-2.5 -scale-x-100 -rotate-12 fill-white" />
              </span>
              <span>{badgeText}</span>
            </div>

            <h3 className="font-serif text-base sm:text-lg font-bold text-white text-center leading-snug">
              {title}
            </h3>
            {subtitle && (
              <p className="text-xs text-neutral-400 mt-0.5 text-center">
                {subtitle}
              </p>
            )}
          </div>

          {/* Modal Body */}
          <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[calc(92vh-130px)] w-full text-center flex flex-col items-center">
            {/* Author Row */}
            <div className="flex items-center justify-center gap-3 w-full py-1">
              <img
                src={authorAvatar}
                alt={authorName}
                className="w-10 h-10 rounded-full object-cover border border-slate-200 shadow-2xs"
              />
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-bold text-slate-900">{authorName}</span>
                  <span className="text-xs text-slate-500 font-mono">@{authorHandle}</span>
                </div>
                <span className="text-[11px] text-emerald-700 font-medium">
                  Posting to Tweet Public Feed
                </span>
              </div>
            </div>

            {/* Optional Custom Controls (e.g., Trade Action / Shares Selector) */}
            {topControls && (
              <div className="w-full space-y-3 text-left">{topControls}</div>
            )}

            {/* Description Textarea (Strictly limited to TWEETING_MAX_CHARS = 500) */}
            <div className="w-full space-y-2 text-center">
              <div className="relative">
                <textarea
                  value={description}
                  maxLength={TWEETING_MAX_CHARS}
                  onChange={(e) =>
                    setDescription(e.target.value.slice(0, TWEETING_MAX_CHARS))
                  }
                  placeholder={placeholder}
                  rows={3}
                  className="w-full p-3.5 rounded-2xl border border-slate-200 bg-slate-50 text-slate-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all resize-none shadow-inner"
                />
                <div className="flex items-center justify-between text-[11px] font-mono px-1 text-slate-400">
                  <span className="flex items-center gap-1 text-slate-500">
                    <Tag className="w-3 h-3 text-slate-400" />
                    Quick Tags
                  </span>
                  <span
                    className={`tabular-nums ${
                      description.length > TWEETING_MAX_CHARS - 30
                        ? 'text-amber-600 font-bold'
                        : 'text-slate-400'
                    }`}
                  >
                    {description.length} / {TWEETING_MAX_CHARS}
                  </span>
                </div>
              </div>

              {suggestedHashtags.length > 0 && (
                <div className="flex items-center justify-center flex-wrap gap-1.5">
                  {suggestedHashtags.map((tag) => {
                    const isActive = description.includes(tag);
                    return (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => toggleHashtag(tag)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-colors cursor-pointer border ${
                          isActive
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                            : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                        }`}
                      >
                        {tag}
                      </button>
                    );
                  })}
                </div>
              )}

              {extractExternalUrls(description).length > 0 && (
                <div className="pt-1">
                  <TweetRichEmbeds
                    content={description}
                    savedLinkPreviews={mergedLinkPreviews}
                    onLinkPreviewsResolved={(resolved) =>
                      setLinkPreviews((prev) => ({ ...prev, ...resolved }))
                    }
                    editableLinks
                    onEditLinkPreview={(url, override) => {
                      setLinkOverrides((prev) => {
                        if (!override) {
                          const next = { ...prev };
                          delete next[url];
                          return next;
                        }
                        return { ...prev, [url]: override };
                      });
                    }}
                    compact
                  />
                </div>
              )}
            </div>

            {/* Additional Photos & Videos Section */}
            <div className="w-full p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5 text-center">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11px] font-bold text-slate-800 font-mono uppercase flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Photos &amp; Videos</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500 tabular-nums">
                  {extraPhotos.length} photos · {extraVideos.length} videos added
                </span>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                multiple
                className="hidden"
                onChange={(e) => {
                  handleFilePick(e.target.files);
                  e.target.value = '';
                }}
              />

              <div className="flex flex-col sm:flex-row items-center gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full sm:w-auto px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-xs font-bold text-slate-800 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Add Photos / Videos</span>
                </button>
                <div className="flex items-center gap-1.5 w-full">
                  <input
                    type="url"
                    placeholder="Or paste photo/video URL..."
                    value={mediaUrlInput}
                    onChange={(e) => setMediaUrlInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAttachMediaUrl();
                      }
                    }}
                    className="flex-1 px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-xs min-w-0"
                  />
                  <button
                    type="button"
                    onClick={handleAttachMediaUrl}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold cursor-pointer shrink-0"
                  >
                    Attach
                  </button>
                </div>
              </div>

              {(cleanExistingPhotos.length > 0 || cleanExistingVideos.length > 0) && (
                <label className="flex items-center justify-center gap-2 text-[11px] text-slate-700 cursor-pointer pt-0.5">
                  <input
                    type="checkbox"
                    checked={includeExistingMedia}
                    onChange={(e) => setIncludeExistingMedia(e.target.checked)}
                    className="rounded text-emerald-600"
                  />
                  <span>
                    {existingMediaLabel ||
                      `Include existing gallery media (${cleanExistingPhotos.length} photos, ${cleanExistingVideos.length} videos)`}
                  </span>
                </label>
              )}

              {(extraPhotos.length > 0 || extraVideos.length > 0) && (
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  {extraPhotos.map((pUrl, idx) => (
                    <div
                      key={`twc-ep-${idx}`}
                      className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-300 bg-white"
                    >
                      <img src={pUrl} alt="" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() =>
                          setExtraPhotos((prev) => prev.filter((_, i) => i !== idx))
                        }
                        className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/75 text-white text-[10px] flex items-center justify-center cursor-pointer"
                        aria-label="Remove photo"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                  {extraVideos.map((vUrl, idx) => (
                    <div
                      key={`twc-ev-${idx}`}
                      className="relative w-24 h-16 rounded-xl overflow-hidden border border-emerald-300 bg-black flex items-center justify-center"
                    >
                      <video src={vUrl} className="w-full h-full object-cover opacity-80" />
                      <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/70 text-white text-[9px] font-mono flex items-center gap-0.5">
                        <Video className="w-2.5 h-2.5" />
                        V{idx + 1}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setExtraVideos((prev) => prev.filter((_, i) => i !== idx))
                        }
                        className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-black/75 text-white text-[10px] flex items-center justify-center cursor-pointer"
                        aria-label="Remove video"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Embedded Preview Card */}
            {previewCard && (
              <div className="w-full text-center space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block text-center">
                  {previewLabel}
                </span>
                {previewCard}
              </div>
            )}

            {/* Actions */}
            <div className="grid grid-cols-2 gap-3 w-full pt-1">
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={isPosting}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-300 text-white text-xs sm:text-sm font-bold transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Twitter className="w-4 h-4 -scale-x-100 -rotate-12 fill-white" />
                <span>{isPosting ? 'Posting...' : submitLabel}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
