import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { getStoredCustomCoins } from '../data/customCoinsData';
import { getAllWorldCurrencies } from '../data/worldCurrenciesData';
import { TransactionMode, UniversalLedgerItem } from '../types/ledger';
import { AuctionBid, AuctionConfig, SettlementMethod } from '../types/marketplace';
import {
  createLedgerItemFromBarter,
  createLedgerItemFromMarketplacePurchase,
  recordLedgerTransaction
} from '../utils/universalLedgerBridge';
import {
  getAuctionBids,
  getAuctionRemainingLabel,
  getMinimumNextBidUSD,
  saveAuctionBidsForListing,
  submitBarterTradeProposal,
  updateListingAuctionState,
  updateListingStatus,
} from './marketplaceService';
import { areUsersBlockedEitherWay, enqueueUserNotification, isAdminAccount } from './socialService';

export type CurrencyTypeId = 'final_coins' | 'stable_coins' | 'fiat' | 'crypto';
export type SettlementModeId = CurrencyTypeId | 'barter';

export interface TargetListingForTrade {
  id: string;
  title: string;
  sellerId: string;
  sellerName: string;
  sellerHandle?: string;
  estimatedValueUSD?: number;
  priceUSD?: number;
  primaryPriceUSD?: number;
  priceInNative?: string;
  category?: string;
  imageUrl?: string;
  itemType?: 'good' | 'service';
  listingIntent?: 'sell' | 'buy' | 'auction';
  auctionConfig?: AuctionConfig;
  primaryTradeMode?: 'currency' | 'barter';
  primaryCurrency?: string;
  acceptedSettlements?: SettlementMethod[];
  acceptedCurrencyList?: string[];
  finalCoinsPricing?: { symbol: string; amount: number };
  stableCoinsPricing?: { symbol: string; amount: number; network?: string };
  fiatPricing?: { currencyCode: string; amount: number };
  cryptoPricing?: { symbol: string; amount: number; network?: string };
  barterDesired?: string;
  barterTerms?: {
    desiredTrades: string;
    desiredExchangeType?: 'good' | 'service' | 'any';
    openToOffers: boolean;
    estimatedValueUSD?: number;
  };
  quantity?: number;
  unitLabel?: string;
  availableUnits?: number;
  unitType?: string;
  turnaroundTime?: string;
  deliverables?: string;
  condition?: string;
  location?: string;
  status?: string;
}

export interface SettlementCoinOption {
  symbol: string;
  name: string;
  currencyType: CurrencyTypeId;
  mode: TransactionMode;
  walletBalance: number;
  linkedBankBalanceUnits: number;
  linkedBankName?: string;
  totalAvailableUnits: number;
  unitPriceUSD: number;
  requiredUnits: number;
  hasSufficientBalance: boolean;
  isSellerPreferred: boolean;
  network?: string;
  decimals: number;
  badge: string;
}

export interface DealExecutionResult {
  success: boolean;
  error?: string;
  ledgerItem?: UniversalLedgerItem;
  proposalId?: string;
  settlementMode: SettlementModeId;
  coinSymbol?: string;
  paidUnits?: number;
  amountUSD: number;
  assetEnrolledName?: string;
  remainingQuantity?: number;
  markedSold?: boolean;
}

const AFNL_BENCHMARK_USD = 20;

export const CURRENCY_TYPE_META: Record<
  CurrencyTypeId,
  { label: string; shortLabel: string; description: string }
> = {
  final_coins: {
    label: 'Final Coins',
    shortLabel: 'Final Coins',
    description: 'Native ecosystem settlement tokens (AFNL & peer Final Coins)',
  },
  stable_coins: {
    label: 'Stablecoins',
    shortLabel: 'Stablecoins',
    description: 'USD / Gold / Euro pegged digital settlement assets (USDC, PAXG, EURC, USDT)',
  },
  fiat: {
    label: 'Fiat Currency',
    shortLabel: 'Fiat Currency',
    description: 'Treasury & Bank Reserve Currencies (USD, CHF, EUR, GBP)',
  },
  crypto: {
    label: 'Cryptocurrency',
    shortLabel: 'Crypto',
    description: 'Layer-1 Digital Assets (BTC, ETH, SOL & listed cryptocurrencies)',
  },
};

export function getListingValuationUSD(listing?: Partial<TargetListingForTrade> | null): number {
  if (!listing) return 0;
  const raw =
    listing.estimatedValueUSD ??
    listing.priceUSD ??
    listing.primaryPriceUSD ??
    listing.barterTerms?.estimatedValueUSD ??
    0;
  return Number(raw) > 0 ? Number(raw) : 0;
}

export function getAllowedSettlementModes(
  listing?: Partial<TargetListingForTrade> | null
): SettlementModeId[] {
  if (!listing) {
    return ['final_coins', 'stable_coins', 'fiat', 'crypto', 'barter'];
  }
  if (Array.isArray(listing.acceptedSettlements) && listing.acceptedSettlements.length > 0) {
    return Array.from(new Set(listing.acceptedSettlements)) as SettlementModeId[];
  }
  const inferred: SettlementModeId[] = [];
  if (listing.finalCoinsPricing || listing.acceptedCurrencyList?.includes('AFNL')) {
    inferred.push('final_coins');
  }
  if (
    listing.stableCoinsPricing ||
    listing.acceptedCurrencyList?.some((c) => ['USDC', 'USDT', 'PAXG', 'EURC', 'EURS'].includes(c.toUpperCase()))
  ) {
    inferred.push('stable_coins');
  }
  if (
    listing.fiatPricing ||
    listing.acceptedCurrencyList?.some((c) => ['USD', 'EUR', 'GBP', 'CHF'].includes(c.toUpperCase()))
  ) {
    inferred.push('fiat');
  }
  if (
    listing.cryptoPricing ||
    listing.acceptedCurrencyList?.some((c) => ['BTC', 'ETH', 'SOL'].includes(c.toUpperCase()))
  ) {
    inferred.push('crypto');
  }
  if (listing.barterDesired || listing.barterTerms?.desiredTrades || listing.primaryTradeMode === 'barter') {
    inferred.push('barter');
  }
  return inferred.length > 0 ? inferred : ['final_coins', 'stable_coins', 'fiat', 'crypto', 'barter'];
}

export function getListingSettlementSummary(
  listing?: Partial<TargetListingForTrade> | null
): string {
  const modes = getAllowedSettlementModes(listing);
  const parts: string[] = [];
  const listed = (listing?.acceptedCurrencyList || []).map((c) => c.toUpperCase());

  if (modes.includes('fiat')) {
    const fiatSym = listed.find((c) => ['USD', 'EUR', 'GBP', 'CHF'].includes(c)) || 'Fiat';
    parts.push(fiatSym);
  }
  if (modes.includes('final_coins')) {
    parts.push('AFNL');
  }
  if (modes.includes('stable_coins')) {
    const stSym = listed.find((c) => ['USDC', 'USDT', 'PAXG', 'EURC', 'EURS'].includes(c)) || 'Stablecoins';
    parts.push(stSym);
  }
  if (modes.includes('crypto')) {
    const crSym = listed.find((c) => ['BTC', 'ETH', 'SOL'].includes(c)) || 'Crypto';
    parts.push(crSym);
  }
  if (modes.includes('barter')) {
    parts.push('Barter');
  }
  return parts.length > 0 ? parts.join(' • ') : 'Multi-Asset • Barter';
}

export function getListingTradeActionLabel(
  listing?: Partial<TargetListingForTrade> | null
): string {
  if (!listing) return 'Buy or Barter';
  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') return 'Settled / Sold';
  if (listing.listingIntent === 'auction') {
    const remaining = getAuctionRemainingLabel(listing.auctionConfig?.endTimeIso);
    if (listing.auctionConfig?.status === 'ended' || remaining.isEnded) {
      return 'Auction Ended';
    }
    return 'Place Bid';
  }
  if (listing.listingIntent === 'buy') return 'Fulfill / Make Offer';
  const modes = getAllowedSettlementModes(listing);
  const acceptsCurrency = modes.some((m) => m !== 'barter');
  const acceptsBarter = modes.includes('barter');
  if (acceptsCurrency && acceptsBarter) return 'Buy or Barter';
  if (acceptsCurrency) return 'Buy Now';
  return 'Propose Barter';
}

function getCoinDecimals(currencyType: CurrencyTypeId, symbol: string): number {
  if (currencyType === 'crypto') {
    return symbol === 'SOL' ? 2 : 6;
  }
  return 2;
}

function roundCoinAmount(val: number, decimals: number): number {
  const factor = Math.pow(10, decimals);
  return Math.ceil(val * factor) / factor;
}

export function getCurrencyOptionsForType(
  userId: string,
  listing: Partial<TargetListingForTrade> | null,
  currencyType: CurrencyTypeId,
  overrideUSDAmount?: number
): SettlementCoinOption[] {
  const wallet = getStoredUserWallets(userId || 'guest');
  const customCoins = getStoredCustomCoins();
  const worldCurrencies = getAllWorldCurrencies();

  const valuationUSD =
    typeof overrideUSDAmount === 'number' && overrideUSDAmount > 0
      ? overrideUSDAmount
      : getListingValuationUSD(listing);

  const preferredSet = new Set(
    [
      ...(listing?.acceptedCurrencyList || []),
      listing?.primaryCurrency,
      listing?.finalCoinsPricing?.symbol,
      listing?.stableCoinsPricing?.symbol,
      listing?.fiatPricing?.currencyCode,
      listing?.cryptoPricing?.symbol,
    ]
      .filter(Boolean)
      .map((s) => String(s).toUpperCase().trim())
  );

  const optionsMap = new Map<string, SettlementCoinOption>();

  if (currencyType === 'final_coins') {
    (wallet.finalCoins || []).forEach((fc) => {
      const sym = (fc.symbol || '').toUpperCase().trim();
      if (!sym) return;
      const customMatch = customCoins.find((c) => c.symbol.toUpperCase() === sym);
      const explicitPricing =
        listing?.finalCoinsPricing?.symbol?.toUpperCase() === sym && listing.finalCoinsPricing.amount > 0
          ? listing.finalCoinsPricing.amount
          : undefined;
      const unitPriceUSD =
        explicitPricing && valuationUSD > 0
          ? valuationUSD / explicitPricing
          : fc.unitPriceUSD > 0
          ? fc.unitPriceUSD
          : customMatch?.priceUSD && customMatch.priceUSD > 0
          ? customMatch.priceUSD
          : sym === 'AFNL'
          ? AFNL_BENCHMARK_USD
          : AFNL_BENCHMARK_USD;
      const decimals = getCoinDecimals('final_coins', sym);
      const requiredUnits =
        explicitPricing && !overrideUSDAmount
          ? explicitPricing
          : valuationUSD > 0
          ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals)
          : 0;
      const balance = Number(fc.balance || 0);
      optionsMap.set(sym, {
        symbol: sym,
        name: fc.name || customMatch?.name || sym,
        currencyType: 'final_coins',
        mode: 'final_coin',
        walletBalance: balance,
        linkedBankBalanceUnits: 0,
        totalAvailableUnits: balance,
        unitPriceUSD,
        requiredUnits,
        hasSufficientBalance: balance >= requiredUnits,
        isSellerPreferred: preferredSet.has(sym) || sym === 'AFNL',
        network: fc.network || customMatch?.network || 'Final Sovereign L1',
        decimals,
        badge: `$${unitPriceUSD.toFixed(2)} / ${sym}`,
      });
    });

    customCoins
      .filter((c) => c.coinType === 'final_coin')
      .forEach((cc) => {
        const sym = cc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = cc.priceUSD && cc.priceUSD > 0 ? cc.priceUSD : AFNL_BENCHMARK_USD;
        const decimals = getCoinDecimals('final_coins', sym);
        const requiredUnits = valuationUSD > 0 ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals) : 0;
        optionsMap.set(sym, {
          symbol: sym,
          name: cc.name,
          currencyType: 'final_coins',
          mode: 'final_coin',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          requiredUnits,
          hasSufficientBalance: requiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: cc.network || 'Final Sovereign L1',
          decimals,
          badge: `$${unitPriceUSD.toFixed(2)} / ${sym}`,
        });
      });
  } else if (currencyType === 'stable_coins') {
    (wallet.stableCoins || []).forEach((sc) => {
      const sym = (sc.symbol || '').toUpperCase().trim();
      if (!sym) return;
      const explicitPricing =
        listing?.stableCoinsPricing?.symbol?.toUpperCase() === sym && listing.stableCoinsPricing.amount > 0
          ? listing.stableCoinsPricing.amount
          : undefined;
      const unitPriceUSD =
        explicitPricing && valuationUSD > 0
          ? valuationUSD / explicitPricing
          : sc.unitPriceUSD > 0
          ? sc.unitPriceUSD
          : 1;
      const decimals = getCoinDecimals('stable_coins', sym);
      const requiredUnits =
        explicitPricing && !overrideUSDAmount
          ? explicitPricing
          : valuationUSD > 0
          ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals)
          : 0;
      const balance = Number(sc.balance || 0);
      optionsMap.set(sym, {
        symbol: sym,
        name: sc.name || sym,
        currencyType: 'stable_coins',
        mode: 'stable_coin',
        walletBalance: balance,
        linkedBankBalanceUnits: 0,
        totalAvailableUnits: balance,
        unitPriceUSD,
        requiredUnits,
        hasSufficientBalance: balance >= requiredUnits,
        isSellerPreferred: preferredSet.has(sym),
        network: sc.network,
        decimals,
        badge: `${sc.peggedCurrency} • ${sc.network}`,
      });
    });

    worldCurrencies
      .filter((w) => w.category === 'stablecoin')
      .forEach((wc) => {
        const sym = wc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = wc.unitPriceUSD > 0 ? wc.unitPriceUSD : 1;
        const decimals = getCoinDecimals('stable_coins', sym);
        const requiredUnits = valuationUSD > 0 ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals) : 0;
        optionsMap.set(sym, {
          symbol: sym,
          name: wc.name,
          currencyType: 'stable_coins',
          mode: 'stable_coin',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          requiredUnits,
          hasSufficientBalance: requiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: wc.network,
          decimals,
          badge: wc.network,
        });
      });

    customCoins
      .filter((c) => c.coinType === 'stable_coin')
      .forEach((cc) => {
        const sym = cc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = cc.priceUSD || cc.pegRateUSD || 1;
        const decimals = getCoinDecimals('stable_coins', sym);
        const requiredUnits = valuationUSD > 0 ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals) : 0;
        optionsMap.set(sym, {
          symbol: sym,
          name: cc.name,
          currencyType: 'stable_coins',
          mode: 'stable_coin',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          requiredUnits,
          hasSufficientBalance: requiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: cc.network,
          decimals,
          badge: cc.network || 'Custom Stablecoin',
        });
      });
  } else if (currencyType === 'fiat') {
    (wallet.fiatCurrencies || []).forEach((fi) => {
      const code = (fi.code || '').toUpperCase().trim();
      if (!code) return;
      const exchangeRateToUSD = fi.exchangeRateToUSD > 0 ? fi.exchangeRateToUSD : 1;
      const explicitPricing =
        listing?.fiatPricing?.currencyCode?.toUpperCase() === code && listing.fiatPricing.amount > 0
          ? listing.fiatPricing.amount
          : undefined;
      const decimals = getCoinDecimals('fiat', code);
      const requiredUnits =
        explicitPricing && !overrideUSDAmount
          ? explicitPricing
          : valuationUSD > 0
          ? roundCoinAmount(valuationUSD / exchangeRateToUSD, decimals)
          : 0;
      const cashBalance = Number(fi.balance || 0);
      const matchingBanks = (wallet.linkedBankAccounts || []).filter(
        (b) => b.currency.toUpperCase() === code && (b.balanceUSD || 0) > 0
      );
      const bankUSD = matchingBanks.reduce((sum, b) => sum + (b.balanceUSD || 0), 0);
      const linkedBankUnits = bankUSD / exchangeRateToUSD;
      const totalAvailableUnits = cashBalance + linkedBankUnits;

      optionsMap.set(code, {
        symbol: code,
        name: fi.name || code,
        currencyType: 'fiat',
        mode: 'fiat',
        walletBalance: cashBalance,
        linkedBankBalanceUnits: linkedBankUnits,
        linkedBankName: matchingBanks[0]?.bankName,
        totalAvailableUnits,
        unitPriceUSD: exchangeRateToUSD,
        requiredUnits,
        hasSufficientBalance: totalAvailableUnits >= requiredUnits,
        isSellerPreferred: preferredSet.has(code),
        network: fi.institution,
        decimals,
        badge: matchingBanks[0]
          ? `${fi.institution} + ${matchingBanks[0].bankName}`
          : fi.institution,
      });
    });

    worldCurrencies
      .filter((w) => w.category === 'fiat')
      .forEach((wc) => {
        const code = wc.symbol.toUpperCase().trim();
        if (!code || optionsMap.has(code)) return;
        const exchangeRateToUSD = wc.unitPriceUSD > 0 ? wc.unitPriceUSD : 1;
        const decimals = getCoinDecimals('fiat', code);
        const requiredUnits = valuationUSD > 0 ? roundCoinAmount(valuationUSD / exchangeRateToUSD, decimals) : 0;
        const matchingBanks = (wallet.linkedBankAccounts || []).filter(
          (b) => b.currency.toUpperCase() === code && (b.balanceUSD || 0) > 0
        );
        const bankUSD = matchingBanks.reduce((sum, b) => sum + (b.balanceUSD || 0), 0);
        const linkedBankUnits = bankUSD / exchangeRateToUSD;

        optionsMap.set(code, {
          symbol: code,
          name: wc.name,
          currencyType: 'fiat',
          mode: 'fiat',
          walletBalance: 0,
          linkedBankBalanceUnits: linkedBankUnits,
          linkedBankName: matchingBanks[0]?.bankName,
          totalAvailableUnits: linkedBankUnits,
          unitPriceUSD: exchangeRateToUSD,
          requiredUnits,
          hasSufficientBalance: linkedBankUnits >= requiredUnits,
          isSellerPreferred: preferredSet.has(code),
          network: wc.issuer,
          decimals,
          badge: wc.issuer,
        });
      });
  } else if (currencyType === 'crypto') {
    (wallet.cryptoCurrencies || []).forEach((cr) => {
      const sym = (cr.symbol || '').toUpperCase().trim();
      if (!sym) return;
      const explicitPricing =
        listing?.cryptoPricing?.symbol?.toUpperCase() === sym && listing.cryptoPricing.amount > 0
          ? listing.cryptoPricing.amount
          : undefined;
      const unitPriceUSD =
        explicitPricing && valuationUSD > 0
          ? valuationUSD / explicitPricing
          : cr.unitPriceUSD > 0
          ? cr.unitPriceUSD
          : 1;
      const decimals = getCoinDecimals('crypto', sym);
      const requiredUnits =
        explicitPricing && !overrideUSDAmount
          ? explicitPricing
          : valuationUSD > 0
          ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals)
          : 0;
      const balance = Number(cr.balance || 0);
      optionsMap.set(sym, {
        symbol: sym,
        name: cr.name || sym,
        currencyType: 'crypto',
        mode: 'crypto',
        walletBalance: balance,
        linkedBankBalanceUnits: 0,
        totalAvailableUnits: balance,
        unitPriceUSD,
        requiredUnits,
        hasSufficientBalance: balance >= requiredUnits,
        isSellerPreferred: preferredSet.has(sym),
        network: cr.network,
        decimals,
        badge: cr.network,
      });
    });

    worldCurrencies
      .filter((w) => w.category === 'crypto')
      .forEach((wc) => {
        const sym = wc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = wc.unitPriceUSD > 0 ? wc.unitPriceUSD : 1;
        const decimals = getCoinDecimals('crypto', sym);
        const requiredUnits = valuationUSD > 0 ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals) : 0;
        optionsMap.set(sym, {
          symbol: sym,
          name: wc.name,
          currencyType: 'crypto',
          mode: 'crypto',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          requiredUnits,
          hasSufficientBalance: requiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: wc.network,
          decimals,
          badge: wc.network,
        });
      });

    customCoins
      .filter((c) => c.coinType === 'crypto')
      .forEach((cc) => {
        const sym = cc.symbol.toUpperCase().trim();
        if (!sym || optionsMap.has(sym)) return;
        const unitPriceUSD = cc.priceUSD && cc.priceUSD > 0 ? cc.priceUSD : 1;
        const decimals = getCoinDecimals('crypto', sym);
        const requiredUnits = valuationUSD > 0 ? roundCoinAmount(valuationUSD / unitPriceUSD, decimals) : 0;
        optionsMap.set(sym, {
          symbol: sym,
          name: cc.name,
          currencyType: 'crypto',
          mode: 'crypto',
          walletBalance: 0,
          linkedBankBalanceUnits: 0,
          totalAvailableUnits: 0,
          unitPriceUSD,
          requiredUnits,
          hasSufficientBalance: requiredUnits === 0,
          isSellerPreferred: preferredSet.has(sym),
          network: cc.network || 'Multi-Chain',
          decimals,
          badge: cc.network || 'Custom Crypto',
        });
      });
  }

  return Array.from(optionsMap.values()).sort((a, b) => {
    if (a.isSellerPreferred !== b.isSellerPreferred) return a.isSellerPreferred ? -1 : 1;
    if (a.hasSufficientBalance !== b.hasSufficientBalance) return a.hasSufficientBalance ? -1 : 1;
    if ((a.totalAvailableUnits > 0) !== (b.totalAvailableUnits > 0)) {
      return a.totalAvailableUnits > 0 ? -1 : 1;
    }
    return a.symbol.localeCompare(b.symbol);
  });
}

function deductOrCreditCoinInWallet(
  userId: string,
  coinOption: SettlementCoinOption,
  unitsDelta: number,
  direction: 'deduct' | 'credit'
): { success: boolean; error?: string } {
  const wallet = getStoredUserWallets(userId);
  const sym = coinOption.symbol.toUpperCase();

  if (coinOption.currencyType === 'final_coins') {
    if (!wallet.finalCoins) wallet.finalCoins = [];
    const idx = wallet.finalCoins.findIndex((c) => c.symbol.toUpperCase() === sym);
    if (direction === 'deduct') {
      if (idx === -1 || wallet.finalCoins[idx].balance < unitsDelta) {
        return {
          success: false,
          error: `Insufficient ${sym} balance. Required: ${unitsDelta.toLocaleString()} ${sym}, Available: ${(idx !== -1 ? wallet.finalCoins[idx].balance : 0).toLocaleString()} ${sym}.`,
        };
      }
      wallet.finalCoins[idx].balance = Number((wallet.finalCoins[idx].balance - unitsDelta).toFixed(4));
    } else {
      if (idx !== -1) {
        wallet.finalCoins[idx].balance = Number((wallet.finalCoins[idx].balance + unitsDelta).toFixed(4));
      } else {
        wallet.finalCoins.push({
          id: `fc-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(4)),
          unitPriceUSD: sym === 'AFNL' ? 0 : coinOption.unitPriceUSD,
          change24h: 0,
          utility: 'Marketplace settlement proceeds',
        });
      }
    }
  } else if (coinOption.currencyType === 'stable_coins') {
    if (!wallet.stableCoins) wallet.stableCoins = [];
    const idx = wallet.stableCoins.findIndex((c) => c.symbol.toUpperCase() === sym);
    if (direction === 'deduct') {
      if (idx === -1 || wallet.stableCoins[idx].balance < unitsDelta) {
        return {
          success: false,
          error: `Insufficient ${sym} balance. Required: ${unitsDelta.toLocaleString()} ${sym}, Available: ${(idx !== -1 ? wallet.stableCoins[idx].balance : 0).toLocaleString()} ${sym}.`,
        };
      }
      wallet.stableCoins[idx].balance = Number((wallet.stableCoins[idx].balance - unitsDelta).toFixed(4));
    } else {
      if (idx !== -1) {
        wallet.stableCoins[idx].balance = Number((wallet.stableCoins[idx].balance + unitsDelta).toFixed(4));
      } else {
        wallet.stableCoins.push({
          id: `sc-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(4)),
          unitPriceUSD: coinOption.unitPriceUSD || 1,
          peggedCurrency: 'USD',
          yieldAPY: 4.5,
          network: coinOption.network || 'Polygon & Ethereum',
        });
      }
    }
  } else if (coinOption.currencyType === 'fiat') {
    if (!wallet.fiatCurrencies) wallet.fiatCurrencies = [];
    const idx = wallet.fiatCurrencies.findIndex((f) => f.code.toUpperCase() === sym);
    const rate = idx !== -1 ? wallet.fiatCurrencies[idx].exchangeRateToUSD || coinOption.unitPriceUSD || 1 : coinOption.unitPriceUSD || 1;
    if (direction === 'deduct') {
      const cashAvail = idx !== -1 ? wallet.fiatCurrencies[idx].balance : 0;
      const matchingBanks = (wallet.linkedBankAccounts || []).filter(
        (b) => b.currency.toUpperCase() === sym && (b.balanceUSD || 0) > 0
      );
      const bankAvailUnits = matchingBanks.reduce((s, b) => s + (b.balanceUSD || 0) / rate, 0);
      if (cashAvail + bankAvailUnits + 1e-6 < unitsDelta) {
        return {
          success: false,
          error: `Insufficient ${sym} reserves. Required: ${unitsDelta.toLocaleString()} ${sym}, Available: ${(cashAvail + bankAvailUnits).toLocaleString()} ${sym}.`,
        };
      }
      let remainingToDeduct = unitsDelta;
      if (idx !== -1 && cashAvail > 0) {
        const deductFromCash = Math.min(cashAvail, remainingToDeduct);
        wallet.fiatCurrencies[idx].balance = Number((cashAvail - deductFromCash).toFixed(2));
        remainingToDeduct -= deductFromCash;
      }
      if (remainingToDeduct > 1e-6 && wallet.linkedBankAccounts) {
        let remainingUSD = remainingToDeduct * rate;
        for (const bank of wallet.linkedBankAccounts) {
          if (bank.currency.toUpperCase() === sym && (bank.balanceUSD || 0) > 0 && remainingUSD > 0) {
            const deductUSD = Math.min(bank.balanceUSD || 0, remainingUSD);
            bank.balanceUSD = Number(((bank.balanceUSD || 0) - deductUSD).toFixed(2));
            remainingUSD -= deductUSD;
          }
        }
      }
    } else {
      if (idx !== -1) {
        wallet.fiatCurrencies[idx].balance = Number((wallet.fiatCurrencies[idx].balance + unitsDelta).toFixed(2));
      } else {
        wallet.fiatCurrencies.push({
          id: `fi-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          code: sym,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(2)),
          exchangeRateToUSD: rate,
          accountType: 'Settlement Reserve',
          institution: 'Sovereign Clearing',
        });
      }
    }
  } else if (coinOption.currencyType === 'crypto') {
    if (!wallet.cryptoCurrencies) wallet.cryptoCurrencies = [];
    const idx = wallet.cryptoCurrencies.findIndex((c) => c.symbol.toUpperCase() === sym);
    if (direction === 'deduct') {
      if (idx === -1 || wallet.cryptoCurrencies[idx].balance < unitsDelta) {
        return {
          success: false,
          error: `Insufficient ${sym} balance. Required: ${unitsDelta} ${sym}, Available: ${idx !== -1 ? wallet.cryptoCurrencies[idx].balance : 0} ${sym}.`,
        };
      }
      wallet.cryptoCurrencies[idx].balance = Number((wallet.cryptoCurrencies[idx].balance - unitsDelta).toFixed(6));
    } else {
      if (idx !== -1) {
        wallet.cryptoCurrencies[idx].balance = Number((wallet.cryptoCurrencies[idx].balance + unitsDelta).toFixed(6));
      } else {
        wallet.cryptoCurrencies.push({
          id: `cr-${sym.toLowerCase()}-${Date.now()}`,
          name: coinOption.name,
          symbol: sym,
          balance: Number(unitsDelta.toFixed(6)),
          unitPriceUSD: coinOption.unitPriceUSD || 1,
          change24h: 0,
          network: coinOption.network || 'Multi-Chain',
          walletAddress: `0x${Date.now().toString(16)}escrow`,
        });
      }
    }
  }

  saveStoredUserWallets(userId, wallet);
  return { success: true };
}

function enrollAcquiredListingInBuyerInventory(
  buyerId: string,
  listing: TargetListingForTrade,
  valuationUSD: number
): string {
  const wallet = getStoredUserWallets(buyerId);
  const isService =
    listing.itemType === 'service' ||
    (listing.category && String(listing.category).toLowerCase().includes('service'));

  if (isService) {
    if (!wallet.barterServices) wallet.barterServices = [];
    const units = listing.availableUnits || 1;
    wallet.barterServices.unshift({
      id: `bs-acq-${listing.id}-${Date.now()}`,
      name: listing.title,
      category: listing.category || 'Professional Services',
      availableUnits: units,
      unitType: (listing.unitType as any) || 'Deliverables',
      hourlyRateValue: Number((valuationUSD / Math.max(1, units)).toFixed(2)),
      deliverableDescription: listing.deliverables || `Acquired service contract from ${listing.sellerName}`,
      turnaroundTime: listing.turnaroundTime || 'Active Retainer',
      skills: ['Acquired Service', 'Escrow Verified'],
    });
  } else {
    if (!wallet.barterGoods) wallet.barterGoods = [];
    wallet.barterGoods.unshift({
      id: `bg-acq-${listing.id}-${Date.now()}`,
      name: listing.title,
      category: listing.category || 'Precious Metals & Bullion',
      quantity: 1,
      unitLabel: listing.unitLabel || 'unit',
      estimatedUnitValue: valuationUSD,
      condition: (listing.condition as any) || 'Certified Vault',
      description: `Acquired via Sovereign Marketplace from ${listing.sellerName}`,
      location: listing.location || 'Zurich Depository',
      imageUrl: listing.imageUrl,
    });
  }

  saveStoredUserWallets(buyerId, wallet);
  return listing.title;
}

export function executeCurrencyListingDeal(params: {
  buyerId: string;
  buyerName: string;
  buyerHandle?: string;
  listing: TargetListingForTrade;
  coinOption: SettlementCoinOption;
  overrideValuationUSD?: number;
  forceMarkSold?: boolean;
}): DealExecutionResult {
  const { buyerId, listing, coinOption, overrideValuationUSD, forceMarkSold } = params;

  if (!buyerId || buyerId === 'guest') {
    return {
      success: false,
      error: 'Please sign in to execute a marketplace transaction.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') {
    return {
      success: false,
      error: 'This listing has already been settled and sold.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  const allowedModes = getAllowedSettlementModes(listing);
  if (!allowedModes.includes(coinOption.currencyType)) {
    return {
      success: false,
      error: `The seller does not accept ${CURRENCY_TYPE_META[coinOption.currencyType].label} for this listing.`,
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  const buyerClean = buyerId.replace(/^user-/, '').toLowerCase();
  const sellerClean = (listing.sellerId || '').replace(/^user-/, '').toLowerCase();
  const sellerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (buyerClean && (buyerClean === sellerClean || buyerClean === sellerHandleClean)) {
    return {
      success: false,
      error: 'You cannot execute a purchase against your own listing.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  const amountUSD =
    typeof overrideValuationUSD === 'number' && overrideValuationUSD > 0
      ? overrideValuationUSD
      : getListingValuationUSD(listing);
  const unitsToTransfer =
    typeof overrideValuationUSD === 'number' && overrideValuationUSD > 0
      ? roundCoinAmount(
          overrideValuationUSD / (coinOption.unitPriceUSD > 0 ? coinOption.unitPriceUSD : 1),
          coinOption.decimals
        )
      : coinOption.requiredUnits;
  if (unitsToTransfer <= 0 || amountUSD <= 0) {
    return {
      success: false,
      error: 'Invalid settlement amount for this listing.',
      settlementMode: coinOption.currencyType,
      amountUSD: 0,
    };
  }

  const isBuyIntent = listing.listingIntent === 'buy';

  // For standard 'sell' listings: buyer pays seller in coinOption
  // For 'buy' (wanted/RFP) listings: buyer (current user) fulfills request and receives coinOption from listing creator
  if (!isBuyIntent) {
    const deductRes = deductOrCreditCoinInWallet(buyerId, coinOption, unitsToTransfer, 'deduct');
    if (!deductRes.success) {
      return {
        success: false,
        error: deductRes.error,
        settlementMode: coinOption.currencyType,
        amountUSD,
      };
    }
    if (listing.sellerId) {
      deductOrCreditCoinInWallet(listing.sellerId, coinOption, unitsToTransfer, 'credit');
    }
    enrollAcquiredListingInBuyerInventory(buyerId, listing, amountUSD);
  } else {
    deductOrCreditCoinInWallet(buyerId, coinOption, unitsToTransfer, 'credit');
  }

  const currentQty = typeof listing.quantity === 'number' ? listing.quantity : 1;
  const remainingQuantity = forceMarkSold ? 0 : Math.max(0, currentQty - 1);
  const markedSold = Boolean(forceMarkSold) || remainingQuantity === 0;

  if (markedSold) {
    updateListingStatus(buyerId, listing.id, 'sold', {
      buyerId,
      buyerName: params.buyerName,
      buyerHandle: params.buyerHandle,
    });
  }

  const ledgerItem = createLedgerItemFromMarketplacePurchase({
    listingTitle: listing.title,
    category: listing.category || (listing.itemType === 'service' ? 'Services' : 'Marketplace Assets'),
    amountUSD,
    quantity: 1,
    sellerName: listing.sellerName,
    sellerHandle: listing.sellerHandle?.replace(/^@/, ''),
    sellerId: listing.sellerId,
    paymentMethod: `${unitsToTransfer.toLocaleString(undefined, { maximumFractionDigits: coinOption.decimals })} ${coinOption.symbol} (${CURRENCY_TYPE_META[coinOption.currencyType].label})`,
    mode: coinOption.mode,
  });

  recordLedgerTransaction(buyerId, ledgerItem);

  return {
    success: true,
    ledgerItem,
    settlementMode: coinOption.currencyType,
    coinSymbol: coinOption.symbol,
    paidUnits: unitsToTransfer,
    amountUSD,
    assetEnrolledName: !isBuyIntent ? listing.title : undefined,
    remainingQuantity,
    markedSold,
  };
}

export function executeBarterListingDeal(params: {
  buyerId: string;
  buyerName: string;
  listing: TargetListingForTrade;
  offeringType: 'inventory' | 'custom';
  inventoryKind: 'good' | 'service';
  selectedGoodId?: string;
  selectedServiceId?: string;
  offeredUnits?: number;
  customOfferText?: string;
  sweetenerCoin?: SettlementCoinOption | null;
  sweetenerAmountUSD?: number;
}): DealExecutionResult {
  const {
    buyerId,
    buyerName,
    listing,
    offeringType,
    inventoryKind,
    selectedGoodId,
    selectedServiceId,
    offeredUnits = 1,
    customOfferText,
    sweetenerCoin,
    sweetenerAmountUSD = 0,
  } = params;

  if (!buyerId || buyerId === 'guest') {
    return {
      success: false,
      error: 'Please sign in to submit a barter trade.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  if (listing.status === 'sold') {
    return {
      success: false,
      error: 'This listing has already been settled and sold.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  const allowedModes = getAllowedSettlementModes(listing);
  if (!allowedModes.includes('barter')) {
    return {
      success: false,
      error: 'The seller only accepts direct currency payment for this listing.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  const buyerClean = buyerId.replace(/^user-/, '').toLowerCase();
  const sellerClean = (listing.sellerId || '').replace(/^user-/, '').toLowerCase();
  const sellerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (buyerClean && (buyerClean === sellerClean || buyerClean === sellerHandleClean)) {
    return {
      success: false,
      error: 'You cannot execute a barter against your own listing.',
      settlementMode: 'barter',
      amountUSD: 0,
    };
  }

  const wallet = getStoredUserWallets(buyerId);
  let offeredDescription = '';
  let offeredEstimatedUSD = 0;

  if (offeringType === 'inventory') {
    if (inventoryKind === 'good') {
      const goodIdx = wallet.barterGoods.findIndex((g) => g.id === selectedGoodId);
      if (goodIdx === -1) {
        return {
          success: false,
          error: 'Please select a valid physical asset from your inventory or switch to Custom Barter Offer.',
          settlementMode: 'barter',
          amountUSD: 0,
        };
      }
      const good = wallet.barterGoods[goodIdx];
      const units = Math.max(1, Math.min(good.quantity, Math.floor(offeredUnits)));
      offeredEstimatedUSD = units * good.estimatedUnitValue;
      offeredDescription = `${units}x ${good.name} (${good.condition}) — Valued at $${offeredEstimatedUSD.toLocaleString()} USD`;
      if (good.quantity > units) {
        wallet.barterGoods[goodIdx].quantity = good.quantity - units;
      } else {
        wallet.barterGoods.splice(goodIdx, 1);
      }
    } else {
      const srvIdx = wallet.barterServices.findIndex((s) => s.id === selectedServiceId);
      if (srvIdx === -1) {
        return {
          success: false,
          error: 'Please select a valid service retainer from your portfolio or switch to Custom Barter Offer.',
          settlementMode: 'barter',
          amountUSD: 0,
        };
      }
      const srv = wallet.barterServices[srvIdx];
      const units = Math.max(1, Math.min(srv.availableUnits, Math.floor(offeredUnits)));
      offeredEstimatedUSD = units * srv.hourlyRateValue;
      offeredDescription = `${units} ${srv.unitType} of ${srv.name} — Valued at $${offeredEstimatedUSD.toLocaleString()} USD`;
      if (srv.availableUnits > units) {
        wallet.barterServices[srvIdx].availableUnits = srv.availableUnits - units;
      } else {
        wallet.barterServices.splice(srvIdx, 1);
      }
    }
  } else {
    const cleanText = (customOfferText || '').trim();
    if (!cleanText) {
      return {
        success: false,
        error: 'Please describe the goods or services you are offering in barter.',
        settlementMode: 'barter',
        amountUSD: 0,
      };
    }
    offeredDescription = cleanText;
    offeredEstimatedUSD = getListingValuationUSD(listing);
  }

  let sweetenerUnits = 0;
  let sweetenerSymbol: string | undefined;

  if (sweetenerCoin && sweetenerAmountUSD > 0) {
    sweetenerUnits = roundCoinAmount(
      sweetenerAmountUSD / (sweetenerCoin.unitPriceUSD > 0 ? sweetenerCoin.unitPriceUSD : 1),
      sweetenerCoin.decimals
    );
    // Re-read or apply sweetener deduction carefully
    saveStoredUserWallets(buyerId, wallet);
    const deductRes = deductOrCreditCoinInWallet(buyerId, sweetenerCoin, sweetenerUnits, 'deduct');
    if (!deductRes.success) {
      return {
        success: false,
        error: deductRes.error,
        settlementMode: 'barter',
        amountUSD: 0,
      };
    }
    if (listing.sellerId) {
      deductOrCreditCoinInWallet(listing.sellerId, sweetenerCoin, sweetenerUnits, 'credit');
    }
    sweetenerSymbol = sweetenerCoin.symbol;
  } else {
    saveStoredUserWallets(buyerId, wallet);
  }

  const proposal = submitBarterTradeProposal({
    listingId: listing.id,
    listingTitle: listing.title,
    senderId: buyerId,
    senderName: buyerName,
    recipientId: listing.sellerId || 'counterparty',
    offeredItemsDescription: offeredDescription,
    offeredSweetenerUSD: sweetenerAmountUSD > 0 ? sweetenerAmountUSD : undefined,
    offeredSweetenerToken:
      sweetenerSymbol && sweetenerUnits > 0
        ? { symbol: sweetenerSymbol, amount: sweetenerUnits }
        : undefined,
  });

  const estimatedTotalUSD = Math.max(
    getListingValuationUSD(listing),
    offeredEstimatedUSD + (sweetenerAmountUSD > 0 ? sweetenerAmountUSD : 0)
  );

  const ledgerItem = createLedgerItemFromBarter({
    offeredDescription:
      sweetenerSymbol && sweetenerUnits > 0
        ? `${offeredDescription} + ${sweetenerUnits.toLocaleString()} ${sweetenerSymbol} ($${sweetenerAmountUSD.toLocaleString()} USD)`
        : offeredDescription,
    targetListingTitle: listing.title,
    counterpartyName: listing.sellerName || 'Counterparty Peer',
    sweetenerUSD: sweetenerAmountUSD > 0 ? sweetenerAmountUSD : 0,
    estimatedTotalValueUSD: estimatedTotalUSD,
  });

  recordLedgerTransaction(buyerId, ledgerItem);

  return {
    success: true,
    proposalId: proposal.proposalId,
    ledgerItem,
    settlementMode: 'barter',
    coinSymbol: sweetenerSymbol,
    paidUnits: sweetenerUnits > 0 ? sweetenerUnits : undefined,
    amountUSD: estimatedTotalUSD,
  };
}

// ==================== AUCTION BIDDING & 5-MODE SETTLEMENT ====================

export interface PlaceAuctionBidParams {
  bidderId: string;
  bidderUid?: string;
  bidderName: string;
  bidderHandle: string;
  bidderAvatar?: string;
  listing: TargetListingForTrade;
  amountUSD: number;
  mode: SettlementMethod;
  coinOption?: SettlementCoinOption | null;
  barterOfferingType?: 'inventory' | 'custom';
  barterInventoryKind?: 'good' | 'service';
  barterSelectedItemId?: string;
  barterOfferedUnits?: number;
  barterOfferDescription?: string;
  sweetenerCoin?: SettlementCoinOption | null;
  sweetenerAmountUSD?: number;
}

export interface PlaceAuctionBidResult {
  success: boolean;
  error?: string;
  bid?: AuctionBid;
  updatedConfig?: AuctionConfig;
}

export function placeAuctionBid(params: PlaceAuctionBidParams): PlaceAuctionBidResult {
  const {
    bidderId,
    bidderUid,
    bidderName,
    bidderHandle,
    bidderAvatar,
    listing,
    amountUSD,
    mode,
    coinOption,
    barterOfferingType,
    barterInventoryKind,
    barterSelectedItemId,
    barterOfferedUnits,
    barterOfferDescription,
    sweetenerCoin,
    sweetenerAmountUSD = 0,
  } = params;

  if (!bidderId || bidderId === 'guest') {
    return { success: false, error: 'Please sign in to place a bid on this auction.' };
  }

  if (listing.listingIntent !== 'auction') {
    return { success: false, error: 'This listing is not configured as an auction.' };
  }

  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') {
    return { success: false, error: 'This auction has already been settled.' };
  }

  const remaining = getAuctionRemainingLabel(listing.auctionConfig?.endTimeIso);
  if (listing.auctionConfig?.status === 'ended' || remaining.isEnded) {
    return { success: false, error: 'This auction has ended and is awaiting settlement.' };
  }

  const bidderClean = bidderId.replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const sellerClean = (listing.sellerId || '').replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const sellerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (bidderClean && (bidderClean === sellerClean || bidderClean === sellerHandleClean)) {
    return { success: false, error: 'You cannot place bids on your own auction.' };
  }

  const targetUid = listing.sellerId?.startsWith('user-') ? listing.sellerId : `user-${sellerClean}`;
  const viewerUid = bidderUid || (bidderId.startsWith('user-') ? bidderId : `user-${bidderClean}`);
  if (
    !isAdminAccount(bidderId) &&
    !isAdminAccount(bidderUid) &&
    (areUsersBlockedEitherWay(viewerUid, targetUid) ||
      areUsersBlockedEitherWay(bidderId, listing.sellerId) ||
      areUsersBlockedEitherWay(bidderClean, sellerHandleClean))
  ) {
    return { success: false, error: 'Bidding unavailable: accounts have blocked each other.' };
  }

  const allowedModes = getAllowedSettlementModes(listing);
  if (!allowedModes.includes(mode)) {
    return {
      success: false,
      error: `Seller does not accept ${mode === 'barter' ? 'Barter' : CURRENCY_TYPE_META[mode].label} on this auction.`,
    };
  }

  const minNextBid = getMinimumNextBidUSD(listing);
  const roundedBidUSD = Math.round(Number(amountUSD) * 100) / 100;
  if (!Number.isFinite(roundedBidUSD) || roundedBidUSD < minNextBid) {
    return {
      success: false,
      error: `Bid must be at least $${minNextBid.toLocaleString()} USD.`,
    };
  }

  let currencySymbol: string | undefined;
  let nativeAmount: number | undefined;

  if (mode === 'barter') {
    if (!barterOfferDescription || !barterOfferDescription.trim()) {
      return { success: false, error: 'Please provide details of the goods or services you are offering in barter.' };
    }
    if (sweetenerCoin && sweetenerAmountUSD > 0) {
      const sweetenerCheck = getCurrencyOptionsForType(
        bidderId,
        listing,
        sweetenerCoin.currencyType,
        sweetenerAmountUSD
      ).find((c) => c.symbol === sweetenerCoin.symbol);
      if (!sweetenerCheck || !sweetenerCheck.hasSufficientBalance) {
        return {
          success: false,
          error: `Insufficient ${sweetenerCoin.symbol} balance for your barter sweetener ($${sweetenerAmountUSD.toLocaleString()} USD).`,
        };
      }
    }
  } else {
    if (!coinOption) {
      return { success: false, error: `Please select a valid ${CURRENCY_TYPE_META[mode].label} asset.` };
    }
    const liveOptions = getCurrencyOptionsForType(bidderId, listing, mode, roundedBidUSD);
    const verifiedOption = liveOptions.find((c) => c.symbol === coinOption.symbol) || coinOption;
    if (!verifiedOption.hasSufficientBalance) {
      return {
        success: false,
        error: `Insufficient ${verifiedOption.symbol} balance to back a $${roundedBidUSD.toLocaleString()} bid (${verifiedOption.requiredUnits.toLocaleString(undefined, { maximumFractionDigits: verifiedOption.decimals })} ${verifiedOption.symbol} required).`,
      };
    }
    currencySymbol = verifiedOption.symbol;
    nativeAmount = verifiedOption.requiredUnits;
  }

  const existingBids = getAuctionBids(listing.id);
  const previousLeader = existingBids.find((b) => b.status === 'active');

  const updatedBids: AuctionBid[] = existingBids.map((b) =>
    b.status === 'active' ? { ...b, status: 'outbid' } : b
  );

  const newBid: AuctionBid = {
    id: `bid-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    listingId: listing.id,
    bidderId,
    bidderUid: viewerUid,
    bidderName,
    bidderHandle: bidderHandle.replace(/^@/, ''),
    bidderAvatar,
    amountUSD: roundedBidUSD,
    mode,
    currencySymbol,
    nativeAmount,
    barterOfferDescription: mode === 'barter' ? barterOfferDescription?.trim() : undefined,
    barterOfferingType: mode === 'barter' ? barterOfferingType : undefined,
    barterInventoryKind: mode === 'barter' ? barterInventoryKind : undefined,
    barterSelectedItemId: mode === 'barter' ? barterSelectedItemId : undefined,
    barterOfferedUnits: mode === 'barter' ? barterOfferedUnits : undefined,
    sweetenerCoinSymbol: sweetenerCoin && sweetenerAmountUSD > 0 ? sweetenerCoin.symbol : undefined,
    sweetenerCurrencyType: sweetenerCoin && sweetenerAmountUSD > 0 ? sweetenerCoin.currencyType : undefined,
    sweetenerAmountUSD: sweetenerCoin && sweetenerAmountUSD > 0 ? sweetenerAmountUSD : undefined,
    createdAt: new Date().toISOString(),
    status: 'active',
  };

  const nextBidsList = [newBid, ...updatedBids];
  saveAuctionBidsForListing(listing.id, nextBidsList);

  const baseConfig: AuctionConfig = listing.auctionConfig || {
    startingBidUSD: roundedBidUSD,
    minIncrementUSD: 100,
    endTimeIso: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
    bidCount: 0,
    status: 'live',
  };

  let nextEndTimeIso = baseConfig.endTimeIso;
  if (baseConfig.allowAutoExtend && remaining.msRemaining > 0 && remaining.msRemaining < 5 * 60 * 1000) {
    nextEndTimeIso = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  }

  const nextConfig: AuctionConfig = {
    ...baseConfig,
    endTimeIso: nextEndTimeIso,
    highestBidUSD: roundedBidUSD,
    highestBidderId: bidderId,
    highestBidderUid: viewerUid,
    highestBidderName: bidderName,
    highestBidderHandle: bidderHandle.replace(/^@/, ''),
    highestBidMode: mode,
    bidCount: nextBidsList.length,
    status: 'live',
  };

  updateListingAuctionState(listing.id, (curr) => ({
    ...curr,
    primaryPriceUSD: roundedBidUSD,
    auctionConfig: nextConfig,
  }));

  const modeLabel =
    mode === 'barter'
      ? `Barter ($${roundedBidUSD.toLocaleString()} eq.)`
      : `${nativeAmount?.toLocaleString()} ${currencySymbol} ($${roundedBidUSD.toLocaleString()})`;

  enqueueUserNotification([listing.sellerId, sellerHandleClean], {
    title: `🔨 New Auction Bid on "${listing.title}"`,
    description: `${bidderName} (@${bidderHandle.replace(/^@/, '')}) placed a ${modeLabel} bid.`,
    type: 'trade',
    targetTab: 'marketplace',
    targetId: listing.id,
  });

  if (previousLeader && previousLeader.bidderId !== bidderId) {
    enqueueUserNotification([previousLeader.bidderId, previousLeader.bidderUid || '', previousLeader.bidderHandle], {
      title: `⚠️ You Were Outbid on "${listing.title}"`,
      description: `A new highest bid of $${roundedBidUSD.toLocaleString()} USD (${mode === 'barter' ? 'Barter' : currencySymbol}) was placed.`,
      type: 'trade',
      targetTab: 'marketplace',
      targetId: listing.id,
    });
  }

  return { success: true, bid: newBid, updatedConfig: nextConfig };
}

export function acceptAuctionBid(params: {
  sellerId: string;
  sellerName: string;
  listing: TargetListingForTrade;
  bidId: string;
}): DealExecutionResult {
  const { sellerId, listing, bidId } = params;
  const bids = getAuctionBids(listing.id);
  const targetBid = bids.find((b) => b.id === bidId);
  if (!targetBid) {
    return {
      success: false,
      error: 'Selected bid could not be found.',
      settlementMode: 'final_coins',
      amountUSD: 0,
    };
  }

  if (listing.status === 'sold' || listing.auctionConfig?.status === 'settled') {
    return {
      success: false,
      error: 'This auction has already been settled.',
      settlementMode: targetBid.mode,
      amountUSD: 0,
    };
  }

  const sellerClean = sellerId.replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const ownerClean = (listing.sellerId || '').replace(/^user-/, '').replace(/^@/, '').toLowerCase();
  const ownerHandleClean = (listing.sellerHandle || '').replace(/^@/, '').toLowerCase();
  if (sellerClean !== ownerClean && sellerClean !== ownerHandleClean) {
    return {
      success: false,
      error: 'Only the auction creator can accept and settle bids.',
      settlementMode: targetBid.mode,
      amountUSD: 0,
    };
  }

  let execResult: DealExecutionResult;

  if (targetBid.mode === 'barter') {
    let sweetenerCoinObj: SettlementCoinOption | null = null;
    if (targetBid.sweetenerCurrencyType && targetBid.sweetenerCoinSymbol && (targetBid.sweetenerAmountUSD || 0) > 0) {
      const opts = getCurrencyOptionsForType(
        targetBid.bidderId,
        listing,
        targetBid.sweetenerCurrencyType,
        targetBid.sweetenerAmountUSD
      );
      sweetenerCoinObj = opts.find((c) => c.symbol === targetBid.sweetenerCoinSymbol) || opts[0] || null;
    }

    execResult = executeBarterListingDeal({
      buyerId: targetBid.bidderId,
      buyerName: targetBid.bidderName,
      listing,
      offeringType: targetBid.barterOfferingType === 'inventory' ? 'inventory' : 'custom',
      inventoryKind: targetBid.barterInventoryKind || 'good',
      selectedGoodId: targetBid.barterInventoryKind === 'good' ? targetBid.barterSelectedItemId : undefined,
      selectedServiceId: targetBid.barterInventoryKind === 'service' ? targetBid.barterSelectedItemId : undefined,
      offeredUnits: targetBid.barterOfferedUnits || 1,
      customOfferText: targetBid.barterOfferDescription || `Winning auction barter bid ($${targetBid.amountUSD.toLocaleString()} USD eq.)`,
      sweetenerCoin: sweetenerCoinObj,
      sweetenerAmountUSD: targetBid.sweetenerAmountUSD || 0,
    });
    if (!execResult.success) return execResult;
    enrollAcquiredListingInBuyerInventory(targetBid.bidderId, listing, targetBid.amountUSD);
  } else {
    const opts = getCurrencyOptionsForType(targetBid.bidderId, listing, targetBid.mode, targetBid.amountUSD);
    const chosenCoin =
      opts.find((c) => c.symbol === targetBid.currencySymbol) || opts[0];
    if (!chosenCoin) {
      return {
        success: false,
        error: `Could not resolve currency asset for ${targetBid.mode}.`,
        settlementMode: targetBid.mode,
        amountUSD: 0,
      };
    }

    execResult = executeCurrencyListingDeal({
      buyerId: targetBid.bidderId,
      buyerName: targetBid.bidderName,
      buyerHandle: targetBid.bidderHandle,
      listing,
      coinOption: chosenCoin,
      overrideValuationUSD: targetBid.amountUSD,
      forceMarkSold: true,
    });
    if (!execResult.success) return execResult;
  }

  const nextBids: AuctionBid[] = bids.map((b) =>
    b.id === targetBid.id ? { ...b, status: 'accepted' } : { ...b, status: 'declined' }
  );
  saveAuctionBidsForListing(listing.id, nextBids);

  updateListingAuctionState(listing.id, (curr) => ({
    ...curr,
    status: 'sold',
    buyerId: targetBid.bidderId,
    buyerUid: targetBid.bidderUid,
    buyerName: targetBid.bidderName,
    buyerHandle: targetBid.bidderHandle,
    primaryPriceUSD: targetBid.amountUSD,
    auctionConfig: {
      ...(curr.auctionConfig || {
        startingBidUSD: targetBid.amountUSD,
        minIncrementUSD: 100,
        endTimeIso: new Date().toISOString(),
        bidCount: nextBids.length,
        status: 'settled',
      }),
      highestBidUSD: targetBid.amountUSD,
      highestBidderId: targetBid.bidderId,
      highestBidderName: targetBid.bidderName,
      highestBidderHandle: targetBid.bidderHandle,
      highestBidMode: targetBid.mode,
      bidCount: nextBids.length,
      status: 'settled',
      winningBidId: targetBid.id,
    },
  }));

  enqueueUserNotification([targetBid.bidderId, targetBid.bidderUid || '', targetBid.bidderHandle], {
    title: `🏆 You Won the Auction: "${listing.title}"`,
    description: `Your ${targetBid.mode === 'barter' ? 'Barter' : targetBid.currencySymbol} bid of $${targetBid.amountUSD.toLocaleString()} USD was accepted and settled!`,
    type: 'trade',
    targetTab: 'marketplace',
    targetId: listing.id,
  });

  return {
    ...execResult,
    markedSold: true,
    amountUSD: targetBid.amountUSD,
  };
}

export function buyNowAuctionListing(params: {
  buyerId: string;
  buyerName: string;
  buyerHandle?: string;
  listing: TargetListingForTrade;
  mode: SettlementMethod;
  coinOption?: SettlementCoinOption | null;
  barterOfferingType?: 'inventory' | 'custom';
  barterInventoryKind?: 'good' | 'service';
  barterSelectedItemId?: string;
  barterOfferedUnits?: number;
  barterCustomOfferText?: string;
  sweetenerCoin?: SettlementCoinOption | null;
  sweetenerAmountUSD?: number;
}): DealExecutionResult {
  const { buyerId, buyerName, buyerHandle, listing, mode } = params;
  const buyNowUSD = Number(listing.auctionConfig?.buyNowPriceUSD || 0);
  if (buyNowUSD <= 0) {
    return {
      success: false,
      error: 'Instant Buy Now price is not enabled for this auction.',
      settlementMode: mode,
      amountUSD: 0,
    };
  }

  let res: DealExecutionResult;
  if (mode === 'barter') {
    res = executeBarterListingDeal({
      buyerId,
      buyerName,
      listing,
      offeringType: params.barterOfferingType || 'custom',
      inventoryKind: params.barterInventoryKind || 'good',
      selectedGoodId: params.barterSelectedItemId,
      selectedServiceId: params.barterSelectedItemId,
      offeredUnits: params.barterOfferedUnits || 1,
      customOfferText: params.barterCustomOfferText || `Instant Buy Now Barter ($${buyNowUSD.toLocaleString()} USD)`,
      sweetenerCoin: params.sweetenerCoin,
      sweetenerAmountUSD: params.sweetenerAmountUSD || 0,
    });
    if (!res.success) return res;
    enrollAcquiredListingInBuyerInventory(buyerId, listing, buyNowUSD);
  } else {
    if (!params.coinOption) {
      return {
        success: false,
        error: 'Please select a valid payment asset for Buy Now settlement.',
        settlementMode: mode,
        amountUSD: 0,
      };
    }
    res = executeCurrencyListingDeal({
      buyerId,
      buyerName,
      buyerHandle,
      listing,
      coinOption: params.coinOption,
      overrideValuationUSD: buyNowUSD,
      forceMarkSold: true,
    });
    if (!res.success) return res;
  }

  const existingBids = getAuctionBids(listing.id);
  if (existingBids.length > 0) {
    saveAuctionBidsForListing(
      listing.id,
      existingBids.map((b) => ({ ...b, status: 'declined' }))
    );
  }

  updateListingAuctionState(listing.id, (curr) => ({
    ...curr,
    status: 'sold',
    buyerId,
    buyerName,
    buyerHandle: buyerHandle?.replace(/^@/, '') || buyerId,
    primaryPriceUSD: buyNowUSD,
    auctionConfig: {
      ...(curr.auctionConfig || {
        startingBidUSD: buyNowUSD,
        minIncrementUSD: 100,
        endTimeIso: new Date().toISOString(),
        bidCount: existingBids.length,
        status: 'settled',
      }),
      highestBidUSD: buyNowUSD,
      highestBidderId: buyerId,
      highestBidderName: buyerName,
      highestBidderHandle: buyerHandle?.replace(/^@/, '') || buyerId,
      highestBidMode: mode,
      status: 'settled',
    },
  }));

  enqueueUserNotification([listing.sellerId, listing.sellerHandle || ''], {
    title: `⚡ Auction Sold via Buy Now: "${listing.title}"`,
    description: `${buyerName} executed Instant Buy Now at $${buyNowUSD.toLocaleString()} USD.`,
    type: 'trade',
    targetTab: 'marketplace',
    targetId: listing.id,
  });

  return {
    ...res,
    markedSold: true,
    amountUSD: buyNowUSD,
  };
}
