import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, 
  Send, 
  Search, 
  Phone, 
  Video, 
  Users, 
  UserPlus, 
  UserMinus,
  Plus, 
  Check, 
  CheckCheck, 
  MoreVertical, 
  Paperclip, 
  Smile, 
  ShieldCheck, 
  Loader2, 
  X, 
  ArrowLeft,
  ArrowRight,
  Crown,
  Shield,
  Gem,
  Compass,
  Sparkles,
  Info,
  Mic,
  Image as ImageIcon,
  Play,
  Pause,
  ThumbsUp,
  Heart,
  SmilePlus,
  User,
  Trash2,
  LogOut,
  AlertTriangle,
  Clock,
  FolderHeart,
  Tag
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { Conversation, ChatMessage, UserPublicProfile, ConversationParticipant, FriendGroup, FriendRequest } from '../types/social';
import { getUserFriendGroups, resolveAndSortGroupMembers } from '../services/friendGroupService';
import { 
  subscribeToUserConversations, 
  subscribeToMessages, 
  sendChatMessage, 
  createGroupConversation,
  getOrCreateDirectConversation,
  addMemberToGroup,
  removeMemberFromGroup,
  deleteGroupConversation,
  leaveGroupConversation,
  MAX_GROUP_MEMBERS 
} from '../services/chatService';
import {
  getAllUsers,
  getUserProfile,
  areUsersBlockedEitherWay,
  areUsersFriends,
  getFriendsList,
  getFollowingList,
  sendFriendRequest,
  acceptFriendRequest,
  cancelFriendRequest,
  getFriendRequestsSent,
  getFriendRequestsReceived,
  isAdminAccount,
} from '../services/socialService';
import { CallLogsView } from './CallLogsView';
import { ConfirmModal } from './common/ConfirmModal';
import { useApp } from '../context/AppContext';

interface MessagesPageProps {
  currentUser?: AuthSession | null;
  initialConversationId?: string | null;
  onOpenVoiceCall: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }, isGroup?: boolean, groupParticipants?: any[]) => void;
  onOpenVideoCall: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }, isGroup?: boolean, groupParticipants?: any[]) => void;
  onViewUserProfile: (userIdOrHandle: string) => void;
  onNavigateBack?: () => void;
  onBackToPosting?: () => void;
  backDestination?: 'marketplace' | 'listing_detail' | null;
  activePostingTitle?: string;
}

const EMOJI_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥', '🚀'];

export const MessagesPage: React.FC<MessagesPageProps> = ({
  currentUser,
  initialConversationId,
  onOpenVoiceCall,
  onOpenVideoCall,
  onViewUserProfile,
  onNavigateBack,
  onBackToPosting,
  backDestination,
  activePostingTitle,
}) => {
  const { addToast } = useApp();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [conversationFilter, setConversationFilter] = useState<'all' | 'direct' | 'group' | 'calls'>('all');
  const [mainViewMode, setMainViewMode] = useState<'chats' | 'call_logs'>('chats');
  const [isSending, setIsSending] = useState(false);

  // Group info panel toggle
  const [showGroupInfo, setShowGroupInfo] = useState(false);

  // Message Reactions local store
  const [messageReactions, setMessageReactions] = useState<Record<string, Record<string, number>>>({});
  const [activeReactionMsgId, setActiveReactionMsgId] = useState<string | null>(null);

  // Voice Note Recording Simulator
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);

  // In-app prompt for adding friend / accepting request before placing friend-only audio/video call
  const [pendingCallFriendPrompt, setPendingCallFriendPrompt] = useState<{
    mode: 'voice' | 'video';
    action: 'send' | 'accept';
    recipient: ConversationParticipant;
  } | null>(null);

  // Unified New Chat / New Group Modal State
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [chatModalTab, setChatModalTab] = useState<'direct' | 'group'>('direct');
  const [directUserSearch, setDirectUserSearch] = useState('');

  // 1-on-1 Call Picker Modal State (Audio / Video, strictly 1 person at a time)
  const [callPickerMode, setCallPickerMode] = useState<'voice' | 'video' | null>(null);
  const [callPickerSearch, setCallPickerSearch] = useState('');

  // Group creation modal state
  const [groupNameInput, setGroupNameInput] = useState('');
  const [groupMemberSearch, setGroupMemberSearch] = useState('');
  const [groupListSearch, setGroupListSearch] = useState('');
  const [availableUsers, setAvailableUsers] = useState<UserPublicProfile[]>([]);
  const [selectedGroupMemberUids, setSelectedGroupMemberUids] = useState<Set<string>>(new Set());
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [groupCreateError, setGroupCreateError] = useState('');

  // Add member modal state for active group
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [addMemberSearch, setAddMemberSearch] = useState('');

  // Group Creator & Member Controls (Eject, End Group, Leave Group)
  const [memberToEject, setMemberToEject] = useState<ConversationParticipant | null>(null);
  const [isEjecting, setIsEjecting] = useState(false);
  const [showEndGroupConfirm, setShowEndGroupConfirm] = useState(false);
  const [isEndingGroup, setIsEndingGroup] = useState(false);
  const [showLeaveGroupConfirm, setShowLeaveGroupConfirm] = useState(false);
  const [isLeavingGroup, setIsLeavingGroup] = useState(false);
  const [groupActionError, setGroupActionError] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeUid = currentUser?.uid || currentUser?.id || 'guest';

  // Check if current user is creator of the selected group
  const isSelectedGroupCreator = 
    selectedConversation?.type === 'group' && 
    (selectedConversation.createdBy === activeUid || currentUser?.role === 'super_admin');

  // 1. Subscribe to current user's conversations
  useEffect(() => {
    const unsubscribe = subscribeToUserConversations(activeUid, (convList) => {
      setConversations(convList);

      if (initialConversationId) {
        const found = convList.find((c) => c.id === initialConversationId);
        if (found) setSelectedConversation(found);
      } else if (!selectedConversation && convList.length > 0) {
        setSelectedConversation(convList[0]);
      } else if (selectedConversation) {
        const updated = convList.find((c) => c.id === selectedConversation.id);
        if (updated) {
          setSelectedConversation(updated);
        } else {
          // Conversation was deleted or user was removed
          setSelectedConversation(convList[0] || null);
        }
      }
    });

    return () => unsubscribe();
  }, [activeUid, initialConversationId]);

  // 2. Subscribe to messages when selectedConversation changes
  useEffect(() => {
    if (!selectedConversation) {
      setMessages([]);
      return;
    }

    const unsubscribe = subscribeToMessages(selectedConversation.id, (msgList) => {
      setMessages(msgList);
    });

    return () => unsubscribe();
  }, [selectedConversation?.id]);

  // 3. Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 4. Listen for external open_direct_conversation events & select target conversation
  useEffect(() => {
    const handleOpenConv = (e: Event) => {
      const custom = e as CustomEvent<string>;
      if (custom.detail) {
        setMainViewMode('chats');
        const found = conversations.find((c) => c.id === custom.detail);
        if (found) {
          setSelectedConversation(found);
        }
      }
    };
    window.addEventListener('open_direct_conversation', handleOpenConv);
    return () => window.removeEventListener('open_direct_conversation', handleOpenConv);
  }, [conversations]);

  // 5. Auto-focus message input when active conversation changes
  useEffect(() => {
    if (selectedConversation) {
      const timer = setTimeout(() => {
        const input = document.getElementById('chat-message-input');
        if (input) {
          input.focus();
        }
      }, 120);
      return () => clearTimeout(timer);
    }
  }, [selectedConversation?.id]);

  const [friendsList, setFriendsList] = useState<UserPublicProfile[]>([]);
  const [followingList, setFollowingList] = useState<UserPublicProfile[]>([]);
  const [sentRequests, setSentRequests] = useState<FriendRequest[]>([]);
  const [receivedRequests, setReceivedRequests] = useState<FriendRequest[]>([]);
  const [customGroupsMade, setCustomGroupsMade] = useState<FriendGroup[]>([]);
  const [, setBlockVersion] = useState(0);
  const [chatBlockNotice, setChatBlockNotice] = useState<string | null>(null);

  const showBlockNotice = (msg: string) => {
    setChatBlockNotice(msg);
    setTimeout(() => {
      setChatBlockNotice((prev) => (prev === msg ? null : prev));
    }, 4000);
  };

  const viewerIsAdmin = isAdminAccount(currentUser);

  const isPeerBlocked = (peerUid?: string, peerHandle?: string): boolean => {
    if (!currentUser || viewerIsAdmin) return false;
    return Boolean(
      (peerUid && areUsersBlockedEitherWay(currentUser.uid, peerUid)) ||
      (peerHandle && areUsersBlockedEitherWay(currentUser.id, peerHandle)) ||
      (peerUid && areUsersBlockedEitherWay(currentUser.id, peerUid)) ||
      (peerHandle && areUsersBlockedEitherWay(currentUser.uid, peerHandle))
    );
  };

  const isPeerFriend = (peerUid?: string, peerHandle?: string): boolean => {
    if (!currentUser) return false;
    if (viewerIsAdmin) return true;
    const cleanPeerUid = (peerUid || '').replace(/^@/, '');
    const cleanPeerHandle = (peerHandle || '').replace(/^@/, '');
    const myUid = currentUser.uid || '';
    const myId = currentUser.id || '';

    if (
      (cleanPeerUid && (areUsersFriends(myUid, cleanPeerUid) || areUsersFriends(myId, cleanPeerUid))) ||
      (cleanPeerHandle && (areUsersFriends(myUid, cleanPeerHandle) || areUsersFriends(myId, cleanPeerHandle))) ||
      (cleanPeerUid && (areUsersFriends(myUid, `user-${cleanPeerUid}`) || areUsersFriends(myId, `user-${cleanPeerUid}`)))
    ) {
      return true;
    }

    if (friendsList && friendsList.length > 0) {
      const match = friendsList.some((f) => {
        const fUid = (f.uid || '').toLowerCase();
        const fId = (f.userId || '').toLowerCase().replace(/^@/, '');
        const pUid = cleanPeerUid.toLowerCase();
        const pId = cleanPeerHandle.toLowerCase();
        return (
          (pUid && (fUid === pUid || fId === pUid || fUid === `user-${pUid}` || `user-${fId}` === pUid)) ||
          (pId && (fUid === pId || fId === pId || fUid === `user-${pId}` || `user-${fId}` === pId))
        );
      });
      if (match) return true;
    }

    return false;
  };

  const getPeerFriendStatus = (peerUid?: string, peerHandle?: string): 'friends' | 'pending_sent' | 'pending_received' | 'none' => {
    if (isPeerFriend(peerUid, peerHandle)) return 'friends';
    const normalizePeer = (s?: string) => (s || '').toLowerCase().replace(/^@/, '').replace(/^user-/, '').replace(/^demo-/, '');
    const peerKeys = new Set([normalizePeer(peerUid), normalizePeer(peerHandle)].filter(Boolean));
    if (
      sentRequests.some(
        (r) => peerKeys.has(normalizePeer(r.receiverUid)) || peerKeys.has(normalizePeer(r.receiverHandle))
      )
    ) {
      return 'pending_sent';
    }
    if (
      receivedRequests.some(
        (r) => peerKeys.has(normalizePeer(r.senderUid)) || peerKeys.has(normalizePeer(r.senderHandle))
      )
    ) {
      return 'pending_received';
    }
    return 'none';
  };

  const loadDirectoryData = () => {
    getAllUsers(activeUid).then(setAvailableUsers).catch(console.error);
    if (activeUid) {
      getFriendsList(activeUid).then(setFriendsList).catch(console.error);
      getFollowingList(activeUid).then(setFollowingList).catch(console.error);
      getFriendRequestsSent(activeUid).then(setSentRequests).catch(console.error);
      getFriendRequestsReceived(activeUid).then(setReceivedRequests).catch(console.error);
      setCustomGroupsMade(getUserFriendGroups(activeUid));
    }
  };

  // Load available users, friends, following, and custom groups made
  useEffect(() => {
    loadDirectoryData();
    const handleDirectoryRefresh = () => {
      setBlockVersion((v) => v + 1);
      loadDirectoryData();
    };
    window.addEventListener('final_finance_block_updated', handleDirectoryRefresh);
    window.addEventListener('final_finance_friends_updated', handleDirectoryRefresh);
    window.addEventListener('final_finance_friend_groups_updated', handleDirectoryRefresh);
    return () => {
      window.removeEventListener('final_finance_block_updated', handleDirectoryRefresh);
      window.removeEventListener('final_finance_friends_updated', handleDirectoryRefresh);
      window.removeEventListener('final_finance_friend_groups_updated', handleDirectoryRefresh);
    };
  }, [activeUid]);

  useEffect(() => {
    if (showNewChatModal) {
      loadDirectoryData();
    }
  }, [showNewChatModal]);

  // Voice note timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecordingVoice) {
      interval = setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } else {
      setRecordSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isRecordingVoice]);

  // Direct 1-on-1 actions with a single person
  const handleStartDirectChat = async (targetUser: UserPublicProfile) => {
    if (!currentUser) return;
    if (isPeerBlocked(targetUser.uid, targetUser.userId)) {
      showBlockNotice('Cannot start chat: communication is blocked between these accounts.');
      return;
    }
    try {
      const conv = await getOrCreateDirectConversation(currentUser, targetUser);
      setSelectedConversation(conv);
      setShowNewChatModal(false);
    } catch (err: any) {
      console.error('Error starting direct conversation:', err);
      showBlockNotice(err?.message || 'Cannot start direct conversation due to a block.');
    }
  };

  const handleStartDirectVoiceCall = (targetUser: UserPublicProfile) => {
    if (isPeerBlocked(targetUser.uid, targetUser.userId)) {
      showBlockNotice('Cannot place audio call: communication is blocked between these accounts.');
      return;
    }
    if (!isPeerFriend(targetUser.uid, targetUser.userId)) {
      showBlockNotice('Audio calls are only available with your friends.');
      return;
    }
    setShowNewChatModal(false);
    onOpenVoiceCall(
      { uid: targetUser.uid, userId: targetUser.userId, name: targetUser.name, avatarUrl: targetUser.avatarUrl },
      false
    );
  };

  const handleStartDirectVideoCall = (targetUser: UserPublicProfile) => {
    if (isPeerBlocked(targetUser.uid, targetUser.userId)) {
      showBlockNotice('Cannot place video call: communication is blocked between these accounts.');
      return;
    }
    if (!isPeerFriend(targetUser.uid, targetUser.userId)) {
      showBlockNotice('Video calls are only available with your friends.');
      return;
    }
    setShowNewChatModal(false);
    onOpenVideoCall(
      { uid: targetUser.uid, userId: targetUser.userId, name: targetUser.name, avatarUrl: targetUser.avatarUrl },
      false
    );
  };

  // Open or initialize a Group Chat from a Community & Social Feed custom group
  const handleOpenCustomGroupChat = async (group: FriendGroup) => {
    if (!currentUser) return;

    const existing = conversations.find(
      (c) =>
        c.type === 'group' &&
        (c.name || '').trim().toLowerCase() === group.name.trim().toLowerCase()
    );
    if (existing) {
      setSelectedConversation(existing);
      setMainViewMode('chats');
      setShowNewChatModal(false);
      return;
    }

    const userPoolMap = new Map<string, UserPublicProfile>();
    [...availableUsers, ...friendsList, ...followingList].forEach((u) => {
      if (u && u.uid) {
        userPoolMap.set(u.uid, u);
      }
    });
    const resolvedMembers = resolveAndSortGroupMembers(group, Array.from(userPoolMap.values()));
    const eligibleMembers = resolvedMembers.filter(
      (m) => m.uid !== activeUid && !isPeerBlocked(m.uid, m.userId)
    );

    if (group.memberUids.length > 0 && eligibleMembers.length === 0) {
      const msg = 'Cannot open group chat: all assigned members in this group are currently blocked.';
      setGroupCreateError(msg);
      showBlockNotice(msg);
      return;
    }

    setIsCreatingGroup(true);
    setGroupCreateError('');
    try {
      const res = await createGroupConversation(currentUser, group.name, eligibleMembers);
      if (res.success && res.conversation) {
        setSelectedConversation(res.conversation);
        setMainViewMode('chats');
        setShowNewChatModal(false);
      } else {
        setGroupCreateError(res.error || 'Failed to open group chat.');
      }
    } catch (err: any) {
      setGroupCreateError(err?.message || 'Error opening group chat.');
    } finally {
      setIsCreatingGroup(false);
    }
  };

  // Send message
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !selectedConversation || isSending || !currentUser) return;

    if (selectedConversation.type === 'direct') {
      const recipient = getDirectRecipient(selectedConversation);
      if (isPeerBlocked(recipient.uid, recipient.userId)) {
        showBlockNotice('Cannot send message: communication is blocked between these accounts.');
        return;
      }
    }

    const textToSend = inputText.trim();
    setInputText('');
    setIsSending(true);

    try {
      await sendChatMessage(selectedConversation.id, currentUser, textToSend);
    } catch (err: any) {
      console.error('Failed to send message:', err);
      showBlockNotice(err?.message || 'Unable to send message.');
    } finally {
      setIsSending(false);
    }
  };

  // Send simulated voice note
  const handleFinishVoiceNote = async () => {
    if (!selectedConversation || !currentUser) return;
    if (selectedConversation.type === 'direct') {
      const recipient = getDirectRecipient(selectedConversation);
      if (isPeerBlocked(recipient.uid, recipient.userId)) {
        setIsRecordingVoice(false);
        showBlockNotice('Cannot send voice message: communication is blocked between these accounts.');
        return;
      }
    }
    const durationStr = `${Math.floor(recordSeconds / 60)}:${(recordSeconds % 60).toString().padStart(2, '0')}`;
    setIsRecordingVoice(false);
    
    try {
      await sendChatMessage(
        selectedConversation.id,
        currentUser,
        `🎤 Voice Message (${durationStr})`
      );
    } catch (err: any) {
      console.error('Error sending voice note:', err);
      showBlockNotice(err?.message || 'Unable to send voice note.');
    }
  };

  // Handle Photo Attachment
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedConversation || !currentUser) return;
    if (selectedConversation.type === 'direct') {
      const recipient = getDirectRecipient(selectedConversation);
      if (isPeerBlocked(recipient.uid, recipient.userId)) {
        showBlockNotice('Cannot share photo: communication is blocked between these accounts.');
        return;
      }
    }

    try {
      await sendChatMessage(
        selectedConversation.id,
        currentUser,
        `📷 Shared Photo: ${file.name}`
      );
    } catch (err: any) {
      console.error('Error uploading photo:', err);
      showBlockNotice(err?.message || 'Unable to send photo.');
    }
  };

  // Message reaction handler
  const handleReactToMessage = (messageId: string, emoji: string) => {
    setMessageReactions((prev) => {
      const msgMap = { ...(prev[messageId] || {}) };
      msgMap[emoji] = (msgMap[emoji] || 0) + 1;
      return { ...prev, [messageId]: msgMap };
    });
    setActiveReactionMsgId(null);
  };

  // Get recipient profile for direct conversation
  const getDirectRecipient = (conv: Conversation) => {
    const otherUid = conv.participantIds.find((id) => id !== activeUid) || conv.participantIds[0];
    return conv.participants[otherUid] || {
      uid: otherUid,
      userId: 'user',
      name: 'Ecosystem Member',
      avatarUrl: undefined,
    };
  };

  // Handle Call Triggers (Strictly 1-on-1 & Friends Only)
  const handleTriggerVoiceCall = () => {
    if (!selectedConversation) {
      setCallPickerSearch('');
      setCallPickerMode('voice');
      return;
    }
    if (selectedConversation.type === 'group') {
      // Group calling is disabled; let user choose 1 friend to call
      setCallPickerSearch('');
      setCallPickerMode('voice');
    } else {
      const recipient = getDirectRecipient(selectedConversation);
      if (isPeerBlocked(recipient.uid, recipient.userId)) {
        showBlockNotice('Cannot place audio call: communication is blocked between these accounts.');
        return;
      }
      if (!isPeerFriend(recipient.uid, recipient.userId)) {
        showBlockNotice('Audio calls are only available with your friends.');
        return;
      }
      onOpenVoiceCall(recipient, false);
    }
  };

  const handleTriggerVideoCall = () => {
    if (!selectedConversation) {
      setCallPickerSearch('');
      setCallPickerMode('video');
      return;
    }
    if (selectedConversation.type === 'group') {
      // Group calling is disabled; let user choose 1 friend to video call
      setCallPickerSearch('');
      setCallPickerMode('video');
    } else {
      const recipient = getDirectRecipient(selectedConversation);
      if (isPeerBlocked(recipient.uid, recipient.userId)) {
        showBlockNotice('Cannot place video call: communication is blocked between these accounts.');
        return;
      }
      if (!isPeerFriend(recipient.uid, recipient.userId)) {
        showBlockNotice('Video calls are only available with your friends.');
        return;
      }
      onOpenVideoCall(recipient, false);
    }
  };

  // Create Group Conference (Up to 20 People)
  const handleCreateGroupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupNameInput.trim()) {
      setGroupCreateError('Please enter a group conference name.');
      return;
    }
    if (selectedGroupMemberUids.size === 0) {
      setGroupCreateError('Please select at least 1 member to invite.');
      return;
    }
    if (selectedGroupMemberUids.size + 1 > MAX_GROUP_MEMBERS) {
      setGroupCreateError(`Cannot exceed maximum limit of ${MAX_GROUP_MEMBERS} members.`);
      return;
    }

    setIsCreatingGroup(true);
    setGroupCreateError('');

    try {
      const selectedMembers = availableUsers.filter((u) => selectedGroupMemberUids.has(u.uid));
      const res = await createGroupConversation(currentUser!, groupNameInput.trim(), selectedMembers);
      if (res.success && res.conversation) {
        setSelectedConversation(res.conversation);
        setShowNewChatModal(false);
        setGroupNameInput('');
        setSelectedGroupMemberUids(new Set());
      } else {
        setGroupCreateError(res.error || 'Failed to initialize group');
      }
    } catch (err: any) {
      setGroupCreateError(err?.message || 'Error creating group');
    } finally {
      setIsCreatingGroup(false);
    }
  };

  // Add Member to existing group
  const handleAddMemberToActiveGroup = async (user: UserPublicProfile) => {
    if (!selectedConversation || selectedConversation.type !== 'group' || !currentUser) return;
    if (isPeerBlocked(user.uid, user.userId)) {
      showBlockNotice('Cannot add blocked user to group.');
      return;
    }
    try {
      const res = await addMemberToGroup(selectedConversation.id, user, currentUser);
      if (!res.success && res.error) {
        showBlockNotice(res.error);
        return;
      }
      setShowAddMemberModal(false);
    } catch (err) {
      console.error('Error adding member:', err);
    }
  };

  // Eject member from group (Creator only)
  const handleConfirmEjectMember = async () => {
    if (!selectedConversation || !memberToEject || !currentUser) return;
    setIsEjecting(true);
    setGroupActionError('');

    try {
      const res = await removeMemberFromGroup(selectedConversation.id, memberToEject.uid, currentUser);
      if (res.success) {
        setMemberToEject(null);
      } else {
        setGroupActionError(res.error || 'Failed to eject member');
      }
    } catch (err: any) {
      setGroupActionError(err?.message || 'Error ejecting member');
    } finally {
      setIsEjecting(false);
    }
  };

  // End & Delete group room (Creator only)
  const handleConfirmEndGroup = async () => {
    if (!selectedConversation || !currentUser) return;
    setIsEndingGroup(true);
    setGroupActionError('');

    try {
      const res = await deleteGroupConversation(selectedConversation.id, currentUser);
      if (res.success) {
        setShowEndGroupConfirm(false);
        setShowGroupInfo(false);
        setSelectedConversation(null);
      } else {
        setGroupActionError(res.error || 'Failed to end group room');
      }
    } catch (err: any) {
      setGroupActionError(err?.message || 'Error ending group');
    } finally {
      setIsEndingGroup(false);
    }
  };

  // Leave group room (Non-creator or any member)
  const handleConfirmLeaveGroup = async () => {
    if (!selectedConversation || !currentUser) return;
    setIsLeavingGroup(true);
    setGroupActionError('');

    try {
      const res = await leaveGroupConversation(selectedConversation.id, currentUser);
      if (res.success) {
        setShowLeaveGroupConfirm(false);
        setShowGroupInfo(false);
        setSelectedConversation(null);
      } else {
        setGroupActionError(res.error || 'Failed to leave group room');
      }
    } catch (err: any) {
      setGroupActionError(err?.message || 'Error leaving group');
    } finally {
      setIsLeavingGroup(false);
    }
  };

  // Filter conversations
  const filteredConversations = conversations.filter((c) => {
    if (conversationFilter === 'direct' && c.type !== 'direct') return false;
    if (conversationFilter === 'group' && c.type !== 'group') return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    if (c.type === 'group') {
      return (c.name || '').toLowerCase().includes(q);
    }
    const other = getDirectRecipient(c);
    return other.name.toLowerCase().includes(q) || other.userId.toLowerCase().includes(q);
  });

  const activeGroupNamesSet = new Set(
    conversations
      .filter((c) => c.type === 'group' && c.name)
      .map((c) => (c.name || '').trim().toLowerCase())
  );

  const unstartedCustomGroups = customGroupsMade.filter((g) => {
    if (activeGroupNamesSet.has(g.name.trim().toLowerCase())) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      g.name.toLowerCase().includes(q) ||
      (g.description && g.description.toLowerCase().includes(q))
    );
  });

  return (
    <div
      id="messages-page-root"
      className="w-full max-w-6xl mx-auto h-[calc(100dvh-105px)] sm:h-[calc(100dvh-125px)] min-h-[500px] max-h-[880px] bg-white border border-neutral-200/90 rounded-3xl shadow-sm overflow-hidden flex flex-col md:flex-row text-left"
    >
      {/* ================= LEFT SIDEBAR: CONVERSATIONS LIST ================= */}
      <div className={`w-full md:w-80 lg:w-96 border-r border-neutral-200/90 flex flex-col bg-neutral-50/50 ${selectedConversation || mainViewMode === 'call_logs' ? 'hidden md:flex' : 'flex'}`}>
        {/* Header */}
        <div className="p-3 sm:p-3.5 border-b border-neutral-200/90 flex items-center justify-between bg-white text-left">
          <div className="flex items-center gap-2 min-w-0">
            {(backDestination === 'marketplace' || backDestination === 'listing_detail' || onBackToPosting) && (onBackToPosting || onNavigateBack) && (
              <button
                type="button"
                onClick={() => {
                  if (backDestination === 'marketplace' && onNavigateBack) {
                    onNavigateBack();
                  } else if (onBackToPosting) {
                    onBackToPosting();
                  } else if (onNavigateBack) {
                    onNavigateBack();
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-2xs cursor-pointer shrink-0"
                title={
                  backDestination === 'marketplace'
                    ? 'Back to Marketplace'
                    : activePostingTitle
                      ? `Back to: ${activePostingTitle}`
                      : 'Back to posting'
                }
              >
                <span className="hidden sm:inline">
                  {backDestination === 'marketplace' ? 'Back to Marketplace' : 'Back to Posting'}
                </span>
                <span className="sm:hidden">
                  {backDestination === 'marketplace' ? 'Marketplace' : 'Posting'}
                </span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
            <h2 className="font-serif-lux text-base sm:text-lg font-light text-black tracking-tight truncate">
              {mainViewMode === 'call_logs' ? 'Call Logs' : 'Social Interactions'}
            </h2>
          </div>
        </div>

        {/* Filter Pills: All | 1-on-1 Direct | Groups | Call Logs */}
        <div className="px-3 pt-2.5 pb-1 flex items-center justify-center gap-1 bg-white border-b border-neutral-100 overflow-x-auto no-scrollbar text-center">
          <button
            type="button"
            onClick={() => {
              setConversationFilter('all');
              setMainViewMode('chats');
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              conversationFilter === 'all' && mainViewMode === 'chats'
                ? 'bg-black text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            All
          </button>
          <button
            type="button"
            onClick={() => {
              setConversationFilter('direct');
              setMainViewMode('chats');
              if (selectedConversation?.type === 'group') {
                const firstDirect = conversations.find((c) => c.type === 'direct') || null;
                setSelectedConversation(firstDirect);
              }
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              conversationFilter === 'direct' && mainViewMode === 'chats'
                ? 'bg-black text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            Direct
          </button>
          <button
            type="button"
            onClick={() => {
              setConversationFilter('group');
              setMainViewMode('chats');
              if (selectedConversation?.type === 'direct') {
                const firstGroup = conversations.find((c) => c.type === 'group') || null;
                setSelectedConversation(firstGroup);
              }
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-1 whitespace-nowrap ${
              conversationFilter === 'group' && mainViewMode === 'chats'
                ? 'bg-black text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <span>Groups</span>
            <span className="text-[10px] opacity-75 font-mono">(20)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setConversationFilter('calls');
              setMainViewMode('call_logs');
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-1 whitespace-nowrap ${
              mainViewMode === 'call_logs'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <Phone className="w-3 h-3" />
            <span>Call Logs</span>
          </button>
          </div>

        {/* Search Conversations */}
        <div className="p-3 border-b border-neutral-100 bg-white flex justify-center">
          <div className="relative flex items-center w-full max-w-xs">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                conversationFilter === 'group'
                  ? 'Search groups...'
                  : conversationFilter === 'direct'
                    ? 'Search direct chats...'
                    : 'Search conversations...'
              }
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-100/80 border border-neutral-200/80 text-xs text-black placeholder:text-neutral-400 focus:outline-none focus:bg-white focus:ring-1 focus:ring-black transition-all text-center sm:text-left"
            />
          </div>
        </div>

        {/* Conversations Scrollable List */}
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-100">
          {filteredConversations.length === 0 && (conversationFilter !== 'group' || unstartedCustomGroups.length === 0) ? (
            <div className="p-8 text-center flex flex-col items-center justify-center text-neutral-400 text-xs space-y-3">
              <MessageSquare className="w-8 h-8 mx-auto text-neutral-300 stroke-1" />
              <p className="font-semibold text-neutral-700 text-center">
                {conversationFilter === 'group'
                  ? 'No group conversations found'
                  : conversationFilter === 'direct'
                    ? 'No direct 1-on-1 chats found'
                    : 'No active conversations found'}
              </p>
              <p className="text-[11px] text-neutral-500 text-center max-w-xs">
                {conversationFilter === 'group'
                  ? 'Open a custom group from Community & Social Feed or use Group (Max 20) below.'
                  : conversationFilter === 'direct'
                    ? 'Use 1-on-1 Chat or Audio/Video Call below to reach someone directly.'
                    : 'Use 1-on-1 Chat, Group (Max 20), or Audio/Video Call below to get started.'}
              </p>
              {conversationFilter === 'group' && (
                <button
                  type="button"
                  onClick={() => {
                    setChatModalTab('group');
                    setShowNewChatModal(true);
                  }}
                  className="mt-2 px-4 py-2 rounded-xl bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-colors inline-flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Open or Create Group</span>
                </button>
              )}
            </div>
          ) : (
            <>
              {filteredConversations.map((conv) => {
                const isSelected = selectedConversation?.id === conv.id;
                const isGroup = conv.type === 'group';
                const recipient = isGroup ? null : getDirectRecipient(conv);

                return (
                  <button
                    key={conv.id}
                    type="button"
                    onClick={() => {
                      setSelectedConversation(conv);
                      setMainViewMode('chats');
                    }}
                    className={`w-full p-3.5 flex items-start gap-3 text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-neutral-100/90 font-medium'
                        : 'hover:bg-neutral-100/50 bg-white'
                    }`}
                  >
                    {/* Avatar */}
                    <div className="relative shrink-0">
                      {isGroup ? (
                        conv.groupAvatarUrl ? (
                          <img
                            src={conv.groupAvatarUrl}
                            alt={conv.name}
                            className="w-11 h-11 rounded-2xl object-cover border border-neutral-200"
                          />
                        ) : (
                          <div className="w-11 h-11 rounded-2xl bg-neutral-900 text-white flex items-center justify-center text-xs font-mono">
                            <Users className="w-5 h-5 text-emerald-400" />
                          </div>
                        )
                      ) : recipient?.avatarUrl ? (
                        <img
                          src={recipient.avatarUrl}
                          alt={recipient.name}
                          className="w-11 h-11 rounded-full object-cover border border-neutral-200"
                        />
                      ) : (
                        <div className="w-11 h-11 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                          {recipient?.name ? recipient.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                      )}

                      {isGroup && (
                        <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded-full bg-emerald-700 text-white text-[9px] font-mono border border-white">
                          {conv.participantIds.length}
                        </span>
                      )}
                    </div>

                    {/* Content Preview */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <h4 className="text-xs font-semibold text-black truncate flex items-center gap-1.5">
                          <span>{isGroup ? conv.name : recipient?.name}</span>
                          {!isGroup && (
                            <span className="text-[10px] font-mono text-neutral-400 font-normal">
                              @{recipient?.userId}
                            </span>
                          )}
                        </h4>
                        <span className="text-[10px] text-neutral-400 font-mono shrink-0">
                          {conv.updatedAt ? new Date(conv.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                        </span>
                      </div>

                      <p className="text-[11px] text-neutral-500 truncate">
                        {conv.lastMessageText || 'Direct channel opened'}
                      </p>
                    </div>
                  </button>
                );
              })}

              {conversationFilter === 'group' && unstartedCustomGroups.length > 0 && (
                <div className="bg-neutral-50/70">
                  <div className="px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-100">
                    Community &amp; Social Feed Groups ({unstartedCustomGroups.length})
                  </div>
                  {unstartedCustomGroups.map((group) => (
                    <button
                      key={group.id}
                      type="button"
                      onClick={() => handleOpenCustomGroupChat(group)}
                      className="w-full p-3.5 flex items-center justify-between gap-3 text-left hover:bg-neutral-100/70 bg-white transition-all cursor-pointer border-b border-neutral-100 last:border-b-0"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {group.avatarUrl ? (
                          <img
                            src={group.avatarUrl}
                            alt={group.name}
                            className="w-10 h-10 rounded-2xl object-cover border border-neutral-200 shrink-0"
                          />
                        ) : (
                          <div
                            className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 text-white text-xs font-bold shadow-2xs"
                            style={{ backgroundColor: group.color || '#f59e0b' }}
                          >
                            {group.name.charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-black truncate">{group.name}</p>
                          <p className="text-[11px] text-neutral-500 truncate">
                            {group.memberUids.length} {group.memberUids.length === 1 ? 'member' : 'members'} • Tap to start chat
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] font-semibold px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                        Open
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Left Sidebar Bottom Quick Bar: 1-on-1 Audio & Video Call + Start Chat / Group */}
        <div className="p-3 border-t border-neutral-200/90 bg-white space-y-2 shrink-0">
          <div className="grid grid-cols-2 gap-2">
            <button
              id="btn-sidebar-audio-call"
              type="button"
              onClick={() => {
                setCallPickerSearch('');
                setCallPickerMode('voice');
              }}
              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-black hover:text-white text-neutral-900 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              title="1-on-1 Audio Call (1 person at a time)"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Audio Call</span>
            </button>
            <button
              id="btn-sidebar-video-call"
              type="button"
              onClick={() => {
                setCallPickerSearch('');
                setCallPickerMode('video');
              }}
              className="min-h-[36px] px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-600 text-emerald-800 hover:text-white border border-emerald-200 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              title="1-on-1 Video Call (1 person at a time)"
            >
              <Video className="w-3.5 h-3.5" />
              <span>Video Call</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                setChatModalTab('direct');
                setShowNewChatModal(true);
                setGroupCreateError('');
                setMainViewMode('chats');
              }}
              className="min-h-[34px] px-2.5 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-[11px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <MessageSquare className="w-3 h-3 text-amber-400" />
              <span>1-on-1 Chat</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setChatModalTab('group');
                setShowNewChatModal(true);
                setGroupCreateError('');
                setMainViewMode('chats');
              }}
              className="min-h-[34px] px-2.5 py-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-[11px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Users className="w-3 h-3 text-emerald-600" />
              <span>Group (Max 20)</span>
            </button>
          </div>
        </div>
      </div>

      {/* ================= RIGHT: CHAT CONVERSATION VIEW, CALL LOGS, OR TWEETING ================= */}
      {mainViewMode === 'call_logs' ? (
        <div className="flex-1 flex flex-col bg-white h-full relative overflow-hidden">
          <CallLogsView
            currentUser={currentUser}
            onOpenVoiceCall={onOpenVoiceCall}
            onOpenVideoCall={onOpenVideoCall}
            onOpenNewCall={(mode) => {
              setCallPickerSearch('');
              setCallPickerMode(mode);
            }}
            onViewUserProfile={onViewUserProfile}
            onBackToMessages={() => {
              setMainViewMode('chats');
              setConversationFilter('all');
            }}
            onOpenChatWithUser={async (uid) => {
              const targetUser = availableUsers.find((u) => u.uid === uid);
              if (targetUser && currentUser) {
                if (isPeerBlocked(targetUser.uid, targetUser.userId)) {
                  showBlockNotice('Cannot start chat: communication is blocked between these accounts.');
                  return;
                }
                try {
                  const res = await getOrCreateDirectConversation(currentUser, targetUser);
                  if (res) {
                    setSelectedConversation(res);
                    setMainViewMode('chats');
                  }
                } catch (err: any) {
                  showBlockNotice(err?.message || 'Chat disabled due to block.');
                }
              }
            }}
          />
        </div>
      ) : selectedConversation ? (
        <div className="flex-1 flex flex-col bg-white h-full relative overflow-hidden">
          {/* Active Conversation Top Bar */}
          <div className="p-3 sm:p-3.5 border-b border-neutral-200/90 grid grid-cols-[1fr_auto] md:grid-cols-[1fr_auto_1fr] items-center gap-2 bg-white z-10 shadow-2xs shrink-0">
            {/* Left Slot: Mobile list back + Posting / Marketplace Return Sign (Arrow to the right) */}
            <div className="flex items-center gap-2 justify-self-start min-w-0">
              <button
                type="button"
                onClick={() => setSelectedConversation(null)}
                className="p-1.5 rounded-full text-neutral-500 hover:text-black hover:bg-neutral-100 transition-colors md:hidden cursor-pointer shrink-0"
                title="Back to conversation list"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>

              {(backDestination === 'marketplace' || backDestination === 'listing_detail' || onBackToPosting) && (onBackToPosting || onNavigateBack) && (
                <button
                  type="button"
                  onClick={() => {
                    if (backDestination === 'marketplace' && onNavigateBack) {
                      onNavigateBack();
                    } else if (onBackToPosting) {
                      onBackToPosting();
                    } else if (onNavigateBack) {
                      onNavigateBack();
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-2xs cursor-pointer shrink-0"
                  title={
                    backDestination === 'marketplace'
                      ? 'Return to Marketplace'
                      : activePostingTitle
                        ? `Return to: ${activePostingTitle}`
                        : 'Back to posting'
                  }
                >
                  <span className="hidden lg:inline">
                    {backDestination === 'marketplace' ? 'Back to Marketplace' : 'Back to Posting'}
                  </span>
                  <span className="lg:hidden">
                    {backDestination === 'marketplace' ? 'Marketplace' : 'Posting'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Center Slot: Targeted User Name, Avatar & Info (Aligned to Center) */}
            <div className="col-span-2 md:col-span-1 order-last md:order-none justify-self-center flex justify-center min-w-0 max-w-full">
              {selectedConversation.type === 'group' ? (
                <div
                  onClick={() => setShowGroupInfo(!showGroupInfo)}
                  className="flex items-center justify-center gap-2.5 min-w-0 cursor-pointer group text-center"
                >
                  <div className="w-9 h-9 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Users className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="min-w-0 flex flex-col items-center text-center">
                    <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-0.5 min-w-0">
                      <h3 className="font-semibold text-sm text-black truncate max-w-[180px] sm:max-w-[240px] group-hover:underline">
                        {selectedConversation.name}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-mono font-bold shrink-0">
                        {selectedConversation.participantIds.length} / 20 Max
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-500 truncate max-w-[220px] sm:max-w-[280px] mt-0.5 text-center">
                      {isSelectedGroupCreator ? '👑 You are the room creator' : 'Click to view participants & actions'}
                    </p>
                  </div>
                </div>
              ) : (
                (() => {
                  const recipient = getDirectRecipient(selectedConversation);
                  const peerStatus = recipient ? getPeerFriendStatus(recipient.uid, recipient.userId) : 'none';
                  const isDirectFriend = peerStatus === 'friends';
                  const isDirectBlocked = Boolean(recipient && isPeerBlocked(recipient.uid, recipient.userId));

                  return (
                    <div
                      onClick={() => onViewUserProfile(recipient.userId || recipient.uid)}
                      className="flex items-center justify-center gap-2.5 min-w-0 cursor-pointer group text-center"
                    >
                      {recipient.avatarUrl ? (
                        <img
                          src={recipient.avatarUrl}
                          alt={recipient.name}
                          className="w-9 h-9 rounded-full object-cover border border-neutral-200 shrink-0 group-hover:scale-105 transition-transform"
                        />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-sm font-serif-lux shrink-0">
                          {recipient.name ? recipient.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                      )}
                      <div className="min-w-0 flex flex-col items-center text-center">
                        <div className="flex items-center justify-center gap-1.5 flex-wrap">
                          <h3 className="font-semibold text-sm text-black group-hover:underline truncate max-w-[170px] sm:max-w-[230px] text-center">
                            {recipient.name}
                          </h3>
                          {isDirectFriend ? (
                            <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[10px] font-bold text-emerald-700 shrink-0">
                              <Check className="w-2.5 h-2.5" />
                              <span>Friends</span>
                            </span>
                          ) : !isDirectBlocked && peerStatus === 'pending_sent' ? (
                            <button
                              type="button"
                              onClick={async (e) => {
                                e.stopPropagation();
                                if (!currentUser) return;
                                await cancelFriendRequest(currentUser.uid || currentUser.id, recipient.uid);
                                loadDirectoryData();
                                addToast({
                                  type: 'info',
                                  title: 'Request Cancelled',
                                  message: `Withdrew friend request to ${recipient.name}.`,
                                });
                              }}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 text-[10px] font-bold transition-all cursor-pointer shrink-0"
                              title="Friend request sent — awaiting their acceptance (click to cancel)"
                            >
                              <Clock className="w-2.5 h-2.5" />
                              <span>Request Sent</span>
                            </button>
                          ) : !isDirectBlocked && peerStatus === 'pending_received' ? (
                            <button
                              type="button"
                              onClick={async (e) => {
                                e.stopPropagation();
                                if (!currentUser) return;
                                await acceptFriendRequest(currentUser, recipient);
                                loadDirectoryData();
                                addToast({
                                  type: 'success',
                                  title: 'Friends Connected',
                                  message: `You and ${recipient.name} are now mutual friends! Voice and video calls are unlocked.`,
                                });
                              }}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold shadow-2xs transition-all cursor-pointer shrink-0"
                              title="Accept incoming friend request"
                            >
                              <Check className="w-2.5 h-2.5" />
                              <span>Accept Request</span>
                            </button>
                          ) : (
                            !isDirectBlocked && (
                              <button
                                type="button"
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  if (!currentUser) return;
                                  const outcome = await sendFriendRequest(currentUser, recipient);
                                  loadDirectoryData();
                                  if (outcome === 'accepted') {
                                    addToast({
                                      type: 'success',
                                      title: 'Friends Connected',
                                      message: `You and ${recipient.name} are now mutual friends! Voice and video calls are unlocked.`,
                                    });
                                  } else {
                                    addToast({
                                      type: 'info',
                                      title: 'Friend Request Sent',
                                      message: `Sent friend request to ${recipient.name}. Both sides must accept before calling unlocks.`,
                                    });
                                  }
                                }}
                                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold shadow-2xs transition-all cursor-pointer shrink-0"
                                title="Send friend request (both sides must accept)"
                              >
                                <UserPlus className="w-2.5 h-2.5" />
                                <span>Add Friend</span>
                              </button>
                            )
                          )}
                        </div>
                        <p className="text-[11px] font-mono text-neutral-400 truncate max-w-[230px] sm:max-w-[300px] text-center">
                          @{recipient.userId} • {isDirectFriend ? 'Friends (Calls Enabled)' : peerStatus === 'pending_sent' ? 'Friend Request Pending' : peerStatus === 'pending_received' ? 'Incoming Friend Request' : 'Direct OTC Channel'}
                        </p>
                      </div>
                    </div>
                  );
                })()
              )}
            </div>

            {/* Top Right Action Icons: 1-on-1 Voice/Video Call or Group Actions */}
            <div className="flex items-center gap-1.5 shrink-0 justify-self-end">
              {selectedConversation.type === 'group' && (
                <button
                  id="btn-add-group-member"
                  type="button"
                  onClick={() => setShowAddMemberModal(true)}
                  className="min-h-[36px] px-3 py-1 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  title="Invite Member to Group (Up to 20)"
                >
                  <UserPlus className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="hidden sm:inline">Invite</span>
                </button>
              )}

              {/* 1-on-1 Audio & Video Call Buttons (Friends Only) */}
              {(() => {
                const directRecipient = selectedConversation.type === 'direct' ? getDirectRecipient(selectedConversation) : null;
                const isDirectBlocked = Boolean(directRecipient && isPeerBlocked(directRecipient.uid, directRecipient.userId));
                const peerStatus = directRecipient ? getPeerFriendStatus(directRecipient.uid, directRecipient.userId) : 'none';
                const isDirectFriend = peerStatus === 'friends';

                return (
                  <>
                    <button
                      id="btn-trigger-voice-call"
                      type="button"
                      onClick={() => {
                        if (isDirectBlocked) {
                          showBlockNotice('Cannot place call: communication is blocked between these accounts.');
                          return;
                        }
                        if (directRecipient && !isDirectFriend) {
                          if (peerStatus === 'pending_sent') {
                            addToast({
                              type: 'info',
                              title: 'Awaiting Acceptance',
                              message: `Friend request already sent to ${directRecipient.name}. Audio calls unlock once they accept.`,
                            });
                            return;
                          }
                          setPendingCallFriendPrompt({
                            mode: 'voice',
                            action: peerStatus === 'pending_received' ? 'accept' : 'send',
                            recipient: directRecipient,
                          });
                          return;
                        }
                        handleTriggerVoiceCall();
                      }}
                      disabled={isDirectBlocked}
                      className={`px-3 h-9 rounded-full flex items-center justify-center gap-1.5 text-xs font-bold transition-all shadow-2xs ${
                        isDirectBlocked
                          ? 'opacity-40 cursor-not-allowed bg-neutral-100 text-neutral-400'
                          : isDirectFriend
                            ? 'bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-800 border border-emerald-300 cursor-pointer'
                            : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-600 border border-neutral-200 cursor-pointer'
                      }`}
                      title={
                        isDirectBlocked
                          ? 'Calls disabled due to block'
                          : isDirectFriend
                            ? `1-on-1 Voice Call with ${directRecipient?.name || 'friend'}`
                            : 'Friends only: Both sides must be friends to place calls'
                      }
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Audio Call</span>
                    </button>

                    <button
                      id="btn-trigger-video-call"
                      type="button"
                      onClick={() => {
                        if (isDirectBlocked) {
                          showBlockNotice('Cannot place video call: communication is blocked between these accounts.');
                          return;
                        }
                        if (directRecipient && !isDirectFriend) {
                          if (peerStatus === 'pending_sent') {
                            addToast({
                              type: 'info',
                              title: 'Awaiting Acceptance',
                              message: `Friend request already sent to ${directRecipient.name}. Video calls unlock once they accept.`,
                            });
                            return;
                          }
                          setPendingCallFriendPrompt({
                            mode: 'video',
                            action: peerStatus === 'pending_received' ? 'accept' : 'send',
                            recipient: directRecipient,
                          });
                          return;
                        }
                        handleTriggerVideoCall();
                      }}
                      disabled={isDirectBlocked}
                      className={`px-3 h-9 rounded-full flex items-center justify-center gap-1.5 text-xs font-bold transition-all shadow-2xs ${
                        isDirectBlocked
                          ? 'opacity-40 cursor-not-allowed bg-neutral-100 text-neutral-400'
                          : isDirectFriend
                            ? 'bg-sky-50 hover:bg-sky-600 hover:text-white text-sky-800 border border-sky-300 cursor-pointer'
                            : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-600 border border-neutral-200 cursor-pointer'
                      }`}
                      title={
                        isDirectBlocked
                          ? 'Calls disabled due to block'
                          : isDirectFriend
                            ? `1-on-1 Video Call with ${directRecipient?.name || 'friend'}`
                            : 'Friends only: Click to connect as friend and video call'
                      }
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Video Call</span>
                    </button>
                  </>
                );
              })()}

              {/* 1-on-1 View Profile Button */}
              {selectedConversation.type !== 'group' && (
                <button
                  id="btn-conv-view-profile"
                  type="button"
                  onClick={() => {
                    const recipient = getDirectRecipient(selectedConversation);
                    onViewUserProfile(recipient.userId || recipient.uid);
                  }}
                  className="w-9 h-9 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 hover:text-black flex items-center justify-center transition-all cursor-pointer"
                  title="View Profile"
                >
                  <User className="w-4 h-4" />
                </button>
              )}

              {/* View Call Logs */}
              <button
                id="btn-conv-call-logs"
                type="button"
                onClick={() => setMainViewMode('call_logs')}
                className="w-9 h-9 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 flex items-center justify-center transition-all cursor-pointer"
                title="View All Sovereign Audio & Video Call Logs"
              >
                <Clock className="w-4 h-4" />
              </button>

              {selectedConversation.type === 'group' && (
                <button
                  type="button"
                  onClick={() => setShowGroupInfo(!showGroupInfo)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                    showGroupInfo ? 'bg-black text-white' : 'bg-neutral-100 text-neutral-800 hover:bg-neutral-200'
                  }`}
                  title="Group Info, Members & Admin Controls"
                >
                  <Users className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {chatBlockNotice && (
            <div className="mx-4 mt-3 px-3.5 py-2.5 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs font-medium flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{chatBlockNotice}</span>
              </div>
              <button
                type="button"
                onClick={() => setChatBlockNotice(null)}
                className="p-0.5 text-red-500 hover:text-red-700 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Main Area: Message Feed + Optional Group Members Drawer */}
          <div className="flex-1 flex overflow-hidden">
            {/* Messages Feed */}
            <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4 bg-neutral-50/40">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-neutral-400 text-center py-10 space-y-2">
                  <ShieldCheck className="w-8 h-8 text-emerald-600" />
                  <p className="text-xs font-semibold text-black">Channel Established</p>
                  <p className="text-[11px] text-neutral-400 max-w-xs">
                    Message 1-on-1 or up to 20 people in group rooms. Audio &amp; video calls are 1-on-1 (one person at a time).
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isMe = msg.senderId === currentUser?.uid;
                  const isSystem = msg.senderId === 'system';
                  const reactions = messageReactions[msg.id] || {};

                  if (isSystem) {
                    return (
                      <div key={msg.id} className="w-full flex justify-center py-1">
                        <div className="px-3 py-1 rounded-full bg-neutral-200/70 border border-neutral-300/60 text-[11px] text-neutral-700 font-medium shadow-2xs">
                          {msg.text}
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={msg.id}
                      className={`flex items-end gap-2.5 group relative ${isMe ? 'justify-end' : 'justify-start'}`}
                    >
                      {!isMe && (
                        <div
                          onClick={() => onViewUserProfile(msg.senderHandle || msg.senderId)}
                          className="cursor-pointer shrink-0"
                        >
                          {msg.senderAvatarUrl ? (
                            <img
                              src={msg.senderAvatarUrl}
                              alt={msg.senderName}
                              className="w-7 h-7 rounded-full object-cover border border-neutral-200"
                            />
                          ) : (
                            <div className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center text-[10px] font-serif-lux">
                              {msg.senderName ? msg.senderName.charAt(0).toUpperCase() : 'U'}
                            </div>
                          )}
                        </div>
                      )}

                      <div className={`max-w-[78%] sm:max-w-md ${isMe ? 'items-end' : 'items-start'} flex flex-col relative`}>
                        {!isMe && selectedConversation.type === 'group' && (
                          <span className="text-[10px] font-medium text-neutral-500 mb-1 ml-1">
                            {msg.senderName} <span className="font-mono text-neutral-400">@{msg.senderHandle}</span>
                          </span>
                        )}

                        {/* Message Bubble */}
                        <div
                          className={`relative px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-2xs ${
                            isMe
                              ? 'bg-black text-white rounded-br-xs'
                              : 'bg-white text-neutral-900 border border-neutral-200/80 rounded-bl-xs'
                          }`}
                        >
                          <p className="whitespace-pre-wrap break-words">{msg.text}</p>

                          {/* Quick Reaction Button on Hover */}
                          <button
                            type="button"
                            onClick={() => setActiveReactionMsgId(activeReactionMsgId === msg.id ? null : msg.id)}
                            className="absolute -top-3 right-0 opacity-0 group-hover:opacity-100 p-1 rounded-full bg-white border border-neutral-200 shadow-md text-neutral-600 hover:text-black cursor-pointer transition-opacity z-10"
                            title="React"
                          >
                            <SmilePlus className="w-3.5 h-3.5" />
                          </button>

                          {/* Reaction Picker Popover */}
                          {activeReactionMsgId === msg.id && (
                            <div className="absolute -top-10 right-0 bg-white border border-neutral-200 rounded-full px-2 py-1 shadow-xl flex items-center gap-1.5 z-20 animate-in fade-in zoom-in-95">
                              {EMOJI_REACTIONS.map((em) => (
                                <button
                                  key={em}
                                  type="button"
                                  onClick={() => handleReactToMessage(msg.id, em)}
                                  className="text-base hover:scale-125 transition-transform cursor-pointer"
                                >
                                  {em}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Reaction Badges below message */}
                        {Object.keys(reactions).length > 0 && (
                          <div className="flex items-center gap-1 mt-1 px-1">
                            {Object.entries(reactions).map(([em, count]) => (
                              <span
                                key={em}
                                className="px-1.5 py-0.5 rounded-full bg-neutral-100 border border-neutral-200 text-[10px] flex items-center gap-1 shadow-2xs font-medium"
                              >
                                <span>{em}</span>
                                <span>{count}</span>
                              </span>
                            ))}
                          </div>
                        )}

                        <span className="text-[9px] font-mono text-neutral-400 mt-1 px-1">
                          {msg.createdAt?.toDate ? new Date(msg.createdAt.toDate()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'just now'}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Group Members & Admin Controls Drawer */}
            <AnimatePresence>
              {showGroupInfo && selectedConversation.type === 'group' && (
                <motion.div
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 310, opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  className="h-full bg-white border-l border-neutral-200 flex flex-col z-20 shrink-0 shadow-lg"
                >
                  {/* Drawer Header */}
                  <div className="p-3.5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
                    <div className="flex items-center gap-2 min-w-0">
                      <Users className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-xs font-bold text-black block truncate">Room Settings</span>
                        <span className="text-[10px] font-mono text-neutral-500">
                          {selectedConversation.participantIds.length} / {MAX_GROUP_MEMBERS} Members
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowGroupInfo(false)}
                      className="p-1 rounded-lg hover:bg-neutral-200 text-neutral-500 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Members List */}
                  <div className="flex-1 overflow-y-auto p-2 space-y-1 divide-y divide-neutral-100">
                    {(Object.values(selectedConversation.participants) as ConversationParticipant[]).map((p) => {
                      const isMe = p.uid === activeUid;
                      const isCreator = p.uid === selectedConversation.createdBy;

                      return (
                        <div key={p.uid} className="pt-2.5 pb-2 px-2 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 min-w-0">
                            {p.avatarUrl ? (
                              <img src={p.avatarUrl} alt={p.name} className="w-8 h-8 rounded-full object-cover border border-neutral-200 shrink-0" />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-neutral-900 text-white flex items-center justify-center text-xs font-serif shrink-0">
                                {p.name.charAt(0)}
                              </div>
                            )}
                            <div className="min-w-0">
                              <div className="flex items-center gap-1">
                                <span className="text-xs font-bold text-black truncate">
                                  {p.name} {isMe && '(You)'}
                                </span>
                                {isCreator && (
                                  <span className="px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800 text-[9px] font-bold flex items-center gap-0.5 shrink-0 border border-amber-200" title="Room Creator / Host">
                                    <Crown className="w-2.5 h-2.5 text-amber-600" />
                                    <span>Host</span>
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] font-mono text-neutral-400 block truncate">@{p.userId}</span>
                            </div>
                          </div>

                          {/* Member actions */}
                          <div className="flex items-center gap-1 shrink-0">
                            {!isMe && (() => {
                              const isMemberBlocked = isPeerBlocked(p.uid, p.userId);
                              if (isMemberBlocked) {
                                return (
                                  <span className="px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 text-[9px] font-semibold">
                                    Blocked
                                  </span>
                                );
                              }
                              const isMemberFriend = isPeerFriend(p.uid, p.userId);
                              return (
                                <>
                                  <button
                                    type="button"
                                    disabled={!isMemberFriend}
                                    onClick={() => isMemberFriend && onOpenVoiceCall(p, false)}
                                    className={`p-1 rounded-full ${
                                      isMemberFriend
                                        ? 'hover:bg-neutral-100 text-neutral-600 hover:text-black cursor-pointer'
                                        : 'opacity-35 cursor-not-allowed text-neutral-400'
                                    }`}
                                    title={isMemberFriend ? `1-on-1 Voice Call ${p.name}` : 'Friends only: Add as friend to call'}
                                  >
                                    <Phone className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    disabled={!isMemberFriend}
                                    onClick={() => isMemberFriend && onOpenVideoCall(p, false)}
                                    className={`p-1 rounded-full ${
                                      isMemberFriend
                                        ? 'hover:bg-neutral-100 text-neutral-600 hover:text-emerald-600 cursor-pointer'
                                        : 'opacity-35 cursor-not-allowed text-neutral-400'
                                    }`}
                                    title={isMemberFriend ? `1-on-1 Video Call ${p.name}` : 'Friends only: Add as friend to video call'}
                                  >
                                    <Video className="w-3.5 h-3.5" />
                                  </button>
                                </>
                              );
                            })()}

                            {/* Creator Eject Option */}
                            {isSelectedGroupCreator && !isMe && !isCreator && (
                              <button
                                type="button"
                                onClick={() => {
                                  setMemberToEject(p);
                                  setGroupActionError('');
                                }}
                                className="p-1.5 rounded-full hover:bg-red-50 text-neutral-400 hover:text-red-600 transition-colors cursor-pointer"
                                title={`Eject ${p.name} from group`}
                              >
                                <UserMinus className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Drawer Footer: Invite Member + End Group / Leave Group */}
                  <div className="p-3 border-t border-neutral-200 bg-neutral-50 space-y-2">
                    {/* Invite Button */}
                    <button
                      type="button"
                      onClick={() => setShowAddMemberModal(true)}
                      disabled={selectedConversation.participantIds.length >= MAX_GROUP_MEMBERS}
                      className="w-full py-2 rounded-xl bg-black hover:bg-neutral-800 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                    >
                      <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Invite Member ({selectedConversation.participantIds.length}/20)</span>
                    </button>

                    {/* End Group (Creator) or Leave Group (Member) */}
                    {isSelectedGroupCreator ? (
                      <button
                        type="button"
                        onClick={() => {
                          setShowEndGroupConfirm(true);
                          setGroupActionError('');
                        }}
                        className="w-full py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-600" />
                        <span>End &amp; Disband Group Room</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setShowLeaveGroupConfirm(true);
                          setGroupActionError('');
                        }}
                        className="w-full py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <LogOut className="w-3.5 h-3.5 text-neutral-600" />
                        <span>Leave Group Room</span>
                      </button>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Bottom Message Input Bar */}
          <div className="p-3 sm:p-4 border-t border-neutral-200/90 bg-white">
            {(() => {
              const isDirectBlocked = selectedConversation.type === 'direct' && (() => {
                const recipient = getDirectRecipient(selectedConversation);
                return recipient ? isPeerBlocked(recipient.uid, recipient.userId) : false;
              })();

              if (isDirectBlocked) {
                return (
                  <div className="p-3 bg-red-50/90 border border-red-200 rounded-2xl flex items-center justify-center gap-2 text-xs text-red-800 font-medium">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                    <span>You cannot call, video call, or chat with this user because communication is blocked.</span>
                  </div>
                );
              }

              if (isRecordingVoice) {
                return (
                  <div className="flex items-center justify-between p-2 rounded-2xl bg-red-50 border border-red-200 animate-pulse">
                    <div className="flex items-center gap-2 text-red-600 text-xs font-bold pl-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
                      <span>Recording Voice Note... ({recordSeconds}s)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setIsRecordingVoice(false)}
                        className="px-3 py-1 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-200 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleFinishVoiceNote}
                        className="px-4 py-1.5 rounded-xl bg-red-600 text-white text-xs font-bold cursor-pointer hover:bg-red-700 flex items-center gap-1"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Send Voice</span>
                      </button>
                    </div>
                  </div>
                );
              }

              return (
                <form
                  onSubmit={handleSendMessage}
                  className="flex items-center gap-2"
                >
                  {/* Photo upload */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handlePhotoUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2.5 rounded-2xl bg-neutral-100 hover:bg-neutral-200 text-neutral-600 hover:text-black transition-colors cursor-pointer"
                    title="Share Photo"
                  >
                    <ImageIcon className="w-4 h-4" />
                  </button>

                  {/* Voice Note Trigger */}
                  <button
                    type="button"
                    onClick={() => setIsRecordingVoice(true)}
                    className="p-2.5 rounded-2xl bg-neutral-100 hover:bg-neutral-200 text-neutral-600 hover:text-black transition-colors cursor-pointer"
                    title="Record Voice Note"
                  >
                    <Mic className="w-4 h-4" />
                  </button>

                  <input
                    type="text"
                    id="chat-message-input"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder={`Message ${selectedConversation.type === 'group' ? selectedConversation.name : getDirectRecipient(selectedConversation).name}...`}
                    className="flex-1 min-h-[44px] px-4 py-2.5 rounded-2xl bg-neutral-100/80 border border-neutral-200/80 text-xs sm:text-sm text-black placeholder:text-neutral-400 focus:outline-none focus:bg-white focus:ring-1 focus:ring-black transition-all"
                  />

                  <button
                    type="submit"
                    id="send-message-submit-btn"
                    disabled={!inputText.trim() || isSending}
                    className="min-h-[44px] min-w-[44px] px-4 rounded-2xl bg-black hover:bg-neutral-800 disabled:opacity-50 text-white flex items-center justify-center transition-all cursor-pointer shadow-xs"
                    title="Send Message"
                  >
                    {isSending ? (
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </button>
                </form>
              );
            })()}
          </div>
        </div>
      ) : (
        /* Empty Right Slate with Quick 1-on-1 or Group Cards */
        <div className="hidden md:flex flex-1 flex-col overflow-y-auto p-6 sm:p-8 bg-neutral-50/30 text-left">
          <div className="max-w-xl mx-auto w-full space-y-6">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 mx-auto rounded-3xl bg-white shadow-xs flex items-center justify-center text-neutral-800 border border-neutral-200">
                {conversationFilter === 'group' ? (
                  <Users className="w-7 h-7 text-emerald-600" />
                ) : (
                  <MessageSquare className="w-7 h-7" />
                )}
              </div>
              <h3 className="font-serif-lux text-2xl text-black font-light">
                {conversationFilter === 'direct'
                  ? 'Direct 1-on-1 Communications'
                  : conversationFilter === 'group'
                    ? 'Group Room Communications'
                    : 'Direct & Group Communications'}
              </h3>
              <p className="text-xs text-neutral-500">
                {conversationFilter === 'direct'
                  ? 'Message individuals 1-on-1 or place 1-on-1 audio and video calls.'
                  : conversationFilter === 'group'
                    ? 'Open groups you created in Community & Social Feed or start a synchronized group room (up to 20 people).'
                    : 'Message individuals 1-on-1 or up to 20 people together in group rooms. Audio & video calls are strictly 1-on-1 (one person at a time).'}
              </p>
            </div>

            {/* Quick 1-on-1 Contacts Roster (Hidden when strictly in Group filter) */}
            {conversationFilter !== 'group' && (
              <div className="bg-white rounded-3xl border border-neutral-200 p-5 shadow-xs space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
                  <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-neutral-500" />
                    <span>Direct 1-on-1 Quick Start</span>
                  </h4>
                  <button
                    type="button"
                    onClick={() => {
                      setChatModalTab('direct');
                      setShowNewChatModal(true);
                    }}
                    className="text-xs font-semibold text-black hover:underline cursor-pointer"
                  >
                    View All
                  </button>
                </div>

                <div className="divide-y divide-neutral-100">
                  {availableUsers.slice(0, 4).map((user) => {
                    const isFriendUser = isPeerFriend(user.uid, user.userId);
                    return (
                      <div key={user.uid} className="py-2.5 flex items-center justify-between gap-3">
                        <div 
                          onClick={() => onViewUserProfile(user.userId || user.uid)}
                          className="flex items-center gap-3 min-w-0 cursor-pointer group"
                        >
                          {user.avatarUrl ? (
                            <img src={user.avatarUrl} alt={user.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200 group-hover:scale-105 transition-transform" />
                          ) : (
                            <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux group-hover:scale-105 transition-transform">
                              {user.name.charAt(0)}
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-black group-hover:underline truncate">{user.name}</p>
                            <p className="text-[11px] font-mono text-neutral-400 truncate">@{user.userId}</p>
                          </div>
                        </div>

                        {/* Direct 1-on-1 Action Buttons (Chat for all, Calls for friends only) */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleStartDirectChat(user)}
                            className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer shadow-2xs transition-colors"
                            title={`Message ${user.name}`}
                          >
                            <MessageSquare className="w-3 h-3" />
                            <span>Chat</span>
                          </button>

                          <button
                            type="button"
                            disabled={!isFriendUser}
                            onClick={() => isFriendUser && handleStartDirectVoiceCall(user)}
                            className={`p-1.5 rounded-xl transition-colors ${
                              isFriendUser
                                ? 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700 hover:text-black cursor-pointer'
                                : 'bg-neutral-100 text-neutral-300 opacity-50 cursor-not-allowed'
                            }`}
                            title={isFriendUser ? `Call ${user.name}` : 'Friends only: Add as friend to call'}
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            disabled={!isFriendUser}
                            onClick={() => isFriendUser && handleStartDirectVideoCall(user)}
                            className={`p-1.5 rounded-xl transition-colors ${
                              isFriendUser
                                ? 'bg-neutral-100 hover:bg-emerald-50 text-neutral-700 hover:text-emerald-700 cursor-pointer'
                                : 'bg-neutral-100 text-neutral-300 opacity-50 cursor-not-allowed'
                            }`}
                            title={isFriendUser ? `Video Call ${user.name}` : 'Friends only: Add as friend to video call'}
                          >
                            <Video className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Community & Social Feed Groups + Quick Group Room Launcher (Hidden when strictly in Direct filter) */}
            {conversationFilter !== 'direct' && (
              <>
                {conversationFilter === 'group' && (
                  <div className="bg-white rounded-3xl border border-neutral-200 p-5 shadow-xs space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
                      <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider flex items-center gap-1.5">
                        <FolderHeart className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Groups You Have Made ({customGroupsMade.length})</span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => {
                          setChatModalTab('group');
                          setShowNewChatModal(true);
                        }}
                        className="text-xs font-semibold text-black hover:underline cursor-pointer"
                      >
                        Manage / Search
                      </button>
                    </div>
                    {customGroupsMade.length === 0 ? (
                      <p className="text-xs text-neutral-500 py-2">
                        No custom groups created yet in Community &amp; Social Feed. Create a group room below.
                      </p>
                    ) : (
                      <div className="divide-y divide-neutral-100">
                        {customGroupsMade.map((group) => (
                          <div key={group.id} className="py-2.5 flex items-center justify-between gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              {group.avatarUrl ? (
                                <img
                                  src={group.avatarUrl}
                                  alt={group.name}
                                  className="w-9 h-9 rounded-xl object-cover border border-neutral-200 shrink-0"
                                />
                              ) : (
                                <div
                                  className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-white text-xs font-bold shadow-2xs"
                                  style={{ backgroundColor: group.color || '#f59e0b' }}
                                >
                                  {group.name.charAt(0).toUpperCase()}
                                </div>
                              )}
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-black truncate">{group.name}</p>
                                <p className="text-[11px] text-neutral-500 truncate">
                                  {group.memberUids.length} {group.memberUids.length === 1 ? 'member' : 'members'} assigned
                                </p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleOpenCustomGroupChat(group)}
                              className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer shadow-2xs shrink-0 transition-colors"
                            >
                              <MessageSquare className="w-3 h-3 text-emerald-400" />
                              <span>Open Chat</span>
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div className="bg-neutral-900 rounded-3xl p-5 text-white flex items-center justify-between gap-4 shadow-sm">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-emerald-400" />
                      <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                        Group Messaging (Up to 20 People)
                      </h4>
                    </div>
                    <p className="text-xs text-neutral-300">
                      Message up to 20 people at once in a synchronized group chat.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setChatModalTab('group');
                      setShowNewChatModal(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs shrink-0 cursor-pointer transition-colors shadow-xs"
                  >
                    New Group Chat
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ================= MODAL: ISOLATED DIRECT OR GROUP MODAL ================= */}
      {showNewChatModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] flex flex-col"
          >
            {/* Isolated Modal Header — never mixes Direct 1-on-1 and Group Room tabs */}
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3 shrink-0">
              {chatModalTab === 'direct' ? (
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-neutral-100 text-black">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-black">Direct (1-on-1) Chat</h3>
                    <p className="text-[11px] text-neutral-500">Private 1-on-1 message or call</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-black">Group Room (Max 20)</h3>
                    <p className="text-[11px] text-neutral-500">Open a Community &amp; Social Feed group or create one</p>
                  </div>
                </div>
              )}
              <button
                type="button"
                onClick={() => setShowNewChatModal(false)}
                className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* TAB 1: DIRECT 1-ON-1 PICKER (Chat with anyone not blocked; Calls for friends only) */}
            {chatModalTab === 'direct' && (
              <div className="space-y-4 flex-1 flex flex-col overflow-hidden">
                <p className="text-xs text-neutral-500">
                  Message anyone on the platform (unless blocked). Audio &amp; video calls are for friends only.
                </p>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={directUserSearch}
                    onChange={(e) => setDirectUserSearch(e.target.value)}
                    placeholder="Search by name or @handle..."
                    className="w-full pl-8 pr-3 py-2 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
                  />
                </div>

                <div className="flex-1 overflow-y-auto space-y-4 pr-1">
                  {/* 1. FRIENDS */}
                  <div>
                    <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2 px-1">
                      Friends ({friendsList.length})
                    </h4>
                    {friendsList.length === 0 ? (
                      <p className="text-xs text-neutral-400 px-1 italic">No friends added yet.</p>
                    ) : (
                      <div className="border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                        {friendsList
                          .filter((u) => !directUserSearch.trim() || u.name.toLowerCase().includes(directUserSearch.toLowerCase()) || u.userId.toLowerCase().includes(directUserSearch.toLowerCase()))
                          .map((u) => (
                            <div key={u.uid} className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors">
                              <div className="flex items-center gap-2.5 min-w-0">
                                {u.avatarUrl ? (
                                  <img src={u.avatarUrl} alt={u.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200" />
                                ) : (
                                  <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                                    {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                                  </div>
                                )}
                                <div className="min-w-0">
                                  <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                                  <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectChat(u)}
                                  className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer"
                                >
                                  <MessageSquare className="w-3 h-3" />
                                  <span>Chat</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectVoiceCall(u)}
                                  className="p-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 cursor-pointer"
                                  title="Voice Call"
                                >
                                  <Phone className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleStartDirectVideoCall(u)}
                                  className="p-1.5 rounded-xl bg-neutral-100 hover:bg-emerald-50 text-neutral-700 hover:text-emerald-700 cursor-pointer"
                                  title="Video Call"
                                >
                                  <Video className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>

                  {/* 2. PEOPLE THEY FOLLOW */}
                  <div>
                    <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2 px-1">
                      People You Follow ({followingList.length})
                    </h4>
                    {followingList.length === 0 ? (
                      <p className="text-xs text-neutral-400 px-1 italic">Not following anyone yet.</p>
                    ) : (
                      <div className="border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                        {followingList
                          .filter((u) => !directUserSearch.trim() || u.name.toLowerCase().includes(directUserSearch.toLowerCase()) || u.userId.toLowerCase().includes(directUserSearch.toLowerCase()))
                          .map((u) => {
                            const isFriendUser = isPeerFriend(u.uid, u.userId);
                            return (
                              <div key={u.uid} className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors">
                                <div className="flex items-center gap-2.5 min-w-0">
                                  {u.avatarUrl ? (
                                    <img src={u.avatarUrl} alt={u.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200" />
                                  ) : (
                                    <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                                      {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                                    </div>
                                  )}
                                  <div className="min-w-0">
                                    <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                                    <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-1.5 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => handleStartDirectChat(u)}
                                    className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer"
                                  >
                                    <MessageSquare className="w-3 h-3" />
                                    <span>Chat</span>
                                  </button>
                                  {isFriendUser && (
                                    <>
                                      <button
                                        type="button"
                                        onClick={() => handleStartDirectVoiceCall(u)}
                                        className="p-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 cursor-pointer"
                                        title="Voice Call"
                                      >
                                        <Phone className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleStartDirectVideoCall(u)}
                                        className="p-1.5 rounded-xl bg-neutral-100 hover:bg-emerald-50 text-neutral-700 hover:text-emerald-700 cursor-pointer"
                                        title="Video Call"
                                      >
                                        <Video className="w-3.5 h-3.5" />
                                      </button>
                                    </>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    )}
                  </div>

                  {/* 3. ALL OTHER PLATFORM MEMBERS (Chat permitted unless blocked) */}
                  {(() => {
                    const knownUids = new Set([
                      ...friendsList.map((u) => u.uid),
                      ...followingList.map((u) => u.uid),
                    ]);
                    const otherPlatformUsers = availableUsers
                      .filter((u) => !knownUids.has(u.uid) && !isPeerBlocked(u.uid, u.userId))
                      .filter(
                        (u) =>
                          !directUserSearch.trim() ||
                          u.name.toLowerCase().includes(directUserSearch.toLowerCase()) ||
                          u.userId.toLowerCase().includes(directUserSearch.toLowerCase())
                      );
                    if (otherPlatformUsers.length === 0) return null;

                    return (
                      <div>
                        <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2 px-1">
                          Platform Members ({otherPlatformUsers.length})
                        </h4>
                        <div className="border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                          {otherPlatformUsers.map((u) => (
                            <div key={u.uid} className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors">
                              <div className="flex items-center gap-2.5 min-w-0">
                                {u.avatarUrl ? (
                                  <img src={u.avatarUrl} alt={u.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200" />
                                ) : (
                                  <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                                    {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                                  </div>
                                )}
                                <div className="min-w-0">
                                  <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                                  <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleStartDirectChat(u)}
                                className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-medium flex items-center gap-1 cursor-pointer shrink-0"
                              >
                                <MessageSquare className="w-3 h-3" />
                                <span>Chat</span>
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            )}

            {/* TAB 2: GROUP ROOMS (COMMUNITY GROUPS + CREATE NEW GROUP) */}
            {chatModalTab === 'group' && (
              <div className="flex-1 overflow-y-auto pr-1 space-y-5">
                {groupCreateError && (
                  <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs flex items-center gap-2">
                    <Info className="w-4 h-4 shrink-0" />
                    <span>{groupCreateError}</span>
                  </div>
                )}

                {/* Community & Social Feed Custom Groups */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h4 className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider flex items-center gap-1.5">
                      <FolderHeart className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Groups You Have Made ({customGroupsMade.length})</span>
                    </h4>
                  </div>

                  {customGroupsMade.length > 0 && (
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={groupListSearch}
                        onChange={(e) => setGroupListSearch(e.target.value)}
                        placeholder="Find a group you created..."
                        className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
                      />
                    </div>
                  )}

                  {customGroupsMade.length === 0 ? (
                    <p className="text-xs text-neutral-400 px-1 italic">
                      No custom groups found from Community &amp; Social Feed yet. Create one below.
                    </p>
                  ) : (
                    <div className="max-h-44 overflow-y-auto border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                      {customGroupsMade
                        .filter(
                          (g) =>
                            !groupListSearch.trim() ||
                            g.name.toLowerCase().includes(groupListSearch.toLowerCase()) ||
                            (g.description && g.description.toLowerCase().includes(groupListSearch.toLowerCase()))
                        )
                        .map((group) => (
                          <div
                            key={group.id}
                            className="p-2.5 rounded-xl flex items-center justify-between gap-2 hover:bg-neutral-50 transition-colors"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              {group.avatarUrl ? (
                                <img
                                  src={group.avatarUrl}
                                  alt={group.name}
                                  className="w-9 h-9 rounded-xl object-cover border border-neutral-200 shrink-0"
                                />
                              ) : (
                                <div
                                  className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border border-black/10 shadow-2xs text-white text-xs font-bold"
                                  style={{ backgroundColor: group.color || '#f59e0b' }}
                                >
                                  {group.name.charAt(0).toUpperCase()}
                                </div>
                              )}
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <p className="text-xs font-semibold text-black truncate">{group.name}</p>
                                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-neutral-100 text-neutral-600 font-medium shrink-0">
                                    {group.groupType === 'general' ? 'General Group' : 'Friend Group'}
                                  </span>
                                </div>
                                <p className="text-[10px] text-neutral-500 truncate">
                                  {group.memberUids.length} {group.memberUids.length === 1 ? 'member' : 'members'} assigned
                                </p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleOpenCustomGroupChat(group)}
                              disabled={isCreatingGroup}
                              className="px-3 py-1.5 rounded-xl bg-black hover:bg-neutral-800 disabled:opacity-50 text-white text-[11px] font-semibold flex items-center gap-1 cursor-pointer shrink-0 transition-colors"
                            >
                              <MessageSquare className="w-3 h-3 text-emerald-400" />
                              <span>Open Chat</span>
                            </button>
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                {/* Create New Group Room Form */}
                <form onSubmit={handleCreateGroupSubmit} className="space-y-3.5 pt-3 border-t border-neutral-100">
                  <h4 className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider">
                    Or Create New Group Room
                  </h4>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Group Room Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Zurich Freeport Syndicate / Sovereign Alpha"
                      value={groupNameInput}
                      onChange={(e) => setGroupNameInput(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs sm:text-sm focus:outline-none focus:border-black"
                      required
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-semibold text-neutral-700">
                        Select Members ({selectedGroupMemberUids.size}/{MAX_GROUP_MEMBERS - 1} Selected)
                      </label>
                    </div>

                    <div className="relative mb-2">
                      <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={groupMemberSearch}
                        onChange={(e) => setGroupMemberSearch(e.target.value)}
                        placeholder="Search people to add..."
                        className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
                      />
                    </div>

                    <div className="max-h-40 overflow-y-auto border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
                      {availableUsers
                        .filter((u) => !isPeerBlocked(u.uid, u.userId))
                        .filter((u) => u.name.toLowerCase().includes(groupMemberSearch.toLowerCase()) || u.userId.toLowerCase().includes(groupMemberSearch.toLowerCase()))
                        .map((u) => {
                          const isSelected = selectedGroupMemberUids.has(u.uid);
                          return (
                            <button
                              key={u.uid}
                              type="button"
                              onClick={() => {
                                setSelectedGroupMemberUids((prev) => {
                                  const next = new Set(prev);
                                  if (next.has(u.uid)) next.delete(u.uid);
                                  else {
                                    if (next.size >= MAX_GROUP_MEMBERS - 1) {
                                      setGroupCreateError(`Maximum ${MAX_GROUP_MEMBERS} members allowed`);
                                      return next;
                                    }
                                    next.add(u.uid);
                                  }
                                  return next;
                                });
                              }}
                              className={`w-full p-2 rounded-xl flex items-center justify-between text-left transition-colors cursor-pointer ${
                                isSelected ? 'bg-neutral-100 font-medium' : 'hover:bg-neutral-50'
                              }`}
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                {u.avatarUrl ? (
                                  <img src={u.avatarUrl} alt={u.name} className="w-7 h-7 rounded-full object-cover" />
                                ) : (
                                  <div className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                                    {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                                  </div>
                                )}
                                <div className="min-w-0">
                                  <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                                  <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                                </div>
                              </div>

                              <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                                isSelected ? 'bg-black text-white border-black' : 'border-neutral-300'
                              }`}>
                                {isSelected && <Check className="w-3 h-3" />}
                              </div>
                            </button>
                          );
                        })}
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowNewChatModal(false)}
                      className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isCreatingGroup}
                      className="min-h-[38px] px-5 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer shadow-xs disabled:opacity-50 flex items-center gap-1.5"
                    >
                      {isCreatingGroup ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <>
                          <Users className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Start Group Room</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            )}
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: ADD MEMBER TO ACTIVE GROUP ================= */}
      {showAddMemberModal && selectedConversation?.type === 'group' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <div>
                <h3 className="font-serif-lux text-xl font-normal text-black">
                  Invite Member to Room
                </h3>
                <p className="text-xs text-neutral-500">
                  {selectedConversation.participantIds.length} / {MAX_GROUP_MEMBERS} active participants
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddMemberModal(false)}
                className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={addMemberSearch}
                onChange={(e) => setAddMemberSearch(e.target.value)}
                placeholder="Search community member..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
              />
            </div>

            <div className="max-h-60 overflow-y-auto border border-neutral-200 rounded-2xl divide-y divide-neutral-100 p-1">
              {availableUsers
                .filter((u) => !selectedConversation.participantIds.includes(u.uid))
                .filter((u) => u.name.toLowerCase().includes(addMemberSearch.toLowerCase()) || u.userId.toLowerCase().includes(addMemberSearch.toLowerCase()))
                .map((u) => (
                  <div
                    key={u.uid}
                    className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {u.avatarUrl ? (
                        <img
                          src={u.avatarUrl}
                          alt={u.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                          {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                        <p className="text-[10px] font-mono text-neutral-400">@{u.userId}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={selectedConversation.participantIds.length >= MAX_GROUP_MEMBERS}
                      onClick={() => handleAddMemberToActiveGroup(u)}
                      className="min-h-[32px] px-3.5 py-1 rounded-full bg-black hover:bg-neutral-800 disabled:opacity-50 text-white text-xs font-medium cursor-pointer shadow-2xs"
                    >
                      Add
                    </button>
                  </div>
                ))}
            </div>
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: EJECT MEMBER CONFIRMATION (CREATOR ONLY) ================= */}
      {memberToEject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-left border border-neutral-200"
          >
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
              <UserMinus className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif-lux text-xl text-black font-normal">
                Eject Member from Group?
              </h3>
              <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                Are you sure you want to eject <strong>{memberToEject.name}</strong> (@{memberToEject.userId}) from <strong>{selectedConversation?.name}</strong>? They will be removed from this text chat and disconnected from all active conference calls.
              </p>
            </div>

            {groupActionError && (
              <div className="p-2.5 rounded-xl bg-red-50 text-red-700 text-xs flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{groupActionError}</span>
              </div>
            )}

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setMemberToEject(null)}
                disabled={isEjecting}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmEjectMember}
                disabled={isEjecting}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                {isEjecting ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <UserMinus className="w-3.5 h-3.5" />
                    <span>Eject Member</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: END & DISBAND GROUP ROOM (CREATOR ONLY) ================= */}
      {showEndGroupConfirm && selectedConversation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-left border border-neutral-200"
          >
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif-lux text-xl text-black font-normal">
                End &amp; Disband Group Room?
              </h3>
              <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                As the room creator, ending <strong>"{selectedConversation.name}"</strong> will permanently delete this group room and terminate all active text threads and audio/video conference calls for all <strong>{selectedConversation.participantIds.length} members</strong>. This action cannot be undone.
              </p>
            </div>

            {groupActionError && (
              <div className="p-2.5 rounded-xl bg-red-50 text-red-700 text-xs flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{groupActionError}</span>
              </div>
            )}

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowEndGroupConfirm(false)}
                disabled={isEndingGroup}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmEndGroup}
                disabled={isEndingGroup}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                {isEndingGroup ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>End Group Room</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* ================= MODAL: LEAVE GROUP ROOM (MEMBER) ================= */}
      {showLeaveGroupConfirm && selectedConversation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-left border border-neutral-200"
          >
            <div className="w-12 h-12 rounded-2xl bg-neutral-100 text-neutral-700 flex items-center justify-center">
              <LogOut className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif-lux text-xl text-black font-normal">
                Leave Group Room?
              </h3>
              <p className="text-xs text-neutral-500 mt-1 leading-relaxed">
                Are you sure you want to leave <strong>"{selectedConversation.name}"</strong>? You will no longer receive messages or be able to join conference calls in this group.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowLeaveGroupConfirm(false)}
                disabled={isLeavingGroup}
                className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-600 hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmLeaveGroup}
                disabled={isLeavingGroup}
                className="px-5 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-bold cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                {isLeavingGroup ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Leave Room</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}
      {/* ================= MODAL: 1-ON-1 AUDIO / VIDEO CALL PICKER ================= */}
      {callPickerMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 max-h-[85vh] flex flex-col"
          >
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${callPickerMode === 'video' ? 'bg-emerald-50 text-emerald-700' : 'bg-neutral-100 text-black'}`}>
                  {callPickerMode === 'video' ? <Video className="w-4 h-4" /> : <Phone className="w-4 h-4" />}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-black">
                    {callPickerMode === 'video' ? '1-on-1 Video Call' : '1-on-1 Audio Call'}
                  </h3>
                  <p className="text-[11px] text-neutral-500">
                    Select a friend to call (audio &amp; video calls are friends only).
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setCallPickerMode(null)}
                className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={callPickerSearch}
                onChange={(e) => setCallPickerSearch(e.target.value)}
                placeholder="Search friend by name or @handle..."
                className="w-full pl-8 pr-3 py-2 rounded-xl bg-neutral-100 border border-neutral-200 text-xs focus:outline-none focus:bg-white"
              />
            </div>

            {/* Friends List Only (Prioritize friends in active group room) */}
            <div className="flex-1 overflow-y-auto divide-y divide-neutral-100 border border-neutral-200 rounded-2xl p-1">
              {(() => {
                const groupPeers: UserPublicProfile[] =
                  selectedConversation?.type === 'group'
                    ? (Object.values(selectedConversation.participants) as ConversationParticipant[])
                        .filter((p) => p.uid !== activeUid && !isPeerBlocked(p.uid, p.userId) && isPeerFriend(p.uid, p.userId))
                        .map((p) => ({
                          uid: p.uid,
                          userId: p.userId,
                          name: p.name,
                          avatarUrl: p.avatarUrl,
                          role: 'user',
                        }))
                    : [];

                const seen = new Set<string>(groupPeers.map((u) => u.uid));
                const baseCombined = [
                  ...groupPeers,
                  ...friendsList.filter((u) => u.uid !== activeUid && !seen.has(u.uid) && !isPeerBlocked(u.uid, u.userId)),
                ];
                if (viewerIsAdmin) {
                  baseCombined.forEach((u) => seen.add(u.uid));
                  availableUsers.forEach((u) => {
                    if (u.uid !== activeUid && !seen.has(u.uid)) {
                      seen.add(u.uid);
                      baseCombined.push(u);
                    }
                  });
                }
                const combinedList = baseCombined.filter(
                  (u) =>
                    !callPickerSearch.trim() ||
                    u.name.toLowerCase().includes(callPickerSearch.toLowerCase()) ||
                    u.userId.toLowerCase().includes(callPickerSearch.toLowerCase())
                );

                if (combinedList.length === 0) {
                  return (
                    <div className="p-6 text-center text-xs text-neutral-500 space-y-1">
                      <p className="font-medium text-neutral-700">No friends available to call.</p>
                      <p className="text-[11px] text-neutral-400">
                        Audio and video calls are only available with your friends.
                      </p>
                    </div>
                  );
                }

                return combinedList.map((u) => {
                  const isBlocked = isPeerBlocked(u.uid, u.userId);
                  return (
                    <div
                      key={u.uid}
                      className="p-2.5 rounded-xl flex items-center justify-between hover:bg-neutral-50 transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {u.avatarUrl ? (
                          <img src={u.avatarUrl} alt={u.name} className="w-9 h-9 rounded-full object-cover border border-neutral-200 shrink-0" />
                        ) : (
                          <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux shrink-0">
                            {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="text-xs font-semibold text-black truncate">{u.name}</p>
                            {seen.has(u.uid) && (
                              <span className="px-1.5 py-0.2 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[9px] font-medium shrink-0">
                                In Room
                              </span>
                            )}
                            {isBlocked && (
                              <span className="px-1.5 py-0.2 rounded-full bg-red-50 text-red-700 border border-red-200 text-[9px] font-semibold shrink-0">
                                Blocked
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] font-mono text-neutral-400 truncate">@{u.userId}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {callPickerMode === 'voice' ? (
                          <button
                            type="button"
                            disabled={isBlocked}
                            onClick={() => {
                              if (isBlocked) return;
                              setCallPickerMode(null);
                              onOpenVoiceCall({ uid: u.uid, userId: u.userId, name: u.name, avatarUrl: u.avatarUrl }, false);
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-colors ${
                              isBlocked
                                ? 'opacity-40 cursor-not-allowed bg-neutral-100 text-neutral-400'
                                : 'bg-black text-white hover:bg-neutral-800 cursor-pointer'
                            }`}
                            title={isBlocked ? 'Calls disabled (Blocked)' : `1-on-1 Audio Call ${u.name}`}
                          >
                            <Phone className="w-3 h-3" />
                            <span>Audio Call</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            disabled={isBlocked}
                            onClick={() => {
                              if (isBlocked) return;
                              setCallPickerMode(null);
                              onOpenVideoCall({ uid: u.uid, userId: u.userId, name: u.name, avatarUrl: u.avatarUrl }, false);
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition-colors ${
                              isBlocked
                                ? 'opacity-40 cursor-not-allowed bg-neutral-100 text-neutral-400 border border-neutral-200'
                                : 'bg-emerald-600 text-white hover:bg-emerald-700 cursor-pointer'
                            }`}
                            title={isBlocked ? 'Calls disabled (Blocked)' : `1-on-1 Video Call ${u.name}`}
                          >
                            <Video className="w-3 h-3" />
                            <span>Video Call</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </motion.div>
        </div>
      )}

      {/* Send / Accept Friend Request Prompt for Audio / Video Calls */}
      <ConfirmModal
        isOpen={Boolean(pendingCallFriendPrompt)}
        onClose={() => setPendingCallFriendPrompt(null)}
        onConfirm={async () => {
          if (!currentUser || !pendingCallFriendPrompt) return;
          const target = pendingCallFriendPrompt.recipient;
          if (pendingCallFriendPrompt.action === 'accept') {
            await acceptFriendRequest(currentUser, target);
            addToast({
              type: 'success',
              title: 'Friends Connected',
              message: `You and ${target.name} are now mutual friends! Audio and video calls are unlocked.`,
            });
          } else {
            const outcome = await sendFriendRequest(currentUser, target);
            if (outcome === 'accepted') {
              addToast({
                type: 'success',
                title: 'Friends Connected',
                message: `You and ${target.name} are now mutual friends! Audio and video calls are unlocked.`,
              });
            } else {
              addToast({
                type: 'info',
                title: 'Friend Request Sent',
                message: `Sent friend request to ${target.name}. Calls unlock once both sides accept.`,
              });
            }
          }
          loadDirectoryData();
          setPendingCallFriendPrompt(null);
        }}
        title={
          pendingCallFriendPrompt?.action === 'accept'
            ? 'Accept Friend Request to Call'
            : 'Send Friend Request to Call'
        }
        message={
          pendingCallFriendPrompt
            ? pendingCallFriendPrompt.action === 'accept'
              ? `${pendingCallFriendPrompt.recipient.name} sent you a friend request. Accept their request to become mutual friends and unlock ${pendingCallFriendPrompt.mode === 'video' ? 'video' : 'audio'} calls?`
              : `${pendingCallFriendPrompt.mode === 'video' ? 'Video' : 'Audio'} calls require both sides to add each other as friends. Send a friend request to ${pendingCallFriendPrompt.recipient.name}?`
            : ''
        }
        confirmText={
          pendingCallFriendPrompt?.action === 'accept'
            ? 'Accept Friend Request'
            : 'Send Friend Request'
        }
        cancelText="Cancel"
        type="info"
      />
    </div>
  );
};
