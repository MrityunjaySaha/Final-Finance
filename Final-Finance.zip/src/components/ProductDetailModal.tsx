import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Coins,
  Check,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Wallet,
  CreditCard,
  Building2,
} from 'lucide-react';
import { SearchableProduct } from '../data/searchCatalog';
import { AuthSession } from '../types/auth';
import { ConfirmModal } from './common/ConfirmModal';
import { useApp } from '../context/AppContext';
import {
  recordLedgerTransaction,
  normalizeLedgerItem,
} from '../utils/universalLedgerBridge';
import { getStoredUserWallets } from '../data/defaultWallets';
import { applyCurrencyWalletDelta } from '../utils/walletBalanceUpdater';
import { loadVerifiedPaymentSources, VerifiedPaymentSources } from '../utils/paymentMethodsBridge';
import { executeStripeCharge } from '../services/stripeClientService';
import {
  calculateWalletPurchaseFee,
  formatInsufficientCurrencyError,
} from '../utils/transactionFees';
import { TransactionMode } from '../types/ledger';
import { checkRestrictedMarketplaceItem } from '../data/restrictedItemsPolicy';

interface ProductDetailModalProps {
  product: SearchableProduct | null;
  currentUser?: AuthSession | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (
    actionType: 'barter' | 'stake' | 'swap' | 'wire' | 'deposit',
    product: SearchableProduct
  ) => void;
}

interface CheckoutPaymentOption {
  id: string;
  kind: 'wallet_fiat' | 'wallet_stable' | 'wallet_crypto' | 'wallet_final' | 'stripe_card' | 'stripe_bank' | 'privy_crypto';
  label: string;
  sublabel: string;
  symbol: string;
  name: string;
  availableUnits: number;
  unitPriceUSD: number;
  mode: TransactionMode;
  stripePaymentMethodId?: string;
  network?: string;
  feeType: 'none' | 'stripe_wallet' | 'privy_wallet';
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  currentUser,
  isOpen,
  onClose,
}) => {
  const { addToast, addNotification } = useApp();
  const [selectedLotSize, setSelectedLotSize] = useState<number>(1);
  const [selectedOptionId, setSelectedOptionId] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [actionConfirmed, setActionConfirmed] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [verifiedSources, setVerifiedSources] = useState<VerifiedPaymentSources | null>(null);
  const [walletVersion, setWalletVersion] = useState(0);

  const userId = currentUser?.uid || currentUser?.id || 'guest';

  useEffect(() => {
    if (!isOpen) return;
    let active = true;
    setErrorMsg(null);
    loadVerifiedPaymentSources(currentUser || null)
      .then((sources) => {
        if (active) setVerifiedSources(sources);
      })
      .catch(() => {
        // non-fatal
      });

    const handleWalletRefresh = () => setWalletVersion((v) => v + 1);
    window.addEventListener('final_finance_wallets_updated', handleWalletRefresh);
    return () => {
      active = false;
      window.removeEventListener('final_finance_wallets_updated', handleWalletRefresh);
    };
  }, [isOpen, currentUser]);

  const paymentOptions = useMemo<CheckoutPaymentOption[]>(() => {
    const wallet = getStoredUserWallets(userId);
    const list: CheckoutPaymentOption[] = [];

    (wallet.fiatCurrencies || []).forEach((f) => {
      list.push({
        id: `fiat-${f.code}`,
        kind: 'wallet_fiat',
        label: `${f.code} — ${f.name}`,
        sublabel: `Fiat Wallet (${f.balance.toLocaleString()} ${f.code} · Stripe Wallet Fee)`,
        symbol: f.code.toUpperCase(),
        name: f.name,
        availableUnits: f.balance || 0,
        unitPriceUSD: f.exchangeRateToUSD || 1,
        mode: 'fiat',
        feeType: 'stripe_wallet',
      });
    });

    (wallet.stableCoins || []).forEach((s) => {
      list.push({
        id: `stable-${s.symbol}`,
        kind: 'wallet_stable',
        label: `${s.symbol} — ${s.name}`,
        sublabel: `Stablecoin (${s.balance.toLocaleString()} ${s.symbol} · Privy Wallet Fee)`,
        symbol: s.symbol.toUpperCase(),
        name: s.name,
        availableUnits: s.balance || 0,
        unitPriceUSD: s.unitPriceUSD || 1,
        mode: 'stable_coin',
        network: s.network,
        feeType: 'privy_wallet',
      });
    });

    (wallet.cryptoCurrencies || []).forEach((c) => {
      list.push({
        id: `crypto-${c.symbol}`,
        kind: 'wallet_crypto',
        label: `${c.symbol} — ${c.name}`,
        sublabel: `Crypto Wallet (${c.balance.toLocaleString()} ${c.symbol} · Privy Wallet Fee)`,
        symbol: c.symbol.toUpperCase(),
        name: c.name,
        availableUnits: c.balance || 0,
        unitPriceUSD: c.unitPriceUSD || 1,
        mode: 'crypto',
        network: c.network,
        feeType: 'privy_wallet',
      });
    });

    (wallet.finalCoins || []).forEach((fc) => {
      list.push({
        id: `final-${fc.symbol}`,
        kind: 'wallet_final',
        label: `${fc.symbol} — ${fc.name}`,
        sublabel: `Final Coin (${fc.balance.toLocaleString()} ${fc.symbol})`,
        symbol: fc.symbol.toUpperCase(),
        name: fc.name,
        availableUnits: fc.balance || 0,
        unitPriceUSD: fc.symbol === 'AFNL' ? 1 : fc.unitPriceUSD || 1,
        mode: 'final_coin',
        feeType: 'none',
      });
    });

    (verifiedSources?.cards || []).forEach((card) => {
      list.push({
        id: `card-${card.id}`,
        kind: 'stripe_card',
        label: `${(card.brand || 'Card').toUpperCase()} •••• ${card.last4 || '0000'}`,
        sublabel: 'Stripe Wallet Card (2.9% + $0.30 fee)',
        symbol: 'USD',
        name: 'Stripe Payment Card',
        availableUnits: Number.POSITIVE_INFINITY,
        unitPriceUSD: 1,
        mode: 'fiat',
        stripePaymentMethodId: card.id,
        feeType: 'stripe_wallet',
      });
    });

    (verifiedSources?.banks || []).forEach((bank) => {
      list.push({
        id: `bank-${bank.id}`,
        kind: 'stripe_bank',
        label: `${bank.bankName || 'Verified Bank'} •••• ${bank.last4 || '0000'}`,
        sublabel: 'Stripe ACH Bank ($0.00 fee)',
        symbol: 'USD',
        name: bank.bankName || 'Stripe ACH Bank',
        availableUnits: Number.POSITIVE_INFINITY,
        unitPriceUSD: 1,
        mode: 'fiat',
        stripePaymentMethodId: bank.id,
        feeType: 'none',
      });
    });

    (verifiedSources?.cryptoWallets || []).forEach((cw) => {
      list.push({
        id: `privy-${cw.address}`,
        kind: 'privy_crypto',
        label: `${cw.label} (${cw.address.slice(0, 6)}...${cw.address.slice(-4)})`,
        sublabel: `Privy Wallet (${cw.network || 'Ethereum'})`,
        symbol: 'ETH',
        name: `Privy ${cw.label}`,
        availableUnits: Number(verifiedSources?.onChainBalances?.nativeToken?.balanceFormatted || 0),
        unitPriceUSD: 2820,
        mode: 'crypto',
        network: cw.network,
        feeType: 'privy_wallet',
      });
    });

    return list;
  }, [userId, verifiedSources, walletVersion]);

  useEffect(() => {
    if (paymentOptions.length === 0) return;
    if (!selectedOptionId || !paymentOptions.some((o) => o.id === selectedOptionId)) {
      const firstFunded =
        paymentOptions.find((o) => o.availableUnits > 0 && Number.isFinite(o.availableUnits)) ||
        paymentOptions[0];
      setSelectedOptionId(firstFunded.id);
    }
  }, [paymentOptions, selectedOptionId]);

  if (!isOpen || !product) return null;

  const numericPrice = parseFloat(product.price.replace(/[^0-9.]/g, '')) || 1000;
  const subtotalUSD = Math.round(numericPrice * selectedLotSize * 100) / 100;
  const activeOption = paymentOptions.find((o) => o.id === selectedOptionId) || paymentOptions[0];

  const walletFee = calculateWalletPurchaseFee({
    category: activeOption?.mode || 'final_coin',
    subtotalUSD,
    symbol: activeOption?.symbol,
    network: activeOption?.network,
    isBankAch: activeOption?.kind === 'stripe_bank',
  });

  const feeUSD = walletFee.feeUSD;

  const totalUSD = Math.round((subtotalUSD + feeUSD) * 100) / 100;
  const requiredUnits =
    activeOption && activeOption.unitPriceUSD > 0
      ? Number((totalUSD / activeOption.unitPriceUSD).toFixed(activeOption.mode === 'crypto' ? 6 : 2))
      : totalUSD;

  const handleAction = () => {
    setErrorMsg(null);
    const restrictionCheck = checkRestrictedMarketplaceItem({
      title: product.name,
      description: product.description,
      category: product.category,
    });
    if (restrictionCheck.restricted) {
      const msg =
        restrictionCheck.reason ||
        'This item is prohibited under our U.S. & Oregon marketplace restriction policy.';
      setErrorMsg(msg);
      addToast({
        title: 'Restricted Item Prohibited',
        message: msg,
        type: 'error',
      });
      return;
    }
    if (!activeOption) {
      setErrorMsg('Please select a payment method or currency.');
      return;
    }

    if (
      activeOption.kind === 'wallet_fiat' ||
      activeOption.kind === 'wallet_stable' ||
      activeOption.kind === 'wallet_crypto' ||
      activeOption.kind === 'wallet_final' ||
      activeOption.kind === 'privy_crypto'
    ) {
      if (activeOption.availableUnits + 1e-6 < requiredUnits) {
        const msg = formatInsufficientCurrencyError({
          symbol: activeOption.symbol,
          name: activeOption.name,
          available: activeOption.availableUnits,
          required: requiredUnits,
          maxDecimals: activeOption.mode === 'crypto' ? 6 : 2,
        });
        setErrorMsg(msg);
        addToast({
          title: activeOption.availableUnits <= 0 ? `No ${activeOption.symbol} Held` : `Insufficient ${activeOption.symbol}`,
          message: msg,
          type: 'error',
        });
        return;
      }
    }

    setShowConfirm(true);
  };

  const processExecution = async () => {
    if (!activeOption) return;
    setShowConfirm(false);
    setIsProcessing(true);
    setErrorMsg(null);

    try {
      let clearingRef = activeOption.label;
      let chargeId = `alloc-${Date.now()}`;

      if (activeOption.kind === 'stripe_card' || activeOption.kind === 'stripe_bank') {
        if (!currentUser || !activeOption.stripePaymentMethodId) {
          throw new Error('Sign in and select a verified Stripe payment method.');
        }
        const chargeRes = await executeStripeCharge(currentUser, {
          paymentMethodId: activeOption.stripePaymentMethodId,
          amountUSD: totalUSD,
          baseAmountUSD: subtotalUSD,
          feeUSD,
          purpose: 'purchase',
          description: `Marketplace allocation: ${selectedLotSize}x ${product.name}`,
          targetCurrencyCode: activeOption.symbol,
        });
        if (chargeRes.status !== 'succeeded' && chargeRes.status !== 'processing') {
          throw new Error(`Card/Bank charge status: ${chargeRes.status}`);
        }
        chargeId = chargeRes.paymentIntentId;
        clearingRef = `Stripe (${activeOption.label})`;
      } else {
        const deltaRes = applyCurrencyWalletDelta({
          userId,
          currencySymbol: activeOption.symbol,
          delta: -requiredUnits,
          requireSufficientBalance: true,
        });
        if (!deltaRes.success) {
          throw new Error(
            deltaRes.error ||
              formatInsufficientCurrencyError({
                symbol: activeOption.symbol,
                name: activeOption.name,
                available: activeOption.availableUnits,
                required: requiredUnits,
              })
          );
        }
        clearingRef =
          activeOption.feeType === 'stripe_wallet'
            ? `Stripe Wallet (${activeOption.symbol})`
            : activeOption.feeType === 'privy_wallet'
              ? `Privy Wallet (${activeOption.symbol})`
              : `Wallet (${activeOption.symbol})`;
      }

      const nowIso = new Date().toISOString();
      const feeNote =
        feeUSD > 0
          ? ` Includes $${feeUSD.toFixed(2)} ${walletFee.feeLabel}.`
          : '';

      const ledgerItem = normalizeLedgerItem({
        id: `rec-prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        receiptNumber: `REC-2026-MKT-${Math.floor(1000 + Math.random() * 9000)}`,
        taxYear: new Date().getFullYear(),
        timestamp: nowIso.replace('T', ' ').slice(0, 19) + ' UTC',
        dateIso: nowIso,
        type: 'product_purchase',
        category: 'product_service',
        mode: activeOption.mode,
        title: `Marketplace Purchase: ${product.name}`,
        description: `Purchased ${selectedLotSize}x ${product.name} (${product.category}) via ${clearingRef} (${requiredUnits.toLocaleString()} ${activeOption.symbol}).${feeNote}`,
        amountUSD: subtotalUSD,
        feeUSD,
        netAmountUSD: -totalUSD,
        sourceOrDestination: clearingRef,
        counterpartyOrIssuer: 'Final Finance Asset Allocation',
        paymentCoinSymbol: activeOption.symbol,
        paymentCoinAmount: requiredUnits,
        taxClassification: {
          formMapping: 'Schedule C / Business Expense',
          taxableEvent: true,
          taxableAmountUSD: -totalUSD,
          holdingPeriod: 'N/A',
          taxDeductible: true,
          irsCategoryNote: `Asset allocation settled in ${activeOption.symbol}.${feeNote}`,
        },
        status: 'Settled',
        clearingNode: 'Marketplace Invoicing Gateway Node #09',
        cryptographicHash: `0x${chargeId.replace(/[^a-zA-Z0-9]/g, '').slice(0, 24).padEnd(24, 'a')}`,
        signature: `SIG-MKT-${Math.floor(100000 + Math.random() * 900000)}`,
      });

      recordLedgerTransaction(userId, ledgerItem);
      setActionConfirmed(true);

      addToast({
        title: 'Asset Allocation Settled',
        message: `Allocated ${selectedLotSize}x ${product.name}. Deducted ${requiredUnits.toLocaleString()} ${activeOption.symbol} ($${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} total).`,
        type: 'gold',
      });

      addNotification({
        title: `🛍️ Asset Order Settled: ${product.name}`,
        description: `Allocated ${selectedLotSize} unit(s) via ${clearingRef}. Subtotal: $${subtotalUSD.toFixed(2)}, Fee: $${feeUSD.toFixed(2)}, Total: $${totalUSD.toFixed(2)}.`,
        type: 'marketplace',
        targetTab: 'ledger',
        amount: totalUSD,
        currency: 'USD',
      });

      setTimeout(() => {
        setActionConfirmed(false);
        onClose();
      }, 1300);
    } catch (err: any) {
      const msg = err?.message || 'Unable to execute asset allocation.';
      setErrorMsg(msg);
      addToast({
        title: 'Allocation Failed',
        message: msg,
        type: 'error',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      id="product-detail-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 12 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="w-full max-w-xl bg-white border border-neutral-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative text-left my-auto max-h-[92dvh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 sm:top-5 sm:right-5 min-h-[36px] min-w-[36px] flex items-center justify-center rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-start gap-4 pb-4 border-b border-neutral-100 pr-8">
          <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Coins className="w-6 h-6 text-amber-400" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-neutral-900 text-white font-medium">
                {product.badge || 'SOVEREIGN ASSET'}
              </span>
              <span className="text-xs text-neutral-400 font-medium">
                {product.category}
              </span>
            </div>

            <h2 className="font-serif-lux text-xl sm:text-2xl font-light text-black tracking-tight leading-snug">
              {product.name}
            </h2>
          </div>
        </div>

        <div className="overflow-y-auto pr-1 py-4 space-y-5 flex-1">
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/90 flex items-center justify-between gap-3">
            <div>
              <p className="text-[11px] text-neutral-400 uppercase tracking-wider font-mono">Reference Valuation</p>
              <p className="text-lg sm:text-xl font-bold text-black font-mono mt-0.5">
                {product.price}
              </p>
            </div>
            <div className="flex items-center gap-1 text-emerald-700 bg-emerald-100/80 px-2.5 py-1 rounded-full text-xs font-semibold shrink-0">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Audited LBMA / Multi-Sig</span>
            </div>
          </div>

          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono mb-1.5">
              Asset Provenance &amp; Specifications
            </h3>
            <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed">
              {product.description}
            </p>
          </div>

          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono mb-2">
              Guaranteed Features
            </h3>
            <div className="space-y-2">
              {product.features.map((feat, idx) => (
                <div key={idx} className="flex items-center gap-2.5 text-xs text-neutral-800">
                  <div className="w-4 h-4 rounded-full bg-black text-white flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5" />
                  </div>
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono">
                Order / Allocation Lot Size
              </label>
              <span className="text-xs font-mono font-semibold text-black">
                {selectedLotSize} Unit{selectedLotSize > 1 ? 's' : ''}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {[1, 5, 10, 25, 50].map((lot) => (
                <button
                  key={lot}
                  type="button"
                  onClick={() => {
                    setSelectedLotSize(lot);
                    setErrorMsg(null);
                  }}
                  className={`min-h-[38px] flex-1 py-1.5 rounded-xl text-xs font-mono font-semibold transition-all cursor-pointer ${
                    selectedLotSize === lot
                      ? 'bg-black text-white shadow-xs'
                      : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                  }`}
                >
                  {lot}x
                </button>
              ))}
            </div>
          </div>

          {/* Payment Source & Currency Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 font-mono flex items-center gap-1.5">
              {activeOption?.kind === 'stripe_card' ? (
                <CreditCard className="w-3.5 h-3.5 text-slate-600" />
              ) : activeOption?.kind === 'stripe_bank' ? (
                <Building2 className="w-3.5 h-3.5 text-slate-600" />
              ) : (
                <Wallet className="w-3.5 h-3.5 text-slate-600" />
              )}
              <span>Payment Currency / Funding Rail</span>
            </label>
            <select
              value={selectedOptionId}
              onChange={(e) => {
                setSelectedOptionId(e.target.value);
                setErrorMsg(null);
              }}
              className="w-full px-3 py-2.5 rounded-xl border border-neutral-200 bg-neutral-50 text-xs font-mono font-semibold text-neutral-900 focus:outline-none focus:border-black cursor-pointer"
            >
              {paymentOptions.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {opt.label} — {opt.sublabel}
                </option>
              ))}
            </select>
          </div>

          {/* Fee & Total Summary */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs font-mono">
            <div className="flex items-center justify-between text-slate-600">
              <span>Allocation Subtotal ({selectedLotSize}x)</span>
              <span>${subtotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span>
                {feeUSD > 0
                  ? `${walletFee.feeLabel}${walletFee.nativeUnits && walletFee.nativeSymbol ? ` (~${walletFee.nativeUnits} ${walletFee.nativeSymbol})` : ''}`
                  : 'Network / Clearing Fee'}
              </span>
              <span className={feeUSD > 0 ? 'text-amber-700 font-semibold' : 'text-emerald-700 font-semibold'}>
                {feeUSD > 0 ? `+$${feeUSD.toFixed(2)}` : '$0.00 (Free)'}
              </span>
            </div>
            <div className="pt-1.5 border-t border-slate-200 flex items-center justify-between font-bold text-slate-900">
              <span>Total Charged</span>
              <span>
                ${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                {activeOption && activeOption.symbol !== 'USD' && (
                  <span className="text-[11px] text-slate-500 font-normal ml-1">
                    ({requiredUnits.toLocaleString()} {activeOption.symbol})
                  </span>
                )}
              </span>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{errorMsg}</span>
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-neutral-100 flex items-center justify-between gap-3">
          <div className="text-xs text-neutral-500 font-mono hidden sm:block">
            Escrow: Final Finance Zurich
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              disabled={isProcessing || actionConfirmed}
              onClick={handleAction}
              className="flex-1 sm:flex-none min-h-[42px] px-6 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60"
            >
              {actionConfirmed ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Allocation Settled!</span>
                </>
              ) : isProcessing ? (
                <span>Settling Payment...</span>
              ) : (
                <>
                  <span>Pay ${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title="Confirm Asset Allocation"
        message={`Authorize allocation of ${selectedLotSize} unit(s) of ${product.name} for $${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD (incl. $${feeUSD.toFixed(2)} fee) via ${activeOption?.label || 'Wallet'}?`}
        confirmText={`Pay $${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
        type="info"
      />
    </div>
  );
};
