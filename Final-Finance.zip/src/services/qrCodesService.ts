export type QRTxMode = 'fiat' | 'final' | 'crypto' | 'barter' | 'stablecoin';
export type QRUsage = 'one-time' | 'inventory';

export interface SavedQRCode {
  id: string;
  title: string;
  usage: QRUsage;
  txMode: QRTxMode;
  currency: string;
  amount: string;
  value: string;
  createdAt: string;
  description?: string;
  photos?: string[];
  videos?: string[];
  source?: 'qrcodes' | 'pos' | 'rideshare';
}

export const SAVED_QR_CODES_STORAGE_KEY = 'ff_saved_qr_codes_v1';
export const QR_CODES_UPDATED_EVENT = 'ff_qr_codes_updated';

function buildDefaultSavedQRCodes(userId: string = 'user_ranma'): SavedQRCode[] {
  const uid = userId || 'user_ranma';
  return [
    {
      id: 'qr-1',
      title: 'Consulting Hour',
      usage: 'inventory',
      txMode: 'fiat',
      currency: 'USD',
      amount: '150',
      value: `ff:inventory:fiat:USD:150:${uid}`,
      createdAt: '2026-08-20',
      description: 'Senior product architectural consulting and custom development session.',
      photos: ['https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80'],
      source: 'qrcodes',
    },
    {
      id: 'qr-fiat-ot',
      title: 'Express Invoice Request',
      usage: 'one-time',
      txMode: 'fiat',
      currency: 'USD',
      amount: '500',
      value: `ff:onetime:fiat:USD:500:${uid}`,
      createdAt: '2026-08-21',
      description: 'One-time milestone settlement invoice.',
      source: 'qrcodes',
    },
    {
      id: 'qr-2',
      title: 'Coffee Payment',
      usage: 'one-time',
      txMode: 'final',
      currency: 'AFNL',
      amount: '5',
      value: `ff:onetime:final:AFNL:5:${uid}`,
      createdAt: '2026-08-22',
      source: 'qrcodes',
    },
    {
      id: 'qr-final-inv',
      title: 'Final Coin Genesis Badge',
      usage: 'inventory',
      txMode: 'final',
      currency: 'AFNL',
      amount: '100',
      value: `ff:inventory:final:AFNL:100:${uid}`,
      createdAt: '2026-08-22',
      description: 'Limited edition Genesis membership NFT token tag.',
      source: 'qrcodes',
    },
    {
      id: 'qr-stable-ot',
      title: 'USDT Escrow Transfer',
      usage: 'one-time',
      txMode: 'stablecoin',
      currency: 'USDT',
      amount: '250',
      value: `ff:onetime:stablecoin:USDT:250:${uid}`,
      createdAt: '2026-08-23',
      source: 'qrcodes',
    },
    {
      id: 'qr-stable-inv',
      title: 'Stable Yield Token Tag',
      usage: 'inventory',
      txMode: 'stablecoin',
      currency: 'USDC',
      amount: '1000',
      value: `ff:inventory:stablecoin:USDC:1000:${uid}`,
      createdAt: '2026-08-23',
      source: 'qrcodes',
    },
    {
      id: 'qr-crypto-ot',
      title: 'ETH Gas & Tip QR',
      usage: 'one-time',
      txMode: 'crypto',
      currency: 'ETH',
      amount: '0.05',
      value: `ff:onetime:crypto:ETH:0.05:${uid}`,
      createdAt: '2026-08-24',
      source: 'qrcodes',
    },
    {
      id: 'qr-crypto-inv',
      title: 'Bitcoin Hardware Node Tag',
      usage: 'inventory',
      txMode: 'crypto',
      currency: 'BTC',
      amount: '0.01',
      value: `ff:inventory:crypto:BTC:0.01:${uid}`,
      createdAt: '2026-08-24',
      source: 'qrcodes',
    },
    {
      id: 'qr-barter-seed',
      title: 'Developer Laptop Exchange',
      usage: 'one-time',
      txMode: 'barter',
      currency: 'Custom Video/Audio Setup',
      amount: '1 Core i9 Laptop',
      value: `ff:onetime:barter:Custom Video/Audio Setup:1 Core i9 Laptop:${uid}`,
      createdAt: '2026-08-25',
      description: 'Premium developer laptop (32GB RAM, 1TB SSD) in exchange for pro-grade podcast or video presentation setups.',
      photos: [
        'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80',
        'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=600&q=80',
      ],
      videos: [
        'https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-his-laptop-34281-large.mp4',
      ],
      source: 'qrcodes',
    },
    {
      id: 'qr-barter-inv',
      title: 'Ergonomic Desk Tag',
      usage: 'inventory',
      txMode: 'barter',
      currency: 'Legal Consultation',
      amount: '1 Standing Desk',
      value: `ff:inventory:barter:Legal Consultation:1 Standing Desk:${uid}`,
      createdAt: '2026-08-26',
      description: 'Standing office desk in exchange for 2 hours of legal review.',
      source: 'qrcodes',
    },
  ];
}

export function getStoredSavedQRCodes(userId?: string): SavedQRCode[] {
  if (typeof window === 'undefined') {
    return buildDefaultSavedQRCodes(userId);
  }
  try {
    const raw = localStorage.getItem(SAVED_QR_CODES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch {
    // ignore storage errors
  }
  const seeded = buildDefaultSavedQRCodes(userId);
  try {
    localStorage.setItem(SAVED_QR_CODES_STORAGE_KEY, JSON.stringify(seeded));
  } catch {
    // ignore
  }
  return seeded;
}

export function saveQRCodeList(codes: SavedQRCode[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SAVED_QR_CODES_STORAGE_KEY, JSON.stringify(codes));
    window.dispatchEvent(new CustomEvent(QR_CODES_UPDATED_EVENT));
  } catch {
    // ignore storage errors
  }
}

export function addSavedQRCode(
  input: Omit<SavedQRCode, 'id' | 'createdAt'> & { id?: string; createdAt?: string },
  userId?: string
): SavedQRCode {
  const existing = getStoredSavedQRCodes(userId);
  const dup = existing.find((c) => c.value === input.value);
  if (dup) return dup;

  const nextItem: SavedQRCode = {
    ...input,
    id: input.id || `qr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    createdAt: input.createdAt || new Date().toISOString().split('T')[0],
  };
  saveQRCodeList([nextItem, ...existing]);
  return nextItem;
}

export function deleteSavedQRCode(id: string, userId?: string): SavedQRCode[] {
  const existing = getStoredSavedQRCodes(userId);
  const next = existing.filter((c) => c.id !== id);
  saveQRCodeList(next);
  return next;
}
