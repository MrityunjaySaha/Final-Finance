import React, { useState, useEffect, useMemo } from 'react';
import {
  getAllLoans,
  getLoansForUser,
  getLoanTotalDue,
  getLoanRemainingBalance,
  getLoanNextDueDateMs,
  getLoanTimelineMetrics,
  getLoanInstallmentSchedule,
  seedExampleLoansForUser,
  payAheadLoan,
  acceptLoanOffer,
  declineLoanOffer,
  calculateMonthlyInstallment,
  getUserFinalLoanDefaultCount,
  isRegisteredInternalBank,
  LoanRecord
} from '../services/loanService';
import { syncFinalCoinCirculationDelta } from '../data/customCoinsData';
import { getUserProfile, enqueueUserNotification } from '../services/socialService';
import { UserPublicProfile } from '../types/social';
import { getProfileReturnAnchor, setPendingProfileReturnAnchor } from '../utils/profileReturnState';
import { useApp } from '../context/AppContext';
import { 
  Clock, 
  CheckCircle2, 
  Zap, 
  Coins, 
  ShieldCheck,
  FileCheck,
  AlertCircle,
  ArrowDownLeft,
  Wallet,
  Check,
  ExternalLink,
  Image,
  Video,
  Upload,
  X,
  RotateCcw,
  Calendar,
  Search
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { applyCurrencyWalletDelta, getWalletCurrencyBalance } from '../utils/walletBalanceUpdater';
import { recordLedgerTransaction, createLedgerItemFromGrantClaim } from '../utils/universalLedgerBridge';
import { getUserVerificationTier, getTierBadgeLabel, isAdminOrSuperAdminUser } from '../utils/verificationTiers';
import { recordAdminSelfGrant } from '../services/adminSelfGrantService';

interface SubsidiesGrantsPageProps {
  currentUser?: AuthSession | null;
  onOpenVerification?: () => void;
  onNavigateToSettings?: () => void;
  onNavigateBack?: () => void;
  onSelectUser?: (userIdOrHandle: string) => void;
}

export const SubsidiesGrantsPage: React.FC<SubsidiesGrantsPageProps> = ({
  currentUser,
  onOpenVerification,
  onNavigateToSettings,
  onSelectUser,
}) => {
  const { addNotification, addToast } = useApp();
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const initialAnchor = useMemo(() => {
    const anchor = getProfileReturnAnchor();
    return anchor?.restoreActive ? anchor : null;
  }, []);

  type BankingViewTab = 'taken_ongoing' | 'loan_offers' | 'lent_to_others' | 'portfolio_transactions';

  const [activeBankingView, setActiveBankingView] = useState<BankingViewTab>(() => {
    const restored = initialAnchor?.bankingView;
    if (restored === 'transactions' || restored === 'portfolio') return 'portfolio_transactions';
    if (
      restored === 'taken_ongoing' ||
      restored === 'loan_offers' ||
      restored === 'lent_to_others' ||
      restored === 'portfolio_transactions'
    ) {
      return restored;
    }
    return 'taken_ongoing';
  });
  const [activePortfolioTab, setActivePortfolioTab] = useState<'ongoing' | 'concluded'>(
    () => initialAnchor?.portfolioTab || 'ongoing'
  );
  const [activeLoanType, setActiveLoanType] = useState<'given' | 'received'>(
    () => initialAnchor?.loanType || 'received'
  );
  const [activeSubTab, setActiveSubTab] = useState<'ubi' | 'grants' | 'banking'>(
    () => initialAnchor?.subsidiesSubTab || 'ubi'
  );
  const [payAheadInputs, setPayAheadInputs] = useState<Record<string, string>>({});
  const [loansVersion, setLoansVersion] = useState(0);
  const [counterpartyProfiles, setCounterpartyProfiles] = useState<Record<string, UserPublicProfile>>({});
  const isAdmin = isAdminOrSuperAdminUser(currentUser);
  const userId = currentUser?.id || 'guest_trader';

  // Seed persisted editable sample loans once per user so Pay Ahead, Due Dates, Timelines, Profiles, and Default flows can be verified cleanly
  useEffect(() => {
    const seeded = seedExampleLoansForUser(userId, {
      uid: currentUser?.uid,
      handle: currentUser?.handle || currentUser?.id,
      name: currentUser?.name,
      avatarUrl: currentUser?.avatarUrl,
    });
    if (seeded) {
      setLoansVersion((v) => v + 1);
    }
  }, [userId, currentUser?.uid, currentUser?.handle, currentUser?.id, currentUser?.name, currentUser?.avatarUrl]);

  useEffect(() => {
    const handleLoansUpdated = () => setLoansVersion((v) => v + 1);
    window.addEventListener('final_finance_loans_updated', handleLoansUpdated);
    return () => window.removeEventListener('final_finance_loans_updated', handleLoansUpdated);
  }, []);

  const allLoans = useMemo(() => {
    void loansVersion;
    return getAllLoans();
  }, [loansVersion]);

  const { issued: loansIssued, received: loansReceived } = useMemo(() => {
    void loansVersion;
    return getLoansForUser(userId, [currentUser?.uid, currentUser?.handle, currentUser?.id]);
  }, [userId, currentUser?.uid, currentUser?.handle, currentUser?.id, loansVersion]);

  // Resolve full public profile (name + avatar) for every borrower and lender
  useEffect(() => {
    const keysToLoad = new Set<string>();
    [...loansIssued, ...loansReceived].forEach((loan) => {
      if (loan.lenderHandle) keysToLoad.add(loan.lenderHandle.replace(/^@/, '').toLowerCase());
      if (loan.lenderId) keysToLoad.add(loan.lenderId);
      if (loan.borrowerHandle) keysToLoad.add(loan.borrowerHandle.replace(/^@/, '').toLowerCase());
      if (loan.borrowerId) keysToLoad.add(loan.borrowerId);
    });
    if (keysToLoad.size === 0) return;

    let cancelled = false;
    Promise.all(
      Array.from(keysToLoad).map(async (key) => {
        const profile = await getUserProfile(key);
        return [key, profile] as const;
      })
    ).then((entries) => {
      if (cancelled) return;
      setCounterpartyProfiles((prev) => {
        const next = { ...prev };
        entries.forEach(([key, profile]) => {
          if (profile) {
            next[key] = profile;
            if (profile.userId) next[profile.userId.toLowerCase()] = profile;
            if (profile.uid) next[profile.uid] = profile;
          }
        });
        return next;
      });
    });

    return () => {
      cancelled = true;
    };
  }, [loansIssued, loansReceived]);

  const resolveCounterpartyDisplay = (
    idVal?: string,
    handleVal?: string,
    storedName?: string,
    storedAvatar?: string
  ) => {
    const cleanHandle = (handleVal || idVal || 'member').replace(/^@/, '');
    const lowerHandle = cleanHandle.toLowerCase();
    const prof =
      counterpartyProfiles[lowerHandle] ||
      (idVal ? counterpartyProfiles[idVal] : undefined) ||
      (idVal ? counterpartyProfiles[idVal.toLowerCase()] : undefined);

    const displayName =
      prof?.name ||
      storedName ||
      cleanHandle
        .split(/[_\-\s]+/)
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ');
    const displayHandle = `@${prof?.userId || cleanHandle}`;
    const avatarUrl =
      prof?.avatarUrl ||
      storedAvatar ||
      `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=f59e0b&color=0f172a&bold=true&size=128`;
    const targetIdentifier = prof?.userId || cleanHandle || idVal || '';

    return {
      name: displayName,
      handle: displayHandle,
      avatarUrl,
      targetIdentifier,
    };
  };

  const handleOpenCounterpartyProfile = (targetIdentifier: string) => {
    if (!targetIdentifier || !onSelectUser) return;
    setPendingProfileReturnAnchor({
      sourceLabel: 'Back to Internal Banking',
      scrollY: typeof window !== 'undefined' ? window.scrollY : 0,
      subsidiesSubTab: activeSubTab,
      bankingView: activeBankingView,
      portfolioTab: activePortfolioTab,
      loanType: activeLoanType,
    });
    onSelectUser(targetIdentifier);
  };

  const handleResetExampleLoans = () => {
    seedExampleLoansForUser(userId, {
      uid: currentUser?.uid,
      handle: currentUser?.handle || currentUser?.id,
      name: currentUser?.name,
      avatarUrl: currentUser?.avatarUrl,
      reset: true,
    });
    setLoansVersion((v) => v + 1);
    showToast('Sample loan examples restored for testing.');
  };

  const pendingLoanOffers = useMemo(
    () => loansReceived.filter((l) => l.status === 'pending_offer'),
    [loansReceived]
  );

  const ongoingLoansTaken = useMemo(
    () => loansReceived.filter((l) => l.status === 'active'),
    [loansReceived]
  );

  const renderInstallmentSchedule = (loan: LoanRecord) => {
    const schedule = getLoanInstallmentSchedule(loan);
    return (
      <div className="w-full bg-white/95 p-3.5 rounded-xl border border-slate-200/80 space-y-2.5 text-center">
        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-semibold text-slate-700 border-b border-slate-100 pb-2">
          <span className="inline-flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-amber-600" />
            <span>
              All Payment Installments ({schedule.length}{' '}
              {schedule.length === 1 ? 'Installment' : 'Installments'})
            </span>
          </span>
          <span className="font-mono text-[10px] text-slate-500">
            Total Obligation: {getLoanTotalDue(loan).toLocaleString()} {loan.coinSymbol}
          </span>
        </div>

        <div className="space-y-1.5">
          {schedule.map((inst) => {
            const dueStr = new Date(inst.dueDateMs).toLocaleDateString(undefined, {
              year: 'numeric',
              month: 'short',
              day: 'numeric',
            });
            const statusMeta =
              inst.status === 'paid'
                ? { label: 'Paid', cls: 'bg-emerald-100 text-emerald-800 border-emerald-200' }
                : inst.status === 'partial'
                ? { label: 'Partially Paid', cls: 'bg-sky-100 text-sky-900 border-sky-200' }
                : inst.status === 'overdue'
                ? { label: 'Overdue', cls: 'bg-rose-100 text-rose-800 border-rose-200' }
                : inst.status === 'due_next'
                ? { label: 'Due Next', cls: 'bg-amber-100 text-amber-900 border-amber-200' }
                : inst.status === 'pending_approval'
                ? { label: 'On Approval', cls: 'bg-sky-50 text-sky-800 border-sky-200' }
                : inst.status === 'declined'
                ? { label: 'Declined', cls: 'bg-slate-200 text-slate-700 border-slate-300' }
                : inst.status === 'defaulted'
                ? { label: 'Defaulted', cls: 'bg-rose-100 text-rose-900 border-rose-200' }
                : { label: 'Upcoming', cls: 'bg-slate-100 text-slate-700 border-slate-200' };

            return (
              <div
                key={`${loan.id}-inst-${inst.installmentNumber}`}
                className="px-3 py-2 rounded-xl bg-slate-50/90 border border-slate-200/70 grid grid-cols-1 sm:grid-cols-4 items-center gap-1.5 text-[11px]"
              >
                <div className="font-mono font-bold text-slate-800 sm:text-left">
                  Installment {inst.installmentNumber} of {inst.totalInstallments}
                </div>
                <div className="font-mono text-slate-600">
                  {loan.status === 'pending_offer' ? `Day ${inst.dayOffset} (~${dueStr})` : dueStr}
                </div>
                <div className="font-mono font-bold text-slate-900">
                  {inst.amountDue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {loan.coinSymbol}
                  {inst.amountPaid > 0 && inst.amountRemaining > 0 && (
                    <span className="block text-[9px] font-normal text-emerald-700">
                      Paid {inst.amountPaid.toLocaleString()} • Rem {inst.amountRemaining.toLocaleString()}
                    </span>
                  )}
                </div>
                <div className="flex justify-center sm:justify-end">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${statusMeta.cls}`}>
                    {statusMeta.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const nextDueLoan = useMemo(() => {
    if (ongoingLoansTaken.length === 0) return null;
    return [...ongoingLoansTaken].sort(
      (a, b) => getLoanNextDueDateMs(a) - getLoanNextDueDateMs(b)
    )[0];
  }, [ongoingLoansTaken]);

  const userDefaultCount = useMemo(() => {
    void loansVersion;
    const registryDefaults = getUserFinalLoanDefaultCount(userId, currentUser?.uid);
    const localBorrowedDefaults = loansReceived.filter((l) => l.status === 'defaulted').length;
    return Math.max(registryDefaults, localBorrowedDefaults);
  }, [userId, currentUser?.uid, loansReceived, loansVersion]);

  const allUserLoans = useMemo(() => {
    const seen = new Set<string>();
    const merged: LoanRecord[] = [];
    [...loansReceived, ...loansIssued].forEach((l) => {
      if (!seen.has(l.id)) {
        seen.add(l.id);
        merged.push(l);
      }
    });
    return merged.sort((a, b) => (b.issuedAtMs || 0) - (a.issuedAtMs || 0));
  }, [loansReceived, loansIssued]);

  const userGender = localStorage.getItem(`ff_user_gender_${userId}`) || currentUser?.gender || 'male';
  const accrualRate = userGender === 'female' ? 0.12 : userGender === 'other' ? 0.11 : 0.1;

  // Signed-in & Tier 1 (1 Verified Legal ID) checks for Admin Final Coins (Admins exempt)
  const isSignedIn = Boolean(currentUser && currentUser.id && currentUser.id !== 'guest_trader');
  const userTier = getUserVerificationTier(currentUser);
  const isVerified = isSignedIn && (isAdmin || userTier >= 1);

  // UBI Stream runs automatically whenever user is signed in and holds Tier 1+ verification or Admin privilege
  const isUbiStreamActive = isVerified;

  // Dedicated Error Modal for Tier 1 / Verification Blocks
  const [tierErrorModal, setTierErrorModal] = useState<{
    title: string;
    message: string;
    requiredTier: 1 | 2 | 3;
    actionLabel?: string;
  } | null>(null);

  // Signup Grant status: 'unclaimed' | 'claimed_to_pool' | 'deposited'
  const [signupStatus, setSignupStatus] = useState<'unclaimed' | 'claimed_to_pool' | 'deposited'>(() => {
    return (localStorage.getItem(`ff_signup_status_${userId}`) as any) || 'unclaimed';
  });

  // Accrued subsidy state (starts at 0.0 by default)
  const [unclaimedAccruedAFNL, setUnclaimedAccruedAFNL] = useState<number>(() => {
    if (!isVerified) return 0;
    const saved = localStorage.getItem(`ff_unclaimed_accrued_${userId}`);
    return saved ? parseFloat(saved) : 0;
  });

  const [claimedAccruedAFNL, setClaimedAccruedAFNL] = useState<number>(() => {
    const saved = localStorage.getItem(`ff_claimed_accrued_${userId}`);
    return saved ? parseFloat(saved) : 0;
  });

  // Countdown timer for next AFNL unit (60 seconds, persistent across page navigation & signed out state)
  const [secondsRemaining, setSecondsRemaining] = useState<number>(() => {
    if (!isVerified) return 60;
    const now = Date.now();
    let lastTsStr = localStorage.getItem(`ff_last_accrual_ts_${userId}`);
    if (!lastTsStr) {
      lastTsStr = now.toString();
      localStorage.setItem(`ff_last_accrual_ts_${userId}`, lastTsStr);
    }
    const lastTs = parseInt(lastTsStr, 10);
    const elapsedSec = Math.floor((now - lastTs) / 1000);

    // If enough time passed while away and user is Tier 1+ verified, catch up accrued minutes automatically
    if (elapsedSec >= 60) {
      const completedMinutes = Math.floor(elapsedSec / 60);
      const remainingSeconds = elapsedSec % 60;
      
      const newLastTs = now - (remainingSeconds * 1000);
      localStorage.setItem(`ff_last_accrual_ts_${userId}`, newLastTs.toString());

      const currentUnclaimed = parseFloat(localStorage.getItem(`ff_unclaimed_accrued_${userId}`) || '0');
      const added = completedMinutes * accrualRate;
      const updatedUnclaimed = Math.round((currentUnclaimed + added) * 100) / 100;
      localStorage.setItem(`ff_unclaimed_accrued_${userId}`, updatedUnclaimed.toString());

      return 60 - remainingSeconds > 0 ? 60 - remainingSeconds : 60;
    } else {
      const rem = 60 - elapsedSec;
      return rem > 0 && rem <= 60 ? rem : 60;
    }
  });

  // Wallet data state
  const [walletData, setWalletData] = useState(() => getStoredUserWallets(userId));

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Listen to external wallet updates
  useEffect(() => {
    const handleWalletUpdate = () => {
      setWalletData(getStoredUserWallets(userId));
    };
    window.addEventListener('final_finance_wallets_updated', handleWalletUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleWalletUpdate);
    };
  }, [userId]);

  // Bank Application State (synced with Admin approvals & presets; Admins exempt & authorized)
  const resolveBankStatus = (): 'none' | 'pending' | 'approved' => {
    if (isAdmin) return 'approved';
    const uidKey = currentUser?.uid ? `ff_bank_app_status_${currentUser.uid}` : '';
    const s1 = localStorage.getItem(`ff_bank_app_status_${userId}`);
    const s2 = uidKey ? localStorage.getItem(uidKey) : null;
    if (
      s1 === 'approved' ||
      s2 === 'approved' ||
      isRegisteredInternalBank(userId) ||
      isRegisteredInternalBank(currentUser?.uid)
    ) {
      return 'approved';
    }
    if (s1 === 'pending' || s2 === 'pending') return 'pending';
    return 'none';
  };
  const [bankAppStatus, setBankAppStatus] = useState<'none' | 'pending' | 'approved'>(resolveBankStatus);

  useEffect(() => {
    const resolved = resolveBankStatus();
    setBankAppStatus(resolved);
    if (isAdmin && userId && userId !== 'guest_trader') {
      try {
        if (localStorage.getItem(`ff_bank_app_status_${userId}`) !== 'approved') {
          localStorage.setItem(`ff_bank_app_status_${userId}`, 'approved');
        }
        if (currentUser?.uid && localStorage.getItem(`ff_bank_app_status_${currentUser.uid}`) !== 'approved') {
          localStorage.setItem(`ff_bank_app_status_${currentUser.uid}`, 'approved');
        }
      } catch {
        // ignore storage errors
      }
    }
    const syncBank = () => setBankAppStatus(resolveBankStatus());
    window.addEventListener('final_finance_bank_status_updated', syncBank);
    window.addEventListener('storage', syncBank);
    return () => {
      window.removeEventListener('final_finance_bank_status_updated', syncBank);
      window.removeEventListener('storage', syncBank);
    };
  }, [userId, currentUser?.uid, isAdmin]);
  const [bankModalOpen, setBankModalOpen] = useState(false);
  const [institutionName, setInstitutionName] = useState('');
  const [institutionReason, setInstitutionReason] = useState('');

  // Final Coin Loan Desk State
  const [loanModalOpen, setLoanModalOpen] = useState(false);
  const [borrowerHandle, setBorrowerHandle] = useState('@');
  const [loanAmount, setLoanAmount] = useState('1000');
  const [loanCoinSearch, setLoanCoinSearch] = useState('');
  const [loanSymbol, setLoanSymbol] = useState(
    () => walletData.finalCoins.find((c) => c.balance > 0)?.symbol || ''
  );
  const [loanInterest, setLoanInterest] = useState('5.0');
  const [loanTermDays, setLoanTermDays] = useState('30');

  const ownedFinalCoinsForLoan = useMemo(
    () => walletData.finalCoins.filter((c) => c.balance > 0),
    [walletData.finalCoins]
  );

  const filteredFinalCoinsForLoan = useMemo(() => {
    const q = loanCoinSearch.trim().toLowerCase();
    if (!q) return ownedFinalCoinsForLoan;
    return ownedFinalCoinsForLoan.filter(
      (c) => c.symbol.toLowerCase().includes(q) || c.name.toLowerCase().includes(q)
    );
  }, [loanCoinSearch, ownedFinalCoinsForLoan]);

  const selectedLoanCoinObj = useMemo(
    () => walletData.finalCoins.find((c) => c.symbol === loanSymbol) || ownedFinalCoinsForLoan[0] || null,
    [walletData.finalCoins, ownedFinalCoinsForLoan, loanSymbol]
  );

  const estimatedLoanMonthlyInstallment = useMemo(
    () => calculateMonthlyInstallment(parseFloat(loanAmount) || 0, parseFloat(loanInterest) || 0, parseInt(loanTermDays, 10) || 30),
    [loanAmount, loanInterest, loanTermDays]
  );

  const reloadLoans = () => {
    setLoansVersion((v) => v + 1);
  };

  const handleApproveLoanOffer = (loan: LoanRecord) => {
    const coinSym = (loan.coinSymbol || 'AFNL').toUpperCase();
    const lenderKey = loan.lenderId || loan.lenderHandle.replace(/^@/, '');

    const debitRes = applyCurrencyWalletDelta({
      userId: lenderKey,
      currencySymbol: coinSym,
      delta: -loan.amount,
      requireSufficientBalance: true,
    });
    if (!debitRes.success) {
      showToast(debitRes.error || `Lender has insufficient ${coinSym} balance to fund this offer.`);
      return;
    }

    const creditRes = applyCurrencyWalletDelta({
      userId,
      currencySymbol: coinSym,
      delta: loan.amount,
      utilityNote: `Approved loan principal received from ${loan.lenderHandle}`,
    });
    setWalletData(creditRes.wallet);

    const activated = acceptLoanOffer(loan.id);
    if (!activated) {
      showToast('Could not locate loan offer.');
      return;
    }

    syncFinalCoinCirculationDelta(coinSym, loan.amount, { adjustTotalSupplyIfNeeded: true });

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-LOAN-ACC-${Math.floor(1000 + Math.random() * 9000)}`;

    const borrowerLedgerItem = {
      id: `rec-loan-acc-in-${Date.now()}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'loan_received' as const,
      category: 'loan' as const,
      mode: 'final_coin' as const,
      title: `Approved Loan Offer from ${loan.lenderHandle}`,
      description: `Approved & received ${loan.amount.toLocaleString()} ${coinSym} loan at ${loan.interestRate}% APR (${loan.termDays} days).`,
      amountUSD: loan.amount,
      feeUSD: 0,
      netAmountUSD: loan.amount,
      sourceOrDestination: `User Wallet (@${currentUser?.handle || userId})`,
      counterpartyOrIssuer: loan.lenderHandle,
      paymentCoinSymbol: coinSym,
      paymentCoinAmount: loan.amount,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer' as const,
        taxableEvent: false,
        taxableAmountUSD: 0,
        holdingPeriod: 'N/A' as const,
        taxDeductible: false,
        irsCategoryNote: 'Borrower-approved sovereign loan principal disbursement.',
      },
      status: 'Settled' as const,
      clearingNode: 'Sovereign Inter-Bank Clearing Node #04',
      cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
      signature: `SIG-LOAN-${Math.floor(100000 + Math.random() * 900000)}`,
    };
    recordLedgerTransaction(userId, borrowerLedgerItem);
    recordLedgerTransaction(lenderKey, {
      ...borrowerLedgerItem,
      id: `rec-loan-acc-out-${Date.now()}`,
      type: 'loan_issued' as const,
      netAmountUSD: -loan.amount,
      title: `Loan Offer Approved by ${loan.borrowerHandle}`,
      description: `${loan.borrowerHandle} approved your Loan Offer of ${loan.amount.toLocaleString()} ${coinSym} at ${loan.interestRate}% APR.`,
      sourceOrDestination: `Clearing Bank Vault (${loan.lenderHandle})`,
      counterpartyOrIssuer: loan.borrowerHandle,
    });

    enqueueUserNotification([loan.lenderId, loan.lenderHandle.replace(/^@/, '')], {
      title: '✅ Loan Offer Approved',
      description: `${currentUser?.name || loan.borrowerHandle} approved your ${loan.amount.toLocaleString()} ${coinSym} Loan Offer.`,
      type: 'loans',
      targetTab: 'subsidies',
      amount: loan.amount,
      currency: coinSym,
    });

    showToast(`Approved Loan Offer of ${loan.amount.toLocaleString()} ${coinSym} from ${loan.lenderName || loan.lenderHandle}! Funds credited to your Final Wallet.`);
    addNotification({
      title: '💰 Loan Offer Approved & Credited',
      description: `Accepted ${loan.amount.toLocaleString()} ${coinSym} loan from ${loan.lenderName || loan.lenderHandle}. Next due in ${Math.min(30, loan.termDays)} days.`,
      type: 'loans',
      targetTab: 'subsidies',
      amount: loan.amount,
      currency: coinSym,
    });
    reloadLoans();
  };

  const handleDeclineLoanOffer = (loan: LoanRecord) => {
    declineLoanOffer(loan.id);
    enqueueUserNotification([loan.lenderId, loan.lenderHandle.replace(/^@/, '')], {
      title: 'Loan Offer Declined',
      description: `${currentUser?.name || loan.borrowerHandle} declined your ${loan.amount.toLocaleString()} ${loan.coinSymbol} Loan Offer.`,
      type: 'loans',
      targetTab: 'subsidies',
    });
    showToast(`Declined Loan Offer from ${loan.lenderName || loan.lenderHandle}.`);
    reloadLoans();
  };

  const handlePayAheadLoan = async (loan: LoanRecord, customAmount?: number) => {
    const remaining = getLoanRemainingBalance(loan);
    if (remaining <= 0) {
      showToast('This loan is already fully paid.');
      return;
    }

    const rawPayAmount = customAmount !== undefined ? customAmount : remaining;
    if (isNaN(rawPayAmount) || rawPayAmount <= 0) {
      showToast('Please enter a valid positive payment amount.');
      return;
    }

    const payAmount = Math.min(remaining, Math.round(rawPayAmount * 100) / 100);
    const coinSym = (loan.coinSymbol || 'AFNL').toUpperCase();
    const wallet = getStoredUserWallets(userId);

    const finalCoinIdx = wallet.finalCoins.findIndex((c) => c.symbol.toUpperCase() === coinSym);
    const stableCoinIdx = wallet.stableCoins.findIndex((c) => c.symbol.toUpperCase() === coinSym);

    let currentBal = 0;
    if (finalCoinIdx >= 0) currentBal = wallet.finalCoins[finalCoinIdx].balance;
    else if (stableCoinIdx >= 0) currentBal = wallet.stableCoins[stableCoinIdx].balance;

    if (currentBal < payAmount) {
      showToast(`Insufficient ${coinSym} balance. You need ${payAmount.toLocaleString()} ${coinSym}.`);
      return;
    }

    if (finalCoinIdx >= 0) {
      wallet.finalCoins[finalCoinIdx].balance = Math.round((wallet.finalCoins[finalCoinIdx].balance - payAmount) * 100) / 100;
    } else if (stableCoinIdx >= 0) {
      wallet.stableCoins[stableCoinIdx].balance = Math.round((wallet.stableCoins[stableCoinIdx].balance - payAmount) * 100) / 100;
    }
    saveStoredUserWallets(userId, wallet);
    window.dispatchEvent(new Event('final_finance_wallets_updated'));

    const lenderKey = loan.lenderId || loan.lenderHandle?.replace(/^@/, '') || '';
    if (lenderKey) {
      const lenderWallet = getStoredUserWallets(lenderKey);
      const lFinalIdx = lenderWallet.finalCoins.findIndex((c) => c.symbol.toUpperCase() === coinSym);
      const lStableIdx = lenderWallet.stableCoins.findIndex((c) => c.symbol.toUpperCase() === coinSym);
      if (lFinalIdx >= 0) {
        lenderWallet.finalCoins[lFinalIdx].balance = Math.round((lenderWallet.finalCoins[lFinalIdx].balance + payAmount) * 100) / 100;
      } else if (lStableIdx >= 0) {
        lenderWallet.stableCoins[lStableIdx].balance = Math.round((lenderWallet.stableCoins[lStableIdx].balance + payAmount) * 100) / 100;
      }
      saveStoredUserWallets(lenderKey, lenderWallet);
    }

    const prevPaidBefore = loan.amountPaid || 0;
    const prevPrincipalPaid = Math.min(loan.amount || 0, prevPaidBefore);
    const nextPrincipalPaid = Math.min(loan.amount || 0, prevPaidBefore + payAmount);
    const principalRetired = Math.max(0, Math.round((nextPrincipalPaid - prevPrincipalPaid) * 100) / 100);
    if (principalRetired > 0) {
      syncFinalCoinCirculationDelta(coinSym, -principalRetired);
    }

    const { fullyPaid } = payAheadLoan(loan.id, payAmount);
    setPayAheadInputs((prev) => ({ ...prev, [loan.id]: '' }));

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-REPAY-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

    const repayItemOut = {
      id: `rec-repay-out-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'loan_repaid' as const,
      category: 'loan' as const,
      mode: coinSym === 'AFNL' ? 'final_coin' as const : 'stable_coin' as const,
      title: fullyPaid ? `Loan Repaid to ${loan.lenderHandle}` : `Early Loan Payment Ahead to ${loan.lenderHandle}`,
      description: `${fullyPaid ? 'Fully repaid' : 'Paid ahead'} ${payAmount.toLocaleString()} ${coinSym} toward loan from ${loan.lenderHandle}.`,
      amountUSD: payAmount,
      feeUSD: 0.00,
      netAmountUSD: -payAmount,
      sourceOrDestination: loan.lenderHandle,
      counterpartyOrIssuer: `User Wallet (@${currentUser?.handle || currentUser?.id || 'wallet'})`,
      paymentCoinSymbol: coinSym,
      paymentCoinAmount: payAmount,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer' as const,
        taxableEvent: false,
        taxableAmountUSD: 0,
        holdingPeriod: 'N/A' as const,
        taxDeductible: false,
        irsCategoryNote: 'Sovereign loan payment out.'
      },
      status: 'Settled' as const,
      clearingNode: 'Sovereign Clearing Node #01',
      cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
      signature: `SIG-REPAY-${Math.floor(100000 + Math.random() * 900000)}`
    };
    recordLedgerTransaction(userId, repayItemOut);

    if (lenderKey) {
      const repayItemIn = {
        ...repayItemOut,
        id: `rec-repay-in-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        netAmountUSD: payAmount,
        title: fullyPaid ? `Loan Repayment Received from ${loan.borrowerHandle}` : `Early Loan Payment Received from ${loan.borrowerHandle}`,
        description: `Received ${payAmount.toLocaleString()} ${coinSym} from ${loan.borrowerHandle}.`,
        sourceOrDestination: loan.borrowerHandle,
        counterpartyOrIssuer: `Clearing Bank Vault (@${lenderKey})`,
        taxClassification: { ...repayItemOut.taxClassification, irsCategoryNote: 'Sovereign loan payment in.' }
      };
      recordLedgerTransaction(lenderKey, repayItemIn);
    }

    showToast(
      fullyPaid
        ? `Loan of ${loan.amount.toLocaleString()} ${coinSym} fully paid ahead & settled!`
        : `Paid ahead ${payAmount.toLocaleString()} ${coinSym}! Next due date extended.`
    );
    addNotification({
      title: fullyPaid ? 'Loan Successfully Repaid' : 'Early Loan Payment Applied',
      description: fullyPaid
        ? `Your loan of ${loan.amount.toLocaleString()} ${coinSym} has been fully settled and repaid.`
        : `Paid ${payAmount.toLocaleString()} ${coinSym} ahead of due date toward your loan from ${loan.lenderHandle}.`,
      type: 'loans',
      targetTab: 'subsidies',
    });
    reloadLoans();
  };

  const handleDefaultLoan = async (loan: any) => {
    const now = Date.now();
    const dueDateMs = loan.issuedAtMs + (loan.termDays * 24 * 60 * 60 * 1000);
    
    if (now < dueDateMs) {
      const daysLeft = Math.ceil((dueDateMs - now) / (24 * 60 * 60 * 1000));
      showToast(`Cannot declare default yet. This loan is not due for another ${daysLeft} days.`);
      return;
    }

    const m = await import('../services/loanService');
    m.updateLoanStatus(loan.id, 'defaulted');
    
    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-DEFAULT-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

    const defaultItem = {
        id: `rec-default-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        receiptNumber: recNum,
        taxYear: 2026,
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'loan_written_off' as const,
        category: 'loan' as const,
        mode: loan.coinSymbol === 'AFNL' ? 'final_coin' as const : 'stable_coin' as const,
        title: `Loan Default Declared for ${loan.borrowerHandle}`,
        description: `Bad debt write-off for defaulted loan of ${loan.amount.toLocaleString()} ${loan.coinSymbol} by ${loan.borrowerHandle}.`,
        amountUSD: loan.amount,
        feeUSD: 0.00,
        netAmountUSD: -loan.amount,
        sourceOrDestination: loan.borrowerHandle,
        counterpartyOrIssuer: `Clearing Bank Vault (@${currentUser?.handle || 'bank'})`,
        paymentCoinSymbol: loan.coinSymbol,
        paymentCoinAmount: loan.amount,
        taxClassification: {
            formMapping: 'Schedule C / Business Expense' as const,
            taxableEvent: true,
            taxableAmountUSD: -loan.amount,
            holdingPeriod: 'N/A' as const,
            taxDeductible: true,
            irsCategoryNote: 'Bad debt write-off for uncollectible sovereign loan.'
        },
        status: 'Settled' as const,
        clearingNode: 'Sovereign Clearing Node #01',
        cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
        signature: `SIG-DEF-${Math.floor(100000 + Math.random() * 900000)}`
    };

    recordLedgerTransaction(userId, defaultItem);
    
    const defaultItemBorrower = { ...defaultItem, 
        id: `rec-default-borrower-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        type: 'loan_defaulted' as const,
        netAmountUSD: 0,
        title: `Loan Defaulted to ${loan.lenderHandle}`,
        description: `Failed to repay loan of ${loan.amount.toLocaleString()} ${loan.coinSymbol} to ${loan.lenderHandle}.`,
        sourceOrDestination: loan.lenderHandle,
        counterpartyOrIssuer: `User Wallet (@${loan.borrowerId})`,
        taxClassification: { ...defaultItem.taxClassification, formMapping: 'Non-Taxable Transfer' as const, taxableEvent: false, taxDeductible: false, irsCategoryNote: 'Loan defaulted' }
    };
    recordLedgerTransaction(loan.borrowerId, defaultItemBorrower);

    showToast(`Loan to ${loan.borrowerHandle} declared defaulted.`);
    addNotification({
      title: '⚠️ Sovereign Loan Declared Defaulted',
      description: `Loan of ${loan.amount.toLocaleString()} ${loan.coinSymbol} to ${loan.borrowerHandle} recorded as bad debt write-off in Tax Ledger.`,
      type: 'loans',
      targetTab: 'dash_ledger',
    });
    reloadLoans();
  };

  const handleApplyForBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!institutionName.trim()) {
      showToast('Please enter your institution or bank name.');
      return;
    }
    const nextStatus: 'pending' | 'approved' = isAdmin ? 'approved' : 'pending';
    setBankAppStatus(nextStatus);
    localStorage.setItem(`ff_bank_app_status_${userId}`, nextStatus);
    localStorage.setItem(`ff_bank_app_name_${userId}`, institutionName.trim());
    if (currentUser?.uid) {
      localStorage.setItem(`ff_bank_app_status_${currentUser.uid}`, nextStatus);
      localStorage.setItem(`ff_bank_app_name_${currentUser.uid}`, institutionName.trim());
    }
    try {
      const existingRaw = localStorage.getItem('ff_admin_banking_requests');
      const existingReqs = existingRaw ? JSON.parse(existingRaw) : [];
      const ownedSummary = walletData.finalCoins
        .filter((c) => c.balance > 0)
        .map((c) => `${c.balance.toLocaleString()} ${c.symbol}`)
        .slice(0, 4)
        .join(', ');
      const newBankReq = {
        id: `bank-req-${Date.now()}`,
        institutionName: institutionName.trim(),
        userHandle: `@${(currentUser?.handle || userId).replace(/^@/, '')}`,
        userId,
        uid: currentUser?.uid,
        capitalReserves: ownedSummary ? `Final Wallet: ${ownedSummary}` : 'Final Wallet Balances Only',
        reason: institutionReason.trim() || 'Inter-bank Final Coin lending and liquidity operations.',
        status: nextStatus,
        submittedAt: isAdmin ? 'Auto-Approved (Admin)' : 'Just now',
      };
      const filtered = Array.isArray(existingReqs)
        ? existingReqs.filter((r: any) => r.userId !== userId)
        : [];
      localStorage.setItem('ff_admin_banking_requests', JSON.stringify([newBankReq, ...filtered]));
    } catch {
      // ignore storage errors
    }
    window.dispatchEvent(new Event('final_finance_bank_status_updated'));
    if (isAdmin) {
      showToast('Clearing Bank Activated Automatically (Admin Privilege)!');
      addNotification({
        title: '🏛️ Sovereign Bank Charter Activated',
        description: `Your Clearing Bank "${institutionName.trim()}" is automatically active and authorized to issue Final Coin loans.`,
        type: 'loans',
        targetTab: 'subsidies',
      });
    } else {
      showToast('Bank Application Submitted for Review.');
      addNotification({
        title: '🏛️ Sovereign Bank Charter Submitted',
        description: `Application for "${institutionName.trim()}" submitted to Protocol Admins for authorization.`,
        type: 'loans',
        targetTab: 'subsidies',
      });
    }
    setBankModalOpen(false);
  };

  const handleCancelBankApp = () => {
    setBankAppStatus('none');
    localStorage.removeItem(`ff_bank_app_status_${userId}`);
    localStorage.removeItem(`ff_bank_app_name_${userId}`);
    if (currentUser?.uid) {
      localStorage.removeItem(`ff_bank_app_status_${currentUser.uid}`);
      localStorage.removeItem(`ff_bank_app_name_${currentUser.uid}`);
    }
    window.dispatchEvent(new Event('final_finance_bank_status_updated'));
    showToast('Banking Application Cancelled.');
    addNotification({
      title: 'Banking Charter Application Cancelled',
      description: 'Your pending internal banking charter request has been withdrawn.',
      type: 'loans',
      targetTab: 'subsidies',
    });
  };

  const handleIssueLoan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (bankAppStatus !== 'approved') {
      showToast('You must be approved to operate as a Clearing Bank by Admin before issuing loans.');
      return;
    }
    const amt = parseFloat(loanAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast('Please enter a valid loan amount.');
      return;
    }
    if (!borrowerHandle.trim() || borrowerHandle.trim() === '@') {
      showToast('Please enter a borrower handle.');
      return;
    }

    if (ownedFinalCoinsForLoan.length === 0) {
      showToast('You do not hold any Final Currency balances in your Final Wallet to loan out.');
      return;
    }

    const heldCoin = ownedFinalCoinsForLoan.find((c) => c.symbol === loanSymbol);
    if (!heldCoin) {
      showToast('You can only loan out a Final Currency that you currently hold in your Final Wallet.');
      return;
    }

    const availableCoinBal = getWalletCurrencyBalance(userId, loanSymbol);
    if (availableCoinBal <= 0 || availableCoinBal < amt) {
      showToast(`Insufficient ${loanSymbol} balance in your Final Wallet. Max loanable: ${availableCoinBal.toLocaleString()} ${loanSymbol}.`);
      return;
    }

    const cleanBorrowerHandle = borrowerHandle.trim().replace(/^@/, '');
    const bh = `@${cleanBorrowerHandle}`;
    const borrowerProfile = await getUserProfile(cleanBorrowerHandle);
    const parsedApr = parseFloat(loanInterest) || 0;
    const parsedTerm = parseInt(loanTermDays, 10) || 30;
    const monthlyInstallment = calculateMonthlyInstallment(amt, parsedApr, parsedTerm);

    const m = await import('../services/loanService');
    const now = Date.now();
    const newLoan: LoanRecord = {
      id: `loan-offer-${now}`,
      lenderId: userId,
      lenderHandle: currentUser?.handle || `@${userId}`,
      lenderName: currentUser?.name || currentUser?.handle || userId,
      lenderAvatar: currentUser?.avatarUrl,
      borrowerId: borrowerProfile?.uid || cleanBorrowerHandle,
      borrowerHandle: borrowerProfile?.userId ? `@${borrowerProfile.userId}` : bh,
      borrowerName: borrowerProfile?.name || cleanBorrowerHandle,
      borrowerAvatar: borrowerProfile?.avatarUrl,
      amount: amt,
      coinSymbol: loanSymbol,
      interestRate: parsedApr,
      termDays: parsedTerm,
      monthlyInstallment,
      status: 'pending_offer',
      timestamp: new Date(now).toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      issuedAtMs: now,
      nextDueDateMs: now + Math.min(30, parsedTerm) * 24 * 60 * 60 * 1000,
      amountPaid: 0,
    };

    m.createLoan(newLoan);
    reloadLoans();

    enqueueUserNotification([borrowerProfile?.uid || cleanBorrowerHandle, cleanBorrowerHandle], {
      title: '🏦 New Loan Offer Awaiting Approval',
      description: `${currentUser?.name || newLoan.lenderHandle} sent you a Loan Offer of ${amt.toLocaleString()} ${loanSymbol} (${parsedApr}% APR, est. ${monthlyInstallment.toLocaleString()} ${loanSymbol}/mo). Review in Internal Banking → Loan Offers.`,
      type: 'loans',
      targetTab: 'subsidies',
      amount: amt,
      currency: loanSymbol,
    });

    setLoanModalOpen(false);
    setBorrowerHandle('@');
    setLoanAmount('1000');
    setLoanCoinSearch('');
    showToast(`Loan Offer of ${amt.toLocaleString()} ${loanSymbol} sent to ${bh} for final approval!`);
    addNotification({
      title: `🏦 Loan Offer Sent (${amt.toLocaleString()} ${loanSymbol})`,
      description: `Sent ${amt.toLocaleString()} ${loanSymbol} offer to ${bh} at ${parsedApr}% APR (${monthlyInstallment.toLocaleString()} ${loanSymbol}/mo). Pending borrower approval.`,
      type: 'loans',
      targetTab: 'subsidies',
      amount: amt,
      currency: loanSymbol,
    });
  };

  // Timestamp-based robust accrual logic (0.1 AFNL every 1 minute) persistent across page navigation
  // ONLY ticks and accrues when isVerified (Tier 1+) AND isUbiStreamActive are both true!
  useEffect(() => {
    if (!isVerified || !isUbiStreamActive) {
      setSecondsRemaining(60);
      return;
    }

    if (!localStorage.getItem(`ff_last_accrual_ts_${userId}`)) {
      localStorage.setItem(`ff_last_accrual_ts_${userId}`, Date.now().toString());
    }

    const interval = setInterval(() => {
      const now = Date.now();
      const lastTs = parseInt(localStorage.getItem(`ff_last_accrual_ts_${userId}`) || now.toString(), 10);
      const elapsedSeconds = Math.floor((now - lastTs) / 1000);

      if (elapsedSeconds >= 60) {
        const completedMinutes = Math.floor(elapsedSeconds / 60);
        const remainingSeconds = elapsedSeconds % 60;

        const newLastTs = now - (remainingSeconds * 1000);
        localStorage.setItem(`ff_last_accrual_ts_${userId}`, newLastTs.toString());

        // Add accrualRate per completed minute
        setUnclaimedAccruedAFNL(curr => {
          const added = completedMinutes * accrualRate;
          const updated = Math.round((curr + added) * 100) / 100;
          localStorage.setItem(`ff_unclaimed_accrued_${userId}`, updated.toString());
          return updated;
        });

        setSecondsRemaining(60 - remainingSeconds);
      } else {
        setSecondsRemaining(60 - elapsedSeconds);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [userId, isVerified, isUbiStreamActive, accrualRate]);

  // Claim 4,000 AFNL Signup Grant into deposit pool (One-time only, requires Tier 1 verification)
  const handleClaimSignupGrant = () => {
    if (!isVerified) {
      const errMsg = 'You cannot claim the 4,000 AFNL Grant without Tier 1 verification. Per community rules, 1 Verified Legal ID (Driver\'s License, Passport, or National ID) is required to unlock your one-time 4,000 AFNL economic grant.';
      setTierErrorModal({
        title: 'Tier 1 Verification Required',
        message: errMsg,
        requiredTier: 1,
        actionLabel: 'Verify Tier 1 (1 Legal ID)'
      });
      showToast('Error: Tier 1 Verification required to claim the 4,000 AFNL Grant.');
      addToast({
        type: 'error',
        title: 'Tier 1 Verification Required',
        message: errMsg,
      });
      return;
    }

    if (signupStatus === 'deposited' || signupStatus === 'claimed_to_pool') {
      showToast('Signup grant is a one-time bonus and has already been claimed.');
      return;
    }

    setSignupStatus('claimed_to_pool');
    localStorage.setItem(`ff_signup_status_${userId}`, 'claimed_to_pool');
    showToast('Successfully added your one-time 4,000 Final Admin Coins (AFNL) signup grant to your deposit pool!');
    addNotification({
      title: 'One-Time Signup Grant Claimed',
      description: 'Successfully claimed your one-time 4,000 AFNL protocol bonus to your deposit pool.',
      type: 'vault',
      targetTab: 'subsidies',
    });
  };

  // Per-minute UBI accrual runs automatically once Tier 1+ verified (cannot be paused)

  // Claim Unclaimed Accrued Subsidy into deposit pool (requires verification)
  const handleClaimAccrued = () => {
    if (!isVerified) {
      const errMsg = 'You must complete Tier 1 Verification (at least 1 form of Legal ID) before claiming subsidies.';
      setTierErrorModal({
        title: 'Tier 1 Verification Required',
        message: errMsg,
        requiredTier: 1,
        actionLabel: 'Verify Tier 1 (1 Legal ID)'
      });
      showToast(errMsg);
      addToast({ type: 'error', title: 'Tier 1 Verification Required', message: errMsg });
      return;
    }

    if (unclaimedAccruedAFNL <= 0) {
      showToast('No accrued subsidy available to claim yet.');
      return;
    }

    const claimAmount = unclaimedAccruedAFNL;
    const newClaimed = Math.round((claimedAccruedAFNL + claimAmount) * 10) / 10;
    
    setClaimedAccruedAFNL(newClaimed);
    localStorage.setItem(`ff_claimed_accrued_${userId}`, newClaimed.toString());

    setUnclaimedAccruedAFNL(0);
    localStorage.setItem(`ff_unclaimed_accrued_${userId}`, '0');

    showToast(`Claimed +${claimAmount.toFixed(1)} AFNL accrued subsidy into your deposit pool!`);
    addNotification({
      title: 'Sovereign Subsidy Claimed',
      description: `Successfully claimed +${claimAmount.toFixed(1)} AFNL accrued subsidy into your deposit pool.`,
      type: 'vault',
      targetTab: 'subsidies',
    });
  };

  // Total claimable AFNL waiting to be deposited
  const totalClaimableAFNL = (signupStatus === 'claimed_to_pool' ? 4000 : 0) + claimedAccruedAFNL;

  // Deposit AFNL into Final Wallet (requires verification)
  const handleDepositToFinalWallet = () => {
    if (!isVerified) {
      const errMsg = 'You must complete Tier 1 Verification (at least 1 Verified Legal ID) in Settings before depositing AFNL into your Final Wallet.';
      setTierErrorModal({
        title: 'Tier 1 Verification Required',
        message: errMsg,
        requiredTier: 1,
        actionLabel: 'Verify Tier 1 (1 Legal ID)'
      });
      showToast(errMsg);
      addToast({ type: 'error', title: 'Tier 1 Verification Required', message: errMsg });
      return;
    }

    if (totalClaimableAFNL <= 0) {
      showToast('No AFNL coins available in your deposit pool to deposit.');
      return;
    }

    try {
      const wallet = getStoredUserWallets(userId);
      const afnlIndex = wallet.finalCoins.findIndex(c => c.symbol === 'AFNL');

      if (afnlIndex >= 0) {
        wallet.finalCoins[afnlIndex].balance += totalClaimableAFNL;
      } else {
        wallet.finalCoins.unshift({
          id: 'fc-admin-subsidy-signup',
          name: 'Final Admin Coin',
          symbol: 'AFNL',
          balance: totalClaimableAFNL,
          unitPriceUSD: 28.75,
          change24h: 3.84,
          utility: 'Initial 4000 AFNL signup grant & continuous 0.1 AFNL/min (~4,000/mo) subsidy accrual.'
        });
      }

      saveStoredUserWallets(userId, wallet);
      setWalletData(wallet);
      syncFinalCoinCirculationDelta('AFNL', totalClaimableAFNL, { adjustTotalSupplyIfNeeded: true });
      window.dispatchEvent(new Event('final_finance_wallets_updated'));

      if (signupStatus === 'claimed_to_pool') {
        setSignupStatus('deposited');
        localStorage.setItem(`ff_signup_status_${userId}`, 'deposited');
      }

      setClaimedAccruedAFNL(0);
      localStorage.setItem(`ff_claimed_accrued_${userId}`, '0');

      // Record in Universal Ledger
      const totalAmountUSD = totalClaimableAFNL * 28.75;
      const isSignup = signupStatus === 'claimed_to_pool';
      const ledgerItem = createLedgerItemFromGrantClaim({
        grantName: isSignup ? 'One-Time Sovereign Signup Grant' : 'Sovereign Community Subsidy Accrual',
        amountAFNL: totalClaimableAFNL,
        amountUSD: totalAmountUSD,
        isSignup
      });
      recordLedgerTransaction(userId, ledgerItem);

      showToast(`Successfully deposited AFNL into your Final Wallet!`);
      addNotification({
        title: `🏛️ Grant Deposited (+${totalClaimableAFNL.toLocaleString()} AFNL)`,
        description: `Transferred ${totalClaimableAFNL.toLocaleString()} AFNL ($${totalAmountUSD.toLocaleString(undefined, { maximumFractionDigits: 2 })}) into your Final Wallet and Tax Ledger.`,
        type: 'subsidies',
        targetTab: 'dash_ledger',
        amount: totalClaimableAFNL,
        currency: 'AFNL',
      });
    } catch (err) {
      console.warn('Failed to deposit AFNL to wallet', err);
      showToast('Error depositing AFNL to Final Wallet.');
    }
  };

  const afnlCoin = walletData.finalCoins.find(c => c.symbol === 'AFNL') || {
    balance: 0,
    unitPriceUSD: 28.75
  };

  // Grant Requests state
  const [grantRequests, setGrantRequests] = useState<Array<{
    id: string;
    name: string;
    description: string;
    amountAFNL: number;
    status: 'Pending' | 'Approved' | 'Cancelled';
    date: string;
    mediaAttachments?: Array<{ type: 'image' | 'video'; url: string; name: string }>;
  }>>(() => {
    try {
      const saved = localStorage.getItem(`ff_grant_requests_${userId}`);
      return saved ? JSON.parse(saved) : [
        {
          id: 'req-1',
          name: 'Greenfield Node Subsidy',
          description: 'Sovereign validator node expansion and community liquidity support.',
          amountAFNL: 15000,
          status: 'Approved',
          date: '2026-08-20',
          mediaAttachments: [
            { type: 'image', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80', name: 'validator_architecture.png' }
          ]
        }
      ];
    } catch {
      return [];
    }
  });

  const [reqName, setReqName] = useState('');
  const [reqDesc, setReqDesc] = useState('');
  const [reqAmount, setReqAmount] = useState('');
  const [reqMedia, setReqMedia] = useState<Array<{ type: 'image' | 'video'; url: string; name: string }>>([]);
  const [requestFilter, setRequestFilter] = useState<'All' | 'Pending' | 'Approved' | 'Cancelled'>('All');

  const handleCancelRequest = (id: string) => {
    const updated = grantRequests.map(req => req.id === id ? { ...req, status: 'Cancelled' as const } : req);
    setGrantRequests(updated);
    localStorage.setItem(`ff_grant_requests_${userId}`, JSON.stringify(updated));
    showToast('Grant request cancelled successfully.');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const newItems: Array<{ type: 'image' | 'video'; url: string; name: string }> = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isVideo = file.type.startsWith('video/');
      const url = URL.createObjectURL(file);
      newItems.push({
        type: isVideo ? 'video' : 'image',
        url,
        name: file.name
      });
    }
    setReqMedia([...reqMedia, ...newItems]);
    showToast(`Attached ${newItems.length} media file(s).`);
  };

  const handleAddSampleMedia = (type: 'image' | 'video') => {
    if (type === 'image') {
      setReqMedia([
        ...reqMedia,
        {
          type: 'image',
          url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=600&auto=format&fit=crop&q=80',
          name: 'project_blueprint_preview.png'
        }
      ]);
    } else {
      setReqMedia([
        ...reqMedia,
        {
          type: 'video',
          url: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-and-numbers-31936-large.mp4',
          name: 'node_demo_walkthrough.mp4'
        }
      ]);
    }
    showToast(`Added sample ${type} attachment.`);
  };

  const handleRemoveMedia = (index: number) => {
    setReqMedia(reqMedia.filter((_, i) => i !== index));
  };

  const handleSendGrantRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin && !isVerified) {
      showToast('You must be verified with ID in Settings before submitting grant requests to admin.');
      return;
    }
    if (!reqName.trim() || !reqDesc.trim() || !reqAmount) {
      showToast('Please provide grant name, description, and requested AFNL amount.');
      return;
    }
    const amountNum = parseFloat(reqAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      showToast('Please enter a valid positive number for Final Admin Coins (AFNL).');
      return;
    }

    const cleanName = reqName.trim();
    const cleanDesc = reqDesc.trim();
    const todayStr = new Date().toISOString().split('T')[0];

    if (isAdmin) {
      const creditRes = applyCurrencyWalletDelta({
        userId,
        currencySymbol: 'AFNL',
        delta: amountNum,
        utilityNote: `Admin Self-Granted Grant / Subsidy: ${cleanName}`,
      });
      setWalletData(creditRes.wallet);
      syncFinalCoinCirculationDelta('AFNL', amountNum, { adjustTotalSupplyIfNeeded: true });
      window.dispatchEvent(new Event('final_finance_wallets_updated'));

      const amountUSD = amountNum * 28.75;
      const ledgerItem = createLedgerItemFromGrantClaim({
        grantName: `Admin Self-Grant: ${cleanName}`,
        amountAFNL: amountNum,
        amountUSD,
        isSignup: false,
      });
      recordLedgerTransaction(userId, ledgerItem);

      const newReq = {
        id: 'req-' + Date.now(),
        name: cleanName,
        description: cleanDesc,
        amountAFNL: amountNum,
        status: 'Approved' as const,
        date: todayStr,
        mediaAttachments: reqMedia.length > 0 ? reqMedia : undefined,
      };
      const updated = [newReq, ...grantRequests];
      setGrantRequests(updated);
      localStorage.setItem(`ff_grant_requests_${userId}`, JSON.stringify(updated));

      const adminHandleRaw = (currentUser?.handle || currentUser?.id || userId).replace(/^@/, '');
      const adminHandleDisplay = `@${adminHandleRaw}`;
      recordAdminSelfGrant({
        adminId: userId,
        adminUid: currentUser?.uid,
        adminName: currentUser?.name || adminHandleRaw,
        adminHandle: adminHandleDisplay,
        adminEmail: currentUser?.email || '',
        adminRole: currentUser?.role === 'super_admin' ? 'super_admin' : 'admin',
        grantName: cleanName,
        description: cleanDesc,
        amountAFNL: amountNum,
        date: todayStr,
        mediaAttachments: reqMedia.length > 0 ? reqMedia : undefined,
      });

      // Notify Super Admin of all grants & subsidies granted by Admins to themselves
      enqueueUserNotification(
        ['super_admin_ranma', 'demo-super-admin', 'demo-ranma-superadmin', 'ranmaanimaker@gmail.com'],
        {
          title: '🏛️ Admin Self-Grant Issued',
          description: `${currentUser?.name || 'Admin'} (${adminHandleDisplay}) granted themselves ${amountNum.toLocaleString()} AFNL for "${cleanName}".`,
          type: 'subsidies',
          targetTab: 'superadmin',
          targetId: 'grants_subsidies',
          amount: amountNum,
          currency: 'AFNL',
        }
      );

      showToast(`Self-granted ${amountNum.toLocaleString()} AFNL ("${cleanName}") to your Final Wallet and notified Super Admin!`);
      setReqName('');
      setReqDesc('');
      setReqAmount('');
      setReqMedia([]);
      return;
    }

    const newReq = {
      id: 'req-' + Date.now(),
      name: cleanName,
      description: cleanDesc,
      amountAFNL: amountNum,
      status: 'Pending' as const,
      date: todayStr,
      mediaAttachments: reqMedia.length > 0 ? reqMedia : undefined
    };

    const updated = [newReq, ...grantRequests];
    setGrantRequests(updated);
    localStorage.setItem(`ff_grant_requests_${userId}`, JSON.stringify(updated));

    showToast(`Successfully sent grant request for ${amountNum.toLocaleString()} AFNL with ${reqMedia.length} attachment(s) to Admin!`);
    setReqName('');
    setReqDesc('');
    setReqAmount('');
    setReqMedia([]);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 pt-1 pb-8 space-y-3 text-center">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-3 text-xs font-medium animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Horizontal Sub-Tabs: UBI | Grants & Subsidies | Internal Banking */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 border-b border-slate-200 pb-2 max-w-full">
        <button
          type="button"
          onClick={() => setActiveSubTab('ubi')}
          className={`px-3 sm:px-4 py-1.5 rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer inline-flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeSubTab === 'ubi'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Coins className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
          <span>UBI</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('grants')}
          className={`px-3 sm:px-4 py-1.5 rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer inline-flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeSubTab === 'grants'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <FileCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
          <span>Grants &amp; Subsidies</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('banking')}
          className={`px-3 sm:px-4 py-1.5 rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer inline-flex items-center justify-center gap-1.5 whitespace-nowrap ${
            activeSubTab === 'banking'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Wallet className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
          <span>Internal Banking</span>
        </button>
      </div>

      {/* Top Header (Compact) */}
      <div className="flex flex-col items-center justify-center text-center gap-2 pb-3 border-b border-slate-200">
        <div className="inline-flex items-center justify-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 border border-amber-200/80 flex items-center justify-center shadow-xs shrink-0">
            <Coins className="w-5 h-5" />
          </div>
          <h1 className="font-serif font-bold text-slate-900 text-xl sm:text-2xl whitespace-nowrap">
            {activeSubTab === 'ubi' ? 'Universal Basic Income' : activeSubTab === 'grants' ? 'Grants & Subsidies' : 'Internal Banking'}
          </h1>
        </div>

        {/* Status Badge (UBI / Grants show Tier 1 AFNL eligibility; Internal Banking shows Bank Charter & AFNL Loan eligibility) */}
        {activeSubTab === 'banking' ? (
          <div className={`px-3.5 py-1.5 rounded-2xl border text-xs font-semibold inline-flex items-center justify-center gap-2 ${
            bankAppStatus === 'approved'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : bankAppStatus === 'pending'
              ? 'bg-amber-50 text-amber-800 border-amber-200'
              : 'bg-sky-50 text-sky-900 border-sky-200'
          }`}>
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>
              {bankAppStatus === 'approved'
                ? 'Approved Clearing Bank · Issue & Receive Final Coin Loans'
                : bankAppStatus === 'pending'
                ? 'Bank Approval Pending · Eligible to Receive AFNL Loans'
                : 'Peer-to-Peer AFNL Loans Open · Apply for Bank License to Lend'}
            </span>
          </div>
        ) : (
          <div className={`px-3.5 py-1.5 rounded-2xl border text-xs font-semibold inline-flex items-center justify-center gap-2 ${
            isVerified 
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
              : 'bg-amber-50 text-amber-800 border-amber-200'
          }`}>
            {isAdmin ? (
              <>
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Admin Privilege · Tier Verification Exempt · Full AFNL Access</span>
              </>
            ) : isVerified ? (
              <>
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>{getTierBadgeLabel(userTier)} · AFNL Eligible</span>
              </>
            ) : (
              <>
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>{isSignedIn ? 'Tier 1 Verification Required' : 'Account & Tier 1 Verification Required'}</span>
              </>
            )}
          </div>
        )}
      </div>

      {/* Tab 1: UBI View */}
      {activeSubTab === 'ubi' && (
        <div className="space-y-6 text-center">
          {/* Verification Notice Banner if Tier 0 (Strictly ONLY under UBI tab) */}
          {!isVerified && (
            <div className="bg-amber-50 border border-amber-200/90 rounded-3xl p-6 text-amber-900 space-y-3 text-center">
              <div className="flex flex-col items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center shrink-0 text-amber-700">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="space-y-1 max-w-xl mx-auto">
                  <h2 className="text-sm font-bold text-amber-950">Tier 1 Verification (1 Legal ID) Required to Receive Admin Final Coins</h2>
                  <p className="text-xs text-amber-800 leading-relaxed">
                    Per sovereign protocol rules, you must complete at least Tier 1 Verification with 1 Legal ID (Driver&apos;s License, Passport, or National ID) before you are eligible to receive Admin Final Coins (AFNL) from the Admin, claim your 4,000 AFNL signup grant, start the Per-Minute Active UBI Stream, or deposit Final Admin Coins into your Final Wallet.
                  </p>
                </div>
              </div>
              <div className="pt-1 flex flex-wrap items-center justify-center gap-2.5">
                {onOpenVerification && (
                  <button
                    type="button"
                    onClick={onOpenVerification}
                    className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-2 cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Complete Tier 1 Verification (1 Legal ID)</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    if (onNavigateToSettings) onNavigateToSettings();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold transition-all shadow-2xs flex items-center gap-2 cursor-pointer"
                >
                  <span>Go to Verification Settings</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
          {/* 1. Initial 4,000 AFNL Signup Grant Card (One-time) */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-4">
            <div className="flex flex-col items-center justify-center text-center gap-4">
              <div className="space-y-1.5 flex flex-col items-center">
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider">
                    One-Time Signup Grant
                  </span>
                  <span className="text-[10px] font-mono text-emerald-700 font-medium flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Permanent Welcome Bonus
                  </span>
                </div>
                <h2 className="text-lg font-bold text-slate-900">4,000 Final Admin Coins (AFNL) Signup Grant</h2>
                <p className="text-xs text-slate-500 max-w-lg">
                  Exclusive one-time welcome grant upon registration. Claimable once into your deposit pool (requires verified ID).
                </p>
              </div>

              {!isVerified && (
                <div className="w-full max-w-md px-3.5 py-2 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center justify-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>Tier 1 Verification required to claim 4,000 AFNL Grant.</span>
                </div>
              )}

              <button
                type="button"
                disabled={signupStatus === 'deposited' || signupStatus === 'claimed_to_pool'}
                onClick={handleClaimSignupGrant}
                className={`px-6 py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-sm shrink-0 cursor-pointer ${
                  !isVerified
                    ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 shadow-rose-500/10'
                    : signupStatus === 'deposited'
                    ? 'bg-emerald-100 text-emerald-800 cursor-default border border-emerald-200'
                    : signupStatus === 'claimed_to_pool'
                    ? 'bg-blue-100 text-blue-800 cursor-default border border-blue-200'
                    : 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-600/20'
                }`}
              >
                {!isVerified ? (
                  <>
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>Claim 4,000 AFNL Grant (Tier 1 Required)</span>
                  </>
                ) : signupStatus === 'deposited' ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-700" />
                    <span>Already Deposited</span>
                  </>
                ) : signupStatus === 'claimed_to_pool' ? (
                  <>
                    <Check className="w-4 h-4 text-blue-700" />
                    <span>In Deposit Pool</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 text-amber-200" />
                    <span>Claim 4,000 AFNL Grant</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 2. Continuous Per-Minute Accrual Stream */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6">
            <div className="flex flex-col items-center justify-center text-center gap-4 pb-4 border-b border-slate-100">
              <div className="space-y-1.5 flex flex-col items-center">
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <span className={`text-[10px] font-mono font-bold px-2.5 py-1 rounded-md uppercase tracking-wider ${
                    !isVerified
                      ? 'bg-rose-100 text-rose-900 border border-rose-200'
                      : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                  }`}>
                    {!isVerified ? 'Stream Stopped (Tier 1 Required)' : 'Stream Live'}
                  </span>
                  <span className="text-[10px] font-mono font-medium text-slate-500">{accrualRate} AFNL / Minute</span>
                </div>
                <h2 className="text-lg font-bold text-slate-900">Per-Minute Active UBI Stream</h2>
              </div>

              {!isVerified && (
                <div className="w-full max-w-md px-3.5 py-2 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center justify-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>Stream will not start without Tier 1 Verification.</span>
                </div>
              )}
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-medium text-slate-600">
                <span>
                  {!isVerified
                    ? 'Stream Inactive · Tier 1 Verification Required to Start'
                    : `Next ${accrualRate} AFNL Unit Unlock in ${secondsRemaining}s`}
                </span>
                <span className="font-mono tabular-nums">
                  {!isVerified ? '0%' : `${Math.round(((60 - secondsRemaining) / 60) * 100)}%`}
                </span>
              </div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200/60">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ${
                    !isVerified ? 'bg-rose-300' : 'bg-amber-500'
                  }`}
                  style={{ width: `${!isVerified ? 0 : ((60 - secondsRemaining) / 60) * 100}%` }}
                />
              </div>
            </div>

            {/* Accrued Status Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-50/50 to-slate-50 border border-amber-200/60 flex flex-col items-center justify-center text-center gap-4">
              <div className="space-y-1 text-center">
                <div className="text-xs text-amber-900 font-medium">Unclaimed Accrued UBI</div>
                <div className="text-2xl font-serif font-bold text-slate-900 tabular-nums">
                  +{unclaimedAccruedAFNL.toFixed(2)} <span className="text-xs font-mono font-bold text-amber-700">AFNL</span>
                </div>
              </div>

              <button
                type="button"
                disabled={!isVerified || unclaimedAccruedAFNL <= 0}
                onClick={handleClaimAccrued}
                className={`px-6 py-3 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-sm ${
                  !isVerified
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : unclaimedAccruedAFNL > 0
                    ? 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-amber-600/20'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>{unclaimedAccruedAFNL > 0 ? `Claim +${unclaimedAccruedAFNL.toFixed(2)} AFNL to Pool` : 'Accumulating...'}</span>
              </button>
            </div>
          </div>

          {/* 3. Final Wallet Deposit Section */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 text-slate-900 space-y-6 shadow-sm text-center">
            <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 border border-amber-500/20 flex items-center justify-center">
                <Wallet className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base sm:text-lg text-slate-900 whitespace-nowrap">Final Wallet Deposit Vault</h3>
            </div>

            {/* Centered Ready to Deposit Box */}
            <div className="flex justify-center">
              <div className="w-full max-w-xs py-2.5 px-5 rounded-2xl bg-amber-50 border border-amber-200/90 text-amber-800 text-xs font-mono font-bold flex items-center justify-center gap-2 shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Ready to Deposit</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1 text-center">
                <div className="text-[11px] font-mono text-slate-500 uppercase tracking-wider">Total Claimable Deposit Pool</div>
                <div className="text-3xl font-mono font-bold text-amber-600 tabular-nums">
                  {totalClaimableAFNL.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 })} <span className="text-xs font-normal text-slate-500">AFNL</span>
                </div>
                <p className="text-[11px] text-slate-500 pt-1">
                  ({signupStatus === 'deposited' ? '4,000 grant already deposited' : signupStatus === 'claimed_to_pool' ? '4,000 grant in pool' : '4,000 one-time grant unclaimed'} + {claimedAccruedAFNL.toFixed(1)} claimed accrued)
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1 text-center">
                <div className="text-[11px] font-mono text-slate-500 uppercase tracking-wider">Current Final Wallet Balance</div>
                <div className="text-3xl font-mono font-bold text-slate-900 tabular-nums">
                  {typeof afnlCoin.balance === 'number' ? afnlCoin.balance.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 }) : '0.0'} <span className="text-xs font-normal text-slate-500">AFNL</span>
                </div>
                <p className="text-[11px] text-emerald-600 pt-1 flex items-center justify-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Synchronized with Final Wallet
                </p>
              </div>
            </div>

            <div className="pt-2 flex flex-col items-center justify-center">
              <button
                type="button"
                disabled={!isVerified || totalClaimableAFNL <= 0}
                onClick={handleDepositToFinalWallet}
                className={`w-full sm:w-auto min-w-[280px] px-8 py-4 rounded-2xl font-bold text-sm tracking-tight transition-all flex items-center justify-center gap-2.5 ${
                  !isVerified || totalClaimableAFNL <= 0
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    : 'bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 hover:from-amber-600 hover:via-amber-500 hover:to-amber-600 text-white hover:text-slate-950 cursor-pointer shadow-lg shadow-slate-900/15 hover:shadow-amber-500/25 active:scale-[0.99] border border-slate-800 hover:border-amber-400'
                }`}
              >
                <ArrowDownLeft className="w-4 h-4 shrink-0" />
                <span className="whitespace-nowrap">Deposit {totalClaimableAFNL > 0 ? `${totalClaimableAFNL.toFixed(1)} ` : ''}AFNL to Final Wallet</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Grants & Subsidies View */}
      {activeSubTab === 'grants' && (
        <div className="space-y-6 animate-fade-in text-center">
          {/* Request Grant from Admin Card */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6">
            <div className="flex flex-col items-center justify-center text-center gap-2 pb-4 border-b border-slate-100">
              <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider">
                {isAdmin ? 'Admin Self-Grant Portal' : 'Admin Request Portal'}
              </span>
              <h2 className="text-lg font-bold text-slate-900">
                {isAdmin
                  ? 'Provide Yourself with a Grant or Subsidy (AFNL)'
                  : 'Request Custom Grant or Subsidy from Admin'}
              </h2>
            </div>

            <form onSubmit={handleSendGrantRequest} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 text-center">
                  <label className="block text-xs font-bold text-slate-700 text-center">Grant / Subsidy Name</label>
                  <input
                    type="text"
                    value={reqName}
                    onChange={(e) => setReqName(e.target.value)}
                    placeholder="e.g. Regional Clean Energy Subsidy"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-slate-50/50"
                  />
                </div>

                <div className="space-y-1.5 text-center">
                  <label className="block text-xs font-bold text-slate-700 text-center">Requested Amount (Final Admin Coins - AFNL Only)</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="any"
                      value={reqAmount}
                      onChange={(e) => setReqAmount(e.target.value)}
                      placeholder="e.g. 10000"
                      className="w-full pl-4 pr-16 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-slate-50/50 font-mono"
                    />
                    <span className="absolute right-3 top-2.5 text-xs font-mono font-bold text-amber-700">AFNL</span>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5 text-center">
                <label className="block text-xs font-bold text-slate-700 text-center">Description &amp; Purpose</label>
                <textarea
                  rows={3}
                  value={reqDesc}
                  onChange={(e) => setReqDesc(e.target.value)}
                  placeholder="Describe the objective, community impact, or node deployment for this grant..."
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 bg-slate-50/50 resize-none"
                />
              </div>

              {/* Photo & Video Attachments Section */}
              <div className="space-y-2.5 text-center">
                <div className="flex flex-col items-center justify-center gap-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center justify-center gap-1.5">
                    <Upload className="w-3.5 h-3.5 text-amber-600" />
                    <span>Attach Photos &amp; Videos (Proof of work, blueprint, demo)</span>
                  </label>
                  <div className="flex items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleAddSampleMedia('image')}
                      className="text-[10px] text-amber-700 hover:text-amber-800 font-semibold underline cursor-pointer"
                    >
                      + Sample Photo
                    </button>
                    <span className="text-slate-300">|</span>
                    <button
                      type="button"
                      onClick={() => handleAddSampleMedia('video')}
                      className="text-[10px] text-amber-700 hover:text-amber-800 font-semibold underline cursor-pointer"
                    >
                      + Sample Video
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-3">
                  <label className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-dashed border-slate-300 hover:border-amber-500 bg-slate-50/50 hover:bg-amber-50/30 transition-all cursor-pointer text-xs font-medium text-slate-600">
                    <Upload className="w-4 h-4 text-slate-400" />
                    <span>Upload local photos or videos...</span>
                    <input
                      type="file"
                      accept="image/*,video/*"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {reqMedia.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2">
                    {reqMedia.map((m, idx) => (
                      <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-video flex items-center justify-center">
                        {m.type === 'image' ? (
                          <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-slate-900 flex items-center justify-center text-white relative">
                            <Video className="w-6 h-6 text-amber-400" />
                            <span className="absolute bottom-1 left-1 text-[9px] bg-black/60 px-1 rounded truncate max-w-[90%]">{m.name}</span>
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRemoveMedia(idx)}
                          className="absolute top-1 right-1 w-6 h-6 rounded-full bg-slate-900/80 hover:bg-rose-600 text-white flex items-center justify-center text-xs transition-all shadow"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-2 flex flex-col items-center justify-center gap-3">
                <span className="text-[11px] text-slate-500 max-w-md">
                  {isAdmin
                    ? 'Self-granted AFNL credits immediately to your Final Wallet and notifies Super Admin for oversight.'
                    : isVerified
                    ? 'Request goes directly to protocol administrator review.'
                    : 'Account sign-up and Tier 1 Verification (1 Legal ID) are required to request or receive Grants & Subsidies in Admin Final Coins (AFNL).'}
                </span>
                <button
                  type="submit"
                  disabled={!isAdmin && !isVerified}
                  className={`px-6 py-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-sm ${
                    !isAdmin && !isVerified
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-amber-600/20'
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  <span>{isAdmin ? 'Provide Grant / Subsidy to Self' : 'Send Request to Admin'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Submitted Grant Requests List */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8 space-y-6">
            <div className="flex flex-col items-center justify-center text-center gap-4 pb-4 border-b border-slate-100">
              <div className="space-y-1 flex flex-col items-center">
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-blue-100 text-blue-900 uppercase tracking-wider">
                  {isAdmin ? 'Self-Granted & Submitted History' : 'Submitted Requests'}
                </span>
                <h2 className="text-lg font-bold text-slate-900">
                  {isAdmin ? 'Your Granted Subsidies & Requests' : 'Your Admin Grant Requests'}
                </h2>
              </div>

              {/* Status Filter Tabs */}
              <div className="flex flex-nowrap items-center justify-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold overflow-x-auto max-w-full">
                {(['All', 'Pending', 'Approved', 'Cancelled'] as const).map((tab) => (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setRequestFilter(tab)}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                      requestFilter === tab
                        ? 'bg-white text-slate-900 shadow-2xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {grantRequests.filter(r => requestFilter === 'All' || r.status === requestFilter).length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                No {requestFilter !== 'All' ? requestFilter.toLowerCase() : ''} grant or subsidy requests found.
              </div>
            ) : (
              <div className="space-y-3">
                {grantRequests
                  .filter(req => requestFilter === 'All' || req.status === requestFilter)
                  .map((req) => (
                  <div key={req.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center text-center gap-3">
                    <div className="space-y-1.5 flex flex-col items-center">
                      <div className="flex items-center justify-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900">{req.name}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          req.status === 'Approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : req.status === 'Cancelled'
                            ? 'bg-slate-200 text-slate-700'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {req.status}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">{req.date}</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed max-w-lg">{req.description}</p>
                      {req.mediaAttachments && req.mediaAttachments.length > 0 && (
                        <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
                          {req.mediaAttachments.map((m, mIdx) => (
                            <div key={mIdx} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-[11px] font-medium text-slate-700 shadow-2xs">
                              {m.type === 'image' ? (
                                <Image className="w-3.5 h-3.5 text-amber-600" />
                              ) : (
                                <Video className="w-3.5 h-3.5 text-blue-600" />
                              )}
                              <span className="truncate max-w-[140px]">{m.name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col items-center gap-2 pt-1">
                      <div className="text-center">
                        <div className="text-sm font-mono font-bold text-amber-700 tabular-nums">
                          {req.amountAFNL.toLocaleString()} AFNL
                        </div>
                        <div className="text-[10px] text-slate-400">Final Admin Coins</div>
                      </div>
                      {req.status === 'Pending' && (
                        <button
                          type="button"
                          onClick={() => handleCancelRequest(req.id)}
                          className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-rose-100 text-slate-700 hover:text-rose-700 text-xs font-bold transition-all cursor-pointer"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Internal Banking View */}
      {activeSubTab === 'banking' && (
        <div className="space-y-6 animate-fade-in text-center">
            {/* Clearing Bank License & Final Coin Loan Desk */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/80 space-y-6 text-center">
              <div className="flex flex-col items-center justify-center text-center gap-4 pb-4 border-b border-amber-200/60">
                <div className="space-y-1.5 flex flex-col items-center text-center">
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-500 text-slate-950 uppercase tracking-wider">
                      Clearing Bank Status
                    </span>
                    {bankAppStatus === 'approved' && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        {isAdmin ? '✅ Auto-Approved Admin Clearing Bank' : '✅ Approved Bank License'}
                      </span>
                    )}
                    {bankAppStatus === 'pending' && (
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                        ⏳ Pending Admin Review
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-bold text-slate-900 text-center">Inter-Bank Final Coin Lending Institution</h3>
                  <p className="text-xs text-slate-600 max-w-lg mx-auto text-center">
                    {bankAppStatus === 'approved'
                      ? isAdmin
                        ? 'As an Administrator, you are automatically authorized as a Clearing Bank to issue and loan your Final Coins to other users — no approval needed.'
                        : 'You are an approved Clearing Bank. You are authorized to issue and loan your Final Coins (AFNL) to other users.'
                      : bankAppStatus === 'pending'
                      ? 'Your application to become an approved Clearing Bank is currently under review by Admin.'
                      : 'Request Admin approval to operate as an approved Clearing Bank and loan your final coins to other users.'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-2 shrink-0">
                  {bankAppStatus === 'none' && (
                    <button
                      type="button"
                      onClick={() => setBankModalOpen(true)}
                      className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
                    >
                      Apply to Become a Bank
                    </button>
                  )}
                  {bankAppStatus === 'pending' && (
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <span className="text-xs font-semibold text-amber-800 bg-amber-100 px-3 py-2 rounded-xl">Review Pending</span>
                      <button
                        type="button"
                        onClick={handleCancelBankApp}
                        className="px-3 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                      {isAdmin && (
                        <button
                          type="button"
                          onClick={() => {
                            setBankAppStatus('approved');
                            localStorage.setItem(`ff_bank_app_status_${userId}`, 'approved');
                            if (institutionName.trim()) {
                              localStorage.setItem(`ff_bank_app_name_${userId}`, institutionName.trim());
                            }
                            if (currentUser?.uid) {
                              localStorage.setItem(`ff_bank_app_status_${currentUser.uid}`, 'approved');
                              if (institutionName.trim()) {
                                localStorage.setItem(`ff_bank_app_name_${currentUser.uid}`, institutionName.trim());
                              }
                            }
                            try {
                              const raw = localStorage.getItem('ff_admin_banking_requests');
                              if (raw) {
                                const parsed = JSON.parse(raw);
                                if (Array.isArray(parsed)) {
                                  const updated = parsed.map((r: any) =>
                                    r?.userId === userId || r?.uid === currentUser?.uid
                                      ? { ...r, status: 'approved' }
                                      : r
                                  );
                                  localStorage.setItem('ff_admin_banking_requests', JSON.stringify(updated));
                                }
                              }
                            } catch {
                              // ignore storage errors
                            }
                            window.dispatchEvent(new Event('final_finance_bank_status_updated'));
                            showToast('Admin approved your Clearing Bank license!');
                          }}
                          className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all cursor-pointer"
                          title="Instant Admin Approve for Demo"
                        >
                          ⚙️ Approve Bank (Admin)
                        </button>
                      )}
                    </div>
                  )}
                  {bankAppStatus === 'approved' && (
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (ownedFinalCoinsForLoan.length === 0) {
                            showToast('You need Final Coins (e.g. AFNL received from a loan or wallet) before issuing a loan.');
                          }
                          setLoanModalOpen(true);
                        }}
                        className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Coins className="w-4 h-4" />
                        <span>Issue Final Coin Loan</span>
                      </button>
                      {isAdmin && (
                        <button
                          type="button"
                          onClick={() => setBankModalOpen(true)}
                          className="px-4 py-2.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all shadow-2xs cursor-pointer"
                        >
                          Configure Bank Node
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Credit Standing, Next Due Date & Defaults Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
                <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                  Ongoing Loans Owed
                </div>
                <div className="text-lg font-mono font-bold text-slate-900">
                  {ongoingLoansTaken.length} {ongoingLoansTaken.length === 1 ? 'Loan' : 'Loans'}
                </div>
                <div className="text-[11px] text-slate-500">
                  {ongoingLoansTaken.length > 0
                    ? `${ongoingLoansTaken.reduce((sum, l) => sum + getLoanRemainingBalance(l), 0).toLocaleString()} AFNL Eq. Remaining`
                    : 'Zero Active Debt'}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
                <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                  Next Loan Due Date
                </div>
                <div className="text-sm font-mono font-bold text-amber-700 flex items-center justify-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {nextDueLoan
                      ? new Date(getLoanNextDueDateMs(nextDueLoan)).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })
                      : 'No Loan Due'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500">
                  {nextDueLoan
                    ? `${Math.max(0, Math.ceil((getLoanNextDueDateMs(nextDueLoan) - Date.now()) / (24 * 60 * 60 * 1000)))} days left · Pay ahead anytime`
                    : 'All caught up'}
                </div>
              </div>

              <div className={`p-4 rounded-2xl border shadow-2xs space-y-1 ${
                userDefaultCount > 0 ? 'bg-rose-50/70 border-rose-200' : 'bg-white border-slate-200'
              }`}>
                <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                  Times Defaulted
                </div>
                <div className={`text-lg font-mono font-bold ${userDefaultCount > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
                  {userDefaultCount} {userDefaultCount === 1 ? 'Time' : 'Times'}
                </div>
                <div className="text-[11px] text-slate-500">
                  {userDefaultCount === 0 ? 'Clean repayment record' : 'Recorded on internal banking ledger'}
                </div>
              </div>
            </div>

            {/* Internal Banking Main Tabs (Ordered vertically so Loan Offers sits directly under Ongoing Loans I've Taken and above Loans Taken From Me) */}
            <div className="flex flex-col gap-1.5 p-1.5 bg-slate-100 rounded-2xl w-full max-w-2xl mx-auto">
              <button
                type="button"
                onClick={() => setActiveBankingView('taken_ongoing')}
                className={`w-full py-2.5 px-4 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeBankingView === 'taken_ongoing'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Ongoing Loans I&apos;ve Taken ({ongoingLoansTaken.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveBankingView('loan_offers')}
                className={`w-full py-2.5 px-4 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  activeBankingView === 'loan_offers'
                    ? 'bg-white text-sky-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Loan Offers ({pendingLoanOffers.length})</span>
                {pendingLoanOffers.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-sky-600 text-white text-[10px] font-bold">
                    Awaiting Approval
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => setActiveBankingView('lent_to_others')}
                className={`w-full py-2.5 px-4 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeBankingView === 'lent_to_others'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Loans Taken From Me ({loansIssued.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveBankingView('portfolio_transactions')}
                className={`w-full py-2.5 px-4 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeBankingView === 'portfolio_transactions'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Recent Internal Banking Transactions &amp; Loan Portfolio Summary
              </button>
            </div>

            <div className="flex items-center justify-center">
              <button
                type="button"
                onClick={handleResetExampleLoans}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-[11px] font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Restore Sample Loan Examples</span>
              </button>
            </div>

            {/* TAB 1: Ongoing Loans User Has Taken */}
            {activeBankingView === 'taken_ongoing' && (
              <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-5 text-center">
                <div className="space-y-1">
                  <h3 className="font-bold text-base text-slate-900">Ongoing Loans You Have Taken</h3>
                  <p className="text-xs text-slate-500">
                    Click any loan provider&apos;s photo or name to visit their profile, inspect all payment installments &amp; debt timelines, or pay ahead early.
                  </p>
                </div>

                {ongoingLoansTaken.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-slate-50 border border-dashed border-slate-200 text-xs text-slate-500">
                    You have no ongoing loans at this time.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {ongoingLoansTaken.map((loan) => {
                      const timeline = getLoanTimelineMetrics(loan);
                      const lender = resolveCounterpartyDisplay(
                        loan.lenderId,
                        loan.lenderHandle,
                        loan.lenderName,
                        loan.lenderAvatar
                      );
                      const issuedStr = new Date(timeline.issuedMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                      const nextDueObj = new Date(timeline.nextDueMs);
                      const nextDueStr = nextDueObj.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                      const finalDueStr = new Date(timeline.finalDueMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                      const customVal = payAheadInputs[loan.id] || '';

                      return (
                        <div
                          key={loan.id}
                          className="p-5 rounded-2xl border text-xs space-y-4 text-center bg-amber-50/60 border-amber-200"
                        >
                          {/* Loan Provider / Lender Profile Picture & Clickable Name */}
                          <div className="flex flex-col items-center justify-center gap-2">
                            <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full text-amber-800">
                              Loan Provider / Lender
                            </span>
                            <div className="flex items-center justify-center gap-3">
                              <button
                                type="button"
                                onClick={() => handleOpenCounterpartyProfile(lender.targetIdentifier)}
                                title={`View ${lender.name}'s profile`}
                                className="group relative rounded-full focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer shrink-0"
                              >
                                <img
                                  src={lender.avatarUrl}
                                  alt={lender.name}
                                  className="w-12 h-12 rounded-full object-cover border-2 border-amber-300 shadow-xs group-hover:scale-105 group-hover:border-amber-500 transition-all"
                                />
                              </button>
                              <div className="text-left">
                                <button
                                  type="button"
                                  onClick={() => handleOpenCounterpartyProfile(lender.targetIdentifier)}
                                  className="font-bold text-sm text-slate-900 hover:text-amber-700 hover:underline transition-colors cursor-pointer block"
                                >
                                  {lender.name}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleOpenCounterpartyProfile(lender.targetIdentifier)}
                                  className="text-[11px] font-mono text-slate-500 hover:text-amber-700 transition-colors cursor-pointer block"
                                >
                                  {lender.handle} · Visit Profile →
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Loan Amount & Status */}
                          <div className="flex flex-col items-center gap-1">
                            <div className="flex items-center justify-center gap-2 flex-wrap">
                              <span className="font-mono font-bold text-base text-slate-900">
                                {timeline.remainingBalance.toLocaleString()} {loan.coinSymbol} Remaining
                              </span>
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                                timeline.isOverdue
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-200/80 text-amber-950'
                              }`}>
                                {timeline.isOverdue ? 'Overdue' : 'Ongoing'}
                              </span>
                            </div>
                            <p className="text-slate-600">
                              Principal: <span className="font-mono font-semibold">{loan.amount.toLocaleString()} {loan.coinSymbol}</span> • Rate: <span className="font-mono">{loan.interestRate}% APR</span> • Term: <span className="font-mono">{timeline.totalDurationDays} Days</span>
                            </p>
                          </div>

                          {/* Metrics Grid (includes Monthly Installment) */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-white/90 p-3.5 rounded-xl border border-black/10">
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Monthly Installment</div>
                              <div className="font-mono font-bold text-amber-700 mt-0.5">
                                {timeline.monthlyInstallment.toLocaleString()} {loan.coinSymbol}/mo
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Next Due Date</div>
                              <div className={`font-bold mt-0.5 ${timeline.isOverdue ? 'text-rose-700' : 'text-slate-900'}`}>
                                {nextDueStr}
                              </div>
                              <div className="text-[10px] text-slate-500">
                                {timeline.isOverdue
                                  ? `${Math.abs(timeline.daysUntilNextDue)} days overdue`
                                  : `${timeline.daysUntilNextDue} days remaining`}
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Total Obligation</div>
                              <div className="font-mono font-bold text-slate-900 mt-0.5">
                                {timeline.totalDue.toLocaleString()} {loan.coinSymbol}
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Paid Ahead</div>
                              <div className="font-mono font-bold text-emerald-700 mt-0.5">
                                {timeline.amountPaid.toLocaleString()} {loan.coinSymbol} ({timeline.repaymentPct}%)
                              </div>
                            </div>
                          </div>

                          {/* Overall Debt Timeline */}
                          <div className="bg-white/95 p-4 rounded-xl border border-black/10 space-y-2.5 text-center">
                            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-700">
                              <span className="inline-flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-amber-600" />
                                <span>Overall Debt Timeline</span>
                              </span>
                              <span className="font-mono text-[10px] text-slate-500">
                                Day {Math.min(timeline.elapsedDays, timeline.totalDurationDays)} of {timeline.totalDurationDays} ({timeline.timeElapsedPct}% elapsed)
                              </span>
                            </div>
                            <div className="space-y-1.5">
                              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/70">
                                <div
                                  className={`h-full transition-all duration-300 ${
                                    timeline.isOverdue ? 'bg-rose-500' : 'bg-amber-500'
                                  }`}
                                  style={{ width: `${Math.max(4, timeline.timeElapsedPct)}%` }}
                                />
                              </div>
                              <div className="w-full h-2 bg-emerald-50 rounded-full overflow-hidden border border-emerald-200/70">
                                <div
                                  className="h-full bg-emerald-500 transition-all duration-300"
                                  style={{ width: `${timeline.repaymentPct}%` }}
                                />
                              </div>
                            </div>
                            <div className="grid grid-cols-3 gap-2 pt-1 text-[10px] text-slate-500 font-mono">
                              <div className="text-left">
                                <div className="uppercase text-slate-400">Issued</div>
                                <div className="font-bold text-slate-700">{issuedStr}</div>
                              </div>
                              <div className="text-center">
                                <div className="uppercase text-slate-400">Next Due</div>
                                <div className={`font-bold ${timeline.isOverdue ? 'text-rose-700' : 'text-amber-700'}`}>{nextDueStr}</div>
                              </div>
                              <div className="text-right">
                                <div className="uppercase text-slate-400">Final Maturity</div>
                                <div className="font-bold text-slate-700">{finalDueStr}</div>
                              </div>
                            </div>
                          </div>

                          {/* All Installments for Every Loan Payment */}
                          {renderInstallmentSchedule(loan)}

                          {/* Pay Ahead Controls */}
                          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-1">
                            <input
                              type="number"
                              min="0.01"
                              max={timeline.remainingBalance}
                              step="any"
                              value={customVal}
                              onChange={(e) => setPayAheadInputs((prev) => ({ ...prev, [loan.id]: e.target.value }))}
                              placeholder={`Amount (max ${timeline.remainingBalance})`}
                              className="w-full sm:w-44 px-3 py-2 rounded-xl border border-amber-300 bg-white text-xs text-slate-900 font-mono text-center focus:outline-none focus:ring-2 focus:ring-amber-500"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                const parsed = parseFloat(customVal);
                                if (!customVal || isNaN(parsed) || parsed <= 0) {
                                  showToast('Enter a valid amount to pay ahead.');
                                  return;
                                }
                                handlePayAheadLoan(loan, parsed);
                              }}
                              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all cursor-pointer shadow-xs"
                            >
                              Pay Ahead
                            </button>
                            <button
                              type="button"
                              onClick={() => handlePayAheadLoan(loan, timeline.remainingBalance)}
                              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition-all cursor-pointer shadow-xs"
                            >
                              Pay Full Ahead ({timeline.remainingBalance.toLocaleString()} {loan.coinSymbol})
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: Dedicated Loan Offers Awaiting Final Approval */}
            {activeBankingView === 'loan_offers' && (
              <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-5 text-center">
                <div className="space-y-1">
                  <h3 className="font-bold text-base text-slate-900">Loan Offers Awaiting Final Approval</h3>
                  <p className="text-xs text-slate-500">
                    Inspect incoming Final Currency Loan Offers, monthly installments, full payment schedules, and provider profiles before accepting or declining.
                  </p>
                </div>

                {pendingLoanOffers.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-slate-50 border border-dashed border-slate-200 text-xs text-slate-500">
                    You have no pending Loan Offers waiting for approval.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingLoanOffers.map((loan) => {
                      const timeline = getLoanTimelineMetrics(loan);
                      const lender = resolveCounterpartyDisplay(
                        loan.lenderId,
                        loan.lenderHandle,
                        loan.lenderName,
                        loan.lenderAvatar
                      );
                      const issuedStr = new Date(timeline.issuedMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                      const nextDueStr = new Date(timeline.nextDueMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                      const finalDueStr = new Date(timeline.finalDueMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

                      return (
                        <div
                          key={loan.id}
                          className="p-5 rounded-2xl border text-xs space-y-4 text-center bg-sky-50/70 border-sky-300 shadow-sm"
                        >
                          {/* Loan Provider Profile Picture & Clickable Name */}
                          <div className="flex flex-col items-center justify-center gap-2">
                            <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-900">
                              Loan Offer · Awaiting Final Approval
                            </span>
                            <div className="flex items-center justify-center gap-3">
                              <button
                                type="button"
                                onClick={() => handleOpenCounterpartyProfile(lender.targetIdentifier)}
                                title={`View ${lender.name}'s profile`}
                                className="group relative rounded-full focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer shrink-0"
                              >
                                <img
                                  src={lender.avatarUrl}
                                  alt={lender.name}
                                  className="w-12 h-12 rounded-full object-cover border-2 border-sky-300 shadow-xs group-hover:scale-105 group-hover:border-sky-500 transition-all"
                                />
                              </button>
                              <div className="text-left">
                                <button
                                  type="button"
                                  onClick={() => handleOpenCounterpartyProfile(lender.targetIdentifier)}
                                  className="font-bold text-sm text-slate-900 hover:text-amber-700 hover:underline transition-colors cursor-pointer block"
                                >
                                  {lender.name}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleOpenCounterpartyProfile(lender.targetIdentifier)}
                                  className="text-[11px] font-mono text-slate-500 hover:text-amber-700 transition-colors cursor-pointer block"
                                >
                                  {lender.handle} · Visit Profile →
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Offered Amount & Status */}
                          <div className="flex flex-col items-center gap-1">
                            <div className="flex items-center justify-center gap-2 flex-wrap">
                              <span className="font-mono font-bold text-base text-slate-900">
                                {loan.amount.toLocaleString()} {loan.coinSymbol} Offered
                              </span>
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-sky-600 text-white">
                                Loan Offer
                              </span>
                            </div>
                            <p className="text-slate-600">
                              Principal: <span className="font-mono font-semibold">{loan.amount.toLocaleString()} {loan.coinSymbol}</span> • Rate: <span className="font-mono">{loan.interestRate}% APR</span> • Term: <span className="font-mono">{timeline.totalDurationDays} Days</span>
                            </p>
                          </div>

                          {/* Metrics Grid */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-white/90 p-3.5 rounded-xl border border-black/10">
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Monthly Installment</div>
                              <div className="font-mono font-bold text-amber-700 mt-0.5">
                                {timeline.monthlyInstallment.toLocaleString()} {loan.coinSymbol}/mo
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">First Due (On Approval)</div>
                              <div className="font-bold text-slate-900 mt-0.5">
                                ~{Math.min(30, timeline.totalDurationDays)} days after approval
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Total Obligation</div>
                              <div className="font-mono font-bold text-slate-900 mt-0.5">
                                {timeline.totalDue.toLocaleString()} {loan.coinSymbol}
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Final Status</div>
                              <div className="font-mono font-bold text-sky-700 mt-0.5">
                                Needs Your Approval
                              </div>
                            </div>
                          </div>

                          {/* Overall Debt Timeline */}
                          <div className="bg-white/95 p-4 rounded-xl border border-black/10 space-y-2.5 text-center">
                            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-700">
                              <span className="inline-flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-amber-600" />
                                <span>Overall Debt Timeline</span>
                              </span>
                              <span className="font-mono text-[10px] text-slate-500">
                                {timeline.totalDurationDays}-Day Term Starts Upon Final Approval
                              </span>
                            </div>
                            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/70">
                              <div className="h-full bg-sky-500 transition-all duration-300" style={{ width: '8%' }} />
                            </div>
                            <div className="grid grid-cols-3 gap-2 pt-1 text-[10px] text-slate-500 font-mono">
                              <div className="text-left">
                                <div className="uppercase text-slate-400">Offered</div>
                                <div className="font-bold text-slate-700">{issuedStr}</div>
                              </div>
                              <div className="text-center">
                                <div className="uppercase text-slate-400">Next Due</div>
                                <div className="font-bold text-amber-700">{nextDueStr}</div>
                              </div>
                              <div className="text-right">
                                <div className="uppercase text-slate-400">Final Maturity</div>
                                <div className="font-bold text-slate-700">{finalDueStr}</div>
                              </div>
                            </div>
                          </div>

                          {/* All Scheduled Installments */}
                          {renderInstallmentSchedule(loan)}

                          {/* Final Approval Actions */}
                          <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 pt-1">
                            <button
                              type="button"
                              onClick={() => handleApproveLoanOffer(loan)}
                              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition-all cursor-pointer shadow-xs inline-flex items-center justify-center gap-1.5"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Approve &amp; Accept Loan Offer</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeclineLoanOffer(loan)}
                              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white hover:bg-rose-50 text-rose-700 border border-rose-200 font-bold transition-all cursor-pointer"
                            >
                              Decline Offer
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: Loans People Have Taken From Me (with Clickable Borrower Photo/Name, Amount, Next Due Date & Overall Debt Timeline) */}
            {activeBankingView === 'lent_to_others' && (
              <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-5 text-center">
                <div className="space-y-1">
                  <h3 className="font-bold text-base text-slate-900">Loans People Have Taken From You</h3>
                  <p className="text-xs text-slate-500">
                    Click any borrower&apos;s photo or name to visit their profile, inspect their next due date &amp; full debt timeline, or declare overdue defaults.
                  </p>
                </div>

                {loansIssued.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-slate-50 border border-dashed border-slate-200 text-xs text-slate-500">
                    No one has taken a loan from you yet.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {loansIssued.map((loan) => {
                      const timeline = getLoanTimelineMetrics(loan);
                      const borrower = resolveCounterpartyDisplay(
                        loan.borrowerId,
                        loan.borrowerHandle,
                        loan.borrowerName,
                        loan.borrowerAvatar
                      );
                      const issuedStr = new Date(timeline.issuedMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                      const nextDueStr = new Date(timeline.nextDueMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                      const finalDueStr = new Date(timeline.finalDueMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

                      return (
                        <div key={loan.id} className={`p-5 rounded-2xl border flex flex-col items-center justify-center gap-4 text-xs ${
                          loan.status === 'pending_offer'
                            ? 'bg-sky-50/60 border-sky-200'
                            : loan.status === 'declined'
                            ? 'bg-slate-100/80 border-slate-200'
                            : timeline.isOverdue
                            ? 'bg-rose-50/60 border-rose-200'
                            : loan.status === 'repaid'
                            ? 'bg-emerald-50/50 border-emerald-200'
                            : 'bg-slate-50 border-slate-200'
                        }`}>
                          {/* Borrower Profile Picture & Clickable Name */}
                          <div className="flex flex-col items-center justify-center gap-2">
                            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                              Borrower
                            </span>
                            <div className="flex items-center justify-center gap-3">
                              <button
                                type="button"
                                onClick={() => handleOpenCounterpartyProfile(borrower.targetIdentifier)}
                                title={`View ${borrower.name}'s profile`}
                                className="group relative rounded-full focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer shrink-0"
                              >
                                <img
                                  src={borrower.avatarUrl}
                                  alt={borrower.name}
                                  className="w-12 h-12 rounded-full object-cover border-2 border-slate-300 shadow-xs group-hover:scale-105 group-hover:border-amber-500 transition-all"
                                />
                              </button>
                              <div className="text-left">
                                <button
                                  type="button"
                                  onClick={() => handleOpenCounterpartyProfile(borrower.targetIdentifier)}
                                  className="font-bold text-sm text-slate-900 hover:text-amber-700 hover:underline transition-colors cursor-pointer block"
                                >
                                  {borrower.name}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleOpenCounterpartyProfile(borrower.targetIdentifier)}
                                  className="text-[11px] font-mono text-slate-500 hover:text-amber-700 transition-colors cursor-pointer block"
                                >
                                  {borrower.handle} · View Profile →
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Amount & Status */}
                          <div className="flex items-center justify-center gap-2 flex-wrap">
                            <span className="font-mono font-bold text-base text-slate-900">
                              {loan.amount.toLocaleString()} {loan.coinSymbol} Principal
                            </span>
                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              loan.status === 'pending_offer'
                                ? 'bg-sky-100 text-sky-900'
                                : loan.status === 'declined'
                                ? 'bg-slate-200 text-slate-700'
                                : loan.status === 'active'
                                ? timeline.isOverdue
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-100 text-amber-800'
                                : loan.status === 'repaid'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}>
                              {loan.status === 'pending_offer'
                                ? 'Loan Offer · Awaiting Approval'
                                : loan.status === 'declined'
                                ? 'Offer Declined'
                                : timeline.isOverdue
                                ? 'OVERDUE'
                                : loan.status}
                            </span>
                          </div>

                          {/* Amount, Next Due Date & Repayment Summary */}
                          <div className="w-full grid grid-cols-1 sm:grid-cols-3 gap-2.5 bg-white p-3.5 rounded-xl border border-slate-200/80">
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Next Due Date</div>
                              <div className={`font-bold mt-0.5 ${timeline.isOverdue ? 'text-rose-700' : 'text-slate-900'}`}>
                                {loan.status === 'pending_offer' ? 'Upon Approval' : loan.status === 'declined' ? '—' : nextDueStr}
                              </div>
                              <div className="text-[10px] text-slate-500">
                                {loan.status === 'pending_offer'
                                  ? 'Pending borrower acceptance'
                                  : loan.status === 'declined'
                                  ? 'Offer declined'
                                  : loan.status === 'repaid'
                                  ? 'Fully settled'
                                  : timeline.isOverdue
                                  ? `${Math.abs(timeline.daysUntilNextDue)} days overdue`
                                  : `${timeline.daysUntilNextDue} days remaining`}
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">Monthly Installment</div>
                              <div className="font-mono font-bold text-slate-900 mt-0.5">
                                {timeline.monthlyInstallment.toLocaleString()} {loan.coinSymbol}/mo
                              </div>
                              <div className="text-[10px] text-slate-500">
                                {loan.interestRate}% APR • {timeline.totalDue.toLocaleString()} {loan.coinSymbol} total
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] font-mono text-slate-400 uppercase">
                                {loan.status === 'repaid' ? 'Total Repaid' : 'Remaining Owed'}
                              </div>
                              <div className={`font-mono font-bold mt-0.5 ${
                                loan.status === 'repaid' ? 'text-emerald-700' : 'text-slate-900'
                              }`}>
                                {(loan.status === 'declined' ? 0 : loan.status === 'repaid' ? timeline.amountPaid : timeline.remainingBalance).toLocaleString()} {loan.coinSymbol}
                              </div>
                              <div className="text-[10px] text-emerald-700">
                                {timeline.repaymentPct}% repaid
                              </div>
                            </div>
                          </div>

                          {/* Overall Timeline for the Debt */}
                          <div className="w-full bg-white p-4 rounded-xl border border-slate-200/80 space-y-2.5">
                            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-700">
                              <span className="inline-flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-amber-600" />
                                <span>Overall Debt Timeline</span>
                              </span>
                              <span className="font-mono text-[10px] text-slate-500">
                                {loan.status === 'pending_offer'
                                  ? `${timeline.totalDurationDays}-Day Proposed Term`
                                  : loan.status === 'declined'
                                  ? 'Offer Declined'
                                  : loan.status === 'repaid'
                                  ? `${timeline.totalDurationDays}-Day Term Completed`
                                  : `Day ${Math.min(timeline.elapsedDays, timeline.totalDurationDays)} of ${timeline.totalDurationDays} (${timeline.timeElapsedPct}% elapsed)`}
                              </span>
                            </div>
                            <div className="space-y-1.5">
                              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/70">
                                <div
                                  className={`h-full transition-all duration-300 ${
                                    loan.status === 'pending_offer'
                                      ? 'bg-sky-400'
                                      : loan.status === 'declined'
                                      ? 'bg-slate-300'
                                      : loan.status === 'repaid'
                                      ? 'bg-emerald-500'
                                      : timeline.isOverdue
                                      ? 'bg-rose-500'
                                      : 'bg-amber-500'
                                  }`}
                                  style={{
                                    width: `${
                                      loan.status === 'pending_offer' || loan.status === 'declined'
                                        ? 0
                                        : loan.status === 'repaid'
                                        ? 100
                                        : Math.max(4, timeline.timeElapsedPct)
                                    }%`,
                                  }}
                                />
                              </div>
                              <div className="w-full h-2 bg-emerald-50 rounded-full overflow-hidden border border-emerald-200/70">
                                <div
                                  className="h-full bg-emerald-500 transition-all duration-300"
                                  style={{ width: `${timeline.repaymentPct}%` }}
                                />
                              </div>
                            </div>
                            <div className="grid grid-cols-3 gap-2 pt-1 text-[10px] text-slate-500 font-mono">
                              <div className="text-left">
                                <div className="uppercase text-slate-400">Issued</div>
                                <div className="font-bold text-slate-700">{issuedStr}</div>
                              </div>
                              <div className="text-center">
                                <div className="uppercase text-slate-400">Next Due</div>
                                <div className={`font-bold ${timeline.isOverdue ? 'text-rose-700' : 'text-slate-700'}`}>{nextDueStr}</div>
                              </div>
                              <div className="text-right">
                                <div className="uppercase text-slate-400">Final Maturity</div>
                                <div className="font-bold text-slate-700">{finalDueStr}</div>
                              </div>
                            </div>
                          </div>

                          {renderInstallmentSchedule(loan)}

                          {loan.status === 'active' && (
                            <button
                              type="button"
                              onClick={() => handleDefaultLoan(loan)}
                              disabled={!timeline.isOverdue}
                              className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                                timeline.isOverdue
                                  ? 'bg-rose-600 hover:bg-rose-700 text-white cursor-pointer shadow-xs'
                                  : 'bg-slate-200 text-slate-500 cursor-not-allowed opacity-70'
                              }`}
                            >
                              {timeline.isOverdue ? 'Declare Default' : 'Not Yet Overdue'}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: Combined Recent Internal Banking Transactions & Loan Portfolio Summary */}
            {activeBankingView === 'portfolio_transactions' && (
              <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-5 text-center">
                <div className="space-y-1">
                  <h3 className="font-bold text-base text-slate-900">
                    Recent Internal Banking Transactions &amp; Loan Portfolio Summary
                  </h3>
                  <p className="text-xs text-slate-500">
                    Unified ledger of your ongoing, offered, and concluded loans alongside every installment, due date, and counterparty profile.
                  </p>
                  <div className="pt-1 text-[11px] font-semibold text-slate-500">
                    Times Defaulted:{' '}
                    <strong className={userDefaultCount > 0 ? 'text-rose-700' : 'text-emerald-700'}>
                      {userDefaultCount}
                    </strong>{' '}
                    • Total Records: <strong className="text-slate-800">{allUserLoans.length}</strong>
                  </div>
                </div>

                {/* Portfolio Status Filter Tabs */}
                <div className="flex p-1 bg-slate-100 rounded-2xl w-full max-w-xl mx-auto">
                  <button
                    type="button"
                    onClick={() => setActivePortfolioTab('ongoing')}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      activePortfolioTab === 'ongoing'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Ongoing &amp; Offers
                  </button>
                  <button
                    type="button"
                    onClick={() => setActivePortfolioTab('concluded')}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      activePortfolioTab === 'concluded'
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Concluded Loans
                  </button>
                </div>

                {/* Sub-Tabs: Loans Taken vs Loans Taken From Me */}
                <div className="flex p-1 gap-1.5 w-full max-w-xl mx-auto">
                  <button
                    type="button"
                    onClick={() => setActiveLoanType('received')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      activeLoanType === 'received'
                        ? 'bg-sky-100 text-sky-900 shadow-sm'
                        : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    Loans Taken ({loansReceived.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveLoanType('given')}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      activeLoanType === 'given'
                        ? 'bg-amber-100 text-amber-900 shadow-sm'
                        : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    Loans Taken From Me ({loansIssued.length})
                  </button>
                </div>

                {(() => {
                  const source = activeLoanType === 'given' ? loansIssued : loansReceived;
                  const filtered = source.filter((l) =>
                    activePortfolioTab === 'ongoing'
                      ? l.status === 'active' || l.status === 'pending_offer'
                      : l.status === 'repaid' || l.status === 'defaulted' || l.status === 'declined'
                  );

                  if (filtered.length === 0) {
                    return (
                      <p className="text-xs text-slate-400 py-6">
                        No {activePortfolioTab} {activeLoanType === 'received' ? 'loans taken' : 'loans taken from you'} recorded.
                      </p>
                    );
                  }

                  return (
                    <div className="space-y-4">
                      {filtered.map((loan) => {
                        const timeline = getLoanTimelineMetrics(loan);
                        const isGiven = activeLoanType === 'given';
                        const counterparty = isGiven
                          ? resolveCounterpartyDisplay(loan.borrowerId, loan.borrowerHandle, loan.borrowerName, loan.borrowerAvatar)
                          : resolveCounterpartyDisplay(loan.lenderId, loan.lenderHandle, loan.lenderName, loan.lenderAvatar);
                        const issuedStr = new Date(timeline.issuedMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                        const nextDueStr = new Date(timeline.nextDueMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                        const finalDueStr = new Date(timeline.finalDueMs).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });

                        const cardStyle =
                          loan.status === 'pending_offer'
                            ? 'bg-sky-50/70 border-sky-200 text-sky-950'
                            : loan.status === 'active'
                            ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                            : loan.status === 'repaid'
                            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                            : loan.status === 'declined'
                            ? 'bg-slate-100/80 border-slate-200 text-slate-800'
                            : 'bg-rose-50/70 border-rose-200 text-rose-950';

                        return (
                          <div key={loan.id} className={`p-4 sm:p-5 rounded-2xl border text-xs space-y-3.5 text-center ${cardStyle}`}>
                            {/* Transaction Header & Counterparty Profile Link */}
                            <div className="flex flex-col items-center justify-center gap-2">
                              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500">
                                {isGiven ? 'Loan Issued Transaction' : 'Loan Taken Transaction'} • {loan.timestamp || issuedStr}
                              </span>
                              <div className="flex items-center justify-center gap-2.5">
                                <button
                                  type="button"
                                  onClick={() => handleOpenCounterpartyProfile(counterparty.targetIdentifier)}
                                  className="rounded-full cursor-pointer shrink-0 group focus:outline-none focus:ring-2 focus:ring-amber-500"
                                >
                                  <img
                                    src={counterparty.avatarUrl}
                                    alt={counterparty.name}
                                    className="w-11 h-11 rounded-full object-cover border border-black/15 group-hover:scale-105 transition-transform"
                                  />
                                </button>
                                <div className="text-left">
                                  <div className="text-[10px] font-mono uppercase opacity-70">
                                    {isGiven ? 'Borrower' : 'Loan Provider'}
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => handleOpenCounterpartyProfile(counterparty.targetIdentifier)}
                                    className="font-bold text-slate-900 hover:text-amber-700 hover:underline cursor-pointer block"
                                  >
                                    {counterparty.name} <span className="font-mono font-normal opacity-75">({counterparty.handle})</span>
                                  </button>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col items-center gap-1 font-mono">
                              <span className="font-bold text-sm">
                                {loan.amount.toLocaleString()} {loan.coinSymbol || 'AFNL'} Principal
                                {loan.status === 'active' && (
                                  <span className="text-xs font-semibold opacity-80">
                                    {' '}• {timeline.remainingBalance.toLocaleString()} {loan.coinSymbol} Remaining
                                  </span>
                                )}
                              </span>
                              <span className="text-[10px] opacity-80">
                                Monthly Installment: {timeline.monthlyInstallment.toLocaleString()} {loan.coinSymbol}/mo ({loan.interestRate}% APR)
                              </span>
                              <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-white/90 border border-black/10">
                                {loan.status === 'pending_offer'
                                  ? 'Loan Offer'
                                  : loan.status === 'declined'
                                  ? 'Declined'
                                  : timeline.isOverdue
                                  ? 'OVERDUE'
                                  : loan.status}
                              </span>
                            </div>

                            <div className="bg-white/85 p-3 rounded-xl border border-black/10 space-y-2 text-[10px] font-mono">
                              <div className="flex items-center justify-between text-slate-700 font-semibold">
                                <span>Overall Debt Timeline ({timeline.totalDurationDays}d)</span>
                                <span>{timeline.repaymentPct}% repaid</span>
                              </div>
                              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                                <div
                                  className={`h-full ${
                                    loan.status === 'pending_offer'
                                      ? 'bg-sky-400'
                                      : loan.status === 'declined'
                                      ? 'bg-slate-300'
                                      : loan.status === 'repaid'
                                      ? 'bg-emerald-500'
                                      : timeline.isOverdue
                                      ? 'bg-rose-500'
                                      : 'bg-amber-500'
                                  }`}
                                  style={{
                                    width: `${
                                      loan.status === 'pending_offer' || loan.status === 'declined'
                                        ? 0
                                        : loan.status === 'repaid'
                                        ? 100
                                        : Math.max(4, timeline.timeElapsedPct)
                                    }%`,
                                  }}
                                />
                              </div>
                              <div className="grid grid-cols-3 gap-1 pt-0.5 text-slate-600">
                                <div className="text-left">Issued: {issuedStr}</div>
                                <div className="text-center font-bold">Due: {loan.status === 'pending_offer' ? 'Upon Approval' : nextDueStr}</div>
                                <div className="text-right">End: {finalDueStr}</div>
                              </div>
                            </div>

                            {renderInstallmentSchedule(loan)}

                            {!isGiven && loan.status === 'pending_offer' && (
                              <div className="flex flex-wrap items-center justify-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => handleApproveLoanOffer(loan)}
                                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-sans font-bold text-xs cursor-pointer transition-colors"
                                >
                                  Approve & Accept Loan Offer
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeclineLoanOffer(loan)}
                                  className="px-4 py-2 rounded-xl bg-white hover:bg-rose-50 border border-slate-300 text-slate-700 hover:text-rose-700 font-sans font-semibold text-xs cursor-pointer transition-colors"
                                >
                                  Decline Offer
                                </button>
                              </div>
                            )}

                            {!isGiven && loan.status === 'active' && (
                              <button
                                type="button"
                                onClick={() => handlePayAheadLoan(loan, timeline.remainingBalance)}
                                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs cursor-pointer transition-colors"
                              >
                                Pay Ahead ({timeline.remainingBalance.toLocaleString()} {loan.coinSymbol})
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
      )}

      {/* Bank Application Modal (Centered, without Capital Reserves USD) */}
      {bankModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 text-center">
            <div className="relative flex flex-col items-center justify-center text-center pt-1">
              <button
                type="button"
                onClick={() => setBankModalOpen(false)}
                aria-label="Close modal"
                className="absolute right-0 top-0 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
              <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider mb-2">
                {isAdmin ? 'Instant Admin Clearing Charter' : 'Clearing Institution License'}
              </span>
              <h3 className="text-lg font-bold text-slate-900 text-center">
                {isAdmin ? 'Activate Sovereign Clearing Bank' : 'Apply to Become a Clearing Bank'}
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 text-center max-w-xs mx-auto">
                {isAdmin
                  ? 'Admin Clearing Banks activate immediately with no approval required and lend held Final Currencies from their Final Wallet.'
                  : 'Licensed banks can only loan out the Final Currencies and exact amounts held in their Final Wallet.'}
              </p>
            </div>

            <form onSubmit={handleApplyForBank} className="space-y-4 text-xs text-center">
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-slate-700 text-center">Institution / Bank Name</label>
                <input
                  type="text"
                  required
                  value={institutionName}
                  onChange={e => setInstitutionName(e.target.value)}
                  placeholder="e.g. Zurich Prime Clearing Bank"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium text-center"
                />
              </div>

              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-slate-700 text-center">Clearing Mandate &amp; Reason</label>
                <textarea
                  rows={3}
                  value={institutionReason}
                  onChange={e => setInstitutionReason(e.target.value)}
                  placeholder="Describe your intended liquidity provisioning and final coin lending operations..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium resize-none text-center"
                />
              </div>

              <div className="pt-2 flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setBankModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer"
                >
                  {isAdmin ? 'Activate Bank Immediately' : 'Submit Application'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Issue Final Coin Loan Modal (Centered, Strict Final Wallet Currency & Balance Cap) */}
      {loanModalOpen && (() => {
        const parsedLoanAmt = parseFloat(loanAmount) || 0;
        const maxLoanable = selectedLoanCoinObj?.balance || 0;
        const hasHeldCoin = ownedFinalCoinsForLoan.length > 0 && !!selectedLoanCoinObj && maxLoanable > 0;
        const exceedsHeldBalance = hasHeldCoin && parsedLoanAmt > maxLoanable;
        const canSubmitLoan = hasHeldCoin && parsedLoanAmt > 0 && !exceedsHeldBalance && borrowerHandle.trim().length > 1;

        return (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto text-center">
            <div className="relative flex flex-col items-center justify-center text-center pt-1">
              <button
                type="button"
                onClick={() => setLoanModalOpen(false)}
                aria-label="Close modal"
                className="absolute right-0 top-0 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
              <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider mb-2">
                Inter-Bank Loan Desk
              </span>
              <h3 className="text-lg font-bold text-slate-900 text-center">
                {borrowerHandle.trim() && borrowerHandle.trim() !== '@'
                  ? `Issue Loan to @${borrowerHandle.trim().replace(/^@/, '')}`
                  : 'Issue Final Coin Loan'}
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 text-center">
                You may only loan out the Final Currency and amount you hold in your Final Wallet.
              </p>
            </div>

            <form onSubmit={handleIssueLoan} className="space-y-4 text-xs text-center">
              <div className="space-y-1.5 text-center">
                <label className="block font-semibold text-slate-700 text-center">Borrower Handle / User</label>
                <input
                  type="text"
                  required
                  value={borrowerHandle}
                  onChange={e => setBorrowerHandle(e.target.value)}
                  placeholder="@elena_rostova"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium text-center"
                />
              </div>

              <div className="space-y-1.5 text-center">
                <div className="flex items-center justify-center gap-2">
                  <label className="font-semibold text-slate-700 text-center">
                    Loan Amount {selectedLoanCoinObj ? `(${selectedLoanCoinObj.symbol})` : ''}
                  </label>
                  {selectedLoanCoinObj && (
                    <button
                      type="button"
                      onClick={() => setLoanAmount(String(selectedLoanCoinObj.balance))}
                      className="text-[10px] font-mono font-bold text-amber-700 hover:text-amber-900 underline cursor-pointer"
                    >
                      Max: {selectedLoanCoinObj.balance.toLocaleString()}
                    </button>
                  )}
                </div>
                <input
                  type="number"
                  min="0.01"
                  max={hasHeldCoin ? maxLoanable : undefined}
                  step="any"
                  required
                  disabled={!hasHeldCoin}
                  value={loanAmount}
                  onChange={e => setLoanAmount(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-bold text-slate-900 text-center tabular-nums disabled:opacity-50"
                />
                {exceedsHeldBalance && (
                  <p className="text-[11px] font-bold text-rose-600 text-center">
                    Exceeds your held {selectedLoanCoinObj?.symbol} balance ({maxLoanable.toLocaleString()} {selectedLoanCoinObj?.symbol} available).
                  </p>
                )}
              </div>

              {/* Searchable Select Final Coin from Final Wallet */}
              <div className="space-y-2 text-center">
                <label className="block font-semibold text-slate-700 text-center">Select Held Final Coin</label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={loanCoinSearch}
                    onChange={e => setLoanCoinSearch(e.target.value)}
                    placeholder="Search your Final Wallet coins (e.g. AFNL, WOLF)..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs text-slate-900 text-center bg-slate-50/70"
                  />
                </div>
                <div className="max-h-36 overflow-y-auto rounded-2xl border border-slate-200 bg-slate-50/60 p-1.5 space-y-1">
                  {filteredFinalCoinsForLoan.length === 0 ? (
                    <div className="py-4 text-[11px] text-rose-600 font-semibold text-center">
                      {ownedFinalCoinsForLoan.length === 0
                        ? 'No Final Coins with a positive balance found in your Final Wallet.'
                        : `No held Final Coins matching "${loanCoinSearch}".`}
                    </div>
                  ) : (
                    filteredFinalCoinsForLoan.map((coin) => {
                      const isSelected = coin.symbol === loanSymbol;
                      return (
                        <button
                          key={coin.id || coin.symbol}
                          type="button"
                          onClick={() => setLoanSymbol(coin.symbol)}
                          className={`w-full px-3 py-2 rounded-xl border text-left flex items-center justify-between gap-2 transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-100/80 border-amber-400 text-slate-900 shadow-2xs'
                              : 'bg-white border-slate-200/80 text-slate-700 hover:border-amber-300'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-700 shrink-0" />}
                            <div className="min-w-0">
                              <div className="font-mono font-bold text-xs text-slate-900 truncate">{coin.symbol}</div>
                              <div className="text-[10px] text-slate-500 truncate">{coin.name}</div>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <div className="font-mono font-bold text-[11px] text-emerald-700 tabular-nums">
                              {coin.balance.toLocaleString()} {coin.symbol}
                            </div>
                            <div className="text-[9px] text-slate-400">Max Loanable</div>
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
                {selectedLoanCoinObj && (
                  <div className="text-[11px] text-slate-500 font-mono tabular-nums text-center">
                    Selected: <strong className="text-slate-900">{selectedLoanCoinObj.symbol}</strong> · Held Balance:{' '}
                    <strong className="text-emerald-700">
                      {selectedLoanCoinObj.balance.toLocaleString()} {selectedLoanCoinObj.symbol}
                    </strong>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="space-y-1.5 text-center">
                  <label className="block font-semibold text-slate-700 text-center">Interest Rate (% APR)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    required
                    value={loanInterest}
                    onChange={e => setLoanInterest(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium text-center"
                  />
                </div>
                <div className="space-y-1.5 text-center">
                  <label className="block font-semibold text-slate-700 text-center">Term (Days)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={loanTermDays}
                    onChange={e => setLoanTermDays(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium text-center"
                  />
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-1 text-center">
                <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-800 inline-flex items-center justify-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Estimated Monthly Installment</span>
                </div>
                <div className="text-base font-mono font-bold text-slate-900 tabular-nums">
                  {estimatedLoanMonthlyInstallment.toLocaleString()} {selectedLoanCoinObj?.symbol || loanSymbol || 'FC'} / month
                </div>
                <div className="text-[10px] text-slate-600">
                  Sent as a Loan Offer to the borrower&apos;s Internal Banking for final approval
                </div>
              </div>

              <div className="pt-2 flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setLoanModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!canSubmitLoan}
                  className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Issue Loan
                </button>
              </div>
            </form>
          </div>
        </div>
        );
      })()}

      {/* Tier 1 Error Modal */}
      {tierErrorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white border border-rose-200 rounded-3xl p-6 shadow-2xl space-y-4 text-left animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6" />
              </div>
              <button
                type="button"
                onClick={() => setTierErrorModal(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">{tierErrorModal.title}</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">{tierErrorModal.message}</p>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Required: <strong>Tier 1 Verification (1 Verified Legal ID)</strong> · Free ($0/mo)</span>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setTierErrorModal(null);
                  if (onOpenVerification) {
                    onOpenVerification();
                  } else if (onNavigateToSettings) {
                    onNavigateToSettings();
                  }
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{tierErrorModal.actionLabel || 'Verify Tier 1 Now'}</span>
              </button>
              <button
                type="button"
                onClick={() => setTierErrorModal(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
