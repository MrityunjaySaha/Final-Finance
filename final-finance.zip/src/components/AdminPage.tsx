import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  FileText, 
  Scale, 
  Search, 
  Filter, 
  Building2, 
  RefreshCw, 
  Lock, 
  Eye, 
  UserCheck, 
  Clock, 
  ArrowUpRight, 
  Landmark, 
  Sliders, 
  Database,
  ArrowRight,
  Shield,
  Layers,
  Sparkles,
  Coins,
  MessageSquare,
  Users,
  Activity
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { AdminIPODesk } from './admin/AdminIPODesk';
import { AdminRequestsDesk } from './admin/AdminRequestsDesk';
import { AdminTransactionsDesk } from './admin/AdminTransactionsDesk';
import { AdminAccountingDesk } from './admin/AdminAccountingDesk';
import { AdminDeactivatedDesk } from './admin/AdminDeactivatedDesk';
import { AdminFeedbackDesk } from './admin/AdminFeedbackDesk';
import { getStoredIPORequests, IPO_UPDATED_EVENT } from '../data/stocksData';
import { getRegisteredUsers } from '../services/firebaseAuth';

interface AdminPageProps {
  currentUser: AuthSession;
  onNavigateToVaults?: () => void;
  onNavigateToMarketplace?: () => void;
  onNavigateToSuperadmin?: () => void;
  onViewProfile?: (userId: string) => void;
}

interface EscrowDispute {
  id: string;
  tradeTitle: string;
  offeredAsset: string;
  requestedAsset: string;
  buyerHandle: string;
  sellerHandle: string;
  valueUSD: number;
  status: 'pending_review' | 'audit_approved' | 'escalated' | 'resolved';
  reportedReason: string;
  timestamp: string;
}

interface VerificationCandidate {
  id: string;
  name: string;
  handle: string;
  email: string;
  idDoc1: string;
  idDoc1Type: string;
  idDoc2: string;
  idDoc2Type: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

interface AuditLogEntry {
  id: string;
  action: string;
  actor: string;
  target: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'critical';
}

export const AdminPage: React.FC<AdminPageProps> = ({
  currentUser,
  onNavigateToVaults,
  onNavigateToMarketplace,
  onNavigateToSuperadmin,
  onViewProfile,
}) => {
  const { vaults = [], listings = [], addToast, setCurrentTab } = useApp();
  const [activeTab, setActiveTab] = useState<'escrow' | 'kyc' | 'ipos' | 'audits' | 'listings' | 'requests' | 'transactions' | 'accounting' | 'deactivated' | 'feedback'>('requests');
  const [searchQuery, setSearchQuery] = useState('');
  const [storedIPOs, setStoredIPOs] = useState(() => getStoredIPORequests());

  React.useEffect(() => {
    const handleSync = () => setStoredIPOs(getStoredIPORequests());
    window.addEventListener(IPO_UPDATED_EVENT, handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener(IPO_UPDATED_EVENT, handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  const pendingIPOCount = storedIPOs.filter(
    (i) => i.status === 'pending_admin_approval' || i.status === 'delist_pending_admin_approval'
  ).length;

  // Sample State for Escrow Disputes
  const [disputes, setDisputes] = useState<EscrowDispute[]>([
    {
      id: 'disp-801',
      tradeTitle: '100 oz Fine Gold Bullion for GPU Cluster Share',
      offeredAsset: '100 oz LBMA Gold (Zurich Vault #04)',
      requestedAsset: '8x NVIDIA H100 GPU Cluster Capacity (30 Days)',
      buyerHandle: '@marcus_vance',
      sellerHandle: '@sterling_vault',
      valueUSD: 284000,
      status: 'pending_review',
      reportedReason: 'Custody verification requested for Zurich depository serial certificate #LBMA-9941-ZUR.',
      timestamp: '18m ago',
    },
    {
      id: 'disp-802',
      tradeTitle: 'Tokyo Prime Commercial Real Estate Lien Swap',
      offeredAsset: 'Ginza Commercial Plaza 0.5% Tokenized Deed',
      requestedAsset: 'Singapore Sovereign Bond Basket ($500k)',
      buyerHandle: '@elena_rostova',
      sellerHandle: '@tokyo_assets',
      valueUSD: 520000,
      status: 'audit_approved',
      reportedReason: 'Title transfer escrow notary notarization verified by Tokyo Legal Desk.',
      timestamp: '1h ago',
    },
    {
      id: 'disp-803',
      tradeTitle: 'Crude Oil Delivery Allocation OTC',
      offeredAsset: '5,000 BBL WTI Crude Oil Tanker Voucher (Rotterdam)',
      requestedAsset: 'Treasury Yield Note 2028 Allocation',
      buyerHandle: '@energy_trader_99',
      sellerHandle: '@rotterdam_desk',
      valueUSD: 365000,
      status: 'pending_review',
      reportedReason: 'Rotterdam terminal receipt stamp review required before release.',
      timestamp: '3h ago',
    }
  ]);

  // Verification Candidates Queue ($2/mo ID subscriptions)
  const [candidates, setCandidates] = useState<VerificationCandidate[]>([
    {
      id: 'cand-1',
      name: 'Julian Vance',
      handle: '@julian_vance',
      email: 'julian.vance@institutional.ch',
      idDoc1: 'CH_Passport_JulianVance.pdf',
      idDoc1Type: 'Swiss Passport',
      idDoc2: 'CreditSuisse_BankStatement_2026.pdf',
      idDoc2Type: 'Certified Bank Proof of Solvency',
      submittedAt: '24m ago',
      status: 'pending',
    },
    {
      id: 'cand-2',
      name: 'Dr. Evelyn Reed',
      handle: '@evelyn_reed',
      email: 'evelyn@biofund.org',
      idDoc1: 'US_Passport_Evelyn_Reed.pdf',
      idDoc1Type: 'US Passport',
      idDoc2: 'NIH_Institutional_Credential.pdf',
      idDoc2Type: 'Official Government ID',
      submittedAt: '2h ago',
      status: 'pending',
    },
    {
      id: 'cand-3',
      name: 'Kenji Sato',
      handle: '@kenji_sato',
      email: 'kenji@tokyoconsortium.jp',
      idDoc1: 'Japan_MyNumber_Encrypted.pdf',
      idDoc1Type: 'National ID Card',
      idDoc2: 'Tokyo_Gas_Utility_Address.pdf',
      idDoc2Type: 'Utility Bill Proof of Address',
      submittedAt: '5h ago',
      status: 'approved',
    }
  ]);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'log-101',
      action: 'Escrow Settlement Release Approved',
      actor: currentUser.name || 'Admin Officer',
      target: 'Trade #disp-802 ($520,000 USD)',
      timestamp: 'Just now',
      severity: 'info',
    },
    {
      id: 'log-102',
      action: 'KYC Document Verification Verified',
      actor: 'Admin System Bot',
      target: 'User @kenji_sato ($2/mo subscription activated)',
      timestamp: '5h ago',
      severity: 'info',
    },
    {
      id: 'log-103',
      action: 'Zurich Vault Reserve Balance Reconciled',
      actor: 'Zurich Depository Custodian',
      target: 'Vault #1 (NAV: $1,420,000,000)',
      timestamp: '8h ago',
      severity: 'info',
    },
    {
      id: 'log-104',
      action: 'High-Value Listing Flagged for Manual Review',
      actor: 'Automated Risk Engine',
      target: 'Listing #LST-904 ($850,000 Gold Consignment)',
      timestamp: '12h ago',
      severity: 'warning',
    }
  ]);

  const handleApproveDispute = (id: string) => {
    setDisputes((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: 'audit_approved' } : d))
    );
    addToast({
      type: 'success',
      title: 'Escrow Released',
      message: `Escrow trade ${id} has been audit-approved and settlement released to counterparty.`,
    });
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        action: 'Escrow Trade Released',
        actor: currentUser.name,
        target: `Trade ${id}`,
        timestamp: 'Just now',
        severity: 'info',
      },
      ...prev,
    ]);
  };

  const handleEscalateDispute = (id: string) => {
    setDisputes((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: 'escalated' } : d))
    );
    addToast({
      type: 'error',
      title: 'Escalated to Superadmin',
      message: `Trade ${id} flagged and escalated to sovereign dispute board.`,
    });
  };

  const handleApproveKYC = (id: string, name: string) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'approved' } : c))
    );
    addToast({
      type: 'success',
      title: 'KYC Approved',
      message: `Verification badge and $2/mo tier activated for ${name}.`,
    });
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        action: 'KYC Approved & Badge Issued',
        actor: currentUser.name,
        target: `Candidate ${name}`,
        timestamp: 'Just now',
        severity: 'info',
      },
      ...prev,
    ]);
  };

  const handleRejectKYC = (id: string, name: string) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'rejected' } : c))
    );
    addToast({
      type: 'error',
      title: 'KYC Rejected',
      message: `Verification application for ${name} rejected. Requesting clearer documentation.`,
    });
  };

  const registeredUsersMap = getRegisteredUsers();
  const registeredCount = Object.keys(registeredUsersMap).length;
  const activeCount = Math.max(1, Math.floor(registeredCount * 0.85));

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-16">
      {/* Top Banner Header */}
      <div className="border-b border-slate-200 bg-white shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col items-center justify-center text-center gap-4">
            <div className="space-y-1 text-center">
              <div className="flex flex-col items-center justify-center gap-2.5">
                <div className="p-2 rounded-xl bg-slate-100 text-slate-700 border border-slate-200">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="text-center">
                  <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight text-center">
                    Admin Operations
                  </h1>
                  <p className="text-xs text-slate-500 mt-0.5 text-center">
                    {currentUser.email || 'awesomedbz@gmail.com'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dynamic Metrics Ribbon */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="grid grid-cols-2 gap-4">
          {/* Signup Users */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs flex items-center gap-4">
            <div className="p-2.5 bg-indigo-50 rounded-xl text-indigo-600 border border-indigo-100/50 shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Signed Up Users</span>
              <span className="text-xl font-bold text-slate-900 tracking-tight">{registeredCount}</span>
            </div>
          </div>

          {/* Active Users */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs flex items-center gap-4">
            <div className="p-2.5 bg-emerald-50 rounded-xl text-emerald-600 border border-emerald-100/50 shrink-0 relative">
              <Activity className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-emerald-500 rounded-full border border-white animate-ping" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-emerald-500 rounded-full border border-white" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Active Users (24h)</span>
              <span className="text-xl font-bold text-slate-900 tracking-tight">{activeCount}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="flex border-b border-slate-200 gap-2 sm:gap-6 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('requests')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 cursor-pointer transition-colors whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'requests'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4 text-amber-600" />
            <span>Requests</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('transactions')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 cursor-pointer transition-colors whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'transactions'
                ? 'border-blue-600 text-blue-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4 text-blue-600" />
            <span>Transactions</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('accounting')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 cursor-pointer transition-colors whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'accounting'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Scale className="w-4 h-4 text-emerald-600" />
            <span>Accounting</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('deactivated')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 cursor-pointer transition-colors whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'deactivated'
                ? 'border-rose-600 text-rose-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Lock className="w-4 h-4 text-rose-600" />
            <span>Deactivated</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('feedback')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 cursor-pointer transition-colors whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'feedback'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-indigo-600" />
            <span>App Feedback</span>
          </button>


        </div>

        {/* Tab: Sovereign Requests Desk */}
        {activeTab === 'requests' && (
          <div className="mt-6">
            <AdminRequestsDesk
              onNotify={(msg, type) => {
                addToast({
                  type: ((type === 'warning' ? 'info' : type) || 'info') as any,
                  title: 'Sovereign Requests',
                  message: msg,
                });
              }}
            />
          </div>
        )}

        {/* Tab: Global Transactions Ledger */}
        {activeTab === 'transactions' && (
          <div className="mt-6">
            <AdminTransactionsDesk
              onNotify={(msg, type) => {
                addToast({
                  type: ((type === 'warning' ? 'info' : type) || 'info') as any,
                  title: 'Ledger Synchronized',
                  message: msg,
                });
              }}
            />
          </div>
        )}

        {/* Tab: Accounting */}
        {activeTab === 'accounting' && (
          <div className="mt-6">
            <AdminAccountingDesk onViewProfile={onViewProfile || ((id) => console.log('Profile:', id))} />
          </div>
        )}

        {/* Tab: Deactivated Accounts */}
        {activeTab === 'deactivated' && (
          <div className="mt-6">
            <AdminDeactivatedDesk 
              onViewProfile={onViewProfile || ((id) => console.log('Profile:', id))}
              onNotify={(msg, type) => {
                addToast({
                  type: (type || 'info') as any,
                  title: 'Account Control',
                  message: msg,
                });
              }}
            />
          </div>
        )}

        {/* Tab: User Experience Feedback Logs */}
        {activeTab === 'feedback' && (
          <div className="mt-6">
            <AdminFeedbackDesk
              currentUser={currentUser}
              onNotify={(msg, type) => {
                addToast({
                  type: (type || 'info') as any,
                  title: 'App Feedback Log',
                  message: msg,
                });
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
};
