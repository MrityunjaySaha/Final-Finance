import React, { useState, useEffect } from 'react';
import { Send, CheckCircle2, ShieldCheck, UserCheck, Zap, AlertCircle, MessageSquare } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { getTransferCurrenciesForUser } from '../utils/transferService';
import { createLedgerItemFromP2PTransfer, recordLedgerTransaction } from '../utils/universalLedgerBridge';
import { applyCurrencyWalletDelta } from '../utils/walletBalanceUpdater';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { enqueueUserNotification } from '../services/socialService';
import { getFinalCoinUsdRate } from '../utils/tokenDollarEquivalence';

export const TransferFundsView: React.FC = () => {
  const { currentUser, addToast } = useApp();
  const userId = currentUser.id || currentUser.handle?.replace('@', '') || 'guest_trader';
  const userName = currentUser.name || 'Sovereign Trader';

  // Load all Final Coins from user's Final Wallet
  const [finalCoins, setFinalCoins] = useState(() =>
    getTransferCurrenciesForUser(userId, currentUser).finalCoins
  );

  useEffect(() => {
    const syncCoins = () => {
      setFinalCoins(getTransferCurrenciesForUser(userId, currentUser).finalCoins);
    };
    syncCoins();
    window.addEventListener('final_finance_wallets_updated', syncCoins);
    window.addEventListener('final_finance_custom_coins_updated', syncCoins);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', syncCoins);
      window.removeEventListener('final_finance_custom_coins_updated', syncCoins);
    };
  }, [userId, currentUser]);

  // Default selected coin to AFNL or first coin
  const [selectedSymbol, setSelectedSymbol] = useState<string>(() => {
    const afnl = finalCoins.find(c => c.symbol === 'AFNL');
    if (afnl) return 'AFNL';
    return finalCoins[0]?.symbol || 'AFNL';
  });

  const [amount, setAmount] = useState<number | ''>('');
  const [memo, setMemo] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [avatarFailed, setAvatarFailed] = useState(false);

  const selectedCoin = finalCoins.find(c => c.symbol === selectedSymbol) || finalCoins[0];
  const maxBalance = Number(selectedCoin?.balance ?? 0);
  const parsedAmount = typeof amount === 'number' ? amount : 0;
  const isInsufficient = parsedAmount > maxBalance;

  const handlePercentage = (pct: number) => {
    const calculated = (maxBalance * pct) / 100;
    setAmount(Number(calculated.toFixed(2)));
    setError(null);
  };

  const handleMax = () => {
    setAmount(maxBalance);
    setError(null);
  };

  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedSymbol) {
      setError('Please select a Final Coin.');
      return;
    }

    if (typeof amount !== 'number' || amount <= 0) {
      setError('Please enter a valid transfer amount.');
      return;
    }

    if (amount > maxBalance) {
      setError(`Insufficient balance. Available: ${maxBalance.toLocaleString()} ${selectedSymbol}.`);
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Deduct from sender wallet
      const currentWallets = getStoredUserWallets(userId);
      const updatedCoins = (currentWallets.finalCoins || []).map(fc => {
        if (fc.symbol.toUpperCase() === selectedSymbol.toUpperCase()) {
          return { ...fc, balance: Math.max(0, fc.balance - amount) };
        }
        return fc;
      });

      saveStoredUserWallets(userId, {
        ...currentWallets,
        finalCoins: updatedCoins
      });

      // 2. Credit recipient (@jordan_belfort)
      const recipientHandle = 'jordan_belfort';
      applyCurrencyWalletDelta({
        userId: recipientHandle,
        currencySymbol: selectedSymbol,
        currencyName: selectedCoin?.name || `${selectedSymbol} Final Coin`,
        delta: amount,
        utilityNote: `P2P Transfer from @${userId}${memo ? `: ${memo}` : ''}`
      });

      const computedUSD = Math.round(amount * getFinalCoinUsdRate(selectedSymbol) * 100) / 100;

      // 3. Record Universal Ledger Transaction
      const senderLedgerItem = createLedgerItemFromP2PTransfer({
        amount,
        amountUSD: computedUSD,
        coinSymbol: selectedSymbol,
        coinName: selectedCoin?.name || `${selectedSymbol} Final Coin`,
        mode: 'final_coin',
        senderUser: { id: userId, name: userName, handle: userId },
        recipientUser: { id: recipientHandle, name: 'Jordan Belfort', handle: recipientHandle },
        memo: memo.trim() || undefined,
        isSender: true
      });
      recordLedgerTransaction(userId, senderLedgerItem);

      const recipientLedgerItem = createLedgerItemFromP2PTransfer({
        amount,
        amountUSD: computedUSD,
        coinSymbol: selectedSymbol,
        coinName: selectedCoin?.name || `${selectedSymbol} Final Coin`,
        mode: 'final_coin',
        senderUser: { id: userId, name: userName, handle: userId },
        recipientUser: { id: recipientHandle, name: 'Jordan Belfort', handle: recipientHandle },
        memo: memo.trim() || undefined,
        isSender: false
      });
      recordLedgerTransaction(recipientHandle, recipientLedgerItem);

      // 4. Notifications
      dispatchGlobalNotification({
        title: `Sent ${amount.toLocaleString()} ${selectedSymbol}`,
        description: `Transferred ${amount.toLocaleString()} ${selectedSymbol} to @jordan_belfort.`,
        type: 'wallet',
        targetTab: 'wallets',
        amount,
        currency: selectedSymbol,
        tone: 'success'
      });

      enqueueUserNotification([recipientHandle], {
        title: `Received ${amount.toLocaleString()} ${selectedSymbol}`,
        description: `${userName} sent you ${amount.toLocaleString()} ${selectedSymbol}${memo ? ` (${memo})` : ''}.`,
        type: 'wallet',
        targetTab: 'wallets',
        amount,
        currency: selectedSymbol
      });

      setSuccess(true);
      addToast({
        type: 'success',
        title: 'Transfer Complete',
        message: `Successfully transferred ${amount.toLocaleString()} ${selectedSymbol} to @jordan_belfort.`
      });
    } catch (err) {
      console.error('Transfer execution error:', err);
      setError('An error occurred during ledger settlement.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="w-full max-w-lg bg-white rounded-3xl p-8 text-center space-y-6 shadow-2xl border border-emerald-100 animate-in fade-in duration-300">
          <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center animate-bounce shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Settled Successfully!</h2>
            <p className="text-slate-600 text-sm">
              You have successfully transferred <span className="font-bold text-slate-900 tabular-nums">{parsedAmount.toLocaleString()} {selectedSymbol}</span> to <span className="font-bold text-blue-600">@jordan_belfort</span>.
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs font-mono text-slate-500 space-y-1">
            <p className="font-bold text-slate-700">Universal Ledger Cryptographic Receipt</p>
            <p>Protocol: Zero-Fee Sovereign P2P Clearing</p>
            <p>Status: Immutable &amp; Settled</p>
          </div>
          <button
            onClick={() => {
              setSuccess(false);
              setAmount('');
              setMemo('');
            }}
            className="w-full py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm transition-all cursor-pointer shadow-lg"
          >
            Make Another Transfer
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full min-h-[85vh] flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200/80 p-6 sm:p-10 flex flex-col items-center text-center space-y-8 backdrop-blur-xl">
        
        {/* Header Section */}
        <div className="space-y-2.5 w-full flex flex-col items-center text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold uppercase tracking-wider">
            <Zap className="w-3.5 h-3.5 fill-current text-amber-500" />
            <span>Universal Ledger</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">Transfer Funds</h1>
          <p className="text-slate-500 text-sm font-medium">Direct zero-fee peer-to-peer sovereign settlement</p>
        </div>

        {/* Destination Node: Jordan Belfort */}
        <div className="w-full p-5 rounded-2xl bg-slate-50 border border-slate-200/70 flex flex-col items-center justify-center space-y-3 shadow-xs text-center">
          <div className="relative">
            {!avatarFailed ? (
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80"
                alt="Jordan Belfort"
                referrerPolicy="no-referrer"
                onError={() => setAvatarFailed(true)}
                className="w-16 h-16 rounded-full object-cover border-2 border-amber-500 shadow-md"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-slate-900 text-white font-bold text-lg flex items-center justify-center border-2 border-amber-500 shadow-md">
                JB
              </div>
            )}
            <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-1 rounded-full shadow-xs" title="Verified Peer">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="space-y-0.5 text-center">
            <h3 className="text-base font-bold text-slate-900 flex items-center justify-center gap-1.5">
              <span>Jordan Belfort</span>
              <UserCheck className="w-4 h-4 text-blue-600" />
            </h3>
            <p className="text-xs font-semibold text-blue-600">@jordan_belfort</p>
          </div>
          <div className="flex items-center justify-center gap-2 pt-1 text-[11px]">
            <span className="text-slate-500 font-semibold uppercase tracking-wider">
              Destination Node
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="text-emerald-700 font-bold uppercase tracking-wider">
              Verified Peer
            </span>
          </div>
        </div>

        {/* Transfer Form (Centered) */}
        <form onSubmit={handleExecuteTransfer} className="w-full space-y-6 text-center">
          {error && (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center justify-center gap-2.5 text-center">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. Select Final Coin */}
          <div className="space-y-3 text-center">
            <div className="flex flex-col items-center justify-center gap-1.5 px-1">
              <label className="text-xs font-extrabold uppercase tracking-widest text-slate-700">Select Final Coin</label>
              <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-md border border-amber-200/60">
                Final Currency &amp; Final Coins Only
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-64 overflow-y-auto pr-1">
              {finalCoins.map((coin) => {
                const isSelected = selectedSymbol === coin.symbol;
                const bal = Number(coin.balance || 0);
                return (
                  <button
                    key={coin.symbol}
                    type="button"
                    onClick={() => {
                      setSelectedSymbol(coin.symbol);
                      setError(null);
                    }}
                    className={`p-3.5 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/60 shadow-sm ring-2 ring-amber-500/20'
                        : 'border-slate-200 bg-slate-50 hover:bg-slate-100/80'
                    }`}
                  >
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-xs font-extrabold text-slate-900 uppercase">{coin.symbol}</span>
                      <span className="text-xs font-bold text-slate-900 tabular-nums">{bal.toLocaleString()} {coin.symbol}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium truncate max-w-full">{coin.name}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Enter Amount */}
          <div className="space-y-3 text-center">
            <div className="flex flex-col items-center justify-center gap-1 px-1">
              <label className="text-xs font-extrabold uppercase tracking-widest text-slate-700">2. Enter Amount</label>
              <span className="text-xs font-bold text-slate-500 tabular-nums">
                Available: <span className="text-slate-900 font-extrabold">{maxBalance.toLocaleString()} {selectedSymbol}</span>
              </span>
            </div>

            <div className="relative">
              <input
                type="number"
                step="any"
                placeholder="0.00"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value === '' ? '' : Number(e.target.value));
                  setError(null);
                }}
                className={`w-full p-4 rounded-2xl border bg-slate-50 text-base font-extrabold text-center focus:ring-2 outline-none px-16 tabular-nums ${
                  isInsufficient
                    ? 'border-rose-400 text-rose-900 focus:ring-rose-500 bg-rose-50/20'
                    : 'border-slate-200 focus:ring-amber-500'
                }`}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-extrabold text-slate-500 uppercase pointer-events-none">
                {selectedSymbol}
              </span>
            </div>

            {/* Percentage Shortcuts */}
            <div className="grid grid-cols-4 gap-2 pt-1 max-w-sm mx-auto">
              <button
                type="button"
                onClick={() => handlePercentage(25)}
                className="py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer border border-slate-200"
              >
                25%
              </button>
              <button
                type="button"
                onClick={() => handlePercentage(50)}
                className="py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer border border-slate-200"
              >
                50%
              </button>
              <button
                type="button"
                onClick={() => handlePercentage(75)}
                className="py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer border border-slate-200"
              >
                75%
              </button>
              <button
                type="button"
                onClick={handleMax}
                className="py-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-extrabold transition-all cursor-pointer border border-amber-300"
              >
                MAX
              </button>
            </div>

            {isInsufficient && (
              <p className="text-xs font-bold text-rose-600 flex items-center justify-center gap-1 px-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>Insufficient balance. Available: {maxBalance.toLocaleString()} {selectedSymbol}.</span>
              </p>
            )}
          </div>

          {/* 3. Transfer Memo / Note (Optional) */}
          <div className="space-y-3 text-center">
            <label className="text-xs font-extrabold uppercase tracking-widest text-slate-700 px-1 block">
              3. Transfer Memo / Note (Optional)
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="e.g. Escrow settlement, barter fee, gift..."
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                className="w-full p-4 rounded-2xl border border-slate-200 bg-slate-50 text-sm font-semibold text-center focus:ring-2 focus:ring-slate-900 outline-none px-11"
              />
              <MessageSquare className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            </div>
          </div>

          {/* Send Funds Button */}
          <button
            type="submit"
            disabled={isSubmitting || parsedAmount <= 0 || isInsufficient}
            className="w-full py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-sm transition-all shadow-xl active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2.5 cursor-pointer mt-4"
          >
            {isSubmitting ? (
              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4 -rotate-12" />
                <span>Send Funds to @jordan_belfort</span>
              </>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
