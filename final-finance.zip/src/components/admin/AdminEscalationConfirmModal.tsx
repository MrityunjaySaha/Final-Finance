import React from 'react';
import { CheckCircle2, Search, X, ShieldAlert, FileText, AlertCircle } from 'lucide-react';
import { AdminEscalation } from '../../services/feedbackService';

interface AdminEscalationConfirmModalProps {
  escalation: AdminEscalation;
  targetStatus: 'investigating' | 'resolved';
  notes?: string;
  onClose: () => void;
  onConfirm: () => void;
}

export const AdminEscalationConfirmModal: React.FC<AdminEscalationConfirmModalProps> = ({
  escalation,
  targetStatus,
  notes,
  onClose,
  onConfirm,
}) => {
  const isInvestigating = targetStatus === 'investigating';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div
          className={`px-6 py-5 border-b flex items-center justify-between ${
            isInvestigating
              ? 'border-indigo-100 bg-indigo-50/70'
              : 'border-emerald-100 bg-emerald-50/70'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border ${
                isInvestigating
                  ? 'bg-indigo-100 text-indigo-700 border-indigo-200'
                  : 'bg-emerald-100 text-emerald-700 border-emerald-200'
              }`}
            >
              {isInvestigating ? (
                <Search className="w-5 h-5" />
              ) : (
                <CheckCircle2 className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="font-serif text-base font-bold text-slate-900">
                {isInvestigating
                  ? 'Confirm Mark as Investigating'
                  : 'Confirm Resolve Advisory & Close'}
              </h3>
              <p
                className={`text-xs font-medium ${
                  isInvestigating ? 'text-indigo-700' : 'text-emerald-700'
                }`}
              >
                Super Admin Security &amp; Advisory Action
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer ${
              isInvestigating ? 'hover:bg-indigo-100' : 'hover:bg-emerald-100'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <p className="text-xs text-slate-600 leading-relaxed">
            {isInvestigating ? (
              <>
                Are you sure you want to mark this advisory ticket as{' '}
                <strong className="text-indigo-900 font-bold">Investigating</strong>?
                This notifies the team that active analysis and verification are underway.
              </>
            ) : (
              <>
                Are you sure you want to finalize and execute{' '}
                <strong className="text-emerald-900 font-bold">Resolve Advisory &amp; Close</strong>?
                This archives the report and locks the advisory status as resolved.
              </>
            )}
          </p>

          {/* Advisory Summary Card */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-start justify-between gap-2">
              <span className="font-bold text-xs text-slate-900 leading-tight">
                {escalation.subject}
              </span>
              <span className="text-[10px] font-mono font-bold text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-200 shrink-0">
                {escalation.id}
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap text-[11px] text-slate-500">
              <span>
                From <strong className="text-slate-700">{escalation.adminName}</strong>
              </span>
              <span>•</span>
              <span
                className={`px-1.5 py-0.2 rounded font-bold uppercase text-[9px] ${
                  escalation.severity === 'critical'
                    ? 'bg-rose-100 text-rose-800'
                    : escalation.severity === 'high'
                    ? 'bg-orange-100 text-orange-800'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {escalation.severity} severity
              </span>
            </div>

            <div className="pt-2 border-t border-slate-200/60 text-[11px] text-slate-600 line-clamp-2 italic">
              "{escalation.message}"
            </div>
          </div>

          {/* Written Notes Preview */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
              <FileText className="w-3 h-3" />
              <span>Response Notes to be Recorded:</span>
            </label>
            <div
              className={`p-3 rounded-xl border text-xs leading-relaxed ${
                notes && notes.trim().length > 0
                  ? 'bg-amber-50/50 border-amber-200 text-slate-800 font-sans'
                  : 'bg-slate-50 border-slate-200 text-slate-400 italic'
              }`}
            >
              {notes && notes.trim().length > 0 ? (
                <span>"{notes.trim()}"</span>
              ) : (
                <span>
                  (No custom notes entered — standard system confirmation will be recorded.)
                </span>
              )}
            </div>
          </div>

          {/* Notice Banner */}
          <div
            className={`p-3.5 rounded-2xl border text-[11px] leading-relaxed flex items-start gap-2.5 ${
              isInvestigating
                ? 'bg-indigo-50/80 border-indigo-200 text-indigo-900'
                : 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
            }`}
          >
            {isInvestigating ? (
              <ShieldAlert className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-bold">
                {isInvestigating ? 'Super Admin Directive' : 'Final Administrative Sign-off'}
              </p>
              <p className="mt-0.5 text-slate-600">
                {isInvestigating
                  ? 'The escalation badge will transition to [INVESTIGATING] across root audit desks and feedback channels.'
                  : 'The advisory will be formally closed and the response notes will be preserved in the persistent cryptographic log.'}
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-end gap-2.5 bg-slate-50/70">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-5 py-2 rounded-xl text-xs font-bold text-white shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 ${
              isInvestigating
                ? 'bg-indigo-600 hover:bg-indigo-700'
                : 'bg-emerald-600 hover:bg-emerald-700'
            }`}
          >
            {isInvestigating ? (
              <>
                <Search className="w-3.5 h-3.5" />
                <span>Confirm Mark as Investigating</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Confirm Resolve Advisory &amp; Close</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
