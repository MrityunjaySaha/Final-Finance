export interface VerificationDetails {
  verified: boolean;
  status: 'unverified' | 'pending' | 'verified';
  monthlyFee: number; // 2 ($2/month)
  subscriptionActive: boolean;
  subscriptionPlan: string;
  idDocument1Type: string;
  idDocument1Name: string;
  idDocument1Number?: string;
  idDocument2Type: string;
  idDocument2Name: string;
  idDocument2Issuer?: string;
  verifiedAt?: string;
  nextBillingDate?: string;
  paymentMethod?: string;
  lastFour?: string;
}

export interface AuthSession {
  uid: string;
  id: string; // handle / username (e.g. 'marcus_vance')
  userId?: string;
  handle?: string;
  username?: string;
  name: string;
  email: string;
  avatarUrl?: string;
  coverUrl?: string;
  bio?: string;
  gender?: 'male' | 'female' | 'other' | '';
  role: 'super_admin' | 'admin' | 'vip_user' | 'user' | 'guest';
  provider: 'google' | 'password' | 'demo';
  authMethod?: string;
  subscriptionActive?: boolean;
  createdAt?: string;
  isVerified?: boolean;
  verification?: VerificationDetails;
  user?: {
    name: string;
    email: string;
    avatar?: string;
  };
}

