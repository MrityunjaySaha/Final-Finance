export type CustomCoinType = 'final_coin' | 'stable_coin' | 'crypto';
export type PegCurrency = 'USD' | 'INR' | 'none';

export interface CoinAttachment {
  id: string;
  type: 'photo' | 'video';
  url: string;
  name: string;
  size?: string;
  uploadedAt: string;
  caption?: string;
}

export interface CustomCoin {
  id: string;
  name: string;
  symbol: string;
  coinType: CustomCoinType;
  pegCurrency: PegCurrency;
  pegTargetDisplay: string; // e.g. "$1.00 USD" or "₹1.00 INR" or "Unpegged (Floating Market)"
  pegRateUSD: number; // For USD = 1.0, for INR = 0.0116 ($1 = ~₹86.20), for unpegged = market price
  priceUSD: number;
  totalSupply: number;
  circulatingSupply: number;
  burnedSupply?: number;
  reserveRatioPercent: number; // e.g. 100% or 125%
  reserveBackingDescription: string;
  collateralAssetType?: string; // e.g. 'US Treasury Bills', 'INR Sovereign Bonds', 'Physical Gold', 'Free Market Liquidity'
  decimals: number;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  creatorAvatar?: string;
  isAdminCoin: boolean;
  createdAt: string;
  contractAddress: string;
  network: string;
  logoBg: string;
  iconSymbol: string;
  logoUrl?: string;
  description: string;
  photos?: string[];
  videos?: string[];
  attachments?: CoinAttachment[];
  status: 'active' | 'paused' | 'archived' | 'draft';
  auditScore: number;
  holdersCount: number;
  dailyVolumeUSD: number;
  change24h: number;
  high24h?: number;
  low24h?: number;
}

export interface CoinMintBurnAction {
  id: string;
  coinId: string;
  coinSymbol: string;
  action: 'mint' | 'burn' | 'transfer';
  amount: number;
  timestamp: string;
  txHash: string;
  note?: string;
  recipientAddress?: string;
}

export const MAX_FINAL_COINS_PER_USER = 5; // Strict quota: users can have up to 5 Final Coins created
export const MAX_COINS_PER_TYPE = 5;
export const TOTAL_DIGITAL_CURRENCY_TYPES = 3; // Stablecoin, Final Coin, Cryptocurrency
export const TOTAL_CREATABLE_COINS = 5;
export const MAX_MARKET_COINS_TOTAL = 15;

export interface FinalCoinDeploymentStatus {
  isDeploying: boolean;
  userId: string;
  coinName: string;
  coinSymbol: string;
  currentStepIndex: number;
  steps: string[];
  progressPercent: number;
  contractAddress?: string;
  txHash?: string;
  startTime: number;
  error?: string;
}
