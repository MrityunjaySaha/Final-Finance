import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  Check, 
  Package, 
  Briefcase, 
  Clock, 
  Search, 
  Filter, 
  ArrowLeft,
  Coins,
  Repeat,
  Sparkles,
  ExternalLink,
  Layers,
  Image as ImageIcon,
  Film,
  Globe,
  Users,
  Shield,
  Lock,
  CheckCircle2,
  CheckSquare,
  Square,
  X,
  Gavel,
  Share2,
  Star,
  MessageSquare
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { MarketplaceListing, ListingStatus, ListingVisibility } from '../types/marketplace';
import { UserPublicProfile, FriendGroup, GroupMemberAssignment } from '../types/social';
import { 
  getUserListings, 
  deleteListing, 
  updateListingStatus,
  updateListingVisibility,
  getAuctionBids,
  getAuctionRemainingLabel,
  getCurrentAuctionPriceUSD,
  getAllMarketplaceListings,
  ensureSampleAuctionsForUser
} from '../services/marketplaceService';
import { createTweet } from '../services/tweetingService';
import {
  getReviewsForListing,
  getAverageRatingForListing,
  getUserReviewForListing,
  savePostReview,
  canUserRateListing,
  getBoughtHistoryCategorized,
  POST_RATINGS_UPDATED_EVENT
} from '../services/postRatingService';
import { 
  MAX_CUSTOM_GROUP_MEMBERS,
  getUserFriendGroups, 
  createFriendGroup, 
  updateFriendGroup, 
  deleteFriendGroup,
  resolveAndSortGroupMembers
} from '../services/friendGroupService';
import { getFriendsList, getAllUsers } from '../services/socialService';
import { CreateListingDraftModal } from './CreateListingDraftModal';
import { AuctionBidModal } from './AuctionBidModal';

export type UploadsFilterStatus =
  | 'all'
  | 'draft'
  | 'uploaded'
  | 'sold'
  | 'live_auctions_participating'
  | 'my_auctions'
  | 'history_bought'
  | 'history_sold';

export interface UploadsFocusRestore {
  listingId: string;
  filterStatus?: UploadsFilterStatus;
  boughtSubSection?: 'all' | 'goods' | 'services' | 'auctions';
  myAuctionsSubTab?: 'active' | 'done';
  key: number;
}

interface UploadsPageProps {
  currentUser?: AuthSession | null;
  onNavigateBack?: () => void;
  onViewListingDetail?: (listing: MarketplaceListing) => void;
  focusRestore?: UploadsFocusRestore | null;
  onFocusRestored?: () => void;
}

export const UploadsPage: React.FC<UploadsPageProps> = ({
  currentUser,
  onViewListingDetail,
  focusRestore,
  onFocusRestored,
}) => {
  const activeUid = currentUser?.uid || currentUser?.id || 'guest';

  const [filterStatus, setFilterStatus] = useState<UploadsFilterStatus>(
    () => focusRestore?.filterStatus || 'all'
  );
  const [boughtSubSection, setBoughtSubSection] = useState<'all' | 'goods' | 'services' | 'auctions'>(
    () => focusRestore?.boughtSubSection || 'all'
  );
  const [myAuctionsSubTab, setMyAuctionsSubTab] = useState<'active' | 'done'>(
    () => focusRestore?.myAuctionsSubTab || 'active'
  );
  const [highlightedListingId, setHighlightedListingId] = useState<string | null>(null);
  const [filterVisibility, setFilterVisibility] = useState<'all' | 'public' | 'friends' | 'custom_group' | 'only_me'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [marketplaceVersion, setMarketplaceVersion] = useState(0);
  const [auctionClockTick, setAuctionClockTick] = useState(0);

  const [listings, setListings] = useState<MarketplaceListing[]>(() => {
    const target = currentUser?.id || currentUser?.uid || 'guest';
    const viewer = currentUser?.uid || currentUser?.id || 'guest';
    return getUserListings(target, viewer, true, currentUser?.id);
  });

  const [postRatingsTrigger, setPostRatingsTrigger] = useState(0);

  useEffect(() => {
    const handleRatingsSync = () => setPostRatingsTrigger((prev) => prev + 1);
    const handleMarketplaceSync = () => {
      const target = currentUser?.id || currentUser?.uid || 'guest';
      const viewer = currentUser?.uid || currentUser?.id || 'guest';
      setListings(getUserListings(target, viewer, true, currentUser?.id));
      setMarketplaceVersion((prev) => prev + 1);
    };
    window.addEventListener(POST_RATINGS_UPDATED_EVENT, handleRatingsSync);
    window.addEventListener('final_finance_listings_updated', handleMarketplaceSync);
    window.addEventListener('storage', handleRatingsSync);
    return () => {
      window.removeEventListener(POST_RATINGS_UPDATED_EVENT, handleRatingsSync);
      window.removeEventListener('final_finance_listings_updated', handleMarketplaceSync);
      window.removeEventListener('storage', handleRatingsSync);
    };
  }, [currentUser]);

  useEffect(() => {
    const interval = setInterval(() => {
      setAuctionClockTick((t) => t + 1);
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!focusRestore?.listingId) return;
    if (focusRestore.filterStatus) {
      setFilterStatus(focusRestore.filterStatus);
    }
    if (focusRestore.boughtSubSection) {
      setBoughtSubSection(focusRestore.boughtSubSection);
    }
    if (focusRestore.myAuctionsSubTab) {
      setMyAuctionsSubTab(focusRestore.myAuctionsSubTab);
    }
    setHighlightedListingId(focusRestore.listingId);

    const scrollToTarget = () => {
      if (typeof document === 'undefined') return;
      const el = document.querySelector(`[data-listing-id="${focusRestore.listingId}"]`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    };

    const rafId = requestAnimationFrame(() => {
      scrollToTarget();
      setTimeout(() => {
        scrollToTarget();
        onFocusRestored?.();
      }, 90);
    });

    const clearTimer = setTimeout(() => {
      setHighlightedListingId((prev) => (prev === focusRestore.listingId ? null : prev));
    }, 3500);

    return () => {
      cancelAnimationFrame(rafId);
      clearTimeout(clearTimer);
    };
  }, [focusRestore, onFocusRestored]);

  const allPlatformListings = useMemo(
    () => getAllMarketplaceListings(),
    [listings, marketplaceVersion]
  );

  const participatingAuctions = useMemo(() => {
    const normalizedUserHandle = (currentUser?.handle || currentUser?.id || '')
      .toLowerCase()
      .replace(/^@/, '')
      .replace(/^user-/, '');
    return allPlatformListings.filter(item => {
      if (item.listingIntent !== 'auction' || item.status === 'draft') return false;
      const bids = getAuctionBids(item.id);
      return bids.some(b => {
        const bHandle = (b.bidderHandle || '').toLowerCase().replace(/^@/, '').replace(/^user-/, '');
        return (
          b.bidderId === activeUid ||
          b.bidderId === currentUser?.id ||
          (currentUser?.uid && (b.bidderUid === currentUser.uid || b.bidderId === currentUser.uid)) ||
          (normalizedUserHandle && bHandle === normalizedUserHandle)
        );
      });
    });
  }, [allPlatformListings, activeUid, currentUser, marketplaceVersion]);

  const isMyAuctionDone = (item: MarketplaceListing) => {
    if (item.status === 'sold') return true;
    if (item.auctionConfig?.status === 'settled' || item.auctionConfig?.status === 'ended') return true;
    return getAuctionRemainingLabel(item.auctionConfig?.endTimeIso).isEnded;
  };

  const myAuctions = useMemo(() => {
    return listings.filter(item => item.listingIntent === 'auction');
  }, [listings]);

  const activeMyAuctions = useMemo(() => {
    void auctionClockTick;
    return myAuctions.filter((item) => !isMyAuctionDone(item));
  }, [myAuctions, auctionClockTick]);

  const doneMyAuctions = useMemo(() => {
    void auctionClockTick;
    return myAuctions.filter((item) => isMyAuctionDone(item));
  }, [myAuctions, auctionClockTick]);

  const soldListings = useMemo(() => {
    return listings.filter(item => item.status === 'sold');
  }, [listings]);

  const boughtHistory = useMemo(() => {
    return getBoughtHistoryCategorized(currentUser?.id || activeUid, currentUser?.uid);
  }, [currentUser, activeUid, postRatingsTrigger, listings]);

  const totalBoughtCount =
    boughtHistory.goods.length + boughtHistory.services.length + boughtHistory.auctions.length;

  // Local state for user rating stars and comments on bought postings
  const [postRatingInputs, setPostRatingInputs] = useState<Record<string, { rating: number; comment: string }>>({});

  const handleRatePost = (listing: MarketplaceListing) => {
    if (!currentUser) return;
    const input = postRatingInputs[listing.id];
    const existing = getUserReviewForListing(listing.id, currentUser.id || activeUid, currentUser.uid);
    if (existing) {
      showToast('Finalized listing ratings can only be submitted once.');
      return;
    }
    const ratingValue = input?.rating ?? 5;
    const commentValue = input?.comment !== undefined ? input.comment : '';

    const res = savePostReview({
      listing,
      listingId: listing.id,
      listingTitle: listing.title,
      sellerId: listing.sellerId || listing.userId,
      sellerHandle: listing.sellerHandle || listing.creatorHandle,
      reviewerId: currentUser.id || activeUid,
      reviewerUid: currentUser.uid,
      reviewerName: currentUser.name || 'Verified Trader',
      reviewerAvatar: currentUser.avatarUrl,
      rating: ratingValue,
      comment: commentValue,
    });

    if (res.rejectedReason === 'already_rated') {
      showToast('You have already submitted your one-time rating for this listing.');
      return;
    }
    if (res.rejectedReason === 'own_listing') {
      showToast('You cannot rate or comment on your own listing.');
      return;
    }
    if (res.rejectedReason === 'not_winner') {
      showToast('Only the auction winner can submit a rating and comment.');
      return;
    }
    if (res.rejectedReason === 'not_purchaser') {
      showToast('Only the final purchaser can submit a rating and comment.');
      return;
    }
    if (res.rejectedReason === 'not_finalized') {
      showToast('Only finalized listings can be rated.');
      return;
    }

    showToast('Final rating and comment submitted!');
    setPostRatingsTrigger((k) => k + 1);
  };

  const handleShareListingTweet = (
    listing: MarketplaceListing,
    customNote?: string,
    overrideStatusLabel?: string
  ) => {
    if (!currentUser) return;
    if (listing.status === 'draft') {
      showToast('Drafts cannot be shared on Tweeting. Publish your listing first.');
      return;
    }

    const avg = getAverageRatingForListing(listing.id);
    const reviews = getReviewsForListing(listing.id);
    const userReview = getUserReviewForListing(listing.id, currentUser.id || activeUid, currentUser.uid);
    const pendingInput = postRatingInputs[listing.id];
    const effectiveUserRating = userReview?.rating ?? pendingInput?.rating ?? 5;
    const effectiveUserComment =
      pendingInput?.comment !== undefined ? pendingInput.comment : (userReview?.comment || '');
    const sellerHandleClean = String(listing.creatorHandle || listing.sellerHandle || listing.sellerId || 'seller').replace(/^@/, '');
    const priceUSD = listing.listingIntent === 'auction'
      ? getCurrentAuctionPriceUSD(listing)
      : (listing.primaryPriceUSD || listing.priceUSD || 0);

    const ratingBadge = avg.count > 0 ? ` ⭐ ${avg.average.toFixed(1)}/5 (${avg.count} ${avg.count === 1 ? 'rating' : 'ratings'})` : ` ⭐ ${effectiveUserRating}.0/5`;
    const topComment = effectiveUserComment
      ? ` 💬 "${effectiveUserComment.slice(0, 80)}"`
      : reviews.length > 0
      ? ` 💬 "${reviews[0].comment.slice(0, 80)}"`
      : '';
    const note = customNote ? ` Note: ${customNote}` : '';

    const content = `Shared from Marketplace: "${listing.title}" ($${priceUSD.toLocaleString()} USD).${ratingBadge}.${topComment}${note} #marketplace #review @${sellerHandleClean}`;

    const itemKind: 'good' | 'service' | 'auction' =
      listing.listingIntent === 'auction' ? 'auction' : (listing.itemType === 'service' ? 'service' : 'good');
    const statusLabel =
      overrideStatusLabel ||
      (listing.listingIntent === 'auction' && listing.status === 'sold'
        ? 'AUCTION WON'
        : listing.listingIntent === 'auction'
        ? 'LIVE AUCTION'
        : listing.status === 'sold'
        ? (filterStatus === 'history_bought' ? 'TRANSACTED' : 'SOLD')
        : 'LIVE');

    const createdTweet = createTweet({
      authorId: currentUser.uid || currentUser.id,
      authorName: currentUser.name,
      authorHandle: currentUser.id,
      authorAvatar: currentUser.avatarUrl || '',
      content: content.slice(0, 480),
      extraHashtags: ['marketplace', 'posting', 'review', 'ratings'],
      sharedPost: {
        listingId: listing.id,
        title: listing.title,
        description: listing.description || '',
        category: listing.category || 'Marketplace',
        itemType: itemKind,
        statusLabel,
        sellerHandle: sellerHandleClean,
        sellerName: listing.creatorName || sellerHandleClean,
        priceUSD,
        imageUrl: listing.imageUrl,
        averageRating: avg.count > 0 ? avg.average : effectiveUserRating,
        ratingCount: avg.count,
        userRating: effectiveUserRating,
        userComment: effectiveUserComment || undefined,
        comments: reviews.map((r) => ({
          reviewerName: r.reviewerName,
          reviewerAvatar: r.reviewerAvatar,
          rating: r.rating,
          comment: r.comment,
          timestamp: r.updatedAt || r.timestamp,
        })),
      },
    });

    showToast('Successfully shared post with rating & comments to Tweeting!');
    window.dispatchEvent(
      new CustomEvent('open_tweeting_feed', {
        detail: {
          tweetId: createdTweet.id,
          listingId: listing.id,
          listingTitle: listing.title,
          sourceTab: 'uploads',
          uploadsFilterStatus: filterStatus,
          uploadsBoughtSubSection: boughtSubSection,
          uploadsMyAuctionsSubTab: myAuctionsSubTab,
        },
      })
    );
  };
  
  // Friend Groups State
  const [friendGroups, setFriendGroups] = useState<FriendGroup[]>([]);
  const [availableFriends, setAvailableFriends] = useState<UserPublicProfile[]>([]);
  const [platformUsers, setPlatformUsers] = useState<UserPublicProfile[]>([]);
  const [saveToastMessage, setSaveToastMessage] = useState<string | null>(null);

  // Modal state for creating/editing listing drafts
  const [activeModalListing, setActiveModalListing] = useState<MarketplaceListing | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');

  // Modal state for audience & privacy selector
  const [isAudienceModalOpen, setIsAudienceModalOpen] = useState(false);
  const [selectedListingForAudience, setSelectedListingForAudience] = useState<MarketplaceListing | null>(null);
  const [selectedVisibility, setSelectedVisibility] = useState<ListingVisibility>('public');
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);

  // Modal state for Friend Groups manager & creator
  const [isGroupManagerModalOpen, setIsGroupManagerModalOpen] = useState(false);
  const [isCreateGroupModalOpen, setIsCreateGroupModalOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<FriendGroup | null>(null);
  const [groupNameInput, setGroupNameInput] = useState('');
  const [groupDescInput, setGroupDescInput] = useState('');
  const [groupColorInput, setGroupColorInput] = useState('#f59e0b');
  const [groupAvatarInput, setGroupAvatarInput] = useState('');
  const groupImageFileRef = useRef<HTMLInputElement>(null);
  const [groupTypeInput, setGroupTypeInput] = useState<'friend' | 'general'>('friend');
  const [selectedMemberUids, setSelectedMemberUids] = useState<string[]>([]);
  const [memberAssignmentsInput, setMemberAssignmentsInput] = useState<Record<string, { number: string; role: string }>>({});
  const [memberSearchQuery, setMemberSearchQuery] = useState('');
  const [groupErrorMsg, setGroupErrorMsg] = useState('');
  const [groupToDelete, setGroupToDelete] = useState<FriendGroup | null>(null);
  const [openedManagerGroupId, setOpenedManagerGroupId] = useState<string | null>(null);
  const [auctionManageListing, setAuctionManageListing] = useState<MarketplaceListing | null>(null);

  const loadData = async () => {
    const target = currentUser?.id || currentUser?.uid || 'guest';
    const viewer = currentUser?.uid || currentUser?.id || 'guest';
    if (currentUser) {
      ensureSampleAuctionsForUser(target, currentUser.uid, currentUser.name);
    }
    const userListings = getUserListings(target, viewer, true, currentUser?.id);
    setListings(userListings);
    setMarketplaceVersion((v) => v + 1);

    // Load friend groups
    const groups = getUserFriendGroups(activeUid);
    setFriendGroups(groups);

    // Load friends
    const confirmedFriends = await getFriendsList(activeUid);
    const allUsers = await getAllUsers(activeUid);
    setAvailableFriends(confirmedFriends);
    setPlatformUsers(allUsers);
  };

  const selectableUsersForGroup = useMemo(() => {
    if (groupTypeInput === 'friend') {
      return availableFriends;
    }
    return platformUsers;
  }, [groupTypeInput, availableFriends, platformUsers]);

  useEffect(() => {
    loadData();
  }, [currentUser, activeUid]);

  const showToast = (msg: string) => {
    setSaveToastMessage(msg);
    setTimeout(() => {
      setSaveToastMessage(null);
    }, 3000);
  };

  const refreshListings = () => {
    const target = currentUser?.id || currentUser?.uid || 'guest';
    const viewer = currentUser?.uid || currentUser?.id || 'guest';
    setListings(getUserListings(target, viewer, true, currentUser?.id));
    setMarketplaceVersion((v) => v + 1);
  };

  const handleOpenCreateModal = () => {
    setActiveModalListing(null);
    setModalMode('create');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (listing: MarketplaceListing) => {
    setActiveModalListing(listing);
    setModalMode('edit');
    setIsModalOpen(true);
  };

  const handleDeleteListing = (id: string) => {
    if (confirm('Are you sure you want to remove this listing?')) {
      if (id.startsWith('mkt-my-auc-') && currentUser) {
        const cleanHandle = (currentUser.id || currentUser.uid || 'guest')
          .trim()
          .toLowerCase()
          .replace(/^@/, '')
          .replace(/^user-/, '');
        try {
          localStorage.setItem(`ff_user_deleted_sample_auction_${cleanHandle}`, '1');
        } catch {}
      }
      deleteListing(currentUser?.id || 'guest', id);
      refreshListings();
      showToast('Listing removed');
    }
  };

  const handleTogglePublish = (listing: MarketplaceListing) => {
    const nextStatus: ListingStatus = listing.status === 'uploaded' ? 'draft' : 'uploaded';
    updateListingStatus(currentUser?.id || 'guest', listing.id, nextStatus);
    refreshListings();
    showToast(nextStatus === 'uploaded' ? 'Listing published live' : 'Listing moved to drafts');
  };

  // ================= AUDIENCE & PRIVACY MODAL HANDLERS =================
  const handleOpenAudienceModal = (listing: MarketplaceListing, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedListingForAudience(listing);
    setSelectedVisibility(listing.visibility || 'public');
    setSelectedGroupIds(listing.allowedGroupIds || []);
    setIsAudienceModalOpen(true);
  };

  const handleSaveAudience = () => {
    if (!selectedListingForAudience) return;
    
    const matchedGroupNames = friendGroups
      .filter(g => selectedGroupIds.includes(g.id))
      .map(g => g.name);

    const updated = updateListingVisibility(
      selectedListingForAudience.id,
      selectedVisibility,
      selectedVisibility === 'custom_group' ? selectedGroupIds : [],
      selectedVisibility === 'custom_group' ? matchedGroupNames : []
    );

    if (updated) {
      setListings(prev => prev.map(l => l.id === updated.id ? updated : l));
      const label = selectedVisibility === 'public' ? 'Public (The World)' :
                    selectedVisibility === 'friends' ? 'Friends Only' :
                    selectedVisibility === 'only_me' ? 'Only Me (Private Vault)' :
                    `Friend Group (${matchedGroupNames.join(', ') || 'Custom'})`;
      showToast(`Listing audience set to ${label}`);
    }

    setIsAudienceModalOpen(false);
    setSelectedListingForAudience(null);
  };

  const toggleGroupSelection = (groupId: string) => {
    setSelectedGroupIds(prev => 
      prev.includes(groupId) ? prev.filter(id => id !== groupId) : [...prev, groupId]
    );
  };

  const handleMemberAssignmentChange = (
    uid: string,
    field: 'number' | 'role',
    value: string
  ) => {
    setMemberAssignmentsInput(prev => ({
      ...prev,
      [uid]: {
        number: prev[uid]?.number ?? '',
        role: prev[uid]?.role ?? '',
        [field]: value
      }
    }));
  };

  // ================= FRIEND GROUP CREATION & MANAGEMENT HANDLERS =================
  const handleOpenCreateGroup = (initialGroup?: FriendGroup) => {
    if (initialGroup) {
      setEditingGroup(initialGroup);
      setGroupNameInput(initialGroup.name);
      setGroupDescInput(initialGroup.description || '');
      setGroupColorInput(initialGroup.color || '#f59e0b');
      setGroupAvatarInput(initialGroup.avatarUrl || '');
      setGroupTypeInput(initialGroup.groupType || 'friend');
      const initialUids = (initialGroup.memberUids || []).slice(0, MAX_CUSTOM_GROUP_MEMBERS);
      setSelectedMemberUids(initialUids);
      const initialMap: Record<string, { number: string; role: string }> = {};
      initialUids.forEach((uid) => {
        const assign = initialGroup.memberAssignments?.[uid];
        initialMap[uid] = {
          number: typeof assign?.number === 'number' ? String(assign.number) : '',
          role: assign?.role || ''
        };
      });
      setMemberAssignmentsInput(initialMap);
    } else {
      setEditingGroup(null);
      setGroupNameInput('');
      setGroupDescInput('');
      setGroupColorInput('#f59e0b');
      setGroupAvatarInput('');
      setGroupTypeInput('friend');
      setSelectedMemberUids([]);
      setMemberAssignmentsInput({});
    }
    setMemberSearchQuery('');
    setGroupErrorMsg('');
    setIsCreateGroupModalOpen(true);
  };

  const handleSaveGroup = () => {
    if (!groupNameInput.trim()) {
      showToast('Please enter a group name');
      return;
    }

    const cappedUids = selectedMemberUids.slice(0, MAX_CUSTOM_GROUP_MEMBERS);
    const allKnownUsers = [...availableFriends, ...platformUsers];
    const memberHandles = cappedUids.map((uid) => {
      const found = allKnownUsers.find((f) => f.uid === uid);
      return found?.userId || uid.replace(/^user-/, '').replace(/^demo-/, '');
    });

    const assignmentsToSave: Record<string, GroupMemberAssignment> = {};
    cappedUids.forEach((uid) => {
      const entry = memberAssignmentsInput[uid];
      if (!entry) return;
      const numStr = entry.number.trim();
      const parsedNum = numStr !== '' ? Number(numStr) : NaN;
      const trimmedRole = entry.role.trim();
      const assignment: GroupMemberAssignment = {};
      if (numStr !== '' && Number.isFinite(parsedNum)) {
        assignment.number = parsedNum;
      }
      if (trimmedRole) {
        assignment.role = trimmedRole;
      }
      if (assignment.number !== undefined || assignment.role !== undefined) {
        assignmentsToSave[uid] = assignment;
      }
    });

    if (editingGroup) {
      const updated = updateFriendGroup(editingGroup.id, {
        name: groupNameInput.trim(),
        description: groupDescInput.trim(),
        color: groupColorInput,
        avatarUrl: groupAvatarInput,
        memberUids: cappedUids,
        memberHandles,
        memberAssignments: assignmentsToSave,
        groupType: groupTypeInput
      });
      if (updated) {
        setFriendGroups(prev => prev.map(g => g.id === updated.id ? updated : g));
        showToast(`Group "${groupNameInput}" updated`);
      }
    } else {
      const created = createFriendGroup(
        activeUid,
        groupNameInput.trim(),
        cappedUids,
        groupDescInput.trim(),
        groupColorInput,
        memberHandles,
        groupTypeInput,
        groupAvatarInput,
        assignmentsToSave
      );
      setFriendGroups(prev => [created, ...prev]);
      showToast(`Group "${groupNameInput}" created with ${cappedUids.length} members`);
      
      // If creating from audience modal, auto-select this new group
      if (isAudienceModalOpen) {
        setSelectedGroupIds(prev => [...prev, created.id]);
        setSelectedVisibility('custom_group');
      }
    }

    setIsCreateGroupModalOpen(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGroupAvatarInput(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteGroup = (groupId: string, _groupName: string) => {
    const group = friendGroups.find(g => g.id === groupId);
    if (group) {
      setGroupToDelete(group);
    }
  };

  const handleSetGroupType = (type: 'friend' | 'general') => {
    setGroupTypeInput(type);
    if (type === 'friend') {
      // Filter out non-friends if switching to friend group
      const friendsSet = new Set(availableFriends.map(f => f.uid));
      setSelectedMemberUids(prev => {
        const filtered = prev.filter(uid => friendsSet.has(uid));
        return filtered.slice(0, MAX_CUSTOM_GROUP_MEMBERS);
      });
    } else {
      // Enforce 20 member limit for general groups as well
      setSelectedMemberUids(prev => prev.slice(0, MAX_CUSTOM_GROUP_MEMBERS));
    }
    setGroupErrorMsg('');
  };

  const confirmDeleteGroup = () => {
    if (groupToDelete) {
      deleteFriendGroup(groupToDelete.id);
      setFriendGroups(prev => prev.filter(g => g.id !== groupToDelete.id));
      setSelectedGroupIds(prev => prev.filter(id => id !== groupToDelete.id));
      if (openedManagerGroupId === groupToDelete.id) {
        setOpenedManagerGroupId(null);
      }
      showToast(`Friend group "${groupToDelete.name}" deleted`);
      setGroupToDelete(null);
    }
  };

  const toggleMemberSelection = (uid: string) => {
    setSelectedMemberUids(prev => {
      if (prev.includes(uid)) {
        setGroupErrorMsg('');
        return prev.filter(id => id !== uid);
      } else {
        if (prev.length >= MAX_CUSTOM_GROUP_MEMBERS) {
          setGroupErrorMsg(`Custom groups are limited to ${MAX_CUSTOM_GROUP_MEMBERS} people.`);
          return prev;
        }
        setGroupErrorMsg('');
        return [...prev, uid];
      }
    });
  };

  const filteredBoughtGoods = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return boughtHistory.goods;
    return boughtHistory.goods.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
    );
  }, [boughtHistory.goods, searchQuery]);

  const filteredBoughtServices = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return boughtHistory.services;
    return boughtHistory.services.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
    );
  }, [boughtHistory.services, searchQuery]);

  const filteredBoughtAuctions = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return boughtHistory.auctions;
    return boughtHistory.auctions.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
    );
  }, [boughtHistory.auctions, searchQuery]);

  const displayedItems = useMemo(() => {
    const baseItems =
      filterStatus === 'live_auctions_participating'
        ? participatingAuctions
        : filterStatus === 'my_auctions'
        ? (myAuctionsSubTab === 'done' ? doneMyAuctions : activeMyAuctions)
        : filterStatus === 'history_sold'
        ? soldListings
        : listings.filter((item) => {
            if (filterStatus === 'uploaded' && item.status !== 'uploaded') return false;
            if (filterStatus === 'draft' && item.status !== 'draft') return false;
            if (filterStatus === 'sold' && item.status !== 'sold') return false;
            return true;
          });

    return baseItems.filter((item) => {
      if (filterVisibility !== 'all') {
        const itemVis = item.visibility || 'public';
        if (filterVisibility !== itemVis) return false;
      }

      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        item.title.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
      );
    });
  }, [
    filterStatus,
    filterVisibility,
    searchQuery,
    listings,
    participatingAuctions,
    activeMyAuctions,
    doneMyAuctions,
    myAuctionsSubTab,
    soldListings,
  ]);

  const renderBoughtHistoryCard = (item: MarketplaceListing, subKind: 'good' | 'service' | 'auction') => {
    const listingAvg = getAverageRatingForListing(item.id);
    const listingReviews = getReviewsForListing(item.id);
    const userReview = currentUser
      ? getUserReviewForListing(item.id, currentUser.id || activeUid, currentUser.uid)
      : null;
    const currentRating = postRatingInputs[item.id]?.rating ?? (userReview?.rating || 5);
    const currentComment =
      postRatingInputs[item.id]?.comment !== undefined
        ? postRatingInputs[item.id].comment
        : (userReview?.comment || '');
    const displayPrice =
      subKind === 'auction'
        ? getCurrentAuctionPriceUSD(item)
        : (item.primaryPriceUSD || item.priceUSD || 0);
    const sellerHandleClean = String(
      item.creatorHandle || item.sellerHandle || item.sellerId || 'seller'
    ).replace(/^@/, '');

    return (
      <div
        key={item.id}
        data-listing-id={item.id}
        className={`border bg-white rounded-3xl overflow-hidden flex flex-col justify-between transition-all shadow-2xs ${
          highlightedListingId === item.id
            ? 'border-sky-400 ring-2 ring-sky-200'
            : 'border-neutral-200 hover:border-neutral-300'
        }`}
      >
        <div>
          {/* Media Header */}
          <div className="relative h-44 w-full bg-neutral-950 overflow-hidden">
            {item.imageUrl ? (
              <img
                src={item.imageUrl}
                alt={item.title}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-neutral-600">
                {subKind === 'auction' ? (
                  <Gavel className="h-8 w-8 text-amber-400" />
                ) : subKind === 'service' ? (
                  <Briefcase className="h-8 w-8 text-indigo-400" />
                ) : (
                  <Package className="h-8 w-8 text-emerald-400" />
                )}
              </div>
            )}
            <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
              <span
                className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border ${
                  subKind === 'auction'
                    ? 'bg-amber-600 text-white border-amber-400'
                    : 'bg-emerald-600 text-white border-emerald-400'
                }`}
              >
                {subKind === 'auction' ? 'AUCTION WON' : 'TRANSACTED'}
              </span>
              <span
                className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border uppercase ${
                  subKind === 'auction'
                    ? 'bg-neutral-900 text-amber-300 border-amber-400/50'
                    : subKind === 'service'
                    ? 'bg-indigo-700 text-white border-indigo-400'
                    : 'bg-purple-700 text-white border-purple-400'
                }`}
              >
                {subKind}
              </span>
            </div>
            <div className="absolute top-2.5 right-2.5">
              <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md text-amber-300 border border-white/20">
                @{sellerHandleClean}
              </span>
            </div>
          </div>

          {/* Content */}
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono">
              <span className="uppercase font-bold text-neutral-700">{item.category}</span>
              <span className="text-emerald-700 font-bold">${displayPrice.toLocaleString()} USD</span>
            </div>

            <div>
              <h4 className="font-serif-lux text-base font-bold text-neutral-900 tracking-tight">
                {item.title}
              </h4>
              <p className="text-xs text-neutral-600 line-clamp-2 mt-1">
                {item.description}
              </p>
            </div>

            {/* Overall Post Rating Header */}
            <div className="p-2.5 rounded-2xl bg-amber-50/60 border border-amber-200/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex items-center text-amber-500">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-3.5 h-3.5 ${
                        s <= Math.round(listingAvg.average || 5)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-neutral-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="font-mono text-xs font-bold text-neutral-900">
                  {listingAvg.count > 0 ? listingAvg.average.toFixed(1) : '5.0'}
                </span>
                <span className="text-[11px] text-neutral-500 font-mono">
                  ({listingAvg.count} {listingAvg.count === 1 ? 'rating' : 'ratings'})
                </span>
              </div>
              <span className="text-[10px] font-mono text-amber-900 font-semibold">
                Post Rating
              </span>
            </div>

            {/* Existing Comments List */}
            {listingReviews.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-700">
                  <MessageSquare className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Comments ({listingReviews.length})</span>
                </div>
                <div className="max-h-32 overflow-y-auto space-y-1.5 pr-1 no-scrollbar">
                  {listingReviews.map((rev) => (
                    <div key={rev.id} className="p-2 rounded-xl bg-neutral-50 border border-neutral-100 text-xs">
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <div className="flex items-center gap-1.5">
                          {rev.reviewerAvatar ? (
                            <img src={rev.reviewerAvatar} alt="" className="w-4 h-4 rounded-full object-cover" />
                          ) : (
                            <div className="w-4 h-4 rounded-full bg-neutral-300 text-[9px] flex items-center justify-center font-bold">
                              {rev.reviewerName.charAt(0)}
                            </div>
                          )}
                          <span className="font-bold text-[11px] text-neutral-800">{rev.reviewerName}</span>
                        </div>
                        <div className="flex items-center text-amber-500 text-[10px]">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-2.5 h-2.5 ${s <= rev.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-200'}`}
                            />
                          ))}
                        </div>
                      </div>
                      {rev.comment && (
                        <p className="text-[11px] text-neutral-600 italic">
                          &ldquo;{rev.comment}&rdquo;
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Interactive One-Time Rate & Comment Form (only for verified final buyer / auction winner, locked once submitted) */}
            {(() => {
              const eligibility = canUserRateListing(
                item,
                currentUser?.id || activeUid,
                currentUser?.uid
              );

              if (userReview) {
                return (
                  <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-emerald-900 flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Final Rating Submitted</span>
                      </span>
                      <span className="text-[10px] font-mono text-emerald-800 bg-white px-2 py-0.5 rounded-md border border-emerald-200 font-bold">
                        {userReview.rating} / 5 ★ (Locked)
                      </span>
                    </div>
                    {userReview.comment && (
                      <p className="text-[11px] text-emerald-900/90 italic">
                        &ldquo;{userReview.comment}&rdquo;
                      </p>
                    )}
                    <p className="text-[10px] text-emerald-700 font-medium">
                      One-time rating recorded for this finalized {subKind === 'auction' ? 'auction win' : 'purchase'}.
                    </p>
                  </div>
                );
              }

              if (!eligibility.canRate) {
                return null;
              }

              return (
                <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-neutral-800">
                      {subKind === 'auction'
                        ? 'Rate your Auction Win'
                        : subKind === 'service'
                        ? 'Rate this Finalized Service'
                        : 'Rate this Finalized Purchase'}
                    </span>
                    <span className="text-[10px] font-mono text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 font-semibold">
                      1-Time Final Review
                    </span>
                  </div>

                  {/* 5 Clickable Stars */}
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((starVal) => (
                      <button
                        key={starVal}
                        type="button"
                        onClick={() => {
                          setPostRatingInputs((prev) => ({
                            ...prev,
                            [item.id]: {
                              rating: starVal,
                              comment:
                                prev[item.id]?.comment !== undefined
                                  ? prev[item.id].comment
                                  : currentComment,
                            },
                          }));
                        }}
                        className="p-1 text-amber-400 hover:scale-115 transition-transform cursor-pointer"
                        title={`Rate ${starVal} star${starVal > 1 ? 's' : ''}`}
                      >
                        <Star
                          className={`w-5 h-5 ${
                            starVal <= currentRating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-neutral-300 hover:text-amber-300'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="text-xs font-mono font-bold text-neutral-700 ml-2">
                      {currentRating} / 5 Stars
                    </span>
                  </div>

                  {/* Comment textarea */}
                  <textarea
                    value={currentComment}
                    onChange={(e) => {
                      const val = e.target.value;
                      setPostRatingInputs((prev) => ({
                        ...prev,
                        [item.id]: {
                          rating: prev[item.id]?.rating ?? currentRating,
                          comment: val,
                        },
                      }));
                    }}
                    placeholder={
                      subKind === 'auction'
                        ? 'Write your one-time review for this auction win...'
                        : subKind === 'service'
                        ? 'Write your one-time review for this finalized service...'
                        : 'Write your one-time review for this finalized purchase...'
                    }
                    rows={2}
                    className="w-full p-2.5 bg-white border border-neutral-200 rounded-xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                  />

                  <div className="flex items-center justify-between gap-2 pt-1">
                    <span className="text-[10px] text-neutral-500">
                      One-time rating per finalized purchase
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRatePost(item)}
                      className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      Submit Final Rating
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>

        {/* Card Footer Actions */}
        <div className="p-4 pt-2 border-t border-neutral-100 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() =>
              handleShareListingTweet(
                item,
                undefined,
                subKind === 'auction' ? 'AUCTION WON' : 'TRANSACTED'
              )
            }
            className="w-full py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share on Tweeting</span>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 pb-16 text-left">
      {/* Toast Notification */}
      <AnimatePresence>
        {saveToastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 bg-neutral-950 text-white border border-neutral-800 px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-medium"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{saveToastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter Tabs & Privacy Controls */}
      <div className="space-y-3">
        {/* Row 1: Status Tabs & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center bg-white border border-neutral-200 p-1 rounded-2xl shrink-0 shadow-2xs overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                filterStatus === 'all'
                  ? 'bg-neutral-900 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              All Items ({listings.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('uploaded')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                filterStatus === 'uploaded'
                  ? 'bg-neutral-900 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              Live Uploads ({listings.filter(l => l.status === 'uploaded').length})
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('draft')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                filterStatus === 'draft'
                  ? 'bg-neutral-900 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              Drafts ({listings.filter(l => l.status === 'draft').length})
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('live_auctions_participating')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1 ${
                filterStatus === 'live_auctions_participating'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              <Gavel className="w-3 h-3" />
              <span>Live Auctions ({participatingAuctions.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('my_auctions')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1 ${
                filterStatus === 'my_auctions'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              <Layers className="w-3 h-3" />
              <span>My Auctions ({myAuctions.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('history_bought')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1 ${
                filterStatus === 'history_bought'
                  ? 'bg-emerald-700 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              <Coins className="w-3 h-3" />
              <span>Bought History ({totalBoughtCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('history_sold')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1 ${
                filterStatus === 'history_sold'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-neutral-600 hover:text-black'
              }`}
            >
              <Package className="w-3 h-3" />
              <span>Sold History ({soldListings.length})</span>
            </button>
          </div>

          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, category..."
              className="w-full pl-9 pr-3 py-2 bg-white border border-neutral-200 rounded-2xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black shadow-2xs"
            />
          </div>
        </div>

        {/* Row 2: Privacy / Audience Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
          <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider mr-1 whitespace-nowrap shrink-0">
            Audience:
          </span>
          <button
            type="button"
            onClick={() => setFilterVisibility('all')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
              filterVisibility === 'all'
                ? 'bg-neutral-900 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            All Audiences
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('public')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'public'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Globe className="w-3 h-3" />
            <span>Public ({listings.filter(l => (l.visibility || 'public') === 'public').length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('friends')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'friends'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Users className="w-3 h-3" />
            <span>Friends Only ({listings.filter(l => l.visibility === 'friends').length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('custom_group')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'custom_group'
                ? 'bg-amber-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Shield className="w-3 h-3" />
            <span>Custom Groups ({listings.filter(l => l.visibility === 'custom_group').length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterVisibility('only_me')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              filterVisibility === 'only_me'
                ? 'bg-slate-800 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Lock className="w-3 h-3" />
            <span>Private / Only Me ({listings.filter(l => l.visibility === 'only_me').length})</span>
          </button>
        </div>
      </div>

      {/* Grid or History View */}
      {filterStatus === 'history_bought' ? (
        totalBoughtCount === 0 ? (
          <div className="text-center py-16 border border-neutral-200 rounded-3xl p-6 bg-white shadow-2xs space-y-3">
            <Coins className="w-8 h-8 text-neutral-400 mx-auto" />
            <p className="text-neutral-500 text-sm">No goods, services, or auctions bought yet.</p>
            <p className="text-xs text-neutral-400 max-w-md mx-auto">
              Goods, services, and auctions you purchase or win from other members will appear here so you can rate, comment, and share them on Tweeting.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Bought History Header & 3 Subsection Filter Pills */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 border border-emerald-200/80 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                    <Coins className="w-4 h-4 text-emerald-700" />
                    <span>Bought History — Goods, Services &amp; Auctions ({totalBoughtCount})</span>
                  </h3>
                  <p className="text-xs text-neutral-600 mt-0.5">
                    Rate your experience (1–5 stars) and leave a comment for every good, service, or auction you bought.
                  </p>
                </div>
                <span className="text-[11px] font-mono px-2.5 py-1 rounded-xl bg-white/90 border border-emerald-200 text-emerald-900 font-semibold shrink-0">
                  1 Rating &amp; Comment per post (Updatable anytime)
                </span>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
                <button
                  type="button"
                  onClick={() => setBoughtSubSection('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    boughtSubSection === 'all'
                      ? 'bg-neutral-900 text-white shadow-2xs'
                      : 'bg-white text-neutral-700 border border-neutral-200 hover:bg-neutral-50'
                  }`}
                >
                  All Subsections ({filteredBoughtGoods.length + filteredBoughtServices.length + filteredBoughtAuctions.length})
                </button>
                <button
                  type="button"
                  onClick={() => setBoughtSubSection('goods')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    boughtSubSection === 'goods'
                      ? 'bg-purple-700 text-white shadow-2xs'
                      : 'bg-white text-neutral-700 border border-neutral-200 hover:bg-neutral-50'
                  }`}
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>1. Goods Bought ({filteredBoughtGoods.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBoughtSubSection('services')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    boughtSubSection === 'services'
                      ? 'bg-indigo-700 text-white shadow-2xs'
                      : 'bg-white text-neutral-700 border border-neutral-200 hover:bg-neutral-50'
                  }`}
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>2. Services Bought ({filteredBoughtServices.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBoughtSubSection('auctions')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    boughtSubSection === 'auctions'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-white text-neutral-700 border border-neutral-200 hover:bg-neutral-50'
                  }`}
                >
                  <Gavel className="w-3.5 h-3.5" />
                  <span>3. Auctions Bought ({filteredBoughtAuctions.length})</span>
                </button>
              </div>
            </div>

            {/* Subsection 1: Goods Bought */}
            {(boughtSubSection === 'all' || boughtSubSection === 'goods') && (
              <section className="space-y-3">
                <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                  <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
                      <Package className="w-3.5 h-3.5" />
                    </span>
                    <span>Goods Bought ({filteredBoughtGoods.length})</span>
                  </h4>
                  <span className="text-[11px] font-mono text-neutral-500">Physical Goods &amp; Assets</span>
                </div>
                {filteredBoughtGoods.length === 0 ? (
                  <div className="p-6 rounded-2xl border border-dashed border-neutral-200 bg-white text-center text-xs text-neutral-500">
                    No purchased goods match your current search.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {filteredBoughtGoods.map((item) => renderBoughtHistoryCard(item, 'good'))}
                  </div>
                )}
              </section>
            )}

            {/* Subsection 2: Services Bought */}
            {(boughtSubSection === 'all' || boughtSubSection === 'services') && (
              <section className="space-y-3">
                <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                  <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                      <Briefcase className="w-3.5 h-3.5" />
                    </span>
                    <span>Services Bought ({filteredBoughtServices.length})</span>
                  </h4>
                  <span className="text-[11px] font-mono text-neutral-500">Advisory, Security &amp; Bespoke Work</span>
                </div>
                {filteredBoughtServices.length === 0 ? (
                  <div className="p-6 rounded-2xl border border-dashed border-neutral-200 bg-white text-center text-xs text-neutral-500">
                    No purchased services match your current search.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {filteredBoughtServices.map((item) => renderBoughtHistoryCard(item, 'service'))}
                  </div>
                )}
              </section>
            )}

            {/* Subsection 3: Auctions Bought & Won */}
            {(boughtSubSection === 'all' || boughtSubSection === 'auctions') && (
              <section className="space-y-3">
                <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
                  <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                      <Gavel className="w-3.5 h-3.5" />
                    </span>
                    <span>Auctions Bought ({filteredBoughtAuctions.length})</span>
                  </h4>
                  <span className="text-[11px] font-mono text-neutral-500">Won &amp; Settled Auction Lots</span>
                </div>
                {filteredBoughtAuctions.length === 0 ? (
                  <div className="p-6 rounded-2xl border border-dashed border-neutral-200 bg-white text-center text-xs text-neutral-500">
                    No auction purchases match your current search.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {filteredBoughtAuctions.map((item) => renderBoughtHistoryCard(item, 'auction'))}
                  </div>
                )}
              </section>
            )}
          </div>
        )
      ) : (
        <div className="space-y-5">
          {filterStatus === 'my_auctions' && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-50 via-orange-50/70 to-neutral-50 border border-amber-200/80 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                    <Gavel className="w-4 h-4 text-amber-700" />
                    <span>My Initiated Auctions ({myAuctions.length})</span>
                  </h3>
                  <p className="text-xs text-neutral-600 mt-0.5">
                    Manage your live auctions or review completed &amp; settled auctions.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
                <button
                  type="button"
                  onClick={() => setMyAuctionsSubTab('active')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    myAuctionsSubTab === 'active'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-white text-neutral-700 border border-neutral-200 hover:bg-neutral-50'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Active Auctions ({activeMyAuctions.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMyAuctionsSubTab('done')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    myAuctionsSubTab === 'done'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'bg-white text-neutral-700 border border-neutral-200 hover:bg-neutral-50'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Done Auctions ({doneMyAuctions.length})</span>
                </button>
              </div>
            </div>
          )}

          {displayedItems.length === 0 ? (
            <div className="text-center py-16 border border-neutral-200 rounded-3xl p-6 bg-white shadow-2xs space-y-3">
              <Package className="w-8 h-8 text-neutral-400 mx-auto" />
              <p className="text-neutral-500 text-sm">
                {filterStatus === 'my_auctions'
                  ? myAuctionsSubTab === 'active'
                    ? 'No active auctions found.'
                    : 'No completed or settled auctions found yet.'
                  : 'No items found in this category or filter.'}
              </p>
              <button
                type="button"
                onClick={handleOpenCreateModal}
                className="text-xs text-neutral-900 font-bold hover:underline cursor-pointer"
              >
                + Create First Listing
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {displayedItems.map((item) => {
            const vis = item.visibility || 'public';
            const isAuction = item.listingIntent === 'auction';
            const isParticipatingExternalAuction = filterStatus === 'live_auctions_participating';
            const auctionBids = isAuction ? getAuctionBids(item.id) : [];
            const auctionTime = isAuction
              ? (void auctionClockTick, getAuctionRemainingLabel(item.auctionConfig?.endTimeIso))
              : null;
            const displayUSD = isAuction ? getCurrentAuctionPriceUSD(item) : (item.primaryPriceUSD || 0);
            const itemAvg = getAverageRatingForListing(item.id);
            const itemReviews = getReviewsForListing(item.id);

            const cleanUserHandle = (currentUser?.handle || currentUser?.id || '')
              .toLowerCase()
              .replace(/^@/, '')
              .replace(/^user-/, '');
            const myUserBids = isAuction
              ? auctionBids.filter((b) => {
                  const bHandle = (b.bidderHandle || '').toLowerCase().replace(/^@/, '').replace(/^user-/, '');
                  return (
                    b.bidderId === activeUid ||
                    b.bidderId === currentUser?.id ||
                    (currentUser?.uid && (b.bidderUid === currentUser.uid || b.bidderId === currentUser.uid)) ||
                    (cleanUserHandle && bHandle === cleanUserHandle)
                  );
                })
              : [];
            const myHighestBid = myUserBids.length > 0
              ? myUserBids.reduce((best, b) => (b.amountUSD > best.amountUSD ? b : best), myUserBids[0])
              : null;
            const isLeadingBidder = Boolean(
              myHighestBid &&
                myHighestBid.status === 'active' &&
                myHighestBid.amountUSD >= displayUSD
            );
            const sellerHandleClean = String(
              item.creatorHandle || item.sellerHandle || item.userId || 'seller'
            ).replace(/^@/, '').replace(/^user-/, '');

            return (
              <div
                key={item.id}
                data-listing-id={item.id}
                className={`border bg-white rounded-3xl overflow-hidden flex flex-col justify-between transition-all shadow-2xs ${
                  highlightedListingId === item.id
                    ? 'border-sky-400 ring-2 ring-sky-200'
                    : 'border-neutral-200 hover:border-neutral-400'
                }`}
              >
                <div>
                  {/* Media Preview */}
                  <div className="relative h-44 w-full bg-neutral-950 overflow-hidden">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center text-neutral-600">
                        <ImageIcon className="h-8 w-8" />
                      </div>
                    )}

                    <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg backdrop-blur-md ${
                        item.listingIntent === 'auction'
                          ? 'bg-amber-500/95 text-neutral-950 border border-amber-300 font-black'
                          : item.listingIntent === 'buy'
                          ? 'bg-blue-600/90 text-white border border-blue-400'
                          : 'bg-emerald-600/90 text-white border border-emerald-400'
                      }`}>
                        {item.listingIntent === 'auction' ? 'AUCTION' : item.listingIntent === 'buy' ? 'WANTED' : 'OFFERING'}
                      </span>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg backdrop-blur-md ${
                        item.status === 'sold' || (isAuction && (item.auctionConfig?.status === 'settled' || item.auctionConfig?.status === 'ended' || auctionTime?.isEnded))
                          ? 'bg-emerald-700/90 text-white border border-emerald-500'
                          : item.status === 'uploaded'
                          ? 'bg-neutral-900/90 text-white border border-neutral-700'
                          : 'bg-amber-500/90 text-neutral-950 border border-amber-300 font-black'
                      }`}>
                        {isAuction && (item.status === 'sold' || item.auctionConfig?.status === 'settled' || item.auctionConfig?.status === 'ended' || auctionTime?.isEnded)
                          ? 'DONE'
                          : item.status === 'sold'
                          ? 'SOLD'
                          : item.status === 'uploaded'
                          ? 'LIVE'
                          : 'DRAFT'}
                      </span>
                    </div>

                    {/* Top-right Badge: Seller handle for external live auctions, Privacy toggle for owned posts */}
                    <div className="absolute top-2.5 right-2.5">
                      {isParticipatingExternalAuction ? (
                        <span className="h-6 px-2.5 rounded-full text-[10px] font-mono font-bold flex items-center gap-1 shadow-md backdrop-blur-md bg-neutral-900/90 text-white border border-neutral-700">
                          <span>@{sellerHandleClean}</span>
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => handleOpenAudienceModal(item, e)}
                          title="Click to edit listing audience / privacy"
                          className={`h-6 px-2.5 rounded-full text-[10px] font-bold flex items-center gap-1 shadow-md backdrop-blur-md cursor-pointer transition-transform hover:scale-105 active:scale-95 border ${
                            vis === 'public'
                              ? 'bg-emerald-500/95 text-white border-emerald-400'
                              : vis === 'friends'
                              ? 'bg-blue-600/95 text-white border-blue-400'
                              : vis === 'custom_group'
                              ? 'bg-amber-500 text-neutral-950 border-amber-300 font-black'
                              : 'bg-neutral-900/95 text-white border-neutral-700'
                          }`}
                        >
                          {vis === 'public' ? (
                            <>
                              <Globe className="w-3 h-3 shrink-0" />
                              <span>Public</span>
                            </>
                          ) : vis === 'friends' ? (
                            <>
                              <Users className="w-3 h-3 shrink-0" />
                              <span>Friends</span>
                            </>
                          ) : vis === 'custom_group' ? (
                            <>
                              <Shield className="w-3 h-3 shrink-0" />
                              <span className="truncate max-w-[80px]">
                                {item.allowedGroupNames?.[0] || 'Group'}
                              </span>
                            </>
                          ) : (
                            <>
                              <Lock className="w-3 h-3 shrink-0" />
                              <span>Only Me</span>
                            </>
                          )}
                          <Edit3 className="w-2.5 h-2.5 ml-0.5 opacity-80" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="p-4 space-y-2.5">
                    <div className="flex items-center justify-between text-[11px] text-neutral-500">
                      <span className="font-mono uppercase font-bold text-neutral-700">{item.category}</span>
                      <span className="capitalize font-semibold text-neutral-500">{item.itemType}</span>
                    </div>

                    <h3 className="font-serif-lux text-base font-bold text-neutral-900 tracking-tight line-clamp-1">
                      {item.title}
                    </h3>

                    <p className="text-xs text-neutral-600 line-clamp-2">
                      {item.description}
                    </p>

                    {isAuction && (
                      <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 space-y-1.5 text-[11px] font-mono text-amber-950">
                        <div className="flex items-center justify-between">
                          <span className="font-bold flex items-center gap-1">
                            <Gavel className="w-3.5 h-3.5 text-amber-700" />
                            <span>
                              {auctionBids.length} {auctionBids.length === 1 ? 'bid' : 'bids'}
                            </span>
                          </span>
                          <span className={`font-bold flex items-center gap-1 ${auctionTime?.isEnded ? 'text-rose-700' : 'text-amber-900'}`}>
                            <Clock className="w-3.5 h-3.5" />
                            <span>{item.status === 'sold' ? 'Settled' : auctionTime?.text || 'Active'}</span>
                          </span>
                        </div>

                        {isParticipatingExternalAuction && myHighestBid && (
                          <div className="flex items-center justify-between pt-1 border-t border-amber-200/80 text-[10px]">
                            <span className="text-amber-900">
                              Your Bid: <strong className="font-bold">${myHighestBid.amountUSD.toLocaleString()}</strong>
                            </span>
                            <span
                              className={`px-1.5 py-0.5 rounded font-bold uppercase ${
                                isLeadingBidder
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                  : 'bg-rose-100 text-rose-700 border border-rose-300'
                              }`}
                            >
                              {isLeadingBidder ? 'Leading' : 'Outbid'}
                            </span>
                          </div>
                        )}

                        {!isParticipatingExternalAuction && isMyAuctionDone(item) && item.auctionConfig?.highestBidderHandle && (
                          <div className="flex items-center justify-between pt-1 border-t border-amber-200/80 text-[10px] text-emerald-800 font-bold">
                            <span>Winner: @{item.auctionConfig.highestBidderHandle.replace(/^@/, '')}</span>
                            <span>Final: ${displayUSD.toLocaleString()}</span>
                          </div>
                        )}

                        {!isParticipatingExternalAuction && !isMyAuctionDone(item) && (item.auctionConfig?.reservePriceUSD || item.auctionConfig?.buyNowPriceUSD) && (
                          <div className="flex items-center justify-between pt-1 border-t border-amber-200/80 text-[10px] text-amber-800">
                            {item.auctionConfig?.reservePriceUSD ? (
                              <span>Reserve: ${item.auctionConfig.reservePriceUSD.toLocaleString()}</span>
                            ) : <span />}
                            {item.auctionConfig?.buyNowPriceUSD && (
                              <span>Buy Now: ${item.auctionConfig.buyNowPriceUSD.toLocaleString()}</span>
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Price and Badges */}
                    <div className="pt-2 border-t border-neutral-100 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono text-xs font-bold text-neutral-900">
                          ${displayUSD.toLocaleString()}
                        </span>
                        <span className="flex items-center gap-1 text-[11px] font-mono text-neutral-500">
                          <Eye className="w-3.5 h-3.5 text-neutral-400" />
                          <span>{(item.views ?? 0).toLocaleString()} views</span>
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        {item.acceptedSettlements?.includes('barter') && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                            ⇄ BARTER
                          </span>
                        )}
                        {item.primaryCurrency && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-800 border border-neutral-200 font-bold uppercase">
                            {item.primaryCurrency}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Post Ratings & Comments Preview */}
                    <div className="pt-2 border-t border-neutral-100 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5 text-amber-500 font-bold">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span className="text-neutral-900 font-mono">
                            {itemAvg.count > 0 ? itemAvg.average.toFixed(1) : '5.0'}
                          </span>
                          <span className="text-neutral-400 text-[10px] font-mono">
                            ({itemAvg.count} {itemAvg.count === 1 ? 'rating' : 'ratings'})
                          </span>
                        </div>
                        {itemReviews.length > 0 && (
                          <span className="text-[10px] text-neutral-500 flex items-center gap-1">
                            <MessageSquare className="w-3 h-3 text-neutral-400" />
                            <span>{itemReviews.length} {itemReviews.length === 1 ? 'comment' : 'comments'}</span>
                          </span>
                        )}
                      </div>
                      {itemReviews.length > 0 && (
                        <p className="text-[11px] text-neutral-600 bg-neutral-50 rounded-xl p-2 line-clamp-2 italic border border-neutral-100">
                          &ldquo;{itemReviews[0].comment}&rdquo;
                          <span className="block not-italic text-[9px] text-neutral-400 mt-0.5 font-medium">
                            — {itemReviews[0].reviewerName}
                          </span>
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="p-4 pt-2 space-y-2 border-t border-neutral-100 mt-3">
                  {isParticipatingExternalAuction ? (
                    <button
                      type="button"
                      onClick={() => setAuctionManageListing(item)}
                      className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                      title="Place a bid or view auction room"
                    >
                      <Gavel className="h-3.5 w-3.5" />
                      <span>{isLeadingBidder ? `View Bids (${auctionBids.length})` : `Place Higher Bid (${auctionBids.length})`}</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      {isAuction && isMyAuctionDone(item) ? (
                        <button
                          type="button"
                          onClick={() => setAuctionManageListing(item)}
                          className="flex-1 py-2 px-3 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          title="Review settled auction bids and winner details"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Settled · Bids ({auctionBids.length})</span>
                        </button>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => handleTogglePublish(item)}
                            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                              item.status === 'uploaded'
                                ? 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200 border border-neutral-200'
                                : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-2xs'
                            }`}
                          >
                            <Check className="h-3.5 w-3.5" />
                            <span>{item.status === 'uploaded' ? 'Unpublish' : 'Publish Live'}</span>
                          </button>

                          {isAuction && (
                            <button
                              type="button"
                              onClick={() => setAuctionManageListing(item)}
                              className="py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                              title="Inspect incoming bids & award auction"
                            >
                              <Gavel className="h-3.5 w-3.5" />
                              <span>Bids ({auctionBids.length})</span>
                            </button>
                          )}
                        </>
                      )}

                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(item)}
                        className="p-2 rounded-xl border border-neutral-200 bg-white text-neutral-700 hover:text-black hover:border-neutral-300 transition-colors cursor-pointer"
                        title="Edit listing details"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteListing(item.id)}
                        className="p-2 rounded-xl border border-neutral-200 bg-white text-neutral-400 hover:text-red-600 hover:border-red-200 transition-colors cursor-pointer"
                        title="Delete listing"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  )}

                  {item.status !== 'draft' && (
                    <button
                      type="button"
                      onClick={() => handleShareListingTweet(item)}
                      className="w-full py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                      title="Share on Tweeting feed with ratings and comments"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Share on Tweeting</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
            </div>
          )}
        </div>
      )}

      {/* Edit Listing Modal */}
      {isModalOpen && (
        <CreateListingDraftModal
          isOpen={isModalOpen}
          currentUser={currentUser}
          initialDraft={activeModalListing}
          onClose={() => setIsModalOpen(false)}
          onSaved={() => {
            setIsModalOpen(false);
            refreshListings();
            showToast('Listing updated successfully');
          }}
        />
      )}

      {/* ================= MODAL: AUDIENCE & PRIVACY SELECTOR ================= */}
      <AnimatePresence>
        {isAudienceModalOpen && selectedListingForAudience && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-md w-full shadow-2xl space-y-5 text-left"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-neutral-900 text-white">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-neutral-900">Select Listing Audience</h3>
                    <p className="text-[11px] text-neutral-500 line-clamp-1">
                      {selectedListingForAudience.title}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAudienceModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Audience Options */}
              <div className="space-y-2.5">
                {/* 1. Public */}
                <label
                  onClick={() => setSelectedVisibility('public')}
                  className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                    selectedVisibility === 'public'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 mt-0.5 shrink-0 border border-emerald-200">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-neutral-900">Public (The World)</span>
                      <input
                        type="radio"
                        name="visibility-page"
                        checked={selectedVisibility === 'public'}
                        onChange={() => setSelectedVisibility('public')}
                        className="accent-black"
                      />
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Visible to everyone across the global marketplace and public profile views.
                    </p>
                  </div>
                </label>

                {/* 2. Friends Only */}
                <label
                  onClick={() => setSelectedVisibility('friends')}
                  className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                    selectedVisibility === 'friends'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-blue-50 text-blue-700 mt-0.5 shrink-0 border border-blue-200">
                    <Users className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-neutral-900">Friends Only</span>
                      <input
                        type="radio"
                        name="visibility-page"
                        checked={selectedVisibility === 'friends'}
                        onChange={() => setSelectedVisibility('friends')}
                        className="accent-black"
                      />
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Only your confirmed mutual friends on Final Finance can see and submit barter trades.
                    </p>
                  </div>
                </label>

                {/* 3. Specific Friend Group */}
                <div
                  className={`p-3 rounded-2xl border-2 transition-all ${
                    selectedVisibility === 'custom_group'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <label
                    onClick={() => setSelectedVisibility('custom_group')}
                    className="flex items-start gap-3 cursor-pointer"
                  >
                    <div className="p-2 rounded-xl bg-amber-50 text-amber-800 mt-0.5 shrink-0 border border-amber-200">
                      <Shield className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-neutral-900">Specific Friend Group</span>
                        <input
                          type="radio"
                          name="visibility-page"
                          checked={selectedVisibility === 'custom_group'}
                          onChange={() => setSelectedVisibility('custom_group')}
                          className="accent-black"
                        />
                      </div>
                      <p className="text-[11px] text-neutral-500 mt-0.5">
                        Only members of your chosen friend group(s) will have access.
                      </p>
                    </div>
                  </label>

                  {/* Friend Group Checkboxes when selected */}
                  {selectedVisibility === 'custom_group' && (
                    <div className="mt-3 pt-3 border-t border-neutral-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-neutral-800 uppercase tracking-wider">
                          Choose Friend Groups:
                        </span>
                        <button
                          type="button"
                          onClick={() => handleOpenCreateGroup()}
                          className="text-[11px] font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          <span>New Group</span>
                        </button>
                      </div>

                      {friendGroups.length === 0 ? (
                        <div className="p-3 rounded-xl bg-white border border-neutral-200 text-center space-y-1.5">
                          <p className="text-xs text-neutral-500">You have no custom friend groups yet.</p>
                          <button
                            type="button"
                            onClick={() => handleOpenCreateGroup()}
                            className="px-3 py-1 rounded-lg bg-neutral-900 text-white text-xs font-semibold cursor-pointer"
                          >
                            + Create First Friend Group
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                          {friendGroups.map((group) => {
                            const isChecked = selectedGroupIds.includes(group.id);
                            return (
                              <div
                                key={group.id}
                                onClick={() => toggleGroupSelection(group.id)}
                                className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                                  isChecked
                                    ? 'bg-amber-500/10 border-amber-400 text-neutral-950 font-semibold'
                                    : 'bg-white border-neutral-200 text-neutral-700 hover:border-neutral-300'
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <div
                                    className="w-2.5 h-2.5 rounded-full shrink-0"
                                    style={{ backgroundColor: group.color || '#f59e0b' }}
                                  />
                                  <span>{group.name}</span>
                                  <span className="text-[10px] text-neutral-400 font-mono">
                                    ({group.memberUids.length} friends)
                                  </span>
                                </div>
                                {isChecked ? (
                                  <CheckSquare className="w-4 h-4 text-amber-600" />
                                ) : (
                                  <Square className="w-4 h-4 text-neutral-300" />
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* 4. Only Me */}
                <label
                  onClick={() => setSelectedVisibility('only_me')}
                  className={`flex items-start gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ${
                    selectedVisibility === 'only_me'
                      ? 'border-neutral-950 bg-neutral-50 ring-2 ring-neutral-900/10'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-neutral-100 text-neutral-700 mt-0.5 shrink-0 border border-neutral-200">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-neutral-900">Only Me (Private Vault)</span>
                      <input
                        type="radio"
                        name="visibility-page"
                        checked={selectedVisibility === 'only_me'}
                        onChange={() => setSelectedVisibility('only_me')}
                        className="accent-black"
                      />
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Completely private allocation. Only you can view this item in your personal depository.
                    </p>
                  </div>
                </label>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsAudienceModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveAudience}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Apply Audience</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: FRIEND GROUPS MANAGER ================= */}
      <AnimatePresence>
        {isGroupManagerModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-lg w-full shadow-2xl space-y-5 text-left max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-neutral-900 text-white">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-neutral-900">Custom Groups</h3>
                    <p className="text-[11px] text-neutral-500">
                      Up to {MAX_CUSTOM_GROUP_MEMBERS} friends or general people per group with optional numbers &amp; roles
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setOpenedManagerGroupId(null);
                    setIsGroupManagerModalOpen(false);
                  }}
                  className="p-1 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {(() => {
                const openedMgrGroup = friendGroups.find(g => g.id === openedManagerGroupId) || null;
                const combinedUsers = [...availableFriends, ...platformUsers];
                if (openedMgrGroup) {
                  const ordered = resolveAndSortGroupMembers(openedMgrGroup, combinedUsers);
                  return (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => setOpenedManagerGroupId(null)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-neutral-100 hover:bg-neutral-200 text-xs font-semibold text-neutral-800 cursor-pointer"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span>All Groups</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenCreateGroup(openedMgrGroup)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-black text-white text-xs font-semibold cursor-pointer"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                      </div>

                      <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3.5 h-3.5 rounded-full shrink-0"
                            style={{ backgroundColor: openedMgrGroup.color || '#f59e0b' }}
                          />
                          <h4 className="font-bold text-sm text-neutral-900">{openedMgrGroup.name}</h4>
                          <span className="text-[10px] font-mono text-neutral-500">
                            {ordered.length}/{MAX_CUSTOM_GROUP_MEMBERS}
                          </span>
                        </div>
                        {openedMgrGroup.description && (
                          <p className="text-[11px] text-neutral-500 mt-1">{openedMgrGroup.description}</p>
                        )}
                      </div>

                      {ordered.length === 0 ? (
                        <p className="text-xs text-neutral-400 italic text-center py-4">
                          No members in this group yet.
                        </p>
                      ) : (
                        <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                          {ordered.map((m) => {
                            const assign = openedMgrGroup.memberAssignments?.[m.uid];
                            const hasNum = typeof assign?.number === 'number' && Number.isFinite(assign.number);
                            return (
                              <div
                                key={m.uid}
                                className="flex items-center justify-between gap-2 p-2.5 rounded-xl border border-neutral-200 bg-white"
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <span
                                    className={`min-w-[32px] h-7 px-1.5 rounded-lg flex items-center justify-center font-mono text-[11px] font-bold shrink-0 ${
                                      hasNum
                                        ? 'bg-black text-white'
                                        : 'bg-neutral-100 text-neutral-400'
                                    }`}
                                  >
                                    {hasNum ? `#${assign?.number}` : '—'}
                                  </span>
                                  <div className="min-w-0">
                                    <p className="text-xs font-semibold text-neutral-900 truncate">{m.name}</p>
                                    <p className="text-[10px] font-mono text-neutral-400 truncate">@{m.userId}</p>
                                  </div>
                                </div>
                                {assign?.role && (
                                  <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-semibold shrink-0">
                                    {assign.role}
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                }

                return (
                  <>
                    {/* Create Group CTA Banner */}
                    <button
                      type="button"
                      onClick={() => handleOpenCreateGroup()}
                      className="w-full min-h-[44px] px-4 py-2.5 rounded-2xl bg-neutral-900 hover:bg-black text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-[0.99]"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Create New Group (Up to {MAX_CUSTOM_GROUP_MEMBERS})</span>
                    </button>

                    {/* Groups List */}
                    <div className="space-y-3">
                      {friendGroups.length === 0 ? (
                        <div className="p-8 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-2">
                          <Users className="w-8 h-8 text-neutral-400 mx-auto" />
                          <h4 className="font-bold text-xs text-neutral-800">No Custom Groups Created</h4>
                          <p className="text-[11px] text-neutral-500 max-w-xs mx-auto">
                            Organize friends or general people into specialized groups (up to {MAX_CUSTOM_GROUP_MEMBERS} people) with optional numbers and roles.
                          </p>
                        </div>
                      ) : (
                        friendGroups.map((group) => {
                          const orderedMembers = resolveAndSortGroupMembers(group, combinedUsers);
                          return (
                            <div
                              key={group.id}
                              className="p-4 rounded-2xl border border-neutral-200/90 bg-white hover:border-neutral-300 transition-all space-y-2.5"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <button
                                  type="button"
                                  onClick={() => setOpenedManagerGroupId(group.id)}
                                  className="flex items-center gap-2 text-left cursor-pointer hover:opacity-80"
                                >
                                  <div
                                    className="w-3.5 h-3.5 rounded-full shrink-0"
                                    style={{ backgroundColor: group.color || '#f59e0b' }}
                                  />
                                  <div>
                                    <h4 className="font-bold text-xs text-neutral-900">{group.name}</h4>
                                    {group.description && (
                                      <p className="text-[11px] text-neutral-500">{group.description}</p>
                                    )}
                                  </div>
                                </button>

                                <div className="flex items-center gap-1 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => setOpenedManagerGroupId(group.id)}
                                    className="px-2.5 py-1 rounded-full bg-neutral-900 text-white text-[10px] font-semibold cursor-pointer"
                                  >
                                    Open
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleOpenCreateGroup(group)}
                                    title="Edit group members and details"
                                    className="p-1.5 rounded-lg text-neutral-500 hover:text-black hover:bg-neutral-100 cursor-pointer"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteGroup(group.id, group.name)}
                                    title="Delete group"
                                    className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>

                              {/* Group Member Count & Ordered Chips */}
                              <div className="pt-2 border-t border-neutral-100 flex items-center justify-between gap-2 text-[11px]">
                                <span className="font-mono text-neutral-500 shrink-0">
                                  {group.memberUids.length}/{MAX_CUSTOM_GROUP_MEMBERS} members
                                </span>
                                {orderedMembers.length > 0 && (
                                  <div className="flex flex-wrap items-center justify-end gap-1 font-mono text-neutral-400">
                                    {orderedMembers.slice(0, 3).map((m) => {
                                      const assign = group.memberAssignments?.[m.uid];
                                      return (
                                        <span key={m.uid} className="bg-neutral-100 px-1.5 py-0.5 rounded-md text-neutral-700 text-[10px]">
                                          {typeof assign?.number === 'number' ? `#${assign.number} ` : ''}
                                          @{m.userId}
                                          {assign?.role ? ` (${assign.role})` : ''}
                                        </span>
                                      );
                                    })}
                                    {orderedMembers.length > 3 && (
                                      <span className="text-[10px]">+{orderedMembers.length - 3}</span>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </>
                );
              })()}

              {/* Close Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setOpenedManagerGroupId(null);
                    setIsGroupManagerModalOpen(false);
                  }}
                  className="w-full min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: CREATE / EDIT FRIEND GROUP ================= */}
      <AnimatePresence>
        {isCreateGroupModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-lg w-full shadow-2xl space-y-4 text-left max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-neutral-900 text-white">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-neutral-900">
                      {editingGroup ? 'Edit Custom Group' : 'Create Custom Group'}
                    </h3>
                    <p className="text-[11px] text-neutral-500">
                      Up to {MAX_CUSTOM_GROUP_MEMBERS} friends or general people &bull; Optional number &amp; role per group
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCreateGroupModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Group Type Selection */}
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  People Source (Max {MAX_CUSTOM_GROUP_MEMBERS})
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleSetGroupType('friend')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      groupTypeInput === 'friend'
                        ? 'bg-black text-white border-black shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    <span>Friend Group</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetGroupType('general')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      groupTypeInput === 'general'
                        ? 'bg-black text-white border-black shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    <span>General People &amp; Friends</span>
                  </button>
                </div>
              </div>

              {/* Group Avatar URL */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-800 block">Group Image (Upload or URL)</label>
                <div className="flex gap-2">
                  <div 
                    onClick={() => groupImageFileRef.current?.click()}
                    className="w-10 h-10 rounded-xl bg-neutral-100 flex items-center justify-center shrink-0 border border-neutral-200 overflow-hidden cursor-pointer hover:bg-neutral-200 transition-colors group"
                  >
                    {groupAvatarInput ? (
                      <img src={groupAvatarInput} alt="Group preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="flex flex-col items-center">
                        <Upload className="w-3.5 h-3.5 text-neutral-400 group-hover:text-black" />
                        <span className="text-[7px] text-neutral-400 group-hover:text-black mt-0.5 uppercase font-bold">Upload</span>
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={groupImageFileRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <div className="flex-1 space-y-1">
                    <input
                      type="text"
                      value={groupAvatarInput}
                      onChange={(e) => setGroupAvatarInput(e.target.value)}
                      placeholder="Paste image URL here..."
                      className="w-full px-3 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                    />
                    {groupAvatarInput && (
                      <button
                        type="button"
                        onClick={() => setGroupAvatarInput('')}
                        className="text-[9px] text-red-500 hover:text-red-700 font-semibold cursor-pointer"
                      >
                        Remove Image
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Group Name Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-neutral-800 block">Group Name *</label>
                <input
                  type="text"
                  value={groupNameInput}
                  onChange={(e) => setGroupNameInput(e.target.value)}
                  placeholder="e.g. Zurich Bullion Syndicate, VIP Horology"
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />
              </div>

              {/* Description Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-neutral-800 block">Description (Optional)</label>
                <input
                  type="text"
                  value={groupDescInput}
                  onChange={(e) => setGroupDescInput(e.target.value)}
                  placeholder="e.g. Private circle for verified bullion swaps"
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />
              </div>

              {/* Color Tag Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-800 block">Group Color Tag</label>
                <div className="flex items-center gap-2">
                  {['#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#64748b'].map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setGroupColorInput(color)}
                      className={`w-6 h-6 rounded-full cursor-pointer transition-transform ${
                        groupColorInput === color ? 'scale-125 ring-2 ring-neutral-950 ring-offset-2' : 'hover:scale-110'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              {/* Friend / People Picker List */}
              <div className="space-y-2 pt-2 border-t border-neutral-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-800 block">
                    Select People ({selectedMemberUids.length} / {MAX_CUSTOM_GROUP_MEMBERS} selected)
                  </label>
                  {selectedMemberUids.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedMemberUids([])}
                      className="text-[11px] text-neutral-500 hover:text-black cursor-pointer underline"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {/* Search Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                  <input
                    type="text"
                    value={memberSearchQuery}
                    onChange={(e) => setMemberSearchQuery(e.target.value)}
                    placeholder={groupTypeInput === 'friend' ? "Search your network friends..." : "Search friends or general people..."}
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                  />
                </div>

                {/* Group Error Message */}
                {groupErrorMsg && (
                  <div className="mt-2 mb-2 p-2 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100 flex items-center justify-between">
                    <span>{groupErrorMsg}</span>
                    <button type="button" onClick={() => setGroupErrorMsg('')} className="p-0.5 hover:bg-red-100 rounded-full text-red-700">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Checkbox List */}
                <div className="mt-2 space-y-1 max-h-40 overflow-y-auto pr-1">
                  {selectableUsersForGroup.length === 0 ? (
                    <div className="p-4 text-center text-xs text-neutral-400">
                      {groupTypeInput === 'friend' 
                        ? "You don't have any confirmed friends yet. Switch to General People & Friends or add friends first."
                        : "No users found in your network. Use 'Discover' to find people."
                      }
                    </div>
                  ) : (
                    selectableUsersForGroup
                      .filter(f => 
                        f.name.toLowerCase().includes(memberSearchQuery.toLowerCase()) ||
                        f.userId.toLowerCase().includes(memberSearchQuery.toLowerCase())
                      )
                      .map((friend) => {
                      const isChecked = selectedMemberUids.includes(friend.uid);
                      return (
                        <div
                          key={friend.uid}
                          onClick={() => toggleMemberSelection(friend.uid)}
                          className={`flex items-center justify-between p-2 rounded-xl border text-xs cursor-pointer transition-all ${
                            isChecked
                              ? 'bg-neutral-900 text-white border-neutral-900 font-medium'
                              : 'bg-white border-neutral-200 text-neutral-800 hover:border-neutral-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-neutral-200 overflow-hidden shrink-0 flex items-center justify-center font-bold text-[10px]">
                              {friend.avatarUrl ? (
                                <img src={friend.avatarUrl} alt={friend.name} className="w-full h-full object-cover" />
                              ) : (
                                friend.name.charAt(0).toUpperCase()
                              )}
                            </div>
                            <div>
                              <p className="font-semibold leading-tight">{friend.name}</p>
                              <p className={`text-[10px] font-mono ${isChecked ? 'text-neutral-300' : 'text-neutral-400'}`}>
                                @{friend.userId}
                              </p>
                            </div>
                          </div>

                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Square className="w-4 h-4 text-neutral-300" />
                          )}
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Selected Members Optional Number & Role Assignment */}
                {selectedMemberUids.length > 0 && (
                  <div className="pt-2 border-t border-neutral-100 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-neutral-800">
                        Assign Optional Number &amp; Role ({selectedMemberUids.length}/{MAX_CUSTOM_GROUP_MEMBERS})
                      </span>
                      <span className="text-[10px] text-neutral-400">Independent per group</span>
                    </div>
                    <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                      {selectedMemberUids.map((uid) => {
                        const allKnown = [...availableFriends, ...platformUsers];
                        const member = allKnown.find((u) => u.uid === uid);
                        const memberName = member?.name || uid.replace(/^user-/, '').replace(/^demo-/, '');
                        const assign = memberAssignmentsInput[uid] || { number: '', role: '' };
                        return (
                          <div
                            key={uid}
                            className="p-2 rounded-xl border border-neutral-200 bg-neutral-50 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                          >
                            <span className="text-xs font-semibold text-neutral-900 truncate">{memberName}</span>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <input
                                type="number"
                                step="1"
                                value={assign.number}
                                onChange={(e) => handleMemberAssignmentChange(uid, 'number', e.target.value)}
                                placeholder="# (opt)"
                                className="w-20 px-2 py-1 rounded-lg bg-white border border-neutral-200 text-xs font-mono text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                              <input
                                type="text"
                                value={assign.role}
                                onChange={(e) => handleMemberAssignmentChange(uid, 'role', e.target.value)}
                                placeholder="Role (optional)"
                                className="w-32 px-2 py-1 rounded-lg bg-white border border-neutral-200 text-xs text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsCreateGroupModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveGroup}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{editingGroup ? 'Save Changes' : 'Create Group'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL 6: CONFIRM DELETE GROUP ================= */}
      {groupToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-sm w-full overflow-hidden flex flex-col">
            <div className="p-5 border-b border-neutral-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-black">Delete Group</h3>
                <p className="text-[11px] text-neutral-400">This action cannot be undone.</p>
              </div>
            </div>
            <div className="p-5">
              <p className="text-xs text-neutral-600 leading-relaxed">
                Are you sure you want to delete the <span className="font-bold text-neutral-900">"{groupToDelete.name}"</span> group? Members will not be removed from your connections, but this grouping will be permanently lost.
              </p>
            </div>
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setGroupToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteGroup}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors shadow-xs cursor-pointer"
              >
                Delete Group
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Seller Auction Bid & Award Modal */}
      {auctionManageListing && (
        <AuctionBidModal
          isOpen={Boolean(auctionManageListing)}
          currentUser={currentUser}
          targetListing={{
            ...auctionManageListing,
            sellerId: auctionManageListing.userId,
            sellerName: auctionManageListing.creatorName,
            sellerHandle: auctionManageListing.creatorHandle,
            priceUSD: auctionManageListing.primaryPriceUSD,
            estimatedValueUSD: auctionManageListing.primaryPriceUSD,
          }}
          onClose={() => setAuctionManageListing(null)}
          onAuctionUpdated={refreshListings}
        />
      )}
    </div>
  );
};
