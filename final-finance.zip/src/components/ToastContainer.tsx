import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2, AlertTriangle, Info, Sparkles, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 sm:top-6 inset-x-0 z-50 flex flex-col items-center gap-3 w-full px-3 sm:px-4 pointer-events-none">
      {toasts.map((toast) => {
        const isGold = toast.type === 'gold';
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto rounded-2xl p-3.5 sm:p-4 shadow-2xl border backdrop-blur-xl flex items-start gap-3 transition-all animate-in fade-in slide-in-from-top-4 duration-300 w-full max-w-sm sm:max-w-md ${
              isGold
                ? 'border-amber-200 bg-amber-50/95 text-amber-900 shadow-amber-500/20'
                : isSuccess
                ? 'border-emerald-200 bg-emerald-50/95 text-emerald-950 shadow-emerald-500/20'
                : isError
                ? 'border-rose-200 bg-rose-50/95 text-rose-950 shadow-rose-500/20'
                : 'border-slate-200 bg-white/95 text-slate-900 shadow-slate-900/10'
            }`}
          >
            <div className="shrink-0 mt-0.5 p-1 rounded-full bg-white/80 shadow-xs">
              {isGold ? (
                <Sparkles className="h-4 w-4 text-amber-600" />
              ) : isSuccess ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              ) : isError ? (
                <AlertTriangle className="h-4 w-4 text-rose-600" />
              ) : (
                <Info className="h-4 w-4 text-sky-600" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h5 className="font-semibold text-xs tracking-tight">{toast.title}</h5>
              <p className="text-[11px] opacity-80 leading-relaxed mt-0.5">{toast.message}</p>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-slate-700 shrink-0 p-1 rounded-lg hover:bg-black/5 transition-colors cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};

