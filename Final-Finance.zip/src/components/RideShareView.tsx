/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { areUsersBlockedEitherWay, getAllUsers, registerDriverProfile } from '../services/socialService';
import { UserPublicProfile } from '../types/social';
import { PresenceAvatarDot, PresenceStatusBadge } from './common/PresenceBadge';
import { 
  Car, 
  MapPin, 
  Navigation, 
  UserCheck, 
  Store, 
  UtensilsCrossed, 
  Clock, 
  DollarSign, 
  CheckCircle2, 
  ShieldCheck, 
  Star, 
  Phone, 
  Award, 
  ArrowRight, 
  Package, 
  Compass,
  AlertCircle,
  Check,
  TrendingUp,
  Coins,
  Map,
  History,
  XCircle,
  Search,
  ExternalLink,
  ListOrdered,
  Bell,
  CornerUpLeft,
  CornerUpRight,
  ArrowUp,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  X,
  Play,
  Pause,
  Ticket,
  QrCode,
  Pencil,
  MessageSquare,
  ArrowLeft
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { CustomCoin } from '../types/coinLaunch';
import { getStoredCustomCoins, isFinalCoinCreatedByUser } from '../data/customCoinsData';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { applyCurrencyWalletDelta } from '../utils/walletBalanceUpdater';
import { UserWalletData } from '../types/wallet';
import {
  recordLedgerTransaction,
  LEDGER_UPDATED_EVENT,
  createLedgerItemFromRideShareBooking,
  createLedgerItemFromRideShareCancellation,
  createLedgerItemFromRideSharePayout,
  markLedgerItemReversedByReceipt
} from '../utils/universalLedgerBridge';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { getUserVerificationTier, isAdminOrSuperAdminUser } from '../utils/verificationTiers';
import {
  AddressSuggestion,
  TurnByTurnStep,
  getAddressSuggestions,
  buildTurnByTurnRoute,
  estimateDeliveryTiming
} from '../utils/rideShareNavigation';
import {
  DEFAULT_VEHICLE_MEDIA,
  getCustomDriverVehicleFallbackPhoto
} from '../utils/vehicleShowcaseMedia';
import { PlatformCoupon } from '../types/coupon';
import {
  COUPONS_UPDATED_EVENT,
  clearPendingCheckoutCoupon,
  evaluateCouponForOrder,
  findCouponByCode,
  getApplicableSavedCoupons,
  peekPendingCheckoutCoupon,
  redeemCouponForUser,
  searchRelevantCouponsForCheckout,
} from '../services/couponService';
import { CouponIssuerWidget } from './CouponIssuerWidget';
import {
  clearProfileReturnAnchor,
  getProfileReturnAnchor,
  setPageReturnAnchor,
} from '../utils/profileReturnState';

interface RideShareViewProps {
  currentUser: AuthSession | null;
  onNavigateBack?: () => void;
  backLabel?: string;
  onViewUserProfile?: (userIdOrHandle: string) => void;
  onOpenVerificationModal?: (tier?: 1 | 2 | 3) => void;
  onOpenDirectMessage?: (targetUser: UserPublicProfile) => void;
  onOpenVoiceCall?: (
    targetUser: { uid: string; userId: string; name: string; avatarUrl?: string },
    isGroup?: boolean,
    groupParticipants?: any[],
    options?: { allowNonFriend?: boolean; voiceOnly?: boolean }
  ) => void;
  pendingDestination?: {
    address: string;
    label?: string;
    requestedAt: number;
  } | null;
  onConsumePendingDestination?: () => void;
}

export type DriverVehicleType = 'car' | 'auto_rickshaw' | 'motor_bike';
export type VehicleTypeLabel = 'Car' | 'Auto Rickshaw' | 'Motor Bike';
export type VehicleClassName =
  | 'Economy'
  | 'Comfort EV'
  | 'Luxury Limousine'
  | 'Auto Rickshaw'
  | 'Moto Express';

export interface DriverVehicleSlot {
  vehicleType: DriverVehicleType;
  vehicleTypeLabel: VehicleTypeLabel;
  vehicleClass: VehicleClassName;
  makeModel: string;
  year: string;
  plate: string;
  licenseId: string;
  ratePerMile: number;
  deliveryRatePerMile?: number;
  foodDeliveryRatePerMile?: number;
  retailDeliveryRatePerMile?: number;
  insuranceInfo: string;
  online: boolean;
  media: string[];
  videoMedia?: string[];
  registeredAt: string;
  updatedAt?: string;
}

interface DriverVehicleDraft {
  makeModel: string;
  vehicleClass: VehicleClassName;
  year: string;
  plate: string;
  licenseId: string;
  ratePerMile: number;
  foodDeliveryRatePerMile: number;
  retailDeliveryRatePerMile: number;
  insuranceInfo: string;
  media: string[];
  videoMedia: string[];
}

export interface RideRequest {
  id: string;
  riderId: string;
  riderName: string;
  pickup: string;
  dropoff: string;
  vehicleType?: VehicleTypeLabel;
  vehicleClass: VehicleClassName;
  fare: number;
  currency: string;
  currencySplits?: Array<{ currency: string; amount: number }>;
  status: 'searching' | 'driver_assigned' | 'in_transit' | 'completed' | 'cancelled';
  driverId?: string;
  driverName?: string;
  driverAvatar?: string;
  driverHandle?: string;
  driverCar?: string;
  driverCarYear?: string;
  driverPlate?: string;
  driverPhotos?: string[];
  driverVideos?: string[];
  driverRating?: number;
  createdAt: string;
  rating?: number;
  comment?: string;
  estimatedTime?: string;
  distance?: string;
  directions?: string[];
}

export interface DeliveryContract {
  id: string;
  takeoutOrderId?: string;
  orderNumber: string;
  merchantId: string;
  merchantName: string;
  businessType: 'retail' | 'restaurant';
  deliveryAddress: string;
  customerName: string;
  deliveryFee: number;
  originalStoreFee?: number;
  storeRatePerMile?: number;
  currency: string;
  originalCurrency?: string;
  orderCurrency?: string;
  orderTotalBefore?: number;
  driverRatePerMile?: number;
  status: 'available' | 'accepted' | 'picked_up' | 'delivered' | 'cancelled';
  driverHandle?: string;
  driverName?: string;
  createdAt: string;
  rating?: number;
  comment?: string;
  pickupAddress?: string;
  estimatedTime?: string;
  distance?: string;
  distanceMiles?: number;
  directions?: string[];
  proofPhotos?: string[];
  proofVideos?: string[];
  deliveredAt?: string;
}

export interface DriverDeliveryNotification {
  id: string;
  contractId: string;
  orderNumber: string;
  merchantName: string;
  businessType: 'retail' | 'restaurant';
  pickupAddress: string;
  deliveryAddress: string;
  customerName: string;
  distance: string;
  distanceMiles: number;
  storeFee: number;
  storeFeeCurrency: string;
  orderCurrency?: string;
  paymentCurrency?: string;
  storeRatePerMile?: number;
  createdAt: string;
  read: boolean;
}

const DEFAULT_PLATFORM_CURRENCY_SYMBOLS = [
  'AFNL',
  'FNL-TECH',
  'FNL-GOLD',
  'FNL-USD',
  'FNL-EURO',
  'FNL-GBP',
  'FNL-CHF',
  'BTC-S',
  'ETH-S',
  'SOL-S'
];

const MOCK_MERCHANT_LOC_IDS = new Set<string>([
  'loc-retail-1',
  'loc-retail-2',
  'loc-retail-3',
  'loc-retail-4',
  'loc-retail-5',
  'loc-retail-6',
  'loc-retail-7',
  'loc-rest-1',
  'loc-rest-2',
  'loc-rest-3',
  'loc-rest-4',
  'loc-rest-5',
  'loc-rest-6',
]);

const SAMPLE_MERCHANT_ORDERS: DeliveryContract[] = [];

interface AvailableVehicleOption {
  id: string;
  vehicleType: VehicleTypeLabel;
  vehicleClass: VehicleClassName;
  driverName: string;
  driverHandle?: string;
  driverAvatar?: string;
  carModel: string;
  carYear: string;
  plate: string;
  rating: number;
  etaMins: number;
  mult: number;
  ratePerMile: number;
  color: string;
  seats: string;
  specs: string;
  media: string[];
  videoMedia: string[];
  available: boolean;
}

const DEFAULT_SECTOR_VEHICLES: AvailableVehicleOption[] = [
  {
    id: 'drv-econ-1',
    vehicleType: 'Car',
    vehicleClass: 'Economy',
    driverName: 'Lukas Meyer',
    driverHandle: 'lukas_meyer',
    driverAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    carModel: 'VW ID.4 Pro Electric',
    carYear: '2025',
    plate: 'ZH-412-809',
    rating: 4.91,
    etaMins: 3,
    mult: 4.2,
    ratePerMile: 5,
    color: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].videos,
    available: true
  },
  {
    id: 'drv-ev-1',
    vehicleType: 'Car',
    vehicleClass: 'Comfort EV',
    driverName: 'Elena Vance',
    driverHandle: 'elena_vance',
    driverAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    carModel: 'Polestar 2 Long Range',
    carYear: '2025',
    plate: 'ZH-618-334',
    rating: 4.97,
    etaMins: 2,
    mult: 7.5,
    ratePerMile: 6,
    color: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].videos,
    available: true
  },
  {
    id: 'drv-lux-1',
    vehicleType: 'Car',
    vehicleClass: 'Luxury Limousine',
    driverName: 'Marc-Antoine Weber',
    driverHandle: 'marc_weber',
    driverAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    carModel: 'Mercedes-Maybach S680',
    carYear: '2025',
    plate: 'ZH-100-777',
    rating: 4.99,
    etaMins: 5,
    mult: 19.5,
    ratePerMile: 12,
    color: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].videos,
    available: true
  },
  {
    id: 'drv-rick-1',
    vehicleType: 'Auto Rickshaw',
    vehicleClass: 'Auto Rickshaw',
    driverName: 'Aarav Patel',
    driverHandle: 'aarav_patel',
    driverAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
    carModel: 'Bajaj RE Electric Three-Wheeler',
    carYear: '2025',
    plate: 'ZH-R30-218',
    rating: 4.93,
    etaMins: 2,
    mult: 3.1,
    ratePerMile: 4,
    color: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].videos,
    available: true
  },
  {
    id: 'drv-moto-1',
    vehicleType: 'Motor Bike',
    vehicleClass: 'Moto Express',
    driverName: 'Matteo Rossi',
    driverHandle: 'matteo_rossi',
    driverAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80',
    carModel: 'Zero SR/F Sovereign Moto',
    carYear: '2025',
    plate: 'ZH-M92-14',
    rating: 4.88,
    etaMins: 1,
    mult: 2.8,
    ratePerMile: 3.5,
    color: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].videos,
    available: true
  },
  {
    id: 'drv-sven',
    vehicleType: 'Car',
    vehicleClass: 'Comfort EV',
    driverName: 'Sven Keller',
    driverHandle: 'driver_sven',
    driverAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    carModel: 'Tesla Model Y Long Range',
    carYear: '2025',
    plate: 'ZH-552-190',
    rating: 4.95,
    etaMins: 4,
    mult: 7.8,
    ratePerMile: 6.5,
    color: 'Pearl White Multi-Coat',
    seats: '4 Passengers · Dual-Zone Climate',
    specs: 'All-Wheel Drive EV · Autopilot Hardware · Generous Luggage Bay',
    media: [
      getCustomDriverVehicleFallbackPhoto('Car', 'Tesla Model Y Long Range (2025)', 'ZH-552-190'),
      DEFAULT_VEHICLE_MEDIA['drv-ev-1'].photos[1]
    ],
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].videos,
    available: true
  },
  {
    id: 'drv-chloe',
    vehicleType: 'Auto Rickshaw',
    vehicleClass: 'Auto Rickshaw',
    driverName: 'Chloe Dubois',
    driverHandle: 'driver_chloe',
    driverAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    carModel: 'Bajaj RE Electric Urban Cab',
    carYear: '2025',
    plate: 'ZH-R88-402',
    rating: 4.92,
    etaMins: 3,
    mult: 3.3,
    ratePerMile: 4.2,
    color: 'Sovereign Emerald & Obsidian',
    seats: '3 Passengers · Weatherproof Canopy',
    specs: 'Zero-Emission Electric Three-Wheeler · USB Charging · Old-Town Priority Lane',
    media: [
      getCustomDriverVehicleFallbackPhoto('Auto Rickshaw', 'Bajaj RE Electric Urban Cab (2025)', 'ZH-R88-402'),
      DEFAULT_VEHICLE_MEDIA['drv-rick-1'].photos[1]
    ],
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].videos,
    available: true
  },
  {
    id: 'drv-marco',
    vehicleType: 'Motor Bike',
    vehicleClass: 'Moto Express',
    driverName: 'Marco Rossi',
    driverHandle: 'driver_marco',
    driverAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    carModel: 'Zero SR/F Express Edition',
    carYear: '2025',
    plate: 'ZH-M19-773',
    rating: 4.90,
    etaMins: 2,
    mult: 3.0,
    ratePerMile: 3.8,
    color: 'Matte Titanium & Slate',
    seats: '1 Pillion Passenger · Helmet Included',
    specs: 'Rapid Electric Moto · Spare ECE Helmet & Rain Shell · Express City Filter',
    media: [
      getCustomDriverVehicleFallbackPhoto('Motor Bike', 'Zero SR/F Express Edition (2025)', 'ZH-M19-773'),
      DEFAULT_VEHICLE_MEDIA['drv-moto-1'].photos[1]
    ],
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].videos,
    available: true
  }
];

const CLASS_META: Record<VehicleClassName, { vehicleType: VehicleTypeLabel; mult: number; defaultEta: number }> = {
  Economy: { vehicleType: 'Car', mult: 4.2, defaultEta: 3 },
  'Comfort EV': { vehicleType: 'Car', mult: 7.5, defaultEta: 2 },
  'Luxury Limousine': { vehicleType: 'Car', mult: 19.5, defaultEta: 5 },
  'Auto Rickshaw': { vehicleType: 'Auto Rickshaw', mult: 3.1, defaultEta: 2 },
  'Moto Express': { vehicleType: 'Motor Bike', mult: 2.8, defaultEta: 1 }
};

const VEHICLE_TYPE_SECTIONS: Array<{
  type: DriverVehicleType;
  label: VehicleTypeLabel;
  defaultClass: VehicleClassName;
  placeholderModel: string;
  placeholderPlate: string;
  defaultRate: number;
}> = [
  {
    type: 'car',
    label: 'Car',
    defaultClass: 'Comfort EV',
    placeholderModel: 'e.g. Tesla Model Y Sovereign',
    placeholderPlate: 'e.g. ZH-884-992',
    defaultRate: 6
  },
  {
    type: 'auto_rickshaw',
    label: 'Auto Rickshaw',
    defaultClass: 'Auto Rickshaw',
    placeholderModel: 'e.g. Bajaj RE Electric Rickshaw',
    placeholderPlate: 'e.g. ZH-R12-409',
    defaultRate: 4
  },
  {
    type: 'motor_bike',
    label: 'Motor Bike',
    defaultClass: 'Moto Express',
    placeholderModel: 'e.g. Zero SR/F Sovereign Bike',
    placeholderPlate: 'e.g. ZH-M44-901',
    defaultRate: 3.5
  }
];

export const RideShareView: React.FC<RideShareViewProps> = ({
  currentUser,
  onNavigateBack,
  backLabel,
  onViewUserProfile,
  onOpenVerificationModal,
  onOpenDirectMessage,
  onOpenVoiceCall,
  pendingDestination,
  onConsumePendingDestination,
}) => {
  const userId = currentUser?.id || currentUser?.uid || 'guest';
  const userName = currentUser?.name || 'Sovereign Explorer';

  const [directoryUsersCache, setDirectoryUsersCache] = useState<UserPublicProfile[]>([]);
  useEffect(() => {
    let active = true;
    const loadDir = async () => {
      try {
        const users = await getAllUsers(currentUser?.uid || currentUser?.id || '', { includeSelf: true });
        if (active && Array.isArray(users)) setDirectoryUsersCache(users);
      } catch {}
    };
    loadDir();
    window.addEventListener('storage', loadDir);
    window.addEventListener('focus', loadDir);
    return () => {
      active = false;
      window.removeEventListener('storage', loadDir);
      window.removeEventListener('focus', loadDir);
    };
  }, [currentUser?.uid, currentUser?.id]);

  const isAdminExempt = isAdminOrSuperAdminUser(currentUser);
  const userTier = getUserVerificationTier(currentUser);
  const canDriveWithoutTierBlock = isAdminExempt || userTier >= 2;
  const [driverTierErrorModal, setDriverTierErrorModal] = useState<{
    title: string;
    message: string;
  } | null>(null);

  // Main Top Tabs: 'book' | 'driver'
  const [activeTab, setActiveTab] = useState<'book' | 'driver'>('book');

  // Customer Book Rides sub-tabs: 'request' | 'in_person' | 'current' | 'history'
  const [bookSubTab, setBookSubTab] = useState<'request' | 'in_person' | 'current' | 'history'>('request');

  // Driver sub-tabs: 'ride_dispatches' | 'delivery_dispatches' | 'coupons' | 'profile'
  const [driverSubTab, setDriverSubTab] = useState<'ride_dispatches' | 'delivery_dispatches' | 'coupons' | 'profile'>('ride_dispatches');

  // Restore exact sub-tab & scroll spot when returning from Messaging / Voice Call / Profile
  useEffect(() => {
    if (pendingDestination?.address) return;
    const anchor = getProfileReturnAnchor();
    if (anchor && anchor.restoreActive && anchor.tab === 'ride_share') {
      if (anchor.rideShareTab === 'book' || anchor.rideShareTab === 'driver') {
        setActiveTab(anchor.rideShareTab);
        if (
          anchor.rideShareTab === 'book' &&
          (anchor.rideShareSubTab === 'request' ||
            anchor.rideShareSubTab === 'in_person' ||
            anchor.rideShareSubTab === 'current' ||
            anchor.rideShareSubTab === 'history')
        ) {
          setBookSubTab(anchor.rideShareSubTab);
        }
        if (
          anchor.rideShareTab === 'driver' &&
          (anchor.rideShareSubTab === 'ride_dispatches' ||
            anchor.rideShareSubTab === 'delivery_dispatches' ||
            anchor.rideShareSubTab === 'coupons' ||
            anchor.rideShareSubTab === 'profile')
        ) {
          setDriverSubTab(anchor.rideShareSubTab);
        }
      }
      const targetY = anchor.scrollY || 0;
      clearProfileReturnAnchor();
      setTimeout(() => {
        window.scrollTo({ top: targetY, behavior: 'instant' });
      }, 90);
    }
  }, [pendingDestination?.address]);

  // Ride-Share Coupons State (Online & In-Person)
  const [couponsVersion, setCouponsVersion] = useState(0);
  const [appliedRideCoupon, setAppliedRideCoupon] = useState<PlatformCoupon | null>(null);
  const [optedOutRideCouponVehicleId, setOptedOutRideCouponVehicleId] = useState<string | null>(null);
  const [rideCouponFeedback, setRideCouponFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [inPersonDriverHandle, setInPersonDriverHandle] = useState('@elena_vance');
  const [inPersonFareInput, setInPersonFareInput] = useState('25');
  const [inPersonCurrency, setInPersonCurrency] = useState('AFNL');
  const [inPersonTripNote, setInPersonTripNote] = useState('In-Person Street Hail Settlement');
  const [appliedInPersonRideCoupon, setAppliedInPersonRideCoupon] = useState<PlatformCoupon | null>(null);
  const [inPersonRideCouponFeedback, setInPersonRideCouponFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isPayingInPersonRide, setIsPayingInPersonRide] = useState(false);

  useEffect(() => {
    const syncCoupons = () => setCouponsVersion(v => v + 1);
    window.addEventListener(COUPONS_UPDATED_EVENT, syncCoupons);
    window.addEventListener('storage', syncCoupons);
    return () => {
      window.removeEventListener(COUPONS_UPDATED_EVENT, syncCoupons);
      window.removeEventListener('storage', syncCoupons);
    };
  }, []);

  useEffect(() => {
    const pending = peekPendingCheckoutCoupon('ride_share');
    if (!pending) return;
    const found = findCouponByCode(pending.code);
    if (!found) {
      clearPendingCheckoutCoupon();
      return;
    }
    setActiveTab('book');
    if (pending.channel === 'in_person') {
      setBookSubTab('in_person');
      setAppliedInPersonRideCoupon(found);
      setInPersonRideCouponFeedback({ type: 'success', text: `In-person ride coupon ${found.code} ready to apply!` });
    } else {
      setBookSubTab('request');
      setAppliedRideCoupon(found);
      setRideCouponFeedback({ type: 'success', text: `Ride coupon ${found.code} ready for online booking!` });
    }
    clearPendingCheckoutCoupon();
  }, []);

  // Driver Ride Dispatches nested sub-tabs: 'active_dispatches' | 'history'
  const [driverRideSubTab, setDriverRideSubTab] = useState<'active_dispatches' | 'history'>('active_dispatches');

  // Driver Delivery Dispatches nested sub-tabs: 'active_deliveries' | 'history'
  const [driverDeliverySubTab, setDriverDeliverySubTab] = useState<'active_deliveries' | 'history'>('active_deliveries');

  // Two tabs under Driver Delivery Active Dispatches: 'restaurant' | 'retail'
  const [activeDeliveryDispatchTab, setActiveDeliveryDispatchTab] = useState<'restaurant' | 'retail'>('restaurant');

  // Live User Wallet & Final List State (allows requesting rides with any 5 Final currencies in the user's Final list)
  const [userWallet, setUserWallet] = useState<UserWalletData>(() => getStoredUserWallets(userId));
  const [allCustomCoins, setAllCustomCoins] = useState<CustomCoin[]>(() => getStoredCustomCoins());

  useEffect(() => {
    const syncWalletAndCoins = () => {
      setUserWallet(getStoredUserWallets(userId));
      setAllCustomCoins(getStoredCustomCoins());
    };
    syncWalletAndCoins();
    window.addEventListener('final_finance_wallets_updated', syncWalletAndCoins);
    window.addEventListener('final_finance_custom_coins_updated', syncWalletAndCoins);
    window.addEventListener('storage', syncWalletAndCoins);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', syncWalletAndCoins);
      window.removeEventListener('final_finance_custom_coins_updated', syncWalletAndCoins);
      window.removeEventListener('storage', syncWalletAndCoins);
    };
  }, [userId]);

  const allPlatformCurrencies = React.useMemo(() => {
    const symbols = allCustomCoins.filter(c => c.coinType === 'final_coin').map(c => c.symbol);
    return Array.from(new Set([...symbols, ...DEFAULT_PLATFORM_CURRENCY_SYMBOLS]));
  }, [allCustomCoins]);

  // All Final Currencies the user holds in their Final list (created by them OR received/held from other issuers)
  const possessedFinalCoins = React.useMemo(() => {
    const seen: Record<
      string,
      { symbol: string; name: string; balance: number; isCreatedByUser: boolean; creatorName?: string }
    > = {};
    (userWallet.finalCoins || []).forEach(fc => {
      const sym = (fc.symbol || '').toUpperCase().trim();
      const bal = Number(fc.balance || 0);
      if (!sym || bal <= 0) return;
      const customMeta = allCustomCoins.find(
        c => c.coinType === 'final_coin' && c.symbol.toUpperCase() === sym
      );
      const isCreated = customMeta ? isFinalCoinCreatedByUser(customMeta, currentUser) : false;
      const existing = seen[sym];
      if (existing) {
        existing.balance += bal;
      } else {
        seen[sym] = {
          symbol: sym,
          name: customMeta?.name || fc.name || sym,
          balance: bal,
          isCreatedByUser: isCreated,
          creatorName: customMeta?.creatorName
        };
      }
    });
    return Object.values(seen);
  }, [userWallet, allCustomCoins, currentUser]);

  // Up to 5 Final Currencies selected from the user's Final Wallet for requesting rides
  const [rideRequestCurrencies, setRideRequestCurrencies] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_ride_request_currencies_${userId}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.map((s: string) => String(s).toUpperCase().trim()).filter(Boolean).slice(0, 5);
        }
      }
    } catch {}
    return [];
  });

  useEffect(() => {
    const ownedSymbols = possessedFinalCoins.map(c => c.symbol);
    if (ownedSymbols.length === 0) {
      if (rideRequestCurrencies.length > 0) {
        setRideRequestCurrencies([]);
      }
      return;
    }
    const validSelected = rideRequestCurrencies
      .filter(sym => ownedSymbols.includes(sym))
      .slice(0, 5);

    const next = validSelected.length > 0 ? validSelected : ownedSymbols.slice(0, 5);

    const changed =
      next.length !== rideRequestCurrencies.length ||
      next.some((sym, idx) => sym !== rideRequestCurrencies[idx]);

    if (changed) {
      setRideRequestCurrencies(next);
      try {
        localStorage.setItem(`final_finance_ride_request_currencies_${userId}`, JSON.stringify(next));
      } catch {}
    }
  }, [possessedFinalCoins, rideRequestCurrencies, userId]);

  const activeRideFinalCoins = React.useMemo(() => {
    if (rideRequestCurrencies.length === 0) return possessedFinalCoins.slice(0, 5);
    const activeSet = new Set(rideRequestCurrencies.map(s => s.toUpperCase()));
    const matched = possessedFinalCoins.filter(c => activeSet.has(c.symbol.toUpperCase()));
    return matched.length > 0 ? matched.slice(0, 5) : possessedFinalCoins.slice(0, 5);
  }, [possessedFinalCoins, rideRequestCurrencies]);

  // Primary display currency derived from the customer's selected Final Wallet currencies (up to 5)
  const [selectedCurrency, setSelectedCurrency] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_customer_selected_currency_${userId}`);
      if (saved) return saved;
    } catch {}
    return 'AFNL';
  });
  const [customerCurrencySearch, setCustomerCurrencySearch] = useState('');
  const [walletErrorMsg, setWalletErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const activeSymbols = activeRideFinalCoins.map(c => c.symbol);
    if (activeSymbols.length === 0) return;
    if (!activeSymbols.includes(selectedCurrency.toUpperCase())) {
      const next = activeSymbols[0];
      setSelectedCurrency(next);
      try {
        localStorage.setItem(`final_finance_customer_selected_currency_${userId}`, next);
      } catch {}
    }
  }, [activeRideFinalCoins, selectedCurrency, userId]);

  const handleToggleRideCurrencySlot = (symbol: string) => {
    const upper = symbol.toUpperCase().trim();
    setWalletErrorMsg(null);
    const isIncluded = rideRequestCurrencies.includes(upper);
    let next = rideRequestCurrencies;
    if (isIncluded) {
      if (rideRequestCurrencies.length <= 1) return;
      next = rideRequestCurrencies.filter(s => s !== upper);
    } else if (rideRequestCurrencies.length < 5) {
      next = [...rideRequestCurrencies, upper];
    } else {
      return;
    }
    setRideRequestCurrencies(next);
    try {
      localStorage.setItem(`final_finance_ride_request_currencies_${userId}`, JSON.stringify(next));
    } catch {}
    if (!isIncluded) {
      setSelectedCurrency(upper);
      try {
        localStorage.setItem(`final_finance_customer_selected_currency_${userId}`, upper);
      } catch {}
    } else if (selectedCurrency.toUpperCase() === upper && next.length > 0) {
      setSelectedCurrency(next[0]);
      try {
        localStorage.setItem(`final_finance_customer_selected_currency_${userId}`, next[0]);
      } catch {}
    }
  };

  // Book Rides State
  const [pickupLocation, setPickupLocation] = useState('Zurich Freeport Terminal 4B, 8048 Zürich');
  const [dropoffLocation, setDropoffLocation] = useState('Bahnhofstrasse Luxury Financial District, 8001 Zürich');
  const [pickupSuggestionsOpen, setPickupSuggestionsOpen] = useState(false);
  const [dropoffSuggestionsOpen, setDropoffSuggestionsOpen] = useState(false);
  const [pickupHighlightIdx, setPickupHighlightIdx] = useState(-1);
  const [dropoffHighlightIdx, setDropoffHighlightIdx] = useState(-1);
  const pickupBoxRef = React.useRef<HTMLDivElement | null>(null);
  const dropoffBoxRef = React.useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!pendingDestination?.address) return;
    const formatted = pendingDestination.label
      ? `${pendingDestination.label}, ${pendingDestination.address}`
      : pendingDestination.address;
    setActiveTab('book');
    setBookSubTab('request');
    setDropoffLocation(formatted);
    setDropoffSuggestionsOpen(false);
    setDropoffHighlightIdx(-1);
    onConsumePendingDestination?.();
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [pendingDestination?.requestedAt]);
  const [selectedVehicleType, setSelectedVehicleType] = useState<'All' | VehicleTypeLabel>('All');
  const [selectedClass, setSelectedClass] = useState<VehicleClassName>('Comfort EV');
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('drv-ev-1');
  const [expandedVehicleId, setExpandedVehicleId] = useState<string | null>(null);
  
  const [myRides, setMyRides] = useState<RideRequest[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_my_rides_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'ride-demo-407732',
        riderId: userId,
        riderName: userName,
        pickup: 'Zurich Freeport Terminal 4B, 8048 Zürich',
        dropoff: 'Bahnhofstrasse Luxury Financial District, 8001 Zürich',
        vehicleClass: 'Comfort EV',
        fare: 32,
        currency: 'AFNL',
        status: 'driver_assigned',
        driverId: 'driver-hans',
        driverName: 'Hansruedi Keller',
        driverHandle: 'driver-hans',
        driverAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        driverCar: 'Tesla Model Y Long Range (White)',
        driverRating: 4.96,
        createdAt: new Date().toISOString(),
        estimatedTime: '~14 mins',
        distance: '4.2 miles',
        directions: [
          'Depart from pickup: Zurich Freeport Terminal 4B (0.3 mi)',
          'Merge onto main Sovereign Transit Corridor toward financial district (2.8 mi)',
          'Arrive at destination: Bahnhofstrasse Luxury Financial District'
        ]
      },
      {
        id: 'ride-demo-407510',
        riderId: userId,
        riderName: userName,
        pickup: 'Geneva Cornavin Station, 1201 Genève',
        dropoff: 'Rue du Rhône Private Banking Mile, 1204 Genève',
        vehicleClass: 'Comfort EV',
        fare: 28,
        currency: 'AFNL',
        status: 'completed',
        driverId: 'drv-ev-1',
        driverName: 'Elena Vance',
        driverHandle: 'elena_vance',
        driverAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
        driverCar: 'Polestar 2 Long Range (2025)',
        driverPlate: 'ZH-618-334',
        driverRating: 4.97,
        rating: 5,
        comment: 'Smooth silent electric ride and punctual arrival.',
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        estimatedTime: '~12 mins',
        distance: '3.6 miles',
        directions: [
          'Depart from pickup: Geneva Cornavin Station',
          'Cross Pont du Mont-Blanc toward Rue du Rhône',
          'Arrive at destination: Rue du Rhône Private Banking Mile'
        ]
      }
    ];
  });
  const [isBookingRide, setIsBookingRide] = useState(false);
  const [customerNavStepIdx, setCustomerNavStepIdx] = useState<number>(1);
  const [isAutoNavigatingCustomer, setIsAutoNavigatingCustomer] = useState<boolean>(true);
  const [driverRideStepIdx, setDriverRideStepIdx] = useState<number>(0);
  const [driverDeliveryStepIdx, setDriverDeliveryStepIdx] = useState<number>(0);
  const [isAutoGpsDriverRide, setIsAutoGpsDriverRide] = useState<boolean>(true);
  const [isAutoGpsDriverDelivery, setIsAutoGpsDriverDelivery] = useState<boolean>(true);
  const [voiceGpsEnabled, setVoiceGpsEnabled] = useState<boolean>(true);
  const [focusedDeliveryId, setFocusedDeliveryId] = useState<string | null>(null);
  const [proofModalContractId, setProofModalContractId] = useState<string | null>(null);
  const [deliveryProofPhotos, setDeliveryProofPhotos] = useState<string[]>([]);
  const [deliveryProofVideos, setDeliveryProofVideos] = useState<string[]>([]);

  // Cancellation modal state / warning state
  const [showCancelWarningModal, setShowCancelWarningModal] = useState(false);
  const [pendingCancelRideId, setPendingCancelRideId] = useState<string | null>(null);

  // Blocked Users State (checked from localStorage)
  const [blockedUsers] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_blocked_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  const isSelfDriver = (driverId?: string, driverHandle?: string): boolean => {
    const cleanHandle = (driverHandle || '').trim().replace(/^@/, '').toLowerCase();
    const cleanId = (driverId || '').trim().toLowerCase();
    const myIds = new Set(
      [
        userId,
        currentUser?.id,
        currentUser?.uid,
        currentUser?.handle?.replace(/^@/, ''),
      ]
        .filter(Boolean)
        .map((s) => String(s).trim().toLowerCase())
    );
    return (Boolean(cleanId) && myIds.has(cleanId)) || (Boolean(cleanHandle) && myIds.has(cleanHandle));
  };

  const resolveDriverFromCache = (driverId?: string, driverHandle?: string): UserPublicProfile | undefined => {
    const cleanHandle = (driverHandle || '').trim().replace(/^@/, '').toLowerCase();
    const cleanId = (driverId || '').trim().toLowerCase();
    return directoryUsersCache.find((u) => {
      const uidLower = (u.uid || '').toLowerCase();
      const userIdLower = (u.userId || '').toLowerCase();
      return (
        (cleanId && (uidLower === cleanId || userIdLower === cleanId)) ||
        (cleanHandle && (userIdLower === cleanHandle || uidLower === cleanHandle))
      );
    });
  };

  const isDriverCommunicationBlocked = (driverId?: string, driverHandle?: string): boolean => {
    const cleanHandle = (driverHandle || '').trim().replace(/^@/, '');
    const cleanId = (driverId || '').trim();
    const viewerIds = Array.from(
      new Set(
        [
          currentUser?.uid,
          currentUser?.id,
          currentUser?.handle?.replace(/^@/, ''),
          userId !== 'guest' ? userId : '',
        ]
          .filter(Boolean)
          .map((s) => String(s).trim())
      )
    );
    if (viewerIds.length === 0) return false;
    const matched = resolveDriverFromCache(cleanId, cleanHandle);
    const driverIds = Array.from(
      new Set(
        [cleanId, cleanHandle, matched?.uid, matched?.userId]
          .filter(Boolean)
          .map((s) => String(s).trim())
      )
    );
    for (const dId of driverIds) {
      if (blockedUsers.some((b) => b.toLowerCase() === dId.toLowerCase())) return true;
      for (const vId of viewerIds) {
        if (areUsersBlockedEitherWay(vId, dId)) return true;
      }
    }
    return false;
  };

  const resolveDriverProfileAsync = async (driver: {
    id?: string;
    handle?: string;
    name?: string;
    avatar?: string;
    carModel?: string;
  }): Promise<UserPublicProfile> => {
    const cleanHandle = (driver.handle || driver.id || '').trim().replace(/^@/, '');
    const cleanId = (driver.id || '').trim();
    const displayName = (driver.name || cleanHandle || 'Platform Driver').trim();
    registerDriverProfile({
      id: cleanId || cleanHandle || `drv-${displayName.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      driverHandle: cleanHandle || cleanId,
      driverName: displayName,
      driverAvatar: driver.avatar,
      carModel: driver.carModel,
    });
    let matched = resolveDriverFromCache(cleanId, cleanHandle);
    if (!matched) {
      try {
        const users = await getAllUsers(currentUser?.uid || currentUser?.id || '', { includeSelf: true });
        matched = users.find((u) => {
          const uidLower = (u.uid || '').toLowerCase();
          const userIdLower = (u.userId || '').toLowerCase();
          return (
            (cleanId && (uidLower === cleanId.toLowerCase() || userIdLower === cleanId.toLowerCase())) ||
            (cleanHandle && (userIdLower === cleanHandle.toLowerCase() || uidLower === cleanHandle.toLowerCase()))
          );
        });
      } catch {}
    }
    return (
      matched || {
        uid: cleanId || `drv-${cleanHandle || 'driver'}`,
        userId: cleanHandle || cleanId || 'driver',
        name: displayName,
        role: 'user',
        bio: driver.carModel ? `Ride-Share Driver · ${driver.carModel}` : 'Verified Ride-Share Driver',
        avatarUrl:
          driver.avatar ||
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      }
    );
  };

  const handleMessageDriver = async (driver: {
    id?: string;
    handle?: string;
    name?: string;
    avatar?: string;
    carModel?: string;
  }) => {
    if (isDriverCommunicationBlocked(driver.id, driver.handle)) {
      dispatchGlobalNotification({
        title: 'Messaging Blocked',
        description: `You cannot message ${driver.name || 'this driver'} because you or the driver has blocked the other.`,
        type: 'security',
        targetTab: 'rideshare',
        showToast: true,
        tone: 'alert',
      });
      return;
    }
    if (!onOpenDirectMessage) {
      dispatchGlobalNotification({
        title: 'Messaging Unavailable',
        description: 'Direct messaging is unavailable in this view.',
        type: 'ride',
        targetTab: 'messages',
        showToast: true,
        tone: 'alert',
      });
      return;
    }
    const targetProfile = await resolveDriverProfileAsync(driver);
    if (
      areUsersBlockedEitherWay(currentUser?.uid || currentUser?.id || '', targetProfile.uid) ||
      areUsersBlockedEitherWay(currentUser?.uid || currentUser?.id || '', targetProfile.userId)
    ) {
      dispatchGlobalNotification({
        title: 'Messaging Blocked',
        description: `You cannot message ${targetProfile.name} because you or the driver has blocked the other.`,
        type: 'security',
        targetTab: 'rideshare',
        showToast: true,
        tone: 'alert',
      });
      return;
    }
    setPageReturnAnchor('messages', {
      tab: 'ride_share',
      sourceLabel: 'Back to Ride-Share',
      scrollY: typeof window !== 'undefined' ? window.scrollY : 0,
      rideShareTab: activeTab,
      rideShareSubTab: activeTab === 'book' ? bookSubTab : driverSubTab,
    });
    onOpenDirectMessage(targetProfile);
  };

  const handleVoiceCallDriver = async (driver: {
    id?: string;
    handle?: string;
    name?: string;
    avatar?: string;
    carModel?: string;
  }) => {
    if (isDriverCommunicationBlocked(driver.id, driver.handle)) {
      dispatchGlobalNotification({
        title: 'Voice Call Blocked',
        description: `You cannot call ${driver.name || 'this driver'} because you or the driver has blocked the other.`,
        type: 'security',
        targetTab: 'rideshare',
        showToast: true,
        tone: 'alert',
      });
      return;
    }
    if (!onOpenVoiceCall) {
      dispatchGlobalNotification({
        title: 'Voice Call Unavailable',
        description: 'Voice calling is unavailable in this view.',
        type: 'ride',
        targetTab: 'rideshare',
        showToast: true,
        tone: 'alert',
      });
      return;
    }
    const targetProfile = await resolveDriverProfileAsync(driver);
    if (
      areUsersBlockedEitherWay(currentUser?.uid || currentUser?.id || '', targetProfile.uid) ||
      areUsersBlockedEitherWay(currentUser?.uid || currentUser?.id || '', targetProfile.userId)
    ) {
      dispatchGlobalNotification({
        title: 'Voice Call Blocked',
        description: `You cannot call ${targetProfile.name} because you or the driver has blocked the other.`,
        type: 'security',
        targetTab: 'rideshare',
        showToast: true,
        tone: 'alert',
      });
      return;
    }
    setPageReturnAnchor('call', {
      tab: 'ride_share',
      sourceLabel: 'Back to Ride-Share',
      scrollY: typeof window !== 'undefined' ? window.scrollY : 0,
      rideShareTab: activeTab,
      rideShareSubTab: activeTab === 'book' ? bookSubTab : driverSubTab,
    });
    onOpenVoiceCall(
      {
        uid: targetProfile.uid,
        userId: targetProfile.userId,
        name: `${targetProfile.name} (Driver)`,
        avatarUrl: targetProfile.avatarUrl || driver.avatar,
      },
      false,
      undefined,
      { allowNonFriend: true, voiceOnly: true }
    );
  };

  // Driver Config State
  const [currencySearchQuery, setCurrencySearchQuery] = useState('');
  const [driverCurrencies, setDriverCurrencies] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_driver_currencies_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return ['AFNL', 'FNL-TECH', 'FNL-GOLD', 'FNL-USD', 'FNL-EURO'];
  });
  const [ratePerMile, setRatePerMile] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_driver_rate_${userId}`);
      if (saved) {
        const parsed = parseFloat(saved);
        if (Number.isFinite(parsed) && parsed > 0) return parsed;
      }
    } catch {}
    return 6;
  });
  const [foodDeliveryRatePerMile, setFoodDeliveryRatePerMile] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_driver_food_delivery_rate_${userId}`);
      if (saved) {
        const parsed = parseFloat(saved);
        if (Number.isFinite(parsed) && parsed > 0) return parsed;
      }
      const fallback =
        localStorage.getItem(`final_finance_driver_delivery_rate_${userId}`) ||
        localStorage.getItem(`final_finance_driver_rate_${userId}`);
      if (fallback) {
        const parsedFallback = parseFloat(fallback);
        if (Number.isFinite(parsedFallback) && parsedFallback > 0) return parsedFallback;
      }
    } catch {}
    return 6;
  });
  const [retailDeliveryRatePerMile, setRetailDeliveryRatePerMile] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_driver_retail_delivery_rate_${userId}`);
      if (saved) {
        const parsed = parseFloat(saved);
        if (Number.isFinite(parsed) && parsed > 0) return parsed;
      }
      const fallback =
        localStorage.getItem(`final_finance_driver_delivery_rate_${userId}`) ||
        localStorage.getItem(`final_finance_driver_rate_${userId}`);
      if (fallback) {
        const parsedFallback = parseFloat(fallback);
        if (Number.isFinite(parsedFallback) && parsedFallback > 0) return parsedFallback;
      }
    } catch {}
    return 6;
  });

  const updateCivilianRatePerMile = (nextRate: number) => {
    const clean = Number.isFinite(nextRate) ? Math.max(0.5, Math.min(100, nextRate)) : 6;
    setRatePerMile(clean);
    try {
      localStorage.setItem(`final_finance_driver_rate_${userId}`, clean.toString());
    } catch {}
  };

  const updateFoodDeliveryRatePerMile = (nextRate: number) => {
    const clean = Number.isFinite(nextRate) ? Math.max(0.5, Math.min(100, nextRate)) : 6;
    setFoodDeliveryRatePerMile(clean);
    try {
      localStorage.setItem(`final_finance_driver_food_delivery_rate_${userId}`, clean.toString());
    } catch {}
  };

  const updateRetailDeliveryRatePerMile = (nextRate: number) => {
    const clean = Number.isFinite(nextRate) ? Math.max(0.5, Math.min(100, nextRate)) : 6;
    setRetailDeliveryRatePerMile(clean);
    try {
      localStorage.setItem(`final_finance_driver_retail_delivery_rate_${userId}`, clean.toString());
    } catch {}
  };

  const getDeliveryRateForBusiness = (businessType: 'retail' | 'restaurant') =>
    businessType === 'retail' ? retailDeliveryRatePerMile : foodDeliveryRatePerMile;

  // 3 separate vehicle slots: Car, Auto Rickshaw, Motor Bike (strictly max 1 per vehicle type)
  const [driverVehicles, setDriverVehicles] = useState<Record<DriverVehicleType, DriverVehicleSlot | null>>(() => {
    try {
      const savedSlots = localStorage.getItem(`final_finance_driver_vehicles_${userId}`);
      if (savedSlots) {
        const parsed = JSON.parse(savedSlots);
        return {
          car: parsed.car || null,
          auto_rickshaw: parsed.auto_rickshaw || null,
          motor_bike: parsed.motor_bike || null
        };
      }
      // Migrate legacy single-vehicle registration into the Car / appropriate slot
      if (localStorage.getItem(`final_finance_is_driver_${userId}`) === 'true') {
        const legacyMake = localStorage.getItem(`final_finance_driver_carmake_${userId}`) || 'Tesla Model Y Sovereign';
        const legacyYear = localStorage.getItem(`final_finance_driver_caryear_${userId}`) || '2025';
        const legacyPlate = localStorage.getItem(`final_finance_driver_plate_${userId}`) || 'ZH-884-992';
        const legacyRate = parseFloat(localStorage.getItem(`final_finance_driver_rate_${userId}`) || '6') || 6;
        const legacyClassRaw = localStorage.getItem(`final_finance_driver_carclass_${userId}`) || 'Comfort EV';
        const isMoto = legacyClassRaw === 'Moto Express';
        const slotType: DriverVehicleType = isMoto ? 'motor_bike' : 'car';
        const vClass: VehicleClassName = isMoto
          ? 'Moto Express'
          : (legacyClassRaw === 'Economy' || legacyClassRaw === 'Luxury Limousine' ? legacyClassRaw : 'Comfort EV');
        return {
          car: slotType === 'car'
            ? {
                vehicleType: 'car',
                vehicleTypeLabel: 'Car',
                vehicleClass: vClass,
                makeModel: legacyMake,
                year: legacyYear,
                plate: legacyPlate,
                licenseId: 'CH-LIC-99214',
                ratePerMile: legacyRate,
                insuranceInfo: 'Zurich Sovereign Commercial Fleet Policy #CH-INS-88491',
                online: true,
                media: [],
                registeredAt: new Date().toISOString()
              }
            : null,
          auto_rickshaw: null,
          motor_bike: slotType === 'motor_bike'
            ? {
                vehicleType: 'motor_bike',
                vehicleTypeLabel: 'Motor Bike',
                vehicleClass: 'Moto Express',
                makeModel: legacyMake,
                year: legacyYear,
                plate: legacyPlate,
                licenseId: 'CH-LIC-99214',
                ratePerMile: legacyRate,
                insuranceInfo: 'Zurich Sovereign Commercial Fleet Policy #CH-INS-88491',
                online: true,
                media: [],
                registeredAt: new Date().toISOString()
              }
            : null
        };
      }
    } catch {}
    return { car: null, auto_rickshaw: null, motor_bike: null };
  });

  const [driverDrafts, setDriverDrafts] = useState<Record<DriverVehicleType, DriverVehicleDraft>>({
    car: {
      makeModel: 'Tesla Model Y Sovereign',
      vehicleClass: 'Comfort EV',
      year: '2025',
      plate: 'ZH-884-992',
      licenseId: 'CH-LIC-99214',
      ratePerMile: 6,
      foodDeliveryRatePerMile: 6,
      retailDeliveryRatePerMile: 6,
      insuranceInfo: 'Zurich Sovereign Commercial Fleet Policy #CH-INS-88491',
      media: [],
      videoMedia: []
    },
    auto_rickshaw: {
      makeModel: 'Bajaj RE Electric Three-Wheeler',
      vehicleClass: 'Auto Rickshaw',
      year: '2025',
      plate: 'ZH-R12-409',
      licenseId: 'CH-LIC-99214',
      ratePerMile: 4,
      foodDeliveryRatePerMile: 4,
      retailDeliveryRatePerMile: 4,
      insuranceInfo: 'Zurich Light Transit Commercial Policy #CH-RIC-31092',
      media: [],
      videoMedia: []
    },
    motor_bike: {
      makeModel: 'Zero SR/F Sovereign Bike',
      vehicleClass: 'Moto Express',
      year: '2025',
      plate: 'ZH-M44-901',
      licenseId: 'CH-LIC-99214',
      ratePerMile: 3.5,
      foodDeliveryRatePerMile: 3.5,
      retailDeliveryRatePerMile: 3.5,
      insuranceInfo: 'Zurich Express Courier & Rider Policy #CH-MOT-77318',
      media: [],
      videoMedia: []
    }
  });

  const [editingVehicleType, setEditingVehicleType] = useState<DriverVehicleType | null>(null);
  const [editTargetVehicleType, setEditTargetVehicleType] = useState<DriverVehicleType>('car');
  const [editVehicleDraft, setEditVehicleDraft] = useState<DriverVehicleDraft | null>(null);
  const [syncDriverInfoAcrossFleet, setSyncDriverInfoAcrossFleet] = useState(false);

  const [driverEarnings, setDriverEarnings] = useState(1420);
  const [activeDriverPayoutCoin, setActiveDriverPayoutCoin] = useState<string>(() => driverCurrencies[0] || 'AFNL');

  useEffect(() => {
    if (!driverCurrencies.includes(activeDriverPayoutCoin) && driverCurrencies.length > 0) {
      setActiveDriverPayoutCoin(driverCurrencies[0]);
    }
  }, [driverCurrencies, activeDriverPayoutCoin]);

  useEffect(() => {
    const handleOutsideClick = (ev: MouseEvent) => {
      if (pickupBoxRef.current && !pickupBoxRef.current.contains(ev.target as Node)) {
        setPickupSuggestionsOpen(false);
      }
      if (dropoffBoxRef.current && !dropoffBoxRef.current.contains(ev.target as Node)) {
        setDropoffSuggestionsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Back button state preservation via hash
  useEffect(() => {
    try {
      window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
    } catch {}
  }, [activeTab, bookSubTab]);

  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash.includes('subtab=in_person')) setBookSubTab('in_person');
      else if (hash.includes('subtab=current')) setBookSubTab('current');
      else if (hash.includes('subtab=history')) setBookSubTab('history');
      else if (hash.includes('subtab=request')) setBookSubTab('request');
      if (hash.includes('tab=driver')) setActiveTab('driver');
      else if (hash.includes('tab=book')) setActiveTab('book');
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Delivery Partner Marketplace State
  const [deliveryContracts, setDeliveryContracts] = useState<DeliveryContract[]>(() => {
    const seededMockContractIds = new Set(['del-1', 'del-2', 'del-3']);
    const isRanmaOwner =
      currentUser?.email?.trim().toLowerCase() === 'ranmaanimaker@gmail.com' ||
      (currentUser?.id || '').toLowerCase() === 'super_admin_ranma' ||
      (currentUser?.handle || '').replace(/^@/, '').toLowerCase() === 'super_admin_ranma';
    const filterContract = (c: DeliveryContract): boolean => {
      if (!c) return false;
      if (seededMockContractIds.has(c.id)) {
        return isRanmaOwner && c.id === 'del-2';
      }
      if (MOCK_MERCHANT_LOC_IDS.has(c.merchantId)) {
        return isRanmaOwner && (c.merchantId === 'loc-rest-1' || c.merchantId === 'loc-retail-3');
      }
      return true;
    };
    try {
      const saved = localStorage.getItem('final_finance_delivery_contracts');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const cleaned = parsed.filter(filterContract);
          if (!localStorage.getItem('ff_rideshare_contracts_v2_cleaned')) {
            localStorage.setItem('ff_rideshare_contracts_v2_cleaned', '1');
            localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(cleaned));
          }
          return cleaned;
        }
      }
      localStorage.setItem('ff_rideshare_contracts_v2_cleaned', '1');
      localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(SAMPLE_MERCHANT_ORDERS));
    } catch {}
    return SAMPLE_MERCHANT_ORDERS;
  });

  const [driverDeliveryNotifications, setDriverDeliveryNotifications] = useState<DriverDeliveryNotification[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_driver_delivery_notifications');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  useEffect(() => {
    const syncDeliveryState = () => {
      try {
        const savedContracts = localStorage.getItem('final_finance_delivery_contracts');
        if (savedContracts) {
          const parsed = JSON.parse(savedContracts);
          if (Array.isArray(parsed)) setDeliveryContracts(parsed);
        }
      } catch {}
      try {
        const savedNotifs = localStorage.getItem('final_finance_driver_delivery_notifications');
        if (savedNotifs) {
          const parsed = JSON.parse(savedNotifs);
          if (Array.isArray(parsed)) setDriverDeliveryNotifications(parsed);
        }
      } catch {}
    };
    window.addEventListener('final_finance_delivery_contracts_updated', syncDeliveryState);
    window.addEventListener('storage', syncDeliveryState);
    return () => {
      window.removeEventListener('final_finance_delivery_contracts_updated', syncDeliveryState);
      window.removeEventListener('storage', syncDeliveryState);
    };
  }, []);

  // Rating & Review state
  const [ratingModalRideId, setRatingModalRideId] = useState<string | null>(null);
  const [ratingModalDeliveryId, setRatingModalDeliveryId] = useState<string | null>(null);
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewComment, setReviewComment] = useState<string>('');

  // Countdown timer ticker for 2-minute cancellation window
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const saveMyRides = (rides: RideRequest[]) => {
    setMyRides(rides);
    try {
      localStorage.setItem(`final_finance_my_rides_${userId}`, JSON.stringify(rides));
      window.dispatchEvent(new CustomEvent('final_finance_my_rides_updated'));
    } catch {}
  };

  const saveDeliveryContracts = (contracts: DeliveryContract[]) => {
    setDeliveryContracts(contracts);
    try {
      localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(contracts));
    } catch {}
  };

  const previewRoute = React.useMemo(
    () => buildTurnByTurnRoute(pickupLocation, dropoffLocation, 'customer_ride'),
    [pickupLocation, dropoffLocation]
  );

  const recentAddressList = React.useMemo(
    () => Array.from(new Set(myRides.flatMap(r => [r.pickup, r.dropoff]).filter(Boolean))),
    [myRides]
  );

  const pickupSuggestions = React.useMemo(
    () => getAddressSuggestions(pickupLocation, recentAddressList),
    [pickupLocation, recentAddressList]
  );

  const dropoffSuggestions = React.useMemo(
    () => getAddressSuggestions(dropoffLocation, recentAddressList),
    [dropoffLocation, recentAddressList]
  );

  // Available Vehicles Pool across Car, Auto Rickshaw, and Motor Bike (only show available vehicles)
  const availableVehiclePool = React.useMemo(() => {
    const busyDriverIds = new Set(
      myRides
        .filter(r => r.status === 'driver_assigned' || r.status === 'in_transit')
        .map(r => r.driverId)
        .filter(Boolean)
    );
    const basePool = DEFAULT_SECTOR_VEHICLES.filter(v => v.available && !busyDriverIds.has(v.id));

    (['car', 'auto_rickshaw', 'motor_bike'] as DriverVehicleType[]).forEach(vType => {
      const slot = driverVehicles[vType];
      const slotDriverId = `${userId}:${vType}`;
      if (slot && slot.online && !busyDriverIds.has(slotDriverId) && !busyDriverIds.has(userId)) {
        basePool.unshift({
          id: slotDriverId,
          vehicleType: slot.vehicleTypeLabel,
          vehicleClass: slot.vehicleClass,
          driverName: userName,
          carModel: slot.makeModel,
          carYear: slot.year,
          plate: slot.plate,
          rating: 4.98,
          etaMins: CLASS_META[slot.vehicleClass]?.defaultEta ?? 2,
          mult: CLASS_META[slot.vehicleClass]?.mult ?? 6,
          ratePerMile: slot.ratePerMile,
          color: 'Registered Fleet Finish',
          seats:
            slot.vehicleTypeLabel === 'Motor Bike'
              ? '1 Passenger · Helmet Provided'
              : slot.vehicleTypeLabel === 'Auto Rickshaw'
                ? '3 Passengers · Covered Cabin'
                : '4 Passengers · Climate Control',
          specs: `${slot.makeModel} (${slot.year}) · ${slot.vehicleClass}`,
          media:
            slot.media && slot.media.length > 0
              ? slot.media
              : [getCustomDriverVehicleFallbackPhoto(slot.vehicleTypeLabel, slot.makeModel, slot.plate)],
          videoMedia: slot.videoMedia && slot.videoMedia.length > 0 ? slot.videoMedia : [],
          available: true
        });
      }
    });
    return basePool;
  }, [myRides, driverVehicles, userId, userName]);

  const availableVehicleTypes = React.useMemo(() => {
    const typeOrder: VehicleTypeLabel[] = ['Car', 'Auto Rickshaw', 'Motor Bike'];
    return typeOrder.filter(t => availableVehiclePool.some(v => v.vehicleType === t));
  }, [availableVehiclePool]);

  useEffect(() => {
    if (selectedVehicleType !== 'All' && !availableVehicleTypes.includes(selectedVehicleType)) {
      setSelectedVehicleType('All');
    }
  }, [availableVehicleTypes, selectedVehicleType]);

  const filteredAvailableVehicles = React.useMemo(
    () =>
      availableVehiclePool.filter(
        v => selectedVehicleType === 'All' || v.vehicleType === selectedVehicleType
      ),
    [availableVehiclePool, selectedVehicleType]
  );

  const availableVehicleClasses = React.useMemo(() => {
    const ordered: VehicleClassName[] = [
      'Economy',
      'Comfort EV',
      'Luxury Limousine',
      'Auto Rickshaw',
      'Moto Express'
    ];
    return ordered
      .map(cls => {
        const cars = filteredAvailableVehicles.filter(v => v.vehicleClass === cls);
        if (cars.length === 0) return null;
        const primary = cars[0];
        return {
          title: cls,
          vehicleType: CLASS_META[cls].vehicleType,
          cars,
          primaryCar: primary,
          mult: CLASS_META[cls].mult,
          time: `${primary.etaMins} min`
        };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null);
  }, [filteredAvailableVehicles]);

  const selectedVehicle = React.useMemo(
    () =>
      filteredAvailableVehicles.find(v => v.id === selectedVehicleId) ||
      filteredAvailableVehicles.find(v => v.vehicleClass === selectedClass) ||
      filteredAvailableVehicles[0] ||
      null,
    [filteredAvailableVehicles, selectedVehicleId, selectedClass]
  );

  useEffect(() => {
    if (selectedVehicle && selectedVehicle.id !== selectedVehicleId) {
      setSelectedVehicleId(selectedVehicle.id);
    }
    if (selectedVehicle && selectedVehicle.vehicleClass !== selectedClass) {
      setSelectedClass(selectedVehicle.vehicleClass);
    }
  }, [selectedVehicle, selectedVehicleId, selectedClass]);

  const currentEstimatedFare = React.useMemo(() => {
    const mult = selectedVehicle?.mult ?? CLASS_META[selectedClass]?.mult ?? 7.5;
    return Math.round(Math.max(8, previewRoute.distanceMiles * mult * (ratePerMile / 6)) * 10) / 10;
  }, [selectedVehicle, selectedClass, previewRoute.distanceMiles, ratePerMile]);

  // Auto-detect saved coupons belonging to the selected driver and automatically apply the best valid 1 coupon at a time
  useEffect(() => {
    if (!selectedVehicle) {
      if (appliedRideCoupon) setAppliedRideCoupon(null);
      return;
    }
    const vDriverHandle = `@${selectedVehicle.driverName.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
    const applicable = getApplicableSavedCoupons(userId, {
      category: 'ride_share',
      channel: 'online',
      subtotal: currentEstimatedFare,
      driverId: selectedVehicle.id,
      driverName: selectedVehicle.driverName,
      driverHandle: vDriverHandle,
    });

    const validDriverSpecific = applicable
      .filter((item) => item.evaluation.valid && item.isMerchantOrDriverSpecific)
      .sort((a, b) => b.evaluation.discountAmount - a.evaluation.discountAmount);

    if (appliedRideCoupon) {
      const currentEval = evaluateCouponForOrder(appliedRideCoupon, {
        category: 'ride_share',
        channel: 'online',
        subtotal: currentEstimatedFare,
        driverId: selectedVehicle.id,
        driverName: selectedVehicle.driverName,
        driverHandle: vDriverHandle,
      });
      if (!currentEval.valid) {
        if (optedOutRideCouponVehicleId !== selectedVehicle.id && validDriverSpecific.length > 0) {
          const best = validDriverSpecific[0];
          setAppliedRideCoupon(best.coupon);
          setRideCouponFeedback({
            type: 'success',
            text: `Auto-applied ${selectedVehicle.driverName}'s coupon ${best.coupon.code} (-${best.evaluation.discountAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${selectedCurrency})`,
          });
        } else {
          setAppliedRideCoupon(null);
          setRideCouponFeedback(null);
        }
      }
      return;
    }

    if (optedOutRideCouponVehicleId !== selectedVehicle.id && validDriverSpecific.length > 0) {
      const best = validDriverSpecific[0];
      setAppliedRideCoupon(best.coupon);
      setRideCouponFeedback({
        type: 'success',
        text: `Auto-applied ${selectedVehicle.driverName}'s coupon ${best.coupon.code} (-${best.evaluation.discountAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${selectedCurrency})`,
      });
    }
  }, [
    selectedVehicle,
    currentEstimatedFare,
    userId,
    couponsVersion,
    optedOutRideCouponVehicleId,
    appliedRideCoupon,
    selectedCurrency,
  ]);

  const rideCouponEvaluation = React.useMemo(() => {
    if (!appliedRideCoupon) return null;
    return evaluateCouponForOrder(appliedRideCoupon, {
      category: 'ride_share',
      channel: 'online',
      subtotal: currentEstimatedFare,
      driverId: selectedVehicle?.id,
      driverName: selectedVehicle?.driverName,
      driverHandle: selectedVehicle ? `@${selectedVehicle.driverName.toLowerCase().replace(/[^a-z0-9]+/g, '_')}` : undefined,
    });
  }, [appliedRideCoupon, currentEstimatedFare, selectedVehicle, couponsVersion]);

  const rideCouponDiscount = rideCouponEvaluation?.valid ? rideCouponEvaluation.discountAmount : 0;
  const discountedEstimatedFare = Math.max(0, Math.round((currentEstimatedFare - rideCouponDiscount) * 100) / 100);

  const totalFinalMoneyBalance = React.useMemo(
    () => possessedFinalCoins.reduce((sum, c) => sum + Number(c.balance || 0), 0),
    [possessedFinalCoins]
  );

  const selectedFinalCombinedBalance = React.useMemo(
    () => activeRideFinalCoins.reduce((sum, c) => sum + Number(c.balance || 0), 0),
    [activeRideFinalCoins]
  );

  const selectedCurrencyBalance = React.useMemo(
    () =>
      possessedFinalCoins.find(c => c.symbol.toUpperCase() === selectedCurrency.toUpperCase())
        ?.balance ?? 0,
    [possessedFinalCoins, selectedCurrency]
  );

  const hasEnoughSelectedCurrency =
    activeRideFinalCoins.length > 0 && selectedFinalCombinedBalance >= discountedEstimatedFare;

  const hasEnoughAnyFinalCurrency = activeRideFinalCoins.some(
    c => Number(c.balance || 0) >= discountedEstimatedFare
  );

  const handleBookRide = (e: React.FormEvent) => {
    e.preventDefault();
    setWalletErrorMsg(null);
    if (!pickupLocation.trim() || !dropoffLocation.trim()) return;

    const chosenClassGroup = availableVehicleClasses.find(c => c.title === selectedClass);
    if (!chosenClassGroup || chosenClassGroup.cars.length === 0) {
      dispatchGlobalNotification({
        title: 'No Vehicles Available',
        description: 'There are currently no available cars for the selected vehicle class.',
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const route = buildTurnByTurnRoute(pickupLocation, dropoffLocation, 'customer_ride');
    const baseCalculatedFare =
      Math.round(
        Math.max(8, route.distanceMiles * CLASS_META[selectedClass].mult * (ratePerMile / 6)) * 10
      ) / 10;
    const activeBookCouponEval = appliedRideCoupon
      ? evaluateCouponForOrder(appliedRideCoupon, {
          category: 'ride_share',
          channel: 'online',
          subtotal: baseCalculatedFare,
          driverId: selectedVehicle?.id,
          driverName: selectedVehicle?.driverName,
          driverHandle: selectedVehicle ? `@${selectedVehicle.driverName.toLowerCase().replace(/[^a-z0-9]+/g, '_')}` : undefined,
        })
      : null;
    const appliedOnlineDiscount = activeBookCouponEval?.valid ? activeBookCouponEval.discountAmount : 0;
    const calculatedFare = Math.max(0, Math.round((baseCalculatedFare - appliedOnlineDiscount) * 100) / 100);

    // Validate live combined balance across the user's selected Final Wallet currencies (up to 5, 1:1 parity)
    const latestWallet = getStoredUserWallets(userId);
    const chosenSymbols = activeRideFinalCoins.map(c => c.symbol.toUpperCase());
    const chosenSet = new Set(chosenSymbols);
    const chosenBalances: Record<string, number> = {};
    (latestWallet.finalCoins || []).forEach(fc => {
      const sym = (fc.symbol || '').toUpperCase().trim();
      if (chosenSet.has(sym)) {
        chosenBalances[sym] = (chosenBalances[sym] || 0) + Number(fc.balance || 0);
      }
    });
    const combinedChosenBalance = Object.values(chosenBalances).reduce((s, v) => s + v, 0);

    if (chosenSymbols.length === 0 || combinedChosenBalance < calculatedFare) {
      const msg = `There's not enough Final money across your selected Final currencies (${chosenSymbols.join(', ') || 'none'}). Combined available: ${combinedChosenBalance.toLocaleString()}, Required: ${calculatedFare} ${selectedCurrency}.`;
      setWalletErrorMsg(msg);
      dispatchGlobalNotification({
        title: "There's not enough Final money",
        description: msg,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    setIsBookingRide(true);
    setTimeout(() => {
      const assignedVehicle = selectedVehicle || chosenClassGroup.cars[0];
      const freshWallet = getStoredUserWallets(userId);
      const freshChosenBalances: Record<string, number> = {};
      (freshWallet.finalCoins || []).forEach(fc => {
        const sym = (fc.symbol || '').toUpperCase().trim();
        if (chosenSet.has(sym)) {
          freshChosenBalances[sym] = (freshChosenBalances[sym] || 0) + Number(fc.balance || 0);
        }
      });
      const freshTotal = Object.values(freshChosenBalances).reduce((s, v) => s + v, 0);
      if (freshTotal < calculatedFare) {
        setIsBookingRide(false);
        setWalletErrorMsg("There's not enough Final money.");
        return;
      }

      // Prefer deducting the full fare from the primary selected coin or first selected coin that covers it; otherwise deduct across selected Final Wallet coins (1:1)
      const singleFullCurrency =
        (freshChosenBalances[selectedCurrency.toUpperCase()] || 0) >= calculatedFare
          ? selectedCurrency.toUpperCase()
          : chosenSymbols.find(sym => (freshChosenBalances[sym] || 0) >= calculatedFare) || null;

      const deductionOrder = singleFullCurrency
        ? [singleFullCurrency]
        : [
            selectedCurrency.toUpperCase(),
            ...chosenSymbols.filter(s => s !== selectedCurrency.toUpperCase())
          ];

      let remainingToDeduct = calculatedFare;
      const splitsMap: Record<string, number> = {};
      let updatedFinalCoins = [...(freshWallet.finalCoins || [])];

      for (const targetSym of deductionOrder) {
        if (remainingToDeduct <= 0) break;
        updatedFinalCoins = updatedFinalCoins.map(fc => {
          if (fc.symbol.toUpperCase() !== targetSym || remainingToDeduct <= 0) {
            return fc;
          }
          const bal = Number(fc.balance || 0);
          if (bal <= 0) return fc;
          const take = Math.min(bal, remainingToDeduct);
          remainingToDeduct = Math.round((remainingToDeduct - take) * 100) / 100;
          splitsMap[targetSym] = Math.round(((splitsMap[targetSym] || 0) + take) * 100) / 100;
          return {
            ...fc,
            balance: Math.max(0, Math.round((bal - take) * 100) / 100)
          };
        });
      }

      const currencySplits = Object.entries(splitsMap).map(([currency, amount]) => ({ currency, amount }));
      const primaryReceiptCurrency =
        currencySplits.length === 1
          ? currencySplits[0].currency
          : singleFullCurrency || selectedCurrency;

      saveStoredUserWallets(userId, { ...freshWallet, finalCoins: updatedFinalCoins });
      setUserWallet(getStoredUserWallets(userId));

      const matchedSlotKey: DriverVehicleType | null =
        assignedVehicle.id === `${userId}:car`
          ? 'car'
          : assignedVehicle.id === `${userId}:auto_rickshaw`
            ? 'auto_rickshaw'
            : assignedVehicle.id === `${userId}:motor_bike`
              ? 'motor_bike'
              : null;

      const newRide: RideRequest = {
        id: `ride-${Date.now()}`,
        riderId: userId,
        riderName: userName,
        pickup: pickupLocation.trim(),
        dropoff: dropoffLocation.trim(),
        vehicleType: assignedVehicle.vehicleType || chosenClassGroup.vehicleType,
        vehicleClass: assignedVehicle.vehicleClass || selectedClass,
        fare: calculatedFare,
        currency: primaryReceiptCurrency,
        currencySplits,
        status: 'driver_assigned',
        driverId: assignedVehicle.id,
        driverName: assignedVehicle.driverName,
        driverHandle: assignedVehicle.driverHandle,
        driverAvatar: assignedVehicle.driverAvatar,
        driverCar: assignedVehicle.carModel,
        driverCarYear: assignedVehicle.carYear,
        driverPlate: assignedVehicle.plate,
        driverPhotos: matchedSlotKey
          ? (driverVehicles[matchedSlotKey]?.media || assignedVehicle.media || [])
          : (assignedVehicle.media || []),
        driverVideos: matchedSlotKey
          ? (driverVehicles[matchedSlotKey]?.videoMedia || assignedVehicle.videoMedia || [])
          : (assignedVehicle.videoMedia || []),
        driverRating: assignedVehicle.rating,
        createdAt: new Date().toISOString(),
        estimatedTime: `~${route.estimatedMinutes} mins`,
        distance: `${route.distanceMiles} miles`,
        directions: route.steps.map(s => s.instruction)
      };

      const updated = [newRide, ...myRides];
      saveMyRides(updated);

      const bookLedgerItem = createLedgerItemFromRideShareBooking({
        rideId: newRide.id,
        pickup: newRide.pickup,
        dropoff: newRide.dropoff,
        vehicleType: newRide.vehicleType,
        vehicleClass: newRide.vehicleClass,
        driverName: assignedVehicle.driverName,
        driverCar: assignedVehicle.carModel,
        fare: calculatedFare,
        currency: primaryReceiptCurrency,
        distance: newRide.distance,
        estimatedTime: newRide.estimatedTime
      });
      recordLedgerTransaction(userId, bookLedgerItem);
      window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

      if (appliedRideCoupon && appliedOnlineDiscount > 0) {
        redeemCouponForUser(userId, appliedRideCoupon.id, {
          channel: 'online',
          orderRef: newRide.id,
          discountApplied: appliedOnlineDiscount,
          currency: primaryReceiptCurrency,
        });
      }
      setAppliedRideCoupon(null);
      setOptedOutRideCouponVehicleId(null);
      setRideCouponFeedback(null);

      setIsBookingRide(false);
      setCustomerNavStepIdx(0);
      setIsAutoNavigatingCustomer(true);
      setBookSubTab('current');

      dispatchGlobalNotification({
        title: '🚗 Ride Booked & Driver Assigned!',
        description: `${assignedVehicle.driverName} (${assignedVehicle.carModel}) dispatched for ${
          currencySplits.length > 1
            ? currencySplits.map(s => `${s.amount} ${s.currency}`).join(' + ')
            : `${calculatedFare} ${primaryReceiptCurrency}`
        }${appliedRideCoupon && appliedOnlineDiscount > 0 ? ` (Coupon ${appliedRideCoupon.code}: -${appliedOnlineDiscount})` : ''}. Live Turn-by-Turn GPS active.`,
        type: 'ride_share',
        targetTab: 'ride_share',
        amount: calculatedFare,
        currency: primaryReceiptCurrency,
        showToast: true,
        tone: 'success'
      });
    }, 600);
  };

  const initiateCancelRide = (rideId: string) => {
    const target = myRides.find(r => r.id === rideId);
    if (!target || target.status === 'cancelled' || target.status === 'completed') return;

    const elapsedMs = Date.now() - new Date(target.createdAt).getTime();
    const isAfterTwoMinutes = elapsedMs > 120000;

    if (isAfterTwoMinutes) {
      setPendingCancelRideId(rideId);
      setShowCancelWarningModal(true);
    } else {
      executeCancelRide(rideId, false);
    }
  };

  const executeCancelRide = (rideId: string, applyFee: boolean) => {
    const target = myRides.find(r => r.id === rideId);
    const cancellationFee = applyFee && target ? Math.round(target.fare * 0.1 * 100) / 100 : 0;
    const refundAmount = target ? Math.max(0, Math.round((target.fare - cancellationFee) * 100) / 100) : 0;

    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'cancelled' as const } : r
    );
    saveMyRides(updated);
    setShowCancelWarningModal(false);
    setPendingCancelRideId(null);

    if (target && refundAmount > 0 && target.id !== 'ride-demo-407732') {
      if (target.currencySplits && target.currencySplits.length > 1) {
        const ratio = refundAmount / Math.max(0.01, target.fare);
        target.currencySplits.forEach(split => {
          const splitRefund = Math.round(split.amount * ratio * 100) / 100;
          if (splitRefund > 0) {
            const res = applyCurrencyWalletDelta({
              userId,
              currencySymbol: split.currency,
              delta: splitRefund,
              utilityNote: `Ride cancellation refund (#${target.id.slice(-6)})`
            });
            setUserWallet(res.wallet);
          }
        });
      } else {
        const res = applyCurrencyWalletDelta({
          userId,
          currencySymbol: target.currency,
          delta: refundAmount,
          utilityNote: `Ride cancellation refund (#${target.id.slice(-6)})`
        });
        setUserWallet(res.wallet);
      }
    }

    if (target) {
      const receiptCode = `RIDE-${target.id.slice(-6).toUpperCase()}`;
      markLedgerItemReversedByReceipt(userId, receiptCode);
      const cancelLedgerItem = createLedgerItemFromRideShareCancellation({
        rideId: target.id,
        pickup: target.pickup,
        dropoff: target.dropoff,
        driverName: target.driverName || 'Sovereign Driver',
        originalFare: target.fare,
        refundAmount,
        cancellationFee,
        currency: target.currency,
        reason: applyFee
          ? 'Cancelled after 2-minute free window (10% late fee applied).'
          : 'Cancelled within 2-minute free cancellation window.'
      });
      recordLedgerTransaction(userId, cancelLedgerItem);
      window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));
    }

    if (applyFee && cancellationFee > 0 && target) {
      dispatchGlobalNotification({
        title: '⚠️ Ride Cancelled (Late Fee Applied)',
        description: `Cancelled after 2 minutes. A 10% cancellation fee of ${cancellationFee.toFixed(2)} ${target.currency} was charged (${refundAmount.toFixed(2)} ${target.currency} refunded).`,
        type: 'ride_share',
        targetTab: 'dash_ledger',
        amount: refundAmount,
        currency: target.currency,
        showToast: true,
        tone: 'alert'
      });
    } else {
      dispatchGlobalNotification({
        title: '✅ Ride Cancelled Successfully',
        description: 'Your ride was cancelled within the 2-minute free window.',
        type: 'ride_share',
        targetTab: 'dash_ledger',
        showToast: true,
        tone: 'success'
      });
    }
  };

  const handleDriverAcceptRide = (rideId: string) => {
    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'in_transit' as const, driverId: userId, driverName: userName } : r
    );
    saveMyRides(updated);
    setDriverRideStepIdx(0);
    dispatchGlobalNotification({
      title: '🚗 Ride Accepted & Navigating',
      description: `You have accepted dispatch #${rideId.slice(-6)}. Follow Driver Turn-by-Turn Map Directions to pickup.`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'success'
    });
  };

  const handleDriverCompleteRide = (rideId: string) => {
    const target = myRides.find(r => r.id === rideId);
    if (!target || target.status === 'completed') return;
    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'completed' as const } : r
    );
    saveMyRides(updated);
    setDriverEarnings(prev => Math.round((prev + target.fare) * 100) / 100);
    setDriverRideStepIdx(0);

    const creditRes = applyCurrencyWalletDelta({
      userId,
      currencySymbol: target.currency,
      delta: target.fare,
      utilityNote: `Ride-share driver payout (${target.pickup} → ${target.dropoff})`
    });
    setUserWallet(creditRes.wallet);

    const payoutLedgerItem = createLedgerItemFromRideSharePayout({
      kind: 'ride',
      refId: target.id,
      pickup: target.pickup,
      dropoff: target.dropoff,
      counterparty: target.riderName || 'Passenger',
      amount: target.fare,
      currency: target.currency
    });
    recordLedgerTransaction(userId, payoutLedgerItem);
    window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

    dispatchGlobalNotification({
      title: `✅ Trip Completed (+${target.fare} ${target.currency})`,
      description: `Passenger arrived at ${target.dropoff}. Earnings credited to your Final Wallet.`,
      type: 'ride_share',
      targetTab: 'dash_ledger',
      amount: target.fare,
      currency: target.currency,
      showToast: true,
      tone: 'success'
    });
  };

  const handleDriverCancelRide = (rideId: string) => {
    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'searching' as const, driverId: undefined } : r
    );
    saveMyRides(updated);
    setDriverRideStepIdx(0);
    dispatchGlobalNotification({
      title: '🚫 Ride Dispatch Cancelled / Unassigned',
      description: `You have cancelled your acceptance for ride dispatch #${rideId.slice(-6)}.`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'alert'
    });
  };

  const persistDriverVehicles = (nextSlots: Record<DriverVehicleType, DriverVehicleSlot | null>) => {
    setDriverVehicles(nextSlots);
    try {
      localStorage.setItem(`final_finance_driver_vehicles_${userId}`, JSON.stringify(nextSlots));
      const anyRegistered = Boolean(nextSlots.car || nextSlots.auto_rickshaw || nextSlots.motor_bike);
      localStorage.setItem(`final_finance_is_driver_${userId}`, anyRegistered ? 'true' : 'false');
    } catch {}
  };

  const updateDriverDraft = (
    vType: DriverVehicleType,
    patch: Partial<DriverVehicleDraft>
  ) => {
    setDriverDrafts(prev => ({
      ...prev,
      [vType]: { ...prev[vType], ...patch }
    }));
  };

  const handleRegisterVehicleSlot = (vType: DriverVehicleType, e: React.FormEvent) => {
    e.preventDefault();
    const effectiveTier = getUserVerificationTier(currentUser);
    if (!isAdminOrSuperAdminUser(currentUser) && effectiveTier < 2) {
      dispatchGlobalNotification({
        title: '🛡️ Tier 2 Verification Required',
        description: 'You must be at least Tier 2 (2 Legal IDs verified) to register as a Driver.',
        type: 'security',
        targetTab: 'settings',
        showToast: true,
        tone: 'alert'
      });
      onOpenVerificationModal?.(2);
      return;
    }
    const meta = VEHICLE_TYPE_SECTIONS.find(s => s.type === vType)!;
    if (driverVehicles[vType]) {
      dispatchGlobalNotification({
        title: `⚠️ Maximum 1 ${meta.label} Allowed`,
        description: `You already have 1 ${meta.label} registered. Drivers can sign up for Car, Auto Rickshaw, and Motor Bike (1 of each maximum).`,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const draft = driverDrafts[vType];
    const parsedRate = Number(draft.ratePerMile);
    const parsedFoodRate = Number(draft.foodDeliveryRatePerMile);
    const parsedRetailRate = Number(draft.retailDeliveryRatePerMile);
    if (
      !draft.makeModel.trim() ||
      !draft.year.trim() ||
      !draft.plate.trim() ||
      !draft.licenseId.trim() ||
      !draft.insuranceInfo.trim() ||
      !Number.isFinite(parsedRate) ||
      parsedRate <= 0 ||
      !Number.isFinite(parsedFoodRate) ||
      parsedFoodRate <= 0 ||
      !Number.isFinite(parsedRetailRate) ||
      parsedRetailRate <= 0
    ) {
      dispatchGlobalNotification({
        title: '⚠️ Missing Required Information',
        description: `All fields (Vehicle Make & Model, Year, License Plate, License ID, Civilian Ride Rate/mi, Food Delivery Rate/mi, Retail Delivery Rate/mi, and Insurance Information) are required to register your ${meta.label}.`,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const assignedClass: VehicleClassName =
      vType === 'car'
        ? draft.vehicleClass
        : vType === 'auto_rickshaw'
          ? 'Auto Rickshaw'
          : 'Moto Express';

    const newSlot: DriverVehicleSlot = {
      vehicleType: vType,
      vehicleTypeLabel: meta.label,
      vehicleClass: assignedClass,
      makeModel: draft.makeModel.trim(),
      year: draft.year.trim(),
      plate: draft.plate.trim(),
      licenseId: draft.licenseId.trim(),
      ratePerMile: parsedRate,
      deliveryRatePerMile: parsedFoodRate,
      foodDeliveryRatePerMile: parsedFoodRate,
      retailDeliveryRatePerMile: parsedRetailRate,
      insuranceInfo: draft.insuranceInfo.trim(),
      online: true,
      media: draft.media || [],
      videoMedia: draft.videoMedia || [],
      registeredAt: new Date().toISOString()
    };

    const nextSlots = { ...driverVehicles, [vType]: newSlot };
    persistDriverVehicles(nextSlots);
    updateCivilianRatePerMile(parsedRate);
    updateFoodDeliveryRatePerMile(parsedFoodRate);
    updateRetailDeliveryRatePerMile(parsedRetailRate);
    try {
      localStorage.setItem(`final_finance_driver_currencies_${userId}`, JSON.stringify(driverCurrencies));
    } catch {}

    dispatchGlobalNotification({
      title: `🛡️ ${meta.label} Registered & Online`,
      description: `${newSlot.year} ${newSlot.makeModel} (Plate ${newSlot.plate}) registered at ${parsedRate}/mi (Rides) · ${parsedFoodRate}/mi (Food) · ${parsedRetailRate}/mi (Retail), valid 1:1 across all your chosen Final currencies.`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'success'
    });
  };

  const handleToggleSlotOnline = (vType: DriverVehicleType) => {
    const existing = driverVehicles[vType];
    if (!existing) return;
    const nextSlots = {
      ...driverVehicles,
      [vType]: { ...existing, online: !existing.online }
    };
    persistDriverVehicles(nextSlots);
  };

  const handleRemoveVehicleSlot = (vType: DriverVehicleType) => {
    const existing = driverVehicles[vType];
    if (!existing) return;
    if (editingVehicleType === vType) {
      setEditingVehicleType(null);
      setEditVehicleDraft(null);
    }
    const nextSlots = { ...driverVehicles, [vType]: null };
    persistDriverVehicles(nextSlots);
    dispatchGlobalNotification({
      title: `${existing.vehicleTypeLabel} Unregistered`,
      description: `Removed ${existing.makeModel}. You may register a replacement ${existing.vehicleTypeLabel} anytime (max 1 per type).`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'default'
    });
  };

  const handleStartEditVehicleSlot = (vType: DriverVehicleType) => {
    const existing = driverVehicles[vType];
    if (!existing) return;
    setEditingVehicleType(vType);
    setEditTargetVehicleType(vType);
    setSyncDriverInfoAcrossFleet(false);
    setEditVehicleDraft({
      makeModel: existing.makeModel,
      vehicleClass: existing.vehicleClass,
      year: existing.year,
      plate: existing.plate,
      licenseId: existing.licenseId,
      ratePerMile: existing.ratePerMile,
      foodDeliveryRatePerMile: existing.foodDeliveryRatePerMile ?? existing.deliveryRatePerMile ?? foodDeliveryRatePerMile,
      retailDeliveryRatePerMile: existing.retailDeliveryRatePerMile ?? existing.deliveryRatePerMile ?? retailDeliveryRatePerMile,
      insuranceInfo: existing.insuranceInfo,
      media: [...(existing.media || [])],
      videoMedia: [...(existing.videoMedia || [])],
    });
  };

  const handleCancelEditVehicleSlot = () => {
    setEditingVehicleType(null);
    setEditVehicleDraft(null);
    setSyncDriverInfoAcrossFleet(false);
  };

  const handleSaveEditedVehicleSlot = (originalType: DriverVehicleType, e: React.FormEvent) => {
    e.preventDefault();
    if (!editVehicleDraft) return;
    const originalSlot = driverVehicles[originalType];
    if (!originalSlot) return;

    const targetMeta = VEHICLE_TYPE_SECTIONS.find(s => s.type === editTargetVehicleType)!;
    const parsedRate = Number(editVehicleDraft.ratePerMile);
    const parsedFoodRate = Number(editVehicleDraft.foodDeliveryRatePerMile);
    const parsedRetailRate = Number(editVehicleDraft.retailDeliveryRatePerMile);

    if (
      !editVehicleDraft.makeModel.trim() ||
      !editVehicleDraft.year.trim() ||
      !editVehicleDraft.plate.trim() ||
      !editVehicleDraft.licenseId.trim() ||
      !editVehicleDraft.insuranceInfo.trim() ||
      !Number.isFinite(parsedRate) ||
      parsedRate <= 0 ||
      !Number.isFinite(parsedFoodRate) ||
      parsedFoodRate <= 0 ||
      !Number.isFinite(parsedRetailRate) ||
      parsedRetailRate <= 0
    ) {
      dispatchGlobalNotification({
        title: '⚠️ Missing Required Driver Info',
        description: `All fields (Make & Model, Year, License Plate, License ID, Rates, and Insurance Information) are required to update your ${targetMeta.label}.`,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const assignedClass: VehicleClassName =
      editTargetVehicleType === 'car'
        ? (editVehicleDraft.vehicleClass === 'Economy' || editVehicleDraft.vehicleClass === 'Comfort EV' || editVehicleDraft.vehicleClass === 'Luxury Limousine'
            ? editVehicleDraft.vehicleClass
            : 'Comfort EV')
        : editTargetVehicleType === 'auto_rickshaw'
          ? 'Auto Rickshaw'
          : 'Moto Express';

    const nowIso = new Date().toISOString();
    const updatedSlot: DriverVehicleSlot = {
      vehicleType: editTargetVehicleType,
      vehicleTypeLabel: targetMeta.label,
      vehicleClass: assignedClass,
      makeModel: editVehicleDraft.makeModel.trim(),
      year: editVehicleDraft.year.trim(),
      plate: editVehicleDraft.plate.trim(),
      licenseId: editVehicleDraft.licenseId.trim(),
      ratePerMile: parsedRate,
      deliveryRatePerMile: parsedFoodRate,
      foodDeliveryRatePerMile: parsedFoodRate,
      retailDeliveryRatePerMile: parsedRetailRate,
      insuranceInfo: editVehicleDraft.insuranceInfo.trim(),
      online: originalSlot.online,
      media: editVehicleDraft.media || [],
      videoMedia: editVehicleDraft.videoMedia || [],
      registeredAt: originalSlot.registeredAt || nowIso,
      updatedAt: nowIso,
    };

    const nextSlots: Record<DriverVehicleType, DriverVehicleSlot | null> = { ...driverVehicles };
    if (editTargetVehicleType !== originalType) {
      nextSlots[originalType] = null;
    }
    nextSlots[editTargetVehicleType] = updatedSlot;

    if (syncDriverInfoAcrossFleet) {
      (['car', 'auto_rickshaw', 'motor_bike'] as DriverVehicleType[]).forEach((t) => {
        const s = nextSlots[t];
        if (s && t !== editTargetVehicleType) {
          nextSlots[t] = {
            ...s,
            licenseId: updatedSlot.licenseId,
            insuranceInfo: updatedSlot.insuranceInfo,
            updatedAt: nowIso,
          };
        }
      });
    }

    persistDriverVehicles(nextSlots);

    // Keep drafts in sync so re-registering or switching retains updated driving info
    setDriverDrafts((prev) => {
      const synced = {
        ...prev,
        [editTargetVehicleType]: {
          ...editVehicleDraft,
          vehicleClass: assignedClass,
        },
      };
      if (syncDriverInfoAcrossFleet) {
        (['car', 'auto_rickshaw', 'motor_bike'] as DriverVehicleType[]).forEach((t) => {
          synced[t] = {
            ...synced[t],
            licenseId: updatedSlot.licenseId,
            insuranceInfo: updatedSlot.insuranceInfo,
          };
        });
      }
      return synced;
    });

    updateCivilianRatePerMile(parsedRate);
    updateFoodDeliveryRatePerMile(parsedFoodRate);
    updateRetailDeliveryRatePerMile(parsedRetailRate);
    try {
      localStorage.setItem(`final_finance_driver_currencies_${userId}`, JSON.stringify(driverCurrencies));
    } catch {}

    setEditingVehicleType(null);
    setEditVehicleDraft(null);
    setSyncDriverInfoAcrossFleet(false);

    dispatchGlobalNotification({
      title: editTargetVehicleType !== originalType
        ? `🔄 Vehicle Switched to ${targetMeta.label}`
        : `✅ ${targetMeta.label} Driver Info Updated`,
      description: `${updatedSlot.year} ${updatedSlot.makeModel} (Plate ${updatedSlot.plate} · License ${updatedSlot.licenseId}) saved at ${parsedRate}/${parsedFoodRate}/${parsedRetailRate} per mi.`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'success'
    });
  };

  const dismissDriverNotification = (notifId: string) => {
    const updated = driverDeliveryNotifications.map(n => n.id === notifId ? { ...n, read: true } : n);
    setDriverDeliveryNotifications(updated);
    try {
      localStorage.setItem('final_finance_driver_delivery_notifications', JSON.stringify(updated));
    } catch {}
  };

  const driverAcceptsCurrency = (currencySymbol?: string): boolean => {
    if (!currencySymbol) return false;
    const clean = currencySymbol.trim().toUpperCase();
    return driverCurrencies.some(c => c.trim().toUpperCase() === clean);
  };

  const handleAcceptDeliveryContract = (contractId: string) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    if (!target || target.status !== 'available') return;

    const customerPaymentCurrency = (target.orderCurrency || target.originalCurrency || target.currency || 'AFNL').toUpperCase();
    if (!driverAcceptsCurrency(customerPaymentCurrency)) {
      dispatchGlobalNotification({
        title: `🚫 Delivery Currency Mismatch (#${target.orderNumber})`,
        description: `Order #${target.orderNumber} was settled in ${customerPaymentCurrency}, which does not match your accepted final currencies (${driverCurrencies.join(', ')}).`,
        type: 'delivery',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const rawDistance = target.distanceMiles ?? (parseFloat(target.distance || '4') || 4.0);
    const isKm = (target.distance || '').toLowerCase().includes('km');
    const distanceMiles = isKm ? Math.max(0.5, Math.round(rawDistance * 0.621371 * 10) / 10) : rawDistance;
    const driverCoin = customerPaymentCurrency;
    const applicableDeliveryRate = getDeliveryRateForBusiness(target.businessType);
    const driverFee = Math.round(applicableDeliveryRate * distanceMiles * 100) / 100;
    const itemAdjustmentPerUnit = Math.max(5, Math.round(applicableDeliveryRate * 2));
    const originalFee = target.originalStoreFee ?? target.deliveryFee ?? 15;
    const originalFeeCurrency = target.originalCurrency ?? target.currency;
    const storeRateVal =
      target.storeRatePerMile ??
      Math.max(0.5, Math.round((originalFee / Math.max(0.5, distanceMiles)) * 100) / 100);
    const acceptedAtIso = new Date().toISOString();
    const timing = estimateDeliveryTiming(
      target.pickupAddress || target.merchantName,
      target.deliveryAddress,
      distanceMiles
    );
    const merchantLabel = target.businessType === 'retail' ? 'Store' : 'Restaurant';
    const driverToMerchantMins = timing.toPickupMinutes;
    const merchantToCustomerMins = timing.deliveryMinutes;
    const waitTimeMins = timing.totalMinutes;
    const waitStatusText = `Owner Wait for Driver: ~${driverToMerchantMins} mins · Driver → ${merchantLabel} (~${driverToMerchantMins}m) + Customer (~${merchantToCustomerMins}m) = ~${waitTimeMins} mins total (${userName})`;

    const updated = deliveryContracts.map(c =>
      c.id === contractId
        ? {
            ...c,
            status: 'accepted' as const,
            driverHandle: userId,
            driverName: userName,
            originalStoreFee: originalFee,
            originalCurrency: originalFeeCurrency,
            storeRatePerMile: storeRateVal,
            deliveryFee: driverFee,
            currency: driverCoin,
            driverRatePerMile: applicableDeliveryRate,
            distanceMiles
          }
        : c
    );
    saveDeliveryContracts(updated);
    setActiveDeliveryDispatchTab(target.businessType);
    setFocusedDeliveryId(contractId);
    setDriverDeliveryStepIdx(0);

    // Mark matching notification read
    const nextNotifs = driverDeliveryNotifications.map(n =>
      n.contractId === contractId || n.orderNumber === target.orderNumber ? { ...n, read: true } : n
    );
    setDriverDeliveryNotifications(nextNotifs);
    try {
      localStorage.setItem('final_finance_driver_delivery_notifications', JSON.stringify(nextNotifs));
    } catch {}

    // Update customer/merchant TakeoutOrder with driver rate, Before/After item & total pricing, wait time & 5-minute cancel countdown
    let beforeTotal = target.orderTotalBefore ?? originalFee;
    let afterTotal = driverFee;
    let orderCurr = target.orderCurrency || originalFeeCurrency;

    try {
      const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
      const updatedOrders = storedOrders.map((ord: any) => {
        if (ord.orderNumber === target.orderNumber || ord.id === target.takeoutOrderId) {
          const origFee = Number(ord.originalDeliveryFee ?? ord.deliveryFee ?? originalFee);
          const origFeeCurrency = ord.originalDeliveryFeeCurrency || ord.deliveryFeeCurrency || ord.currency;
          const origTotal = Number(ord.originalTotal ?? ord.total ?? 0);
          const origSubtotal = Number(ord.subtotal || 0);
          const origTax = Number(ord.tax || 0);
          const tipAmt = Number(ord.tip || 0);

          const updatedItems = Array.isArray(ord.items)
            ? ord.items.map((it: any) => {
                const lineBefore = Number(it.priceBefore ?? it.item?.price ?? 0);
                const lineAfter = Math.round((lineBefore + itemAdjustmentPerUnit) * 100) / 100;
                return {
                  ...it,
                  priceBefore: lineBefore,
                  priceAfter: lineAfter,
                  item: {
                    ...it.item,
                    price: lineAfter
                  }
                };
              })
            : ord.items;

          const newSubtotal = Array.isArray(updatedItems)
            ? Math.round(updatedItems.reduce((s: number, it: any) => s + (Number(it.item?.price || 0) * Number(it.quantity || 1)), 0) * 100) / 100
            : origSubtotal;
          const newTax = 0;
          const firstBefore = Number(ord.itemPriceBefore ?? updatedItems?.[0]?.priceBefore ?? updatedItems?.[0]?.item?.price ?? 0);
          const firstAfter = Number(updatedItems?.[0]?.priceAfter ?? firstBefore + itemAdjustmentPerUnit);

          const hadFeeInTotal =
            origFeeCurrency.toUpperCase() === (ord.currency || '').toUpperCase() &&
            origTotal >= origSubtotal + tipAmt + origFee - 0.05;

          const newTotal =
            driverCoin.toUpperCase() === (ord.currency || '').toUpperCase()
              ? Math.round((newSubtotal + tipAmt + driverFee) * 100) / 100
              : Math.round((newSubtotal + tipAmt) * 100) / 100;

          beforeTotal = origTotal;
          afterTotal = newTotal;
          orderCurr = ord.currency;

          if (ord.walletDeducted && !ord.walletRefunded) {
            const payerId = ord.customerWalletUserId || userId;
            if (driverCoin.toUpperCase() === (ord.currency || '').toUpperCase()) {
              const totalDiff = Math.round((newTotal - Number(ord.total || 0)) * 100) / 100;
              if (totalDiff !== 0) {
                applyCurrencyWalletDelta({
                  userId: payerId,
                  currencySymbol: ord.currency,
                  delta: -totalDiff,
                  utilityNote: `Driver delivery & item rate adjustment for order #${ord.orderNumber}`
                });
                setUserWallet(getStoredUserWallets(userId));
              }
            } else {
              const prevBaseOnly = hadFeeInTotal
                ? Math.max(0, Math.round((Number(ord.total || 0) - origFee) * 100) / 100)
                : Number(ord.total || 0);
              const itemsDiff = Math.round((newTotal - prevBaseOnly) * 100) / 100;
              if (itemsDiff !== 0) {
                applyCurrencyWalletDelta({
                  userId: payerId,
                  currencySymbol: ord.currency,
                  delta: -itemsDiff,
                  utilityNote: `Driver item price update for order #${ord.orderNumber}`
                });
              }
              if (hadFeeInTotal && origFee > 0) {
                applyCurrencyWalletDelta({
                  userId: payerId,
                  currencySymbol: ord.currency,
                  delta: origFee,
                  utilityNote: `Delivery fee refund on driver currency switch (#${ord.orderNumber})`
                });
              } else if (origFeeCurrency.toUpperCase() === driverCoin.toUpperCase()) {
                const feeDelta = Math.round((driverFee - Number(ord.deliveryFee || 0)) * 100) / 100;
                if (feeDelta !== 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: driverCoin,
                    delta: -feeDelta,
                    utilityNote: `Driver delivery rate adjustment (#${ord.orderNumber})`
                  });
                }
              } else {
                if (Number(ord.deliveryFee || 0) > 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: origFeeCurrency,
                    delta: Number(ord.deliveryFee || 0),
                    utilityNote: `Delivery fee refund on driver currency switch (#${ord.orderNumber})`
                  });
                }
                if (driverFee > 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: driverCoin,
                    delta: -driverFee
                  });
                }
              }
              setUserWallet(getStoredUserWallets(userId));
            }
          }

          return {
            ...ord,
            items: updatedItems,
            subtotal: newSubtotal,
            tax: newTax,
            driverAccepted: true,
            driverAcceptedAt: acceptedAtIso,
            driverHandle: userId,
            driverName: userName,
            driverAcceptedCurrencies: driverCurrencies,
            storeRatePerMile: ord.storeRatePerMile ?? storeRateVal,
            driverRatePerMile: applicableDeliveryRate,
            driverRateCurrency: driverCoin,
            originalDeliveryFee: origFee,
            originalDeliveryFeeCurrency: origFeeCurrency,
            updatedDeliveryFee: driverFee,
            deliveryFee: driverFee,
            deliveryFeeCurrency: driverCoin,
            itemPriceBefore: firstBefore,
            itemPriceAfter: firstAfter,
            originalTotal: origTotal,
            total: newTotal,
            driverToMerchantMinutes: driverToMerchantMins,
            merchantToCustomerMinutes: merchantToCustomerMins,
            waitTimeMinutes: waitTimeMins,
            waitTimeStatusText: waitStatusText,
            waitTimeUpdatedAt: acceptedAtIso
          };
        }
        return ord;
      });
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(updatedOrders));
      window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));

      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('final_finance_pos_transactions_')) {
          try {
            const txs = JSON.parse(localStorage.getItem(k) || '[]');
            if (Array.isArray(txs)) {
              const nextTxs = txs.map((tx: any) =>
                tx.receiptNumber === target.orderNumber
                  ? {
                      ...tx,
                      subtotal: Array.isArray(updatedOrders.find((o: any) => o.orderNumber === target.orderNumber)?.subtotal)
                        ? tx.subtotal
                        : (updatedOrders.find((o: any) => o.orderNumber === target.orderNumber)?.subtotal ?? tx.subtotal),
                      tax: updatedOrders.find((o: any) => o.orderNumber === target.orderNumber)?.tax ?? tx.tax,
                      total: afterTotal,
                      deliveryFee: driverFee,
                      deliveryFeeCurrency: driverCoin,
                      deliveryProviderType: 'third_party',
                      driverAccepted: true,
                      driverName: userName,
                      driverHandle: userId
                    }
                  : tx
              );
              localStorage.setItem(k, JSON.stringify(nextTxs));
            }
          } catch {}
        }
      }
      window.dispatchEvent(new CustomEvent('final_finance_pos_transactions_updated'));
    } catch (e) {
      console.error(e);
    }

    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));

    const merchantKind = target.businessType === 'retail' ? 'Store' : 'Restaurant';
    dispatchGlobalNotification({
      title: `📦 Delivery Price Updated (#${target.orderNumber})`,
      description: `${merchantKind} Rate: ${storeRateVal} ${originalFeeCurrency}/mi vs Driver ${target.businessType === 'retail' ? 'Retail' : 'Food'} Delivery Rate: ${applicableDeliveryRate} ${driverCoin}/mi. Delivery Fee: ${originalFee} ${originalFeeCurrency} → ${driverFee} ${driverCoin} (Order Total: ${beforeTotal} → ${afterTotal} ${orderCurr}). Wait time updated to ~${waitTimeMins} mins. Customer has 5:00 to cancel.`,
      type: 'delivery',
      targetTab: 'point_of_sale',
      amount: driverFee,
      currency: driverCoin,
      showToast: true,
      tone: 'success'
    });
  };

  const handleMarkDeliveryPickedUp = (contractId: string) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    const updated = deliveryContracts.map(c =>
      c.id === contractId ? { ...c, status: 'picked_up' as const } : c
    );
    saveDeliveryContracts(updated);
    setDriverDeliveryStepIdx(2);
    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));
    if (target) {
      try {
        const dist = target.distanceMiles ?? (parseFloat(target.distance || '4') || 4);
        const timing = estimateDeliveryTiming(
          target.pickupAddress || target.merchantName,
          target.deliveryAddress,
          dist
        );
        const minsLeft = timing.deliveryMinutes;
        const merchantLabel = target.businessType === 'retail' ? 'Store' : 'Restaurant';
        const nowIso = new Date().toISOString();
        const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
        const nextOrders = storedOrders.map((ord: any) =>
          ord.orderNumber === target.orderNumber || ord.id === target.takeoutOrderId
            ? {
                ...ord,
                status: ord.status === 'received' || ord.status === 'in_kitchen' ? 'ready_for_pickup' : ord.status,
                driverToMerchantMinutes: 0,
                merchantToCustomerMinutes: minsLeft,
                waitTimeMinutes: minsLeft,
                waitTimeStatusText: `Picked up at ${merchantLabel} · ${merchantLabel} to Customer Address: ~${minsLeft} mins (${userName})`,
                waitTimeUpdatedAt: nowIso
              }
            : ord
        );
        localStorage.setItem('final_finance_takeout_orders', JSON.stringify(nextOrders));
        window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
      } catch {}
      dispatchGlobalNotification({
        title: `📦 Order #${target.orderNumber} Picked Up`,
        description: `Picked up from ${target.merchantName}. En route to ${target.customerName} (${target.deliveryAddress}).`,
        type: 'delivery',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'success'
      });
    }
  };

  const handleDriverCancelDelivery = (contractId: string) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    const restoredFee = target?.originalStoreFee ?? target?.deliveryFee ?? 15;
    const restoredCurrency = target?.originalCurrency ?? target?.currency ?? 'AFNL';

    const updated = deliveryContracts.map(c =>
      c.id === contractId
        ? {
            ...c,
            status: 'available' as const,
            driverHandle: undefined,
            driverName: undefined,
            deliveryFee: restoredFee,
            currency: restoredCurrency
          }
        : c
    );
    saveDeliveryContracts(updated);
    if (focusedDeliveryId === contractId) setFocusedDeliveryId(null);
    setDriverDeliveryStepIdx(0);

    if (target) {
      try {
        const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
        const revertedOrders = storedOrders.map((ord: any) => {
          if (ord.orderNumber === target.orderNumber || ord.id === target.takeoutOrderId) {
            if (ord.walletDeducted && !ord.walletRefunded) {
              const payerId = ord.customerWalletUserId || userId;
              const origTotal = Number(ord.originalTotal ?? ord.total ?? 0);
              const currTotal = Number(ord.total ?? 0);
              const currentFeeCurrency = (ord.deliveryFeeCurrency || ord.currency || restoredCurrency).toUpperCase();
              if (currentFeeCurrency === (ord.currency || '').toUpperCase()) {
                const diff = Math.round((origTotal - currTotal) * 100) / 100;
                if (diff !== 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: ord.currency,
                    delta: -diff,
                    utilityNote: `Delivery fee restored on driver cancel (#${ord.orderNumber})`
                  });
                  setUserWallet(getStoredUserWallets(userId));
                }
              } else {
                const chargedDriverFee = Number(ord.deliveryFee || 0);
                if (chargedDriverFee > 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: currentFeeCurrency,
                    delta: chargedDriverFee,
                    utilityNote: `Refund driver delivery fee (#${ord.orderNumber})`
                  });
                }
                const origFee = Number(ord.originalDeliveryFee ?? restoredFee);
                if (origFee > 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: ord.originalDeliveryFeeCurrency || ord.currency,
                    delta: -origFee
                  });
                }
                setUserWallet(getStoredUserWallets(userId));
              }
            }
            const restoredItems = Array.isArray(ord.items)
              ? ord.items.map((it: any) => ({
                  ...it,
                  priceBefore: undefined,
                  priceAfter: undefined,
                  item: {
                    ...it.item,
                    price: it.priceBefore ?? it.item?.price
                  }
                }))
              : ord.items;
            const restoredSubtotal = Array.isArray(restoredItems)
              ? Math.round(restoredItems.reduce((s: number, it: any) => s + (Number(it.item?.price || 0) * Number(it.quantity || 1)), 0) * 100) / 100
              : ord.subtotal;
            const restoredTax = 0;
            const restoredDist = Number(ord.deliveryDistance ?? target.distanceMiles ?? 4) || 4;
            const restoredTiming = estimateDeliveryTiming(
              target.pickupAddress || target.merchantName,
              target.deliveryAddress,
              restoredDist
            );
            const merchantLabel = target.businessType === 'retail' ? 'Store' : 'Restaurant';
            return {
              ...ord,
              items: restoredItems,
              subtotal: restoredSubtotal,
              tax: restoredTax,
              driverAccepted: false,
              driverHandle: undefined,
              driverName: undefined,
              driverRatePerMile: undefined,
              driverRateCurrency: undefined,
              updatedDeliveryFee: undefined,
              itemPriceBefore: undefined,
              itemPriceAfter: undefined,
              deliveryFee: ord.originalDeliveryFee ?? restoredFee,
              deliveryFeeCurrency: ord.originalDeliveryFeeCurrency ?? restoredCurrency,
              total: ord.originalTotal ?? ord.total,
              driverToMerchantMinutes: restoredTiming.toPickupMinutes,
              merchantToCustomerMinutes: restoredTiming.deliveryMinutes,
              waitTimeMinutes: restoredTiming.totalMinutes,
              waitTimeStatusText: `Owner Wait for Driver: ~${restoredTiming.toPickupMinutes} mins · Driver → ${merchantLabel} (~${restoredTiming.toPickupMinutes}m) + Customer (~${restoredTiming.deliveryMinutes}m) = ~${restoredTiming.totalMinutes} mins total`,
              waitTimeUpdatedAt: new Date().toISOString()
            };
          }
          return ord;
        });
        localStorage.setItem('final_finance_takeout_orders', JSON.stringify(revertedOrders));
        window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));

        const matchedOrd = revertedOrders.find((o: any) => o.orderNumber === target.orderNumber || o.id === target.takeoutOrderId);
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith('final_finance_pos_transactions_')) {
            try {
              const txs = JSON.parse(localStorage.getItem(k) || '[]');
              if (Array.isArray(txs)) {
                const nextTxs = txs.map((tx: any) =>
                  tx.receiptNumber === target.orderNumber
                    ? {
                        ...tx,
                        subtotal: matchedOrd?.subtotal ?? tx.subtotal,
                        tax: matchedOrd?.tax ?? tx.tax,
                        total: matchedOrd?.total ?? tx.total,
                        deliveryFee: restoredFee,
                        deliveryFeeCurrency: restoredCurrency,
                        driverAccepted: false,
                        driverName: undefined,
                        driverHandle: undefined
                      }
                    : tx
                );
                localStorage.setItem(k, JSON.stringify(nextTxs));
              }
            } catch {}
          }
        }
        window.dispatchEvent(new CustomEvent('final_finance_pos_transactions_updated'));
      } catch {}
    }
    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));

    dispatchGlobalNotification({
      title: '📦 Delivery Dispatch Returned',
      description: 'You have unassigned yourself and restored the original store delivery fee.',
      type: 'delivery',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'alert'
    });
  };

  const openDeliveryProofModal = (contractId: string) => {
    setProofModalContractId(contractId);
    setDeliveryProofPhotos([]);
    setDeliveryProofVideos([]);
  };

  const handleCompleteDelivery = (
    contractId: string,
    proof?: { photos: string[]; videos: string[] }
  ) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    if (!target || (target.status !== 'accepted' && target.status !== 'picked_up')) return;

    const attachedPhotos = proof?.photos ?? deliveryProofPhotos;
    const attachedVideos = proof?.videos ?? deliveryProofVideos;
    if (attachedPhotos.length === 0 && attachedVideos.length === 0) {
      dispatchGlobalNotification({
        title: 'Photo or Video Required',
        description: `Take or upload at least 1 picture or 1 video of Order #${target.orderNumber} before confirming delivery.`,
        type: 'delivery',
        targetTab: 'rideshare',
        showToast: true,
        tone: 'alert'
      });
      return;
    }
    const deliveredAtIso = new Date().toISOString();

    const updated = deliveryContracts.map(c =>
      c.id === contractId
        ? {
            ...c,
            status: 'delivered' as const,
            proofPhotos: attachedPhotos,
            proofVideos: attachedVideos,
            deliveredAt: deliveredAtIso
          }
        : c
    );
    saveDeliveryContracts(updated);
    setDriverEarnings(prev => Math.round((prev + target.deliveryFee) * 100) / 100);

    const deliveryCreditRes = applyCurrencyWalletDelta({
      userId,
      currencySymbol: target.currency,
      delta: target.deliveryFee,
      utilityNote: `Delivery payout for order #${target.orderNumber} (${target.merchantName})`
    });
    setUserWallet(deliveryCreditRes.wallet);

    if (focusedDeliveryId === contractId) setFocusedDeliveryId(null);
    setDriverDeliveryStepIdx(0);
    setProofModalContractId(null);
    setDeliveryProofPhotos([]);
    setDeliveryProofVideos([]);

    try {
      const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
      const completedOrders = storedOrders.map((ord: any) => {
        if (ord.orderNumber === target.orderNumber || ord.id === target.takeoutOrderId) {
          return {
            ...ord,
            status: 'completed',
            deliveryProofPhotos: attachedPhotos,
            deliveryProofVideos: attachedVideos,
            deliveredAt: deliveredAtIso,
            driverToMerchantMinutes: 0,
            merchantToCustomerMinutes: 0,
            waitTimeMinutes: 0,
            waitTimeStatusText: 'Delivered & Completed',
            waitTimeUpdatedAt: deliveredAtIso
          };
        }
        return ord;
      });
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(completedOrders));
      window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));

      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('final_finance_pos_transactions_')) {
          try {
            const txs = JSON.parse(localStorage.getItem(k) || '[]');
            if (Array.isArray(txs)) {
              const nextTxs = txs.map((tx: any) =>
                tx.receiptNumber === target.orderNumber
                  ? {
                      ...tx,
                      deliveryProviderType: 'third_party',
                      driverAccepted: true,
                      driverName: target.driverName || userName,
                      driverHandle: target.driverHandle || userId,
                      deliveredAt: deliveredAtIso
                    }
                  : tx
              );
              localStorage.setItem(k, JSON.stringify(nextTxs));
            }
          } catch {}
        }
      }
      window.dispatchEvent(new CustomEvent('final_finance_pos_transactions_updated'));
    } catch {}
    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));

    const deliveryLedgerEntry = createLedgerItemFromRideSharePayout({
      kind: 'delivery',
      refId: target.id,
      orderOrRideCode: target.orderNumber,
      pickup: target.merchantName || target.pickupAddress,
      dropoff: target.deliveryAddress,
      counterparty: target.customerName,
      amount: target.deliveryFee,
      currency: target.currency,
      proofSummary: `Proof attached: ${attachedPhotos.length} photo(s), ${attachedVideos.length} video(s).`
    });
    recordLedgerTransaction(userId, deliveryLedgerEntry);
    window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

    dispatchGlobalNotification({
      title: `✅ Delivery Completed! (+${target.deliveryFee} ${target.currency})`,
      description: `Delivered order #${target.orderNumber} with ${attachedPhotos.length} proof photo(s) and ${attachedVideos.length} proof video(s). Earnings credited to your Final Wallet.`,
      type: 'delivery',
      targetTab: 'dash_ledger',
      amount: target.deliveryFee,
      currency: target.currency,
      showToast: true,
      tone: 'success'
    });
  };

  const handleSaveReview = () => {
    if (ratingModalRideId) {
      const updated = myRides.map(r =>
        r.id === ratingModalRideId ? { ...r, rating: reviewRating, comment: reviewComment, status: 'completed' as const } : r
      );
      saveMyRides(updated);
      dispatchGlobalNotification({
        title: '⭐ Driver Rating & Review Saved',
        description: `Thank you for rating driver (${reviewRating} Stars).`,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'success'
      });
      setRatingModalRideId(null);
    } else if (ratingModalDeliveryId) {
      const targetContract = deliveryContracts.find(c => c.id === ratingModalDeliveryId);
      const updated = deliveryContracts.map(c =>
        c.id === ratingModalDeliveryId ? { ...c, rating: reviewRating, comment: reviewComment } : c
      );
      saveDeliveryContracts(updated);
      if (targetContract) {
        try {
          const ratedAtIso = new Date().toISOString();
          const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
          const nextOrders = storedOrders.map((ord: any) =>
            ord.orderNumber === targetContract.orderNumber || ord.id === targetContract.takeoutOrderId
              ? {
                  ...ord,
                  customerDriverRating: reviewRating,
                  customerDriverComment: reviewComment,
                  customerDriverRatedAt: ratedAtIso
                }
              : ord
          );
          localStorage.setItem('final_finance_takeout_orders', JSON.stringify(nextOrders));
          window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
        } catch {}
      }
      dispatchGlobalNotification({
        title: '⭐ Delivery Partner Rating Saved',
        description: `Merchant delivery partner rating updated successfully (${reviewRating} Stars).`,
        type: 'delivery',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'success'
      });
      setRatingModalDeliveryId(null);
    }
    setReviewComment('');
    setReviewRating(5);
  };

  const filteredRides = myRides.filter(r => !blockedUsers.includes(r.driverId || '') && !blockedUsers.includes(r.riderId));
  const filteredDeliveries = deliveryContracts.filter(c => {
    if (blockedUsers.includes(c.driverHandle || '')) return false;
    if (c.status === 'available') {
      const targetCurrency = c.orderCurrency || c.originalCurrency || c.currency;
      return driverAcceptsCurrency(targetCurrency);
    }
    return true;
  });
  const activeRide = filteredRides.find(r => r.status !== 'cancelled' && r.status !== 'completed');
  const activeDriverRide = filteredRides.find(r => r.status === 'in_transit' && r.driverId === userId) || null;
  const acceptedDeliveries = filteredDeliveries.filter(c => c.status === 'accepted' || c.status === 'picked_up');
  const activeDeliveryContract = acceptedDeliveries.find(c => c.id === focusedDeliveryId) || acceptedDeliveries[0] || null;
  const unreadDeliveryNotifs = driverDeliveryNotifications.filter(n => {
    if (n.read) return false;
    const notifCurrency = n.paymentCurrency || n.orderCurrency || n.storeFeeCurrency;
    if (!driverAcceptsCurrency(notifCurrency)) return false;
    const matching = deliveryContracts.find(c => c.id === n.contractId || c.orderNumber === n.orderNumber);
    if (matching && matching.status !== 'available') return false;
    return true;
  });

  // Auto-advance customer ride navigation when enabled
  const customerRoute = React.useMemo(
    () => activeRide ? buildTurnByTurnRoute(activeRide.pickup, activeRide.dropoff, 'customer_ride') : null,
    [activeRide]
  );

  // Live routes for Driver Ride & Driver Delivery so GPS announces turns automatically along the road
  const activeDriverRideRoute = React.useMemo(
    () => activeDriverRide ? buildTurnByTurnRoute(activeDriverRide.pickup, activeDriverRide.dropoff, 'driver_ride') : null,
    [activeDriverRide]
  );

  const activeDriverDeliveryRoute = React.useMemo(
    () =>
      activeDeliveryContract
        ? buildTurnByTurnRoute(
            activeDeliveryContract.pickupAddress || activeDeliveryContract.merchantName,
            activeDeliveryContract.deliveryAddress,
            'driver_delivery',
            {
              merchantName: activeDeliveryContract.merchantName,
              customerName: activeDeliveryContract.customerName,
              baseDistanceMiles: activeDeliveryContract.distanceMiles
            }
          )
        : null,
    [activeDeliveryContract]
  );

  const speakTurnPrompt = React.useCallback(
    (text: string) => {
      if (!voiceGpsEnabled) return;
      try {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.rate = 1.02;
          window.speechSynthesis.speak(utterance);
        }
      } catch {}
    },
    [voiceGpsEnabled]
  );

  useEffect(() => {
    if (!isAutoNavigatingCustomer || !customerRoute) return;
    const maxIdx = customerRoute.steps.length - 1;
    if (customerNavStepIdx >= maxIdx) {
      setIsAutoNavigatingCustomer(false);
      return;
    }
    const timer = window.setInterval(() => {
      setCustomerNavStepIdx(prev => {
        if (prev >= maxIdx) {
          setIsAutoNavigatingCustomer(false);
          return prev;
        }
        return prev + 1;
      });
    }, 3500);
    return () => window.clearInterval(timer);
  }, [isAutoNavigatingCustomer, customerRoute, customerNavStepIdx]);

  // Automatic GPS turn-by-turn progression for Driver Ride Dispatches (no button presses needed)
  useEffect(() => {
    if (!activeDriverRide || !activeDriverRideRoute || !isAutoGpsDriverRide) return;
    const maxIdx = activeDriverRideRoute.steps.length - 1;
    if (driverRideStepIdx >= maxIdx) return;
    const timer = window.setInterval(() => {
      setDriverRideStepIdx(prev => {
        const next = Math.min(maxIdx, prev + 1);
        if (next !== prev && activeTab === 'driver' && driverSubTab === 'ride_dispatches') {
          const stepObj = activeDriverRideRoute.steps[next];
          if (stepObj) speakTurnPrompt(stepObj.instruction);
        }
        return next;
      });
    }, 4000);
    return () => window.clearInterval(timer);
  }, [
    activeDriverRide,
    activeDriverRideRoute,
    isAutoGpsDriverRide,
    driverRideStepIdx,
    activeTab,
    driverSubTab,
    speakTurnPrompt
  ]);

  // Automatic GPS turn-by-turn progression for Driver Delivery Dispatches (no button presses needed)
  useEffect(() => {
    if (!activeDeliveryContract || !activeDriverDeliveryRoute || !isAutoGpsDriverDelivery) return;
    const maxIdx = activeDriverDeliveryRoute.steps.length - 1;
    if (driverDeliveryStepIdx >= maxIdx) return;
    const timer = window.setInterval(() => {
      setDriverDeliveryStepIdx(prev => {
        const next = Math.min(maxIdx, prev + 1);
        if (next !== prev && activeTab === 'driver' && driverSubTab === 'delivery_dispatches') {
          const stepObj = activeDriverDeliveryRoute.steps[next];
          if (stepObj) speakTurnPrompt(stepObj.instruction);
        }
        return next;
      });
    }, 4000);
    return () => window.clearInterval(timer);
  }, [
    activeDeliveryContract,
    activeDriverDeliveryRoute,
    isAutoGpsDriverDelivery,
    driverDeliveryStepIdx,
    activeTab,
    driverSubTab,
    speakTurnPrompt
  ]);

  const getManeuverIcon = (maneuver: TurnByTurnStep['maneuver']) => {
    switch (maneuver) {
      case 'left':
        return <CornerUpLeft className="w-3.5 h-3.5 shrink-0" />;
      case 'right':
        return <CornerUpRight className="w-3.5 h-3.5 shrink-0" />;
      case 'pickup':
        return <MapPin className="w-3.5 h-3.5 shrink-0" />;
      case 'arrive':
        return <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />;
      default:
        return <ArrowUp className="w-3.5 h-3.5 shrink-0" />;
    }
  };

  // Compute exact (x%, y%) along quadratic Bezier M 80 190 Q 390 40 700 90 inside viewBox="0 0 780 260"
  const getBezierMarkerPos = (stepIdx: number, totalSteps: number) => {
    const t = totalSteps <= 1 ? 0.5 : Math.min(1, Math.max(0, stepIdx / (totalSteps - 1)));
    const p0 = { x: 80, y: 190 };
    const p1 = { x: 390, y: 40 };
    const p2 = { x: 700, y: 90 };
    const x = (1 - t) * (1 - t) * p0.x + 2 * (1 - t) * t * p1.x + t * t * p2.x;
    const y = (1 - t) * (1 - t) * p0.y + 2 * (1 - t) * t * p1.y + t * t * p2.y;
    return {
      leftPct: `${(x / 780) * 100}%`,
      topPct: `${(y / 260) * 100}%`
    };
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6 text-center space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="relative flex flex-col items-center justify-center text-center gap-2 pb-4 border-b border-neutral-200 mx-auto w-full">
        {onNavigateBack && backLabel && backLabel !== 'Back to Dashboard' && (
          <div className="w-full flex justify-start sm:w-auto sm:absolute sm:left-0 sm:top-0">
            <button
              type="button"
              onClick={onNavigateBack}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 border border-neutral-200 text-neutral-800 text-xs font-semibold transition-all cursor-pointer shadow-2xs"
            >
              <ArrowLeft className="w-3.5 h-3.5 shrink-0" />
              <span>{backLabel}</span>
            </button>
          </div>
        )}
        <h1 className="font-serif-lux text-2xl sm:text-3xl font-semibold text-black tracking-tight flex items-center justify-center gap-2.5">
          <Car className="w-6 h-6 text-neutral-800" />
          <span>Ride-Share</span>
        </h1>

        <div className="grid grid-cols-2 gap-1 sm:gap-1.5 p-1 sm:p-1.5 bg-neutral-200/80 rounded-2xl mx-auto mt-2 max-w-md w-full">
          <button
            type="button"
            onClick={() => setActiveTab('book')}
            className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'book' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span>Book Rides</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!canDriveWithoutTierBlock) {
                setDriverTierErrorModal({
                  title: 'Tier 2 Verification Required to Become a Driver',
                  message: 'You cannot become a platform driver or access the driver console without Tier 2 Verification. Per community safety regulations, drivers must verify 2 Legal IDs (Government ID & Driver\'s License) and vehicle credentials.'
                });
                dispatchGlobalNotification({
                  title: '🛡️ Tier 2 Verification Required',
                  description: 'You must have Tier 2 verification (2 Legal IDs) to become a driver.',
                  type: 'security',
                  targetTab: 'settings',
                  showToast: true,
                  tone: 'alert'
                });
              }
              setActiveTab('driver');
            }}
            className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'driver' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Navigation className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Driver</span>
            {!canDriveWithoutTierBlock ? (
              <span className="px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[9px] font-bold">
                Tier 2 Req
              </span>
            ) : unreadDeliveryNotifs.length > 0 ? (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-mono font-bold">
                {unreadDeliveryNotifs.length}
              </span>
            ) : null}
          </button>
        </div>
      </div>

      {/* ==================================================== */}
      {/* TAB 1: BOOK RIDES (CUSTOMER) - 3 SUB-TABS           */}
      {/* ==================================================== */}
      {activeTab === 'book' && (
        <div className="space-y-6 max-w-5xl mx-auto">
          {/* Customer Sub-Tabs: Request a Ride | Current Ride | Ride History */}
          <div className="inline-flex flex-wrap sm:flex-nowrap items-center justify-center gap-1.5 p-1.5 bg-neutral-200/70 rounded-2xl mx-auto max-w-full">
            <button
              type="button"
              onClick={() => setBookSubTab('request')}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                bookSubTab === 'request' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>Request a Ride</span>
            </button>
            <button
              type="button"
              onClick={() => setBookSubTab('in_person')}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                bookSubTab === 'in_person' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <QrCode className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>In-Person Ride Pay</span>
            </button>
            <button
              type="button"
              onClick={() => setBookSubTab('current')}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                bookSubTab === 'current' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Map className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Current Ride</span>
            </button>
            <button
              type="button"
              onClick={() => setBookSubTab('history')}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                bookSubTab === 'history' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <History className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>Ride History</span>
            </button>
          </div>

          {/* Sub-Tab 1: Request a Ride */}
          {bookSubTab === 'request' && (
            <div className="max-w-xl mx-auto text-left">
              <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-center">
                <h2 className="font-serif-lux text-xl sm:text-2xl font-semibold text-black tracking-tight flex items-center justify-center gap-2 text-center">
                  <Compass className="w-5 h-5 text-indigo-600" />
                  <span>Request a Sovereign Ride</span>
                </h2>

                <form onSubmit={handleBookRide} className="space-y-5 text-center">
                  {/* Pickup Location with Current Standing Location + Probable Address Suggestions */}
                  <div className="space-y-2" ref={pickupBoxRef}>
                    <div className="flex flex-col items-center justify-center gap-1 text-center">
                      <label className="text-[10px] font-bold uppercase font-mono text-neutral-500">Pickup Location</label>
                      <button
                        type="button"
                        onClick={() => {
                          setPickupLocation('Zurich Freeport Vault 4B, 8048 Zürich');
                          setPickupSuggestionsOpen(false);
                        }}
                        className="text-[11px] font-bold text-indigo-600 hover:underline cursor-pointer inline-flex items-center justify-center gap-1"
                      >
                        <MapPin className="w-3 h-3" />
                        <span>Use Current Standing Location</span>
                      </button>
                    </div>
                    <div className="relative">
                      <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-600 pointer-events-none" />
                      <input
                        type="text"
                        value={pickupLocation}
                        onFocus={() => {
                          setPickupSuggestionsOpen(true);
                          setPickupHighlightIdx(-1);
                        }}
                        onChange={(e) => {
                          setPickupLocation(e.target.value);
                          setPickupSuggestionsOpen(true);
                          setPickupHighlightIdx(-1);
                        }}
                        onKeyDown={(e) => {
                          if (!pickupSuggestionsOpen || pickupSuggestions.length === 0) return;
                          if (e.key === 'ArrowDown') {
                            e.preventDefault();
                            setPickupHighlightIdx(prev => (prev + 1) % pickupSuggestions.length);
                          } else if (e.key === 'ArrowUp') {
                            e.preventDefault();
                            setPickupHighlightIdx(prev => (prev <= 0 ? pickupSuggestions.length - 1 : prev - 1));
                          } else if (e.key === 'Enter' && pickupHighlightIdx >= 0) {
                            e.preventDefault();
                            setPickupLocation(pickupSuggestions[pickupHighlightIdx].address);
                            setPickupSuggestionsOpen(false);
                          } else if (e.key === 'Escape') {
                            setPickupSuggestionsOpen(false);
                          }
                        }}
                        placeholder="Start typing street, hub, or landmark for suggestions..."
                        required
                        autoComplete="off"
                        className="w-full px-10 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 text-center outline-none focus:border-indigo-500"
                      />
                      {pickupLocation && (
                        <button
                          type="button"
                          onClick={() => {
                            setPickupLocation('');
                            setPickupSuggestionsOpen(true);
                          }}
                          aria-label="Clear pickup address"
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {pickupSuggestionsOpen && pickupSuggestions.length > 0 && (
                        <div className="absolute z-30 left-0 right-0 mt-1.5 bg-white border border-neutral-200 rounded-2xl shadow-xl overflow-hidden max-h-60 overflow-y-auto text-left">
                          <div className="px-3 py-1.5 bg-neutral-50 border-b border-neutral-100 text-[10px] font-mono font-bold text-neutral-500 uppercase flex items-center justify-between">
                            <span>Probable Pickup Addresses</span>
                            <span>{pickupSuggestions.length} matches</span>
                          </div>
                          {pickupSuggestions.map((sugg: AddressSuggestion, idx: number) => (
                            <button
                              key={sugg.id}
                              type="button"
                              onMouseDown={(e) => {
                                e.preventDefault();
                                setPickupLocation(sugg.address);
                                setPickupSuggestionsOpen(false);
                              }}
                              className={`w-full text-left px-3.5 py-2.5 flex items-start gap-2.5 border-b border-neutral-100 last:border-b-0 transition-colors cursor-pointer ${
                                pickupHighlightIdx === idx ? 'bg-indigo-50' : 'hover:bg-neutral-50'
                              }`}
                            >
                              <MapPin className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                              <div className="min-w-0 flex-1">
                                <p className="text-xs font-bold text-neutral-900 truncate">{sugg.address}</p>
                                <p className="text-[10px] text-neutral-500 truncate">{sugg.label} · {sugg.district}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Dropoff Destination Address with Probable Address Suggestions */}
                  <div className="space-y-2" ref={dropoffBoxRef}>
                    <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block text-center">
                      Dropoff Destination Address (Valid Address Required)
                    </label>
                    <div className="relative">
                      <Navigation className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-600 pointer-events-none" />
                      <input
                        type="text"
                        value={dropoffLocation}
                        onFocus={() => {
                          setDropoffSuggestionsOpen(true);
                          setDropoffHighlightIdx(-1);
                        }}
                        onChange={(e) => {
                          setDropoffLocation(e.target.value);
                          setDropoffSuggestionsOpen(true);
                          setDropoffHighlightIdx(-1);
                        }}
                        onKeyDown={(e) => {
                          if (!dropoffSuggestionsOpen || dropoffSuggestions.length === 0) return;
                          if (e.key === 'ArrowDown') {
                            e.preventDefault();
                            setDropoffHighlightIdx(prev => (prev + 1) % dropoffSuggestions.length);
                          } else if (e.key === 'ArrowUp') {
                            e.preventDefault();
                            setDropoffHighlightIdx(prev => (prev <= 0 ? dropoffSuggestions.length - 1 : prev - 1));
                          } else if (e.key === 'Enter' && dropoffHighlightIdx >= 0) {
                            e.preventDefault();
                            setDropoffLocation(dropoffSuggestions[dropoffHighlightIdx].address);
                            setDropoffSuggestionsOpen(false);
                          } else if (e.key === 'Escape') {
                            setDropoffSuggestionsOpen(false);
                          }
                        }}
                        placeholder="Start typing destination street or landmark for suggestions..."
                        required
                        autoComplete="off"
                        className="w-full px-10 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 text-center outline-none focus:border-indigo-500"
                      />
                      {dropoffLocation && (
                        <button
                          type="button"
                          onClick={() => {
                            setDropoffLocation('');
                            setDropoffSuggestionsOpen(true);
                          }}
                          aria-label="Clear dropoff address"
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {dropoffSuggestionsOpen && dropoffSuggestions.length > 0 && (
                        <div className="absolute z-30 left-0 right-0 mt-1.5 bg-white border border-neutral-200 rounded-2xl shadow-xl overflow-hidden max-h-60 overflow-y-auto text-left">
                          <div className="px-3 py-1.5 bg-neutral-50 border-b border-neutral-100 text-[10px] font-mono font-bold text-neutral-500 uppercase flex items-center justify-between">
                            <span>Probable Dropoff Addresses</span>
                            <span>{dropoffSuggestions.length} matches</span>
                          </div>
                          {dropoffSuggestions.map((sugg: AddressSuggestion, idx: number) => (
                            <button
                              key={sugg.id}
                              type="button"
                              onMouseDown={(e) => {
                                e.preventDefault();
                                setDropoffLocation(sugg.address);
                                setDropoffSuggestionsOpen(false);
                              }}
                              className={`w-full text-left px-3.5 py-2.5 flex items-start gap-2.5 border-b border-neutral-100 last:border-b-0 transition-colors cursor-pointer ${
                                dropoffHighlightIdx === idx ? 'bg-emerald-50' : 'hover:bg-neutral-50'
                              }`}
                            >
                              <Navigation className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <div className="min-w-0 flex-1">
                                <p className="text-xs font-bold text-neutral-900 truncate">{sugg.address}</p>
                                <p className="text-[10px] text-neutral-500 truncate">{sugg.label} · {sugg.district}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Live Estimated Route Preview */}
                  {pickupLocation.trim() && dropoffLocation.trim() && (
                    <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-wrap items-center justify-center gap-3 text-xs font-mono">
                      <div className="text-neutral-700">
                        <span className="font-bold text-neutral-900">Route Estimate:</span>{' '}
                        {previewRoute.distanceMiles} miles · ~{previewRoute.estimatedMinutes} mins
                      </div>
                      <span className="text-indigo-700 font-bold">
                        {previewRoute.steps.length} Turn Steps
                      </span>
                    </div>
                  )}

                  {/* Search & Choose Final Wallet Currencies to Pay (Up to 5) */}
                  <div className="space-y-2 pt-2 border-t border-neutral-100 text-left">
                    <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                      Search &amp; Choose Final Wallet Payment Currencies (Up to 5)
                    </label>


                    {possessedFinalCoins.length === 0 ? (
                      <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 space-y-1 text-center">
                        <p className="text-xs font-extrabold">There&apos;s not enough Final money</p>
                        <p className="text-[11px]">
                          You do not possess any Final coins in your Final Wallet with a positive balance to pay for this ride.
                        </p>
                      </div>
                    ) : (
                      <>
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                          <input
                            type="text"
                            value={customerCurrencySearch}
                            onChange={(e) => setCustomerCurrencySearch(e.target.value)}
                            placeholder="Search your Final Wallet currencies (e.g. AFNL, VANC)..."
                            className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
                          {possessedFinalCoins
                            .filter(c =>
                              c.symbol.toLowerCase().includes(customerCurrencySearch.toLowerCase()) ||
                              c.name.toLowerCase().includes(customerCurrencySearch.toLowerCase())
                            )
                            .map(coin => {
                              const curr = coin.symbol;
                              const isSelected = rideRequestCurrencies.includes(curr);
                              const atMaxCap = !isSelected && rideRequestCurrencies.length >= 5;
                              return (
                                <button
                                  key={curr}
                                  type="button"
                                  disabled={atMaxCap}
                                  onClick={() => handleToggleRideCurrencySlot(curr)}
                                  className={`p-2 rounded-xl text-xs font-bold border transition-all cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed flex flex-col items-center justify-center tabular-nums ${
                                    isSelected
                                      ? 'bg-emerald-50 border-emerald-500 text-emerald-950'
                                      : 'bg-neutral-50 border-neutral-200 text-neutral-600 hover:border-emerald-300'
                                  }`}
                                >
                                  <span className="whitespace-nowrap">{curr} {isSelected ? '✓' : ''}</span>
                                  <span className="text-[10px] font-mono font-normal opacity-80 whitespace-nowrap">
                                    Bal: {Number(coin.balance).toLocaleString()}
                                  </span>
                                </button>
                              );
                            })}
                        </div>
                        <p className="text-[10px] text-neutral-500 text-center font-mono pt-0.5 tabular-nums">
                          Selected ({activeRideFinalCoins.length}/5):{' '}
                          <strong className="text-emerald-800">
                            {activeRideFinalCoins.map(c => c.symbol).join(', ')}
                          </strong>{' '}
                          (Combined Available: {selectedFinalCombinedBalance.toLocaleString()})
                        </p>
                      </>
                    )}
                  </div>

                  {/* Vehicle Type & Vehicle Class Selection — Car, Auto Rickshaw, Motor Bike */}
                  <div className="space-y-3 pt-2 border-t border-neutral-100 text-center">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block text-center">
                        Vehicle Type ({availableVehiclePool.length} {availableVehiclePool.length === 1 ? 'vehicle' : 'vehicles'} available)
                      </label>
                      {availableVehicleTypes.length > 0 && (
                        <div className="flex flex-wrap items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedVehicleType('All')}
                            className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer whitespace-nowrap ${
                              selectedVehicleType === 'All'
                                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                                : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                            }`}
                          >
                            All Types
                          </button>
                          {availableVehicleTypes.map(vType => (
                            <button
                              key={vType}
                              type="button"
                              onClick={() => setSelectedVehicleType(vType)}
                              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer whitespace-nowrap ${
                                selectedVehicleType === vType
                                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                                  : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                              }`}
                            >
                              {vType}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block text-center">
                        Available Vehicles &amp; Class (Tap Any Vehicle to Inspect Info, Photos &amp; Videos)
                      </label>
                      {filteredAvailableVehicles.length === 0 ? (
                        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold text-center">
                          No vehicles are currently available for this selection.
                        </div>
                      ) : (
                        <div className="flex flex-col gap-2.5 w-full">
                          {filteredAvailableVehicles.map(v => {
                            const estFare =
                              Math.round(Math.max(8, previewRoute.distanceMiles * v.mult * (ratePerMile / 6)) * 10) / 10;
                            const isSelected = selectedVehicle?.id === v.id;
                            const isExpanded = expandedVehicleId === v.id;
                            const vDriverHandle = `@${v.driverName.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
                            const driverSavedCoupons = getApplicableSavedCoupons(userId, {
                              category: 'ride_share',
                              channel: 'online',
                              subtotal: estFare,
                              driverId: v.id,
                              driverName: v.driverName,
                              driverHandle: vDriverHandle,
                            });
                            const handleVehicleCardToggle = () => {
                              if (selectedVehicle?.id !== v.id) {
                                setOptedOutRideCouponVehicleId(null);
                                setAppliedRideCoupon(null);
                                setRideCouponFeedback(null);
                              }
                              setSelectedVehicleId(v.id);
                              setSelectedClass(v.vehicleClass);
                              setExpandedVehicleId(prev => (prev === v.id ? null : v.id));
                            };

                            return (
                              <div
                                key={v.id}
                                role="button"
                                tabIndex={0}
                                aria-expanded={isExpanded}
                                onClick={handleVehicleCardToggle}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    handleVehicleCardToggle();
                                  }
                                }}
                                className={`w-full p-3.5 rounded-2xl border text-center transition-all cursor-pointer select-none ${
                                  isSelected
                                    ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 shadow-xs'
                                    : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                                }`}
                              >
                                <div className="flex flex-col items-center justify-center gap-1.5">
                                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                                    <span className="inline-block px-2 py-0.5 rounded-md bg-white border border-neutral-200 text-[9px] font-mono font-bold uppercase text-indigo-700">
                                      {v.vehicleType} · {v.vehicleClass}
                                    </span>
                                    <span className="inline-block px-2 py-0.5 rounded-md bg-amber-50 border border-amber-200 text-[9px] font-mono font-bold text-amber-700">
                                      ★ {v.rating}
                                    </span>
                                    {driverSavedCoupons.length > 0 && (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-[9px] font-mono font-bold text-emerald-700">
                                        <Ticket className="w-2.5 h-2.5 shrink-0" />
                                        <span>{driverSavedCoupons.length} Saved {driverSavedCoupons.length === 1 ? 'Coupon' : 'Coupons'}</span>
                                      </span>
                                    )}
                                    {isSelected && (
                                      <span className="inline-block px-2 py-0.5 rounded-md bg-indigo-600 text-white text-[9px] font-mono font-bold uppercase">
                                        Selected
                                      </span>
                                    )}
                                  </div>

                                  <div className="flex flex-wrap items-center justify-center gap-2">
                                    <span className="text-xs sm:text-sm font-bold text-neutral-900">
                                      {v.carModel} ({v.carYear})
                                    </span>
                                    <span className="text-neutral-400">·</span>
                                    <div className="inline-flex items-center gap-1.5 bg-white/90 border border-neutral-200/90 rounded-full py-0.5 px-2">
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          try {
                                            window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
                                          } catch {}
                                          registerDriverProfile({ id: v.id, driverHandle: v.driverHandle, driverName: v.driverName, driverAvatar: v.driverAvatar, carModel: v.carModel });
                                          onViewUserProfile?.(v.driverHandle || v.id);
                                        }}
                                        className="relative group/avatar cursor-pointer shrink-0"
                                        title={`View Driver ${v.driverName}'s profile`}
                                      >
                                        <img
                                          src={v.driverAvatar || 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80'}
                                          alt={v.driverName}
                                          className="w-6 h-6 rounded-full object-cover border border-neutral-300 group-hover/avatar:scale-110 transition-all"
                                        />
                                        <PresenceAvatarDot
                                          identifiers={[v.id, v.driverHandle, v.driverName]}
                                          size="xs"
                                        />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          try {
                                            window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
                                          } catch {}
                                          registerDriverProfile({ id: v.id, driverHandle: v.driverHandle, driverName: v.driverName, driverAvatar: v.driverAvatar, carModel: v.carModel });
                                          onViewUserProfile?.(v.driverHandle || v.id);
                                        }}
                                        className="text-xs font-bold text-indigo-700 hover:underline cursor-pointer"
                                      >
                                        Driver: {v.driverName}
                                      </button>
                                      <PresenceStatusBadge
                                        identifiers={[v.id, v.driverHandle, v.driverName]}
                                        size="xs"
                                      />
                                    </div>
                                  </div>

                                  <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] font-mono tabular-nums">
                                    <span className="font-extrabold text-indigo-700">{estFare} {selectedCurrency}</span>
                                    <span className="text-neutral-500">· {v.etaMins} min ETA</span>
                                    <span className="text-neutral-500">· {v.media.length} {v.media.length === 1 ? 'Photo' : 'Photos'}</span>
                                    <span className="text-neutral-500">· {v.videoMedia.length} {v.videoMedia.length === 1 ? 'Video' : 'Videos'}</span>
                                  </div>

                                  {!isSelfDriver(v.id, v.driverHandle) && (
                                    <div className="flex flex-wrap items-center justify-center gap-2 pt-1" onClick={(e) => e.stopPropagation()}>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          handleMessageDriver({
                                            id: v.id,
                                            handle: v.driverHandle,
                                            name: v.driverName,
                                            avatar: v.driverAvatar,
                                            carModel: v.carModel,
                                          })
                                        }
                                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold cursor-pointer transition-colors"
                                      >
                                        <MessageSquare className="w-3 h-3 shrink-0" />
                                        <span>Message Driver</span>
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          handleVoiceCallDriver({
                                            id: v.id,
                                            handle: v.driverHandle,
                                            name: v.driverName,
                                            avatar: v.driverAvatar,
                                            carModel: v.carModel,
                                          })
                                        }
                                        title={`Voice Call ${v.driverName}`}
                                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold cursor-pointer transition-colors"
                                      >
                                        <Phone className="w-3 h-3 shrink-0" />
                                        <span>Voice Call</span>
                                      </button>
                                    </div>
                                  )}

                                  <div className="inline-flex items-center justify-center gap-1 text-[10px] font-bold text-indigo-700 pt-0.5">
                                    <span>{isExpanded ? 'Tap to collapse vehicle details' : 'Tap to inspect vehicle info, photos & videos'}</span>
                                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                  </div>
                                </div>

                                {/* Driver-Specific Relevant Coupon Picker when Driver is Selected */}
                                {isSelected && (() => {
                                  const relevantForSelectedDriver = searchRelevantCouponsForCheckout(userId, {
                                    category: 'ride_share',
                                    channel: 'online',
                                    subtotal: estFare,
                                    query: '',
                                    driverId: v.id,
                                    driverName: v.driverName,
                                    driverHandle: v.driverHandle,
                                  });
                                  return (
                                    <div
                                      onClick={(e) => e.stopPropagation()}
                                      className="mt-3 p-3 rounded-2xl bg-emerald-50/90 border border-emerald-300 shadow-xs space-y-2 text-center animate-in fade-in zoom-in-95 duration-150 cursor-default"
                                    >
                                      <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px] font-bold uppercase font-mono text-emerald-900">
                                        <Ticket className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                        <span>
                                          {driverSavedCoupons.some(d => appliedRideCoupon?.id === d.coupon.id && d.evaluation.valid)
                                            ? `Auto-Applied Driver Coupon Code for ${v.driverName} (1 Per Ride)`
                                            : `Relevant Coupon Codes for ${v.driverName} (1 Per Ride)`}
                                        </span>
                                      </div>

                                      {relevantForSelectedDriver.length > 0 ? (
                                        <div className="space-y-1.5 max-h-40 overflow-y-auto pr-0.5">
                                          {relevantForSelectedDriver.map(({ coupon, evaluation, isSaved, isMerchantOrDriverSpecific }) => {
                                            const isCouponApplied = appliedRideCoupon?.id === coupon.id && evaluation.valid;
                                            return (
                                              <div
                                                key={`drv-popup-${v.id}-${coupon.id}`}
                                                className={`w-full min-w-0 overflow-hidden p-2.5 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left ${
                                                  isCouponApplied
                                                    ? 'bg-emerald-600 text-white border-emerald-700'
                                                    : 'bg-white text-neutral-900 border-emerald-200'
                                                }`}
                                              >
                                                <div className="space-y-0.5 text-center sm:text-left w-full min-w-0 flex-1">
                                                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5">
                                                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-extrabold ${
                                                      isCouponApplied ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-900'
                                                    }`}>
                                                      {coupon.code}
                                                    </span>
                                                    <span className={`text-[10px] font-bold ${isCouponApplied ? 'text-emerald-100' : 'text-emerald-700'}`}>
                                                      {coupon.discountType === 'percentage'
                                                        ? `${coupon.discountValue}% Off${coupon.currency && coupon.currency !== 'ANY' ? ` (${coupon.currency})` : ''}`
                                                        : `${coupon.discountValue} ${coupon.currency === 'ANY' ? 'FC' : coupon.currency} Off`}
                                                    </span>
                                                    {isSaved && (
                                                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                                        isCouponApplied ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-900'
                                                      }`}>
                                                        Saved
                                                      </span>
                                                    )}
                                                    {isMerchantOrDriverSpecific && (
                                                      <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                                                        isCouponApplied ? 'bg-white/15 text-white' : 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                                                      }`}>
                                                        {v.driverName}
                                                      </span>
                                                    )}
                                                  </div>
                                                  <p className={`w-full text-[11px] font-semibold whitespace-normal break-words leading-snug ${isCouponApplied ? 'text-white' : 'text-neutral-800'}`}>
                                                    {coupon.title}
                                                  </p>
                                                  {!evaluation.valid && (
                                                    <p className="text-[10px] text-amber-700 font-semibold break-words">{evaluation.reason}</p>
                                                  )}
                                                </div>
                                                <button
                                                  type="button"
                                                  disabled={!evaluation.valid && !isCouponApplied}
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    if (isCouponApplied) {
                                                      setOptedOutRideCouponVehicleId(v.id);
                                                      setAppliedRideCoupon(null);
                                                      setRideCouponFeedback({ type: 'success', text: `Removed coupon code ${coupon.code}.` });
                                                    } else {
                                                      setOptedOutRideCouponVehicleId(null);
                                                      setAppliedRideCoupon(coupon);
                                                      setRideCouponFeedback({
                                                        type: 'success',
                                                        text: `Applied ${v.driverName}'s coupon code ${coupon.code} (-${evaluation.discountAmount.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${selectedCurrency})`,
                                                      });
                                                    }
                                                  }}
                                                  className={`px-3 py-1.5 rounded-xl text-[11px] font-bold cursor-pointer shrink-0 transition-colors disabled:opacity-45 disabled:cursor-not-allowed ${
                                                    isCouponApplied
                                                      ? 'bg-white text-emerald-800 hover:bg-emerald-50'
                                                      : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                                                  }`}
                                                >
                                                  {isCouponApplied
                                                    ? `Applied (-${evaluation.discountAmount} ${selectedCurrency}) · Remove`
                                                    : `Use Coupon Code (-${evaluation.discountAmount} ${selectedCurrency})`}
                                                </button>
                                              </div>
                                            );
                                          })}
                                        </div>
                                      ) : (
                                        <p className="text-[11px] text-neutral-600">
                                          No active relevant coupon codes found for {v.driverName} right now.
                                        </p>
                                      )}
                                    </div>
                                  );
                                })()}

                                {isExpanded && (
                                  <div className="mt-3 pt-3 border-t border-indigo-200/80 space-y-3 text-center">
                                    {/* Vehicle Details Grid (excluding Driver's License & Insurance per privacy) */}
                                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Make &amp; Model</span>
                                        <span className="font-bold text-neutral-900">{v.carModel}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Year &amp; Color</span>
                                        <span className="font-bold text-neutral-900">{v.carYear} · {v.color}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">License Plate</span>
                                        <span className="font-bold text-neutral-900 font-mono">{v.plate}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90 flex flex-col items-center justify-center">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block mb-1">Driver</span>
                                        <div className="flex items-center gap-1.5">
                                          <button
                                            type="button"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              try {
                                                window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
                                              } catch {}
                                              onViewUserProfile?.(v.driverHandle || v.id);
                                            }}
                                            className="relative group/avatar cursor-pointer shrink-0"
                                            title={`View ${v.driverName}'s profile`}
                                          >
                                            <img
                                              src={v.driverAvatar || 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80'}
                                              alt={v.driverName}
                                              className="w-5 h-5 rounded-full object-cover border border-neutral-300"
                                            />
                                            <PresenceAvatarDot identifiers={[v.id, v.driverHandle, v.driverName]} size="xs" />
                                          </button>
                                          <button
                                            type="button"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              try {
                                                window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
                                              } catch {}
                                              onViewUserProfile?.(v.driverHandle || v.id);
                                            }}
                                            className="font-bold text-indigo-700 hover:underline cursor-pointer text-[11px]"
                                          >
                                            {v.driverName} (★ {v.rating})
                                          </button>
                                        </div>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Capacity</span>
                                        <span className="font-semibold text-neutral-800">{v.seats}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Rate &amp; Arrival</span>
                                        <span className="font-bold text-emerald-700 font-mono tabular-nums">{v.ratePerMile} {selectedCurrency}/mi · {v.etaMins} min</span>
                                      </div>
                                    </div>

                                    <div className="p-2.5 rounded-xl bg-white border border-neutral-200/90 text-[11px] text-neutral-700">
                                      <span className="text-[9px] uppercase font-mono text-neutral-400 block mb-0.5">Vehicle Features</span>
                                      <span className="font-medium text-neutral-900">{v.specs}</span>
                                    </div>

                                    {/* Vehicle Photos & Videos Gallery */}
                                    {(v.media.length > 0 || v.videoMedia.length > 0) && (
                                      <div className="space-y-2">
                                        <span className="text-[10px] font-bold uppercase font-mono text-indigo-900 block">
                                          Vehicle Photos &amp; Video Walkaround
                                        </span>
                                        <div className="flex flex-wrap items-center justify-center gap-2.5">
                                          {v.media.map((photoUrl, pIdx) => (
                                            <img
                                              key={`veh-photo-${v.id}-${pIdx}`}
                                              src={photoUrl}
                                              alt={`${v.carModel} Photo ${pIdx + 1}`}
                                              referrerPolicy="no-referrer"
                                              onClick={(e) => e.stopPropagation()}
                                              className="w-40 h-24 object-cover rounded-xl border border-indigo-200 bg-neutral-900 shadow-2xs"
                                            />
                                          ))}
                                          {v.videoMedia.map((vidUrl, vIdx) => (
                                            <video
                                              key={`veh-vid-${v.id}-${vIdx}`}
                                              src={vidUrl}
                                              controls
                                              playsInline
                                              onClick={(e) => e.stopPropagation()}
                                              className="w-48 h-28 rounded-xl border border-indigo-200 bg-black shadow-2xs"
                                            />
                                          ))}
                                        </div>
                                      </div>
                                    )}

                                    <div className="pt-1 flex items-center justify-center">
                                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-white border border-indigo-200 text-[10px] font-bold text-indigo-700">
                                        <span>Tap anywhere on card to collapse</span>
                                        <ChevronUp className="w-3 h-3" />
                                      </span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Auto-Applied Driver Coupon Fare Summary (Strictly 1 coupon at a time) */}
                  {appliedRideCoupon && rideCouponDiscount > 0 && (
                    <div className="p-3 rounded-2xl bg-emerald-50/80 border border-emerald-200/90 space-y-1 text-center">
                      <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold font-mono text-emerald-900">
                        <Ticket className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>
                          Auto-Applied Driver Coupon: {appliedRideCoupon.code} (-{rideCouponDiscount} {selectedCurrency})
                        </span>
                      </div>
                      <div className="text-xs font-mono font-bold text-emerald-900">
                        Base Fare: {currentEstimatedFare} {selectedCurrency} · Discount: -{rideCouponDiscount} · Final Total: {discountedEstimatedFare} {selectedCurrency}
                      </div>
                    </div>
                  )}
                  {rideCouponFeedback && rideCouponDiscount === 0 && (
                    <p className={`text-[11px] font-semibold text-center ${rideCouponFeedback.type === 'success' ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {rideCouponFeedback.text}
                    </p>
                  )}

                  {(!hasEnoughSelectedCurrency || walletErrorMsg) && possessedFinalCoins.length > 0 && (
                    <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold text-center">
                      {walletErrorMsg
                        ? walletErrorMsg
                        : !hasEnoughAnyFinalCurrency
                          ? `There's not enough Final money across your selected Final currencies (${activeRideFinalCoins.map(c => c.symbol).join(', ')}). Combined held: ${selectedFinalCombinedBalance.toLocaleString()}, Required: ${discountedEstimatedFare} ${selectedCurrency}.`
                          : `Combined selected Final balance (${selectedFinalCombinedBalance.toLocaleString()}) is less than ${discountedEstimatedFare} ${selectedCurrency}. Select up to 5 Final Wallet coins above.`}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isBookingRide || availableVehicleClasses.length === 0 || !selectedVehicle}
                    className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md cursor-pointer disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                  >
                    {isBookingRide
                      ? 'Dispatching Nearest Driver...'
                      : !hasEnoughSelectedCurrency
                        ? "Not Enough Final Money"
                        : `Book ${(selectedVehicle?.vehicleClass || selectedClass)} (${selectedVehicle?.vehicleType || CLASS_META[selectedClass].vehicleType}) Ride (${discountedEstimatedFare} ${selectedCurrency})`}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Sub-Tab 1B: In-Person Ride Fare Settlement & Coupon */}
          {bookSubTab === 'in_person' && (() => {
            void couponsVersion;
            const parsedAgreedFare = Math.max(0, parseFloat(inPersonFareInput) || 0);
            const activeCoinCurrency = inPersonCurrency || selectedCurrency || 'AFNL';
            const inPersonEval = appliedInPersonRideCoupon
              ? evaluateCouponForOrder(appliedInPersonRideCoupon, {
                  category: 'ride_share',
                  channel: 'in_person',
                  subtotal: parsedAgreedFare,
                  driverHandle: inPersonDriverHandle,
                })
              : null;
            const inPersonDiscount = inPersonEval?.valid ? inPersonEval.discountAmount : 0;
            const netInPersonFare = Math.max(0, Math.round((parsedAgreedFare - inPersonDiscount) * 100) / 100);
            const heldCoinBal =
              possessedFinalCoins.find(c => c.symbol.toUpperCase() === activeCoinCurrency.toUpperCase())?.balance ?? 0;
            const savedInPersonCoupons = getApplicableSavedCoupons(userId, {
              category: 'ride_share',
              channel: 'in_person',
              subtotal: parsedAgreedFare,
              driverHandle: inPersonDriverHandle,
            });

            const handleSettleInPersonRide = (ev: React.FormEvent) => {
              ev.preventDefault();
              if (parsedAgreedFare <= 0) {
                setInPersonRideCouponFeedback({ type: 'error', text: 'Enter an agreed ride fare greater than 0.' });
                return;
              }
              if (heldCoinBal < netInPersonFare) {
                setInPersonRideCouponFeedback({
                  type: 'error',
                  text: `Insufficient ${activeCoinCurrency} balance (Held: ${heldCoinBal.toLocaleString()}, Due: ${netInPersonFare}).`,
                });
                return;
              }
              setIsPayingInPersonRide(true);
              const debit = applyCurrencyWalletDelta({
                userId,
                currencySymbol: activeCoinCurrency,
                delta: -netInPersonFare,
                requireSufficientBalance: true,
                utilityNote: `In-person ride settlement to ${inPersonDriverHandle}`,
              });
              if (!debit.success) {
                setIsPayingInPersonRide(false);
                setInPersonRideCouponFeedback({ type: 'error', text: debit.error || 'Wallet debit failed.' });
                return;
              }
              setUserWallet(debit.wallet);

              const cleanDriver = inPersonDriverHandle.trim().replace(/^@/, '');
              if (cleanDriver && cleanDriver !== userId) {
                applyCurrencyWalletDelta({
                  userId: cleanDriver,
                  currencySymbol: activeCoinCurrency,
                  delta: netInPersonFare,
                  utilityNote: `In-person ride payout from ${userName}`,
                });
              }

              const inPersonRideId = `ride-inperson-${Date.now()}`;
              const matchedDriver = availableVehiclePool.find(
                v => v.driverName.toLowerCase().includes(cleanDriver.toLowerCase()) || v.id.toLowerCase().includes(cleanDriver.toLowerCase())
              );
              const completedRide: RideRequest = {
                id: inPersonRideId,
                riderId: userId,
                riderName: userName,
                pickup: inPersonTripNote.trim() || 'In-Person Street Hail',
                dropoff: `Settled with ${inPersonDriverHandle.trim() || '@driver'}`,
                vehicleType: matchedDriver?.vehicleType || 'Car',
                vehicleClass: matchedDriver?.vehicleClass || 'Comfort EV',
                fare: netInPersonFare,
                currency: activeCoinCurrency,
                status: 'completed',
                driverId: matchedDriver?.id || cleanDriver || 'driver_inperson',
                driverName: matchedDriver?.driverName || inPersonDriverHandle.trim() || 'Platform Driver',
                driverCar: matchedDriver?.carModel || 'Verified Ride-Share Fleet',
                driverCarYear: matchedDriver?.carYear || '2025',
                driverPlate: matchedDriver?.plate || 'IN-PERSON',
                driverRating: matchedDriver?.rating || 4.9,
                createdAt: new Date().toISOString(),
                estimatedTime: 'In-Person Settlement',
                distance: 'Direct Hail',
                directions: ['Settled directly in-person via Final Wallet'],
              };
              const updatedRides = [completedRide, ...myRides];
              saveMyRides(updatedRides);

              const ledgerEntry = createLedgerItemFromRideShareBooking({
                rideId: inPersonRideId,
                pickup: completedRide.pickup,
                dropoff: completedRide.dropoff,
                vehicleType: completedRide.vehicleType,
                vehicleClass: completedRide.vehicleClass,
                driverName: completedRide.driverName,
                driverCar: completedRide.driverCar,
                fare: netInPersonFare,
                currency: activeCoinCurrency,
                distance: 'In-Person Hail',
                estimatedTime: 'Completed',
              });
              recordLedgerTransaction(userId, ledgerEntry);
              window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

              if (appliedInPersonRideCoupon && inPersonDiscount > 0) {
                redeemCouponForUser(userId, appliedInPersonRideCoupon.id, {
                  channel: 'in_person',
                  orderRef: inPersonRideId,
                  discountApplied: inPersonDiscount,
                  currency: activeCoinCurrency,
                });
              }

              dispatchGlobalNotification({
                title: '✅ In-Person Ride Paid!',
                description: `Paid ${netInPersonFare} ${activeCoinCurrency} to ${completedRide.driverName}${appliedInPersonRideCoupon && inPersonDiscount > 0 ? ` using coupon ${appliedInPersonRideCoupon.code} (-${inPersonDiscount})` : ''}.`,
                type: 'ride_share',
                targetTab: 'ride_share',
                amount: netInPersonFare,
                currency: activeCoinCurrency,
                showToast: true,
                tone: 'success',
              });

              setAppliedInPersonRideCoupon(null);
              setInPersonRideCouponFeedback({
                type: 'success',
                text: `Paid ${netInPersonFare} ${activeCoinCurrency} in-person and recorded to Ride History & Tax Ledger!`,
              });
              setIsPayingInPersonRide(false);
            };

            return (
              <div className="max-w-xl mx-auto">
                <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5 text-center">
                  <div className="space-y-1">
                    <h2 className="font-serif-lux text-xl font-bold text-neutral-900 flex items-center justify-center gap-2">
                      <QrCode className="w-5 h-5 text-emerald-600" />
                      <span>In-Person Ride-Share Fare Settlement</span>
                    </h2>

                  </div>

                  <form onSubmit={handleSettleInPersonRide} className="space-y-4 text-center">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase font-mono text-neutral-500 block">
                        Driver Handle or Select Active Driver
                      </label>
                      <input
                        type="text"
                        required
                        value={inPersonDriverHandle}
                        onChange={(e) => setInPersonDriverHandle(e.target.value)}
                        placeholder="@elena_vance"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-center outline-none focus:border-emerald-500"
                      />
                      {(() => {
                        const cleanInPersonHandle = inPersonDriverHandle.trim().replace(/^@/, '');
                        if (!cleanInPersonHandle) return null;
                        const matchedDrv = availableVehiclePool.find(
                          (v) =>
                            (v.driverHandle || '').toLowerCase() === cleanInPersonHandle.toLowerCase() ||
                            v.id.toLowerCase() === cleanInPersonHandle.toLowerCase()
                        );
                        const driverPayload = {
                          id: matchedDrv?.id || cleanInPersonHandle,
                          handle: matchedDrv?.driverHandle || cleanInPersonHandle,
                          name: matchedDrv?.driverName || `@${cleanInPersonHandle}`,
                          avatar: matchedDrv?.driverAvatar,
                          carModel: matchedDrv?.carModel,
                        };
                        if (isSelfDriver(driverPayload.id, driverPayload.handle)) return null;
                        return (
                          <div className="flex flex-wrap items-center justify-center gap-2 pt-1.5">
                            <button
                              type="button"
                              onClick={() => handleMessageDriver(driverPayload)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[11px] font-bold cursor-pointer transition-colors"
                            >
                              <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                              <span>Message {matchedDrv ? matchedDrv.driverName : `@${cleanInPersonHandle}`}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleVoiceCallDriver(driverPayload)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-bold cursor-pointer transition-colors"
                            >
                              <Phone className="w-3.5 h-3.5 shrink-0" />
                              <span>Voice Call Driver</span>
                            </button>
                          </div>
                        );
                      })()}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold uppercase font-mono text-neutral-500 block">
                          Agreed Ride Fare *
                        </label>
                        <input
                          type="number"
                          min="1"
                          step="any"
                          required
                          value={inPersonFareInput}
                          onChange={(e) => setInPersonFareInput(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-center outline-none focus:border-emerald-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold uppercase font-mono text-neutral-500 block">
                          Final Wallet Currency
                        </label>
                        <select
                          value={activeCoinCurrency}
                          onChange={(e) => setInPersonCurrency(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-mono font-bold text-center outline-none focus:border-emerald-500"
                        >
                          {possessedFinalCoins.length > 0 ? (
                            possessedFinalCoins.map((c) => (
                              <option key={c.symbol} value={c.symbol}>
                                {c.symbol} (Bal: {Number(c.balance || 0).toLocaleString()})
                              </option>
                            ))
                          ) : (
                            <option value="AFNL">AFNL (Bal: 0)</option>
                          )}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold uppercase font-mono text-neutral-500 block">
                        Trip Note / Pickup Landmark
                      </label>
                      <input
                        type="text"
                        value={inPersonTripNote}
                        onChange={(e) => setInPersonTripNote(e.target.value)}
                        placeholder="e.g. Bahnhofstrasse Stand #4"
                        className="w-full px-3.5 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-center outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 space-y-2.5 text-center">
                      <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold uppercase font-mono text-emerald-800">
                        <Ticket className="w-3.5 h-3.5 text-emerald-600" />
                        <span>In-Person Ride Coupon Code (1 Per Ride)</span>
                      </div>

                      {(() => {
                        const driverSpecificMatches = searchRelevantCouponsForCheckout(userId, {
                          category: 'ride_share',
                          channel: 'in_person',
                          subtotal: parsedAgreedFare,
                          query: '',
                          driverHandle: inPersonDriverHandle,
                        });
                        const allRideMatches = searchRelevantCouponsForCheckout(userId, {
                          category: 'ride_share',
                          channel: 'in_person',
                          subtotal: parsedAgreedFare,
                          query: '',
                        });

                        // Prioritize coupons matching current driver, and include all relevant ride-share coupons
                        const seenIds = new Set<string>();
                        const visibleCoupons: typeof driverSpecificMatches = [];
                        driverSpecificMatches.forEach(entry => {
                          if (!seenIds.has(entry.coupon.id)) {
                            seenIds.add(entry.coupon.id);
                            visibleCoupons.push(entry);
                          }
                        });
                        allRideMatches.forEach(entry => {
                          if (!seenIds.has(entry.coupon.id)) {
                            seenIds.add(entry.coupon.id);
                            visibleCoupons.push(entry);
                          }
                        });

                        if (visibleCoupons.length === 0 && savedInPersonCoupons.length === 0) {
                          return (
                            <p className="text-[11px] text-neutral-500">
                              No active relevant coupon codes found right now.
                            </p>
                          );
                        }

                        return (
                          <div className="space-y-1.5 max-w-md mx-auto max-h-40 overflow-y-auto pr-0.5">
                            {visibleCoupons.map(({ coupon, evaluation, isSaved }) => {
                              const selected = appliedInPersonRideCoupon?.id === coupon.id;
                              const isActiveDiscount = selected && evaluation.valid;
                              return (
                                <div
                                  key={coupon.id}
                                  className={`w-full min-w-0 overflow-hidden p-2 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left transition-colors ${
                                    isActiveDiscount
                                      ? 'bg-emerald-600 text-white border-emerald-700'
                                      : selected
                                        ? 'bg-amber-50 text-amber-950 border-amber-400'
                                        : 'bg-white text-neutral-900 border-emerald-200'
                                  }`}
                                >
                                  <div className="w-full min-w-0 flex-1 space-y-0.5">
                                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1">
                                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-extrabold ${
                                        isActiveDiscount ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-900'
                                      }`}>
                                        {coupon.code}
                                      </span>
                                      <span className={`text-[10px] font-bold ${isActiveDiscount ? 'text-emerald-100' : 'text-emerald-700'}`}>
                                        {coupon.discountType === 'percentage'
                                          ? `${coupon.discountValue}% Off${coupon.currency && coupon.currency !== 'ANY' ? ` (${coupon.currency})` : ''}`
                                          : `${coupon.discountValue} ${coupon.currency === 'ANY' ? 'FC' : coupon.currency} Off`}
                                      </span>
                                      {isSaved && (
                                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                          isActiveDiscount ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-900'
                                        }`}>
                                          Saved
                                        </span>
                                      )}
                                      <span className={`text-[9px] font-mono ${isActiveDiscount ? 'text-emerald-100' : 'text-neutral-500'}`}>
                                        {coupon.issuerName}
                                      </span>
                                    </div>
                                    <p className={`w-full text-[10px] font-semibold whitespace-normal break-words leading-snug ${isActiveDiscount ? 'text-white' : 'text-neutral-800'}`}>
                                      {coupon.title}
                                    </p>
                                    {!evaluation.valid && (
                                      <p className={`text-[9px] font-semibold break-words ${isActiveDiscount ? 'text-emerald-100' : 'text-amber-700'}`}>
                                        {evaluation.reason}
                                      </p>
                                    )}
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (selected) {
                                        setAppliedInPersonRideCoupon(null);
                                        setInPersonRideCouponFeedback(null);
                                      } else {
                                        if (coupon.issuerHandle) {
                                          setInPersonDriverHandle(coupon.issuerHandle);
                                        }
                                        setAppliedInPersonRideCoupon(coupon);
                                        setInPersonRideCouponFeedback({
                                          type: 'success',
                                          text: evaluation.valid
                                            ? `Applied coupon code ${coupon.code} (-${evaluation.discountAmount} ${activeCoinCurrency})`
                                            : `Selected coupon code ${coupon.code}`,
                                        });
                                      }
                                    }}
                                    className={`px-2.5 py-1 rounded-xl text-[10px] font-bold cursor-pointer shrink-0 ${
                                      isActiveDiscount
                                        ? 'bg-white text-emerald-800 hover:bg-emerald-50'
                                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                                    }`}
                                  >
                                    {selected ? 'Selected ✓' : 'Use Code'}
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        );
                      })()}

                      {appliedInPersonRideCoupon && (
                        <button
                          type="button"
                          onClick={() => {
                            setAppliedInPersonRideCoupon(null);
                            setInPersonRideCouponFeedback(null);
                          }}
                          className="px-2.5 py-1 rounded-xl bg-rose-50 text-rose-700 text-[10px] font-bold cursor-pointer"
                        >
                          Remove Coupon Code ({appliedInPersonRideCoupon.code})
                        </button>
                      )}
                      {appliedInPersonRideCoupon && inPersonEval && !inPersonEval.valid && (
                        <p className="text-[11px] font-semibold text-amber-800">{inPersonEval.reason}</p>
                      )}
                      {inPersonRideCouponFeedback && (
                        <p className={`text-[11px] font-semibold ${inPersonRideCouponFeedback.type === 'success' ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {inPersonRideCouponFeedback.text}
                        </p>
                      )}
                    </div>

                    <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-1 text-xs font-mono">
                      <div className="flex items-center justify-center gap-2 text-neutral-600">
                        <span>Agreed Fare:</span>
                        <span className="font-bold text-neutral-900">{parsedAgreedFare.toLocaleString()} {activeCoinCurrency}</span>
                      </div>
                      {inPersonDiscount > 0 && appliedInPersonRideCoupon && (
                        <div className="flex items-center justify-center gap-2 text-emerald-700 font-bold">
                          <span>Coupon ({appliedInPersonRideCoupon.code}):</span>
                          <span>-{inPersonDiscount.toLocaleString()} {activeCoinCurrency}</span>
                        </div>
                      )}
                      <div className="flex items-center justify-center gap-2 pt-1.5 border-t border-neutral-200 text-sm font-extrabold text-emerald-700">
                        <span>Final In-Person Settlement:</span>
                        <span>{netInPersonFare.toLocaleString()} {activeCoinCurrency}</span>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isPayingInPersonRide || parsedAgreedFare <= 0 || heldCoinBal < netInPersonFare}
                      className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold shadow-md cursor-pointer disabled:opacity-50"
                    >
                      {heldCoinBal < netInPersonFare
                        ? `Insufficient ${activeCoinCurrency} Balance`
                        : `Pay ${netInPersonFare} ${activeCoinCurrency} In-Person`}
                    </button>
                  </form>
                </div>
              </div>
            );
          })()}

          {/* Sub-Tab 2: Current Ride */}
          {bookSubTab === 'current' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto text-left">
              {!activeRide || !customerRoute ? (
                <div className="p-12 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-3">
                  <Car className="w-10 h-10 text-neutral-400 mx-auto" />
                  <p className="text-base font-bold text-neutral-900">No Active Ride</p>
                  <p className="text-xs text-neutral-500">Book a ride from the "Request a Ride" tab to view live GPS tracking and turn-by-turn directions here.</p>
                </div>
              ) : (() => {
                const steps = customerRoute.steps;
                const clampedIdx = Math.min(customerNavStepIdx, steps.length - 1);
                const currentStep = steps[clampedIdx];
                const markerPos = getBezierMarkerPos(clampedIdx, steps.length);
                const elapsedMs = Date.now() - new Date(activeRide.createdAt).getTime();
                const freeSecsLeft = Math.max(0, Math.ceil((120000 - elapsedMs) / 1000));

                return (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-center justify-between pb-2 border-b border-neutral-200 gap-2 text-center sm:text-left">
                    <div>
                      <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                        <Map className="w-4 h-4 text-emerald-600" />
                        Live End-to-End GPS Map &amp; Turn-by-Turn Directions
                      </h3>
                      <p className="text-xs text-neutral-500 font-mono">
                        Estimated: {activeRide.estimatedTime || `~${customerRoute.estimatedMinutes} mins`} ({activeRide.distance || `${customerRoute.distanceMiles} miles`})
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold font-mono">
                        {activeRide.fare} {activeRide.currency}
                      </span>
                      <button
                        type="button"
                        onClick={() => initiateCancelRide(activeRide.id)}
                        className="px-3 py-1 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                      >
                        {freeSecsLeft > 0 ? `Cancel Free (${freeSecsLeft}s)` : 'Cancel Ride'}
                      </button>
                    </div>
                  </div>

                  {/* Interactive Map Canvas */}
                  <div className="relative w-full h-72 rounded-2xl bg-neutral-900 overflow-hidden border border-neutral-800">
                    <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#4f46e5_1px,transparent_1px)] [background-size:24px_24px]"></div>
                    <svg viewBox="0 0 780 260" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                      <path d="M 80 190 Q 390 40, 700 90" fill="none" stroke="#6366f1" strokeWidth="4" strokeDasharray="8 6" />
                    </svg>
                    <div className="absolute left-[10%] bottom-[22%] -translate-x-1/2 flex flex-col items-center max-w-[38%]">
                      <div className="px-2.5 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-bold font-mono shadow-md truncate max-w-full">
                        Pickup: {activeRide.pickup}
                      </div>
                      <div className="w-3.5 h-3.5 rounded-full bg-indigo-500 border-2 border-white mt-1 shadow-md"></div>
                    </div>
                    <div className="absolute right-[10%] top-[28%] translate-x-1/2 flex flex-col items-center max-w-[38%]">
                      <div className="px-2.5 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-bold font-mono shadow-md truncate max-w-full">
                        Dropoff: {activeRide.dropoff}
                      </div>
                      <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white mt-1 shadow-md"></div>
                    </div>
                    <div
                      className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700 flex flex-col items-center z-10"
                      style={{ left: markerPos.leftPct, top: markerPos.topPct }}
                    >
                      <div className="bg-white text-neutral-900 px-2.5 py-1 rounded-lg text-[10px] font-bold font-mono shadow-xl flex items-center gap-1 border border-neutral-200 whitespace-nowrap">
                        <Car className="w-3.5 h-3.5 text-indigo-600" />
                        <span>{clampedIdx === steps.length - 1 ? 'Arrived at Destination' : `${activeRide.driverName || 'Driver'} En Route`}</span>
                      </div>
                      <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg mt-1 border-2 border-white">
                        <Car className="w-4 h-4" />
                      </div>
                    </div>

                    {/* Active Instruction Banner */}
                    <div className="absolute bottom-3 left-3 right-3 bg-black/75 backdrop-blur-md px-3.5 py-2.5 rounded-xl border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-white">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-indigo-400">{getManeuverIcon(currentStep.maneuver)}</span>
                        <span className="font-mono font-bold truncate">{currentStep.instruction}</span>
                      </div>
                      <span className="text-emerald-400 font-mono font-bold shrink-0">
                        Step {clampedIdx + 1}/{steps.length} · {currentStep.distanceLabel}
                      </span>
                    </div>
                  </div>

                  {/* Route details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-neutral-50 p-4 rounded-2xl border border-neutral-200 text-xs">
                    <div>
                      <span className="text-[10px] uppercase font-mono text-neutral-400 block font-bold">Pickup Location</span>
                      <p className="font-bold text-neutral-900">{activeRide.pickup}</p>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-mono text-neutral-400 block font-bold">Dropoff Destination</span>
                      <p className="font-bold text-neutral-900">{activeRide.dropoff}</p>
                    </div>
                  </div>

                  {/* Driver info & Car Media */}
                  <div className="p-5 rounded-2xl bg-indigo-50 border border-indigo-200 space-y-4 text-left">
                    <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4">
                      <div className="flex items-center gap-3.5">
                        <button
                          type="button"
                          onClick={() => {
                            try {
                              window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
                            } catch {}
                            onViewUserProfile?.(activeRide.driverHandle || activeRide.driverId || 'driver-hans');
                          }}
                          className="relative group/avatar cursor-pointer shrink-0"
                          title={`View Driver ${activeRide.driverName || 'Driver'}'s profile`}
                        >
                          <img
                            src={activeRide.driverAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'}
                            alt={activeRide.driverName || 'Driver'}
                            className="w-12 h-12 rounded-full object-cover border-2 border-indigo-300 shadow-sm group-hover/avatar:scale-105 transition-all"
                          />
                          <PresenceAvatarDot
                            identifiers={[activeRide.driverId, activeRide.driverHandle, activeRide.driverName]}
                            size="sm"
                          />
                        </button>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            {onViewUserProfile ? (
                              <button
                                type="button"
                                onClick={() => {
                                  try {
                                    window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
                                  } catch {}
                                  onViewUserProfile(activeRide.driverHandle || activeRide.driverId || 'driver-hans');
                                }}
                                className="text-sm font-bold text-indigo-700 hover:underline flex items-center gap-1 cursor-pointer"
                              >
                                <span>{activeRide.driverName || 'Hansruedi Keller'}</span>
                                <ExternalLink className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <span className="text-sm font-bold text-neutral-900">{activeRide.driverName || 'Hansruedi Keller'}</span>
                            )}
                            <PresenceStatusBadge
                              identifiers={[activeRide.driverId, activeRide.driverHandle, activeRide.driverName]}
                              size="xs"
                            />
                            <span className="text-xs text-amber-600 font-bold px-2 py-0.5 rounded bg-amber-100/80">★ {activeRide.driverRating || 4.96}</span>
                          </div>
                          <p className="text-xs text-neutral-800 font-semibold mt-1">
                            {activeRide.driverCar || 'Tesla Model Y Sovereign'} ({activeRide.driverCarYear || '2025'}) ·{' '}
                            <span className="text-indigo-700">{activeRide.vehicleType || CLASS_META[activeRide.vehicleClass]?.vehicleType || 'Car'} ({activeRide.vehicleClass})</span>
                          </p>
                          <p className="text-[11px] text-neutral-600 font-mono">
                            License Plate: {activeRide.driverPlate || 'ZH-884-992'}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {!isSelfDriver(activeRide.driverId, activeRide.driverHandle) && (
                          <>
                            <button
                              type="button"
                              onClick={() =>
                                handleMessageDriver({
                                  id: activeRide.driverId,
                                  handle: activeRide.driverHandle,
                                  name: activeRide.driverName || 'Hansruedi Keller',
                                  avatar: activeRide.driverAvatar,
                                  carModel: activeRide.driverCar,
                                })
                              }
                              className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                              <span>Message</span>
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleVoiceCallDriver({
                                  id: activeRide.driverId,
                                  handle: activeRide.driverHandle,
                                  name: activeRide.driverName || 'Hansruedi Keller',
                                  avatar: activeRide.driverAvatar,
                                  carModel: activeRide.driverCar,
                                })
                              }
                              title={`Voice Call ${activeRide.driverName || 'Driver'}`}
                              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                            >
                              <Phone className="w-3.5 h-3.5 shrink-0" />
                              <span>Voice Call</span>
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => setRatingModalRideId(activeRide.id)}
                          className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shrink-0 text-center cursor-pointer"
                        >
                          Complete &amp; Rate Ride
                        </button>
                      </div>
                    </div>

                    {/* Car Photos & Videos View for Customer (excluding DL & Insurance per privacy) */}
                    {((activeRide.driverPhotos && activeRide.driverPhotos.length > 0) ||
                      (activeRide.driverVideos && activeRide.driverVideos.length > 0)) && (
                      <div className="space-y-2 pt-3 border-t border-indigo-100">
                        <h5 className="text-[11px] font-bold uppercase font-mono text-indigo-900">Verified Vehicle Photos &amp; Video Media</h5>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {(activeRide.driverPhotos || []).map((photoUrl, pIdx) => (
                            <div key={`act-p-${pIdx}`} className="aspect-video rounded-xl bg-neutral-900 overflow-hidden relative border border-indigo-200">
                              <img
                                src={photoUrl}
                                alt={`Car Photo ${pIdx + 1}`}
                                referrerPolicy="no-referrer"
                                onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                          {(activeRide.driverVideos || []).map((vidUrl, vIdx) => (
                            <div key={`act-v-${vIdx}`} className="aspect-video rounded-xl bg-black overflow-hidden relative border border-indigo-200">
                              <video
                                src={vidUrl}
                                controls
                                playsInline
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Turn-by-Turn Map Directions (Interactive) */}
                  <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h4 className="text-xs font-bold text-neutral-800 uppercase font-mono flex items-center gap-1.5">
                        <ListOrdered className="w-4 h-4 text-indigo-600" />
                        Turn-by-Turn Map Directions
                      </h4>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setIsAutoNavigatingCustomer(prev => !prev)}
                          className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-800 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                        >
                          {isAutoNavigatingCustomer ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                          <span>{isAutoNavigatingCustomer ? 'Pause Live GPS' : 'Simulate Route'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setCustomerNavStepIdx(prev => Math.max(0, prev - 1))}
                          disabled={clampedIdx === 0}
                          className="p-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 disabled:opacity-40 cursor-pointer"
                          aria-label="Previous direction step"
                        >
                          <ChevronLeft className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setCustomerNavStepIdx(prev => Math.min(steps.length - 1, prev + 1))}
                          disabled={clampedIdx >= steps.length - 1}
                          className="p-1 rounded-lg bg-indigo-600 text-white disabled:opacity-40 cursor-pointer"
                          aria-label="Next direction step"
                        >
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <ol className="space-y-2 text-xs font-mono">
                      {steps.map((step, idx) => {
                        const isDone = idx < clampedIdx;
                        const isActive = idx === clampedIdx;
                        return (
                          <li
                            key={step.id}
                            onClick={() => setCustomerNavStepIdx(idx)}
                            className={`p-2.5 rounded-xl border flex items-start justify-between gap-3 cursor-pointer transition-colors ${
                              isActive
                                ? 'bg-indigo-50 border-indigo-300 text-indigo-950'
                                : isDone
                                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                                  : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex items-start gap-2.5 min-w-0">
                              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 ${
                                isActive ? 'bg-indigo-600 text-white' : isDone ? 'bg-emerald-600 text-white' : 'bg-neutral-200 text-neutral-700'
                              }`}>
                                {isDone ? '✓' : idx + 1}
                              </span>
                              <div className="min-w-0">
                                <p className="font-bold flex items-center gap-1.5">
                                  {getManeuverIcon(step.maneuver)}
                                  <span>{step.instruction}</span>
                                </p>
                                <p className="text-[11px] opacity-80 font-sans mt-0.5">{step.detail}</p>
                              </div>
                            </div>
                            <span className="text-[11px] font-bold shrink-0 tabular-nums">{step.distanceLabel}</span>
                          </li>
                        );
                      })}
                    </ol>
                  </div>
                </div>
                );
              })()}
            </div>
          )}

          {/* Sub-Tab 3: Ride History */}
          {bookSubTab === 'history' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-4 max-w-4xl mx-auto text-left">
              <h3 className="text-sm font-bold text-neutral-900 text-center flex items-center justify-center gap-2">
                <History className="w-4 h-4 text-emerald-600" />
                Complete Ride History &amp; Receipts ({myRides.length})
              </h3>

              {myRides.length === 0 ? (
                <div className="p-8 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                  <p className="text-xs font-bold text-neutral-800">No past ride records found.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {myRides.map(ride => (
                    <div key={ride.id} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="space-y-1 text-center sm:text-left">
                        <div className="flex items-center gap-2 justify-center sm:justify-start">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                            ride.status === 'cancelled' ? 'bg-rose-100 text-rose-900' : 'bg-indigo-100 text-indigo-900'
                          }`}>
                            {ride.status.toUpperCase()}
                          </span>
                          <span className="text-xs font-bold text-neutral-900">
                            Ride #{ride.id.slice(-6)} • {ride.vehicleType || CLASS_META[ride.vehicleClass]?.vehicleType || 'Car'} ({ride.vehicleClass})
                          </span>
                        </div>
                        <p className="text-xs text-neutral-700">From {ride.pickup} → {ride.dropoff}</p>
                        <p className="text-[11px] text-neutral-500 font-mono">Date: {new Date(ride.createdAt).toLocaleString()}</p>
                        {ride.rating && (
                          <p className="text-[11px] text-amber-600 font-bold">★ {ride.rating}/5 - "{ride.comment}"</p>
                        )}
                      </div>
                      <div className="text-center sm:text-right font-mono flex flex-col items-center sm:items-end gap-1.5">
                        <p className="text-sm font-extrabold text-emerald-700">{ride.fare} {ride.currency}</p>
                        <div className="flex flex-wrap items-center justify-center sm:justify-end gap-1.5">
                          {(ride.driverId || ride.driverHandle || ride.driverName) &&
                            !isSelfDriver(ride.driverId, ride.driverHandle) && (
                              <>
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleMessageDriver({
                                      id: ride.driverId,
                                      handle: ride.driverHandle,
                                      name: ride.driverName,
                                      avatar: ride.driverAvatar,
                                      carModel: ride.driverCar,
                                    })
                                  }
                                  className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[10px] font-bold flex items-center gap-1 cursor-pointer font-sans"
                                >
                                  <MessageSquare className="w-3 h-3 shrink-0" />
                                  <span>Message</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleVoiceCallDriver({
                                      id: ride.driverId,
                                      handle: ride.driverHandle,
                                      name: ride.driverName,
                                      avatar: ride.driverAvatar,
                                      carModel: ride.driverCar,
                                    })
                                  }
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold flex items-center gap-1 cursor-pointer font-sans"
                                >
                                  <Phone className="w-3 h-3 shrink-0" />
                                  <span>Voice Call</span>
                                </button>
                              </>
                            )}
                          <button
                            type="button"
                            onClick={() => setRatingModalRideId(ride.id)}
                            className="px-2.5 py-1 rounded-lg bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-[10px] font-bold flex items-center gap-1 cursor-pointer font-sans"
                          >
                            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                            {ride.rating ? 'Update Rating & Comment' : 'Rate Driver'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 2: DRIVER (WITH 3 NESTED SUB-TABS)               */}
      {/* ==================================================== */}
      {activeTab === 'driver' && !canDriveWithoutTierBlock ? (
        <div className="max-w-2xl mx-auto p-6 sm:p-10 bg-white border border-rose-200 rounded-3xl shadow-sm text-center space-y-6 my-8 animate-in fade-in zoom-in-95">
          <div className="w-16 h-16 rounded-3xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center mx-auto shadow-xs">
            <Car className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-rose-100 text-rose-900 uppercase tracking-wider">
              Verification Required
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              Tier 2 Verification Required to Become a Driver
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto leading-relaxed">
              You cannot become a driver or access the driver dispatch console without Tier 2 Verification. In accordance with community safety and commercial transport standards, drivers must verify 2 Legal IDs (Government ID &amp; Driver&apos;s License) and vehicle details before accepting passenger rides or deliveries.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-left max-w-md mx-auto space-y-2.5 text-xs">
            <div className="flex items-center justify-between font-bold text-slate-900">
              <span>Your Current Status:</span>
              <span className="px-2 py-0.5 rounded-md bg-white border border-amber-300 text-amber-800">
                {userTier === 0 ? 'Tier 0 · Unverified' : 'Tier 1 · 1 Legal ID'}
              </span>
            </div>
            <div className="flex items-center justify-between font-bold text-slate-900">
              <span>Required Status:</span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold">
                Tier 2 · Dual Legal ID (Free $0/mo)
              </span>
            </div>
            <div className="pt-1 text-[11px] text-amber-800 leading-relaxed">
              ✓ Requires: 1 Primary ID (Driver&apos;s License) + 1 Secondary ID (Passport/National ID)
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => onOpenVerificationModal?.(2)}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Complete Tier 2 Verification (2 Legal IDs)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('book')}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
            >
              Back to Book Rides
            </button>
          </div>
        </div>
      ) : activeTab === 'driver' && (
        <div className="space-y-6 max-w-5xl mx-auto">
          {/* Driver 3 Nested Sub-Tabs (intrinsic widths so badge & labels always fit cleanly) */}
          <div className="inline-flex flex-wrap sm:flex-nowrap items-center justify-center gap-1.5 p-1.5 bg-neutral-200/80 rounded-2xl mx-auto max-w-full">
            <button
              type="button"
              onClick={() => setDriverSubTab('ride_dispatches')}
              className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                driverSubTab === 'ride_dispatches' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Navigation className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>Ride Dispatches</span>
            </button>

            <button
              type="button"
              onClick={() => setDriverSubTab('delivery_dispatches')}
              className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                driverSubTab === 'delivery_dispatches' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Store className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Delivery Dispatches</span>
              {unreadDeliveryNotifs.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-mono font-bold tabular-nums leading-none">
                  {unreadDeliveryNotifs.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setDriverSubTab('coupons')}
              className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                driverSubTab === 'coupons' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Ticket className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Driver Coupons</span>
            </button>

            <button
              type="button"
              onClick={() => setDriverSubTab('profile')}
              className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                driverSubTab === 'profile' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Driver Signup</span>
            </button>
          </div>

          {/* ================================================ */}
          {/* DRIVER SUB-TAB 1: RIDE DISPATCHES (2 SUB-TABS)    */}
          {/* ================================================ */}
          {driverSubTab === 'ride_dispatches' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto text-center">
              <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-xl mx-auto max-w-full">
                <button
                  type="button"
                  onClick={() => setDriverRideSubTab('active_dispatches')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverRideSubTab === 'active_dispatches' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <Map className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span>Live Map &amp; Dispatches</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDriverRideSubTab('history')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverRideSubTab === 'history' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <History className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Ride History</span>
                </button>
              </div>

              {driverRideSubTab === 'active_dispatches' && (
                <div className="space-y-6">
                  <div className="flex flex-wrap items-center justify-center text-center gap-2.5 pb-3 border-b border-neutral-200">
                    <h3 className="text-sm font-bold text-neutral-900 flex items-center justify-center gap-2 text-center">
                      <Navigation className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span>Driver End-to-End Navigation Map &amp; Passenger Dispatches</span>
                    </h3>
                    <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 tabular-nums whitespace-nowrap">
                      Earnings: {driverEarnings} {activeDriverPayoutCoin}
                    </span>
                  </div>

                  {/* ONLY show active Driver Ride Map & Driver Turn-by-Turn Map Directions when a ride is accepted */}
                  {activeDriverRide ? (() => {
                    const driverRoute = activeDriverRideRoute || buildTurnByTurnRoute(activeDriverRide.pickup, activeDriverRide.dropoff, 'driver_ride');
                    const steps = driverRoute.steps;
                    const clampedIdx = Math.min(driverRideStepIdx, steps.length - 1);
                    const currentStep = steps[clampedIdx];
                    const nextStep = clampedIdx < steps.length - 1 ? steps[clampedIdx + 1] : null;
                    const markerPos = getBezierMarkerPos(clampedIdx, steps.length);

                    return (
                      <div className="space-y-4">
                        <div className="relative w-full h-72 rounded-2xl bg-neutral-900 overflow-hidden border border-neutral-800">
                          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px]"></div>
                          <svg viewBox="0 0 780 260" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                            <path d="M 80 190 Q 390 40, 700 90" fill="none" stroke="#10b981" strokeWidth="4" strokeDasharray="6 6" />
                          </svg>
                          <div className="absolute left-[10%] bottom-[22%] -translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-indigo-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Pickup Passenger: {activeDriverRide.pickup}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-indigo-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div className="absolute right-[10%] top-[28%] translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Dropoff Destination: {activeDriverRide.dropoff}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div
                            className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700 flex flex-col items-center z-10"
                            style={{ left: markerPos.leftPct, top: markerPos.topPct }}
                          >
                            <div className="mb-1 px-2 py-0.5 rounded bg-white text-neutral-900 text-[9px] font-mono font-bold shadow-md whitespace-nowrap">
                              GPS Live · {currentStep.distanceLabel}
                            </div>
                            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                              <Car className="w-4 h-4" />
                            </div>
                          </div>
                          <div className="absolute bottom-3 left-3 right-3 bg-black/75 backdrop-blur-md p-3 rounded-xl border border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs text-white">
                            <span className="font-mono">
                              Active Dispatch: {activeDriverRide.pickup} → {activeDriverRide.dropoff}
                            </span>
                            <span className="text-emerald-400 font-bold font-mono tabular-nums">
                              Rate: {ratePerMile} {activeDriverPayoutCoin} / mile · {activeDriverRide.fare} {activeDriverRide.currency}
                            </span>
                          </div>
                        </div>

                        {/* Automatic Live GPS Turn-by-Turn Directions Box */}
                        <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-left space-y-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <h4 className="text-xs font-bold text-neutral-800 uppercase font-mono flex items-center gap-1.5">
                              <ListOrdered className="w-4 h-4 text-emerald-600" />
                              Live Auto-GPS Turn-by-Turn Directions
                            </h4>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 text-[10px] font-mono font-bold flex items-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${isAutoGpsDriverRide ? 'bg-emerald-600 animate-pulse' : 'bg-neutral-400'}`}></span>
                                <span>{clampedIdx >= steps.length - 1 ? 'Arrived' : isAutoGpsDriverRide ? 'Auto-Tracking Road' : 'GPS Paused'}</span>
                              </span>
                              <button
                                type="button"
                                onClick={() => setVoiceGpsEnabled(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer"
                              >
                                {voiceGpsEnabled ? '🔊 Voice On' : '🔇 Voice Muted'}
                              </button>
                              <button
                                type="button"
                                onClick={() => setIsAutoGpsDriverRide(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer flex items-center gap-1"
                              >
                                {isAutoGpsDriverRide ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                                <span>{isAutoGpsDriverRide ? 'Pause' : 'Resume'}</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDriverCompleteRide(activeDriverRide.id)}
                                className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer whitespace-nowrap"
                              >
                                Complete Trip (+{activeDriverRide.fare} {activeDriverRide.currency})
                              </button>
                            </div>
                          </div>

                          <div className="p-3 rounded-xl bg-emerald-900 text-white text-xs font-mono space-y-1.5">
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-bold flex items-center gap-1.5">
                                {getManeuverIcon(currentStep.maneuver)}
                                <span>NOW: {currentStep.instruction}</span>
                              </span>
                              <span className="shrink-0 font-bold text-emerald-300 tabular-nums">{currentStep.distanceLabel}</span>
                            </div>
                            <p className="text-[11px] text-emerald-100 font-sans">
                              {nextStep
                                ? `Next Turn Ahead (auto-updating): ${nextStep.instruction} (${nextStep.distanceLabel})`
                                : 'Final segment — approaching dropoff destination.'}
                            </p>
                          </div>

                          <ol className="space-y-1.5 text-xs font-mono">
                            {steps.map((step, idx) => {
                              const isDone = idx < clampedIdx;
                              const isActive = idx === clampedIdx;
                              return (
                                <li
                                  key={step.id}
                                  onClick={() => setDriverRideStepIdx(idx)}
                                  className={`p-2 rounded-xl border flex items-start justify-between gap-2 cursor-pointer transition-colors ${
                                    isActive
                                      ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                                      : isDone
                                        ? 'bg-neutral-100 border-neutral-200 text-neutral-500 line-through'
                                        : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                                  }`}
                                >
                                  <div className="flex items-start gap-2 min-w-0">
                                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                                      isActive ? 'bg-emerald-600 text-white' : isDone ? 'bg-neutral-400 text-white' : 'bg-neutral-200 text-neutral-700'
                                    }`}>
                                      {isDone ? '✓' : idx + 1}
                                    </span>
                                    <div>
                                      <p className="font-bold">{step.instruction}</p>
                                      <p className="text-[11px] font-sans opacity-80">{step.detail}</p>
                                    </div>
                                  </div>
                                  <span className="text-[11px] font-bold shrink-0 tabular-nums">{step.distanceLabel}</span>
                                </li>
                              );
                            })}
                          </ol>
                        </div>
                      </div>
                    );
                  })() : (
                    <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-1.5">
                      <Navigation className="w-7 h-7 text-indigo-600 mx-auto" />
                      <p className="text-xs font-bold text-neutral-900">
                        Accept a ride request below to activate live navigation
                      </p>
                      <p className="text-[11px] text-neutral-500">
                        Pickup Passenger, Dropoff Destination, and Driver Turn-by-Turn Map Directions appear as soon as you accept a dispatch.
                      </p>
                    </div>
                  )}

                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-neutral-700 uppercase font-mono text-center">Available Ride Requests in Sector</h4>
                    {filteredRides.filter(r => r.status !== 'cancelled' && r.status !== 'completed').length === 0 ? (
                      <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                        <p className="text-xs text-neutral-500">No incoming ride dispatches available.</p>
                      </div>
                    ) : (
                      filteredRides
                        .filter(r => r.status !== 'cancelled' && r.status !== 'completed')
                        .map(ride => {
                          const isAcceptedByThisDriver = ride.status === 'in_transit' && ride.driverId === userId;

                          return (
                            <div key={ride.id} className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col items-center justify-center text-center gap-3">
                              <div className="space-y-1.5 text-center w-full">
                                <div className="flex flex-wrap items-center gap-2 justify-center">
                                  <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-900 text-[10px] font-bold font-mono">
                                    {ride.vehicleType || CLASS_META[ride.vehicleClass]?.vehicleType || 'Car'} · {ride.vehicleClass}
                                  </span>
                                  {onViewUserProfile ? (
                                    <button
                                      type="button"
                                      onClick={() => onViewUserProfile(ride.riderId)}
                                      className="text-xs font-bold text-indigo-600 hover:underline inline-flex items-center gap-1 cursor-pointer"
                                    >
                                      <span>Passenger: {ride.riderName}</span>
                                      <ExternalLink className="w-3 h-3" />
                                    </button>
                                  ) : (
                                    <span className="text-xs font-bold text-neutral-900">Passenger: {ride.riderName}</span>
                                  )}
                                </div>
                                <p className="text-xs text-neutral-600">Pickup: {ride.pickup} → Dropoff: {ride.dropoff}</p>
                              </div>

                              <div className="flex flex-wrap items-center justify-center gap-2 w-full pt-1">
                                <span className="px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-xs font-mono font-bold text-emerald-700 tabular-nums whitespace-nowrap">
                                  {ride.fare} {ride.currency}
                                </span>
                                {!isAcceptedByThisDriver ? (
                                  <button
                                    type="button"
                                    onClick={() => handleDriverAcceptRide(ride.id)}
                                    className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-sm whitespace-nowrap"
                                  >
                                    Accept &amp; Navigate Ride
                                  </button>
                                ) : (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => handleDriverCompleteRide(ride.id)}
                                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer whitespace-nowrap shadow-xs"
                                    >
                                      Complete Trip
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDriverCancelRide(ride.id)}
                                      className="px-3.5 py-1.5 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold cursor-pointer whitespace-nowrap"
                                    >
                                      Cancel Dispatch
                                    </button>
                                  </>
                                )}
                              </div>
                            </div>
                          );
                        })
                    )}
                  </div>
                </div>
              )}

              {driverRideSubTab === 'history' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-neutral-900 text-center">Driver Completed Ride Dispatches History</h3>
                  {filteredRides.filter(r => r.status === 'completed').map(r => (
                    <div key={r.id} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center justify-between">
                      <div>
                        <p className="text-xs font-bold text-neutral-900">Ride Dispatch #{r.id.slice(-6)} ({r.vehicleClass})</p>
                        <p className="text-[11px] text-neutral-600">{r.pickup} → {r.dropoff} · Passenger: {r.riderName}</p>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-700 tabular-nums">+{r.fare} {r.currency}</span>
                    </div>
                  ))}
                  <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-neutral-900">Ride Dispatch #407732 (Comfort EV)</p>
                      <p className="text-[11px] text-neutral-600">Zurich Freeport → Bahnhofstrasse · Passenger: Sovereign Explorer</p>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-700 tabular-nums">+32 AFNL</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================================================ */}
          {/* DRIVER SUB-TAB 2: DELIVERY DISPATCHES (2 SUB-TABS) */}
          {/* ================================================ */}
          {driverSubTab === 'delivery_dispatches' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto text-center">
              <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-xl mx-auto max-w-full">
                <button
                  type="button"
                  onClick={() => setDriverDeliverySubTab('active_deliveries')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverDeliverySubTab === 'active_deliveries' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <Store className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Active Dispatches</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDriverDeliverySubTab('history')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverDeliverySubTab === 'history' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <History className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Delivery History</span>
                </button>
              </div>

              {driverDeliverySubTab === 'active_deliveries' && (() => {
                const restaurantDeliveries = filteredDeliveries.filter(c => c.businessType === 'restaurant');
                const storeDeliveries = filteredDeliveries.filter(c => c.businessType === 'retail');
                const restaurantUnread = unreadDeliveryNotifs.filter(n => n.businessType === 'restaurant');
                const storeUnread = unreadDeliveryNotifs.filter(n => n.businessType === 'retail');

                const tabContracts =
                  activeDeliveryDispatchTab === 'restaurant' ? restaurantDeliveries : storeDeliveries;
                const tabUnreadNotifs =
                  activeDeliveryDispatchTab === 'restaurant' ? restaurantUnread : storeUnread;
                const tabAccepted = tabContracts.filter(
                  c => c.status === 'accepted' || c.status === 'picked_up'
                );
                const tabActiveContract =
                  tabAccepted.find(c => c.id === focusedDeliveryId) || tabAccepted[0] || null;
                const otherTab: 'restaurant' | 'retail' =
                  activeDeliveryDispatchTab === 'restaurant' ? 'retail' : 'restaurant';
                const otherAcceptedCount = acceptedDeliveries.filter(
                  c => c.businessType === otherTab
                ).length;

                return (
                <div className="space-y-6">
                  <div className="flex flex-wrap items-center justify-center gap-2.5 pb-3 border-b border-neutral-200 text-center">
                    <h3 className="text-sm font-bold text-neutral-900 flex items-center justify-center gap-2 text-center">
                      <Store className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Active Delivery Dispatches</span>
                    </h3>
                    <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 tabular-nums whitespace-nowrap">
                      {tabContracts.filter(c => c.status === 'available').length} Ready
                    </span>
                  </div>

                  {/* Two Tabs Under Active Dispatches: Restaurant vs Stores */}
                  <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-xl mx-auto">
                    <button
                      type="button"
                      onClick={() => setActiveDeliveryDispatchTab('restaurant')}
                      className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                        activeDeliveryDispatchTab === 'restaurant'
                          ? 'bg-white text-neutral-900 shadow-sm'
                          : 'text-neutral-600 hover:text-neutral-900'
                      }`}
                    >
                      <UtensilsCrossed className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>Restaurant</span>
                      <span className="px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-mono font-bold tabular-nums leading-none">
                        {restaurantDeliveries.filter(c => c.status === 'available').length}
                      </span>
                      {restaurantUnread.length > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-mono font-bold tabular-nums leading-none">
                          {restaurantUnread.length} new
                        </span>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveDeliveryDispatchTab('retail')}
                      className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                        activeDeliveryDispatchTab === 'retail'
                          ? 'bg-white text-neutral-900 shadow-sm'
                          : 'text-neutral-600 hover:text-neutral-900'
                      }`}
                    >
                      <Store className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      <span>Stores</span>
                      <span className="px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-900 text-[10px] font-mono font-bold tabular-nums leading-none">
                        {storeDeliveries.filter(c => c.status === 'available').length}
                      </span>
                      {storeUnread.length > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-mono font-bold tabular-nums leading-none">
                          {storeUnread.length} new
                        </span>
                      )}
                    </button>
                  </div>

                  {otherAcceptedCount > 0 && !tabActiveContract && (
                    <div className="p-3 rounded-2xl bg-indigo-50 border border-indigo-200 flex flex-wrap items-center justify-center gap-3 text-xs">
                      <span className="font-semibold text-indigo-950">
                        You have {otherAcceptedCount} active accepted {otherTab === 'restaurant' ? 'Restaurant' : 'Stores'} delivery.
                      </span>
                      <button
                        type="button"
                        onClick={() => setActiveDeliveryDispatchTab(otherTab)}
                        className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-bold cursor-pointer"
                      >
                        Switch to {otherTab === 'restaurant' ? 'Restaurant' : 'Stores'} Tab
                      </button>
                    </div>
                  )}

                  {/* Driver Delivery Dispatch Notifications (filtered by Restaurant or Stores tab) */}
                  {tabUnreadNotifs.length > 0 && (
                    <div className="space-y-2">
                      {tabUnreadNotifs.map(notif => {
                        const matchingContract = tabContracts.find(
                          c => c.id === notif.contractId || c.orderNumber === notif.orderNumber
                        );
                        const driverEstPayout = Math.round(getDeliveryRateForBusiness(notif.businessType) * (notif.distanceMiles || 4) * 100) / 100;
                        const notifTiming = estimateDeliveryTiming(
                          notif.pickupAddress || notif.merchantName,
                          notif.deliveryAddress,
                          notif.distanceMiles || 4
                        );
                        return (
                          <div
                            key={notif.id}
                            className="p-4 rounded-2xl bg-amber-50 border border-amber-300 flex flex-col items-center justify-center gap-3 text-center"
                          >
                            <div className="space-y-1 flex flex-col items-center text-center w-full">
                              <div className="flex flex-wrap items-center justify-center gap-2">
                                <Bell className="w-4 h-4 text-amber-700 shrink-0" />
                                <span className="text-xs font-extrabold text-amber-950">
                                  New {notif.businessType === 'retail' ? 'Store' : 'Restaurant'} Delivery Request · #{notif.orderNumber}
                                </span>
                              </div>
                              <p className="text-xs text-amber-900">
                                <span className="font-bold">{notif.merchantName}</span> → {notif.deliveryAddress} ({notif.distance})
                              </p>
                              <p className="text-[11px] font-mono text-amber-900 tabular-nums">
                                To {notif.businessType === 'retail' ? 'Store' : 'Restaurant'}: ~{notifTiming.toPickupMinutes} mins ({notifTiming.toPickupMiles} mi) + Delivery: ~{notifTiming.deliveryMinutes} mins ({notifTiming.deliveryMiles} mi) = <strong>~{notifTiming.totalMinutes} mins total</strong>
                              </p>
                              <p className="text-[11px] font-mono text-amber-800">
                                {notif.businessType === 'retail' ? 'Store' : 'Restaurant'} Base Fee: {notif.storeFee} {notif.storeFeeCurrency} · Your Rate Payout: <strong>+{driverEstPayout} {activeDriverPayoutCoin}</strong>
                              </p>
                            </div>
                            <div className="flex flex-wrap items-center justify-center gap-2 shrink-0 w-full">
                              {matchingContract && matchingContract.status === 'available' && (
                                <button
                                  type="button"
                                  onClick={() => handleAcceptDeliveryContract(matchingContract.id)}
                                  className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                                >
                                  Accept Delivery
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => dismissDriverNotification(notif.id)}
                                className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-neutral-100 border border-amber-300 text-amber-900 text-xs font-bold cursor-pointer"
                              >
                                Dismiss
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* ONLY show Merchant Pickup -> Customer Delivery Map & Live Auto-GPS Turn-by-Turn Directions when a delivery IS accepted */}
                  {tabActiveContract && (() => {
                    const deliveryRoute = buildTurnByTurnRoute(
                      tabActiveContract.pickupAddress || tabActiveContract.merchantName,
                      tabActiveContract.deliveryAddress,
                      'driver_delivery',
                      {
                        merchantName: tabActiveContract.merchantName,
                        customerName: tabActiveContract.customerName,
                        baseDistanceMiles: tabActiveContract.distanceMiles
                      }
                    );
                    const steps = deliveryRoute.steps;
                    const clampedIdx = Math.min(driverDeliveryStepIdx, steps.length - 1);
                    const currentStep = steps[clampedIdx];
                    const nextStep = clampedIdx < steps.length - 1 ? steps[clampedIdx + 1] : null;
                    const markerPos = getBezierMarkerPos(clampedIdx, steps.length);

                    return (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-center font-mono">
                          <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                            <p className="text-[10px] uppercase text-amber-700 font-bold">
                              To {tabActiveContract.businessType === 'retail' ? 'Store' : 'Restaurant'} Pickup
                            </p>
                            <p className="text-xs font-extrabold text-amber-950 tabular-nums">
                              ~{deliveryRoute.toPickupMinutes} mins · {deliveryRoute.pickupApproachMiles} mi
                            </p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                            <p className="text-[10px] uppercase text-emerald-700 font-bold">
                              Delivery From {tabActiveContract.businessType === 'retail' ? 'Store' : 'Restaurant'}
                            </p>
                            <p className="text-xs font-extrabold text-emerald-950 tabular-nums">
                              ~{deliveryRoute.deliveryLegMinutes} mins · {deliveryRoute.distanceMiles} mi
                            </p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-neutral-100 border border-neutral-200">
                            <p className="text-[10px] uppercase text-neutral-600 font-bold">Total Delivery Time</p>
                            <p className="text-xs font-extrabold text-neutral-900 tabular-nums">
                              ~{deliveryRoute.totalMinutes} mins · {deliveryRoute.totalMiles} mi
                            </p>
                          </div>
                        </div>

                        <div className="relative w-full h-72 rounded-2xl bg-neutral-900 overflow-hidden border border-neutral-800">
                          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:24px_24px]"></div>
                          <svg viewBox="0 0 780 260" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                            <path d="M 80 190 Q 390 40, 700 90" fill="none" stroke="#f59e0b" strokeWidth="4" strokeDasharray="6 6" />
                          </svg>
                          <div className="absolute left-[10%] bottom-[22%] -translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-amber-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Merchant Pickup: {tabActiveContract.pickupAddress || tabActiveContract.merchantName}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-amber-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div className="absolute right-[10%] top-[28%] translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Customer Delivery: {tabActiveContract.deliveryAddress}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div
                            className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700 flex flex-col items-center z-10"
                            style={{ left: markerPos.leftPct, top: markerPos.topPct }}
                          >
                            <div className="mb-1 px-2 py-0.5 rounded bg-white text-neutral-900 text-[9px] font-mono font-bold shadow-md whitespace-nowrap">
                              GPS Live · {currentStep.distanceLabel}
                            </div>
                            <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                              <Package className="w-4 h-4" />
                            </div>
                          </div>
                          <div className="absolute bottom-3 left-3 right-3 bg-black/75 backdrop-blur-md p-3 rounded-xl border border-white/10 flex flex-col items-center justify-center text-center gap-1 text-xs text-white">
                            <span className="font-mono text-center">
                              Active Contract: {tabActiveContract.merchantName} Delivery (#{tabActiveContract.orderNumber})
                            </span>
                            <span className="text-amber-400 font-bold font-mono tabular-nums text-center">
                              Fee: +{tabActiveContract.deliveryFee} {tabActiveContract.currency} · ~{deliveryRoute.totalMinutes} mins total
                            </span>
                          </div>
                        </div>

                        {/* Automatic Live GPS Delivery Turn-by-Turn Directions Box */}
                        <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-3">
                          <div className="flex flex-col items-center justify-center text-center gap-2.5">
                            <h4 className="text-xs font-bold text-neutral-800 uppercase font-mono flex items-center justify-center gap-1.5 text-center">
                              <ListOrdered className="w-4 h-4 text-amber-600 shrink-0" />
                              <span>Live Auto-GPS Delivery Directions</span>
                            </h4>
                            <div className="flex flex-wrap items-center justify-center gap-1.5 w-full">
                              <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-950 text-[10px] font-mono font-bold flex items-center justify-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${isAutoGpsDriverDelivery ? 'bg-amber-600 animate-pulse' : 'bg-neutral-400'}`}></span>
                                <span>{clampedIdx >= steps.length - 1 ? 'Arrived' : isAutoGpsDriverDelivery ? 'Auto-Tracking Road' : 'GPS Paused'}</span>
                              </span>
                              <button
                                type="button"
                                onClick={() => setVoiceGpsEnabled(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer"
                              >
                                {voiceGpsEnabled ? '🔊 Voice On' : '🔇 Voice Muted'}
                              </button>
                              <button
                                type="button"
                                onClick={() => setIsAutoGpsDriverDelivery(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer flex items-center justify-center gap-1"
                              >
                                {isAutoGpsDriverDelivery ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                                <span>{isAutoGpsDriverDelivery ? 'Pause' : 'Resume'}</span>
                              </button>
                              {tabActiveContract.status === 'accepted' && (
                                <button
                                  type="button"
                                  onClick={() => handleMarkDeliveryPickedUp(tabActiveContract.id)}
                                  className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold cursor-pointer"
                                >
                                  Picked Up
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => openDeliveryProofModal(tabActiveContract.id)}
                                className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer whitespace-nowrap"
                              >
                                Mark Delivered (+{tabActiveContract.deliveryFee} {tabActiveContract.currency})
                              </button>
                            </div>
                          </div>

                          <div className="p-3 rounded-xl bg-amber-950 text-white text-xs font-mono space-y-1.5 text-center flex flex-col items-center justify-center">
                            <div className="flex flex-wrap items-center justify-center gap-2">
                              <span className="font-bold flex items-center justify-center gap-1.5">
                                {getManeuverIcon(currentStep.maneuver)}
                                <span>NOW: {currentStep.instruction}</span>
                              </span>
                              <span className="shrink-0 font-bold text-amber-300 tabular-nums">{currentStep.distanceLabel}</span>
                            </div>
                            <p className="text-[11px] text-amber-100 font-sans text-center">
                              {nextStep
                                ? `Next Turn Ahead (auto-updating): ${nextStep.instruction} (${nextStep.distanceLabel})`
                                : 'Final dropoff — take proof photos/videos and mark delivered.'}
                            </p>
                          </div>

                          <ol className="space-y-1.5 text-xs font-mono text-center">
                            {steps.map((step, idx) => {
                              const isDone = idx < clampedIdx;
                              const isActive = idx === clampedIdx;
                              return (
                                <li
                                  key={step.id}
                                  onClick={() => setDriverDeliveryStepIdx(idx)}
                                  className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer transition-colors ${
                                    isActive
                                      ? 'bg-amber-50 border-amber-300 text-amber-950'
                                      : isDone
                                        ? 'bg-neutral-100 border-neutral-200 text-neutral-500 line-through'
                                        : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                                  }`}
                                >
                                  <div className="flex items-center justify-center gap-2">
                                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                                      isActive ? 'bg-amber-600 text-white' : isDone ? 'bg-neutral-400 text-white' : 'bg-neutral-200 text-neutral-700'
                                    }`}>
                                      {isDone ? '✓' : idx + 1}
                                    </span>
                                    <span className="text-[11px] font-bold tabular-nums">{step.distanceLabel}</span>
                                  </div>
                                  <p className="font-bold text-center">{step.instruction}</p>
                                  <p className="text-[11px] font-sans opacity-80 text-center">{step.detail}</p>
                                </li>
                              );
                            })}
                          </ol>
                        </div>
                      </div>
                    );
                  })()}

                  <div className="space-y-4">
                    {tabContracts.length === 0 ? (
                      <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center text-xs text-neutral-500">
                        No {activeDeliveryDispatchTab === 'restaurant' ? 'Restaurant' : 'Store'} delivery dispatches currently queued.
                      </div>
                    ) : (
                      tabContracts.map(contract => {
                        const rawDist = contract.distanceMiles ?? (parseFloat(contract.distance || '4') || 4);
                        const isKm = (contract.distance || '').toLowerCase().includes('km');
                        const distMiles = isKm ? Math.max(0.5, Math.round(rawDist * 0.621371 * 10) / 10) : rawDist;
                        const estDriverPayout = Math.round(getDeliveryRateForBusiness(contract.businessType) * distMiles * 100) / 100;
                        const isFocused = tabActiveContract?.id === contract.id;
                        const timing = estimateDeliveryTiming(
                          contract.pickupAddress || contract.merchantName,
                          contract.deliveryAddress,
                          distMiles
                        );

                        return (
                          <div
                            key={contract.id}
                            className={`p-5 rounded-3xl border shadow-sm flex flex-col items-center justify-center text-center gap-3.5 ${
                              isFocused ? 'bg-amber-50/50 border-amber-300' : 'bg-neutral-50 border-neutral-200'
                            }`}
                          >
                            <div className="space-y-1.5 text-center w-full flex flex-col items-center justify-center">
                              <div className="flex flex-wrap items-center justify-center gap-2">
                                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md border uppercase ${
                                  contract.businessType === 'retail' ? 'bg-indigo-50 text-indigo-900 border-indigo-200' : 'bg-amber-50 text-amber-900 border-amber-200'
                                }`}>
                                  {contract.businessType === 'retail' ? 'Store' : 'Restaurant'}
                                </span>
                                <span className="text-xs font-bold text-neutral-900 font-mono">Order #{contract.orderNumber}</span>
                                {contract.status === 'available' ? (
                                  <span className="text-xs font-mono font-extrabold text-emerald-700 tabular-nums">
                                    <span className="text-neutral-500 line-through font-normal mr-1.5">
                                      {contract.businessType === 'retail' ? 'Store' : 'Restaurant'}: {contract.originalStoreFee ?? contract.deliveryFee} {contract.originalCurrency || contract.currency}
                                    </span>
                                    <span>Your Payout: +{estDriverPayout} {activeDriverPayoutCoin}</span>
                                  </span>
                                ) : (
                                  <span className="text-xs font-mono font-extrabold text-emerald-700 tabular-nums">
                                    +{contract.deliveryFee} {contract.currency}
                                  </span>
                                )}
                              </div>
                              <h4 className="text-sm font-bold text-neutral-900 text-center">
                                Pickup From: <span className="text-indigo-600">{contract.merchantName} — {contract.pickupAddress || 'Merchant Hub'}</span>
                              </h4>
                              <p className="text-xs text-neutral-600 text-center">
                                Deliver To: <span className="font-semibold">{contract.deliveryAddress}</span> (Customer: {contract.customerName} · {contract.distance || `${distMiles} miles`})
                              </p>
                              <div className="flex flex-wrap items-center justify-center gap-2 pt-0.5 text-[11px] font-mono tabular-nums w-full">
                                <span className="px-2.5 py-0.5 rounded-md bg-amber-100/80 text-amber-950 font-semibold">
                                  To {contract.businessType === 'retail' ? 'Store' : 'Restaurant'}: ~{timing.toPickupMinutes} mins ({timing.toPickupMiles} mi)
                                </span>
                                <span className="px-2.5 py-0.5 rounded-md bg-emerald-100/80 text-emerald-950 font-semibold">
                                  Delivery Leg: ~{timing.deliveryMinutes} mins ({timing.deliveryMiles} mi)
                                </span>
                                <span className="px-2.5 py-0.5 rounded-md bg-neutral-200/80 text-neutral-900 font-bold">
                                  Total: ~{timing.totalMinutes} mins ({timing.totalMiles} mi)
                                </span>
                              </div>
                            </div>

                            {/* Centered Delivery Proof Photos & Videos when delivered */}
                            {((contract.proofPhotos && contract.proofPhotos.length > 0) ||
                              (contract.proofVideos && contract.proofVideos.length > 0)) && (
                              <div className="w-full pt-2 border-t border-neutral-200/70 space-y-2 text-center flex flex-col items-center">
                                <p className="text-[10px] font-mono font-bold uppercase text-emerald-800">
                                  Verified Proof of Delivery ({contract.proofPhotos?.length || 0} Photos · {contract.proofVideos?.length || 0} Videos)
                                </p>
                                <div className="flex flex-wrap items-center justify-center gap-2.5 w-full">
                                  {(contract.proofPhotos || []).map((photoUrl, pIdx) => (
                                    <img
                                      key={`dp-${contract.id}-${pIdx}`}
                                      src={photoUrl}
                                      alt={`Delivery Proof Photo ${pIdx + 1}`}
                                      className="w-28 h-20 object-cover rounded-xl border border-emerald-200 shadow-2xs"
                                    />
                                  ))}
                                  {(contract.proofVideos || []).map((vidUrl, vIdx) => (
                                    <video
                                      key={`dv-${contract.id}-${vIdx}`}
                                      src={vidUrl}
                                      controls
                                      className="w-40 h-24 rounded-xl border border-emerald-200 bg-black shadow-2xs"
                                    />
                                  ))}
                                </div>
                              </div>
                            )}

                            <div className="flex flex-wrap items-center justify-center gap-2 w-full">
                              {contract.status === 'available' && (
                                <button
                                  type="button"
                                  onClick={() => handleAcceptDeliveryContract(contract.id)}
                                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-sm whitespace-nowrap"
                                >
                                  Accept Delivery
                                </button>
                              )}
                              {(contract.status === 'accepted' || contract.status === 'picked_up') && (
                                <div className="flex flex-wrap items-center justify-center gap-2 w-full">
                                  {!isFocused && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setFocusedDeliveryId(contract.id);
                                        setDriverDeliveryStepIdx(0);
                                      }}
                                      className="px-3.5 py-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold cursor-pointer whitespace-nowrap"
                                    >
                                      View Navigation
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => openDeliveryProofModal(contract.id)}
                                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-sm whitespace-nowrap"
                                  >
                                    Mark Delivered
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDriverCancelDelivery(contract.id)}
                                    className="px-3.5 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold cursor-pointer whitespace-nowrap"
                                  >
                                    Cancel Dispatch
                                  </button>
                                </div>
                              )}
                              {contract.status === 'delivered' && (
                                <div className="flex flex-wrap items-center justify-center gap-2">
                                  <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-1.5">
                                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                    Delivered &amp; Settled
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => setRatingModalDeliveryId(contract.id)}
                                    className="px-3 py-1.5 rounded-lg bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold flex items-center gap-1 cursor-pointer"
                                  >
                                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                                    {contract.rating ? 'Update Rating' : 'Rate Driver'}
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
                );
              })()}

              {driverDeliverySubTab === 'history' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-neutral-900 text-center">Completed Restaurant &amp; Retail Deliveries History</h3>
                  {deliveryContracts.filter(c => c.status === 'delivered').length === 0 ? (
                    <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                      <p className="text-xs text-neutral-500">No completed deliveries yet.</p>
                    </div>
                  ) : (
                    deliveryContracts.filter(c => c.status === 'delivered').map(c => (
                      <div key={c.id} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col items-center justify-center text-center gap-3">
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-neutral-900">Order #{c.orderNumber} ({c.businessType === 'retail' ? 'Store' : 'Restaurant'})</p>
                          <p className="text-[11px] text-neutral-600">Pickup: {c.pickupAddress} → {c.deliveryAddress}</p>
                          {c.rating && (
                            <p className="text-[11px] text-amber-600 font-bold">★ {c.rating}/5 - "{c.comment}"</p>
                          )}
                        </div>
                        {((c.proofPhotos && c.proofPhotos.length > 0) || (c.proofVideos && c.proofVideos.length > 0)) && (
                          <div className="flex flex-wrap items-center justify-center gap-2 w-full">
                            {(c.proofPhotos || []).map((photoUrl, pIdx) => (
                              <img
                                key={`hp-${c.id}-${pIdx}`}
                                src={photoUrl}
                                alt={`Proof ${pIdx + 1}`}
                                className="w-24 h-16 object-cover rounded-lg border border-emerald-200"
                              />
                            ))}
                            {(c.proofVideos || []).map((vidUrl, vIdx) => (
                              <video
                                key={`hv-${c.id}-${vIdx}`}
                                src={vidUrl}
                                controls
                                className="w-36 h-20 rounded-lg border border-emerald-200 bg-black"
                              />
                            ))}
                          </div>
                        )}
                        <div className="flex flex-wrap items-center justify-center gap-3">
                          <span className="text-xs font-mono font-bold text-emerald-700 tabular-nums">+{c.deliveryFee} {c.currency}</span>
                          <button
                            type="button"
                            onClick={() => setRatingModalDeliveryId(c.id)}
                            className="px-2.5 py-1 rounded-lg bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                            {c.rating ? 'Update' : 'Rate'}
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          )}

          {/* ================================================ */}
          {/* DRIVER SUB-TAB 3: DRIVER SIGNUP (3 VEHICLE TYPES) */}
          {/* ================================================ */}
          {driverSubTab === 'profile' && (
            <div className="max-w-3xl mx-auto bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-center">
              <div className="space-y-2">
                <ShieldCheck className="w-10 h-10 text-emerald-600 mx-auto" />
                <h2 className="font-serif-lux text-xl sm:text-2xl font-semibold text-black tracking-tight text-center">
                  Sovereign Driver Signup &amp; Fleet Profile
                </h2>
              </div>

              {/* Driver Stats (compact & single-line numbers) */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="px-2.5 py-2 rounded-xl bg-neutral-50 border border-neutral-200 space-y-0.5 min-w-0">
                  <p className="text-[9px] text-neutral-400 uppercase font-mono font-bold whitespace-nowrap truncate">Total Earnings</p>
                  <p className="text-xs font-extrabold text-neutral-900 font-mono tabular-nums whitespace-nowrap">{driverEarnings} AFNL</p>
                </div>
                <div className="px-2.5 py-2 rounded-xl bg-neutral-50 border border-neutral-200 space-y-0.5 min-w-0">
                  <p className="text-[9px] text-neutral-400 uppercase font-mono font-bold whitespace-nowrap truncate">Rating</p>
                  <p className="text-xs font-extrabold text-amber-600 font-mono tabular-nums whitespace-nowrap">4.98 ★</p>
                </div>
                <div className="px-2.5 py-2 rounded-xl bg-neutral-50 border border-neutral-200 space-y-0.5 min-w-0">
                  <p className="text-[9px] text-neutral-400 uppercase font-mono font-bold whitespace-nowrap truncate">Registered Fleet</p>
                  <p className="text-xs font-extrabold text-indigo-600 font-mono tabular-nums whitespace-nowrap">
                    {Object.values(driverVehicles).filter(Boolean).length}/3 Types
                  </p>
                </div>
              </div>

              {/* Driver Per-Mile Pricing Controls (Civilian Driving, Food Delivery & Retail Delivery — 1:1 Across Any Chosen Final Currency) */}
              <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-3 text-center">
                <div className="space-y-0.5">
                  <label className="text-[10px] font-bold uppercase font-mono text-emerald-900 block">
                    Your Final Currency Rate Per Mile (Rides, Food &amp; Retail Delivery)
                  </label>
                  <p className="text-[11px] text-emerald-800/80">
                    All Final currencies are equal 1:1 — choose separate per-mile rates for civilian rides, food deliveries, and retail deliveries.
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                  <div className="p-3 rounded-xl bg-white border border-emerald-200 space-y-1">
                    <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block">
                      Civilian Driving (Final/mi)
                    </label>
                    <div className="flex items-center justify-center gap-1.5">
                      <input
                        type="number"
                        step="0.5"
                        min={0.5}
                        max={100}
                        value={ratePerMile}
                        onChange={(e) => updateCivilianRatePerMile(parseFloat(e.target.value))}
                        className="w-20 px-2.5 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs font-bold text-neutral-900 text-center font-mono tabular-nums outline-none focus:border-emerald-500"
                      />
                      <span className="text-xs font-mono font-bold text-emerald-800 whitespace-nowrap">{activeDriverPayoutCoin}/mi</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white border border-amber-200 space-y-1">
                    <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block">
                      Food Delivery (Final/mi)
                    </label>
                    <div className="flex items-center justify-center gap-1.5">
                      <input
                        type="number"
                        step="0.5"
                        min={0.5}
                        max={100}
                        value={foodDeliveryRatePerMile}
                        onChange={(e) => updateFoodDeliveryRatePerMile(parseFloat(e.target.value))}
                        className="w-20 px-2.5 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs font-bold text-neutral-900 text-center font-mono tabular-nums outline-none focus:border-amber-500"
                      />
                      <span className="text-xs font-mono font-bold text-amber-800 whitespace-nowrap">{activeDriverPayoutCoin}/mi</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white border border-indigo-200 space-y-1">
                    <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block">
                      Retail Delivery (Final/mi)
                    </label>
                    <div className="flex items-center justify-center gap-1.5">
                      <input
                        type="number"
                        step="0.5"
                        min={0.5}
                        max={100}
                        value={retailDeliveryRatePerMile}
                        onChange={(e) => updateRetailDeliveryRatePerMile(parseFloat(e.target.value))}
                        className="w-20 px-2.5 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs font-bold text-neutral-900 text-center font-mono tabular-nums outline-none focus:border-indigo-500"
                      />
                      <span className="text-xs font-mono font-bold text-indigo-800 whitespace-nowrap">{activeDriverPayoutCoin}/mi</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3 Vehicle Sections: Car, Auto Rickshaw, Motor Bike (Max 1 Each) */}
              <div className="space-y-5 text-left">
                {VEHICLE_TYPE_SECTIONS.map((sec, idx) => {
                  const slot = driverVehicles[sec.type];
                  const draft = driverDrafts[sec.type];
                  const slotFoodRate = slot?.foodDeliveryRatePerMile ?? slot?.deliveryRatePerMile ?? foodDeliveryRatePerMile;
                  const slotRetailRate = slot?.retailDeliveryRatePerMile ?? slot?.deliveryRatePerMile ?? retailDeliveryRatePerMile;
                  return (
                    <div
                      key={sec.type}
                      className={`p-5 rounded-3xl border space-y-4 ${
                        slot ? 'bg-emerald-50/40 border-emerald-200' : 'bg-neutral-50/70 border-neutral-200'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-2 pb-2 border-b border-neutral-200/80 text-center">
                        <span className="w-6 h-6 rounded-full bg-neutral-900 text-white text-xs font-bold flex items-center justify-center font-mono">
                          {idx + 1}
                        </span>
                        <h3 className="text-sm font-bold text-neutral-900">{sec.label}</h3>
                      </div>

                      {slot ? (
                        editingVehicleType === sec.type && editVehicleDraft ? (
                          <form onSubmit={(e) => handleSaveEditedVehicleSlot(sec.type, e)} className="space-y-3 text-center pt-1">
                            <div className="p-3 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2">
                              <label className="text-[10px] font-bold uppercase font-mono text-indigo-900 text-center block">
                                Change Vehicle Type (Switch Across Any of the 3 Vehicle Types)
                              </label>
                              <div className="grid grid-cols-3 gap-2">
                                {VEHICLE_TYPE_SECTIONS.map((opt) => {
                                  const isSelected = editTargetVehicleType === opt.type;
                                  const isOccupiedOther = opt.type !== sec.type && Boolean(driverVehicles[opt.type]);
                                  return (
                                    <button
                                      key={opt.type}
                                      type="button"
                                      onClick={() => {
                                        setEditTargetVehicleType(opt.type);
                                        setEditVehicleDraft((prev) =>
                                          prev
                                            ? {
                                                ...prev,
                                                vehicleClass:
                                                  opt.type === 'car'
                                                    ? (prev.vehicleClass === 'Economy' || prev.vehicleClass === 'Comfort EV' || prev.vehicleClass === 'Luxury Limousine'
                                                        ? prev.vehicleClass
                                                        : 'Comfort EV')
                                                    : opt.defaultClass,
                                              }
                                            : prev
                                        );
                                      }}
                                      className={`px-2.5 py-2 rounded-xl text-xs font-bold border cursor-pointer transition-all ${
                                        isSelected
                                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                                          : 'bg-white text-neutral-800 border-indigo-200 hover:bg-indigo-50'
                                      }`}
                                    >
                                      {opt.label}
                                      {isOccupiedOther && (
                                        <span className={`block text-[9px] font-mono ${isSelected ? 'text-indigo-100' : 'text-amber-600'}`}>
                                          (Replaces Existing)
                                        </span>
                                      )}
                                    </button>
                                  );
                                })}
                              </div>
                              {editTargetVehicleType !== sec.type && driverVehicles[editTargetVehicleType] && (
                                <p className="text-[10px] font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-2.5 py-1.5">
                                  Switching from {sec.label} to {VEHICLE_TYPE_SECTIONS.find(s => s.type === editTargetVehicleType)?.label} will vacate your {sec.label} slot and replace your current {VEHICLE_TYPE_SECTIONS.find(s => s.type === editTargetVehicleType)?.label} registration.
                                </p>
                              )}
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Vehicle Make &amp; Model *
                                </label>
                                <input
                                  type="text"
                                  value={editVehicleDraft.makeModel}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, makeModel: e.target.value } : prev)}
                                  required
                                  placeholder={VEHICLE_TYPE_SECTIONS.find(s => s.type === editTargetVehicleType)?.placeholderModel}
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-indigo-500 text-center"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Year *
                                </label>
                                <input
                                  type="text"
                                  value={editVehicleDraft.year}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, year: e.target.value } : prev)}
                                  required
                                  placeholder="e.g. 2025"
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-indigo-500 font-mono text-center"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  License Plate *
                                </label>
                                <input
                                  type="text"
                                  value={editVehicleDraft.plate}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, plate: e.target.value } : prev)}
                                  required
                                  placeholder={VEHICLE_TYPE_SECTIONS.find(s => s.type === editTargetVehicleType)?.placeholderPlate}
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-indigo-500 font-mono text-center"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Driver License ID *
                                </label>
                                <input
                                  type="text"
                                  value={editVehicleDraft.licenseId}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, licenseId: e.target.value } : prev)}
                                  required
                                  placeholder="e.g. CH-LIC-99214"
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-indigo-500 font-mono text-center"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Insurance Information *
                                </label>
                                <input
                                  type="text"
                                  value={editVehicleDraft.insuranceInfo}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, insuranceInfo: e.target.value } : prev)}
                                  required
                                  placeholder="Commercial Policy ID..."
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-indigo-500 text-center"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Civilian Ride Rate (Final/mi) *
                                </label>
                                <input
                                  type="number"
                                  step="0.5"
                                  min={0.5}
                                  max={100}
                                  value={editVehicleDraft.ratePerMile}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, ratePerMile: parseFloat(e.target.value) || sec.defaultRate } : prev)}
                                  required
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none text-center font-mono tabular-nums"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Food Delivery Rate (Final/mi) *
                                </label>
                                <input
                                  type="number"
                                  step="0.5"
                                  min={0.5}
                                  max={100}
                                  value={editVehicleDraft.foodDeliveryRatePerMile}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, foodDeliveryRatePerMile: parseFloat(e.target.value) || sec.defaultRate } : prev)}
                                  required
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none text-center font-mono tabular-nums"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Retail Delivery Rate (Final/mi) *
                                </label>
                                <input
                                  type="number"
                                  step="0.5"
                                  min={0.5}
                                  max={100}
                                  value={editVehicleDraft.retailDeliveryRatePerMile}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, retailDeliveryRatePerMile: parseFloat(e.target.value) || sec.defaultRate } : prev)}
                                  required
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none text-center font-mono tabular-nums"
                                />
                              </div>
                            </div>

                            {editTargetVehicleType === 'car' && (
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                  Car Class *
                                </label>
                                <select
                                  value={editVehicleDraft.vehicleClass}
                                  onChange={(e) => setEditVehicleDraft(prev => prev ? { ...prev, vehicleClass: e.target.value as VehicleClassName } : prev)}
                                  className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none focus:border-indigo-500 text-center"
                                >
                                  <option value="Economy">Economy</option>
                                  <option value="Comfort EV">Comfort EV</option>
                                  <option value="Luxury Limousine">Luxury Limousine</option>
                                </select>
                              </div>
                            )}

                            <div className="flex flex-col items-center justify-center gap-2.5 pt-1 w-full">
                              <label className="w-full py-2 px-4 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5 shadow-2xs">
                                <span>📷 Upload / Add Photos ({editVehicleDraft.media.length})</span>
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="environment"
                                  multiple
                                  className="hidden"
                                  onChange={(e) => {
                                    if (e.target.files && e.target.files.length > 0) {
                                      const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                                      setEditVehicleDraft(prev => prev ? { ...prev, media: [...urls, ...prev.media] } : prev);
                                    }
                                  }}
                                />
                              </label>

                              <label className="w-full py-2 px-4 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5 shadow-2xs">
                                <span>🎬 Upload / Add Videos ({editVehicleDraft.videoMedia.length})</span>
                                <input
                                  type="file"
                                  accept="video/*"
                                  capture="environment"
                                  multiple
                                  className="hidden"
                                  onChange={(e) => {
                                    if (e.target.files && e.target.files.length > 0) {
                                      const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                                      setEditVehicleDraft(prev => prev ? { ...prev, videoMedia: [...urls, ...prev.videoMedia] } : prev);
                                    }
                                  }}
                                />
                              </label>

                              {(editVehicleDraft.media.length > 0 || editVehicleDraft.videoMedia.length > 0) && (
                                <div className="flex flex-wrap items-center justify-center gap-2 w-full pt-1">
                                  {editVehicleDraft.media.map((url, mIdx) => (
                                    <div key={`edit-img-${sec.type}-${mIdx}`} className="relative">
                                      <img
                                        src={url}
                                        alt={`Preview ${mIdx + 1}`}
                                        className="w-20 h-14 object-cover rounded-lg border border-neutral-300"
                                      />
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setEditVehicleDraft(prev => prev ? { ...prev, media: prev.media.filter((_, i) => i !== mIdx) } : prev)
                                        }
                                        aria-label="Remove photo"
                                        className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                      >
                                        ×
                                      </button>
                                    </div>
                                  ))}
                                  {editVehicleDraft.videoMedia.map((vUrl, vIdx) => (
                                    <div key={`edit-vid-${sec.type}-${vIdx}`} className="relative">
                                      <video
                                        src={vUrl}
                                        controls
                                        className="w-28 h-16 rounded-lg border border-neutral-300 bg-black"
                                      />
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setEditVehicleDraft(prev => prev ? { ...prev, videoMedia: prev.videoMedia.filter((_, i) => i !== vIdx) } : prev)
                                        }
                                        aria-label="Remove video"
                                        className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                      >
                                        ×
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>

                            <label className="flex items-center justify-center gap-2 text-xs text-neutral-700 cursor-pointer select-none pt-1">
                              <input
                                type="checkbox"
                                checked={syncDriverInfoAcrossFleet}
                                onChange={(e) => setSyncDriverInfoAcrossFleet(e.target.checked)}
                                className="w-4 h-4 rounded border-neutral-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                              />
                              <span>Also sync updated Driver License ID &amp; Insurance to all my vehicle types</span>
                            </label>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                              <button
                                type="button"
                                onClick={handleCancelEditVehicleSlot}
                                className="w-full py-2.5 px-4 rounded-xl bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold cursor-pointer transition-colors"
                              >
                                Cancel
                              </button>
                              <button
                                type="submit"
                                className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm cursor-pointer transition-colors"
                              >
                                {editTargetVehicleType !== sec.type
                                  ? `Save & Switch to ${VEHICLE_TYPE_SECTIONS.find(s => s.type === editTargetVehicleType)?.label}`
                                  : `Save Updated ${sec.label} Info`}
                              </button>
                            </div>
                          </form>
                        ) : (
                        <div className="space-y-3 text-center">
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Vehicle Make &amp; Model</span>
                              <span className="font-bold text-neutral-900">{slot.makeModel}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Year &amp; Class</span>
                              <span className="font-bold text-neutral-900 font-mono">{slot.year} · {slot.vehicleClass}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">License Plate</span>
                              <span className="font-bold text-neutral-900 font-mono">{slot.plate}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">License ID</span>
                              <span className="font-bold text-neutral-900 font-mono">{slot.licenseId}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Rates (Ride / Food / Retail)</span>
                              <span className="font-bold text-emerald-700 font-mono tabular-nums whitespace-nowrap">
                                {slot.ratePerMile} / {slotFoodRate} / {slotRetailRate}/mi
                              </span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Insurance Info</span>
                              <span className="font-semibold text-neutral-800 truncate block">{slot.insuranceInfo}</span>
                            </div>
                          </div>

                          {((slot.media && slot.media.length > 0) || (slot.videoMedia && slot.videoMedia.length > 0)) && (
                            <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                              {(slot.media || []).map((url, mIdx) => (
                                <img
                                  key={`slot-img-${sec.type}-${mIdx}`}
                                  src={url}
                                  alt={`${sec.label} Photo ${mIdx + 1}`}
                                  className="w-24 h-16 object-cover rounded-xl border border-emerald-200"
                                />
                              ))}
                              {(slot.videoMedia || []).map((vUrl, vIdx) => (
                                <video
                                  key={`slot-vid-${sec.type}-${vIdx}`}
                                  src={vUrl}
                                  controls
                                  className="w-36 h-20 rounded-xl border border-emerald-200 bg-black"
                                />
                              ))}
                            </div>
                          )}

                          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => handleToggleSlotOnline(sec.type)}
                              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                                slot.online ? 'bg-emerald-600 text-white shadow-xs' : 'bg-neutral-200 text-neutral-700'
                              }`}
                            >
                              {slot.online ? `🟢 ${sec.label} Online` : `🔴 ${sec.label} Offline`}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleStartEditVehicleSlot(sec.type)}
                              className="px-3.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold cursor-pointer inline-flex items-center gap-1.5"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              <span>Edit Info / Change Vehicle</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                updateCivilianRatePerMile(slot.ratePerMile);
                                updateFoodDeliveryRatePerMile(slotFoodRate);
                                updateRetailDeliveryRatePerMile(slotRetailRate);
                                dispatchGlobalNotification({
                                  title: `Active Rates Updated (${sec.label})`,
                                  description: `Ride rate: ${slot.ratePerMile}/mi · Food delivery: ${slotFoodRate}/mi · Retail delivery: ${slotRetailRate}/mi across all chosen Final currencies.`,
                                  type: 'ride_share',
                                  targetTab: 'ride_share',
                                  showToast: true,
                                  tone: 'success'
                                });
                              }}
                              className="px-3.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-bold cursor-pointer"
                            >
                              Use {slot.ratePerMile} / {slotFoodRate} / {slotRetailRate} Rates
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveVehicleSlot(sec.type)}
                              className="px-3.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                            >
                              Remove {sec.label}
                            </button>
                          </div>
                        </div>
                        )
                      ) : (
                        <form onSubmit={(e) => handleRegisterVehicleSlot(sec.type, e)} className="space-y-3 text-center">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Vehicle Make &amp; Model *
                              </label>
                              <input
                                type="text"
                                value={draft.makeModel}
                                onChange={(e) => updateDriverDraft(sec.type, { makeModel: e.target.value })}
                                required
                                placeholder={sec.placeholderModel}
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 text-center"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Year *
                              </label>
                              <input
                                type="text"
                                value={draft.year}
                                onChange={(e) => updateDriverDraft(sec.type, { year: e.target.value })}
                                required
                                placeholder="e.g. 2025"
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 font-mono text-center"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                License Plate *
                              </label>
                              <input
                                type="text"
                                value={draft.plate}
                                onChange={(e) => updateDriverDraft(sec.type, { plate: e.target.value })}
                                required
                                placeholder={sec.placeholderPlate}
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 font-mono text-center"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                License ID *
                              </label>
                              <input
                                type="text"
                                value={draft.licenseId}
                                onChange={(e) => updateDriverDraft(sec.type, { licenseId: e.target.value })}
                                required
                                placeholder="e.g. CH-LIC-99214"
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 font-mono text-center"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Insurance Information *
                              </label>
                              <input
                                type="text"
                                value={draft.insuranceInfo}
                                onChange={(e) => updateDriverDraft(sec.type, { insuranceInfo: e.target.value })}
                                required
                                placeholder="Commercial Policy ID..."
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 text-center"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Civilian Ride Rate (Final/mi) *
                              </label>
                              <input
                                type="number"
                                step="0.5"
                                min={0.5}
                                max={100}
                                value={draft.ratePerMile}
                                onChange={(e) => updateDriverDraft(sec.type, { ratePerMile: parseFloat(e.target.value) || sec.defaultRate })}
                                required
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none text-center font-mono tabular-nums"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Food Delivery Rate (Final/mi) *
                              </label>
                              <input
                                type="number"
                                step="0.5"
                                min={0.5}
                                max={100}
                                value={draft.foodDeliveryRatePerMile}
                                onChange={(e) => updateDriverDraft(sec.type, { foodDeliveryRatePerMile: parseFloat(e.target.value) || sec.defaultRate })}
                                required
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none text-center font-mono tabular-nums"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Retail Delivery Rate (Final/mi) *
                              </label>
                              <input
                                type="number"
                                step="0.5"
                                min={0.5}
                                max={100}
                                value={draft.retailDeliveryRatePerMile}
                                onChange={(e) => updateDriverDraft(sec.type, { retailDeliveryRatePerMile: parseFloat(e.target.value) || sec.defaultRate })}
                                required
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none text-center font-mono tabular-nums"
                              />
                            </div>
                          </div>

                          {sec.type === 'car' && (
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Car Class *
                              </label>
                              <select
                                value={draft.vehicleClass}
                                onChange={(e) => updateDriverDraft('car', { vehicleClass: e.target.value as VehicleClassName })}
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none focus:border-emerald-500 text-center"
                              >
                                <option value="Economy">Economy</option>
                                <option value="Comfort EV">Comfort EV</option>
                                <option value="Luxury Limousine">Luxury Limousine</option>
                              </select>
                            </div>
                          )}

                          {/* Full-width centered Photo + Video upload/capture & previews + Register CTA */}
                          <div className="flex flex-col items-center justify-center gap-2.5 pt-2 w-full">
                            <label className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5 shadow-2xs">
                              <span>📷 Upload / Take {sec.label} Photos ({draft.media.length})</span>
                              <input
                                type="file"
                                accept="image/*"
                                capture="environment"
                                multiple
                                className="hidden"
                                onChange={(e) => {
                                  if (e.target.files && e.target.files.length > 0) {
                                    const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                                    updateDriverDraft(sec.type, { media: [...urls, ...draft.media] });
                                  }
                                }}
                              />
                            </label>

                            <label className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5 shadow-2xs">
                              <span>🎬 Upload / Take {sec.label} Videos ({draft.videoMedia.length})</span>
                              <input
                                type="file"
                                accept="video/*"
                                capture="environment"
                                multiple
                                className="hidden"
                                onChange={(e) => {
                                  if (e.target.files && e.target.files.length > 0) {
                                    const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                                    updateDriverDraft(sec.type, { videoMedia: [...urls, ...draft.videoMedia] });
                                  }
                                }}
                              />
                            </label>

                            {(draft.media.length > 0 || draft.videoMedia.length > 0) && (
                              <div className="flex flex-wrap items-center justify-center gap-2 w-full pt-1">
                                {draft.media.map((url, mIdx) => (
                                  <div key={`draft-img-${sec.type}-${mIdx}`} className="relative">
                                    <img
                                      src={url}
                                      alt={`${sec.label} Preview ${mIdx + 1}`}
                                      className="w-20 h-14 object-cover rounded-lg border border-neutral-300"
                                    />
                                    <button
                                      type="button"
                                      onClick={() =>
                                        updateDriverDraft(sec.type, {
                                          media: draft.media.filter((_, i) => i !== mIdx)
                                        })
                                      }
                                      aria-label="Remove photo"
                                      className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                    >
                                      ×
                                    </button>
                                  </div>
                                ))}
                                {draft.videoMedia.map((vUrl, vIdx) => (
                                  <div key={`draft-vid-${sec.type}-${vIdx}`} className="relative">
                                    <video
                                      src={vUrl}
                                      controls
                                      className="w-28 h-16 rounded-lg border border-neutral-300 bg-black"
                                    />
                                    <button
                                      type="button"
                                      onClick={() =>
                                        updateDriverDraft(sec.type, {
                                          videoMedia: draft.videoMedia.filter((_, i) => i !== vIdx)
                                        })
                                      }
                                      aria-label="Remove video"
                                      className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                    >
                                      ×
                                    </button>
                                  </div>
                                ))}
                              </div>
                            )}

                            <button
                              type="submit"
                              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm cursor-pointer transition-colors flex items-center justify-center text-center"
                            >
                              Register {sec.label} (1 Max)
                            </button>
                          </div>
                        </form>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Driver Payout Final Currencies Selector */}
              <div className="space-y-2 pt-2 border-t border-neutral-200 text-left">
                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                  Search &amp; Choose Driver Payout Final Currencies (Up to 5)
                </label>
                <p className="text-[10px] text-neutral-400 font-mono text-center">
                  Civilian Ride ({ratePerMile}/mi), Food Delivery ({foodDeliveryRatePerMile}/mi) &amp; Retail Delivery ({retailDeliveryRatePerMile}/mi) apply 1:1 across all chosen Final currencies
                </p>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                  <input
                    type="text"
                    value={currencySearchQuery}
                    onChange={(e) => setCurrencySearchQuery(e.target.value)}
                    placeholder="Search any platform currency (e.g. AFNL, FNL-GOLD)..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
                  {allPlatformCurrencies
                    .filter(c => c.toLowerCase().includes(currencySearchQuery.toLowerCase()))
                    .map(curr => {
                      const isSelected = driverCurrencies.includes(curr);
                      return (
                        <button
                          key={curr}
                          type="button"
                          onClick={() => {
                            let next = driverCurrencies;
                            if (isSelected && driverCurrencies.length > 1) {
                              next = driverCurrencies.filter(c => c !== curr);
                            } else if (!isSelected && driverCurrencies.length < 5) {
                              next = [...driverCurrencies, curr];
                            }
                            setDriverCurrencies(next);
                            try {
                              localStorage.setItem(`final_finance_driver_currencies_${userId}`, JSON.stringify(next));
                              window.dispatchEvent(new CustomEvent('final_finance_driver_currencies_updated'));
                            } catch {}
                          }}
                          className={`p-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            isSelected ? 'bg-emerald-50 border-emerald-500 text-emerald-950' : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                          }`}
                        >
                          {curr} {isSelected ? '✓' : ''}
                        </button>
                      );
                    })}
                </div>
              </div>
            </div>
          )}
          {/* ================================================ */}
          {/* DRIVER SUB-TAB: DRIVER COUPONS ISSUER             */}
          {/* ================================================ */}
          {driverSubTab === 'coupons' && (
            <div className="max-w-4xl mx-auto">
              <CouponIssuerWidget
                currentUser={currentUser}
                fixedRole="driver"
                onOpenVerificationModal={onOpenVerificationModal}
              />
            </div>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* WARNING MODAL FOR CANCELLING RIDE AFTER 2 MINUTES     */}
      {/* ==================================================== */}
      {showCancelWarningModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-xl text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-neutral-900">Late Cancellation Warning</h3>
            <p className="text-xs text-neutral-600">
              The 2-minute free cancellation window has expired. If you cancel this ride now, you will be charged a **10% cancellation fee** of the original ride fare.
            </p>
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowCancelWarningModal(false);
                  setPendingCancelRideId(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold cursor-pointer"
              >
                Keep Ride
              </button>
              <button
                type="button"
                onClick={() => pendingCancelRideId && executeCancelRide(pendingCancelRideId, true)}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer shadow-sm"
              >
                Confirm &amp; Pay 10% Fee
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* RATING & COMMENT MODAL                                */}
      {/* ==================================================== */}
      {(ratingModalRideId || ratingModalDeliveryId) && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-xl text-center">
            <h3 className="text-base font-bold text-neutral-900">Rate Driver &amp; Leave Review</h3>
            <div className="flex items-center justify-center gap-2">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setReviewRating(star)}
                  className="p-1 cursor-pointer focus:outline-hidden"
                >
                  <Star className={`w-8 h-8 ${star <= reviewRating ? 'text-amber-500 fill-amber-500' : 'text-neutral-300'}`} />
                </button>
              ))}
            </div>
            <textarea
              value={reviewComment}
              onChange={(e) => setReviewComment(e.target.value)}
              placeholder="Leave a comment about your trip or delivery experience..."
              className="w-full p-3 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-indigo-500 h-24 resize-none"
            ></textarea>
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setRatingModalRideId(null);
                  setRatingModalDeliveryId(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-neutral-100 text-neutral-800 text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveReview}
                className="flex-1 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold cursor-pointer shadow-sm"
              >
                Submit Review
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* DELIVERY PROOF MODAL (PHOTOS & VIDEOS CAPTURE/UPLOAD) */}
      {/* ==================================================== */}
      {proofModalContractId && (() => {
        const targetContract = deliveryContracts.find(c => c.id === proofModalContractId);
        if (!targetContract) return null;
        return (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-xl text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-neutral-900">
                    Proof of Delivery · Order #{targetContract.orderNumber}
                  </h3>
                  <p className="text-xs text-neutral-500">
                    Take or upload at least 1 picture or 1 video showing handover at {targetContract.deliveryAddress} before marking delivered.
                  </p>
                </div>

                <div className="flex flex-col items-center justify-center gap-2.5 w-full">
                  <label className="w-full py-2.5 px-4 rounded-xl bg-neutral-50 hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5">
                    <span>📷 Take / Upload Proof Photos ({deliveryProofPhotos.length})</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      multiple
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          Array.from(e.target.files).forEach((file) => {
                            const reader = new FileReader();
                            reader.onload = () => {
                              if (typeof reader.result === 'string') {
                                setDeliveryProofPhotos(prev => [reader.result as string, ...prev]);
                              }
                            };
                            reader.readAsDataURL(file);
                          });
                        }
                        e.target.value = '';
                      }}
                    />
                  </label>

                  <label className="w-full py-2.5 px-4 rounded-xl bg-neutral-50 hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5">
                    <span>🎬 Take / Upload Proof Videos ({deliveryProofVideos.length})</span>
                    <input
                      type="file"
                      accept="video/*"
                      capture="environment"
                      multiple
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          Array.from(e.target.files).forEach((file) => {
                            const reader = new FileReader();
                            reader.onload = () => {
                              if (typeof reader.result === 'string') {
                                setDeliveryProofVideos(prev => [reader.result as string, ...prev]);
                              }
                            };
                            reader.readAsDataURL(file);
                          });
                        }
                        e.target.value = '';
                      }}
                    />
                  </label>
                </div>

                {deliveryProofPhotos.length === 0 && deliveryProofVideos.length === 0 && (
                  <p className="text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
                    Required: Take or upload at least 1 picture or 1 video of the delivery to confirm delivery.
                  </p>
                )}

                {(deliveryProofPhotos.length > 0 || deliveryProofVideos.length > 0) && (
                  <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1 max-h-48 overflow-y-auto">
                    {deliveryProofPhotos.map((pUrl, idx) => (
                      <div key={`modal-photo-${idx}`} className="relative">
                        <img
                          src={pUrl}
                          alt={`Proof Photo ${idx + 1}`}
                          className="w-24 h-18 object-cover rounded-xl border border-emerald-200"
                        />
                        <button
                          type="button"
                          onClick={() => setDeliveryProofPhotos(prev => prev.filter((_, i) => i !== idx))}
                          aria-label="Remove proof photo"
                          className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-rose-600 text-white text-xs flex items-center justify-center cursor-pointer"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                    {deliveryProofVideos.map((vUrl, idx) => (
                      <div key={`modal-vid-${idx}`} className="relative">
                        <video
                          src={vUrl}
                          controls
                          className="w-36 h-20 rounded-xl border border-emerald-200 bg-black"
                        />
                        <button
                          type="button"
                          onClick={() => setDeliveryProofVideos(prev => prev.filter((_, i) => i !== idx))}
                          aria-label="Remove proof video"
                          className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-rose-600 text-white text-xs flex items-center justify-center cursor-pointer"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex flex-col gap-2 pt-2 w-full">
                  <button
                    type="button"
                    disabled={deliveryProofPhotos.length === 0 && deliveryProofVideos.length === 0}
                    onClick={() =>
                      handleCompleteDelivery(targetContract.id, {
                        photos: deliveryProofPhotos,
                        videos: deliveryProofVideos
                      })
                    }
                    className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-neutral-300 disabled:text-neutral-500 disabled:cursor-not-allowed text-white text-xs font-bold cursor-pointer shadow-sm"
                  >
                    Confirm &amp; Mark Delivered (+{targetContract.deliveryFee} {targetContract.currency})
                  </button>
                <button
                  type="button"
                  onClick={() => {
                    setProofModalContractId(null);
                    setDeliveryProofPhotos([]);
                    setDeliveryProofVideos([]);
                  }}
                  className="w-full py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Tier 2 Driver Error Modal */}
      {driverTierErrorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white border border-rose-200 rounded-3xl p-6 shadow-2xl space-y-4 text-left animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center shrink-0">
                <AlertCircle className="w-6 h-6" />
              </div>
              <button
                type="button"
                onClick={() => setDriverTierErrorModal(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">{driverTierErrorModal.title}</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">{driverTierErrorModal.message}</p>
            </div>
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Required: <strong>Tier 2 (2 Verified Legal IDs)</strong> · Free ($0/mo)</span>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setDriverTierErrorModal(null);
                  onOpenVerificationModal?.(2);
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Verify Tier 2 Now</span>
              </button>
              <button
                type="button"
                onClick={() => setDriverTierErrorModal(null)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
