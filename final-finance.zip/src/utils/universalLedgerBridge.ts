import { UniversalLedgerItem, TransactionType, TransactionCategory, TransactionMode, TaxClassification } from '../types/ledger';
import { StockOrder, StockItem } from '../types/stocks';

const LEDGER_STORAGE_KEY = 'final_finance_universal_ledger';
export const LEDGER_UPDATED_EVENT = 'final_finance_ledger_updated';

/**
 * Initial historical ledger records pre-populated with realistic multi-modal trades,
 * personal & business equity allocations, money additions, and withdrawals.
 */
export const INITIAL_LEDGER_RECORDS: UniversalLedgerItem[] = [
  {
    id: 'rec-tx-1001',
    receiptNumber: 'REC-2026-X8920-001',
    taxYear: 2026,
    timestamp: '2026-08-23 14:15:22 UTC',
    dateIso: '2026-08-23T14:15:22Z',
    type: 'deposit',
    category: 'money_inflow',
    mode: 'fiat',
    title: 'Fedwire Institutional Cash Inflow',
    description: 'Primary liquidity deposit from verified institutional depository into USD Clearing Node.',
    amountUSD: 25000.00,
    feeUSD: 0.00,
    netAmountUSD: 25000.00,
    sourceOrDestination: 'JPMorgan Chase Prime (•••• 8920)',
    counterpartyOrIssuer: 'Fedwire Depository Clearing',
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable principal bank transfer into sovereign trading account.'
    },
    status: 'Audited',
    clearingNode: 'Sovereign Clearing Node #4810-CH (FedNow Bridge)',
    cryptographicHash: '0x8f2d91c7a4b39e65d8920fc41e80932bc1947e21',
    signature: 'SIG-VERIFIED-FED-9920194'
  },
  {
    id: 'rec-tx-1002-sell',
    receiptNumber: 'REC-2026-X8920-011',
    taxYear: 2026,
    timestamp: '2026-08-23 11:10:00 UTC',
    dateIso: '2026-08-23T11:10:00Z',
    type: 'stock_sell',
    category: 'personal_stock',
    mode: 'final_coin',
    title: 'Personal Stock Sale: $ALEX (Alex Rivera Sovereign Equity)',
    description: 'Executed SALE of 100 shares of Alex Rivera Personal Human Capital stock at $32.50/sh (Bought at $25.00/sh). Realized Profit: +$750.00 (+30.0%).',
    amountUSD: 3250.00,
    feeUSD: 3.25,
    netAmountUSD: 3246.75,
    sourceOrDestination: 'Final Coin (AFNL) Treasury Reserve',
    counterpartyOrIssuer: 'Alex Rivera (Sovereign Individual)',
    issuerHandle: '@arivera_sov',
    isPersonalStock: true,
    stockTicker: 'ALEX',
    stockName: 'Alex Rivera Sovereign Equity',
    shares: 100,
    unitPriceUSD: 32.50,
    buyPriceUSD: 25.00,
    costBasisUSD: 2500.00,
    realizedGainLossUSD: 746.75,
    realizedGainLossPercent: 29.87,
    paymentCoinSymbol: 'AFNL',
    paymentCoinAmount: 162.34,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: true,
      taxableAmountUSD: 746.75,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Personal stock capital gain realized on disposal. Taxable under IRS Form 8949 / Schedule D.'
    },
    status: 'Audited',
    clearingNode: 'Final Protocol L1 Smart Contract Node #01',
    cryptographicHash: '0x2b89f01c4a99120485c8194018274faa819385c9',
    signature: 'SIG-SOV-SALE-449102'
  },
  {
    id: 'rec-tx-1002',
    receiptNumber: 'REC-2026-X8920-002',
    taxYear: 2026,
    timestamp: '2026-08-22 16:30:10 UTC',
    dateIso: '2026-08-22T16:30:10Z',
    type: 'stock_buy',
    category: 'personal_stock',
    mode: 'final_coin',
    title: 'Personal Stock IPO: $ALEX (Alex Rivera Sovereign Equity)',
    description: 'Acquisition of 250 sovereign personal equity shares issued by Alex Rivera, settled with Final Coins ($AFNL).',
    amountUSD: 6250.00,
    feeUSD: 6.25,
    netAmountUSD: 6256.25,
    sourceOrDestination: 'Final Coin (AFNL) Treasury Reserve',
    counterpartyOrIssuer: 'Alex Rivera (Sovereign Individual)',
    issuerHandle: '@arivera_sov',
    isPersonalStock: true,
    stockTicker: 'ALEX',
    stockName: 'Alex Rivera Sovereign Equity',
    shares: 250,
    unitPriceUSD: 25.00,
    buyPriceUSD: 25.00,
    costBasisUSD: 6256.25,
    paymentCoinSymbol: 'AFNL',
    paymentCoinAmount: 312.81,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: false, // Purchase establishes cost basis
      taxableAmountUSD: 0,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Acquisition of sovereign personal human capital asset; cost basis recorded for future capital gains.'
    },
    status: 'Settled',
    clearingNode: 'Final Protocol L1 Smart Contract Node #01',
    cryptographicHash: '0x3c71a998b4ef2100874e532a81907cb58d4109fa',
    signature: 'SIG-SOV-IPO-8831049'
  },
  {
    id: 'rec-tx-1003',
    receiptNumber: 'REC-2026-X8920-003',
    taxYear: 2026,
    timestamp: '2026-08-21 11:20:45 UTC',
    dateIso: '2026-08-21T11:20:45Z',
    type: 'stock_buy',
    category: 'business_stock',
    mode: 'stable_coin',
    title: 'Corporate Stock IPO: $QVTX (QuantumVault Enterprise Systems)',
    description: 'Purchased 400 shares of QuantumVault Enterprise corporate equity settled in USD Coin ($USDC).',
    amountUSD: 18000.00,
    feeUSD: 9.00,
    netAmountUSD: 18009.00,
    sourceOrDestination: 'USD Coin (USDC Clearing Escrow)',
    counterpartyOrIssuer: 'QuantumVault Systems Inc.',
    issuerHandle: '@quantumvault_corp',
    isBusinessStock: true,
    stockTicker: 'QVTX',
    stockName: 'QuantumVault Enterprise Systems',
    shares: 400,
    unitPriceUSD: 45.00,
    buyPriceUSD: 45.00,
    costBasisUSD: 18009.00,
    paymentCoinSymbol: 'USDC',
    paymentCoinAmount: 18009.00,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Qualified corporate equity acquisition; established tax cost basis.'
    },
    status: 'Settled',
    clearingNode: 'USDC Institutional Escrow Node #12',
    cryptographicHash: '0x59a0f2b384617dc29a431057bc9810efc4103859',
    signature: 'SIG-CORP-IPO-449102'
  },
  {
    id: 'rec-tx-1004-sell',
    receiptNumber: 'REC-2026-X8920-012',
    taxYear: 2026,
    timestamp: '2026-08-21 09:40:00 UTC',
    dateIso: '2026-08-21T09:40:00Z',
    type: 'stock_sell',
    category: 'business_stock',
    mode: 'fiat',
    title: 'Business Stock Sale: $NEXA (Nexa Sovereign Robotics)',
    description: 'Executed SALE of 25 shares of Nexa Robotics at $74.75/sh (Bought at $65.00/sh). Realized Profit: +$243.75 (+15.0%).',
    amountUSD: 1868.75,
    feeUSD: 1.85,
    netAmountUSD: 1866.90,
    sourceOrDestination: 'USD Cash & Treasury Reserve',
    counterpartyOrIssuer: 'Sovereign Clearing Gateway',
    isBusinessStock: true,
    stockTicker: 'NEXA',
    stockName: 'Nexa Sovereign Robotics & AI Inc.',
    shares: 25,
    unitPriceUSD: 74.75,
    buyPriceUSD: 65.00,
    costBasisUSD: 1625.00,
    realizedGainLossUSD: 241.90,
    realizedGainLossPercent: 14.89,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: true,
      taxableAmountUSD: 241.90,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Corporate equity capital gain realized on sale. Proceeds and net gain reportable on Form 8949.'
    },
    status: 'Audited',
    clearingNode: 'Sovereign Node Clearing Gateway #09',
    cryptographicHash: '0x88491048295847b2019485c8194018274faa8193',
    signature: 'SIG-SOV-SALE-772109'
  },
  {
    id: 'rec-tx-1004',
    receiptNumber: 'REC-2026-X8920-004',
    taxYear: 2026,
    timestamp: '2026-08-20 18:44:00 UTC',
    dateIso: '2026-08-20T18:44:00Z',
    type: 'stock_buy',
    category: 'stock_trade',
    mode: 'final_coin',
    title: 'Stock Purchase: $HYPR (Hyperion Quantum Fusion)',
    description: 'Purchased 60 shares of Hyperion Quantum Fusion via Final Coin Sovereign Vault clearing.',
    amountUSD: 2910.00,
    feeUSD: 0.00,
    netAmountUSD: 2910.00,
    sourceOrDestination: 'Final Coin Sovereign Vault (AFNL)',
    counterpartyOrIssuer: 'Hyperion Quantum Fusion Dynamics',
    isBusinessStock: true,
    stockTicker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion Dynamics Inc.',
    shares: 60,
    unitPriceUSD: 48.50,
    buyPriceUSD: 48.50,
    costBasisUSD: 2910.00,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Platform-issued enterprise equity acquisition; establishing cost basis.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Node Clearing Gateway #09',
    cryptographicHash: '0x1948fe2b774019a8475c9284bb7195c2004810ae',
    signature: 'SIG-SOV-891048'
  },
  {
    id: 'rec-tx-1005',
    receiptNumber: 'REC-2026-X8920-005',
    taxYear: 2026,
    timestamp: '2026-08-19 14:10:00 UTC',
    dateIso: '2026-08-19T14:10:00Z',
    type: 'dividend',
    category: 'income_yield',
    mode: 'stable_coin',
    title: 'Stock Dividend Payout ($HYPR & $BSYN Equities)',
    description: 'Quarterly dividend disbursement credited directly to user reserve vaults.',
    amountUSD: 1850.00,
    feeUSD: 0.00,
    netAmountUSD: 1850.00,
    sourceOrDestination: 'Stock Market Exchange Depository',
    counterpartyOrIssuer: 'Hyperion & BioSynthetica Corporate Treasuries',
    taxClassification: {
      formMapping: 'Form 1099-DIV',
      taxableEvent: true,
      taxableAmountUSD: 1850.00,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Qualified dividend income reportable on IRS Form 1099-DIV.'
    },
    status: 'Audited',
    clearingNode: 'Depository Trust Company (DTC)',
    cryptographicHash: '0x661849bcde7104928504fbb1947265a09284715b',
    signature: 'SIG-DIV-9910481'
  },
  {
    id: 'rec-tx-1006',
    receiptNumber: 'REC-2026-X8920-006',
    taxYear: 2026,
    timestamp: '2026-08-18 09:30:00 UTC',
    dateIso: '2026-08-18T09:30:00Z',
    type: 'stock_buy',
    category: 'stock_trade',
    mode: 'gold_bullion',
    title: 'Gold-Backed Equity Purchase: $GLD (SPDR Gold Shares)',
    description: 'Purchased 150 shares of SPDR Gold Trust cleared against Zurich Freeport Gold bullion reserves.',
    amountUSD: 36750.00,
    feeUSD: 12.50,
    netAmountUSD: 36762.50,
    sourceOrDestination: 'Zurich Freeport Gold Vault (999.9 Fine)',
    counterpartyOrIssuer: 'SPDR Gold Trust / World Gold Council',
    stockTicker: 'GLD',
    stockName: 'SPDR Gold Trust',
    shares: 150,
    unitPriceUSD: 245.00,
    costBasisUSD: 36762.50,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Physical commodity trust equity; collectibles tax classification applies on future disposal.'
    },
    status: 'Settled',
    clearingNode: 'Zurich Freeport Sovereign Depository Vault 4B',
    cryptographicHash: '0xaa819385c91048295847b2019485c8194018274f',
    signature: 'SIG-GOLD-481920'
  },
  {
    id: 'rec-tx-1007',
    receiptNumber: 'REC-2026-X8920-007',
    taxYear: 2026,
    timestamp: '2026-08-17 19:12:00 UTC',
    dateIso: '2026-08-17T19:12:00Z',
    type: 'stock_buy',
    category: 'stock_trade',
    mode: 'crypto',
    title: 'Crypto-Settled Equity: $MSTR (MicroStrategy Inc.)',
    description: 'Purchased 120 shares of MicroStrategy equity settled seamlessly using Bitcoin ($BTC).',
    amountUSD: 16800.00,
    feeUSD: 8.50,
    netAmountUSD: 16808.50,
    sourceOrDestination: 'Web3 Multisig Ledger Wallet (BTC/ETH)',
    counterpartyOrIssuer: 'MicroStrategy Inc. / Coinbase Prime',
    stockTicker: 'MSTR',
    stockName: 'MicroStrategy Inc.',
    shares: 120,
    unitPriceUSD: 140.00,
    costBasisUSD: 16808.50,
    paymentCoinSymbol: 'BTC',
    paymentCoinAmount: 0.28,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: true, // Crypto disposal for asset is a dual tax event
      taxableAmountUSD: 450.00, // Small realized gain on crypto disposed
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Dual-asset transaction: Crypto property disposal with realized gain plus new stock cost basis.'
    },
    status: 'Settled',
    clearingNode: 'Coinbase Prime & Bitcoin L1 Bridge #04',
    cryptographicHash: '0xbb2948194018274758b29104928504fbb1947265',
    signature: 'SIG-CRYPTO-MSTR-991'
  },
  {
    id: 'rec-tx-1008',
    receiptNumber: 'REC-2026-X8920-008',
    taxYear: 2026,
    timestamp: '2026-08-16 12:00:00 UTC',
    dateIso: '2026-08-16T12:00:00Z',
    type: 'bank_withdraw',
    category: 'money_outflow',
    mode: 'fiat',
    title: 'External Bank Withdrawal (Instant FedNow)',
    description: 'Transferred trading capital to verified external Chase Checking account.',
    amountUSD: 12500.00,
    feeUSD: 0.00,
    netAmountUSD: 12500.00,
    sourceOrDestination: 'JPMorgan Chase Checking (•••• 4109)',
    counterpartyOrIssuer: 'JPMorgan Chase Prime Bank',
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable transfer of principal cash to personal commercial bank account.'
    },
    status: 'Audited',
    clearingNode: 'FedNow Instant Settlement Gateway #01',
    cryptographicHash: '0xee91048295847b2019485c8194018274faa81938',
    signature: 'SIG-WITHDRAW-FED-884102'
  },
  {
    id: 'rec-tx-1009',
    receiptNumber: 'REC-2026-X8920-009',
    taxYear: 2026,
    timestamp: '2026-08-15 15:40:00 UTC',
    dateIso: '2026-08-15T15:40:00Z',
    type: 'staking_reward',
    category: 'income_yield',
    mode: 'final_coin',
    title: 'AFNL Protocol Treasury Staking Reward',
    description: 'Algorithmic protocol yield reward minted and distributed for sovereign vault staking.',
    amountUSD: 1420.00,
    feeUSD: 0.00,
    netAmountUSD: 1420.00,
    sourceOrDestination: 'Final Coins Vault Protocol',
    counterpartyOrIssuer: 'Autonomous Final Protocol Treasury',
    paymentCoinSymbol: 'AFNL',
    paymentCoinAmount: 71.0,
    taxClassification: {
      formMapping: 'Form 1099-MISC',
      taxableEvent: true,
      taxableAmountUSD: 1420.00,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Staking reward income treated as ordinary income upon receipt.'
    },
    status: 'Audited',
    clearingNode: 'Final Smart Contract Staking Node #01',
    cryptographicHash: '0x9920194fbb1947265a09284715b661849bcde710',
    signature: 'SIG-STAKE-AFNL-77120'
  },
  {
    id: 'rec-tx-1010',
    receiptNumber: 'REC-2026-X8920-010',
    taxYear: 2026,
    timestamp: '2026-08-14 10:15:00 UTC',
    dateIso: '2026-08-14T10:15:00Z',
    type: 'barter_swap',
    category: 'barter',
    mode: 'fiat',
    title: 'Barter Commercial Contract Completed',
    description: 'Fulfilled bespoke sovereign architecture consultation in exchange for fine horology asset.',
    amountUSD: 3200.00,
    feeUSD: 0.00,
    netAmountUSD: 3200.00,
    sourceOrDestination: 'Barter Inventory Depository',
    counterpartyOrIssuer: 'Elena Rostova Sovereign Studio',
    taxClassification: {
      formMapping: 'Form 1099-B',
      taxableEvent: true,
      taxableAmountUSD: 3200.00,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Barter exchange transaction value reportable on IRS Form 1099-B.'
    },
    status: 'Audited',
    clearingNode: 'Geneva Barter Depository & Title Escrow',
    cryptographicHash: '0x7719485c8194018274faa819385c91048295847b',
    signature: 'SIG-BARTER-REV-41098'
  },
  {
    id: 'rec-tx-1011-loan-given',
    receiptNumber: 'REC-2026-X8920-013',
    taxYear: 2026,
    timestamp: '2026-08-13 16:20:00 UTC',
    dateIso: '2026-08-13T16:20:00Z',
    type: 'loan_issued',
    category: 'loan',
    mode: 'final_coin',
    title: 'Inter-Bank Final Coin Loan Issued (Giving Loan to @marcus_v)',
    description: 'Disbursed 5,000 AFNL sovereign liquidity loan at 6.5% APR (60-day term) to verified clearing partner @marcus_v.',
    amountUSD: 5000.00,
    feeUSD: 0.00,
    netAmountUSD: 5000.00,
    sourceOrDestination: 'Clearing Bank Liquidity Vault',
    counterpartyOrIssuer: 'Marcus Vance (@marcus_v)',
    paymentCoinSymbol: 'AFNL',
    paymentCoinAmount: 5000,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Loan principal disbursement (lending); non-taxable capital transfer.'
    },
    status: 'Audited',
    clearingNode: 'Sovereign Inter-Bank Clearing Node #04',
    cryptographicHash: '0x33491048295847b2019485c8194018274faa8194',
    signature: 'SIG-LOAN-GIVEN-99201'
  },
  {
    id: 'rec-tx-1012-loan-received',
    receiptNumber: 'REC-2026-X8920-014',
    taxYear: 2026,
    timestamp: '2026-08-12 11:05:00 UTC',
    dateIso: '2026-08-12T11:05:00Z',
    type: 'loan_received',
    category: 'loan',
    mode: 'stable_coin',
    title: 'Sovereign Credit Facility Received (Receiving Loan from Escrow)',
    description: 'Drawdown of 15,000 USDC sovereign credit facility at 4.2% APR from Treasury Clearing Escrow.',
    amountUSD: 15000.00,
    feeUSD: 0.00,
    netAmountUSD: 15000.00,
    sourceOrDestination: 'USD Coin Escrow Reserve (•••• 7810)',
    counterpartyOrIssuer: 'Sovereign Protocol Clearing Bank',
    paymentCoinSymbol: 'USDC',
    paymentCoinAmount: 15000,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Borrowed loan principal proceeds (borrowing); non-taxable inflow.'
    },
    status: 'Settled',
    clearingNode: 'USDC Institutional Escrow Node #12',
    cryptographicHash: '0x4489fe2b774019a8475c9284bb7195c2004810ae',
    signature: 'SIG-LOAN-RCV-77401'
  },
  {
    id: 'rec-tx-1013-barter-swap',
    receiptNumber: 'REC-2026-X8920-015',
    taxYear: 2026,
    timestamp: '2026-08-11 14:45:00 UTC',
    dateIso: '2026-08-11T14:45:00Z',
    type: 'barter_swap',
    category: 'barter',
    mode: 'gold_bullion',
    title: 'Atomic Barter Trade Completed (100oz Gold for Timepieces)',
    description: 'Transferred 100oz LBMA-certified physical gold bullion in atomic exchange for 2x Geneva Tourbillon Timepieces with verified title escrow.',
    amountUSD: 288000.00,
    feeUSD: 0.00,
    netAmountUSD: 288000.00,
    sourceOrDestination: 'Zurich Freeport Vault 1',
    counterpartyOrIssuer: 'Lord Sterling (@sterling_vault)',
    paymentCoinSymbol: 'XAU',
    paymentCoinAmount: 100,
    taxClassification: {
      formMapping: 'Form 1099-B',
      taxableEvent: true,
      taxableAmountUSD: 288000.00,
      holdingPeriod: 'Long-Term',
      taxDeductible: false,
      irsCategoryNote: 'IRS Form 1099-B Barter Exchange reportability for physical asset trade.'
    },
    status: 'Settled',
    clearingNode: 'Zurich Freeport Escrow Depository Node #01',
    cryptographicHash: '0x5590184fa981745c8194018274faa819485c8194',
    signature: 'SIG-BARTER-SWAP-88190'
  },
  {
    id: 'rec-tx-1014-product-purchase',
    receiptNumber: 'REC-2026-X8920-016',
    taxYear: 2026,
    timestamp: '2026-08-10 09:30:00 UTC',
    dateIso: '2026-08-10T09:30:00Z',
    type: 'product_purchase',
    category: 'product_service',
    mode: 'stable_coin',
    title: 'Product Purchase: Enterprise Clustered GPU Server Nodes',
    description: 'Direct commercial hardware acquisition of 4x HGX H100 8-GPU clustered server nodes for sovereign AI data center.',
    amountUSD: 140000.00,
    feeUSD: 0.00,
    netAmountUSD: 140000.00,
    sourceOrDestination: 'USD Coin Escrow Reserve (•••• 7810)',
    counterpartyOrIssuer: 'Sovereign Compute & Hardware Corp',
    paymentCoinSymbol: 'USDC',
    paymentCoinAmount: 140000,
    taxClassification: {
      formMapping: 'Schedule C / Business Expense',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: true,
      irsCategoryNote: 'Section 179 qualified hardware equipment purchase / capital asset depreciation.'
    },
    status: 'Audited',
    clearingNode: 'USDC Merchant Invoicing Node #08',
    cryptographicHash: '0x8891048295847b2019485c8194018274faa89912',
    signature: 'SIG-PROD-BUY-14000'
  },
  {
    id: 'rec-tx-1015-service-payment',
    receiptNumber: 'REC-2026-X8920-017',
    taxYear: 2026,
    timestamp: '2026-08-09 18:10:00 UTC',
    dateIso: '2026-08-09T18:10:00Z',
    type: 'service_payment',
    category: 'product_service',
    mode: 'final_coin',
    title: 'Professional Service: Smart Contract Formal Security Audit',
    description: 'Retained senior cryptography engineers for formal verification mathematical proofs and zero-day audit of sovereign multi-currency contracts.',
    amountUSD: 15000.00,
    feeUSD: 0.00,
    netAmountUSD: 15000.00,
    sourceOrDestination: 'Sovereign Final Coin Vault (AFNL)',
    counterpartyOrIssuer: 'Alex Morgan Security Lab (@alex_morgan)',
    paymentCoinSymbol: 'AFNL',
    paymentCoinAmount: 750,
    taxClassification: {
      formMapping: 'Schedule C / Business Expense',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: true,
      irsCategoryNote: 'Deductible professional software security consulting and verification service fee.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Service Clearing Node #02',
    cryptographicHash: '0x112019485c8194018274faa819485c8194998124',
    signature: 'SIG-SERV-AUDIT-750'
  },
  {
    id: 'rec-tx-1016-marketplace-sale',
    receiptNumber: 'REC-2026-X8920-018',
    taxYear: 2026,
    timestamp: '2026-08-08 12:00:00 UTC',
    dateIso: '2026-08-08T12:00:00Z',
    type: 'marketplace_sale',
    category: 'product_service',
    mode: 'fiat',
    title: 'Marketplace Product Revenue: Hardware Validator Module Sold',
    description: 'Sold custom biometric hardware security validator module to verified institutional custody partner.',
    amountUSD: 4800.00,
    feeUSD: 0.00,
    netAmountUSD: 4800.00,
    sourceOrDestination: 'Primary Commercial Settlement (•••• 9940)',
    counterpartyOrIssuer: 'Zurich Institutional Custody Node',
    taxClassification: {
      formMapping: 'Form 1099-MISC',
      taxableEvent: true,
      taxableAmountUSD: 4800.00,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Commercial marketplace product sales revenue.'
    },
    status: 'Audited',
    clearingNode: 'Marketplace Invoicing Gateway Node #09',
    cryptographicHash: '0x66491048295847b2019485c8194018274faa8772',
    signature: 'SIG-MKT-SALE-4800'
  }
];

/**
 * Loads universal ledger records from localStorage with fallback to default seed data.
 */
export function getStoredLedgerTransactions(userId: string = 'guest'): UniversalLedgerItem[] {
  try {
    const saved = localStorage.getItem(`${LEDGER_STORAGE_KEY}_${userId}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure new seed records (such as initial loans) exist in the user's ledger
        const existingIds = new Set(parsed.map((item: UniversalLedgerItem) => item.id));
        const missingInitial = INITIAL_LEDGER_RECORDS.filter(init => !existingIds.has(init.id));
        if (missingInitial.length > 0) {
          const merged = [...parsed, ...missingInitial];
          saveStoredLedgerTransactions(userId, merged);
          return merged;
        }
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to load ledger transactions from localStorage', err);
  }
  return INITIAL_LEDGER_RECORDS;
}

/**
 * Saves universal ledger records to localStorage and dispatches global sync event.
 */
export function saveStoredLedgerTransactions(userId: string = 'guest', transactions: UniversalLedgerItem[]): void {
  try {
    localStorage.setItem(`${LEDGER_STORAGE_KEY}_${userId}`, JSON.stringify(transactions));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT, { detail: { userId, count: transactions.length } }));
    }
  } catch (err) {
    console.warn('Failed to save ledger transactions to localStorage', err);
  }
}

/**
 * Appends a new transaction to the user's ledger and updates storage.
 */
export function recordLedgerTransaction(userId: string = 'guest', transaction: UniversalLedgerItem): UniversalLedgerItem[] {
  const current = getStoredLedgerTransactions(userId);
  const updated = [transaction, ...current];
  saveStoredLedgerTransactions(userId, updated);

  // Sync transaction to global system transactions ledger (final_finance_transactions)
  try {
    const savedGlobal = localStorage.getItem('final_finance_transactions');
    let globalList: UniversalLedgerItem[] = savedGlobal ? JSON.parse(savedGlobal) : [];
    if (!globalList.some(item => item.id === transaction.id)) {
      globalList = [transaction, ...globalList];
      localStorage.setItem('final_finance_transactions', JSON.stringify(globalList));
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('final_finance_global_transactions_updated', { detail: { transaction, count: globalList.length } }));
      }
    }
  } catch (err) {
    console.warn('Failed to sync global ledger transaction', err);
  }

  return updated;
}

/**
 * Creates a formatted ledger record from a Stock Order.
 */
export function createLedgerItemFromStockOrder(order: StockOrder, stockDetails?: StockItem): UniversalLedgerItem {
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-X${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

  let mode: TransactionMode = 'fiat';
  if (order.paymentSource.type === 'wallet_final') mode = 'final_coin';
  else if (order.paymentSource.type === 'wallet_stable') mode = 'stable_coin';
  else if (order.paymentSource.type === 'wallet_gold') mode = 'gold_bullion';
  else if (order.paymentSource.type === 'wallet_crypto' || order.paymentSource.type === 'crypto_wallet') mode = 'crypto';

  const isPersonal = order.isPersonalStock ?? (
    stockDetails?.issuanceType === 'personal' || 
    stockDetails?.assetCategory === 'personal' || 
    order.ticker === 'ALEX' ||
    order.stockName.toLowerCase().includes('personal') ||
    order.stockName.toLowerCase().includes('sovereign')
  );
  const isBusiness = !isPersonal;

  const type: TransactionType = order.side === 'buy' ? 'stock_buy' : 'stock_sell';
  const category: TransactionCategory = isPersonal ? 'personal_stock' : 'business_stock';

  const fee = Number((order.totalUSD * 0.0005).toFixed(2));
  const netAmount = order.side === 'buy' ? order.totalUSD + fee : order.totalUSD - fee;

  // Calculate Cost Basis and Realized Profit/Loss for Sells
  const buyPriceUSD = order.buyPriceUSD ?? (order.side === 'buy' ? order.price : undefined);
  const estimatedCostBasis = order.costBasisUSD ?? (
    order.side === 'sell'
      ? (buyPriceUSD ? order.shares * buyPriceUSD : order.shares * (order.price * 0.85))
      : netAmount
  );

  let realizedGainLossUSD: number | undefined = undefined;
  let realizedGainLossPercent: number | undefined = undefined;

  if (order.side === 'sell') {
    if (order.realizedGainLossUSD !== undefined) {
      realizedGainLossUSD = Number(order.realizedGainLossUSD.toFixed(2));
    } else {
      realizedGainLossUSD = Number((netAmount - estimatedCostBasis).toFixed(2));
    }

    if (order.realizedGainLossPercent !== undefined) {
      realizedGainLossPercent = Number(order.realizedGainLossPercent.toFixed(2));
    } else if (estimatedCostBasis > 0) {
      realizedGainLossPercent = Number(((realizedGainLossUSD / estimatedCostBasis) * 100).toFixed(2));
    }
  }

  const pnlSummary = realizedGainLossUSD !== undefined
    ? ` • Realized P&L: ${realizedGainLossUSD >= 0 ? '+' : ''}$${realizedGainLossUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} (${(realizedGainLossPercent ?? 0) >= 0 ? '+' : ''}${(realizedGainLossPercent ?? 0).toFixed(2)}%)`
    : '';

  const titlePrefix = isPersonal 
    ? (order.side === 'buy' ? 'Personal Stock Purchase' : 'Personal Stock Sale')
    : (order.side === 'buy' ? 'Business Stock Purchase' : 'Business Stock Sale');
  const title = `${titlePrefix}: $${order.ticker} (${order.stockName})`;

  const formMapping = 'Form 8949 / Schedule D';
  const isTaxableEvent = order.side === 'sell';
  const taxableAmount = isTaxableEvent ? Math.max(0, realizedGainLossUSD ?? 0) : 0;

  const desc = order.side === 'buy'
    ? `Acquisition of ${order.shares} shares of ${isPersonal ? 'Personal' : 'Corporate'} equity in ${order.stockName} ($${order.ticker}) at $${order.price.toFixed(2)}/sh via ${order.paymentSource.label}. Cost basis recorded: $${netAmount.toFixed(2)}.`
    : `Executed SALE of ${order.shares} shares of ${isPersonal ? 'Personal' : 'Corporate'} stock ${order.stockName} ($${order.ticker}) at $${order.price.toFixed(2)}/sh (Cost Basis: $${estimatedCostBasis.toFixed(2)})${pnlSummary}. Settled into ${order.paymentSource.label}.`;

  return {
    id: `rec-order-${order.id}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type,
    category,
    mode,
    title,
    description: desc,
    amountUSD: order.totalUSD,
    feeUSD: fee,
    netAmountUSD: netAmount,
    sourceOrDestination: order.paymentSource.label,
    counterpartyOrIssuer: stockDetails?.issuerName || order.stockName,
    issuerHandle: stockDetails?.issuerHandle,
    isPersonalStock: isPersonal,
    isBusinessStock: isBusiness,
    stockTicker: order.ticker,
    stockName: order.stockName,
    shares: order.shares,
    unitPriceUSD: order.price,
    buyPriceUSD,
    costBasisUSD: estimatedCostBasis,
    realizedGainLossUSD,
    realizedGainLossPercent,
    paymentCoinSymbol: stockDetails?.issuanceCoinSymbol || (mode === 'final_coin' ? 'AFNL' : mode === 'stable_coin' ? 'USDC' : mode === 'crypto' ? 'BTC' : undefined),
    taxClassification: {
      formMapping,
      taxableEvent: isTaxableEvent,
      taxableAmountUSD: taxableAmount,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: order.side === 'buy' 
        ? `Capital asset acquisition of ${isPersonal ? 'Personal' : 'Corporate'} equity. Total cost basis recorded for future tax calculations.` 
        : (realizedGainLossUSD !== undefined && realizedGainLossUSD >= 0)
          ? `Realized short-term capital gain ($${realizedGainLossUSD.toFixed(2)}) on ${isPersonal ? 'Personal' : 'Corporate'} stock disposal. Reportable on IRS Form 8949 / Schedule D.`
          : `Realized short-term capital loss ($${Math.abs(realizedGainLossUSD || 0).toFixed(2)}) on ${isPersonal ? 'Personal' : 'Corporate'} stock disposal. Reportable on IRS Form 8949 for capital loss offset.`
    },
    status: 'Settled',
    clearingNode: 'Sovereign Clearing Node #4810-CH',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-TRADE-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from an Account Deposit.
 */
export function createLedgerItemFromDeposit(
  amountUSD: number, 
  sourceLabel: string, 
  mode: TransactionMode = 'fiat'
): UniversalLedgerItem {
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-DEP-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-dep-${Date.now()}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'deposit',
    category: 'money_inflow',
    mode,
    title: `Account Capital Addition (+${amountUSD >= 1000 ? `$${(amountUSD / 1000).toFixed(0)}k` : `$${amountUSD}`})`,
    description: `Added $${amountUSD.toLocaleString()} into trading account from ${sourceLabel}.`,
    amountUSD,
    feeUSD: 0,
    netAmountUSD: amountUSD,
    sourceOrDestination: sourceLabel,
    counterpartyOrIssuer: 'Sovereign Clearing Depository',
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable cash inflow / principal capital addition.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Clearing Node #4810-CH',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-DEP-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from a Bank Withdrawal.
 */
export function createLedgerItemFromWithdrawal(
  amountUSD: number, 
  bankLabel: string, 
  methodType: string = 'instant'
): UniversalLedgerItem {
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-WTH-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-wth-${Date.now()}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'bank_withdraw',
    category: 'money_outflow',
    mode: 'fiat',
    title: `Bank Withdrawal (${methodType.toUpperCase()} Transfer)`,
    description: `Withdrew $${amountUSD.toLocaleString()} from cash reserve to ${bankLabel}.`,
    amountUSD,
    feeUSD: 0,
    netAmountUSD: amountUSD,
    sourceOrDestination: bankLabel,
    counterpartyOrIssuer: 'External Depository Institution',
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable principal capital withdrawal to personal bank account.'
    },
    status: 'Settled',
    clearingNode: 'FedNow / ACH Clearing Gateway',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-WTH-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from a Peer-to-Peer Transfer (Sent or Received).
 */
export function createLedgerItemFromP2PTransfer(params: {
  amount: number;
  amountUSD: number;
  coinSymbol: string;
  coinName: string;
  mode: TransactionMode;
  senderUser: { id: string; name: string; handle?: string };
  recipientUser: { id: string; name: string; handle?: string };
  memo?: string;
  isSender: boolean;
}): UniversalLedgerItem {
  const {
    amount,
    amountUSD,
    coinSymbol,
    coinName,
    mode,
    senderUser,
    recipientUser,
    memo,
    isSender
  } = params;

  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-P2P-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

  const otherUserHandle = isSender
    ? (recipientUser.handle || recipientUser.name)
    : (senderUser.handle || senderUser.name);
  const otherUserName = isSender ? recipientUser.name : senderUser.name;

  const title = isSender
    ? `Peer Transfer Out: ${amount.toLocaleString()} ${coinSymbol} to @${otherUserHandle}`
    : `Peer Transfer In: +${amount.toLocaleString()} ${coinSymbol} from @${otherUserHandle}`;

  const description = isSender
    ? `Direct sovereign transfer of ${amount.toLocaleString()} ${coinSymbol} (${coinName} • ≈ $${amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD) sent to ${otherUserName} (@${otherUserHandle}).${memo ? ` Note: "${memo}"` : ''}`
    : `Direct sovereign transfer of ${amount.toLocaleString()} ${coinSymbol} (${coinName} • ≈ $${amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD) received from ${otherUserName} (@${otherUserHandle}).${memo ? ` Note: "${memo}"` : ''}`;

  return {
    id: `rec-p2p-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: isSender ? 'p2p_transfer' : 'deposit',
    category: isSender ? 'transfer' : 'money_inflow',
    mode,
    title,
    description,
    amountUSD,
    feeUSD: 0.00,
    netAmountUSD: amountUSD,
    sourceOrDestination: isSender
      ? `To @${recipientUser.handle || recipientUser.name} Sovereign Node`
      : `From @${senderUser.handle || senderUser.name} Sovereign Node`,
    counterpartyOrIssuer: `${otherUserName} (@${otherUserHandle})`,
    paymentCoinSymbol: coinSymbol,
    paymentCoinAmount: amount,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable peer-to-peer sovereign transfer / direct gift between verified sovereign identities.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign P2P Instant Settlement Node #09 (Zero-Fee Clearing)',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-P2P-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from a Vault Custody Deposit.
 */
export function createLedgerItemFromVaultDeposit(params: {
  vaultId: string;
  vaultName: string;
  amountUSD: number;
  assetName: string;
  mode?: TransactionMode;
}): UniversalLedgerItem {
  const { vaultId, vaultName, amountUSD, assetName, mode = 'gold_bullion' } = params;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-VLT-DEP-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-vlt-dep-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'deposit',
    category: 'money_inflow',
    mode,
    title: `Vault Allocation: ${vaultName}`,
    description: `Allocated $${amountUSD.toLocaleString()} (${assetName}) into ${vaultName} (${vaultId.toUpperCase()}) with Grade AAA custodian certification.`,
    amountUSD,
    feeUSD: 0,
    netAmountUSD: amountUSD,
    sourceOrDestination: `Direct Inbound Treasury Allocation`,
    counterpartyOrIssuer: `${vaultName} Custody Reserve`,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable principal vault custody deposit and asset backing allocation.'
    },
    status: 'Audited',
    clearingNode: 'Zurich / London Multi-Sig Cold Vault Node #04',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-VLT-DEP-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from a Vault Custody Withdrawal.
 */
export function createLedgerItemFromVaultWithdrawal(params: {
  vaultId: string;
  vaultName: string;
  amountUSD: number;
  mode?: TransactionMode;
}): UniversalLedgerItem {
  const { vaultId, vaultName, amountUSD, mode = 'gold_bullion' } = params;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-VLT-WTH-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-vlt-wth-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'bank_withdraw',
    category: 'money_outflow',
    mode,
    title: `Vault Settlement: ${vaultName}`,
    description: `Settled and withdrew $${amountUSD.toLocaleString()} from ${vaultName} (${vaultId.toUpperCase()}) reserve back to primary operating cash.`,
    amountUSD,
    feeUSD: 0,
    netAmountUSD: amountUSD,
    sourceOrDestination: `${vaultName} Custody Reserve`,
    counterpartyOrIssuer: `Operating Treasury Account`,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable principal vault capital withdrawal.'
    },
    status: 'Audited',
    clearingNode: 'Zurich / London Multi-Sig Cold Vault Node #04',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-VLT-WTH-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from an Instant Multi-Asset Swap.
 */
export function createLedgerItemFromVaultSwap(params: {
  fromAsset: string;
  toAsset: string;
  fromAmount: number;
  toAmount: number;
  amountUSD: number;
  mode?: TransactionMode;
}): UniversalLedgerItem {
  const { fromAsset, toAsset, fromAmount, toAmount, amountUSD, mode = 'stable_coin' } = params;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-SWAP-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-swap-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'vault_swap',
    category: 'barter',
    mode,
    title: `Multi-Asset Swap: ${fromAsset} ➔ ${toAsset}`,
    description: `Swapped ${fromAmount.toLocaleString()} ${fromAsset} for ${toAmount.toLocaleString()} ${toAsset} ($${amountUSD.toLocaleString()} USD reference value) via Zero-Slippage Liquidity Router.`,
    amountUSD,
    feeUSD: 0.00,
    netAmountUSD: amountUSD,
    sourceOrDestination: `${fromAsset} Reserve Pool`,
    counterpartyOrIssuer: `Final Protocol Liquidity Mesh`,
    paymentCoinSymbol: toAsset,
    paymentCoinAmount: toAmount,
    taxClassification: {
      formMapping: 'Form 8949 / Schedule D',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'Short-Term',
      taxDeductible: false,
      irsCategoryNote: 'Like-kind multi-asset cryptographic swap; cost basis rolled over.'
    },
    status: 'Settled',
    clearingNode: 'Zero-Slippage Atomic Settlement Engine #01',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-SWAP-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from a Sovereign Grant or UBI claim / deposit.
 */
export function createLedgerItemFromGrantOrSubsidy(params: {
  title?: string;
  description?: string;
  grantName?: string;
  amountAFNL: number;
  amountUSD: number;
  isSignupGrant?: boolean;
  isSignup?: boolean;
}): UniversalLedgerItem {
  const { title, description, grantName, amountAFNL, amountUSD, isSignupGrant, isSignup } = params;
  const isInitialSignup = isSignupGrant || isSignup;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-GRANT-${Math.floor(1000 + Math.random() * 9000)}`;

  const finalTitle = isInitialSignup 
    ? `Sovereign Signup Grant: +${amountAFNL.toLocaleString()} AFNL` 
    : (grantName || title || 'Sovereign Community Subsidy Accrual');

  const finalDescription = description || (
    isInitialSignup 
      ? `One-time +${amountAFNL.toLocaleString()} AFNL protocol bonus transferred to Sovereign Final Wallet.` 
      : `Accrued protocol community subsidy of +${amountAFNL.toLocaleString()} AFNL deposited into Sovereign Final Wallet.`
  );

  return {
    id: `rec-grant-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'grant_claim',
    category: 'grant_subsidy',
    mode: 'final_coin',
    title: finalTitle,
    description: finalDescription,
    amountUSD,
    feeUSD: 0.00,
    netAmountUSD: amountUSD,
    sourceOrDestination: `Sovereign Protocol Grant Fund (Smart Contract #AFNL-GRANT)`,
    counterpartyOrIssuer: `Protocol Treasury & Sovereign UBI Node`,
    paymentCoinSymbol: 'AFNL',
    paymentCoinAmount: amountAFNL,
    taxClassification: {
      formMapping: 'Sovereign Grant',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Sovereign protocol UBI entitlement & institutional development grant. Exempt from capital taxation at distribution.'
    },
    status: 'Audited',
    clearingNode: 'Sovereign UBI Mint Node #01',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-GRANT-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

export const createLedgerItemFromGrantClaim = createLedgerItemFromGrantOrSubsidy;

/**
 * Creates a formatted ledger record from a Crowdfunding / Charity Campaign Donation.
 */
export function createLedgerItemFromCampaignDonation(params: {
  campaignId?: string;
  campaignTitle: string;
  amountUSD: number;
  modality: string;
  recipientOrg?: string;
  message?: string;
  isCharity?: boolean;
}): UniversalLedgerItem {
  const { campaignTitle, amountUSD, modality, recipientOrg, message, isCharity } = params;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-DON-${Math.floor(1000 + Math.random() * 9000)}`;

  let mode: TransactionMode = 'fiat';
  if (modality.toLowerCase().includes('final')) mode = 'final_coin';
  else if (modality.toLowerCase().includes('stable') || modality.toLowerCase().includes('usdc')) mode = 'stable_coin';
  else if (modality.toLowerCase().includes('gold') || modality.toLowerCase().includes('bullion')) mode = 'gold_bullion';
  else if (modality.toLowerCase().includes('crypto') || modality.toLowerCase().includes('btc') || modality.toLowerCase().includes('eth')) mode = 'crypto';

  return {
    id: `rec-don-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'campaign_donation',
    category: isCharity ? 'charity_donation' : 'charity_donation',
    mode,
    title: `Campaign Contribution: "${campaignTitle}"`,
    description: `Contributed $${amountUSD.toLocaleString()} USD via ${modality} to "${campaignTitle}".${message ? ` Note: "${message}"` : ''}`,
    amountUSD,
    feeUSD: 0.00,
    netAmountUSD: -amountUSD,
    sourceOrDestination: `Campaign Escrow (${modality})`,
    counterpartyOrIssuer: recipientOrg || campaignTitle,
    taxClassification: {
      formMapping: 'Schedule C / Business Expense',
      taxableEvent: true,
      taxableAmountUSD: -amountUSD,
      holdingPeriod: 'N/A',
      taxDeductible: true,
      irsCategoryNote: 'Qualified philanthropic contribution and public initiative grant. Eligible for tax deduction on IRS Schedule C / Itemized Form.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Crowdfund Smart Contract #99',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-DON-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from a Marketplace Product or Service Purchase.
 */
export function createLedgerItemFromProductPurchase(params: {
  productName?: string;
  listingTitle?: string;
  category?: string;
  amountUSD?: number;
  priceUSD?: number;
  quantity?: number;
  sellerName?: string;
  sellerHandle?: string;
  sellerId?: string;
  paymentMethod?: string;
  mode?: TransactionMode;
}): UniversalLedgerItem {
  const { productName, listingTitle, category = 'General Goods', amountUSD, priceUSD, quantity = 1, sellerName, sellerHandle, sellerId, paymentMethod = 'Final Coin', mode = 'final_coin' } = params;
  const effectiveAmountUSD = amountUSD !== undefined ? amountUSD : (priceUSD !== undefined ? priceUSD : 0);
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-MKT-${Math.floor(1000 + Math.random() * 9000)}`;
  const titleName = productName || listingTitle || 'Marketplace Item';
  const merchantName = sellerName || (sellerId ? `@${sellerId}` : 'Marketplace Vendor');

  return {
    id: `rec-mkt-buy-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'product_purchase',
    category: 'product_service',
    mode,
    title: `Marketplace Purchase: ${titleName}`,
    description: `Purchased ${quantity > 1 ? `${quantity}x ` : ''}${titleName} (${category}) for $${effectiveAmountUSD.toLocaleString()} USD from ${merchantName}${sellerHandle ? ` (@${sellerHandle})` : ''} via ${paymentMethod}.`,
    amountUSD: effectiveAmountUSD,
    feeUSD: Number((effectiveAmountUSD * 0.002).toFixed(2)),
    netAmountUSD: -effectiveAmountUSD,
    sourceOrDestination: paymentMethod,
    counterpartyOrIssuer: merchantName,
    issuerHandle: sellerHandle,
    taxClassification: {
      formMapping: 'Schedule C / Business Expense',
      taxableEvent: true,
      taxableAmountUSD: -effectiveAmountUSD,
      holdingPeriod: 'N/A',
      taxDeductible: true,
      irsCategoryNote: 'Qualified business technology / asset procurement expenditure.'
    },
    status: 'Settled',
    clearingNode: 'Marketplace Invoicing Gateway Node #09',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-MKT-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

export const createLedgerItemFromMarketplacePurchase = createLedgerItemFromProductPurchase;

/**
 * Creates a formatted ledger record from a Barter Trade Proposal or Exchange.
 */
export function createLedgerItemFromBarter(params: {
  offeredDescription: string;
  targetListingTitle: string;
  counterpartyName: string;
  sweetenerUSD?: number;
  estimatedTotalValueUSD: number;
}): UniversalLedgerItem {
  const { offeredDescription, targetListingTitle, counterpartyName, sweetenerUSD = 0, estimatedTotalValueUSD } = params;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-BARTER-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-barter-trade-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'barter_swap',
    category: 'barter',
    mode: sweetenerUSD > 0 ? 'fiat' : 'final_coin',
    title: `Barter Trade: ${targetListingTitle}`,
    description: `Offered [${offeredDescription}] in exchange for [${targetListingTitle}] with ${counterpartyName}.${sweetenerUSD > 0 ? ` Sweetener: $${sweetenerUSD.toLocaleString()} USD.` : ''}`,
    amountUSD: estimatedTotalValueUSD,
    feeUSD: 0.00,
    netAmountUSD: estimatedTotalValueUSD,
    sourceOrDestination: 'Barter Inventory Depository',
    counterpartyOrIssuer: counterpartyName,
    taxClassification: {
      formMapping: 'Form 1099-B',
      taxableEvent: true,
      taxableAmountUSD: estimatedTotalValueUSD,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Barter exchange transaction value reportable on IRS Form 1099-B.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Barter Depository & Title Escrow Node #01',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-BARTER-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from Barter Goods Inventory Addition.
 */
export function createLedgerItemFromBarterGoodAdded(params: {
  goodName: string;
  quantity: number;
  unitValue: number;
  unitLabel: string;
}): UniversalLedgerItem {
  const { goodName, quantity, unitValue, unitLabel } = params;
  const totalVal = quantity * unitValue;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-BARTER-G-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-barter-good-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'deposit',
    category: 'barter',
    mode: 'gold_bullion',
    title: `Barter Inventory Enrolled: ${goodName}`,
    description: `Added ${quantity} ${unitLabel} of ${goodName} valued at $${totalVal.toLocaleString()} USD ($${unitValue}/unit) to peer barter asset catalog.`,
    amountUSD: totalVal,
    feeUSD: 0,
    netAmountUSD: totalVal,
    sourceOrDestination: `Physical Custody / Warehouse Inventory`,
    counterpartyOrIssuer: `Sovereign Barter Desk`,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Asset enrollment into barter escrow catalog. Capital gains recognized only upon final disposal or trade completion.'
    },
    status: 'Audited',
    clearingNode: 'Sovereign Barter Registry Node #02',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-BTR-G-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from Barter Service Retainer Addition.
 */
export function createLedgerItemFromBarterServiceAdded(params: {
  serviceName: string;
  availableUnits: number;
  hourlyRate: number;
  unitType: string;
}): UniversalLedgerItem {
  const { serviceName, availableUnits, hourlyRate, unitType } = params;
  const totalVal = availableUnits * hourlyRate;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-BARTER-S-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-barter-srv-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'deposit',
    category: 'barter',
    mode: 'final_coin',
    title: `Barter Service Registered: ${serviceName}`,
    description: `Registered ${availableUnits} ${unitType} of professional services for ${serviceName} @ $${hourlyRate}/unit (Total capacity: $${totalVal.toLocaleString()} USD).`,
    amountUSD: totalVal,
    feeUSD: 0,
    netAmountUSD: totalVal,
    sourceOrDestination: `Professional Service Commitment`,
    counterpartyOrIssuer: `Sovereign Barter Desk`,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Service capacity reservation. Income recognized upon delivery under Form 1099-MISC / Schedule C.'
    },
    status: 'Audited',
    clearingNode: 'Sovereign Barter Registry Node #02',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-BTR-S-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from Card Top-Up.
 */
export function createLedgerItemFromCardTopUp(params: {
  amountUSD: number;
  cardLast4: string;
  brand: string;
  targetFiatName: string;
}): UniversalLedgerItem {
  const { amountUSD, cardLast4, brand, targetFiatName } = params;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-CARD-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-card-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'deposit',
    category: 'money_inflow',
    mode: 'fiat',
    title: `Card Liquidity Top-Up (+${amountUSD >= 1000 ? `$${(amountUSD / 1000).toFixed(0)}k` : `$${amountUSD}`})`,
    description: `Funded $${amountUSD.toLocaleString()} USD into ${targetFiatName} via ${brand.toUpperCase()} card (•••• ${cardLast4}).`,
    amountUSD,
    feeUSD: 0,
    netAmountUSD: amountUSD,
    sourceOrDestination: `${brand.toUpperCase()} Card (•••• ${cardLast4})`,
    counterpartyOrIssuer: `Card Payment Gateway Network`,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable principal card liquidity deposit into sovereign wallet balance.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Card Processing Node #14',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-CARD-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Creates a formatted ledger record from Crypto Wallet Inbound Deposit.
 */
export function createLedgerItemFromCryptoDeposit(params: {
  amountUSD: number;
  units: number;
  symbol: string;
  walletName: string;
}): UniversalLedgerItem {
  const { amountUSD, units, symbol, walletName } = params;
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-CRYPTO-DEP-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `rec-crypto-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: 'deposit',
    category: 'money_inflow',
    mode: 'crypto',
    title: `Web3 Crypto Inflow: +${units.toFixed(4)} ${symbol}`,
    description: `Deposited ${units.toFixed(4)} ${symbol} ($${amountUSD.toLocaleString()} USD) from connected ${walletName} into sovereign crypto treasury.`,
    amountUSD,
    feeUSD: 0,
    netAmountUSD: amountUSD,
    sourceOrDestination: `${walletName} Web3 Bridge`,
    counterpartyOrIssuer: `Decentralized Blockchain Relayer`,
    paymentCoinSymbol: symbol,
    paymentCoinAmount: units,
    taxClassification: {
      formMapping: 'Non-Taxable Transfer',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Non-taxable principal cryptocurrency transfer from user cold storage wallet into trading balance.'
    },
    status: 'Settled',
    clearingNode: 'Web3 Multi-Chain Bridge Node #08',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-CRYPTO-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Exports all transactions as an IRS-compatible CSV ledger file.
 */
export function exportLedgerToCSV(transactions: UniversalLedgerItem[], fileName = 'Sovereign_Tax_Ledger_2026.csv'): void {
  const headers = [
    'Receipt Number',
    'Date & Time (UTC)',
    'Type',
    'Category',
    'Transaction Mode',
    'Title / Asset',
    'Ticker',
    'Shares',
    'Unit Price (USD)',
    'Gross Amount (USD)',
    'Fee (USD)',
    'Net Amount (USD)',
    'Source / Destination',
    'Counterparty / Issuer',
    'IRS Tax Form Mapping',
    'Taxable Event?',
    'Taxable Amount (USD)',
    'Holding Period',
    'Cryptographic Hash',
    'Status'
  ];

  const rows = transactions.map((t) => [
    `"${t.receiptNumber}"`,
    `"${t.timestamp}"`,
    `"${t.type}"`,
    `"${t.category}"`,
    `"${t.mode}"`,
    `"${t.title.replace(/"/g, '""')}"`,
    `"${t.stockTicker || 'N/A'}"`,
    t.shares ?? 'N/A',
    t.unitPriceUSD ? `$${t.unitPriceUSD.toFixed(2)}` : 'N/A',
    `$${t.amountUSD.toFixed(2)}`,
    `$${t.feeUSD.toFixed(2)}`,
    `$${t.netAmountUSD.toFixed(2)}`,
    `"${t.sourceOrDestination.replace(/"/g, '""')}"`,
    `"${t.counterpartyOrIssuer.replace(/"/g, '""')}"`,
    `"${t.taxClassification.formMapping}"`,
    t.taxClassification.taxableEvent ? 'YES' : 'NO',
    `$${t.taxClassification.taxableAmountUSD.toFixed(2)}`,
    `"${t.taxClassification.holdingPeriod || 'N/A'}"`,
    `"${t.cryptographicHash}"`,
    `"${t.status}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
