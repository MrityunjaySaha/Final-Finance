import { MarketplaceListing, ListingStatus, ListingVisibility } from '../types/marketplace';
import { isUserInAnyGroup } from './friendGroupService';
import { areUsersBlockedEitherWay } from './socialService';

const MARKETPLACE_STORAGE_KEY = 'final_finance_marketplace_listings_v5';

const INITIAL_MARKETPLACE_LISTINGS: MarketplaceListing[] = [
  {
    id: 'mkt-gold-1',
    userId: 'user-lord_sterling',
    creatorName: 'Lord Sterling',
    creatorHandle: 'sterling_vault',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 288000,
    title: '100oz 24K Imperial Gold Ingot (999.9 Purity)',
    category: 'Precious Metals & Bullion',
    description: 'Directly allocated LBMA-certified physical gold bullion stored in Zurich Freeport vault with cryptographic serial matrix #AFNL-9981.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'USD', 'BTC'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: '50% Physical Horology + 50% AFNL Coins or USDC',
      customExchangeOffers: 'Seeking Geneva tourbillon timepieces, fine silver ingots, or legal escrow credits.'
    },
    barterTerms: {
      desiredTrades: 'Geneva Tourbillon Timepieces, Enterprise AI GPU Servers, or Real Estate Title Deeds',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 288000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 14400 },
    stableCoinsPricing: { symbol: 'USDC', amount: 288000, network: 'Polygon & Ethereum' },
    fiatPricing: { currencyCode: 'USD', amount: 288000 },
    cryptoPricing: { symbol: 'BTC', amount: 3.04, network: 'Bitcoin' },
    quantity: 4,
    unitLabel: 'bars',
    condition: 'Brand New',
    location: 'Zurich Freeport Vault 1',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    tags: ['Gold', 'Bullion', 'LBMA', 'Zurich', 'Vault1'],
    createdAt: '2024-03-01T12:00:00.000Z'
  },
  {
    id: 'mkt-sec-audit',
    userId: 'demo-vip-alex',
    creatorName: 'Alex Morgan',
    creatorHandle: 'alex_morgan',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'service',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USDC',
    primaryPriceUSD: 15000,
    title: 'Smart Contract Formal Verification & Zero-Day Audit',
    category: 'Cybersecurity & Auditing',
    description: 'Comprehensive static analysis, symbolic execution bytecode proof, and multi-sig security audit by senior cryptographers.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'crypto'],
    acceptedCurrencyList: ['USDC', 'AFNL', 'ETH'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: 'Open to barter trade for physical bullion or GPU compute hours',
      customExchangeOffers: 'Accepting gold bullion, platinum watches, or AFNL'
    },
    barterTerms: {
      desiredTrades: 'Physical Gold Bullion, High-Density GPU Hardware, or Swiss Freeport Storage Credits',
      desiredExchangeType: 'any',
      openToOffers: true,
      estimatedValueUSD: 15000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 750 },
    stableCoinsPricing: { symbol: 'USDC', amount: 15000, network: 'Polygon' },
    cryptoPricing: { symbol: 'ETH', amount: 5.32, network: 'Ethereum' },
    availableUnits: 20,
    unitType: 'Hours',
    turnaroundTime: '2-3 Business Days',
    deliverables: 'Formal Verification Audit PDF Report + Remediation Review',
    skills: ['EVM', 'Formal Verification', 'Solidity', 'Rust', 'Security Proofs'],
    imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80',
    tags: ['Audit', 'Security', 'SmartContract', 'Verification'],
    createdAt: '2024-03-05T15:30:00.000Z'
  },
  {
    id: 'mkt-private-bullion-alex',
    userId: 'demo-vip-alex',
    creatorName: 'Alex Morgan',
    creatorHandle: 'alex_morgan',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'barter',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 120000,
    title: 'Private Syndicate 50oz Swiss Vault Ingot Allocation',
    category: 'Precious Metals & Bullion',
    description: 'Direct allocated bullion available strictly to Swiss Bullion Syndicate partners & verified friends.',
    status: 'uploaded',
    visibility: 'custom_group',
    allowedGroupIds: ['grp-bullion-syndicate'],
    allowedGroupNames: ['Swiss Bullion Syndicate'],
    acceptedSettlements: ['barter', 'final_coins'],
    acceptedCurrencyList: ['AFNL'],
    barterTerms: {
      desiredTrades: 'Geneva Tourbillon or Enterprise AI GPUs',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 120000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 6000 },
    quantity: 1,
    unitLabel: 'bars',
    condition: 'Brand New',
    location: 'Zurich Vault Private Cell',
    imageUrl: 'https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?auto=format&fit=crop&w=800&q=80',
    tags: ['Syndicate', 'Bullion', 'Gold', 'Private'],
    createdAt: '2024-03-06T10:00:00.000Z'
  },
  {
    id: 'mkt-buy-gpu',
    userId: 'user-kaelen_reserve',
    creatorName: 'Kaelen Vance',
    creatorHandle: 'kaelen_reserve',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'buy',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'USD',
    primaryPriceUSD: 85000,
    title: '[WANTED / BUYING] 8x NVIDIA H100 SXM5 80GB GPU Server Rigs',
    category: 'Hardware & Compute',
    description: 'Looking to purchase or barter for verified enterprise HGX H100 8-GPU clustered server nodes. Immediate settlement in USD, USDC, or AFNL.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['fiat', 'stable_coins', 'final_coins', 'barter'],
    acceptedCurrencyList: ['USD', 'USDC', 'AFNL'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: 'Can offer USD wire or barter tokenized sovereign gold certificates',
      customExchangeOffers: 'Accepting hardware delivery in Zurich or Northern Virginia datacenters'
    },
    barterTerms: {
      desiredTrades: 'Offering Zurich LBMA Gold Ingots or Staked ETH Validator Bonds in Exchange',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 85000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 4250 },
    stableCoinsPricing: { symbol: 'USDC', amount: 85000, network: 'Ethereum' },
    fiatPricing: { currencyCode: 'USD', amount: 85000 },
    quantity: 2,
    unitLabel: 'nodes',
    condition: 'Brand New',
    location: 'Zurich / US East',
    imageUrl: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=800&q=80',
    tags: ['GPU', 'H100', 'Compute', 'AI', 'Wanted'],
    createdAt: '2024-03-07T18:00:00.000Z'
  },
  {
    id: 'mkt-watch-1',
    userId: 'user-elena_rostova',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena_rostova',
    creatorAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'barter',
    primaryPriceUSD: 145000,
    title: 'Geneva Celestial Tourbillon Platinum Horology (#07/20)',
    category: 'Luxury Goods & Watches',
    description: 'Rare platinum astronomical timepiece featuring celestial star-chart complications and sapphire crystal tourbillon cage.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat'],
    acceptedCurrencyList: ['AFNL', 'USDC', 'EUR'],
    crossTransactionalTerms: {
      acceptSplitSettlements: true,
      splitPreferences: 'Open to 50% Gold Ingot trade + 50% AFNL native coins',
      customExchangeOffers: 'Seeking physical precious metals or sovereign charter deed credits.'
    },
    barterTerms: {
      desiredTrades: '100oz Gold Bullion or Sovereign Superyacht Charter Deed',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 145000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 7250 },
    stableCoinsPricing: { symbol: 'USDC', amount: 145000, network: 'Ethereum' },
    fiatPricing: { currencyCode: 'EUR', amount: 133000 },
    quantity: 1,
    unitLabel: 'timepiece',
    condition: 'Certified Rare',
    location: 'Geneva Freeport Custody',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    tags: ['Horology', 'Platinum', 'Luxury', 'Geneva'],
    createdAt: '2024-03-08T10:00:00.000Z'
  },
  {
    id: 'mkt-demo-gholu-1',
    userId: 'user-gholu653',
    creatorName: 'Gholu',
    creatorHandle: 'gholu653',
    creatorAvatar: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'currency',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 54000,
    title: 'Certified 1kg Fine Silver Bullion Bar (99.99%)',
    category: 'Precious Metals & Bullion',
    description: 'Vault-stored physical silver bar with serial attestation, ready for instant atomic barter transfer.',
    status: 'uploaded',
    visibility: 'public',
    acceptedSettlements: ['final_coins', 'stable_coins', 'barter'],
    acceptedCurrencyList: ['AFNL', 'USDC'],
    finalCoinsPricing: { symbol: 'AFNL', amount: 2700 },
    stableCoinsPricing: { symbol: 'USDC', amount: 54000, network: 'Polygon' },
    quantity: 1,
    unitLabel: 'bar',
    condition: 'Brand New',
    location: 'Zurich Vault Depository',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    tags: ['Silver', 'Bullion', 'Zurich', 'Physical'],
    createdAt: '2024-03-09T14:00:00.000Z'
  },
  {
    id: 'mkt-demo-gholu-2',
    userId: 'user-gholu653',
    creatorName: 'Gholu',
    creatorHandle: 'gholu653',
    creatorAvatar: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    listingIntent: 'sell',
    itemType: 'good',
    primaryTradeMode: 'barter',
    primaryCurrency: 'AFNL',
    primaryPriceUSD: 95000,
    title: 'Private Vault Sovereign Allocation Certificate',
    category: 'Precious Metals & Bullion',
    description: 'Private allocation deed shared strictly with close partners & confirmed friends in my trade network.',
    status: 'uploaded',
    visibility: 'friends',
    acceptedSettlements: ['barter', 'final_coins'],
    acceptedCurrencyList: ['AFNL'],
    barterTerms: {
      desiredTrades: 'Precious metals, Horology, or High-grade GPUs',
      desiredExchangeType: 'good',
      openToOffers: true,
      estimatedValueUSD: 95000
    },
    finalCoinsPricing: { symbol: 'AFNL', amount: 4750 },
    quantity: 1,
    unitLabel: 'certificate',
    condition: 'Mint',
    location: 'Private Vault Storage',
    imageUrl: 'https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?auto=format&fit=crop&w=800&q=80',
    tags: ['FriendsOnly', 'Certificate', 'Private'],
    createdAt: '2024-03-10T11:00:00.000Z'
  }
];

function loadMarketplaceStore(): MarketplaceListing[] {
  try {
    const raw = localStorage.getItem(MARKETPLACE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Error reading marketplace store from localStorage:', e);
  }
  // Initialize
  saveMarketplaceStore(INITIAL_MARKETPLACE_LISTINGS);
  return INITIAL_MARKETPLACE_LISTINGS;
}

function saveMarketplaceStore(listings: MarketplaceListing[]) {
  try {
    localStorage.setItem(MARKETPLACE_STORAGE_KEY, JSON.stringify(listings));
  } catch (e) {
    console.error('Error saving marketplace store:', e);
  }
}

let marketplaceStore: MarketplaceListing[] = loadMarketplaceStore();

export function getAllMarketplaceListings(currentUserId?: string): MarketplaceListing[] {
  marketplaceStore = loadMarketplaceStore();
  if (!currentUserId) return marketplaceStore;

  const cleanViewerUid = currentUserId.toLowerCase().replace(/^@/, '').replace(/^user-/, '');
  const viewerUid = currentUserId.startsWith('user-') ? currentUserId : `user-${cleanViewerUid}`;

  return marketplaceStore.filter(l => {
    const lUid = l.userId.startsWith('user-') ? l.userId : `user-${l.userId.toLowerCase().replace(/^@/, '')}`;
    if (areUsersBlockedEitherWay(viewerUid, lUid) || areUsersBlockedEitherWay(currentUserId, l.userId)) {
      return false;
    }
    return true;
  });
}

function normalizeUserKey(s?: string): string {
  if (!s) return '';
  return s.trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '').split('@')[0].replace(/[_\-\s]/g, '');
}

export function getUserListings(
  targetUserIdOrHandle: string,
  viewerUidOrHandle?: string,
  isFriendWithTarget: boolean = false,
  viewerHandle?: string
): MarketplaceListing[] {
  marketplaceStore = loadMarketplaceStore();
  if (!targetUserIdOrHandle) return [];

  const cleanTarget = targetUserIdOrHandle.trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '');
  const cleanTargetNorm = normalizeUserKey(targetUserIdOrHandle);

  const userListings = marketplaceStore.filter(l => {
    const lUser = (l.userId || '').toLowerCase().replace(/^user-/, '').replace(/^@/, '');
    const lHandle = (l.creatorHandle || '').toLowerCase().replace(/^@/, '').replace(/^user-/, '');
    const lUserNorm = normalizeUserKey(l.userId);
    const lHandleNorm = normalizeUserKey(l.creatorHandle);

    return (
      lUser === cleanTarget ||
      lHandle === cleanTarget ||
      lUserNorm === cleanTargetNorm ||
      lHandleNorm === cleanTargetNorm ||
      l.userId === targetUserIdOrHandle ||
      l.creatorHandle === targetUserIdOrHandle
    );
  });

  // Check if viewer is the owner of these listings
  const cleanViewerUid = viewerUidOrHandle ? viewerUidOrHandle.toLowerCase().replace(/^@/, '').replace(/^user-/, '') : '';
  const cleanViewerHandle = viewerHandle ? viewerHandle.toLowerCase().replace(/^@/, '').replace(/^user-/, '') : '';
  const cleanViewerNorm = normalizeUserKey(viewerUidOrHandle);
  const cleanViewerHandleNorm = normalizeUserKey(viewerHandle);

  // If viewer is omitted (e.g. called to get user's own listings in management UI) or matches target:
  const isOwner = Boolean(
    !viewerUidOrHandle ||
    viewerUidOrHandle === targetUserIdOrHandle ||
    (cleanViewerNorm && cleanViewerNorm === cleanTargetNorm) ||
    (cleanViewerHandleNorm && cleanViewerHandleNorm === cleanTargetNorm) ||
    (cleanViewerUid && (cleanViewerUid === cleanTarget || cleanViewerUid.replace(/[_\-\s]/g, '') === cleanTargetNorm)) ||
    (cleanViewerHandle && (cleanViewerHandle === cleanTarget || cleanViewerHandle.replace(/[_\-\s]/g, '') === cleanTargetNorm)) ||
    (viewerUidOrHandle && (viewerUidOrHandle === targetUserIdOrHandle || viewerUidOrHandle === `user-${cleanTarget}`))
  );

  // If viewer is the owner, return all their listings (public, friends, custom group, only_me, and drafts)
  if (isOwner) {
    if (userListings.length === 0) {
      const sampleDraft: MarketplaceListing = {
        id: `mkt-sample-draft-${Date.now()}`,
        userId: targetUserIdOrHandle,
        creatorName: targetUserIdOrHandle,
        creatorHandle: cleanTarget,
        listingIntent: 'sell',
        itemType: 'good',
        primaryTradeMode: 'currency',
        primaryCurrency: 'USD',
        primaryPriceUSD: 14500,
        title: '[DRAFT] Sovereign Autonomous AI Drone Rig (MK-IV)',
        category: 'Hardware & Compute',
        description: 'Unpublished draft listing featuring thermal imaging camera, autonomous lidar mapping, and encrypted telemetry.',
        status: 'draft',
        visibility: 'only_me',
        acceptedSettlements: ['fiat', 'stable_coins', 'crypto'],
        acceptedCurrencyList: ['USD', 'USDC'],
        fiatPricing: { currencyCode: 'USD', amount: 14500 },
        quantity: 1,
        unitLabel: 'unit',
        condition: 'Brand New',
        location: 'Zurich Vault Lab',
        imageUrl: 'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?auto=format&fit=crop&w=800&q=80',
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-drone-flying-over-a-forest-34282-large.mp4',
        tags: ['Draft', 'Drone', 'AI', 'Hardware'],
        createdAt: new Date().toISOString()
      };

      const sampleUploaded: MarketplaceListing = {
        id: `mkt-sample-uploaded-${Date.now() + 1}`,
        userId: targetUserIdOrHandle,
        creatorName: targetUserIdOrHandle,
        creatorHandle: cleanTarget,
        listingIntent: 'sell',
        itemType: 'service',
        primaryTradeMode: 'currency',
        primaryCurrency: 'AFNL',
        primaryPriceUSD: 7500,
        title: 'Quantum Cryptographic Security & Zero-Day Audit',
        category: 'Cybersecurity & Auditing',
        description: 'Full-stack lattice cryptography assessment, symbolic execution, and zero-knowledge circuit verification.',
        status: 'uploaded',
        visibility: 'public',
        acceptedSettlements: ['barter', 'final_coins', 'stable_coins'],
        acceptedCurrencyList: ['AFNL', 'USDC'],
        finalCoinsPricing: { symbol: 'AFNL', amount: 375 },
        quantity: 10,
        unitLabel: 'audits',
        condition: 'Brand New',
        location: 'Global Remote',
        imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-screens-with-code-31938-large.mp4',
        tags: ['Security', 'Quantum', 'Audit', 'Crypto'],
        createdAt: new Date().toISOString()
      };

      const sampleSold: MarketplaceListing = {
        id: `mkt-sample-sold-${Date.now() + 2}`,
        userId: targetUserIdOrHandle,
        creatorName: targetUserIdOrHandle,
        creatorHandle: cleanTarget,
        listingIntent: 'sell',
        itemType: 'good',
        primaryTradeMode: 'currency',
        primaryCurrency: 'USD',
        primaryPriceUSD: 85000,
        title: 'Allocated 100oz 24K Gold Bullion Ingot (LBMA Certified)',
        category: 'Precious Metals & Bullion',
        description: 'Successfully settled physical bullion transfer stored in Zurich Freeport repository.',
        status: 'sold',
        visibility: 'public',
        acceptedSettlements: ['barter', 'final_coins', 'stable_coins', 'fiat'],
        acceptedCurrencyList: ['AFNL', 'USDC', 'USD'],
        fiatPricing: { currencyCode: 'USD', amount: 85000 },
        quantity: 1,
        unitLabel: 'bar',
        condition: 'Mint',
        location: 'Zurich Freeport Vault 1',
        imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-gold-bar-42938-large.mp4',
        tags: ['Gold', 'Bullion', 'Sold', 'Zurich'],
        createdAt: new Date().toISOString()
      };

      marketplaceStore = [sampleDraft, sampleUploaded, sampleSold, ...marketplaceStore];
      saveMarketplaceStore(marketplaceStore);
      return [sampleDraft, sampleUploaded, sampleSold];
    }
    return userListings;
  }

  // If viewer is someone else, check if either party has blocked the other:
  const targetUid = targetUserIdOrHandle.startsWith('user-') ? targetUserIdOrHandle : `user-${cleanTarget}`;
  const viewerUid = (viewerUidOrHandle || '').startsWith('user-') ? viewerUidOrHandle! : `user-${cleanViewerUid}`;

  if (viewerUidOrHandle && (areUsersBlockedEitherWay(viewerUid, targetUid) || areUsersBlockedEitherWay(viewerUidOrHandle, targetUserIdOrHandle))) {
    return [];
  }

  // If viewer is someone else, ONLY return listings that the viewer has permission to view:
  return userListings.filter(l => {
    // Hide drafts and inactive status from public/visitor profiles
    if (l.status === 'draft') return false;

    const visibility = l.visibility || 'public';

    // 1. Public listings: visible to everyone
    if (visibility === 'public') {
      return true;
    }

    // 2. Only Me: strictly private, never visible to other users
    if (visibility === 'only_me') {
      return false;
    }

    // 3. Friends Only: visible strictly to confirmed friends
    if (visibility === 'friends') {
      return Boolean(isFriendWithTarget);
    }

    // 4. Custom Friend Group: visible strictly to members of the specific groups
    if (visibility === 'custom_group') {
      if (!l.allowedGroupIds || l.allowedGroupIds.length === 0) return false;
      const idsToCheck = [viewerUidOrHandle, viewerHandle, cleanViewerUid, cleanViewerHandle, cleanViewerNorm].filter(Boolean) as string[];
      return idsToCheck.some(id => isUserInAnyGroup(id, l.allowedGroupIds!));
    }

    return true;
  });
}

export function updateListingVisibility(
  listingId: string,
  visibility: ListingVisibility,
  allowedGroupIds?: string[],
  allowedGroupNames?: string[]
): MarketplaceListing | null {
  marketplaceStore = loadMarketplaceStore();
  const index = marketplaceStore.findIndex(l => l.id === listingId);
  if (index === -1) return null;

  const updated: MarketplaceListing = {
    ...marketplaceStore[index],
    visibility,
    allowedGroupIds: visibility === 'custom_group' ? (allowedGroupIds || []) : [],
    allowedGroupNames: visibility === 'custom_group' ? (allowedGroupNames || []) : []
  };

  marketplaceStore[index] = updated;
  saveMarketplaceStore(marketplaceStore);
  return updated;
}

export function createOrUpdateListing(
  userId: string,
  payload: Partial<MarketplaceListing> & { title: string; itemType: any; status: ListingStatus }
): MarketplaceListing {
  marketplaceStore = loadMarketplaceStore();
  const existingIndex = marketplaceStore.findIndex(l => l.id === payload.id);
  
  if (existingIndex > -1) {
    const updated = {
      ...marketplaceStore[existingIndex],
      ...payload,
      updatedAt: new Date().toISOString()
    } as MarketplaceListing;
    marketplaceStore[existingIndex] = updated;
    saveMarketplaceStore(marketplaceStore);
    return updated;
  }

  const newListing: MarketplaceListing = {
    id: payload.id || `mkt-${Date.now()}`,
    userId,
    creatorName: payload.creatorName || 'You',
    creatorHandle: payload.creatorHandle || userId,
    creatorAvatar: payload.creatorAvatar,
    listingIntent: payload.listingIntent || 'sell',
    itemType: payload.itemType,
    primaryTradeMode: payload.primaryTradeMode || 'currency',
    primaryCurrency: payload.primaryCurrency || 'USD',
    primaryPriceUSD: payload.primaryPriceUSD || 1000,
    title: payload.title,
    category: payload.category || 'General',
    description: payload.description || '',
    status: payload.status || 'draft',
    visibility: payload.visibility || 'public',
    allowedGroupIds: payload.allowedGroupIds || [],
    allowedGroupNames: payload.allowedGroupNames || [],
    acceptedSettlements: payload.acceptedSettlements || ['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto'],
    acceptedCurrencyList: payload.acceptedCurrencyList || ['USD', 'AFNL', 'USDC'],
    crossTransactionalTerms: payload.crossTransactionalTerms,
    barterTerms: payload.barterTerms,
    finalCoinsPricing: payload.finalCoinsPricing,
    stableCoinsPricing: payload.stableCoinsPricing,
    fiatPricing: payload.fiatPricing,
    cryptoPricing: payload.cryptoPricing,
    quantity: payload.quantity,
    unitLabel: payload.unitLabel,
    condition: payload.condition,
    location: payload.location,
    availableUnits: payload.availableUnits,
    unitType: payload.unitType,
    turnaroundTime: payload.turnaroundTime,
    deliverables: payload.deliverables,
    skills: payload.skills,
    imageUrl: payload.imageUrl,
    videoUrl: payload.videoUrl,
    mediaList: payload.mediaList,
    tags: payload.tags || [],
    createdAt: new Date().toISOString()
  };

  marketplaceStore = [newListing, ...marketplaceStore];
  saveMarketplaceStore(marketplaceStore);
  return newListing;
}

export function updateListingStatus(userId: string, listingId: string, status: ListingStatus): MarketplaceListing | null {
  marketplaceStore = loadMarketplaceStore();
  const item = marketplaceStore.find(l => l.id === listingId);
  if (item) {
    item.status = status;
    saveMarketplaceStore(marketplaceStore);
    return item;
  }
  return null;
}

export function deleteListing(userId: string, listingId: string): boolean {
  marketplaceStore = loadMarketplaceStore();
  const initialLen = marketplaceStore.length;
  marketplaceStore = marketplaceStore.filter(l => l.id !== listingId);
  if (marketplaceStore.length < initialLen) {
    saveMarketplaceStore(marketplaceStore);
    return true;
  }
  return false;
}

export function submitBarterTradeProposal(proposalData: {
  listingId: string;
  listingTitle: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  offeredItemsDescription: string;
  offeredSweetenerUSD?: number;
  offeredSweetenerToken?: { symbol: string; amount: number };
}): { success: boolean; proposalId: string } {
  const proposalId = `PROP-${Date.now()}`;
  return { success: true, proposalId };
}
