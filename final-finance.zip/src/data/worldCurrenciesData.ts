import { UserWalletData, StableCoinItem, CryptoCurrencyItem, FiatCurrencyItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from './defaultWallets';

export type CurrencyCategory = 'all' | 'stablecoin' | 'crypto' | 'fiat';

export interface WorldCurrency {
  id: string;
  symbol: string;
  name: string;
  category: 'stablecoin' | 'crypto' | 'fiat';
  pegCurrency?: 'USD' | 'INR' | 'EUR' | 'GBP' | 'Gold' | 'JPY' | 'CHF' | 'AED' | 'SGD' | 'CAD' | 'AUD' | 'none';
  pegDisplay?: string;
  unitPriceUSD: number;
  exchangeRateToUSD?: number; // e.g. 86.20 INR per 1 USD
  change24h: number;
  marketCapUSD: string;
  dailyVolumeUSD: string;
  network: string;
  issuer: string;
  countryFlag: string;
  countryName: string;
  description: string;
  iconSymbol: string;
  logoBg: string;
  contractStandard?: string;
  isPopular?: boolean;
}

export const WORLD_CURRENCIES_CATALOG: WorldCurrency[] = [
  // --- STABLECOINS ---
  {
    id: 'usdc',
    symbol: 'USDC',
    name: 'USD Coin',
    category: 'stablecoin',
    pegCurrency: 'USD',
    pegDisplay: '1:1 US Dollar ($1.00 USD)',
    unitPriceUSD: 1.00,
    exchangeRateToUSD: 1.00,
    change24h: 0.01,
    marketCapUSD: '$35.4B',
    dailyVolumeUSD: '$6.8B',
    network: 'Ethereum, Polygon, Solana, Base',
    issuer: 'Circle Internet Financial / Centre',
    countryFlag: '🇺🇸',
    countryName: 'United States',
    description: 'Fully reserved regulated digital dollar backed by cash and short-dated US Treasuries.',
    iconSymbol: '$',
    logoBg: 'from-blue-600 via-indigo-600 to-cyan-500 text-white',
    contractStandard: 'ERC-20, SPL, Multi-Chain',
    isPopular: true
  },
  {
    id: 'usdt',
    symbol: 'USDT',
    name: 'Tether USD',
    category: 'stablecoin',
    pegCurrency: 'USD',
    pegDisplay: '1:1 US Dollar ($1.00 USD)',
    unitPriceUSD: 1.00,
    exchangeRateToUSD: 1.00,
    change24h: -0.01,
    marketCapUSD: '$128.2B',
    dailyVolumeUSD: '$48.5B',
    network: 'Ethereum, Tron, Solana, Arbitrum',
    issuer: 'Tether Holdings Ltd.',
    countryFlag: '🇺🇸',
    countryName: 'Global Reserve',
    description: 'The largest high-liquidity digital dollar stablecoin used globally for digital asset settlement.',
    iconSymbol: '₮',
    logoBg: 'from-teal-500 via-emerald-600 to-cyan-700 text-white',
    contractStandard: 'TRC-20, ERC-20',
    isPopular: true
  },
  {
    id: 'inr_stable',
    symbol: 'INR-S',
    name: 'Indian Rupee Sovereign Stable',
    category: 'stablecoin',
    pegCurrency: 'INR',
    pegDisplay: '1:1 Indian Rupee (₹1.00 INR)',
    unitPriceUSD: 0.0116,
    exchangeRateToUSD: 86.20,
    change24h: 0.02,
    marketCapUSD: '$1.4B',
    dailyVolumeUSD: '$280M',
    network: 'Final Protocol Subnet, Polygon POS',
    issuer: 'Final Finance Sovereign Reserve',
    countryFlag: '🇮🇳',
    countryName: 'India',
    description: 'Decentralized Indian Rupee pegged stablecoin offering instant cross-border settlement and oracle valuation.',
    iconSymbol: '₹',
    logoBg: 'from-orange-500 via-amber-500 to-emerald-600 text-white',
    contractStandard: 'Final-EVM',
    isPopular: true
  },
  {
    id: 'inrc',
    symbol: 'INRC',
    name: 'Digital Rupee Coin',
    category: 'stablecoin',
    pegCurrency: 'INR',
    pegDisplay: '1:1 Indian Rupee (₹1.00 INR)',
    unitPriceUSD: 0.0116,
    exchangeRateToUSD: 86.20,
    change24h: 0.00,
    marketCapUSD: '$890M',
    dailyVolumeUSD: '$145M',
    network: 'Ethereum, Base L2, Polygon',
    issuer: 'Bharat Digital Treasury Consortium',
    countryFlag: '🇮🇳',
    countryName: 'India',
    description: 'Audited digital rupee stablecoin backed by RBI sovereign deposits and high-grade Indian T-Bills.',
    iconSymbol: '₹',
    logoBg: 'from-amber-600 via-orange-600 to-indigo-700 text-white',
    contractStandard: 'ERC-20',
    isPopular: true
  },
  {
    id: 'eurc',
    symbol: 'EURC',
    name: 'Euro Coin',
    category: 'stablecoin',
    pegCurrency: 'EUR',
    pegDisplay: '1:1 Euro (€1.00 EUR / $1.09 USD)',
    unitPriceUSD: 1.09,
    exchangeRateToUSD: 0.917,
    change24h: 0.12,
    marketCapUSD: '$2.1B',
    dailyVolumeUSD: '$310M',
    network: 'Base, Ethereum, Avalanche',
    issuer: 'Circle Internet Financial (MiCA Compliant)',
    countryFlag: '🇪🇺',
    countryName: 'European Union',
    description: 'MiCA-compliant euro-backed stablecoin 100% held in European financial institutional reserves.',
    iconSymbol: '€',
    logoBg: 'from-blue-700 via-indigo-800 to-amber-500 text-white',
    contractStandard: 'ERC-20',
    isPopular: true
  },
  {
    id: 'dai',
    symbol: 'DAI',
    name: 'Dai / Sky Dollar',
    category: 'stablecoin',
    pegCurrency: 'USD',
    pegDisplay: '1:1 US Dollar ($1.00 USD)',
    unitPriceUSD: 1.00,
    exchangeRateToUSD: 1.00,
    change24h: 0.00,
    marketCapUSD: '$5.4B',
    dailyVolumeUSD: '$420M',
    network: 'Ethereum Mainnet, Optimism, Arbitrum',
    issuer: 'MakerDAO / Sky Protocol',
    countryFlag: '🇺🇸',
    countryName: 'Decentralized Sovereign',
    description: 'Decentralized multi-collateral stablecoin governed autonomously via smart contract vaults.',
    iconSymbol: '◈',
    logoBg: 'from-amber-500 via-yellow-500 to-orange-600 text-slate-950',
    contractStandard: 'ERC-20',
    isPopular: true
  },
  {
    id: 'pyusd',
    symbol: 'PYUSD',
    name: 'PayPal USD',
    category: 'stablecoin',
    pegCurrency: 'USD',
    pegDisplay: '1:1 US Dollar ($1.00 USD)',
    unitPriceUSD: 1.00,
    exchangeRateToUSD: 1.00,
    change24h: 0.01,
    marketCapUSD: '$1.05B',
    dailyVolumeUSD: '$190M',
    network: 'Solana, Ethereum',
    issuer: 'PayPal & Paxos Trust Company',
    countryFlag: '🇺🇸',
    countryName: 'United States',
    description: 'Regulated dollar stablecoin designed for digital payments and Web3 consumer commerce.',
    iconSymbol: 'P',
    logoBg: 'from-blue-600 via-cyan-600 to-blue-900 text-white',
    contractStandard: 'ERC-20, SPL'
  },
  {
    id: 'paxg',
    symbol: 'PAXG',
    name: 'PAX Gold',
    category: 'stablecoin',
    pegCurrency: 'Gold',
    pegDisplay: '1 Fine Troy Ounce Gold ($2,880.00 USD)',
    unitPriceUSD: 2880.00,
    exchangeRateToUSD: 0.000347,
    change24h: 0.65,
    marketCapUSD: '$720M',
    dailyVolumeUSD: '$65M',
    network: 'Ethereum Mainnet',
    issuer: 'Paxos Trust Company (LBMA Vaults)',
    countryFlag: '🪙',
    countryName: 'Precious Metals',
    description: 'Physical gold-backed token representing 1 fine troy ounce of London Good Delivery gold bar.',
    iconSymbol: '⚱',
    logoBg: 'from-yellow-400 via-amber-500 to-yellow-600 text-slate-950',
    contractStandard: 'ERC-20',
    isPopular: true
  },
  {
    id: 'xsgd',
    symbol: 'XSGD',
    name: 'StraitsX Singapore Dollar',
    category: 'stablecoin',
    pegCurrency: 'SGD',
    pegDisplay: '1:1 Singapore Dollar (S$1.00 SGD / $0.75 USD)',
    unitPriceUSD: 0.75,
    exchangeRateToUSD: 1.33,
    change24h: 0.05,
    marketCapUSD: '$310M',
    dailyVolumeUSD: '$45M',
    network: 'Ethereum, Polygon',
    issuer: 'StraitsX (MAS Regulated)',
    countryFlag: '🇸🇬',
    countryName: 'Singapore',
    description: 'MAS-licensed digital Singapore dollar pegged 1:1 with fully segregated bank escrow accounts.',
    iconSymbol: 'S$',
    logoBg: 'from-red-500 via-rose-600 to-pink-700 text-white',
    contractStandard: 'ERC-20'
  },
  {
    id: 'gurs',
    symbol: 'AED-S',
    name: 'UAE Dirham Sovereign Stable',
    category: 'stablecoin',
    pegCurrency: 'AED',
    pegDisplay: '1:1 UAE Dirham (3.67 AED / $0.272 USD)',
    unitPriceUSD: 0.272,
    exchangeRateToUSD: 3.67,
    change24h: 0.00,
    marketCapUSD: '$480M',
    dailyVolumeUSD: '$82M',
    network: 'Base, Final Protocol Subnet',
    issuer: 'Gulf Sovereign Vault Consortium',
    countryFlag: '🇦🇪',
    countryName: 'United Arab Emirates',
    description: 'Fully collateralized UAE Dirham digital asset optimized for Middle East and GCC trade clearance.',
    iconSymbol: 'د.إ',
    logoBg: 'from-emerald-600 via-teal-700 to-slate-900 text-white',
    contractStandard: 'Final-EVM'
  },
  {
    id: 'chfc',
    symbol: 'CHFC',
    name: 'Swiss Franc Stablecoin',
    category: 'stablecoin',
    pegCurrency: 'CHF',
    pegDisplay: '1:1 Swiss Franc (CHF 1.00 / $1.15 USD)',
    unitPriceUSD: 1.15,
    exchangeRateToUSD: 0.87,
    change24h: 0.18,
    marketCapUSD: '$650M',
    dailyVolumeUSD: '$95M',
    network: 'Ethereum, Avalanche',
    issuer: 'Swiss Alpine Custody AG (FINMA Audited)',
    countryFlag: '🇨🇭',
    countryName: 'Switzerland',
    description: 'Triple-audited Swiss Franc stablecoin backed 100% by physical vault deposits in Zurich.',
    iconSymbol: 'CHF',
    logoBg: 'from-red-600 via-red-700 to-slate-900 text-white',
    contractStandard: 'ERC-20'
  },

  // --- TOP GLOBAL CRYPTOCURRENCIES ---
  {
    id: 'btc',
    symbol: 'BTC',
    name: 'Bitcoin',
    category: 'crypto',
    unitPriceUSD: 94800.00,
    change24h: 3.45,
    marketCapUSD: '$1.87T',
    dailyVolumeUSD: '$42.1B',
    network: 'Bitcoin Mainnet (SegWit/Taproot)',
    issuer: 'Satoshi Nakamoto / Decentralized PoW',
    countryFlag: '₿',
    countryName: 'Global Decentralized',
    description: 'The pioneering sovereign digital store of value and premier decentralized base money asset.',
    iconSymbol: '₿',
    logoBg: 'from-amber-500 via-orange-500 to-yellow-600 text-white',
    contractStandard: 'Native UTXO',
    isPopular: true
  },
  {
    id: 'eth',
    symbol: 'ETH',
    name: 'Ethereum',
    category: 'crypto',
    unitPriceUSD: 2820.00,
    change24h: 2.15,
    marketCapUSD: '$339.4B',
    dailyVolumeUSD: '$18.9B',
    network: 'Ethereum Mainnet (PoS)',
    issuer: 'Ethereum Foundation / Decentralized',
    countryFlag: 'Ξ',
    countryName: 'Global Decentralized',
    description: 'The leading decentralized smart contract platform powering decentralized finance and global tokenization.',
    iconSymbol: 'Ξ',
    logoBg: 'from-indigo-600 via-purple-600 to-slate-900 text-white',
    contractStandard: 'Native EVM Base Asset',
    isPopular: true
  },
  {
    id: 'sol',
    symbol: 'SOL',
    name: 'Solana',
    category: 'crypto',
    unitPriceUSD: 195.00,
    change24h: 6.80,
    marketCapUSD: '$92.1B',
    dailyVolumeUSD: '$8.4B',
    network: 'Solana Network',
    issuer: 'Solana Labs / Decentralized PoH',
    countryFlag: '◎',
    countryName: 'Global Decentralized',
    description: 'High-throughput, ultra-low-latency blockchain network designed for institutional speed and consumer scale.',
    iconSymbol: '◎',
    logoBg: 'from-purple-500 via-fuchsia-600 to-cyan-400 text-white',
    contractStandard: 'Native Solana Protocol',
    isPopular: true
  },
  {
    id: 'bnb',
    symbol: 'BNB',
    name: 'BNB Chain',
    category: 'crypto',
    unitPriceUSD: 640.00,
    change24h: 1.85,
    marketCapUSD: '$95.2B',
    dailyVolumeUSD: '$2.1B',
    network: 'BNB Smart Chain (BEP-20)',
    issuer: 'BNB Chain Community / Build and Build',
    countryFlag: '🔶',
    countryName: 'Global Decentralized',
    description: 'Native gas and governance token of the high-speed BNB ecosystem and decentralised exchange protocols.',
    iconSymbol: 'BNB',
    logoBg: 'from-yellow-400 via-amber-500 to-yellow-600 text-slate-950',
    contractStandard: 'BEP-20 / Native',
    isPopular: true
  },
  {
    id: 'xrp',
    symbol: 'XRP',
    name: 'XRP Ledger',
    category: 'crypto',
    unitPriceUSD: 2.45,
    change24h: 5.12,
    marketCapUSD: '$140.2B',
    dailyVolumeUSD: '$9.4B',
    network: 'XRP Ledger (XRPL)',
    issuer: 'Ripple Labs / Decentralized XRPL',
    countryFlag: '✕',
    countryName: 'Global Interbank Clearing',
    description: 'High-speed real-time gross settlement digital asset built for cross-border institutional remittances.',
    iconSymbol: '✕',
    logoBg: 'from-slate-800 via-slate-900 to-blue-900 text-white',
    contractStandard: 'Native XRPL',
    isPopular: true
  },
  {
    id: 'ada',
    symbol: 'ADA',
    name: 'Cardano',
    category: 'crypto',
    unitPriceUSD: 0.78,
    change24h: 4.20,
    marketCapUSD: '$27.8B',
    dailyVolumeUSD: '$1.2B',
    network: 'Cardano (Ouroboros PoS)',
    issuer: 'IOG & Cardano Foundation',
    countryFlag: '₳',
    countryName: 'Decentralized Research',
    description: 'Peer-reviewed proof-of-stake blockchain engineered for security, sustainability, and formal verification.',
    iconSymbol: '₳',
    logoBg: 'from-blue-600 via-indigo-700 to-slate-900 text-white',
    contractStandard: 'Native Cardano',
    isPopular: true
  },
  {
    id: 'doge',
    symbol: 'DOGE',
    name: 'Dogecoin',
    category: 'crypto',
    unitPriceUSD: 0.26,
    change24h: 8.40,
    marketCapUSD: '$38.1B',
    dailyVolumeUSD: '$3.8B',
    network: 'Dogecoin Network (AuxPoW)',
    issuer: 'Dogecoin Community & Foundation',
    countryFlag: 'Ð',
    countryName: 'Decentralized Community',
    description: 'Open-source peer-to-peer digital currency favored for micro-tips, tipping rails, and global liquidity.',
    iconSymbol: 'Ð',
    logoBg: 'from-amber-400 via-yellow-500 to-amber-600 text-slate-950',
    contractStandard: 'Native UTXO',
    isPopular: true
  },
  {
    id: 'avax',
    symbol: 'AVAX',
    name: 'Avalanche',
    category: 'crypto',
    unitPriceUSD: 32.40,
    change24h: 3.10,
    marketCapUSD: '$13.2B',
    dailyVolumeUSD: '$680M',
    network: 'Avalanche C-Chain & Subnets',
    issuer: 'Ava Labs / Decentralized Consensus',
    countryFlag: '🔺',
    countryName: 'Decentralized Subnets',
    description: 'Subnet-enabled scalable smart contract execution platform delivering sub-second finality.',
    iconSymbol: '🔺',
    logoBg: 'from-red-600 via-rose-700 to-slate-900 text-white',
    contractStandard: 'Avalanche C-Chain (EVM)'
  },
  {
    id: 'link',
    symbol: 'LINK',
    name: 'Chainlink',
    category: 'crypto',
    unitPriceUSD: 18.50,
    change24h: 4.80,
    marketCapUSD: '$11.6B',
    dailyVolumeUSD: '$950M',
    network: 'Ethereum, Multi-Chain',
    issuer: 'Chainlink Labs',
    countryFlag: '🔗',
    countryName: 'Decentralized Oracle Network',
    description: 'Industry-standard decentralized oracle compute network connecting blockchains to real-world price feeds and data.',
    iconSymbol: '⬡',
    logoBg: 'from-blue-600 via-cyan-600 to-indigo-800 text-white',
    contractStandard: 'ERC-20, Multi-Chain',
    isPopular: true
  },
  {
    id: 'pol',
    symbol: 'POL',
    name: 'Polygon Ecosystem Token',
    category: 'crypto',
    unitPriceUSD: 0.48,
    change24h: 2.90,
    marketCapUSD: '$4.8B',
    dailyVolumeUSD: '$240M',
    network: 'Polygon POS & AggLayer',
    issuer: 'Polygon Labs',
    countryFlag: '🟣',
    countryName: 'Decentralized L2/AggLayer',
    description: 'Next-generation hyperproductive staking and gas token securing Polygon AggLayer networks.',
    iconSymbol: 'POL',
    logoBg: 'from-purple-600 via-indigo-700 to-purple-900 text-white',
    contractStandard: 'ERC-20, Polygon POS'
  },
  {
    id: 'sui',
    symbol: 'SUI',
    name: 'Sui Network',
    category: 'crypto',
    unitPriceUSD: 3.40,
    change24h: 9.15,
    marketCapUSD: '$9.8B',
    dailyVolumeUSD: '$1.4B',
    network: 'Sui Network (Move VM)',
    issuer: 'Mysten Labs',
    countryFlag: '💧',
    countryName: 'Object-Centric L1',
    description: 'Object-centric Layer-1 blockchain built with Move language for instant parallel execution and low latency.',
    iconSymbol: 'SUI',
    logoBg: 'from-cyan-500 via-blue-600 to-indigo-700 text-white',
    contractStandard: 'Sui Move'
  },
  {
    id: 'near',
    symbol: 'NEAR',
    name: 'NEAR Protocol',
    category: 'crypto',
    unitPriceUSD: 5.60,
    change24h: 5.40,
    marketCapUSD: '$6.8B',
    dailyVolumeUSD: '$520M',
    network: 'NEAR Sharded Mainnet',
    issuer: 'NEAR Foundation',
    countryFlag: 'Ⓝ',
    countryName: 'AI & Chain Abstraction L1',
    description: 'Sharded proof-of-stake blockchain built with Nightshade consensus and Chain Abstraction for User-Owned AI.',
    iconSymbol: 'Ⓝ',
    logoBg: 'from-slate-900 via-emerald-800 to-teal-600 text-white',
    contractStandard: 'NEAR Native'
  },
  {
    id: 'dot',
    symbol: 'DOT',
    name: 'Polkadot',
    category: 'crypto',
    unitPriceUSD: 7.20,
    change24h: 1.95,
    marketCapUSD: '$10.4B',
    dailyVolumeUSD: '$410M',
    network: 'Polkadot Relay Chain & Parachains',
    issuer: 'Web3 Foundation & Parity',
    countryFlag: '●',
    countryName: 'Interoperable Multichain',
    description: 'Heterogeneous multi-chain architecture enabling trustless interoperability and shared security.',
    iconSymbol: '●',
    logoBg: 'from-pink-600 via-rose-700 to-slate-900 text-white',
    contractStandard: 'Substrate Native'
  },
  {
    id: 'ton',
    symbol: 'TON',
    name: 'The Open Network',
    category: 'crypto',
    unitPriceUSD: 5.80,
    change24h: 3.80,
    marketCapUSD: '$14.8B',
    dailyVolumeUSD: '$690M',
    network: 'TON Blockchain',
    issuer: 'TON Foundation',
    countryFlag: '💎',
    countryName: 'Telegram Consumer Web3',
    description: 'Scalable multi-blockchain architecture deeply integrated with Telegram for billions of consumer wallets.',
    iconSymbol: '💎',
    logoBg: 'from-sky-500 via-blue-600 to-slate-900 text-white',
    contractStandard: 'TON Native'
  },

  // --- WORLD SOVEREIGN FIAT CURRENCIES (FOREX ORACLE LINKED) ---
  {
    id: 'fiat_usd',
    symbol: 'USD',
    name: 'United States Dollar',
    category: 'fiat',
    pegCurrency: 'USD',
    pegDisplay: 'Global Reserve Currency ($1.00 USD Baseline)',
    unitPriceUSD: 1.00,
    exchangeRateToUSD: 1.00,
    change24h: 0.00,
    marketCapUSD: '$21.4T M2',
    dailyVolumeUSD: '$2.8T Forex',
    network: 'Federal Reserve / Fedwire / ACH',
    issuer: 'Federal Reserve System (United States)',
    countryFlag: '🇺🇸',
    countryName: 'United States',
    description: 'The premier global reserve currency and international benchmark for multi-asset valuation.',
    iconSymbol: '$',
    logoBg: 'from-emerald-700 via-teal-800 to-slate-950 text-white',
    isPopular: true
  },
  {
    id: 'fiat_inr',
    symbol: 'INR',
    name: 'Indian Rupee',
    category: 'fiat',
    pegCurrency: 'INR',
    pegDisplay: '₹86.20 INR = $1.00 USD (Oracle Feed)',
    unitPriceUSD: 0.0116,
    exchangeRateToUSD: 86.20,
    change24h: 0.02,
    marketCapUSD: '$3.9T Sovereign GDP',
    dailyVolumeUSD: '$68B Forex',
    network: 'Reserve Bank of India / NEFT / RTGS / UPI',
    issuer: 'Reserve Bank of India (RBI)',
    countryFlag: '🇮🇳',
    countryName: 'India',
    description: 'Official sovereign currency of the Republic of India, the fifth largest global economy.',
    iconSymbol: '₹',
    logoBg: 'from-orange-600 via-amber-600 to-emerald-700 text-white',
    isPopular: true
  },
  {
    id: 'fiat_eur',
    symbol: 'EUR',
    name: 'Euro',
    category: 'fiat',
    pegCurrency: 'EUR',
    pegDisplay: '€0.917 EUR = $1.00 USD ($1.09 USD)',
    unitPriceUSD: 1.09,
    exchangeRateToUSD: 0.917,
    change24h: 0.15,
    marketCapUSD: '$16.2T Eurozone GDP',
    dailyVolumeUSD: '$1.4T Forex',
    network: 'European Central Bank / TARGET2 / SEPA',
    issuer: 'European Central Bank (ECB)',
    countryFlag: '🇪🇺',
    countryName: 'European Union (Eurozone)',
    description: 'Official monetary union currency across 20 European Union member nations.',
    iconSymbol: '€',
    logoBg: 'from-blue-700 via-indigo-900 to-slate-950 text-white',
    isPopular: true
  },
  {
    id: 'fiat_gbp',
    symbol: 'GBP',
    name: 'British Pound Sterling',
    category: 'fiat',
    pegCurrency: 'GBP',
    pegDisplay: '£0.769 GBP = $1.00 USD ($1.30 USD)',
    unitPriceUSD: 1.30,
    exchangeRateToUSD: 0.769,
    change24h: -0.08,
    marketCapUSD: '$3.4T UK GDP',
    dailyVolumeUSD: '$780B Forex',
    network: 'Bank of England / CHAPS / Faster Payments',
    issuer: 'Bank of England (BoE)',
    countryFlag: '🇬🇧',
    countryName: 'United Kingdom',
    description: 'The oldest continuously used currency in the world, anchoring London institutional finance.',
    iconSymbol: '£',
    logoBg: 'from-indigo-800 via-blue-900 to-rose-900 text-white',
    isPopular: true
  },
  {
    id: 'fiat_jpy',
    symbol: 'JPY',
    name: 'Japanese Yen',
    category: 'fiat',
    pegCurrency: 'JPY',
    pegDisplay: '¥149.25 JPY = $1.00 USD ($0.0067 USD)',
    unitPriceUSD: 0.0067,
    exchangeRateToUSD: 149.25,
    change24h: -0.22,
    marketCapUSD: '$4.2T Japan GDP',
    dailyVolumeUSD: '$1.1T Forex',
    network: 'Bank of Japan / Zengin System',
    issuer: 'Bank of Japan (BOJ)',
    countryFlag: '🇯🇵',
    countryName: 'Japan',
    description: 'Major Asian safe-haven currency and third most traded currency in foreign exchange markets.',
    iconSymbol: '¥',
    logoBg: 'from-rose-600 via-red-700 to-slate-900 text-white',
    isPopular: true
  },
  {
    id: 'fiat_chf',
    symbol: 'CHF',
    name: 'Swiss Franc',
    category: 'fiat',
    pegCurrency: 'CHF',
    pegDisplay: 'CHF 0.87 = $1.00 USD ($1.15 USD)',
    unitPriceUSD: 1.15,
    exchangeRateToUSD: 0.87,
    change24h: 0.10,
    marketCapUSD: '$890B Swiss GDP',
    dailyVolumeUSD: '$320B Forex',
    network: 'Swiss National Bank / SIC Settlement',
    issuer: 'Swiss National Bank (SNB)',
    countryFlag: '🇨🇭',
    countryName: 'Switzerland',
    description: 'Premier global safe-haven sovereign currency backed by Switzerland robust legal and gold reserves.',
    iconSymbol: 'CHF',
    logoBg: 'from-red-600 via-rose-700 to-slate-950 text-white',
    isPopular: true
  },
  {
    id: 'fiat_aed',
    symbol: 'AED',
    name: 'UAE Dirham',
    category: 'fiat',
    pegCurrency: 'AED',
    pegDisplay: '3.67 AED = $1.00 USD ($0.272 USD Fixed Peg)',
    unitPriceUSD: 0.272,
    exchangeRateToUSD: 3.67,
    change24h: 0.00,
    marketCapUSD: '$530B UAE GDP',
    dailyVolumeUSD: '$45B Forex',
    network: 'Central Bank of the UAE / UAEFTS',
    issuer: 'Central Bank of the United Arab Emirates (CBUAE)',
    countryFlag: '🇦🇪',
    countryName: 'United Arab Emirates',
    description: 'Official sovereign currency of the UAE, anchored by stable dollar parity and sovereign wealth.',
    iconSymbol: 'د.إ',
    logoBg: 'from-emerald-700 via-teal-800 to-amber-700 text-white'
  },
  {
    id: 'fiat_sgd',
    symbol: 'SGD',
    name: 'Singapore Dollar',
    category: 'fiat',
    pegCurrency: 'SGD',
    pegDisplay: 'S$1.33 SGD = $1.00 USD ($0.75 USD)',
    unitPriceUSD: 0.75,
    exchangeRateToUSD: 1.33,
    change24h: 0.05,
    marketCapUSD: '$510B Singapore GDP',
    dailyVolumeUSD: '$210B Forex',
    network: 'Monetary Authority of Singapore / MEPS+',
    issuer: 'Monetary Authority of Singapore (MAS)',
    countryFlag: '🇸🇬',
    countryName: 'Singapore',
    description: 'Sovereign managed-float currency anchoring Southeast Asia premier international financial hub.',
    iconSymbol: 'S$',
    logoBg: 'from-rose-600 via-red-600 to-slate-900 text-white'
  },
  {
    id: 'fiat_cad',
    symbol: 'CAD',
    name: 'Canadian Dollar',
    category: 'fiat',
    pegCurrency: 'CAD',
    pegDisplay: 'C$1.37 CAD = $1.00 USD ($0.73 USD)',
    unitPriceUSD: 0.73,
    exchangeRateToUSD: 1.37,
    change24h: -0.10,
    marketCapUSD: '$2.2T Canada GDP',
    dailyVolumeUSD: '$380B Forex',
    network: 'Bank of Canada / Lynx Clearing',
    issuer: 'Bank of Canada (BoC)',
    countryFlag: '🇨🇦',
    countryName: 'Canada',
    description: 'Major G7 commodity-linked currency backed by Canada natural resources and energy exports.',
    iconSymbol: 'C$',
    logoBg: 'from-red-600 via-rose-800 to-slate-900 text-white'
  },
  {
    id: 'fiat_aud',
    symbol: 'AUD',
    name: 'Australian Dollar',
    category: 'fiat',
    pegCurrency: 'AUD',
    pegDisplay: 'A$1.54 AUD = $1.00 USD ($0.65 USD)',
    unitPriceUSD: 0.65,
    exchangeRateToUSD: 1.54,
    change24h: 0.18,
    marketCapUSD: '$1.7T Australia GDP',
    dailyVolumeUSD: '$420B Forex',
    network: 'Reserve Bank of Australia / RITS',
    issuer: 'Reserve Bank of Australia (RBA)',
    countryFlag: '🇦🇺',
    countryName: 'Australia',
    description: 'Highly liquid Asia-Pacific commodity trade currency reflecting metals, minerals, and agricultural flow.',
    iconSymbol: 'A$',
    logoBg: 'from-emerald-700 via-green-800 to-amber-600 text-white'
  },
  {
    id: 'fiat_cny',
    symbol: 'CNY',
    name: 'Chinese Yuan Renminbi',
    category: 'fiat',
    pegCurrency: 'none',
    pegDisplay: '¥7.24 CNY = $1.00 USD ($0.138 USD)',
    unitPriceUSD: 0.138,
    exchangeRateToUSD: 7.24,
    change24h: 0.01,
    marketCapUSD: '$18.5T China GDP',
    dailyVolumeUSD: '$480B Forex',
    network: 'People\'s Bank of China / CIPS / CNAPS',
    issuer: 'People\'s Bank of China (PBOC)',
    countryFlag: '🇨🇳',
    countryName: 'China',
    description: 'Official sovereign currency of the world\'s manufacturing hub and second largest economy.',
    iconSymbol: '¥',
    logoBg: 'from-red-700 via-yellow-600 to-red-900 text-white'
  },
  {
    id: 'fiat_sar',
    symbol: 'SAR',
    name: 'Saudi Riyal',
    category: 'fiat',
    pegCurrency: 'none',
    pegDisplay: '3.75 SAR = $1.00 USD ($0.267 USD Pegged)',
    unitPriceUSD: 0.267,
    exchangeRateToUSD: 3.75,
    change24h: 0.00,
    marketCapUSD: '$1.1T Saudi GDP',
    dailyVolumeUSD: '$35B Forex',
    network: 'Saudi Central Bank / SARIE',
    issuer: 'Saudi Central Bank (SAMA)',
    countryFlag: '🇸🇦',
    countryName: 'Saudi Arabia',
    description: 'Official sovereign currency of the Kingdom of Saudi Arabia, fixed to the US Dollar.',
    iconSymbol: '﷼',
    logoBg: 'from-emerald-800 via-green-900 to-slate-900 text-white'
  },
  {
    id: 'fiat_brl',
    symbol: 'BRL',
    name: 'Brazilian Real',
    category: 'fiat',
    pegCurrency: 'none',
    pegDisplay: 'R$5.85 BRL = $1.00 USD ($0.171 USD)',
    unitPriceUSD: 0.171,
    exchangeRateToUSD: 5.85,
    change24h: 0.35,
    marketCapUSD: '$2.1T Brazil GDP',
    dailyVolumeUSD: '$75B Forex',
    network: 'Central Bank of Brazil / PIX / STR',
    issuer: 'Central Bank of Brazil (BCB)',
    countryFlag: '🇧🇷',
    countryName: 'Brazil',
    description: 'Official currency of Brazil, featuring PIX instant payments and commodities backing.',
    iconSymbol: 'R$',
    logoBg: 'from-green-600 via-yellow-500 to-blue-700 text-white'
  },
  {
    id: 'fiat_zar',
    symbol: 'ZAR',
    name: 'South African Rand',
    category: 'fiat',
    pegCurrency: 'none',
    pegDisplay: 'R 18.20 ZAR = $1.00 USD ($0.055 USD)',
    unitPriceUSD: 0.055,
    exchangeRateToUSD: 18.20,
    change24h: -0.15,
    marketCapUSD: '$410B South Africa GDP',
    dailyVolumeUSD: '$55B Forex',
    network: 'South African Reserve Bank / SAMOS',
    issuer: 'South African Reserve Bank (SARB)',
    countryFlag: '🇿🇦',
    countryName: 'South Africa',
    description: 'Major emerging market commodity currency and financial benchmark for the African continent.',
    iconSymbol: 'R',
    logoBg: 'from-teal-700 via-yellow-600 to-slate-900 text-white'
  },
  {
    id: 'fiat_krw',
    symbol: 'KRW',
    name: 'South Korean Won',
    category: 'fiat',
    pegCurrency: 'none',
    pegDisplay: '₩1,390 KRW = $1.00 USD ($0.00072 USD)',
    unitPriceUSD: 0.00072,
    exchangeRateToUSD: 1390.00,
    change24h: 0.08,
    marketCapUSD: '$1.8T South Korea GDP',
    dailyVolumeUSD: '$190B Forex',
    network: 'Bank of Korea / BOK-Wire+',
    issuer: 'Bank of Korea (BOK)',
    countryFlag: '🇰🇷',
    countryName: 'South Korea',
    description: 'Official currency of South Korea, powering advanced semiconductor and industrial trade.',
    iconSymbol: '₩',
    logoBg: 'from-blue-700 via-rose-700 to-slate-900 text-white'
  },
  {
    id: 'fiat_mxn',
    symbol: 'MXN',
    name: 'Mexican Peso',
    category: 'fiat',
    pegCurrency: 'none',
    pegDisplay: '$20.40 MXN = $1.00 USD ($0.049 USD)',
    unitPriceUSD: 0.049,
    exchangeRateToUSD: 20.40,
    change24h: -0.05,
    marketCapUSD: '$1.5T Mexico GDP',
    dailyVolumeUSD: '$115B Forex',
    network: 'Bank of Mexico / SPEI Clearing',
    issuer: 'Bank of Mexico (Banxico)',
    countryFlag: '🇲🇽',
    countryName: 'Mexico',
    description: 'The most liquid currency in Latin America, central to North American nearshoring trade.',
    iconSymbol: 'Mex$',
    logoBg: 'from-emerald-700 via-red-700 to-slate-900 text-white'
  }
];

export function getAllWorldCurrencies(): WorldCurrency[] {
  return WORLD_CURRENCIES_CATALOG;
}

export function isCurrencyInUserWallet(walletData: UserWalletData, symbol: string): boolean {
  const s = symbol.toUpperCase();
  if (walletData.stableCoins?.some(sc => sc.symbol.toUpperCase() === s)) return true;
  if (walletData.cryptoCurrencies?.some(cr => cr.symbol.toUpperCase() === s)) return true;
  if (walletData.fiatCurrencies?.some(fi => fi.code.toUpperCase() === s)) return true;
  return false;
}

export function addCurrencyToUserWallet(
  userId: string,
  currency: WorldCurrency,
  amount: number = 1000,
  linkedWalletId?: string
): { success: boolean; message: string; updatedData: UserWalletData } {
  const walletData = getStoredUserWallets(userId);
  let updated = { ...walletData };
  const symbol = currency.symbol.toUpperCase();

  if (currency.category === 'stablecoin') {
    const existingIndex = (updated.stableCoins || []).findIndex(sc => sc.symbol.toUpperCase() === symbol);
    if (existingIndex >= 0) {
      const current = updated.stableCoins[existingIndex];
      const updatedList = [...updated.stableCoins];
      updatedList[existingIndex] = {
        ...current,
        balance: (current.balance || 0) + amount,
      };
      updated = { ...updated, stableCoins: updatedList };
    } else {
      const newStable: StableCoinItem = {
        id: `sc-imported-${currency.id}-${Date.now()}`,
        name: currency.name,
        symbol: currency.symbol,
        balance: amount,
        unitPriceUSD: currency.unitPriceUSD,
        peggedCurrency: currency.pegCurrency || 'USD',
        yieldAPY: 4.8,
        network: currency.network
      };
      updated = { ...updated, stableCoins: [newStable, ...(updated.stableCoins || [])] };
    }
  } else if (currency.category === 'crypto') {
    const existingIndex = (updated.cryptoCurrencies || []).findIndex(cr => cr.symbol.toUpperCase() === symbol);
    if (existingIndex >= 0) {
      const current = updated.cryptoCurrencies[existingIndex];
      const updatedList = [...updated.cryptoCurrencies];
      updatedList[existingIndex] = {
        ...current,
        balance: (current.balance || 0) + amount,
      };
      updated = { ...updated, cryptoCurrencies: updatedList };
    } else {
      const newCrypto: CryptoCurrencyItem = {
        id: `cr-imported-${currency.id}-${Date.now()}`,
        name: currency.name,
        symbol: currency.symbol,
        balance: amount,
        unitPriceUSD: currency.unitPriceUSD,
        change24h: currency.change24h,
        network: currency.network,
        walletAddress: `0x${Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('')}`
      };
      updated = { ...updated, cryptoCurrencies: [newCrypto, ...(updated.cryptoCurrencies || [])] };
    }
  } else {
    // Fiat
    const existingIndex = (updated.fiatCurrencies || []).findIndex(fi => fi.code.toUpperCase() === symbol);
    if (existingIndex >= 0) {
      const current = updated.fiatCurrencies[existingIndex];
      const updatedList = [...updated.fiatCurrencies];
      updatedList[existingIndex] = {
        ...current,
        balance: (current.balance || 0) + amount,
      };
      updated = { ...updated, fiatCurrencies: updatedList };
    } else {
      const newFiat: FiatCurrencyItem = {
        id: `fi-imported-${currency.id}-${Date.now()}`,
        name: currency.name,
        code: currency.symbol,
        symbol: currency.iconSymbol || currency.symbol,
        balance: amount,
        exchangeRateToUSD: currency.exchangeRateToUSD || (currency.unitPriceUSD > 0 ? 1 / currency.unitPriceUSD : 1),
        accountType: 'Connected Multi-Currency Account',
        institution: currency.issuer
      };
      updated = { ...updated, fiatCurrencies: [newFiat, ...(updated.fiatCurrencies || [])] };
    }
  }

  saveStoredUserWallets(userId, updated);
  return {
    success: true,
    message: `Added ${amount.toLocaleString()} ${currency.symbol} to your active wallet holdings.`,
    updatedData: updated
  };
}

export function removeCurrencyFromUserWallet(
  userId: string,
  symbol: string,
  category: 'stable' | 'crypto' | 'fiat' | 'final'
): { success: boolean; updatedData: UserWalletData } {
  const walletData = getStoredUserWallets(userId);
  let updated = { ...walletData };
  const s = symbol.toUpperCase();

  if (category === 'final') {
    updated = {
      ...updated,
      finalCoins: (updated.finalCoins || []).filter(fc => fc.symbol.toUpperCase() !== s)
    };
  } else if (category === 'stable') {
    updated = {
      ...updated,
      stableCoins: (updated.stableCoins || []).filter(sc => sc.symbol.toUpperCase() !== s)
    };
  } else if (category === 'crypto') {
    updated = {
      ...updated,
      cryptoCurrencies: (updated.cryptoCurrencies || []).filter(cr => cr.symbol.toUpperCase() !== s)
    };
  } else {
    updated = {
      ...updated,
      fiatCurrencies: (updated.fiatCurrencies || []).filter(fi => fi.code.toUpperCase() !== s)
    };
  }

  saveStoredUserWallets(userId, updated);
  return { success: true, updatedData: updated };
}
