import React, { useState } from 'react';
import { 
  StockItem, 
  StockOrder, 
  StockPosition,
  StockNewsItem
} from '../../types/stocks';
import { MARKET_INDICES, BREAKING_STOCK_NEWS } from '../../data/stocksData';
import { StockNewsFeed } from './StockNewsFeed';
import { StockHeaderSearchBar } from './StockHeaderSearchBar';
import { 
  Star, 
  ArrowRight, 
  ChevronRight, 
  Plus, 
  DollarSign, 
  Building2, 
  Wallet, 
  ShieldCheck, 
  CheckCircle2, 
  BarChart3, 
  Briefcase, 
  Eye
} from 'lucide-react';

interface StockFrontPageViewProps {
  stocks: StockItem[];
  positions: StockPosition[];
  watchlist: string[];
  orders: StockOrder[];
  news?: StockNewsItem[];
  onSelectStock: (stock: StockItem) => void;
  onToggleWatchlist: (ticker: string) => void;
  onQuickTrade: (stock: StockItem, side: 'buy' | 'sell') => void;
  onOpenLinkBankModal?: (tab: 'bank' | 'card' | 'crypto') => void;
  onNavigateBack?: () => void;
  totalLinked: number;
  numLinkedBanks: number;
  numLinkedCards: number;
  numLinkedCrypto: number;
}

export const StockFrontPageView: React.FC<StockFrontPageViewProps> = ({
  stocks,
  positions,
  watchlist,
  news = BREAKING_STOCK_NEWS,
  onSelectStock,
  onToggleWatchlist,
  onQuickTrade,
  onOpenLinkBankModal,
  onNavigateBack,
  totalLinked,
  numLinkedBanks,
  numLinkedCards,
  numLinkedCrypto,
}) => {
  const [activeTabSection, setActiveTabSection] = useState<'owned' | 'followed'>('owned');

  // Calculate owned stocks with current live prices
  const ownedPositions = positions.filter((p) => p.shares > 0);
  
  const enrichedPositions = ownedPositions.map((pos) => {
    const liveStock = stocks.find((s) => s.ticker === pos.ticker);
    const currentPrice = liveStock ? liveStock.price : pos.currentPriceUSD;
    const currentTotalValue = pos.shares * currentPrice;
    const totalCost = pos.shares * pos.avgCostUSD;
    const totalGain = currentTotalValue - totalCost;
    const totalGainPct = totalCost > 0 ? (totalGain / totalCost) * 100 : 0;
    const dayChangePct = liveStock ? liveStock.changePercent : 0;
    const dayChangeUSD = liveStock ? liveStock.changeUSD * pos.shares : 0;

    return {
      ...pos,
      liveStock,
      currentPrice,
      currentTotalValue,
      totalCost,
      totalGain,
      totalGainPct,
      dayChangePct,
      dayChangeUSD,
    };
  });

  // Calculate total portfolio summary values
  const totalPortfolioValue = enrichedPositions.reduce((acc, p) => acc + p.currentTotalValue, 0);
  const totalCostBasis = enrichedPositions.reduce((acc, p) => acc + p.totalCost, 0);
  const totalUnrealizedGain = totalPortfolioValue - totalCostBasis;
  const totalUnrealizedGainPct = totalCostBasis > 0 ? (totalUnrealizedGain / totalCostBasis) * 100 : 0;
  const totalDayGainUSD = enrichedPositions.reduce((acc, p) => acc + p.dayChangeUSD, 0);

  // Followed / Watchlist stocks
  const followedStocks = stocks.filter((s) => watchlist.includes(s.ticker));

  const ownedTickers = enrichedPositions.map((p) => p.ticker);
  const followedTickers = watchlist;

  const handleSelectByTicker = (ticker: string) => {
    const found = stocks.find((s) => s.ticker === ticker);
    if (found) {
      onSelectStock(found);
    }
  };

  const handleQuickTradeByTicker = (ticker: string) => {
    const found = stocks.find((s) => s.ticker === ticker);
    if (found) {
      onQuickTrade(found, 'buy');
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Bar for all Stocks & Equities (Instant ticker & company search) */}
      <StockHeaderSearchBar
        stocks={stocks}
        watchlist={watchlist}
        ownedTickers={ownedTickers}
        onSelectStock={onSelectStock}
        onQuickTrade={onQuickTrade}
      />

      {/* Top Banner: Navigation, Title & Live Status */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Final Finance</span>
            <ChevronRight className="w-3 h-3 text-slate-300" />
            <span className="text-slate-900 font-semibold">Stock Exchange</span>
          </div>
          <h1 className="text-lg sm:text-xl font-serif font-bold text-slate-900 leading-tight">
            My Stocks &amp; Followed Equities
          </h1>
        </div>

        {/* Live Status & Linked Status */}
        <div className="flex items-center gap-2 flex-wrap">
          {totalLinked > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900 text-white text-xs font-bold shadow-2xs">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="truncate max-w-[180px] sm:max-w-none">
                {[
                  numLinkedBanks > 0 ? `${numLinkedBanks} Bank${numLinkedBanks > 1 ? 's' : ''}` : null,
                  numLinkedCards > 0 ? `${numLinkedCards} Card${numLinkedCards > 1 ? 's' : ''}` : null,
                  numLinkedCrypto > 0 ? `${numLinkedCrypto} Crypto` : null
                ].filter(Boolean).join(' • ')}
              </span>
            </div>
          )}

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>NYSE &amp; NASDAQ • LIVE</span>
          </div>
        </div>
      </div>

      {/* Major Market Indices Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 overflow-x-auto pb-1 scrollbar-none">
        {MARKET_INDICES.map((idx) => {
          const isPos = idx.change >= 0;
          return (
            <div
              key={idx.symbol}
              className="p-3 rounded-2xl bg-white border border-slate-200 shadow-2xs min-w-[130px]"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-[11px] text-slate-500 truncate">
                  {idx.symbol}
                </span>
                <span
                  className={`text-[10px] font-mono font-bold flex items-center ${
                    isPos ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {isPos ? '+' : ''}{idx.changePercent.toFixed(2)}%
                </span>
              </div>
              <div className="font-mono font-bold text-sm sm:text-base text-slate-900 mt-0.5">
                {(idx.value ?? 0) > 100 ? (idx.value ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : (idx.value ?? 0).toFixed(2)}
              </div>
            </div>
          );
        })}
      </div>

      {/* Portfolio Performance & Watchlist Bento Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div 
          onClick={() => setActiveTabSection('owned')}
          className={`p-4 rounded-3xl text-white shadow-md border flex flex-col justify-between cursor-pointer transition-all ${
            activeTabSection === 'owned'
              ? 'bg-slate-900 border-emerald-500/50 ring-2 ring-emerald-500/30'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
          title="Click to view owned stocks"
        >
          <div>
            <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
              <span>Total Stock Holdings</span>
              <Briefcase className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="font-mono font-bold text-2xl text-white mt-1.5">
              ${totalPortfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs font-mono pt-2 border-t border-slate-800">
            <span className="text-slate-400">{ownedPositions.length} active positions</span>
            <span className={totalDayGainUSD >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
              {totalDayGainUSD >= 0 ? '+' : ''}${totalDayGainUSD.toFixed(2)} Today
            </span>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Total Unrealized P&amp;L</span>
              <BarChart3 className="w-4 h-4 text-amber-500" />
            </div>
            <div className={`font-mono font-bold text-2xl mt-1.5 ${totalUnrealizedGain >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              {totalUnrealizedGain >= 0 ? '+' : ''}${totalUnrealizedGain.toFixed(2)}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs font-mono pt-2 border-t border-slate-100">
            <span className="text-slate-400">Return Rate</span>
            <span className={`font-bold ${totalUnrealizedGainPct >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              {totalUnrealizedGainPct >= 0 ? '+' : ''}{totalUnrealizedGainPct.toFixed(2)}%
            </span>
          </div>
        </div>

        <div 
          onClick={() => setActiveTabSection('followed')}
          className={`p-4 rounded-3xl border shadow-2xs flex flex-col justify-between cursor-pointer transition-all ${
            activeTabSection === 'followed'
              ? 'bg-amber-50/90 border-amber-300 ring-2 ring-amber-400/40 shadow-xs'
              : 'bg-white border-slate-200 hover:border-amber-300'
          }`}
          title="Click to view followed stocks & watchlist"
        >
          <div>
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Followed Equities</span>
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            </div>
            <div className="font-mono font-bold text-2xl text-slate-900 mt-1.5">
              {followedStocks.length} Stocks
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs font-mono pt-2 border-t border-slate-100">
            <span className="text-slate-400">Click to view watchlist</span>
            <span className="text-emerald-600 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live Pricing
            </span>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-amber-50/80 border border-amber-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-amber-900 text-xs font-medium">
              <span>Trading Power &amp; Settlement</span>
              <ShieldCheck className="w-4 h-4 text-amber-700" />
            </div>
            <div className="font-serif font-bold text-lg text-amber-950 mt-1.5">
              0% Commission
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-amber-800 pt-2 border-t border-amber-200/60 font-medium">
            <span>SIPC Insured Vaults</span>
            <span>1-Click Trade</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs for Front Page */}
      <div className="flex items-center gap-2 bg-slate-100/90 p-1.5 rounded-2xl border border-slate-200 w-fit">
        <button
          type="button"
          onClick={() => setActiveTabSection('owned')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTabSection === 'owned'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
          <span>Stocks You Bought &amp; Own ({ownedPositions.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTabSection('followed')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTabSection === 'followed'
              ? 'bg-amber-500 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Star className={`w-3.5 h-3.5 ${activeTabSection === 'followed' ? 'text-white fill-white' : 'text-amber-500 fill-amber-500'}`} />
          <span>Stocks You Follow &amp; Favorited ({followedStocks.length})</span>
        </button>
      </div>

      {/* SECTION 1: STOCKS THE USER HAS BOUGHT (OWNED POSITIONS) */}
      {activeTabSection === 'owned' && (
        <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                <Briefcase className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-serif font-bold text-slate-900">
                  Stocks You Bought &amp; Own
                </h2>
                <p className="text-xs text-slate-500">
                  Active equity holdings backed by your linked accounts
                </p>
              </div>
            </div>

            <div className="font-mono text-right">
              <span className="text-[11px] text-slate-400 block font-medium">Holdings Value</span>
              <span className="text-sm font-bold text-emerald-700 block">
                ${totalPortfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {enrichedPositions.length === 0 ? (
            <div className="py-8 px-4 text-center rounded-2xl bg-slate-50 border border-dashed border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 mx-auto flex items-center justify-center">
                <Briefcase className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">No stocks purchased yet</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-0.5">
                  You haven't bought any equities yet. Browse our followed equities below to invest in platform-issued personal equities and business stocks.
                </p>
              </div>
              <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
                {(['ALEX', 'HYPR', 'AFNL-EQ', 'BSYN'] as const).map((tick) => {
                  const st = stocks.find((s) => s.ticker === tick);
                  if (!st) return null;
                  return (
                    <button
                      key={tick}
                      type="button"
                      onClick={() => onQuickTrade(st, 'buy')}
                      className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-xs font-bold text-slate-800 flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <span>Buy ${tick}</span>
                      <span className="text-[10px] text-emerald-600 font-mono">+1 Click</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {enrichedPositions.map((pos) => {
                const isPos = pos.totalGain >= 0;
                const liveStock = pos.liveStock || stocks.find((s) => s.ticker === pos.ticker);

                return (
                  <div
                    key={pos.ticker}
                    className="p-4 rounded-2xl bg-slate-50/90 border border-slate-200 hover:border-slate-300 hover:shadow-sm transition-all flex flex-col justify-between gap-3 group"
                  >
                    <div>
                      {/* Ticker, Name & Shares */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs shadow-2xs group-hover:bg-amber-600 transition-colors">
                            {pos.ticker}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-sm text-slate-900">
                                ${pos.ticker}
                              </span>
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                                {pos.shares} {pos.shares === 1 ? 'Share' : 'Shares'}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600 truncate max-w-[150px]">
                              {pos.name}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleWatchlist(pos.ticker);
                          }}
                          className="p-1 text-slate-400 hover:text-amber-500 cursor-pointer"
                          title={watchlist.includes(pos.ticker) ? 'Unfollow' : 'Follow'}
                        >
                          <Star
                            className={`w-4 h-4 ${
                              watchlist.includes(pos.ticker)
                                ? 'text-amber-500 fill-amber-500'
                                : 'text-slate-300'
                            }`}
                          />
                        </button>
                      </div>

                      {/* Position Financials */}
                      <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-200/80 text-xs font-mono">
                        <div>
                          <span className="text-[10px] text-slate-400 block">Total Value</span>
                          <span className="font-bold text-slate-900 text-sm">
                            ${pos.currentTotalValue.toFixed(2)}
                          </span>
                          <span className="text-[10px] text-slate-500 block">
                            ${pos.currentPrice.toFixed(2)} / sh
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block">Total Return</span>
                          <span className={`font-bold text-sm ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPos ? '+' : ''}${pos.totalGain.toFixed(2)}
                          </span>
                          <span className={`text-[10px] font-bold block ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                            ({isPos ? '+' : ''}{pos.totalGainPct.toFixed(2)}%)
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Actions: View Details (Separate Page) & Quick Trade */}
                    <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (liveStock) {
                            onSelectStock(liveStock);
                          }
                        }}
                        className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-95 text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
                        title={`View ${pos.name} in-depth stock details`}
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Details</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (liveStock) {
                            onQuickTrade(liveStock, 'buy');
                          }
                        }}
                        className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
                        title={`Buy More Shares of ${pos.ticker}`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Buy</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (liveStock) {
                            onQuickTrade(liveStock, 'sell');
                          }
                        }}
                        className="py-2 px-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
                        title={`Sell Shares of ${pos.ticker}`}
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        <span>Sell</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: FAVORITE & FOLLOWED STOCKS (WATCHLIST) */}
      {activeTabSection === 'followed' && (
        <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                <Star className="w-4 h-4 fill-amber-500 text-amber-600" />
              </div>
              <div>
                <h2 className="text-base font-serif font-bold text-slate-900">
                  Stocks You Follow &amp; Favorited
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{followedStocks.length} Followed</span>
            </div>
          </div>

          {followedStocks.length === 0 ? (
            <div className="py-8 px-4 text-center rounded-2xl bg-slate-50 border border-dashed border-slate-200 space-y-2">
              <Star className="w-8 h-8 mx-auto text-slate-300" />
              <h3 className="text-sm font-bold text-slate-800">Your Favorites List is Empty</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Follow equities to track real-time valuations, earnings reports, and breaking catalyst alerts.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {followedStocks.map((stock) => {
                const isPos = stock.changeUSD >= 0;
                const isOwned = positions.some((p) => p.ticker === stock.ticker && p.shares > 0);

                return (
                  <div
                    key={stock.ticker}
                    className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-amber-400/80 hover:shadow-md transition-all flex flex-col justify-between gap-3 group cursor-pointer"
                    onClick={() => onSelectStock(stock)}
                  >
                    <div>
                      {/* Header row: Ticker, Name, Star */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs shadow-2xs group-hover:bg-amber-600 transition-colors">
                            {stock.ticker}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-sm text-slate-900 group-hover:text-amber-800 transition-colors">
                                ${stock.ticker}
                              </span>
                              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                                {stock.exchange}
                              </span>
                              {isOwned && (
                                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                                  Owned
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-600 truncate max-w-[170px] font-medium">
                              {stock.name}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleWatchlist(stock.ticker);
                          }}
                          className="p-1.5 text-amber-500 hover:scale-110 active:scale-95 transition-all cursor-pointer"
                          title="Remove from Favorites"
                        >
                          <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                        </button>
                      </div>

                      {/* Live Price & Metrics */}
                      <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-100 text-xs font-mono">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-sans">Live Price</span>
                          <span className="font-bold text-slate-900 text-base">
                            ${stock.price.toFixed(2)}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block font-sans">24h Gain/Loss</span>
                          <span className={`font-bold text-sm ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%
                          </span>
                          <span className={`text-[10px] block ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                            ({isPos ? '+' : ''}${stock.changeUSD.toFixed(2)})
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-100">
                        <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
                          <span className="text-[10px] uppercase font-mono text-slate-400 block">Market Cap</span>
                          <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5 truncate">{stock.marketCap}</span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
                          <span className="text-[10px] uppercase font-mono text-slate-400 block">P/E Ratio</span>
                          <span className="font-mono font-bold text-xs text-slate-900 block mt-0.5">{stock.peRatio ? `${stock.peRatio.toFixed(1)}x` : 'N/A'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action: Instant Buy */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-end">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onQuickTrade(stock, 'buy');
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
                        title={`Instant Buy ${stock.ticker}`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Instant Buy</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: EQUITIES NEWS FEED & CATALYST INTELLIGENCE */}
      <StockNewsFeed
        news={news}
        stocks={stocks}
        ownedTickers={ownedTickers}
        followedTickers={followedTickers}
        onSelectTicker={handleSelectByTicker}
        onQuickTrade={handleQuickTradeByTicker}
      />
    </div>
  );
};
