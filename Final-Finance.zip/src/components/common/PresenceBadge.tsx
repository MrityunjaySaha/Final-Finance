import React from 'react';
import { useUserPresence } from '../../utils/presenceService';

interface PresenceStatusBadgeProps {
  identifiers?: string | Array<string | undefined | null> | null;
  forceOffline?: boolean;
  isOnline?: boolean;
  size?: 'xs' | 'sm';
  showDot?: boolean;
  className?: string;
}

export const PresenceStatusBadge: React.FC<PresenceStatusBadgeProps> = ({
  identifiers,
  forceOffline = false,
  isOnline: explicitOnline,
  size = 'xs',
  showDot = true,
  className = '',
}) => {
  const hookStatus = useUserPresence(identifiers, forceOffline);
  const online =
    forceOffline
      ? false
      : typeof explicitOnline === 'boolean'
        ? explicitOnline
        : hookStatus.isOnline;

  const sizeClasses =
    size === 'sm'
      ? 'px-2.5 py-0.5 text-[11px] gap-1.5'
      : 'px-2 py-0.5 text-[10px] gap-1';

  return (
    <span
      className={`inline-flex items-center justify-center rounded-full font-semibold border whitespace-nowrap shrink-0 leading-tight ${sizeClasses} ${
        online
          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
          : 'bg-slate-100 text-slate-500 border-slate-200'
      } ${className}`}
      title={online ? 'Currently Online' : 'Currently Offline'}
    >
      {showDot && (
        <span className="relative flex h-2 w-2 shrink-0">
          {online && (
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          )}
          <span
            className={`relative inline-flex rounded-full h-2 w-2 ${
              online ? 'bg-emerald-500' : 'bg-slate-400'
            }`}
          />
        </span>
      )}
      <span>{online ? 'Online' : 'Offline'}</span>
    </span>
  );
};

interface PresenceAvatarDotProps {
  identifiers?: string | Array<string | undefined | null> | null;
  forceOffline?: boolean;
  isOnline?: boolean;
  size?: 'xs' | 'sm' | 'md';
  className?: string;
}

export const PresenceAvatarDot: React.FC<PresenceAvatarDotProps> = ({
  identifiers,
  forceOffline = false,
  isOnline: explicitOnline,
  size = 'sm',
  className = '',
}) => {
  const hookStatus = useUserPresence(identifiers, forceOffline);
  const online =
    forceOffline
      ? false
      : typeof explicitOnline === 'boolean'
        ? explicitOnline
        : hookStatus.isOnline;

  const sizeClasses =
    size === 'md'
      ? 'w-3.5 h-3.5'
      : size === 'xs'
        ? 'w-2 h-2'
        : 'w-2.5 h-2.5';

  return (
    <span
      className={`absolute -bottom-0.5 -right-0.5 rounded-full ring-2 ring-white pointer-events-none ${sizeClasses} ${
        online ? 'bg-emerald-500' : 'bg-slate-300'
      } ${className}`}
      title={online ? 'Online right now' : 'Offline'}
    >
      {online && (
        <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-60" />
      )}
    </span>
  );
};
