import { AuthSession } from '../types/auth';
import { UserWalletData, LinkedBankAccountItem, LinkedCardItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import {
  StripeSavedPaymentMethod,
  fetchSavedPaymentMethods,
  getStripeConfigSafe,
} from '../services/stripeClientService';
import {
  PrivyWalletBalancesResponse,
  fetchPrivyWalletBalances,
} from '../services/privyClientService';
import { DEFAULT_PRIVY_NETWORK_KEY } from '../config/privyConfig';

export const PAYMENT_METHODS_UPDATED_EVENT = 'final_finance_payment_methods_updated';

export const SEEDED_UNVERIFIED_CARD_IDS = new Set(['card-1', 'card-2']);
export const SEEDED_UNVERIFIED_BANK_IDS = new Set(['bank-1', 'bank-2']);
export const SEEDED_UNVERIFIED_CRYPTO_IDS = new Set(['cw-1', 'cw-2', 'cw-3']);

export interface VerifiedCryptoWalletSummary {
  address: string;
  label: string;
  source: string;
  network: string;
  addedAt?: string;
}

export interface VerifiedPaymentSources {
  stripeConfigured: boolean;
  stripeReachable: boolean;
  banks: StripeSavedPaymentMethod[];
  cards: StripeSavedPaymentMethod[];
  cryptoWallets: VerifiedCryptoWalletSummary[];
  onChainBalances?: PrivyWalletBalancesResponse | null;
}

export const SUPPORTED_FIAT_CATALOG: Array<{
  code: string;
  name: string;
  symbol: string;
  exchangeRateToUSD: number;
  accountType: string;
  institution: string;
}> = [
  { code: 'USD', name: 'United States Dollar', symbol: '$', exchangeRateToUSD: 1.0, accountType: 'Checking & Fedwire', institution: 'JPMorgan Chase N.A.' },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF ', exchangeRateToUSD: 1.15, accountType: 'Institutional Escrow', institution: 'UBS Switzerland AG' },
  { code: 'GBP', name: 'British Pound Sterling', symbol: '£', exchangeRateToUSD: 1.30, accountType: 'Commercial Treasury', institution: 'Barclays Private Bank' },
  { code: 'EUR', name: 'Euro (SEPA Clearing)', symbol: '€', exchangeRateToUSD: 1.09, accountType: 'SEPA Treasury', institution: 'Deutsche Bank AG' },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', exchangeRateToUSD: 0.73, accountType: 'Clearing Account', institution: 'RBC Clearing' },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', exchangeRateToUSD: 0.0067, accountType: 'Settlement Account', institution: 'MUFG Clearing' },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', exchangeRateToUSD: 0.65, accountType: 'Settlement Account', institution: 'ANZ Clearing' },
];

export const SUPPORTED_STABLECOIN_CATALOG: Array<{
  symbol: string;
  name: string;
  peggedCurrency: string;
  yieldAPY: number;
  network: string;
  unitPriceUSD: number;
}> = [
  { symbol: 'USDC', name: 'USD Coin (Centre Consortium)', peggedCurrency: 'USD', yieldAPY: 5.4, network: 'Ethereum & Polygon', unitPriceUSD: 1.0 },
  { symbol: 'USDT', name: 'Tether USD', peggedCurrency: 'USD', yieldAPY: 4.8, network: 'Ethereum Mainnet', unitPriceUSD: 1.0 },
  { symbol: 'EURC', name: 'Euro Coin (Circle)', peggedCurrency: 'EUR', yieldAPY: 4.6, network: 'Ethereum & Base', unitPriceUSD: 1.09 },
  { symbol: 'PAXG', name: 'PAX Gold (LBMA Gold Backed)', peggedCurrency: '1oz Fine Gold', yieldAPY: 3.8, network: 'Ethereum Mainnet', unitPriceUSD: 2880.0 },
  { symbol: 'DAI', name: 'MakerDAO DAI', peggedCurrency: 'USD', yieldAPY: 5.0, network: 'Ethereum Mainnet', unitPriceUSD: 1.0 },
  { symbol: 'PYUSD', name: 'PayPal USD', peggedCurrency: 'USD', yieldAPY: 4.2, network: 'Ethereum & Solana', unitPriceUSD: 1.0 },
];

export const SUPPORTED_CRYPTO_CATALOG: Array<{
  symbol: string;
  name: string;
  unitPriceUSD: number;
  network: string;
}> = [
  { symbol: 'BTC', name: 'Bitcoin (Glacier Cold Storage)', unitPriceUSD: 94800.0, network: 'Bitcoin Mainnet' },
  { symbol: 'ETH', name: 'Ethereum (Validator Staking)', unitPriceUSD: 2820.0, network: 'Ethereum Mainnet' },
  { symbol: 'SOL', name: 'Solana (High Frequency Clearing)', unitPriceUSD: 195.0, network: 'Solana Network' },
  { symbol: 'POL', name: 'Polygon POL', unitPriceUSD: 0.55, network: 'Polygon PoS' },
  { symbol: 'AVAX', name: 'Avalanche', unitPriceUSD: 36.0, network: 'Avalanche C-Chain' },
];

export function emitPaymentMethodsUpdated(detail?: Record<string, unknown>): void {
  if (typeof window === 'undefined') return;
  try {
    window.dispatchEvent(new CustomEvent(PAYMENT_METHODS_UPDATED_EVENT, { detail }));
  } catch {
    try {
      window.dispatchEvent(new Event(PAYMENT_METHODS_UPDATED_EVENT));
    } catch {
      // ignore
    }
  }
}

export function syncStripeMethodsToWalletStorage(
  userId: string,
  paymentMethods: StripeSavedPaymentMethod[]
): UserWalletData {
  const current = getStoredUserWallets(userId);
  const banks: LinkedBankAccountItem[] = paymentMethods
    .filter((pm) => pm.type === 'us_bank_account')
    .map((pm) => ({
      id: pm.id,
      accountHolderName: pm.cardholderName || 'Verified Account Holder',
      bankName: pm.bankName || 'Connected Bank Account',
      accountType: pm.accountType === 'savings' ? 'Savings' : 'Checking',
      routingNumberMasked: pm.routingNumber || '••••',
      accountNumberLast4: pm.last4 || '0000',
      currency: 'USD',
      country: 'United States',
      isDefault: pm.isDefault,
      status: (pm.status as LinkedBankAccountItem['status']) || 'Verified',
      addedAt: new Date((pm.created || Math.floor(Date.now() / 1000)) * 1000).toISOString(),
    }));

  const cards: LinkedCardItem[] = paymentMethods
    .filter((pm) => pm.type === 'card')
    .map((pm) => {
      const normalizedBrand = (pm.brand || 'visa').toLowerCase();
      const safeBrand: LinkedCardItem['brand'] =
        normalizedBrand === 'mastercard' ||
        normalizedBrand === 'amex' ||
        normalizedBrand === 'discover'
          ? normalizedBrand
          : 'visa';
      return {
        id: pm.id,
        cardholderName: pm.cardholderName || 'VERIFIED CARDHOLDER',
        cardNumberLast4: pm.last4 || '0000',
        brand: safeBrand,
        cardType: pm.funding === 'credit' ? 'credit' : 'debit',
        expiryMonth: String(pm.expMonth || 1).padStart(2, '0'),
        expiryYear: String(pm.expYear || 2028).slice(-2),
        bankName: `${safeBrand.toUpperCase()} Verified`,
        isDefault: pm.isDefault,
        addedAt: new Date((pm.created || Math.floor(Date.now() / 1000)) * 1000).toISOString(),
      };
    });

  const next: UserWalletData = {
    ...current,
    linkedBankAccounts: banks,
    linkedCards: cards,
  };

  saveStoredUserWallets(userId, next);
  return next;
}

export function getVerifiedCryptoWalletsForUser(
  user: Pick<AuthSession, 'id' | 'uid'>
): VerifiedCryptoWalletSummary[] {
  const userId = user.id || 'guest';
  const userStorageKey = user.uid || user.id || 'guest';
  const result: VerifiedCryptoWalletSummary[] = [];
  const seen = new Set<string>();

  const addWallet = (item: VerifiedCryptoWalletSummary) => {
    const key = item.address.trim().toLowerCase();
    if (!key || seen.has(key)) return;
    seen.add(key);
    result.push(item);
  };

  if (typeof window !== 'undefined') {
    try {
      const rawManual = window.localStorage.getItem(`privy_manual_wallets_${userStorageKey}`);
      if (rawManual) {
        const parsed = JSON.parse(rawManual);
        if (Array.isArray(parsed)) {
          for (const w of parsed) {
            if (w?.address && /^0x[a-fA-F0-9]{40}$/.test(w.address)) {
              addWallet({
                address: w.address,
                label: w.label || 'Verified On-Chain Wallet',
                source: w.source || 'verified-wallet',
                network: 'Ethereum',
                addedAt: w.addedAt,
              });
            }
          }
        }
      }
    } catch {
      // ignore
    }

    try {
      const rawServer = window.localStorage.getItem(`privy_server_wallets_${userStorageKey}`);
      if (rawServer) {
        const parsed = JSON.parse(rawServer);
        if (Array.isArray(parsed)) {
          for (const w of parsed) {
            if (w?.address && /^0x[a-fA-F0-9]{40}$/.test(w.address)) {
              addWallet({
                address: w.address,
                label: 'Verified Vault Wallet',
                source: 'privy-server-api',
                network: 'Ethereum',
              });
            }
          }
        }
      }
    } catch {
      // ignore
    }
  }

  const storedWallets = getStoredUserWallets(userId);
  for (const w of storedWallets.linkedCryptoWallets || []) {
    if (SEEDED_UNVERIFIED_CRYPTO_IDS.has(w.id)) continue;
    if (w.address && /^0x[a-fA-F0-9]{40}$/.test(w.address)) {
      addWallet({
        address: w.address,
        label: w.walletName || 'Verified Crypto Wallet',
        source: 'verified-legacy',
        network: w.network || 'Ethereum',
        addedAt: w.connectedAt,
      });
    }
  }

  return result;
}

export async function loadVerifiedPaymentSources(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  options?: { fetchOnChainBalances?: boolean }
): Promise<VerifiedPaymentSources> {
  const userId = user.id || user.uid || 'guest';
  const cryptoWallets = getVerifiedCryptoWalletsForUser(user);

  const cfg = await getStripeConfigSafe();
  const stripeReachable = Boolean(cfg.reachable);
  const stripeConfigured = Boolean(cfg.reachable && cfg.configured);

  let paymentMethods: StripeSavedPaymentMethod[] = [];
  if (stripeConfigured) {
    try {
      const res = await fetchSavedPaymentMethods(user);
      paymentMethods = res.paymentMethods || [];
      syncStripeMethodsToWalletStorage(userId, paymentMethods);
    } catch {
      paymentMethods = [];
    }
  } else {
    syncStripeMethodsToWalletStorage(userId, []);
  }

  let onChainBalances: PrivyWalletBalancesResponse | null = null;
  if (options?.fetchOnChainBalances && cryptoWallets.length > 0) {
    try {
      onChainBalances = await fetchPrivyWalletBalances({
        address: cryptoWallets[0].address,
        network: DEFAULT_PRIVY_NETWORK_KEY,
      });
    } catch {
      onChainBalances = null;
    }
  }

  return {
    stripeConfigured,
    stripeReachable,
    banks: paymentMethods.filter((pm) => pm.type === 'us_bank_account'),
    cards: paymentMethods.filter((pm) => pm.type === 'card'),
    cryptoWallets,
    onChainBalances,
  };
}
