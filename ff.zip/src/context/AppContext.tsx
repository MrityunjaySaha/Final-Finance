import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  ReserveVault, 
  MarketplaceListing, 
  UserProfile, 
  CommunityPost, 
  Conversation, 
  Message, 
  GeneratedImageHistory,
  AssetClass,
  UniversalLedgerItem
} from '../types';
import { 
  INITIAL_VAULTS, 
  INITIAL_LISTINGS, 
  INITIAL_POSTS, 
  CURRENT_USER, 
  INITIAL_CONVERSATIONS, 
  INITIAL_MESSAGES,
  INITIAL_TRANSACTIONS
} from '../data/mockData';
import {
  recordLedgerTransaction,
  createLedgerItemFromVaultDeposit,
  createLedgerItemFromVaultWithdrawal
} from '../utils/universalLedgerBridge';
import {
  NotificationPreferences,
  getNotificationPreferences,
  saveNotificationPreferences,
  playNotificationChime,
  sendBrowserPushNotification,
  isCategoryEnabled,
  UniversalNotificationEventDetail,
  ChimeTone
} from '../utils/notificationService';
import { consumeQueuedUserNotifications } from '../services/socialService';
import { getAllMarketplaceListings } from '../services/marketplaceService';
import { applyCurrencyWalletDelta } from '../utils/walletBalanceUpdater';

export type NavTab = 
  | 'landing'
  | 'dashboard'
  | 'vaults' 
  | 'ai_studio' 
  | 'marketplace' 
  | 'community' 
  | 'messages' 
  | 'social' 
  | 'stocks'
  | 'subsidies'
  | 'uploads' 
  | 'qrcodes'
  | 'point_of_sale'
  | 'wallets' 
  | 'settings' 
  | 'fundraising'
  | 'community_search' 
  | 'search_results'
  | 'user_profile'
  | 'admin'
  | 'superadmin'
  | 'portfolio'
  | 'holdings'
  | 'tweeting'
  | 'listing_detail'
  | 'asset_inventory'
  | 'ride_share';

export type NotificationType = 
  | 'trade' 
  | 'stocks' 
  | 'vault' 
  | 'wallet' 
  | 'marketplace' 
  | 'pos'
  | 'ride_share'
  | 'delivery'
  | 'social' 
  | 'chat' 
  | 'subsidies' 
  | 'fundraising' 
  | 'security' 
  | 'system' 
  | 'feedback'
  | 'loans';

export interface NotificationItem {
  id: string;
  title: string;
  description: string;
  time: string;
  read: boolean;
  type: NotificationType;
  targetTab?: string;
  targetId?: string;
  amount?: number;
  currency?: string;
  timestampIso?: string;
}

interface Toast {
  id: string;
  type: 'success' | 'info' | 'error' | 'gold';
  title: string;
  message: string;
}

export type DeviceMode = 'web' | 'ios' | 'android' | 'tablet';

interface AppContextType {
  deviceMode: DeviceMode;
  setDeviceMode: (mode: DeviceMode) => void;
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  currentUser: UserProfile;
  setCurrentUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  vaults: ReserveVault[];
  setVaults: React.Dispatch<React.SetStateAction<ReserveVault[]>>;
  listings: MarketplaceListing[];
  setListings: React.Dispatch<React.SetStateAction<MarketplaceListing[]>>;
  posts: CommunityPost[];
  setPosts: React.Dispatch<React.SetStateAction<CommunityPost[]>>;
  conversations: Conversation[];
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  messages: Record<string, Message[]>;
  imageHistory: GeneratedImageHistory[];
  addImageToHistory: (item: Omit<GeneratedImageHistory, 'id' | 'createdAt'>) => GeneratedImageHistory;
  transactions: UniversalLedgerItem[];
  addTransaction: (tx: Omit<UniversalLedgerItem, 'id' | 'timestamp' | 'dateIso' | 'cryptographicHash' | 'signature' | 'receiptNumber'>) => void;
  reverseTransaction: (id: string) => void;
  createListing: (listing: Omit<MarketplaceListing, 'id' | 'createdAt' | 'likes' | 'sellerId' | 'sellerName' | 'sellerHandle' | 'sellerAvatar' | 'sellerVerified'>) => MarketplaceListing;
  publishDraft: (draftId: string) => void;
  deleteListing: (id: string) => void;
  toggleLikeListing: (id: string) => void;
  incrementListingView: (id: string) => void;
  buyOrSwapListing: (listing: MarketplaceListing, paymentVault: AssetClass) => boolean;
  createPost: (content: string, imageUrl?: string, imageMeta?: CommunityPost['imageMeta'], assetTag?: CommunityPost['assetTag']) => void;
  toggleLikePost: (postId: string) => void;
  addCommentToPost: (postId: string, commentText: string) => void;
  toggleFollowUser: (handle: string) => void;
  sendMessage: (conversationId: string, text: string, imageUrl?: string) => void;
  respondToTradeProposal: (conversationId: string, messageId: string, status: 'accepted' | 'declined') => void;
  startDirectConversation: (recipientName: string, recipientAvatar?: string, initialMessage?: string) => string;
  depositToVault: (vaultId: AssetClass, amountUSD: number, assetName: string) => void;
  withdrawFromVault: (vaultId: AssetClass, amountUSD: number) => boolean;
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
  stagedAssetForDraft: {
    imageUrl: string;
    title: string;
    description: string;
    category: AssetClass;
    imageResolution?: string;
    modelUsed?: string;
  } | null;
  setStagedAssetForDraft: (staged: {
    imageUrl: string;
    title: string;
    description: string;
    category: AssetClass;
    imageResolution?: string;
    modelUsed?: string;
  } | null) => void;
  notifications: NotificationItem[];
  setNotifications: React.Dispatch<React.SetStateAction<NotificationItem[]>>;
  addNotification: (
    notification: 
      | (Omit<Partial<NotificationItem>, 'id' | 'time' | 'read'> & { title: string; description: string; type?: NotificationType; showToast?: boolean; toastType?: 'success' | 'info' | 'error' | 'gold'; tone?: ChimeTone; _mediaHandled?: boolean })
      | string,
    legacyTypeOrToast?: any
  ) => void;
  deleteNotification: (id: string) => void;
  clearAllNotifications: () => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  notificationPrefs: NotificationPreferences;
  updateNotificationPrefs: (prefs: Partial<NotificationPreferences>) => void;
  triggerTestNotification: (type?: NotificationType) => void;
  previousTab: NavTab | null;
  setPreviousTab: (tab: NavTab | null) => void;
  returnListingId: string | null;
  setReturnListingId: (id: string | null) => void;
  chatReturnOrigin: 'marketplace' | 'listing_detail' | null;
  setChatReturnOrigin: (origin: 'marketplace' | 'listing_detail' | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('web');
  const [currentTab, setCurrentTab] = useState<NavTab>(() => {
    console.log('AppProvider: Initializing currentTab');
    try {
      // Check if user has an active session -> route to appropriate landing/dashboard
      const hasSession = localStorage.getItem('final_finance_auth_session');
      if (hasSession) {
        const parsed = JSON.parse(hasSession);
        const email = parsed.email?.trim().toLowerCase();
        if (email === 'ranmaanimaker@gmail.com') return 'superadmin';
        if (email === 'awesomedbz@gmail.com') return 'admin';
        return 'marketplace';
      }
    } catch (e) {
      console.warn('AppProvider: Failed to parse auth session', e);
    }
    return 'landing';
  });
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    console.log('AppProvider: Initializing currentUser');
    try {
      const saved = localStorage.getItem('final_finance_user');
      let user = saved ? JSON.parse(saved) : CURRENT_USER;
      const email = user.email?.trim().toLowerCase();
      if (email === 'ranmaanimaker@gmail.com' || email === 'awesomedbz@gmail.com') {
        user.verified = true;
        user.isVerified = true;
        user.role = email === 'ranmaanimaker@gmail.com' ? 'super_admin' : 'admin';
        user.verification = {
          verified: true,
          status: 'verified',
          monthlyFee: 0,
          subscriptionActive: true,
          subscriptionPlan: 'Admin Sovereign Pass (Free)',
          verifiedAt: new Date().toISOString(),
          paymentMethod: 'Automatic Sovereign Grant'
        };
      }
      return user;
    } catch (e) {
      console.warn('AppProvider: Failed to parse user profile', e);
      return CURRENT_USER;
    }
  });

  const [vaults, setVaults] = useState<ReserveVault[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_vaults');
      return saved ? JSON.parse(saved) : INITIAL_VAULTS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse vaults', e);
      return INITIAL_VAULTS;
    }
  });

  const [returnListingId, setReturnListingId] = useState<string | null>(null);
  const [chatReturnOrigin, setChatReturnOrigin] = useState<'marketplace' | 'listing_detail' | null>(null);

  const [listings, setListings] = useState<MarketplaceListing[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_listings');
      if (saved) {
        const parsed: MarketplaceListing[] = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const seedMap = new Map(INITIAL_LISTINGS.map((item) => [item.id, item]));
          let hydrated: MarketplaceListing[] = parsed.map((item) => {
            const seed = seedMap.get(item.id);
            return {
              ...seed,
              ...item,
              views: typeof item.views === 'number' ? item.views : (seed?.views ?? ((item.likes || 0) * 14 + 120)),
              photos: item.photos && item.photos.length > 0 ? item.photos : seed?.photos,
              videoUrl: item.videoUrl || seed?.videoUrl,
              videos: item.videos && item.videos.length > 0 ? item.videos : seed?.videos,
              tags: item.tags && item.tags.length > 0 ? item.tags : seed?.tags,
              hashtags: item.hashtags && item.hashtags.length > 0 ? item.hashtags : seed?.hashtags,
              skills: item.skills && item.skills.length > 0 ? item.skills : seed?.skills,
              description: seed?.description && item.description && seed.description.length > item.description.length && !item.description.includes('#')
                ? seed.description
                : item.description,
            };
          });
          if (!localStorage.getItem('ff_app_seeded_auctions_v1')) {
            const existingIds = new Set(hydrated.map((l) => l.id));
            const missingAuctions = INITIAL_LISTINGS.filter(
              (l) => l.listingIntent === 'auction' && !existingIds.has(l.id)
            );
            if (missingAuctions.length > 0) {
              hydrated = [...missingAuctions, ...hydrated];
            }
            localStorage.setItem('ff_app_seeded_auctions_v1', '1');
          }
          return hydrated;
        }
      }
      localStorage.setItem('ff_app_seeded_auctions_v1', '1');
      return INITIAL_LISTINGS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse listings', e);
      return INITIAL_LISTINGS;
    }
  });

  const [posts, setPosts] = useState<CommunityPost[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_posts');
      return saved ? JSON.parse(saved) : INITIAL_POSTS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse posts', e);
      return INITIAL_POSTS;
    }
  });

  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_convs');
      return saved ? JSON.parse(saved) : INITIAL_CONVERSATIONS;
    } catch (e) {
      console.warn('AppProvider: Failed to parse conversations', e);
      return INITIAL_CONVERSATIONS;
    }
  });

  const [activeConversationId, setActiveConversationId] = useState<string>(() => {
    return INITIAL_CONVERSATIONS[0]?.id || 'conv-1';
  });

  const [messages, setMessages] = useState<Record<string, Message[]>>(() => {
    try {
      const saved = localStorage.getItem('final_finance_msgs');
      return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
    } catch (e) {
      console.warn('AppProvider: Failed to parse messages', e);
      return INITIAL_MESSAGES;
    }
  });

  const [imageHistory, setImageHistory] = useState<GeneratedImageHistory[]>(() => {
    const saved = localStorage.getItem('final_finance_image_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return [
      {
        id: 'img-hist-1',
        imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=1000&q=80',
        prompt: 'A monolithic 100oz pure 24k gold ingot engraved with Final Finance emblem, resting on dark titanium podium with soft amber studio lighting',
        model: 'gemini-3-pro-image-preview',
        aspectRatio: '1:1',
        imageSize: '4K',
        createdAt: '2 hours ago',
        category: 'final_coins'
      },
      {
        id: 'img-hist-2',
        imageUrl: 'https://images.unsplash.com/photo-1567899378494-47b22a2ae96a?auto=format&fit=crop&w=1000&q=80',
        prompt: 'Luxury 65m black-hulled megayacht moored in Monaco harbor at twilight with golden illuminated deck',
        model: 'gemini-3-pro-image-preview',
        aspectRatio: '16:9',
        imageSize: '2K',
        createdAt: '4 hours ago',
        category: 'barter'
      },
      {
        id: 'img-hist-3',
        imageUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1000&q=80',
        prompt: 'Futuristic cryptographic sovereign reserve token with embedded glowing emerald neon circuits and physical gold bezel',
        model: 'gemini-3.1-flash-image-preview',
        aspectRatio: '1:1',
        imageSize: '1K',
        createdAt: '8 hours ago',
        category: 'crypto'
      }
    ];
  });

  const [stagedAssetForDraft, setStagedAssetForDraft] = useState<{
    imageUrl: string;
    title: string;
    description: string;
    category: AssetClass;
    imageResolution?: string;
    modelUsed?: string;
  } | null>(null);

  const [toasts, setToasts] = useState<Toast[]>([]);

  const getNotifStorageKey = useCallback((user: UserProfile) => {
    const rawKey = (user?.handle || user?.email || 'guest')
      .trim()
      .toLowerCase()
      .replace(/^@/, '')
      .replace(/[^a-z0-9_.-]/g, '_');
    return `final_finance_notifications_${rawKey || 'guest'}`;
  }, []);

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const rawKey = (currentUser?.handle || currentUser?.email || 'guest')
      .trim()
      .toLowerCase()
      .replace(/^@/, '')
      .replace(/[^a-z0-9_.-]/g, '_');
    const perUserKey = `final_finance_notifications_${rawKey || 'guest'}`;
    const saved = localStorage.getItem(perUserKey) || localStorage.getItem('final_finance_notifications');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [
      {
        id: 'notif-1',
        title: 'OTC Trade Proposal Received',
        description: 'Counterparty proposed 100oz Fine Gold for Switzerland Vault Allocation.',
        time: '12m ago',
        read: false,
        type: 'trade',
        targetTab: 'marketplace',
      },
      {
        id: 'notif-2',
        title: 'Vault Settlement Confirmed',
        description: 'Physical bullion reserve verified by Zurich Depository.',
        time: '1h ago',
        read: false,
        type: 'vault',
        targetTab: 'vaults',
      },
      {
        id: 'notif-3',
        title: 'Marketplace Listing Viewed',
        description: 'Your GPU cluster node listing received 4 new inquiries.',
        time: '3h ago',
        read: true,
        type: 'system',
        targetTab: 'uploads',
      },
    ];
  });

  const [previousTab, setPreviousTab] = useState<NavTab | null>(null);

  const [transactions, setTransactions] = useState<UniversalLedgerItem[]>(() => {
    const saved = localStorage.getItem('final_finance_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  // Sync with ledger update events
  useEffect(() => {
    const syncGlobalTransactions = () => {
      try {
        const saved = localStorage.getItem('final_finance_transactions');
        if (saved) {
          const parsed = JSON.parse(saved);
          setTransactions(parsed);
        }
      } catch (err) {
        console.warn('Failed to sync global transactions in AppContext', err);
      }
    };

    window.addEventListener('final_finance_global_transactions_updated', syncGlobalTransactions);
    window.addEventListener('final_finance_ledger_updated', syncGlobalTransactions);

    const syncMarketplaceUpdates = () => {
      try {
        const svcListings = getAllMarketplaceListings();
        const svcMap = new Map(svcListings.map((s) => [s.id, s]));
        setListings((prev): MarketplaceListing[] => {
          const updatedPrev: MarketplaceListing[] = prev.map((item) => {
            const match = svcMap.get(item.id);
            if (!match) return item;
            const mappedStatus: MarketplaceListing['status'] =
              match.status === 'sold' ? 'sold' : match.status === 'draft' ? 'draft' : 'active';
            return {
              ...item,
              status: mappedStatus,
              listingIntent: match.listingIntent || item.listingIntent,
              auctionConfig: match.auctionConfig || item.auctionConfig,
              acceptedSettlements: match.acceptedSettlements || item.acceptedSettlements,
              acceptedCurrencyList: match.acceptedCurrencyList || item.acceptedCurrencyList,
              priceUSD:
                match.listingIntent === 'auction' && match.auctionConfig?.highestBidUSD
                  ? match.auctionConfig.highestBidUSD
                  : (match.primaryPriceUSD ?? item.priceUSD),
            };
          });

          const existingIds = new Set(updatedPrev.map((l) => l.id));
          const validCategories = new Set<string>(['barter', 'final_coins', 'stable_coins', 'fiat', 'crypto']);
          const newlyUploaded: MarketplaceListing[] = svcListings
            .filter((s) => s.status === 'uploaded' && !existingIds.has(s.id))
            .map((s): MarketplaceListing => {
              const photos = (s.mediaList || []).filter((m) => m.type === 'image' && m.url).map((m) => m.url);
              const videos = (s.mediaList || []).filter((m) => m.type === 'video' && m.url).map((m) => m.url);
              const rawCat = String(s.category || '').toLowerCase();
              const resolvedCategory: AssetClass = validCategories.has(rawCat)
                ? (rawCat as AssetClass)
                : 'barter';
              const handleClean = (s.creatorHandle || s.userId || 'member').replace(/^@/, '');
              return {
                id: s.id,
                title: s.title || 'Untitled Listing',
                description: s.description || '',
                priceUSD:
                  s.listingIntent === 'auction' && s.auctionConfig?.highestBidUSD
                    ? s.auctionConfig.highestBidUSD
                    : (s.primaryPriceUSD || 0),
                priceInNative: s.finalCoinsPricing?.amount
                  ? `${s.finalCoinsPricing.amount.toLocaleString()} ${s.finalCoinsPricing.symbol}`
                  : undefined,
                category: resolvedCategory,
                itemType: s.itemType,
                listingIntent: s.listingIntent,
                auctionConfig: s.auctionConfig,
                primaryTradeMode: s.primaryTradeMode,
                primaryCurrency: s.primaryCurrency,
                acceptedSettlements: s.acceptedSettlements,
                acceptedCurrencyList: s.acceptedCurrencyList,
                sellerName: s.creatorName || 'Sovereign Member',
                sellerId: s.userId || handleClean,
                sellerHandle: `@${handleClean}`,
                sellerAvatar: s.creatorAvatar || '',
                sellerVerified: true,
                attributes: {},
                status: 'active',
                imageUrl: s.imageUrl || photos[0] || '',
                photos: photos.length > 0 ? photos : undefined,
                videoUrl: s.videoUrl || videos[0],
                videos: videos.length > 0 ? videos : undefined,
                tags: s.tags,
                skills: s.skills,
                location: s.location,
                condition: s.condition,
                quantity: s.quantity,
                unitLabel: s.unitLabel,
                availableUnits: s.availableUnits,
                unitType: s.unitType,
                turnaroundTime: s.turnaroundTime,
                deliverables: s.deliverables,
                barterDesired: s.barterTerms?.desiredTrades,
                finalCoinsPricing: s.finalCoinsPricing,
                stableCoinsPricing: s.stableCoinsPricing,
                fiatPricing: s.fiatPricing,
                cryptoPricing: s.cryptoPricing,
                barterTerms: s.barterTerms,
                likes: s.likes || 0,
                views: s.views || 0,
                createdAt: s.createdAt || new Date().toISOString(),
              };
            });

          return newlyUploaded.length > 0 ? [...newlyUploaded, ...updatedPrev] : updatedPrev;
        });
      } catch (err) {
        console.warn('Failed syncing marketplace updates in AppContext:', err);
      }
    };
    window.addEventListener('final_finance_listings_updated', syncMarketplaceUpdates);

    return () => {
      window.removeEventListener('final_finance_global_transactions_updated', syncGlobalTransactions);
      window.removeEventListener('final_finance_ledger_updated', syncGlobalTransactions);
      window.removeEventListener('final_finance_listings_updated', syncMarketplaceUpdates);
    };
  }, []);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('final_finance_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('final_finance_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('final_finance_vaults', JSON.stringify(vaults));
  }, [vaults]);

  useEffect(() => {
    localStorage.setItem('final_finance_listings', JSON.stringify(listings));
  }, [listings]);

  useEffect(() => {
    localStorage.setItem('final_finance_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('final_finance_convs', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem('final_finance_msgs', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('final_finance_image_history', JSON.stringify(imageHistory));
  }, [imageHistory]);

  useEffect(() => {
    localStorage.setItem(getNotifStorageKey(currentUser), JSON.stringify(notifications));
  }, [notifications, currentUser, getNotifStorageKey]);

  // Reload per-user notifications and drain queued notifications when active account changes or queue updates
  const syncPerUserQueue = useCallback((notifyOnNewQueue: boolean) => {
    const key = getNotifStorageKey(currentUser);
    const identifiers = [
      currentUser?.handle?.replace(/^@/, '') || '',
      currentUser?.email || '',
    ].filter(Boolean);

    try {
      const rawAuth = localStorage.getItem('final_finance_auth_session');
      if (rawAuth) {
        const sess = JSON.parse(rawAuth);
        if (sess?.uid) identifiers.push(sess.uid);
        if (sess?.id) identifiers.push(sess.id);
      }
    } catch {}

    const queued = consumeQueuedUserNotifications(identifiers);
    if (queued.length > 0) {
      const converted: NotificationItem[] = queued
        .filter((q) => isCategoryEnabled(q.type))
        .map((q) => ({
          id: q.id,
          title: q.title,
          description: q.description,
          time: 'Just now',
          read: false,
          type: (q.type || 'system') as NotificationType,
          targetTab: q.targetTab,
          targetId: q.targetId,
          amount: q.amount,
          currency: q.currency,
          timestampIso: q.createdAt,
        }));

      if (converted.length > 0) {
        setNotifications((prev) => {
          const existingIds = new Set(prev.map((n) => n.id));
          const uniqueIncoming = converted.filter((c) => !existingIds.has(c.id));
          if (uniqueIncoming.length === 0) return prev;
          const next = [...uniqueIncoming, ...prev];
          try {
            localStorage.setItem(key, JSON.stringify(next));
          } catch {}
          return next;
        });

        if (notifyOnNewQueue) {
          const latest = converted[0];
          playNotificationChime(
            latest.type === 'trade' || latest.type === 'stocks' || latest.type === 'vault'
              ? 'trade'
              : latest.type === 'ride_share' || latest.type === 'delivery' || latest.type === 'pos'
                ? 'success'
                : latest.type === 'chat' || latest.type === 'social'
                  ? 'message'
                  : latest.type === 'security'
                    ? 'alert'
                    : 'default'
          );
          sendBrowserPushNotification(latest.title, latest.description, latest.type);
        }
      }
    }
  }, [currentUser, getNotifStorageKey]);

  const prevNotifStorageKeyRef = React.useRef<string>(getNotifStorageKey(currentUser));

  useEffect(() => {
    const key = getNotifStorageKey(currentUser);
    const didSwitchUser = prevNotifStorageKeyRef.current !== key;
    prevNotifStorageKeyRef.current = key;

    if (didSwitchUser) {
      let baseList: NotificationItem[] = [];
      try {
        const saved = localStorage.getItem(key);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) baseList = parsed;
        }
      } catch {}
      setNotifications(baseList);
    }

    syncPerUserQueue(false);
  }, [currentUser.handle, currentUser.email, getNotifStorageKey, syncPerUserQueue]);

  useEffect(() => {
    const handleLiveQueueUpdate = () => {
      syncPerUserQueue(true);
    };
    const handleStorageQueueUpdate = (e: StorageEvent) => {
      if (!e.key || e.key === 'ff_user_notifications_queue_v1') {
        syncPerUserQueue(true);
      }
    };
    window.addEventListener('ff_user_notif_queue_updated', handleLiveQueueUpdate);
    window.addEventListener('storage', handleStorageQueueUpdate);
    return () => {
      window.removeEventListener('ff_user_notif_queue_updated', handleLiveQueueUpdate);
      window.removeEventListener('storage', handleStorageQueueUpdate);
    };
  }, [syncPerUserQueue]);

  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(() => {
    return getNotificationPreferences();
  });

  const updateNotificationPrefs = (newPrefs: Partial<NotificationPreferences>) => {
    const updated = { ...notificationPrefs, ...newPrefs };
    setNotificationPrefs(updated);
    saveNotificationPreferences(updated);
  };

  const addToast = useCallback((toast: Omit<Toast, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const addImageToHistory = (item: Omit<GeneratedImageHistory, 'id' | 'createdAt'>) => {
    const newEntry: GeneratedImageHistory = {
      ...item,
      id: 'img-' + Date.now(),
      createdAt: 'Just now',
    };
    setImageHistory((prev) => [newEntry, ...prev]);
    return newEntry;
  };

  const addNotification = useCallback((
    input: 
      | (Omit<Partial<NotificationItem>, 'id' | 'time' | 'read'> & { title: string; description: string; type?: NotificationType; showToast?: boolean; toastType?: 'success' | 'info' | 'error' | 'gold'; tone?: ChimeTone; _mediaHandled?: boolean })
      | string,
    legacyArg?: any
  ) => {
    let title = '';
    let description = '';
    let type: NotificationType = 'system';
    let targetTab: string | undefined = undefined;
    let showToastBanner = true;
    let toastType: 'success' | 'info' | 'error' | 'gold' = 'info';
    let tone: ChimeTone | undefined = undefined;
    let targetId: string | undefined = undefined;
    let amount: number | undefined = undefined;
    let currency: string | undefined = undefined;
    let mediaHandled = false;

    if (typeof input === 'string') {
      title = input;
      description = typeof legacyArg === 'string' ? legacyArg : input;
      if (typeof legacyArg === 'string' && (legacyArg === 'error' || legacyArg === 'success' || legacyArg === 'info' || legacyArg === 'gold')) {
        toastType = legacyArg as any;
        description = input;
      }
    } else {
      title = input.title;
      description = input.description;
      type = input.type || 'system';
      targetTab = input.targetTab;
      targetId = input.targetId;
      amount = input.amount;
      currency = input.currency;
      showToastBanner = input.showToast !== false;
      toastType = input.toastType || (
        type === 'stocks' || type === 'trade' || type === 'vault' ? 'gold'
        : type === 'ride_share' || type === 'delivery' || type === 'pos' ? 'success'
        : type === 'security' ? 'error'
        : 'info'
      );
      tone = input.tone;
      mediaHandled = Boolean(input._mediaHandled);
    }

    // Check if category is enabled in notification preferences
    if (!isCategoryEnabled(type)) {
      return;
    }

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title,
      description,
      time: 'Just now',
      read: false,
      type,
      targetTab,
      targetId,
      amount,
      currency,
      timestampIso: new Date().toISOString(),
    };

    setNotifications((prev) => [newNotif, ...prev]);

    if (!mediaHandled) {
      // Play synthesized Web Audio chime
      playNotificationChime(tone || (
        type === 'stocks' || type === 'trade' || type === 'vault' ? 'trade'
        : type === 'ride_share' || type === 'delivery' || type === 'pos' ? 'success'
        : type === 'chat' || type === 'social' ? 'message'
        : type === 'security' ? 'alert'
        : 'default'
      ));

      // Send Browser Push Notification if permission is granted & enabled
      sendBrowserPushNotification(title, description, type);
    }

    // Show floating toast banner if enabled
    if (showToastBanner && notificationPrefs.inAppBannerEnabled) {
      addToast({
        type: toastType,
        title,
        message: description,
      });
    }
  }, [addToast, notificationPrefs.inAppBannerEnabled]);

  useEffect(() => {
    const handleAppNotificationEvent = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        addNotification(customEvent.detail);
      }
    };
    window.addEventListener('ff-app-notification', handleAppNotificationEvent);
    return () => window.removeEventListener('ff-app-notification', handleAppNotificationEvent);
  }, [addNotification]);

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const triggerTestNotification = (category: NotificationType = 'stocks') => {
    const testSamples: Record<NotificationType, { title: string; description: string; targetTab: string }> = {
      stocks: {
        title: '📈 Stock Order Executed: $HYPR',
        description: 'Successfully purchased 50 shares of Hyperion Energy at $142.50 via Final Coin settlement.',
        targetTab: 'stocks',
      },
      trade: {
        title: '🤝 OTC Barter Proposal Accepted',
        description: 'Titan Vaults accepted your physical 100oz Silver Bullion transfer offer.',
        targetTab: 'marketplace',
      },
      vault: {
        title: '🏦 Zurich Gold Reserve Deposited',
        description: 'Allocated +$25,000 to Physical Gold Depository with audited provenance.',
        targetTab: 'vaults',
      },
      wallet: {
        title: '💳 Final Coin Transfer Received',
        description: 'Received +5,000 $AFNL ($5,000.00 USD) from Sovereign Staking Pool.',
        targetTab: 'wallets',
      },
      marketplace: {
        title: '🛍️ Marketplace Asset Sold',
        description: 'Your listing "NVIDIA H100 GPU Cluster Lease" was purchased for $12,500.',
        targetTab: 'uploads',
      },
      pos: {
        title: '🏪 POS Order Settled',
        description: 'Online merchant order #ORD-9921 settled via Final Coin ($AFNL) and recorded to Tax Ledger.',
        targetTab: 'point_of_sale',
      },
      ride_share: {
        title: '🚗 Sovereign Ride Dispatched',
        description: 'Driver accepted Zurich Freeport → Bahnhofstrasse (6 $AFNL/mi) with live GPS turn-by-turn routing.',
        targetTab: 'ride_share',
      },
      delivery: {
        title: '📦 Driver Delivery Accepted',
        description: 'Courier en route to merchant pickup (+15 $AFNL settlement) with proof capture enabled.',
        targetTab: 'ride_share',
      },
      social: {
        title: '🌟 New Follower on Final Finance',
        description: '@elena_quant started following your equity portfolio and trades.',
        targetTab: 'social',
      },
      chat: {
        title: '💬 Direct Message Received',
        description: 'Institutional Desk: "Your OTC settlement allocation has been confirmed."',
        targetTab: 'messages',
      },
      subsidies: {
        title: '🏛️ Sovereign Subsidy Disbursed',
        description: 'Grant claim #SUB-902 approved for $3,500.00 clean energy research allowance.',
        targetTab: 'subsidies',
      },
      fundraising: {
        title: '🚀 Campaign Goal Milestone Reached',
        description: 'Your project "Quantum Silicon Foundry" reached 85% of funding target.',
        targetTab: 'fundraising',
      },
      security: {
        title: '🛡️ Security Verification Notice',
        description: 'Biometric multi-factor key authenticated from verified workstation.',
        targetTab: 'settings',
      },
      feedback: {
        title: '✨ Platform Feedback Acknowledged',
        description: 'Thank you for your rating! Development ticket has been scheduled.',
        targetTab: 'settings',
      },
      loans: {
        title: '📄 Sovereign Credit Line Approved',
        description: 'Collateralized vault credit line of $50,000 ready for deployment.',
        targetTab: 'subsidies',
      },
      system: {
        title: '⚡ Final Finance Engine Operational',
        description: 'Global multi-currency network latency optimal across all 4 stock market ways.',
        targetTab: 'dashboard',
      },
    };

    const sample = testSamples[category] || testSamples.stocks;
    addNotification({
      title: sample.title,
      description: sample.description,
      type: category,
      targetTab: sample.targetTab,
      showToast: true,
    });
  };

  // Global event listener for custom notification events fired anywhere in the app
  useEffect(() => {
    const handleGlobalNotifEvent = (e: Event) => {
      const customEvt = e as CustomEvent<UniversalNotificationEventDetail & { _mediaHandled?: boolean }>;
      if (customEvt.detail) {
        addNotification({
          title: customEvt.detail.title,
          description: customEvt.detail.description,
          type: customEvt.detail.type as NotificationType,
          targetTab: customEvt.detail.targetTab,
          targetId: customEvt.detail.targetId,
          amount: customEvt.detail.amount,
          currency: customEvt.detail.currency,
          showToast: customEvt.detail.showToast,
          toastType: customEvt.detail.toastType,
          tone: customEvt.detail.tone,
          _mediaHandled: customEvt.detail._mediaHandled,
        });
      }
    };

    const handlePrefsChanged = (e: Event) => {
      const customEvt = e as CustomEvent<NotificationPreferences>;
      if (customEvt.detail) {
        setNotificationPrefs(customEvt.detail);
      }
    };

    window.addEventListener('final_finance_notification_event', handleGlobalNotifEvent);
    window.addEventListener('final_finance_prefs_changed', handlePrefsChanged);
    return () => {
      window.removeEventListener('final_finance_notification_event', handleGlobalNotifEvent);
      window.removeEventListener('final_finance_prefs_changed', handlePrefsChanged);
    };
  }, [addNotification]);

  const addTransaction = (data: Partial<UniversalLedgerItem> & Omit<UniversalLedgerItem, 'id' | 'timestamp' | 'dateIso' | 'cryptographicHash' | 'signature' | 'receiptNumber'>) => {
    const newTx: UniversalLedgerItem = {
      id: `TX-${Date.now().toString().slice(-6)}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      receiptNumber: `REC-${Math.floor(100 + Math.random() * 899)}-FF`,
      timestamp: 'Just now',
      dateIso: new Date().toISOString(),
      cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}...${Math.random().toString(16).slice(2, 6)}`,
      signature: `sig_${Math.random().toString(16).slice(2, 12)}`,
      ...data,
    };

    setTransactions((prev) => [newTx, ...prev]);

    try {
      const userId = currentUser?.id || 'current-user-id';
      const netUSD = data.netAmountUSD ?? data.amountUSD ?? 0;
      const mode = data.mode || 'final_coin';
      const currencySymbol = data.paymentCoinSymbol || data.stockTicker || (
        mode === 'final_coin' ? 'AFNL' :
        mode === 'stable_coin' ? 'USDC' :
        mode === 'crypto' ? 'BTC' :
        mode === 'gold_bullion' ? 'PAXG' : 'USD'
      );

      const isOutflow = 
        data.type === 'stock_buy' ||
        data.type === 'product_purchase' ||
        data.type === 'service_payment' ||
        data.type === 'ride_share_booking' ||
        data.type === 'vault_deposit' ||
        data.type === 'bank_withdraw' ||
        data.type === 'loan_issued' ||
        data.type === 'campaign_donation' ||
        (netUSD < 0 && data.type !== 'deposit' && data.type !== 'stock_sell' && data.type !== 'ride_share_payout' && data.type !== 'delivery_payout');

      const delta = isOutflow ? -Math.abs(netUSD) : Math.abs(netUSD);

      applyCurrencyWalletDelta({
        userId,
        currencySymbol,
        delta,
        allowNegativeClamp: true
      });
    } catch (err) {
      console.warn('Failed to update wallet currency on addTransaction:', err);
    }
  };

  const reverseTransaction = (id: string) => {
    const targetTx = transactions.find(t => t.id === id);
    
    setTransactions((prev) => 
      prev.map((tx) => tx.id === id ? { ...tx, status: 'Reversed' } : tx)
    );
    
    if (targetTx) {
      // Check if this transaction involved the current user and reverse the balance impact
      if (targetTx.issuerHandle === currentUser.handle || targetTx.sourceOrDestination === currentUser.handle) {
        const isOutgoing = targetTx.netAmountUSD < 0;
        const reversalAmount = -targetTx.netAmountUSD; // If it was -100, we add +100. If it was +100, we add -100.
        
        setCurrentUser((prev) => ({
          ...prev,
          portfolioNAV: prev.portfolioNAV + reversalAmount,
          holdings: {
            ...prev.holdings,
            [targetTx.mode || 'fiat_currency']: (prev.holdings[targetTx.mode || 'fiat_currency'] || 0) + reversalAmount
          }
        }));
      }
    }

    addToast({
      type: 'error',
      title: 'Transaction Control',
      message: `Transaction ${id} has been successfully reversed and funds restored to origin.`
    });

    addNotification({
      title: '🛡️ Transaction Reversed',
      description: `Transaction ${id}${targetTx?.title ? ` (${targetTx.title})` : ''} has been reversed and funds restored to origin.`,
      type: 'security',
      targetTab: 'dashboard',
      showToast: false,
      tone: 'alert',
    });
  };

  const createListing = (data: Omit<MarketplaceListing, 'id' | 'createdAt' | 'likes' | 'sellerId' | 'sellerName' | 'sellerHandle' | 'sellerAvatar' | 'sellerVerified'>) => {
    const newListing: MarketplaceListing = {
      ...data,
      id: 'mkt-' + Date.now(),
      sellerId: currentUser.id,
      sellerName: currentUser.name,
      sellerHandle: currentUser.handle,
      sellerAvatar: currentUser.avatarUrl,
      sellerVerified: currentUser.verified,
      createdAt: 'Just now',
      likes: 0,
      isLiked: false,
      views: data.views ?? 1,
    };

    setListings((prev) => [newListing, ...prev]);
    addToast({
      type: 'gold',
      title: data.status === 'draft' ? 'Draft Saved' : 'Asset Listed',
      message: data.status === 'draft' 
        ? `"${data.title}" saved to your private marketplace drafts.`
        : `"${data.title}" is now live on the multi-asset marketplace.`
    });
    addNotification({
      title: data.status === 'draft' ? 'Draft Saved' : 'Asset Listed on Marketplace',
      description: data.status === 'draft'
        ? `"${data.title}" was saved to your drafts.`
        : `"${data.title}" is now active in ${data.category.toUpperCase()} category for $${data.priceUSD.toLocaleString()}.`,
      type: 'marketplace',
      targetTab: 'marketplace',
    });
    return newListing;
  };

  const publishDraft = (draftId: string) => {
    const targetDraft = listings.find((l) => l.id === draftId);
    setListings((prev) => 
      prev.map((item) => item.id === draftId ? { ...item, status: 'active', createdAt: 'Just now' } : item)
    );
    addToast({
      type: 'success',
      title: 'Draft Published',
      message: 'Your asset draft is now live in the global reserve marketplace.'
    });
    addNotification({
      title: '🛍️ Draft Published to Marketplace',
      description: targetDraft
        ? `"${targetDraft.title}" is now live on the multi-asset marketplace.`
        : 'Your asset draft is now live in the global reserve marketplace.',
      type: 'marketplace',
      targetTab: 'listing_detail',
      targetId: draftId,
      showToast: false,
    });
  };

  const deleteListing = (id: string) => {
    const targetItem = listings.find((l) => l.id === id);
    setListings((prev) => prev.filter((item) => item.id !== id));
    addToast({
      type: 'info',
      title: 'Listing Removed',
      message: 'The asset has been withdrawn from the marketplace.'
    });
    addNotification({
      title: 'Marketplace Listing Removed',
      description: targetItem
        ? `"${targetItem.title}" has been withdrawn from the marketplace.`
        : 'Listing has been withdrawn from the marketplace.',
      type: 'marketplace',
      targetTab: 'uploads',
      showToast: false,
    });
  };

  const toggleLikeListing = (id: string) => {
    setListings((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const isLiked = !item.isLiked;
          return {
            ...item,
            isLiked,
            likes: isLiked ? item.likes + 1 : Math.max(0, item.likes - 1)
          };
        }
        return item;
      })
    );
  };

  const incrementListingView = (id: string) => {
    setListings((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, views: (item.views ?? 0) + 1 }
          : item
      )
    );
  };

  const buyOrSwapListing = (listing: MarketplaceListing, paymentVault: AssetClass) => {
    const userBalance = currentUser.holdings[paymentVault] || 0;
    if (userBalance < listing.priceUSD) {
      addToast({
        type: 'error',
        title: 'Insufficient Vault Balance',
        message: `Your ${paymentVault.replace('_', ' ')} vault balance is $${userBalance.toLocaleString()}, but this asset requires $${listing.priceUSD.toLocaleString()}.`
      });
      return false;
    }

    // Deduct payment and add asset
    setCurrentUser((prev) => ({
      ...prev,
      portfolioNAV: prev.portfolioNAV,
      holdings: {
        ...prev.holdings,
        [paymentVault]: prev.holdings[paymentVault] - listing.priceUSD,
        [listing.category]: prev.holdings[listing.category] + listing.priceUSD
      }
    }));

    // Mark listing as sold or update status
    setListings((prev) =>
      prev.map((item) => item.id === listing.id ? { ...item, status: 'sold' } : item)
    );

    addToast({
      type: 'gold',
      title: 'Settlement Executed',
      message: `Successfully acquired "${listing.title}" for $${listing.priceUSD.toLocaleString()} settled via ${paymentVault.toUpperCase()}.`
    });

    addNotification({
      title: 'Settlement Executed',
      description: `Successfully acquired "${listing.title}" for $${listing.priceUSD.toLocaleString()} settled via ${paymentVault.toUpperCase()} Vault.`,
      type: 'trade',
      targetTab: 'portfolio',
    });

    return true;
  };

  const createPost = (content: string, imageUrl?: string, imageMeta?: CommunityPost['imageMeta'], assetTag?: CommunityPost['assetTag']) => {
    const newPost: CommunityPost = {
      id: 'post-' + Date.now(),
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorHandle: currentUser.handle,
      authorAvatar: currentUser.avatarUrl,
      authorTier: currentUser.tier,
      authorVerified: currentUser.verified,
      content,
      imageUrl,
      imageMeta,
      assetTag,
      likes: 0,
      isLiked: false,
      commentsCount: 0,
      comments: [],
      shares: 0,
      createdAt: 'Just now'
    };

    setPosts((prev) => [newPost, ...prev]);
    addToast({
      type: 'success',
      title: 'Post Published',
      message: 'Your broadcast was shared to the Final Finance community.'
    });

    addNotification({
      title: 'Post Published',
      description: `Your broadcast "${content.slice(0, 40)}${content.length > 40 ? '...' : ''}" was successfully posted to the community feed.`,
      type: 'system',
      targetTab: 'community',
    });
  };

  const toggleLikePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const isLiked = !post.isLiked;
          return {
            ...post,
            isLiked,
            likes: isLiked ? post.likes + 1 : Math.max(0, post.likes - 1)
          };
        }
        return post;
      })
    );
  };

  const addCommentToPost = (postId: string, commentText: string) => {
    const newComment = {
      id: 'c-' + Date.now(),
      authorName: currentUser.name,
      authorHandle: currentUser.handle,
      authorAvatar: currentUser.avatarUrl,
      content: commentText,
      createdAt: 'Just now'
    };

    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            commentsCount: post.commentsCount + 1,
            comments: [...(post.comments || []), newComment]
          };
        }
        return post;
      })
    );

    addNotification({
      title: '💬 Community Reply Posted',
      description: `Added comment: "${commentText.slice(0, 60)}${commentText.length > 60 ? '...' : ''}"`,
      type: 'social',
      targetTab: 'community',
      showToast: true,
    });
  };

  const toggleFollowUser = (handle: string) => {
    setCurrentUser((prev) => ({
      ...prev,
      followingCount: prev.followingCount + 1
    }));

    addToast({
      type: 'info',
      title: 'Network Updated',
      message: `You are now following ${handle}.`
    });

    addNotification({
      title: 'Network Follow Updated',
      description: `You are now following ${handle}. Real-time trading updates enabled.`,
      type: 'social',
      targetTab: 'social',
    });
  };

  const sendMessage = (conversationId: string, text: string, imageUrl?: string) => {
    const newMsg: Message = {
      id: 'm-' + Date.now(),
      conversationId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatarUrl,
      text,
      imageUrl,
      createdAt: 'Just now'
    };

    setMessages((prev) => ({
      ...prev,
      [conversationId]: [...(prev[conversationId] || []), newMsg]
    }));

    setConversations((prev) =>
      prev.map((conv) =>
        conv.id === conversationId
          ? {
              ...conv,
              lastMessageText: text || (imageUrl ? 'Shared an image asset' : ''),
              lastMessageTime: 'Just now'
            }
          : conv
      )
    );

    // Simulate smart auto-reply from desk after 2.5 seconds
    setTimeout(() => {
      const activeConv = conversations.find((c) => c.id === conversationId);
      if (activeConv && activeConv.type === 'direct') {
        const replyText = `Confirmed Marcus. Our institutional settlement desk has logged your request regarding "${text.substring(0, 40)}...". Processing verification hash.`;
        const autoReply: Message = {
          id: 'm-auto-' + Date.now(),
          conversationId,
          senderId: 'desk-agent',
          senderName: activeConv.name,
          senderAvatar: activeConv.avatar,
          text: replyText,
          createdAt: 'Just now'
        };

        setMessages((prev) => ({
          ...prev,
          [conversationId]: [...(prev[conversationId] || []), autoReply]
        }));

        setConversations((prev) =>
          prev.map((conv) =>
            conv.id === conversationId
              ? {
                  ...conv,
                  lastMessageText: replyText,
                  lastMessageTime: 'Just now'
                }
              : conv
          )
        );

        addNotification({
          title: `New Message from ${activeConv.name}`,
          description: replyText,
          type: 'chat',
          targetTab: 'messages',
          tone: 'message',
        });
      }
    }, 2800);
  };

  const respondToTradeProposal = (conversationId: string, messageId: string, status: 'accepted' | 'declined') => {
    setMessages((prev) => ({
      ...prev,
      [conversationId]: (prev[conversationId] || []).map((msg) => {
        if (msg.id === messageId && msg.tradeProposal) {
          return {
            ...msg,
            tradeProposal: {
              ...msg.tradeProposal,
              status
            }
          };
        }
        return msg;
      })
    }));

    addToast({
      type: status === 'accepted' ? 'gold' : 'info',
      title: status === 'accepted' ? 'Trade Swap Accepted' : 'Trade Declined',
      message: status === 'accepted' 
        ? 'Escrow contracts deployed and asset titles transferred.' 
        : 'Counterparty informed of decision.'
    });

    addNotification({
      title: status === 'accepted' ? '🤝 Trade Proposal Accepted' : 'Trade Proposal Declined',
      description: status === 'accepted'
        ? 'Atomic escrow settlement confirmed. Assets credited to your portfolio holdings.'
        : 'The exchange proposal was declined and escrow holds released.',
      type: 'trade',
      targetTab: 'marketplace',
    });
  };

  const startDirectConversation = (recipientName: string, recipientAvatar?: string, initialMessage?: string) => {
    const existing = conversations.find((c) => c.name.toLowerCase() === recipientName.toLowerCase());
    if (existing) {
      setActiveConversationId(existing.id);
      setCurrentTab('messages');
      if (initialMessage) {
        sendMessage(existing.id, initialMessage);
      }
      return existing.id;
    }

    const newId = 'conv-' + Date.now();
    const newConv: Conversation = {
      id: newId,
      type: 'direct',
      name: recipientName,
      avatar: recipientAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      participantIds: [currentUser.id, 'temp-' + Date.now()],
      lastMessageText: initialMessage || 'Conversation opened',
      lastMessageTime: 'Just now',
      unreadCount: 0,
      isVerifiedDesk: true
    };

    setConversations((prev) => [newConv, ...prev]);
    setMessages((prev) => ({
      ...prev,
      [newId]: initialMessage ? [
        {
          id: 'm-init-' + Date.now(),
          conversationId: newId,
          senderId: currentUser.id,
          senderName: currentUser.name,
          senderAvatar: currentUser.avatarUrl,
          text: initialMessage,
          createdAt: 'Just now'
        }
      ] : []
    }));

    setActiveConversationId(newId);
    setCurrentTab('messages');
    return newId;
  };

  const depositToVault = (vaultId: AssetClass, amountUSD: number, assetName: string) => {
    setVaults((prev) =>
      prev.map((vault) => {
        if (vault.id === vaultId) {
          return {
            ...vault,
            totalReserveUSD: vault.totalReserveUSD + amountUSD
          };
        }
        return vault;
      })
    );

    setCurrentUser((prev) => ({
      ...prev,
      portfolioNAV: prev.portfolioNAV + amountUSD,
      holdings: {
        ...prev.holdings,
        [vaultId]: prev.holdings[vaultId] + amountUSD
      }
    }));

    // Record in Universal Ledger
    const vaultObj = vaults.find(v => v.id === vaultId);
    const vaultName = vaultObj?.name || vaultId.replace('_', ' ').toUpperCase();
    let mode: 'gold_bullion' | 'stable_coin' | 'fiat' | 'crypto' | 'final_coin' = 'gold_bullion';
    if (vaultId.includes('stable') || vaultId.includes('liquidity')) mode = 'stable_coin';
    else if (vaultId.includes('fiat') || vaultId.includes('treasury')) mode = 'fiat';
    else if (vaultId.includes('crypto') || vaultId.includes('btc') || vaultId.includes('eth')) mode = 'crypto';
    else if (vaultId.includes('final')) mode = 'final_coin';

    const ledgerItem = createLedgerItemFromVaultDeposit({
      vaultId,
      vaultName,
      amountUSD,
      assetName,
      mode
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    addToast({
      type: 'gold',
      title: 'Vault Allocation Confirmed',
      message: `Deposited $${amountUSD.toLocaleString()} (${assetName}) into ${vaultId.replace('_', ' ').toUpperCase()} Reserve Vault.`
    });

    addNotification({
      title: 'Vault Allocation Confirmed',
      description: `Allocated $${amountUSD.toLocaleString()} (${assetName}) into ${vaultId.replace('_', ' ').toUpperCase()} Reserve Vault.`,
      type: 'vault',
      targetTab: 'vaults',
    });
  };

  const withdrawFromVault = (vaultId: AssetClass, amountUSD: number) => {
    const currentBalance = currentUser.holdings[vaultId] || 0;
    if (currentBalance < amountUSD) {
      addToast({
        type: 'error',
        title: 'Exceeds Vault Balance',
        message: `Your available balance in ${vaultId.replace('_', ' ')} is $${currentBalance.toLocaleString()}.`
      });
      return false;
    }

    setVaults((prev) =>
      prev.map((vault) => {
        if (vault.id === vaultId) {
          return {
            ...vault,
            totalReserveUSD: Math.max(0, vault.totalReserveUSD - amountUSD)
          };
        }
        return vault;
      })
    );

    setCurrentUser((prev) => ({
      ...prev,
      portfolioNAV: Math.max(0, prev.portfolioNAV - amountUSD),
      holdings: {
        ...prev.holdings,
        [vaultId]: Math.max(0, prev.holdings[vaultId] - amountUSD)
      }
    }));

    // Record in Universal Ledger
    const vaultObj = vaults.find(v => v.id === vaultId);
    const vaultName = vaultObj?.name || vaultId.replace('_', ' ').toUpperCase();
    let mode: 'gold_bullion' | 'stable_coin' | 'fiat' | 'crypto' | 'final_coin' = 'gold_bullion';
    if (vaultId.includes('stable') || vaultId.includes('liquidity')) mode = 'stable_coin';
    else if (vaultId.includes('fiat') || vaultId.includes('treasury')) mode = 'fiat';
    else if (vaultId.includes('crypto') || vaultId.includes('btc') || vaultId.includes('eth')) mode = 'crypto';
    else if (vaultId.includes('final')) mode = 'final_coin';

    const ledgerItem = createLedgerItemFromVaultWithdrawal({
      vaultId,
      vaultName,
      amountUSD,
      mode
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    addToast({
      type: 'info',
      title: 'Settlement Withdrawn',
      message: `Withdrew $${amountUSD.toLocaleString()} from ${vaultId.replace('_', ' ').toUpperCase()} Vault to external custody.`
    });

    addNotification({
      title: 'Settlement Withdrawn',
      description: `Withdrew $${amountUSD.toLocaleString()} from ${vaultId.replace('_', ' ').toUpperCase()} Vault to external custody.`,
      type: 'vault',
      targetTab: 'vaults',
    });

    return true;
  };

  return (
    <AppContext.Provider
      value={{
        deviceMode,
        setDeviceMode,
        currentTab,
        setCurrentTab,
        currentUser,
        setCurrentUser,
        vaults,
        setVaults,
        listings,
        setListings,
        posts,
        setPosts,
        conversations,
        activeConversationId,
        setActiveConversationId,
        messages,
        imageHistory,
        addImageToHistory,
        transactions,
        addTransaction,
        reverseTransaction,
        createListing,
        publishDraft,
        deleteListing,
        toggleLikeListing,
        incrementListingView,
        buyOrSwapListing,
        createPost,
        toggleLikePost,
        addCommentToPost,
        toggleFollowUser,
        sendMessage,
        respondToTradeProposal,
        startDirectConversation,
        depositToVault,
        withdrawFromVault,
        toasts,
        addToast,
        removeToast,
        stagedAssetForDraft,
        setStagedAssetForDraft,
        notifications,
        setNotifications,
        addNotification,
        deleteNotification,
        clearAllNotifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        notificationPrefs,
        updateNotificationPrefs,
        triggerTestNotification,
        previousTab,
        setPreviousTab,
        returnListingId,
        setReturnListingId,
        chatReturnOrigin,
        setChatReturnOrigin,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
