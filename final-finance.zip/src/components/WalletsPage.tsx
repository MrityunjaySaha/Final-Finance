import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet, 
  ArrowLeft, 
  Repeat, 
  Sparkles, 
  ShieldCheck, 
  Building2, 
  Coins, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  TrendingUp, 
  Send, 
  QrCode, 
  Layers, 
  Check, 
  ExternalLink,
  Package,
  Briefcase,
  Trash2,
  Edit3,
  X,
  Clock,
  Banknote,
  Binary,
  CreditCard,
  Copy,
  Zap,
  Lock,
  Globe,
  RefreshCw,
  Cpu,
  CheckCircle2,
  HelpCircle,
  AlertCircle,
  Search
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { 
  UserWalletData, 
  WalletSectionType, 
  BarterGoodItem, 
  BarterServiceItem,
  LinkedCardItem,
  LinkedBankAccountItem,
  LinkedCryptoWalletItem,
  FiatCurrencyItem,
  CryptoCurrencyItem
} from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { useApp } from '../context/AppContext';
import { 
  recordLedgerTransaction, 
  createLedgerItemFromBarterGoodAdded, 
  createLedgerItemFromBarterServiceAdded, 
  createLedgerItemFromCardTopUp, 
  createLedgerItemFromCryptoDeposit,
  createLedgerItemFromDeposit
} from '../utils/universalLedgerBridge';

interface WalletsPageProps {
  currentUser?: AuthSession | null;
  onNavigateBack?: () => void;
  onInitiateBarterProposal?: (item: BarterGoodItem | BarterServiceItem) => void;
  onDepositVaultModal?: (vaultType: string) => void;
}

export const WalletsPage: React.FC<WalletsPageProps> = ({
  currentUser,
  onNavigateBack,
  onInitiateBarterProposal,
  onDepositVaultModal,
}) => {
  const { addNotification } = useApp();
  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(currentUser?.id || 'guest'));

  // Keep state synchronized with updates made in Settings, Equities Desk, or other tabs
  React.useEffect(() => {
    setWalletData(getStoredUserWallets(currentUser?.id || 'guest'));
    const handleUpdate = () => {
      setWalletData(getStoredUserWallets(currentUser?.id || 'guest'));
    };
    window.addEventListener('final_finance_wallets_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [currentUser?.id]);

  const [activeSection, setActiveSection] = useState<WalletSectionType>('fiat');
  const [barterSubTab, setBarterSubTab] = useState<'goods' | 'services'>('goods');
  const [fiatSubTab, setFiatSubTab] = useState<'all' | 'accounts' | 'cards' | 'banks'>('all');
  const [cryptoSubTab, setCryptoSubTab] = useState<'all' | 'holdings' | 'wallets'>('all');
  
  // Modal states for adding inventory & linking
  const [showAddGoodModal, setShowAddGoodModal] = useState(false);
  const [showAddServiceModal, setShowAddServiceModal] = useState(false);
  const [showLinkCardModal, setShowLinkCardModal] = useState(false);
  const [showLinkBankModal, setShowLinkBankModal] = useState(false);
  const [showConnectCryptoModal, setShowConnectCryptoModal] = useState(false);
  const [showCardTopUpModal, setShowCardTopUpModal] = useState<LinkedCardItem | null>(null);
  const [showBankDepositModal, setShowBankDepositModal] = useState<LinkedBankAccountItem | null>(null);
  const [showCryptoDepositModal, setShowCryptoDepositModal] = useState<LinkedCryptoWalletItem | null>(null);

  // New Good Form State
  const [goodName, setGoodName] = useState('');
  const [goodCategory, setGoodCategory] = useState('Precious Metals & Bullion');
  const [goodQuantity, setGoodQuantity] = useState<number>(1);
  const [goodUnitLabel, setGoodUnitLabel] = useState('bars');
  const [goodValueUSD, setGoodValueUSD] = useState<number>(5000);
  const [goodLocation, setGoodLocation] = useState('Zurich Freeport');
  const [goodDescription, setGoodDescription] = useState('');

  // New Service Form State
  const [serviceName, setServiceName] = useState('');
  const [serviceCategory, setServiceCategory] = useState('Cybersecurity & Auditing');
  const [serviceUnits, setServiceUnits] = useState<number>(20);
  const [serviceUnitType, setServiceUnitType] = useState<'Hours' | 'Sessions' | 'Consultations' | 'Deliverables' | 'Credits'>('Hours');
  const [serviceRateUSD, setServiceRateUSD] = useState<number>(300);
  const [serviceTurnaround, setServiceTurnaround] = useState('2-3 Days');
  const [serviceDescription, setServiceDescription] = useState('');

  // New Card Form State
  const [cardholderName, setCardholderName] = useState(currentUser?.name ? currentUser.name.toUpperCase() : 'ALEXANDER STERLING');
  const [cardNumber, setCardNumber] = useState('');
  const [cardBrand, setCardBrand] = useState<'visa' | 'mastercard' | 'amex' | 'discover' | 'unionpay'>('visa');
  const [cardType, setCardType] = useState<'credit' | 'debit'>('debit');
  const [cardExpMonth, setCardExpMonth] = useState('12');
  const [cardExpYear, setCardExpYear] = useState('29');
  const [cardCvv, setCardCvv] = useState('');
  const [cardBankName, setCardBankName] = useState('JPMorgan Chase');
  const [cardBillingZip, setCardBillingZip] = useState('10005');
  const [cardIsDefault, setCardIsDefault] = useState(false);

  // New Bank Account Form State
  const [bankAccountHolder, setBankAccountHolder] = useState(currentUser?.name || 'Alexander Sterling');
  const [bankInstitution, setBankInstitution] = useState('JPMorgan Chase');
  const [bankAccountType, setBankAccountType] = useState<'Checking' | 'Savings' | 'Business Treasury' | 'Escrow Deposit'>('Checking');
  const [bankRoutingNumber, setBankRoutingNumber] = useState('021000021');
  const [bankAccountNumber, setBankAccountNumber] = useState('');
  const [bankCurrency, setBankCurrency] = useState<'USD' | 'EUR' | 'GBP' | 'CHF' | 'CAD' | 'AUD' | 'JPY'>('USD');
  const [bankCountry, setBankCountry] = useState('United States');
  const [bankSwiftBic, setBankSwiftBic] = useState('');
  const [bankIsDefault, setBankIsDefault] = useState(false);
  const [isLinkingBankPlaid, setIsLinkingBankPlaid] = useState(false);
  const [bankSearchQuery, setBankSearchQuery] = useState('');
  const [selectedBankCategory, setSelectedBankCategory] = useState<'All' | 'US Major' | 'European' | 'Global / Private' | 'Credit Unions'>('All');

  // New Crypto Wallet Form / Connector State
  const [selectedWalletProvider, setSelectedWalletProvider] = useState<'metamask' | 'phantom' | 'coinbase' | 'walletconnect' | 'ledger' | 'custom'>('metamask');
  const [customWalletAddress, setCustomWalletAddress] = useState('');
  const [customWalletName, setCustomWalletName] = useState('');
  const [customWalletNetwork, setCustomWalletNetwork] = useState<'Ethereum' | 'Polygon' | 'Solana' | 'Bitcoin' | 'Base' | 'Arbitrum' | 'Multi-Chain'>('Ethereum');
  const [customWalletEns, setCustomWalletEns] = useState('');
  const [cryptoWalletIsPrimary, setCryptoWalletIsPrimary] = useState(false);
  const [isConnectingWeb3, setIsConnectingWeb3] = useState(false);
  const [cryptoSearchQuery, setCryptoSearchQuery] = useState('');
  const [selectedCryptoCategory, setSelectedCryptoCategory] = useState<'All' | 'Currencies & Tokens' | 'EVM Wallets' | 'Solana & SVM' | 'Hardware & Vaults' | 'Layer 2 & Cosmos' | 'Stablecoins & Currencies' | 'Crypto & Web3 Wallets'>('All');

  // Top Up / Deposit State
  const [topUpAmountUSD, setTopUpAmountUSD] = useState<number>(1000);
  const [topUpTargetCurrency, setTopUpTargetCurrency] = useState<string>('USD');
  const [bankDepositAmountUSD, setBankDepositAmountUSD] = useState<number>(5000);
  const [bankDepositTargetCurrency, setBankDepositTargetCurrency] = useState<string>('USD');
  const [cryptoDepositAmountUSD, setCryptoDepositAmountUSD] = useState<number>(5000);
  const [cryptoDepositTargetCoin, setCryptoDepositTargetCoin] = useState<string>('ETH');

  // Success toast & copied states
  const [toastMessage, setToastMessage] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast('Address copied to clipboard');
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Helper to format card numbers
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').slice(0, 16);
    // Auto-detect brand
    if (val.startsWith('4')) setCardBrand('visa');
    else if (val.startsWith('5') || val.startsWith('2')) setCardBrand('mastercard');
    else if (val.startsWith('3')) setCardBrand('amex');
    else if (val.startsWith('6')) setCardBrand('discover');

    // Add spaces every 4 digits
    const formatted = val.match(/.{1,4}/g)?.join(' ') || val;
    setCardNumber(formatted);
  };

  // Handler: Add Goods
  const handleCreateGood = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goodName.trim()) return;

    const newGood: BarterGoodItem = {
      id: `bg-${Date.now()}`,
      name: goodName.trim(),
      category: goodCategory,
      quantity: goodQuantity,
      unitLabel: goodUnitLabel,
      estimatedUnitValue: goodValueUSD,
      condition: 'Mint',
      description: goodDescription.trim() || 'Allocated item held in certified depository escrow.',
      location: goodLocation.trim(),
      tags: ['BarterInventory', (goodCategory || 'Goods').split(' ')[0]],
    };

    const updated = {
      ...walletData,
      barterGoods: [newGood, ...walletData.barterGoods],
    };

    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    setShowAddGoodModal(false);
    setGoodName('');

    // Record in Universal Ledger
    const ledgerItem = createLedgerItemFromBarterGoodAdded({
      goodName: newGood.name,
      quantity: newGood.quantity,
      unitValue: newGood.estimatedUnitValue,
      unitLabel: newGood.unitLabel
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    showToast(`Added "${newGood.name}" to your Barter Goods.`);
    addNotification({
      title: `📦 Barter Good Added: ${newGood.name}`,
      description: `${newGood.quantity} ${newGood.unitLabel} valued at $${(newGood.estimatedUnitValue * newGood.quantity).toLocaleString()} USD allocated to trade inventory.`,
      type: 'trade',
      targetTab: 'wallets',
    });
  };

  // Handler: Add Services
  const handleCreateService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceName.trim()) return;

    const newService: BarterServiceItem = {
      id: `bs-${Date.now()}`,
      name: serviceName.trim(),
      category: serviceCategory,
      availableUnits: serviceUnits,
      unitType: serviceUnitType,
      hourlyRateValue: serviceRateUSD,
      deliverableDescription: serviceDescription.trim() || 'Professional capacity with formal verification report.',
      turnaroundTime: serviceTurnaround,
      skills: [(serviceCategory || 'Services').split(' ')[0], 'Certified'],
    };

    const updated = {
      ...walletData,
      barterServices: [newService, ...walletData.barterServices],
    };

    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    setShowAddServiceModal(false);
    setServiceName('');

    // Record in Universal Ledger
    const ledgerItem = createLedgerItemFromBarterServiceAdded({
      serviceName: newService.name,
      availableUnits: newService.availableUnits,
      hourlyRate: newService.hourlyRateValue,
      unitType: newService.unitType
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    showToast(`Added "${newService.name}" to your Barter Services.`);
    addNotification({
      title: `💼 Barter Service Added: ${newService.name}`,
      description: `${newService.availableUnits} ${newService.unitType} @ $${newService.hourlyRateValue}/unit registered for peer exchange.`,
      type: 'trade',
      targetTab: 'wallets',
    });
  };

  // Handler: Link New Card
  const handleLinkCard = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNum = cardNumber.replace(/\s/g, '');
    if (cleanNum.length < 12) {
      showToast('Please enter a valid card number');
      return;
    }

    const last4 = cleanNum.slice(-4);
    const newCard: LinkedCardItem = {
      id: `card-${Date.now()}`,
      cardholderName: cardholderName.trim().toUpperCase() || 'CARDHOLDER',
      cardNumberLast4: last4,
      brand: cardBrand,
      cardType: cardType,
      expiryMonth: cardExpMonth.padStart(2, '0'),
      expiryYear: cardExpYear,
      bankName: cardBankName.trim() || 'Sovereign Clearing Bank',
      isDefault: cardIsDefault || (walletData.linkedCards?.length === 0),
      addedAt: new Date().toISOString(),
      billingZip: cardBillingZip.trim(),
    };

    const existingCards = (walletData.linkedCards || []).map(c => 
      newCard.isDefault ? { ...c, isDefault: false } : c
    );

    const updated: UserWalletData = {
      ...walletData,
      linkedCards: [newCard, ...existingCards],
    };

    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    setShowLinkCardModal(false);
    setCardNumber('');
    setCardCvv('');
    showToast(`Linked ${newCard.brand.toUpperCase()} ${newCard.cardType.toUpperCase()} (•••• ${last4}) successfully.`);
    addNotification({
      title: `💳 Card Linked: ${newCard.brand.toUpperCase()} •••• ${last4}`,
      description: `Payment card successfully enrolled for instant settlement and liquidity top-ups.`,
      type: 'wallet',
      targetTab: 'wallets',
    });
  };

  // Handler: Link Bank Account (Manual or Plaid / FedNow Instant)
  const handleLinkBank = (e?: React.FormEvent, instantProvider?: string) => {
    if (e) e.preventDefault();
    
    if (instantProvider) {
      setIsLinkingBankPlaid(true);
      setTimeout(() => {
        const last4 = String(Math.floor(1000 + Math.random() * 9000));
        const newBank: LinkedBankAccountItem = {
          id: `bank-${Date.now()}`,
          accountHolderName: currentUser?.name || 'Alexander Sterling',
          bankName: instantProvider,
          accountType: 'Checking',
          routingNumberMasked: '••••0210',
          accountNumberLast4: last4,
          currency: 'USD',
          country: 'United States',
          isDefault: (walletData.linkedBankAccounts?.length || 0) === 0,
          status: 'Instant FedNow Connected',
          addedAt: new Date().toISOString(),
          balanceUSD: 85000,
        };

        const existingBanks = (walletData.linkedBankAccounts || []).map(b => 
          newBank.isDefault ? { ...b, isDefault: false } : b
        );

        const updated: UserWalletData = {
          ...walletData,
          linkedBankAccounts: [newBank, ...existingBanks],
        };

        setWalletData(updated);
        saveStoredUserWallets(currentUser?.id || 'guest', updated);
        setIsLinkingBankPlaid(false);
        setShowLinkBankModal(false);
        showToast(`Connected ${instantProvider} (•••• ${last4}) via Instant Clearing.`);
      }, 700);
      return;
    }

    const cleanAcc = bankAccountNumber.trim();
    if (cleanAcc.length < 4) {
      showToast('Please enter a valid bank account number');
      return;
    }

    const last4 = cleanAcc.slice(-4);
    const maskedRouting = bankRoutingNumber.length >= 4 
      ? `••••${bankRoutingNumber.slice(-4)}` 
      : '••••0210';

    const newBank: LinkedBankAccountItem = {
      id: `bank-${Date.now()}`,
      accountHolderName: bankAccountHolder.trim() || 'Alexander Sterling',
      bankName: bankInstitution.trim() || 'Commercial Bank',
      accountType: bankAccountType,
      routingNumberMasked: maskedRouting,
      accountNumberLast4: last4,
      currency: bankCurrency,
      country: bankCountry.trim() || 'United States',
      swiftBic: bankSwiftBic.trim() || undefined,
      isDefault: bankIsDefault || ((walletData.linkedBankAccounts?.length || 0) === 0),
      status: 'Verified',
      addedAt: new Date().toISOString(),
      balanceUSD: 50000,
    };

    const existingBanks = (walletData.linkedBankAccounts || []).map(b => 
      newBank.isDefault ? { ...b, isDefault: false } : b
    );

    const updated: UserWalletData = {
      ...walletData,
      linkedBankAccounts: [newBank, ...existingBanks],
    };

    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    setShowLinkBankModal(false);
    setBankAccountNumber('');
    setBankSwiftBic('');
    showToast(`Bank account ${newBank.bankName} (•••• ${last4}) linked securely.`);
  };

  // Handler: Set Default Bank
  const handleSetDefaultBank = (bankId: string) => {
    const updatedBanks = (walletData.linkedBankAccounts || []).map(b => ({
      ...b,
      isDefault: b.id === bankId,
    }));
    const updated = { ...walletData, linkedBankAccounts: updatedBanks };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Default bank account updated for wire settlements.');
  };

  // Handler: Unlink Bank
  const handleUnlinkBank = (bankId: string) => {
    const remaining = (walletData.linkedBankAccounts || []).filter(b => b.id !== bankId);
    if (remaining.length > 0 && !remaining.some(b => b.isDefault)) {
      remaining[0].isDefault = true;
    }
    const updated = { ...walletData, linkedBankAccounts: remaining };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Bank account disconnected.');
  };

  // Handler: Deposit / Wire from Linked Bank to Fiat Balance
  const handleExecuteBankDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showBankDepositModal || bankDepositAmountUSD <= 0) return;

    const targetFiat = walletData.fiatCurrencies.find(f => f.code === bankDepositTargetCurrency);
    if (!targetFiat) return;

    const rate = targetFiat.exchangeRateToUSD || 1.0;
    const addedUnits = bankDepositAmountUSD / rate;

    const updatedFiat = walletData.fiatCurrencies.map(f => {
      if (f.code === bankDepositTargetCurrency) {
        return { ...f, balance: f.balance + addedUnits };
      }
      return f;
    });

    const updated = { ...walletData, fiatCurrencies: updatedFiat };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    setShowBankDepositModal(null);

    // Record in Universal Ledger
    const ledgerItem = createLedgerItemFromDeposit(
      bankDepositAmountUSD, 
      `${showBankDepositModal.bankName} (•••• ${showBankDepositModal.accountNumberLast4})`,
      'fiat'
    );
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    showToast(`Transferred $${bankDepositAmountUSD.toLocaleString()} USD from ${showBankDepositModal.bankName} (•••• ${showBankDepositModal.accountNumberLast4}) to ${targetFiat.code} treasury.`);
    addNotification({
      title: `🏦 Bank Transfer Settled: $${bankDepositAmountUSD.toLocaleString()} USD`,
      description: `Inbound transfer from ${showBankDepositModal.bankName} (•••• ${showBankDepositModal.accountNumberLast4}) deposited to ${targetFiat.code}.`,
      type: 'wallet',
      targetTab: 'wallets',
      amount: bankDepositAmountUSD,
      currency: 'USD',
    });
  };

  // Handler: Set Default Card
  const handleSetDefaultCard = (cardId: string) => {
    const updatedCards = (walletData.linkedCards || []).map(c => ({
      ...c,
      isDefault: c.id === cardId,
    }));
    const updated = { ...walletData, linkedCards: updatedCards };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Default payment card updated.');
  };

  // Handler: Unlink Card
  const handleUnlinkCard = (cardId: string) => {
    const remaining = (walletData.linkedCards || []).filter(c => c.id !== cardId);
    if (remaining.length > 0 && !remaining.some(c => c.isDefault)) {
      remaining[0].isDefault = true;
    }
    const updated = { ...walletData, linkedCards: remaining };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Card unlinked successfully.');
  };

  // Handler: Instant Top-Up from Card to Fiat Balance
  const handleExecuteCardTopUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showCardTopUpModal || topUpAmountUSD <= 0) return;

    const targetFiat = walletData.fiatCurrencies.find(f => f.code === topUpTargetCurrency);
    if (!targetFiat) return;

    const rate = targetFiat.exchangeRateToUSD || 1.0;
    const addedUnits = topUpAmountUSD / rate;

    const updatedFiat = walletData.fiatCurrencies.map(f => {
      if (f.code === topUpTargetCurrency) {
        return { ...f, balance: f.balance + addedUnits };
      }
      return f;
    });

    const updated = { ...walletData, fiatCurrencies: updatedFiat };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    setShowCardTopUpModal(null);

    // Record in Universal Ledger
    const ledgerItem = createLedgerItemFromCardTopUp({
      amountUSD: topUpAmountUSD,
      cardLast4: showCardTopUpModal.cardNumberLast4,
      brand: showCardTopUpModal.brand,
      targetFiatName: targetFiat.name
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    showToast(`Funded $${topUpAmountUSD.toLocaleString()} USD into ${targetFiat.name} via card •••• ${showCardTopUpModal.cardNumberLast4}.`);
    addNotification({
      title: `💳 Card Top-Up Completed: $${topUpAmountUSD.toLocaleString()} USD`,
      description: `Funded into ${targetFiat.code} balance via card •••• ${showCardTopUpModal.cardNumberLast4}.`,
      type: 'wallet',
      targetTab: 'wallets',
      amount: topUpAmountUSD,
      currency: 'USD',
    });
  };

  // Handler: Connect Crypto Wallet (1-Click, Searched Asset, or Manual)
  const handleConnectCryptoWallet = (
    e?: React.FormEvent,
    instantCryptoItem?: { name: string; symbol?: string; network: string; type: 'wallet' | 'crypto'; logo?: string; addressPrefix?: string }
  ) => {
    if (e) e.preventDefault();
    setIsConnectingWeb3(true);

    setTimeout(() => {
      let walletName = 'Web3 Wallet';
      let address = '';
      let network = customWalletNetwork;
      let balanceUSD = 45000;
      let ens = customWalletEns;
      let walletType: any = selectedWalletProvider;

      if (instantCryptoItem) {
        walletName = instantCryptoItem.symbol 
          ? `${instantCryptoItem.name} (${instantCryptoItem.symbol}) Vault`
          : instantCryptoItem.name;
        network = instantCryptoItem.network as any;
        walletType = instantCryptoItem.type === 'wallet' ? instantCryptoItem.name.toLowerCase().replace(/\s+/g, '') : 'custom';
        
        // Generate authentic address pattern based on network/chain
        if (instantCryptoItem.network === 'Bitcoin' || instantCryptoItem.symbol === 'BTC') {
          address = 'bc1q' + Array.from({length: 38}, () => Math.floor(Math.random()*36).toString(36)).join('');
          balanceUSD = 185000;
        } else if (instantCryptoItem.network === 'Solana' || instantCryptoItem.symbol === 'SOL') {
          address = '8x' + Array.from({length: 42}, () => Math.floor(Math.random()*36).toString(36)).join('');
          balanceUSD = 76000;
        } else if (instantCryptoItem.symbol === 'XRP') {
          address = 'r' + Array.from({length: 33}, () => Math.floor(Math.random()*36).toString(36)).join('');
          balanceUSD = 42000;
        } else if (instantCryptoItem.symbol === 'ADA') {
          address = 'addr1' + Array.from({length: 50}, () => Math.floor(Math.random()*36).toString(36)).join('');
          balanceUSD = 31000;
        } else if (instantCryptoItem.symbol === 'TON') {
          address = 'EQ' + Array.from({length: 44}, () => Math.floor(Math.random()*36).toString(36)).join('');
          balanceUSD = 58000;
        } else if (instantCryptoItem.symbol === 'SUI') {
          address = '0x' + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('');
          balanceUSD = 39000;
        } else if (instantCryptoItem.symbol === 'DOGE') {
          address = 'D' + Array.from({length: 33}, () => Math.floor(Math.random()*36).toString(36)).join('');
          balanceUSD = 28000;
        } else if (instantCryptoItem.network === 'Cosmos' || instantCryptoItem.symbol === 'ATOM') {
          address = 'cosmos1' + Array.from({length: 38}, () => Math.floor(Math.random()*36).toString(36)).join('');
          balanceUSD = 34000;
        } else {
          // Standard EVM
          address = '0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('');
          balanceUSD = 95000;
        }
      } else if (selectedWalletProvider === 'metamask') {
        walletName = 'MetaMask';
        network = 'Ethereum';
        address = '0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('');
        ens = ens || 'sovereign-vault.eth';
        balanceUSD = 128500;
      } else if (selectedWalletProvider === 'phantom') {
        walletName = 'Phantom Wallet';
        network = 'Solana';
        address = '8x' + Array.from({length: 42}, () => Math.floor(Math.random()*36).toString(36)).join('');
        ens = ens || 'sterling.sol';
        balanceUSD = 64200;
      } else if (selectedWalletProvider === 'coinbase') {
        walletName = 'Coinbase Smart Wallet';
        network = 'Base';
        address = '0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('');
        ens = ens || 'alexander.base.eth';
        balanceUSD = 92000;
      } else if (selectedWalletProvider === 'walletconnect') {
        walletName = 'WalletConnect Mobile';
        network = 'Multi-Chain';
        address = '0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join('');
        balanceUSD = 55000;
      } else if (selectedWalletProvider === 'ledger') {
        walletName = 'Ledger Hardware Vault';
        network = 'Bitcoin';
        address = 'bc1q' + Array.from({length: 38}, () => Math.floor(Math.random()*36).toString(36)).join('');
        balanceUSD = 340000;
      } else {
        walletName = customWalletName.trim() || 'Custom Sovereign Wallet';
        address = customWalletAddress.trim() || ('0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join(''));
        balanceUSD = 25000;
      }

      const newCryptoWallet: LinkedCryptoWalletItem = {
        id: `cw-${Date.now()}`,
        walletName,
        walletType,
        address,
        network,
        isPrimary: cryptoWalletIsPrimary || (walletData.linkedCryptoWallets?.length === 0),
        connectedAt: new Date().toISOString(),
        balanceUSD,
        ensOrDomain: ens?.trim() || undefined,
      };

      const existing = (walletData.linkedCryptoWallets || []).map(w => 
        newCryptoWallet.isPrimary ? { ...w, isPrimary: false } : w
      );

      const updated: UserWalletData = {
        ...walletData,
        linkedCryptoWallets: [newCryptoWallet, ...existing],
      };

      setWalletData(updated);
      saveStoredUserWallets(currentUser?.id || 'guest', updated);
      setIsConnectingWeb3(false);
      setShowConnectCryptoModal(false);
      setCustomWalletAddress('');
      setCustomWalletName('');
      setCustomWalletEns('');
      showToast(`Connected ${walletName} (${network}) to sovereign escrow.`);
    }, 600);
  };

  // Handler: Set Primary Crypto Wallet
  const handleSetPrimaryCryptoWallet = (walletId: string) => {
    const updatedWallets = (walletData.linkedCryptoWallets || []).map(w => ({
      ...w,
      isPrimary: w.id === walletId,
    }));
    const updated = { ...walletData, linkedCryptoWallets: updatedWallets };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Primary Web3 signing wallet updated.');
  };

  // Handler: Unlink Crypto Wallet
  const handleUnlinkCryptoWallet = (walletId: string) => {
    const remaining = (walletData.linkedCryptoWallets || []).filter(w => w.id !== walletId);
    if (remaining.length > 0 && !remaining.some(w => w.isPrimary)) {
      remaining[0].isPrimary = true;
    }
    const updated = { ...walletData, linkedCryptoWallets: remaining };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Crypto wallet disconnected.');
  };

  // Handler: Deposit from Crypto Wallet into Reserve
  const handleExecuteCryptoDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showCryptoDepositModal || cryptoDepositAmountUSD <= 0) return;

    const targetCoin = walletData.cryptoCurrencies.find(c => c.symbol === cryptoDepositTargetCoin);
    if (!targetCoin) return;

    const addedUnits = cryptoDepositAmountUSD / targetCoin.unitPriceUSD;

    const updatedCrypto = walletData.cryptoCurrencies.map(c => {
      if (c.symbol === cryptoDepositTargetCoin) {
        return { ...c, balance: Number((c.balance + addedUnits).toFixed(4)) };
      }
      return c;
    });

    const updated = { ...walletData, cryptoCurrencies: updatedCrypto };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    setShowCryptoDepositModal(null);

    // Record in Universal Ledger
    const ledgerItem = createLedgerItemFromCryptoDeposit({
      amountUSD: cryptoDepositAmountUSD,
      units: addedUnits,
      symbol: targetCoin.symbol,
      walletName: showCryptoDepositModal.walletName
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    showToast(`Deposited ${addedUnits.toFixed(4)} ${targetCoin.symbol} ($${cryptoDepositAmountUSD.toLocaleString()} USD) from ${showCryptoDepositModal.walletName}.`);
  };

  const handleDeleteGood = (id: string) => {
    const updated = {
      ...walletData,
      barterGoods: walletData.barterGoods.filter((g) => g.id !== id),
    };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Item removed from portfolio.');
  };

  const handleDeleteService = (id: string) => {
    const updated = {
      ...walletData,
      barterServices: walletData.barterServices.filter((s) => s.id !== id),
    };
    setWalletData(updated);
    saveStoredUserWallets(currentUser?.id || 'guest', updated);
    showToast('Service capacity updated.');
  };

  // Portfolio Totals (excluding non-priced barter and non-convertible Final Coins)
  const barterGoodsTotalUSD = 0;
  const barterServicesTotalUSD = 0;
  const finalCoinsTotalUSD = 0;
  const stableCoinsTotalUSD = walletData.stableCoins.reduce((sum, s) => sum + s.balance * s.unitPriceUSD, 0);
  const fiatTotalUSD = walletData.fiatCurrencies.reduce((sum, f) => sum + f.balance * f.exchangeRateToUSD, 0);
  const cryptoTotalUSD = walletData.cryptoCurrencies.reduce((sum, c) => sum + c.balance * c.unitPriceUSD, 0);

  const aggregateTotalPortfolioUSD = 
    stableCoinsTotalUSD + 
    fiatTotalUSD + 
    cryptoTotalUSD;

  const linkedCardsList = walletData.linkedCards || [];
  const linkedBanksList = walletData.linkedBankAccounts || [];
  const linkedCryptoList = walletData.linkedCryptoWallets || [];

  return (
    <div className="space-y-6 pb-16 text-left">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 text-white text-xs font-semibold shadow-2xl flex items-center gap-2"
          >
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Header Card with Link Bank, Add Card, Add Crypto Wallet & High Contrast */}
      <div className="border border-neutral-700/80 bg-neutral-850/95 bg-neutral-800/90 rounded-2xl p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-5 shadow-lg">
        <div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-tight">
            My Wallet
          </h1>
          <p className="text-xs text-neutral-300 font-medium mt-1">
            Manage your linked banks, payment cards, and Web3 crypto wallets with instant settlement.
          </p>
        </div>

        {/* Action Buttons with crisp contrast & lighter styling */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5">
          {/* Link Bank Account Button */}
          <button
            type="button"
            id="wallets-link-bank-btn"
            onClick={() => setShowLinkBankModal(true)}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center gap-2 shadow-sm transition-all hover:scale-[1.02] cursor-pointer"
          >
            <Building2 className="w-4 h-4 text-neutral-950 stroke-[2.5]" />
            <span>Link Bank</span>
            {linkedBanksList.length > 0 && (
              <span className="text-[11px] px-1.5 py-0.2 rounded-md bg-neutral-950/20 text-neutral-950 font-mono font-bold">
                {linkedBanksList.length}
              </span>
            )}
          </button>

          {/* Add Card Button */}
          <button
            type="button"
            id="wallets-link-card-btn"
            onClick={() => setShowLinkCardModal(true)}
            className="px-3.5 py-2.5 rounded-xl bg-sky-400 hover:bg-sky-300 text-neutral-950 font-bold text-xs flex items-center gap-2 shadow-sm transition-all hover:scale-[1.02] cursor-pointer"
          >
            <CreditCard className="w-4 h-4 text-neutral-950 stroke-[2.5]" />
            <span>Add Card</span>
            {linkedCardsList.length > 0 && (
              <span className="text-[11px] px-1.5 py-0.2 rounded-md bg-neutral-950/20 text-neutral-950 font-mono font-bold">
                {linkedCardsList.length}
              </span>
            )}
          </button>

          {/* Link Stablecoin / Currency Wallet Button */}
          <button
            type="button"
            id="wallets-link-stablecoin-btn"
            onClick={() => {
              setSelectedCryptoCategory('Stablecoins & Currencies');
              setShowConnectCryptoModal(true);
            }}
            className="px-3.5 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-neutral-950 font-bold text-xs flex items-center gap-2 shadow-sm transition-all hover:scale-[1.02] cursor-pointer"
          >
            <Coins className="w-4 h-4 text-neutral-950 stroke-[2.5]" />
            <span>Link Stablecoin Wallet</span>
          </button>

          {/* Link Crypto Wallet Button */}
          <button
            type="button"
            id="wallets-link-crypto-btn"
            onClick={() => {
              setSelectedCryptoCategory('EVM Wallets');
              setShowConnectCryptoModal(true);
            }}
            className="px-3.5 py-2.5 rounded-xl bg-purple-400 hover:bg-purple-300 text-neutral-950 font-bold text-xs flex items-center gap-2 shadow-sm transition-all hover:scale-[1.02] cursor-pointer"
          >
            <Wallet className="w-4 h-4 text-neutral-950 stroke-[2.5]" />
            <span>Link Crypto Wallet</span>
            {linkedCryptoList.length > 0 && (
              <span className="text-[11px] px-1.5 py-0.2 rounded-md bg-neutral-950/20 text-neutral-950 font-mono font-bold">
                {linkedCryptoList.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Section Navigation Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-3 overflow-x-auto scrollbar-none">
        <button
          type="button"
          onClick={() => setActiveSection('fiat')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === 'fiat'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
              : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
          }`}
        >
          <Building2 className="w-4 h-4 text-emerald-400" />
          <span>Fiat &amp; Bank Accounts ({linkedBanksList.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('stable_coins')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === 'stable_coins'
              ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40 shadow-sm'
              : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
          }`}
        >
          <Coins className="w-4 h-4 text-teal-400" />
          <span>Stablecoin &amp; Currency Wallets ({walletData.stableCoins?.length || 0})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('crypto')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === 'crypto'
              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
              : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
          }`}
        >
          <Wallet className="w-4 h-4 text-purple-400" />
          <span>Crypto &amp; Web3 Wallets ({linkedCryptoList.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('barter')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeSection === 'barter'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
          }`}
        >
          <Package className="w-4 h-4 text-amber-400" />
          <span>Barter Goods &amp; Services</span>
        </button>
      </div>

      {/* ================= SECTION CONTENT: STABLECOIN & CURRENCY WALLETS ================= */}
      {activeSection === 'stable_coins' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="p-6 rounded-3xl bg-gradient-to-r from-teal-950/40 via-neutral-900 to-neutral-900 border border-teal-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-300">
                  <Coins className="w-4 h-4" />
                </div>
                <h2 className="font-serif text-lg font-bold text-white">Institutional Stablecoin &amp; Currency Reserves</h2>
              </div>
              <p className="text-xs text-neutral-300">
                Link and manage decentralized stablecoin vaults (USDC, USDT, DAI, PYUSD, EURC, USDE) with auto-compounding yields and institutional custody.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setSelectedCryptoCategory('Stablecoins & Currencies');
                setShowConnectCryptoModal(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-neutral-950 font-bold text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Link Stablecoin Wallet</span>
            </button>
          </div>

          {/* Stablecoins Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(walletData.stableCoins || []).map((coin) => (
              <div 
                key={coin.id}
                className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-teal-500/40 transition-all space-y-4 shadow-md flex flex-col justify-between"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-lg">
                      {coin.symbol === 'USDC' ? '💲' : coin.symbol === 'EURC' ? '💶' : coin.symbol === 'USDT' ? '💵' : '🪙'}
                    </div>
                    <div>
                      <h3 className="font-serif text-sm font-bold text-white">{coin.name}</h3>
                      <p className="text-[11px] font-mono text-teal-400">{coin.symbol} • {coin.network}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-teal-500/20 text-teal-300 font-bold">
                    {coin.yieldAPY}% APY
                  </span>
                </div>

                <div className="space-y-1 bg-neutral-950/70 p-3 rounded-xl border border-neutral-800/80">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-neutral-400">Balance</span>
                    <span className="text-white font-bold">{coin.balance.toLocaleString()} {coin.symbol}</span>
                  </div>
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-neutral-400">USD Valuation</span>
                    <span className="text-teal-400 font-bold">${(coin.balance * coin.unitPriceUSD).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono text-neutral-500 pt-1 border-t border-neutral-800/60">
                    <span>Pegged: {coin.peggedCurrency}</span>
                    <span>1 {coin.symbol} = ${coin.unitPriceUSD} USD</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCryptoCategory('Stablecoins & Currencies');
                      setShowConnectCryptoModal(true);
                    }}
                    className="flex-1 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Link New Wallet</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      showToast(`Opening transfer bridge for ${coin.symbol}`);
                    }}
                    className="py-2 px-3 rounded-xl bg-teal-500 text-neutral-950 font-bold text-xs hover:bg-teal-400 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Linking Banner for Stablecoins */}
          <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500/20 flex items-center justify-center text-teal-400 font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Looking to connect another stablecoin issuer or currency reserve?</h4>
                <p className="text-[11px] text-neutral-400">Connect Circle, Tether, MakerDAO DAI, PayPal PYUSD, Ethena USDe, or custom smart contract vaults instantly.</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setSelectedCryptoCategory('Stablecoins & Currencies');
                setShowConnectCryptoModal(true);
              }}
              className="px-4 py-2 rounded-xl bg-teal-400 hover:bg-teal-300 text-neutral-950 font-bold text-xs whitespace-nowrap transition-all cursor-pointer"
            >
              Browse All Stablecoins
            </button>
          </div>
        </div>
      )}

      {/* ================= SECTION CONTENT: FIAT & BANK ACCOUNTS ================= */}
      {activeSection === 'fiat' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Banks Panel */}
            <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-md">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-serif text-base font-bold text-white">Linked Bank Accounts</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowLinkBankModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[3]" />
                  <span>Link Bank</span>
                </button>
              </div>

              {linkedBanksList.length === 0 ? (
                <div className="p-8 text-center rounded-2xl border border-dashed border-neutral-800 bg-neutral-950/50 space-y-2">
                  <Building2 className="w-8 h-8 text-neutral-600 mx-auto" />
                  <p className="text-xs text-neutral-400 font-medium">No bank accounts linked yet.</p>
                  <button
                    type="button"
                    onClick={() => setShowLinkBankModal(true)}
                    className="text-xs text-emerald-400 font-bold hover:underline"
                  >
                    Connect your bank via Plaid / FedNow
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {linkedBanksList.map((bank) => (
                    <div key={bank.id} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold">
                          🏛️
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-xs font-bold text-white">{bank.bankName}</h4>
                            {bank.isDefault && (
                              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">Default</span>
                            )}
                          </div>
                          <p className="text-[11px] font-mono text-neutral-400">{bank.accountType} • ••••{bank.accountNumberLast4} ({bank.currency})</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setShowBankDepositModal(bank)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold text-xs cursor-pointer"
                        >
                          Deposit
                        </button>
                        <button
                          type="button"
                          onClick={() => handleUnlinkBank(bank.id)}
                          className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400 hover:bg-neutral-900 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Cards Panel */}
            <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-md">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-sky-400" />
                  <h3 className="font-serif text-base font-bold text-white">Linked Cards</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowLinkCardModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-sky-400 hover:bg-sky-300 text-neutral-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[3]" />
                  <span>Add Card</span>
                </button>
              </div>

              {linkedCardsList.length === 0 ? (
                <div className="p-8 text-center rounded-2xl border border-dashed border-neutral-800 bg-neutral-950/50 space-y-2">
                  <CreditCard className="w-8 h-8 text-neutral-600 mx-auto" />
                  <p className="text-xs text-neutral-400 font-medium">No cards linked yet.</p>
                  <button
                    type="button"
                    onClick={() => setShowLinkCardModal(true)}
                    className="text-xs text-sky-400 font-bold hover:underline"
                  >
                    Link a debit or credit card
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {linkedCardsList.map((card) => (
                    <div key={card.id} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400 font-bold uppercase text-xs font-mono">
                          {card.brand.slice(0, 3)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-xs font-bold text-white uppercase">{card.brand} •••• {card.cardNumberLast4}</h4>
                            {card.isDefault && (
                              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-bold">Default</span>
                            )}
                          </div>
                          <p className="text-[11px] font-mono text-neutral-400">{card.cardType.toUpperCase()} • Exp {card.expiryMonth}/{card.expiryYear}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setShowCardTopUpModal(card)}
                          className="px-3 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 font-bold text-xs cursor-pointer"
                        >
                          Top-Up
                        </button>
                        <button
                          type="button"
                          onClick={() => handleUnlinkCard(card.id)}
                          className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400 hover:bg-neutral-900 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Fiat Balances Grid */}
          <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
            <h3 className="font-serif text-base font-bold text-white">Fiat Currency Treasuries</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {walletData.fiatCurrencies.map((fiat) => (
                <div key={fiat.id} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-mono font-bold text-emerald-400">{fiat.code} ({fiat.symbol})</span>
                    <span className="text-[10px] text-neutral-400">{fiat.institution}</span>
                  </div>
                  <p className="text-lg font-mono font-bold text-white">{fiat.symbol}{fiat.balance.toLocaleString()}</p>
                  <p className="text-[10px] text-neutral-500">{fiat.accountType}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================= SECTION CONTENT: CRYPTO & WEB3 WALLETS ================= */}
      {activeSection === 'crypto' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-950/40 via-neutral-900 to-neutral-900 border border-purple-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                  <Wallet className="w-4 h-4" />
                </div>
                <h2 className="font-serif text-lg font-bold text-white">Connected Web3 &amp; Crypto Wallets</h2>
              </div>
              <p className="text-xs text-neutral-300">
                Manage MetaMask, Phantom, Coinbase Smart Wallet, Ledger, and multi-sig escrow addresses for decentralized settlement.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setSelectedCryptoCategory('EVM Wallets');
                setShowConnectCryptoModal(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-purple-400 hover:bg-purple-300 text-neutral-950 font-bold text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Link Crypto Wallet</span>
            </button>
          </div>

          {linkedCryptoList.length === 0 ? (
            <div className="p-12 text-center rounded-3xl border border-dashed border-neutral-800 bg-neutral-900/50 space-y-3">
              <Wallet className="w-10 h-10 text-neutral-600 mx-auto" />
              <h3 className="text-sm font-bold text-white">No Crypto Wallets Connected</h3>
              <p className="text-xs text-neutral-400 max-w-sm mx-auto">Connect your EVM, Solana, Bitcoin or hardware vault to begin multi-chain transactions.</p>
              <button
                type="button"
                onClick={() => {
                  setSelectedCryptoCategory('EVM Wallets');
                  setShowConnectCryptoModal(true);
                }}
                className="px-4 py-2.5 rounded-xl bg-purple-500 text-white font-bold text-xs hover:bg-purple-400 transition-colors inline-flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Connect First Wallet</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {linkedCryptoList.map((cw) => (
                <div key={cw.id} className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-purple-500/40 transition-all space-y-4 shadow-md flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 font-bold">
                        {cw.network === 'Solana' ? '👻' : cw.network === 'Bitcoin' ? '₿' : '🦊'}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-serif text-sm font-bold text-white">{cw.walletName}</h4>
                          {cw.isPrimary && (
                            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">Primary</span>
                          )}
                        </div>
                        <p className="text-[11px] font-mono text-purple-400">{cw.network} {cw.ensOrDomain ? `• ${cw.ensOrDomain}` : ''}</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-white">${(cw.balanceUSD || 0).toLocaleString()} USD</span>
                  </div>

                  <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs font-mono">
                    <span className="text-neutral-400 truncate max-w-[220px]">{cw.address}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(cw.address, cw.id)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                      title="Copy Address"
                    >
                      {copiedId === cw.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    {!cw.isPrimary && (
                      <button
                        type="button"
                        onClick={() => handleSetPrimaryCryptoWallet(cw.id)}
                        className="text-[11px] text-purple-400 hover:underline font-semibold"
                      >
                        Set as Primary
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setShowCryptoDepositModal(cw)}
                      className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 font-bold text-xs"
                    >
                      Deposit / Bridge
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUnlinkCryptoWallet(cw.id)}
                      className="text-[11px] text-neutral-500 hover:text-rose-400 font-semibold"
                    >
                      Disconnect
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ================= SECTION CONTENT: BARTER INVENTORY ================= */}
      {activeSection === 'barter' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/40 via-neutral-900 to-neutral-900 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
                  <Package className="w-4 h-4" />
                </div>
                <h2 className="font-serif text-lg font-bold text-white">Barter Goods &amp; Service Capacity</h2>
              </div>
              <p className="text-xs text-neutral-300">
                List physical bullion, luxury assets, and professional service hours for direct sovereign barter proposals and multi-party trade settlement.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowAddGoodModal(true)}
                className="px-3.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Add Physical Good</span>
              </button>
              <button
                type="button"
                onClick={() => setShowAddServiceModal(true)}
                className="px-3.5 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-xs border border-amber-500/40 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Add Service Capacity</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Goods List */}
            <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
              <h3 className="font-serif text-base font-bold text-white">Physical Goods &amp; Assets ({walletData.barterGoods.length})</h3>
              {walletData.barterGoods.length === 0 ? (
                <p className="text-xs text-neutral-400 py-6 text-center">No physical goods added for barter.</p>
              ) : (
                <div className="space-y-3">
                  {walletData.barterGoods.map((good) => (
                    <div key={good.id} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-white">{good.name}</h4>
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">{good.category}</span>
                        </div>
                        <p className="text-[11px] font-mono text-neutral-400">Qty: {good.quantity} {good.unitLabel} • Est. ${good.estimatedUnitValue.toLocaleString()} / unit</p>
                        {good.location && <p className="text-[10px] text-neutral-500">Location: {good.location}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        {onInitiateBarterProposal && (
                          <button
                            type="button"
                            onClick={() => onInitiateBarterProposal(good)}
                            className="px-3 py-1.5 rounded-xl bg-amber-500 text-black font-bold text-xs hover:bg-amber-400 transition-colors"
                          >
                            Propose Trade
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDeleteGood(good.id)}
                          className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Services List */}
            <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
              <h3 className="font-serif text-base font-bold text-white">Service Capacity &amp; Hours ({walletData.barterServices.length})</h3>
              {walletData.barterServices.length === 0 ? (
                <p className="text-xs text-neutral-400 py-6 text-center">No service capacities added.</p>
              ) : (
                <div className="space-y-3">
                  {walletData.barterServices.map((service) => (
                    <div key={service.id} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-white">{service.name}</h4>
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">{service.category}</span>
                        </div>
                        <p className="text-[11px] font-mono text-neutral-400">{service.availableUnits} {service.unitType} available • ${service.hourlyRateValue}/hr</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {onInitiateBarterProposal && (
                          <button
                            type="button"
                            onClick={() => onInitiateBarterProposal(service)}
                            className="px-3 py-1.5 rounded-xl bg-amber-500 text-black font-bold text-xs hover:bg-amber-400 transition-colors"
                          >
                            Propose Trade
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDeleteService(service.id)}
                          className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: LINK FIAT CARD (CREDIT OR DEBIT) ================= */}
      {showLinkCardModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 w-full max-w-md text-white space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-sky-400" />
                <h3 className="font-serif text-lg font-bold">Link Debit or Credit Card</h3>
              </div>
              <button 
                onClick={() => setShowLinkCardModal(false)} 
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Live Interactive Card Preview */}
            <div className="p-4 rounded-2xl bg-gradient-to-tr from-slate-900 via-neutral-900 to-sky-950 border border-sky-500/30 text-white shadow-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-sky-300 font-bold">
                  {cardBankName || 'SOVEREIGN RESERVE BANK'}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-200 uppercase font-semibold">
                  {cardType.toUpperCase()}
                </span>
              </div>

              <div className="flex items-center gap-2 my-2">
                <div className="w-8 h-5 rounded bg-amber-300/80 border border-amber-400" />
                <span className="font-mono text-sm tracking-widest text-white">
                  {cardNumber || '•••• •••• •••• ••••'}
                </span>
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-neutral-300 pt-1">
                <div>
                  <span className="text-[8px] uppercase text-neutral-400 block">Name</span>
                  <span className="font-bold truncate max-w-[140px] block">{cardholderName || 'CARDHOLDER NAME'}</span>
                </div>
                <div className="text-right">
                  <span className="text-[8px] uppercase text-neutral-400 block">Expires</span>
                  <span className="font-bold">{cardExpMonth}/{cardExpYear}</span>
                </div>
                <div className="text-right font-serif font-black text-xs uppercase text-white">
                  {cardBrand.toUpperCase()}
                </div>
              </div>
            </div>

            <form onSubmit={handleLinkCard} className="space-y-3 text-xs">
              {/* Card Type Switcher */}
              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Card Classification</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCardType('debit')}
                    className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                      cardType === 'debit'
                        ? 'bg-sky-500/20 border-sky-500 text-sky-300'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    Debit Card (Checking)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCardType('credit')}
                    className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                      cardType === 'credit'
                        ? 'bg-sky-500/20 border-sky-500 text-sky-300'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    Credit Card (Revolving)
                  </button>
                </div>
              </div>

              {/* Cardholder Name */}
              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Cardholder Name (as on card)</label>
                <input
                  type="text"
                  required
                  value={cardholderName}
                  onChange={(e) => setCardholderName(e.target.value)}
                  placeholder="e.g. ALEXANDER STERLING"
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Card Number */}
              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Card Number</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    placeholder="4111 2222 3333 4444"
                    maxLength={19}
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-sky-500"
                  />
                  <span className="absolute right-3 top-2.5 text-[10px] font-mono uppercase text-sky-400 font-bold">
                    {cardBrand}
                  </span>
                </div>
              </div>

              {/* Expiry & CVV */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Exp Month</label>
                  <select
                    value={cardExpMonth}
                    onChange={(e) => setCardExpMonth(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-sky-500"
                  >
                    {Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0')).map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Exp Year</label>
                  <select
                    value={cardExpYear}
                    onChange={(e) => setCardExpYear(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-sky-500"
                  >
                    {['26', '27', '28', '29', '30', '31', '32', '33', '34', '35'].map(y => (
                      <option key={y} value={y}>20{y}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">CVV / CVC</label>
                  <input
                    type="password"
                    maxLength={4}
                    value={cardCvv}
                    onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                    placeholder="•••"
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono text-center focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              {/* Bank Name & Billing Zip */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Issuing Bank</label>
                  <input
                    type="text"
                    value={cardBankName}
                    onChange={(e) => setCardBankName(e.target.value)}
                    placeholder="e.g. JPMorgan Chase"
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Billing Zip / Postal</label>
                  <input
                    type="text"
                    value={cardBillingZip}
                    onChange={(e) => setCardBillingZip(e.target.value)}
                    placeholder="10005"
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              {/* Default Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="card-default-check"
                  checked={cardIsDefault}
                  onChange={(e) => setCardIsDefault(e.target.checked)}
                  className="rounded border-neutral-700 text-sky-500 focus:ring-sky-500"
                />
                <label htmlFor="card-default-check" className="text-[11px] text-neutral-300 cursor-pointer">
                  Set as default card for instant fiat top-ups and trade settlement
                </label>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-sky-500 text-black font-bold text-xs hover:bg-sky-400 transition-colors shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Link &amp; Secure Card</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CONNECT BANK ACCOUNT ================= */}
      {showLinkBankModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 w-full max-w-lg text-white space-y-4 shadow-2xl animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-400" />
                <h3 className="font-serif text-lg font-bold">Connect Bank Account (Fiat)</h3>
              </div>
              <button 
                onClick={() => setShowLinkBankModal(false)} 
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              Link your commercial, checking, or depository escrow bank account for instant FedNow transfers, SEPA instant clearing, and multi-currency fiat settlements.
            </p>

            {/* Instant Bank Integration Options with Live Search Lookup */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-neutral-300 font-bold tracking-wider block">
                  Search Your Bank (FedNow / Open Banking / Plaid / SEPA)
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">10,000+ Institutions</span>
              </div>

              {/* Bank Search Input */}
              <div className="relative">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={bankSearchQuery}
                  onChange={(e) => setBankSearchQuery(e.target.value)}
                  placeholder="Search by bank name (e.g. Citi, Schwab, Capital One, HSBC, Credit Union...)"
                  className="w-full pl-9 pr-8 py-2 rounded-xl bg-neutral-950 border border-neutral-700 text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-emerald-400"
                />
                {bankSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setBankSearchQuery('')}
                    className="absolute right-2.5 top-2.5 text-neutral-400 hover:text-white p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Category Quick Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
                {(['All', 'US Major', 'European', 'Global / Private', 'Credit Unions'] as const).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedBankCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors cursor-pointer ${
                      selectedBankCategory === cat
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                        : 'bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Filtered Bank List Grid */}
              {(() => {
                const ALL_BANKS = [
                  { name: 'JPMorgan Chase', logo: '🏛️', sub: 'FedNow Instant', cat: 'US Major', routing: '021000021' },
                  { name: 'Bank of America', logo: '🏦', sub: 'Instant ACH', cat: 'US Major', routing: '026009593' },
                  { name: 'Wells Fargo', logo: '🏢', sub: 'Instant Wire & ACH', cat: 'US Major', routing: '12100024' },
                  { name: 'Citigroup / Citibank', logo: '🌐', sub: 'FedNow / Global', cat: 'US Major', routing: '021000089' },
                  { name: 'Charles Schwab Bank', logo: '📈', sub: 'Instant Clearing', cat: 'US Major', routing: '121202211' },
                  { name: 'Capital One', logo: '💳', sub: 'Instant ACH', cat: 'US Major', routing: '051405515' },
                  { name: 'Goldman Sachs Bank', logo: '🛡️', sub: 'Treasury / Marcus', cat: 'US Major', routing: '026014229' },
                  { name: 'Morgan Stanley Private Bank', logo: '👔', sub: 'Private Reserve', cat: 'US Major', routing: '021000018' },
                  { name: 'PNC Bank', logo: '🏧', sub: 'Instant FedNow', cat: 'US Major', routing: '043000096' },
                  { name: 'U.S. Bank', logo: '🇺🇸', sub: 'RTP Instant', cat: 'US Major', routing: '091000022' },
                  { name: 'TD Bank', logo: '🟢', sub: 'Cross-Border Instant', cat: 'US Major', routing: '011103093' },
                  { name: 'Truist Bank', logo: '🟣', sub: 'Instant ACH', cat: 'US Major', routing: '061000104' },
                  { name: 'UBS Switzerland', logo: '🇨🇭', sub: 'SIC / SEPA Instant', cat: 'European', routing: 'UBSWCHZH' },
                  { name: 'Barclays UK', logo: '🇬🇧', sub: 'Faster Payments', cat: 'European', routing: 'BARCGB22' },
                  { name: 'Deutsche Bank', logo: '🇩🇪', sub: 'SEPA Real-Time', cat: 'European', routing: 'DEUTDEDD' },
                  { name: 'BNP Paribas', logo: '🇫🇷', sub: 'SEPA Instant Credit', cat: 'European', routing: 'BNPAFRPP' },
                  { name: 'HSBC Holdings', logo: '🔴', sub: 'Global Premier', cat: 'Global / Private', routing: 'HSBCUS33' },
                  { name: 'Santander Bank', logo: '🇪🇸', sub: 'SEPA / Multi-Currency', cat: 'European', routing: 'BSCHESMM' },
                  { name: 'Credit Suisse / UBS', logo: '💼', sub: 'Swiss Depository', cat: 'European', routing: 'CRESCHZZ' },
                  { name: 'Standard Chartered', logo: '🌏', sub: 'Cross-Border Clearing', cat: 'Global / Private', routing: 'SCBLUS33' },
                  { name: 'Bank of Montreal (BMO)', logo: '🍁', sub: 'EFT / Interac Instant', cat: 'Global / Private', routing: 'BOFMCAT2' },
                  { name: 'Royal Bank of Canada (RBC)', logo: '🦁', sub: 'EFT / Wire Instant', cat: 'Global / Private', routing: 'ROYCCAT2' },
                  { name: 'Navy Federal Credit Union', logo: '⚓', sub: 'RTP Direct', cat: 'Credit Unions', routing: '256074974' },
                  { name: 'State Employees CU (SECU)', logo: '🌲', sub: 'ACH Direct', cat: 'Credit Unions', routing: '253177028' },
                  { name: 'First Republic (JP Morgan)', logo: '🦅', sub: 'Private Escrow', cat: 'US Major', routing: '321081669' },
                  { name: 'Silicon Valley Bank (First Citizens)', logo: '💡', sub: 'Venture / Treasury', cat: 'US Major', routing: '121140399' },
                  { name: 'Revolut Business / Personal', logo: '⚡', sub: 'Instant Multi-IBAN', cat: 'Global / Private', routing: 'REVOGB21' },
                  { name: 'Wise (TransferWise)', logo: '🚀', sub: 'Global ACH & SEPA', cat: 'Global / Private', routing: 'TRWIGB2L' },
                  { name: 'Interactive Brokers Cash Mgmt', logo: '📊', sub: 'Institutional Wire', cat: 'US Major', routing: '026013673' },
                  { name: 'Fidelity Cash Management', logo: '🌿', sub: 'Treasury Clearing', cat: 'US Major', routing: '101205681' },
                ];

                const q = bankSearchQuery.trim().toLowerCase();
                const filtered = ALL_BANKS.filter(b => {
                  const matchCat = selectedBankCategory === 'All' || b.cat === selectedBankCategory;
                  const matchQuery = !q || b.name.toLowerCase().includes(q) || b.sub.toLowerCase().includes(q) || b.cat.toLowerCase().includes(q);
                  return matchCat && matchQuery;
                });

                if (filtered.length === 0) {
                  return (
                    <div className="p-4 rounded-xl border border-dashed border-neutral-700 bg-neutral-950/60 text-center space-y-2">
                      <p className="text-xs text-white font-medium">"{bankSearchQuery}" not found in instant direct listing.</p>
                      <p className="text-[11px] text-neutral-400">
                        You can connect <strong>{bankSearchQuery}</strong> instantly below using the standard routing and account form.
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setBankInstitution(bankSearchQuery);
                          setBankSearchQuery('');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black text-xs font-bold hover:bg-emerald-400 transition-colors"
                      >
                        Auto-fill "{bankSearchQuery}" into Form Below
                      </button>
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-56 overflow-y-auto pr-1 scrollbar-thin">
                    {filtered.map((b) => (
                      <button
                        key={b.name}
                        type="button"
                        disabled={isLinkingBankPlaid}
                        onClick={() => handleLinkBank(undefined, b.name)}
                        className="p-2.5 rounded-xl border border-neutral-800 bg-neutral-950/80 hover:border-emerald-500/60 hover:bg-emerald-950/30 text-left transition-all group cursor-pointer"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-base">{b.logo}</span>
                          <span className="text-[9px] font-mono text-emerald-400 group-hover:underline font-bold">Connect</span>
                        </div>
                        <p className="text-xs font-bold text-white mt-1 truncate" title={b.name}>{b.name}</p>
                        <p className="text-[10px] text-neutral-400 truncate">{b.sub}</p>
                      </button>
                    ))}
                  </div>
                );
              })()}
            </div>

            <div className="flex items-center gap-3 my-2">
              <div className="h-px bg-neutral-800 flex-1" />
              <span className="text-[10px] font-mono uppercase text-neutral-500">Or Manual ACH / Routing Form</span>
              <div className="h-px bg-neutral-800 flex-1" />
            </div>

            <form onSubmit={(e) => handleLinkBank(e)} className="space-y-3 text-xs">
              {/* Account Type */}
              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Account Classification</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Checking', 'Savings', 'Business Treasury', 'Escrow Deposit'] as const).map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setBankAccountType(type)}
                      className={`py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all ${
                        bankAccountType === type
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                          : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Account Holder Name & Bank Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Account Holder Full Legal Name</label>
                  <input
                    type="text"
                    required
                    value={bankAccountHolder}
                    onChange={(e) => setBankAccountHolder(e.target.value)}
                    placeholder="e.g. Alexander Sterling"
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Banking Institution</label>
                  <input
                    type="text"
                    required
                    value={bankInstitution}
                    onChange={(e) => setBankInstitution(e.target.value)}
                    placeholder="e.g. JPMorgan Chase & Co."
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Routing & Account Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Routing Number (ABA / Sort Code)</label>
                  <input
                    type="text"
                    required
                    value={bankRoutingNumber}
                    onChange={(e) => setBankRoutingNumber(e.target.value)}
                    placeholder="9-digit routing"
                    maxLength={12}
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Account Number</label>
                  <input
                    type="text"
                    required
                    value={bankAccountNumber}
                    onChange={(e) => setBankAccountNumber(e.target.value.replace(/\s/g, ''))}
                    placeholder="e.g. 9840219482"
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Currency & SWIFT / BIC */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Denomination</label>
                  <select
                    value={bankCurrency}
                    onChange={(e) => setBankCurrency(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-emerald-500"
                  >
                    {['USD', 'EUR', 'GBP', 'CHF', 'CAD', 'AUD', 'JPY'].map(curr => (
                      <option key={curr} value={curr}>{curr}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">Country / Jurisdiction</label>
                  <input
                    type="text"
                    value={bankCountry}
                    onChange={(e) => setBankCountry(e.target.value)}
                    placeholder="United States"
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1 font-semibold">SWIFT / BIC (Optional)</label>
                  <input
                    type="text"
                    value={bankSwiftBic}
                    onChange={(e) => setBankSwiftBic(e.target.value.toUpperCase())}
                    placeholder="CHASUS33"
                    className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Primary / Default Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="bank-default-check"
                  checked={bankIsDefault}
                  onChange={(e) => setBankIsDefault(e.target.checked)}
                  className="rounded border-neutral-700 text-emerald-500 focus:ring-emerald-500"
                />
                <label htmlFor="bank-default-check" className="text-[11px] text-neutral-300 cursor-pointer">
                  Set as primary bank account for sovereign fiat wires &amp; settlements
                </label>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLinkingBankPlaid}
                  className="w-full py-3 rounded-xl bg-emerald-500 text-black font-bold text-xs hover:bg-emerald-400 transition-colors shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Link &amp; Authorize Bank Account</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: DEPOSIT FROM LINKED BANK ACCOUNT ================= */}
      {showBankDepositModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 w-full max-w-md text-white space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-400" />
                <h3 className="font-serif text-lg font-bold">Transfer / Wire from Bank</h3>
              </div>
              <button 
                onClick={() => setShowBankDepositModal(null)} 
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Source Bank Info */}
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs font-mono">
              <div>
                <span className="text-[10px] text-neutral-500 uppercase block">Source Account</span>
                <span className="text-white font-bold">{showBankDepositModal.bankName} (•••• {showBankDepositModal.accountNumberLast4})</span>
                <span className="text-[10px] text-emerald-400 block">{showBankDepositModal.accountType} • {showBankDepositModal.status}</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-neutral-500 uppercase block">Available Balance</span>
                <span className="text-emerald-400 font-bold">${(showBankDepositModal.balanceUSD || 0).toLocaleString()} USD</span>
              </div>
            </div>

            <form onSubmit={handleExecuteBankDeposit} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Target Treasury Currency</label>
                <select
                  value={bankDepositTargetCurrency}
                  onChange={(e) => setBankDepositTargetCurrency(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-emerald-500"
                >
                  {walletData.fiatCurrencies.map(f => (
                    <option key={f.code} value={f.code}>
                      {f.code} ({f.symbol}) - {f.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Transfer Valuation (USD)</label>
                <input
                  type="number"
                  min="100"
                  step="100"
                  required
                  value={bankDepositAmountUSD}
                  onChange={(e) => setBankDepositAmountUSD(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono text-base font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Quick Amount Buttons */}
              <div className="grid grid-cols-4 gap-2">
                {[1000, 5000, 25000, 50000].map(amt => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setBankDepositAmountUSD(amt)}
                    className="py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-mono font-semibold"
                  >
                    +${amt.toLocaleString()}
                  </button>
                ))}
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-emerald-500 text-black font-bold text-xs hover:bg-emerald-400 transition-colors shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>Execute Clearing &amp; Deposit ${bankDepositAmountUSD.toLocaleString()} USD</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CONNECT CRYPTO WALLET ================= */}
      {showConnectCryptoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 w-full max-w-xl text-white space-y-4 shadow-2xl animate-in fade-in zoom-in-95 max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 font-bold">
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold">Connect Cryptocurrency / Web3 Wallet</h3>
                  <p className="text-[11px] text-neutral-400">Escrow settlement, multi-sig signers &amp; native token reserves</p>
                </div>
              </div>
              <button 
                onClick={() => setShowConnectCryptoModal(false)} 
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Live Search & Filter Bar */}
            <div className="space-y-2.5 shrink-0">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-neutral-300 font-bold tracking-wider block">
                  Search Coin, Token, Blockchain or Web3 Wallet
                </span>
                <span className="text-[10px] text-purple-400 font-mono">40+ Cryptocurrencies &amp; Providers</span>
              </div>

              {/* Crypto Search Input */}
              <div className="relative">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={cryptoSearchQuery}
                  onChange={(e) => setCryptoSearchQuery(e.target.value)}
                  placeholder="Search by coin or wallet (e.g. Bitcoin, Solana, XRP, Cardano, USDT, Rabby, Keplr, Sui, AVAX, DOGE...)"
                  className="w-full pl-9 pr-8 py-2 rounded-xl bg-neutral-950 border border-neutral-700 text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-purple-400"
                />
                {cryptoSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setCryptoSearchQuery('')}
                    className="absolute right-2.5 top-2.5 text-neutral-400 hover:text-white p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Category Quick Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
                {(['All', 'Stablecoins & Currencies', 'Crypto & Web3 Wallets', 'EVM Wallets', 'Solana & SVM', 'Hardware & Vaults', 'Layer 2 & Cosmos'] as const).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCryptoCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors cursor-pointer ${
                      selectedCryptoCategory === cat
                        ? 'bg-purple-500/25 text-purple-300 border border-purple-500/40 font-bold'
                        : 'bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Filtered Crypto & Wallet List Grid */}
            <div className="overflow-y-auto pr-1 scrollbar-thin flex-1 max-h-64">
              {(() => {
                const ALL_CRYPTO_ITEMS = [
                  // Dedicated Stablecoins & Digital Currency Wallets
                  { name: 'Circle USDC Treasury', symbol: 'USDC', cat: 'Stablecoins & Currencies', network: 'Ethereum', logo: '💲', sub: 'Circle Institutional Reserve', type: 'crypto' as const },
                  { name: 'Tether USDT Web3 Vault', symbol: 'USDT', cat: 'Stablecoins & Currencies', network: 'Multi-Chain', logo: '💵', sub: 'Tether Treasury Escrow', type: 'crypto' as const },
                  { name: 'DAI MakerDAO Reserve', symbol: 'DAI', cat: 'Stablecoins & Currencies', network: 'Ethereum', logo: '◈', sub: 'MakerDAO Over-Collateralized', type: 'crypto' as const },
                  { name: 'PayPal Digital Currency', symbol: 'PYUSD', cat: 'Stablecoins & Currencies', network: 'Ethereum', logo: '🅿️', sub: 'PayPal USD Stablecoin', type: 'crypto' as const },
                  { name: 'Paxos Treasury Vault', symbol: 'USDP', cat: 'Stablecoins & Currencies', network: 'Ethereum', logo: '🛡️', sub: 'Paxos Regulated Trust', type: 'crypto' as const },
                  { name: 'Circle EURC Euro Wallet', symbol: 'EURC', cat: 'Stablecoins & Currencies', network: 'Ethereum', logo: '💶', sub: 'Euro Backed Stablecoin', type: 'crypto' as const },
                  { name: 'Ethena USDe Synthetic Dollar', symbol: 'USDE', cat: 'Stablecoins & Currencies', network: 'Ethereum', logo: '⚡', sub: 'Delta-Neutral Synthetic Dollar', type: 'crypto' as const },
                  { name: 'First Digital USD Vault', symbol: 'FDUSD', cat: 'Stablecoins & Currencies', network: 'Multi-Chain', logo: '🌐', sub: 'FD121 Reserve Escrow', type: 'crypto' as const },
                  { name: 'Gemini Dollar Vault', symbol: 'GUSD', cat: 'Stablecoins & Currencies', network: 'Ethereum', logo: '♊', sub: 'NYDFS Regulated Escrow', type: 'crypto' as const },

                  // Major Cryptocurrencies
                  { name: 'Bitcoin', symbol: 'BTC', cat: 'Crypto & Web3 Wallets', network: 'Bitcoin', logo: '₿', sub: 'Taproot / SegWit Reserve', type: 'crypto' as const },
                  { name: 'Ethereum', symbol: 'ETH', cat: 'Crypto & Web3 Wallets', network: 'Ethereum', logo: '⟠', sub: 'EVM Smart Contracts', type: 'crypto' as const },
                  { name: 'Solana', symbol: 'SOL', cat: 'Crypto & Web3 Wallets', network: 'Solana', logo: '🟣', sub: 'SVM High Throughput', type: 'crypto' as const },
                  { name: 'Ripple', symbol: 'XRP', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: '✕', sub: 'XRPL Institutional Liquidity', type: 'crypto' as const },
                  { name: 'Cardano', symbol: 'ADA', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: '₳', sub: 'PoS Formal Verification', type: 'crypto' as const },
                  { name: 'Avalanche', symbol: 'AVAX', cat: 'Crypto & Web3 Wallets', network: 'Ethereum', logo: '🔺', sub: 'Avalanche C-Chain', type: 'crypto' as const },
                  { name: 'Binance Coin', symbol: 'BNB', cat: 'Crypto & Web3 Wallets', network: 'Ethereum', logo: '🟡', sub: 'BNB Smart Chain', type: 'crypto' as const },
                  { name: 'Toncoin', symbol: 'TON', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: '💎', sub: 'The Open Network (Telegram)', type: 'crypto' as const },
                  { name: 'Sui', symbol: 'SUI', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: '💧', sub: 'Move VM Object Execution', type: 'crypto' as const },
                  { name: 'Chainlink', symbol: 'LINK', cat: 'Crypto & Web3 Wallets', network: 'Ethereum', logo: '⬡', sub: 'Oracle CCIP Cross-Chain', type: 'crypto' as const },
                  { name: 'Polkadot', symbol: 'DOT', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: '🔴', sub: 'Substrate Relay Chain', type: 'crypto' as const },
                  { name: 'Polygon', symbol: 'POL', cat: 'Crypto & Web3 Wallets', network: 'Polygon', logo: '💜', sub: 'AggLayer zkEVM', type: 'crypto' as const },
                  { name: 'Dogecoin', symbol: 'DOGE', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: '🐕', sub: 'Scrypt Proof-of-Work', type: 'crypto' as const },
                  { name: 'Near Protocol', symbol: 'NEAR', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: 'Ⓝ', sub: 'Nightshade Sharding', type: 'crypto' as const },
                  { name: 'Arbitrum', symbol: 'ARB', cat: 'Layer 2 & Cosmos', network: 'Arbitrum', logo: '🔵', sub: 'Nitro Rollup L2', type: 'crypto' as const },
                  { name: 'Optimism', symbol: 'OP', cat: 'Layer 2 & Cosmos', network: 'Ethereum', logo: '🔴', sub: 'OP Stack Superchain', type: 'crypto' as const },
                  { name: 'Cosmos Hub', symbol: 'ATOM', cat: 'Layer 2 & Cosmos', network: 'Multi-Chain', logo: '⚛️', sub: 'Inter-Blockchain IBC', type: 'crypto' as const },
                  { name: 'Uniswap', symbol: 'UNI', cat: 'Crypto & Web3 Wallets', network: 'Ethereum', logo: '🦄', sub: 'Decentralized Liquidity', type: 'crypto' as const },
                  { name: 'Monero', symbol: 'XMR', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: '🔒', sub: 'RingCT Private Ledger', type: 'crypto' as const },
                  { name: 'Litecoin', symbol: 'LTC', cat: 'Crypto & Web3 Wallets', network: 'Multi-Chain', logo: 'Ł', sub: 'Scrypt P2P Network', type: 'crypto' as const },

                  // Wallets & Signers
                  { name: 'MetaMask', symbol: '', cat: 'EVM Wallets', network: 'Ethereum', logo: '🦊', sub: 'EVM & Layer-2 Standard', type: 'wallet' as const },
                  { name: 'Phantom Wallet', symbol: '', cat: 'Solana & SVM', network: 'Solana', logo: '👻', sub: 'Solana, BTC & EVM Multi', type: 'wallet' as const },
                  { name: 'Coinbase Smart Wallet', symbol: '', cat: 'EVM Wallets', network: 'Base', logo: '🔵', sub: 'Base & Passkey Native', type: 'wallet' as const },
                  { name: 'Rabby Wallet', symbol: '', cat: 'EVM Wallets', network: 'Ethereum', logo: '🐰', sub: 'Anti-Drainer Security Client', type: 'wallet' as const },
                  { name: 'Rainbow Wallet', symbol: '', cat: 'EVM Wallets', network: 'Ethereum', logo: '🌈', sub: 'Visual Web3 & NFT Mobile', type: 'wallet' as const },
                  { name: 'Ledger Hardware Vault', symbol: '', cat: 'Hardware & Vaults', network: 'Bitcoin', logo: '🛡️', sub: 'Secure Element Cold Storage', type: 'wallet' as const },
                  { name: 'Trezor Hardware Safe', symbol: '', cat: 'Hardware & Vaults', network: 'Bitcoin', logo: '🔐', sub: 'Open-Source Cold Vault', type: 'wallet' as const },
                  { name: 'Safe (Gnosis Safe)', symbol: '', cat: 'Hardware & Vaults', network: 'Ethereum', logo: '🏢', sub: 'Institutional Multi-Sig Escrow', type: 'wallet' as const },
                  { name: 'Trust Wallet', symbol: '', cat: 'EVM Wallets', network: 'Multi-Chain', logo: '🛡️', sub: '70+ Blockchain Multi-Asset', type: 'wallet' as const },
                  { name: 'Keplr Wallet', symbol: '', cat: 'Layer 2 & Cosmos', network: 'Multi-Chain', logo: '🪐', sub: 'Interchain Cosmos Gateway', type: 'wallet' as const },
                  { name: 'Backpack Wallet', symbol: '', cat: 'Solana & SVM', network: 'Solana', logo: '🎒', sub: 'Solana xNFT & SVM Super App', type: 'wallet' as const },
                  { name: 'OKX Web3 Wallet', symbol: '', cat: 'EVM Wallets', network: 'Multi-Chain', logo: '⬛', sub: '80+ Chains DEX Aggregator', type: 'wallet' as const },
                  { name: 'WalletConnect Bridge', symbol: '', cat: 'EVM Wallets', network: 'Multi-Chain', logo: '🔗', sub: 'Mobile QR Handshake', type: 'wallet' as const },
                  { name: 'Custom Address / ENS', symbol: '', cat: 'EVM Wallets', network: 'Multi-Chain', logo: '⚙️', sub: 'Manual Hex, ENS, or Safe', type: 'wallet' as const },
                ];

                const q = cryptoSearchQuery.trim().toLowerCase();
                const filtered = ALL_CRYPTO_ITEMS.filter(item => {
                  const matchCat = selectedCryptoCategory === 'All' || item.cat === selectedCryptoCategory;
                  const matchQuery = !q || 
                    item.name.toLowerCase().includes(q) || 
                    item.symbol.toLowerCase().includes(q) || 
                    item.network.toLowerCase().includes(q) || 
                    item.sub.toLowerCase().includes(q);
                  return matchCat && matchQuery;
                });

                if (filtered.length === 0) {
                  return (
                    <div className="p-4 rounded-xl border border-dashed border-neutral-700 bg-neutral-950/60 text-center space-y-2">
                      <p className="text-xs text-white font-medium">"{cryptoSearchQuery}" not found in instant list.</p>
                      <p className="text-[11px] text-neutral-400">
                        You can link a custom vault for <strong>{cryptoSearchQuery}</strong> using custom address &amp; network below.
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedWalletProvider('custom');
                          setCustomWalletName(`${cryptoSearchQuery.toUpperCase()} Escrow`);
                          setCryptoSearchQuery('');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-purple-500 text-white text-xs font-bold hover:bg-purple-400 transition-colors"
                      >
                        Auto-fill "{cryptoSearchQuery}" into Custom Wallet Form
                      </button>
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {filtered.map((item) => (
                      <button
                        key={item.name + item.symbol}
                        type="button"
                        disabled={isConnectingWeb3}
                        onClick={() => {
                          if (item.name === 'Custom Address / ENS') {
                            setSelectedWalletProvider('custom');
                          } else {
                            handleConnectCryptoWallet(undefined, item);
                          }
                        }}
                        className="p-2.5 rounded-xl border border-neutral-800 bg-neutral-950/80 hover:border-purple-500/60 hover:bg-purple-950/25 text-left transition-all group cursor-pointer"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-base">{item.logo}</span>
                          <span className="text-[9px] font-mono text-purple-400 group-hover:underline font-bold">
                            {item.symbol ? `Connect ${item.symbol}` : 'Connect'}
                          </span>
                        </div>
                        <p className="text-xs font-bold text-white mt-1 truncate" title={item.name}>
                          {item.name} {item.symbol && <span className="text-neutral-400 text-[10px]">({item.symbol})</span>}
                        </p>
                        <p className="text-[10px] text-neutral-400 truncate">{item.sub}</p>
                      </button>
                    ))}
                  </div>
                );
              })()}
            </div>

            {/* Custom Address Input Option Accordion */}
            <div className="pt-2 border-t border-neutral-800 shrink-0">
              <button
                type="button"
                onClick={() => setSelectedWalletProvider(selectedWalletProvider === 'custom' ? 'metamask' : 'custom')}
                className="w-full flex items-center justify-between text-xs text-neutral-300 hover:text-white font-medium p-1.5 rounded-lg hover:bg-neutral-800/60 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-purple-400 font-mono text-sm">⚙️</span>
                  <span>Enter Custom Multi-Sig, Contract, or Cold Public Address</span>
                </div>
                <span className="text-[11px] font-mono text-neutral-500">
                  {selectedWalletProvider === 'custom' ? '▲ Hide Form' : '▼ Expand Form'}
                </span>
              </button>

              {selectedWalletProvider === 'custom' && (
                <form onSubmit={handleConnectCryptoWallet} className="space-y-2.5 text-xs pt-3 mt-1">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block text-neutral-400 mb-1 font-semibold">Wallet / Label Name</label>
                      <input
                        type="text"
                        value={customWalletName}
                        onChange={(e) => setCustomWalletName(e.target.value)}
                        placeholder="e.g. Zurich Cold Multisig"
                        className="w-full p-2 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-neutral-400 mb-1 font-semibold">Blockchain Network</label>
                      <select
                        value={customWalletNetwork}
                        onChange={(e) => setCustomWalletNetwork(e.target.value as any)}
                        className="w-full p-2 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-purple-500"
                      >
                        <option value="Ethereum">Ethereum (EVM Mainnet)</option>
                        <option value="Polygon">Polygon (PoS Network)</option>
                        <option value="Base">Base L2 (Coinbase)</option>
                        <option value="Arbitrum">Arbitrum One</option>
                        <option value="Solana">Solana (SVM)</option>
                        <option value="Bitcoin">Bitcoin (SegWit / Taproot)</option>
                        <option value="Multi-Chain">Multi-Chain Sovereign</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-neutral-400 mb-1 font-semibold">Public Address (or Multi-Sig Safe)</label>
                    <input
                      type="text"
                      required
                      value={customWalletAddress}
                      onChange={(e) => setCustomWalletAddress(e.target.value)}
                      placeholder="0x... or bc1... or Solana / Cosmos / Sui address"
                      className="w-full p-2 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-neutral-400 mb-1 font-semibold">Web3 Domain / ENS (Optional)</label>
                    <input
                      type="text"
                      value={customWalletEns}
                      onChange={(e) => setCustomWalletEns(e.target.value)}
                      placeholder="e.g. vitalik.eth or satoshi.sol"
                      className="w-full p-2 rounded-xl bg-neutral-950 border border-neutral-700 text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="checkbox"
                      id="crypto-primary-check-custom"
                      checked={cryptoWalletIsPrimary}
                      onChange={(e) => setCryptoWalletIsPrimary(e.target.checked)}
                      className="rounded border-neutral-700 text-purple-500 focus:ring-purple-500"
                    />
                    <label htmlFor="crypto-primary-check-custom" className="text-[11px] text-neutral-300 cursor-pointer">
                      Set as primary multi-sig signing wallet
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={isConnectingWeb3}
                    className="w-full py-2.5 rounded-xl bg-purple-500 text-white font-bold text-xs hover:bg-purple-400 transition-colors shadow-lg flex items-center justify-center gap-2 cursor-pointer mt-1"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Link Custom Crypto Wallet</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: INSTANT CARD TOP-UP ================= */}
      {showCardTopUpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 w-full max-w-md text-white space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-sky-400" />
                <h3 className="font-serif text-lg font-bold">Instant Card Fiat Top-Up</h3>
              </div>
              <button 
                onClick={() => setShowCardTopUpModal(null)} 
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Source Card Info */}
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs font-mono">
              <div>
                <span className="text-[10px] text-neutral-500 uppercase block">Charging Linked Card</span>
                <span className="text-white font-bold">{showCardTopUpModal.brand.toUpperCase()} {showCardTopUpModal.cardType.toUpperCase()} (•••• {showCardTopUpModal.cardNumberLast4})</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-neutral-500 uppercase block">Bank</span>
                <span className="text-sky-400 font-bold">{showCardTopUpModal.bankName}</span>
              </div>
            </div>

            <form onSubmit={handleExecuteCardTopUp} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Target Fiat Currency Account</label>
                <select
                  value={topUpTargetCurrency}
                  onChange={(e) => setTopUpTargetCurrency(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-sky-500"
                >
                  {walletData.fiatCurrencies.map(f => (
                    <option key={f.code} value={f.code}>
                      {f.code} - {f.name} (Current: {f.symbol}{f.balance.toLocaleString()})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Top-Up Amount (USD)</label>
                <input
                  type="number"
                  min="50"
                  step="50"
                  required
                  value={topUpAmountUSD}
                  onChange={(e) => setTopUpAmountUSD(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono text-base font-bold focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Quick Amount Buttons */}
              <div className="grid grid-cols-4 gap-2">
                {[500, 1000, 5000, 10000].map(amt => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setTopUpAmountUSD(amt)}
                    className="py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-mono font-semibold"
                  >
                    +${amt.toLocaleString()}
                  </button>
                ))}
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-sky-500 text-black font-bold text-xs hover:bg-sky-400 transition-colors shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>Authorize &amp; Deposit ${topUpAmountUSD.toLocaleString()} USD</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: DEPOSIT FROM CRYPTO WALLET ================= */}
      {showCryptoDepositModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 w-full max-w-md text-white space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-purple-400" />
                <h3 className="font-serif text-lg font-bold">Transfer from Crypto Wallet</h3>
              </div>
              <button 
                onClick={() => setShowCryptoDepositModal(null)} 
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Source Crypto Wallet Info */}
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs font-mono">
              <div>
                <span className="text-[10px] text-neutral-500 uppercase block">Transfer Source</span>
                <span className="text-white font-bold">{showCryptoDepositModal.walletName} ({showCryptoDepositModal.network})</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-neutral-500 uppercase block">Wallet Balance</span>
                <span className="text-purple-400 font-bold">${(showCryptoDepositModal.balanceUSD || 0).toLocaleString()} USD</span>
              </div>
            </div>

            <form onSubmit={handleExecuteCryptoDeposit} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Target Reserve Crypto Asset</label>
                <select
                  value={cryptoDepositTargetCoin}
                  onChange={(e) => setCryptoDepositTargetCoin(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono focus:outline-none focus:border-purple-500"
                >
                  {walletData.cryptoCurrencies.map(c => (
                    <option key={c.symbol} value={c.symbol}>
                      {c.symbol} - {c.name} (${c.unitPriceUSD.toLocaleString()} USD/unit)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-neutral-400 mb-1 font-semibold">Deposit Valuation (USD)</label>
                <input
                  type="number"
                  min="100"
                  step="100"
                  required
                  value={cryptoDepositAmountUSD}
                  onChange={(e) => setCryptoDepositAmountUSD(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-700 text-white font-mono text-base font-bold focus:outline-none focus:border-purple-500"
                />
              </div>

              {/* Quick Amount Buttons */}
              <div className="grid grid-cols-4 gap-2">
                {[1000, 5000, 25000, 50000].map(amt => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setCryptoDepositAmountUSD(amt)}
                    className="py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-mono font-semibold"
                  >
                    +${amt.toLocaleString()}
                  </button>
                ))}
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-purple-500 text-white font-bold text-xs hover:bg-purple-400 transition-colors shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Sign &amp; Bridge ${cryptoDepositAmountUSD.toLocaleString()} USD</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD GOOD ================= */}
      {showAddGoodModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 w-full max-w-md text-white space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
              <h3 className="font-serif text-lg font-bold">Add Physical Good to Barter Portfolio</h3>
              <button onClick={() => setShowAddGoodModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateGood} className="space-y-3 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1">Asset Name</label>
                <input
                  type="text"
                  required
                  value={goodName}
                  onChange={(e) => setGoodName(e.target.value)}
                  placeholder="e.g. 1oz Fine Gold Bullion Bar, Rolex Submariner"
                  className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={goodQuantity}
                    onChange={(e) => setGoodQuantity(Number(e.target.value))}
                    className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Unit Value (USD)</label>
                  <input
                    type="number"
                    min="1"
                    value={goodValueUSD}
                    onChange={(e) => setGoodValueUSD(Number(e.target.value))}
                    className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-neutral-400 mb-1">Vault / Depository Location</label>
                <input
                  type="text"
                  value={goodLocation}
                  onChange={(e) => setGoodLocation(e.target.value)}
                  placeholder="e.g. Zurich Freeport, London Depository"
                  className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 text-black font-bold text-xs hover:bg-amber-400 transition-colors mt-2 cursor-pointer"
              >
                Add to Portfolio
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD SERVICE ================= */}
      {showAddServiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 w-full max-w-md text-white space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
              <h3 className="font-serif text-lg font-bold">Add Service Capacity to Barter Portfolio</h3>
              <button onClick={() => setShowAddServiceModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateService} className="space-y-3 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1">Service Title</label>
                <input
                  type="text"
                  required
                  value={serviceName}
                  onChange={(e) => setServiceName(e.target.value)}
                  placeholder="e.g. Smart Contract Formal Audit, Tax Strategy"
                  className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-neutral-400 mb-1">Available Units / Hours</label>
                  <input
                    type="number"
                    min="1"
                    value={serviceUnits}
                    onChange={(e) => setServiceUnits(Number(e.target.value))}
                    className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Rate (USD / Hour)</label>
                  <input
                    type="number"
                    min="1"
                    value={serviceRateUSD}
                    onChange={(e) => setServiceRateUSD(Number(e.target.value))}
                    className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-neutral-400 mb-1">Turnaround Time</label>
                <input
                  type="text"
                  value={serviceTurnaround}
                  onChange={(e) => setServiceTurnaround(e.target.value)}
                  placeholder="e.g. 2-3 Business Days"
                  className="w-full p-2 rounded-lg bg-neutral-950 border border-neutral-700 text-white"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 text-black font-bold text-xs hover:bg-amber-400 transition-colors mt-2 cursor-pointer"
              >
                Add to Capacity
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
