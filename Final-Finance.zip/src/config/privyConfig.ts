import {
  arbitrum,
  base,
  mainnet,
  polygon,
  type Chain,
} from 'viem/chains';

export type PrivyNetworkKey =
  | 'ethereum'
  | 'base'
  | 'polygon'
  | 'arbitrum';

export interface PrivyTokenConfig {
  symbol: 'USDC' | 'USDT';
  name: string;
  decimals: number;
  address: `0x${string}` | null;
}

export interface PrivyNetworkConfig {
  key: PrivyNetworkKey;
  name: string;
  shortName: string;
  chainId: number;
  isTestnet: boolean;
  nativeSymbol: string;
  nativeName: string;
  rpcUrl: string;
  explorerUrl: string;
  faucetUrl?: string;
  chain: Chain;
  tokens: PrivyTokenConfig[];
}

export const DEFAULT_PRIVY_NETWORK_KEY: PrivyNetworkKey = 'ethereum';

export const PRIVY_NETWORKS: PrivyNetworkConfig[] = [
  {
    key: 'ethereum',
    name: 'Ethereum',
    shortName: 'Ethereum',
    chainId: 1,
    isTestnet: false,
    nativeSymbol: 'ETH',
    nativeName: 'Ether',
    rpcUrl: 'https://ethereum-rpc.publicnode.com',
    explorerUrl: 'https://etherscan.io',
    chain: mainnet,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
      },
    ],
  },
  {
    key: 'base',
    name: 'Base',
    shortName: 'Base',
    chainId: 8453,
    isTestnet: false,
    nativeSymbol: 'ETH',
    nativeName: 'Ether',
    rpcUrl: 'https://mainnet.base.org',
    explorerUrl: 'https://basescan.org',
    chain: base,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2',
      },
    ],
  },
  {
    key: 'polygon',
    name: 'Polygon',
    shortName: 'Polygon',
    chainId: 137,
    isTestnet: false,
    nativeSymbol: 'POL',
    nativeName: 'POL (Polygon)',
    rpcUrl: 'https://polygon-bor-rpc.publicnode.com',
    explorerUrl: 'https://polygonscan.com',
    chain: polygon,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
      },
    ],
  },
  {
    key: 'arbitrum',
    name: 'Arbitrum',
    shortName: 'Arbitrum',
    chainId: 42161,
    isTestnet: false,
    nativeSymbol: 'ETH',
    nativeName: 'Ether',
    rpcUrl: 'https://arbitrum-one-rpc.publicnode.com',
    explorerUrl: 'https://arbiscan.io',
    chain: arbitrum,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
      },
    ],
  },
];

export const PRIVY_SUPPORTED_CHAINS: Chain[] = PRIVY_NETWORKS.map((n) => n.chain);

export function getPrivyAppId(): string {
  const envVal = (import.meta.env?.VITE_PRIVY_APP_ID || '').trim();
  return envVal || 'cmwsldhq500pv0gjmwputn68u';
}

export function getPrivyNetworkByKey(key: string): PrivyNetworkConfig {
  if (key === 'base-sepolia') return PRIVY_NETWORKS.find((n) => n.key === 'base') || PRIVY_NETWORKS[0];
  if (key === 'sepolia') return PRIVY_NETWORKS[0];
  return PRIVY_NETWORKS.find((n) => n.key === key) || PRIVY_NETWORKS[0];
}

export function getPrivyNetworkByChainId(chainId?: number | string | null): PrivyNetworkConfig | undefined {
  if (chainId === undefined || chainId === null) return undefined;
  const numeric =
    typeof chainId === 'string' && chainId.startsWith('eip155:')
      ? Number(chainId.split(':')[1])
      : Number(chainId);
  if (!Number.isFinite(numeric)) return undefined;
  return PRIVY_NETWORKS.find((n) => n.chainId === numeric);
}
