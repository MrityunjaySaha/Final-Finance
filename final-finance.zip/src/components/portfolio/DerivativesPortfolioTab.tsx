import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Layers, 
  Clock, 
  ShieldCheck, 
  Zap, 
  Search, 
  Calendar,
  RotateCcw
} from 'lucide-react';
import { StockOrder, StockItem } from '../../types/stocks';
import { DEFAULT_INITIAL_STOCK_ORDERS } from '../../data/stocksData';

interface DerivativesPortfolioTabProps {
  userId: string;
  orders: StockOrder[];
  stocks: StockItem[];
  onSelectStock?: (stock: StockItem) => void;
  onOpenTradeModal: (tickerOrStock: string | StockItem, side: 'buy' | 'sell') => void;
  onRefreshOrders: () => void;
}

export const DerivativesPortfolioTab: React.FC<DerivativesPortfolioTabProps> = ({
  userId: _userId,
  orders,
  stocks,
  onSelectStock,
  onOpenTradeModal,
  onRefreshOrders: _onRefreshOrders,
}) => {
  const [filterType, setFilterType] = useState<'call_option' | 'put_option'>('call_option');
  const [filterMode, setFilterMode] = useState<'fiat' | 'stable_coin' | 'crypto'>('fiat');
  const [searchQuery, setSearchQuery] = useState('');

  // Stock lookup map
  const stockMap = useMemo(() => {
    const map = new Map<string, StockItem>();
    stocks.forEach((s) => map.set(s.ticker.toUpperCase(), s));
    return map;
  }, [stocks]);

  const getOrderMode = (ord: StockOrder): 'fiat' | 'crypto' | 'final_coin' | 'stable_coin' => {
    const t = ord.paymentSource?.type;
    if (t === 'wallet_final') return 'final_coin';
    if (t === 'wallet_stable') return 'stable_coin';
    if (t === 'wallet_crypto' || t === 'crypto_wallet') return 'crypto';
    return 'fiat';
  };

  // Provide initial derivative examples if no derivative orders exist
  const effectiveOrders = useMemo(() => {
    const hasDerivatives = orders.some((ord) => ord.derivativeType && ord.derivativeType !== 'spot');
    if (!hasDerivatives) {
      const defaultDerivs = DEFAULT_INITIAL_STOCK_ORDERS.filter(o => o.derivativeType && o.derivativeType !== 'spot');
      return [...orders, ...defaultDerivs];
    }
    return orders;
  }, [orders]);

  // Filter orders that are derivatives
  const derivativesOrders = useMemo(() => {
    return effectiveOrders.filter((ord) => {
      const dt = ord.derivativeType;
      if (!dt || dt === 'spot') return false;
      if (dt !== filterType) return false;
      
      const mode = getOrderMode(ord);
      if (mode !== filterMode) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().replace(/^\$/, '');
        return (
          ord.ticker.toLowerCase().includes(q) ||
          ord.stockName.toLowerCase().includes(q) ||
          (ord.tradeSlipId && ord.tradeSlipId.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [effectiveOrders, filterType, filterMode, searchQuery]);

  const getDerivativeBadge = (dt?: string) => {
    switch (dt) {
      case 'call_option':
        return {
          label: 'Call Option',
          color: 'bg-emerald-500/10 text-emerald-900 border-emerald-500/30',
          icon: TrendingUp
        };
      case 'put_option':
        return {
          label: 'Put Option',
          color: 'bg-rose-500/10 text-rose-900 border-rose-500/30',
          icon: TrendingDown
        };
      case 'futures_long':
        return {
          label: 'Futures Long',
          color: 'bg-amber-500/10 text-amber-900 border-amber-500/30',
          icon: Zap
        };
      case 'futures_short':
        return {
          label: 'Futures Short',
          color: 'bg-indigo-500/10 text-indigo-900 border-indigo-500/30',
          icon: ShieldCheck
        };
      default:
        return {
          label: 'Derivative',
          color: 'bg-slate-100 text-slate-800 border-slate-200',
          icon: Layers
        };
    }
  };

  const getModeBadge = (mode: 'fiat' | 'crypto' | 'final_coin' | 'stable_coin') => {
    switch (mode) {
      case 'final_coin':
        return { label: 'Final Coin ($FINAL)', color: 'bg-amber-100 text-amber-950 border-amber-300' };
      case 'stable_coin':
        return { label: 'Stable Coin ($USDC)', color: 'bg-teal-100 text-teal-950 border-teal-300' };
      case 'crypto':
        return { label: 'Crypto Assets', color: 'bg-indigo-100 text-indigo-950 border-indigo-300' };
      default:
        return { label: 'Fiat Currency (USD)', color: 'bg-emerald-100 text-emerald-950 border-emerald-300' };
    }
  };

  const hasActiveFilters = filterType !== 'all' || filterMode !== 'all' || searchQuery.trim() !== '';

  return (
    <div className="space-y-6 text-left animate-in fade-in duration-200">
      {/* 1. Header Banner */}
      <div className="p-6 sm:p-7 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 flex items-center gap-2.5">
                <Layers className="w-6 h-6 text-indigo-600" />
                <span>Derivatives Portfolio &amp; Modes</span>
              </h2>
              <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-900 border border-indigo-200">
                {derivativesOrders.length} {derivativesOrders.length === 1 ? 'Active Contract' : 'Active Contracts'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-200">
              <Calendar className="w-4 h-4 text-slate-400" />
              <div className="text-left">
                <span className="text-[10px] uppercase font-mono text-slate-400 block">Server Time &amp; Expiry Clock</span>
                <span className="font-mono text-xs font-bold text-slate-900">
                  {new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })} • {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="space-y-3 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400 mr-1 uppercase">Mode:</span>
            <button
              onClick={() => setFilterMode('fiat')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${filterMode === 'fiat' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700'}`}
            >
              Fiat
            </button>
            <button
              onClick={() => setFilterMode('stable_coin')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${filterMode === 'stable_coin' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700'}`}
            >
              Stable
            </button>
            <button
              onClick={() => setFilterMode('crypto')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${filterMode === 'crypto' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700'}`}
            >
              Crypto
            </button>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400 mr-1 uppercase">Type:</span>
            <button
              onClick={() => setFilterType('call_option')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${filterType === 'call_option' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-900'}`}
            >
              Call
            </button>
            <button
              onClick={() => setFilterType('put_option')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${filterType === 'put_option' ? 'bg-rose-600 text-white' : 'bg-rose-50 text-rose-900'}`}
            >
              Put
            </button>
          </div>
        </div>
      </div>

      {/* 2. Derivatives Table View */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-4">
        {/* Table Header: Title/Count on left, Search Bar moved down to directly above Asset & Contract */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <h3 className="font-serif text-base font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>Active Derivative Contracts</span>
            </h3>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
              {derivativesOrders.length} {derivativesOrders.length === 1 ? 'Contract' : 'Contracts'}
            </span>
          </div>

          {/* Search Bar directly above Asset & Contract */}
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="derivatives-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search ticker, contract, slip..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>
        </div>

        {derivativesOrders.length === 0 ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
              <Layers className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-slate-900">
                {searchQuery ? `No derivative contracts match "${searchQuery}"` : 'No derivative contracts match the selected filters'}
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Try adjusting your derivative filter or clear the search field to view all active contracts.
              </p>
            </div>
            {hasActiveFilters && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setFilterType('all');
                    setFilterMode('all');
                    setSearchQuery('');
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer shadow-xs inline-flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Filters &amp; Search</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                  <th className="py-3 px-3">Asset &amp; Contract</th>
                  <th className="py-3 px-3">Derivative &amp; Mode Combo</th>
                  <th className="py-3 px-3 text-center">Strike &amp; Leverage</th>
                  <th className="py-3 px-3 text-center">Expiry Date &amp; Timing</th>
                  <th className="py-3 px-3 text-right">Units / Shares</th>
                  <th className="py-3 px-3 text-right">Notional Value</th>
                  <th className="py-3 px-3 text-right">Executed Price</th>
                  <th className="py-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {derivativesOrders.map((ord) => {
                  const badge = getDerivativeBadge(ord.derivativeType);
                  const mode = getOrderMode(ord);
                  const modeBadge = getModeBadge(mode);
                  const stock = stockMap.get(ord.ticker.toUpperCase()) || ({
                    ticker: ord.ticker,
                    name: ord.stockName || ord.ticker,
                    price: ord.price || 100,
                    changeUSD: 0,
                    changePercent: 0,
                    marketCap: 'N/A',
                    volume: 'N/A',
                    sector: ord.sector || 'General',
                    dayRange: 'N/A',
                    marketType: 'fiat',
                    settlementMethod: 'USD Direct Clearing',
                  } as unknown as StockItem);

                  return (
                    <tr key={ord.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Asset & Contract */}
                      <td className="py-3 px-3">
                        <div 
                          onClick={() => onSelectStock && onSelectStock(stock)}
                          className="flex items-center gap-2.5 group cursor-pointer"
                          title={`View stock page for $${ord.ticker}`}
                        >
                          <div className="w-8 h-8 rounded-xl bg-slate-900 group-hover:bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 transition-colors">
                            {ord.ticker.slice(0, 3)}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-slate-900 group-hover:text-indigo-600 font-mono transition-colors">${ord.ticker}</span>
                              <span className="text-[10px] text-slate-400 font-mono">{ord.tradeSlipId || ord.id.slice(-6)}</span>
                            </div>
                            <span className="text-[11px] text-slate-500 truncate block max-w-[160px] group-hover:underline">
                              {ord.stockName}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Derivative & Mode Combo */}
                      <td className="py-3 px-3 space-y-1">
                        <div>
                          <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${badge.color}`}>
                            <badge.icon className="w-3 h-3" />
                            <span>{badge.label}</span>
                          </span>
                        </div>
                        <div>
                          <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border ${modeBadge.color}`}>
                            <span>{modeBadge.label}</span>
                          </span>
                        </div>
                      </td>

                      {/* Strike & Leverage */}
                      <td className="py-3 px-3 text-center">
                        {ord.strikePrice ? (
                          <div className="font-mono">
                            <span className="font-bold text-slate-900 block">${ord.strikePrice.toFixed(2)} Strike</span>
                            <span className="text-[10px] text-slate-400 block">5% Premium: ${ord.premiumUSD?.toFixed(2) || '0.00'}</span>
                          </div>
                        ) : ord.leverage ? (
                          <div className="font-mono">
                            <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded block">{ord.leverage}x Leverage</span>
                            <span className="text-[10px] text-slate-400 block">Margin Contract</span>
                          </div>
                        ) : (
                          <span className="text-slate-400 font-mono text-[10px]">Standard</span>
                        )}
                      </td>

                      {/* Expiry Date & Timing */}
                      <td className="py-3 px-3 text-center">
                        <div className="font-mono">
                          <span className="font-bold text-slate-800 flex items-center justify-center gap-1">
                            <Clock className="w-3 h-3 text-amber-500" />
                            <span>{ord.expiryDate || 'Open Expiry'}</span>
                          </span>
                          <span className="text-[10px] text-slate-400 block">Time: {ord.timestamp}</span>
                        </div>
                      </td>

                      {/* Shares */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                        {ord.shares.toLocaleString()}
                      </td>

                      {/* Notional Value */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                        ${ord.totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* Executed Price */}
                      <td className="py-3 px-3 text-right font-mono text-slate-600">
                        ${ord.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => onOpenTradeModal(ord.ticker, 'buy')}
                            className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] transition-colors cursor-pointer"
                          >
                            Trade More
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

