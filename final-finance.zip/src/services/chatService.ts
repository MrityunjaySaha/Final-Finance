import { AuthSession } from '../types/auth';
import { Conversation, ChatMessage, UserPublicProfile } from '../types/social';
import { areUsersBlockedEitherWay } from './socialService';

export const MAX_GROUP_MEMBERS = 20;

// Persistent mock chat state in memory & localStorage
const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv-group-zurich',
    type: 'group',
    name: 'Zurich Freeport Gold Syndicate',
    groupAvatarUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=300&q=80',
    participantIds: ['demo-super-admin', 'demo-vip-alex', 'user-elena_rostova', 'user-lord_sterling'],
    participants: {
      'demo-super-admin': {
        uid: 'demo-super-admin',
        userId: 'super_admin_ranma',
        name: 'Ranma Sovereign Master',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
        role: 'super_admin'
      },
      'demo-vip-alex': {
        uid: 'demo-vip-alex',
        userId: 'alex_morgan',
        name: 'Alex Morgan',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        role: 'vip_user'
      },
      'user-elena_rostova': {
        uid: 'user-elena_rostova',
        userId: 'elena_rostova',
        name: 'Elena Rostova',
        avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
        role: 'user'
      },
      'user-lord_sterling': {
        uid: 'user-lord_sterling',
        userId: 'sterling_vault',
        name: 'Lord Sterling',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        role: 'user'
      }
    },
    createdBy: 'demo-vip-alex',
    lastMessageText: 'The 100oz gold lot has passed dual LBMA assay verification.',
    lastMessageSenderId: 'user-lord_sterling',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'conv-direct-sterling',
    type: 'direct',
    participantIds: ['demo-vip-alex', 'user-lord_sterling'],
    participants: {
      'demo-vip-alex': {
        uid: 'demo-vip-alex',
        userId: 'alex_morgan',
        name: 'Alex Morgan',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
      },
      'user-lord_sterling': {
        uid: 'user-lord_sterling',
        userId: 'sterling_vault',
        name: 'Lord Sterling',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'
      }
    },
    lastMessageText: 'Greetings! Are you looking to barter for the 1st Edition bullion?',
    lastMessageSenderId: 'user-lord_sterling',
    updatedAt: new Date().toISOString()
  }
];

const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  'conv-group-zurich': [
    {
      id: 'msg-1',
      conversationId: 'conv-group-zurich',
      senderId: 'user-lord_sterling',
      senderName: 'Lord Sterling',
      senderHandle: 'sterling_vault',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      text: 'Good day syndicate members. Our Zurich Freeport bullion allocation is ready for barter verification.',
      createdAt: { toDate: () => new Date(Date.now() - 3600000) }
    },
    {
      id: 'msg-2',
      conversationId: 'conv-group-zurich',
      senderId: 'demo-vip-alex',
      senderName: 'Alex Morgan',
      senderHandle: 'alex_morgan',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      text: 'Confirmed. We can settle 50% in AFNL native coins and 50% in physical horology delivery.',
      createdAt: { toDate: () => new Date(Date.now() - 1800000) }
    },
    {
      id: 'msg-3',
      conversationId: 'conv-group-zurich',
      senderId: 'user-lord_sterling',
      senderName: 'Lord Sterling',
      senderHandle: 'sterling_vault',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      text: 'The 100oz gold lot has passed dual LBMA assay verification.',
      createdAt: { toDate: () => new Date(Date.now() - 600000) }
    }
  ],
  'conv-direct-sterling': [
    {
      id: 'msg-10',
      conversationId: 'conv-direct-sterling',
      senderId: 'user-lord_sterling',
      senderName: 'Lord Sterling',
      senderHandle: 'sterling_vault',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      text: 'Greetings! Are you looking to barter for the 1st Edition bullion?',
      createdAt: { toDate: () => new Date(Date.now() - 1200000) }
    }
  ]
};

let conversationsList = [...INITIAL_CONVERSATIONS];
let messagesStore = { ...INITIAL_MESSAGES };
const listeners: Array<() => void> = [];

function notifyListeners() {
  listeners.forEach(cb => cb());
}

export function subscribeToUserConversations(uid: string, callback: (conversations: Conversation[]) => void): () => void {
  const handler = () => {
    const userConvs = conversationsList.filter(c => c.participantIds.includes(uid));
    callback(userConvs);
  };
  listeners.push(handler);
  handler();

  return () => {
    const idx = listeners.indexOf(handler);
    if (idx > -1) listeners.splice(idx, 1);
  };
}

export function subscribeToMessages(conversationId: string, callback: (messages: ChatMessage[]) => void): () => void {
  const handler = () => {
    callback(messagesStore[conversationId] || []);
  };
  listeners.push(handler);
  handler();

  return () => {
    const idx = listeners.indexOf(handler);
    if (idx > -1) listeners.splice(idx, 1);
  };
}

export async function sendChatMessage(
  conversationId: string,
  user: AuthSession,
  text: string
): Promise<void> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (conv && conv.type === 'direct') {
    const otherUid = conv.participantIds.find(id => id !== user.uid);
    if (otherUid && areUsersBlockedEitherWay(user.uid, otherUid)) {
      throw new Error('Cannot send message: this user is blocked or has blocked communication.');
    }
  }

  const newMsg: ChatMessage = {
    id: 'msg-' + Date.now(),
    conversationId,
    senderId: user.uid,
    senderName: user.name,
    senderHandle: user.id,
    senderAvatarUrl: user.avatarUrl,
    text,
    createdAt: { toDate: () => new Date() }
  };

  if (!messagesStore[conversationId]) {
    messagesStore[conversationId] = [];
  }
  messagesStore[conversationId].push(newMsg);

  // Update conversation last message
  conversationsList = conversationsList.map(c => {
    if (c.id === conversationId) {
      return {
        ...c,
        lastMessageText: text,
        lastMessageSenderId: user.uid,
        updatedAt: new Date().toISOString()
      };
    }
    return c;
  });

  notifyListeners();
}

export async function createGroupConversation(
  currentUser: AuthSession,
  name: string,
  members: UserPublicProfile[]
): Promise<{ success: boolean; conversation?: Conversation; error?: string }> {
  const allUids = [currentUser.uid, ...members.map(m => m.uid)];
  const participantsMap: Record<string, any> = {
    [currentUser.uid]: {
      uid: currentUser.uid,
      userId: currentUser.id,
      name: currentUser.name,
      avatarUrl: currentUser.avatarUrl,
      role: currentUser.role
    }
  };

  members.forEach(m => {
    participantsMap[m.uid] = {
      uid: m.uid,
      userId: m.userId,
      name: m.name,
      avatarUrl: m.avatarUrl,
      role: m.role
    };
  });

  const newConv: Conversation = {
    id: 'group-' + Date.now(),
    type: 'group',
    name: name || `Multi-Conference (${allUids.length} members)`,
    groupAvatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=000&color=fff&size=128`,
    participantIds: allUids,
    participants: participantsMap,
    createdBy: currentUser.uid,
    lastMessageText: 'Group created. Conference ready.',
    lastMessageSenderId: currentUser.uid,
    updatedAt: new Date().toISOString()
  };

  conversationsList = [newConv, ...conversationsList];
  messagesStore[newConv.id] = [
    {
      id: 'msg-init-' + Date.now(),
      conversationId: newConv.id,
      senderId: currentUser.uid,
      senderName: currentUser.name,
      senderHandle: currentUser.id,
      senderAvatarUrl: currentUser.avatarUrl,
      text: `🎉 Started new multi-conference group: "${name}"`,
      createdAt: { toDate: () => new Date() }
    }
  ];

  notifyListeners();
  return { success: true, conversation: newConv };
}

export async function getOrCreateDirectConversation(
  currentUser: AuthSession,
  targetUser: UserPublicProfile
): Promise<Conversation> {
  const existing = conversationsList.find(c => 
    c.type === 'direct' &&
    c.participantIds.includes(currentUser.uid) &&
    c.participantIds.includes(targetUser.uid)
  );

  if (existing) return existing;

  const newConv: Conversation = {
    id: `direct-${currentUser.uid}-${targetUser.uid}`,
    type: 'direct',
    participantIds: [currentUser.uid, targetUser.uid],
    participants: {
      [currentUser.uid]: {
        uid: currentUser.uid,
        userId: currentUser.id,
        name: currentUser.name,
        avatarUrl: currentUser.avatarUrl
      },
      [targetUser.uid]: {
        uid: targetUser.uid,
        userId: targetUser.userId,
        name: targetUser.name,
        avatarUrl: targetUser.avatarUrl
      }
    },
    lastMessageText: 'Direct channel opened.',
    updatedAt: new Date().toISOString()
  };

  conversationsList = [newConv, ...conversationsList];
  messagesStore[newConv.id] = [];
  notifyListeners();
  return newConv;
}

export async function addMemberToGroup(
  conversationId: string,
  member: UserPublicProfile
): Promise<{ success: boolean; error?: string }> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group conversation not found' };

  if (conv.participantIds.length >= MAX_GROUP_MEMBERS) {
    return { success: false, error: `Group has reached maximum limit of ${MAX_GROUP_MEMBERS} members` };
  }

  if (conv.participantIds.includes(member.uid)) {
    return { success: false, error: 'Member already in group' };
  }

  conv.participantIds.push(member.uid);
  conv.participants[member.uid] = {
    uid: member.uid,
    userId: member.userId,
    name: member.name,
    avatarUrl: member.avatarUrl,
    role: member.role
  };

  notifyListeners();
  return { success: true };
}

export async function removeMemberFromGroup(
  conversationId: string,
  targetUid: string,
  requestedBy: AuthSession
): Promise<{ success: boolean; error?: string }> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group room not found' };

  if (conv.createdBy && conv.createdBy !== requestedBy.uid && requestedBy.role !== 'super_admin') {
    return { success: false, error: 'Only the room creator can eject members from this group.' };
  }

  if (targetUid === conv.createdBy) {
    return { success: false, error: 'The room creator cannot be ejected. Use End Group to disband the room.' };
  }

  const targetParticipant = conv.participants[targetUid];
  const targetName = targetParticipant?.name || 'Member';

  // Remove from participant list & map
  conv.participantIds = conv.participantIds.filter(id => id !== targetUid);
  delete conv.participants[targetUid];

  const sysMsg: ChatMessage = {
    id: 'msg-sys-' + Date.now(),
    conversationId,
    senderId: 'system',
    senderName: 'System Bot',
    senderHandle: 'system',
    text: `🚫 ${targetName} was ejected from the group by the room creator (${requestedBy.name}).`,
    createdAt: { toDate: () => new Date() }
  };

  if (!messagesStore[conversationId]) {
    messagesStore[conversationId] = [];
  }
  messagesStore[conversationId].push(sysMsg);
  conv.lastMessageText = `${targetName} was removed from the group`;
  conv.updatedAt = new Date().toISOString();

  notifyListeners();
  return { success: true };
}

export async function deleteGroupConversation(
  conversationId: string,
  requestedBy: AuthSession
): Promise<{ success: boolean; error?: string }> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group room not found' };

  if (conv.createdBy && conv.createdBy !== requestedBy.uid && requestedBy.role !== 'super_admin') {
    return { success: false, error: 'Only the room creator can end and delete this group room.' };
  }

  conversationsList = conversationsList.filter(c => c.id !== conversationId);
  delete messagesStore[conversationId];

  notifyListeners();
  return { success: true };
}

export async function leaveGroupConversation(
  conversationId: string,
  currentUser: AuthSession
): Promise<{ success: boolean; error?: string }> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group room not found' };

  conv.participantIds = conv.participantIds.filter(id => id !== currentUser.uid);
  delete conv.participants[currentUser.uid];

  if (conv.participantIds.length === 0) {
    conversationsList = conversationsList.filter(c => c.id !== conversationId);
    delete messagesStore[conversationId];
  } else {
    const sysMsg: ChatMessage = {
      id: 'msg-sys-' + Date.now(),
      conversationId,
      senderId: 'system',
      senderName: 'System Bot',
      senderHandle: 'system',
      text: `👋 ${currentUser.name} left the group room.`,
      createdAt: { toDate: () => new Date() }
    };
    if (!messagesStore[conversationId]) {
      messagesStore[conversationId] = [];
    }
    messagesStore[conversationId].push(sysMsg);
    conv.lastMessageText = `${currentUser.name} left the group`;
    conv.updatedAt = new Date().toISOString();
  }

  notifyListeners();
  return { success: true };
}

