import {
  createPublicClient,
  encodeFunctionData,
  erc20Abi,
  formatUnits,
  getAddress,
  http,
  isAddress,
  parseUnits,
  verifyMessage,
} from 'viem';
import {
  arbitrum,
  base,
  mainnet,
  polygon,
  type Chain,
} from 'viem/chains';

export type PrivyServerNetworkKey =
  | 'ethereum'
  | 'base'
  | 'polygon'
  | 'arbitrum';

interface ServerTokenDef {
  symbol: string;
  name: string;
  decimals: number;
  address: `0x${string}` | null;
}

interface ServerNetworkDef {
  key: PrivyServerNetworkKey;
  name: string;
  chainId: number;
  isTestnet: boolean;
  nativeSymbol: string;
  nativeName: string;
  rpcUrl: string;
  explorerUrl: string;
  chain: Chain;
  tokens: ServerTokenDef[];
}

const SERVER_NETWORKS: ServerNetworkDef[] = [
  {
    key: 'base',
    name: 'Base Mainnet',
    chainId: 8453,
    isTestnet: false,
    nativeSymbol: 'ETH',
    nativeName: 'Ether',
    rpcUrl: 'https://mainnet.base.org',
    explorerUrl: 'https://basescan.org',
    chain: base,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2',
      },
    ],
  },
  {
    key: 'ethereum',
    name: 'Ethereum Mainnet',
    chainId: 1,
    isTestnet: false,
    nativeSymbol: 'ETH',
    nativeName: 'Ether',
    rpcUrl: 'https://ethereum-rpc.publicnode.com',
    explorerUrl: 'https://etherscan.io',
    chain: mainnet,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
      },
    ],
  },
  {
    key: 'polygon',
    name: 'Polygon PoS',
    chainId: 137,
    isTestnet: false,
    nativeSymbol: 'POL',
    nativeName: 'POL (Polygon)',
    rpcUrl: 'https://polygon-bor-rpc.publicnode.com',
    explorerUrl: 'https://polygonscan.com',
    chain: polygon,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
      },
    ],
  },
  {
    key: 'arbitrum',
    name: 'Arbitrum One',
    chainId: 42161,
    isTestnet: false,
    nativeSymbol: 'ETH',
    nativeName: 'Ether',
    rpcUrl: 'https://arbitrum-one-rpc.publicnode.com',
    explorerUrl: 'https://arbiscan.io',
    chain: arbitrum,
    tokens: [
      {
        symbol: 'USDC',
        name: 'USD Coin',
        decimals: 6,
        address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
      },
      {
        symbol: 'USDT',
        name: 'Tether USD',
        decimals: 6,
        address: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
      },
    ],
  },
];

export class PrivyApiError extends Error {
  public readonly statusCode: number;
  public readonly isConfigError: boolean;
  constructor(message: string, statusCode = 400, isConfigError = false) {
    super(message);
    this.name = 'PrivyApiError';
    this.statusCode = statusCode;
    this.isConfigError = isConfigError;
  }
}

function readEnvValue(name: string): string | null {
  const raw = process.env[name];
  if (typeof raw !== 'string') return null;
  let trimmed = raw.trim();
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    trimmed = trimmed.slice(1, -1).trim();
  }
  if (!trimmed || /^MY_[A-Z0-9_]+$/i.test(trimmed)) return null;
  return trimmed;
}

export function getPrivyAppIdServer(): string {
  return (
    readEnvValue('PRIVY_APP_ID') ||
    readEnvValue('VITE_PRIVY_APP_ID') ||
    'cmwsldhq500pv0gjmwputn68u'
  );
}

export function getPrivyAppSecretServer(): string | null {
  return readEnvValue('PRIVY_APP_SECRET');
}

export function getPrivyServerConfig() {
  const appId = getPrivyAppIdServer();
  const appSecretConfigured = Boolean(getPrivyAppSecretServer());
  return {
    appIdConfigured: Boolean(appId),
    appId,
    appSecretConfigured,
    defaultNetworkKey: 'ethereum' as PrivyServerNetworkKey,
    supportedNetworks: SERVER_NETWORKS.map((n) => ({
      key: n.key,
      name: n.name,
      chainId: n.chainId,
      isTestnet: n.isTestnet,
      nativeSymbol: n.nativeSymbol,
      explorerUrl: n.explorerUrl,
    })),
  };
}

function resolveNetwork(networkKey: unknown): ServerNetworkDef {
  const rawInput = typeof networkKey === 'string' && networkKey.trim() ? networkKey.trim() : 'ethereum';
  const raw =
    rawInput === 'base-sepolia'
      ? 'base'
      : rawInput === 'sepolia'
      ? 'ethereum'
      : rawInput;
  const matched = SERVER_NETWORKS.find((n) => n.key === raw);
  if (!matched) {
    throw new PrivyApiError(
      `Unsupported network "${rawInput}". Supported networks: ${SERVER_NETWORKS.map((n) => n.key).join(', ')}.`,
      400
    );
  }
  return matched;
}

function assertValidEvmAddress(value: unknown, fieldName: string): `0x${string}` {
  if (typeof value !== 'string' || !value.trim()) {
    throw new PrivyApiError(`${fieldName} is required.`, 400);
  }
  const trimmed = value.trim();
  if (!isAddress(trimmed)) {
    throw new PrivyApiError(`${fieldName} must be a valid EVM wallet address (0x...).`, 400);
  }
  return trimmed as `0x${string}`;
}

function createNetworkClient(net: ServerNetworkDef) {
  return createPublicClient({
    chain: net.chain,
    transport: http(net.rpcUrl, { timeout: 10_000 }),
  });
}

async function readErc20<T>(
  client: ReturnType<typeof createNetworkClient>,
  params: {
    address: `0x${string}`;
    functionName: 'balanceOf' | 'decimals' | 'symbol' | 'name';
    args?: readonly [`0x${string}`];
  }
): Promise<T> {
  return (client.readContract as (input: Record<string, unknown>) => Promise<T>)({
    address: params.address,
    abi: erc20Abi,
    functionName: params.functionName,
    ...(params.args ? { args: params.args } : {}),
  });
}

export interface WalletTokenBalanceItem {
  symbol: string;
  name: string;
  decimals: number;
  address: string | null;
  isNative: boolean;
  isStablecoin: boolean;
  available: boolean;
  balanceRaw: string;
  balanceFormatted: string;
  note?: string;
}

export async function fetchPrivyWalletBalances(params: {
  address: unknown;
  network?: unknown;
  customTokens?: unknown;
}): Promise<{
  address: `0x${string}`;
  networkKey: PrivyServerNetworkKey;
  networkName: string;
  chainId: number;
  isTestnet: boolean;
  explorerUrl: string;
  nativeToken: WalletTokenBalanceItem;
  tokens: WalletTokenBalanceItem[];
  fetchedAt: string;
}> {
  const address = assertValidEvmAddress(params.address, 'address');
  const net = resolveNetwork(params.network);
  const client = createNetworkClient(net);

  let nativeRaw = 0n;
  try {
    nativeRaw = await client.getBalance({ address });
  } catch (error: any) {
    throw new PrivyApiError(
      `Failed to query ${net.name} RPC for native balance: ${error?.shortMessage || error?.message || 'RPC unavailable'}.`,
      502
    );
  }

  const nativeToken: WalletTokenBalanceItem = {
    symbol: net.nativeSymbol,
    name: net.nativeName,
    decimals: 18,
    address: null,
    isNative: true,
    isStablecoin: false,
    available: true,
    balanceRaw: nativeRaw.toString(),
    balanceFormatted: Number(formatUnits(nativeRaw, 18)).toFixed(6).replace(/\.?0+$/, '') || '0',
  };

  const customTokenAddresses: `0x${string}`[] = [];
  if (Array.isArray(params.customTokens)) {
    for (const entry of params.customTokens.slice(0, 10)) {
      if (typeof entry === 'string' && isAddress(entry.trim())) {
        const normalized = entry.trim() as `0x${string}`;
        const alreadyBuiltIn = net.tokens.some(
          (t) => t.address && t.address.toLowerCase() === normalized.toLowerCase()
        );
        if (!alreadyBuiltIn && !customTokenAddresses.some((a) => a.toLowerCase() === normalized.toLowerCase())) {
          customTokenAddresses.push(normalized);
        }
      }
    }
  }

  const builtInResults = await Promise.all(
    net.tokens.map(async (token): Promise<WalletTokenBalanceItem> => {
      if (!token.address) {
        return {
          symbol: token.symbol,
          name: token.name,
          decimals: token.decimals,
          address: null,
          isNative: false,
          isStablecoin: true,
          available: false,
          balanceRaw: '0',
          balanceFormatted: '0',
          note: `No canonical ${token.symbol} contract on ${net.name}. Add a custom contract address or switch to Ethereum Sepolia / Mainnet.`,
        };
      }

      try {
        const raw = await readErc20<bigint>(client, {
          address: token.address,
          functionName: 'balanceOf',
          args: [address],
        });
        const formatted = formatUnits(raw, token.decimals);
        return {
          symbol: token.symbol,
          name: token.name,
          decimals: token.decimals,
          address: token.address,
          isNative: false,
          isStablecoin: true,
          available: true,
          balanceRaw: raw.toString(),
          balanceFormatted: Number(formatted).toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 4,
          }),
        };
      } catch {
        return {
          symbol: token.symbol,
          name: token.name,
          decimals: token.decimals,
          address: token.address,
          isNative: false,
          isStablecoin: true,
          available: false,
          balanceRaw: '0',
          balanceFormatted: '0',
          note: 'Unable to read token contract on this RPC.',
        };
      }
    })
  );

  const customResults = await Promise.all(
    customTokenAddresses.map(async (tokenAddr): Promise<WalletTokenBalanceItem> => {
      try {
        const [raw, decimals, symbol, name] = await Promise.all([
          readErc20<bigint>(client, {
            address: tokenAddr,
            functionName: 'balanceOf',
            args: [address],
          }),
          readErc20<number>(client, {
            address: tokenAddr,
            functionName: 'decimals',
          }).catch(() => 18),
          readErc20<string>(client, {
            address: tokenAddr,
            functionName: 'symbol',
          }).catch(() => 'TOKEN'),
          readErc20<string>(client, {
            address: tokenAddr,
            functionName: 'name',
          }).catch(() => 'Custom ERC-20'),
        ]);

        const decNum = Number(decimals) || 18;
        const formatted = formatUnits(raw, decNum);
        return {
          symbol: String(symbol),
          name: String(name),
          decimals: decNum,
          address: tokenAddr,
          isNative: false,
          isStablecoin: ['USDC', 'USDT', 'DAI', 'EURC', 'PYUSD'].includes(String(symbol).toUpperCase()),
          available: true,
          balanceRaw: raw.toString(),
          balanceFormatted: Number(formatted).toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 4,
          }),
        };
      } catch {
        return {
          symbol: 'ERC20',
          name: 'Unverified Contract',
          decimals: 18,
          address: tokenAddr,
          isNative: false,
          isStablecoin: false,
          available: false,
          balanceRaw: '0',
          balanceFormatted: '0',
          note: 'Contract did not respond as a standard ERC-20 on this network.',
        };
      }
    })
  );

  return {
    address,
    networkKey: net.key,
    networkName: net.name,
    chainId: net.chainId,
    isTestnet: net.isTestnet,
    explorerUrl: net.explorerUrl,
    nativeToken,
    tokens: [...builtInResults, ...customResults],
    fetchedAt: new Date().toISOString(),
  };
}

export function preparePrivyTokenTransfer(params: {
  fromAddress: unknown;
  toAddress: unknown;
  amount: unknown;
  network?: unknown;
  assetType: unknown;
  tokenSymbol?: unknown;
  tokenAddress?: unknown;
  decimals?: unknown;
}) {
  const fromAddress = assertValidEvmAddress(params.fromAddress, 'fromAddress');
  const toAddress = assertValidEvmAddress(params.toAddress, 'toAddress');
  const net = resolveNetwork(params.network);

  const amountStr = typeof params.amount === 'number' ? String(params.amount) : typeof params.amount === 'string' ? params.amount.trim() : '';
  const amountNum = Number(amountStr);
  if (!amountStr || !Number.isFinite(amountNum) || amountNum <= 0) {
    throw new PrivyApiError('Transfer amount must be a positive number.', 400);
  }

  const assetType = params.assetType === 'erc20' ? 'erc20' : params.assetType === 'native' ? 'native' : null;
  if (!assetType) {
    throw new PrivyApiError('assetType must be "native" or "erc20".', 400);
  }

  if (assetType === 'native') {
    const valueWei = parseUnits(amountStr, 18);
    if (valueWei <= 0n) {
      throw new PrivyApiError('Transfer amount is too small.', 400);
    }
    return {
      fromAddress,
      chainId: net.chainId,
      networkKey: net.key,
      networkName: net.name,
      explorerUrl: net.explorerUrl,
      assetSymbol: net.nativeSymbol,
      transaction: {
        to: toAddress,
        value: `0x${valueWei.toString(16)}`,
        chainId: net.chainId,
      },
    };
  }

  // ERC-20 transfer
  let contractAddr: `0x${string}` | null = null;
  let decimals = Number(params.decimals) || 6;
  const symbolStr = typeof params.tokenSymbol === 'string' ? params.tokenSymbol.trim().toUpperCase() : '';

  if (typeof params.tokenAddress === 'string' && params.tokenAddress.trim()) {
    contractAddr = assertValidEvmAddress(params.tokenAddress, 'tokenAddress');
  } else if (symbolStr) {
    const found = net.tokens.find((t) => t.symbol === symbolStr);
    if (!found || !found.address) {
      throw new PrivyApiError(
        `${symbolStr} does not have a default contract configured on ${net.name}. Provide a custom token contract address or switch networks.`,
        400
      );
    }
    contractAddr = found.address;
    decimals = found.decimals;
  } else {
    throw new PrivyApiError('tokenAddress or tokenSymbol is required for ERC-20 transfers.', 400);
  }

  const rawUnits = parseUnits(amountStr, decimals);
  if (rawUnits <= 0n) {
    throw new PrivyApiError('Token transfer amount is too small.', 400);
  }

  const data = encodeFunctionData({
    abi: erc20Abi,
    functionName: 'transfer',
    args: [toAddress, rawUnits],
  });

  return {
    fromAddress,
    chainId: net.chainId,
    networkKey: net.key,
    networkName: net.name,
    explorerUrl: net.explorerUrl,
    assetSymbol: symbolStr || 'ERC20',
    transaction: {
      to: contractAddr,
      data,
      value: '0x0',
      chainId: net.chainId,
    },
  };
}

export async function verifyPrivyBackendToken(params: {
  accessToken?: unknown;
  privyUserId?: unknown;
}) {
  const appId = getPrivyAppIdServer();
  const appSecret = getPrivyAppSecretServer();
  const token = typeof params.accessToken === 'string' ? params.accessToken.trim() : '';

  if (!token) {
    throw new PrivyApiError('Missing Privy accessToken in request body or Authorization header.', 400);
  }

  if (!appSecret) {
    return {
      verified: false,
      appSecretConfigured: false,
      appId,
      verificationMode: 'client-public',
      message: 'Client wallet connection and live RPC balance reads are active.',
    };
  }

  const privyUserId = typeof params.privyUserId === 'string' ? params.privyUserId.trim() : '';
  if (privyUserId && !/^did:privy:[a-zA-Z0-9_-]+$/.test(privyUserId)) {
    throw new PrivyApiError('Invalid privyUserId format.', 400);
  }

  // Server-to-server Privy REST API check using Basic auth (appId:appSecret) strictly on backend
  const basicAuth = Buffer.from(`${appId}:${appSecret}`).toString('base64');
  if (privyUserId) {
    const apiRes = await fetch(`https://api.privy.io/v1/users/${encodeURIComponent(privyUserId)}`, {
      method: 'GET',
      headers: {
        Authorization: `Basic ${basicAuth}`,
        'privy-app-id': appId,
        Accept: 'application/json',
      },
    });
    if (!apiRes.ok) {
      const errText = await apiRes.text().catch(() => '');
      throw new PrivyApiError(
        `Privy server API rejected verification (HTTP ${apiRes.status}): ${errText || apiRes.statusText}`,
        apiRes.status === 401 || apiRes.status === 403 ? 503 : 400,
        apiRes.status === 401 || apiRes.status === 403
      );
    }
    const userData = await apiRes.json();
    return {
      verified: true,
      appSecretConfigured: true,
      appId,
      verificationMode: 'server-api',
      privyUserId: userData.id || privyUserId,
      linkedAccountsCount: Array.isArray(userData.linked_accounts) ? userData.linked_accounts.length : 0,
    };
  }

  return {
    verified: true,
    appSecretConfigured: true,
    appId,
    verificationMode: 'server-configured',
  };
}

interface StoredWalletPrefs {
  userId: string;
  walletAddress: string | null;
  networkKey: PrivyServerNetworkKey;
  customTokensByNetwork: Record<string, string[]>;
  updatedAt: string;
}

const walletPrefsStore = new Map<string, StoredWalletPrefs>();

export function getWalletPreferences(userIdRaw: unknown): StoredWalletPrefs {
  const userId = typeof userIdRaw === 'string' && userIdRaw.trim() ? userIdRaw.trim().slice(0, 128) : '';
  if (!userId) {
    throw new PrivyApiError('userId is required.', 400);
  }
  return (
    walletPrefsStore.get(userId) || {
      userId,
      walletAddress: null,
      networkKey: 'ethereum',
      customTokensByNetwork: {},
      updatedAt: new Date().toISOString(),
    }
  );
}

export function saveWalletPreferences(params: {
  userId: unknown;
  walletAddress?: unknown;
  networkKey?: unknown;
  customTokensByNetwork?: unknown;
}): StoredWalletPrefs {
  const userId = typeof params.userId === 'string' && params.userId.trim() ? params.userId.trim().slice(0, 128) : '';
  if (!userId) {
    throw new PrivyApiError('userId is required.', 400);
  }

  const net = params.networkKey ? resolveNetwork(params.networkKey) : resolveNetwork('ethereum');
  let walletAddress: string | null = null;
  if (params.walletAddress !== undefined && params.walletAddress !== null && String(params.walletAddress).trim() !== '') {
    walletAddress = assertValidEvmAddress(params.walletAddress, 'walletAddress');
  }

  const existing = getWalletPreferences(userId);
  const nextCustom: Record<string, string[]> = { ...existing.customTokensByNetwork };
  if (params.customTokensByNetwork && typeof params.customTokensByNetwork === 'object') {
    for (const [k, list] of Object.entries(params.customTokensByNetwork as Record<string, unknown>)) {
      if (SERVER_NETWORKS.some((n) => n.key === k) && Array.isArray(list)) {
        nextCustom[k] = list
          .filter((addr): addr is string => typeof addr === 'string' && isAddress(addr.trim()))
          .map((addr) => addr.trim())
          .slice(0, 10);
      }
    }
  }

  const updated: StoredWalletPrefs = {
    userId,
    walletAddress: walletAddress ?? existing.walletAddress,
    networkKey: net.key,
    customTokensByNetwork: nextCustom,
    updatedAt: new Date().toISOString(),
  };
  walletPrefsStore.set(userId, updated);
  return updated;
}

export interface PrivyServerManagedWallet {
  id: string;
  address: `0x${string}`;
  chainType: 'ethereum';
  createdAt: string;
  source: 'privy-server-api';
}

const serverWalletsByUser = new Map<string, PrivyServerManagedWallet[]>();

function getPrivyBasicHeaders() {
  const appId = getPrivyAppIdServer();
  const appSecret = getPrivyAppSecretServer();
  if (!appSecret) {
    throw new PrivyApiError(
      'PRIVY_APP_SECRET is not configured on the server. Add it in Secrets to create server-managed Privy wallets.',
      503,
      true
    );
  }
  const basicAuth = Buffer.from(`${appId}:${appSecret}`).toString('base64');
  return {
    Authorization: `Basic ${basicAuth}`,
    'privy-app-id': appId,
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };
}

export function getPrivyServerWallets(userIdRaw: unknown): PrivyServerManagedWallet[] {
  const userId = typeof userIdRaw === 'string' && userIdRaw.trim() ? userIdRaw.trim().slice(0, 128) : '';
  if (!userId) {
    throw new PrivyApiError('userId is required.', 400);
  }
  return serverWalletsByUser.get(userId) || [];
}

export async function createPrivyServerWallet(params: {
  userId: unknown;
  createNew?: boolean;
}): Promise<PrivyServerManagedWallet> {
  const userId =
    typeof params.userId === 'string' && params.userId.trim() ? params.userId.trim().slice(0, 128) : 'guest';
  const existing = serverWalletsByUser.get(userId) || [];
  if (!params.createNew && existing.length > 0) {
    return existing[0];
  }

  const headers = getPrivyBasicHeaders();
  const res = await fetch('https://api.privy.io/v1/wallets', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      chain_type: 'ethereum',
    }),
  });

  const rawText = await res.text().catch(() => '');
  let parsed: any = null;
  try {
    parsed = rawText ? JSON.parse(rawText) : null;
  } catch {
    parsed = null;
  }

  if (!res.ok) {
    const msg =
      parsed?.error ||
      parsed?.message ||
      rawText ||
      `Privy Wallets API returned HTTP ${res.status}`;
    throw new PrivyApiError(
      `Unable to create Privy wallet: ${msg}`,
      res.status >= 400 && res.status < 600 ? res.status : 502
    );
  }

  if (!parsed?.id || !parsed?.address || !isAddress(parsed.address)) {
    throw new PrivyApiError('Privy Wallets API returned an unexpected response without a wallet address.', 502);
  }

  const created: PrivyServerManagedWallet = {
    id: String(parsed.id),
    address: parsed.address as `0x${string}`,
    chainType: 'ethereum',
    createdAt: parsed.created_at ? new Date(parsed.created_at).toISOString() : new Date().toISOString(),
    source: 'privy-server-api',
  };

  serverWalletsByUser.set(userId, [created, ...existing]);
  return created;
}

export async function sendPrivyServerWalletTransaction(params: {
  walletId: unknown;
  fromAddress: unknown;
  toAddress: unknown;
  amount: unknown;
  network?: unknown;
  assetType: unknown;
  tokenSymbol?: unknown;
  tokenAddress?: unknown;
  decimals?: unknown;
}) {
  const walletId = typeof params.walletId === 'string' && params.walletId.trim() ? params.walletId.trim() : '';
  if (!walletId) {
    throw new PrivyApiError('walletId is required for Privy server wallet transactions.', 400);
  }

  const prepared = preparePrivyTokenTransfer({
    fromAddress: params.fromAddress,
    toAddress: params.toAddress,
    amount: params.amount,
    network: params.network,
    assetType: params.assetType,
    tokenSymbol: params.tokenSymbol,
    tokenAddress: params.tokenAddress,
    decimals: params.decimals,
  });

  const headers = getPrivyBasicHeaders();
  const txPayload: Record<string, string> = {
    to: prepared.transaction.to,
    value: prepared.transaction.value,
  };
  if (prepared.transaction.data) {
    txPayload.data = prepared.transaction.data;
  }

  const res = await fetch(`https://api.privy.io/v1/wallets/${encodeURIComponent(walletId)}/rpc`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      method: 'eth_sendTransaction',
      caip2: `eip155:${prepared.chainId}`,
      chain_type: 'ethereum',
      params: {
        transaction: txPayload,
      },
    }),
  });

  const rawText = await res.text().catch(() => '');
  let parsed: any = null;
  try {
    parsed = rawText ? JSON.parse(rawText) : null;
  } catch {
    parsed = null;
  }

  if (!res.ok) {
    const msg =
      parsed?.error ||
      parsed?.message ||
      rawText ||
      `Privy Wallet RPC returned HTTP ${res.status}`;
    throw new PrivyApiError(
      `Unable to broadcast transaction via Privy wallet: ${msg}`,
      res.status >= 400 && res.status < 600 ? res.status : 502
    );
  }

  const txHash = parsed?.data?.hash || parsed?.hash;
  if (!txHash || typeof txHash !== 'string') {
    throw new PrivyApiError('Privy Wallet RPC did not return a transaction hash.', 502);
  }

  return {
    hash: txHash,
    chainId: prepared.chainId,
    networkKey: prepared.networkKey,
    networkName: prepared.networkName,
    explorerUrl: prepared.explorerUrl,
  };
}

const DISALLOWED_WALLET_ADDRESSES = new Set([
  '0x0000000000000000000000000000000000000000',
  '0x000000000000000000000000000000000000dead',
  '0xffffffffffffffffffffffffffffffffffffffff',
]);

function assertRealCandidateWalletAddress(raw: unknown): `0x${string}` {
  const addr = assertValidEvmAddress(raw, 'walletAddress');
  const lower = addr.toLowerCase();
  if (DISALLOWED_WALLET_ADDRESSES.has(lower) || /^0x([0-9a-f])\1{39}$/i.test(lower)) {
    throw new PrivyApiError('Zero, burn, or placeholder wallet addresses cannot be saved.', 400);
  }
  return getAddress(addr);
}

export async function verifyWalletOwnershipSignature(params: {
  address: unknown;
  message: unknown;
  signature: unknown;
}) {
  const checksummed = assertRealCandidateWalletAddress(params.address);
  const message = typeof params.message === 'string' ? params.message : '';
  const signature = typeof params.signature === 'string' ? params.signature.trim() : '';

  if (!message || !signature || !signature.startsWith('0x')) {
    throw new PrivyApiError('Wallet ownership signature is required.', 400);
  }

  let isValid = false;
  try {
    isValid = await verifyMessage({
      address: checksummed,
      message,
      signature: signature as `0x${string}`,
    });
  } catch {
    isValid = false;
  }

  if (!isValid) {
    throw new PrivyApiError('Cryptographic wallet signature verification failed.', 401);
  }

  return {
    verified: true,
    address: checksummed,
    verificationMethod: 'cryptographic_signature' as const,
  };
}

export async function verifyWalletAddressOnChain(params: {
  address: unknown;
  network?: unknown;
}) {
  const checksummed = assertRealCandidateWalletAddress(params.address);
  const preferredNet = params.network ? resolveNetwork(params.network) : resolveNetwork('ethereum');
  const networksToCheck = [
    preferredNet,
    ...SERVER_NETWORKS.filter((n) => n.key !== preferredNet.key),
  ];

  let totalTxCount = 0;
  let hasBalance = false;
  let isSmartContract = false;
  let reachableChains = 0;
  const activeNetworks: string[] = [];

  await Promise.all(
    networksToCheck.map(async (net) => {
      try {
        const client = createPublicClient({
          chain: net.chain,
          transport: http(net.rpcUrl, { timeout: 8_000 }),
        });

        const [bytecode, txCount, nativeBal] = await Promise.all([
          client.getBytecode({ address: checksummed }),
          client.getTransactionCount({ address: checksummed }),
          client.getBalance({ address: checksummed }),
        ]);

        reachableChains += 1;
        if (bytecode && bytecode !== '0x') {
          isSmartContract = true;
          return;
        }

        let chainHasTokenBal = false;
        for (const token of net.tokens) {
          if (!token.address) continue;
          try {
            const rawBal = await readErc20<bigint>(client, {
              address: token.address,
              functionName: 'balanceOf',
              args: [checksummed],
            });
            if (rawBal > 0n) {
              chainHasTokenBal = true;
              break;
            }
          } catch {
            // ignore token read failures
          }
        }

        totalTxCount += txCount;
        if (nativeBal > 0n || chainHasTokenBal || txCount > 0) {
          if (nativeBal > 0n || chainHasTokenBal) {
            hasBalance = true;
          }
          activeNetworks.push(net.name);
        }
      } catch {
        // continue checking other chains
      }
    })
  );

  if (isSmartContract) {
    throw new PrivyApiError(
      'This 0x address belongs to a smart contract, not a personal wallet address.',
      400
    );
  }

  if (reachableChains === 0) {
    throw new PrivyApiError(
      'Unable to reach blockchain networks right now to verify this wallet address. Please try again.',
      503
    );
  }

  if (totalTxCount === 0 && !hasBalance) {
    throw new PrivyApiError(
      'This wallet address has no verified on-chain existence (0 transactions and 0 balance on Ethereum, Base, Polygon, and Arbitrum). Only verified active wallets or signed browser wallets can be saved.',
      400
    );
  }

  return {
    verified: true,
    address: checksummed,
    txCount: totalTxCount,
    hasBalance,
    activeNetworks,
    verificationMethod: 'onchain_rpc' as const,
  };
}


