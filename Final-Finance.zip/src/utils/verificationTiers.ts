import { AuthSession, VerificationDetails, VerificationTier } from '../types/auth';

export const USER_VERIFICATION_TIERS_STORAGE_KEY = 'final_finance_user_verification_tiers_v1';
export const USER_VERIFICATION_UPDATED_EVENT = 'final_finance_verification_updated';

export interface VerificationTierMetadata {
  tier: 1 | 2 | 3;
  name: string;
  shortTitle: string;
  requirement: string;
  feeLabel: string;
  monthlyFee: number;
  permissionsSummary: string;
}

export const VERIFICATION_TIERS: VerificationTierMetadata[] = [
  {
    tier: 1,
    name: 'Tier 1 — Basic Legal ID',
    shortTitle: '1 Legal ID',
    requirement: '1 Verified Legal ID',
    feeLabel: 'Free ($0/mo)',
    monthlyFee: 0,
    permissionsSummary: 'Eligible to receive Admin Final Coins (AFNL) from Admin & claim AFNL grants/subsidies.'
  },
  {
    tier: 2,
    name: 'Tier 2 — Dual Legal ID',
    shortTitle: '2 Legal IDs',
    requirement: '2 Verified Legal IDs',
    feeLabel: 'Free ($0/mo)',
    monthlyFee: 0,
    permissionsSummary: 'Eligible to be a Driver, Retail Store Owner, or Restaurant Owner (plus all Tier 1 benefits).'
  },
  {
    tier: 3,
    name: 'Tier 3 — Verified User',
    shortTitle: '2 Legal IDs + $2/mo',
    requirement: '2 Verified Legal IDs + $2.00/month Subscription',
    feeLabel: '$2.00 / month',
    monthlyFee: 2,
    permissionsSummary: 'Full Verified User status & verified badge across the platform (plus all Tier 1 & Tier 2 benefits).'
  }
];

const BUILTIN_ADMIN_IDENTIFIERS = new Set([
  'super_admin_ranma',
  'demo-ranma-superadmin',
  'demo-super-admin',
  'ranmaanimaker@gmail.com',
  'officer_dbz',
  'demo-dbz-admin',
  'demo-admin-officer',
  'awesomedbz@gmail.com',
  'jordan_belfort',
  'demo-jordan-belfort',
  'jordan@finalfinance.io'
]);

const BUILTIN_TIER3_IDENTIFIERS = new Set([
  ...Array.from(BUILTIN_ADMIN_IDENTIFIERS),
  'satoshi_nakamoto',
  'demo-satoshi-nakamoto',
  'satoshi@finalfinance.io',
  'alex_morgan',
  'demo-alex-morgan',
  'alex@finalfinance.io',
  'sterling_vault',
  'user-lord_sterling',
  'elena_rostova',
  'user-elena_rostova',
  'marcus_vance',
  'user-marcus_vance'
]);

const BUILTIN_TIER0_IDENTIFIERS = new Set([
  'guest',
  'guest_trader',
  'demo-guest-trader',
  'guest@finalfinance.io'
]);

export function normalizeVerificationKey(val?: string | null): string {
  return (val || '').trim().toLowerCase().replace(/^@/, '');
}

export function isAdminOrSuperAdminUser(
  user?: { role?: string; id?: string; uid?: string; userId?: string; handle?: string; email?: string } | null
): boolean {
  if (!user) return false;
  if (user.role === 'admin' || user.role === 'super_admin') return true;
  const keys = [user.id, user.uid, user.userId, user.handle, user.email]
    .map(normalizeVerificationKey)
    .filter(Boolean);
  if (keys.some((k) => BUILTIN_ADMIN_IDENTIFIERS.has(k))) return true;

  try {
    const adminsRaw = localStorage.getItem('ff_admin_members_v1');
    if (adminsRaw) {
      const members = JSON.parse(adminsRaw);
      if (Array.isArray(members)) {
        const matched = members.some((m: any) => {
          if (m?.status === 'deactivated') return false;
          const mKeys = [m?.id, m?.handle, m?.email].map(normalizeVerificationKey).filter(Boolean);
          return mKeys.some((mk) => keys.includes(mk));
        });
        if (matched) return true;
      }
    }
  } catch {}

  try {
    const regRaw = localStorage.getItem('final_finance_registered_users');
    if (regRaw) {
      const regMap = JSON.parse(regRaw);
      for (const acc of Object.values<any>(regMap)) {
        if (acc?.role !== 'admin' && acc?.role !== 'super_admin') continue;
        const accKeys = [acc?.userId, acc?.email].map(normalizeVerificationKey).filter(Boolean);
        if (accKeys.some((ak) => keys.includes(ak))) return true;
      }
    }
  } catch {}

  return false;
}

export function getVerificationTierFromDetails(
  verification?: Partial<VerificationDetails> | null,
  fallbackIsVerified?: boolean
): VerificationTier {
  if (verification) {
    const hasDoc1 = Boolean(verification.idDocument1Type && verification.idDocument1Name);
    const hasDoc2 = Boolean(verification.idDocument2Type && verification.idDocument2Name);
    const now = Date.now();
    const expiresAt = verification.subscriptionExpiresAt ? new Date(verification.subscriptionExpiresAt).getTime() : 0;
    const hasUnexpiredWindow = Boolean(expiresAt && now < expiresAt);
    const hasActiveSub = Boolean(
      (verification.subscriptionActive || hasUnexpiredWindow) && Number(verification.monthlyFee ?? 0) >= 2
    );

    if (verification.tier === 3 || (hasDoc1 && hasDoc2 && hasActiveSub) || (verification.verified && (verification.subscriptionActive || hasUnexpiredWindow))) {
      return 3;
    }
    if (verification.tier === 2 || (hasDoc1 && hasDoc2)) {
      return 2;
    }
    if (verification.tier === 1 || hasDoc1) {
      return 1;
    }
    return 0;
  }

  if (fallbackIsVerified === true) {
    return 3;
  }
  return 0;
}

export function getUserVerificationTier(user?: AuthSession | null): VerificationTier {
  if (!user) return 0;

  // Admins and Super Admins do not need any tier verification to use platform features
  if (isAdminOrSuperAdminUser(user)) {
    return 3;
  }

  if (user.verification) {
    return getVerificationTierFromDetails(user.verification, user.isVerified);
  }

  const stored = getStoredVerificationForUser([user.id, user.uid, user.handle || '', user.email]);
  if (stored) {
    return getVerificationTierFromDetails(stored, user.isVerified);
  }

  const normKeys = [user.id, user.uid, user.handle, user.email].map(normalizeVerificationKey).filter(Boolean);
  if (normKeys.some((k) => BUILTIN_TIER0_IDENTIFIERS.has(k))) return 0;
  if (normKeys.some((k) => BUILTIN_TIER3_IDENTIFIERS.has(k))) return 3;

  return user.isVerified ? 3 : 0;
}

export function isTier3VerifiedUser(user?: AuthSession | null): boolean {
  return getUserVerificationTier(user) >= 3;
}

export function loadStoredVerificationMap(): Record<string, VerificationDetails> {
  try {
    const raw = localStorage.getItem(USER_VERIFICATION_TIERS_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {}
  return {};
}

export function getStoredVerificationForUser(identifiers: Array<string | undefined | null>): VerificationDetails | null {
  const map = loadStoredVerificationMap();
  for (const rawId of identifiers) {
    const norm = normalizeVerificationKey(rawId);
    if (!norm) continue;
    if (map[norm]) return map[norm];
    if (norm.startsWith('user-') && map[norm.slice(5)]) return map[norm.slice(5)];
    if (norm.startsWith('google-') && map[norm.slice(7)]) return map[norm.slice(7)];
    if (map[`user-${norm}`]) return map[`user-${norm}`];
  }
  return null;
}

export function saveStoredVerificationForUser(
  identifiers: Array<string | undefined | null>,
  details: VerificationDetails
): void {
  try {
    const map = loadStoredVerificationMap();
    identifiers.forEach((rawId) => {
      const norm = normalizeVerificationKey(rawId);
      if (!norm) return;
      map[norm] = details;
      if (norm.startsWith('user-')) map[norm.slice(5)] = details;
      if (norm.startsWith('google-')) map[norm.slice(7)] = details;
    });
    localStorage.setItem(USER_VERIFICATION_TIERS_STORAGE_KEY, JSON.stringify(map));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(USER_VERIFICATION_UPDATED_EVENT, { detail: { identifiers, details } }));
    }
  } catch {}
}

/**
 * Resolves the verification tier (0..3) of any target user in the platform
 * across stored tier records, registered users, current active session, and built-in demo profiles.
 */
export function resolveTargetUserVerificationTier(
  identifiers: Array<string | undefined | null>,
  fallback?: {
    verification?: VerificationDetails | null;
    isVerified?: boolean;
    role?: string;
  }
): VerificationTier {
  if (fallback?.role === 'admin' || fallback?.role === 'super_admin') {
    return 3;
  }

  const cleanKeys = new Set<string>();
  identifiers.forEach((id) => {
    const norm = normalizeVerificationKey(id);
    if (!norm) return;
    cleanKeys.add(norm);
    if (norm.startsWith('user-')) cleanKeys.add(norm.slice(5));
    if (norm.startsWith('google-')) cleanKeys.add(norm.slice(7));
    if (norm.startsWith('demo-')) cleanKeys.add(norm.slice(5));
  });

  for (const k of cleanKeys) {
    if (BUILTIN_ADMIN_IDENTIFIERS.has(k)) return 3;
  }

  // 1. Explicit stored tier record
  const stored = getStoredVerificationForUser(Array.from(cleanKeys));
  if (stored) {
    return getVerificationTierFromDetails(stored);
  }

  // 2. Current active session (if viewing self or matching user)
  try {
    const savedSession = localStorage.getItem('final_finance_auth_session');
    if (savedSession) {
      const sess: AuthSession = JSON.parse(savedSession);
      const sessKeys = [sess.id, sess.uid, sess.handle, sess.email].map(normalizeVerificationKey).filter(Boolean);
      if (sessKeys.some((k) => cleanKeys.has(k))) {
        return getUserVerificationTier(sess);
      }
    }
  } catch {}

  // 3. Registered users registry
  try {
    const regRaw = localStorage.getItem('final_finance_registered_users');
    if (regRaw) {
      const regMap = JSON.parse(regRaw);
      for (const acc of Object.values<any>(regMap)) {
        const accKeys = [acc?.userId, acc?.email].map(normalizeVerificationKey).filter(Boolean);
        if (accKeys.some((k) => cleanKeys.has(k))) {
          if (acc?.role === 'admin' || acc?.role === 'super_admin') {
            return 3;
          }
          if (acc?.verification) {
            return getVerificationTierFromDetails(acc.verification, acc.isVerified);
          }
          if (accKeys.some((k) => BUILTIN_TIER3_IDENTIFIERS.has(k))) {
            return 3;
          }
          return acc?.isVerified ? 3 : 0;
        }
      }
    }
  } catch {}

  // 4. Fallback verification details if provided
  if (fallback?.verification) {
    return getVerificationTierFromDetails(fallback.verification, fallback.isVerified);
  }

  // 5. Built-in demo/guest identities
  for (const k of cleanKeys) {
    if (BUILTIN_TIER0_IDENTIFIERS.has(k)) return 0;
  }
  for (const k of cleanKeys) {
    if (BUILTIN_TIER3_IDENTIFIERS.has(k)) return 3;
  }

  if (fallback?.isVerified === true) return 3;
  return 0;
}

export function getTierBadgeLabel(tier: VerificationTier): string {
  switch (tier) {
    case 3:
      return 'Tier 3 · Verified User ($2/mo)';
    case 2:
      return 'Tier 2 · 2 Legal IDs';
    case 1:
      return 'Tier 1 · 1 Legal ID';
    default:
      return 'Tier 0 · Unverified';
  }
}

export const CLAIMED_LEGAL_IDS_STORAGE_KEY = 'final_finance_claimed_legal_ids_v1';

export interface ClaimedLegalIdRecord {
  normalizedNumber: string;
  docType?: string;
  ownerKeys: string[];
  claimedAt: string;
}

export function normalizeLegalIdNumber(val?: string | null): string {
  return (val || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function expandOwnerKeys(identifiers: Array<string | undefined | null>): Set<string> {
  const keys = new Set<string>();
  identifiers.forEach((raw) => {
    const norm = normalizeVerificationKey(raw);
    if (!norm) return;
    keys.add(norm);
    if (norm.startsWith('user-')) keys.add(norm.slice(5));
    if (norm.startsWith('google-')) keys.add(norm.slice(7));
    if (norm.startsWith('demo-')) keys.add(norm.slice(5));
  });
  return keys;
}

function ownersOverlap(a: Set<string>, b: Set<string>): boolean {
  for (const k of a) {
    if (b.has(k)) return true;
  }
  return false;
}

const BUILTIN_CLAIMED_LEGAL_IDS: Array<{ idNumber: string; owners: string[] }> = [
  { idNumber: 'ID-KEY-001-ALPHA', owners: ['super_admin_ranma', 'demo-ranma-superadmin', 'ranmaanimaker@gmail.com'] },
  { idNumber: 'ID-DBZ-7789', owners: ['officer_dbz', 'demo-dbz-admin', 'awesomedbz@gmail.com'] },
  { idNumber: 'USA-94827103', owners: ['jordan_belfort', 'demo-jordan-belfort', 'jordan@finalfinance.io'] },
  { idNumber: 'JPN-88392019', owners: ['satoshi_nakamoto', 'demo-satoshi-nakamoto', 'satoshi@finalfinance.io'] },
  { idNumber: 'CHE-55419028', owners: ['alex_morgan', 'demo-alex-morgan', 'alex@finalfinance.io'] }
];

export function loadClaimedLegalIdsMap(): Record<string, ClaimedLegalIdRecord> {
  try {
    const raw = localStorage.getItem(CLAIMED_LEGAL_IDS_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {}
  return {};
}

export function checkLegalIdsDuplicateAcrossPlatform(params: {
  currentIdentifiers: Array<string | undefined | null>;
  doc1Number?: string;
  doc1Type?: string;
  doc2Number?: string;
  doc2Type?: string;
}): { isDuplicate: boolean; error?: string } {
  const normDoc1 = normalizeLegalIdNumber(params.doc1Number);
  const normDoc2 = normalizeLegalIdNumber(params.doc2Number);

  // Prevent using the exact same Legal ID twice on one submission
  if (normDoc1 && normDoc2 && normDoc1 === normDoc2) {
    return {
      isDuplicate: true,
      error: 'Legal ID #1 and Legal ID #2 cannot have the same ID number. Please provide two distinct Legal IDs.'
    };
  }

  const currentOwners = expandOwnerKeys(params.currentIdentifiers);
  const submittedIds = [normDoc1, normDoc2].filter(Boolean);
  if (submittedIds.length === 0) {
    return { isDuplicate: false };
  }

  const duplicateErrMsg =
    'Verification blocked: That user already exists in our platform. Each Legal ID can only be verified on one account — users cannot have multiple accounts.';

  // 1. Check dedicated claimed Legal IDs registry
  const claimedMap = loadClaimedLegalIdsMap();
  for (const idNorm of submittedIds) {
    const existing = claimedMap[idNorm];
    if (existing && Array.isArray(existing.ownerKeys)) {
      const existingOwners = expandOwnerKeys(existing.ownerKeys);
      if (!ownersOverlap(currentOwners, existingOwners)) {
        return { isDuplicate: true, error: duplicateErrMsg };
      }
    }
  }

  // 2. Check built-in verified accounts
  for (const builtin of BUILTIN_CLAIMED_LEGAL_IDS) {
    const builtinNorm = normalizeLegalIdNumber(builtin.idNumber);
    if (submittedIds.includes(builtinNorm)) {
      const builtinOwners = expandOwnerKeys(builtin.owners);
      if (!ownersOverlap(currentOwners, builtinOwners)) {
        return { isDuplicate: true, error: duplicateErrMsg };
      }
    }
  }

  // 3. Scan registered users registry
  try {
    const regRaw = localStorage.getItem('final_finance_registered_users');
    if (regRaw) {
      const regMap = JSON.parse(regRaw);
      for (const acc of Object.values<any>(regMap)) {
        const accOwners = expandOwnerKeys([acc?.userId, acc?.email]);
        if (ownersOverlap(currentOwners, accOwners)) continue;
        const accDoc1 = normalizeLegalIdNumber(acc?.verification?.idDocument1Number);
        const accDoc2 = normalizeLegalIdNumber(acc?.verification?.idDocument2Number);
        if ((accDoc1 && submittedIds.includes(accDoc1)) || (accDoc2 && submittedIds.includes(accDoc2))) {
          return { isDuplicate: true, error: duplicateErrMsg };
        }
      }
    }
  } catch {}

  // 4. Scan stored verification tier map
  try {
    const tiersMap = loadStoredVerificationMap();
    for (const [ownerKey, details] of Object.entries(tiersMap)) {
      const tierOwners = expandOwnerKeys([ownerKey]);
      if (ownersOverlap(currentOwners, tierOwners)) continue;
      const storedDoc1 = normalizeLegalIdNumber(details?.idDocument1Number);
      const storedDoc2 = normalizeLegalIdNumber(details?.idDocument2Number);
      if ((storedDoc1 && submittedIds.includes(storedDoc1)) || (storedDoc2 && submittedIds.includes(storedDoc2))) {
        return { isDuplicate: true, error: duplicateErrMsg };
      }
    }
  } catch {}

  return { isDuplicate: false };
}

export function registerClaimedLegalIdsForUser(
  identifiers: Array<string | undefined | null>,
  details: Pick<VerificationDetails, 'idDocument1Number' | 'idDocument1Type' | 'idDocument2Number' | 'idDocument2Type'>
): void {
  try {
    const map = loadClaimedLegalIdsMap();
    const ownerKeys = Array.from(expandOwnerKeys(identifiers));
    const now = new Date().toISOString();

    const d1 = normalizeLegalIdNumber(details.idDocument1Number);
    if (d1) {
      map[d1] = {
        normalizedNumber: d1,
        docType: details.idDocument1Type,
        ownerKeys,
        claimedAt: now
      };
    }

    const d2 = normalizeLegalIdNumber(details.idDocument2Number);
    if (d2) {
      map[d2] = {
        normalizedNumber: d2,
        docType: details.idDocument2Type,
        ownerKeys,
        claimedAt: now
      };
    }

    localStorage.setItem(CLAIMED_LEGAL_IDS_STORAGE_KEY, JSON.stringify(map));
  } catch {}
}

export function releaseClaimedLegalIdsForUser(identifiers: Array<string | undefined | null>): void {
  try {
    const targetOwners = expandOwnerKeys(identifiers);
    const map = loadClaimedLegalIdsMap();
    let changed = false;
    for (const [idNorm, rec] of Object.entries(map)) {
      const recOwners = expandOwnerKeys(rec?.ownerKeys || []);
      if (ownersOverlap(targetOwners, recOwners)) {
        delete map[idNorm];
        changed = true;
      }
    }
    if (changed) {
      localStorage.setItem(CLAIMED_LEGAL_IDS_STORAGE_KEY, JSON.stringify(map));
    }

    const tiersMap = loadStoredVerificationMap();
    let tiersChanged = false;
    for (const key of Object.keys(tiersMap)) {
      if (targetOwners.has(normalizeVerificationKey(key))) {
        delete tiersMap[key];
        tiersChanged = true;
      }
    }
    if (tiersChanged) {
      localStorage.setItem(USER_VERIFICATION_TIERS_STORAGE_KEY, JSON.stringify(tiersMap));
    }
  } catch {}
}
