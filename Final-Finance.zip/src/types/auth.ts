export type VerificationTier = 0 | 1 | 2 | 3;

export interface VerificationDetails {
  tier?: VerificationTier; // 0 = Unverified, 1 = 1 Legal ID, 2 = 2 Legal IDs, 3 = 2 Legal IDs + $2/mo
  verified: boolean; // true ONLY at Tier 3
  status: 'unverified' | 'tier1' | 'tier2' | 'pending' | 'verified';
  monthlyFee: number; // 0 for Tier 1/2, 2 ($2/month) for Tier 3
  subscriptionActive: boolean; // true ONLY at Tier 3
  subscriptionPlan: string;
  idDocument1Type: string;
  idDocument1Name: string;
  idDocument1Number?: string;
  idDocument2Type: string;
  idDocument2Name: string;
  idDocument2Number?: string;
  idDocument2Issuer?: string;
  verifiedAt?: string;
  nextBillingDate?: string;
  subscriptionCancelled?: boolean;
  subscriptionExpiresAt?: string;
  paymentMethod?: string;
  lastFour?: string;
}

export interface AuthSession {
  uid: string;
  id: string; // handle / username (e.g. 'marcus_vance')
  userId?: string;
  handle?: string;
  username?: string;
  name: string;
  email: string;
  avatarUrl?: string;
  coverUrl?: string;
  bio?: string;
  gender?: 'male' | 'female' | 'other' | '';
  role: 'super_admin' | 'admin' | 'vip_user' | 'user' | 'guest';
  provider: 'google' | 'password' | 'demo';
  authMethod?: string;
  subscriptionActive?: boolean;
  createdAt?: string;
  isVerified?: boolean;
  isPrivate?: boolean;
  verification?: VerificationDetails;
  user?: {
    name: string;
    email: string;
    avatar?: string;
  };
}

