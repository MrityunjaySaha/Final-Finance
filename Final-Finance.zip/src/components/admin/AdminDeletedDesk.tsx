import React, { useState, useEffect } from 'react';
import { Search, Trash2, Users, Check, Mail, Clock } from 'lucide-react';
import {
  ACCOUNT_STATUS_UPDATED_EVENT,
  DeletedAccountRecord,
  getDeletedAccounts,
} from '../../utils/accountStatusStorage';
import { maskProtectedEmailForViewer, isEmailSearchableForViewer } from '../../utils/privacyShield';

export const AdminDeletedDesk: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [deletedUsers, setDeletedUsers] = useState<DeletedAccountRecord[]>(() =>
    getDeletedAccounts('user')
  );

  useEffect(() => {
    const refresh = () => {
      setDeletedUsers(getDeletedAccounts('user'));
    };
    refresh();
    window.addEventListener(ACCOUNT_STATUS_UPDATED_EVENT, refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener(ACCOUNT_STATUS_UPDATED_EVENT, refresh);
      window.removeEventListener('storage', refresh);
    };
  }, []);

  const filtered = deletedUsers.filter((u) => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return true;
    return (
      u.name.toLowerCase().includes(q) ||
      u.userId.toLowerCase().includes(q) ||
      (u.email && isEmailSearchableForViewer(u.email) && u.email.toLowerCase().includes(q))
    );
  });

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden text-center">
      <div className="p-6 border-b border-slate-100 flex flex-col items-center justify-center text-center gap-4 bg-white">
        <div className="flex items-center justify-center gap-2 flex-wrap">
          <h2 className="font-serif text-xl font-bold text-slate-900 text-center">
            Deleted User Accounts
          </h2>
          <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-xs font-bold font-mono">
            Total: {deletedUsers.length}
          </span>
        </div>

        {/* Real-time search filter */}
        <div className="relative w-full max-w-sm mx-auto">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search deleted user accounts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 text-center focus:outline-none focus:ring-2 focus:ring-rose-500"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center mx-auto mb-3.5 border border-slate-200">
              <Check className="w-6 h-6 text-emerald-600" />
            </div>
            <h3 className="font-serif text-sm font-bold text-slate-950">No Deleted Accounts</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              {deletedUsers.length === 0
                ? 'No user accounts have been permanently deleted from Settings yet.'
                : 'No deleted accounts match your current search query.'}
            </p>
          </div>
        ) : (
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-slate-500 uppercase bg-slate-50/50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">Deleted Profile</th>
                <th className="px-6 py-4">System Role</th>
                <th className="px-6 py-4">Deleted On</th>
                <th className="px-6 py-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {user.avatarUrl ? (
                        <img
                          src={user.avatarUrl}
                          alt={user.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0 grayscale opacity-80"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 border border-slate-200 shrink-0">
                          <Users className="w-5 h-5" />
                        </div>
                      )}
                      <div>
                        <div className="font-bold text-slate-900 text-left">{user.name}</div>
                        <div className="text-xs text-slate-400 font-mono">@{user.userId}</div>
                        {user.email && (
                          <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                            <Mail className="w-3 h-3 text-slate-400" />
                            <span>{maskProtectedEmailForViewer(user.email)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider font-mono border bg-slate-100 text-slate-600 border-slate-200">
                      {user.role}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1 text-xs text-slate-600 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{new Date(user.deletedAt).toLocaleString()}</span>
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 border border-rose-200 text-rose-800">
                      <Trash2 className="w-3 h-3 text-rose-500 shrink-0" />
                      <span>DELETED BY USER</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
