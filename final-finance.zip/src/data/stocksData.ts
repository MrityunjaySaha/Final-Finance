import { 
  StockItem, 
  StockOrder,
  MarketIndex, 
  StockNewsItem, 
  StockPosition, 
  StockMarketWay, 
  IPORequest, 
  IPOType, 
  IPOStatus, 
  FiveModeNetWorth, 
  BusinessDetails, 
  PersonalDetails 
} from '../types/stocks';

export interface MarketWayInfo {
  id: StockMarketWay;
  title: string;
  shortName: string;
  badge: string;
  tagline: string;
  description: string;
  settlementVault: string;
  settlementCurrency: string;
  tradingHours: string;
  clearingSpeed: string;
  liquidity: string;
  activeVolume24h: string;
  totalMarketCap: string;
  themeColor: {
    badgeBg: string;
    badgeText: string;
    badgeBorder: string;
    activeTabBg: string;
    accent: string;
  };
}

export const STOCK_MARKET_WAYS: MarketWayInfo[] = [
  {
    id: 'final',
    title: 'Final Stock Market',
    shortName: 'Final Market',
    badge: '⚡ Sovereign & Vault Backed',
    tagline: 'Sovereign Network Assets, AFNL & Allocated Vault Denominated Equities',
    description: 'Personal human capital equities and enterprise energy & infrastructure trusts issued through platform IPOs and cleared on Final Network Sovereign Nodes.',
    settlementVault: 'Final Coins & Sovereign Vaults',
    settlementCurrency: 'AFNL / AFNL / Sovereign Gold / Vault Tokens',
    tradingHours: '24/7/365 Continuous Clearing',
    clearingSpeed: 'Instant 0-Block Settlement',
    liquidity: '$18.4B Active Sovereign Depth',
    activeVolume24h: '$1.42B',
    totalMarketCap: '$148.5B',
    themeColor: {
      badgeBg: 'bg-amber-500/10',
      badgeText: 'text-amber-700 dark:text-amber-400',
      badgeBorder: 'border-amber-500/30',
      activeTabBg: 'bg-amber-500 text-slate-950',
      accent: 'amber'
    }
  },
  {
    id: 'stable',
    title: 'Stable Stock Market',
    shortName: 'Stable Market',
    badge: '🛡️ Yields, Treasuries & Defensive',
    tagline: 'Yield-Generating Treasury Trusts, Longevity AG & Defensive Business Stocks',
    description: 'Platform-issued corporate equities and yield-generating sovereign treasury trusts settled with 1:1 USD Stablecoins.',
    settlementVault: 'Stablecoins Reserve Vault',
    settlementCurrency: 'USDC / USDT / USD Pegged Stablecoins',
    tradingHours: '24/7 Digital Liquidity Bridge',
    clearingSpeed: 'Sub-second Digital Wire',
    liquidity: '$42.8B Institutional Liquidity',
    activeVolume24h: '$3.85B',
    totalMarketCap: '$2.15T',
    themeColor: {
      badgeBg: 'bg-emerald-500/10',
      badgeText: 'text-emerald-700 dark:text-emerald-400',
      badgeBorder: 'border-emerald-500/30',
      activeTabBg: 'bg-emerald-600 text-white',
      accent: 'emerald'
    }
  },
  {
    id: 'fiat',
    title: 'Fiat Stock Market',
    shortName: 'Fiat Market',
    badge: '🏛️ Verified Enterprise IPOs',
    tagline: 'Platform-Issued Sovereign Robotics & Aerospace Corporations',
    description: 'Corporate business stock IPOs issued with verified Delaware and global legal structures, settled natively in Fiat USD.',
    settlementVault: 'Fiat Cash & Central Banking Reserves',
    settlementCurrency: 'USD Fiat (Fedwire / ACH / Direct Clearing)',
    tradingHours: '9:30 AM - 4:00 PM EST (+ Extended 24/7 internal clearing)',
    clearingSpeed: 'T+0 Instant Internal',
    liquidity: '$120B+ Deep Market Book',
    activeVolume24h: '$24.6B',
    totalMarketCap: '$46.8T',
    themeColor: {
      badgeBg: 'bg-indigo-500/10',
      badgeText: 'text-indigo-700 dark:text-indigo-400',
      badgeBorder: 'border-indigo-500/30',
      activeTabBg: 'bg-slate-900 text-white',
      accent: 'indigo'
    }
  },
  {
    id: 'crypto',
    title: 'Cryptocurrency Stock Market',
    shortName: 'Crypto Market',
    badge: '⛓️ Decentralized Protocol IPOs',
    tagline: 'Microgrid Protocols, Quantum Compute Trusts & Crypto-Native Equities',
    description: 'Platform-issued decentralized infrastructure and quantum cryptography business stocks settled in native crypto and multi-chain assets.',
    settlementVault: 'Multi-Chain Crypto & Web3 Custody',
    settlementCurrency: 'BTC / BTC / ETH / SOL Native Assets',
    tradingHours: '24/7/365 Non-Stop Global Trading',
    clearingSpeed: 'On-Chain Verified Settlement',
    liquidity: '$28.5B High-Frequency Depth',
    activeVolume24h: '$6.90B',
    totalMarketCap: '$1.85T',
    themeColor: {
      badgeBg: 'bg-purple-500/10',
      badgeText: 'text-purple-700 dark:text-purple-400',
      badgeBorder: 'border-purple-500/30',
      activeTabBg: 'bg-purple-600 text-white',
      accent: 'purple'
    }
  },
  {
    id: 'global',
    title: 'Global Stock Market',
    shortName: 'Global Market',
    badge: '🌍 Alpaca Unified Equities',
    tagline: 'Standard US Equities & Global Assets via Alpaca Securities',
    description: 'Unified access to US-listed stocks, ETFs, and institutional assets through the Alpaca Brokerage API with real-time institutional pricing.',
    settlementVault: 'Fiat USD & Alpaca Clearing',
    settlementCurrency: 'USD Fiat',
    tradingHours: '9:30 AM - 4:00 PM EST (US Regular Session)',
    clearingSpeed: 'T+2 Standard / Instant Margin',
    liquidity: 'Deep Global Public Exchange Liquidity',
    activeVolume24h: '$480B+',
    totalMarketCap: '$52T+',
    themeColor: {
      badgeBg: 'bg-sky-500/10',
      badgeText: 'text-sky-700 dark:text-sky-400',
      badgeBorder: 'border-sky-500/30',
      activeTabBg: 'bg-sky-600 text-white',
      accent: 'sky'
    }
  }
];

// Helper to generate realistic timeframe history curves
function generateHistory(basePrice: number, volatility = 0.015) {
  const result: StockItem['history'] = {
    '1D': [],
    '1W': [],
    '1M': [],
    '1Y': [],
    '5Y': []
  };

  // 1D: 78 points
  let p = basePrice * 0.992;
  const times1D = [
    '09:30 AM', '09:45 AM', '10:00 AM', '10:15 AM', '10:30 AM', '10:45 AM',
    '11:00 AM', '11:15 AM', '11:30 AM', '11:45 AM', '12:00 PM', '12:15 PM',
    '12:30 PM', '12:45 PM', '01:00 PM', '01:15 PM', '01:30 PM', '01:45 PM',
    '02:00 PM', '02:15 PM', '02:30 PM', '02:45 PM', '03:00 PM', '03:15 PM',
    '03:30 PM', '03:45 PM', '04:00 PM'
  ];
  times1D.forEach((t, i) => {
    const step = (Math.sin(i * 0.4) * 0.005 + (Math.random() - 0.47) * volatility);
    p = Math.max(p * 0.9, p * (1 + step));
    if (i === times1D.length - 1) p = basePrice;
    result['1D'].push({
      time: t,
      price: Number(p.toFixed(2)),
      volume: Math.floor(150000 + Math.random() * 850000),
      open: Number((p * 0.998).toFixed(2)),
      high: Number((p * 1.004).toFixed(2)),
      low: Number((p * 0.995).toFixed(2)),
      close: Number(p.toFixed(2))
    });
  });

  // 1W: 35 points
  const days1W = ['Mon 09:30', 'Mon 01:00', 'Tue 09:30', 'Tue 01:00', 'Wed 09:30', 'Wed 01:00', 'Thu 09:30', 'Thu 01:00', 'Fri 09:30', 'Fri 04:00'];
  let pw = basePrice * 0.965;
  days1W.forEach((t, i) => {
    const step = (Math.cos(i * 0.6) * 0.008 + (Math.random() - 0.46) * 0.02);
    pw = Math.max(pw * 0.85, pw * (1 + step));
    if (i === days1W.length - 1) pw = basePrice;
    result['1W'].push({
      time: t,
      price: Number(pw.toFixed(2)),
      volume: Math.floor(1200000 + Math.random() * 3500000),
      open: Number((pw * 0.995).toFixed(2)),
      high: Number((pw * 1.008).toFixed(2)),
      low: Number((pw * 0.991).toFixed(2)),
      close: Number(pw.toFixed(2))
    });
  });

  // 1M: 30 days
  let pm = basePrice * 0.91;
  for (let i = 1; i <= 22; i++) {
    const step = (Math.sin(i * 0.3) * 0.01 + (Math.random() - 0.45) * 0.022);
    pm = Math.max(pm * 0.8, pm * (1 + step));
    if (i === 22) pm = basePrice;
    result['1M'].push({
      time: `Day ${i}`,
      price: Number(pm.toFixed(2)),
      volume: Math.floor(5000000 + Math.random() * 12000000)
    });
  }

  // 1Y: 12 months
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  let py = basePrice * 0.72;
  months.forEach((m, i) => {
    const step = (0.025 + Math.sin(i * 0.5) * 0.02 + (Math.random() - 0.4) * 0.035);
    py = py * (1 + step);
    if (i === months.length - 1) py = basePrice;
    result['1Y'].push({
      time: m,
      price: Number(py.toFixed(2)),
      volume: Math.floor(25000000 + Math.random() * 50000000)
    });
  });

  // 5Y: 5 years
  const years = ['2022', '2023', '2024', '2025', '2026'];
  let p5 = basePrice * 0.38;
  years.forEach((y, i) => {
    const step = 0.28 + (Math.random() - 0.3) * 0.15;
    p5 = p5 * (1 + step);
    if (i === years.length - 1) p5 = basePrice;
    result['5Y'].push({
      time: y,
      price: Number(p5.toFixed(2)),
      volume: Math.floor(100000000 + Math.random() * 250000000)
    });
  });

  return result;
}

export const MARKET_INDICES: MarketIndex[] = [
  {
    symbol: 'SOV-COMP',
    name: 'Sovereign Stock Composite Index',
    value: 6420.50,
    change: 68.40,
    changePercent: 1.08,
    sparkline: [6320, 6345, 6380, 6365, 6400, 6415, 6420.50]
  },
  {
    symbol: 'HUMAN-EQ',
    name: 'Personal Human Capital Index',
    value: 2840.25,
    change: 45.80,
    changePercent: 1.64,
    sparkline: [2780, 2795, 2815, 2800, 2825, 2835, 2840.25]
  },
  {
    symbol: 'CORP-IPO',
    name: 'Enterprise Business IPO Index',
    value: 4890.10,
    change: 52.30,
    changePercent: 1.08,
    sparkline: [4820, 4840, 4865, 4850, 4875, 4885, 4890.10]
  },
  {
    symbol: 'AFNL-VAULT',
    name: 'Final Multi-Vault Settlement Index',
    value: 14820.50,
    change: 212.40,
    changePercent: 1.45,
    sparkline: [14550, 14620, 14690, 14660, 14750, 14790, 14820.50]
  }
];

export const MARKET_WAY_INDICES: Record<StockMarketWay, MarketIndex[]> = {
  final: [
    {
      symbol: 'AFNL-COMP',
      name: 'Final Sovereign Composite Index',
      value: 14820.50,
      change: 212.40,
      changePercent: 1.45,
      sparkline: [14550, 14620, 14690, 14660, 14750, 14790, 14820.50]
    },
    {
      symbol: 'HUMAN-50',
      name: 'Sovereign Personal Human Equities',
      value: 2840.25,
      change: 45.80,
      changePercent: 1.64,
      sparkline: [2780, 2795, 2815, 2800, 2825, 2835, 2840.25]
    },
    {
      symbol: 'CLEAN-FUS',
      name: 'Clean Fusion & Energy Trust Index',
      value: 4180.20,
      change: 38.10,
      changePercent: 0.92,
      sparkline: [4120, 4135, 4150, 4145, 4165, 4172, 4180.20]
    }
  ],
  stable: [
    {
      symbol: 'VAULT-YLD',
      name: 'Global Vault Yield Benchmark',
      value: 3892.40,
      change: 16.30,
      changePercent: 0.42,
      sparkline: [3865, 3872, 3880, 3876, 3888, 3890, 3892.40]
    },
    {
      symbol: 'BIO-LONGEV',
      name: 'Longevity Therapeutics Index',
      value: 2410.15,
      change: 24.60,
      changePercent: 1.03,
      sparkline: [2380, 2390, 2400, 2395, 2405, 2408, 2410.15]
    }
  ],
  fiat: [
    {
      symbol: 'ROBOT-50',
      name: 'Sovereign Robotics & AI Enterprise Index',
      value: 5120.40,
      change: 72.30,
      changePercent: 1.43,
      sparkline: [5020, 5050, 5080, 5070, 5105, 5115, 5120.40]
    },
    {
      symbol: 'HYPERS-IND',
      name: 'Hypersonic Aerospace Enterprise Benchmark',
      value: 3640.80,
      change: 28.50,
      changePercent: 0.79,
      sparkline: [3600, 3615, 3630, 3625, 3635, 3638, 3640.80]
    }
  ],
  crypto: [
    {
      symbol: 'MICRO-GRID',
      name: 'Microgrid Energy Settlement Index',
      value: 1940.50,
      change: 32.20,
      changePercent: 1.69,
      sparkline: [1900, 1915, 1930, 1925, 1935, 1938, 1940.50]
    },
    {
      symbol: 'Q-CRYPTO',
      name: 'Quantum Cryptography & Compute Trust Index',
      value: 2680.10,
      change: 41.50,
      changePercent: 1.57,
      sparkline: [2620, 2640, 2660, 2650, 2670, 2675, 2680.10]
    }
  ],
  global: []
};

// ============================================================================
// INITIAL PUBLIC OFFERINGS (IPO) - PLATFORM-ISSUED PERSONAL & BUSINESS REGISTRY
// ============================================================================

export const INITIAL_IPO_REQUESTS: IPORequest[] = [
  // 1. PERSONAL STOCK IPOs
  {
    id: 'ipo_personal_alex_chen',
    ipoType: 'personal',
    ticker: 'ALEX',
    equityName: 'Alex Chen Sovereign Human Equity',
    issuerId: 'creator_alex_chen',
    issuerName: 'Alex Chen',
    issuerHandle: 'alex_chen',
    issuerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 1000000,
    offeringPriceUSD: 25.00,
    targetValuationUSD: 25000000,
    circulatingFloat: 450000,
    submittedAt: '2026-02-10T14:30:00Z',
    reviewedAt: '2026-02-11T09:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Swiss verified biometric credentials, multi-asset 5-mode solvency validated at $25.0M NAV, sovereign personality index approved.',
    personalDetails: {
      fullName: 'Alex Chen',
      handle: '@alex_chen',
      profession: 'Quantitative System Architect & AI Research Fellow',
      personaProfile: 'Deep-tech researcher with 12+ years pioneering zero-knowledge machine learning verifiers and high-frequency algorithmic liquidity engines.',
      personalityTraits: [
        'Visionary Architect',
        'Algorithmic Strategist',
        'High-Conviction Builder',
        'Mathematical Purist',
        'Decentralized Sovereign'
      ],
      keyAchievements: 'Engineered zero-knowledge settlement bridge clearing $4.2B volume; author of 6 peer-reviewed decentralized finance mechanisms; advisor to tier-1 decentralized liquidity vaults.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 2450000,
        sovereignGoldBarter: 3800000,
        finalCoins: 8500000,
        stableCoins: 4250000,
        cryptoAssets: 6000000,
        totalNetWorthUSD: 25000000
      },
      valuationRationale: 'Directly collateralized against verified 5-mode net worth ($25M NAV) combined with projected sovereign IP licensing royalties and high-throughput research outputs.',
      personalMission: 'To build uncompromised sovereign financial rails accessible globally with mathematical zero-knowledge guarantees.',
      mediaGallery: [
        {
          id: 'med_alex_1',
          type: 'photo',
          url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
          title: 'Executive Sovereign Portrait',
          description: 'Official verified identity portrait for Swiss Biometric Registry.',
          uploadedAt: '2026-02-10T14:35:00Z',
          isCover: true
        }
      ]
    },
    mediaGallery: [
      {
        id: 'med_alex_1',
        type: 'photo',
        url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
        title: 'Executive Sovereign Portrait',
        description: 'Official verified identity portrait for Swiss Biometric Registry.',
        uploadedAt: '2026-02-10T14:35:00Z',
        isCover: true
      }
    ]
  },
  {
    id: 'ipo_personal_satoshi',
    ipoType: 'personal',
    ticker: 'SATO',
    equityName: 'Satoshi Nakamoto Sovereign Human Equity',
    issuerId: 'creator_satoshi',
    issuerName: 'Satoshi Nakamoto',
    issuerHandle: 'satoshi_nakamoto',
    issuerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 2100000,
    offeringPriceUSD: 100.00,
    targetValuationUSD: 210000000,
    circulatingFloat: 600000,
    submittedAt: '2026-01-03T09:00:00Z',
    reviewedAt: '2026-01-04T12:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Cryptographic genesis signatures verified against early sovereign blocks, multi-vault proof of reserves validated.',
    personalDetails: {
      fullName: 'Satoshi Nakamoto',
      handle: '@satoshi_nakamoto',
      profession: 'Pioneer of Sovereign Digital Cash & Cryptographic Architecture',
      personaProfile: 'Architect of decentralized peer-to-peer settlement infrastructure, mathematical consensus engines, and trust-minimized economic systems.',
      personalityTraits: [
        'Cypherpunk Philosopher',
        'Cryptographic Architect',
        'Consensus Engineer',
        'Economic Visionary'
      ],
      keyAchievements: 'Designed the world’s first decentralized digital currency architecture; authored immutable proof-of-work consensus mechanism.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 10000000,
        sovereignGoldBarter: 50000000,
        finalCoins: 80000000,
        stableCoins: 20000000,
        cryptoAssets: 50000000,
        totalNetWorthUSD: 210000000
      },
      valuationRationale: 'Directly supported by multi-vault reserve collateral and foundational sovereign protocol patent dedications.',
      personalMission: 'A purely peer-to-peer version of electronic cash allowing direct payments without financial intermediaries.',
      mediaGallery: [
        {
          id: 'med_sato_1',
          type: 'photo',
          url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80',
          title: 'Genesis Sovereign Portrait',
          description: 'Verified public persona identity portrait.',
          uploadedAt: '2026-01-03T09:15:00Z',
          isCover: true
        }
      ]
    }
  },
  {
    id: 'ipo_personal_elena_rostova',
    ipoType: 'personal',
    ticker: 'ELEN',
    equityName: 'Dr. Elena Rostova Plasma Physics Equity',
    issuerId: 'creator_elena_rostova',
    issuerName: 'Dr. Elena Rostova',
    issuerHandle: 'elena_rostova',
    issuerAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 1500000,
    offeringPriceUSD: 20.00,
    targetValuationUSD: 30000000,
    circulatingFloat: 500000,
    submittedAt: '2026-02-01T10:00:00Z',
    reviewedAt: '2026-02-02T14:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Plasma physics patents and Zurich research lab equity validated.',
    personalDetails: {
      fullName: 'Dr. Elena Rostova',
      handle: '@elena_rostova',
      profession: 'Lead Plasma Magnetics Researcher & Fusion Systems Architect',
      personaProfile: 'Pioneered high-temperature superconducting containment geometries with record-setting Q-plasma confinement stability.',
      personalityTraits: ['Quantum Physicist', 'Precision Engineer', 'Clean Energy Innovator'],
      keyAchievements: 'Published 18 papers on magnetohydrodynamic simulation; coinventor of Generation-3 Tokamak containment ring.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 3000000,
        sovereignGoldBarter: 5000000,
        finalCoins: 12000000,
        stableCoins: 4000000,
        cryptoAssets: 6000000,
        totalNetWorthUSD: 30000000
      },
      valuationRationale: 'Backing backed by fusion patent licensing stream and sovereign research royalties.',
      personalMission: 'To unlock inexhaustible commercial fusion energy for every sovereign node.'
    }
  },
  {
    id: 'ipo_personal_lord_sterling',
    ipoType: 'personal',
    ticker: 'STRL',
    equityName: 'Lord Sterling Swiss Vault Sovereign Equity',
    issuerId: 'creator_lord_sterling',
    issuerName: 'Lord Sterling',
    issuerHandle: 'sterling_vault',
    issuerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 1200000,
    offeringPriceUSD: 35.00,
    targetValuationUSD: 42000000,
    circulatingFloat: 350000,
    submittedAt: '2026-01-15T11:00:00Z',
    reviewedAt: '2026-01-16T15:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Swiss Freeport gold custody allocations and private trustee syndicate assets audited at $42.0M NAV.',
    personalDetails: {
      fullName: 'Lord Sterling',
      handle: '@sterling_vault',
      profession: 'Swiss Freeport Trustee & Sovereign Custody Syndicate Lead',
      personaProfile: 'Veteran allocator managing sovereign multi-vault physical gold reserves and high-security depository settlement corridors.',
      personalityTraits: ['Swiss Trustee', 'Gold Standard Allocator', 'Risk Sentinel'],
      keyAchievements: 'Oversaw $1.8B in allocated gold bullion custody across Zurich and Geneva freeports.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 5000000,
        sovereignGoldBarter: 22000000,
        finalCoins: 8000000,
        stableCoins: 4000000,
        cryptoAssets: 3000000,
        totalNetWorthUSD: 42000000
      },
      valuationRationale: 'Direct physical bullion reserve custody backing combined with trustee syndicate cashflow yields.',
      personalMission: 'To restore gold-backed sovereign solvency and immutable multi-vault safety.'
    }
  },

  // 2. BUSINESS STOCK IPOs
  {
    id: 'ipo_business_hyperion_fusion',
    ipoType: 'business',
    ticker: 'HYPR',
    equityName: 'Hyperion Quantum Fusion Dynamics Inc.',
    issuerId: 'creator_marcus_vance',
    issuerName: 'Dr. Marcus Vance',
    issuerHandle: 'marcus_vance',
    issuerAvatar: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 10000000,
    offeringPriceUSD: 48.50,
    targetValuationUSD: 485000000,
    circulatingFloat: 2400000,
    submittedAt: '2026-02-14T11:00:00Z',
    reviewedAt: '2026-02-15T16:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Delaware C-Corp certification verified, USPTO patent portfolio cleared, reserve backing audited in sovereign vault tokens.',
    businessDetails: {
      companyName: 'Hyperion Quantum Fusion Dynamics Inc.',
      legalStructure: 'Delaware C-Corporation (Public Tier)',
      sector: 'Energy & Aerospace',
      industry: 'Magnetohydrodynamic Clean Energy & Superconducting Generators',
      registrationNumber: 'EIN-84-9921448',
      jurisdiction: 'Wilmington, Delaware, USA',
      foundedYear: 2022,
      headquarters: 'Austin, Texas & Zurich R&D Annex',
      employeeCount: '84 Full-Time Engineers & Physicists',
      website: 'https://hyperionfusion.tech',
      businessModel: 'Design, manufacturing, and grid-licensing of modular high-temperature superconducting tokamak power generators.',
      valueProposition: 'Zero-carbon continuous baseload power generation at $0.024/kWh with proprietary magnetic plasma containment.',
      annualRevenueUSD: 42000000,
      netProfitMarginPercent: 28.5,
      projectedGrowthPercent: 140,
      executives: {
        ceo: 'Dr. Marcus Vance (Founder & Chief Scientist)',
        cto: 'Elena Rostova, Ph.D. (Plasma Magnetics)',
        cfo: 'Julian Thorne (ex-Goldman Energy Partner)'
      },
      backingCoinId: 'admin_final_coin_master',
      backingCoinSymbol: 'AFNL',
      backingCoinType: 'final_coin',
      backingCoinName: 'Final Admin Coin',
      useOfProceeds: 'Expansion of Generation-3 Tokamak fabrication facility in Austin, Texas ($120M) and global commercial grid certification.'
    }
  },
  {
    id: 'ipo_business_final_treasury',
    ipoType: 'business',
    ticker: 'AFNL-EQ',
    equityName: 'Final Network Treasury Equity',
    issuerId: 'foundation_final',
    issuerName: 'Final Network Sovereign Foundation',
    issuerHandle: 'final_foundation',
    issuerAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 15000000,
    offeringPriceUSD: 300.00,
    targetValuationUSD: 4500000000,
    circulatingFloat: 3500000,
    submittedAt: '2026-01-01T00:00:00Z',
    reviewedAt: '2026-01-02T00:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Sovereign Clearing Foundation charter verified, multi-vault liquidity depth cleared.',
    businessDetails: {
      companyName: 'Final Network Treasury Equity',
      legalStructure: 'Sovereign Foundation Trust (Zug, Switzerland)',
      sector: 'Sovereign Reserves',
      industry: 'Sovereign Clearing Infrastructure & Multi-Vault Liquidity Pools',
      registrationNumber: 'CHE-918.234.110',
      jurisdiction: 'Zug, Switzerland',
      foundedYear: 2024,
      headquarters: 'Crypto Valley, Zug, Switzerland',
      employeeCount: '120 Distributed Protocol Engineers',
      website: 'https://finalnetwork.io',
      businessModel: 'Zero-debt multi-vault transaction clearing fees and sovereign liquidity node staking rewards.',
      valueProposition: 'Decentralized institutional settlement layer clearing over $18.4B in asset reserves with 0-block finality.',
      annualRevenueUSD: 185000000,
      netProfitMarginPercent: 42.0,
      projectedGrowthPercent: 85,
      executives: {
        ceo: 'Sovereign Foundation Governance Board',
        cto: 'Alex Chen (Principal System Architect)',
        cfo: 'Lord Sterling (Trustee Chair)'
      },
      backingCoinId: 'admin_final_coin_master',
      backingCoinSymbol: 'AFNL',
      backingCoinType: 'final_coin',
      backingCoinName: 'Final Admin Coin',
      useOfProceeds: 'Multi-vault liquidity depth expansion and global settlement node distribution.'
    }
  },
  {
    id: 'ipo_business_bio_synth',
    ipoType: 'business',
    ticker: 'BSYN',
    equityName: 'BioSynthetica Genomics International AG',
    issuerId: 'creator_dr_reed',
    issuerName: 'Dr. Evelyn Reed',
    issuerHandle: 'evelyn_reed',
    issuerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 5000000,
    offeringPriceUSD: 30.00,
    targetValuationUSD: 150000000,
    circulatingFloat: 1200000,
    submittedAt: '2026-02-05T08:15:00Z',
    reviewedAt: '2026-02-06T12:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Swiss Aktiengesellschaft registration cleared, protein folding AI patent portfolio audited.',
    businessDetails: {
      companyName: 'BioSynthetica Genomics International AG',
      legalStructure: 'Swiss Aktiengesellschaft (AG)',
      sector: 'Technology & AI',
      industry: 'Algorithmic Protein Engineering & Epigenetic Longevity Therapeutics',
      registrationNumber: 'CHE-419.882.019',
      jurisdiction: 'Basel, Switzerland',
      foundedYear: 2023,
      headquarters: 'BioValley Innovation Campus, Basel, Switzerland',
      employeeCount: '52 Computational Biologists & Chemists',
      website: 'https://biosynthetica.ch',
      businessModel: 'AI-driven therapeutic candidate discovery, clinical milestone licensing, and sovereign longevity enzyme formulation.',
      valueProposition: 'Accelerating molecular target de-risking from 4.5 years to 60 days via custom tensor-accelerated molecular dynamics.',
      annualRevenueUSD: 18500000,
      netProfitMarginPercent: 34.2,
      projectedGrowthPercent: 95,
      executives: {
        ceo: 'Dr. Evelyn Reed (Founding Director)',
        cto: 'Henri Duval, Ph.D. (Lead AI Biochemist)',
        cfo: 'Sophie Meyer (Swiss Bio-Venture Partner)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Phase-II multi-target clinical validation trials ($45M) and high-throughput automated robotics lab expansion.'
    }
  },
  {
    id: 'ipo_business_vault_yield',
    ipoType: 'business',
    ticker: 'VLT-YLD',
    equityName: 'Global Vault Yield & Treasury Corp',
    issuerId: 'creator_vault_corp',
    issuerName: 'Julian Thorne',
    issuerHandle: 'julian_thorne',
    issuerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 8000000,
    offeringPriceUSD: 100.00,
    targetValuationUSD: 800000000,
    circulatingFloat: 2500000,
    submittedAt: '2026-01-10T10:00:00Z',
    reviewedAt: '2026-01-11T16:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: '100% full reserve treasury auditing verified by Swiss regulatory accountants.',
    businessDetails: {
      companyName: 'Global Vault Yield & Treasury Corp',
      legalStructure: 'Cayman Sovereign Trust Corporation',
      sector: 'Treasuries & Yield',
      industry: 'Yield-Generating Treasury Reserves & Cashflow Asset Management',
      registrationNumber: 'KY-TR-99014',
      jurisdiction: 'George Town, Cayman Islands',
      foundedYear: 2024,
      headquarters: 'George Town & Zurich Financial Centre',
      employeeCount: '28 Fixed-Income Quants & Legal Trustees',
      website: 'https://vaultyield.capital',
      businessModel: 'Short-duration sovereign treasury yields and cashflow-yielding asset management settled in USDC.',
      valueProposition: '5.20% net annual cashflow yield backed by 1:1 audited physical reserves and zero debt leverage.',
      annualRevenueUSD: 41600000,
      netProfitMarginPercent: 92.0,
      projectedGrowthPercent: 45,
      executives: {
        ceo: 'Julian Thorne (Managing Director)',
        cto: 'Lucas Weber (Algorithmic Yield Architect)',
        cfo: 'Helena Varga (Chief Risk Officer)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Expansion of short-duration sovereign bond vault reserves and institutional liquidity rails.'
    }
  },
  {
    id: 'ipo_business_nexa_robotics',
    ipoType: 'business',
    ticker: 'NEXA',
    equityName: 'Nexa Sovereign Robotics & AI Inc.',
    issuerId: 'creator_nexa',
    issuerName: 'Vikram Mehta',
    issuerHandle: 'vikram_nexa',
    issuerAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=120&auto=format&fit=crop&q=80',
    marketWay: 'fiat',
    status: 'active',
    sharesOffered: 6000000,
    offeringPriceUSD: 65.00,
    targetValuationUSD: 390000000,
    circulatingFloat: 1800000,
    submittedAt: '2026-01-28T09:00:00Z',
    reviewedAt: '2026-01-29T14:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Delaware C-Corp filing verified, autonomous robotics factory tour cleared.',
    businessDetails: {
      companyName: 'Nexa Sovereign Robotics & AI Inc.',
      legalStructure: 'Delaware C-Corporation',
      sector: 'Technology & AI',
      industry: 'Humanoid Spatial Compute & Autonomous Factory Actuators',
      registrationNumber: 'EIN-87-3310492',
      jurisdiction: 'San Francisco, California, USA',
      foundedYear: 2023,
      headquarters: 'San Francisco, California',
      employeeCount: '78 Robotics Engineers & Machine Learning Researchers',
      website: 'https://nexarobotics.ai',
      businessModel: 'Manufacturing of general-purpose humanoid robots and spatial perception neural models.',
      valueProposition: 'Superconducting magnetic joint actuators with sub-millimeter dexterity and 20-hour continuous battery life.',
      annualRevenueUSD: 32000000,
      netProfitMarginPercent: 24.5,
      projectedGrowthPercent: 120,
      executives: {
        ceo: 'Vikram Mehta (Chief Executive Officer)',
        cto: 'Dr. Sarah Lin (Head of Spatial Perception)',
        cfo: 'David Ross (VP Finance)'
      },
      backingCoinId: 'fiat_usd_master',
      backingCoinSymbol: 'USD',
      backingCoinType: 'fiat',
      backingCoinName: 'US Dollar Fiat Reserve',
      useOfProceeds: 'Scaling automated manufacturing line 2 in Fremont and European distribution hub.'
    }
  },
  {
    id: 'ipo_business_aerostrato',
    ipoType: 'business',
    ticker: 'AERO',
    equityName: 'AeroStrato Sovereign Hypersonics Inc.',
    issuerId: 'creator_aerostrato',
    issuerName: 'Col. Gregory Vance',
    issuerHandle: 'gregory_vance',
    issuerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'fiat',
    status: 'active',
    sharesOffered: 4000000,
    offeringPriceUSD: 85.00,
    targetValuationUSD: 340000000,
    circulatingFloat: 1100000,
    submittedAt: '2026-02-02T11:00:00Z',
    reviewedAt: '2026-02-03T15:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'FAA commercial space license clearance verified, propulsion bench tests audited.',
    businessDetails: {
      companyName: 'AeroStrato Sovereign Hypersonics Inc.',
      legalStructure: 'US Aerospace C-Corporation',
      sector: 'Energy & Aerospace',
      industry: 'Suborbital High-Mach Logistics & Ceramic Matrix Scramjet Propulsion',
      registrationNumber: 'EIN-81-7782019',
      jurisdiction: 'Mojave Air and Space Port, California, USA',
      foundedYear: 2022,
      headquarters: 'Mojave Space Port, California',
      employeeCount: '64 Aerospace & Thermal Shield Engineers',
      website: 'https://aerostrato.aero',
      businessModel: 'Mach-7 point-to-point suborbital commercial cargo and rapid sovereign satellite deployment.',
      valueProposition: 'Reducing trans-oceanic cargo delivery from 14 hours to 45 minutes using reusable scramjets.',
      annualRevenueUSD: 27500000,
      netProfitMarginPercent: 22.0,
      projectedGrowthPercent: 110,
      executives: {
        ceo: 'Col. Gregory Vance (Managing Director)',
        cto: 'Dr. Kenneth Clarke (Hypersonic Aerodynamics)',
        cfo: 'Amanda Scott (CFO)'
      },
      backingCoinId: 'fiat_usd_master',
      backingCoinSymbol: 'USD',
      backingCoinType: 'fiat',
      backingCoinName: 'US Dollar Fiat Reserve',
      useOfProceeds: 'Commercial Mach-7 flight envelope testing and thermal barrier production scaling.'
    }
  },
  {
    id: 'ipo_business_solar_node',
    ipoType: 'business',
    ticker: 'SOLN',
    equityName: 'SolarNode MicroGrid Protocol Ltd.',
    issuerId: 'creator_kenji',
    issuerName: 'Kenji Sato',
    issuerHandle: 'kenji_sato',
    issuerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 2000000,
    offeringPriceUSD: 14.50,
    targetValuationUSD: 29000000,
    circulatingFloat: 800000,
    submittedAt: '2026-01-20T10:00:00Z',
    reviewedAt: '2026-01-21T12:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Singapore Pte Ltd verified, real-time microgrid energy telemetry audited.',
    businessDetails: {
      companyName: 'SolarNode MicroGrid Protocol Ltd.',
      legalStructure: 'Singapore Private Limited Company',
      sector: 'Energy & Aerospace',
      industry: 'Decentralized Microgrid Energy Arbitrage & Battery Telemetry',
      registrationNumber: 'UEN-202304991K',
      jurisdiction: 'Singapore Financial District',
      foundedYear: 2023,
      headquarters: 'Marina Bay Financial Centre, Singapore',
      employeeCount: '36 Renewable Engineers & IoT Architects',
      website: 'https://solarnode.sg',
      businessModel: 'Peer-to-peer neighborhood renewable electricity routing with real-time settlement.',
      valueProposition: 'Optimizing commercial rooftop solar energy yields by up to 24% through automated high-frequency grid dispatch.',
      annualRevenueUSD: 8200000,
      netProfitMarginPercent: 21.0,
      projectedGrowthPercent: 60,
      executives: {
        ceo: 'Kenji Sato (Managing Director)',
        cto: 'Liam O’Connor (Chief IoT Architect)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'BTC',
      backingCoinType: 'crypto',
      backingCoinName: 'Bitcoin Crypto Asset (BTC)',
      useOfProceeds: 'Expansion of microgrid IoT nodes across 1,200 commercial buildings in Southeast Asia.'
    }
  },
  {
    id: 'ipo_business_quantum_compute',
    ipoType: 'business',
    ticker: 'QBIT',
    equityName: 'Quantum Compute Sovereign Trust',
    issuerId: 'creator_qbit',
    issuerName: 'Dr. Akira Tanaka',
    issuerHandle: 'akira_qbit',
    issuerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 3500000,
    offeringPriceUSD: 80.00,
    targetValuationUSD: 280000000,
    circulatingFloat: 950000,
    submittedAt: '2026-01-25T14:00:00Z',
    reviewedAt: '2026-01-26T16:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Superconducting quantum q-bit coherence times verified on benchmark testing.',
    businessDetails: {
      companyName: 'Quantum Compute Sovereign Trust',
      legalStructure: 'Swiss Cryptographic Trust',
      sector: 'Technology & AI',
      industry: 'Superconducting Quantum Processors & Zero-Knowledge Proof Acceleration',
      registrationNumber: 'CHE-772.109.840',
      jurisdiction: 'Zurich & Lausanne, Switzerland',
      foundedYear: 2023,
      headquarters: 'EPFL Innovation Park, Lausanne, Switzerland',
      employeeCount: '44 Quantum Hardware Physicists',
      website: 'https://qbit-trust.ch',
      businessModel: 'Quantum-as-a-Service (QaaS) compute time licensing for zero-knowledge proving and molecular simulation.',
      valueProposition: '1,024-qubit error-mitigated quantum processors delivering 10,000x acceleration for cryptographic verification.',
      annualRevenueUSD: 24000000,
      netProfitMarginPercent: 31.5,
      projectedGrowthPercent: 130,
      executives: {
        ceo: 'Dr. Akira Tanaka (Founder & Chief Scientist)',
        cto: 'Dr. Celine Laurent (Quantum Hardware Lead)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'BTC',
      backingCoinType: 'crypto',
      backingCoinName: 'Bitcoin Crypto Asset (BTC)',
      useOfProceeds: 'Dilution refrigerator cluster expansion and superconducting quantum chip fabrication.'
    }
  },
  {
    id: 'ipo_business_usdc_treasuries',
    ipoType: 'business',
    ticker: 'USDC-TR',
    equityName: 'Sovereign Treasury Reserves Corp',
    issuerId: 'creator_usdc_treasury',
    issuerName: 'Alexander Vance',
    issuerHandle: 'alexander_vance',
    issuerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 10000000,
    offeringPriceUSD: 50.00,
    targetValuationUSD: 500000000,
    circulatingFloat: 4000000,
    submittedAt: '2026-01-14T09:00:00Z',
    reviewedAt: '2026-01-15T11:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Fully verified tokenized short-term US Treasury Bills backing verified by third-party attestation.',
    businessDetails: {
      companyName: 'Sovereign Treasury Reserves Corp',
      legalStructure: 'Delaware Sovereign Trust Corp',
      sector: 'Treasuries & Yield',
      industry: 'Tokenized Short-Duration US Treasuries & Fixed Income Liquidity',
      registrationNumber: 'DE-TR-88201',
      jurisdiction: 'Wilmington, Delaware, USA',
      foundedYear: 2024,
      headquarters: '1209 Orange St, Wilmington, DE',
      employeeCount: '24 Fixed-Income Quants & Compliance Directors',
      website: 'https://treasuryreserves.sovereign',
      businessModel: 'Tokenized ultra-short sovereign bills producing 5.15% APY yield, cleared and settled 1:1 against USDC stablecoins.',
      valueProposition: 'Stable institutional cash management delivering programmatic daily yield dividends settled in audited USDC.',
      annualRevenueUSD: 25750000,
      netProfitMarginPercent: 94.0,
      projectedGrowthPercent: 55,
      executives: {
        ceo: 'Alexander Vance (Chief Executive Officer)',
        cto: 'David K. Liu (Lead Financial Engineer)',
        cfo: 'Amanda Stern (Treasurer)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Expansion of short-duration US sovereign bill inventory and 1:1 on-chain settlement channels.'
    }
  },
  {
    id: 'ipo_business_real_yield_stable',
    ipoType: 'business',
    ticker: 'REAL-STBL',
    equityName: 'RealYield Sovereign Properties Inc.',
    issuerId: 'creator_realyield',
    issuerName: 'Marcus Sterling',
    issuerHandle: 'marcus_realyield',
    issuerAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 5000000,
    offeringPriceUSD: 42.00,
    targetValuationUSD: 210000000,
    circulatingFloat: 1800000,
    submittedAt: '2026-02-01T10:00:00Z',
    reviewedAt: '2026-02-02T14:30:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: '100% unencumbered commercial properties title deeds verified and audited.',
    businessDetails: {
      companyName: 'RealYield Sovereign Properties Inc.',
      legalStructure: 'Singapore Property Trust Limited',
      sector: 'Treasuries & Yield',
      industry: 'Tokenized Commercial Real Estate & Monthly Rental Dividend Vaults',
      registrationNumber: 'SG-PROP-44102',
      jurisdiction: 'Marina Bay, Singapore',
      foundedYear: 2023,
      headquarters: 'One Raffles Quay, Singapore',
      employeeCount: '35 Property Asset Managers',
      website: 'https://realyield.sg',
      businessModel: 'Prime commercial real estate portfolios generating monthly rental cashflows distributed directly in USDC stablecoins.',
      valueProposition: 'Institutional fractional real estate providing 6.40% stable dividend yields with inflation-hedged physical collateral.',
      annualRevenueUSD: 16800000,
      netProfitMarginPercent: 68.0,
      projectedGrowthPercent: 40,
      executives: {
        ceo: 'Marcus Sterling (Managing Director)',
        cto: 'Li Wei (Real Estate Tokenization Architect)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Acquisition of grade-A logistics hub properties and tenant lease escrow reserves.'
    }
  },
  {
    id: 'ipo_business_hashrate_infrastructure',
    ipoType: 'business',
    ticker: 'HASH-M',
    equityName: 'Sovereign Hashrate Infrastructure Inc.',
    issuerId: 'creator_hashrate_corp',
    issuerName: 'Viktor Lindqvist',
    issuerHandle: 'viktor_hashrate',
    issuerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 6000000,
    offeringPriceUSD: 32.00,
    targetValuationUSD: 192000000,
    circulatingFloat: 2200000,
    submittedAt: '2026-02-10T12:00:00Z',
    reviewedAt: '2026-02-11T17:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Clean geothermal energy power purchase agreements verified and zero carbon footprint confirmed.',
    businessDetails: {
      companyName: 'Sovereign Hashrate Infrastructure Inc.',
      legalStructure: 'Reykjavik Energy & Compute Corp',
      sector: 'Energy & Aerospace',
      industry: 'Zero-Emission Geothermal Bitcoin Mining & AI Compute Clusters',
      registrationNumber: 'IS-HASH-77120',
      jurisdiction: 'Reykjavik, Iceland',
      foundedYear: 2023,
      headquarters: 'Reykjavik Geothermal Park, Iceland',
      employeeCount: '45 Infrastructure & HPC Engineers',
      website: 'https://sovereignhash.is',
      businessModel: 'Industrial-scale Bitcoin mining operations powered by stranded geothermal energy, settling daily hashrate revenues in BTC.',
      valueProposition: 'Clean-energy Bitcoin network security infrastructure delivering direct equity participation in sovereign cryptographic hashrate.',
      annualRevenueUSD: 38400000,
      netProfitMarginPercent: 42.5,
      projectedGrowthPercent: 85,
      executives: {
        ceo: 'Viktor Lindqvist (Founder & CEO)',
        cto: 'Astrid Olsen (Chief Power Systems Engineer)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'BTC',
      backingCoinType: 'crypto',
      backingCoinName: 'Bitcoin Crypto Asset (BTC)',
      useOfProceeds: 'Commissioning of 85MW geothermal turbine arrays and next-gen immersion ASIC compute pods.'
    }
  },
  {
    id: 'ipo_business_validator_prime',
    ipoType: 'business',
    ticker: 'VAL-ETH',
    equityName: 'Validator Prime Ledger Corp',
    issuerId: 'creator_val_prime',
    issuerName: 'Elena Rostova',
    issuerHandle: 'elena_val_prime',
    issuerAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 4500000,
    offeringPriceUSD: 68.00,
    targetValuationUSD: 306000000,
    circulatingFloat: 1600000,
    submittedAt: '2026-02-15T14:00:00Z',
    reviewedAt: '2026-02-16T18:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Slashing protection and institutional validator multi-sig architecture verified.',
    businessDetails: {
      companyName: 'Validator Prime Ledger Corp',
      legalStructure: 'Zug Crypto Valley Foundation AG',
      sector: 'Technology & AI',
      industry: 'Institutional Proof-of-Stake Validator Infrastructure & Staking Yields',
      registrationNumber: 'CH-VAL-33290',
      jurisdiction: 'Zug, Switzerland',
      foundedYear: 2024,
      headquarters: 'Crypto Valley, Zug, Switzerland',
      employeeCount: '30 Distributed Systems Architects',
      website: 'https://validatorprime.io',
      businessModel: 'High-availability multi-region validator node infrastructure providing institutional staking yields settled in crypto assets.',
      valueProposition: 'Slashing-insured proof-of-stake validator cluster generating continuous cryptographic staking revenue.',
      annualRevenueUSD: 28200000,
      netProfitMarginPercent: 54.0,
      projectedGrowthPercent: 90,
      executives: {
        ceo: 'Elena Rostova (Co-Founder & Executive Director)',
        cto: 'Dmitri Vane (Lead Consensus Engineer)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'ETH',
      backingCoinType: 'crypto',
      backingCoinName: 'Ethereum Crypto Asset (ETH)',
      useOfProceeds: 'Geographic node distribution across tier-4 data centers and staking insurance reserve pool.'
    }
  }
];

// ============================================================================
// BASE STOCKS DERIVED EXCLUSIVELY FROM APPROVED PLATFORM-ISSUED IPOs
// ============================================================================

export const INITIAL_STOCKS: StockItem[] = [
  ...INITIAL_IPO_REQUESTS.map((ipo) => {
    const isPersonal = ipo.ipoType === 'personal';
  const livePrice = ipo.offeringPriceUSD * 1.15; // Realistic active secondary price
  const changeUSD = +(livePrice - ipo.offeringPriceUSD).toFixed(2);
  const changePercent = +((changeUSD / ipo.offeringPriceUSD) * 100).toFixed(2);

  const sector = isPersonal 
    ? 'Sovereign Reserves' 
    : (ipo.businessDetails?.sector || 'Technology & AI');

  const description = isPersonal
    ? (ipo.personalDetails?.personaProfile || `${ipo.equityName} - Personal Sovereign Equity released via platform IPO.`)
    : (ipo.businessDetails?.valueProposition || ipo.businessDetails?.businessModel || `${ipo.equityName} - Corporate Enterprise Equity.`);

  return {
    ticker: ipo.ticker,
    name: ipo.equityName,
    price: +(livePrice).toFixed(2),
    changeUSD,
    changePercent,
    marketType: ipo.marketWay,
    settlementMethod: isPersonal
      ? `Final Coin Sovereign Vault (${ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL'})`
      : `${ipo.businessDetails?.backingCoinType === 'stable_coin' ? 'USD Stablecoin Clearing' : ipo.businessDetails?.backingCoinType === 'crypto' ? 'Crypto Custody Ledger' : ipo.businessDetails?.backingCoinType === 'fiat' ? 'USD Fiat Direct Clearing' : 'Final Coin Sovereign Vault'} (${ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')})`,
    high24h: +(livePrice * 1.04).toFixed(2),
    low24h: +(livePrice * 0.98).toFixed(2),
    openPrice: +(livePrice * 0.99).toFixed(2),
    prevClose: +(ipo.offeringPriceUSD * 1.02).toFixed(2),
    volume: `$${(ipo.targetValuationUSD * 0.04 / 1e6).toFixed(1)}M`,
    avgVolume: `$${(ipo.targetValuationUSD * 0.035 / 1e6).toFixed(1)}M`,
    marketCap: `$${(ipo.targetValuationUSD * 1.15 / 1e6).toFixed(1)}M`,
    peRatio: isPersonal ? 14.2 : 28.5,
    eps: isPersonal ? 1.75 : 2.45,
    dividendYield: isPersonal ? '3.80%' : '1.90%',
    beta: 1.05,
    fiftyTwoWeekHigh: +(livePrice * 1.18).toFixed(2),
    fiftyTwoWeekLow: +(ipo.offeringPriceUSD * 0.95).toFixed(2),
    sector: sector as any,
    subSector: isPersonal ? 'Personal Sovereign Equity' : ipo.businessDetails?.industry,
    description,
    exchange: 'SOVEREIGN_NODE' as const,
    analystRating: 'Strong Buy' as const,
    analystTargetUSD: +(livePrice * 1.25).toFixed(2),
    analystCount: 18,
    sparkline: [
      livePrice * 0.96,
      livePrice * 0.97,
      livePrice * 0.965,
      livePrice * 0.98,
      livePrice * 0.975,
      livePrice * 0.99,
      livePrice * 1.01,
      livePrice * 1.005,
      livePrice * 1.025,
      livePrice * 1.032
    ],
    history: generateHistory(livePrice, 0.018),
    ceo: isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.executives?.ceo,
    headquarters: isPersonal ? 'Global Sovereign Node' : ipo.businessDetails?.headquarters,
    foundedYear: isPersonal ? 2026 : ipo.businessDetails?.foundedYear,
    employeesCount: isPersonal ? '1 Principal' : ipo.businessDetails?.employeeCount,
    revenueTTM: isPersonal 
      ? `$${((ipo.personalDetails?.fiveModeNetWorth.totalNetWorthUSD || 10e6) * 0.2 / 1e6).toFixed(1)}M` 
      : `$${((ipo.businessDetails?.annualRevenueUSD || 10e6) / 1e6).toFixed(1)}M`,
    profitMargin: isPersonal ? '85.0%' : `${ipo.businessDetails?.netProfitMarginPercent || 25}%`,
    issuanceType: (isPersonal ? 'personal' : 'business') as 'personal' | 'business',
    assetCategory: (isPersonal ? 'personal' : 'business') as 'personal' | 'business',
    issuanceCoinSymbol: isPersonal 
      ? (ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL')
      : (ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')),
    issuanceCoinName: isPersonal
      ? (ipo.personalDetails?.backingFinalCoinName || 'Final Sovereign Coin')
      : (ipo.businessDetails?.backingCoinName || (ipo.marketWay === 'stable' ? 'USD Stablecoin' : ipo.marketWay === 'crypto' ? 'Bitcoin Crypto Asset' : 'Final Coin')),
    issuanceCoinType: isPersonal
      ? 'final_coin'
      : (ipo.businessDetails?.backingCoinType || (ipo.marketWay === 'stable' ? 'stable_coin' : ipo.marketWay === 'crypto' ? 'crypto' : 'final_coin')),
    issuerName: ipo.issuerName || (isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.companyName),
    issuerHandle: ipo.issuerHandle || ipo.personalDetails?.handle,
    issuerAvatar: ipo.issuerAvatar,
    ipoRefId: ipo.id
  };
})
];

// ============================================================================
// INITIAL USER OWNED EQUITIES - PLATFORM-ISSUED PERSONAL & BUSINESS STOCKS ONLY
// ============================================================================

export const INITIAL_USER_STOCK_POSITIONS: StockPosition[] = [
  // 1. Personal Stock Holdings
  {
    ticker: 'ALEX',
    name: 'Alex Chen Sovereign Human Equity',
    shares: 696,
    avgCostUSD: 25.00,
    currentPriceUSD: 28.75,
    totalValueUSD: 20000,
    totalGainUSD: 0,
    totalGainPercent: 0,
    dailyGainUSD: 0,
    marketType: 'final',
    settlementMethod: 'Final Coin (AFNL)',
    sector: 'Sovereign Reserves',
    dividendYield: '3.80%',
    initialBoughtDate: '2026-06-15',
    lastPurchasedDate: '2026-08-18',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },
  {
    ticker: 'ELEN',
    name: 'Dr. Elena Rostova Plasma Physics Equity',
    shares: 235,
    avgCostUSD: 20.00,
    currentPriceUSD: 23.00,
    totalValueUSD: 5397,
    totalGainUSD: 0,
    totalGainPercent: 0,
    dailyGainUSD: 0,
    marketType: 'final',
    settlementMethod: 'Final Coin (AFNL)',
    sector: 'Sovereign Reserves',
    dividendYield: '3.50%',
    initialBoughtDate: '2026-07-01',
    lastPurchasedDate: '2026-08-15',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },

  // 2. Business Stock Holdings
  {
    ticker: 'HYPR',
    name: 'Hyperion Quantum Fusion Dynamics Inc.',
    shares: 60,
    avgCostUSD: 48.50,
    currentPriceUSD: 55.78,
    totalValueUSD: 3346.80,
    totalGainUSD: 436.80,
    totalGainPercent: 15.00,
    dailyGainUSD: 84.00,
    marketType: 'final',
    settlementMethod: 'Final Coin (AFNL)',
    sector: 'Energy & Aerospace',
    dividendYield: '1.90%',
    initialBoughtDate: '2026-06-20',
    lastPurchasedDate: '2026-08-14',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },
  {
    ticker: 'AFNL-EQ',
    name: 'Final Network Treasury Equity',
    shares: 20,
    avgCostUSD: 300.00,
    currentPriceUSD: 345.00,
    totalValueUSD: 6900.00,
    totalGainUSD: 900.00,
    totalGainPercent: 15.00,
    dailyGainUSD: 196.00,
    marketType: 'final',
    settlementMethod: 'Final Coins & Sovereign Settlement Nodes',
    sector: 'Sovereign Reserves',
    dividendYield: '3.80%',
    initialBoughtDate: '2026-04-10',
    lastPurchasedDate: '2026-08-12',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },
  // 3. Regular Stocks: Stable Stocks Examples (Settled in 1:1 USDC Stablecoins)
  {
    ticker: 'BSYN',
    name: 'BioSynthetica Genomics International AG',
    shares: 80,
    avgCostUSD: 30.00,
    currentPriceUSD: 34.50,
    totalValueUSD: 2760.00,
    totalGainUSD: 360.00,
    totalGainPercent: 15.00,
    dailyGainUSD: 72.00,
    marketType: 'stable',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Technology & AI',
    dividendYield: '2.10%',
    initialBoughtDate: '2026-05-15',
    lastPurchasedDate: '2026-08-01',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'VLT-YLD',
    name: 'Global Vault Yield & Treasury Corp',
    shares: 50,
    avgCostUSD: 100.00,
    currentPriceUSD: 115.00,
    totalValueUSD: 5750.00,
    totalGainUSD: 750.00,
    totalGainPercent: 15.00,
    dailyGainUSD: 45.00,
    marketType: 'stable',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Treasuries & Yield',
    dividendYield: '5.20%',
    initialBoughtDate: '2026-03-22',
    lastPurchasedDate: '2026-07-10',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'USDC-TR',
    name: 'Sovereign Treasury Reserves Corp',
    shares: 60,
    avgCostUSD: 50.00,
    currentPriceUSD: 51.75,
    totalValueUSD: 3105.00,
    totalGainUSD: 105.00,
    totalGainPercent: 3.50,
    dailyGainUSD: 18.00,
    marketType: 'stable',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Treasuries & Yield',
    dividendYield: '5.15%',
    initialBoughtDate: '2026-07-05',
    lastPurchasedDate: '2026-08-20',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },

  // 4. Regular Stocks: Fiat Stocks (Settled in USD Brokerage / Direct Clearing)
  {
    ticker: 'NEXA',
    name: 'Nexa Sovereign Robotics & AI Inc.',
    shares: 35,
    avgCostUSD: 65.00,
    currentPriceUSD: 74.75,
    totalValueUSD: 2616.25,
    totalGainUSD: 341.25,
    totalGainPercent: 15.00,
    dailyGainUSD: 85.00,
    marketType: 'fiat',
    settlementMethod: 'USD Fiat Direct Clearing',
    sector: 'Technology & AI',
    dividendYield: '0.80%',
    initialBoughtDate: '2026-06-12',
    lastPurchasedDate: '2026-08-14',
    primaryFundingSourceLabel: 'USD Fiat Brokerage Clearing',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'AAPL',
    name: 'Apple Inc.',
    shares: 15,
    avgCostUSD: 215.50,
    currentPriceUSD: 224.25,
    totalValueUSD: 3363.75,
    totalGainUSD: 131.25,
    totalGainPercent: 4.06,
    dailyGainUSD: 24.50,
    marketType: 'fiat',
    settlementMethod: 'USD Brokerage Clearing',
    sector: 'Technology & AI',
    dividendYield: '0.50%',
    initialBoughtDate: '2026-08-01',
    lastPurchasedDate: '2026-08-25',
    primaryFundingSourceLabel: 'USD Fiat Brokerage Clearing',
    assetCategory: 'spot',
    isSpotStock: true,
    isEquity: false
  },
  {
    ticker: 'NVDA',
    name: 'NVIDIA Corp',
    shares: 25,
    avgCostUSD: 125.40,
    currentPriceUSD: 132.80,
    totalValueUSD: 3320.00,
    totalGainUSD: 185.00,
    totalGainPercent: 5.90,
    dailyGainUSD: 42.00,
    marketType: 'fiat',
    settlementMethod: 'USD Brokerage Clearing',
    sector: 'Semiconductors',
    dividendYield: '0.08%',
    initialBoughtDate: '2026-08-05',
    lastPurchasedDate: '2026-08-25',
    primaryFundingSourceLabel: 'USD Fiat Brokerage Clearing',
    assetCategory: 'spot',
    isSpotStock: true,
    isEquity: false
  },

  // 5. Regular Stocks: Crypto Stocks Examples (Settled in BTC / ETH Cryptocurrencies)
  {
    ticker: 'SOLN',
    name: 'SolarNode MicroGrid Protocol Ltd.',
    shares: 100,
    avgCostUSD: 14.50,
    currentPriceUSD: 16.68,
    totalValueUSD: 1668.00,
    totalGainUSD: 218.00,
    totalGainPercent: 15.03,
    dailyGainUSD: 36.00,
    marketType: 'crypto',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    sector: 'Energy & Aerospace',
    dividendYield: '2.40%',
    initialBoughtDate: '2026-05-14',
    lastPurchasedDate: '2026-08-16',
    primaryFundingSourceLabel: 'Bitcoin Crypto Asset (BTC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'QBIT',
    name: 'Quantum Compute Sovereign Trust',
    shares: 20,
    avgCostUSD: 85.00,
    currentPriceUSD: 92.00,
    totalValueUSD: 1840.00,
    totalGainUSD: 140.00,
    totalGainPercent: 8.24,
    dailyGainUSD: 28.00,
    marketType: 'crypto',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    sector: 'Technology & AI',
    dividendYield: '1.20%',
    initialBoughtDate: '2026-06-20',
    lastPurchasedDate: '2026-08-22',
    primaryFundingSourceLabel: 'Bitcoin Crypto Asset (BTC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'HASH-M',
    name: 'Sovereign Hashrate Infrastructure Inc.',
    shares: 75,
    avgCostUSD: 28.00,
    currentPriceUSD: 32.00,
    totalValueUSD: 2400.00,
    totalGainUSD: 300.00,
    totalGainPercent: 14.29,
    dailyGainUSD: 48.00,
    marketType: 'crypto',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    sector: 'Energy & Aerospace',
    dividendYield: '3.60%',
    initialBoughtDate: '2026-07-15',
    lastPurchasedDate: '2026-08-24',
    primaryFundingSourceLabel: 'Bitcoin Crypto Asset (BTC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  }
];

// ============================================================================
// INITIAL USER STOCK ORDERS (INCLUDING DERIVATIVE CONTRACT EXAMPLES)
// ============================================================================

export const DEFAULT_INITIAL_STOCK_ORDERS: StockOrder[] = [
  {
    id: 'ord-samp-spot-aapl',
    ticker: 'AAPL',
    stockName: 'Apple Inc. [Spot Shares]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 15,
    price: 215.50,
    totalUSD: 3232.50,
    paymentSource: { id: 'fiat-bank', type: 'bank_account', label: 'Direct Settlement Vault', subtitle: 'USD Reserves', balanceUSD: 100000, iconType: 'bank' },
    status: 'filled',
    timestamp: '10:00:15 AM',
    dateIso: '2026-08-25T10:00:15.000Z',
    sector: 'Technology & AI',
    tradeSlipId: 'SLIP-AAPL-SPOT'
  },
  {
    id: 'ord-samp-spot-nvda',
    ticker: 'NVDA',
    stockName: 'NVIDIA Corp [Spot Shares]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 25,
    price: 125.40,
    totalUSD: 3135.00,
    paymentSource: { id: 'fiat-bank', type: 'bank_account', label: 'Direct Settlement Vault', subtitle: 'USD Reserves', balanceUSD: 100000, iconType: 'bank' },
    status: 'filled',
    timestamp: '11:12:00 AM',
    dateIso: '2026-08-25T11:12:00.000Z',
    sector: 'Semiconductors',
    tradeSlipId: 'SLIP-NVDA-SPOT'
  },
  {
    id: 'ord-samp-call-aapl',
    ticker: 'AAPL',
    stockName: 'Apple Inc. [Call Option ($210.00 Strike)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'call_option',
    strikePrice: 210.00,
    expiryDate: '2026-10-31',
    premiumUSD: 250.00,
    shares: 10,
    price: 215.50,
    totalUSD: 250.00,
    paymentSource: { id: 'fiat-bank', type: 'bank_account', label: 'Direct Settlement Vault', subtitle: 'USD Reserves', balanceUSD: 100000, iconType: 'bank' },
    status: 'filled',
    timestamp: '09:15:22 AM',
    dateIso: '2026-08-20T09:15:22.000Z',
    sector: 'Technology & AI',
    tradeSlipId: 'SLIP-AAPL-CALL'
  },
  {
    id: 'ord-samp-put-tsla',
    ticker: 'TSLA',
    stockName: 'Tesla Motors [Put Option ($180.00 Strike)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'put_option',
    strikePrice: 180.00,
    expiryDate: '2026-09-15',
    premiumUSD: 190.00,
    shares: 5,
    price: 185.20,
    totalUSD: 190.00,
    paymentSource: { id: 'crypto-w', type: 'wallet_crypto', label: 'Crypto Assets', subtitle: 'ETH / BTC Vault', balanceUSD: 50000, iconType: 'crypto' },
    status: 'filled',
    timestamp: '10:22:04 AM',
    dateIso: '2026-08-21T10:22:04.000Z',
    sector: 'Energy & Aerospace',
    tradeSlipId: 'SLIP-TSLA-PUT'
  },
  {
    id: 'ord-samp-futl-nvda',
    ticker: 'NVDA',
    stockName: 'NVIDIA Corp [Futures Long (10x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_long',
    leverage: 10,
    expiryDate: '2026-12-31',
    shares: 20,
    price: 125.40,
    totalUSD: 500.00,
    paymentSource: { id: 'final-w', type: 'wallet_final', label: 'Final Coin ($FINAL)', subtitle: 'Issuer Token Vault', balanceUSD: 25000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '11:05:40 AM',
    dateIso: '2026-08-22T11:05:40.000Z',
    sector: 'Semiconductors',
    tradeSlipId: 'SLIP-NVDA-FUT'
  },
  {
    id: 'ord-samp-futs-msft',
    ticker: 'MSFT',
    stockName: 'Microsoft Corp [Futures Short (5x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_short',
    leverage: 5,
    expiryDate: '2026-11-20',
    shares: 15,
    price: 418.00,
    totalUSD: 400.00,
    paymentSource: { id: 'stable-w', type: 'wallet_stable', label: 'Stable Coin ($USDC)', subtitle: 'Pegged Reserve', balanceUSD: 40000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '01:40:12 PM',
    dateIso: '2026-08-23T13:40:12.000Z',
    sector: 'Technology & AI',
    tradeSlipId: 'SLIP-MSFT-SHORT'
  },
  {
    id: 'ord-samp-call-alex',
    ticker: 'ALEX',
    stockName: 'Alex Chen Sovereign Equity [Call Option ($32.00 Strike)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'call_option',
    strikePrice: 32.00,
    expiryDate: '2026-10-15',
    premiumUSD: 145.00,
    shares: 25,
    price: 28.75,
    totalUSD: 145.00,
    paymentSource: { id: 'final-w', type: 'wallet_final', label: 'Final Coin ($FINAL)', subtitle: 'Protocol Sovereign Vault', balanceUSD: 2840000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '02:15:30 PM',
    dateIso: '2026-08-23T14:15:30.000Z',
    sector: 'Sovereign Reserves',
    tradeSlipId: 'SLIP-ALEX-CALL'
  },
  {
    id: 'ord-samp-futl-hypr',
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion [Futures Long (10x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_long',
    leverage: 10,
    expiryDate: '2026-12-15',
    shares: 30,
    price: 55.78,
    totalUSD: 334.68,
    paymentSource: { id: 'stable-w', type: 'wallet_stable', label: 'USD Coin (USDC)', subtitle: 'Escrow Vault', balanceUSD: 350000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '03:45:00 PM',
    dateIso: '2026-08-24T15:45:00.000Z',
    sector: 'Energy & Aerospace',
    tradeSlipId: 'SLIP-HYPR-FUT'
  }
];

// ============================================================================
// BREAKING NEWS ON PLATFORM-ISSUED PERSONAL & BUSINESS EQUITIES
// ============================================================================

export const BREAKING_STOCK_NEWS: StockNewsItem[] = [
  {
    id: 'news-1',
    title: 'Hyperion Quantum Fusion Surpasses Q-Factor 2.4 in Live Municipal Substation Power Run',
    source: 'Clean Energy Telegraph',
    time: '12m ago',
    sentiment: 'bullish',
    tickers: ['HYPR'],
    category: 'Energy & Aerospace',
    impact: 'High Impact',
    keyTakeaway: 'Generation-3 modular tokamak sustained 24-hour continuous baseline power delivery with net positive thermal output.',
    summary: 'Hyperion Quantum Fusion Dynamics reported a technical milestone during grid interconnect trials in Austin, confirming commercial scalability of its platform-issued business stock shares.',
    readTime: '3 min read'
  },
  {
    id: 'news-2',
    title: 'Alex Chen Personal Sovereign Equity Achieves 89% AI Algorithm Licensing Royalty Growth',
    source: 'Sovereign Journal',
    time: '35m ago',
    sentiment: 'bullish',
    tickers: ['ALEX'],
    category: 'Sovereign Reserves',
    impact: 'High Impact',
    keyTakeaway: 'Zero-knowledge algorithmic liquidity proofs licensed by 4 tier-1 decentralized clearing vaults.',
    summary: 'Quarterly audited earnings for Alex Chen personal human equity IPO confirmed record royalty revenue distribution into the AFNL backing reserve vault.',
    readTime: '4 min read'
  },
  {
    id: 'news-3',
    title: 'BioSynthetica Secures Swiss Regulatory Clearance for Phase-II Longevity Enzyme Protocol',
    source: 'Swiss BioTech Review',
    time: '52m ago',
    sentiment: 'bullish',
    tickers: ['BSYN'],
    category: 'Technology & AI',
    impact: 'High Impact',
    keyTakeaway: 'Epigenetic de-risking timeline compressed to 45 days using tensor-accelerated molecular dynamics.',
    summary: 'BioSynthetica Genomics International AG announced milestone clearance from Swiss authorities, advancing candidate licensing discussions with European pharmaceutical syndicates.',
    readTime: '2 min read'
  },
  {
    id: 'news-4',
    title: 'Global Vault Yield & Treasury Corp Reports $41.6M Cashflow Backing USDC Dividend Pool',
    source: 'Treasury & Reserves Digest',
    time: '1h ago',
    sentiment: 'bullish',
    tickers: ['VLT-YLD'],
    category: 'Treasuries & Yield',
    impact: 'High Impact',
    keyTakeaway: '100% full-reserve short-duration treasury backing generates 5.20% annualized yield with zero credit risk.',
    summary: 'Global Vault Yield confirmed pristine full reserve verification across Zurich and George Town custodial trusts, distributing monthly dividends to USDC stock holders.',
    readTime: '3 min read'
  },
  {
    id: 'news-5',
    title: 'Nexa Sovereign Robotics Delivers First 100 Autonomous Humanoid Spatial Perception Units',
    source: 'Robotics Insider',
    time: '2h ago',
    sentiment: 'bullish',
    tickers: ['NEXA'],
    category: 'Technology & AI',
    impact: 'High Impact',
    keyTakeaway: 'Factory automation efficiency improved by 34% with sub-millimeter dexterity magnetic actuators.',
    summary: 'Nexa Robotics confirmed initial enterprise deliveries to automated automotive and electronics fabrication cleanrooms in North America.',
    readTime: '3 min read'
  },
  {
    id: 'news-6',
    title: 'SolarNode MicroGrid Protocol Deploys 2.4MW Peer-to-Peer Neighborhood Energy Mesh',
    source: 'Decentralized Grid Daily',
    time: '3h ago',
    sentiment: 'bullish',
    tickers: ['SOLN'],
    category: 'Energy & Aerospace',
    impact: 'Medium Impact',
    keyTakeaway: 'Microgrid dispatch algorithms reduce commercial rooftop solar energy curtailment by 22%.',
    summary: 'SolarNode confirmed rapid expansion of its decentralized rooftop solar IoT telemetry network in Singapore and Southeast Asia.',
    readTime: '2 min read'
  }
];

export const INITIAL_STOCK_NEWS = BREAKING_STOCK_NEWS;

// ============================================================================
// STORAGE & IPO MANAGEMENT HELPERS
// ============================================================================

const IPO_STORAGE_KEY = 'final_finance_ipos_v1';
export const IPO_UPDATED_EVENT = 'final_finance_ipos_updated';

export function getStoredIPORequests(): IPORequest[] {
  try {
    const raw = localStorage.getItem(IPO_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(INITIAL_IPO_REQUESTS));
      return INITIAL_IPO_REQUESTS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(INITIAL_IPO_REQUESTS));
      return INITIAL_IPO_REQUESTS;
    }
    // Ensure all base system IPOs (including new stable/crypto stocks) are present
    const existingIds = new Set(parsed.map((p: any) => p.id));
    let hasNew = false;
    for (const baseIpo of INITIAL_IPO_REQUESTS) {
      if (!existingIds.has(baseIpo.id)) {
        parsed.push(baseIpo);
        hasNew = true;
      }
    }
    if (hasNew) {
      localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(parsed));
    }
    return parsed;
  } catch (err) {
    console.error('Failed reading IPO requests from storage:', err);
    return INITIAL_IPO_REQUESTS;
  }
}

export function saveIPORequests(ipos: IPORequest[]): void {
  try {
    localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(ipos));
    window.dispatchEvent(new CustomEvent(IPO_UPDATED_EVENT, { detail: ipos }));
  } catch (err) {
    console.error('Failed saving IPO requests to storage:', err);
  }
}

// Check if user can create a Personal IPO (Limit 1 Personal IPO at a time)
export function canCreatePersonalIPO(userId = 'you'): { 
  allowed: boolean; 
  activeIPO?: IPORequest; 
  existingTicker?: string; 
  message?: string; 
  reason?: string; 
} {
  const ipos = getStoredIPORequests();
  const existingPersonal = ipos.find(
    (i) => (i.issuerId === userId || (userId === 'you' && (i.issuerId === 'you' || i.issuerId === 'user_main' || i.issuerId === 'current_user'))) && 
           i.id !== 'ipo_personal_alex_chen' &&
           i.ipoType === 'personal' && 
           (i.status === 'active' || i.status === 'pending_admin_approval' || i.status === 'delist_pending_admin_approval')
  );

  if (existingPersonal) {
    const msg = `Protocol Limit: You already have an active or pending Personal IPO ($${existingPersonal.ticker} - ${existingPersonal.equityName}). Sovereign individuals are restricted to 1 active Personal IPO at a time. You may launch multiple Business IPOs without restriction.`;
    return {
      allowed: false,
      activeIPO: existingPersonal,
      existingTicker: existingPersonal.ticker,
      message: msg,
      reason: msg
    };
  }

  return { allowed: true };
}

// Calculate real-time live valuation for an active IPO
export function getLiveIPOValuation(ipo: IPORequest) {
  const basePrice = ipo.offeringPriceUSD;
  const isLive = ipo.status === 'active';
  
  let livePrice = ipo.currentLivePriceUSD || basePrice;
  let changePercent = ipo.priceChangePercent24h ?? 3.42;

  if (isLive && !ipo.currentLivePriceUSD) {
    const tickerSum = ipo.ticker.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
    const mod = (tickerSum % 15) - 3;
    const gainPct = +(3.2 + mod * 0.45).toFixed(2);
    changePercent = gainPct;
    livePrice = Number((basePrice * (1 + changePercent / 100)).toFixed(2));
  }

  const currentMarketCap = livePrice * ipo.sharesOffered;
  const circulatingValuation = livePrice * ipo.circulatingFloat;
  const founderRetainedShares = ipo.sharesOffered - ipo.circulatingFloat;
  const founderRetainedValuation = livePrice * founderRetainedShares;
  const totalGainLossUSD = (livePrice - basePrice) * ipo.sharesOffered;
  const changeUSD = +(livePrice - basePrice).toFixed(2);

  return {
    isLive,
    basePrice,
    livePrice,
    currentMarketCap,
    targetValuation: ipo.targetValuationUSD,
    circulatingValuation,
    founderRetainedShares,
    founderRetainedValuation,
    changeUSD,
    changePercent,
    totalGainLossUSD
  };
}

export function submitIPORequest(ipoData: Partial<IPORequest>): IPORequest {
  const current = getStoredIPORequests();
  const cleanTicker = (ipoData.ticker || 'IPO').replace(/^\$/, '').toUpperCase();
  const offeringPrice = ipoData.offeringPriceUSD || 10.0;
  const shares = ipoData.sharesOffered || 1000000;
  const targetValuation = ipoData.targetValuationUSD || (shares * offeringPrice);

  const media = ipoData.mediaGallery || 
    (ipoData.ipoType === 'personal' ? ipoData.personalDetails?.mediaGallery : ipoData.businessDetails?.mediaGallery) || 
    [];
  
  const newIPO: IPORequest = {
    id: `ipo_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    ipoType: ipoData.ipoType || 'personal',
    ticker: cleanTicker,
    equityName: ipoData.equityName || `${cleanTicker} Sovereign Equity`,
    issuerId: ipoData.issuerId || 'you',
    issuerName: ipoData.issuerName || 'You (Current User)',
    issuerHandle: ipoData.issuerHandle || 'you',
    issuerAvatar: ipoData.issuerAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    marketWay: ipoData.marketWay || (ipoData.ipoType === 'personal' ? 'final' : 'stable'),
    status: 'pending_admin_approval',
    sharesOffered: shares,
    offeringPriceUSD: offeringPrice,
    targetValuationUSD: targetValuation,
    circulatingFloat: Math.round(shares * 0.4),
    currentLivePriceUSD: offeringPrice,
    currentLiveValuationUSD: targetValuation,
    priceChangePercent24h: 0,
    submittedAt: new Date().toISOString(),
    businessDetails: ipoData.businessDetails ? { ...ipoData.businessDetails, mediaGallery: media } : undefined,
    personalDetails: ipoData.personalDetails ? { ...ipoData.personalDetails, mediaGallery: media } : undefined,
    mediaGallery: media
  };

  const updated = [newIPO, ...current];
  saveIPORequests(updated);
  return newIPO;
}

export function updateIPOMedia(ipoId: string, media: import('../types/stocks').IPOMediaItem[]): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      const updatedItem = {
        ...item,
        mediaGallery: media,
        businessDetails: item.businessDetails ? { ...item.businessDetails, mediaGallery: media } : undefined,
        personalDetails: item.personalDetails ? { ...item.personalDetails, mediaGallery: media } : undefined
      };
      return updatedItem;
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function requestDelistIPO(ipoId: string, reason: string): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'delist_pending_admin_approval' as IPOStatus,
        delistReason: reason.trim(),
        delistRequestedAt: new Date().toISOString()
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminApproveIPO(ipoId: string, adminName = 'System Protocol Admin', notes = 'Approved after institutional review.'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'active' as IPOStatus,
        reviewedAt: new Date().toISOString(),
        reviewedBy: adminName,
        adminNotes: notes
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminRejectIPO(ipoId: string, notes?: string, adminName = 'System Protocol Admin'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'rejected' as IPOStatus,
        reviewedAt: new Date().toISOString(),
        reviewedBy: adminName,
        adminNotes: notes || 'Prospectus requirements not satisfied.'
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminApproveDelist(ipoId: string, adminName = 'System Protocol Admin'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'delisted' as IPOStatus,
        delistReviewedAt: new Date().toISOString(),
        delistReviewedBy: adminName
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminRejectDelist(ipoId: string, notes?: string, adminName = 'System Protocol Admin'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'active' as IPOStatus,
        delistReviewedAt: new Date().toISOString(),
        delistReviewedBy: adminName,
        adminNotes: notes || 'Delist request rejected. Trading remains active.'
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function cancelIPORequest(ipoId: string): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.filter((item) => {
    if (item.id === ipoId) {
      if (item.status === 'pending_admin_approval') {
        found = true;
        return false; // Remove the item
      }
    }
    return true; // Keep the item
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

// Convert an approved active IPO into a tradeable StockItem
export function convertIPOToStockItem(ipo: IPORequest): StockItem {
  const liveVal = getLiveIPOValuation(ipo);
  const livePrice = liveVal.livePrice;
  const isPersonal = ipo.ipoType === 'personal';
  const sector = isPersonal 
    ? 'Sovereign Reserves' 
    : (ipo.businessDetails?.sector || 'Technology & AI');
  
  const description = isPersonal
    ? (ipo.personalDetails?.personaProfile || `${ipo.equityName} - Personal Sovereign Equity released via platform IPO.`)
    : (ipo.businessDetails?.valueProposition || ipo.businessDetails?.businessModel || `${ipo.equityName} - Corporate Enterprise Equity.`);

  return {
    ticker: ipo.ticker,
    name: ipo.equityName,
    price: livePrice,
    changeUSD: liveVal.changeUSD,
    changePercent: liveVal.changePercent,
    marketType: ipo.marketWay,
    settlementMethod: isPersonal 
      ? `Final Coin (${ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL'})`
      : `${ipo.businessDetails?.backingCoinType === 'stable_coin' ? 'USD Stablecoin' : ipo.businessDetails?.backingCoinType === 'crypto' ? 'Cryptocurrency' : ipo.businessDetails?.backingCoinType === 'fiat' ? 'USD Fiat Clearing' : 'Final Coin'} (${ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')})`,
    high24h: +(livePrice * 1.05).toFixed(2),
    low24h: +(livePrice * 0.98).toFixed(2),
    openPrice: +(livePrice * 0.99).toFixed(2),
    prevClose: ipo.offeringPriceUSD,
    volume: `$${(liveVal.currentMarketCap * 0.04 / 1e6).toFixed(1)}M`,
    avgVolume: `$${(liveVal.currentMarketCap * 0.035 / 1e6).toFixed(1)}M`,
    marketCap: `$${(liveVal.currentMarketCap / 1e6).toFixed(1)}M`,
    peRatio: isPersonal ? 14.2 : 28.5,
    eps: isPersonal ? 1.75 : 2.45,
    dividendYield: isPersonal ? '3.80%' : '1.90%',
    beta: 1.05,
    fiftyTwoWeekHigh: +(livePrice * 1.15).toFixed(2),
    fiftyTwoWeekLow: +(livePrice * 0.85).toFixed(2),
    sector: sector as any,
    subSector: isPersonal ? 'Personal Sovereign Equity' : ipo.businessDetails?.industry,
    description,
    exchange: 'SOVEREIGN_NODE',
    analystRating: 'Strong Buy',
    analystTargetUSD: +(livePrice * 1.28).toFixed(2),
    analystCount: 18,
    sparkline: [
      livePrice * 0.96,
      livePrice * 0.97,
      livePrice * 0.965,
      livePrice * 0.98,
      livePrice * 0.975,
      livePrice * 0.99,
      livePrice * 1.01,
      livePrice * 1.005,
      livePrice * 1.025,
      livePrice * 1.032
    ],
    history: generateHistory(livePrice, 0.02),
    ceo: isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.executives?.ceo,
    headquarters: isPersonal ? 'Global Sovereign Node' : ipo.businessDetails?.headquarters,
    foundedYear: isPersonal ? 2026 : ipo.businessDetails?.foundedYear,
    employeesCount: isPersonal ? '1 Principal' : ipo.businessDetails?.employeeCount,
    revenueTTM: isPersonal 
      ? `$${((ipo.personalDetails?.fiveModeNetWorth?.totalNetWorthUSD || 10e6) * 0.2 / 1e6).toFixed(1)}M` 
      : `$${((ipo.businessDetails?.annualRevenueUSD || 10e6) / 1e6).toFixed(1)}M`,
    profitMargin: isPersonal ? '85.0%' : `${ipo.businessDetails?.netProfitMarginPercent || 25}%`,
    issuanceType: isPersonal ? 'personal' : 'business',
    assetCategory: isPersonal ? 'personal' : 'business',
    issuanceCoinSymbol: isPersonal 
      ? (ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL')
      : (ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')),
    issuanceCoinName: isPersonal
      ? (ipo.personalDetails?.backingFinalCoinName || 'Final Sovereign Coin')
      : (ipo.businessDetails?.backingCoinName || (ipo.marketWay === 'stable' ? 'USD Stablecoin' : ipo.marketWay === 'crypto' ? 'Bitcoin Crypto Asset' : 'Final Coin')),
    issuanceCoinType: isPersonal
      ? 'final_coin'
      : (ipo.businessDetails?.backingCoinType || (ipo.marketWay === 'stable' ? 'stable_coin' : ipo.marketWay === 'crypto' ? 'crypto' : 'final_coin')),
    issuerName: ipo.issuerName || (isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.companyName),
    issuerHandle: ipo.issuerHandle || ipo.personalDetails?.handle,
    issuerAvatar: ipo.issuerAvatar,
    ipoRefId: ipo.id
  };
}

// Get all active stocks combined with active approved IPO stocks
export function getAllActiveMarketStocks(): StockItem[] {
  const ipos = getStoredIPORequests();
  const activeIPOs = ipos.filter((ipo) => ipo.status === 'active');
  const ipoStockItems = activeIPOs.map(convertIPOToStockItem);
  
  // Combine initial benchmark stocks with all user-created and active IPO stocks (deduplicating by ticker)
  const tickerMap = new Map<string, StockItem>();
  
  // Add initial benchmark stocks first
  INITIAL_STOCKS.forEach((stock) => {
    tickerMap.set(stock.ticker, stock);
  });
  
  // Override or add all active approved/launched IPO equities (e.g. personal sovereign equities, creator IPOs, business offerings)
  ipoStockItems.forEach((ipoStock) => {
    tickerMap.set(ipoStock.ticker, ipoStock);
  });
  
  return Array.from(tickerMap.values());
}
