import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Trash2,
  Sparkles,
  Coins,
  ShieldCheck,
  Zap,
  ArrowRight,
  TrendingUp,
  Flame,
  Plus,
  Lock,
  CheckCircle2,
  AlertCircle,
  Clock,
  Layers,
  Copy,
  Check,
  ArrowUpRight,
  RefreshCw,
  Info,
  DollarSign,
  Activity,
  Sliders,
  Wallet,
  Building2,
  ExternalLink,
  ChevronRight,
  X,
  Image as ImageIcon,
  Video,
  Upload,
  Eye,
  FileText
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import {
  CustomCoin,
  MAX_FINAL_COINS_PER_USER,
  FinalCoinDeploymentStatus,
  CoinAttachment
} from '../../types/coinLaunch';
import {
  getStoredCustomCoins,
  saveCustomCoins,
  mintCustomCoinSupply,
  burnCustomCoinSupply
} from '../../data/customCoinsData';
import { getStoredUserWallets, saveStoredUserWallets } from '../../data/defaultWallets';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { FinalCoinDetailsModal } from './FinalCoinDetailsModal';

interface FinalCoinMintStudioProps {
  currentUser: AuthSession | null;
  onOpenExchange?: (tokenSymbol?: string) => void;
  onOpenHoldings?: () => void;
}

const COLOR_PRESETS = [
  { id: 'amber', label: 'Golden Sovereign', bg: 'from-amber-400 via-amber-500 to-amber-600 text-slate-950', border: 'border-amber-400/40' },
  { id: 'emerald', label: 'Emerald Vault', bg: 'from-emerald-500 via-teal-600 to-emerald-700 text-white', border: 'border-emerald-400/40' },
  { id: 'purple', label: 'Cosmic Violet', bg: 'from-purple-600 via-indigo-600 to-violet-700 text-white', border: 'border-purple-400/40' },
  { id: 'blue', label: 'Azure Subnet', bg: 'from-blue-600 via-cyan-600 to-sky-700 text-white', border: 'border-blue-400/40' },
  { id: 'rose', label: 'Crimson Treasury', bg: 'from-rose-500 via-pink-600 to-red-700 text-white', border: 'border-rose-400/40' },
];

const ICONS = ['⚡', '🛡️', '👑', '🌌', '🏛️', '💎', '🪙', '🌟', '🚀', '🔥', '🦅', '🦁', '🪐'];

import { deleteCustomCoin } from '../../data/customCoinsData';
export const FinalCoinMintStudio: React.FC<FinalCoinMintStudioProps> = ({
  currentUser,
  onOpenExchange,
  onOpenHoldings
}) => {
  const userId = currentUser?.id || 'guest';
  const userName = currentUser?.name || 'Sovereign Pioneer';
  const userHandle = currentUser?.username || currentUser?.id || 'sovereign_builder';
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  const [allCoins, setAllCoins] = useState<CustomCoin[]>(() => getStoredCustomCoins());
  const [copiedAddress, setCopiedAddress] = useState<string | null>(null);

  // Deletion Confirmation
  const [coinToDelete, setCoinToDelete] = useState<CustomCoin | null>(null);

  // Modals & Details View
  const [selectedCoinForDetails, setSelectedCoinForDetails] = useState<CustomCoin | null>(null);
  const [isMintModalOpen, setIsMintModalOpen] = useState(false);
  const [selectedCoinForMint, setSelectedCoinForMint] = useState<CustomCoin | null>(null);
  const [mintAmountInput, setMintAmountInput] = useState<string>('50000');
  const [isMintingSupply, setIsMintingSupply] = useState(false);

  // New Coin Form State
  const [isDeployWizardOpen, setIsDeployWizardOpen] = useState(false);
  const [coinName, setCoinName] = useState('');
  const [coinSymbol, setCoinSymbol] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLOR_PRESETS[0]);
  const [selectedIcon, setSelectedIcon] = useState('⚡');
  const [description, setDescription] = useState('');
  const [formAttachments, setFormAttachments] = useState<CoinAttachment[]>([]);
  const [formMediaUrl, setFormMediaUrl] = useState('');
  const [formError, setFormError] = useState('');
  const [isProcessingMedia, setIsProcessingMedia] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Toast
  const [toastMsg, setToastMsg] = useState('');
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 4500);
  };

  // Sync custom coins
  useEffect(() => {
    const handleUpdate = () => {
      const stored = getStoredCustomCoins();
      setAllCoins(stored);
      // Update selected coin if details modal is open
      if (selectedCoinForDetails) {
        const found = stored.find(c => c.id === selectedCoinForDetails.id);
        if (found) setSelectedCoinForDetails(found);
      }
    };
    window.addEventListener('final_finance_custom_coins_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_custom_coins_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [selectedCoinForDetails]);

  // Filter user's created Final Coins vs Network Final Coins
  const userCreatedFinalCoins = useMemo(() => {
    return allCoins.filter((c) => {
      if (c.coinType !== 'final_coin') return false;
      if (isAdmin) {
        return c.isAdminCoin || c.creatorId === userId || c.creatorId === 'you';
      }
      return (c.creatorId === userId || c.creatorId === 'you' || c.creatorHandle === 'sovereign_builder') && !c.isAdminCoin;
    });
  }, [allCoins, userId, isAdmin]);

  const networkFinalCoins = useMemo(() => {
    return allCoins.filter((c) => c.coinType === 'final_coin' && !userCreatedFinalCoins.some(uc => uc.id === c.id));
  }, [allCoins, userCreatedFinalCoins]);

  // Quota calculation
  const createdCount = userCreatedFinalCoins.length;
  const maxQuota = MAX_FINAL_COINS_PER_USER; // 5

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAddress(text);
    setTimeout(() => setCopiedAddress(null), 2000);
  };

  // Handle Photo & Video upload in Create Wizard
  const handleWizardFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsProcessingMedia(true);
    const newItems: CoinAttachment[] = [];
    let filesProcessed = 0;

    Array.from(files).forEach((file) => {
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isVideo && !isImage) {
        setFormError('Please select only images (JPG, PNG, WebP) or videos (MP4, WebM).');
        filesProcessed += 1;
        if (filesProcessed === files.length) setIsProcessingMedia(false);
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const fileSizeMB = (file.size / (1024 * 1024)).toFixed(1);
          newItems.push({
            id: `att-draft-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            type: isVideo ? 'video' : 'photo',
            url: reader.result,
            name: file.name,
            size: `${fileSizeMB} MB`,
            uploadedAt: new Date().toISOString(),
            caption: file.name
          });
        }
        filesProcessed += 1;
        if (filesProcessed === files.length) {
          setFormAttachments(prev => [...prev, ...newItems]);
          setIsProcessingMedia(false);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Add media URL in wizard
  const handleAddWizardUrl = () => {
    if (!formMediaUrl.trim()) return;
    const url = formMediaUrl.trim();
    const isVideo = url.match(/\.(mp4|webm|mov|ogg)($|\?)/i) || url.includes('video');
    const newItem: CoinAttachment = {
      id: `att-url-${Date.now()}`,
      type: isVideo ? 'video' : 'photo',
      url,
      name: isVideo ? 'Video Attachment' : 'Photo Attachment',
      uploadedAt: new Date().toISOString(),
      caption: 'Attached Media'
    };
    setFormAttachments(prev => [...prev, newItem]);
    setFormMediaUrl('');
  };

  const removeFormAttachment = (id: string) => {
    setFormAttachments(prev => prev.filter(item => item.id !== id));
  };

  // Create a New Final Coin
  const handleCreateFinalCoin = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Pre-flight checks
    if (!coinName.trim()) {
      setFormError('Please provide a name for your Final Coin.');
      return;
    }
    if (!coinSymbol.trim() || coinSymbol.length < 2 || coinSymbol.length > 8) {
      setFormError('Coin Symbol must be between 2 and 8 uppercase letters (e.g. QGEN).');
      return;
    }

    const cleanSymbol = coinSymbol.trim().toUpperCase();
    const cleanName = coinName.trim();

    // Check reserved names
    const reservedNames = ['final coin', 'final coins', 'final admin coin', 'afnl', 'stablecoin', 'cryptocurrency', 'sovereign unit'];
    if (reservedNames.includes(cleanName.toLowerCase()) || reservedNames.includes(cleanSymbol.toLowerCase())) {
      setFormError(`"${cleanName}" is a reserved protocol identifier.`);
      return;
    }

    // Check unique symbol
    if (allCoins.some(c => c.symbol.toUpperCase() === cleanSymbol)) {
      setFormError(`The symbol "${cleanSymbol}" is already registered. Please choose a unique ticker.`);
      return;
    }

    // Check quota
    if (createdCount >= maxQuota) {
      setFormError(`Maximum limit reached: You have created ${createdCount}/${maxQuota} Final Coins.`);
      return;
    }

    const photoUrls = formAttachments.filter(a => a.type === 'photo').map(a => a.url);
    const videoUrls = formAttachments.filter(a => a.type === 'video').map(a => a.url);

    const newCoin: CustomCoin = {
      id: `final_coin_${Date.now()}_${cleanSymbol.toLowerCase()}`,
      name: cleanName,
      symbol: cleanSymbol,
      coinType: 'final_coin',
      pegCurrency: 'none',
      pegTargetDisplay: 'Sovereign Asset (Unpegged)',
      pegRateUSD: 0,
      priceUSD: 0,
      totalSupply: 5000000,
      circulatingSupply: 5000000,
      burnedSupply: 0,
      reserveRatioPercent: 0,
      reserveBackingDescription: 'Sovereign protocol asset. Independent valuation.',
      collateralAssetType: 'Sovereign Protocol Reserve Vault',
      decimals: 18,
      creatorId: userId,
      creatorName: userName,
      creatorHandle: userHandle,
      isAdminCoin: false,
      createdAt: new Date().toISOString(),
      contractAddress: `0x${cleanSymbol}${Math.random().toString(16).substring(2, 34)}`,
      network: 'Final Ledger Layer-1',
      logoBg: selectedColor.bg,
      iconSymbol: selectedIcon,
      description: description.trim() || `${cleanName} (${cleanSymbol}) is a sovereign Final Coin on Final Ledger Layer-1.`,
      attachments: formAttachments,
      photos: photoUrls,
      videos: videoUrls,
      status: 'active',
      auditScore: 99,
      holdersCount: 1,
      dailyVolumeUSD: 0,
      change24h: 0.0,
      high24h: 0,
      low24h: 0
    };

    // Save new coin
    const existingCoinsList = getStoredCustomCoins();
    const updatedCoins = [newCoin, ...existingCoinsList];
    saveCustomCoins(updatedCoins);
    setAllCoins(updatedCoins);

    // Add initial allocation into user's wallet
    const initialAllocation = 5000000;
    const currentWallets = getStoredUserWallets(userId);
    const existingFinalCoins = currentWallets.finalCoins || [];
    const updatedWalletFinalCoins = [
      ...existingFinalCoins.filter(fc => fc.symbol !== newCoin.symbol),
      {
        id: `fc-${newCoin.id}`,
        name: newCoin.name,
        symbol: newCoin.symbol,
        balance: initialAllocation,
        unitPriceUSD: 0,
        change24h: 0.0,
        utility: `Creator Initial Allocation (${initialAllocation.toLocaleString()} ${newCoin.symbol})`,
        contractAddress: newCoin.contractAddress
      }
    ];
    saveStoredUserWallets(userId, { ...currentWallets, finalCoins: updatedWalletFinalCoins });

    // Record in Universal Ledger
    const nowIso = new Date().toISOString();
    recordLedgerTransaction(userId, {
      id: `tx-mint-${Date.now()}`,
      receiptNumber: `REC-MNT-${Date.now().toString().slice(-6)}`,
      taxYear: new Date().getFullYear(),
      timestamp: nowIso,
      dateIso: nowIso,
      type: 'deposit',
      category: 'money_inflow',
      mode: 'final_coin',
      title: `Initial Mint: Created ${newCoin.name} (${newCoin.symbol})`,
      description: `Sovereign creation of ${newCoin.name} on Final Protocol. Initial supply of 5,000,000 ${newCoin.symbol} minted to creator.`,
      amountUSD: 0,
      feeUSD: 0,
      netAmountUSD: 0,
      sourceOrDestination: 'Final Protocol Subnet',
      counterpartyOrIssuer: userName,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        taxableAmountUSD: 0,
        irsCategoryNote: 'Sovereign asset creation capital addition.'
      },
      status: 'Settled',
      clearingNode: 'Final Settlement Subnet #1',
      cryptographicHash: `0xMNT_${Date.now()}`,
      signature: `SIG-MNT-${Date.now()}`
    });

    setIsDeployWizardOpen(false);
    showToast(`${cleanName} is now LIVE on Final Protocol!`);
    
    // Reset form
    setCoinName('');
    setCoinSymbol('');
    setDescription('');
    setFormAttachments([]);
  };

  // Handler: Delete Final Coin
  const handleDeleteCoin = (coinId: string) => {
    const res = deleteCustomCoin(coinId, userId);
    if (res.success) {
      const updated = getStoredCustomCoins();
      setAllCoins(updated);
      showToast('Sovereign Final Coin deleted from protocol.');
    } else {
      showToast(res.message);
    }
    setCoinToDelete(null);
  };

  // Handler: Mint Additional Supply
  const handleExecuteMintSupply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCoinForMint) return;
    const amount = parseFloat(mintAmountInput);
    if (isNaN(amount) || amount <= 0) {
      showToast('Please specify a valid mint amount greater than 0.');
      return;
    }

    setIsMintingSupply(true);
    setTimeout(() => {
      const res = mintCustomCoinSupply(selectedCoinForMint.id, amount, userId);
      if (res.success && res.updatedCoin) {
        // Update wallet
        const currentWallets = getStoredUserWallets(userId);
        const existingFinalCoins = currentWallets.finalCoins || [];
        const existingItem = existingFinalCoins.find(fc => fc.symbol === selectedCoinForMint.symbol);
        const newBalance = (existingItem?.balance || 0) + amount;

        const updatedWalletFinalCoins = [
          ...existingFinalCoins.filter(fc => fc.symbol !== selectedCoinForMint.symbol),
          {
            id: existingItem?.id || `fc-${selectedCoinForMint.id}`,
            name: selectedCoinForMint.name,
            symbol: selectedCoinForMint.symbol,
            balance: newBalance,
            unitPriceUSD: 0,
            change24h: selectedCoinForMint.change24h,
            utility: `Creator Managed Supply (${newBalance.toLocaleString()} ${selectedCoinForMint.symbol})`,
            contractAddress: selectedCoinForMint.contractAddress
          }
        ];
        saveStoredUserWallets(userId, { ...currentWallets, finalCoins: updatedWalletFinalCoins });

        // Record in ledger
        const nowIso = new Date().toISOString();
        recordLedgerTransaction(userId, {
          id: `tx-mint-more-${Date.now()}`,
          receiptNumber: `REC-MNT-${Date.now().toString().slice(-6)}`,
          taxYear: new Date().getFullYear(),
          timestamp: nowIso,
          dateIso: nowIso,
          type: 'deposit',
          category: 'money_inflow',
          mode: 'final_coin',
          title: `Minted ${amount.toLocaleString()} ${selectedCoinForMint.symbol}`,
          description: `Authorized supply expansion for ${selectedCoinForMint.name}. Deposited ${amount.toLocaleString()} ${selectedCoinForMint.symbol} into creator wallet.`,
          amountUSD: 0,
          feeUSD: 0,
          netAmountUSD: 0,
          sourceOrDestination: 'Final Protocol Minting Engine',
          counterpartyOrIssuer: userName,
          paymentCoinSymbol: selectedCoinForMint.symbol,
          clearingNode: 'Final Settlement Subnet',
          cryptographicHash: `0xMINT_${Date.now()}`,
          signature: `SIG-MNT-${Date.now()}`,
          status: 'Settled',
          taxClassification: { formMapping: 'Non-Taxable Transfer', taxableEvent: false, taxableAmountUSD: 0, irsCategoryNote: 'Authorized token supply minting' }
        });

        showToast(res.message);
        setAllCoins(getStoredCustomCoins());
      } else {
        showToast(res.message);
      }
      setIsMintingSupply(false);
      setSelectedCoinForMint(null);
    }, 500);
  };

  return (
    <div className="space-y-6 text-left">
      {/* Toast */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-3 duration-200 text-xs font-mono">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* STUDIO HEADER */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm relative overflow-hidden text-slate-900">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 tracking-tight">
              Final Coin Mint &amp; Creator Studio
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed font-normal">
              Manage and deploy sovereign Final Coins. Deployed one coin at a time on Final Ledger Layer-1.
            </p>
          </div>

          {/* Quota & Quick Action Card */}
          <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 shadow-xs shrink-0 lg:w-80 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">Creation Quota</span>
              <span className="text-xs font-bold text-amber-900 font-mono bg-amber-100 px-2.5 py-1 rounded-lg border border-amber-200">
                {createdCount} / {maxQuota} Created
              </span>
            </div>

            {/* 5-Slot Quota Indicator */}
            <div className="grid grid-cols-5 gap-1.5">
              {[0, 1, 2, 3, 4].map((index) => {
                const isFilled = index < createdCount;
                return (
                  <div
                    key={index}
                    className={`h-2.5 rounded-full transition-all ${
                      isFilled
                        ? 'bg-amber-500 shadow-xs'
                        : 'bg-slate-200 border border-slate-300'
                    }`}
                    title={isFilled ? `Slot ${index + 1}: Used` : `Slot ${index + 1}: Available`}
                  />
                );
              })}
            </div>

            <div className="text-[11px] text-slate-600 flex justify-between font-medium">
              <span>{maxQuota - createdCount} slots available</span>
              <span>{createdCount >= maxQuota ? 'Quota Limit Reached' : 'Ready to Mint'}</span>
            </div>

            <button
              type="button"
              onClick={() => {
                setFormError('');
                setIsDeployWizardOpen(true);
              }}
              disabled={createdCount >= maxQuota}
              className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm ${
                createdCount >= maxQuota
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold shadow-amber-500/20 active:scale-[0.98]'
              }`}
            >
              <Sparkles className="w-4 h-4 fill-slate-950" />
              <span>
                {createdCount >= maxQuota
                  ? 'Quota Full (5/5 Final Coins)'
                  : 'Mint New Final Coin'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* MANAGE YOUR SOVEREIGN ASSETS SECTION */}
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span>Manage Your Sovereign Assets</span>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                {userCreatedFinalCoins.length} / {maxQuota}
              </span>
            </h2>
            <p className="text-[11px] text-slate-500 font-medium">
              Create and manage up to {maxQuota} sovereign Final Coins.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {onOpenHoldings && (
              <button
                type="button"
                onClick={onOpenHoldings}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Wallet className="w-3.5 h-3.5 text-slate-500" />
                <span>View in Wallet</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setFormError('');
                setIsDeployWizardOpen(true);
              }}
              disabled={createdCount >= maxQuota}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                createdCount >= maxQuota
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-sm'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Mint Final Coin</span>
            </button>
          </div>
        </div>

        {/* List of Created Coins */}
        {userCreatedFinalCoins.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center space-y-4 shadow-sm">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 mx-auto flex items-center justify-center text-amber-600">
              <Zap className="w-7 h-7" />
            </div>
            <div className="max-w-md mx-auto space-y-1">
              <h3 className="text-base font-bold text-slate-900">No Final Coins Minted Yet</h3>
            </div>
            <button
              type="button"
              onClick={() => {
                setFormError('');
                setIsDeployWizardOpen(true);
              }}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs inline-flex items-center gap-2 shadow-sm cursor-pointer transition-all active:scale-[0.98]"
            >
              <Sparkles className="w-4 h-4 fill-slate-950" />
              <span>Mint Your First Final Coin (1 of 5)</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {userCreatedFinalCoins.map((coin) => {
              const mediaCount = (coin.attachments?.length || 0) + (coin.photos?.length || 0) + (coin.videos?.length || 0);

              return (
                <div
                  key={coin.id}
                  className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4"
                >
                  {/* Coin Header */}
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${coin.logoBg} flex items-center justify-center text-lg font-bold shadow-md shrink-0`}>
                          {coin.iconSymbol}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="text-sm font-bold text-slate-900 leading-tight">{coin.name}</h4>
                            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-mono text-[10px] font-bold">
                              {coin.symbol}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>


                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {coin.description}
                    </p>

                    {/* Media Attachments Badge & Quick Preview */}
                    <div className="flex items-center justify-between text-xs pt-1">
                      <button
                        type="button"
                        onClick={() => setSelectedCoinForDetails(coin)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-[11px] font-bold transition-colors cursor-pointer"
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-purple-600" />
                        <span>{mediaCount > 0 ? `${mediaCount} Media Attached` : 'Attach Photos / Videos'}</span>
                      </button>
                    </div>

                    {/* Supply & Metrics */}
                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-semibold">Total Supply</span>
                        <p className="font-bold text-slate-900 font-mono">
                          {coin.totalSupply.toLocaleString()} {coin.symbol}
                        </p>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase font-semibold">Circulation</span>
                        <p className="font-bold text-slate-900 font-mono">
                          {coin.circulatingSupply.toLocaleString()} {coin.symbol}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-1 border-t border-slate-100">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSelectedCoinForDetails(coin)}
                        className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Details</span>
                      </button>

                      {(coin.creatorId === userId || coin.creatorId === 'you') && (
                        <button
                          type="button"
                          onClick={() => setCoinToDelete(coin)}
                          className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 transition-all cursor-pointer shadow-xs active:scale-90"
                          title="Delete Protocol"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* NETWORK VERIFIED FINAL COINS SECTION */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">Network Verified Final Coins</h3>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {networkFinalCoins.map((coin) => (
            <div
              key={coin.id}
              className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between space-y-3 hover:shadow-md transition-all"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-2xl bg-gradient-to-br ${coin.logoBg} flex items-center justify-center text-base font-bold shadow-md shrink-0`}>
                      {coin.iconSymbol}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{coin.name}</h4>
                      <span className="font-mono text-xs font-bold text-slate-500">{coin.symbol}</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {coin.description}
                </p>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedCoinForDetails(coin)}
                  className="w-full py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5 text-slate-600" />
                  <span>View Details &amp; Attachments</span>
                </button>

                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Issuer: {coin.creatorName}</span>
                  <div className="flex items-center gap-3">
                    {(coin.creatorId === userId || coin.creatorId === 'you') && (
                      <button
                        type="button"
                        onClick={() => setCoinToDelete(coin)}
                        className="text-rose-600 hover:text-rose-700 font-bold inline-flex items-center gap-1 cursor-pointer p-1 rounded-lg hover:bg-rose-50 transition-colors"
                        title="Delete this Final Coin"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL 1: DEPLOY NEW FINAL COIN WIZARD */}
      {isDeployWizardOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/40 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl border border-slate-200/80 shadow-2xl overflow-hidden my-6 text-left max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-5 sm:p-6 bg-white text-slate-900 flex items-center justify-between border-b border-slate-100 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-200/80 flex items-center justify-center text-amber-600">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-slate-900">Mint New Sovereign Final Coin</h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsDeployWizardOpen(false)}
                className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Error Message */}
            {formError && (
              <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-xs text-rose-800">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleCreateFinalCoin} className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                    Coin Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Apex Horizon Final Coin"
                    value={coinName}
                    onChange={(e) => setCoinName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                    Symbol / Ticker * (2-8 Chars)
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={8}
                    placeholder="e.g. AHFN"
                    value={coinSymbol}
                    onChange={(e) => setCoinSymbol(e.target.value.toUpperCase())}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-sm uppercase"
                  />
                </div>
              </div>

              {/* PHOTOS & VIDEOS ATTACHMENTS SECTION */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-amber-600" />
                    <span>Upload Photos &amp; Videos (Attachments)</span>
                  </label>
                  <span className="text-[10px] text-slate-500">
                    {formAttachments.length} attached
                  </span>
                </div>

                {/* Dropzone */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="p-4 rounded-xl bg-white border-2 border-dashed border-slate-300 hover:border-amber-500 transition-all text-center cursor-pointer space-y-1"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept="image/*,video/*"
                    onChange={handleWizardFileUpload}
                    className="hidden"
                  />
                  <div className="w-8 h-8 rounded-full bg-amber-50 text-amber-700 mx-auto flex items-center justify-center">
                    <Upload className="w-4 h-4" />
                  </div>
                  <p className="text-xs font-bold text-slate-700">Click or Drag to Upload Photos &amp; Videos</p>
                  <p className="text-[10px] text-slate-400">PNG, JPG, WebP, SVG, MP4, WebM</p>
                </div>

                {/* Media URL Alternative */}
                <div className="flex items-center gap-2">
                  <input
                    type="url"
                    placeholder="Or paste direct image or video URL..."
                    value={formMediaUrl}
                    onChange={(e) => setFormMediaUrl(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddWizardUrl}
                    disabled={!formMediaUrl.trim()}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs disabled:opacity-40 cursor-pointer"
                  >
                    Add URL
                  </button>
                </div>

                {/* Attachments Preview Grid */}
                {formAttachments.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                    {formAttachments.map((item) => (
                      <div
                        key={item.id}
                        className="relative rounded-xl overflow-hidden border border-slate-200 bg-white shadow-xs group"
                      >
                        {item.type === 'video' ? (
                          <div className="w-full h-20 bg-slate-900 flex items-center justify-center text-white">
                            <Video className="w-6 h-6 text-amber-400" />
                          </div>
                        ) : (
                          <img
                            src={item.url}
                            alt={item.name}
                            className="w-full h-20 object-cover"
                          />
                        )}
                        <span className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-slate-950/80 text-[8px] font-mono text-white">
                          {item.type === 'video' ? 'VIDEO' : 'PHOTO'}
                        </span>
                        <button
                          type="button"
                          onClick={() => removeFormAttachment(item.id)}
                          className="absolute top-1 right-1 p-1 rounded-full bg-rose-600 text-white opacity-80 hover:opacity-100 transition-opacity cursor-pointer"
                        >
                          <X className="w-3 h-3" />
                        </button>
                        <p className="text-[9px] text-slate-600 truncate px-1.5 py-1 font-mono">{item.name}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Visual Styling */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  Choose Color Preset &amp; Symbol
                </label>
                <div className="flex items-center gap-2 flex-wrap mb-3">
                  {COLOR_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setSelectedColor(preset)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        selectedColor.id === preset.id
                          ? 'ring-2 ring-slate-900 bg-slate-900 text-white shadow-md'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      <div className={`w-3.5 h-3.5 rounded-full bg-gradient-to-br ${preset.bg}`} />
                      <span>{preset.label}</span>
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1.5 flex-wrap">
                  {ICONS.map((icon) => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => setSelectedIcon(icon)}
                      className={`w-9 h-9 rounded-xl text-base flex items-center justify-center transition-all cursor-pointer ${
                        selectedIcon === icon
                          ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-400 font-bold scale-110 shadow-sm'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  Description &amp; Utility (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Describe your sovereign final coin's utility, community governance, or treasury goals..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs"
                />
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsDeployWizardOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs shadow-md inline-flex items-center gap-2 cursor-pointer transition-all active:scale-[0.98]"
                >
                  <Sparkles className="w-4 h-4 fill-slate-950" />
                  <span>Save Draft &amp; Choose Deployment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: MINT ADDITIONAL SUPPLY */}
      {selectedCoinForMint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200 text-left">
          <div className="relative w-full max-w-md bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl bg-gradient-to-br ${selectedCoinForMint.logoBg} flex items-center justify-center text-lg font-bold shadow-md`}>
                  {selectedCoinForMint.iconSymbol}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Mint More {selectedCoinForMint.symbol}</h3>
                  <p className="text-xs text-slate-500">Authorized Creator Supply Expansion</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCoinForMint(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleExecuteMintSupply} className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1.5">
                  Amount to Mint ({selectedCoinForMint.symbol})
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  step={100}
                  value={mintAmountInput}
                  onChange={(e) => setMintAmountInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-sm"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Current Total Supply: {selectedCoinForMint.totalSupply.toLocaleString()} {selectedCoinForMint.symbol}
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedCoinForMint(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isMintingSupply}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  {isMintingSupply ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                  <span>Confirm Mint</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DETAILS & MEDIA SHOWCASE MODAL */}
      {selectedCoinForDetails && (
        <FinalCoinDetailsModal
          coin={selectedCoinForDetails}
          isOpen={!!selectedCoinForDetails}
          onClose={() => setSelectedCoinForDetails(null)}
          currentUser={currentUser}
          onOpenExchange={onOpenExchange}
          onOpenMintModal={(coin) => {
            setSelectedCoinForMint(coin);
            setMintAmountInput('50000');
          }}
          onCoinUpdated={(updated) => {
            setSelectedCoinForDetails(updated);
            setAllCoins(getStoredCustomCoins());
          }}
        />
      )}

      {/* Delete Confirmation Modal */}
      {coinToDelete && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-300">
            <div className="p-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-rose-50 flex items-center justify-center text-rose-600 mx-auto">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div className="space-y-1 text-left">
                <h3 className="text-lg font-bold text-slate-900 text-center">Confirm Protocol Deletion</h3>
                <p className="text-xs text-slate-500 leading-relaxed text-center">
                  Are you sure you want to delete <span className="font-bold text-slate-900">{coinToDelete.name}</span>? This action is irreversible and will purge all on-chain metadata.
                </p>
              </div>
            </div>
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-3">
              <button
                onClick={() => setCoinToDelete(null)}
                className="flex-1 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteCoin(coinToDelete.id)}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 shadow-md transition-all cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
