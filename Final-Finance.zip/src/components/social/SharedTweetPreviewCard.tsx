import React from 'react';
import {
  CheckCircle2,
  Play,
  Heart,
  Repeat2,
  MessageCircle,
  ExternalLink,
  Twitter,
} from 'lucide-react';
import { SharedTweetCardData } from '../../types/tweet';

interface SharedTweetPreviewCardProps {
  data: SharedTweetCardData;
  onClick?: () => void;
  compact?: boolean;
  darkSurface?: boolean;
}

export const SharedTweetPreviewCard: React.FC<SharedTweetPreviewCardProps> = ({
  data,
  onClick,
  compact = false,
  darkSurface = false,
}) => {
  const cleanHandle = (data.authorHandle || 'user').replace(/^@/, '');
  const hasThumbnail = Boolean(data.thumbnailUrl);
  const hasVideo = Boolean(data.videoUrl);

  return (
    <div
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={(e) => {
        if (onClick) {
          e.stopPropagation();
          onClick();
        }
      }}
      onKeyDown={(e) => {
        if (onClick && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          e.stopPropagation();
          onClick();
        }
      }}
      className={`w-full rounded-2xl overflow-hidden border text-left transition-all ${
        onClick ? 'cursor-pointer hover:border-emerald-400 active:scale-[0.995]' : ''
      } ${
        darkSurface
          ? 'bg-neutral-900 border-neutral-700 text-neutral-100'
          : 'bg-white border-slate-200 text-slate-900 shadow-2xs'
      }`}
    >
      {/* Visual Thumbnail / Media Banner (Twitter-style Summary Large Card) */}
      {hasThumbnail ? (
        <div className={`relative w-full bg-slate-950 overflow-hidden ${compact ? 'h-32' : 'h-40 sm:h-44'}`}>
          <img
            src={data.thumbnailUrl}
            alt={`Post thumbnail by ${data.authorName}`}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
          {hasVideo && (
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="w-11 h-11 rounded-full bg-black/75 border border-white/30 text-white flex items-center justify-center shadow-lg">
                <Play className="w-5 h-5 fill-white ml-0.5" />
              </span>
            </div>
          )}
          <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between gap-2 text-white">
            <span className="text-[11px] font-medium truncate text-white/95">
              {data.contextLabel || 'Tweeting Wire'}
            </span>
            <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-300 shrink-0">
              <Twitter className="w-3 h-3 -scale-x-100 -rotate-12" />
              <span>Post</span>
            </span>
          </div>
        </div>
      ) : hasVideo ? (
        <div className={`relative w-full bg-slate-950 overflow-hidden ${compact ? 'h-32' : 'h-40'}`}>
          <video
            src={data.videoUrl}
            muted
            playsInline
            preload="metadata"
            className="w-full h-full object-cover opacity-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="w-11 h-11 rounded-full bg-emerald-600/90 border border-white/30 text-white flex items-center justify-center shadow-lg">
              <Play className="w-5 h-5 fill-white ml-0.5" />
            </span>
          </div>
          <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between gap-2 text-white">
            <span className="text-[11px] font-medium truncate">
              {data.contextLabel || 'Video Post'}
            </span>
            <span className="text-[10px] font-mono text-emerald-300 shrink-0">Video</span>
          </div>
        </div>
      ) : (
        /* Editorial visual header thumbnail when tweet has no attached photo/video */
        <div className="relative w-full px-3.5 py-3 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 text-white border-b border-slate-800">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-300 truncate">
              {data.contextLabel || 'Tweeting Wire'}
            </span>
            <Twitter className="w-3.5 h-3.5 text-emerald-400 -scale-x-100 -rotate-12 shrink-0" />
          </div>
          {data.content ? (
            <p className="text-xs sm:text-sm font-medium text-white/95 line-clamp-2 leading-snug">
              &ldquo;{data.content}&rdquo;
            </p>
          ) : (
            <p className="text-xs text-slate-300 italic">Shared post from @{cleanHandle}</p>
          )}
        </div>
      )}

      {/* Context Body */}
      <div className="p-3 space-y-2">
        {/* Author Identity */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <img
              src={
                data.authorAvatar ||
                `https://ui-avatars.com/api/?name=${encodeURIComponent(data.authorName || cleanHandle)}&background=0f172a&color=f8fafc&bold=true`
              }
              alt={data.authorName}
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-full object-cover border border-slate-200 shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-1 min-w-0">
                <span className={`text-xs font-bold truncate ${darkSurface ? 'text-white' : 'text-slate-900'}`}>
                  {data.authorName}
                </span>
                {data.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
              </div>
              <div className={`flex items-center gap-1.5 text-[10px] font-mono truncate ${darkSurface ? 'text-neutral-400' : 'text-slate-500'}`}>
                <span className="truncate">@{cleanHandle}</span>
                <span aria-hidden="true">·</span>
                <span className="shrink-0">{data.timestamp}</span>
              </div>
            </div>
          </div>

          {onClick && (
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 shrink-0">
              <span>View</span>
              <ExternalLink className="w-3 h-3" />
            </span>
          )}
        </div>

        {/* Post Text Excerpt (shown when media thumbnail is present above) */}
        {(hasThumbnail || hasVideo) && data.content && (
          <p className={`text-xs leading-relaxed line-clamp-3 ${darkSurface ? 'text-neutral-200' : 'text-slate-700'}`}>
            {data.content}
          </p>
        )}

        {/* Quoted / Retweeted Inner Context */}
        {data.quotedAuthorHandle && (
          <div className={`px-2.5 py-2 rounded-xl border text-[11px] ${
            darkSurface ? 'bg-neutral-800/70 border-neutral-700 text-neutral-300' : 'bg-slate-50 border-slate-200 text-slate-600'
          }`}>
            <span className="font-semibold">
              {data.quotedAuthorName} (@{data.quotedAuthorHandle.replace(/^@/, '')})
            </span>
            {data.quotedContent && (
              <p className="line-clamp-2 mt-0.5 opacity-90">{data.quotedContent}</p>
            )}
          </div>
        )}

        {/* Metadata Footer (Clean unboxed metadata with typographic separators) */}
        <div className={`pt-1.5 border-t flex items-center justify-between gap-2 flex-wrap text-[10px] font-mono tabular-nums ${
          darkSurface ? 'border-neutral-800 text-neutral-400' : 'border-slate-100 text-slate-500'
        }`}>
          <div className="flex items-center gap-2.5">
            <span className="inline-flex items-center gap-1">
              <MessageCircle className="w-3 h-3" />
              <span>{data.repliesCount ?? 0}</span>
            </span>
            <span className="inline-flex items-center gap-1">
              <Repeat2 className="w-3 h-3" />
              <span>{data.retweets ?? 0}</span>
            </span>
            <span className="inline-flex items-center gap-1">
              <Heart className="w-3 h-3" />
              <span>{data.likes ?? 0}</span>
            </span>
          </div>

          <span className="truncate max-w-[180px]">
            {[
              ...(data.tickers || []).slice(0, 2).map((tk) => `F:${tk}`),
              ...(data.hashtags || []).slice(0, 2).map((h) => `#${h}`),
            ].join(' · ') || 'finalfinance.app'}
          </span>
        </div>
      </div>
    </div>
  );
};
