import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { AssetClass, MarketplaceListing } from '../types';
import { 
  Plus, 
  Search, 
  Heart, 
  MessageSquare, 
  Repeat,
  Users,
  Package,
  Briefcase,
  Coins,
  Banknote,
  Binary,
  ArrowRight,
  Sparkles,
  X,
  Building2,
  Eye,
  Star,
  ArrowRightLeft,
  Gavel,
  Clock
} from 'lucide-react';
import { SearchableProduct } from '../data/searchCatalog';
import { StockItem } from '../types/stocks';
import { DEMO_ACCOUNTS, getCurrentSession } from '../services/firebaseAuth';
import { areUsersBlockedEitherWay, getAllUsers, getIdentityAliases, isAdminAccount, isCurrentSessionAdmin } from '../services/socialService';
import { getOrCreateDirectConversation } from '../services/chatService';
import { UserPublicProfile } from '../types/social';
import { getAverageRating } from '../services/ratingService';
import {
  getAuctionBids,
  getAuctionRemainingLabel,
  getCurrentAuctionPriceUSD,
} from '../services/marketplaceService';
import { getListingSettlementSummary, getListingTradeActionLabel } from '../services/marketplaceSettlementService';
import { isRegisteredInternalBank, getAllApprovedInternalBankPartners } from '../services/loanService';
import { isAdminOrSuperAdminUser } from '../utils/verificationTiers';
import { PresenceStatusBadge } from './common/PresenceBadge';
import {
  clearProfileReturnAnchor,
  getProfileReturnAnchor,
  setPageReturnAnchor,
} from '../utils/profileReturnState';

interface MarketplaceViewProps {
  onOpenNewListing: () => void;
  onOpenBarterModal?: (listing: MarketplaceListing) => void;
  onSelectListing?: (listing: MarketplaceListing) => void;
  onSelectProduct?: (product: SearchableProduct) => void;
  onSelectUser?: (userIdOrHandle: string) => void;
  onSelectStock?: (stock: StockItem) => void;
  onQuickBuyStock?: (stock: StockItem) => void;
}

type SearchFilterType = 'all' | 'auction' | 'people' | 'products' | 'services' | 'barter' | 'fiat' | 'crypto';

interface DirectoryUser {
  id: string;
  uid?: string;
  name: string;
  role: string;
  avatarUrl: string;
  bio: string;
  reputationScore?: number;
  tradesCompleted?: number;
  isSelf?: boolean;
}

const DIRECTORY_USERS: DirectoryUser[] = [
  {
    id: 'jordan_belfort',
    name: 'Jordan Belfort',
    role: 'Escrow Lead & Vault Allocator',
    avatarUrl: DEMO_ACCOUNTS.jordan?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Founder & Chief Reserve Allocator. Overseeing $4.2B in tokenized reserve vaults and physical bullion settlement.',
    reputationScore: 99.8,
    tradesCompleted: 342,
  },
  {
    id: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    role: 'Sovereign Protocol Pioneer',
    avatarUrl: DEMO_ACCOUNTS.satoshi?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic cold storage.',
    reputationScore: 100.0,
    tradesCompleted: 890,
  },
  {
    id: 'alex_morgan',
    name: 'Alex Morgan',
    role: 'Institutional Commodity Arbiter',
    avatarUrl: DEMO_ACCOUNTS.alex?.avatarUrl || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Swiss Vault & Gold Bullion Reserve specialist. Zurich Freeport certified custodian and counter-trade broker.',
    reputationScore: 98.9,
    tradesCompleted: 215,
  },
  {
    id: 'elena_rostova',
    name: 'Elena Rostova',
    role: 'Smart Contract Auditor',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    bio: 'Senior Security Architect offering formal verification and bytecode audits in exchange for gold allocations or AFNL tokens.',
    reputationScore: 99.4,
    tradesCompleted: 180,
  },
  {
    id: 'marcus_vance',
    name: 'Marcus Vance',
    role: 'Geneva Horology & Luxury Custodian',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    bio: 'Curator of vintage Patek Philippe, Audemars Piguet, and investment-grade fine timepieces for bilateral barter.',
    reputationScore: 99.1,
    tradesCompleted: 140,
  },
];

export const MarketplaceView: React.FC<MarketplaceViewProps> = ({ 
  onOpenNewListing,
  onOpenBarterModal,
  onSelectListing,
  onSelectUser,
}) => {
  const { 
    listings = [], 
    currentUser, 
    toggleLikeListing, 
    incrementListingView,
    startDirectConversation,
    setCurrentTab,
    addToast,
    setReturnListingId,
    setChatReturnOrigin,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'my_listings'>('all');
  const [selectedCategory, setSelectedCategory] = useState<AssetClass | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchScope, setSearchScope] = useState<'all' | 'users' | 'goods' | 'services'>('all');
  const [activeFilterType, setActiveFilterType] = useState<SearchFilterType>('all');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [showBanks, setShowBanks] = useState(false);
  const [bankSearchQuery, setBankSearchQuery] = useState('');
  const [platformUsers, setPlatformUsers] = useState<UserPublicProfile[]>([]);
  const [bankDirectoryVersion, setBankDirectoryVersion] = useState(0);

  const searchContainerRef = useRef<HTMLDivElement>(null);

  const currentViewerUid = currentUser ? (currentUser.id?.startsWith('user-') ? currentUser.id : `user-${currentUser.id}`) : '';
  const currentViewerHandle = currentUser?.handle?.replace(/^@/, '') || '';
  const viewerIsAdmin = isAdminAccount(currentUser) || isCurrentSessionAdmin();

  // Load all registered & platform users (including self) for user search & Internal Banks directory
  useEffect(() => {
    let active = true;
    getAllUsers(currentViewerUid || currentUser?.id || '', { includeSelf: true })
      .then((users) => {
        if (active) setPlatformUsers(users);
      })
      .catch((err) => console.debug('Failed loading users for marketplace search:', err));
    return () => {
      active = false;
    };
  }, [currentViewerUid, currentUser?.id, currentUser?.name, currentUser?.avatarUrl, bankDirectoryVersion]);

  // Listen to bank license approvals/delistings & profile updates so Marketplace stays live
  useEffect(() => {
    const refreshDirectory = () => setBankDirectoryVersion((v) => v + 1);
    window.addEventListener('final_finance_bank_status_updated', refreshDirectory);
    window.addEventListener('final_finance_profile_updated', refreshDirectory);
    window.addEventListener('final_finance_account_status_updated', refreshDirectory);
    window.addEventListener('final_finance_admin_directory_updated', refreshDirectory);
    window.addEventListener('storage', refreshDirectory);
    return () => {
      window.removeEventListener('final_finance_bank_status_updated', refreshDirectory);
      window.removeEventListener('final_finance_profile_updated', refreshDirectory);
      window.removeEventListener('final_finance_account_status_updated', refreshDirectory);
      window.removeEventListener('final_finance_admin_directory_updated', refreshDirectory);
      window.removeEventListener('storage', refreshDirectory);
    };
  }, []);

  // Restore exact tab ('all' | 'my_listings') and scroll spot when returning from OTC Desk / Profile
  useEffect(() => {
    const anchor = getProfileReturnAnchor();
    if (anchor && anchor.restoreActive && anchor.tab === 'marketplace') {
      if (anchor.marketplaceTab === 'all' || anchor.marketplaceTab === 'my_listings') {
        setActiveTab(anchor.marketplaceTab);
      }
      const targetY = anchor.scrollY || 0;
      clearProfileReturnAnchor();
      setTimeout(() => {
        window.scrollTo({ top: targetY, behavior: 'instant' });
      }, 90);
    }
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Expand current signed-in user aliases for "You" badge, My Listings matching & synchronous fallback
  const sessionForAliases = getCurrentSession();
  const myAliasSet = useMemo(() => {
    const set = new Set<string>();
    [
      currentUser?.id,
      currentViewerUid,
      currentViewerHandle,
      currentUser?.email,
      sessionForAliases?.id,
      sessionForAliases?.uid,
      sessionForAliases?.email,
    ]
      .filter(Boolean)
      .forEach((id) => {
        getIdentityAliases(String(id)).forEach((a) => set.add(a.toLowerCase()));
      });
    return set;
  }, [
    currentUser?.id,
    currentUser?.email,
    currentViewerUid,
    currentViewerHandle,
    sessionForAliases?.id,
    sessionForAliases?.uid,
    sessionForAliases?.email,
  ]);

  const isMyListing = (item: MarketplaceListing): boolean => {
    if (myAliasSet.size === 0) return false;
    const rawItem = item as any;
    const candidates = [
      item.sellerId,
      item.sellerHandle,
      rawItem.userId,
      rawItem.creatorHandle,
    ].filter(Boolean) as string[];
    return candidates.some((candidate) =>
      getIdentityAliases(candidate).some((alias) => myAliasSet.has(alias.toLowerCase()))
    );
  };

  // Merge registered platform users and DIRECTORY_USERS (including self & all admins/members)
  const searchableUsers = useMemo<DirectoryUser[]>(() => {
    const map = new Map<string, DirectoryUser>();
    const directoryMetaByHandle = new Map(
      DIRECTORY_USERS.map((d) => [d.id.toLowerCase().replace(/^@/, ''), d])
    );

    const checkIsSelf = (uidVal?: string, handleVal?: string) => {
      if (myAliasSet.size === 0) return false;
      const candidates = [uidVal, handleVal].filter(Boolean) as string[];
      return candidates.some((c) =>
        getIdentityAliases(c).some((a) => myAliasSet.has(a.toLowerCase()))
      );
    };

    platformUsers.forEach((u) => {
      const cleanHandle = (u.userId || u.uid || '').toLowerCase().replace(/^@/, '');
      if (!cleanHandle) return;
      const dirMeta = directoryMetaByHandle.get(cleanHandle);
      map.set(cleanHandle, {
        id: cleanHandle,
        uid: u.uid,
        name: u.name || dirMeta?.name || cleanHandle,
        role:
          u.role === 'super_admin'
            ? 'Super Admin'
            : u.role === 'admin'
              ? 'Admin'
              : dirMeta?.role || 'Verified Member',
        avatarUrl: u.avatarUrl || dirMeta?.avatarUrl || '',
        bio: u.bio || dirMeta?.bio || 'Sovereign Marketplace Member',
        reputationScore: dirMeta?.reputationScore,
        tradesCompleted: dirMeta?.tradesCompleted,
        isSelf: checkIsSelf(u.uid, cleanHandle),
      });
    });

    DIRECTORY_USERS.forEach((u) => {
      const cleanId = u.id.toLowerCase().replace(/^@/, '');
      if (!map.has(cleanId)) {
        map.set(cleanId, {
          ...u,
          isSelf: checkIsSelf(u.uid, cleanId),
        });
      }
    });

    // Ensure current signed-in user is synchronously searchable by name/handle even on initial mount
    const currentRole = (currentUser as any)?.role;
    if (currentUser && currentRole !== 'guest') {
      const selfHandle = (currentViewerHandle || currentUser.id || '').toLowerCase().replace(/^@/, '');
      if (selfHandle && !Array.from(map.values()).some((u) => u.isSelf)) {
        map.set(selfHandle, {
          id: selfHandle,
          uid: currentViewerUid || currentUser.id,
          name: currentUser.name || selfHandle,
          role:
            currentRole === 'super_admin'
              ? 'Super Admin'
              : currentRole === 'admin'
                ? 'Admin'
                : 'Verified Member',
          avatarUrl: currentUser.avatarUrl || '',
          bio: currentUser.bio || 'Sovereign Marketplace Member',
          isSelf: true,
        });
      }
    }

    return Array.from(map.values());
  }, [platformUsers, myAliasSet, currentUser, currentViewerHandle, currentViewerUid]);

  // 1. Users matching search query (by name, @handle, role, or bio — including self)
  const matchingPeople = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase().trim().replace(/^@/, '');
    const tokens = q.split(/\s+/).filter(Boolean);

    const filtered = searchableUsers.filter((user) => {
      const userUid = user.uid || (user.id.startsWith('user-') ? user.id : `user-${user.id}`);
      if (
        !user.isSelf &&
        !viewerIsAdmin &&
        currentViewerUid &&
        (areUsersBlockedEitherWay(currentViewerUid, userUid) ||
          areUsersBlockedEitherWay(currentUser.id, user.id) ||
          areUsersBlockedEitherWay(currentViewerHandle, user.id))
      ) {
        return false;
      }

      const nameLower = user.name.toLowerCase();
      const idLower = user.id.toLowerCase();
      const roleLower = user.role.toLowerCase();
      const bioLower = (user.bio || '').toLowerCase();
      const combined = `${nameLower} ${idLower} ${roleLower} ${bioLower}`;

      if (
        nameLower.includes(q) ||
        idLower.includes(q) ||
        roleLower.includes(q) ||
        bioLower.includes(q)
      ) {
        return true;
      }
      return tokens.length > 1 && tokens.every((t) => combined.includes(t));
    });

    return filtered.sort((a, b) => {
      const aName = a.name.toLowerCase();
      const bName = b.name.toLowerCase();
      const aExact = aName === q || a.id.toLowerCase() === q ? 0 : aName.startsWith(q) || a.id.toLowerCase().startsWith(q) ? 1 : 2;
      const bExact = bName === q || b.id.toLowerCase() === q ? 0 : bName.startsWith(q) || b.id.toLowerCase().startsWith(q) ? 1 : 2;
      if (aExact !== bExact) return aExact - bExact;
      return aName.localeCompare(bName);
    });
  }, [searchQuery, searchableUsers, viewerIsAdmin, currentViewerUid, currentUser?.id, currentViewerHandle]);

  // All active, non-blocked platform listings matching the search query
  const searchMatchingListings = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase().trim();
    return listings.filter((item) => {
      if (!viewerIsAdmin && item.status === 'draft') return false;
      const sellerUid = item.sellerId?.startsWith('user-') ? item.sellerId : `user-${item.sellerId}`;
      const sellerHandle = item.sellerHandle?.replace(/^@/, '') || '';
      if (
        !viewerIsAdmin &&
        currentViewerUid &&
        (areUsersBlockedEitherWay(currentViewerUid, sellerUid) ||
          areUsersBlockedEitherWay(currentUser.id, item.sellerId) ||
          areUsersBlockedEitherWay(currentViewerHandle, sellerHandle))
      ) {
        return false;
      }
      return (
        (item.title && item.title.toLowerCase().includes(q)) ||
        (item.description && item.description.toLowerCase().includes(q)) ||
        (item.sellerName && item.sellerName.toLowerCase().includes(q)) ||
        (item.sellerHandle && item.sellerHandle.toLowerCase().includes(q)) ||
        (item.category && item.category.toLowerCase().includes(q))
      );
    });
  }, [searchQuery, listings, viewerIsAdmin, currentViewerUid, currentUser?.id, currentViewerHandle]);

  const isServiceItem = (item: MarketplaceListing): boolean =>
    item.itemType === 'service' ||
    (item.category && item.category.toLowerCase().includes('service'));

  // 2. Goods listed on our platform matching query
  const matchingGoods = useMemo(
    () => searchMatchingListings.filter((item) => !isServiceItem(item)),
    [searchMatchingListings]
  );

  // 3. Services listed on our platform matching query
  const matchingServices = useMemo(
    () => searchMatchingListings.filter((item) => isServiceItem(item)),
    [searchMatchingListings]
  );

  // Filter listings based on tab, category, search query, and filter type
  const filteredListings = listings.filter((item) => {
    // Exclude drafts from non-admin public marketplace
    if (!viewerIsAdmin && item.status === 'draft') return false;

    // Filter out items from blocked users for non-admins
    const sellerUid = item.sellerId?.startsWith('user-') ? item.sellerId : `user-${item.sellerId}`;
    const sellerHandle = item.sellerHandle?.replace(/^@/, '') || '';
    if (
      !viewerIsAdmin &&
      currentViewerUid &&
      (areUsersBlockedEitherWay(currentViewerUid, sellerUid) ||
        areUsersBlockedEitherWay(currentUser.id, item.sellerId) ||
        areUsersBlockedEitherWay(currentViewerHandle, sellerHandle))
    ) {
      return false;
    }

    // Tab filter
    if (activeTab === 'my_listings' && !isMyListing(item)) return false;

    // Category filter
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;

    // Filter type
    if (activeFilterType === 'people') return false; // Handled in dedicated people section
    if (activeFilterType === 'auction' && item.listingIntent !== 'auction') return false;
    if (activeFilterType === 'products' && item.itemType === 'service') return false;
    if (activeFilterType === 'services' && item.itemType !== 'service' && !item.title.toLowerCase().includes('service') && !item.description.toLowerCase().includes('hour') && !item.description.toLowerCase().includes('audit')) return false;
    if (activeFilterType === 'barter' && item.category !== 'barter' && !item.acceptedSettlements?.includes('barter')) return false;
    if (activeFilterType === 'fiat' && item.category !== 'fiat' && !item.acceptedSettlements?.includes('fiat')) return false;
    if (activeFilterType === 'crypto' && item.category !== 'crypto' && item.category !== 'stable_coins' && item.category !== 'final_coins') return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return (
        (item.title && item.title.toLowerCase().includes(q)) ||
        (item.description && item.description.toLowerCase().includes(q)) ||
        (item.sellerName && item.sellerName.toLowerCase().includes(q)) ||
        (item.sellerHandle && item.sellerHandle.toLowerCase().includes(q)) ||
        (item.category && item.category.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const bankingCapacityUsers = useMemo(() => {
    void bankDirectoryVersion;
    return getAllApprovedInternalBankPartners(platformUsers, currentUser);
  }, [platformUsers, currentUser, bankDirectoryVersion]);

  const filteredBankingCapacityUsers = bankingCapacityUsers.filter((user) => {
    if (!bankSearchQuery) return true;
    const q = bankSearchQuery.toLowerCase();
    return (
      user.name.toLowerCase().includes(q) ||
      user.handle.toLowerCase().includes(q) ||
      user.bankName.toLowerCase().includes(q) ||
      user.role.toLowerCase().includes(q) ||
      user.bio.toLowerCase().includes(q)
    );
  });

  const filterPills: { id: SearchFilterType; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'All Listings', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'auction', label: 'Live Auctions', icon: <Gavel className="w-3.5 h-3.5 text-amber-600" /> },
    { id: 'people', label: 'People & Traders', icon: <Users className="w-3.5 h-3.5 text-blue-600" /> },
    { id: 'products', label: 'Products & Bullion', icon: <Package className="w-3.5 h-3.5 text-amber-600" /> },
    { id: 'services', label: 'Services & Capacity', icon: <Briefcase className="w-3.5 h-3.5 text-indigo-600" /> },
    { id: 'barter', label: 'Barter & Counter-Trade', icon: <Repeat className="w-3.5 h-3.5 text-amber-700" /> },
    { id: 'fiat', label: 'Fiat (USD / EUR / CHF)', icon: <Banknote className="w-3.5 h-3.5 text-sky-600" /> },
    { id: 'crypto', label: 'Crypto & Stablecoins', icon: <Binary className="w-3.5 h-3.5 text-purple-600" /> },
  ];

  const categories: { id: AssetClass | 'all'; label: string }[] = [
    { id: 'all', label: 'All Categories' },
    { id: 'barter', label: 'Physical Goods & Services' },
    { id: 'final_coins', label: 'Final Coins (AFNL)' },
    { id: 'stable_coins', label: 'Stablecoins' },
    { id: 'fiat', label: 'Fiat Reserves' },
    { id: 'crypto', label: 'Cryptocurrency' },
  ];

  return (
    <div className="space-y-6 pb-20 text-center">
      {/* ================= HERO SEARCH BAR (MOVED TO VERY TOP OF HOMEPAGE) ================= */}
      <div className="border border-slate-200 bg-white rounded-3xl p-5 sm:p-7 shadow-xs">
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="text-center">
            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight text-center">
              Marketplace
            </h1>
          </div>

          {/* Search Bar Input Container */}
          <div ref={searchContainerRef} className="relative w-full mx-auto">
            <div className="relative flex items-center justify-center">
              <Search className="absolute left-4 h-5 w-5 text-slate-400 pointer-events-none" />
              <input
                id="homepage-universal-search-input"
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchOpen(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIsSearchOpen(true);
                }}
                placeholder="Search users by name or @handle, goods, or services..."
                className="w-full pl-12 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm text-slate-900 placeholder:text-slate-400 text-center focus:outline-none focus:border-amber-500 focus:bg-white transition-all shadow-xs font-sans"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
                  title="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Instant Search Results Dropdown — 3 Categories: Users, Goods, Services */}
            {isSearchOpen && searchQuery.trim().length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 overflow-hidden divide-y divide-slate-100 max-h-[70vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                {/* 3-Category Filter Strip */}
                <div className="px-3 py-2 bg-slate-50/90 flex items-center justify-center gap-1.5 flex-wrap">
                  {[
                    { id: 'all' as const, label: 'All', count: matchingPeople.length + matchingGoods.length + matchingServices.length },
                    { id: 'users' as const, label: 'Users', count: matchingPeople.length },
                    { id: 'goods' as const, label: 'Goods', count: matchingGoods.length },
                    { id: 'services' as const, label: 'Services', count: matchingServices.length },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setSearchScope(tab.id)}
                      className={`px-3 py-1 rounded-full text-[11px] font-bold transition-colors cursor-pointer ${
                        searchScope === tab.id
                          ? 'bg-slate-900 text-white shadow-2xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {tab.label} ({tab.count})
                    </button>
                  ))}
                </div>

                {/* 1. Users */}
                {(searchScope === 'all' || searchScope === 'users') && matchingPeople.length > 0 && (
                  <div className="p-3 text-left">
                    <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold px-2 flex items-center gap-1.5 mb-1.5">
                      <Users className="w-3 h-3 text-blue-600" />
                      <span>Users ({matchingPeople.length})</span>
                    </span>
                    <div className="space-y-1">
                      {matchingPeople.slice(0, 8).map((user, idx) => (
                        <div
                          key={`mkt-search-user-${user.id}-${idx}`}
                          onClick={() => {
                            setIsSearchOpen(false);
                            if (onSelectUser) {
                              onSelectUser(user.uid || user.id);
                            }
                          }}
                          className="p-2 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            {user.avatarUrl ? (
                              <img
                                src={user.avatarUrl}
                                alt={user.name}
                                className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold font-serif shrink-0">
                                {user.name.charAt(0)}
                              </div>
                            )}
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <p className="text-xs font-bold text-slate-900 truncate">{user.name}</p>
                                {user.isSelf && (
                                  <span className="text-[9px] font-mono uppercase font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200 shrink-0">
                                    You
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-2">
                                <p className="text-[11px] text-slate-500 font-mono truncate">@{user.id}</p>
                                {(() => {
                                  const avgRating = getAverageRating(user.id);
                                  return avgRating.count > 0 ? (
                                    <div className="flex items-center gap-1">
                                      <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                      <span className="text-[10px] font-bold text-slate-700">{avgRating.average}</span>
                                    </div>
                                  ) : null;
                                })()}
                              </div>
                            </div>
                          </div>
                          <span className="text-[11px] font-semibold text-amber-700 flex items-center gap-1 shrink-0">
                            <span>View Profile</span>
                            <ArrowRight className="w-3 h-3" />
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2. Goods Listed on Our Platform */}
                {(searchScope === 'all' || searchScope === 'goods') && matchingGoods.length > 0 && (
                  <div className="p-3 text-left">
                    <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold px-2 flex items-center gap-1.5 mb-1.5">
                      <Package className="w-3 h-3 text-amber-600" />
                      <span>Goods Listed ({matchingGoods.length})</span>
                    </span>
                    <div className="space-y-1">
                      {matchingGoods.slice(0, 5).map((listing, idx) => (
                        <div
                          key={`mkt-search-good-${listing.id}-${idx}`}
                          onClick={() => {
                            setIsSearchOpen(false);
                            incrementListingView(listing.id);
                            if (onSelectListing) {
                              onSelectListing(listing);
                            } else if (onOpenBarterModal) {
                              onOpenBarterModal(listing);
                            }
                          }}
                          className="p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0 flex-1 pr-3">
                            {listing.imageUrl && (
                              <img
                                src={listing.imageUrl}
                                alt={listing.title}
                                className="w-8 h-8 rounded-lg object-cover border border-slate-200 shrink-0"
                              />
                            )}
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 truncate">{listing.title}</p>
                              <div className="flex items-center gap-2">
                                <p className="text-[11px] text-slate-500 font-mono">by {listing.sellerHandle?.startsWith('@') ? listing.sellerHandle : `@${listing.sellerHandle}`}</p>
                                {(() => {
                                  const avgRating = getAverageRating(listing.sellerHandle || '');
                                  return avgRating.count > 0 ? (
                                    <div className="flex items-center gap-1">
                                      <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                      <span className="text-[10px] font-bold text-slate-700">{avgRating.average}</span>
                                    </div>
                                  ) : null;
                                })()}
                              </div>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="font-mono text-xs font-bold text-amber-700">
                              ${(listing.priceUSD || 0).toLocaleString()} USD
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. Services Listed on Our Platform */}
                {(searchScope === 'all' || searchScope === 'services') && matchingServices.length > 0 && (
                  <div className="p-3 text-left">
                    <span className="text-[10px] font-mono uppercase text-slate-500 font-semibold px-2 flex items-center gap-1.5 mb-1.5">
                      <Briefcase className="w-3 h-3 text-indigo-600" />
                      <span>Services Listed ({matchingServices.length})</span>
                    </span>
                    <div className="space-y-1">
                      {matchingServices.slice(0, 5).map((listing, idx) => (
                        <div
                          key={`mkt-search-service-${listing.id}-${idx}`}
                          onClick={() => {
                            setIsSearchOpen(false);
                            incrementListingView(listing.id);
                            if (onSelectListing) {
                              onSelectListing(listing);
                            } else if (onOpenBarterModal) {
                              onOpenBarterModal(listing);
                            }
                          }}
                          className="p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-2.5 min-w-0 flex-1 pr-3">
                            {listing.imageUrl && (
                              <img
                                src={listing.imageUrl}
                                alt={listing.title}
                                className="w-8 h-8 rounded-lg object-cover border border-slate-200 shrink-0"
                              />
                            )}
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-900 truncate">{listing.title}</p>
                              <div className="flex items-center gap-2">
                                <p className="text-[11px] text-slate-500 font-mono">by {listing.sellerHandle?.startsWith('@') ? listing.sellerHandle : `@${listing.sellerHandle}`}</p>
                                {(() => {
                                  const avgRating = getAverageRating(listing.sellerHandle || '');
                                  return avgRating.count > 0 ? (
                                    <div className="flex items-center gap-1">
                                      <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                      <span className="text-[10px] font-bold text-slate-700">{avgRating.average}</span>
                                    </div>
                                  ) : null;
                                })()}
                              </div>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="font-mono text-xs font-bold text-indigo-700">
                              ${(listing.priceUSD || 0).toLocaleString()} USD
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {((searchScope === 'all' && matchingPeople.length === 0 && matchingGoods.length === 0 && matchingServices.length === 0) ||
                  (searchScope === 'users' && matchingPeople.length === 0) ||
                  (searchScope === 'goods' && matchingGoods.length === 0) ||
                  (searchScope === 'services' && matchingServices.length === 0)) && (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No matching {searchScope === 'users' ? 'users' : searchScope === 'goods' ? 'goods' : searchScope === 'services' ? 'services' : 'users, goods, or services'} found for "{searchQuery}".
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ================= MATCHING USERS INLINE SECTION (WHEN SEARCHING) ================= */}
      {searchQuery.trim().length > 0 && matchingPeople.length > 0 && activeFilterType !== 'people' && !showBanks && (
        <div className="border border-slate-200 bg-white rounded-3xl p-5 shadow-xs space-y-4 text-left">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-600" />
              <h2 className="font-serif text-base font-bold text-slate-900">
                Matching Users ({matchingPeople.length})
              </h2>
            </div>
            <span className="text-[11px] font-mono text-slate-500">
              Query: "{searchQuery.trim()}"
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {matchingPeople.map((user, idx) => (
              <div
                key={`mkt-inline-user-${user.id}-${idx}`}
                onClick={() => onSelectUser && onSelectUser(user.uid || user.id)}
                className="border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-amber-300 rounded-2xl p-3.5 flex items-center justify-between gap-3 transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm font-serif font-bold shrink-0">
                      {user.name.charAt(0)}
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-bold text-slate-900 truncate group-hover:text-amber-800 transition-colors">
                        {user.name}
                      </p>
                      {user.isSelf && (
                        <span className="text-[9px] font-mono uppercase font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200 shrink-0">
                          You
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-mono text-slate-500 truncate">@{user.id}</p>
                    <p className="text-[11px] text-amber-800 font-medium truncate">{user.role}</p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-amber-700 flex items-center gap-1 shrink-0">
                  <span>Profile</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= PEOPLE DIRECTORY (WHEN 'PEOPLE' IS FILTERED) ================= */}
      {activeFilterType === 'people' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                SOVEREIGN DIRECTORY
              </span>
              <h2 className="font-serif text-xl font-bold text-slate-900 mt-1">
                People &amp; Certified Traders
              </h2>
            </div>
            <span className="text-xs text-slate-500 font-mono">
              {(searchQuery.trim() ? matchingPeople : searchableUsers).length} Members
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(searchQuery.trim() ? matchingPeople : searchableUsers).map((user, idx) => (
              <div
                key={`mkt-dir-user-${user.id}-${idx}`}
                className="border border-slate-200 bg-white rounded-2xl p-4 flex flex-col justify-between hover:border-slate-300 transition-all shadow-xs text-left"
              >
                <div className="flex items-start gap-3">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      className="w-12 h-12 rounded-full object-cover border border-slate-200"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center text-base font-serif font-bold">
                      {user.name.charAt(0)}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-semibold text-sm text-slate-900 truncate">{user.name}</h3>
                      {user.isSelf && (
                        <span className="text-[9px] font-mono uppercase font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200 shrink-0">
                          You
                        </span>
                      )}
                      {(() => {
                        const avgRating = getAverageRating(user.id);
                        return avgRating.count > 0 ? (
                          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-amber-50 border border-amber-100">
                            <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                            <span className="text-[10px] font-bold text-amber-800">{avgRating.average}</span>
                          </div>
                        ) : null;
                      })()}
                    </div>
                    <p className="text-xs font-mono text-slate-500">@{user.id}</p>
                    <p className="text-[11px] font-medium text-amber-800 mt-0.5">{user.role}</p>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2">{user.bio}</p>
                  </div>
                </div>

                <div className="pt-3 mt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onSelectUser && onSelectUser(user.uid || user.id)}
                    className="flex-1 py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-semibold transition-colors cursor-pointer text-center"
                  >
                    View Profile
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const session = getCurrentSession();
                      if (!session || !session.uid) {
                        addToast({
                          type: 'error',
                          title: 'Authentication Required',
                          message: 'Please sign in to contact this trader.',
                        });
                        return;
                      }
                      const targetUid = user.uid || `user-${user.id.replace(/^@/, '')}`;
                      if (
                        !isAdminAccount(session) &&
                        (areUsersBlockedEitherWay(session.uid, targetUid) ||
                          areUsersBlockedEitherWay(session.id, user.id))
                      ) {
                        addToast({
                          type: 'error',
                          title: 'Chat Unavailable',
                          message: 'Cannot contact trader: communication is blocked between these accounts.',
                        });
                        return;
                      }
                      try {
                        setPageReturnAnchor('messages', {
                          tab: 'marketplace',
                          sourceLabel: 'Back to Marketplace',
                          scrollY: typeof window !== 'undefined' ? window.scrollY : 0,
                          marketplaceTab: activeTab,
                        });
                        const conv = await getOrCreateDirectConversation(session, {
                          uid: targetUid,
                          userId: user.id,
                          name: user.name,
                          avatarUrl: user.avatarUrl,
                          role: 'user',
                        });
                        setReturnListingId(null);
                        setChatReturnOrigin('marketplace');
                        if (conv?.id) {
                          window.dispatchEvent(new CustomEvent('open_direct_conversation', { detail: conv.id }));
                        }
                        setCurrentTab('messages');
                      } catch (err: any) {
                        startDirectConversation(user.id);
                        setReturnListingId(null);
                        setChatReturnOrigin('marketplace');
                        setCurrentTab('messages');
                      }
                    }}
                    className="py-1.5 px-3 rounded-xl bg-amber-500 text-slate-950 hover:bg-amber-400 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>OTC Desk</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= MARKETPLACE LISTINGS & CATEGORY CONTROLS ================= */}
      {activeFilterType !== 'people' && (
        <div className="space-y-6">
          {/* Unified Single Tab Bar: All Listings | My Listings | Internal Bank */}
          <div className="flex w-full items-center justify-center overflow-x-auto no-scrollbar">
            <div className="inline-flex flex-nowrap items-center justify-center gap-0.5 sm:gap-1 rounded-xl bg-slate-100 p-1 border border-slate-200 shrink-0 mx-auto">
              <button
                type="button"
                onClick={() => {
                  setShowBanks(false);
                  setActiveTab('all');
                }}
                className={`px-2.5 sm:px-3.5 py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  !showBanks && activeTab === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Listings
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowBanks(false);
                  setActiveTab('my_listings');
                }}
                className={`px-2.5 sm:px-3.5 py-1.5 text-[11px] sm:text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  !showBanks && activeTab === 'my_listings'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                My Listings ({listings.filter((l) => isMyListing(l) && l.status !== 'draft').length})
              </button>
              <button
                type="button"
                onClick={() => setShowBanks(true)}
                className={`inline-flex items-center gap-1 sm:gap-1.5 rounded-lg px-2.5 sm:px-3.5 py-1.5 text-[11px] sm:text-xs font-semibold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  showBanks
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Building2 className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                <span>Internal Bank</span>
              </button>
            </div>
          </div>


          {showBanks ? (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300 text-center">
              <div className="p-6 rounded-3xl bg-indigo-50/50 border border-indigo-100 flex flex-col items-center justify-center text-center gap-3">
                <h3 className="font-serif text-lg font-bold text-slate-900 text-center">
                  Sovereign Clearing Banks &amp; Providers
                </h3>
                <div className="px-4 py-2 bg-indigo-50 border border-indigo-100 rounded-xl shrink-0 mx-auto">
                  <span className="text-xs font-bold text-indigo-700">Clearing Partners: {bankingCapacityUsers.length}</span>
                </div>
              </div>

              {/* Banks Search Bar */}
              <div className="relative max-w-2xl mx-auto">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  value={bankSearchQuery}
                  onChange={(e) => setBankSearchQuery(e.target.value)}
                  placeholder="Search clearing banks by node name, owner @handle, capacity, or role..."
                  className="w-full pl-10 pr-10 py-2.5 text-xs rounded-2xl border border-slate-200 bg-white text-slate-800 placeholder-slate-400 text-center focus:outline-hidden focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400/30 transition-all"
                />
                {bankSearchQuery && (
                  <button
                    onClick={() => setBankSearchQuery('')}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                    title="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {filteredBankingCapacityUsers.length === 0 ? (
                <div className="border border-dashed border-slate-300 rounded-3xl p-12 text-center bg-white">
                  <Building2 className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <h3 className="font-serif text-base font-bold text-slate-800">No Banks Found</h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                    No authorized clearing nodes match "{bankSearchQuery}". Try looking up by other names, capacities or roles.
                  </p>
                  <button
                    type="button"
                    onClick={() => setBankSearchQuery('')}
                    className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Clear Search
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {filteredBankingCapacityUsers.map((user, idx) => {
                    const cleanHandle = (user.handle || user.id || 'user').replace(/^@+/, '');
                    return (
                      <div
                        key={`mkt-bank-user-${user.id}-${idx}`}
                        className="border-2 border-indigo-100/80 bg-white rounded-3xl p-5 flex flex-col justify-between items-center text-center hover:border-indigo-300 hover:shadow-md transition-all"
                      >
                        <div className="w-full flex flex-col items-center text-center">
                          <div className="flex flex-col items-center justify-center gap-2 w-full">
                            {user.avatarUrl ? (
                              <img src={user.avatarUrl} alt={user.name} className="w-12 h-12 rounded-full object-cover border border-slate-200 shrink-0 animate-fade-in mx-auto" referrerPolicy="no-referrer" />
                            ) : (
                              <div className="w-12 h-12 rounded-full bg-slate-950 text-white flex items-center justify-center text-lg font-serif font-bold shrink-0 mx-auto">
                                {user.name.charAt(0)}
                              </div>
                            )}
                            <div className="min-w-0 w-full text-center">
                              <h3 className="font-bold text-sm text-slate-900 truncate text-center">{user.name}</h3>
                              <p className="text-xs text-slate-500 font-mono text-center">@{cleanHandle}</p>
                            </div>
                            <span className="text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 uppercase shrink-0">
                              LICENSED
                            </span>
                          </div>

                          <div className="mt-4 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 space-y-2.5 w-full text-center">
                            <div className="flex flex-col items-center justify-center text-xs gap-0.5">
                              <span className="text-slate-500 font-mono">Clearing Node:</span>
                              <span className="font-bold text-slate-900 font-serif text-center">{user.bankName}</span>
                            </div>
                            <div className="flex flex-col items-center justify-center text-xs gap-0.5">
                              <span className="text-slate-500 font-mono">Reserve Capacity:</span>
                              <span className="font-mono font-bold text-indigo-700 text-center">{user.capacityUSD}</span>
                            </div>
                          </div>

                          <p className="text-xs text-slate-600 mt-4 line-clamp-3 leading-relaxed text-center">
                            {user.bio}
                          </p>
                        </div>

                        <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-center gap-2 w-full">
                          <button
                            type="button"
                            onClick={() => onSelectUser && onSelectUser(user.uid || cleanHandle || user.id)}
                            className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-semibold transition-colors cursor-pointer text-center"
                          >
                            View Profile
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            <>
              {/* Category Filter Pills — Single Horizontal Slide Line */}
              <div className="w-full overflow-x-auto pb-1.5 scrollbar-none">
                <div className="flex items-center justify-start sm:justify-center gap-1.5 flex-nowrap min-w-max mx-auto px-1">
                  {categories.map((cat) => {
                    const isSelected = selectedCategory === cat.id;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setSelectedCategory(cat.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                          isSelected
                            ? 'bg-amber-50 text-amber-900 border border-amber-300 shadow-xs'
                            : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {cat.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Listings Grid */}
              {filteredListings.length === 0 ? (
                <div className="border border-dashed border-slate-300 rounded-3xl p-12 text-center bg-white">
                  <Package className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <h3 className="font-serif text-base font-bold text-slate-800">No Listings Match Your Search</h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                    Try refining your keyword query or clear category filters to view available reserve inventory.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('all');
                      setActiveFilterType('all');
                    }}
                    className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {filteredListings.map((item, idx) => {
                    const isAuction = item.listingIntent === 'auction';
                    const isSoldOrSettled = item.status === 'sold' || item.auctionConfig?.status === 'settled';
                    const auctionBids = isAuction ? getAuctionBids(item.id) : [];
                    const bidCount = isAuction ? (auctionBids.length || item.auctionConfig?.bidCount || 0) : 0;
                    const auctionTime = isAuction ? getAuctionRemainingLabel(item.auctionConfig?.endTimeIso) : null;
                    const displayPriceUSD = isAuction
                      ? getCurrentAuctionPriceUSD(item as any)
                      : (item.priceUSD || 0);
                    return (
                      <div
                        key={`mkt-grid-listing-${item.id}-${idx}`}
                        onClick={() => {
                          incrementListingView(item.id);
                          if (onSelectListing) {
                            onSelectListing(item);
                          }
                        }}
                        className="border border-slate-200 bg-white rounded-3xl p-5 flex flex-col justify-between items-center text-center hover:border-amber-300 hover:shadow-md transition-all cursor-pointer group"
                      >
                        <div className="w-full flex flex-col items-center text-center">
                          {/* Image Preview */}
                          <div className="w-full h-48 rounded-2xl bg-slate-100 overflow-hidden mb-4 relative">
                            {item.imageUrl ? (
                              <img
                                src={item.imageUrl}
                                alt={item.title}
                                className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                            ) : (
                              <div className="h-full w-full flex items-center justify-center text-slate-400 text-xs">
                                No image available
                              </div>
                            )}
                            <span className="absolute top-3 left-3 text-[10px] font-mono uppercase px-2.5 py-1 rounded-full bg-slate-900/80 text-white backdrop-blur-xs font-semibold">
                              {item.category.replace('_', ' ')}
                            </span>

                            {isAuction && (
                              <div className="absolute top-3 right-3 flex items-center gap-1.5">
                                <span
                                  className={`inline-flex items-center gap-1 text-[10px] font-mono uppercase px-2.5 py-1 rounded-full font-bold shadow-xs ${
                                    isSoldOrSettled
                                      ? 'bg-emerald-600 text-white'
                                      : auctionTime?.isEnded
                                      ? 'bg-slate-800 text-slate-200'
                                      : 'bg-amber-500 text-slate-950'
                                  }`}
                                >
                                  <Gavel className="w-3 h-3" />
                                  <span>{isSoldOrSettled ? 'Settled' : auctionTime?.isEnded ? 'Ended' : 'Live Auction'}</span>
                                </span>
                              </div>
                            )}

                            {isAuction && !isSoldOrSettled && auctionTime && (
                              <span className="absolute bottom-2.5 right-2.5 inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-lg bg-slate-950/85 text-amber-200 backdrop-blur-xs font-semibold">
                                <Clock className="w-3 h-3" />
                                <span>{auctionTime.text}</span>
                              </span>
                            )}
                          </div>

                          {/* Seller Tag */}
                          <div className="flex flex-col items-center justify-center gap-1 text-xs text-slate-500 font-mono pb-2 text-center">
                            <div className="flex items-center justify-center gap-2 flex-wrap">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectUser && onSelectUser(item.sellerId);
                                }}
                                className="hover:text-amber-800 transition-colors font-medium cursor-pointer"
                              >
                                {item.sellerHandle?.startsWith('@') ? item.sellerHandle : `@${item.sellerHandle || 'merchant'}`}
                              </button>
                              <PresenceStatusBadge
                                identifiers={[item.sellerId, item.sellerHandle]}
                                size="xs"
                              />
                              {(() => {
                                const avgRating = getAverageRating(item.sellerHandle || '');
                                return avgRating.count > 0 ? (
                                  <div className="flex items-center gap-1">
                                    <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                                    <span className="text-[10px] font-bold text-slate-700">{avgRating.average}</span>
                                  </div>
                                ) : null;
                              })()}
                            </div>
                            <span className="text-[11px] text-slate-400">
                              {isAuction ? `${bidCount} ${bidCount === 1 ? 'bid' : 'bids'}` : 'Zurich Depository'}
                            </span>
                          </div>

                          {/* Title & Description */}
                          <h3 className="font-serif text-base font-bold text-slate-900 group-hover:text-amber-800 transition-colors mt-1 line-clamp-1 text-center">
                            {item.title}
                          </h3>
                          <p className="text-xs text-slate-500 mt-1 line-clamp-2 text-center">
                            {item.description}
                          </p>

                          {/* Payment & Barter Accepted Badge */}
                          <div className="mt-3 w-full p-2 rounded-xl bg-slate-50 border border-slate-100 flex flex-col items-center justify-center gap-0.5 text-[11px] font-mono text-center">
                            <span className="text-slate-500">Settlement:</span>
                            <span className="font-semibold text-slate-800 truncate max-w-full">
                              {getListingSettlementSummary(item)}
                            </span>
                          </div>
                        </div>

                        {/* Bottom Pricing & Actions */}
                        <div className="w-full pt-4 mt-4 border-t border-slate-100">
                          <div className="flex flex-col items-center justify-center gap-2 mb-3 text-center">
                            <div>
                              <span className="text-[10px] font-mono text-slate-500 uppercase block">
                                {isAuction
                                  ? item.auctionConfig?.highestBidUSD
                                    ? 'Current High Bid'
                                    : 'Starting Bid'
                                  : 'Valuation'}
                              </span>
                              <span className="font-mono text-base font-bold text-amber-700">
                                ${displayPriceUSD.toLocaleString()} USD
                              </span>
                            </div>

                            <div className="flex items-center justify-center gap-4">
                              {/* Likes counter */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleLikeListing(item.id);
                                }}
                                className={`flex items-center gap-1 text-xs transition-colors cursor-pointer ${
                                  item.isLiked ? 'text-red-500 font-semibold' : 'text-slate-500 hover:text-red-500'
                                }`}
                              >
                                <Heart className={`w-4 h-4 ${item.isLiked ? 'fill-red-500 text-red-500' : 'text-slate-400'}`} />
                                <span>{(item as any).likesCount ?? item.likes ?? 0}</span>
                              </button>

                              {/* Views counter */}
                              <div
                                className="flex items-center gap-1 text-[11px] font-mono text-slate-500"
                                title="Posting views"
                              >
                                <Eye className="w-3.5 h-3.5 text-slate-400" />
                                <span>{(item.views ?? 0).toLocaleString()} views</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-center gap-2 w-full">
                            <button
                              type="button"
                              disabled={isSoldOrSettled}
                              onClick={(e) => {
                                e.stopPropagation();
                                incrementListingView(item.id);
                                onOpenBarterModal && onOpenBarterModal(item);
                              }}
                              className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-xs ${
                                isSoldOrSettled
                                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 cursor-default'
                                  : 'bg-amber-500 text-slate-950 hover:bg-amber-400 cursor-pointer'
                              }`}
                            >
                              {isAuction ? <Gavel className="h-3.5 w-3.5" /> : <ArrowRightLeft className="h-3.5 w-3.5" />}
                              <span>{getListingTradeActionLabel(item)}</span>
                            </button>

                            <button
                              type="button"
                              onClick={async (e) => {
                                e.stopPropagation();
                                incrementListingView(item.id);

                                const session = getCurrentSession();
                                if (!session || !session.uid) {
                                  addToast({
                                    type: 'error',
                                    title: 'Authentication Required',
                                    message: 'Please sign in to contact the seller.',
                                  });
                                  return;
                                }

                                const rawItem = item as any;
                                const sellerId = rawItem.sellerId || rawItem.userId || '';
                                const sellerName = rawItem.sellerName || rawItem.creatorName || 'Merchant';
                                const sellerHandle = rawItem.sellerHandle || rawItem.creatorHandle || sellerId;
                                const sellerAvatar = rawItem.sellerAvatar || rawItem.creatorAvatar || '';

                                const targetUid = sellerId.startsWith('user-') ? sellerId : `user-${sellerId.replace(/^@/, '')}`;
                                const targetHandle = sellerHandle.replace(/^@/, '');

                                if (
                                  !isAdminAccount(session) &&
                                  (areUsersBlockedEitherWay(session.uid, targetUid) ||
                                    areUsersBlockedEitherWay(session.id, sellerId) ||
                                    areUsersBlockedEitherWay(session.id, targetHandle))
                                ) {
                                  addToast({
                                    type: 'error',
                                    title: 'Chat Unavailable',
                                    message: 'Cannot contact seller: communication is blocked between these accounts.',
                                  });
                                  return;
                                }

                                try {
                                  const targetProfile = {
                                    uid: targetUid,
                                    userId: sellerId,
                                    name: sellerName,
                                    avatarUrl: sellerAvatar,
                                    role: 'user' as const,
                                  };
                                  const conv = await getOrCreateDirectConversation(session, targetProfile);
                                  setReturnListingId(null);
                                  setChatReturnOrigin('marketplace');
                                  if (conv?.id) {
                                    window.dispatchEvent(new CustomEvent('open_direct_conversation', { detail: conv.id }));
                                  }
                                  setCurrentTab('messages');
                                } catch (err: any) {
                                  addToast({
                                    type: 'error',
                                    title: 'Chat Unavailable',
                                    message: err?.message || 'Cannot start chat with this seller.',
                                  });
                                }
                              }}
                              className="p-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
                              title="Message Trader"
                            >
                              <MessageSquare className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};
