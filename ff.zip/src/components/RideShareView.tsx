/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Car, 
  MapPin, 
  Navigation, 
  UserCheck, 
  Store, 
  UtensilsCrossed, 
  Clock, 
  DollarSign, 
  CheckCircle2, 
  ShieldCheck, 
  Star, 
  Phone, 
  Award, 
  ArrowRight, 
  Package, 
  Compass,
  AlertCircle,
  Check,
  TrendingUp,
  Coins,
  Map,
  History,
  XCircle,
  Search,
  ExternalLink,
  ListOrdered,
  Bell,
  CornerUpLeft,
  CornerUpRight,
  ArrowUp,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  X,
  Play,
  Pause
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { applyCurrencyWalletDelta } from '../utils/walletBalanceUpdater';
import { UserWalletData } from '../types/wallet';
import {
  recordLedgerTransaction,
  LEDGER_UPDATED_EVENT,
  createLedgerItemFromRideShareBooking,
  createLedgerItemFromRideShareCancellation,
  createLedgerItemFromRideSharePayout,
  markLedgerItemReversedByReceipt
} from '../utils/universalLedgerBridge';
import { dispatchGlobalNotification } from '../utils/notificationService';
import {
  AddressSuggestion,
  TurnByTurnStep,
  getAddressSuggestions,
  buildTurnByTurnRoute,
  estimateDeliveryTiming
} from '../utils/rideShareNavigation';
import {
  DEFAULT_VEHICLE_MEDIA,
  getCustomDriverVehicleFallbackPhoto
} from '../utils/vehicleShowcaseMedia';

interface RideShareViewProps {
  currentUser: AuthSession | null;
  onNavigateBack?: () => void;
  onViewUserProfile?: (userIdOrHandle: string) => void;
}

export type DriverVehicleType = 'car' | 'auto_rickshaw' | 'motor_bike';
export type VehicleTypeLabel = 'Car' | 'Auto Rickshaw' | 'Motor Bike';
export type VehicleClassName =
  | 'Economy'
  | 'Comfort EV'
  | 'Luxury Limousine'
  | 'Auto Rickshaw'
  | 'Moto Express';

export interface DriverVehicleSlot {
  vehicleType: DriverVehicleType;
  vehicleTypeLabel: VehicleTypeLabel;
  vehicleClass: VehicleClassName;
  makeModel: string;
  year: string;
  plate: string;
  licenseId: string;
  ratePerMile: number;
  insuranceInfo: string;
  online: boolean;
  media: string[];
  videoMedia?: string[];
  registeredAt: string;
}

interface DriverVehicleDraft {
  makeModel: string;
  vehicleClass: VehicleClassName;
  year: string;
  plate: string;
  licenseId: string;
  ratePerMile: number;
  insuranceInfo: string;
  media: string[];
  videoMedia: string[];
}

export interface RideRequest {
  id: string;
  riderId: string;
  riderName: string;
  pickup: string;
  dropoff: string;
  vehicleType?: VehicleTypeLabel;
  vehicleClass: VehicleClassName;
  fare: number;
  currency: string;
  status: 'searching' | 'driver_assigned' | 'in_transit' | 'completed' | 'cancelled';
  driverId?: string;
  driverName?: string;
  driverCar?: string;
  driverCarYear?: string;
  driverPlate?: string;
  driverPhotos?: string[];
  driverVideos?: string[];
  driverRating?: number;
  createdAt: string;
  rating?: number;
  comment?: string;
  estimatedTime?: string;
  distance?: string;
  directions?: string[];
}

export interface DeliveryContract {
  id: string;
  takeoutOrderId?: string;
  orderNumber: string;
  merchantId: string;
  merchantName: string;
  businessType: 'retail' | 'restaurant';
  deliveryAddress: string;
  customerName: string;
  deliveryFee: number;
  originalStoreFee?: number;
  storeRatePerMile?: number;
  currency: string;
  originalCurrency?: string;
  orderCurrency?: string;
  orderTotalBefore?: number;
  driverRatePerMile?: number;
  status: 'available' | 'accepted' | 'picked_up' | 'delivered' | 'cancelled';
  driverHandle?: string;
  driverName?: string;
  createdAt: string;
  rating?: number;
  comment?: string;
  pickupAddress?: string;
  estimatedTime?: string;
  distance?: string;
  distanceMiles?: number;
  directions?: string[];
  proofPhotos?: string[];
  proofVideos?: string[];
  deliveredAt?: string;
}

export interface DriverDeliveryNotification {
  id: string;
  contractId: string;
  orderNumber: string;
  merchantName: string;
  businessType: 'retail' | 'restaurant';
  pickupAddress: string;
  deliveryAddress: string;
  customerName: string;
  distance: string;
  distanceMiles: number;
  storeFee: number;
  storeFeeCurrency: string;
  storeRatePerMile?: number;
  createdAt: string;
  read: boolean;
}

const ALL_PLATFORM_CURRENCIES = [
  'AFNL', 'FNL-TECH', 'FNL-GOLD', 'FNL-USD', 'FNL-EURO', 'FNL-GBP', 'FNL-CHF', 'BTC-S', 'ETH-S', 'SOL-S'
];

const AVAILABLE_CURRENCIES = ALL_PLATFORM_CURRENCIES;

const SAMPLE_MERCHANT_ORDERS: DeliveryContract[] = [
  {
    id: 'del-1',
    takeoutOrderId: 'ord-ex-ret-1',
    orderNumber: 'ORD-RET-884210',
    merchantId: 'loc-retail-1',
    merchantName: 'Zurich Freeport Sovereign Bullion & Electronics',
    businessType: 'retail',
    pickupAddress: 'Zurich Freeport Hub, Sector 4, 8048 Zürich',
    deliveryAddress: 'Zurich Freeport Vault 4B, 8048 Zürich',
    customerName: 'Sovereign Explorer',
    deliveryFee: 10,
    originalStoreFee: 10,
    storeRatePerMile: 2.5,
    currency: 'FNL-GOLD',
    originalCurrency: 'FNL-GOLD',
    orderCurrency: 'FNL-GOLD',
    orderTotalBefore: 1490,
    status: 'available',
    createdAt: new Date().toISOString(),
    estimatedTime: '~13 mins',
    distance: '4 miles',
    distanceMiles: 4,
    directions: [
      'Head south on Hafnerstrasse toward Förrlibuckstrasse (0.6 mi)',
      'Turn right onto Pfingstweidstrasse (1.4 mi)',
      'Take exit toward Zurich Freeport Security Gate (1.5 mi)',
      'Arrive at Zurich Freeport Vault 4B, 8048 Zürich'
    ]
  },
  {
    id: 'del-2',
    takeoutOrderId: 'ord-ex-res-1',
    orderNumber: 'ORD-TK-554109',
    merchantId: 'loc-rest-1',
    merchantName: "Ranma's Sovereign Dining",
    businessType: 'restaurant',
    pickupAddress: 'Gessnerallee 28, 8001 Zürich',
    deliveryAddress: 'Zurich Freeport Vault 4B, 8048 Zürich',
    customerName: 'Sovereign Explorer',
    deliveryFee: 5,
    originalStoreFee: 5,
    storeRatePerMile: 2.5,
    currency: 'AFNL',
    originalCurrency: 'AFNL',
    orderCurrency: 'AFNL',
    orderTotalBefore: 295,
    status: 'available',
    createdAt: new Date().toISOString(),
    estimatedTime: '~8 mins',
    distance: '2 miles',
    distanceMiles: 2,
    directions: [
      'Head west on Gessnerallee toward Sihlquai (0.4 mi)',
      'Proceed along Pfingstweidstrasse corridor (1.1 mi)',
      'Turn right toward Zurich Freeport Vault 4B, 8048 Zürich (0.5 mi)'
    ]
  },
  {
    id: 'del-3',
    orderNumber: 'ORD-RET-662019',
    merchantId: 'loc-retail-2',
    merchantName: 'Tokyo Cybernetic Vault Hardware',
    businessType: 'retail',
    pickupAddress: 'Akihabara Electric Town Block 4, Tokyo',
    deliveryAddress: 'Akihabara Tech District Floor 9, Tokyo',
    customerName: 'Marcus Vance',
    deliveryFee: 20,
    originalStoreFee: 20,
    currency: 'FNL-TECH',
    originalCurrency: 'FNL-TECH',
    orderCurrency: 'FNL-TECH',
    status: 'available',
    createdAt: new Date().toISOString(),
    estimatedTime: '~6 mins',
    distance: '1.4 miles',
    distanceMiles: 1.4,
    directions: [
      'Head north on Chuo-dori toward Manseibashi (0.4 mi)',
      'Turn left onto Kanda-Neribeicho Ave (0.7 mi)',
      'Arrive at Akihabara Tech District Floor 9'
    ]
  }
];

interface AvailableVehicleOption {
  id: string;
  vehicleType: VehicleTypeLabel;
  vehicleClass: VehicleClassName;
  driverName: string;
  carModel: string;
  carYear: string;
  plate: string;
  rating: number;
  etaMins: number;
  mult: number;
  ratePerMile: number;
  color: string;
  seats: string;
  specs: string;
  media: string[];
  videoMedia: string[];
  available: boolean;
}

const DEFAULT_SECTOR_VEHICLES: AvailableVehicleOption[] = [
  {
    id: 'drv-econ-1',
    vehicleType: 'Car',
    vehicleClass: 'Economy',
    driverName: 'Lukas Meyer',
    carModel: 'VW ID.4 Pro Electric',
    carYear: '2025',
    plate: 'ZH-412-809',
    rating: 4.91,
    etaMins: 3,
    mult: 4.2,
    ratePerMile: 5,
    color: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-econ-1'].videos,
    available: true
  },
  {
    id: 'drv-ev-1',
    vehicleType: 'Car',
    vehicleClass: 'Comfort EV',
    driverName: 'Elena Vance',
    carModel: 'Polestar 2 Long Range',
    carYear: '2025',
    plate: 'ZH-618-334',
    rating: 4.97,
    etaMins: 2,
    mult: 7.5,
    ratePerMile: 6,
    color: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-ev-1'].videos,
    available: true
  },
  {
    id: 'drv-lux-1',
    vehicleType: 'Car',
    vehicleClass: 'Luxury Limousine',
    driverName: 'Marc-Antoine Weber',
    carModel: 'Mercedes-Maybach S680',
    carYear: '2025',
    plate: 'ZH-100-777',
    rating: 4.99,
    etaMins: 5,
    mult: 19.5,
    ratePerMile: 12,
    color: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-lux-1'].videos,
    available: true
  },
  {
    id: 'drv-rick-1',
    vehicleType: 'Auto Rickshaw',
    vehicleClass: 'Auto Rickshaw',
    driverName: 'Aarav Patel',
    carModel: 'Bajaj RE Electric Three-Wheeler',
    carYear: '2025',
    plate: 'ZH-R30-218',
    rating: 4.93,
    etaMins: 2,
    mult: 3.1,
    ratePerMile: 4,
    color: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-rick-1'].videos,
    available: true
  },
  {
    id: 'drv-moto-1',
    vehicleType: 'Motor Bike',
    vehicleClass: 'Moto Express',
    driverName: 'Matteo Rossi',
    carModel: 'Zero SR/F Sovereign Moto',
    carYear: '2025',
    plate: 'ZH-M92-14',
    rating: 4.88,
    etaMins: 1,
    mult: 2.8,
    ratePerMile: 3.5,
    color: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].color,
    seats: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].seats,
    specs: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].specs,
    media: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].photos,
    videoMedia: DEFAULT_VEHICLE_MEDIA['drv-moto-1'].videos,
    available: true
  }
];

const CLASS_META: Record<VehicleClassName, { vehicleType: VehicleTypeLabel; mult: number; defaultEta: number }> = {
  Economy: { vehicleType: 'Car', mult: 4.2, defaultEta: 3 },
  'Comfort EV': { vehicleType: 'Car', mult: 7.5, defaultEta: 2 },
  'Luxury Limousine': { vehicleType: 'Car', mult: 19.5, defaultEta: 5 },
  'Auto Rickshaw': { vehicleType: 'Auto Rickshaw', mult: 3.1, defaultEta: 2 },
  'Moto Express': { vehicleType: 'Motor Bike', mult: 2.8, defaultEta: 1 }
};

const VEHICLE_TYPE_SECTIONS: Array<{
  type: DriverVehicleType;
  label: VehicleTypeLabel;
  defaultClass: VehicleClassName;
  placeholderModel: string;
  placeholderPlate: string;
  defaultRate: number;
}> = [
  {
    type: 'car',
    label: 'Car',
    defaultClass: 'Comfort EV',
    placeholderModel: 'e.g. Tesla Model Y Sovereign',
    placeholderPlate: 'e.g. ZH-884-992',
    defaultRate: 6
  },
  {
    type: 'auto_rickshaw',
    label: 'Auto Rickshaw',
    defaultClass: 'Auto Rickshaw',
    placeholderModel: 'e.g. Bajaj RE Electric Rickshaw',
    placeholderPlate: 'e.g. ZH-R12-409',
    defaultRate: 4
  },
  {
    type: 'motor_bike',
    label: 'Motor Bike',
    defaultClass: 'Moto Express',
    placeholderModel: 'e.g. Zero SR/F Sovereign Bike',
    placeholderPlate: 'e.g. ZH-M44-901',
    defaultRate: 3.5
  }
];

export const RideShareView: React.FC<RideShareViewProps> = ({ currentUser, onViewUserProfile }) => {
  const userId = currentUser?.id || currentUser?.uid || 'guest';
  const userName = currentUser?.name || 'Sovereign Explorer';

  // Main Top Tabs: 'book' | 'driver'
  const [activeTab, setActiveTab] = useState<'book' | 'driver'>('book');

  // Customer Book Rides sub-tabs: 'request' | 'current' | 'history'
  const [bookSubTab, setBookSubTab] = useState<'request' | 'current' | 'history'>('request');

  // Driver sub-tabs: 'ride_dispatches' | 'delivery_dispatches' | 'profile'
  const [driverSubTab, setDriverSubTab] = useState<'ride_dispatches' | 'delivery_dispatches' | 'profile'>('ride_dispatches');

  // Driver Ride Dispatches nested sub-tabs: 'active_dispatches' | 'history'
  const [driverRideSubTab, setDriverRideSubTab] = useState<'active_dispatches' | 'history'>('active_dispatches');

  // Driver Delivery Dispatches nested sub-tabs: 'active_deliveries' | 'history'
  const [driverDeliverySubTab, setDriverDeliverySubTab] = useState<'active_deliveries' | 'history'>('active_deliveries');

  // Two tabs under Driver Delivery Active Dispatches: 'restaurant' | 'retail'
  const [activeDeliveryDispatchTab, setActiveDeliveryDispatchTab] = useState<'restaurant' | 'retail'>('restaurant');

  // Live User Wallet State (strictly restricts customer ride payments to possessed Final coins)
  const [userWallet, setUserWallet] = useState<UserWalletData>(() => getStoredUserWallets(userId));

  useEffect(() => {
    const syncWallet = () => {
      setUserWallet(getStoredUserWallets(userId));
    };
    syncWallet();
    window.addEventListener('final_finance_wallets_updated', syncWallet);
    window.addEventListener('storage', syncWallet);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', syncWallet);
      window.removeEventListener('storage', syncWallet);
    };
  }, [userId]);

  const possessedFinalCoins = React.useMemo(() => {
    const seen: Record<string, { symbol: string; name: string; balance: number }> = {};
    (userWallet.finalCoins || []).forEach(fc => {
      const sym = (fc.symbol || '').toUpperCase().trim();
      const bal = Number(fc.balance || 0);
      if (!sym || bal <= 0) return;
      const existing = seen[sym];
      if (existing) {
        existing.balance += bal;
      } else {
        seen[sym] = { symbol: sym, name: fc.name || sym, balance: bal };
      }
    });
    return Object.values(seen);
  }, [userWallet]);

  // Customer can pay with ANY Final currency they possess (as long as they have enough)
  const [selectedCurrency, setSelectedCurrency] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_customer_selected_currency_${userId}`);
      if (saved) return saved;
    } catch {}
    return 'AFNL';
  });
  const [customerCurrencySearch, setCustomerCurrencySearch] = useState('');
  const [walletErrorMsg, setWalletErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const ownedSymbols = possessedFinalCoins.map(c => c.symbol);
    if (ownedSymbols.length === 0) return;
    if (!ownedSymbols.includes(selectedCurrency.toUpperCase())) {
      const next = ownedSymbols[0];
      setSelectedCurrency(next);
      try {
        localStorage.setItem(`final_finance_customer_selected_currency_${userId}`, next);
      } catch {}
    }
  }, [possessedFinalCoins, selectedCurrency, userId]);

  // Book Rides State
  const [pickupLocation, setPickupLocation] = useState('Zurich Freeport Terminal 4B, 8048 Zürich');
  const [dropoffLocation, setDropoffLocation] = useState('Bahnhofstrasse Luxury Financial District, 8001 Zürich');
  const [pickupSuggestionsOpen, setPickupSuggestionsOpen] = useState(false);
  const [dropoffSuggestionsOpen, setDropoffSuggestionsOpen] = useState(false);
  const [pickupHighlightIdx, setPickupHighlightIdx] = useState(-1);
  const [dropoffHighlightIdx, setDropoffHighlightIdx] = useState(-1);
  const pickupBoxRef = React.useRef<HTMLDivElement | null>(null);
  const dropoffBoxRef = React.useRef<HTMLDivElement | null>(null);
  const [selectedVehicleType, setSelectedVehicleType] = useState<'All' | VehicleTypeLabel>('All');
  const [selectedClass, setSelectedClass] = useState<VehicleClassName>('Comfort EV');
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('drv-ev-1');
  const [expandedVehicleId, setExpandedVehicleId] = useState<string | null>(null);
  
  const [myRides, setMyRides] = useState<RideRequest[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_my_rides_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'ride-demo-407732',
        riderId: userId,
        riderName: userName,
        pickup: 'Zurich Freeport Terminal 4B, 8048 Zürich',
        dropoff: 'Bahnhofstrasse Luxury Financial District, 8001 Zürich',
        vehicleClass: 'Comfort EV',
        fare: 32,
        currency: 'AFNL',
        status: 'driver_assigned',
        driverId: 'driver-hans',
        driverName: 'Hansruedi Keller',
        driverCar: 'Tesla Model Y Long Range (White)',
        driverRating: 4.96,
        createdAt: new Date().toISOString(),
        estimatedTime: '~14 mins',
        distance: '4.2 miles',
        directions: [
          'Depart from pickup: Zurich Freeport Terminal 4B (0.3 mi)',
          'Merge onto main Sovereign Transit Corridor toward financial district (2.8 mi)',
          'Arrive at destination: Bahnhofstrasse Luxury Financial District'
        ]
      }
    ];
  });
  const [isBookingRide, setIsBookingRide] = useState(false);
  const [customerNavStepIdx, setCustomerNavStepIdx] = useState<number>(1);
  const [isAutoNavigatingCustomer, setIsAutoNavigatingCustomer] = useState<boolean>(true);
  const [driverRideStepIdx, setDriverRideStepIdx] = useState<number>(0);
  const [driverDeliveryStepIdx, setDriverDeliveryStepIdx] = useState<number>(0);
  const [isAutoGpsDriverRide, setIsAutoGpsDriverRide] = useState<boolean>(true);
  const [isAutoGpsDriverDelivery, setIsAutoGpsDriverDelivery] = useState<boolean>(true);
  const [voiceGpsEnabled, setVoiceGpsEnabled] = useState<boolean>(true);
  const [focusedDeliveryId, setFocusedDeliveryId] = useState<string | null>(null);
  const [proofModalContractId, setProofModalContractId] = useState<string | null>(null);
  const [deliveryProofPhotos, setDeliveryProofPhotos] = useState<string[]>([]);
  const [deliveryProofVideos, setDeliveryProofVideos] = useState<string[]>([]);

  // Cancellation modal state / warning state
  const [showCancelWarningModal, setShowCancelWarningModal] = useState(false);
  const [pendingCancelRideId, setPendingCancelRideId] = useState<string | null>(null);

  // Blocked Users State (checked from localStorage)
  const [blockedUsers] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_blocked_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  // Driver Config State
  const [currencySearchQuery, setCurrencySearchQuery] = useState('');
  const [driverCurrencies, setDriverCurrencies] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_driver_currencies_${userId}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return ['AFNL', 'FNL-TECH', 'FNL-GOLD', 'FNL-USD', 'FNL-EURO'];
  });
  const [ratePerMile, setRatePerMile] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`final_finance_driver_rate_${userId}`);
      if (saved) return parseFloat(saved);
    } catch {}
    return 6;
  });

  // 3 separate vehicle slots: Car, Auto Rickshaw, Motor Bike (strictly max 1 per vehicle type)
  const [driverVehicles, setDriverVehicles] = useState<Record<DriverVehicleType, DriverVehicleSlot | null>>(() => {
    try {
      const savedSlots = localStorage.getItem(`final_finance_driver_vehicles_${userId}`);
      if (savedSlots) {
        const parsed = JSON.parse(savedSlots);
        return {
          car: parsed.car || null,
          auto_rickshaw: parsed.auto_rickshaw || null,
          motor_bike: parsed.motor_bike || null
        };
      }
      // Migrate legacy single-vehicle registration into the Car / appropriate slot
      if (localStorage.getItem(`final_finance_is_driver_${userId}`) === 'true') {
        const legacyMake = localStorage.getItem(`final_finance_driver_carmake_${userId}`) || 'Tesla Model Y Sovereign';
        const legacyYear = localStorage.getItem(`final_finance_driver_caryear_${userId}`) || '2025';
        const legacyPlate = localStorage.getItem(`final_finance_driver_plate_${userId}`) || 'ZH-884-992';
        const legacyRate = parseFloat(localStorage.getItem(`final_finance_driver_rate_${userId}`) || '6') || 6;
        const legacyClassRaw = localStorage.getItem(`final_finance_driver_carclass_${userId}`) || 'Comfort EV';
        const isMoto = legacyClassRaw === 'Moto Express';
        const slotType: DriverVehicleType = isMoto ? 'motor_bike' : 'car';
        const vClass: VehicleClassName = isMoto
          ? 'Moto Express'
          : (legacyClassRaw === 'Economy' || legacyClassRaw === 'Luxury Limousine' ? legacyClassRaw : 'Comfort EV');
        return {
          car: slotType === 'car'
            ? {
                vehicleType: 'car',
                vehicleTypeLabel: 'Car',
                vehicleClass: vClass,
                makeModel: legacyMake,
                year: legacyYear,
                plate: legacyPlate,
                licenseId: 'CH-LIC-99214',
                ratePerMile: legacyRate,
                insuranceInfo: 'Zurich Sovereign Commercial Fleet Policy #CH-INS-88491',
                online: true,
                media: [],
                registeredAt: new Date().toISOString()
              }
            : null,
          auto_rickshaw: null,
          motor_bike: slotType === 'motor_bike'
            ? {
                vehicleType: 'motor_bike',
                vehicleTypeLabel: 'Motor Bike',
                vehicleClass: 'Moto Express',
                makeModel: legacyMake,
                year: legacyYear,
                plate: legacyPlate,
                licenseId: 'CH-LIC-99214',
                ratePerMile: legacyRate,
                insuranceInfo: 'Zurich Sovereign Commercial Fleet Policy #CH-INS-88491',
                online: true,
                media: [],
                registeredAt: new Date().toISOString()
              }
            : null
        };
      }
    } catch {}
    return { car: null, auto_rickshaw: null, motor_bike: null };
  });

  const [driverDrafts, setDriverDrafts] = useState<Record<DriverVehicleType, DriverVehicleDraft>>({
    car: {
      makeModel: 'Tesla Model Y Sovereign',
      vehicleClass: 'Comfort EV',
      year: '2025',
      plate: 'ZH-884-992',
      licenseId: 'CH-LIC-99214',
      ratePerMile: 6,
      insuranceInfo: 'Zurich Sovereign Commercial Fleet Policy #CH-INS-88491',
      media: [],
      videoMedia: []
    },
    auto_rickshaw: {
      makeModel: 'Bajaj RE Electric Three-Wheeler',
      vehicleClass: 'Auto Rickshaw',
      year: '2025',
      plate: 'ZH-R12-409',
      licenseId: 'CH-LIC-99214',
      ratePerMile: 4,
      insuranceInfo: 'Zurich Light Transit Commercial Policy #CH-RIC-31092',
      media: [],
      videoMedia: []
    },
    motor_bike: {
      makeModel: 'Zero SR/F Sovereign Bike',
      vehicleClass: 'Moto Express',
      year: '2025',
      plate: 'ZH-M44-901',
      licenseId: 'CH-LIC-99214',
      ratePerMile: 3.5,
      insuranceInfo: 'Zurich Express Courier & Rider Policy #CH-MOT-77318',
      media: [],
      videoMedia: []
    }
  });

  const [driverEarnings, setDriverEarnings] = useState(1420);
  const [activeDriverPayoutCoin, setActiveDriverPayoutCoin] = useState<string>(() => driverCurrencies[0] || 'AFNL');

  useEffect(() => {
    if (!driverCurrencies.includes(activeDriverPayoutCoin) && driverCurrencies.length > 0) {
      setActiveDriverPayoutCoin(driverCurrencies[0]);
    }
  }, [driverCurrencies, activeDriverPayoutCoin]);

  useEffect(() => {
    const handleOutsideClick = (ev: MouseEvent) => {
      if (pickupBoxRef.current && !pickupBoxRef.current.contains(ev.target as Node)) {
        setPickupSuggestionsOpen(false);
      }
      if (dropoffBoxRef.current && !dropoffBoxRef.current.contains(ev.target as Node)) {
        setDropoffSuggestionsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Back button state preservation via hash
  useEffect(() => {
    try {
      window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
    } catch {}
  }, [activeTab, bookSubTab]);

  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash.includes('subtab=current')) setBookSubTab('current');
      else if (hash.includes('subtab=history')) setBookSubTab('history');
      else if (hash.includes('subtab=request')) setBookSubTab('request');
      if (hash.includes('tab=driver')) setActiveTab('driver');
      else if (hash.includes('tab=book')) setActiveTab('book');
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Delivery Partner Marketplace State
  const [deliveryContracts, setDeliveryContracts] = useState<DeliveryContract[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_delivery_contracts');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    try {
      localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(SAMPLE_MERCHANT_ORDERS));
    } catch {}
    return SAMPLE_MERCHANT_ORDERS;
  });

  const [driverDeliveryNotifications, setDriverDeliveryNotifications] = useState<DriverDeliveryNotification[]>(() => {
    try {
      const saved = localStorage.getItem('final_finance_driver_delivery_notifications');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  useEffect(() => {
    const syncDeliveryState = () => {
      try {
        const savedContracts = localStorage.getItem('final_finance_delivery_contracts');
        if (savedContracts) {
          const parsed = JSON.parse(savedContracts);
          if (Array.isArray(parsed)) setDeliveryContracts(parsed);
        }
      } catch {}
      try {
        const savedNotifs = localStorage.getItem('final_finance_driver_delivery_notifications');
        if (savedNotifs) {
          const parsed = JSON.parse(savedNotifs);
          if (Array.isArray(parsed)) setDriverDeliveryNotifications(parsed);
        }
      } catch {}
    };
    window.addEventListener('final_finance_delivery_contracts_updated', syncDeliveryState);
    window.addEventListener('storage', syncDeliveryState);
    return () => {
      window.removeEventListener('final_finance_delivery_contracts_updated', syncDeliveryState);
      window.removeEventListener('storage', syncDeliveryState);
    };
  }, []);

  // Rating & Review state
  const [ratingModalRideId, setRatingModalRideId] = useState<string | null>(null);
  const [ratingModalDeliveryId, setRatingModalDeliveryId] = useState<string | null>(null);
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewComment, setReviewComment] = useState<string>('');

  // Countdown timer ticker for 2-minute cancellation window
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const saveMyRides = (rides: RideRequest[]) => {
    setMyRides(rides);
    try {
      localStorage.setItem(`final_finance_my_rides_${userId}`, JSON.stringify(rides));
    } catch {}
  };

  const saveDeliveryContracts = (contracts: DeliveryContract[]) => {
    setDeliveryContracts(contracts);
    try {
      localStorage.setItem('final_finance_delivery_contracts', JSON.stringify(contracts));
    } catch {}
  };

  const previewRoute = React.useMemo(
    () => buildTurnByTurnRoute(pickupLocation, dropoffLocation, 'customer_ride'),
    [pickupLocation, dropoffLocation]
  );

  const recentAddressList = React.useMemo(
    () => Array.from(new Set(myRides.flatMap(r => [r.pickup, r.dropoff]).filter(Boolean))),
    [myRides]
  );

  const pickupSuggestions = React.useMemo(
    () => getAddressSuggestions(pickupLocation, recentAddressList),
    [pickupLocation, recentAddressList]
  );

  const dropoffSuggestions = React.useMemo(
    () => getAddressSuggestions(dropoffLocation, recentAddressList),
    [dropoffLocation, recentAddressList]
  );

  // Available Vehicles Pool across Car, Auto Rickshaw, and Motor Bike (only show available vehicles)
  const availableVehiclePool = React.useMemo(() => {
    const busyDriverIds = new Set(
      myRides
        .filter(r => r.status === 'driver_assigned' || r.status === 'in_transit')
        .map(r => r.driverId)
        .filter(Boolean)
    );
    const basePool = DEFAULT_SECTOR_VEHICLES.filter(v => v.available && !busyDriverIds.has(v.id));

    (['car', 'auto_rickshaw', 'motor_bike'] as DriverVehicleType[]).forEach(vType => {
      const slot = driverVehicles[vType];
      const slotDriverId = `${userId}:${vType}`;
      if (slot && slot.online && !busyDriverIds.has(slotDriverId) && !busyDriverIds.has(userId)) {
        basePool.unshift({
          id: slotDriverId,
          vehicleType: slot.vehicleTypeLabel,
          vehicleClass: slot.vehicleClass,
          driverName: userName,
          carModel: slot.makeModel,
          carYear: slot.year,
          plate: slot.plate,
          rating: 4.98,
          etaMins: CLASS_META[slot.vehicleClass]?.defaultEta ?? 2,
          mult: CLASS_META[slot.vehicleClass]?.mult ?? 6,
          ratePerMile: slot.ratePerMile,
          color: 'Registered Fleet Finish',
          seats:
            slot.vehicleTypeLabel === 'Motor Bike'
              ? '1 Passenger · Helmet Provided'
              : slot.vehicleTypeLabel === 'Auto Rickshaw'
                ? '3 Passengers · Covered Cabin'
                : '4 Passengers · Climate Control',
          specs: `${slot.makeModel} (${slot.year}) · ${slot.vehicleClass}`,
          media:
            slot.media && slot.media.length > 0
              ? slot.media
              : [getCustomDriverVehicleFallbackPhoto(slot.vehicleTypeLabel, slot.makeModel, slot.plate)],
          videoMedia: slot.videoMedia && slot.videoMedia.length > 0 ? slot.videoMedia : [],
          available: true
        });
      }
    });
    return basePool;
  }, [myRides, driverVehicles, userId, userName]);

  const availableVehicleTypes = React.useMemo(() => {
    const typeOrder: VehicleTypeLabel[] = ['Car', 'Auto Rickshaw', 'Motor Bike'];
    return typeOrder.filter(t => availableVehiclePool.some(v => v.vehicleType === t));
  }, [availableVehiclePool]);

  useEffect(() => {
    if (selectedVehicleType !== 'All' && !availableVehicleTypes.includes(selectedVehicleType)) {
      setSelectedVehicleType('All');
    }
  }, [availableVehicleTypes, selectedVehicleType]);

  const filteredAvailableVehicles = React.useMemo(
    () =>
      availableVehiclePool.filter(
        v => selectedVehicleType === 'All' || v.vehicleType === selectedVehicleType
      ),
    [availableVehiclePool, selectedVehicleType]
  );

  const availableVehicleClasses = React.useMemo(() => {
    const ordered: VehicleClassName[] = [
      'Economy',
      'Comfort EV',
      'Luxury Limousine',
      'Auto Rickshaw',
      'Moto Express'
    ];
    return ordered
      .map(cls => {
        const cars = filteredAvailableVehicles.filter(v => v.vehicleClass === cls);
        if (cars.length === 0) return null;
        const primary = cars[0];
        return {
          title: cls,
          vehicleType: CLASS_META[cls].vehicleType,
          cars,
          primaryCar: primary,
          mult: CLASS_META[cls].mult,
          time: `${primary.etaMins} min`
        };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null);
  }, [filteredAvailableVehicles]);

  const selectedVehicle = React.useMemo(
    () =>
      filteredAvailableVehicles.find(v => v.id === selectedVehicleId) ||
      filteredAvailableVehicles.find(v => v.vehicleClass === selectedClass) ||
      filteredAvailableVehicles[0] ||
      null,
    [filteredAvailableVehicles, selectedVehicleId, selectedClass]
  );

  useEffect(() => {
    if (selectedVehicle && selectedVehicle.id !== selectedVehicleId) {
      setSelectedVehicleId(selectedVehicle.id);
    }
    if (selectedVehicle && selectedVehicle.vehicleClass !== selectedClass) {
      setSelectedClass(selectedVehicle.vehicleClass);
    }
  }, [selectedVehicle, selectedVehicleId, selectedClass]);

  const currentEstimatedFare = React.useMemo(() => {
    const mult = selectedVehicle?.mult ?? CLASS_META[selectedClass]?.mult ?? 7.5;
    return Math.round(Math.max(8, previewRoute.distanceMiles * mult * (ratePerMile / 6)) * 10) / 10;
  }, [selectedVehicle, selectedClass, previewRoute.distanceMiles, ratePerMile]);

  const totalFinalMoneyBalance = React.useMemo(
    () => possessedFinalCoins.reduce((sum, c) => sum + Number(c.balance || 0), 0),
    [possessedFinalCoins]
  );

  const selectedCurrencyBalance = React.useMemo(
    () =>
      possessedFinalCoins.find(c => c.symbol.toUpperCase() === selectedCurrency.toUpperCase())
        ?.balance ?? 0,
    [possessedFinalCoins, selectedCurrency]
  );

  const hasEnoughSelectedCurrency =
    possessedFinalCoins.length > 0 && selectedCurrencyBalance >= currentEstimatedFare;

  const hasEnoughAnyFinalCurrency = possessedFinalCoins.some(
    c => Number(c.balance || 0) >= currentEstimatedFare
  );

  const handleBookRide = (e: React.FormEvent) => {
    e.preventDefault();
    setWalletErrorMsg(null);
    if (!pickupLocation.trim() || !dropoffLocation.trim()) return;

    const chosenClassGroup = availableVehicleClasses.find(c => c.title === selectedClass);
    if (!chosenClassGroup || chosenClassGroup.cars.length === 0) {
      dispatchGlobalNotification({
        title: 'No Vehicles Available',
        description: 'There are currently no available cars for the selected vehicle class.',
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const route = buildTurnByTurnRoute(pickupLocation, dropoffLocation, 'customer_ride');
    const calculatedFare =
      Math.round(
        Math.max(8, route.distanceMiles * CLASS_META[selectedClass].mult * (ratePerMile / 6)) * 10
      ) / 10;

    // Validate live Final coin balance from wallet
    const latestWallet = getStoredUserWallets(userId);
    const ownedFinalCoins = (latestWallet.finalCoins || []).filter(fc => Number(fc.balance || 0) > 0);
    const totalOwnedFinal = ownedFinalCoins.reduce((s, c) => s + Number(c.balance || 0), 0);
    const targetCoinIdx = (latestWallet.finalCoins || []).findIndex(
      fc => fc.symbol.toUpperCase() === selectedCurrency.toUpperCase()
    );
    const availableInSelected =
      targetCoinIdx >= 0 ? Number(latestWallet.finalCoins[targetCoinIdx].balance || 0) : 0;

    if (ownedFinalCoins.length === 0 || totalOwnedFinal < calculatedFare || availableInSelected < calculatedFare) {
      const msg =
        totalOwnedFinal < calculatedFare
          ? `There's not enough Final money. Your wallet holds ${totalOwnedFinal.toLocaleString()} across Final coins, and this trip requires ${calculatedFare} ${selectedCurrency}.`
          : `There's not enough Final money in ${selectedCurrency} (Available: ${availableInSelected.toLocaleString()} ${selectedCurrency}, Required: ${calculatedFare} ${selectedCurrency}).`;
      setWalletErrorMsg(msg);
      dispatchGlobalNotification({
        title: "There's not enough Final money",
        description: msg,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    setIsBookingRide(true);
    setTimeout(() => {
      const assignedVehicle = selectedVehicle || chosenClassGroup.cars[0];
      const freshWallet = getStoredUserWallets(userId);
      const coinIndex = (freshWallet.finalCoins || []).findIndex(
        fc => fc.symbol.toUpperCase() === selectedCurrency.toUpperCase()
      );
      if (coinIndex < 0 || Number(freshWallet.finalCoins[coinIndex].balance || 0) < calculatedFare) {
        setIsBookingRide(false);
        setWalletErrorMsg("There's not enough Final money.");
        return;
      }

      const updatedFinalCoins = [...freshWallet.finalCoins];
      updatedFinalCoins[coinIndex] = {
        ...updatedFinalCoins[coinIndex],
        balance: Math.max(0, Math.round((updatedFinalCoins[coinIndex].balance - calculatedFare) * 100) / 100)
      };
      saveStoredUserWallets(userId, { ...freshWallet, finalCoins: updatedFinalCoins });
      setUserWallet(getStoredUserWallets(userId));

      const matchedSlotKey: DriverVehicleType | null =
        assignedVehicle.id === `${userId}:car`
          ? 'car'
          : assignedVehicle.id === `${userId}:auto_rickshaw`
            ? 'auto_rickshaw'
            : assignedVehicle.id === `${userId}:motor_bike`
              ? 'motor_bike'
              : null;

      const newRide: RideRequest = {
        id: `ride-${Date.now()}`,
        riderId: userId,
        riderName: userName,
        pickup: pickupLocation.trim(),
        dropoff: dropoffLocation.trim(),
        vehicleType: assignedVehicle.vehicleType || chosenClassGroup.vehicleType,
        vehicleClass: assignedVehicle.vehicleClass || selectedClass,
        fare: calculatedFare,
        currency: selectedCurrency,
        status: 'driver_assigned',
        driverId: assignedVehicle.id,
        driverName: assignedVehicle.driverName,
        driverCar: assignedVehicle.carModel,
        driverCarYear: assignedVehicle.carYear,
        driverPlate: assignedVehicle.plate,
        driverPhotos: matchedSlotKey
          ? (driverVehicles[matchedSlotKey]?.media || assignedVehicle.media || [])
          : (assignedVehicle.media || []),
        driverVideos: matchedSlotKey
          ? (driverVehicles[matchedSlotKey]?.videoMedia || assignedVehicle.videoMedia || [])
          : (assignedVehicle.videoMedia || []),
        driverRating: assignedVehicle.rating,
        createdAt: new Date().toISOString(),
        estimatedTime: `~${route.estimatedMinutes} mins`,
        distance: `${route.distanceMiles} miles`,
        directions: route.steps.map(s => s.instruction)
      };

      const updated = [newRide, ...myRides];
      saveMyRides(updated);

      const bookLedgerItem = createLedgerItemFromRideShareBooking({
        rideId: newRide.id,
        pickup: newRide.pickup,
        dropoff: newRide.dropoff,
        vehicleType: newRide.vehicleType,
        vehicleClass: newRide.vehicleClass,
        driverName: assignedVehicle.driverName,
        driverCar: assignedVehicle.carModel,
        fare: calculatedFare,
        currency: selectedCurrency,
        distance: newRide.distance,
        estimatedTime: newRide.estimatedTime
      });
      recordLedgerTransaction(userId, bookLedgerItem);
      window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

      setIsBookingRide(false);
      setCustomerNavStepIdx(0);
      setIsAutoNavigatingCustomer(true);
      setBookSubTab('current');

      dispatchGlobalNotification({
        title: '🚗 Ride Booked & Driver Assigned!',
        description: `${assignedVehicle.driverName} (${assignedVehicle.carModel}) dispatched for ${calculatedFare} ${selectedCurrency}. Live Turn-by-Turn GPS active.`,
        type: 'ride_share',
        targetTab: 'ride_share',
        amount: calculatedFare,
        currency: selectedCurrency,
        showToast: true,
        tone: 'success'
      });
    }, 600);
  };

  const initiateCancelRide = (rideId: string) => {
    const target = myRides.find(r => r.id === rideId);
    if (!target || target.status === 'cancelled' || target.status === 'completed') return;

    const elapsedMs = Date.now() - new Date(target.createdAt).getTime();
    const isAfterTwoMinutes = elapsedMs > 120000;

    if (isAfterTwoMinutes) {
      setPendingCancelRideId(rideId);
      setShowCancelWarningModal(true);
    } else {
      executeCancelRide(rideId, false);
    }
  };

  const executeCancelRide = (rideId: string, applyFee: boolean) => {
    const target = myRides.find(r => r.id === rideId);
    const cancellationFee = applyFee && target ? Math.round(target.fare * 0.1 * 100) / 100 : 0;
    const refundAmount = target ? Math.max(0, Math.round((target.fare - cancellationFee) * 100) / 100) : 0;

    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'cancelled' as const } : r
    );
    saveMyRides(updated);
    setShowCancelWarningModal(false);
    setPendingCancelRideId(null);

    if (target && refundAmount > 0 && target.id !== 'ride-demo-407732') {
      const res = applyCurrencyWalletDelta({
        userId,
        currencySymbol: target.currency,
        delta: refundAmount,
        utilityNote: `Ride cancellation refund (#${target.id.slice(-6)})`
      });
      setUserWallet(res.wallet);
    }

    if (target) {
      const receiptCode = `RIDE-${target.id.slice(-6).toUpperCase()}`;
      markLedgerItemReversedByReceipt(userId, receiptCode);
      const cancelLedgerItem = createLedgerItemFromRideShareCancellation({
        rideId: target.id,
        pickup: target.pickup,
        dropoff: target.dropoff,
        driverName: target.driverName || 'Sovereign Driver',
        originalFare: target.fare,
        refundAmount,
        cancellationFee,
        currency: target.currency,
        reason: applyFee
          ? 'Cancelled after 2-minute free window (10% late fee applied).'
          : 'Cancelled within 2-minute free cancellation window.'
      });
      recordLedgerTransaction(userId, cancelLedgerItem);
      window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));
    }

    if (applyFee && cancellationFee > 0 && target) {
      dispatchGlobalNotification({
        title: '⚠️ Ride Cancelled (Late Fee Applied)',
        description: `Cancelled after 2 minutes. A 10% cancellation fee of ${cancellationFee.toFixed(2)} ${target.currency} was charged (${refundAmount.toFixed(2)} ${target.currency} refunded).`,
        type: 'ride_share',
        targetTab: 'dash_ledger',
        amount: refundAmount,
        currency: target.currency,
        showToast: true,
        tone: 'alert'
      });
    } else {
      dispatchGlobalNotification({
        title: '✅ Ride Cancelled Successfully',
        description: 'Your ride was cancelled within the 2-minute free window.',
        type: 'ride_share',
        targetTab: 'dash_ledger',
        showToast: true,
        tone: 'success'
      });
    }
  };

  const handleDriverAcceptRide = (rideId: string) => {
    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'in_transit' as const, driverId: userId, driverName: userName } : r
    );
    saveMyRides(updated);
    setDriverRideStepIdx(0);
    dispatchGlobalNotification({
      title: '🚗 Ride Accepted & Navigating',
      description: `You have accepted dispatch #${rideId.slice(-6)}. Follow Driver Turn-by-Turn Map Directions to pickup.`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'success'
    });
  };

  const handleDriverCompleteRide = (rideId: string) => {
    const target = myRides.find(r => r.id === rideId);
    if (!target || target.status === 'completed') return;
    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'completed' as const } : r
    );
    saveMyRides(updated);
    setDriverEarnings(prev => Math.round((prev + target.fare) * 100) / 100);
    setDriverRideStepIdx(0);

    const creditRes = applyCurrencyWalletDelta({
      userId,
      currencySymbol: target.currency,
      delta: target.fare,
      utilityNote: `Ride-share driver payout (${target.pickup} → ${target.dropoff})`
    });
    setUserWallet(creditRes.wallet);

    const payoutLedgerItem = createLedgerItemFromRideSharePayout({
      kind: 'ride',
      refId: target.id,
      pickup: target.pickup,
      dropoff: target.dropoff,
      counterparty: target.riderName || 'Passenger',
      amount: target.fare,
      currency: target.currency
    });
    recordLedgerTransaction(userId, payoutLedgerItem);
    window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

    dispatchGlobalNotification({
      title: `✅ Trip Completed (+${target.fare} ${target.currency})`,
      description: `Passenger arrived at ${target.dropoff}. Earnings credited to your Final Wallet.`,
      type: 'ride_share',
      targetTab: 'dash_ledger',
      amount: target.fare,
      currency: target.currency,
      showToast: true,
      tone: 'success'
    });
  };

  const handleDriverCancelRide = (rideId: string) => {
    const updated = myRides.map(r =>
      r.id === rideId ? { ...r, status: 'searching' as const, driverId: undefined } : r
    );
    saveMyRides(updated);
    setDriverRideStepIdx(0);
    dispatchGlobalNotification({
      title: '🚫 Ride Dispatch Cancelled / Unassigned',
      description: `You have cancelled your acceptance for ride dispatch #${rideId.slice(-6)}.`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'alert'
    });
  };

  const persistDriverVehicles = (nextSlots: Record<DriverVehicleType, DriverVehicleSlot | null>) => {
    setDriverVehicles(nextSlots);
    try {
      localStorage.setItem(`final_finance_driver_vehicles_${userId}`, JSON.stringify(nextSlots));
      const anyRegistered = Boolean(nextSlots.car || nextSlots.auto_rickshaw || nextSlots.motor_bike);
      localStorage.setItem(`final_finance_is_driver_${userId}`, anyRegistered ? 'true' : 'false');
    } catch {}
  };

  const updateDriverDraft = (
    vType: DriverVehicleType,
    patch: Partial<DriverVehicleDraft>
  ) => {
    setDriverDrafts(prev => ({
      ...prev,
      [vType]: { ...prev[vType], ...patch }
    }));
  };

  const handleRegisterVehicleSlot = (vType: DriverVehicleType, e: React.FormEvent) => {
    e.preventDefault();
    const meta = VEHICLE_TYPE_SECTIONS.find(s => s.type === vType)!;
    if (driverVehicles[vType]) {
      dispatchGlobalNotification({
        title: `⚠️ Maximum 1 ${meta.label} Allowed`,
        description: `You already have 1 ${meta.label} registered. Drivers can sign up for Car, Auto Rickshaw, and Motor Bike (1 of each maximum).`,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const draft = driverDrafts[vType];
    const parsedRate = Number(draft.ratePerMile);
    if (
      !draft.makeModel.trim() ||
      !draft.year.trim() ||
      !draft.plate.trim() ||
      !draft.licenseId.trim() ||
      !draft.insuranceInfo.trim() ||
      !Number.isFinite(parsedRate) ||
      parsedRate <= 0
    ) {
      dispatchGlobalNotification({
        title: '⚠️ Missing Required Information',
        description: `All 6 fields (Vehicle Make & Model, Year, License Plate, License ID, Rate Per Mile, and Insurance Information) are required to register your ${meta.label}.`,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    const assignedClass: VehicleClassName =
      vType === 'car'
        ? draft.vehicleClass
        : vType === 'auto_rickshaw'
          ? 'Auto Rickshaw'
          : 'Moto Express';

    const newSlot: DriverVehicleSlot = {
      vehicleType: vType,
      vehicleTypeLabel: meta.label,
      vehicleClass: assignedClass,
      makeModel: draft.makeModel.trim(),
      year: draft.year.trim(),
      plate: draft.plate.trim(),
      licenseId: draft.licenseId.trim(),
      ratePerMile: parsedRate,
      insuranceInfo: draft.insuranceInfo.trim(),
      online: true,
      media: draft.media || [],
      videoMedia: draft.videoMedia || [],
      registeredAt: new Date().toISOString()
    };

    const nextSlots = { ...driverVehicles, [vType]: newSlot };
    persistDriverVehicles(nextSlots);
    setRatePerMile(parsedRate);
    try {
      localStorage.setItem(`final_finance_driver_rate_${userId}`, parsedRate.toString());
      localStorage.setItem(`final_finance_driver_currencies_${userId}`, JSON.stringify(driverCurrencies));
    } catch {}

    dispatchGlobalNotification({
      title: `🛡️ ${meta.label} Registered & Online`,
      description: `${newSlot.year} ${newSlot.makeModel} (Plate ${newSlot.plate}) registered at ${parsedRate} ${activeDriverPayoutCoin}/mi.`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'success'
    });
  };

  const handleToggleSlotOnline = (vType: DriverVehicleType) => {
    const existing = driverVehicles[vType];
    if (!existing) return;
    const nextSlots = {
      ...driverVehicles,
      [vType]: { ...existing, online: !existing.online }
    };
    persistDriverVehicles(nextSlots);
  };

  const handleRemoveVehicleSlot = (vType: DriverVehicleType) => {
    const existing = driverVehicles[vType];
    if (!existing) return;
    const nextSlots = { ...driverVehicles, [vType]: null };
    persistDriverVehicles(nextSlots);
    dispatchGlobalNotification({
      title: `${existing.vehicleTypeLabel} Unregistered`,
      description: `Removed ${existing.makeModel}. You may register a replacement ${existing.vehicleTypeLabel} anytime (max 1 per type).`,
      type: 'ride_share',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'default'
    });
  };

  const dismissDriverNotification = (notifId: string) => {
    const updated = driverDeliveryNotifications.map(n => n.id === notifId ? { ...n, read: true } : n);
    setDriverDeliveryNotifications(updated);
    try {
      localStorage.setItem('final_finance_driver_delivery_notifications', JSON.stringify(updated));
    } catch {}
  };

  const handleAcceptDeliveryContract = (contractId: string) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    if (!target || target.status !== 'available') return;

    const rawDistance = target.distanceMiles ?? (parseFloat(target.distance || '4') || 4.0);
    const isKm = (target.distance || '').toLowerCase().includes('km');
    const distanceMiles = isKm ? Math.max(0.5, Math.round(rawDistance * 0.621371 * 10) / 10) : rawDistance;
    const driverCoin = activeDriverPayoutCoin || driverCurrencies[0] || 'AFNL';
    const driverFee = Math.round(ratePerMile * distanceMiles * 100) / 100;
    const originalFee = target.originalStoreFee ?? target.deliveryFee ?? 15;
    const originalFeeCurrency = target.originalCurrency ?? target.currency;
    const storeRateVal =
      target.storeRatePerMile ??
      Math.max(0.5, Math.round((originalFee / Math.max(0.5, distanceMiles)) * 100) / 100);
    const acceptedAtIso = new Date().toISOString();

    const updated = deliveryContracts.map(c =>
      c.id === contractId
        ? {
            ...c,
            status: 'accepted' as const,
            driverHandle: userId,
            driverName: userName,
            originalStoreFee: originalFee,
            originalCurrency: originalFeeCurrency,
            storeRatePerMile: storeRateVal,
            deliveryFee: driverFee,
            currency: driverCoin,
            driverRatePerMile: ratePerMile,
            distanceMiles
          }
        : c
    );
    saveDeliveryContracts(updated);
    setActiveDeliveryDispatchTab(target.businessType);
    setFocusedDeliveryId(contractId);
    setDriverDeliveryStepIdx(0);

    // Mark matching notification read
    const nextNotifs = driverDeliveryNotifications.map(n =>
      n.contractId === contractId || n.orderNumber === target.orderNumber ? { ...n, read: true } : n
    );
    setDriverDeliveryNotifications(nextNotifs);
    try {
      localStorage.setItem('final_finance_driver_delivery_notifications', JSON.stringify(nextNotifs));
    } catch {}

    // Update customer/merchant TakeoutOrder with driver rate, Before/After pricing & 5-minute cancel countdown start
    let beforeTotal = target.orderTotalBefore ?? originalFee;
    let afterTotal = driverFee;
    let orderCurr = target.orderCurrency || originalFeeCurrency;

    try {
      const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
      const updatedOrders = storedOrders.map((ord: any) => {
        if (ord.orderNumber === target.orderNumber || ord.id === target.takeoutOrderId) {
          const origFee = Number(ord.originalDeliveryFee ?? ord.deliveryFee ?? originalFee);
          const origFeeCurrency = ord.originalDeliveryFeeCurrency || ord.deliveryFeeCurrency || ord.currency;
          const origTotal = Number(ord.originalTotal ?? ord.total ?? 0);
          const itemsAndExtras = Number(ord.subtotal || 0) + Number(ord.tax || 0) + Number(ord.tip || 0);
          const hadFeeInTotal =
            origFeeCurrency === ord.currency &&
            origTotal >= itemsAndExtras + origFee - 0.05;
          const baseWithoutDelivery = hadFeeInTotal
            ? Math.max(0, Math.round((origTotal - origFee) * 100) / 100)
            : origTotal;
          const newTotal =
            driverCoin === ord.currency
              ? Math.round((baseWithoutDelivery + driverFee) * 100) / 100
              : baseWithoutDelivery;

          beforeTotal = origTotal;
          afterTotal = newTotal;
          orderCurr = ord.currency;

          if (ord.walletDeducted && !ord.walletRefunded) {
            const payerId = ord.customerWalletUserId || userId;
            if (driverCoin.toUpperCase() === ord.currency.toUpperCase()) {
              const totalDiff = Math.round((newTotal - Number(ord.total || 0)) * 100) / 100;
              if (totalDiff !== 0) {
                applyCurrencyWalletDelta({
                  userId: payerId,
                  currencySymbol: ord.currency,
                  delta: -totalDiff,
                  utilityNote: `Driver delivery rate adjustment for order #${ord.orderNumber}`
                });
                setUserWallet(getStoredUserWallets(userId));
              }
            } else {
              if (hadFeeInTotal && origFee > 0) {
                applyCurrencyWalletDelta({
                  userId: payerId,
                  currencySymbol: ord.currency,
                  delta: origFee,
                  utilityNote: `Delivery fee refund on driver currency switch (#${ord.orderNumber})`
                });
              }
              applyCurrencyWalletDelta({
                userId: payerId,
                currencySymbol: driverCoin,
                delta: -driverFee
              });
              setUserWallet(getStoredUserWallets(userId));
            }
          }

          return {
            ...ord,
            driverAccepted: true,
            driverAcceptedAt: acceptedAtIso,
            driverHandle: userId,
            driverName: userName,
            storeRatePerMile: ord.storeRatePerMile ?? storeRateVal,
            driverRatePerMile: ratePerMile,
            driverRateCurrency: driverCoin,
            originalDeliveryFee: origFee,
            originalDeliveryFeeCurrency: origFeeCurrency,
            updatedDeliveryFee: driverFee,
            deliveryFee: driverFee,
            deliveryFeeCurrency: driverCoin,
            originalTotal: origTotal,
            total: newTotal
          };
        }
        return ord;
      });
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(updatedOrders));
      window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
    } catch (e) {
      console.error(e);
    }

    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));

    const merchantKind = target.businessType === 'retail' ? 'Store' : 'Restaurant';
    dispatchGlobalNotification({
      title: `📦 Delivery Price Updated (#${target.orderNumber})`,
      description: `${merchantKind} Rate: ${storeRateVal} ${originalFeeCurrency}/mi vs Driver Rate: ${ratePerMile} ${driverCoin}/mi. Delivery Fee: ${originalFee} ${originalFeeCurrency} → ${driverFee} ${driverCoin} (Order Total: ${beforeTotal} → ${afterTotal} ${orderCurr}). Customer has 5:00 to cancel.`,
      type: 'delivery',
      targetTab: 'point_of_sale',
      amount: driverFee,
      currency: driverCoin,
      showToast: true,
      tone: 'success'
    });
  };

  const handleMarkDeliveryPickedUp = (contractId: string) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    const updated = deliveryContracts.map(c =>
      c.id === contractId ? { ...c, status: 'picked_up' as const } : c
    );
    saveDeliveryContracts(updated);
    setDriverDeliveryStepIdx(2);
    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));
    if (target) {
      dispatchGlobalNotification({
        title: `📦 Order #${target.orderNumber} Picked Up`,
        description: `Picked up from ${target.merchantName}. En route to ${target.customerName} (${target.deliveryAddress}).`,
        type: 'delivery',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'success'
      });
    }
  };

  const handleDriverCancelDelivery = (contractId: string) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    const restoredFee = target?.originalStoreFee ?? target?.deliveryFee ?? 15;
    const restoredCurrency = target?.originalCurrency ?? target?.currency ?? 'AFNL';

    const updated = deliveryContracts.map(c =>
      c.id === contractId
        ? {
            ...c,
            status: 'available' as const,
            driverHandle: undefined,
            driverName: undefined,
            deliveryFee: restoredFee,
            currency: restoredCurrency
          }
        : c
    );
    saveDeliveryContracts(updated);
    if (focusedDeliveryId === contractId) setFocusedDeliveryId(null);
    setDriverDeliveryStepIdx(0);

    if (target) {
      try {
        const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
        const revertedOrders = storedOrders.map((ord: any) => {
          if (ord.orderNumber === target.orderNumber || ord.id === target.takeoutOrderId) {
            if (ord.walletDeducted && !ord.walletRefunded) {
              const payerId = ord.customerWalletUserId || userId;
              const origTotal = Number(ord.originalTotal ?? ord.total ?? 0);
              const currTotal = Number(ord.total ?? 0);
              const currentFeeCurrency = (ord.deliveryFeeCurrency || ord.currency || restoredCurrency).toUpperCase();
              if (currentFeeCurrency === (ord.currency || '').toUpperCase()) {
                const diff = Math.round((origTotal - currTotal) * 100) / 100;
                if (diff !== 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: ord.currency,
                    delta: -diff,
                    utilityNote: `Delivery fee restored on driver cancel (#${ord.orderNumber})`
                  });
                  setUserWallet(getStoredUserWallets(userId));
                }
              } else {
                const chargedDriverFee = Number(ord.deliveryFee || 0);
                if (chargedDriverFee > 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: currentFeeCurrency,
                    delta: chargedDriverFee,
                    utilityNote: `Refund driver delivery fee (#${ord.orderNumber})`
                  });
                }
                const origFee = Number(ord.originalDeliveryFee ?? restoredFee);
                if (origFee > 0) {
                  applyCurrencyWalletDelta({
                    userId: payerId,
                    currencySymbol: ord.originalDeliveryFeeCurrency || ord.currency,
                    delta: -origFee
                  });
                }
                setUserWallet(getStoredUserWallets(userId));
              }
            }
            return {
              ...ord,
              driverAccepted: false,
              driverHandle: undefined,
              driverName: undefined,
              driverRatePerMile: undefined,
              driverRateCurrency: undefined,
              updatedDeliveryFee: undefined,
              deliveryFee: ord.originalDeliveryFee ?? restoredFee,
              deliveryFeeCurrency: ord.originalDeliveryFeeCurrency ?? restoredCurrency,
              total: ord.originalTotal ?? ord.total
            };
          }
          return ord;
        });
        localStorage.setItem('final_finance_takeout_orders', JSON.stringify(revertedOrders));
        window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
      } catch {}
    }
    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));

    dispatchGlobalNotification({
      title: '📦 Delivery Dispatch Returned',
      description: 'You have unassigned yourself and restored the original store delivery fee.',
      type: 'delivery',
      targetTab: 'ride_share',
      showToast: true,
      tone: 'alert'
    });
  };

  const openDeliveryProofModal = (contractId: string) => {
    setProofModalContractId(contractId);
    setDeliveryProofPhotos([]);
    setDeliveryProofVideos([]);
  };

  const handleCompleteDelivery = (
    contractId: string,
    proof?: { photos: string[]; videos: string[] }
  ) => {
    const target = deliveryContracts.find(c => c.id === contractId);
    if (!target || (target.status !== 'accepted' && target.status !== 'picked_up')) return;

    const attachedPhotos = proof?.photos ?? deliveryProofPhotos;
    const attachedVideos = proof?.videos ?? deliveryProofVideos;
    const deliveredAtIso = new Date().toISOString();

    const updated = deliveryContracts.map(c =>
      c.id === contractId
        ? {
            ...c,
            status: 'delivered' as const,
            proofPhotos: attachedPhotos,
            proofVideos: attachedVideos,
            deliveredAt: deliveredAtIso
          }
        : c
    );
    saveDeliveryContracts(updated);
    setDriverEarnings(prev => Math.round((prev + target.deliveryFee) * 100) / 100);

    const deliveryCreditRes = applyCurrencyWalletDelta({
      userId,
      currencySymbol: target.currency,
      delta: target.deliveryFee,
      utilityNote: `Delivery payout for order #${target.orderNumber} (${target.merchantName})`
    });
    setUserWallet(deliveryCreditRes.wallet);

    if (focusedDeliveryId === contractId) setFocusedDeliveryId(null);
    setDriverDeliveryStepIdx(0);
    setProofModalContractId(null);
    setDeliveryProofPhotos([]);
    setDeliveryProofVideos([]);

    try {
      const storedOrders = JSON.parse(localStorage.getItem('final_finance_takeout_orders') || '[]');
      const completedOrders = storedOrders.map((ord: any) => {
        if (ord.orderNumber === target.orderNumber || ord.id === target.takeoutOrderId) {
          return {
            ...ord,
            status: 'completed',
            deliveryProofPhotos: attachedPhotos,
            deliveryProofVideos: attachedVideos,
            deliveredAt: deliveredAtIso
          };
        }
        return ord;
      });
      localStorage.setItem('final_finance_takeout_orders', JSON.stringify(completedOrders));
      window.dispatchEvent(new CustomEvent('final_finance_takeout_orders_updated'));
    } catch {}
    window.dispatchEvent(new CustomEvent('final_finance_delivery_contracts_updated'));

    const deliveryLedgerEntry = createLedgerItemFromRideSharePayout({
      kind: 'delivery',
      refId: target.id,
      orderOrRideCode: target.orderNumber,
      pickup: target.merchantName || target.pickupAddress,
      dropoff: target.deliveryAddress,
      counterparty: target.customerName,
      amount: target.deliveryFee,
      currency: target.currency,
      proofSummary: `Proof attached: ${attachedPhotos.length} photo(s), ${attachedVideos.length} video(s).`
    });
    recordLedgerTransaction(userId, deliveryLedgerEntry);
    window.dispatchEvent(new CustomEvent(LEDGER_UPDATED_EVENT));

    dispatchGlobalNotification({
      title: `✅ Delivery Completed! (+${target.deliveryFee} ${target.currency})`,
      description: `Delivered order #${target.orderNumber} with ${attachedPhotos.length} proof photo(s) and ${attachedVideos.length} proof video(s). Earnings credited to your Final Wallet.`,
      type: 'delivery',
      targetTab: 'dash_ledger',
      amount: target.deliveryFee,
      currency: target.currency,
      showToast: true,
      tone: 'success'
    });
  };

  const handleSaveReview = () => {
    if (ratingModalRideId) {
      const updated = myRides.map(r =>
        r.id === ratingModalRideId ? { ...r, rating: reviewRating, comment: reviewComment, status: 'completed' as const } : r
      );
      saveMyRides(updated);
      dispatchGlobalNotification({
        title: '⭐ Driver Rating & Review Saved',
        description: `Thank you for rating driver (${reviewRating} Stars).`,
        type: 'ride_share',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'success'
      });
      setRatingModalRideId(null);
    } else if (ratingModalDeliveryId) {
      const updated = deliveryContracts.map(c =>
        c.id === ratingModalDeliveryId ? { ...c, rating: reviewRating, comment: reviewComment } : c
      );
      saveDeliveryContracts(updated);
      dispatchGlobalNotification({
        title: '⭐ Delivery Partner Rating Saved',
        description: `Merchant delivery partner rating updated successfully (${reviewRating} Stars).`,
        type: 'delivery',
        targetTab: 'ride_share',
        showToast: true,
        tone: 'success'
      });
      setRatingModalDeliveryId(null);
    }
    setReviewComment('');
    setReviewRating(5);
  };

  const filteredRides = myRides.filter(r => !blockedUsers.includes(r.driverId || '') && !blockedUsers.includes(r.riderId));
  const filteredDeliveries = deliveryContracts.filter(c => !blockedUsers.includes(c.driverHandle || ''));
  const activeRide = filteredRides.find(r => r.status !== 'cancelled' && r.status !== 'completed');
  const activeDriverRide = filteredRides.find(r => r.status === 'in_transit' && r.driverId === userId) || null;
  const acceptedDeliveries = filteredDeliveries.filter(c => c.status === 'accepted' || c.status === 'picked_up');
  const activeDeliveryContract = acceptedDeliveries.find(c => c.id === focusedDeliveryId) || acceptedDeliveries[0] || null;
  const unreadDeliveryNotifs = driverDeliveryNotifications.filter(n => !n.read);

  // Auto-advance customer ride navigation when enabled
  const customerRoute = React.useMemo(
    () => activeRide ? buildTurnByTurnRoute(activeRide.pickup, activeRide.dropoff, 'customer_ride') : null,
    [activeRide]
  );

  // Live routes for Driver Ride & Driver Delivery so GPS announces turns automatically along the road
  const activeDriverRideRoute = React.useMemo(
    () => activeDriverRide ? buildTurnByTurnRoute(activeDriverRide.pickup, activeDriverRide.dropoff, 'driver_ride') : null,
    [activeDriverRide]
  );

  const activeDriverDeliveryRoute = React.useMemo(
    () =>
      activeDeliveryContract
        ? buildTurnByTurnRoute(
            activeDeliveryContract.pickupAddress || activeDeliveryContract.merchantName,
            activeDeliveryContract.deliveryAddress,
            'driver_delivery',
            {
              merchantName: activeDeliveryContract.merchantName,
              customerName: activeDeliveryContract.customerName,
              baseDistanceMiles: activeDeliveryContract.distanceMiles
            }
          )
        : null,
    [activeDeliveryContract]
  );

  const speakTurnPrompt = React.useCallback(
    (text: string) => {
      if (!voiceGpsEnabled) return;
      try {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.rate = 1.02;
          window.speechSynthesis.speak(utterance);
        }
      } catch {}
    },
    [voiceGpsEnabled]
  );

  useEffect(() => {
    if (!isAutoNavigatingCustomer || !customerRoute) return;
    const maxIdx = customerRoute.steps.length - 1;
    if (customerNavStepIdx >= maxIdx) {
      setIsAutoNavigatingCustomer(false);
      return;
    }
    const timer = window.setInterval(() => {
      setCustomerNavStepIdx(prev => {
        if (prev >= maxIdx) {
          setIsAutoNavigatingCustomer(false);
          return prev;
        }
        return prev + 1;
      });
    }, 3500);
    return () => window.clearInterval(timer);
  }, [isAutoNavigatingCustomer, customerRoute, customerNavStepIdx]);

  // Automatic GPS turn-by-turn progression for Driver Ride Dispatches (no button presses needed)
  useEffect(() => {
    if (!activeDriverRide || !activeDriverRideRoute || !isAutoGpsDriverRide) return;
    const maxIdx = activeDriverRideRoute.steps.length - 1;
    if (driverRideStepIdx >= maxIdx) return;
    const timer = window.setInterval(() => {
      setDriverRideStepIdx(prev => {
        const next = Math.min(maxIdx, prev + 1);
        if (next !== prev && activeTab === 'driver' && driverSubTab === 'ride_dispatches') {
          const stepObj = activeDriverRideRoute.steps[next];
          if (stepObj) speakTurnPrompt(stepObj.instruction);
        }
        return next;
      });
    }, 4000);
    return () => window.clearInterval(timer);
  }, [
    activeDriverRide,
    activeDriverRideRoute,
    isAutoGpsDriverRide,
    driverRideStepIdx,
    activeTab,
    driverSubTab,
    speakTurnPrompt
  ]);

  // Automatic GPS turn-by-turn progression for Driver Delivery Dispatches (no button presses needed)
  useEffect(() => {
    if (!activeDeliveryContract || !activeDriverDeliveryRoute || !isAutoGpsDriverDelivery) return;
    const maxIdx = activeDriverDeliveryRoute.steps.length - 1;
    if (driverDeliveryStepIdx >= maxIdx) return;
    const timer = window.setInterval(() => {
      setDriverDeliveryStepIdx(prev => {
        const next = Math.min(maxIdx, prev + 1);
        if (next !== prev && activeTab === 'driver' && driverSubTab === 'delivery_dispatches') {
          const stepObj = activeDriverDeliveryRoute.steps[next];
          if (stepObj) speakTurnPrompt(stepObj.instruction);
        }
        return next;
      });
    }, 4000);
    return () => window.clearInterval(timer);
  }, [
    activeDeliveryContract,
    activeDriverDeliveryRoute,
    isAutoGpsDriverDelivery,
    driverDeliveryStepIdx,
    activeTab,
    driverSubTab,
    speakTurnPrompt
  ]);

  const getManeuverIcon = (maneuver: TurnByTurnStep['maneuver']) => {
    switch (maneuver) {
      case 'left':
        return <CornerUpLeft className="w-3.5 h-3.5 shrink-0" />;
      case 'right':
        return <CornerUpRight className="w-3.5 h-3.5 shrink-0" />;
      case 'pickup':
        return <MapPin className="w-3.5 h-3.5 shrink-0" />;
      case 'arrive':
        return <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />;
      default:
        return <ArrowUp className="w-3.5 h-3.5 shrink-0" />;
    }
  };

  // Compute exact (x%, y%) along quadratic Bezier M 80 190 Q 390 40 700 90 inside viewBox="0 0 780 260"
  const getBezierMarkerPos = (stepIdx: number, totalSteps: number) => {
    const t = totalSteps <= 1 ? 0.5 : Math.min(1, Math.max(0, stepIdx / (totalSteps - 1)));
    const p0 = { x: 80, y: 190 };
    const p1 = { x: 390, y: 40 };
    const p2 = { x: 700, y: 90 };
    const x = (1 - t) * (1 - t) * p0.x + 2 * (1 - t) * t * p1.x + t * t * p2.x;
    const y = (1 - t) * (1 - t) * p0.y + 2 * (1 - t) * t * p1.y + t * t * p2.y;
    return {
      leftPct: `${(x / 780) * 100}%`,
      topPct: `${(y / 260) * 100}%`
    };
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6 text-center space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col items-center justify-center text-center gap-2 pb-4 border-b border-neutral-200 mx-auto">
        <h1 className="font-serif-lux text-2xl sm:text-3xl font-semibold text-black tracking-tight flex items-center justify-center gap-2.5">
          <Car className="w-6 h-6 text-neutral-800" />
          <span>Ride-Share</span>
        </h1>

        <div className="grid grid-cols-2 gap-1 sm:gap-1.5 p-1 sm:p-1.5 bg-neutral-200/80 rounded-2xl mx-auto mt-2 max-w-md w-full">
          <button
            type="button"
            onClick={() => setActiveTab('book')}
            className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'book' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span>Book Rides</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('driver')}
            className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'driver' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Navigation className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Driver</span>
            {unreadDeliveryNotifs.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-mono font-bold">
                {unreadDeliveryNotifs.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* ==================================================== */}
      {/* TAB 1: BOOK RIDES (CUSTOMER) - 3 SUB-TABS           */}
      {/* ==================================================== */}
      {activeTab === 'book' && (
        <div className="space-y-6 max-w-5xl mx-auto">
          {/* Customer Sub-Tabs: Request a Ride | Current Ride | Ride History */}
          <div className="inline-flex flex-wrap sm:flex-nowrap items-center justify-center gap-1.5 p-1.5 bg-neutral-200/70 rounded-2xl mx-auto max-w-full">
            <button
              type="button"
              onClick={() => setBookSubTab('request')}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                bookSubTab === 'request' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>Request a Ride</span>
            </button>
            <button
              type="button"
              onClick={() => setBookSubTab('current')}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                bookSubTab === 'current' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Map className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Current Ride</span>
            </button>
            <button
              type="button"
              onClick={() => setBookSubTab('history')}
              className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                bookSubTab === 'history' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <History className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>Ride History</span>
            </button>
          </div>

          {/* Sub-Tab 1: Request a Ride */}
          {bookSubTab === 'request' && (
            <div className="max-w-xl mx-auto text-left">
              <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-center">
                <h2 className="font-serif-lux text-xl sm:text-2xl font-semibold text-black tracking-tight flex items-center justify-center gap-2 text-center">
                  <Compass className="w-5 h-5 text-indigo-600" />
                  <span>Request a Sovereign Ride</span>
                </h2>

                <form onSubmit={handleBookRide} className="space-y-5 text-center">
                  {/* Pickup Location with Current Standing Location + Probable Address Suggestions */}
                  <div className="space-y-2" ref={pickupBoxRef}>
                    <div className="flex flex-col items-center justify-center gap-1 text-center">
                      <label className="text-[10px] font-bold uppercase font-mono text-neutral-500">Pickup Location</label>
                      <button
                        type="button"
                        onClick={() => {
                          setPickupLocation('Zurich Freeport Vault 4B, 8048 Zürich');
                          setPickupSuggestionsOpen(false);
                        }}
                        className="text-[11px] font-bold text-indigo-600 hover:underline cursor-pointer inline-flex items-center justify-center gap-1"
                      >
                        <MapPin className="w-3 h-3" />
                        <span>Use Current Standing Location</span>
                      </button>
                    </div>
                    <div className="relative">
                      <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-600 pointer-events-none" />
                      <input
                        type="text"
                        value={pickupLocation}
                        onFocus={() => {
                          setPickupSuggestionsOpen(true);
                          setPickupHighlightIdx(-1);
                        }}
                        onChange={(e) => {
                          setPickupLocation(e.target.value);
                          setPickupSuggestionsOpen(true);
                          setPickupHighlightIdx(-1);
                        }}
                        onKeyDown={(e) => {
                          if (!pickupSuggestionsOpen || pickupSuggestions.length === 0) return;
                          if (e.key === 'ArrowDown') {
                            e.preventDefault();
                            setPickupHighlightIdx(prev => (prev + 1) % pickupSuggestions.length);
                          } else if (e.key === 'ArrowUp') {
                            e.preventDefault();
                            setPickupHighlightIdx(prev => (prev <= 0 ? pickupSuggestions.length - 1 : prev - 1));
                          } else if (e.key === 'Enter' && pickupHighlightIdx >= 0) {
                            e.preventDefault();
                            setPickupLocation(pickupSuggestions[pickupHighlightIdx].address);
                            setPickupSuggestionsOpen(false);
                          } else if (e.key === 'Escape') {
                            setPickupSuggestionsOpen(false);
                          }
                        }}
                        placeholder="Start typing street, hub, or landmark for suggestions..."
                        required
                        autoComplete="off"
                        className="w-full px-10 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 text-center outline-none focus:border-indigo-500"
                      />
                      {pickupLocation && (
                        <button
                          type="button"
                          onClick={() => {
                            setPickupLocation('');
                            setPickupSuggestionsOpen(true);
                          }}
                          aria-label="Clear pickup address"
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {pickupSuggestionsOpen && pickupSuggestions.length > 0 && (
                        <div className="absolute z-30 left-0 right-0 mt-1.5 bg-white border border-neutral-200 rounded-2xl shadow-xl overflow-hidden max-h-60 overflow-y-auto text-left">
                          <div className="px-3 py-1.5 bg-neutral-50 border-b border-neutral-100 text-[10px] font-mono font-bold text-neutral-500 uppercase flex items-center justify-between">
                            <span>Probable Pickup Addresses</span>
                            <span>{pickupSuggestions.length} matches</span>
                          </div>
                          {pickupSuggestions.map((sugg: AddressSuggestion, idx: number) => (
                            <button
                              key={sugg.id}
                              type="button"
                              onMouseDown={(e) => {
                                e.preventDefault();
                                setPickupLocation(sugg.address);
                                setPickupSuggestionsOpen(false);
                              }}
                              className={`w-full text-left px-3.5 py-2.5 flex items-start gap-2.5 border-b border-neutral-100 last:border-b-0 transition-colors cursor-pointer ${
                                pickupHighlightIdx === idx ? 'bg-indigo-50' : 'hover:bg-neutral-50'
                              }`}
                            >
                              <MapPin className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                              <div className="min-w-0 flex-1">
                                <p className="text-xs font-bold text-neutral-900 truncate">{sugg.address}</p>
                                <p className="text-[10px] text-neutral-500 truncate">{sugg.label} · {sugg.district}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Dropoff Destination Address with Probable Address Suggestions */}
                  <div className="space-y-2" ref={dropoffBoxRef}>
                    <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block text-center">
                      Dropoff Destination Address (Valid Address Required)
                    </label>
                    <div className="relative">
                      <Navigation className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-600 pointer-events-none" />
                      <input
                        type="text"
                        value={dropoffLocation}
                        onFocus={() => {
                          setDropoffSuggestionsOpen(true);
                          setDropoffHighlightIdx(-1);
                        }}
                        onChange={(e) => {
                          setDropoffLocation(e.target.value);
                          setDropoffSuggestionsOpen(true);
                          setDropoffHighlightIdx(-1);
                        }}
                        onKeyDown={(e) => {
                          if (!dropoffSuggestionsOpen || dropoffSuggestions.length === 0) return;
                          if (e.key === 'ArrowDown') {
                            e.preventDefault();
                            setDropoffHighlightIdx(prev => (prev + 1) % dropoffSuggestions.length);
                          } else if (e.key === 'ArrowUp') {
                            e.preventDefault();
                            setDropoffHighlightIdx(prev => (prev <= 0 ? dropoffSuggestions.length - 1 : prev - 1));
                          } else if (e.key === 'Enter' && dropoffHighlightIdx >= 0) {
                            e.preventDefault();
                            setDropoffLocation(dropoffSuggestions[dropoffHighlightIdx].address);
                            setDropoffSuggestionsOpen(false);
                          } else if (e.key === 'Escape') {
                            setDropoffSuggestionsOpen(false);
                          }
                        }}
                        placeholder="Start typing destination street or landmark for suggestions..."
                        required
                        autoComplete="off"
                        className="w-full px-10 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 text-center outline-none focus:border-indigo-500"
                      />
                      {dropoffLocation && (
                        <button
                          type="button"
                          onClick={() => {
                            setDropoffLocation('');
                            setDropoffSuggestionsOpen(true);
                          }}
                          aria-label="Clear dropoff address"
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {dropoffSuggestionsOpen && dropoffSuggestions.length > 0 && (
                        <div className="absolute z-30 left-0 right-0 mt-1.5 bg-white border border-neutral-200 rounded-2xl shadow-xl overflow-hidden max-h-60 overflow-y-auto text-left">
                          <div className="px-3 py-1.5 bg-neutral-50 border-b border-neutral-100 text-[10px] font-mono font-bold text-neutral-500 uppercase flex items-center justify-between">
                            <span>Probable Dropoff Addresses</span>
                            <span>{dropoffSuggestions.length} matches</span>
                          </div>
                          {dropoffSuggestions.map((sugg: AddressSuggestion, idx: number) => (
                            <button
                              key={sugg.id}
                              type="button"
                              onMouseDown={(e) => {
                                e.preventDefault();
                                setDropoffLocation(sugg.address);
                                setDropoffSuggestionsOpen(false);
                              }}
                              className={`w-full text-left px-3.5 py-2.5 flex items-start gap-2.5 border-b border-neutral-100 last:border-b-0 transition-colors cursor-pointer ${
                                dropoffHighlightIdx === idx ? 'bg-emerald-50' : 'hover:bg-neutral-50'
                              }`}
                            >
                              <Navigation className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <div className="min-w-0 flex-1">
                                <p className="text-xs font-bold text-neutral-900 truncate">{sugg.address}</p>
                                <p className="text-[10px] text-neutral-500 truncate">{sugg.label} · {sugg.district}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Live Estimated Route Preview */}
                  {pickupLocation.trim() && dropoffLocation.trim() && (
                    <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-wrap items-center justify-center gap-3 text-xs font-mono">
                      <div className="text-neutral-700">
                        <span className="font-bold text-neutral-900">Route Estimate:</span>{' '}
                        {previewRoute.distanceMiles} miles · ~{previewRoute.estimatedMinutes} mins
                      </div>
                      <span className="text-indigo-700 font-bold">
                        {previewRoute.steps.length} Turn Steps
                      </span>
                    </div>
                  )}

                  {/* Pay With Any Possessed Final Currency */}
                  <div className="space-y-2.5 pt-2 border-t border-neutral-100 text-center">
                    <div className="flex flex-col items-center justify-center gap-0.5 text-center">
                      <label className="text-[10px] font-bold uppercase font-mono text-neutral-500">
                        Pay With Any Possessed Final Currency ({possessedFinalCoins.length} owned)
                      </label>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        Select any Final coin you hold with enough balance for this ride
                      </span>
                    </div>

                    {possessedFinalCoins.length === 0 ? (
                      <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 space-y-1 text-center">
                        <p className="text-xs font-extrabold">There&apos;s not enough Final money</p>
                        <p className="text-[11px]">
                          You do not possess any Final coins with a positive balance to pay for this ride.
                        </p>
                      </div>
                    ) : (
                      <>
                        {possessedFinalCoins.length > 2 && (
                          <div className="relative">
                            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
                            <input
                              type="text"
                              value={customerCurrencySearch}
                              onChange={(e) => setCustomerCurrencySearch(e.target.value)}
                              placeholder="Filter your possessed Final coins..."
                              className="w-full px-9 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 text-center outline-none focus:border-indigo-500 font-mono"
                            />
                          </div>
                        )}

                        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                          {possessedFinalCoins
                            .filter(c =>
                              c.symbol.toLowerCase().includes(customerCurrencySearch.toLowerCase()) ||
                              c.name.toLowerCase().includes(customerCurrencySearch.toLowerCase())
                            )
                            .map(coin => {
                              const curr = coin.symbol;
                              const isActive = selectedCurrency.toUpperCase() === curr.toUpperCase();
                              const hasEnough = Number(coin.balance || 0) >= currentEstimatedFare;
                              return (
                                <button
                                  key={curr}
                                  type="button"
                                  onClick={() => {
                                    setWalletErrorMsg(null);
                                    setSelectedCurrency(curr);
                                    try {
                                      localStorage.setItem(`final_finance_customer_selected_currency_${userId}`, curr);
                                    } catch {}
                                  }}
                                  className={`min-w-[118px] px-3 py-2 rounded-xl text-[11px] font-mono font-bold border transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 tabular-nums ${
                                    isActive
                                      ? (hasEnough
                                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                                          : 'bg-rose-600 text-white border-rose-600 shadow-xs')
                                      : (hasEnough
                                          ? 'bg-neutral-50 text-neutral-800 border-neutral-200 hover:bg-indigo-50 hover:border-indigo-300'
                                          : 'bg-neutral-50 text-neutral-400 border-neutral-200 hover:bg-rose-50')
                                  }`}
                                >
                                  <span>{curr}</span>
                                  <span className="text-[10px] font-mono opacity-85">
                                    Bal: {Number(coin.balance).toLocaleString()}
                                  </span>
                                  <span className="text-[9px] font-sans font-normal opacity-90">
                                    {isActive
                                      ? (hasEnough ? 'Active Pay ✓' : 'Low Balance')
                                      : (hasEnough ? 'Click to Pay' : 'Insufficient')}
                                  </span>
                                </button>
                              );
                            })}
                        </div>
                        <p className="text-[10px] text-neutral-500 text-center font-mono pt-0.5 tabular-nums">
                          Paying with: <strong className="text-indigo-700">{selectedCurrency}</strong>{' '}
                          (Available: {selectedCurrencyBalance.toLocaleString()} {selectedCurrency})
                        </p>
                      </>
                    )}
                  </div>

                  {/* Vehicle Type & Vehicle Class Selection — Car, Auto Rickshaw, Motor Bike */}
                  <div className="space-y-3 pt-2 border-t border-neutral-100 text-center">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block text-center">
                        Vehicle Type ({availableVehiclePool.length} {availableVehiclePool.length === 1 ? 'vehicle' : 'vehicles'} available)
                      </label>
                      {availableVehicleTypes.length > 0 && (
                        <div className="flex flex-wrap items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedVehicleType('All')}
                            className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer whitespace-nowrap ${
                              selectedVehicleType === 'All'
                                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                                : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                            }`}
                          >
                            All Types
                          </button>
                          {availableVehicleTypes.map(vType => (
                            <button
                              key={vType}
                              type="button"
                              onClick={() => setSelectedVehicleType(vType)}
                              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition-all cursor-pointer whitespace-nowrap ${
                                selectedVehicleType === vType
                                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                                  : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                              }`}
                            >
                              {vType}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 block text-center">
                        Available Vehicles &amp; Class (Tap Any Vehicle to Inspect Info, Photos &amp; Videos)
                      </label>
                      {filteredAvailableVehicles.length === 0 ? (
                        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold text-center">
                          No vehicles are currently available for this selection.
                        </div>
                      ) : (
                        <div className="flex flex-col gap-2.5 w-full">
                          {filteredAvailableVehicles.map(v => {
                            const estFare =
                              Math.round(Math.max(8, previewRoute.distanceMiles * v.mult * (ratePerMile / 6)) * 10) / 10;
                            const isSelected = selectedVehicle?.id === v.id;
                            const isExpanded = expandedVehicleId === v.id;
                            const handleVehicleCardToggle = () => {
                              setSelectedVehicleId(v.id);
                              setSelectedClass(v.vehicleClass);
                              setExpandedVehicleId(prev => (prev === v.id ? null : v.id));
                            };

                            return (
                              <div
                                key={v.id}
                                role="button"
                                tabIndex={0}
                                aria-expanded={isExpanded}
                                onClick={handleVehicleCardToggle}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    handleVehicleCardToggle();
                                  }
                                }}
                                className={`w-full p-3.5 rounded-2xl border text-center transition-all cursor-pointer select-none ${
                                  isSelected
                                    ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 shadow-xs'
                                    : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                                }`}
                              >
                                <div className="flex flex-col items-center justify-center gap-1.5">
                                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                                    <span className="inline-block px-2 py-0.5 rounded-md bg-white border border-neutral-200 text-[9px] font-mono font-bold uppercase text-indigo-700">
                                      {v.vehicleType} · {v.vehicleClass}
                                    </span>
                                    <span className="inline-block px-2 py-0.5 rounded-md bg-amber-50 border border-amber-200 text-[9px] font-mono font-bold text-amber-700">
                                      ★ {v.rating}
                                    </span>
                                    {isSelected && (
                                      <span className="inline-block px-2 py-0.5 rounded-md bg-indigo-600 text-white text-[9px] font-mono font-bold uppercase">
                                        Selected
                                      </span>
                                    )}
                                  </div>

                                  <p className="text-xs sm:text-sm font-bold text-neutral-900">
                                    {v.carModel} ({v.carYear})
                                  </p>

                                  <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] font-mono tabular-nums">
                                    <span className="font-extrabold text-indigo-700">{estFare} {selectedCurrency}</span>
                                    <span className="text-neutral-500">· {v.etaMins} min ETA</span>
                                    <span className="text-neutral-500">· {v.media.length} {v.media.length === 1 ? 'Photo' : 'Photos'}</span>
                                    <span className="text-neutral-500">· {v.videoMedia.length} {v.videoMedia.length === 1 ? 'Video' : 'Videos'}</span>
                                  </div>

                                  <div className="inline-flex items-center justify-center gap-1 text-[10px] font-bold text-indigo-700 pt-0.5">
                                    <span>{isExpanded ? 'Tap to collapse vehicle details' : 'Tap to inspect vehicle info, photos & videos'}</span>
                                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                  </div>
                                </div>

                                {isExpanded && (
                                  <div className="mt-3 pt-3 border-t border-indigo-200/80 space-y-3 text-center">
                                    {/* Vehicle Details Grid (excluding Driver's License & Insurance per privacy) */}
                                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Make &amp; Model</span>
                                        <span className="font-bold text-neutral-900">{v.carModel}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Year &amp; Color</span>
                                        <span className="font-bold text-neutral-900">{v.carYear} · {v.color}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">License Plate</span>
                                        <span className="font-bold text-neutral-900 font-mono">{v.plate}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Driver</span>
                                        <span className="font-bold text-neutral-900">{v.driverName} (★ {v.rating})</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Capacity</span>
                                        <span className="font-semibold text-neutral-800">{v.seats}</span>
                                      </div>
                                      <div className="p-2 rounded-xl bg-white border border-neutral-200/90">
                                        <span className="text-[9px] uppercase font-mono text-neutral-400 block">Rate &amp; Arrival</span>
                                        <span className="font-bold text-emerald-700 font-mono tabular-nums">{v.ratePerMile} {selectedCurrency}/mi · {v.etaMins} min</span>
                                      </div>
                                    </div>

                                    <div className="p-2.5 rounded-xl bg-white border border-neutral-200/90 text-[11px] text-neutral-700">
                                      <span className="text-[9px] uppercase font-mono text-neutral-400 block mb-0.5">Vehicle Features</span>
                                      <span className="font-medium text-neutral-900">{v.specs}</span>
                                    </div>

                                    {/* Vehicle Photos & Videos Gallery */}
                                    {(v.media.length > 0 || v.videoMedia.length > 0) && (
                                      <div className="space-y-2">
                                        <span className="text-[10px] font-bold uppercase font-mono text-indigo-900 block">
                                          Vehicle Photos &amp; Video Walkaround
                                        </span>
                                        <div className="flex flex-wrap items-center justify-center gap-2.5">
                                          {v.media.map((photoUrl, pIdx) => (
                                            <img
                                              key={`veh-photo-${v.id}-${pIdx}`}
                                              src={photoUrl}
                                              alt={`${v.carModel} Photo ${pIdx + 1}`}
                                              referrerPolicy="no-referrer"
                                              onClick={(e) => e.stopPropagation()}
                                              className="w-40 h-24 object-cover rounded-xl border border-indigo-200 bg-neutral-900 shadow-2xs"
                                            />
                                          ))}
                                          {v.videoMedia.map((vidUrl, vIdx) => (
                                            <video
                                              key={`veh-vid-${v.id}-${vIdx}`}
                                              src={vidUrl}
                                              controls
                                              playsInline
                                              onClick={(e) => e.stopPropagation()}
                                              className="w-48 h-28 rounded-xl border border-indigo-200 bg-black shadow-2xs"
                                            />
                                          ))}
                                        </div>
                                      </div>
                                    )}

                                    <div className="pt-1 flex items-center justify-center">
                                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-white border border-indigo-200 text-[10px] font-bold text-indigo-700">
                                        <span>Tap anywhere on card to collapse</span>
                                        <ChevronUp className="w-3 h-3" />
                                      </span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>

                  {(!hasEnoughSelectedCurrency || walletErrorMsg) && possessedFinalCoins.length > 0 && (
                    <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold text-center">
                      {walletErrorMsg
                        ? walletErrorMsg
                        : !hasEnoughAnyFinalCurrency
                          ? `There's not enough Final money. Total held across Final coins: ${totalFinalMoneyBalance.toLocaleString()}, Required: ${currentEstimatedFare} ${selectedCurrency}.`
                          : `There's not enough Final money in ${selectedCurrency} (Available: ${selectedCurrencyBalance.toLocaleString()} ${selectedCurrency}, Required: ${currentEstimatedFare} ${selectedCurrency}). Select another owned Final coin above.`}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isBookingRide || availableVehicleClasses.length === 0 || !selectedVehicle}
                    className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md cursor-pointer disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                  >
                    {isBookingRide
                      ? 'Dispatching Nearest Driver...'
                      : !hasEnoughSelectedCurrency
                        ? "Not Enough Final Money"
                        : `Book ${(selectedVehicle?.vehicleClass || selectedClass)} (${selectedVehicle?.vehicleType || CLASS_META[selectedClass].vehicleType}) Ride (${currentEstimatedFare} ${selectedCurrency})`}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Sub-Tab 2: Current Ride */}
          {bookSubTab === 'current' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto text-left">
              {!activeRide || !customerRoute ? (
                <div className="p-12 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-3">
                  <Car className="w-10 h-10 text-neutral-400 mx-auto" />
                  <p className="text-base font-bold text-neutral-900">No Active Ride</p>
                  <p className="text-xs text-neutral-500">Book a ride from the "Request a Ride" tab to view live GPS tracking and turn-by-turn directions here.</p>
                </div>
              ) : (() => {
                const steps = customerRoute.steps;
                const clampedIdx = Math.min(customerNavStepIdx, steps.length - 1);
                const currentStep = steps[clampedIdx];
                const markerPos = getBezierMarkerPos(clampedIdx, steps.length);
                const elapsedMs = Date.now() - new Date(activeRide.createdAt).getTime();
                const freeSecsLeft = Math.max(0, Math.ceil((120000 - elapsedMs) / 1000));

                return (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row items-center justify-between pb-2 border-b border-neutral-200 gap-2 text-center sm:text-left">
                    <div>
                      <h3 className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                        <Map className="w-4 h-4 text-emerald-600" />
                        Live End-to-End GPS Map &amp; Turn-by-Turn Directions
                      </h3>
                      <p className="text-xs text-neutral-500 font-mono">
                        Estimated: {activeRide.estimatedTime || `~${customerRoute.estimatedMinutes} mins`} ({activeRide.distance || `${customerRoute.distanceMiles} miles`})
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold font-mono">
                        {activeRide.fare} {activeRide.currency}
                      </span>
                      <button
                        type="button"
                        onClick={() => initiateCancelRide(activeRide.id)}
                        className="px-3 py-1 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                      >
                        {freeSecsLeft > 0 ? `Cancel Free (${freeSecsLeft}s)` : 'Cancel Ride'}
                      </button>
                    </div>
                  </div>

                  {/* Interactive Map Canvas */}
                  <div className="relative w-full h-72 rounded-2xl bg-neutral-900 overflow-hidden border border-neutral-800">
                    <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#4f46e5_1px,transparent_1px)] [background-size:24px_24px]"></div>
                    <svg viewBox="0 0 780 260" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                      <path d="M 80 190 Q 390 40, 700 90" fill="none" stroke="#6366f1" strokeWidth="4" strokeDasharray="8 6" />
                    </svg>
                    <div className="absolute left-[10%] bottom-[22%] -translate-x-1/2 flex flex-col items-center max-w-[38%]">
                      <div className="px-2.5 py-0.5 rounded-md bg-indigo-600 text-white text-[10px] font-bold font-mono shadow-md truncate max-w-full">
                        Pickup: {activeRide.pickup}
                      </div>
                      <div className="w-3.5 h-3.5 rounded-full bg-indigo-500 border-2 border-white mt-1 shadow-md"></div>
                    </div>
                    <div className="absolute right-[10%] top-[28%] translate-x-1/2 flex flex-col items-center max-w-[38%]">
                      <div className="px-2.5 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-bold font-mono shadow-md truncate max-w-full">
                        Dropoff: {activeRide.dropoff}
                      </div>
                      <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white mt-1 shadow-md"></div>
                    </div>
                    <div
                      className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700 flex flex-col items-center z-10"
                      style={{ left: markerPos.leftPct, top: markerPos.topPct }}
                    >
                      <div className="bg-white text-neutral-900 px-2.5 py-1 rounded-lg text-[10px] font-bold font-mono shadow-xl flex items-center gap-1 border border-neutral-200 whitespace-nowrap">
                        <Car className="w-3.5 h-3.5 text-indigo-600" />
                        <span>{clampedIdx === steps.length - 1 ? 'Arrived at Destination' : `${activeRide.driverName || 'Driver'} En Route`}</span>
                      </div>
                      <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg mt-1 border-2 border-white">
                        <Car className="w-4 h-4" />
                      </div>
                    </div>

                    {/* Active Instruction Banner */}
                    <div className="absolute bottom-3 left-3 right-3 bg-black/75 backdrop-blur-md px-3.5 py-2.5 rounded-xl border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-white">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-indigo-400">{getManeuverIcon(currentStep.maneuver)}</span>
                        <span className="font-mono font-bold truncate">{currentStep.instruction}</span>
                      </div>
                      <span className="text-emerald-400 font-mono font-bold shrink-0">
                        Step {clampedIdx + 1}/{steps.length} · {currentStep.distanceLabel}
                      </span>
                    </div>
                  </div>

                  {/* Route details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-neutral-50 p-4 rounded-2xl border border-neutral-200 text-xs">
                    <div>
                      <span className="text-[10px] uppercase font-mono text-neutral-400 block font-bold">Pickup Location</span>
                      <p className="font-bold text-neutral-900">{activeRide.pickup}</p>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-mono text-neutral-400 block font-bold">Dropoff Destination</span>
                      <p className="font-bold text-neutral-900">{activeRide.dropoff}</p>
                    </div>
                  </div>

                  {/* Driver info & Car Media */}
                  <div className="p-5 rounded-2xl bg-indigo-50 border border-indigo-200 space-y-4 text-left">
                    <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4">
                      <div className="flex items-center gap-3.5">
                        <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-sm">
                          HK
                        </div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            {onViewUserProfile ? (
                              <button
                                type="button"
                                onClick={() => {
                                  try {
                                    window.location.hash = `rideshare?tab=${activeTab}&subtab=${bookSubTab}`;
                                  } catch {}
                                  onViewUserProfile(activeRide.driverId || 'driver-hans');
                                }}
                                className="text-sm font-bold text-indigo-700 hover:underline flex items-center gap-1 cursor-pointer"
                              >
                                <span>{activeRide.driverName || 'Hansruedi Keller'}</span>
                                <ExternalLink className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <span className="text-sm font-bold text-neutral-900">{activeRide.driverName || 'Hansruedi Keller'}</span>
                            )}
                            <span className="text-xs text-amber-600 font-bold px-2 py-0.5 rounded bg-amber-100/80">★ {activeRide.driverRating || 4.96}</span>
                          </div>
                          <p className="text-xs text-neutral-800 font-semibold mt-1">
                            {activeRide.driverCar || 'Tesla Model Y Sovereign'} ({activeRide.driverCarYear || '2025'}) ·{' '}
                            <span className="text-indigo-700">{activeRide.vehicleType || CLASS_META[activeRide.vehicleClass]?.vehicleType || 'Car'} ({activeRide.vehicleClass})</span>
                          </p>
                          <p className="text-[11px] text-neutral-600 font-mono">
                            License Plate: {activeRide.driverPlate || 'ZH-884-992'}
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setRatingModalRideId(activeRide.id)}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shrink-0 text-center cursor-pointer"
                      >
                        Complete &amp; Rate Ride
                      </button>
                    </div>

                    {/* Car Photos & Videos View for Customer (excluding DL & Insurance per privacy) */}
                    {((activeRide.driverPhotos && activeRide.driverPhotos.length > 0) ||
                      (activeRide.driverVideos && activeRide.driverVideos.length > 0)) && (
                      <div className="space-y-2 pt-3 border-t border-indigo-100">
                        <h5 className="text-[11px] font-bold uppercase font-mono text-indigo-900">Verified Vehicle Photos &amp; Video Media</h5>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {(activeRide.driverPhotos || []).map((photoUrl, pIdx) => (
                            <div key={`act-p-${pIdx}`} className="aspect-video rounded-xl bg-neutral-900 overflow-hidden relative border border-indigo-200">
                              <img
                                src={photoUrl}
                                alt={`Car Photo ${pIdx + 1}`}
                                referrerPolicy="no-referrer"
                                onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                          {(activeRide.driverVideos || []).map((vidUrl, vIdx) => (
                            <div key={`act-v-${vIdx}`} className="aspect-video rounded-xl bg-black overflow-hidden relative border border-indigo-200">
                              <video
                                src={vidUrl}
                                controls
                                playsInline
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Turn-by-Turn Map Directions (Interactive) */}
                  <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h4 className="text-xs font-bold text-neutral-800 uppercase font-mono flex items-center gap-1.5">
                        <ListOrdered className="w-4 h-4 text-indigo-600" />
                        Turn-by-Turn Map Directions
                      </h4>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setIsAutoNavigatingCustomer(prev => !prev)}
                          className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-800 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                        >
                          {isAutoNavigatingCustomer ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                          <span>{isAutoNavigatingCustomer ? 'Pause Live GPS' : 'Simulate Route'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setCustomerNavStepIdx(prev => Math.max(0, prev - 1))}
                          disabled={clampedIdx === 0}
                          className="p-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 disabled:opacity-40 cursor-pointer"
                          aria-label="Previous direction step"
                        >
                          <ChevronLeft className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setCustomerNavStepIdx(prev => Math.min(steps.length - 1, prev + 1))}
                          disabled={clampedIdx >= steps.length - 1}
                          className="p-1 rounded-lg bg-indigo-600 text-white disabled:opacity-40 cursor-pointer"
                          aria-label="Next direction step"
                        >
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <ol className="space-y-2 text-xs font-mono">
                      {steps.map((step, idx) => {
                        const isDone = idx < clampedIdx;
                        const isActive = idx === clampedIdx;
                        return (
                          <li
                            key={step.id}
                            onClick={() => setCustomerNavStepIdx(idx)}
                            className={`p-2.5 rounded-xl border flex items-start justify-between gap-3 cursor-pointer transition-colors ${
                              isActive
                                ? 'bg-indigo-50 border-indigo-300 text-indigo-950'
                                : isDone
                                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                                  : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex items-start gap-2.5 min-w-0">
                              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 ${
                                isActive ? 'bg-indigo-600 text-white' : isDone ? 'bg-emerald-600 text-white' : 'bg-neutral-200 text-neutral-700'
                              }`}>
                                {isDone ? '✓' : idx + 1}
                              </span>
                              <div className="min-w-0">
                                <p className="font-bold flex items-center gap-1.5">
                                  {getManeuverIcon(step.maneuver)}
                                  <span>{step.instruction}</span>
                                </p>
                                <p className="text-[11px] opacity-80 font-sans mt-0.5">{step.detail}</p>
                              </div>
                            </div>
                            <span className="text-[11px] font-bold shrink-0 tabular-nums">{step.distanceLabel}</span>
                          </li>
                        );
                      })}
                    </ol>
                  </div>
                </div>
                );
              })()}
            </div>
          )}

          {/* Sub-Tab 3: Ride History */}
          {bookSubTab === 'history' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-4 max-w-4xl mx-auto text-left">
              <h3 className="text-sm font-bold text-neutral-900 text-center flex items-center justify-center gap-2">
                <History className="w-4 h-4 text-emerald-600" />
                Complete Ride History &amp; Receipts ({myRides.length})
              </h3>

              {myRides.length === 0 ? (
                <div className="p-8 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                  <p className="text-xs font-bold text-neutral-800">No past ride records found.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {myRides.map(ride => (
                    <div key={ride.id} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="space-y-1 text-center sm:text-left">
                        <div className="flex items-center gap-2 justify-center sm:justify-start">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                            ride.status === 'cancelled' ? 'bg-rose-100 text-rose-900' : 'bg-indigo-100 text-indigo-900'
                          }`}>
                            {ride.status.toUpperCase()}
                          </span>
                          <span className="text-xs font-bold text-neutral-900">
                            Ride #{ride.id.slice(-6)} • {ride.vehicleType || CLASS_META[ride.vehicleClass]?.vehicleType || 'Car'} ({ride.vehicleClass})
                          </span>
                        </div>
                        <p className="text-xs text-neutral-700">From {ride.pickup} → {ride.dropoff}</p>
                        <p className="text-[11px] text-neutral-500 font-mono">Date: {new Date(ride.createdAt).toLocaleString()}</p>
                        {ride.rating && (
                          <p className="text-[11px] text-amber-600 font-bold">★ {ride.rating}/5 - "{ride.comment}"</p>
                        )}
                      </div>
                      <div className="text-center sm:text-right font-mono flex flex-col items-center sm:items-end gap-1">
                        <p className="text-sm font-extrabold text-emerald-700">{ride.fare} {ride.currency}</p>
                        <button
                          type="button"
                          onClick={() => setRatingModalRideId(ride.id)}
                          className="px-2.5 py-1 rounded-lg bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-[10px] font-bold flex items-center gap-1"
                        >
                          <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                          {ride.rating ? 'Update Rating & Comment' : 'Rate Driver'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* TAB 2: DRIVER (WITH 3 NESTED SUB-TABS)               */}
      {/* ==================================================== */}
      {activeTab === 'driver' && (
        <div className="space-y-6 max-w-5xl mx-auto">
          {/* Driver 3 Nested Sub-Tabs (intrinsic widths so badge & labels always fit cleanly) */}
          <div className="inline-flex flex-wrap sm:flex-nowrap items-center justify-center gap-1.5 p-1.5 bg-neutral-200/80 rounded-2xl mx-auto max-w-full">
            <button
              type="button"
              onClick={() => setDriverSubTab('ride_dispatches')}
              className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                driverSubTab === 'ride_dispatches' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Navigation className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>Ride Dispatches</span>
            </button>

            <button
              type="button"
              onClick={() => setDriverSubTab('delivery_dispatches')}
              className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                driverSubTab === 'delivery_dispatches' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Store className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Delivery Dispatches</span>
              {unreadDeliveryNotifs.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-mono font-bold tabular-nums leading-none">
                  {unreadDeliveryNotifs.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setDriverSubTab('profile')}
              className={`py-2 px-3.5 sm:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                driverSubTab === 'profile' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Driver Signup</span>
            </button>
          </div>

          {/* ================================================ */}
          {/* DRIVER SUB-TAB 1: RIDE DISPATCHES (2 SUB-TABS)    */}
          {/* ================================================ */}
          {driverSubTab === 'ride_dispatches' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto text-center">
              <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-xl mx-auto max-w-full">
                <button
                  type="button"
                  onClick={() => setDriverRideSubTab('active_dispatches')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverRideSubTab === 'active_dispatches' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <Map className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span>Live Map &amp; Dispatches</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDriverRideSubTab('history')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverRideSubTab === 'history' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <History className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Ride History</span>
                </button>
              </div>

              {driverRideSubTab === 'active_dispatches' && (
                <div className="space-y-6">
                  <div className="flex flex-col items-center justify-center text-center gap-2 pb-3 border-b border-neutral-200">
                    <h3 className="text-sm font-bold text-neutral-900 flex items-center justify-center gap-2 text-center">
                      <Navigation className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span>Driver End-to-End Navigation Map &amp; Passenger Dispatches</span>
                    </h3>
                    <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 tabular-nums mx-auto">
                      Earnings: {driverEarnings} AFNL
                    </span>
                  </div>

                  {/* ONLY show active Driver Ride Map & Driver Turn-by-Turn Map Directions when a ride is accepted */}
                  {activeDriverRide ? (() => {
                    const driverRoute = activeDriverRideRoute || buildTurnByTurnRoute(activeDriverRide.pickup, activeDriverRide.dropoff, 'driver_ride');
                    const steps = driverRoute.steps;
                    const clampedIdx = Math.min(driverRideStepIdx, steps.length - 1);
                    const currentStep = steps[clampedIdx];
                    const nextStep = clampedIdx < steps.length - 1 ? steps[clampedIdx + 1] : null;
                    const markerPos = getBezierMarkerPos(clampedIdx, steps.length);

                    return (
                      <div className="space-y-4">
                        <div className="relative w-full h-72 rounded-2xl bg-neutral-900 overflow-hidden border border-neutral-800">
                          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px]"></div>
                          <svg viewBox="0 0 780 260" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                            <path d="M 80 190 Q 390 40, 700 90" fill="none" stroke="#10b981" strokeWidth="4" strokeDasharray="6 6" />
                          </svg>
                          <div className="absolute left-[10%] bottom-[22%] -translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-indigo-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Pickup Passenger: {activeDriverRide.pickup}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-indigo-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div className="absolute right-[10%] top-[28%] translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Dropoff Destination: {activeDriverRide.dropoff}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div
                            className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700 flex flex-col items-center z-10"
                            style={{ left: markerPos.leftPct, top: markerPos.topPct }}
                          >
                            <div className="mb-1 px-2 py-0.5 rounded bg-white text-neutral-900 text-[9px] font-mono font-bold shadow-md whitespace-nowrap">
                              GPS Live · {currentStep.distanceLabel}
                            </div>
                            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                              <Car className="w-4 h-4" />
                            </div>
                          </div>
                          <div className="absolute bottom-3 left-3 right-3 bg-black/75 backdrop-blur-md p-3 rounded-xl border border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs text-white">
                            <span className="font-mono">
                              Active Dispatch: {activeDriverRide.pickup} → {activeDriverRide.dropoff}
                            </span>
                            <span className="text-emerald-400 font-bold font-mono tabular-nums">
                              Rate: {ratePerMile} {activeDriverPayoutCoin} / mile · {activeDriverRide.fare} {activeDriverRide.currency}
                            </span>
                          </div>
                        </div>

                        {/* Automatic Live GPS Turn-by-Turn Directions Box */}
                        <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-left space-y-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <h4 className="text-xs font-bold text-neutral-800 uppercase font-mono flex items-center gap-1.5">
                              <ListOrdered className="w-4 h-4 text-emerald-600" />
                              Live Auto-GPS Turn-by-Turn Directions
                            </h4>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 text-[10px] font-mono font-bold flex items-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${isAutoGpsDriverRide ? 'bg-emerald-600 animate-pulse' : 'bg-neutral-400'}`}></span>
                                <span>{clampedIdx >= steps.length - 1 ? 'Arrived' : isAutoGpsDriverRide ? 'Auto-Tracking Road' : 'GPS Paused'}</span>
                              </span>
                              <button
                                type="button"
                                onClick={() => setVoiceGpsEnabled(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer"
                              >
                                {voiceGpsEnabled ? '🔊 Voice On' : '🔇 Voice Muted'}
                              </button>
                              <button
                                type="button"
                                onClick={() => setIsAutoGpsDriverRide(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer flex items-center gap-1"
                              >
                                {isAutoGpsDriverRide ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                                <span>{isAutoGpsDriverRide ? 'Pause' : 'Resume'}</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDriverCompleteRide(activeDriverRide.id)}
                                className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer whitespace-nowrap"
                              >
                                Complete Trip (+{activeDriverRide.fare} {activeDriverRide.currency})
                              </button>
                            </div>
                          </div>

                          <div className="p-3 rounded-xl bg-emerald-900 text-white text-xs font-mono space-y-1.5">
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-bold flex items-center gap-1.5">
                                {getManeuverIcon(currentStep.maneuver)}
                                <span>NOW: {currentStep.instruction}</span>
                              </span>
                              <span className="shrink-0 font-bold text-emerald-300 tabular-nums">{currentStep.distanceLabel}</span>
                            </div>
                            <p className="text-[11px] text-emerald-100 font-sans">
                              {nextStep
                                ? `Next Turn Ahead (auto-updating): ${nextStep.instruction} (${nextStep.distanceLabel})`
                                : 'Final segment — approaching dropoff destination.'}
                            </p>
                          </div>

                          <ol className="space-y-1.5 text-xs font-mono">
                            {steps.map((step, idx) => {
                              const isDone = idx < clampedIdx;
                              const isActive = idx === clampedIdx;
                              return (
                                <li
                                  key={step.id}
                                  onClick={() => setDriverRideStepIdx(idx)}
                                  className={`p-2 rounded-xl border flex items-start justify-between gap-2 cursor-pointer transition-colors ${
                                    isActive
                                      ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                                      : isDone
                                        ? 'bg-neutral-100 border-neutral-200 text-neutral-500 line-through'
                                        : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                                  }`}
                                >
                                  <div className="flex items-start gap-2 min-w-0">
                                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                                      isActive ? 'bg-emerald-600 text-white' : isDone ? 'bg-neutral-400 text-white' : 'bg-neutral-200 text-neutral-700'
                                    }`}>
                                      {isDone ? '✓' : idx + 1}
                                    </span>
                                    <div>
                                      <p className="font-bold">{step.instruction}</p>
                                      <p className="text-[11px] font-sans opacity-80">{step.detail}</p>
                                    </div>
                                  </div>
                                  <span className="text-[11px] font-bold shrink-0 tabular-nums">{step.distanceLabel}</span>
                                </li>
                              );
                            })}
                          </ol>
                        </div>
                      </div>
                    );
                  })() : (
                    <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-1.5">
                      <Navigation className="w-7 h-7 text-indigo-600 mx-auto" />
                      <p className="text-xs font-bold text-neutral-900">
                        Accept a ride request below to activate live navigation
                      </p>
                      <p className="text-[11px] text-neutral-500">
                        Pickup Passenger, Dropoff Destination, and Driver Turn-by-Turn Map Directions appear as soon as you accept a dispatch.
                      </p>
                    </div>
                  )}

                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-neutral-700 uppercase font-mono text-center">Available Ride Requests in Sector</h4>
                    {filteredRides.filter(r => r.status !== 'cancelled' && r.status !== 'completed').length === 0 ? (
                      <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                        <p className="text-xs text-neutral-500">No incoming ride dispatches available.</p>
                      </div>
                    ) : (
                      filteredRides
                        .filter(r => r.status !== 'cancelled' && r.status !== 'completed')
                        .map(ride => {
                          const isAcceptedByThisDriver = ride.status === 'in_transit' && ride.driverId === userId;

                          return (
                            <div key={ride.id} className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col items-center justify-center text-center gap-3">
                              <div className="space-y-1.5 text-center w-full">
                                <div className="flex flex-wrap items-center gap-2 justify-center">
                                  <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-900 text-[10px] font-bold font-mono">
                                    {ride.vehicleType || CLASS_META[ride.vehicleClass]?.vehicleType || 'Car'} · {ride.vehicleClass}
                                  </span>
                                  {onViewUserProfile ? (
                                    <button
                                      type="button"
                                      onClick={() => onViewUserProfile(ride.riderId)}
                                      className="text-xs font-bold text-indigo-600 hover:underline inline-flex items-center gap-1 cursor-pointer"
                                    >
                                      <span>Passenger: {ride.riderName}</span>
                                      <ExternalLink className="w-3 h-3" />
                                    </button>
                                  ) : (
                                    <span className="text-xs font-bold text-neutral-900">Passenger: {ride.riderName}</span>
                                  )}
                                </div>
                                <p className="text-xs text-neutral-600">Pickup: {ride.pickup} → Dropoff: {ride.dropoff}</p>
                              </div>

                              <div className="flex flex-wrap items-center justify-center gap-2 w-full pt-1">
                                <span className="px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-xs font-mono font-bold text-emerald-700 tabular-nums whitespace-nowrap">
                                  {ride.fare} {ride.currency}
                                </span>
                                {!isAcceptedByThisDriver ? (
                                  <button
                                    type="button"
                                    onClick={() => handleDriverAcceptRide(ride.id)}
                                    className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-sm whitespace-nowrap"
                                  >
                                    Accept &amp; Navigate Ride
                                  </button>
                                ) : (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => handleDriverCompleteRide(ride.id)}
                                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer whitespace-nowrap shadow-xs"
                                    >
                                      Complete Trip
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDriverCancelRide(ride.id)}
                                      className="px-3.5 py-1.5 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold cursor-pointer whitespace-nowrap"
                                    >
                                      Cancel Dispatch
                                    </button>
                                  </>
                                )}
                              </div>
                            </div>
                          );
                        })
                    )}
                  </div>
                </div>
              )}

              {driverRideSubTab === 'history' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-neutral-900 text-center">Driver Completed Ride Dispatches History</h3>
                  {filteredRides.filter(r => r.status === 'completed').map(r => (
                    <div key={r.id} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center justify-between">
                      <div>
                        <p className="text-xs font-bold text-neutral-900">Ride Dispatch #{r.id.slice(-6)} ({r.vehicleClass})</p>
                        <p className="text-[11px] text-neutral-600">{r.pickup} → {r.dropoff} · Passenger: {r.riderName}</p>
                      </div>
                      <span className="text-xs font-mono font-bold text-emerald-700 tabular-nums">+{r.fare} {r.currency}</span>
                    </div>
                  ))}
                  <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-neutral-900">Ride Dispatch #407732 (Comfort EV)</p>
                      <p className="text-[11px] text-neutral-600">Zurich Freeport → Bahnhofstrasse · Passenger: Sovereign Explorer</p>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-700 tabular-nums">+32 AFNL</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================================================ */}
          {/* DRIVER SUB-TAB 2: DELIVERY DISPATCHES (2 SUB-TABS) */}
          {/* ================================================ */}
          {driverSubTab === 'delivery_dispatches' && (
            <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-sm space-y-6 max-w-4xl mx-auto text-center">
              <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-xl mx-auto max-w-full">
                <button
                  type="button"
                  onClick={() => setDriverDeliverySubTab('active_deliveries')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverDeliverySubTab === 'active_deliveries' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <Store className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Active Dispatches</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDriverDeliverySubTab('history')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                    driverDeliverySubTab === 'history' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-600'
                  }`}
                >
                  <History className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Delivery History</span>
                </button>
              </div>

              {driverDeliverySubTab === 'active_deliveries' && (() => {
                const restaurantDeliveries = filteredDeliveries.filter(c => c.businessType === 'restaurant');
                const storeDeliveries = filteredDeliveries.filter(c => c.businessType === 'retail');
                const restaurantUnread = unreadDeliveryNotifs.filter(n => n.businessType === 'restaurant');
                const storeUnread = unreadDeliveryNotifs.filter(n => n.businessType === 'retail');

                const tabContracts =
                  activeDeliveryDispatchTab === 'restaurant' ? restaurantDeliveries : storeDeliveries;
                const tabUnreadNotifs =
                  activeDeliveryDispatchTab === 'restaurant' ? restaurantUnread : storeUnread;
                const tabAccepted = tabContracts.filter(
                  c => c.status === 'accepted' || c.status === 'picked_up'
                );
                const tabActiveContract =
                  tabAccepted.find(c => c.id === focusedDeliveryId) || tabAccepted[0] || null;
                const otherTab: 'restaurant' | 'retail' =
                  activeDeliveryDispatchTab === 'restaurant' ? 'retail' : 'restaurant';
                const otherAcceptedCount = acceptedDeliveries.filter(
                  c => c.businessType === otherTab
                ).length;

                return (
                <div className="space-y-6">
                  <div className="flex flex-col items-center justify-center text-center gap-2.5 pb-3 border-b border-neutral-200">
                    <h3 className="text-sm font-bold text-neutral-900 flex items-center justify-center gap-2 text-center">
                      <Store className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Active Delivery Dispatches</span>
                    </h3>
                    <div className="flex flex-wrap items-center justify-center gap-2 w-full">
                      <div className="flex items-center justify-center gap-1.5 bg-neutral-100 px-2.5 py-1 rounded-xl border border-neutral-200 text-[11px] font-mono">
                        <span className="text-neutral-600">Your Rate:</span>
                        <span className="font-bold text-neutral-900">{ratePerMile}</span>
                        <select
                          value={activeDriverPayoutCoin}
                          onChange={(e) => setActiveDriverPayoutCoin(e.target.value)}
                          aria-label="Driver payout coin"
                          className="bg-white border border-neutral-300 rounded-md px-1.5 py-0.5 text-[11px] font-bold text-emerald-800 outline-none cursor-pointer"
                        >
                          {driverCurrencies.map(c => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                        <span className="text-neutral-600">/mi</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 tabular-nums">
                        {tabContracts.filter(c => c.status === 'available').length} Ready
                      </span>
                    </div>
                  </div>

                  {/* Two Tabs Under Active Dispatches: Restaurant vs Stores */}
                  <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1 bg-neutral-100 rounded-xl mx-auto">
                    <button
                      type="button"
                      onClick={() => setActiveDeliveryDispatchTab('restaurant')}
                      className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                        activeDeliveryDispatchTab === 'restaurant'
                          ? 'bg-white text-neutral-900 shadow-sm'
                          : 'text-neutral-600 hover:text-neutral-900'
                      }`}
                    >
                      <UtensilsCrossed className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>Restaurant</span>
                      <span className="px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-mono font-bold tabular-nums leading-none">
                        {restaurantDeliveries.filter(c => c.status === 'available').length}
                      </span>
                      {restaurantUnread.length > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-mono font-bold tabular-nums leading-none">
                          {restaurantUnread.length} new
                        </span>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveDeliveryDispatchTab('retail')}
                      className={`py-1.5 px-4 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 ${
                        activeDeliveryDispatchTab === 'retail'
                          ? 'bg-white text-neutral-900 shadow-sm'
                          : 'text-neutral-600 hover:text-neutral-900'
                      }`}
                    >
                      <Store className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      <span>Stores</span>
                      <span className="px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-900 text-[10px] font-mono font-bold tabular-nums leading-none">
                        {storeDeliveries.filter(c => c.status === 'available').length}
                      </span>
                      {storeUnread.length > 0 && (
                        <span className="px-1.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-mono font-bold tabular-nums leading-none">
                          {storeUnread.length} new
                        </span>
                      )}
                    </button>
                  </div>

                  {otherAcceptedCount > 0 && !tabActiveContract && (
                    <div className="p-3 rounded-2xl bg-indigo-50 border border-indigo-200 flex flex-wrap items-center justify-center gap-3 text-xs">
                      <span className="font-semibold text-indigo-950">
                        You have {otherAcceptedCount} active accepted {otherTab === 'restaurant' ? 'Restaurant' : 'Stores'} delivery.
                      </span>
                      <button
                        type="button"
                        onClick={() => setActiveDeliveryDispatchTab(otherTab)}
                        className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-bold cursor-pointer"
                      >
                        Switch to {otherTab === 'restaurant' ? 'Restaurant' : 'Stores'} Tab
                      </button>
                    </div>
                  )}

                  {/* Driver Delivery Dispatch Notifications (filtered by Restaurant or Stores tab) */}
                  {tabUnreadNotifs.length > 0 && (
                    <div className="space-y-2">
                      {tabUnreadNotifs.map(notif => {
                        const matchingContract = tabContracts.find(
                          c => c.id === notif.contractId || c.orderNumber === notif.orderNumber
                        );
                        const driverEstPayout = Math.round(ratePerMile * (notif.distanceMiles || 4) * 100) / 100;
                        const notifTiming = estimateDeliveryTiming(
                          notif.pickupAddress || notif.merchantName,
                          notif.deliveryAddress,
                          notif.distanceMiles || 4
                        );
                        return (
                          <div
                            key={notif.id}
                            className="p-4 rounded-2xl bg-amber-50 border border-amber-300 flex flex-col items-center justify-center gap-3 text-center"
                          >
                            <div className="space-y-1 flex flex-col items-center text-center w-full">
                              <div className="flex flex-wrap items-center justify-center gap-2">
                                <Bell className="w-4 h-4 text-amber-700 shrink-0" />
                                <span className="text-xs font-extrabold text-amber-950">
                                  New {notif.businessType === 'retail' ? 'Store' : 'Restaurant'} Delivery Request · #{notif.orderNumber}
                                </span>
                              </div>
                              <p className="text-xs text-amber-900">
                                <span className="font-bold">{notif.merchantName}</span> → {notif.deliveryAddress} ({notif.distance})
                              </p>
                              <p className="text-[11px] font-mono text-amber-900 tabular-nums">
                                To {notif.businessType === 'retail' ? 'Store' : 'Restaurant'}: ~{notifTiming.toPickupMinutes} mins ({notifTiming.toPickupMiles} mi) + Delivery: ~{notifTiming.deliveryMinutes} mins ({notifTiming.deliveryMiles} mi) = <strong>~{notifTiming.totalMinutes} mins total</strong>
                              </p>
                              <p className="text-[11px] font-mono text-amber-800">
                                {notif.businessType === 'retail' ? 'Store' : 'Restaurant'} Base Fee: {notif.storeFee} {notif.storeFeeCurrency} · Your Rate Payout: <strong>+{driverEstPayout} {activeDriverPayoutCoin}</strong>
                              </p>
                            </div>
                            <div className="flex flex-wrap items-center justify-center gap-2 shrink-0 w-full">
                              {matchingContract && matchingContract.status === 'available' && (
                                <button
                                  type="button"
                                  onClick={() => handleAcceptDeliveryContract(matchingContract.id)}
                                  className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                                >
                                  Accept Delivery
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => dismissDriverNotification(notif.id)}
                                className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-neutral-100 border border-amber-300 text-amber-900 text-xs font-bold cursor-pointer"
                              >
                                Dismiss
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* ONLY show Merchant Pickup -> Customer Delivery Map & Live Auto-GPS Turn-by-Turn Directions when a delivery IS accepted */}
                  {tabActiveContract ? (() => {
                    const deliveryRoute = buildTurnByTurnRoute(
                      tabActiveContract.pickupAddress || tabActiveContract.merchantName,
                      tabActiveContract.deliveryAddress,
                      'driver_delivery',
                      {
                        merchantName: tabActiveContract.merchantName,
                        customerName: tabActiveContract.customerName,
                        baseDistanceMiles: tabActiveContract.distanceMiles
                      }
                    );
                    const steps = deliveryRoute.steps;
                    const clampedIdx = Math.min(driverDeliveryStepIdx, steps.length - 1);
                    const currentStep = steps[clampedIdx];
                    const nextStep = clampedIdx < steps.length - 1 ? steps[clampedIdx + 1] : null;
                    const markerPos = getBezierMarkerPos(clampedIdx, steps.length);

                    return (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-center font-mono">
                          <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                            <p className="text-[10px] uppercase text-amber-700 font-bold">
                              To {tabActiveContract.businessType === 'retail' ? 'Store' : 'Restaurant'} Pickup
                            </p>
                            <p className="text-xs font-extrabold text-amber-950 tabular-nums">
                              ~{deliveryRoute.toPickupMinutes} mins · {deliveryRoute.pickupApproachMiles} mi
                            </p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                            <p className="text-[10px] uppercase text-emerald-700 font-bold">
                              Delivery From {tabActiveContract.businessType === 'retail' ? 'Store' : 'Restaurant'}
                            </p>
                            <p className="text-xs font-extrabold text-emerald-950 tabular-nums">
                              ~{deliveryRoute.deliveryLegMinutes} mins · {deliveryRoute.distanceMiles} mi
                            </p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-neutral-100 border border-neutral-200">
                            <p className="text-[10px] uppercase text-neutral-600 font-bold">Total Delivery Time</p>
                            <p className="text-xs font-extrabold text-neutral-900 tabular-nums">
                              ~{deliveryRoute.totalMinutes} mins · {deliveryRoute.totalMiles} mi
                            </p>
                          </div>
                        </div>

                        <div className="relative w-full h-72 rounded-2xl bg-neutral-900 overflow-hidden border border-neutral-800">
                          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:24px_24px]"></div>
                          <svg viewBox="0 0 780 260" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                            <path d="M 80 190 Q 390 40, 700 90" fill="none" stroke="#f59e0b" strokeWidth="4" strokeDasharray="6 6" />
                          </svg>
                          <div className="absolute left-[10%] bottom-[22%] -translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-amber-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Merchant Pickup: {tabActiveContract.pickupAddress || tabActiveContract.merchantName}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-amber-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div className="absolute right-[10%] top-[28%] translate-x-1/2 flex flex-col items-center max-w-[38%]">
                            <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-bold font-mono truncate max-w-full">
                              Customer Delivery: {tabActiveContract.deliveryAddress}
                            </span>
                            <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white mt-1 shadow-md"></div>
                          </div>
                          <div
                            className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-700 flex flex-col items-center z-10"
                            style={{ left: markerPos.leftPct, top: markerPos.topPct }}
                          >
                            <div className="mb-1 px-2 py-0.5 rounded bg-white text-neutral-900 text-[9px] font-mono font-bold shadow-md whitespace-nowrap">
                              GPS Live · {currentStep.distanceLabel}
                            </div>
                            <div className="w-8 h-8 rounded-full bg-amber-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                              <Package className="w-4 h-4" />
                            </div>
                          </div>
                          <div className="absolute bottom-3 left-3 right-3 bg-black/75 backdrop-blur-md p-3 rounded-xl border border-white/10 flex flex-col items-center justify-center text-center gap-1 text-xs text-white">
                            <span className="font-mono text-center">
                              Active Contract: {tabActiveContract.merchantName} Delivery (#{tabActiveContract.orderNumber})
                            </span>
                            <span className="text-amber-400 font-bold font-mono tabular-nums text-center">
                              Fee: +{tabActiveContract.deliveryFee} {tabActiveContract.currency} · ~{deliveryRoute.totalMinutes} mins total
                            </span>
                          </div>
                        </div>

                        {/* Automatic Live GPS Delivery Turn-by-Turn Directions Box */}
                        <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-3">
                          <div className="flex flex-col items-center justify-center text-center gap-2.5">
                            <h4 className="text-xs font-bold text-neutral-800 uppercase font-mono flex items-center justify-center gap-1.5 text-center">
                              <ListOrdered className="w-4 h-4 text-amber-600 shrink-0" />
                              <span>Live Auto-GPS Delivery Directions</span>
                            </h4>
                            <div className="flex flex-wrap items-center justify-center gap-1.5 w-full">
                              <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-950 text-[10px] font-mono font-bold flex items-center justify-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${isAutoGpsDriverDelivery ? 'bg-amber-600 animate-pulse' : 'bg-neutral-400'}`}></span>
                                <span>{clampedIdx >= steps.length - 1 ? 'Arrived' : isAutoGpsDriverDelivery ? 'Auto-Tracking Road' : 'GPS Paused'}</span>
                              </span>
                              <button
                                type="button"
                                onClick={() => setVoiceGpsEnabled(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer"
                              >
                                {voiceGpsEnabled ? '🔊 Voice On' : '🔇 Voice Muted'}
                              </button>
                              <button
                                type="button"
                                onClick={() => setIsAutoGpsDriverDelivery(v => !v)}
                                className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 text-[11px] font-bold cursor-pointer flex items-center justify-center gap-1"
                              >
                                {isAutoGpsDriverDelivery ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                                <span>{isAutoGpsDriverDelivery ? 'Pause' : 'Resume'}</span>
                              </button>
                              {tabActiveContract.status === 'accepted' && (
                                <button
                                  type="button"
                                  onClick={() => handleMarkDeliveryPickedUp(tabActiveContract.id)}
                                  className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold cursor-pointer"
                                >
                                  Picked Up
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => openDeliveryProofModal(tabActiveContract.id)}
                                className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer whitespace-nowrap"
                              >
                                Mark Delivered (+{tabActiveContract.deliveryFee} {tabActiveContract.currency})
                              </button>
                            </div>
                          </div>

                          <div className="p-3 rounded-xl bg-amber-950 text-white text-xs font-mono space-y-1.5 text-center flex flex-col items-center justify-center">
                            <div className="flex flex-wrap items-center justify-center gap-2">
                              <span className="font-bold flex items-center justify-center gap-1.5">
                                {getManeuverIcon(currentStep.maneuver)}
                                <span>NOW: {currentStep.instruction}</span>
                              </span>
                              <span className="shrink-0 font-bold text-amber-300 tabular-nums">{currentStep.distanceLabel}</span>
                            </div>
                            <p className="text-[11px] text-amber-100 font-sans text-center">
                              {nextStep
                                ? `Next Turn Ahead (auto-updating): ${nextStep.instruction} (${nextStep.distanceLabel})`
                                : 'Final dropoff — take proof photos/videos and mark delivered.'}
                            </p>
                          </div>

                          <ol className="space-y-1.5 text-xs font-mono text-center">
                            {steps.map((step, idx) => {
                              const isDone = idx < clampedIdx;
                              const isActive = idx === clampedIdx;
                              return (
                                <li
                                  key={step.id}
                                  onClick={() => setDriverDeliveryStepIdx(idx)}
                                  className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer transition-colors ${
                                    isActive
                                      ? 'bg-amber-50 border-amber-300 text-amber-950'
                                      : isDone
                                        ? 'bg-neutral-100 border-neutral-200 text-neutral-500 line-through'
                                        : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                                  }`}
                                >
                                  <div className="flex items-center justify-center gap-2">
                                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                                      isActive ? 'bg-amber-600 text-white' : isDone ? 'bg-neutral-400 text-white' : 'bg-neutral-200 text-neutral-700'
                                    }`}>
                                      {isDone ? '✓' : idx + 1}
                                    </span>
                                    <span className="text-[11px] font-bold tabular-nums">{step.distanceLabel}</span>
                                  </div>
                                  <p className="font-bold text-center">{step.instruction}</p>
                                  <p className="text-[11px] font-sans opacity-80 text-center">{step.detail}</p>
                                </li>
                              );
                            })}
                          </ol>
                        </div>
                      </div>
                    );
                  })() : (
                    <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center space-y-1.5">
                      <Package className="w-7 h-7 text-amber-600 mx-auto" />
                      <p className="text-xs font-bold text-neutral-900">
                        Accept a {activeDeliveryDispatchTab === 'restaurant' ? 'Restaurant' : 'Store'} delivery dispatch below to start navigation
                      </p>
                      <p className="text-[11px] text-neutral-500">
                        Merchant Pickup, Customer Delivery, Active Contract details, and Automatic GPS Turn-by-Turn Directions appear once you accept an order.
                      </p>
                    </div>
                  )}

                  <div className="space-y-4">
                    {tabContracts.length === 0 ? (
                      <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center text-xs text-neutral-500">
                        No {activeDeliveryDispatchTab === 'restaurant' ? 'Restaurant' : 'Store'} delivery dispatches currently queued.
                      </div>
                    ) : (
                      tabContracts.map(contract => {
                        const rawDist = contract.distanceMiles ?? (parseFloat(contract.distance || '4') || 4);
                        const isKm = (contract.distance || '').toLowerCase().includes('km');
                        const distMiles = isKm ? Math.max(0.5, Math.round(rawDist * 0.621371 * 10) / 10) : rawDist;
                        const estDriverPayout = Math.round(ratePerMile * distMiles * 100) / 100;
                        const isFocused = tabActiveContract?.id === contract.id;
                        const timing = estimateDeliveryTiming(
                          contract.pickupAddress || contract.merchantName,
                          contract.deliveryAddress,
                          distMiles
                        );

                        return (
                          <div
                            key={contract.id}
                            className={`p-5 rounded-3xl border shadow-sm flex flex-col items-center justify-center text-center gap-3.5 ${
                              isFocused ? 'bg-amber-50/50 border-amber-300' : 'bg-neutral-50 border-neutral-200'
                            }`}
                          >
                            <div className="space-y-1.5 text-center w-full flex flex-col items-center justify-center">
                              <div className="flex flex-wrap items-center justify-center gap-2">
                                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md border uppercase ${
                                  contract.businessType === 'retail' ? 'bg-indigo-50 text-indigo-900 border-indigo-200' : 'bg-amber-50 text-amber-900 border-amber-200'
                                }`}>
                                  {contract.businessType === 'retail' ? 'Store' : 'Restaurant'}
                                </span>
                                <span className="text-xs font-bold text-neutral-900 font-mono">Order #{contract.orderNumber}</span>
                                {contract.status === 'available' ? (
                                  <span className="text-xs font-mono font-extrabold text-emerald-700 tabular-nums">
                                    <span className="text-neutral-500 line-through font-normal mr-1.5">
                                      {contract.businessType === 'retail' ? 'Store' : 'Restaurant'}: {contract.originalStoreFee ?? contract.deliveryFee} {contract.originalCurrency || contract.currency}
                                    </span>
                                    <span>Your Payout: +{estDriverPayout} {activeDriverPayoutCoin}</span>
                                  </span>
                                ) : (
                                  <span className="text-xs font-mono font-extrabold text-emerald-700 tabular-nums">
                                    +{contract.deliveryFee} {contract.currency}
                                  </span>
                                )}
                              </div>
                              <h4 className="text-sm font-bold text-neutral-900 text-center">
                                Pickup From: <span className="text-indigo-600">{contract.merchantName} — {contract.pickupAddress || 'Merchant Hub'}</span>
                              </h4>
                              <p className="text-xs text-neutral-600 text-center">
                                Deliver To: <span className="font-semibold">{contract.deliveryAddress}</span> (Customer: {contract.customerName} · {contract.distance || `${distMiles} miles`})
                              </p>
                              <div className="flex flex-wrap items-center justify-center gap-2 pt-0.5 text-[11px] font-mono tabular-nums w-full">
                                <span className="px-2.5 py-0.5 rounded-md bg-amber-100/80 text-amber-950 font-semibold">
                                  To {contract.businessType === 'retail' ? 'Store' : 'Restaurant'}: ~{timing.toPickupMinutes} mins ({timing.toPickupMiles} mi)
                                </span>
                                <span className="px-2.5 py-0.5 rounded-md bg-emerald-100/80 text-emerald-950 font-semibold">
                                  Delivery Leg: ~{timing.deliveryMinutes} mins ({timing.deliveryMiles} mi)
                                </span>
                                <span className="px-2.5 py-0.5 rounded-md bg-neutral-200/80 text-neutral-900 font-bold">
                                  Total: ~{timing.totalMinutes} mins ({timing.totalMiles} mi)
                                </span>
                              </div>
                            </div>

                            {/* Centered Delivery Proof Photos & Videos when delivered */}
                            {((contract.proofPhotos && contract.proofPhotos.length > 0) ||
                              (contract.proofVideos && contract.proofVideos.length > 0)) && (
                              <div className="w-full pt-2 border-t border-neutral-200/70 space-y-2 text-center flex flex-col items-center">
                                <p className="text-[10px] font-mono font-bold uppercase text-emerald-800">
                                  Verified Proof of Delivery ({contract.proofPhotos?.length || 0} Photos · {contract.proofVideos?.length || 0} Videos)
                                </p>
                                <div className="flex flex-wrap items-center justify-center gap-2.5 w-full">
                                  {(contract.proofPhotos || []).map((photoUrl, pIdx) => (
                                    <img
                                      key={`dp-${contract.id}-${pIdx}`}
                                      src={photoUrl}
                                      alt={`Delivery Proof Photo ${pIdx + 1}`}
                                      className="w-28 h-20 object-cover rounded-xl border border-emerald-200 shadow-2xs"
                                    />
                                  ))}
                                  {(contract.proofVideos || []).map((vidUrl, vIdx) => (
                                    <video
                                      key={`dv-${contract.id}-${vIdx}`}
                                      src={vidUrl}
                                      controls
                                      className="w-40 h-24 rounded-xl border border-emerald-200 bg-black shadow-2xs"
                                    />
                                  ))}
                                </div>
                              </div>
                            )}

                            <div className="flex flex-wrap items-center justify-center gap-2 w-full">
                              {contract.status === 'available' && (
                                <button
                                  type="button"
                                  onClick={() => handleAcceptDeliveryContract(contract.id)}
                                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-sm whitespace-nowrap"
                                >
                                  Accept Delivery
                                </button>
                              )}
                              {(contract.status === 'accepted' || contract.status === 'picked_up') && (
                                <div className="flex flex-wrap items-center justify-center gap-2 w-full">
                                  {!isFocused && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setFocusedDeliveryId(contract.id);
                                        setDriverDeliveryStepIdx(0);
                                      }}
                                      className="px-3.5 py-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold cursor-pointer whitespace-nowrap"
                                    >
                                      View Navigation
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => openDeliveryProofModal(contract.id)}
                                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer transition-colors shadow-sm whitespace-nowrap"
                                  >
                                    Mark Delivered
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDriverCancelDelivery(contract.id)}
                                    className="px-3.5 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-800 text-xs font-bold cursor-pointer whitespace-nowrap"
                                  >
                                    Cancel Dispatch
                                  </button>
                                </div>
                              )}
                              {contract.status === 'delivered' && (
                                <div className="flex flex-wrap items-center justify-center gap-2">
                                  <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-1.5">
                                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                    Delivered &amp; Settled
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => setRatingModalDeliveryId(contract.id)}
                                    className="px-3 py-1.5 rounded-lg bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold flex items-center gap-1 cursor-pointer"
                                  >
                                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                                    {contract.rating ? 'Update Rating' : 'Rate Driver'}
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
                );
              })()}

              {driverDeliverySubTab === 'history' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-neutral-900 text-center">Completed Restaurant &amp; Retail Deliveries History</h3>
                  {deliveryContracts.filter(c => c.status === 'delivered').length === 0 ? (
                    <div className="p-6 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                      <p className="text-xs text-neutral-500">No completed deliveries yet.</p>
                    </div>
                  ) : (
                    deliveryContracts.filter(c => c.status === 'delivered').map(c => (
                      <div key={c.id} className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col items-center justify-center text-center gap-3">
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-neutral-900">Order #{c.orderNumber} ({c.businessType === 'retail' ? 'Store' : 'Restaurant'})</p>
                          <p className="text-[11px] text-neutral-600">Pickup: {c.pickupAddress} → {c.deliveryAddress}</p>
                          {c.rating && (
                            <p className="text-[11px] text-amber-600 font-bold">★ {c.rating}/5 - "{c.comment}"</p>
                          )}
                        </div>
                        {((c.proofPhotos && c.proofPhotos.length > 0) || (c.proofVideos && c.proofVideos.length > 0)) && (
                          <div className="flex flex-wrap items-center justify-center gap-2 w-full">
                            {(c.proofPhotos || []).map((photoUrl, pIdx) => (
                              <img
                                key={`hp-${c.id}-${pIdx}`}
                                src={photoUrl}
                                alt={`Proof ${pIdx + 1}`}
                                className="w-24 h-16 object-cover rounded-lg border border-emerald-200"
                              />
                            ))}
                            {(c.proofVideos || []).map((vidUrl, vIdx) => (
                              <video
                                key={`hv-${c.id}-${vIdx}`}
                                src={vidUrl}
                                controls
                                className="w-36 h-20 rounded-lg border border-emerald-200 bg-black"
                              />
                            ))}
                          </div>
                        )}
                        <div className="flex flex-wrap items-center justify-center gap-3">
                          <span className="text-xs font-mono font-bold text-emerald-700 tabular-nums">+{c.deliveryFee} {c.currency}</span>
                          <button
                            type="button"
                            onClick={() => setRatingModalDeliveryId(c.id)}
                            className="px-2.5 py-1 rounded-lg bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                            {c.rating ? 'Update' : 'Rate'}
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          )}

          {/* ================================================ */}
          {/* DRIVER SUB-TAB 3: DRIVER SIGNUP (3 VEHICLE TYPES) */}
          {/* ================================================ */}
          {driverSubTab === 'profile' && (
            <div className="max-w-3xl mx-auto bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6 text-center">
              <div className="space-y-2">
                <ShieldCheck className="w-10 h-10 text-emerald-600 mx-auto" />
                <h2 className="font-serif-lux text-xl sm:text-2xl font-semibold text-black tracking-tight text-center">
                  Sovereign Driver Signup &amp; Fleet Profile
                </h2>
              </div>

              {/* Driver Stats */}
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-0.5">
                  <p className="text-[10px] text-neutral-400 uppercase font-mono font-bold">Total Earnings</p>
                  <p className="text-sm font-extrabold text-neutral-900 font-mono tabular-nums">{driverEarnings} AFNL</p>
                </div>
                <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-0.5">
                  <p className="text-[10px] text-neutral-400 uppercase font-mono font-bold">Rating</p>
                  <p className="text-sm font-extrabold text-amber-600 font-mono">4.98 ★</p>
                </div>
                <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-0.5">
                  <p className="text-[10px] text-neutral-400 uppercase font-mono font-bold">Registered Fleet</p>
                  <p className="text-sm font-extrabold text-indigo-600 font-mono tabular-nums">
                    {Object.values(driverVehicles).filter(Boolean).length}/3 Types
                  </p>
                </div>
              </div>

              {/* 3 Vehicle Sections: Car, Auto Rickshaw, Motor Bike (Max 1 Each) */}
              <div className="space-y-5 text-left">
                {VEHICLE_TYPE_SECTIONS.map((sec, idx) => {
                  const slot = driverVehicles[sec.type];
                  const draft = driverDrafts[sec.type];
                  return (
                    <div
                      key={sec.type}
                      className={`p-5 rounded-3xl border space-y-4 ${
                        slot ? 'bg-emerald-50/40 border-emerald-200' : 'bg-neutral-50/70 border-neutral-200'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-neutral-200/80">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-neutral-900 text-white text-xs font-bold flex items-center justify-center font-mono">
                            {idx + 1}
                          </span>
                          <h3 className="text-sm font-bold text-neutral-900">{sec.label}</h3>
                        </div>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                            slot
                              ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                              : 'bg-white text-neutral-600 border-neutral-200'
                          }`}
                        >
                          {slot ? '1/1 Registered (Max 1 Allowed)' : '0/1 Registered · Max 1 Allowed'}
                        </span>
                      </div>

                      {slot ? (
                        <div className="space-y-3 text-center">
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Vehicle Make &amp; Model</span>
                              <span className="font-bold text-neutral-900">{slot.makeModel}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Year &amp; Class</span>
                              <span className="font-bold text-neutral-900 font-mono">{slot.year} · {slot.vehicleClass}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">License Plate</span>
                              <span className="font-bold text-neutral-900 font-mono">{slot.plate}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">License ID</span>
                              <span className="font-bold text-neutral-900 font-mono">{slot.licenseId}</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Rate Per Mile</span>
                              <span className="font-bold text-emerald-700 font-mono tabular-nums">{slot.ratePerMile} {activeDriverPayoutCoin}/mi</span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-white border border-neutral-200">
                              <span className="text-[10px] uppercase font-mono text-neutral-400 block">Insurance Info</span>
                              <span className="font-semibold text-neutral-800 truncate block">{slot.insuranceInfo}</span>
                            </div>
                          </div>

                          {((slot.media && slot.media.length > 0) || (slot.videoMedia && slot.videoMedia.length > 0)) && (
                            <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                              {(slot.media || []).map((url, mIdx) => (
                                <img
                                  key={`slot-img-${sec.type}-${mIdx}`}
                                  src={url}
                                  alt={`${sec.label} Photo ${mIdx + 1}`}
                                  className="w-24 h-16 object-cover rounded-xl border border-emerald-200"
                                />
                              ))}
                              {(slot.videoMedia || []).map((vUrl, vIdx) => (
                                <video
                                  key={`slot-vid-${sec.type}-${vIdx}`}
                                  src={vUrl}
                                  controls
                                  className="w-36 h-20 rounded-xl border border-emerald-200 bg-black"
                                />
                              ))}
                            </div>
                          )}

                          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => handleToggleSlotOnline(sec.type)}
                              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
                                slot.online ? 'bg-emerald-600 text-white shadow-xs' : 'bg-neutral-200 text-neutral-700'
                              }`}
                            >
                              {slot.online ? `🟢 ${sec.label} Online` : `🔴 ${sec.label} Offline`}
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setRatePerMile(slot.ratePerMile);
                                try {
                                  localStorage.setItem(`final_finance_driver_rate_${userId}`, slot.ratePerMile.toString());
                                } catch {}
                                dispatchGlobalNotification({
                                  title: `Active Rate Updated (${sec.label})`,
                                  description: `Dispatch calculation rate set to ${slot.ratePerMile} ${activeDriverPayoutCoin}/mi.`,
                                  type: 'ride_share',
                                  targetTab: 'ride_share',
                                  showToast: true,
                                  tone: 'success'
                                });
                              }}
                              className="px-3.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-bold cursor-pointer"
                            >
                              Use {slot.ratePerMile}/mi Rate
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveVehicleSlot(sec.type)}
                              className="px-3.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                            >
                              Remove {sec.label}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <form onSubmit={(e) => handleRegisterVehicleSlot(sec.type, e)} className="space-y-3 text-center">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Vehicle Make &amp; Model *
                              </label>
                              <input
                                type="text"
                                value={draft.makeModel}
                                onChange={(e) => updateDriverDraft(sec.type, { makeModel: e.target.value })}
                                required
                                placeholder={sec.placeholderModel}
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 text-center"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Year *
                              </label>
                              <input
                                type="text"
                                value={draft.year}
                                onChange={(e) => updateDriverDraft(sec.type, { year: e.target.value })}
                                required
                                placeholder="e.g. 2025"
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 font-mono text-center"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                License Plate *
                              </label>
                              <input
                                type="text"
                                value={draft.plate}
                                onChange={(e) => updateDriverDraft(sec.type, { plate: e.target.value })}
                                required
                                placeholder={sec.placeholderPlate}
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 font-mono text-center"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                License ID *
                              </label>
                              <input
                                type="text"
                                value={draft.licenseId}
                                onChange={(e) => updateDriverDraft(sec.type, { licenseId: e.target.value })}
                                required
                                placeholder="e.g. CH-LIC-99214"
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 font-mono text-center"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Rate Per Mile *
                              </label>
                              <input
                                type="number"
                                step="0.5"
                                min={0.5}
                                max={100}
                                value={draft.ratePerMile}
                                onChange={(e) => updateDriverDraft(sec.type, { ratePerMile: parseFloat(e.target.value) || sec.defaultRate })}
                                required
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none text-center font-mono"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Insurance Information *
                              </label>
                              <input
                                type="text"
                                value={draft.insuranceInfo}
                                onChange={(e) => updateDriverDraft(sec.type, { insuranceInfo: e.target.value })}
                                required
                                placeholder="Commercial Policy ID..."
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-medium text-neutral-900 outline-none focus:border-emerald-500 text-center"
                              />
                            </div>
                          </div>

                          {sec.type === 'car' && (
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                                Car Class *
                              </label>
                              <select
                                value={draft.vehicleClass}
                                onChange={(e) => updateDriverDraft('car', { vehicleClass: e.target.value as VehicleClassName })}
                                className="w-full px-3 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-bold text-neutral-900 outline-none focus:border-emerald-500 text-center"
                              >
                                <option value="Economy">Economy</option>
                                <option value="Comfort EV">Comfort EV</option>
                                <option value="Luxury Limousine">Luxury Limousine</option>
                              </select>
                            </div>
                          )}

                          {/* Full-width centered Photo + Video upload/capture & previews + Register CTA */}
                          <div className="flex flex-col items-center justify-center gap-2.5 pt-2 w-full">
                            <label className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5 shadow-2xs">
                              <span>📷 Upload / Take {sec.label} Photos ({draft.media.length})</span>
                              <input
                                type="file"
                                accept="image/*"
                                capture="environment"
                                multiple
                                className="hidden"
                                onChange={(e) => {
                                  if (e.target.files && e.target.files.length > 0) {
                                    const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                                    updateDriverDraft(sec.type, { media: [...urls, ...draft.media] });
                                  }
                                }}
                              />
                            </label>

                            <label className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5 shadow-2xs">
                              <span>🎬 Upload / Take {sec.label} Videos ({draft.videoMedia.length})</span>
                              <input
                                type="file"
                                accept="video/*"
                                capture="environment"
                                multiple
                                className="hidden"
                                onChange={(e) => {
                                  if (e.target.files && e.target.files.length > 0) {
                                    const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                                    updateDriverDraft(sec.type, { videoMedia: [...urls, ...draft.videoMedia] });
                                  }
                                }}
                              />
                            </label>

                            {(draft.media.length > 0 || draft.videoMedia.length > 0) && (
                              <div className="flex flex-wrap items-center justify-center gap-2 w-full pt-1">
                                {draft.media.map((url, mIdx) => (
                                  <div key={`draft-img-${sec.type}-${mIdx}`} className="relative">
                                    <img
                                      src={url}
                                      alt={`${sec.label} Preview ${mIdx + 1}`}
                                      className="w-20 h-14 object-cover rounded-lg border border-neutral-300"
                                    />
                                    <button
                                      type="button"
                                      onClick={() =>
                                        updateDriverDraft(sec.type, {
                                          media: draft.media.filter((_, i) => i !== mIdx)
                                        })
                                      }
                                      aria-label="Remove photo"
                                      className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                    >
                                      ×
                                    </button>
                                  </div>
                                ))}
                                {draft.videoMedia.map((vUrl, vIdx) => (
                                  <div key={`draft-vid-${sec.type}-${vIdx}`} className="relative">
                                    <video
                                      src={vUrl}
                                      controls
                                      className="w-28 h-16 rounded-lg border border-neutral-300 bg-black"
                                    />
                                    <button
                                      type="button"
                                      onClick={() =>
                                        updateDriverDraft(sec.type, {
                                          videoMedia: draft.videoMedia.filter((_, i) => i !== vIdx)
                                        })
                                      }
                                      aria-label="Remove video"
                                      className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] flex items-center justify-center cursor-pointer"
                                    >
                                      ×
                                    </button>
                                  </div>
                                ))}
                              </div>
                            )}

                            <button
                              type="submit"
                              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm cursor-pointer transition-colors flex items-center justify-center text-center"
                            >
                              Register {sec.label} (1 Max)
                            </button>
                          </div>
                        </form>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Driver Payout Final Currencies Selector */}
              <div className="space-y-2 pt-2 border-t border-neutral-200 text-left">
                <label className="text-[10px] font-bold uppercase font-mono text-neutral-500 text-center block">
                  Search &amp; Choose Driver Payout Final Currencies (Up to 5)
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                  <input
                    type="text"
                    value={currencySearchQuery}
                    onChange={(e) => setCurrencySearchQuery(e.target.value)}
                    placeholder="Search any platform currency (e.g. AFNL, FNL-GOLD)..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
                  {ALL_PLATFORM_CURRENCIES
                    .filter(c => c.toLowerCase().includes(currencySearchQuery.toLowerCase()))
                    .map(curr => {
                      const isSelected = driverCurrencies.includes(curr);
                      return (
                        <button
                          key={curr}
                          type="button"
                          onClick={() => {
                            let next = driverCurrencies;
                            if (isSelected && driverCurrencies.length > 1) {
                              next = driverCurrencies.filter(c => c !== curr);
                            } else if (!isSelected && driverCurrencies.length < 5) {
                              next = [...driverCurrencies, curr];
                            }
                            setDriverCurrencies(next);
                            try {
                              localStorage.setItem(`final_finance_driver_currencies_${userId}`, JSON.stringify(next));
                            } catch {}
                          }}
                          className={`p-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            isSelected ? 'bg-emerald-50 border-emerald-500 text-emerald-950' : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                          }`}
                        >
                          {curr} {isSelected ? '✓' : ''}
                        </button>
                      );
                    })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* WARNING MODAL FOR CANCELLING RIDE AFTER 2 MINUTES     */}
      {/* ==================================================== */}
      {showCancelWarningModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-xl text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-neutral-900">Late Cancellation Warning</h3>
            <p className="text-xs text-neutral-600">
              The 2-minute free cancellation window has expired. If you cancel this ride now, you will be charged a **10% cancellation fee** of the original ride fare.
            </p>
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowCancelWarningModal(false);
                  setPendingCancelRideId(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold cursor-pointer"
              >
                Keep Ride
              </button>
              <button
                type="button"
                onClick={() => pendingCancelRideId && executeCancelRide(pendingCancelRideId, true)}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer shadow-sm"
              >
                Confirm &amp; Pay 10% Fee
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* RATING & COMMENT MODAL                                */}
      {/* ==================================================== */}
      {(ratingModalRideId || ratingModalDeliveryId) && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-xl text-center">
            <h3 className="text-base font-bold text-neutral-900">Rate Driver &amp; Leave Review</h3>
            <div className="flex items-center justify-center gap-2">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setReviewRating(star)}
                  className="p-1 cursor-pointer focus:outline-hidden"
                >
                  <Star className={`w-8 h-8 ${star <= reviewRating ? 'text-amber-500 fill-amber-500' : 'text-neutral-300'}`} />
                </button>
              ))}
            </div>
            <textarea
              value={reviewComment}
              onChange={(e) => setReviewComment(e.target.value)}
              placeholder="Leave a comment about your trip or delivery experience..."
              className="w-full p-3 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 outline-none focus:border-indigo-500 h-24 resize-none"
            ></textarea>
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setRatingModalRideId(null);
                  setRatingModalDeliveryId(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-neutral-100 text-neutral-800 text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveReview}
                className="flex-1 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold cursor-pointer shadow-sm"
              >
                Submit Review
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* DELIVERY PROOF MODAL (PHOTOS & VIDEOS CAPTURE/UPLOAD) */}
      {/* ==================================================== */}
      {proofModalContractId && (() => {
        const targetContract = deliveryContracts.find(c => c.id === proofModalContractId);
        if (!targetContract) return null;
        return (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-xl text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-neutral-900">
                  Proof of Delivery · Order #{targetContract.orderNumber}
                </h3>
                <p className="text-xs text-neutral-500">
                  Take or upload photos and videos showing handover at {targetContract.deliveryAddress} before marking delivered.
                </p>
              </div>

              <div className="flex flex-col items-center justify-center gap-2.5 w-full">
                <label className="w-full py-2.5 px-4 rounded-xl bg-neutral-50 hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5">
                  <span>📷 Take / Upload Proof Photos ({deliveryProofPhotos.length})</span>
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files.length > 0) {
                        const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                        setDeliveryProofPhotos(prev => [...urls, ...prev]);
                      }
                    }}
                  />
                </label>

                <label className="w-full py-2.5 px-4 rounded-xl bg-neutral-50 hover:bg-neutral-100 border border-neutral-300 text-xs font-bold text-neutral-800 cursor-pointer flex items-center justify-center text-center gap-1.5">
                  <span>🎬 Take / Upload Proof Videos ({deliveryProofVideos.length})</span>
                  <input
                    type="file"
                    accept="video/*"
                    capture="environment"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files.length > 0) {
                        const urls = Array.from(e.target.files).map(f => URL.createObjectURL(f));
                        setDeliveryProofVideos(prev => [...urls, ...prev]);
                      }
                    }}
                  />
                </label>
              </div>

              {(deliveryProofPhotos.length > 0 || deliveryProofVideos.length > 0) && (
                <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1 max-h-48 overflow-y-auto">
                  {deliveryProofPhotos.map((pUrl, idx) => (
                    <div key={`modal-photo-${idx}`} className="relative">
                      <img
                        src={pUrl}
                        alt={`Proof Photo ${idx + 1}`}
                        className="w-24 h-18 object-cover rounded-xl border border-emerald-200"
                      />
                      <button
                        type="button"
                        onClick={() => setDeliveryProofPhotos(prev => prev.filter((_, i) => i !== idx))}
                        aria-label="Remove proof photo"
                        className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-rose-600 text-white text-xs flex items-center justify-center cursor-pointer"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                  {deliveryProofVideos.map((vUrl, idx) => (
                    <div key={`modal-vid-${idx}`} className="relative">
                      <video
                        src={vUrl}
                        controls
                        className="w-36 h-20 rounded-xl border border-emerald-200 bg-black"
                      />
                      <button
                        type="button"
                        onClick={() => setDeliveryProofVideos(prev => prev.filter((_, i) => i !== idx))}
                        aria-label="Remove proof video"
                        className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-rose-600 text-white text-xs flex items-center justify-center cursor-pointer"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex flex-col gap-2 pt-2 w-full">
                <button
                  type="button"
                  onClick={() =>
                    handleCompleteDelivery(targetContract.id, {
                      photos: deliveryProofPhotos,
                      videos: deliveryProofVideos
                    })
                  }
                  className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shadow-sm"
                >
                  Confirm &amp; Mark Delivered (+{targetContract.deliveryFee} {targetContract.currency})
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setProofModalContractId(null);
                    setDeliveryProofPhotos([]);
                    setDeliveryProofVideos([]);
                  }}
                  className="w-full py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
