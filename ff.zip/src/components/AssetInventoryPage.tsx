import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { 
  PieChart, 
  Wallet, 
  RefreshCw, 
  Coins, 
  Hexagon, 
  DollarSign, 
  Bitcoin, 
  Archive, 
  Briefcase, 
  TrendingUp, 
  CreditCard,
  ArrowLeft,
  Search,
  Filter,
  BarChart3,
  ShieldCheck,
  Check,
  Layers,
  ArrowDownLeft,
  ArrowUpRight,
  ExternalLink,
  SlidersHorizontal,
  Building2,
  Clock
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { UserWalletData, BarterGoodItem, BarterServiceItem, FinalCoinItem, StableCoinItem, FiatCurrencyItem, CryptoCurrencyItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { INITIAL_STOCKS, INITIAL_USER_STOCK_POSITIONS } from '../data/stocksData';
import { StockItem, StockPosition } from '../types/stocks';
import { getStoredStockPositions } from '../utils/stockWalletBridge';
import { getAllLoans, LoanRecord } from '../services/loanService';
import { recordLedgerTransaction } from '../utils/universalLedgerBridge';
import { UniversalLedgerItem } from '../types/ledger';
import { AccountPayModal } from './dashboard/AccountPayModal';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { PieChart as RePieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';

export type InventoryTab = 'overview' | 'stocks' | 'fiat' | 'stable' | 'final' | 'crypto' | 'barter';

export interface AssetInventoryPageProps {
  currentUser: AuthSession;
  onNavigateBack?: () => void;
  backLabel?: string;
  initialTab?: InventoryTab;
  onOpenDepositModal?: (vault?: any) => void;
  onOpenInstantSwap?: () => void;
  onOpenBarterModal?: (listing?: any) => void;
  onSelectStock?: (stock: StockItem) => void;
}

export const AssetInventoryPage: React.FC<AssetInventoryPageProps> = ({ 
  currentUser, 
  onNavigateBack, 
  backLabel = 'Back to Dashboard',
  initialTab = 'overview',
  onOpenDepositModal,
  onOpenInstantSwap,
  onOpenBarterModal,
  onSelectStock
}) => {
  const userId = currentUser?.id || 'guest';
  const [activeTab, setActiveTab] = useState<InventoryTab>(initialTab);
  const [barterSubTab, setBarterSubTab] = useState<'goods' | 'services'>('goods');

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Live Wallet Data
  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(userId));

  // Live Stock Positions & Stocks
  const [stocks] = useState<StockItem[]>(INITIAL_STOCKS);
  const [positions, setPositions] = useState<StockPosition[]>(() => 
    getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS)
  );

  // Live Liabilities / Debt
  const [debt, setDebt] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(`final_debt_${userId}`);
      if (stored !== null) return Number(stored);
    } catch {}
    return 140621.03; // Default liability
  });

  // Loans from loanService
  const [loansVersion, setLoansVersion] = useState(0);
  const allLoans = useMemo(() => getAllLoans(), [loansVersion]);

  const activeBorrowedLoans = useMemo(() => {
    return allLoans.filter(l => 
      (l.borrowerId === userId || l.borrowerHandle === `@${userId}`) && l.status === 'active'
    );
  }, [allLoans, userId]);

  const activeLentLoans = useMemo(() => {
    return allLoans.filter(l => 
      (l.lenderId === userId || l.lenderHandle === `@${userId}`) && l.status === 'active'
    );
  }, [allLoans, userId]);

  const borrowedLoansUSD = useMemo(() => {
    return activeBorrowedLoans.reduce((sum, l) => sum + (l.coinSymbol === 'AFNL' ? 0 : l.amount), 0);
  }, [activeBorrowedLoans]);

  const lentLoansUSD = useMemo(() => {
    return activeLentLoans.reduce((sum, l) => sum + (l.coinSymbol === 'AFNL' ? 0 : l.amount), 0);
  }, [activeLentLoans]);

  // Modals & Feedback
  const [isPayDebtModalOpen, setIsPayDebtModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  // Re-fetch all dynamic data
  const refreshAllData = useCallback(() => {
    setIsRefreshing(true);
    setWalletData(getStoredUserWallets(userId));
    setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
    setLoansVersion(v => v + 1);

    try {
      const stored = localStorage.getItem(`final_debt_${userId}`);
      if (stored !== null) setDebt(Number(stored));
    } catch {}

    setTimeout(() => setIsRefreshing(false), 400);
  }, [userId]);

  // Synchronize across events
  useEffect(() => {
    const handleWalletUpdate = () => {
      setWalletData(getStoredUserWallets(userId));
    };
    const handleStockUpdate = () => {
      setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
    };
    const handleDebtUpdate = (e: any) => {
      if (e.detail?.debt !== undefined) {
        setDebt(Number(e.detail.debt));
      } else {
        try {
          const stored = localStorage.getItem(`final_debt_${userId}`);
          if (stored !== null) setDebt(Number(stored));
        } catch {}
      }
    };
    const handleLoansUpdate = () => {
      setLoansVersion(v => v + 1);
    };

    window.addEventListener('final_finance_wallets_updated', handleWalletUpdate);
    window.addEventListener('final_finance_stock_positions_updated', handleStockUpdate);
    window.addEventListener('final_debt_updated', handleDebtUpdate);
    window.addEventListener('final_finance_loans_updated', handleLoansUpdate);
    window.addEventListener('final_finance_listings_updated', handleWalletUpdate);
    window.addEventListener('storage', refreshAllData);

    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleWalletUpdate);
      window.removeEventListener('final_finance_stock_positions_updated', handleStockUpdate);
      window.removeEventListener('final_debt_updated', handleDebtUpdate);
      window.removeEventListener('final_finance_loans_updated', handleLoansUpdate);
      window.removeEventListener('final_finance_listings_updated', handleWalletUpdate);
      window.removeEventListener('storage', refreshAllData);
    };
  }, [userId, refreshAllData]);

  // Debt payment handling with ledger record and wallet deduction
  const handleDebtPayment = (paymentAmount: number, sourceLabel: string = 'Reserve Bank Account') => {
    const newDebt = Math.max(0, debt - paymentAmount);
    setDebt(newDebt);

    // Save debt
    try {
      localStorage.setItem(`final_debt_${userId}`, newDebt.toString());
      window.dispatchEvent(new CustomEvent('final_debt_updated', { detail: { debt: newDebt } }));
    } catch (err) {
      console.warn('Failed to save debt from inventory', err);
    }

    // Deduct from fiat cash if available
    const currentWallets = getStoredUserWallets(userId);
    const updatedFiat = [...currentWallets.fiatCurrencies];
    if (updatedFiat.length > 0 && updatedFiat[0].balance > 0) {
      updatedFiat[0] = {
        ...updatedFiat[0],
        balance: Math.max(0, updatedFiat[0].balance - paymentAmount),
      };
      const updatedWallets: UserWalletData = {
        ...currentWallets,
        fiatCurrencies: updatedFiat,
      };
      setWalletData(updatedWallets);
      saveStoredUserWallets(userId, updatedWallets);
    }

    // Record formal receipt into Universal Ledger
    try {
      const now = new Date();
      const randomHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      const ledgerItem: UniversalLedgerItem = {
        id: `tx-inv-settle-${Date.now()}`,
        receiptNumber: `REC-${now.getFullYear()}-ST-${Math.floor(100000 + Math.random() * 900000)}`,
        timestamp: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} UTC`,
        dateIso: now.toISOString(),
        type: 'payment_settlement',
        category: 'money_outflow',
        mode: 'fiat',
        title: 'Settlement & Debt Obligation Payment',
        description: `Settled outstanding debt liability against sovereign account inventory using ${sourceLabel}`,
        amountUSD: paymentAmount,
        feeUSD: 0.00,
        netAmountUSD: paymentAmount,
        sourceOrDestination: sourceLabel,
        counterpartyOrIssuer: 'Sovereign Clearing Node Corp',
        status: 'Audited',
        taxYear: now.getFullYear(),
        taxClassification: {
          taxableEvent: false,
          taxableAmountUSD: 0,
          formMapping: 'Non-Taxable Transfer',
          holdingPeriod: 'N/A',
          irsCategoryNote: 'Repayment of principal obligation and settlement liabilities. Not taxable income.'
        },
        cryptographicHash: `0x${randomHex}`,
        clearingNode: 'Node #4810-CH',
        signature: `SIG_${Math.floor(100000 + Math.random() * 900000)}_ECDSA`
      };
      recordLedgerTransaction(userId, ledgerItem);
    } catch (e) {
      console.warn('Failed to record inventory debt payment in ledger', e);
    }

    showToast(`Payment of $${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} authorized. Liabilities reduced successfully.`);
    dispatchGlobalNotification({
      title: 'Liability Payment Authorized',
      description: `Settled $${paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} USD in obligations using ${sourceLabel}.`,
      type: 'wallet',
      targetTab: 'asset_inventory',
      amount: paymentAmount,
      currency: 'USD',
      showToast: false,
      tone: 'success',
    });
  };

  // Calculations
  const stocksTotalUSD = useMemo(() => {
    return positions.reduce((s, p) => {
      const stk = stocks.find(st => st.ticker === p.ticker);
      return s + p.shares * (stk ? stk.price : p.avgCostUSD);
    }, 0);
  }, [positions, stocks]);

  const stocksTotalGainUSD = useMemo(() => {
    return positions.reduce((s, p) => s + (p.totalGainUSD || 0), 0);
  }, [positions]);

  const fiatTotalUSD = useMemo(() => 
    walletData.fiatCurrencies.reduce((acc, curr) => acc + (curr.balance * curr.exchangeRateToUSD), 0), 
    [walletData]
  );
  const fiatTotalUnits = useMemo(() => 
    walletData.fiatCurrencies.reduce((acc, curr) => acc + curr.balance, 0), 
    [walletData]
  );
  
  const stableTotalUSD = useMemo(() => 
    walletData.stableCoins.reduce((acc, curr) => acc + (curr.balance * curr.unitPriceUSD), 0), 
    [walletData]
  );
  const stableTotalUnits = useMemo(() => 
    walletData.stableCoins.reduce((acc, curr) => acc + curr.balance, 0), 
    [walletData]
  );
  
  const finalTotalUnits = useMemo(() => 
    walletData.finalCoins.reduce((acc, curr) => acc + curr.balance, 0), 
    [walletData]
  );
  
  const cryptoTotalUSD = useMemo(() => 
    walletData.cryptoCurrencies.reduce((acc, curr) => acc + (curr.balance * curr.unitPriceUSD), 0), 
    [walletData]
  );
  const cryptoTotalUnits = useMemo(() => 
    walletData.cryptoCurrencies.reduce((acc, curr) => acc + curr.balance, 0), 
    [walletData]
  );

  const barterGoodsTotalUnits = useMemo(() => 
    (walletData.barterGoods || []).reduce((acc, curr) => acc + curr.quantity, 0), 
    [walletData]
  );
  const barterServicesTotalCount = useMemo(() => 
    (walletData.barterServices || []).length, 
    [walletData]
  );
  
  const barterGoodsTotalUSD = useMemo(() => 
    (walletData.barterGoods || []).reduce((acc, curr) => acc + (curr.quantity * (curr.estimatedUnitValue || 0)), 0), 
    [walletData]
  );
  
  // Total Vault Gross Assets (Priced capital + Receivables)
  const totalVaultCapital = fiatTotalUSD + stableTotalUSD + cryptoTotalUSD + stocksTotalUSD + barterGoodsTotalUSD + lentLoansUSD;
  const totalLiabilities = debt + borrowedLoansUSD;
  const totalNetWorth = totalVaultCapital - totalLiabilities;

  // Chart data
  const chartData = useMemo(() => [
    { name: 'Stocks & Equities', value: stocksTotalUSD, color: '#6366f1' },
    { name: 'Crypto-Currency', value: cryptoTotalUSD, color: '#8b5cf6' },
    { name: 'Fiat Treasury', value: fiatTotalUSD, color: '#0ea5e9' },
    { name: 'Stable Coins', value: stableTotalUSD, color: '#10b981' },
    { name: 'Physical Commodities', value: barterGoodsTotalUSD, color: '#f59e0b' },
    { name: 'Loans Receivable', value: lentLoansUSD, color: '#059669' },
  ].filter(d => d.value > 0), [stocksTotalUSD, cryptoTotalUSD, fiatTotalUSD, stableTotalUSD, barterGoodsTotalUSD, lentLoansUSD]);

  // Filtered Barter Goods
  const filteredBarterGoods = useMemo(() => {
    return (walletData.barterGoods || []).filter(item => {
      const matchesSearch = searchQuery === '' || 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = categoryFilter === 'all' || 
        (categoryFilter === 'bullion' && item.category?.toLowerCase().includes('bullion')) ||
        (categoryFilter === 'luxury' && item.category?.toLowerCase().includes('luxury')) ||
        (categoryFilter === 'hardware' && (item.category?.toLowerCase().includes('hardware') || item.category?.toLowerCase().includes('compute'))) ||
        (categoryFilter === 'acquired' && item.id.includes('acq'));

      return matchesSearch && matchesCategory;
    });
  }, [walletData.barterGoods, searchQuery, categoryFilter]);

  // Filtered Barter Services
  const filteredBarterServices = useMemo(() => {
    return (walletData.barterServices || []).filter(item => {
      return searchQuery === '' ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.deliverableDescription.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [walletData.barterServices, searchQuery]);

  const TABS: { id: InventoryTab; label: string; icon: React.ElementType; count?: number | string }[] = [
    { id: 'overview', label: 'Portfolio Overview', icon: PieChart },
    { id: 'stocks', label: 'Stocks & Equities', icon: BarChart3, count: positions.length },
    { id: 'crypto', label: 'Crypto-Currency', icon: Bitcoin, count: walletData.cryptoCurrencies.length },
    { id: 'fiat', label: 'Fiat Treasury', icon: DollarSign, count: walletData.fiatCurrencies.length },
    { id: 'barter', label: 'Goods & Services', icon: RefreshCw, count: barterGoodsTotalUnits + barterServicesTotalCount },
    { id: 'stable', label: 'Stable Coins', icon: Coins, count: walletData.stableCoins.length },
    { id: 'final', label: 'Final Coins', icon: Hexagon, count: `${(finalTotalUnits / 1000).toFixed(0)}k` },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-left">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-semibold shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Account Pay Modal */}
      <AccountPayModal
        isOpen={isPayDebtModalOpen}
        onClose={() => setIsPayDebtModalOpen(false)}
        negativeBalance={-totalLiabilities}
        walletData={walletData}
        onConfirmPayment={handleDebtPayment}
      />

      {/* Top Sticky Header */}
      <div className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {onNavigateBack && (
              <button
                type="button"
                onClick={onNavigateBack}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer border border-slate-200"
                title={backLabel}
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">{backLabel}</span>
                <span className="sm:hidden">Back</span>
              </button>
            )}
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600">
                <Archive className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <span>Asset Inventory</span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200/80 hidden sm:inline-flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Live Vault Sync
                  </span>
                </h1>
                <p className="text-[11px] text-slate-500 hidden sm:block">
                  Universal sovereign registry of commodities, physical bullion, securities, digital assets & currencies
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={refreshAllData}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold shadow-2xs transition-all cursor-pointer disabled:opacity-50"
              title="Force Refresh Data from Storage"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-indigo-600' : 'text-slate-500'}`} />
              <span className="hidden sm:inline">Sync Assets</span>
            </button>
            {onOpenDepositModal && (
              <button
                type="button"
                onClick={() => onOpenDepositModal()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer"
              >
                <ArrowDownLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Deposit Vault Asset</span>
                <span className="sm:hidden">Deposit</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col lg:flex-row gap-6">
        {/* Left Sidebar */}
        <div className="lg:w-72 shrink-0">
          <div className="bg-white rounded-3xl border border-slate-200 p-4 shadow-xs sticky top-24 space-y-4">
            {/* Executive Valuation Summary */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-3">
              <div className="space-y-0.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Total Vault Capital
                </span>
                <p className="text-lg font-bold text-slate-900 font-mono">
                  ${totalVaultCapital.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-[10px] text-slate-500">Gross asset valuation</p>
              </div>

              {totalLiabilities > 0 && (
                <div className="pt-2 border-t border-slate-200/60 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider block">
                      Outstanding Debt
                    </span>
                    <span className="text-[9px] font-bold text-rose-600 bg-rose-50 border border-rose-200/60 px-1.5 py-0.5 rounded">
                      DUE
                    </span>
                  </div>
                  <p className="text-sm font-bold text-rose-600 font-mono">
                    -${totalLiabilities.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsPayDebtModalOpen(true)}
                    className="w-full mt-1 py-1.5 px-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Pay Off Debt</span>
                  </button>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200/60 space-y-0.5">
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider block">
                  Net Asset Value (NAV)
                </span>
                <p className="text-2xl font-extrabold text-slate-900 font-mono">
                  ${totalNetWorth.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="space-y-1">
              {TABS.map(tab => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                      <span>{tab.label}</span>
                    </div>
                    {tab.count !== undefined && (
                      <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md font-bold ${
                        isActive ? 'bg-indigo-700 text-white' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Right Content Area */}
        <div className="flex-1 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Asset Allocation Chart Card */}
              <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-8">
                <div className="w-full md:w-1/2 h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={75}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip 
                        formatter={(value: any) => [`$${Number(value || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Valuation']}
                      />
                      <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '10px' }} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>

                <div className="w-full md:w-1/2 grid grid-cols-2 gap-3">
                  {[
                    { label: 'Public Equities', value: stocksTotalUSD, type: 'currency', color: 'text-indigo-600', sub: `${positions.length} active positions` },
                    { label: 'Crypto Assets', value: cryptoTotalUSD, type: 'currency', color: 'text-purple-600', sub: 'Glacier Cold + Hot Wallets' },
                    { label: 'Fiat Reserves', value: fiatTotalUSD, type: 'currency', color: 'text-sky-600', sub: `${walletData.fiatCurrencies.length} Commercial Accounts` },
                    { label: 'Stablecoins', value: stableTotalUSD, type: 'currency', color: 'text-emerald-600', sub: '5.4% Weighted APY' },
                    { label: 'Physical Commodities', value: barterGoodsTotalUSD, type: 'currency', color: 'text-amber-600', sub: `${barterGoodsTotalUnits} Physical Units Held` },
                    { label: 'Loans Receivable', value: lentLoansUSD, type: 'currency', color: 'text-emerald-700', sub: `${activeLentLoans.length} Loans Active` },
                  ].map((stat, i) => (
                    <div key={i} className="bg-slate-50 p-3 rounded-2xl border border-slate-100 flex flex-col justify-between">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">{stat.label}</p>
                      <div>
                        <p className={`text-sm sm:text-base font-bold font-mono ${stat.color}`}>
                          ${stat.value.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </p>
                        <p className="text-[10px] text-slate-500 mt-0.5">{stat.sub}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('stocks')}
                  className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-sm transition-all text-left flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                      <BarChart3 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Manage Stocks</h4>
                      <p className="text-[11px] text-slate-500">{positions.length} equities held</p>
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-colors" />
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('barter')}
                  className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-amber-300 hover:shadow-sm transition-all text-left flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                      <Archive className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Physical Vault Assets</h4>
                      <p className="text-[11px] text-slate-500">{barterGoodsTotalUnits} units &amp; gold bullion</p>
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-amber-600 transition-colors" />
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('crypto')}
                  className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-purple-300 hover:shadow-sm transition-all text-left flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-purple-50 text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                      <Bitcoin className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Digital Currency Vault</h4>
                      <p className="text-[11px] text-slate-500">${cryptoTotalUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })} valuation</p>
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-purple-600 transition-colors" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: STOCKS & EQUITIES */}
          {activeTab === 'stocks' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-indigo-600" />
                    Stocks &amp; Public Equities ({positions.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Live valuation of public shares, dividend allocations, and personal/corporate equity
                  </p>
                </div>
                <div className="font-mono text-left sm:text-right">
                  <p className="text-base font-bold text-slate-900">${stocksTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className={`text-xs font-bold ${stocksTotalGainUSD >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {stocksTotalGainUSD >= 0 ? '+' : ''}${stocksTotalGainUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} Unrealized P&amp;L
                  </p>
                </div>
              </div>

              {positions.length === 0 ? (
                <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
                  <BarChart3 className="w-10 h-10 text-slate-300 mx-auto" />
                  <h3 className="font-bold text-slate-800 text-sm">No Stock Positions Held</h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    You currently have no open equities. Open the Stock Market Exchange to acquire sovereign or market equities.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {positions.map((pos) => {
                    const stk = stocks.find(s => s.ticker === pos.ticker);
                    const currentPrice = stk ? stk.price : pos.currentPriceUSD;
                    const positionVal = pos.shares * currentPrice;
                    const costBasis = pos.shares * pos.avgCostUSD;
                    const gainUSD = positionVal - costBasis;
                    const gainPct = costBasis > 0 ? (gainUSD / costBasis) * 100 : 0;

                    return (
                      <div
                        key={pos.ticker}
                        onClick={() => {
                          if (stk && onSelectStock) onSelectStock(stk);
                        }}
                        className={`bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between space-y-4 ${
                          stk && onSelectStock ? 'cursor-pointer' : ''
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold font-mono text-sm px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-100">
                                {pos.ticker}
                              </span>
                              <span className="text-xs text-slate-500">{pos.sector}</span>
                            </div>
                            <h3 className="font-bold text-slate-900 text-sm mt-1">{pos.name}</h3>
                          </div>
                          <div className="text-right font-mono">
                            <p className="text-sm font-bold text-slate-900">${positionVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                            <p className="text-[11px] text-slate-500">{pos.shares.toLocaleString()} shares</p>
                          </div>
                        </div>

                        <div className="pt-3 border-t border-slate-100 grid grid-cols-3 gap-2 text-xs font-mono">
                          <div>
                            <span className="text-[10px] text-slate-400 block uppercase">Avg Cost</span>
                            <span className="font-bold text-slate-700">${pos.avgCostUSD.toFixed(2)}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400 block uppercase">Market Price</span>
                            <span className="font-bold text-slate-900">${currentPrice.toFixed(2)}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] text-slate-400 block uppercase">Return</span>
                            <span className={`font-bold ${gainUSD >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {gainUSD >= 0 ? '+' : ''}${gainUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })} ({gainPct.toFixed(1)}%)
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PHYSICAL GOODS & COMMODITIES (BARTER) */}
          {activeTab === 'barter' && (
            <div className="space-y-6">
              {/* Controls Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-amber-600" />
                    Physical Custody, Commodities &amp; Retainers
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Gold bullion, luxury assets, hardware nodes &amp; service contracts held in sovereign freeport custody
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200">
                    <button
                      type="button"
                      onClick={() => setBarterSubTab('goods')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        barterSubTab === 'goods' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Goods &amp; Bullion ({barterGoodsTotalUnits})
                    </button>
                    <button
                      type="button"
                      onClick={() => setBarterSubTab('services')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        barterSubTab === 'services' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Services ({barterServicesTotalCount})
                    </button>
                  </div>
                  {onOpenBarterModal && (
                    <button
                      type="button"
                      onClick={() => onOpenBarterModal()}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-xs transition-all cursor-pointer whitespace-nowrap"
                    >
                      Propose Trade
                    </button>
                  )}
                </div>
              </div>

              {/* Search & Filters Toolbar */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search goods by name, location, hallmark, or description..."
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-white border border-slate-200 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-slate-900"
                  />
                </div>
                {barterSubTab === 'goods' && (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    {[
                      { id: 'all', label: 'All Items' },
                      { id: 'bullion', label: 'Bullion & Gold' },
                      { id: 'luxury', label: 'Luxury' },
                      { id: 'hardware', label: 'Compute & Tech' },
                      { id: 'acquired', label: 'Acquired via Market' }
                    ].map(f => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setCategoryFilter(f.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                          categoryFilter === f.id
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Goods Grid */}
              {barterSubTab === 'goods' && (
                <div className="space-y-4">
                  {filteredBarterGoods.length === 0 ? (
                    <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-2">
                      <Archive className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-xs text-slate-500">No goods match your search or filter criteria.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {filteredBarterGoods.map(good => (
                        <div 
                          key={good.id} 
                          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all flex flex-col sm:flex-row gap-5"
                        >
                          {good.imageUrl && (
                            <div className="w-full sm:w-36 h-36 rounded-xl overflow-hidden shrink-0 bg-slate-100 border border-slate-200/80">
                              <img src={good.imageUrl} alt={good.name} className="w-full h-full object-cover" />
                            </div>
                          )}
                          <div className="flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-2">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
                                      {good.category}
                                    </span>
                                    <span className="text-xs text-slate-500">&bull; {good.condition}</span>
                                    {good.id.includes('acq') && (
                                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                                        Marketplace Acquired
                                      </span>
                                    )}
                                  </div>
                                  <h3 className="font-bold text-slate-900 text-base mt-1">{good.name}</h3>
                                </div>
                                <div className="text-left sm:text-right font-mono">
                                  <p className="font-bold text-slate-900 text-base">
                                    ${(good.estimatedUnitValue * good.quantity).toLocaleString()}
                                  </p>
                                  <p className="text-xs text-slate-500">
                                    ${good.estimatedUnitValue.toLocaleString()} / {good.unitLabel.replace(/s$/, '')}
                                  </p>
                                </div>
                              </div>
                              <p className="text-xs text-slate-600 line-clamp-2 mb-3 leading-relaxed">
                                {good.description}
                              </p>
                            </div>

                            <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                              <div className="flex flex-wrap items-center gap-1.5">
                                {good.location && (
                                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                                    📍 {good.location}
                                  </span>
                                )}
                                {good.sku && (
                                  <span className="text-[10px] font-mono text-slate-500 px-2 py-0.5 rounded-md bg-slate-50 border border-slate-200/60">
                                    SKU: {good.sku}
                                  </span>
                                )}
                                {good.tags?.map((t, idx) => (
                                  <span key={idx} className="text-[10px] font-semibold text-slate-500 px-2 py-0.5 rounded-md bg-slate-50">
                                    #{t}
                                  </span>
                                ))}
                              </div>
                              <span className="text-xs font-bold font-mono text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                                {good.quantity} {good.unitLabel} available
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Services Grid */}
              {barterSubTab === 'services' && (
                <div className="space-y-4">
                  {filteredBarterServices.length === 0 ? (
                    <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-2">
                      <TrendingUp className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-xs text-slate-500">No services match your search query.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {filteredBarterServices.map(service => (
                        <div key={service.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                            <div>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-800 border border-indigo-200">
                                {service.category}
                              </span>
                              <h3 className="font-bold text-slate-900 text-base mt-1">{service.name}</h3>
                            </div>
                            <div className="text-left sm:text-right font-mono">
                              <p className="font-bold text-slate-900 text-base">
                                ${(service.hourlyRateValue * service.availableUnits).toLocaleString()}
                              </p>
                              <p className="text-xs text-slate-500">
                                ${service.hourlyRateValue.toLocaleString()} / {service.unitType.replace(/s$/, '')}
                              </p>
                            </div>
                          </div>
                          <p className="text-xs text-slate-600 leading-relaxed">{service.deliverableDescription}</p>
                          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                            <div className="flex flex-wrap gap-1.5">
                              {service.skills?.map((sk, idx) => (
                                <span key={idx} className="text-[10px] font-semibold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md">
                                  {sk}
                                </span>
                              ))}
                            </div>
                            <div className="flex items-center gap-2">
                              {service.turnaroundTime && (
                                <span className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                                  <Clock className="w-3 h-3" />
                                  {service.turnaroundTime}
                                </span>
                              )}
                              <span className="text-xs font-bold font-mono text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-md">
                                {service.availableUnits} {service.unitType}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: FIAT TREASURY */}
          {activeTab === 'fiat' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-sky-600" />
                    Fiat Currency Treasury ({walletData.fiatCurrencies.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Multi-currency commercial checking, escrow &amp; liquid treasury reserves
                  </p>
                </div>
                <div className="font-mono text-left sm:text-right">
                  <p className="text-base font-bold text-slate-900">${fiatTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-xs text-slate-500">{fiatTotalUnits.toLocaleString()} total units</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.fiatCurrencies.map(fiat => (
                  <div key={fiat.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-base font-bold font-mono px-2 py-0.5 rounded-md bg-sky-50 text-sky-700 border border-sky-100">
                            {fiat.code}
                          </span>
                          <span className="text-xs text-slate-500">{fiat.accountType}</span>
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mt-1">{fiat.name}</h3>
                        <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                          <Building2 className="w-3 h-3" />
                          {fiat.institution}
                        </p>
                      </div>
                      <div className="text-right font-mono">
                        <p className="text-base font-bold text-slate-900">{fiat.symbol}{fiat.balance.toLocaleString()}</p>
                        <p className="text-xs text-slate-500">≈ ${(fiat.balance * fiat.exchangeRateToUSD).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: STABLECOINS */}
          {activeTab === 'stable' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Coins className="w-5 h-5 text-emerald-600" />
                    Yield-Bearing Stablecoins ({walletData.stableCoins.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Dollar, gold &amp; euro pegged cash equivalents deployed into institutional custody yield
                  </p>
                </div>
                <div className="font-mono text-left sm:text-right">
                  <p className="text-base font-bold text-slate-900">${stableTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-xs text-emerald-600 font-bold">5.4% Weighted APY</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.stableCoins.map(coin => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold font-mono px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-100">
                            {coin.symbol}
                          </span>
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 uppercase font-mono">
                            {coin.network}
                          </span>
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mt-1">{coin.name}</h3>
                        <p className="text-[11px] text-slate-500 mt-0.5">Peg: {coin.peggedCurrency}</p>
                      </div>
                      <div className="text-right font-mono">
                        <p className="text-base font-bold text-slate-900">{coin.balance.toLocaleString()} {coin.symbol}</p>
                        <p className="text-xs font-bold text-emerald-600">+{coin.yieldAPY}% APY</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: CRYPTO-CURRENCY */}
          {activeTab === 'crypto' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Bitcoin className="w-5 h-5 text-purple-600" />
                    Digital Assets &amp; Crypto Vault ({walletData.cryptoCurrencies.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Glacier cold storage Bitcoin, validator staked Ethereum, and Solana clearing reserves
                  </p>
                </div>
                <div className="font-mono text-left sm:text-right">
                  <p className="text-base font-bold text-slate-900">${cryptoTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-xs text-slate-500">{cryptoTotalUnits.toLocaleString()} units</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.cryptoCurrencies.map(coin => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold font-mono px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-100">
                            {coin.symbol}
                          </span>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            coin.change24h >= 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                          }`}>
                            {coin.change24h > 0 ? '+' : ''}{coin.change24h}% 24h
                          </span>
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mt-1">{coin.name}</h3>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5 truncate max-w-[180px]">
                          {coin.walletAddress}
                        </p>
                      </div>
                      <div className="text-right font-mono">
                        <p className="text-base font-bold text-slate-900">{coin.balance.toLocaleString()} {coin.symbol}</p>
                        <p className="text-xs text-slate-500">≈ ${(coin.balance * coin.unitPriceUSD).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: FINAL COINS */}
          {activeTab === 'final' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Hexagon className="w-5 h-5 text-amber-600" />
                    Final Coins Standard ({walletData.finalCoins.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Non-convertible sovereign protocol units, continuous subsidy grants, and custom creator issuances
                  </p>
                </div>
                <div className="font-mono text-left sm:text-right">
                  <p className="text-base font-bold text-amber-900">{finalTotalUnits.toLocaleString()} AFNL</p>
                  <p className="text-xs text-emerald-600 font-bold">+0.1 AFNL/min active subsidy</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.finalCoins.map(coin => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold font-mono px-2 py-0.5 rounded-md bg-amber-50 text-amber-900 border border-amber-200">
                            {coin.symbol}
                          </span>
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
                            Protocol Native
                          </span>
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mt-1">{coin.name}</h3>
                        <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{coin.utility}</p>
                      </div>
                      <div className="text-right font-mono shrink-0">
                        <p className="text-base font-bold text-slate-900">{coin.balance.toLocaleString()} {coin.symbol}</p>
                        <p className="text-[11px] text-amber-800 font-semibold">Sovereign Standard</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
