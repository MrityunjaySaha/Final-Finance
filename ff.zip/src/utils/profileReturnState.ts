export interface PortfolioTabSnapshot {
  dashboardTab?: string;
  portfolioPrimaryTab?: string;
  portfolioEquitySubTab?: string;
  alpacaStockType?: string;
  alpacaSubTab?: string;
  currenciesMainTab?: string;
}

export interface ProfileReturnAnchor {
  sourceLabel?: string;
  scrollY: number;
  finalCoinId?: string;
  openFinalCoinModal?: boolean;
  listingId?: string;
  restoreActive?: boolean;
}

const PORTFOLIO_TABS_KEY = 'ff_portfolio_tab_snapshot_v1';
const PROFILE_ANCHOR_KEY = 'ff_profile_return_anchor_v1';

export function updatePortfolioTabSnapshot(patch: Partial<PortfolioTabSnapshot>): void {
  try {
    const raw = sessionStorage.getItem(PORTFOLIO_TABS_KEY);
    const current: PortfolioTabSnapshot = raw ? JSON.parse(raw) : {};
    sessionStorage.setItem(PORTFOLIO_TABS_KEY, JSON.stringify({ ...current, ...patch }));
  } catch {
    // Ignore storage errors
  }
}

export function getPortfolioTabSnapshot(): PortfolioTabSnapshot {
  try {
    const raw = sessionStorage.getItem(PORTFOLIO_TABS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setPendingProfileReturnAnchor(anchor: ProfileReturnAnchor): void {
  try {
    sessionStorage.setItem(PROFILE_ANCHOR_KEY, JSON.stringify(anchor));
  } catch {
    // Ignore storage errors
  }
}

export function getProfileReturnAnchor(): ProfileReturnAnchor | null {
  try {
    const raw = sessionStorage.getItem(PROFILE_ANCHOR_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clearProfileReturnAnchor(): void {
  try {
    sessionStorage.removeItem(PROFILE_ANCHOR_KEY);
  } catch {
    // Ignore storage errors
  }
}

export function isRestoreProfileReturnActive(): boolean {
  const anchor = getProfileReturnAnchor();
  return Boolean(anchor?.restoreActive);
}
