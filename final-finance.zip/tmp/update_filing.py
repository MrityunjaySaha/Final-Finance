path = 'src/components/stocks/CelebrityOfficialFilingView.tsx'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace('All ({profile.detailedTransactions.length})', 'All')
content = content.replace('Buys ({buyTransactionsCount})', 'Buys')
content = content.replace('Sells ({sellTransactionsCount})', 'Sells')

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)
print('SUCCESS')
