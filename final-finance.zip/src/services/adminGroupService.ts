export interface AdminMember {
  id: string;
  name: string;
  handle: string;
  email: string;
  role: 'super_admin' | 'admin';
  jobTitle?: string;
  secondaryJobTitle?: string;
  status: 'active' | 'deactivated';
  lastActive: string;
  permissionsCount: number;
}

export interface AdminGroup {
  id: string;
  name: string;
  description: string;
  color: string;
  adminIds: string[]; // List of AdminMember ids
  memberSecondaryTitles?: Record<string, string>; // Maps adminId -> secondaryJobTitle in this group
  createdAt: string;
  updatedAt: string;
}

const ADMIN_MEMBERS_STORAGE_KEY = 'final_finance_admin_directory_v2';
const ADMIN_GROUPS_STORAGE_KEY = 'final_finance_admin_groups_v1';

export const DEFAULT_ADMIN_MEMBERS: AdminMember[] = [
  {
    id: 'adm-1',
    name: 'Ranma (Root Master)',
    handle: '@super_admin_ranma',
    email: 'ranmaanimaker@gmail.com',
    role: 'super_admin',
    jobTitle: 'Chief System Architect',
    status: 'active',
    lastActive: 'Just now',
    permissionsCount: 48,
  },
  {
    id: 'adm-2',
    name: 'Awesome DBZ',
    handle: '@officer_dbz',
    email: 'awesomedbz@gmail.com',
    role: 'admin',
    jobTitle: 'Senior Officer',
    status: 'active',
    lastActive: '2 mins ago',
    permissionsCount: 24,
  },
  {
    id: 'adm-3',
    name: 'Jordan Belfort',
    handle: '@jordan_belfort',
    email: 'jordan@finalfinance.io',
    role: 'admin',
    jobTitle: 'Senior Investment Officer',
    status: 'active',
    lastActive: '15 mins ago',
    permissionsCount: 18,
  },
  {
    id: 'adm-4',
    name: 'Satoshi Nakamoto',
    handle: '@satoshi_nakamoto',
    email: 'satoshi@finalfinance.io',
    role: 'admin',
    jobTitle: 'Cryptographic Reserve Officer',
    status: 'active',
    lastActive: '1 hour ago',
    permissionsCount: 24,
  },
  {
    id: 'adm-5',
    name: 'Elena Rostova',
    handle: '@elena_compliance',
    email: 'elena.rostova@finalfinance.io',
    role: 'admin',
    jobTitle: 'Compliance Lead',
    status: 'active',
    lastActive: '3 hours ago',
    permissionsCount: 16,
  },
  {
    id: 'adm-6',
    name: 'Marcus Vance',
    handle: '@marcus_vance',
    email: 'marcus.vance@finalfinance.io',
    role: 'admin',
    jobTitle: 'Junior Operations Admin',
    status: 'deactivated',
    lastActive: '2 days ago',
    permissionsCount: 0,
  },
];

export function getAdminMembers(): AdminMember[] {
  try {
    const raw = localStorage.getItem(ADMIN_MEMBERS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure all 6 default administrators exist even if user has older local storage
        const existingIds = new Set(parsed.map((m: any) => m.id));
        const merged = [...parsed];
        for (const def of DEFAULT_ADMIN_MEMBERS) {
          if (!existingIds.has(def.id)) {
            merged.push(def);
          }
        }
        const finalized = merged.map((m: any) => ({
          ...m,
          role: m.role === 'super_admin' ? 'super_admin' : 'admin',
          jobTitle: m.jobTitle || (m.role === 'super_admin' ? 'Chief System Architect' : 'Administrator'),
        }));
        if (finalized.length !== parsed.length) {
          saveAdminMembers(finalized);
        }
        return finalized;
      }
    }
  } catch (e) {
    console.warn('Error loading admin members from storage:', e);
  }
  saveAdminMembers(DEFAULT_ADMIN_MEMBERS);
  return DEFAULT_ADMIN_MEMBERS;
}

export function saveAdminMembers(admins: AdminMember[]): void {
  try {
    localStorage.setItem(ADMIN_MEMBERS_STORAGE_KEY, JSON.stringify(admins));
  } catch (e) {
    console.error('Error saving admin members to storage:', e);
  }
}

export function updateAdminMemberTitle(adminId: string, jobTitle: string): AdminMember[] {
  const admins = getAdminMembers();
  const updated = admins.map((a) => (a.id === adminId ? { ...a, jobTitle: jobTitle.trim() } : a));
  saveAdminMembers(updated);
  return updated;
}

export function setAdminMemberStatus(adminId: string, status: 'active' | 'deactivated'): AdminMember[] {
  const admins = getAdminMembers();
  const updated = admins.map((a) => (a.id === adminId ? { ...a, status } : a));
  saveAdminMembers(updated);
  return updated;
}

const DEFAULT_ADMIN_GROUPS: AdminGroup[] = [
  {
    id: 'grp-adm-security',
    name: 'Security & Reserve Oversight',
    description: 'Oversees root protocol upgrades, multi-sig treasury sweeps, and cold vault reserves.',
    color: '#f59e0b', // amber
    adminIds: ['adm-1', 'adm-2', 'adm-4'],
    memberSecondaryTitles: {
      'adm-1': 'Root Key Signer',
      'adm-2': 'Cold Vault Custodian',
      'adm-4': 'Cryptographic Protocol Inspector',
    },
    createdAt: '2024-01-15T08:00:00.000Z',
    updatedAt: '2024-01-15T08:00:00.000Z'
  },
  {
    id: 'grp-adm-compliance',
    name: 'Financial Compliance Council',
    description: 'Coordinates AML/KYC policies, jurisdiction licensing, and regulatory advisories.',
    color: '#8b5cf6', // purple
    adminIds: ['adm-3', 'adm-5'],
    memberSecondaryTitles: {
      'adm-3': 'AML Lead Arbiter',
      'adm-5': 'Regulatory Affairs Inspector',
    },
    createdAt: '2024-01-20T10:30:00.000Z',
    updatedAt: '2024-01-20T10:30:00.000Z'
  },
  {
    id: 'grp-adm-liquidity',
    name: 'VIP Liquidity & Desk Taskforce',
    description: 'Handles high-volume bullion allocations, OTC clearing, and tier-1 partner disputes.',
    color: '#10b981', // emerald
    adminIds: ['adm-2', 'adm-3', 'adm-1'],
    memberSecondaryTitles: {
      'adm-2': 'OTC Desk Director',
      'adm-3': 'VIP Liquidity Allocator',
      'adm-1': 'Treasury Protocol Governor',
    },
    createdAt: '2024-02-05T14:15:00.000Z',
    updatedAt: '2024-02-05T14:15:00.000Z'
  }
];

export function getAdminGroups(): AdminGroup[] {
  try {
    const raw = localStorage.getItem(ADMIN_GROUPS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Error loading admin groups from storage:', e);
  }
  // Initialize with defaults
  saveAdminGroups(DEFAULT_ADMIN_GROUPS);
  return DEFAULT_ADMIN_GROUPS;
}

export function saveAdminGroups(groups: AdminGroup[]): void {
  try {
    localStorage.setItem(ADMIN_GROUPS_STORAGE_KEY, JSON.stringify(groups));
  } catch (e) {
    console.error('Error saving admin groups to storage:', e);
  }
}

export function setGroupMemberSecondaryTitle(
  groupId: string,
  adminId: string,
  secondaryTitle: string
): AdminGroup[] {
  const groups = getAdminGroups();
  const group = groups.find(g => g.id === groupId);
  if (group) {
    if (!group.memberSecondaryTitles) {
      group.memberSecondaryTitles = {};
    }
    const cleanTitle = secondaryTitle.trim();
    if (cleanTitle) {
      group.memberSecondaryTitles[adminId] = cleanTitle;
    } else {
      delete group.memberSecondaryTitles[adminId];
    }
    group.updatedAt = new Date().toISOString();
    saveAdminGroups(groups);
  }
  return groups;
}

export function createAdminGroup(data: {
  name: string;
  description?: string;
  color?: string;
  adminIds?: string[];
}): AdminGroup {
  const groups = getAdminGroups();
  const newGroup: AdminGroup = {
    id: `grp-adm-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    name: data.name.trim(),
    description: data.description?.trim() || '',
    color: data.color || '#3b82f6',
    adminIds: Array.from(new Set(data.adminIds || [])),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const updated = [newGroup, ...groups];
  saveAdminGroups(updated);
  return newGroup;
}

export function updateAdminGroup(
  id: string,
  updates: Partial<Omit<AdminGroup, 'id' | 'createdAt'>>
): AdminGroup | null {
  const groups = getAdminGroups();
  const idx = groups.findIndex(g => g.id === id);
  if (idx === -1) return null;

  const updatedGroup: AdminGroup = {
    ...groups[idx],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  groups[idx] = updatedGroup;
  saveAdminGroups(groups);
  return updatedGroup;
}

export function deleteAdminGroup(id: string): boolean {
  const groups = getAdminGroups();
  const filtered = groups.filter(g => g.id !== id);
  if (filtered.length !== groups.length) {
    saveAdminGroups(filtered);
    return true;
  }
  return false;
}

export function getGroupsForAdmin(adminId: string): AdminGroup[] {
  const groups = getAdminGroups();
  return groups.filter(g => g.adminIds.includes(adminId));
}

export function addAdminToGroup(groupId: string, adminId: string): void {
  const groups = getAdminGroups();
  const group = groups.find(g => g.id === groupId);
  if (group && !group.adminIds.includes(adminId)) {
    group.adminIds.push(adminId);
    group.updatedAt = new Date().toISOString();
    saveAdminGroups(groups);
  }
}

export function removeAdminFromGroup(groupId: string, adminId: string): void {
  const groups = getAdminGroups();
  const group = groups.find(g => g.id === groupId);
  if (group && group.adminIds.includes(adminId)) {
    group.adminIds = group.adminIds.filter(id => id !== adminId);
    group.updatedAt = new Date().toISOString();
    saveAdminGroups(groups);
  }
}

/**
 * Assigns an admin to multiple groups at once (or updates their memberships).
 * Groups not in targetGroupIds will have the admin removed.
 * Groups in targetGroupIds will have the admin added.
 */
export function setAdminGroups(adminId: string, targetGroupIds: string[]): void {
  const groups = getAdminGroups();
  let modified = false;

  for (const group of groups) {
    const shouldBeIn = targetGroupIds.includes(group.id);
    const isCurrentlyIn = group.adminIds.includes(adminId);

    if (shouldBeIn && !isCurrentlyIn) {
      group.adminIds.push(adminId);
      group.updatedAt = new Date().toISOString();
      modified = true;
    } else if (!shouldBeIn && isCurrentlyIn) {
      group.adminIds = group.adminIds.filter(id => id !== adminId);
      group.updatedAt = new Date().toISOString();
      modified = true;
    }
  }

  if (modified) {
    saveAdminGroups(groups);
  }
}
