export interface RestrictedItemCategory {
  number: number;
  title: string;
  description: string;
  patterns: RegExp[];
}

export const RESTRICTED_ITEM_CATEGORIES: RestrictedItemCategory[] = [
  {
    number: 1,
    title: 'Firearms & Weapons',
    description:
      'Guns, ghost guns/3D-printed gun parts, ammunition, explosives, fireworks, switchblades, brass knuckles, stun guns, pepper spray',
    patterns: [
      /\bfirearms?\b/i,
      /\bguns?\b/i,
      /\bhandguns?\b/i,
      /\brifles?\b/i,
      /\bshotguns?\b/i,
      /\bpistols?\b/i,
      /\bghost guns?\b/i,
      /\b3d[- ]?printed gun/i,
      /\bammunition\b/i,
      /\bammo\b/i,
      /\bexplosives?\b/i,
      /\bfireworks?\b/i,
      /\bswitchblades?\b/i,
      /\bbrass knuckles\b/i,
      /\bstun guns?\b/i,
      /\btasers?\b/i,
      /\bpepper spray\b/i,
      /\bsilencers?\b/i,
      /\bsuppressors?\b/i,
    ],
  },
  {
    number: 2,
    title: 'Drugs & Controlled Substances',
    description:
      'Cannabis/THC, CBD/hemp ingestibles, kratom, prescription drugs, illegal narcotics, drug paraphernalia',
    patterns: [
      /\bcannabis\b/i,
      /\bmarijuana\b/i,
      /\bweed\b/i,
      /\bthc\b/i,
      /\bcbd\b/i,
      /\bhemp ingestibles?\b/i,
      /\bkratom\b/i,
      /\bprescription drugs?\b/i,
      /\bprescription medications?\b/i,
      /\billegal narcotics?\b/i,
      /\bnarcotics?\b/i,
      /\bcocaine\b/i,
      /\bheroin\b/i,
      /\bfentanyl\b/i,
      /\bmethamphetamine\b/i,
      /\bmdma\b/i,
      /\becstasy\b/i,
      /\blsd\b/i,
      /\bpsilocybin\b/i,
      /\bshrooms?\b/i,
      /\bdrug paraphernalia\b/i,
      /\bcrack pipe\b/i,
    ],
  },
  {
    number: 3,
    title: 'Alcohol & Tobacco',
    description:
      'Beer, wine, liquor, cigarettes, cigars, e-cigarettes, vapes, nicotine pouches',
    patterns: [
      /\bbeer\b/i,
      /\bwine\b/i,
      /\bliquor\b/i,
      /\bwhiskey\b/i,
      /\bvodka\b/i,
      /\btequila\b/i,
      /\bbourbon\b/i,
      /\bcigarettes?\b/i,
      /\bcigars?\b/i,
      /\be[- ]?cigarettes?\b/i,
      /\becigarettes?\b/i,
      /\be[- ]?cigs?\b/i,
      /\bvapes?\b/i,
      /\bvaping\b/i,
      /\bjuul\b/i,
      /\btobacco\b/i,
      /\bchewing tobacco\b/i,
      /\bpipe tobacco\b/i,
      /\bsnus\b/i,
      /\bhookah\b/i,
      /\bshisha\b/i,
      /\brolling papers?\b/i,
      /\bnicotine\b/i,
      /\bnicotine pouch(es)?\b/i,
    ],
  },
  {
    number: 4,
    title: 'Secondhand Medical & Baby Goods (Oregon ORS 167.502)',
    description:
      'Baby food, infant formula, used/opened cosmetics, personal care products, over-the-counter (OTC) medications, medical devices (e.g., CPAP machines, contact lenses, blood glucose monitors)',
    patterns: [
      /\bbaby food\b/i,
      /\binfant formula\b/i,
      /\bused cosmetics?\b/i,
      /\bopened cosmetics?\b/i,
      /\bused personal care\b/i,
      /\bover-the-counter medications?\b/i,
      /\botc medications?\b/i,
      /\bmedical devices?\b/i,
      /\bcpap\b/i,
      /\bcontact lens(es)?\b/i,
      /\bblood glucose monitors?\b/i,
      /\bglucometers?\b/i,
    ],
  },
  {
    number: 5,
    title: 'Recalled & Banned Products',
    description:
      'Any CPSC-recalled items, drop-side cribs, inclined infant sleepers, padded crib bumpers, undeployed airbags, mercury thermometers/thermostats',
    patterns: [
      /\bcpsc[- ]?recalled\b/i,
      /\brecalled (item|product|crib|sleeper|toy)s?\b/i,
      /\bdrop[- ]?side cribs?\b/i,
      /\binclined infant sleepers?\b/i,
      /\bpadded crib bumpers?\b/i,
      /\bcrib bumpers?\b/i,
      /\bundeployed airbags?\b/i,
      /\bmercury thermometers?\b/i,
      /\bmercury thermostats?\b/i,
    ],
  },
  {
    number: 6,
    title: 'Stolen, Counterfeit & Infringing Goods',
    description:
      'Stolen property, counterfeit designer goods, replicas, pirated software/media, unauthorized digital accounts',
    patterns: [
      /\bstolen property\b/i,
      /\bstolen goods?\b/i,
      /\bcounterfeit\b/i,
      /\breplica designer\b/i,
      /\breplica (watch|bag|handbag|shoe|sneaker)s?\b/i,
      /\bpirated software\b/i,
      /\bpirated media\b/i,
      /\bcracked software\b/i,
      /\bunauthorized digital accounts?\b/i,
    ],
  },
  {
    number: 7,
    title: 'Government & Financial Items',
    description:
      'Government-issued IDs, passports, fake IDs, currency, gift cards, prepaid debit cards, lottery tickets, raffles, gambling/mystery boxes with cash value',
    patterns: [
      /\bgovernment[- ]?issued ids?\b/i,
      /\bpassports?\b/i,
      /\bfake ids?\b/i,
      /\bdriver'?s licen[cs]e\b/i,
      /\bcounterfeit currency\b/i,
      /\bprop money\b/i,
      /\bgift cards?\b/i,
      /\bprepaid debit cards?\b/i,
      /\blottery tickets?\b/i,
      /\braffles?\b/i,
      /\bgambling\b/i,
      /\bmystery box(es)?\b/i,
    ],
  },
  {
    number: 8,
    title: 'Hazardous Materials',
    description:
      'Toxic chemicals, pesticides, flammable liquids, asbestos, radioactive materials, hazardous waste',
    patterns: [
      /\btoxic chemicals?\b/i,
      /\bpesticides?\b/i,
      /\bflammable liquids?\b/i,
      /\basbestos\b/i,
      /\bradioactive\b/i,
      /\bhazardous waste\b/i,
      /\bhazardous materials?\b/i,
    ],
  },
  {
    number: 9,
    title: 'Live Animals & Regulated Wildlife',
    description:
      'Live pets, livestock, protected wildlife, ivory, endangered animal parts',
    patterns: [
      /\blive pets?\b/i,
      /\blive animals?\b/i,
      /\blivestock\b/i,
      /\bprotected wildlife\b/i,
      /\bivory\b/i,
      /\bendangered animal/i,
    ],
  },
  {
    number: 10,
    title: 'Perishable & Unlicensed Food',
    description:
      'Homemade perishable foods, uninspected meat/dairy, non-cottage-law food items',
    patterns: [
      /\bhomemade perishable\b/i,
      /\buninspected meat\b/i,
      /\buninspected dairy\b/i,
      /\bnon[- ]?cottage[- ]?law\b/i,
      /\bunlicensed food\b/i,
      /\braw milk\b/i,
    ],
  },
  {
    number: 11,
    title: 'Adult & Explicit Content',
    description:
      'Pornography, sexually explicit media, adult services, escorting',
    patterns: [
      /\bpornography\b/i,
      /\bporn\b/i,
      /\bsexually explicit\b/i,
      /\badult services?\b/i,
      /\bescort(ing|s)?\b/i,
    ],
  },
  {
    number: 12,
    title: 'Human Remains & Fluids',
    description:
      'Human organs, blood, bodily fluids, bones, teeth',
    patterns: [
      /\bhuman organs?\b/i,
      /\bhuman blood\b/i,
      /\bbodily fluids?\b/i,
      /\bhuman bones?\b/i,
      /\bhuman teeth\b/i,
      /\bhuman remains?\b/i,
      /\bhuman skull\b/i,
    ],
  },
  {
    number: 13,
    title: 'Surveillance & Hacking Tools',
    description:
      'Hidden spy cameras disguised as everyday objects, signal jammers, lockpicking tools, credit card skimmers',
    patterns: [
      /\bspy cameras?\b/i,
      /\bhidden camera/i,
      /\bsignal jammers?\b/i,
      /\blockpicking\b/i,
      /\block[- ]?picks?\b/i,
      /\bcredit card skimmers?\b/i,
      /\bcard skimmers?\b/i,
    ],
  },
  {
    number: 14,
    title: 'Hate Speech & Harassment',
    description:
      'We do not allow hate speech. Content, items, listings, or messaging promoting hate speech, discrimination, harassment, violence, or intolerance against protected groups is strictly prohibited.',
    patterns: [
      /\bhate[- ]?speech\b/i,
      /\bharassment\b/i,
      /\bbigotry\b/i,
      /\bsupremacy\b/i,
      /\bdiscriminatory content\b/i,
    ],
  },
];

export interface RestrictedItemCheckResult {
  restricted: boolean;
  categoryNumber?: number;
  categoryTitle?: string;
  matchedTerm?: string;
  reason?: string;
}

export function checkRestrictedMarketplaceItem(fields: {
  title?: string;
  description?: string;
  category?: string;
  tags?: string[];
  deliverables?: string;
  barterDesired?: string;
  customOfferText?: string;
}): RestrictedItemCheckResult {
  const combined = [
    fields.title || '',
    fields.description || '',
    fields.category || '',
    Array.isArray(fields.tags) ? fields.tags.join(' ') : '',
    fields.deliverables || '',
    fields.barterDesired || '',
    fields.customOfferText || '',
  ]
    .join(' ')
    .trim();

  if (!combined) {
    return { restricted: false };
  }

  for (const cat of RESTRICTED_ITEM_CATEGORIES) {
    for (const pattern of cat.patterns) {
      const match = combined.match(pattern);
      if (match) {
        const matchedTerm = match[0];
        return {
          restricted: true,
          categoryNumber: cat.number,
          categoryTitle: cat.title,
          matchedTerm,
          reason: `Prohibited product or service detected ("${matchedTerm}") under Restriction #${cat.number}: ${cat.title}. Selling, buying, bartering, or listing U.S. & Oregon restricted products or services is not permitted on the marketplace, retail stores, or restaurants.`,
        };
      }
    }
  }

  return { restricted: false };
}
