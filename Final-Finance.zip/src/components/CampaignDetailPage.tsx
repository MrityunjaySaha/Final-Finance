import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  Bookmark,
  ShieldCheck,
  Clock,
  Users,
  Coins,
  HeartHandshake,
  PauseCircle,
  PlayCircle,
  ExternalLink,
  Layers,
  FileText,
  Video,
  Image as ImageIcon,
  AlertTriangle,
  Receipt,
  Info,
  Power,
  Search,
  X,
  RotateCcw,
  Eye,
  Twitter,
  ChevronDown,
  MessageSquare,
  Check,
  UploadCloud
} from 'lucide-react';
import { ShareOnTweetingModal } from './ShareOnTweetingModal';
import { formatInsufficientCurrencyError } from '../utils/transactionFees';
import {
  UserCampaign,
  UploadedMedia,
  isUserCampaignInitiator,
  isUserCampaignDonor,
  getUserDonationsForCampaign,
  getUserTotalDonatedToCampaign,
  updateCampaignStatus,
  updateCampaignCover,
  addCampaignMediaAndSetCover,
  donateToCampaign,
  cancelAndRefundCampaign,
  isCampaignBookmarked,
  toggleBookmarkCampaign,
  getAllPlatformFinalCoins,
  FinalCoinOption
} from '../services/fundraisingService';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';

interface CampaignDetailPageProps {
  campaign: UserCampaign;
  currentUser?: AuthSession | null;
  onBack: () => void;
  onRefresh: () => void;
  onOpenAuthModal?: () => void;
}

export const CampaignDetailPage: React.FC<CampaignDetailPageProps> = ({
  campaign,
  currentUser,
  onBack,
  onRefresh,
  onOpenAuthModal
}) => {
  const { addToast, addNotification } = useApp();
  const activeUserId = currentUser?.username || currentUser?.id || 'super_admin_ranma';
  const walletUserId = currentUser?.id || currentUser?.uid || activeUserId;
  const [walletVersion, setWalletVersion] = useState(0);

  useEffect(() => {
    const syncWallets = () => setWalletVersion(v => v + 1);
    window.addEventListener('final_finance_wallets_updated', syncWallets);
    return () => window.removeEventListener('final_finance_wallets_updated', syncWallets);
  }, []);

  // Ensure page scrolls to top immediately upon entering or changing campaign
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) {
      document.documentElement.scrollTop = 0;
    }
    if (document.body) {
      document.body.scrollTop = 0;
    }
  }, [campaign.id]);

  const isInitiator = isUserCampaignInitiator(campaign, activeUserId);
  const isDonor = isUserCampaignDonor(campaign, activeUserId);
  const userDonations = getUserDonationsForCampaign(campaign, activeUserId);
  const userTotalDonated = getUserTotalDonatedToCampaign(campaign, activeUserId);

  // Active Tab: Story, Gallery, Updates & Backers, FAQ & Risks (NO Milestones)
  const [activeTab, setActiveTab] = useState<'story' | 'gallery' | 'updates' | 'faq'>('story');

  // Media Gallery Selection (default to video if available, else first image)
  const [selectedMediaIndex, setSelectedMediaIndex] = useState<number>(0);

  // Donation Modal (Final Currency & Final Coins Only)
  const [isDonateModalOpen, setIsDonateModalOpen] = useState(false);
  const [selectedCoinSymbol, setSelectedCoinSymbol] = useState<string>('AFNL');
  const [coinSearchQuery, setCoinSearchQuery] = useState<string>('');
  const [donationAmount, setDonationAmount] = useState<string>('500');
  const [donorMessage, setDonorMessage] = useState<string>('');
  const [isSubmittingDonation, setIsSubmittingDonation] = useState(false);

  // Pause Modal
  const [isPauseModalOpen, setIsPauseModalOpen] = useState(false);
  const [pauseReasonInput, setPauseReasonInput] = useState(campaign.pauseReason || '');

  // End / Cancel Campaign Modal
  const [isEndCampaignModalOpen, setIsEndCampaignModalOpen] = useState(false);
  const [isProcessingEnd, setIsProcessingEnd] = useState(false);

  // Bookmark state (persistent across sessions)
  const [isBookmarked, setIsBookmarked] = useState(() => isCampaignBookmarked(campaign.id));

  useEffect(() => {
    setIsBookmarked(isCampaignBookmarked(campaign.id));
    const syncBookmarks = () => setIsBookmarked(isCampaignBookmarked(campaign.id));
    window.addEventListener('fundraising_bookmarks_updated', syncBookmarks);
    return () => window.removeEventListener('fundraising_bookmarks_updated', syncBookmarks);
  }, [campaign.id]);

  // Modals for On-Platform Share on Tweet and Audited Escrow Ledger
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [expandedDonorId, setExpandedDonorId] = useState<string | null>(null);
  const coverFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleSetExistingAsCover = (url: string) => {
    if (updateCampaignCover(campaign.id, url)) {
      addToast({
        type: 'success',
        title: 'Cover Photo Updated',
        message: 'Your campaign cover photo has been updated.'
      });
      onRefresh();
    }
  };

  const handleUploadNewCover = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) {
      if (file) {
        addToast({
          type: 'error',
          title: 'Invalid File',
          message: 'Please choose an image file (PNG, JPG, WebP) for the cover photo.'
        });
      }
      return;
    }
    const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : URL.createObjectURL(file);
      const newMedia: UploadedMedia = {
        id: `cover-${Date.now()}`,
        url: dataUrl,
        name: file.name,
        type: 'image',
        sizeFormatted: `${sizeInMB} MB`,
        caption: `${campaign.title} Cover`
      };
      if (addCampaignMediaAndSetCover(campaign.id, newMedia, true)) {
        setSelectedMediaIndex(0);
        addToast({
          type: 'success',
          title: 'Cover Photo Updated',
          message: `"${file.name}" is now set as your campaign cover photo.`
        });
        onRefresh();
      }
    };
    reader.readAsDataURL(file);
    if (coverFileInputRef.current) coverFileInputRef.current.value = '';
  };

  // Platform final coins for user selection (includes user's custom & held Final Coins)
  const platformFinalCoins: FinalCoinOption[] = useMemo(() => {
    return getAllPlatformFinalCoins(walletUserId);
  }, [walletUserId, walletVersion, isDonateModalOpen]);

  // Accepted final coins on this campaign
  const campaignAcceptedCoins = useMemo(() => {
    const symbols = campaign.acceptedFinalCoinSymbols;
    if (!symbols || symbols.length === 0) {
      return platformFinalCoins;
    }
    return platformFinalCoins.filter(c =>
      symbols.some(s => s.toUpperCase() === c.symbol.toUpperCase())
    );
  }, [campaign.acceptedFinalCoinSymbols, platformFinalCoins]);

  useEffect(() => {
    if (campaignAcceptedCoins.length > 0) {
      const stillValid = campaignAcceptedCoins.some(
        c => c.symbol.toUpperCase() === selectedCoinSymbol.toUpperCase()
      );
      if (!stillValid) {
        setSelectedCoinSymbol(campaignAcceptedCoins[0].symbol);
      }
    }
  }, [campaignAcceptedCoins, selectedCoinSymbol, isDonateModalOpen]);

  const selectedCoinObj = useMemo(() => {
    return (
      campaignAcceptedCoins.find(c => c.symbol.toUpperCase() === selectedCoinSymbol.toUpperCase()) ||
      campaignAcceptedCoins[0]
    );
  }, [campaignAcceptedCoins, selectedCoinSymbol]);

  // Calculations
  const progressPercent = Math.min(100, Math.round((campaign.raisedAmountUSD / campaign.targetAmountUSD) * 100));
  
  const endDate = new Date(campaign.endDateTime);
  const now = new Date();
  const diffMs = endDate.getTime() - now.getTime();
  const daysRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
  const isExpired = diffMs <= 0;

  // Media fallback
  const mediaList: UploadedMedia[] = campaign.mediaList && campaign.mediaList.length > 0
    ? campaign.mediaList
    : [
        {
          id: 'def-1',
          url: campaign.bannerUrl,
          name: 'campaign_banner.jpg',
          type: 'image',
          sizeFormatted: '2.5 MB',
          caption: campaign.title
        }
      ];

  const currentMedia = mediaList[selectedMediaIndex] || mediaList[0];

  const handleBack = () => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    onBack();
  };

  const handleToggleStatus = (nextStatus: 'active' | 'paused') => {
    if (nextStatus === 'paused') {
      setIsPauseModalOpen(true);
      return;
    }

    const success = updateCampaignStatus(campaign.id, 'active');
    if (success) {
      addToast({
        type: 'success',
        title: 'Campaign Resumed',
        message: `"${campaign.title}" is now active.`
      });
      onRefresh();
    }
  };

  const handleConfirmPause = () => {
    const success = updateCampaignStatus(
      campaign.id,
      'paused',
      pauseReasonInput.trim() || 'Voluntarily paused by campaign initiator.'
    );
    if (success) {
      addToast({
        type: 'info',
        title: 'Campaign Paused',
        message: 'Campaign has been paused. Escrow deposits remain secure.'
      });
      setIsPauseModalOpen(false);
      onRefresh();
    }
  };

  // End Campaign with 100% Backer Escrow Refund
  const handleConfirmEndCampaign = () => {
    setIsProcessingEnd(true);
    setTimeout(() => {
      const result = cancelAndRefundCampaign(campaign.id, activeUserId);
      setIsProcessingEnd(false);
      setIsEndCampaignModalOpen(false);

      if (result.success) {
        addToast({
          type: 'info',
          title: 'Campaign Cancelled & Escrow Refunded',
          message: `All ${result.refundedCount} backer contribution(s) totaling F ${result.refundedTotalUSD.toLocaleString()} FC have been 100% returned to donor Final Coin wallets.`
        });
        addNotification({
          title: `🛡️ Campaign Escrow Returned: ${campaign.title}`,
          description: `Campaign ended by initiator. F ${result.refundedTotalUSD.toLocaleString()} FC was refunded across ${result.refundedCount} donors.`,
          type: 'fundraising',
          targetTab: 'fundraising'
        });
        onRefresh();
      } else {
        addToast({
          type: 'error',
          title: 'Error Ending Campaign',
          message: result.error || 'Unable to process campaign refund.'
        });
      }
    }, 400);
  };

  const handleSubmitDonation = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(donationAmount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      addToast({
        type: 'error',
        title: 'Invalid Amount',
        message: 'Please enter an amount greater than 0.'
      });
      return;
    }

    const coinSym = selectedCoinObj?.symbol || selectedCoinSymbol;
    const availableBalance = selectedCoinObj?.balance || 0;
    if (numericAmount > availableBalance) {
      addToast({
        type: 'error',
        title: availableBalance <= 0 ? `No ${coinSym} Held` : `Insufficient ${coinSym}`,
        message: formatInsufficientCurrencyError({
          symbol: coinSym,
          name: selectedCoinObj?.name,
          available: availableBalance,
          required: numericAmount,
        }),
      });
      return;
    }

    setIsSubmittingDonation(true);
    setTimeout(() => {
      const donorName = currentUser?.name || 'Ranma';
      const donorHandle = currentUser?.username || currentUser?.id || 'super_admin_ranma';
      const donorId = walletUserId;
      const donorAvatar = currentUser?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80';

      const finalModalityLabel = `Final Coins (${coinSym})`;

      const success = donateToCampaign(campaign.id, {
        donorId,
        donorHandle,
        donorName,
        donorAvatar,
        amountUSD: numericAmount,
        originalAmount: numericAmount,
        originalCurrency: coinSym,
        modality: finalModalityLabel,
        message: donorMessage.trim() || undefined
      });

      setIsSubmittingDonation(false);
      if (success) {
        const displayContribution = `${numericAmount.toLocaleString()} ${coinSym}`;

        addToast({
          type: 'success',
          title: 'Contribution Successful',
          message: `You backed "${campaign.title}" with ${displayContribution} via ${finalModalityLabel}.`
        });
        addNotification({
          title: `🤝 Contribution Confirmed: ${displayContribution}`,
          description: `You backed "${campaign.title}" via ${finalModalityLabel}. Funds safeguarded in escrow.`,
          type: 'fundraising',
          targetTab: 'fundraising',
          amount: numericAmount,
          currency: coinSym
        });
        setIsDonateModalOpen(false);
        setDonorMessage('');
        onRefresh();
      } else {
        addToast({
          type: 'error',
          title: 'Contribution Failed',
          message: `Unable to process ${numericAmount.toLocaleString()} ${coinSym}. Please verify your wallet balance and campaign acceptance rules.`
        });
      }
    }, 350);
  };

  // Filter coins for modal selection
  const filteredDonationCoins = useMemo(() => {
    return campaignAcceptedCoins.filter(c =>
      c.symbol.toLowerCase().includes(coinSearchQuery.toLowerCase()) ||
      c.name.toLowerCase().includes(coinSearchQuery.toLowerCase())
    );
  }, [campaignAcceptedCoins, coinSearchQuery]);

  return (
    <div className="space-y-6 pb-16 max-w-5xl mx-auto text-center flex flex-col items-center">
      {/* Top Navigation Bar: Back button only on left, NO Share button before it */}
      <div className="w-full flex items-center justify-between gap-3 bg-white rounded-2xl border border-slate-200 px-4 py-2.5 shadow-2xs">
        <button
          type="button"
          onClick={handleBack}
          className="inline-flex items-center justify-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-slate-600" />
          <span>Back to Campaigns</span>
        </button>

        {/* Bookmark / Save button */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              const nextSaved = toggleBookmarkCampaign(campaign.id);
              setIsBookmarked(nextSaved);
              onRefresh();
              addToast({
                type: 'info',
                title: nextSaved ? 'Saved Fundraiser' : 'Removed from Saved',
                message: nextSaved ? 'Saved to your Saved fundraisers.' : 'Campaign removed from Saved fundraisers.'
              });
            }}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              isBookmarked
                ? 'bg-amber-50 border-amber-300 text-amber-800'
                : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
            }`}
            title={isBookmarked ? 'Remove from Saved' : 'Save campaign'}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-500 text-amber-600' : 'text-slate-500'}`} />
            <span>{isBookmarked ? 'Saved' : 'Save'}</span>
          </button>
        </div>
      </div>

      {/* Cancelled / Refunded Banner */}
      {campaign.isCancelledAndRefunded && (
        <div className="w-full bg-rose-50 border border-rose-200 rounded-2xl p-4 flex flex-col items-center justify-center text-center text-rose-950 space-y-1">
          <div className="flex items-center justify-center gap-2 text-rose-700 font-bold text-sm">
            <RotateCcw className="w-4 h-4" />
            <span>Campaign Cancelled & 100% Escrow Refunded</span>
          </div>
          <p className="text-xs text-rose-900 leading-relaxed max-w-xl">
            This campaign was cancelled by the initiator. All contributions have been 100% refunded back to donor wallets in their original currency modalities.
          </p>
        </div>
      )}

      {/* Paused Notice */}
      {campaign.status === 'paused' && !campaign.isCancelledAndRefunded && (
        <div className="w-full bg-amber-50 border border-amber-200 rounded-2xl p-4 flex flex-col items-center justify-center text-center text-amber-950 space-y-1">
          <div className="flex items-center justify-center gap-2 text-amber-700 font-bold text-sm">
            <AlertTriangle className="w-4 h-4" />
            <span>Campaign Temporarily Paused</span>
            {isInitiator && (
              <span className="font-mono text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded font-semibold">
                By You
              </span>
            )}
          </div>
          <p className="text-xs text-amber-900 leading-relaxed max-w-xl">
            {campaign.pauseReason || 'This campaign is temporarily paused by the initiator. Escrow deposits remain safe.'}
          </p>
        </div>
      )}

      {/* Main Container - Centered */}
      <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Media & Narrative (7 cols) */}
        <div className="lg:col-span-7 space-y-4 flex flex-col items-center text-center">
          {/* Header Metadata */}
          <div className="space-y-2 flex flex-col items-center justify-center text-center w-full">
            <div className="flex flex-wrap items-center justify-center gap-2 text-xs">
              <span className="px-2.5 py-0.5 rounded-md font-mono font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                {campaign.category}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-md font-mono font-bold uppercase ${
                  campaign.isCancelledAndRefunded
                    ? 'bg-rose-100 text-rose-800 border border-rose-300'
                    : campaign.status === 'active'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : campaign.status === 'completed'
                    ? 'bg-sky-100 text-sky-800 border border-sky-300'
                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}
              >
                {campaign.isCancelledAndRefunded ? 'Refunded' : campaign.status}
              </span>
              {isInitiator && campaign.status === 'paused' && (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-amber-200 text-amber-950 border border-amber-300">
                  Paused by You
                </span>
              )}
              {isInitiator && isDonor ? (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-emerald-900 text-white">
                  Created & Co-Backed (F {userTotalDonated.toLocaleString()})
                </span>
              ) : isInitiator ? (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-slate-900 text-white">
                  Created by You
                </span>
              ) : isDonor ? (
                <span className="px-2 py-0.5 rounded-md font-mono text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                  Backed (F {userTotalDonated.toLocaleString()})
                </span>
              ) : null}
            </div>

            <h1 className="font-serif text-xl sm:text-2xl lg:text-3xl font-bold text-slate-900 leading-tight text-center text-balance break-words w-full px-1">
              {campaign.title}
            </h1>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed text-center max-w-xl">
              {campaign.shortDescription}
            </p>
          </div>

          {/* Featured Media Player / Image Display */}
          <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-200 shadow-xs aspect-video w-full mx-auto">
            {currentMedia.type === 'video' ? (
              <video
                key={currentMedia.url}
                src={currentMedia.url}
                controls
                autoPlay={false}
                className="w-full h-full object-cover"
                poster={campaign.bannerUrl}
              />
            ) : (
              <img
                key={currentMedia.url}
                src={currentMedia.url}
                alt={currentMedia.caption || campaign.title}
                className="w-full h-full object-cover"
              />
            )}

            {currentMedia.caption && (
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 text-white text-xs font-mono flex items-center justify-between text-center">
                <span className="line-clamp-1">{currentMedia.caption}</span>
                <span className="text-[11px] text-neutral-300 shrink-0 ml-2">
                  {currentMedia.sizeFormatted}
                </span>
              </div>
            )}
          </div>

          {/* Media Carousel (if > 1 item) */}
          {mediaList.length > 1 && (
            <div className="flex items-center justify-center gap-2 overflow-x-auto pb-1 w-full">
              {mediaList.map((med, idx) => (
                <button
                  key={med.id}
                  type="button"
                  onClick={() => setSelectedMediaIndex(idx)}
                  className={`relative w-18 h-12 rounded-lg overflow-hidden border-2 shrink-0 transition-all cursor-pointer ${
                    selectedMediaIndex === idx
                      ? 'border-emerald-600 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={med.url} alt={med.name} className="w-full h-full object-cover" />
                  {med.type === 'video' && (
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-white">
                      <Video className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          )}

          {/* Initiator Cover Photo Controls */}
          {isInitiator && (
            <div className="flex flex-wrap items-center justify-center gap-2 w-full">
              <input
                type="file"
                ref={coverFileInputRef}
                onChange={handleUploadNewCover}
                accept="image/*"
                className="hidden"
              />
              {currentMedia.type === 'image' && currentMedia.url !== campaign.bannerUrl && (
                <button
                  type="button"
                  onClick={() => handleSetExistingAsCover(currentMedia.url)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Set This Photo as Cover</span>
                </button>
              )}
              {currentMedia.type === 'image' && currentMedia.url === campaign.bannerUrl && (
                <span className="text-[11px] font-mono font-semibold text-emerald-700 inline-flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  Current Campaign Cover
                </span>
              )}
              <button
                type="button"
                onClick={() => coverFileInputRef.current?.click()}
                className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <UploadCloud className="w-3.5 h-3.5 text-emerald-600" />
                <span>Upload / Change Cover Photo</span>
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Funding Progress & Actions (5 cols) */}
        <div className="lg:col-span-5 space-y-4 flex flex-col items-center text-center w-full">
          {/* Main Funding Progress Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 w-full text-center flex flex-col items-center">
            {/* Raised vs Target */}
            <div className="space-y-1.5 w-full flex flex-col items-center text-center">
              <div className="flex items-baseline justify-center gap-2 text-center">
                <span className="font-serif text-3xl font-bold text-slate-900">
                  F {campaign.raisedAmountUSD.toLocaleString()}
                </span>
                <span className="text-xs text-slate-500 font-mono">
                  FC raised
                </span>
                <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 ml-1">
                  {progressPercent}%
                </span>
              </div>

              <div className="w-full h-2.5 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 mx-auto ${
                    campaign.isCancelledAndRefunded
                      ? 'bg-rose-500'
                      : campaign.status === 'completed'
                      ? 'bg-sky-500'
                      : campaign.status === 'paused'
                      ? 'bg-amber-500'
                      : 'bg-emerald-600'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono tabular-nums text-slate-500 pt-0.5 w-full px-1">
                <span>Target: F {campaign.targetAmountUSD.toLocaleString()} FC</span>
                <span className="inline-flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-slate-400" />
                  {(campaign.viewsCount || 0).toLocaleString()} Views
                </span>
                <span>{campaign.backersCount.toLocaleString()} Backers</span>
              </div>
            </div>

            {/* Key Stats */}
            <div className="grid grid-cols-2 gap-2.5 pt-1 w-full text-center">
              <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 flex flex-col items-center justify-center text-center">
                <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 font-mono">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Timeline</span>
                </div>
                <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                  {campaign.isCancelledAndRefunded ? 'Refunded' : campaign.status === 'completed' ? 'Fully Funded' : isExpired ? 'Ended' : `${daysRemaining} Days Left`}
                </div>
              </div>

              <div
                onClick={() => setIsAuditModalOpen(true)}
                className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-emerald-50/50 hover:border-emerald-200 transition-colors"
                title="View Audited Escrow Ledger"
              >
                <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 font-mono">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Escrow</span>
                </div>
                <div className="text-sm font-bold font-mono text-emerald-700 mt-0.5 flex items-center justify-center gap-1">
                  <span>Verified Vault</span>
                </div>
              </div>
            </div>

            {/* Accepted Modalities (Final Currency & Final Coins Only) */}
            <div className="space-y-1.5 pt-1 border-t border-slate-100 w-full flex flex-col items-center text-center">
              <span className="text-[11px] font-mono font-semibold text-slate-500 uppercase text-center">
                Accepted Currency
              </span>
              <div className="w-full flex flex-col gap-1.5 text-xs font-mono">
                <div className="flex items-center justify-between bg-emerald-50/70 border border-emerald-200 px-3 py-2 rounded-lg text-emerald-950">
                  <span className="flex items-center gap-1.5 font-semibold text-[11px]">
                    <Coins className="w-3.5 h-3.5 text-emerald-600" />
                    Final Coins Only
                  </span>
                  <span className="font-bold">F {campaign.targetAmountUSD.toLocaleString()} FC</span>
                </div>
                <div className="text-[10px] text-slate-600 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-lg">
                  {campaign.acceptedFinalCoinSymbols && campaign.acceptedFinalCoinSymbols.length > 0
                    ? `Accepted Coins: ${campaign.acceptedFinalCoinSymbols.join(', ')}`
                    : 'All Platform & User Final Coins Accepted'}
                </div>
              </div>
            </div>

            {/* Action Buttons Stack: Back This Campaign -> Pause (if mine) -> End Campaign (if mine) -> Share on X */}
            <div className="pt-2 w-full space-y-2 flex flex-col items-center">
              {/* Back This Campaign Button */}
              <button
                type="button"
                onClick={() => {
                  if (!currentUser && onOpenAuthModal) {
                    onOpenAuthModal();
                    return;
                  }
                  if (campaignAcceptedCoins.length > 0) {
                    const preferred = campaignAcceptedCoins.find(c => (c.balance || 0) > 0) || campaignAcceptedCoins[0];
                    setSelectedCoinSymbol(preferred.symbol);
                  }
                  setIsDonateModalOpen(true);
                }}
                disabled={campaign.status === 'completed' || campaign.status === 'paused' || campaign.isCancelledAndRefunded}
                className={`w-full py-3 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer ${
                  campaign.isCancelledAndRefunded || campaign.status === 'completed' || campaign.status === 'paused'
                    ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                }`}
              >
                <HeartHandshake className="w-4 h-4" />
                <span>
                  {campaign.isCancelledAndRefunded
                    ? 'Campaign Cancelled'
                    : campaign.status === 'completed'
                    ? 'Campaign Concluded'
                    : campaign.status === 'paused'
                    ? 'Campaign Paused'
                    : isDonor
                    ? 'Contribute Additional Funds'
                    : 'Back This Campaign'}
                </span>
              </button>

              {/* If initiated by me: Pause Campaign button below Back this Campaign button */}
              {isInitiator && !campaign.isCancelledAndRefunded && (
                <>
                  {campaign.status === 'active' ? (
                    <button
                      type="button"
                      onClick={() => setIsPauseModalOpen(true)}
                      className="w-full py-2.5 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                    >
                      <PauseCircle className="w-4 h-4 text-amber-600" />
                      <span>Pause Campaign</span>
                    </button>
                  ) : campaign.status === 'paused' ? (
                    <button
                      type="button"
                      onClick={() => handleToggleStatus('active')}
                      className="w-full py-2.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                    >
                      <PlayCircle className="w-4 h-4 text-emerald-600" />
                      <span>Resume Campaign</span>
                    </button>
                  ) : null}

                  {/* Below Pause button: End Campaign option */}
                  <button
                    type="button"
                    onClick={() => setIsEndCampaignModalOpen(true)}
                    className="w-full py-2.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-900 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                  >
                    <Power className="w-4 h-4 text-rose-600" />
                    <span>End Campaign</span>
                  </button>
                </>
              )}

              {/* Tweeting (On-Platform Quote Tweet with Note & Media) */}
              <button
                type="button"
                onClick={() => setIsShareModalOpen(true)}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs whitespace-nowrap"
              >
                <span className="w-4 h-4 rounded bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Twitter className="w-2.5 h-2.5 -scale-x-100 -rotate-12 fill-white" />
                </span>
                <span>Tweet</span>
              </button>
            </div>
          </div>

          {/* Campaign Initiator Card - Centered */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3 w-full text-center flex flex-col items-center">
            <div className="flex items-center justify-center gap-2 text-xs font-mono">
              <span className="text-slate-400 font-semibold uppercase text-[11px]">
                Campaign Initiator
              </span>
              {campaign.verifiedCreator && (
                <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  Verified
                </span>
              )}
            </div>

            <div className="flex flex-col items-center justify-center gap-2 text-center">
              <img
                src={campaign.creatorAvatar}
                alt={campaign.creatorName}
                className="w-12 h-12 rounded-xl object-cover border border-slate-200 mx-auto"
              />
              <div className="space-y-0.5">
                <h4 className="font-bold text-slate-900 text-sm flex items-center justify-center gap-1.5">
                  <span>{campaign.creatorName}</span>
                  {isInitiator && (
                    <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-bold">
                      YOU
                    </span>
                  )}
                </h4>
                <div className="text-xs font-mono text-slate-500">
                  @{campaign.creatorHandle}
                </div>
              </div>
            </div>

            {campaign.creatorBio && (
              <p className="text-xs text-slate-600 leading-relaxed text-center max-w-sm">
                {campaign.creatorBio}
              </p>
            )}

            {campaign.creatorWebsite && (
              <div className="pt-2 border-t border-slate-100 flex items-center justify-center gap-2 text-xs font-mono">
                <span className="text-slate-400">Website:</span>
                <a
                  href={campaign.creatorWebsite}
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-700 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>{campaign.creatorWebsite.replace(/^https?:\/\//, '')}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Tabs Row - Fits cleanly without clipping or horizontal scrolling */}
      <div className="w-full border-b border-slate-200">
        <div className="flex flex-wrap sm:flex-nowrap items-center justify-center gap-x-1 sm:gap-x-2 gap-y-1 w-full px-1 pb-px">
          {[
            { id: 'story', label: 'Story & Narrative', icon: FileText },
            { id: 'gallery', label: `Gallery (${mediaList.length})`, icon: ImageIcon },
            { id: 'updates', label: `Updates & Backers (${(campaign.updates?.length || 0) + (campaign.donations?.length || 0)})`, icon: Users },
            { id: 'faq', label: 'FAQ & Risks', icon: Info },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-2 sm:px-3.5 py-2 sm:py-2.5 text-[11px] sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors inline-flex items-center gap-1.5 border-b-2 cursor-pointer ${
                  isSelected
                    ? 'border-emerald-600 text-emerald-950 font-bold'
                    : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-emerald-600' : 'text-slate-400'}`} />
                <span className="whitespace-nowrap">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Panels - Centered */}
      <div className="w-full bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs text-center flex flex-col items-center">
        {/* Story Tab */}
        {activeTab === 'story' && (
          <div className="max-w-3xl space-y-4 text-center">
            <div className="text-slate-700 text-xs sm:text-sm leading-relaxed space-y-3 text-center">
              {campaign.fullStory.split('\n\n').map((para, i) => {
                if (para.startsWith('### ')) {
                  return (
                    <h3 key={`h3-${i}`} className="font-serif text-base sm:text-lg font-bold text-slate-900 mt-5 mb-1.5 text-center">
                      {para.replace('### ', '')}
                    </h3>
                  );
                }
                return (
                  <p key={`p-${i}`} className="leading-relaxed text-center">
                    {para}
                  </p>
                );
              })}
            </div>
          </div>
        )}

        {/* Gallery Tab */}
        {activeTab === 'gallery' && (
          <div className="space-y-4 w-full flex flex-col items-center">
            <div className="flex flex-wrap items-center justify-center gap-3 w-full">
              <h3 className="font-serif text-lg font-bold text-slate-900 text-center">
                Media &amp; Documentation
              </h3>
              {isInitiator && (
                <button
                  type="button"
                  onClick={() => coverFileInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Add &amp; Set New Cover</span>
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 w-full">
              {mediaList.map((med, i) => {
                const isCover = med.type === 'image' && med.url === campaign.bannerUrl;
                return (
                  <div
                    key={med.id}
                    className={`rounded-xl overflow-hidden bg-white border flex flex-col ${
                      isCover ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-slate-200'
                    }`}
                  >
                    <div
                      onClick={() => setSelectedMediaIndex(i)}
                      className="group relative bg-slate-900 aspect-video cursor-pointer overflow-hidden"
                    >
                      {med.type === 'video' ? (
                        <video src={med.url} className="w-full h-full object-cover" />
                      ) : (
                        <img
                          src={med.url}
                          alt={med.name}
                          className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-200"
                        />
                      )}
                    </div>
                    <div className="p-2.5 flex flex-col gap-1.5 text-center bg-slate-50">
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                        <span className="uppercase font-semibold text-slate-700">{med.type}</span>
                        <span>{med.sizeFormatted}</span>
                      </div>
                      {med.caption && (
                        <p className="text-xs line-clamp-1 text-slate-700 text-center">
                          {med.caption}
                        </p>
                      )}
                      {isInitiator && med.type === 'image' && (
                        <button
                          type="button"
                          onClick={() => handleSetExistingAsCover(med.url)}
                          className={`mt-0.5 w-full py-1.5 rounded-lg text-[11px] font-semibold inline-flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                            isCover
                              ? 'bg-emerald-600 text-white'
                              : 'bg-white border border-slate-200 hover:border-emerald-400 hover:text-emerald-700 text-slate-700'
                          }`}
                        >
                          {isCover ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Current Cover</span>
                            </>
                          ) : (
                            <span>Set as Cover Photo</span>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Updates & Backers Combined Tab */}
        {activeTab === 'updates' && (
          <div className="space-y-6 max-w-3xl w-full flex flex-col items-center text-center">
            {/* Updates Section */}
            <div className="space-y-3 w-full">
              <h3 className="font-serif text-lg font-bold text-slate-900 text-center">
                Creator Field Updates
              </h3>
              <div className="space-y-2.5 w-full">
                {(campaign.updates && campaign.updates.length > 0 ? campaign.updates : [
                  {
                    id: 'up-def-1',
                    title: 'Campaign Launched on Final Finance',
                    date: campaign.createdAt,
                    author: campaign.creatorName,
                    likesCount: 24,
                    content: 'Campaign is live and open for multi-asset backing. Thank you to our initial community supporters.'
                  }
                ]).map((up) => (
                  <div key={up.id} className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1.5 text-center">
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-1 text-center">
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm text-center">
                        {up.title}
                      </h4>
                      <span className="text-[11px] font-mono text-slate-400">
                        {up.date}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed text-center">
                      {up.content}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Backers Section */}
            <div className="space-y-3 pt-4 border-t border-slate-100 w-full">
              <div className="flex flex-col items-center justify-center text-center">
                <h3 className="font-serif text-lg font-bold text-slate-900">
                  Recent Backers
                </h3>
                <span className="text-xs font-mono text-slate-500">
                  {campaign.donations?.length || 0} Backers Recorded
                </span>
              </div>

              <div className="space-y-2 w-full">
                {campaign.donations && campaign.donations.length > 0 ? (
                  campaign.donations.map((don) => {
                    const isExpanded = expandedDonorId === don.id;
                    return (
                      <div
                        key={don.id}
                        onClick={() => setExpandedDonorId(prev => prev === don.id ? null : don.id)}
                        className={`rounded-xl border transition-colors cursor-pointer text-xs ${
                          isExpanded
                            ? 'bg-emerald-50/50 border-emerald-300'
                            : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between p-3 gap-2">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <img
                              src={don.donorAvatar}
                              alt={don.donorName}
                              className="w-8 h-8 rounded-lg object-cover border border-slate-200 shrink-0"
                            />
                            <div className="text-left min-w-0">
                              <div className="font-bold text-slate-900 truncate">
                                {don.donorName}
                              </div>
                              <div className="text-[11px] font-mono text-slate-500">
                                {don.modality} · {new Date(don.timestamp).toLocaleDateString()}
                                {don.message ? ' · Note attached' : ''}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <div className="text-right">
                              <span className="font-mono font-bold text-emerald-700 block tabular-nums">
                                F {don.amountUSD.toLocaleString()} FC
                              </span>
                              {don.originalAmount && don.originalCurrency && (
                                <span className="text-[10px] font-mono text-slate-500 block tabular-nums">
                                  {don.originalAmount.toLocaleString()} {don.originalCurrency}
                                </span>
                              )}
                            </div>
                            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isExpanded ? 'rotate-180 text-emerald-600' : ''}`} />
                          </div>
                        </div>

                        {isExpanded && (
                          <div className="px-3 pb-3 pt-2 border-t border-slate-200/70 text-left space-y-1">
                            <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase text-slate-500 font-semibold">
                              <MessageSquare className="w-3 h-3 text-emerald-600" />
                              <span>Contribution Note / Message</span>
                            </div>
                            <p className={`text-xs leading-relaxed ${don.message ? 'text-slate-800 italic' : 'text-slate-400'}`}>
                              {don.message ? `"${don.message}"` : 'No contribution note / message was included with this pledge.'}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center py-6 text-slate-400 font-mono text-xs">
                    No public donations recorded yet.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* FAQ & Risks Tab */}
        {activeTab === 'faq' && (
          <div className="space-y-4 max-w-3xl w-full flex flex-col items-center text-center">
            <h3 className="font-serif text-lg font-bold text-slate-900 text-center">
              Frequently Asked Questions
            </h3>
            
            <div className="space-y-2.5 w-full">
              {(campaign.faqs && campaign.faqs.length > 0 ? campaign.faqs : [
                {
                  question: 'How are backer funds safeguarded?',
                  answer: 'All contributions are locked in multi-signature smart contract escrow vaults. Funds are only unlocked upon independent verification of milestones.'
                },
                {
                  question: 'Can I request a refund if milestones fail?',
                  answer: 'Yes. If a project fails milestone verification or is cancelled, remaining escrow capital is returned proportionally to donors in their original asset modality.'
                }
              ]).map((faq, i) => (
                <div key={`faq-${i}`} className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1 text-center">
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm text-center">
                    {faq.question}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed text-center">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>

            {campaign.risksAndChallenges && (
              <div className="bg-slate-100 border border-slate-300 rounded-xl p-4 space-y-1 mt-4 w-full text-center">
                <div className="flex items-center justify-center gap-1.5 text-slate-900 font-bold text-xs">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  <span>Technical Risks & Challenges</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed text-center">
                  {campaign.risksAndChallenges}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ================= MODAL: DONATE / BACK CAMPAIGN ================= */}
      <AnimatePresence>
        {isDonateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-4 text-center flex flex-col items-center"
            >
              <div className="relative flex items-center justify-center w-full pr-7">
                <div className="text-center w-full">
                  <h3 className="font-serif text-lg font-bold text-slate-900 text-center">
                    Back This Campaign
                  </h3>
                  <p className="text-xs text-slate-500 font-mono text-center text-balance break-words leading-snug">
                    {campaign.title}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsDonateModalOpen(false)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSubmitDonation} className="space-y-4 w-full text-center">
                {/* Final Currency & Final Coins Badge */}
                <div className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-mono font-bold">
                  <Coins className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Final Currency &amp; Final Coins Only</span>
                </div>

                {/* Coin search & selection */}
                <div className="space-y-2 text-center bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[11px] font-mono text-slate-600 block text-center font-semibold">
                    Select Accepted Final Coin from Your Wallet:
                  </span>

                  {/* Search */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={coinSearchQuery}
                      onChange={(e) => setCoinSearchQuery(e.target.value)}
                      placeholder="Search Final Coins (e.g. AFNL, VANC, ASOV)..."
                      className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-center font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>

                  {/* Coins List */}
                  <div className="max-h-40 overflow-y-auto space-y-1 text-left">
                    {filteredDonationCoins.map((coin) => {
                      const isSelected = selectedCoinObj?.symbol === coin.symbol;
                      const hasBalance = (coin.balance || 0) > 0;
                      return (
                        <div
                          key={coin.symbol}
                          onClick={() => setSelectedCoinSymbol(coin.symbol)}
                          className={`p-2 rounded-lg border text-xs flex items-center justify-between cursor-pointer transition-colors ${
                            isSelected
                              ? 'bg-emerald-100/70 border-emerald-500 text-emerald-950 font-bold'
                              : 'bg-white border-slate-200 hover:bg-slate-100 text-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span>{coin.icon || '🪙'}</span>
                            <span className="font-mono font-bold">{coin.symbol}</span>
                            <span className="text-[10px] text-slate-500 truncate max-w-[120px]">
                              {coin.name}
                            </span>
                          </div>
                          <span className="font-mono text-[10px] text-slate-600 shrink-0 tabular-nums">
                            {hasBalance ? `${coin.balance?.toLocaleString()} in wallet` : '0 in wallet'}
                          </span>
                        </div>
                      );
                    })}
                    {filteredDonationCoins.length === 0 && (
                      <div className="py-3 text-center text-[11px] font-mono text-slate-400">
                        No matching accepted Final Coin found.
                      </div>
                    )}
                  </div>
                </div>

                {/* Amount */}
                {(() => {
                  const coinSym = selectedCoinObj?.symbol || selectedCoinSymbol;
                  const availableBal = Number(selectedCoinObj?.balance || 0);
                  const parsedAmt = parseFloat(donationAmount) || 0;
                  const exceedsBalance = parsedAmt > availableBal;
                  return (
                    <div className="space-y-1 text-center">
                      <label className="text-xs font-mono font-semibold text-slate-700 block text-center">
                        Contribution Amount ({coinSym} · Available: {availableBal.toLocaleString()} {coinSym})
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs font-semibold">
                          F
                        </span>
                        <input
                          type="number"
                          min="1"
                          step="any"
                          value={donationAmount}
                          onChange={(e) => setDonationAmount(e.target.value)}
                          required
                          className={`w-full pl-9 pr-16 py-2 rounded-xl border focus:outline-none focus:ring-2 font-mono text-xs text-center tabular-nums ${
                            exceedsBalance
                              ? 'border-rose-400 bg-rose-50/40 text-rose-900 focus:ring-rose-500/20 focus:border-rose-500'
                              : 'border-slate-300 focus:ring-emerald-500'
                          }`}
                          placeholder="500"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-[11px] font-bold">
                          {coinSym}
                        </span>
                      </div>

                      {exceedsBalance && (
                        <p className="text-xs font-semibold text-rose-600 pt-0.5">
                          You do not have that much balance. Available: {availableBal.toLocaleString()} {coinSym}.
                        </p>
                      )}

                      <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                        {[100, 250, 500, 1000, 5000].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setDonationAmount(preset.toString())}
                            className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-mono font-semibold transition-colors cursor-pointer tabular-nums"
                          >
                            F {preset.toLocaleString()}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })()}

                <div className="space-y-1 text-center">
                  <label className="text-xs font-mono font-semibold text-slate-700 block text-center">
                    Public Note (Optional)
                  </label>
                  <textarea
                    rows={2}
                    value={donorMessage}
                    onChange={(e) => setDonorMessage(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-center"
                    placeholder="Supporting open innovation..."
                  />
                </div>

                <div className="flex items-center justify-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsDonateModalOpen(false)}
                    className="flex-1 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer border border-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingDonation}
                    className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>{isSubmittingDonation ? 'Confirming...' : 'Confirm Pledge'}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: PAUSE CAMPAIGN ================= */}
      <AnimatePresence>
        {isPauseModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-3.5 text-center flex flex-col items-center"
            >
              <div className="flex items-center justify-center gap-2 text-amber-700">
                <PauseCircle className="w-5 h-5 shrink-0" />
                <h3 className="font-serif text-base font-bold text-slate-900">
                  Pause Campaign Pledges
                </h3>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed text-center">
                Pausing temporarily stops new pledges from being made. Escrow funds remain safe. Reason for backers:
              </p>

              <textarea
                rows={2}
                value={pauseReasonInput}
                onChange={(e) => setPauseReasonInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs text-center"
                placeholder="E.g., Temporarily paused while awaiting telemetry approval..."
              />

              <div className="flex items-center justify-center gap-2 pt-1 w-full">
                <button
                  type="button"
                  onClick={() => setIsPauseModalOpen(false)}
                  className="flex-1 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer border border-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPause}
                  className="flex-1 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
                >
                  Confirm Pause
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: END CAMPAIGN & REFUND ALL BACKERS ================= */}
      <AnimatePresence>
        {isEndCampaignModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-rose-200 space-y-4 text-center flex flex-col items-center"
            >
              <div className="flex items-center justify-center gap-2 text-rose-700">
                <Power className="w-5 h-5 shrink-0" />
                <h3 className="font-serif text-base font-bold text-slate-900">
                  End Campaign & Refund Escrow
                </h3>
              </div>

              <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-xs text-rose-900 space-y-1 text-center">
                <div className="font-bold">100% Backer Refund Protocol</div>
                <p className="leading-relaxed">
                  If this campaign is cancelled by you, all escrowed funds (F {campaign.raisedAmountUSD.toLocaleString()} FC across {campaign.backersCount} backer{campaign.backersCount !== 1 ? 's' : ''}) will be automatically returned in full to all donors in their original Final Coin wallets.
                </p>
              </div>

              <div className="flex items-center justify-center gap-2 pt-1 w-full">
                <button
                  type="button"
                  onClick={() => setIsEndCampaignModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer border border-slate-200"
                >
                  Keep Campaign Active
                </button>
                <button
                  type="button"
                  onClick={handleConfirmEndCampaign}
                  disabled={isProcessingEnd}
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
                >
                  {isProcessingEnd ? 'Refunding...' : 'Confirm End & Refund'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: AUDIT VAULT LEDGER (CENTERED & RESPONSIVE) ================= */}
      <AnimatePresence>
        {isAuditModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full max-h-[88vh] overflow-hidden text-center flex flex-col items-center mx-auto my-auto relative"
            >
              {/* Header - Centered & Safe Absolute Close Button */}
              <div className="relative w-full bg-neutral-950 text-white pt-6 pb-5 px-6 border-b border-neutral-800 flex flex-col items-center text-center">
                <button
                  type="button"
                  onClick={() => setIsAuditModalOpen(false)}
                  className="absolute right-4 top-4 p-2 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer z-10"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold uppercase tracking-wider mb-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Audited Escrow Ledger</span>
                </div>

                <h3 className="font-serif text-base sm:text-lg font-bold text-white text-center leading-snug max-w-md break-words px-2 text-balance">
                  {campaign.title}
                </h3>

                <div className="mt-1.5 flex items-center justify-center gap-2 text-xs text-neutral-400 font-mono">
                  <span className="text-emerald-400 font-semibold">{campaign.category}</span>
                  <span>•</span>
                  <span>Lead: {campaign.creatorName}</span>
                </div>
              </div>

              {/* Body */}
              <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[calc(88vh-130px)] w-full text-center flex flex-col items-center">
                {/* 3 Metric Cards */}
                <div className="grid grid-cols-3 gap-2.5 w-full text-center">
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">Target Goal</span>
                    <span className="text-sm sm:text-base font-bold font-mono text-slate-900 truncate max-w-full">
                      F {campaign.targetAmountUSD.toLocaleString()} FC
                    </span>
                  </div>
                  <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-mono text-emerald-700 block uppercase">In Escrow</span>
                    <span className="text-sm sm:text-base font-bold font-mono text-emerald-800 truncate max-w-full">
                      F {campaign.raisedAmountUSD.toLocaleString()} FC
                    </span>
                  </div>
                  <div className="p-3 rounded-2xl bg-sky-50 border border-sky-200 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-mono text-sky-700 block uppercase">Funded</span>
                    <span className="text-sm sm:text-base font-bold font-mono text-sky-800">
                      {progressPercent}%
                    </span>
                  </div>
                </div>

                {/* Accepted Modalities */}
                <div className="w-full p-3 rounded-2xl bg-slate-50/80 border border-slate-200 text-center space-y-2">
                  <span className="text-[11px] font-mono uppercase text-slate-500 font-bold block">
                    Accepted Modality Channels
                  </span>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {campaign.acceptedModalities.map((m) => (
                      <span
                        key={m}
                        className="text-[11px] font-mono bg-white text-slate-700 px-2 py-0.5 rounded-md border border-slate-200"
                      >
                        {m}
                      </span>
                    ))}
                    {campaign.acceptedFinalCoinSymbols && campaign.acceptedFinalCoinSymbols.length > 0 && (
                      <span className="text-[11px] font-mono bg-amber-50 text-amber-800 px-2 py-0.5 rounded-md border border-amber-200 font-semibold">
                        Coins: {campaign.acceptedFinalCoinSymbols.join(', ')}
                      </span>
                    )}
                  </div>
                </div>

                {/* Verified Donor Transactions List */}
                <div className="w-full text-center">
                  <div className="flex items-center justify-between mb-2 px-1">
                    <h4 className="text-xs font-mono uppercase font-bold text-slate-700">
                      Verified Donor Contributions ({campaign.donations?.length || 0})
                    </h4>
                    <span className="text-[10px] font-mono text-emerald-700 font-semibold">
                      Cryptographically Logged
                    </span>
                  </div>
                  {campaign.donations && campaign.donations.length > 0 ? (
                    <div className="space-y-2 w-full">
                      {campaign.donations.map((don) => {
                        const isExpanded = expandedDonorId === don.id;
                        return (
                          <div
                            key={don.id}
                            onClick={() => setExpandedDonorId(prev => prev === don.id ? null : don.id)}
                            className={`p-3 rounded-2xl border transition-colors cursor-pointer text-xs space-y-2 ${
                              isExpanded
                                ? 'border-emerald-400 bg-emerald-50/40'
                                : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2.5 text-left min-w-0">
                                <img
                                  src={don.donorAvatar}
                                  alt={don.donorName}
                                  className="w-7 h-7 rounded-full object-cover border border-slate-200 shrink-0"
                                />
                                <div className="min-w-0">
                                  <span className="font-semibold text-slate-900 block truncate">{don.donorName}</span>
                                  <span className="text-[10px] font-mono text-slate-500 block truncate">
                                    @{don.donorHandle || 'anonymous'} · {new Date(don.timestamp).toLocaleDateString()}
                                    {don.message ? ' · Note attached' : ''}
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <div className="text-right">
                                  <span className="font-mono font-bold text-emerald-700 block tabular-nums">
                                    +F {don.amountUSD.toLocaleString()} FC
                                  </span>
                                  <span className="text-[10px] font-mono text-slate-600 block mt-0.5">
                                    {don.originalAmount && don.originalCurrency
                                      ? `${don.originalAmount.toLocaleString()} ${don.originalCurrency} (${don.modality})`
                                      : don.modality}
                                  </span>
                                </div>
                                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isExpanded ? 'rotate-180 text-emerald-600' : ''}`} />
                              </div>
                            </div>

                            {isExpanded && (
                              <div className="pt-2 border-t border-slate-200/80 text-left space-y-1">
                                <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase text-slate-500 font-semibold">
                                  <MessageSquare className="w-3 h-3 text-emerald-600" />
                                  <span>Contribution Note / Message</span>
                                </div>
                                <p className={`text-xs leading-relaxed ${don.message ? 'text-slate-800 italic' : 'text-slate-400'}`}>
                                  {don.message ? `"${don.message}"` : 'No contribution note / message was included with this pledge.'}
                                </p>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-4 text-center rounded-2xl bg-slate-50 border border-slate-200 text-slate-500 text-xs">
                      No public donor transactions recorded yet for this vault.
                    </div>
                  )}
                </div>

                {/* Trust Seal */}
                <div className="flex items-center justify-center gap-2 text-[11px] font-mono text-emerald-700 bg-emerald-50/70 border border-emerald-200/80 p-2.5 rounded-2xl w-full">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>On-Chain Multi-Signature Escrow Vault Active</span>
                </div>

                {/* Close Button */}
                <button
                  type="button"
                  onClick={() => setIsAuditModalOpen(false)}
                  className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Close Audit Ledger
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: SHARE ON TWEETING (WITH NOTE) ================= */}
      <ShareOnTweetingModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        campaign={campaign}
        currentUser={currentUser}
      />
    </div>
  );
};
