import { PrivyNetworkKey } from '../config/privyConfig';
import { getWalletCurrencyBalance, inferCurrencyCategory } from './walletBalanceUpdater';

export interface FeeBreakdown {
  subtotalUSD: number;
  feeUSD: number;
  totalUSD: number;
  feeLabel: string;
}

export interface PrivyGasEstimate {
  networkKey: PrivyNetworkKey;
  nativeSymbol: string;
  nativeUnits: number;
  nativePriceUSD: number;
  feeUSD: number;
  label: string;
}

const KNOWN_CURRENCY_NAMES: Record<string, string> = {
  USD: 'United States Dollar',
  CHF: 'Swiss Franc',
  GBP: 'British Pound Sterling',
  EUR: 'Euro',
  USDC: 'USD Coin',
  USDT: 'Tether USD',
  EURC: 'Euro Coin',
  PAXG: 'PAX Gold',
  BTC: 'Bitcoin',
  ETH: 'Ethereum',
  SOL: 'Solana',
  POL: 'Polygon POL',
  AFNL: 'Final Admin Coin',
  VANC: 'Vance Sovereign Gold Final Coin',
  ASOV: 'Aurora Sovereign Final Coin',
  WOLF: 'Wolf Sovereign Final Coin',
  STRL: 'Sterling Bullion Final Coin',
  'FNL-GOLD': 'Imperial Gold Bullion Coin',
  'FNL-SWISS': 'Zurich Reserve Sovereign Coin',
};

export function getCurrencyDisplayName(symbol: string): string {
  const clean = (symbol || '').trim().toUpperCase();
  return KNOWN_CURRENCY_NAMES[clean] || clean;
}

/**
 * Standard Stripe card processing fee: 2.9% + $0.30 USD.
 */
export function calculateStripeCardFee(subtotalUSD: number): number {
  if (!Number.isFinite(subtotalUSD) || subtotalUSD <= 0) return 0;
  return Math.round((subtotalUSD * 0.029 + 0.30) * 100) / 100;
}

/**
 * Standard ACH / verified bank transfer fee ($0.00).
 */
export function calculateStripeBankFee(): number {
  return 0;
}

const PRIVY_GAS_TABLE: Record<
  PrivyNetworkKey,
  { nativeSymbol: string; baseUnits: number; erc20Multiplier: number; nativePriceUSD: number; label: string }
> = {
  ethereum: {
    nativeSymbol: 'ETH',
    baseUnits: 0.0009,
    erc20Multiplier: 1.45,
    nativePriceUSD: 2820,
    label: 'Ethereum Mainnet Gas',
  },
  base: {
    nativeSymbol: 'ETH',
    baseUnits: 0.00002,
    erc20Multiplier: 1.5,
    nativePriceUSD: 2820,
    label: 'Base L2 Gas',
  },
  arbitrum: {
    nativeSymbol: 'ETH',
    baseUnits: 0.00003,
    erc20Multiplier: 1.4,
    nativePriceUSD: 2820,
    label: 'Arbitrum One Gas',
  },
  polygon: {
    nativeSymbol: 'POL',
    baseUnits: 0.04,
    erc20Multiplier: 1.5,
    nativePriceUSD: 0.55,
    label: 'Polygon PoS Gas',
  },
};

export function calculatePrivyNetworkFee(params?: {
  networkKey?: PrivyNetworkKey | string;
  isErc20?: boolean;
}): PrivyGasEstimate {
  const keyRaw = (params?.networkKey || 'ethereum').toLowerCase();
  const networkKey: PrivyNetworkKey =
    keyRaw === 'base' || keyRaw === 'polygon' || keyRaw === 'arbitrum' ? keyRaw : 'ethereum';
  const entry = PRIVY_GAS_TABLE[networkKey];
  const multiplier = params?.isErc20 ? entry.erc20Multiplier : 1;
  const nativeUnits = Number((entry.baseUnits * multiplier).toFixed(6));
  const feeUSD = Math.max(0.01, Math.round(nativeUnits * entry.nativePriceUSD * 100) / 100);
  return {
    networkKey,
    nativeSymbol: entry.nativeSymbol,
    nativeUnits,
    nativePriceUSD: entry.nativePriceUSD,
    feeUSD,
    label: `Privy ${entry.label}`,
  };
}

export type WalletProviderId = 'stripe_wallet' | 'privy_wallet' | 'none';

export interface WalletPurchaseFeeResult {
  walletProvider: WalletProviderId;
  walletProviderLabel: string;
  feeUSD: number;
  feeLabel: string;
  networkKey?: PrivyNetworkKey;
  nativeSymbol?: string;
  nativeUnits?: number;
  isErc20?: boolean;
}

const ERC20_OR_TOKEN_SYMBOLS = new Set([
  'USDC',
  'USDT',
  'EURC',
  'EURS',
  'PAXG',
  'DAI',
  'PYUSD',
  'BUSD',
  'TUSD',
  'USDD',
  'FDUSD',
  'BDRS',
  'ASVD',
  'LINK',
  'UNI',
  'WBTC',
  'WETH',
  'ARB',
]);

export function inferPrivyNetworkKey(symbol?: string, network?: string): PrivyNetworkKey {
  const netLower = (network || '').toLowerCase();
  const symUpper = (symbol || '').trim().toUpperCase();
  if (netLower.includes('base')) return 'base';
  if (netLower.includes('arbitrum')) return 'arbitrum';
  if (netLower.includes('polygon') || netLower.includes('matic') || symUpper === 'POL' || symUpper === 'MATIC') {
    return 'polygon';
  }
  return 'ethereum';
}

export function isErc20CryptoSymbol(symbol?: string, category?: string): boolean {
  const catLower = (category || '').toLowerCase();
  if (catLower === 'stable_coin' || catLower === 'stable_coins' || catLower === 'stablecoin') {
    return true;
  }
  const symUpper = (symbol || '').trim().toUpperCase();
  if (!symUpper) return false;
  return ERC20_OR_TOKEN_SYMBOLS.has(symUpper);
}

/**
 * Canonical wallet fee calculator for any purchase or settlement:
 * - Fiat -> Stripe Wallet (2.9% + $0.30 USD, or $0.00 only for verified ACH bank transfers)
 * - Stablecoins -> Privy Wallet (ERC-20 network gas fee)
 * - Cryptocurrency -> Privy Wallet (native or token gas fee)
 * - Final Coins / Direct Barter -> $0.00 fee
 */
export function calculateWalletPurchaseFee(params: {
  category:
    | 'fiat'
    | 'fiat_currency'
    | 'stable_coin'
    | 'stable_coins'
    | 'crypto'
    | 'final_coin'
    | 'final_coins'
    | 'gold_bullion'
    | 'barter';
  subtotalUSD: number;
  symbol?: string;
  network?: string;
  isBankAch?: boolean;
}): WalletPurchaseFeeResult {
  const { category, subtotalUSD, symbol, network, isBankAch } = params;
  if (!Number.isFinite(subtotalUSD) || subtotalUSD <= 0) {
    return {
      walletProvider: 'none',
      walletProviderLabel: 'Sovereign Clearing',
      feeUSD: 0,
      feeLabel: 'Wallet Fee',
    };
  }

  if (
    category === 'final_coin' ||
    category === 'final_coins' ||
    category === 'barter' ||
    category === 'gold_bullion'
  ) {
    return {
      walletProvider: 'none',
      walletProviderLabel: 'Sovereign Final Clearing',
      feeUSD: 0,
      feeLabel: 'Protocol Clearing Fee',
    };
  }

  if (category === 'fiat' || category === 'fiat_currency') {
    if (isBankAch) {
      return {
        walletProvider: 'stripe_wallet',
        walletProviderLabel: 'Stripe Wallet (ACH)',
        feeUSD: calculateStripeBankFee(),
        feeLabel: 'Stripe Wallet ACH Fee',
      };
    }
    const feeUSD = calculateStripeCardFee(subtotalUSD);
    return {
      walletProvider: 'stripe_wallet',
      walletProviderLabel: 'Stripe Wallet',
      feeUSD,
      feeLabel: 'Stripe Wallet Fee (2.9% + $0.30)',
    };
  }

  const networkKey = inferPrivyNetworkKey(symbol, network);
  const isErc20 = isErc20CryptoSymbol(symbol, category);
  const gas = calculatePrivyNetworkFee({ networkKey, isErc20 });
  const chainLabel = gas.label.replace(/^Privy\s+/i, '');

  return {
    walletProvider: 'privy_wallet',
    walletProviderLabel: 'Privy Wallet',
    feeUSD: gas.feeUSD,
    feeLabel: `Privy Wallet Fee (${chainLabel})`,
    networkKey: gas.networkKey,
    nativeSymbol: gas.nativeSymbol,
    nativeUnits: gas.nativeUnits,
    isErc20,
  };
}

export function formatUnitsForDisplay(amount: number, maxDecimals: number = 4): string {
  if (!Number.isFinite(amount)) return '0';
  return amount.toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: maxDecimals,
  });
}

/**
 * Formats an explicit error message distinguishing between:
 * 1) User does NOT hold the currency at all (available <= 0)
 * 2) User holds some, but not enough to cover required amount (0 < available < required)
 */
export function formatInsufficientCurrencyError(params: {
  symbol: string;
  name?: string;
  available: number;
  required: number;
  maxDecimals?: number;
}): string {
  const sym = (params.symbol || 'USD').trim().toUpperCase();
  const displayName = params.name?.trim() || getCurrencyDisplayName(sym);
  const nameTag = displayName && displayName.toUpperCase() !== sym ? ` (${displayName})` : '';
  const available = Math.max(0, Number(params.available || 0));
  const required = Math.max(0, Number(params.required || 0));
  const decimals =
    params.maxDecimals ??
    (inferCurrencyCategory(sym) === 'crypto' ? 6 : 2);

  const reqFormatted = formatUnitsForDisplay(required, decimals);
  const availFormatted = formatUnitsForDisplay(available, decimals);

  if (available <= 1e-8) {
    return `You do not have ${sym}${nameTag} in your wallet (Available: 0 ${sym}, Required: ${reqFormatted} ${sym}).`;
  }

  const shortfall = Math.max(0, required - available);
  const shortFormatted = formatUnitsForDisplay(shortfall, decimals);
  return `You do not have enough ${sym}${nameTag} in your wallet (Available: ${availFormatted} ${sym}, Required: ${reqFormatted} ${sym}, Short by: ${shortFormatted} ${sym}).`;
}

export function checkWalletCurrencySufficiency(
  userId: string,
  symbol: string,
  requiredAmount: number,
  currencyName?: string
): { sufficient: boolean; available: number; required: number; error?: string } {
  const available = getWalletCurrencyBalance(userId, symbol);
  if (available + 1e-6 >= requiredAmount) {
    return { sufficient: true, available, required: requiredAmount };
  }
  return {
    sufficient: false,
    available,
    required: requiredAmount,
    error: formatInsufficientCurrencyError({
      symbol,
      name: currencyName,
      available,
      required: requiredAmount,
    }),
  };
}
