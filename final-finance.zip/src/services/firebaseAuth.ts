import { AuthSession } from '../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';

export function getRoleForEmail(email?: string): 'super_admin' | 'admin' | 'user' {
  if (!email) return 'user';
  const clean = email.trim().toLowerCase();
  if (clean === 'ranmaanimaker@gmail.com') return 'super_admin';
  if (clean === 'awesomedbz@gmail.com') return 'admin';
  return 'user';
}

export const DEMO_ACCOUNTS: Record<string, AuthSession> = {
  ranma: {
    uid: 'demo-ranma-superadmin',
    id: 'super_admin_ranma',
    name: 'Ranma',
    email: 'ranmaanimaker@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Verified participant in Final Finance.',
    role: 'super_admin',
    provider: 'demo',
    isVerified: true,
    verification: {
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: 'Institutional Member Pass',
      idDocument1Type: 'Identity Certificate',
      idDocument1Name: 'ID_Document_01.crt',
      idDocument1Number: 'ID-KEY-001-ALPHA',
      idDocument2Type: 'Institutional Hardware Key',
      idDocument2Name: 'Security_Token.pem',
      idDocument2Issuer: 'Final Finance Identity Authority',
      verifiedAt: '2026-01-01T00:00:00Z',
      nextBillingDate: '2099-01-01T00:00:00Z',
      paymentMethod: 'Protocol Reserve Settlement',
      lastFour: '0001'
    },
    user: {
      name: 'Ranma',
      email: 'ranmaanimaker@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'
    }
  },
  dbz: {
    uid: 'demo-dbz-admin',
    id: 'officer_dbz',
    name: 'Awesome DBZ',
    email: 'awesomedbz@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    bio: 'Verified participant in Final Finance.',
    role: 'admin',
    provider: 'demo',
    isVerified: true,
    verification: {
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: 'Institutional Member Pass',
      idDocument1Type: 'Identity Credential',
      idDocument1Name: 'ID_Document_DBZ.pdf',
      idDocument1Number: 'ID-DBZ-7789',
      idDocument2Type: 'Security Token',
      idDocument2Name: 'Security_Token_Zurich.pem',
      idDocument2Issuer: 'Zurich Vault Authority',
      verifiedAt: '2026-01-10T12:00:00Z',
      nextBillingDate: '2099-01-01T00:00:00Z',
      paymentMethod: 'Institutional Clearing Settlement',
      lastFour: '7789'
    },
    user: {
      name: 'Awesome DBZ',
      email: 'awesomedbz@gmail.com',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80'
    }
  },
  jordan: {
    uid: 'demo-jordan-belfort',
    id: 'jordan_belfort',
    name: 'Jordan Belfort',
    email: 'jordan@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Founder & Chief Reserve Allocator at Final Finance. Overseeing $4.2B in tokenized reserve vaults.',
    role: 'admin',
    provider: 'demo',
    isVerified: true,
    verification: {
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: '$2.00 / month KYC & ID Verification',
      idDocument1Type: "Passport",
      idDocument1Name: 'US_Passport_JB_Verified.pdf',
      idDocument1Number: 'USA-94827103',
      idDocument2Type: "Driver's License",
      idDocument2Name: 'NY_Driver_License_FrontBack.png',
      idDocument2Issuer: 'New York DMV',
      verifiedAt: '2026-01-15T10:00:00Z',
      nextBillingDate: '2026-09-15T10:00:00Z',
      paymentMethod: 'Visa ending in 4242',
      lastFour: '4242'
    },
    user: {
      name: 'Jordan Belfort',
      email: 'jordan@finalfinance.io',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
    }
  },
  satoshi: {
    uid: 'demo-satoshi-nakamoto',
    id: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    email: 'satoshi@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks.',
    role: 'user',
    provider: 'demo',
    isVerified: true,
    verification: {
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: '$2.00 / month KYC & ID Verification',
      idDocument1Type: 'National ID Card',
      idDocument1Name: 'JP_MyNumber_Card_Encrypted.pdf',
      idDocument1Number: 'JPN-88392019',
      idDocument2Type: 'Utility Bill (Proof of Address)',
      idDocument2Name: 'Tokyo_Electric_Statement.pdf',
      idDocument2Issuer: 'TEPCO Energy',
      verifiedAt: '2026-02-01T08:30:00Z',
      nextBillingDate: '2026-09-01T08:30:00Z',
      paymentMethod: 'Mastercard ending in 8899',
      lastFour: '8899'
    },
    user: {
      name: 'Satoshi Nakamoto',
      email: 'satoshi@finalfinance.io',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'
    }
  },
  alex: {
    uid: 'demo-alex-morgan',
    id: 'alex_morgan',
    name: 'Alex Morgan',
    email: 'alex@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Institutional Commodity Desk Arbiter. Swiss Vault & Gold Bullion Reserve specialist.',
    role: 'user',
    provider: 'demo',
    isVerified: true,
    verification: {
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: '$2.00 / month KYC & ID Verification',
      idDocument1Type: "Passport",
      idDocument1Name: 'CH_Swiss_Passport.pdf',
      idDocument1Number: 'CHE-55419028',
      idDocument2Type: 'Bank Statement (Proof of Solvency)',
      idDocument2Name: 'UBS_Zurich_Certified_Statement.pdf',
      idDocument2Issuer: 'UBS Switzerland AG',
      verifiedAt: '2026-03-10T14:15:00Z',
      nextBillingDate: '2026-09-10T14:15:00Z',
      paymentMethod: 'Swiss Card ending in 1902',
      lastFour: '1902'
    },
    user: {
      name: 'Alex Morgan',
      email: 'alex@finalfinance.io',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80'
    }
  },
  guest: {
    uid: 'demo-guest-trader',
    id: 'guest_trader',
    name: 'Guest Explorer',
    email: 'guest@finalfinance.io',
    avatarUrl: '',
    bio: 'Decentralized ecosystem explorer evaluating multi-asset vaults and barter opportunities.',
    role: 'guest',
    provider: 'demo',
    isVerified: false,
    user: {
      name: 'Guest Explorer',
      email: 'guest@finalfinance.io',
      avatar: ''
    }
  }
};

const SESSION_STORAGE_KEY = 'final_finance_auth_session';
const REGISTERED_USERS_KEY = 'final_finance_registered_users';

export interface RegisteredAccount {
  email: string;
  passwordHash: string;
  name: string;
  userId: string;
  avatarUrl: string;
}

// Initial registered credentials (lowercase emails)
const DEFAULT_USER_REGISTRY: Record<string, RegisteredAccount> = {
  'ranmaanimaker@gmail.com': {
    email: 'ranmaanimaker@gmail.com',
    passwordHash: 'password123',
    name: 'Ranma',
    userId: 'super_admin_ranma',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80'
  },
  'awesomedbz@gmail.com': {
    email: 'awesomedbz@gmail.com',
    passwordHash: 'password123',
    name: 'Awesome DBZ',
    userId: 'officer_dbz',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80'
  },
  'gholu653@gmail.com': {
    email: 'gholu653@gmail.com',
    passwordHash: 'gholu123',
    name: 'Gholu',
    userId: 'gholu653',
    avatarUrl: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128'
  },
  'jordan@finalfinance.io': {
    email: 'jordan@finalfinance.io',
    passwordHash: 'password123',
    name: 'Jordan Belfort',
    userId: 'jordan_belfort',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
  },
  'satoshi@finalfinance.io': {
    email: 'satoshi@finalfinance.io',
    passwordHash: 'bitcoin2009',
    name: 'Satoshi Nakamoto',
    userId: 'satoshi_nakamoto',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'
  },
  'trader.alex@gmail.com': {
    email: 'trader.alex@gmail.com',
    passwordHash: 'alex123',
    name: 'Trader Alex',
    userId: 'trader_alex',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=128&q=80'
  }
};

export function getRegisteredUsers(): Record<string, RegisteredAccount> {
  try {
    const raw = localStorage.getItem(REGISTERED_USERS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_USER_REGISTRY, ...parsed };
    }
  } catch (e) {
    // ignore
  }
  return { ...DEFAULT_USER_REGISTRY };
}

export function saveRegisteredUser(account: RegisteredAccount): void {
  try {
    const current = getRegisteredUsers();
    current[account.email.toLowerCase().trim()] = account;
    localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(current));
  } catch (e) {
    // ignore
  }
}

export function getCurrentSession(): AuthSession | null {
  try {
    const saved = localStorage.getItem(SESSION_STORAGE_KEY);
    if (saved) {
      const parsed: AuthSession = JSON.parse(saved);
      if (parsed.bio === 'Verified Google participant in Final Finance.') {
        parsed.bio = '';
      }
      const role = getRoleForEmail(parsed.email);
      if (role !== 'user' && parsed.role !== role) {
        parsed.role = role;
      }
      return parsed;
    }
  } catch (err) {
    console.warn('Error reading auth session', err);
  }
  return null;
}

export function saveSession(session: AuthSession): void {
  try {
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
  } catch (err) {
    console.warn('Error saving auth session', err);
  }
}

export function clearSession(): void {
  try {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    localStorage.removeItem('final_finance_google_accounts');
    sessionStorage.clear();
  } catch (err) {
    console.warn('Error clearing auth session', err);
  }
}

export async function signInWithDemoAccount(key: keyof typeof DEMO_ACCOUNTS): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const account = DEMO_ACCOUNTS[key];
  if (account) {
    saveSession(account);
    return { success: true, user: account };
  }
  return { success: false, error: 'Account preset not found' };
}

/**
 * Strict Google/Gmail Authentication with password verification
 */
export async function signInWithGoogle(
  customEmail: string, 
  password?: string,
  isCreateMode: boolean = false
): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  if (!customEmail || !customEmail.trim()) {
    return { success: false, error: 'Email address is required.' };
  }

  const email = customEmail.trim().toLowerCase();
  const role = getRoleForEmail(email);
  const username = email === 'ranmaanimaker@gmail.com'
    ? 'super_admin_ranma'
    : (email === 'awesomedbz@gmail.com' ? 'officer_dbz' : (email.split('@')[0] || 'user'));
  
  const defaultDisplayName = email === 'ranmaanimaker@gmail.com'
    ? 'Ranma'
    : (email === 'awesomedbz@gmail.com' ? 'Awesome DBZ' : (username.charAt(0).toUpperCase() + username.slice(1)));

  const avatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(defaultDisplayName)}&background=f59e0b&color=0f172a&bold=true&size=128`;

  const users = getRegisteredUsers();
  const existing = users[email];

  if (password !== undefined) {
    const trimmedPass = password.trim();
    if (!trimmedPass) {
      return { success: false, error: 'Please enter your password.' };
    }

    if (existing) {
      // STRICT password verification
      if (existing.passwordHash !== trimmedPass) {
        return { 
          success: false, 
          error: 'Wrong password. Try again or click Forgot password to reset.' 
        };
      }
    } else {
      if (!isCreateMode) {
        // If not explicitly creating an account, check if account exists
        return {
          success: false,
          error: "Couldn't find your Google Account. Click 'Create account' to register with this email."
        };
      }

      // In create mode: register new credentials
      if (trimmedPass.length < 4) {
        return { success: false, error: 'Password must be at least 4 characters.' };
      }
      saveRegisteredUser({
        email,
        passwordHash: trimmedPass,
        name: defaultDisplayName,
        userId: username,
        avatarUrl: avatar,
      });
    }
  }

  const googleUser: AuthSession = {
    uid: `google-${username}`,
    id: username,
    name: existing?.name || defaultDisplayName,
    email: email,
    avatarUrl: existing?.avatarUrl || avatar,
    bio: '',
    role: role,
    provider: 'google',
    isVerified: true,
    user: {
      name: existing?.name || defaultDisplayName,
      email: email,
      avatar: existing?.avatarUrl || avatar
    }
  };
  saveSession(googleUser);
  return { success: true, user: googleUser };
}

export async function signInWithCredentials(identifier: string, pass: string): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const cleanId = identifier.trim().toLowerCase().replace(/^@/, '');
  const isEmail = cleanId.includes('@');
  const email = isEmail ? cleanId : `${cleanId}@finalfinance.io`;

  if (!pass || pass.trim().length === 0) {
    return { success: false, error: 'Please enter your password.' };
  }

  const users = getRegisteredUsers();
  const existing = users[email] || Object.values(users).find(u => u.userId.toLowerCase() === cleanId);

  if (existing) {
    if (existing.passwordHash !== pass.trim()) {
      return { success: false, error: 'Wrong password. Try again or click Forgot password.' };
    }
  } else {
    return { success: false, error: 'No account found with this User ID or Email.' };
  }

  const role = getRoleForEmail(email);

  const user: AuthSession = {
    uid: 'user-' + cleanId,
    id: cleanId,
    name: existing?.name || (isEmail ? cleanId.split('@')[0] : cleanId),
    email: email,
    avatarUrl: existing?.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(cleanId)}&background=f1f5f9&color=0f172a&size=128`,
    bio: role === 'super_admin' ? 'Super Administrator & Sovereign Reserve Master Keyholder.' : (role === 'admin' ? 'Custody & Escrow Admin Officer.' : 'Final Finance verified participant.'),
    role: role,
    provider: 'password',
    isVerified: true,
    user: {
      name: existing?.name || (isEmail ? cleanId.split('@')[0] : cleanId),
      email: email,
      avatar: existing?.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(cleanId)}&background=f1f5f9&color=0f172a&size=128`
    }
  };
  saveSession(user);
  return { success: true, user };
}

export async function registerWithCredentials(data: {
  fullName: string;
  userId: string;
  email: string;
  password?: string;
}): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const email = data.email.trim().toLowerCase();
  const pass = (data.password || '').trim();

  if (!pass || pass.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters long.' };
  }

  saveRegisteredUser({
    email,
    passwordHash: pass,
    name: data.fullName.trim(),
    userId: data.userId.trim().toLowerCase(),
    avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.fullName)}&background=f1f5f9&color=0f172a&size=128`,
  });

  const role = getRoleForEmail(email);

  const user: AuthSession = {
    uid: 'user-' + data.userId,
    id: data.userId,
    name: data.fullName,
    email: email,
    avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.fullName)}&background=f1f5f9&color=0f172a&size=128`,
    bio: role === 'super_admin' ? 'Super Administrator & Sovereign Reserve Master Keyholder.' : (role === 'admin' ? 'Custody & Escrow Admin Officer.' : 'Verified ecosystem participant.'),
    role: role,
    provider: 'password',
    isVerified: true,
    user: {
      name: data.fullName,
      email: email,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(data.fullName)}&background=f1f5f9&color=0f172a&size=128`
    }
  };
  saveSession(user);

  // Credit 4000 Final Admin Coins sign-up subsidy bonus (one-time)
  try {
    const wallet = getStoredUserWallets(data.userId);
    const afnlIdx = wallet.finalCoins.findIndex(c => c.symbol === 'AFNL');
    if (afnlIdx >= 0) {
      wallet.finalCoins[afnlIdx].balance += 4000;
    } else {
      wallet.finalCoins.unshift({
        id: 'fc-signup-bonus',
        name: 'Final Admin Coin',
        symbol: 'AFNL',
        balance: 4000,
        unitPriceUSD: 28.75,
        change24h: 3.84,
        utility: 'One-time registration sign-up subsidy allocation.'
      });
    }
    saveStoredUserWallets(data.userId, wallet);
  } catch (err) {
    console.warn('Failed to credit sign-up bonus', err);
  }

  return { success: true, user };
}

export async function requestPasswordReset(identifier: string): Promise<{ success: boolean; emailSentTo?: string; error?: string }> {
  return { success: true, emailSentTo: identifier.includes('@') ? identifier : `${identifier}@domain.com` };
}

export function checkUserIdAvailability(
  newUserId: string,
  currentUserId?: string
): { available: boolean; message?: string } {
  const clean = (newUserId || '').trim().toLowerCase().replace(/^@/, '');
  const cleanCurrent = (currentUserId || '').trim().toLowerCase().replace(/^@/, '');

  if (!clean) {
    return { available: false, message: 'User ID handle is required.' };
  }
  if (clean.length < 3) {
    return { available: false, message: 'User ID must be at least 3 characters.' };
  }
  if (!/^[a-z0-9_.-]+$/.test(clean)) {
    return { available: false, message: 'User ID can only contain letters, numbers, underscores, dashes, and periods.' };
  }
  if (clean === cleanCurrent) {
    return { available: true, message: 'Current User ID' };
  }

  // Check registered accounts
  const registered = getRegisteredUsers();
  for (const acc of Object.values(registered)) {
    if (acc.userId && acc.userId.toLowerCase().replace(/^@/, '') === clean) {
      return { available: false, message: `@${clean} is already taken.` };
    }
  }

  // Check demo accounts
  for (const acc of Object.values(DEMO_ACCOUNTS)) {
    if (acc.id && acc.id.toLowerCase().replace(/^@/, '') === clean) {
      return { available: false, message: `@${clean} is already taken.` };
    }
  }

  // Check known sample handles
  const knownHandles = [
    'jordan_belfort',
    'satoshi_nakamoto',
    'alex_morgan',
    'guest_trader',
    'super_admin_ranma',
    'officer_dbz',
    'sterling_vault',
    'elena_rostova',
    'marcus_vance'
  ];
  if (knownHandles.includes(clean)) {
    return { available: false, message: `@${clean} is already taken.` };
  }

  return { available: true, message: `@${clean} is available!` };
}

export function checkEmailAvailability(
  newEmail: string,
  currentEmail?: string
): { available: boolean; message?: string } {
  const clean = (newEmail || '').trim().toLowerCase();
  const cleanCurrent = (currentEmail || '').trim().toLowerCase();

  if (!clean) {
    return { available: false, message: 'Email address is required.' };
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean)) {
    return { available: false, message: 'Invalid email address format.' };
  }
  if (clean === cleanCurrent) {
    return { available: true, message: 'Current Email' };
  }

  // Check registered accounts
  const registered = getRegisteredUsers();
  if (registered[clean]) {
    return { available: false, message: 'This email is already registered.' };
  }

  // Check demo accounts
  for (const acc of Object.values(DEMO_ACCOUNTS)) {
    if (acc.email && acc.email.toLowerCase() === clean) {
      return { available: false, message: 'This email is already registered.' };
    }
  }

  return { available: true, message: 'Email is available!' };
}

export async function updateUserAccountProfile(data: {
  fullName: string;
  userId: string;
  avatarUrl?: string;
  coverUrl?: string;
  bio?: string;
  gender?: 'male' | 'female' | 'other' | '';
  email?: string;
  newPassword?: string;
}): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const current = getCurrentSession();
  const cleanUserId = (data.userId || current?.id || '').trim().toLowerCase().replace(/^@/, '');
  const cleanEmail = (data.email || current?.email || '').trim().toLowerCase();

  // Validate User ID availability if changed
  if (current && cleanUserId !== current.id.toLowerCase().replace(/^@/, '')) {
    const idCheck = checkUserIdAvailability(cleanUserId, current.id);
    if (!idCheck.available) {
      return { success: false, error: idCheck.message || 'User ID is unavailable.' };
    }
  }

  // Validate Email availability if changed
  if (current && cleanEmail && current.email && cleanEmail !== current.email.toLowerCase()) {
    const emailCheck = checkEmailAvailability(cleanEmail, current.email);
    if (!emailCheck.available) {
      return { success: false, error: emailCheck.message || 'Email is unavailable.' };
    }
  }

  const updated: AuthSession = {
    ...current,
    name: data.fullName.trim() || current?.name || 'Citizen',
    id: cleanUserId || current?.id || 'citizen',
    avatarUrl: data.avatarUrl !== undefined ? data.avatarUrl : (current?.avatarUrl || ''),
    coverUrl: data.coverUrl !== undefined ? data.coverUrl : (current?.coverUrl || ''),
    bio: data.bio !== undefined ? data.bio : (current?.bio || ''),
    gender: data.gender !== undefined ? data.gender : (current?.gender || ''),
    email: cleanEmail || current?.email || '',
    user: {
      name: data.fullName.trim() || current?.name || 'Citizen',
      email: cleanEmail || current?.email || '',
      avatar: data.avatarUrl !== undefined ? data.avatarUrl : (current?.avatarUrl || '')
    }
  };

  // Sync with registered users
  const registered = getRegisteredUsers();
  const oldEmail = current?.email?.toLowerCase() || '';
  if (oldEmail && registered[oldEmail]) {
    const existing = registered[oldEmail];
    delete registered[oldEmail];
    registered[cleanEmail] = {
      ...existing,
      email: cleanEmail,
      name: updated.name,
      userId: updated.id,
      avatarUrl: updated.avatarUrl || '',
      passwordHash: data.newPassword ? data.newPassword.trim() : existing.passwordHash,
    };
    try {
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(registered));
    } catch {}
  } else if (cleanEmail) {
    saveRegisteredUser({
      email: cleanEmail,
      passwordHash: data.newPassword ? data.newPassword.trim() : 'password123',
      name: updated.name,
      userId: updated.id,
      avatarUrl: updated.avatarUrl || '',
    });
  }

  saveSession(updated);
  return { success: true, user: updated };
}

export async function verifyUserWithSubscription(data: {
  idDocument1Type: string;
  idDocument1Name: string;
  idDocument1Number?: string;
  idDocument2Type: string;
  idDocument2Name: string;
  idDocument2Issuer?: string;
  paymentMethod: string;
  lastFour?: string;
}): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found. Please sign in.' };
  }

  const nextMonth = new Date();
  nextMonth.setMonth(nextMonth.getMonth() + 1);

  const updated: AuthSession = {
    ...current,
    isVerified: true,
    verification: {
      verified: true,
      status: 'verified',
      monthlyFee: 2,
      subscriptionActive: true,
      subscriptionPlan: '$2.00 / month KYC & ID Verification',
      idDocument1Type: data.idDocument1Type,
      idDocument1Name: data.idDocument1Name,
      idDocument1Number: data.idDocument1Number || 'DOC-1-VERIFIED',
      idDocument2Type: data.idDocument2Type,
      idDocument2Name: data.idDocument2Name,
      idDocument2Issuer: data.idDocument2Issuer || 'Issued & Authenticated',
      verifiedAt: new Date().toISOString(),
      nextBillingDate: nextMonth.toISOString(),
      paymentMethod: data.paymentMethod,
      lastFour: data.lastFour || '4242'
    }
  };

  saveSession(updated);
  return { success: true, user: updated };
}

export async function cancelUserSubscription(): Promise<{ success: boolean; user?: AuthSession; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found.' };
  }

  const updated: AuthSession = {
    ...current,
    isVerified: false,
    verification: current.verification ? {
      ...current.verification,
      verified: false,
      status: 'unverified',
      subscriptionActive: false
    } : undefined
  };

  saveSession(updated);
  return { success: true, user: updated };
}

export async function signOut(): Promise<void> {
  clearSession();
}

export async function deactivateUserAccount(): Promise<{ success: boolean; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found.' };
  }
  const email = current.email?.toLowerCase().trim();
  const registered = getRegisteredUsers();
  if (email && registered[email]) {
    registered[email] = {
      ...registered[email],
    };
    try {
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(registered));
    } catch {}
  }
  clearSession();
  return { success: true };
}

export async function deleteUserAccount(): Promise<{ success: boolean; error?: string }> {
  const current = getCurrentSession();
  if (!current) {
    return { success: false, error: 'No active session found.' };
  }
  const email = current.email?.toLowerCase().trim();
  const registered = getRegisteredUsers();
  if (email && registered[email]) {
    delete registered[email];
    try {
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(registered));
    } catch {}
  }
  try {
    localStorage.removeItem(`final_finance_wallets_${current.id}`);
  } catch {}
  clearSession();
  return { success: true };
}

