import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  X,
  ArrowDownUp,
  Check,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from './common/ConfirmModal';
import { recordLedgerTransaction, createLedgerItemFromVaultSwap } from '../utils/universalLedgerBridge';
import { applyCurrencyWalletDelta, getWalletCurrencyBalance } from '../utils/walletBalanceUpdater';
import { getStoredUserWallets } from '../data/defaultWallets';
import { formatInsufficientCurrencyError } from '../utils/transactionFees';

interface InstantSwapModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AuthSession | null;
}

interface SwapCurrencyOption {
  symbol: string;
  name: string;
  rateUSD: number;
  balance: number;
  category: 'fiat' | 'stable_coin' | 'crypto';
}

export const InstantSwapModal: React.FC<InstantSwapModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const { addToast, addNotification } = useApp();
  const activeUserId = currentUser?.id || 'guest';

  const [walletVersion, setWalletVersion] = useState(0);
  const [fromAsset, setFromAsset] = useState<string>('USDC');
  const [toAsset, setToAsset] = useState<string>('USD');
  const [fromAmount, setFromAmount] = useState<number>(500);
  const [isSwapping, setIsSwapping] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [swapError, setSwapError] = useState('');

  useEffect(() => {
    const refresh = () => setWalletVersion((v) => v + 1);
    window.addEventListener('final_finance_wallets_updated', refresh);
    return () => window.removeEventListener('final_finance_wallets_updated', refresh);
  }, []);

  // Build swappable currency options strictly from currencies the user actually holds in their wallet (balance > 0)
  const heldCurrencyOptions = useMemo<SwapCurrencyOption[]>(() => {
    void walletVersion;
    const wallet = getStoredUserWallets(activeUserId);
    const list: SwapCurrencyOption[] = [];

    for (const s of wallet.stableCoins || []) {
      if (Number(s.balance || 0) > 0) {
        list.push({
          symbol: s.symbol.toUpperCase(),
          name: s.name,
          rateUSD: Number(s.unitPriceUSD || 1),
          balance: Number(s.balance || 0),
          category: 'stable_coin',
        });
      }
    }

    for (const f of wallet.fiatCurrencies || []) {
      if (Number(f.balance || 0) > 0) {
        list.push({
          symbol: f.code.toUpperCase(),
          name: f.name,
          rateUSD: Number(f.exchangeRateToUSD || 1),
          balance: Number(f.balance || 0),
          category: 'fiat',
        });
      }
    }

    for (const c of wallet.cryptoCurrencies || []) {
      if (Number(c.balance || 0) > 0) {
        list.push({
          symbol: c.symbol.toUpperCase(),
          name: c.name,
          rateUSD: Number(c.unitPriceUSD || 1),
          balance: Number(c.balance || 0),
          category: 'crypto',
        });
      }
    }

    return list;
  }, [activeUserId, walletVersion, isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    setSwapError('');
    if (heldCurrencyOptions.length > 0) {
      if (!heldCurrencyOptions.some((o) => o.symbol === fromAsset)) {
        setFromAsset(heldCurrencyOptions[0].symbol);
      }
      if (!heldCurrencyOptions.some((o) => o.symbol === toAsset) || toAsset === fromAsset) {
        const nextTo = heldCurrencyOptions.find((o) => o.symbol !== fromAsset) || heldCurrencyOptions[0];
        if (nextTo) setToAsset(nextTo.symbol);
      }
    }
  }, [isOpen, heldCurrencyOptions, fromAsset, toAsset]);

  if (!isOpen) return null;

  const fromOption = heldCurrencyOptions.find((o) => o.symbol === fromAsset) || heldCurrencyOptions[0];
  const toOption =
    heldCurrencyOptions.find((o) => o.symbol === toAsset) ||
    heldCurrencyOptions.find((o) => o.symbol !== fromOption?.symbol) ||
    heldCurrencyOptions[0];

  const effectiveFromSymbol = fromOption?.symbol || fromAsset;
  const effectiveToSymbol = toOption?.symbol || toAsset;

  const availableFromBalance = fromOption ? getWalletCurrencyBalance(activeUserId, effectiveFromSymbol) : 0;
  const fromRate = fromOption?.rateUSD || 1;
  const toRate = toOption?.rateUSD || 1;

  const estimatedReceive = ((fromAmount * fromRate) / toRate).toFixed(
    toOption?.category === 'crypto' || effectiveToSymbol === 'PAXG' ? 6 : 2
  );

  const handleInvert = () => {
    setSwapError('');
    const prevFrom = effectiveFromSymbol;
    setFromAsset(effectiveToSymbol);
    setToAsset(prevFrom);
  };

  const handleOpenConfirm = () => {
    setSwapError('');
    if (!fromOption || !toOption) {
      setSwapError('You do not have enough held currencies in your wallet to swap.');
      return;
    }
    if (effectiveFromSymbol === effectiveToSymbol) {
      setSwapError('Select two different held currencies to swap.');
      return;
    }
    if (!Number.isFinite(fromAmount) || fromAmount <= 0) {
      setSwapError('Enter a swap amount greater than 0.');
      return;
    }
    if (fromAmount > availableFromBalance + 1e-8) {
      const msg = formatInsufficientCurrencyError({
        symbol: effectiveFromSymbol,
        name: fromOption.name,
        available: availableFromBalance,
        required: fromAmount,
        maxDecimals: fromOption.category === 'crypto' ? 6 : 2,
      });
      setSwapError(msg);
      return;
    }
    setShowConfirm(true);
  };

  const handleExecuteSwap = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSwapError('');

    if (!fromOption || !toOption) {
      setShowConfirm(false);
      setSwapError('Select valid wallet currencies to swap.');
      return;
    }
    if (fromAmount <= 0 || availableFromBalance < fromAmount) {
      setShowConfirm(false);
      const msg = formatInsufficientCurrencyError({
        symbol: effectiveFromSymbol,
        name: fromOption.name,
        available: availableFromBalance,
        required: fromAmount,
        maxDecimals: fromOption.category === 'crypto' ? 6 : 2,
      });
      setSwapError(msg);
      addToast({
        title: 'Insufficient Swap Balance',
        message: msg,
        type: 'error',
      });
      return;
    }

    setIsSwapping(true);
    setShowConfirm(false);

    setTimeout(() => {
      const debitRes = applyCurrencyWalletDelta({
        userId: activeUserId,
        currencySymbol: effectiveFromSymbol,
        currencyName: fromOption.name,
        delta: -fromAmount,
        requireSufficientBalance: true,
      });
      if (!debitRes.success) {
        setIsSwapping(false);
        const msg =
          debitRes.error ||
          formatInsufficientCurrencyError({
            symbol: effectiveFromSymbol,
            name: fromOption.name,
            available: availableFromBalance,
            required: fromAmount,
          });
        setSwapError(msg);
        addToast({
          title: 'Insufficient Swap Balance',
          message: msg,
          type: 'error',
        });
        return;
      }

      const receiveAmount = Number(estimatedReceive);
      applyCurrencyWalletDelta({
        userId: activeUserId,
        currencySymbol: effectiveToSymbol,
        delta: receiveAmount,
        currencyName: toOption.name,
        unitPriceUSD: toRate,
        utilityNote: `Instant multi-vault swap from ${effectiveFromSymbol} to ${effectiveToSymbol}`,
      });

      setIsSwapping(false);
      setIsSuccess(true);

      const swapValueUSD = fromAmount * fromRate;
      const mode: 'stable_coin' | 'fiat' | 'crypto' | 'gold_bullion' | 'final_coin' =
        fromOption.category === 'fiat' || toOption.category === 'fiat'
          ? 'fiat'
          : effectiveFromSymbol === 'PAXG' || effectiveToSymbol === 'PAXG'
          ? 'gold_bullion'
          : fromOption.category === 'crypto' || toOption.category === 'crypto'
          ? 'crypto'
          : 'stable_coin';

      const ledgerItem = createLedgerItemFromVaultSwap({
        fromAsset: effectiveFromSymbol,
        toAsset: effectiveToSymbol,
        fromAmount,
        toAmount: receiveAmount,
        amountUSD: swapValueUSD,
        mode,
      });
      recordLedgerTransaction(activeUserId, ledgerItem);

      addToast({
        title: 'Instant Multi-Asset Swap Settled',
        message: `Swapped ${fromAmount} ${effectiveFromSymbol} for ${estimatedReceive} ${effectiveToSymbol} via Final Liquidity Engine.`,
        type: 'success',
      });
      addNotification({
        title: `⚡ Multi-Vault Swap Executed: ${effectiveFromSymbol} → ${effectiveToSymbol}`,
        description: `Exchanged ${fromAmount} ${effectiveFromSymbol} for ${estimatedReceive} ${effectiveToSymbol} ($${swapValueUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}) at zero slippage.`,
        type: 'vault',
        targetTab: 'vaults',
        amount: swapValueUSD,
        currency: 'USD',
      });
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
      }, 1400);
    }, 600);
  };

  return (
    <div
      id="instant-swap-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="w-full max-w-md bg-neutral-900 border border-neutral-700/80 rounded-2xl p-5 sm:p-6 shadow-2xl text-left text-neutral-100 my-auto flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-300">
              <ArrowDownUp className="h-4 w-4" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-white tracking-wide">
                Instant Multi-Vault Swapper
              </h2>
              <p className="text-xs text-neutral-400">
                Swap strictly between currencies held in your wallet
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Swap Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleOpenConfirm();
          }}
          className="mt-4 space-y-4"
        >
          {swapError && (
            <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{swapError}</span>
            </div>
          )}

          {heldCurrencyOptions.length < 2 ? (
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-300 text-center">
              You need at least two funded wallet currencies (with positive balance) to perform a swap.
            </div>
          ) : (
            <>
              {/* FROM CONTAINER */}
              <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs text-neutral-400">
                  <span>You Pay (Bal: {availableFromBalance.toLocaleString()} {effectiveFromSymbol})</span>
                  <span>Rate: ${fromRate.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="0.000001"
                    step="any"
                    value={fromAmount}
                    onChange={(e) => {
                      setSwapError('');
                      setFromAmount(Number(e.target.value));
                    }}
                    className="w-full bg-transparent text-xl font-mono font-bold text-white focus:outline-none min-w-0"
                  />
                  <select
                    value={effectiveFromSymbol}
                    onChange={(e) => {
                      setSwapError('');
                      const next = e.target.value;
                      setFromAsset(next);
                      if (next === effectiveToSymbol) {
                        const alt = heldCurrencyOptions.find((o) => o.symbol !== next);
                        if (alt) setToAsset(alt.symbol);
                      }
                    }}
                    className="bg-neutral-800 border border-neutral-700 text-xs font-bold text-amber-300 rounded-xl px-2.5 py-1.5 focus:outline-none shrink-0"
                  >
                    {heldCurrencyOptions.map((opt) => (
                      <option key={opt.symbol} value={opt.symbol}>
                        {opt.symbol} ({opt.balance.toLocaleString(undefined, { maximumFractionDigits: opt.category === 'crypto' ? 4 : 2 })})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* INVERT ARROW */}
              <div className="flex justify-center -my-2 relative z-10">
                <button
                  type="button"
                  onClick={handleInvert}
                  className="p-2 rounded-full bg-neutral-800 border border-neutral-700 text-amber-400 hover:text-amber-300 hover:bg-neutral-700 transition-all shadow-md active:scale-95"
                >
                  <ArrowDownUp className="h-4 w-4" />
                </button>
              </div>

              {/* TO CONTAINER */}
              <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-1.5">
                <div className="flex justify-between items-center text-xs text-neutral-400">
                  <span>You Receive (Bal: {(toOption?.balance || 0).toLocaleString()} {effectiveToSymbol})</span>
                  <span>Rate: ${toRate.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={estimatedReceive}
                    className="w-full bg-transparent text-xl font-mono font-bold text-emerald-400 focus:outline-none min-w-0"
                  />
                  <select
                    value={effectiveToSymbol}
                    onChange={(e) => {
                      setSwapError('');
                      setToAsset(e.target.value);
                    }}
                    className="bg-neutral-800 border border-neutral-700 text-xs font-bold text-amber-300 rounded-xl px-2.5 py-1.5 focus:outline-none shrink-0"
                  >
                    {heldCurrencyOptions
                      .filter((opt) => opt.symbol !== effectiveFromSymbol)
                      .map((opt) => (
                        <option key={opt.symbol} value={opt.symbol}>
                          {opt.symbol} ({opt.balance.toLocaleString(undefined, { maximumFractionDigits: opt.category === 'crypto' ? 4 : 2 })})
                        </option>
                      ))}
                  </select>
                </div>
              </div>
            </>
          )}

          {/* Route Info */}
          <div className="p-2.5 rounded-xl bg-neutral-950/40 border border-neutral-800/80 text-[11px] space-y-1.5 text-neutral-400">
            <div className="flex justify-between">
              <span>Settlement Route</span>
              <span className="text-neutral-200">Final Protocol Automated Market Maker</span>
            </div>
            <div className="flex justify-between">
              <span>Network Protocol Fee</span>
              <span className="text-emerald-400">$0.00 (Internal Wallet Swap)</span>
            </div>
            <div className="border-t border-neutral-800/60 pt-1.5 mt-1.5 text-[10px] text-amber-500 leading-normal">
              ⚠️ <strong>Final Coins Protocol Notice</strong>: Final Coins (AFNL) represent permanent sovereign utility assets and are non-convertible to other asset classes.
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="button"
            onClick={handleOpenConfirm}
            disabled={isSwapping || isSuccess || fromAmount <= 0 || heldCurrencyOptions.length < 2}
            className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 ${
              isSuccess
                ? 'bg-emerald-500 text-black'
                : 'bg-gradient-to-r from-amber-500 to-amber-600 text-black hover:opacity-95 shadow-lg shadow-amber-500/20'
            }`}
          >
            {isSuccess ? (
              <>
                <Check className="h-4 w-4" />
                <span>Swap Settled Successfully</span>
              </>
            ) : isSwapping ? (
              <>
                <div className="h-4 w-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Executing Multi-Vault Settlement...</span>
              </>
            ) : (
              <>
                <Zap className="h-4 w-4" />
                <span>Execute Instant Swap</span>
              </>
            )}
          </button>
        </form>

        <ConfirmModal
          isOpen={showConfirm}
          onClose={() => setShowConfirm(false)}
          onConfirm={handleExecuteSwap}
          title="Confirm Instant Swap"
          message={`Are you sure you want to swap ${fromAmount} ${effectiveFromSymbol} for approximately ${estimatedReceive} ${effectiveToSymbol}?`}
          confirmText="Confirm Swap"
          type="warning"
        />
      </motion.div>
    </div>
  );
};

