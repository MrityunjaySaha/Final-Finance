import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Message, Conversation } from '../types';
import { ConfirmModal } from './common/ConfirmModal';
import { 
  Send, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  ArrowLeftRight, 
  Clock, 
  Check, 
  X, 
  Image as ImageIcon,
  Users,
  MessageSquare
} from 'lucide-react';

export const MessagingView: React.FC = () => {
  const { 
    conversations, 
    activeConversationId, 
    setActiveConversationId, 
    messages, 
    sendMessage, 
    respondToTradeProposal,
    currentUser,
    imageHistory 
  } = useApp();

  const [inputMessage, setInputMessage] = useState('');
  const [selectedAssetForMessage, setSelectedAssetForMessage] = useState<string | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [pendingTradeResponse, setPendingTradeResponse] = useState<{convId: string, msgId: string, status: 'accepted' | 'declined'} | null>(null);

  const activeConv = conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const activeMessages = messages[activeConv?.id || ''] || [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() && !selectedAssetForMessage) return;

    sendMessage(activeConv.id, inputMessage, selectedAssetForMessage || undefined);
    setInputMessage('');
    setSelectedAssetForMessage(null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[720px] pb-20">
      {/* Conversations List Column (4 cols) */}
      <div className="lg:col-span-4 rounded-2xl border border-neutral-800 bg-[#0b0e14] p-4 flex flex-col h-full shadow-xl">
        <div className="border-b border-neutral-800 pb-3 mb-3">
          <div className="flex items-center justify-between">
            <h2 className="font-serif text-base font-bold text-white flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-amber-400" />
              <span>OTC Desks & Syndicates</span>
            </h2>
            <span className="rounded bg-amber-500/10 px-2 py-0.5 text-[10px] font-mono text-amber-300 font-bold">
              Encrypted
            </span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {conversations.map((conv) => {
            const isActive = conv.id === activeConv?.id;
            return (
              <button
                key={conv.id}
                onClick={() => setActiveConversationId(conv.id)}
                className={`w-full text-left rounded-xl p-3 transition-all flex items-start gap-3 border ${
                  isActive
                    ? 'border-amber-500/40 bg-neutral-900 shadow-md ring-1 ring-amber-500/20'
                    : 'border-transparent bg-neutral-900/40 hover:bg-neutral-900/80 hover:border-neutral-800'
                }`}
              >
                <img
                  src={conv.avatar}
                  alt={conv.name}
                  className="h-10 w-10 rounded-full object-cover border border-neutral-700 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="font-serif text-xs font-bold text-white truncate flex items-center gap-1">
                      {conv.name}
                      {conv.isVerifiedDesk && <CheckCircle2 className="h-3 w-3 text-emerald-400 shrink-0" />}
                    </h4>
                    <span className="text-[10px] font-mono text-neutral-500 shrink-0">{conv.lastMessageTime}</span>
                  </div>
                  <p className="text-[11px] text-neutral-400 truncate mt-0.5">{conv.lastMessageText}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Conversation Chat Column (8 cols) */}
      <div className="lg:col-span-8 rounded-2xl border border-neutral-800 bg-[#0b0e14] flex flex-col h-full shadow-xl overflow-hidden">
        
        {/* Chat Top Bar */}
        <div className="flex items-center justify-between border-b border-neutral-800/80 bg-[#0d1017] p-4">
          <div className="flex items-center gap-3">
            <img
              src={activeConv?.avatar}
              alt={activeConv?.name}
              className="h-10 w-10 rounded-full object-cover border border-amber-500/40"
            />
            <div>
              <h3 className="font-serif text-sm font-bold text-white flex items-center gap-1.5">
                {activeConv?.name}
                {activeConv?.isVerifiedDesk && (
                  <span className="rounded bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.2 text-[9px] font-mono text-emerald-300 font-bold">
                    Verified OTC Desk
                  </span>
                )}
              </h3>
              <p className="text-[11px] font-mono text-neutral-400">
                {activeConv?.type === 'group' ? 'Multi-Sig Syndicate Room' : 'Direct Sovereign Channel'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span className="hidden sm:inline">Escrow Clearance Active</span>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {activeMessages.map((msg) => {
            const isMe = msg.senderId === currentUser.id;
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <img
                  src={msg.senderAvatar}
                  alt={msg.senderName}
                  className="h-8 w-8 rounded-full object-cover border border-neutral-700 shrink-0 mt-0.5"
                />
                
                <div className={`max-w-[75%] space-y-2 ${isMe ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`rounded-2xl p-3 text-xs leading-relaxed ${
                      isMe
                        ? 'bg-amber-500/20 border border-amber-500/30 text-amber-100 rounded-tr-none'
                        : 'bg-neutral-900 border border-neutral-800 text-neutral-200 rounded-tl-none'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>

                    {/* Shared Image Attachment */}
                    {msg.imageUrl && (
                      <div className="mt-2 rounded-xl overflow-hidden border border-neutral-700/60 max-h-56">
                        <img src={msg.imageUrl} alt="Shared Asset" className="w-full h-full object-cover" />
                      </div>
                    )}

                    {/* Trade Proposal Card */}
                    {msg.tradeProposal && (
                      <div className="mt-3 rounded-xl border border-amber-500/40 bg-black/60 p-3 text-xs space-y-2">
                        <div className="flex items-center gap-1.5 text-amber-300 font-serif font-bold">
                          <ArrowLeftRight className="h-4 w-4" />
                          <span>Formal Barter Trade Proposal</span>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-neutral-900/80 p-2 rounded-lg">
                          <div>
                            <span className="text-neutral-500 block">Offered Asset:</span>
                            <span className="text-white font-semibold">{msg.tradeProposal.offeredAsset}</span>
                          </div>
                          <div>
                            <span className="text-neutral-500 block">Requested Swap:</span>
                            <span className="text-amber-300 font-semibold">{msg.tradeProposal.requestedAsset}</span>
                          </div>
                        </div>

                        {/* Proposal Actions */}
                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[10px] font-mono uppercase text-neutral-400">
                            Status: <strong className={msg.tradeProposal.status === 'accepted' ? 'text-emerald-400' : msg.tradeProposal.status === 'declined' ? 'text-rose-400' : 'text-amber-400'}>{msg.tradeProposal.status}</strong>
                          </span>

                          {msg.tradeProposal.status === 'pending' && !isMe && (
                            <div className="flex gap-1.5">
                              <button
                                onClick={() => {
                                  setPendingTradeResponse({ convId: activeConv.id, msgId: msg.id, status: 'accepted' });
                                  setShowConfirm(true);
                                }}
                                className="flex items-center gap-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 text-[11px] font-bold transition-colors"
                              >
                                <Check className="h-3 w-3" /> Accept
                              </button>
                              <button
                                onClick={() => respondToTradeProposal(activeConv.id, msg.id, 'declined')}
                                className="flex items-center gap-1 rounded bg-neutral-800 hover:bg-neutral-700 text-rose-400 px-2.5 py-1 text-[11px] transition-colors"
                              >
                                <X className="h-3 w-3" /> Decline
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-neutral-500 block px-1">{msg.createdAt}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Input Bar */}
        <div className="border-t border-neutral-800/80 bg-[#0d1017] p-3 space-y-2">
          {selectedAssetForMessage && (
            <div className="flex items-center justify-between rounded-lg bg-neutral-900 p-2 text-xs">
              <span className="text-neutral-300 truncate">Attached Asset from AI Studio History</span>
              <button
                onClick={() => setSelectedAssetForMessage(null)}
                className="text-rose-400 text-xs hover:underline"
              >
                Remove
              </button>
            </div>
          )}

          <form onSubmit={handleSend} className="flex gap-2">
            {imageHistory.length > 0 && (
              <button
                type="button"
                onClick={() => setSelectedAssetForMessage(imageHistory[0].imageUrl)}
                className="rounded-xl border border-neutral-800 bg-neutral-900 px-3 text-neutral-300 hover:text-amber-300 hover:border-amber-500/40 transition-colors"
                title="Attach Latest AI Asset"
              >
                <Sparkles className="h-4 w-4" />
              </button>
            )}

            <input
              type="text"
              placeholder={`Message ${activeConv?.name}...`}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-1 rounded-xl border border-neutral-800 bg-neutral-900 px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:border-amber-500/50 focus:outline-none"
            />

            <button
              type="submit"
              disabled={!inputMessage.trim() && !selectedAssetForMessage}
              className="rounded-xl border border-amber-500/50 bg-gradient-to-r from-amber-500 to-amber-600 px-4 py-2.5 text-xs font-bold text-black hover:opacity-95 transition-opacity disabled:opacity-50 flex items-center gap-1.5"
            >
              <Send className="h-4 w-4" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </form>
        </div>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => {
          setShowConfirm(false);
          setPendingTradeResponse(null);
        }}
        onConfirm={() => {
          if (pendingTradeResponse) {
            respondToTradeProposal(pendingTradeResponse.convId, pendingTradeResponse.msgId, pendingTradeResponse.status);
          }
          setShowConfirm(false);
          setPendingTradeResponse(null);
        }}
        title="Confirm Trade Acceptance"
        message="Are you sure you want to accept this barter trade proposal? Accepting will initiate the formal escrow settlement process and may lock assets for clearing."
        confirmText="Accept Proposal"
        type="warning"
      />
    </div>
  );
};
