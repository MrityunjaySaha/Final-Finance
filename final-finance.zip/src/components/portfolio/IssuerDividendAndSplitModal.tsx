import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Coins, 
  DollarSign, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  TrendingUp, 
  ArrowRightLeft,
  PieChart,
  Layers,
  Sparkles
} from 'lucide-react';
import { IPORequest } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { UniversalLedgerItem } from '../../types/ledger';
import { getLiveIPOValuation } from '../../data/stocksData';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { getStoredUserWallets, saveStoredUserWallets } from '../../data/defaultWallets';

interface IssuerDividendAndSplitModalProps {
  isOpen: boolean;
  onClose: () => void;
  ipo: IPORequest;
  currentUser: AuthSession | null;
  onSuccess?: () => void;
}

export const IssuerDividendAndSplitModal: React.FC<IssuerDividendAndSplitModalProps> = ({
  isOpen,
  onClose,
  ipo,
  currentUser,
  onSuccess
}) => {
  const currentUserId = currentUser?.id || currentUser?.uid || 'guest';
  const isPersonal = ipo.ipoType === 'personal';
  const liveValuation = getLiveIPOValuation(ipo);

  const [activeTab, setActiveTab] = useState<'dividend' | 'split'>('dividend');

  // Dividend states
  const [dividendRatePercent, setDividendRatePercent] = useState<string>('3.5');
  const [selectedCurrency, setSelectedCurrency] = useState<string>(ipo.marketWay === 'final' ? 'AFNL' : ipo.marketWay === 'stable' ? 'USDC' : 'USD');
  const [isExecutingDividend, setIsExecutingDividend] = useState<boolean>(false);
  const [dividendSuccessMsg, setDividendSuccessMsg] = useState<string>('');

  // Split states
  const [splitRatio, setSplitRatio] = useState<'2:1' | '3:1' | '5:1' | '10:1' | 'reverse_1:5' | 'reverse_1:10'>('2:1');
  const [isExecutingSplit, setIsExecutingSplit] = useState<boolean>(false);
  const [splitSuccessMsg, setSplitSuccessMsg] = useState<string>('');

  // Calculate annual/quarterly dividend liability
  const totalShares = ipo.sharesOffered;
  const pricePerShare = liveValuation.livePrice;
  const totalMarketCap = totalShares * pricePerShare;
  const rateNum = parseFloat(dividendRatePercent) || 0;
  const annualDividendLiabilityUSD = totalMarketCap * (rateNum / 100);
  const quarterlyDividendLiabilityUSD = annualDividendLiabilityUSD / 4;

  const handleDisburseDividend = () => {
    setIsExecutingDividend(true);
    setDividendSuccessMsg('');

    setTimeout(() => {
      // Record liability & disbursement in Universal Ledger
      const dateObj = new Date();
      const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
      const recNum = `REC-DIV-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

      const ledgerItem = {
        id: `rec-div-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        receiptNumber: recNum,
        taxYear: dateObj.getFullYear(),
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'dividend' as const,
        category: 'income_yield' as const,
        mode: ipo.marketWay === 'final' ? 'final_coin' as const : ipo.marketWay === 'stable' ? 'stable_coin' as const : ipo.marketWay === 'crypto' ? 'crypto' as const : 'fiat' as const,
        title: `Issuer Dividend Disbursement: $${ipo.ticker} (${rateNum}% Yield Payout)`,
        description: `Issuer liability settlement of $${quarterlyDividendLiabilityUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD in quarterly dividends distributed to all ${ipo.equityName} ($${ipo.ticker}) shareholders.`,
        amountUSD: quarterlyDividendLiabilityUSD,
        feeUSD: 0.00,
        netAmountUSD: quarterlyDividendLiabilityUSD,
        sourceOrDestination: `Issuer Reserve Vault (@${currentUser?.userId || 'issuer'})`,
        counterpartyOrIssuer: `${ipo.equityName} Shareholders Pool`,
        paymentCoinSymbol: selectedCurrency,
        paymentCoinAmount: quarterlyDividendLiabilityUSD,
        taxClassification: {
          formMapping: 'Form 1099-DIV',
          taxableEvent: true,
          taxableAmountUSD: quarterlyDividendLiabilityUSD,
          holdingPeriod: 'Long-Term',
          taxDeductible: true,
          irsCategoryNote: 'Issuer mandatory dividend disbursement liability cleared across sovereign network vaults.'
        },
        status: 'Settled',
        clearingNode: 'Sovereign Dividend Clearing Router #04',
        cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
        signature: `SIG-DIV-${Math.floor(100000 + Math.random() * 900000)}`
      };

      recordLedgerTransaction(currentUserId, ledgerItem as UniversalLedgerItem);
      setIsExecutingDividend(false);
      setDividendSuccessMsg(`Successfully disbursed $${quarterlyDividendLiabilityUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD in dividends to all shareholders of $${ipo.ticker}! Ledger audit record created.`);
      
      if (onSuccess) onSuccess();
    }, 600);
  };

  const handleExecuteSplit = () => {
    setIsExecutingSplit(true);
    setSplitSuccessMsg('');

    setTimeout(() => {
      // Record split in ledger
      const dateObj = new Date();
      const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
      const recNum = `REC-SPLIT-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

      const ledgerItem = {
        id: `rec-split-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        receiptNumber: recNum,
        taxYear: dateObj.getFullYear(),
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'payment_settlement' as const,
        category: 'stock_trade' as const,
        mode: ipo.marketWay === 'final' ? 'final_coin' as const : ipo.marketWay === 'stable' ? 'stable_coin' as const : ipo.marketWay === 'crypto' ? 'crypto' as const : 'fiat' as const,
        title: `Stock Split Executed: $${ipo.ticker} (${splitRatio})`,
        description: `Corporate & Sovereign Issuer action: Executed ${splitRatio} stock split for $${ipo.ticker} (${ipo.equityName}). Share quantities and nominal price adjusted across all investor vaults.`,
        amountUSD: 0,
        feeUSD: 0.00,
        netAmountUSD: 0,
        sourceOrDestination: `Issuer Registrar Desk (@${currentUser?.userId || 'issuer'})`,
        counterpartyOrIssuer: `${ipo.equityName} Shareholder Registry`,
        paymentCoinSymbol: ipo.ticker,
        paymentCoinAmount: totalShares,
        taxClassification: {
          formMapping: 'Non-Taxable Transfer',
          taxableEvent: false,
          taxableAmountUSD: 0,
          holdingPeriod: 'N/A',
          taxDeductible: false,
          irsCategoryNote: 'Stock split adjustment under corporate sovereign registrar rules.'
        },
        status: 'Settled',
        clearingNode: 'Sovereign Registrar & Split Engine #08',
        cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
        signature: `SIG-SPLIT-${Math.floor(100000 + Math.random() * 900000)}`
      };

      recordLedgerTransaction(currentUserId, ledgerItem as UniversalLedgerItem);
      setIsExecutingSplit(false);
      setSplitSuccessMsg(`Stock split (${splitRatio}) successfully executed for $${ipo.ticker}! Investor holdings automatically multiplied/adjusted.`);

      if (onSuccess) onSuccess();
    }, 600);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-xl w-full overflow-hidden my-auto text-left"
      >
        {/* Header */}
        <div className="bg-neutral-950 text-white px-6 py-4 flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
              {isPersonal ? '👤' : '🏢'}
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Issuer Governance Desk</span>
                <span className="text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
                  ${ipo.ticker}
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Manage dividend liability, payout reserves, and stock splits
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs: Dividend Liability vs Stock Splits */}
        <div className="flex border-b border-neutral-200 bg-neutral-50 p-1.5 gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('dividend')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'dividend'
                ? 'bg-neutral-950 text-white shadow-2xs'
                : 'text-neutral-600 hover:text-neutral-900 bg-white'
            }`}
          >
            <Coins className="w-4 h-4 text-amber-400" />
            <span>Dividend Liability &amp; Payout</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('split')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'split'
                ? 'bg-neutral-950 text-white shadow-2xs'
                : 'text-neutral-600 hover:text-neutral-900 bg-white'
            }`}
          >
            <Layers className="w-4 h-4 text-sky-400" />
            <span>Stock Split Execution</span>
          </button>
        </div>

        <div className="p-6 space-y-6">
          {activeTab === 'dividend' ? (
            /* ================= DIVIDEND LIABILITY & PAYOUT TAB ================= */
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200/80 text-amber-950 space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs">
                  <ShieldCheck className="w-4 h-4 text-amber-700" />
                  <span>Mandatory Issuer Dividend Liability</span>
                </div>
                <p className="text-xs text-amber-900 leading-relaxed">
                  As the sovereign issuer of <strong>{ipo.equityName} (${ipo.ticker})</strong>, you are legally and programmatically liable to disburse regular dividend yields to all public shareholders.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200">
                  <span className="text-[10px] uppercase font-mono text-neutral-400 block">Total Issued Shares</span>
                  <span className="text-sm font-mono font-bold text-neutral-900">{totalShares.toLocaleString()}</span>
                </div>
                <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200">
                  <span className="text-[10px] uppercase font-mono text-neutral-400 block">Current Stock Price</span>
                  <span className="text-sm font-mono font-bold text-neutral-900">${pricePerShare.toFixed(2)} USD</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-600 block">
                  Dividend Yield Rate (%)
                </label>
                <div className="flex items-center gap-3">
                  {['1.5', '2.5', '3.5', '5.0', '7.5'].map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => setDividendRatePercent(rate)}
                      className={`flex-1 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer border ${
                        dividendRatePercent === rate
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                      }`}
                    >
                      {rate}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Liability Calculation Box */}
              <div className="p-4 rounded-2xl bg-neutral-900 text-white space-y-2.5 font-mono">
                <div className="flex items-center justify-between text-xs pb-2 border-b border-neutral-800">
                  <span className="text-neutral-400 font-sans">Annual Dividend Obligation</span>
                  <span className="font-bold text-amber-400">${annualDividendLiabilityUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-400 font-sans">Quarterly Payout Liability</span>
                  <span className="font-bold text-emerald-400">${quarterlyDividendLiabilityUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD</span>
                </div>
              </div>

              {dividendSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{dividendSuccessMsg}</span>
                </div>
              )}

              <button
                type="button"
                onClick={handleDisburseDividend}
                disabled={isExecutingDividend}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
              >
                {isExecutingDividend ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Disbursing Dividend to Shareholders...</span>
                  </>
                ) : (
                  <>
                    <Coins className="w-4 h-4 text-amber-300" />
                    <span>Disburse Quarterly Dividend (${quarterlyDividendLiabilityUSD.toLocaleString(undefined, { maximumFractionDigits: 2 })} USD)</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            /* ================= STOCK SPLIT TAB ================= */
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-sky-50 border border-sky-200/80 text-sky-950 space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs">
                  <Layers className="w-4 h-4 text-sky-700" />
                  <span>Corporate Stock Split Registrar</span>
                </div>
                <p className="text-xs text-sky-900 leading-relaxed">
                  Execute stock splits to increase or decrease share liquidity. All investor vaults and circulating float will be programmatically scaled.
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-600 block">
                  Select Split Ratio
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: '2:1', label: '2-for-1 Split', desc: 'Doubles shares, halves price' },
                    { id: '3:1', label: '3-for-1 Split', desc: 'Triples shares, 1/3 price' },
                    { id: '5:1', label: '5-for-1 Split', desc: '5x shares, 1/5 price' },
                    { id: '10:1', label: '10-for-1 Split', desc: '10x shares, 1/10 price' },
                    { id: 'reverse_1:5', label: 'Reverse 1:5', desc: '1/5 shares, 5x price' },
                    { id: 'reverse_1:10', label: 'Reverse 1:10', desc: '1/10 shares, 10x price' }
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setSplitRatio(s.id as any)}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        splitRatio === s.id
                          ? 'border-neutral-900 bg-neutral-900 text-white shadow-md'
                          : 'border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-900'
                      }`}
                    >
                      <span className="text-xs font-bold font-mono">{s.label}</span>
                      <span className={`text-[10px] mt-1 ${splitRatio === s.id ? 'text-neutral-300' : 'text-neutral-500'}`}>
                        {s.desc}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {splitSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{splitSuccessMsg}</span>
                </div>
              )}

              <button
                type="button"
                onClick={handleExecuteSplit}
                disabled={isExecutingSplit}
                className="w-full py-3.5 px-4 rounded-2xl bg-neutral-950 hover:bg-black text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
              >
                {isExecutingSplit ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Executing Registrar Stock Split...</span>
                  </>
                ) : (
                  <>
                    <Layers className="w-4 h-4 text-sky-400" />
                    <span>Execute {splitRatio} Stock Split for ${ipo.ticker}</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
