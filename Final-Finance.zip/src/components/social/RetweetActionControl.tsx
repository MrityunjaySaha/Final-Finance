import React, { useEffect, useRef, useState } from 'react';
import { Repeat2, PenSquare, RotateCcw } from 'lucide-react';
import { Tweet } from '../../types/tweet';

interface RetweetActionControlProps {
  tweet: Tweet;
  isRetweeted: boolean;
  onDirectRetweet: () => void;
  onRetweetWithComment: () => void;
  iconSizeClass?: string;
}

export const RetweetActionControl: React.FC<RetweetActionControlProps> = ({
  tweet,
  isRetweeted,
  onDirectRetweet,
  onRetweetWithComment,
  iconSizeClass = 'w-4 h-4',
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handleOutside = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, [menuOpen]);

  return (
    <div ref={wrapperRef} className="relative inline-flex items-center">
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setMenuOpen((prev) => !prev);
        }}
        className={`flex items-center gap-1 hover:text-emerald-600 transition-colors cursor-pointer group ${
          isRetweeted ? 'text-emerald-600 font-bold' : ''
        }`}
        title="Retweet"
      >
        <div className="p-1.5 rounded-full group-hover:bg-emerald-50 transition-colors">
          <Repeat2 className={iconSizeClass} />
        </div>
        <span className="font-mono text-[11px] tabular-nums">{tweet.retweets}</span>
      </button>

      {menuOpen && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-52 rounded-2xl bg-white border border-slate-200 shadow-xl py-1.5 z-40 text-left"
        >
          <button
            type="button"
            onClick={() => {
              setMenuOpen(false);
              onDirectRetweet();
            }}
            className={`w-full px-3.5 py-2 text-xs font-semibold flex items-center gap-2.5 transition-colors cursor-pointer ${
              isRetweeted
                ? 'text-rose-600 hover:bg-rose-50'
                : 'text-slate-800 hover:bg-emerald-50 hover:text-emerald-700'
            }`}
          >
            {isRetweeted ? (
              <>
                <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                <span>Undo Retweet</span>
              </>
            ) : (
              <>
                <Repeat2 className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                <span>Retweet</span>
              </>
            )}
          </button>
          <button
            type="button"
            onClick={() => {
              setMenuOpen(false);
              onRetweetWithComment();
            }}
            className="w-full px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-2.5 transition-colors cursor-pointer"
          >
            <PenSquare className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
            <span>Retweet with Comment</span>
          </button>
        </div>
      )}
    </div>
  );
};
