import React from 'react';
import { Compass, ArrowRight, Shield, LogOut } from 'lucide-react';
import { AuthSession } from '../types/auth';
import { signOut } from '../services/firebaseAuth';
import { PWAInstallButton } from './PWAInstallButton';

interface LandingHomePageProps {
  onOpenAuthModal: () => void;
  onEnterApp: () => void;
  onAuthSuccess?: (user: AuthSession) => void;
  currentUserSession: AuthSession | null;
  onSelectDemoAccount?: (key: any) => void;
}

const FinalFinanceGoldCoinLogo: React.FC = () => {
  return (
    <div className="relative inline-flex items-center justify-center my-1" aria-hidden="true">
      {/* Ambient blue hue halo around the coin */}
      <div className="absolute -inset-4 rounded-full bg-gradient-to-tr from-blue-600/35 via-sky-400/30 to-indigo-500/35 blur-xl pointer-events-none" />
      <div className="relative p-1.5 rounded-full bg-gradient-to-br from-blue-500/25 via-sky-400/20 to-blue-600/30 ring-2 ring-blue-400/45 shadow-[0_0_28px_rgba(37,99,235,0.42)]">
        <svg
          viewBox="0 0 120 120"
          className="w-24 h-24 sm:w-28 sm:h-28 drop-shadow-[0_6px_14px_rgba(180,115,10,0.45)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Outer rim gold gradient */}
            <linearGradient id="ffCoinRim" x1="12" y1="10" x2="108" y2="110" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFF7C2" />
              <stop offset="22%" stopColor="#FBBF24" />
              <stop offset="50%" stopColor="#D97706" />
              <stop offset="78%" stopColor="#FDE68A" />
              <stop offset="100%" stopColor="#92400E" />
            </linearGradient>

            {/* Inner coin face radial metallic sheen */}
            <radialGradient id="ffCoinFace" cx="38%" cy="32%" r="72%">
              <stop offset="0%" stopColor="#FFFBEB" />
              <stop offset="24%" stopColor="#FDE047" />
              <stop offset="58%" stopColor="#F59E0B" />
              <stop offset="88%" stopColor="#B45309" />
              <stop offset="100%" stopColor="#78350F" />
            </radialGradient>

            {/* Specular highlight band */}
            <linearGradient id="ffCoinGloss" x1="18" y1="18" x2="96" y2="96" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.58" />
              <stop offset="40%" stopColor="#FFFFFF" stopOpacity="0.12" />
              <stop offset="65%" stopColor="#FFFFFF" stopOpacity="0" />
              <stop offset="100%" stopColor="#FEF08A" stopOpacity="0.22" />
            </linearGradient>

            {/* Monogram gold-bronze embossed gradient */}
            <linearGradient id="ffMonogramFill" x1="35" y1="30" x2="85" y2="90" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFBEB" />
              <stop offset="48%" stopColor="#FEF08A" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
          </defs>

          {/* Outer coin body */}
          <circle cx="60" cy="60" r="56" fill="url(#ffCoinRim)" stroke="#78350F" strokeWidth="1.5" />

          {/* Reeded / milled coin edge */}
          <circle
            cx="60"
            cy="60"
            r="52"
            stroke="#92400E"
            strokeWidth="2.2"
            strokeDasharray="2 3"
            strokeOpacity="0.55"
          />

          {/* Recessed coin face */}
          <circle cx="60" cy="60" r="47.5" fill="url(#ffCoinFace)" stroke="#FEF08A" strokeWidth="1.2" strokeOpacity="0.8" />

          {/* Inner engraved ring */}
          <circle cx="60" cy="60" r="41" stroke="#92400E" strokeWidth="1" strokeOpacity="0.45" />
          <circle cx="60" cy="60" r="39.5" stroke="#FFFBEB" strokeWidth="0.8" strokeOpacity="0.55" />

          {/* Glossy diagonal coin sheen */}
          <path
            d="M24 38C34 20 58 12 80 18C62 24 44 40 32 62C23 78 22 92 22 92C14 76 14 54 24 38Z"
            fill="url(#ffCoinGloss)"
          />

          {/* Subtle engraved shadow layer for FF dollar-style monogram */}
          <g transform="translate(1.2, 1.8)" opacity="0.48">
            {/* Currency vertical bars through F and F (dollar-sign motif) */}
            <rect x="40" y="31" width="3.4" height="58" rx="1.7" fill="#78350F" />
            <rect x="68" y="31" width="3.4" height="58" rx="1.7" fill="#78350F" />
            {/* First F */}
            <path
              d="M35 38H58V44.5H43.5V56.5H55V62.8H43.5V82H35V38Z"
              fill="#78350F"
            />
            {/* Second F */}
            <path
              d="M63 38H86V44.5H71.5V56.5H83V62.8H71.5V82H63V38Z"
              fill="#78350F"
            />
          </g>

          {/* Crisp embossed FF dollar-sign monogram */}
          <g>
            {/* Vertical currency bars like $ running through each F */}
            <rect x="40" y="31" width="3.4" height="58" rx="1.7" fill="url(#ffMonogramFill)" stroke="#78350F" strokeWidth="0.9" />
            <rect x="68" y="31" width="3.4" height="58" rx="1.7" fill="url(#ffMonogramFill)" stroke="#78350F" strokeWidth="0.9" />

            {/* First F */}
            <path
              d="M35 38H58V44.5H43.5V56.5H55V62.8H43.5V82H35V38Z"
              fill="url(#ffMonogramFill)"
              stroke="#78350F"
              strokeWidth="1.1"
              strokeLinejoin="round"
            />

            {/* Second F */}
            <path
              d="M63 38H86V44.5H71.5V56.5H83V62.8H71.5V82H63V38Z"
              fill="url(#ffMonogramFill)"
              stroke="#78350F"
              strokeWidth="1.1"
              strokeLinejoin="round"
            />
          </g>
        </svg>
      </div>
    </div>
  );
};

export const LandingHomePage: React.FC<LandingHomePageProps> = ({
  onOpenAuthModal,
  onEnterApp,
  currentUserSession,
}) => {
  const handleSignOut = async () => {
    await signOut();
    window.location.reload();
  };

  return (
    <div className="flex-1 w-full bg-white flex flex-col items-center px-5 sm:px-8 py-6 text-center">
      {/* Top flexible spacer keeps hero & sign-in centered on the single screen */}
      <div className="flex-1 min-h-4" aria-hidden="true" />

      <div className="w-full max-w-lg mx-auto flex flex-col items-center text-center space-y-6 sm:space-y-7 shrink-0">
        {/* Shiny Gold Coin Logo with FF Dollar-Sign Monogram & Blue Hue */}
        <FinalFinanceGoldCoinLogo />

        {/* Centered Title & Enlarged Subtitle */}
        <div className="w-full flex flex-col items-center text-center space-y-2.5">
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight text-balance">
            Welcome to FINAL FINANCE
          </h1>
          <p className="text-base sm:text-lg font-semibold text-slate-700 tracking-wide">
            Everything Finance!
          </p>
        </div>

        {/* Active Session Zone or Sign In */}
        {currentUserSession ? (
          <div className="w-full max-w-md mx-auto space-y-4 pt-1 flex flex-col items-center">
            <div className="w-full p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center gap-3">
              <div className="flex items-center justify-center gap-3 min-w-0">
                {currentUserSession.avatarUrl ? (
                  <img
                    src={currentUserSession.avatarUrl}
                    alt={currentUserSession.name}
                    className="w-10 h-10 rounded-full object-cover border border-slate-300 shrink-0"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm font-serif font-bold shrink-0">
                    {currentUserSession.name?.charAt(0) || 'U'}
                  </div>
                )}
                <div className="min-w-0 text-center">
                  <p className="text-[11px] text-emerald-600 font-semibold uppercase tracking-wider text-center">Signed In</p>
                  <p className="text-sm font-bold text-slate-900 truncate">
                    {currentUserSession.name}
                  </p>
                  <p className="text-xs text-slate-500 truncate">
                    {currentUserSession.email}
                  </p>
                </div>
              </div>
            </div>

            <div className="w-full space-y-2.5">
              <button
                type="button"
                onClick={onEnterApp}
                className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Compass className="w-4 h-4" />
                <span>Enter Marketplace Page</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleSignOut}
                className="w-full min-h-[40px] py-2.5 px-4 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5 text-slate-500" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        ) : (
          /* Sign In Zone */
          <div className="w-full max-w-md mx-auto space-y-3.5 pt-1 flex flex-col items-center">
            <button
              type="button"
              onClick={onOpenAuthModal}
              className="w-full min-h-[48px] py-3 px-5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <span>Sign In / Create Account</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Google security badge */}
            <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500 pt-1">
              <Shield className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Protected by Google Secure Sign-In</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom flexible zone positions the Install button 50% down toward the bottom of the page */}
      <div className="flex-1 min-h-16 w-full max-w-md mx-auto flex flex-col items-center justify-center pt-4 pb-2">
        <PWAInstallButton variant="banner" />
      </div>
    </div>
  );
};
