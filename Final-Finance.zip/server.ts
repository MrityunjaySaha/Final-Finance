import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { generateOrEditImage, enhanceAssetPrompt, generateValuationReport, processChatRequest } from './src/server/geminiService';

const currentFile = typeof __filename !== 'undefined' ? __filename : (typeof process !== 'undefined' && process.argv[1] ? process.argv[1] : '');

dotenv.config();
if (fs.existsSync(path.join(process.cwd(), '.env.local'))) {
  dotenv.config({ path: path.join(process.cwd(), '.env.local'), override: true });
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const projectRoot = process.cwd();

  const { getStripeConfigDiagnostics } = await import('./src/server/stripeService');
  const startupStripe = getStripeConfigDiagnostics();
  console.log('[Server Startup] Stripe config readiness:', {
    secretKeyConfigured: startupStripe.configured,
    publishableKeyConfigured: startupStripe.publishableKeyValid,
    webhookConfigured: startupStripe.webhookConfigured,
    membershipPriceConfigured: startupStripe.membershipPriceConfigured,
  });

  // Stripe Webhook (must receive raw request body before express.json parses it)
  const stripeWebhookHandler = async (req: express.Request, res: express.Response) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    const signature = req.headers['stripe-signature'];
    if (typeof signature !== 'string' || !signature) {
      return res.status(400).json({ success: false, error: 'Missing stripe-signature header' });
    }
    try {
      const { verifyStripeWebhookEvent, handleStripeWebhookEvent } = await import('./src/server/stripeService');
      const event = verifyStripeWebhookEvent(req.body as Buffer, signature);
      await handleStripeWebhookEvent(event);
      return res.json({ received: true, eventId: event.id, type: event.type });
    } catch (error: any) {
      const { mapStripeErrorToHttp } = await import('./src/server/stripeService');
      const mapped = mapStripeErrorToHttp(error, 'Webhook verification failed');
      return res.status(mapped.status).json({ success: false, error: mapped.message });
    }
  };
  app.post('/api/webhooks/stripe', express.raw({ type: 'application/json' }), stripeWebhookHandler);
  app.post('/api/stripe/webhook', express.raw({ type: 'application/json' }), stripeWebhookHandler);

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // Serve static files from public directory
  app.use(express.static(path.join(projectRoot, 'public')));

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Precise External Link Metadata & Thumbnail Preview
  app.get('/api/link-preview', async (req, res) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    if (!rawUrl) {
      return res.status(400).json({ success: false, error: 'Missing url query parameter' });
    }
    try {
      const { resolveServerLinkPreview } = await import('./src/server/linkPreviewService');
      const data = await resolveServerLinkPreview(rawUrl);
      return res.json({ success: true, data });
    } catch (error: any) {
      const msg = error?.message || 'Failed to resolve link preview';
      const isClientError =
        msg.includes('Invalid') ||
        msg.includes('Only http') ||
        msg.includes('Blocked') ||
        msg.includes('Could not resolve');
      return res.status(isClientError ? 400 : 502).json({ success: false, error: msg });
    }
  });

  // API Endpoints
  app.post('/api/generate-image', async (req, res) => {
    try {
      const result = await generateOrEditImage({
        prompt: req.body.prompt,
        model: req.body.model || 'gemini-3-pro-image-preview',
        aspectRatio: req.body.aspectRatio || '1:1',
        imageSize: req.body.imageSize || '1K',
        useSearch: !!req.body.useSearch,
        referenceImage: req.body.referenceImage,
        referenceMimeType: req.body.referenceMimeType,
      });
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/edit-image', async (req, res) => {
    try {
      const result = await generateOrEditImage({
        prompt: req.body.prompt,
        model: req.body.model || 'gemini-3.1-flash-image-preview',
        aspectRatio: req.body.aspectRatio || '1:1',
        referenceImage: req.body.referenceImage,
        referenceMimeType: req.body.referenceMimeType,
      });
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/enhance-prompt', async (req, res) => {
    try {
      const result = await enhanceAssetPrompt(req.body.prompt, req.body.category);
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/valuation-report', async (req, res) => {
    try {
      const result = await generateValuationReport(req.body.name, req.body.category, req.body.price, req.body.attributes);
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/chat', async (req, res) => {
    try {
      const { message, history } = req.body;
      const result = await processChatRequest(message, history);
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  // Direct Alpaca API Endpoints
  app.get('/api/alpaca/account', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const result = await alpaca.getAccount();
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  app.get('/api/alpaca/positions', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const result = await alpaca.getPositions();
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  app.get('/api/alpaca/assets', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { asset_class } = req.query;
      const result = await alpaca.getAssets(asset_class as any);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/asset/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const result = await alpaca.getAssetBySymbol(req.params.symbol);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/snapshot/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { asset_class } = req.query;
      const result = await alpaca.getAssetSnapshot(req.params.symbol, asset_class as any);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/options/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { expiration_gte, expiration_lte } = req.query;
      const result = await alpaca.getOptionsChain(
        req.params.symbol,
        expiration_gte as string,
        expiration_lte as string
      );
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/bars/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { timeframe, limit, asset_class } = req.query;
      const result = await alpaca.getAssetBars(
        req.params.symbol, 
        (timeframe as string) || '1Day', 
        limit ? parseInt(limit as string) : 100,
        asset_class as any
      );
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  app.get('/api/alpaca/search', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { q, asset_class } = req.query;
      if (!q) return res.json({ success: true, data: [] });
      const result = await alpaca.searchAssets(q as string, asset_class as any);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  // Stripe Server-Side API Routes (Customer, SetupIntent, PaymentMethods, Market Membership, Billing, Connect, Invoicing, Tax)
  const getRequestOrigin = (req: express.Request): string => {
    const proto = (req.headers['x-forwarded-proto'] as string)?.split(',')[0]?.trim() || req.protocol || 'http';
    const host = (req.headers['x-forwarded-host'] as string)?.split(',')[0]?.trim() || req.get('host') || 'localhost:3000';
    return `${proto}://${host}`;
  };

  const sendStripeError = async (
    res: express.Response,
    error: unknown,
    fallbackMessage: string
  ) => {
    const { mapStripeErrorToHttp } = await import('./src/server/stripeService');
    const mapped = mapStripeErrorToHttp(error, fallbackMessage);
    return res.status(mapped.status).json({
      success: false,
      ...(mapped.isConfigError ? { configured: false } : {}),
      error: mapped.message,
    });
  };

  app.use('/api/stripe', (_req, res, next) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    next();
  });

  app.get('/api/stripe/config', async (_req, res) => {
    try {
      const { getStripeConfigDiagnostics } = await import('./src/server/stripeService');
      const diagnostics = getStripeConfigDiagnostics();
      return res.json({
        success: true,
        configured: diagnostics.configured,
        secretKeyValid: diagnostics.secretKeyValid,
        publishableKeyValid: diagnostics.publishableKeyValid,
        webhookConfigured: diagnostics.webhookConfigured,
        membershipPriceConfigured: diagnostics.membershipPriceConfigured,
        publishableKey: diagnostics.publishableKey,
        configurationError: diagnostics.configurationError,
        products: ['payments', 'billing', 'connect', 'invoicing', 'tax'],
      });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to read Stripe configuration');
    }
  });

  app.post('/api/stripe/session', async (req, res) => {
    try {
      const {
        getStripeConfigDiagnostics,
        getMembershipPriceId,
        ensureStripeCustomerForUser,
        issueStripeSessionToken,
      } = await import('./src/server/stripeService');

      const diagnostics = getStripeConfigDiagnostics();
      if (!diagnostics.configured) {
        return res.status(503).json({
          success: false,
          configured: false,
          error:
            diagnostics.configurationError ||
            'Stripe is not configured. Set STRIPE_SECRET_KEY in environment secrets.',
        });
      }

      const { userId, email, name } = req.body || {};
      const customer = await ensureStripeCustomerForUser({ userId, email, name });
      const sessionToken = issueStripeSessionToken({
        userId: String(userId).trim(),
        customerId: customer.customerId,
        email: customer.email,
      });

      return res.json({
        success: true,
        data: {
          sessionToken,
          customerId: customer.customerId,
          publishableKey: diagnostics.publishableKey,
          membershipPriceConfigured: Boolean(getMembershipPriceId()),
        },
      });
    } catch (error: any) {
      console.error('[Stripe Session Error]', error?.message || error);
      return sendStripeError(res, error, 'Failed to initialize Stripe session');
    }
  });

  app.get('/api/stripe/payment-methods', async (req, res) => {
    try {
      const { verifyStripeSessionToken, listCustomerPaymentMethods } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const data = await listCustomerPaymentMethods(claims.customerId);
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to fetch payment methods');
    }
  });

  app.post('/api/stripe/setup-intent', async (req, res) => {
    try {
      const { verifyStripeSessionToken, createCustomerSetupIntent } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { preference } = req.body || {};
      const data = await createCustomerSetupIntent({
        customerId: claims.customerId,
        preference,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create SetupIntent');
    }
  });

  app.post('/api/stripe/setup-checkout-session', async (req, res) => {
    try {
      const { verifyStripeSessionToken, createSetupCheckoutSession } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { preference, successUrl, cancelUrl } = req.body || {};
      const data = await createSetupCheckoutSession({
        customerId: claims.customerId,
        preference,
        successUrl,
        cancelUrl,
        requestOrigin: getRequestOrigin(req),
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create Setup Checkout Session');
    }
  });

  app.post('/api/stripe/payment-methods/default', async (req, res) => {
    try {
      const { verifyStripeSessionToken, setDefaultCustomerPaymentMethod } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { paymentMethodId } = req.body || {};
      const data = await setDefaultCustomerPaymentMethod({
        customerId: claims.customerId,
        paymentMethodId,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to update default payment method');
    }
  });

  app.delete('/api/stripe/payment-methods/:paymentMethodId', async (req, res) => {
    try {
      const { verifyStripeSessionToken, detachCustomerPaymentMethod } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const data = await detachCustomerPaymentMethod({
        customerId: claims.customerId,
        paymentMethodId: req.params.paymentMethodId,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to remove payment method');
    }
  });

  app.post('/api/stripe/bank-accounts/link', async (req, res) => {
    try {
      const { verifyStripeSessionToken, linkUsBankAccountToCustomer } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const forwardedFor = typeof req.headers['x-forwarded-for'] === 'string'
        ? req.headers['x-forwarded-for'].split(',')[0]?.trim()
        : undefined;
      const clientIp = forwardedFor || req.ip || '127.0.0.1';
      const userAgent = typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : 'FinalFinance/1.0';
      const data = await linkUsBankAccountToCustomer({
        customerId: claims.customerId,
        bankName: req.body?.bankName,
        accountHolderName: req.body?.accountHolderName,
        accountType: req.body?.accountType,
        routingNumber: req.body?.routingNumber,
        accountNumber: req.body?.accountNumber,
        email: claims.email,
        clientIp,
        userAgent,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to link bank account');
    }
  });

  app.post('/api/stripe/bank-accounts/verify-microdeposits', async (req, res) => {
    try {
      const { verifyStripeSessionToken, verifyUsBankMicrodeposits } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const data = await verifyUsBankMicrodeposits({
        customerId: claims.customerId,
        setupIntentId: req.body?.setupIntentId,
        amounts: req.body?.amounts,
        descriptorCode: req.body?.descriptorCode,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to verify bank micro-deposits');
    }
  });

  app.post('/api/stripe/setup-intent/verify', async (req, res) => {
    try {
      const { verifyStripeSessionToken, verifySetupIntentCard } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const data = await verifySetupIntentCard({
        customerId: claims.customerId,
        setupIntentId: req.body?.setupIntentId,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to verify payment card');
    }
  });

  app.post('/api/stripe/charges/execute', async (req, res) => {
    try {
      const { verifyStripeSessionToken, executeStripePaymentMethodCharge } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const data = await executeStripePaymentMethodCharge({
        customerId: claims.customerId,
        paymentMethodId: req.body?.paymentMethodId,
        amountUSD: req.body?.amountUSD,
        baseAmountUSD: req.body?.baseAmountUSD,
        feeUSD: req.body?.feeUSD,
        description: req.body?.description,
        purpose: req.body?.purpose,
        targetAssetClass: req.body?.targetAssetClass,
        targetCurrencyCode: req.body?.targetCurrencyCode,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to authorize Stripe charge');
    }
  });

  app.get('/api/stripe/membership/status', async (req, res) => {
    try {
      const { verifyStripeSessionToken, getCustomerMembershipStatus } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const data = await getCustomerMembershipStatus(claims.customerId);
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to fetch Market Membership status');
    }
  });

  app.post('/api/stripe/membership/subscribe', async (req, res) => {
    try {
      const { verifyStripeSessionToken, startMarketMembershipWithSavedMethod } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { paymentMethodId } = req.body || {};
      const data = await startMarketMembershipWithSavedMethod({
        customerId: claims.customerId,
        paymentMethodId,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to start Market Membership subscription');
    }
  });

  app.post('/api/stripe/membership/checkout-session', async (req, res) => {
    try {
      const { verifyStripeSessionToken, createMarketMembershipCheckoutSession } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { successUrl, cancelUrl } = req.body || {};
      const data = await createMarketMembershipCheckoutSession({
        customerId: claims.customerId,
        successUrl,
        cancelUrl,
        requestOrigin: getRequestOrigin(req),
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create Membership Checkout session');
    }
  });

  app.post('/api/stripe/membership/cancel', async (req, res) => {
    try {
      const { verifyStripeSessionToken, updateMarketMembershipCancellation } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { subscriptionId } = req.body || {};
      const data = await updateMarketMembershipCancellation({
        customerId: claims.customerId,
        subscriptionId,
        cancelAtPeriodEnd: true,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to cancel Market Membership');
    }
  });

  app.post('/api/stripe/membership/resume', async (req, res) => {
    try {
      const { verifyStripeSessionToken, updateMarketMembershipCancellation } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { subscriptionId } = req.body || {};
      const data = await updateMarketMembershipCancellation({
        customerId: claims.customerId,
        subscriptionId,
        cancelAtPeriodEnd: false,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to resume Market Membership');
    }
  });

  app.post('/api/stripe/membership/portal', async (req, res) => {
    try {
      const { verifyStripeSessionToken, createBillingPortalSession } = await import('./src/server/stripeService');
      const claims = verifyStripeSessionToken(req.headers.authorization);
      const { returnUrl } = req.body || {};
      const data = await createBillingPortalSession({
        customerId: claims.customerId,
        returnUrl: returnUrl || '/?tab=verification',
        requestOrigin: getRequestOrigin(req),
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to open Stripe Billing Portal');
    }
  });

  app.post('/api/stripe/payment-intent', async (req, res) => {
    try {
      const { createPaymentIntent } = await import('./src/server/stripeService');
      const data = await createPaymentIntent(req.body || {});
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create PaymentIntent');
    }
  });

  app.post('/api/stripe/checkout-session', async (req, res) => {
    try {
      const { createCheckoutSession } = await import('./src/server/stripeService');
      const data = await createCheckoutSession({
        ...(req.body || {}),
        requestOrigin: getRequestOrigin(req),
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create Checkout Session');
    }
  });

  app.post('/api/stripe/billing/portal-session', async (req, res) => {
    try {
      const { createBillingPortalSession } = await import('./src/server/stripeService');
      const data = await createBillingPortalSession({
        ...(req.body || {}),
        requestOrigin: getRequestOrigin(req),
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create Billing Portal session');
    }
  });

  app.post('/api/stripe/connect/account', async (req, res) => {
    try {
      const { createConnectedAccount } = await import('./src/server/stripeService');
      const data = await createConnectedAccount(req.body || {});
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create Connect account');
    }
  });

  app.post('/api/stripe/connect/onboarding-link', async (req, res) => {
    try {
      const { createConnectOnboardingLink } = await import('./src/server/stripeService');
      const data = await createConnectOnboardingLink({
        ...(req.body || {}),
        requestOrigin: getRequestOrigin(req),
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create Connect onboarding link');
    }
  });

  app.post('/api/stripe/invoices', async (req, res) => {
    try {
      const { createAndFinalizeInvoice } = await import('./src/server/stripeService');
      const data = await createAndFinalizeInvoice(req.body || {});
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to create invoice');
    }
  });

  app.post('/api/stripe/tax/calculate', async (req, res) => {
    try {
      const { calculateStripeTax } = await import('./src/server/stripeService');
      const data = await calculateStripeTax(req.body || {});
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendStripeError(res, error, 'Failed to calculate tax');
    }
  });

  // Privy Crypto & Stablecoins Wallet API Routes (strictly JSON)
  const sendPrivyError = (res: express.Response, error: any, fallbackMessage: string) => {
    const status =
      typeof error?.statusCode === 'number'
        ? error.statusCode
        : typeof error?.status === 'number'
          ? error.status
          : 400;
    return res.status(status).json({
      success: false,
      ...(error?.isConfigError ? { configured: false } : {}),
      error: error?.message || fallbackMessage,
    });
  };

  app.use('/api/privy', (_req, res, next) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    next();
  });

  app.get('/api/privy/config', async (_req, res) => {
    try {
      const { getPrivyServerConfig } = await import('./src/server/privyService');
      return res.json({ success: true, data: getPrivyServerConfig() });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to load Privy configuration');
    }
  });

  app.post('/api/privy/verify-token', async (req, res) => {
    try {
      const { verifyPrivyBackendToken } = await import('./src/server/privyService');
      const authHeader = typeof req.headers.authorization === 'string' ? req.headers.authorization : '';
      const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.slice('Bearer '.length).trim() : '';
      const data = await verifyPrivyBackendToken({
        accessToken: req.body?.accessToken || bearerToken,
        privyUserId: req.body?.privyUserId,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to verify Privy session token');
    }
  });

  app.get('/api/privy/balances', async (req, res) => {
    try {
      const { fetchPrivyWalletBalances } = await import('./src/server/privyService');
      const customTokens =
        typeof req.query.customTokens === 'string' && req.query.customTokens.trim()
          ? req.query.customTokens.split(',').map((s) => s.trim())
          : undefined;
      const data = await fetchPrivyWalletBalances({
        address: req.query.address,
        network: req.query.network,
        customTokens,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to fetch wallet token balances');
    }
  });

  app.post('/api/privy/balances', async (req, res) => {
    try {
      const { fetchPrivyWalletBalances } = await import('./src/server/privyService');
      const data = await fetchPrivyWalletBalances({
        address: req.body?.address,
        network: req.body?.network,
        customTokens: req.body?.customTokens,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to fetch wallet token balances');
    }
  });

  app.post('/api/privy/wallets/prepare-transfer', async (req, res) => {
    try {
      const { preparePrivyTokenTransfer } = await import('./src/server/privyService');
      const data = preparePrivyTokenTransfer({
        fromAddress: req.body?.fromAddress,
        toAddress: req.body?.toAddress,
        amount: req.body?.amount,
        network: req.body?.network,
        assetType: req.body?.assetType,
        tokenSymbol: req.body?.tokenSymbol,
        tokenAddress: req.body?.tokenAddress,
        decimals: req.body?.decimals,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to prepare wallet transfer');
    }
  });

  app.post('/api/privy/wallets/verify-signature', async (req, res) => {
    try {
      const { verifyWalletOwnershipSignature } = await import('./src/server/privyService');
      const data = await verifyWalletOwnershipSignature({
        address: req.body?.address,
        message: req.body?.message,
        signature: req.body?.signature,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Wallet signature verification failed');
    }
  });

  app.post('/api/privy/wallets/verify-address', async (req, res) => {
    try {
      const { verifyWalletAddressOnChain } = await import('./src/server/privyService');
      const data = await verifyWalletAddressOnChain({
        address: req.body?.address,
        network: req.body?.network,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Wallet address verification failed');
    }
  });

  app.get('/api/privy/wallets/list', async (req, res) => {
    try {
      const { getPrivyServerWallets } = await import('./src/server/privyService');
      const data = getPrivyServerWallets(req.query.userId);
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to load Privy server wallets');
    }
  });

  app.post('/api/privy/wallets/create', async (req, res) => {
    try {
      const { createPrivyServerWallet } = await import('./src/server/privyService');
      const data = await createPrivyServerWallet({
        userId: req.body?.userId,
        createNew: Boolean(req.body?.createNew),
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to create Privy wallet');
    }
  });

  app.post('/api/privy/wallets/send', async (req, res) => {
    try {
      const { sendPrivyServerWalletTransaction } = await import('./src/server/privyService');
      const data = await sendPrivyServerWalletTransaction({
        walletId: req.body?.walletId,
        fromAddress: req.body?.fromAddress,
        toAddress: req.body?.toAddress,
        amount: req.body?.amount,
        network: req.body?.network,
        assetType: req.body?.assetType,
        tokenSymbol: req.body?.tokenSymbol,
        tokenAddress: req.body?.tokenAddress,
        decimals: req.body?.decimals,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to submit transaction via Privy wallet');
    }
  });

  app.get('/api/privy/wallets/preferences', async (req, res) => {
    try {
      const { getWalletPreferences } = await import('./src/server/privyService');
      const data = getWalletPreferences(req.query.userId);
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to read wallet preferences');
    }
  });

  app.post('/api/privy/wallets/preferences', async (req, res) => {
    try {
      const { saveWalletPreferences } = await import('./src/server/privyService');
      const data = saveWalletPreferences({
        userId: req.body?.userId,
        walletAddress: req.body?.walletAddress,
        networkKey: req.body?.networkKey,
        customTokensByNetwork: req.body?.customTokensByNetwork,
      });
      return res.json({ success: true, data });
    } catch (error: any) {
      return sendPrivyError(res, error, 'Failed to save wallet preferences');
    }
  });

  // Real-time User & Admin Presence Tracking (60s heartbeat TTL)
  const PRESENCE_TTL_MS = 60_000;
  const presenceSessions = new Map<
    string,
    { tabId: string; keys: string[]; name?: string; lastSeen: number }
  >();
  const presenceLastSeen = new Map<string, number>();

  const prunePresenceSessions = () => {
    const now = Date.now();
    for (const [tabId, entry] of presenceSessions.entries()) {
      if (now - entry.lastSeen > PRESENCE_TTL_MS) {
        for (const k of entry.keys) {
          presenceLastSeen.set(k, entry.lastSeen);
        }
        presenceSessions.delete(tabId);
      }
    }
  };

  app.get('/api/presence', (_req, res) => {
    prunePresenceSessions();
    const sessions = Array.from(presenceSessions.values());
    const lastSeen: Record<string, number> = {};
    for (const [k, ts] of presenceLastSeen.entries()) {
      lastSeen[k] = ts;
    }
    return res.json({
      success: true,
      ttlMs: PRESENCE_TTL_MS,
      serverTime: Date.now(),
      sessions,
      lastSeen,
    });
  });

  app.post('/api/presence/heartbeat', (req, res) => {
    prunePresenceSessions();
    const tabId = typeof req.body?.tabId === 'string' ? req.body.tabId.trim() : '';
    const rawKeys: unknown[] = Array.isArray(req.body?.keys) ? req.body.keys : [];
    const keys: string[] = Array.from(
      new Set<string>(
        rawKeys
          .filter((k: unknown): k is string => typeof k === 'string' && k.trim().length > 0)
          .map((k: string) => k.trim().toLowerCase())
      )
    );
    if (!tabId || keys.length === 0) {
      return res.status(400).json({ success: false, error: 'Missing tabId or keys' });
    }
    const now = Date.now();
    presenceSessions.set(tabId, {
      tabId,
      keys,
      name: typeof req.body?.name === 'string' ? req.body.name : undefined,
      lastSeen: now,
    });
    for (const k of keys) {
      presenceLastSeen.set(k, now);
    }
    return res.json({ success: true, serverTime: now });
  });

  app.post('/api/presence/offline', express.text({ type: '*/*' }), (req, res) => {
    prunePresenceSessions();
    let payload: any = req.body;
    if (typeof payload === 'string') {
      try {
        payload = JSON.parse(payload);
      } catch {
        payload = {};
      }
    }
    const tabId = typeof payload?.tabId === 'string' ? payload.tabId.trim() : '';
    const rawKeys: unknown[] = Array.isArray(payload?.keys) ? payload.keys : [];
    const targetKeys = new Set<string>(
      rawKeys
        .filter((k: unknown): k is string => typeof k === 'string' && k.trim().length > 0)
        .map((k: string) => k.trim().toLowerCase())
    );
    const now = Date.now();

    if (tabId && presenceSessions.has(tabId)) {
      const existing = presenceSessions.get(tabId)!;
      for (const k of existing.keys) {
        presenceLastSeen.set(k, now);
      }
      presenceSessions.delete(tabId);
    }

    if (targetKeys.size > 0) {
      for (const [existingTabId, entry] of presenceSessions.entries()) {
        if (tabId && existingTabId !== tabId) continue;
        if (entry.keys.some((k) => targetKeys.has(k))) {
          for (const k of entry.keys) {
            presenceLastSeen.set(k, now);
          }
          presenceSessions.delete(existingTabId);
        }
      }
      for (const k of targetKeys) {
        presenceLastSeen.set(k, now);
      }
    }

    return res.json({ success: true, serverTime: now });
  });

  // Ensure unmatched /api and /api/* routes and errors always return JSON (never HTML index.html)
  app.use('/api', (req, res) => {
    return res.status(404).json({
      success: false,
      error: `API route not found: ${req.method} ${req.originalUrl}`,
    });
  });

  app.use('/api', (err: any, _req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (res.headersSent) {
      return next(err);
    }
    const status =
      typeof err?.status === 'number'
        ? err.status
        : typeof err?.statusCode === 'number'
          ? err.statusCode
          : 500;
    return res.status(status).json({
      success: false,
      error: err?.message || 'Internal server error',
    });
  });

  // Vite middleware for development vs static for production
  const isProduction = process.env.NODE_ENV === 'production' || currentFile.endsWith('.cjs');
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: false,
        ws: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(projectRoot, 'dist');
    const buildDir = path.join(projectRoot, 'build');
    const distPath = fs.existsSync(path.join(distDir, 'index.html')) ? distDir : buildDir;
    if (!fs.existsSync(path.join(distPath, 'index.html'))) {
      console.error(`[Server] CRITICAL: Production index.html not found at ${path.join(distPath, 'index.html')}`);
    }
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      if (req.path === '/api' || req.path.startsWith('/api/')) {
        return res.status(404).json({
          success: false,
          error: `API route not found: ${req.method} ${req.originalUrl}`,
        });
      }
      return res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Final Finance server successfully started`);
    console.log(`[Server] Local: http://localhost:${PORT}`);
    console.log(`[Server] Network: http://0.0.0.0:${PORT}`);
    console.log(`[Server] Environment: ${process.env.NODE_ENV || 'development'}`);
  });
}

startServer().catch((err) => {
  console.error('[Server] CRITICAL FAILURE during startup:', err);
  process.exit(1);
});
