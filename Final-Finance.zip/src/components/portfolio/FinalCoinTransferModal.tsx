import React, { useState } from 'react';
import { X, Send, User, MessageSquare, AlertCircle, CheckCircle2, Zap } from 'lucide-react';
import { FinalCoinItem } from '../../types/wallet';
import { createLedgerItemFromP2PTransfer, recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { saveStoredUserWallets, getStoredUserWallets } from '../../data/defaultWallets';
import { applyCurrencyWalletDelta, inferCurrencyCategory } from '../../utils/walletBalanceUpdater';
import { dispatchGlobalNotification } from '../../utils/notificationService';
import { enqueueUserNotification } from '../../services/socialService';
import { getFinalCoinUsdRate } from '../../utils/tokenDollarEquivalence';

interface FinalCoinTransferModalProps {
  userId: string;
  userName: string;
  finalCoinsHoldings: FinalCoinItem[];
  initialCoinSymbol?: string | null;
  onClose: () => void;
  onTransferComplete?: () => void;
}

export const FinalCoinTransferModal: React.FC<FinalCoinTransferModalProps> = ({
  userId,
  userName,
  finalCoinsHoldings,
  initialCoinSymbol,
  onClose,
  onTransferComplete
}) => {
  const heldFinalCoins = React.useMemo(
    () => finalCoinsHoldings.filter(c => Number(c.balance || 0) > 0),
    [finalCoinsHoldings]
  );

  const [selectedCoinSymbol, setSelectedCoinSymbol] = useState<string>(() => {
    if (initialCoinSymbol && heldFinalCoins.find(c => c.symbol === initialCoinSymbol)) {
      return initialCoinSymbol;
    }
    return heldFinalCoins[0]?.symbol || '';
  });
  const [recipientHandle, setRecipientHandle] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [note, setNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedCoin = heldFinalCoins.find(c => c.symbol === selectedCoinSymbol);
  const maxBalance = Number(selectedCoin?.balance || 0);
  const parsedAmount = typeof amount === 'number' ? amount : 0;
  const isInsufficientBalance = parsedAmount > maxBalance;

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedCoinSymbol) {
      setError('Please select a Final Coin to transfer.');
      return;
    }

    if (inferCurrencyCategory(selectedCoinSymbol) !== 'final_coin') {
      setError('Money transfers are restricted exclusively to Final Currency and Final Coins.');
      return;
    }

    if (!recipientHandle.trim()) {
      setError('Please enter a recipient handle.');
      return;
    }

    if (typeof amount !== 'number' || amount <= 0) {
      setError('Please enter a valid amount.');
      return;
    }

    if (amount > maxBalance) {
      setError(`You do not have enough balance. Available: ${maxBalance.toLocaleString()} ${selectedCoinSymbol}.`);
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Update Wallet
      const currentWallets = getStoredUserWallets(userId);
      const updatedFinalCoins = (currentWallets.finalCoins || []).map(fc => {
        if (fc.symbol === selectedCoinSymbol) {
          return { ...fc, balance: fc.balance - amount };
        }
        return fc;
      });

      saveStoredUserWallets(userId, {
        ...currentWallets,
        finalCoins: updatedFinalCoins
      });

      const cleanRecipientTarget = recipientHandle.trim().replace(/^@/, '');
      if (cleanRecipientTarget && cleanRecipientTarget !== userId) {
        applyCurrencyWalletDelta({
          userId: cleanRecipientTarget,
          currencySymbol: selectedCoinSymbol,
          currencyName: selectedCoin?.name,
          delta: amount,
          utilityNote: `P2P transfer received from ${userName}${note ? `: ${note}` : ''}`
        });
      }

      const computedUSD = Math.round(amount * getFinalCoinUsdRate(selectedCoinSymbol) * 100) / 100;

      // 2. Record Ledger Transactions for Sender & Recipient
      const cleanRecipient = recipientHandle.trim().replace(/^@/, '');
      const senderLedgerItem = createLedgerItemFromP2PTransfer({
        amount,
        amountUSD: computedUSD,
        coinSymbol: selectedCoinSymbol,
        coinName: selectedCoin?.name || `${selectedCoinSymbol} Final Coin`,
        mode: 'final_coin',
        senderUser: { id: userId, name: userName, handle: userId },
        recipientUser: { id: cleanRecipient, name: cleanRecipient, handle: cleanRecipient },
        memo: note.trim() || undefined,
        isSender: true
      });
      recordLedgerTransaction(userId, senderLedgerItem);

      if (cleanRecipient && cleanRecipient !== userId) {
        const recipientLedgerItem = createLedgerItemFromP2PTransfer({
          amount,
          amountUSD: computedUSD,
          coinSymbol: selectedCoinSymbol,
          coinName: selectedCoin?.name || `${selectedCoinSymbol} Final Coin`,
          mode: 'final_coin',
          senderUser: { id: userId, name: userName, handle: userId },
          recipientUser: { id: cleanRecipient, name: cleanRecipient, handle: cleanRecipient },
          memo: note.trim() || undefined,
          isSender: false
        });
        recordLedgerTransaction(cleanRecipient, recipientLedgerItem);
      }
      dispatchGlobalNotification({
        title: `Sent ${amount.toLocaleString()} ${selectedCoinSymbol}`,
        description: `Transferred ${amount.toLocaleString()} ${selectedCoinSymbol} to @${cleanRecipient}.`,
        type: 'wallet',
        targetTab: 'wallets',
        amount,
        currency: selectedCoinSymbol,
        tone: 'success',
      });
      enqueueUserNotification([cleanRecipient], {
        title: `Received ${amount.toLocaleString()} ${selectedCoinSymbol}`,
        description: `${userName} sent you ${amount.toLocaleString()} ${selectedCoinSymbol}${note ? ` (${note})` : ''}.`,
        type: 'wallet',
        targetTab: 'wallets',
        amount,
        currency: selectedCoinSymbol,
      });

      setSuccess(true);
      if (onTransferComplete) onTransferComplete();
      
      // Close after 2 seconds
      setTimeout(() => {
        onClose();
      }, 2500);
    } catch (err) {
      console.error('Transfer error:', err);
      setError('An error occurred while processing the transfer.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
        <div className="w-full max-w-md bg-white rounded-3xl p-8 text-center space-y-6 shadow-2xl border border-emerald-100">
          <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center animate-bounce">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-slate-900 font-display">Transfer Successful!</h2>
            <p className="text-slate-500">
              Successfully sent <span className="font-bold text-slate-900">{amount.toLocaleString()} {selectedCoinSymbol}</span> to <span className="font-bold text-blue-600">@{recipientHandle.replace('@', '')}</span>.
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs font-mono text-slate-500">
            Transaction recorded on Final Protocol L1 Ledger.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200 text-left">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200 shadow-xs">
              <Send className="w-5 h-5 -rotate-12" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Transfer Final Coins</h2>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Sovereign Peer-to-Peer Protocol</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-100 text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleTransfer} className="p-6 space-y-5 overflow-y-auto">
          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-start gap-2.5 animate-in shake-in-from-left duration-200">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Asset Selection */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-1">Select Sovereign Asset</label>
            <div className="grid grid-cols-1 gap-2">
              {heldFinalCoins.length > 0 ? (
                <div className="relative">
                  <select
                    value={selectedCoinSymbol}
                    onChange={(e) => setSelectedCoinSymbol(e.target.value)}
                    className="w-full p-4 rounded-2xl border border-slate-200 bg-slate-50 text-sm font-bold appearance-none focus:ring-2 focus:ring-amber-500 outline-none pr-10 cursor-pointer"
                  >
                    {heldFinalCoins.map(fc => (
                      <option key={fc.symbol} value={fc.symbol}>
                        {fc.name} ({fc.symbol}) — {fc.balance.toLocaleString()} Available
                      </option>
                    ))}
                  </select>
                  <Zap className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-500 pointer-events-none fill-current" />
                </div>
              ) : (
                <div className="p-4 rounded-2xl border border-dashed border-slate-300 text-center text-slate-500 text-xs font-bold italic bg-slate-50">
                  You do not have any Final Coins with an available balance.
                </div>
              )}
            </div>
          </div>

          {/* Recipient */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-1">Recipient Handle</label>
            <div className="relative">
              <input
                type="text"
                placeholder="e.g. username_23"
                value={recipientHandle}
                onChange={(e) => setRecipientHandle(e.target.value)}
                className="w-full p-4 rounded-2xl border border-slate-200 bg-slate-50 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none pl-11"
              />
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            </div>
          </div>

          {/* Amount */}
          <div className="space-y-2">
            <div className="flex items-center justify-between ml-1">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Transfer Amount</label>
              <button
                type="button"
                onClick={() => setAmount(maxBalance)}
                className="text-[10px] font-bold text-amber-600 hover:text-amber-700 uppercase tracking-wider cursor-pointer"
              >
                Max: {maxBalance.toLocaleString()}
              </button>
            </div>
            <div className="relative">
              <input
                type="number"
                placeholder="0.00"
                step="any"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value === '' ? '' : Number(e.target.value));
                  setError(null);
                }}
                className={`w-full p-4 rounded-2xl border bg-slate-50 text-sm font-bold focus:ring-2 outline-none pr-16 ${
                  isInsufficientBalance
                    ? 'border-rose-400 text-rose-900 focus:ring-rose-500'
                    : 'border-slate-200 focus:ring-amber-500'
                }`}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 uppercase">
                {selectedCoinSymbol}
              </span>
            </div>
            {isInsufficientBalance && (
              <p className="text-xs font-bold text-rose-600 flex items-center gap-1.5 ml-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>You do not have enough balance. Available: {maxBalance.toLocaleString()} {selectedCoinSymbol}.</span>
              </p>
            )}
          </div>

          {/* Note */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 ml-1">Memo / Note (Optional)</label>
            <div className="relative">
              <input
                type="text"
                placeholder="What is this for?"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full p-4 rounded-2xl border border-slate-200 bg-slate-50 text-sm font-bold focus:ring-2 focus:ring-slate-500 outline-none pl-11"
              />
              <MessageSquare className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isSubmitting || heldFinalCoins.length === 0}
            className="w-full py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm transition-all shadow-lg active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer mt-2"
          >
            {isSubmitting ? (
              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Execute Protocol Transfer</span>
              </>
            )}
          </button>

          <p className="text-[10px] text-center text-slate-400 font-bold uppercase leading-relaxed px-4">
            Final Currency &amp; Final Coins Only — Zero fiat involved.
          </p>
        </form>
      </div>
    </div>
  );
};
