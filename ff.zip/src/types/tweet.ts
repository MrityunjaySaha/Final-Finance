export interface TweetPollOption {
  id: string;
  text: string;
  votes: number;
}

export interface TweetPoll {
  id: string;
  question?: string;
  options: TweetPollOption[];
  voterIds: Record<string, string>; // userId -> optionId
  totalVotes: number;
  durationDays: number;
  expiresAt: number;
}

export interface TweetReply {
  id: string;
  tweetId: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  content: string;
  timestamp: string;
  createdAt: number;
  likes: number;
  likedBy: string[];
}

export interface TweetTradeReceipt {
  instrumentCategory: 'equity' | 'derivatives';
  assetName: string;
  ticker: string;
  side: 'buy' | 'sell';
  shares: number;
  price: number;
  totalValue: number;
  coinLabel: string;
  derivativeLabel?: string;
  strikePrice?: number;
  leverage?: number;
  expiryDate?: string;
  gainLossPercent?: number;
}

export interface TweetSharedPostComment {
  reviewerName: string;
  reviewerAvatar?: string;
  rating: number;
  comment: string;
  timestamp?: number;
}

export interface TweetSharedPost {
  listingId: string;
  title: string;
  description: string;
  category: string;
  itemType: 'good' | 'service' | 'auction';
  statusLabel: string;
  sellerHandle: string;
  sellerName?: string;
  priceUSD: number;
  imageUrl?: string;
  averageRating: number;
  ratingCount: number;
  userRating?: number;
  userComment?: string;
  comments?: TweetSharedPostComment[];
}

export interface Tweet {
  id: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  isVerified?: boolean;
  content: string;
  createdAt: number;
  timestamp: string;
  photos?: string[];
  video?: string;
  poll?: TweetPoll;
  tradeReceipt?: TweetTradeReceipt;
  sharedPost?: TweetSharedPost;
  likes: number;
  likedBy: string[];
  retweets: number;
  retweetedBy: string[];
  bookmarks: number;
  bookmarkedBy: string[];
  views: number;
  replies: TweetReply[];
  hashtags: string[];
  mentions: string[];
  tickers?: string[];
}
