import React, { useState, useEffect } from 'react';
// import { motion } from 'motion/react';
import { X, Loader2, Eye, EyeOff, AlertCircle, ShieldCheck, KeyRound, Sparkles } from 'lucide-react';
import { AuthSession } from '../types/auth';
import { signInWithGoogle, getRegisteredUsers, RegisteredAccount } from '../services/firebaseAuth';

interface GoogleAccountChooserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAccount: (user: AuthSession) => void;
  initialAccount?: RegisteredAccount | null;
}

export const GoogleAccountChooserModal: React.FC<GoogleAccountChooserModalProps> = ({
  isOpen,
  onClose,
  onSelectAccount,
}) => {
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const registeredUsers = getRegisteredUsers();

  // If email changes to a known account, suggest or auto-fill the saved password
  useEffect(() => {
    const trimmed = emailInput.trim().toLowerCase();
    if (trimmed && registeredUsers[trimmed]) {
      const acc = registeredUsers[trimmed];
      if (acc.passwordHash && !passwordInput) {
        setPasswordInput(acc.passwordHash);
      }
    }
  }, [emailInput, registeredUsers, passwordInput]);

  if (!isOpen) return null;

  const handleSignInSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawEmail = emailInput.trim();
    if (!rawEmail) {
      setErrorMessage('Please enter your Google / Gmail email address.');
      return;
    }
    if (!passwordInput) {
      setErrorMessage('Please enter your password.');
      return;
    }

    const email = rawEmail.includes('@') ? rawEmail.toLowerCase() : `${rawEmail.toLowerCase()}@gmail.com`;
    setIsLoading(true);
    setErrorMessage('');

    try {
      const isExisting = Boolean(registeredUsers[email]);
      const res = await signInWithGoogle(email, passwordInput, !isExisting);
      if (res.success && res.user) {
        onSelectAccount(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Password mismatch. Try again or check your saved password.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Authentication error.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAutofillGholu = () => {
    setEmailInput('gholu653@gmail.com');
    setPasswordInput('gholu123');
    setErrorMessage('');
  };

  const handleAutofillRanma = () => {
    setEmailInput('ranmaanimaker@gmail.com');
    setPasswordInput('password123');
    setErrorMessage('');
  };

  const handleAutofillDBZ = () => {
    setEmailInput('awesomedbz@gmail.com');
    setPasswordInput('password123');
    setErrorMessage('');
  };

  const handleAutofillCurrentPassword = () => {
    const trimmed = emailInput.trim().toLowerCase();
    if (trimmed && registeredUsers[trimmed]) {
      setPasswordInput(registeredUsers[trimmed].passwordHash);
    } else {
      setPasswordInput('gholu123');
    }
    setErrorMessage('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-[440px] bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 text-left relative overflow-hidden font-sans animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Google Header */}
        <div className="space-y-2 mb-4">
          <svg className="w-7 h-7" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
            />
          </svg>

          <div>
            <h2 className="text-xl sm:text-2xl font-normal text-slate-900 tracking-tight">
              Sign in with Google
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Enter any Gmail address and use your saved password
            </p>
          </div>
        </div>

        {/* Quick Saved Account Autofill Helper Chips */}
        <div className="mb-4 space-y-2">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Quick Select Accounts</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={handleAutofillRanma}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-900 border border-slate-200 text-left transition-colors cursor-pointer flex items-center justify-between"
            >
              <div className="min-w-0">
                <p className="text-xs font-bold truncate">Ranma</p>
                <p className="text-[10px] text-slate-500 truncate">ranmaanimaker@gmail.com</p>
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-lg bg-slate-200 text-slate-800 shrink-0">Select</span>
            </button>

            <button
              type="button"
              onClick={handleAutofillDBZ}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-900 border border-slate-200 text-left transition-colors cursor-pointer flex items-center justify-between"
            >
              <div className="min-w-0">
                <p className="text-xs font-bold truncate">Awesome DBZ</p>
                <p className="text-[10px] text-slate-500 truncate">awesomedbz@gmail.com</p>
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-lg bg-slate-200 text-slate-800 shrink-0">Select</span>
            </button>
          </div>

          <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <KeyRound className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <div className="min-w-0">
                <p className="text-xs font-medium text-slate-800 truncate">gholu653@gmail.com</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleAutofillGholu}
              className="px-2 py-0.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-[10px] font-bold transition-all shrink-0 cursor-pointer"
            >
              Select
            </button>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-4 p-3 text-xs text-red-600 bg-red-50 rounded-xl border border-red-200 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Standard Form with Password Manager Autofill attributes */}
        <form onSubmit={handleSignInSubmit} method="POST" action="#" autoComplete="on" className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="google_account_email" className="block text-xs font-medium text-slate-700">
                Gmail / Google Account
              </label>
              <span className="text-[11px] text-slate-400">username / email</span>
            </div>
            <input
              type="email"
              id="google_account_email"
              name="username"
              autoComplete="username email webauthn"
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              placeholder="gholu653@gmail.com"
              autoFocus
              className="w-full px-3.5 py-3 text-sm rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 outline-none transition-all text-slate-900 placeholder:text-slate-400 bg-white"
              required
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="google_account_password" className="text-xs font-medium text-slate-700">
                Password
              </label>
              <button
                type="button"
                onClick={handleAutofillCurrentPassword}
                className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3 h-3 text-blue-600" />
                <span>Autofill password</span>
              </button>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                id="google_account_password"
                name="password"
                autoComplete="current-password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter password or click autofill"
                className="w-full px-3.5 py-3 pr-20 text-sm rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 outline-none transition-all text-slate-900 placeholder:text-slate-400 bg-white"
                required
              />
              <div className="absolute right-2.5 top-2.5 flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1 rounded text-slate-400 hover:text-slate-700 cursor-pointer"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>Browser credential manager & 1-click password autofill enabled.</span>
          </div>

          <div className="pt-3 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading || !emailInput.trim() || !passwordInput}
              className="px-6 py-2.5 rounded-full bg-[#1a73e8] hover:bg-[#1557b0] active:bg-[#174ea6] text-white text-sm font-medium transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-40 disabled:cursor-not-allowed min-w-[90px]"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin text-white" /> : 'Continue'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
