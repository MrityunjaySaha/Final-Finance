import React, { useState } from 'react';
import { migrateLoanIdsToLedger } from './utils/ledgerMigration';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { LandingHomePage } from './components/LandingHomePage';
import { UserDashboardView } from './components/UserDashboardView';
import { VaultsView } from './components/VaultsView';
import { MarketplaceView } from './components/MarketplaceView';
import { ListingDetailPage } from './components/ListingDetailPage';
import { CommunityView } from './components/CommunityView';
import { MessagesPage } from './components/MessagesPage';
import { SocialPage } from './components/SocialPage';
import { CommunitySearchPage } from './components/CommunitySearchPage';
import { UploadsPage, UploadsFocusRestore, UploadsFilterStatus } from './components/UploadsPage';
import { QRCodesPage } from './components/QRCodesPage';
import { PointOfSaleView } from './components/PointOfSaleView';
import { RideShareView } from './components/RideShareView';
import { WalletsPage } from './components/WalletsPage';
import { PortfolioPage, PortfolioPrimaryTab } from './components/PortfolioPage';
import { SettingsPage } from './components/SettingsPage';
import { FundraisingPage } from './components/FundraisingPage';
import { UserProfileView } from './components/UserProfileView';
import { SearchResultsPage } from './components/SearchResultsPage';
import { StockMarketView } from './components/StockMarketView';
import { SubsidiesGrantsPage } from './components/SubsidiesGrantsPage';
import { AdminPage } from './components/AdminPage';
import { SuperAdminPage } from './components/SuperAdminPage';
import { AssetInventoryPage } from './components/AssetInventoryPage';
import { TweetingView, TweetingViewSnapshot, SharedTweetFocusContext } from './components/social/TweetingView';
import { AuthModal } from './components/AuthModal';
import { CallModal } from './components/CallModal';
import { CreateListingDraftModal } from './components/CreateListingDraftModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { DepositModal } from './components/DepositModal';
import { BarterProposalModal } from './components/BarterProposalModal';
import { AuctionBidModal } from './components/AuctionBidModal';
import { InstantSwapModal } from './components/InstantSwapModal';
import { VerificationModal } from './components/VerificationModal';
import { ToastContainer } from './components/ToastContainer';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ReserveVault, MarketplaceListing } from './types';
import { AuthSession } from './types/auth';
import { SearchableProduct } from './data/searchCatalog';
import { StockItem, StockMarketWay } from './types/stocks';
import { UserPublicProfile } from './types/social';
import { getCurrentSession, signInWithDemoAccount, DEMO_ACCOUNTS, signOut } from './services/firebaseAuth';
import { getOrCreateDirectConversation } from './services/chatService';
import { areUsersBlockedEitherWay, areUsersFriends, isAdminAccount } from './services/socialService';
import { simulateNetworkTweet, TWEETS_STORAGE_KEY, notifyIfTweetFromFriendOrFollowed } from './services/tweetingService';
import { getAllMarketplaceListings } from './services/marketplaceService';
import { INITIAL_STOCKS } from './data/stocksData';
import {
  ProfileReturnAnchor,
  clearProfileReturnAnchor,
  getProfileReturnAnchor,
  setPendingProfileReturnAnchor,
} from './utils/profileReturnState';

function convertAnyListingToAppListing(item: any): MarketplaceListing {
  const photos = [
    ...(Array.isArray(item.photos) ? item.photos : []),
    ...(Array.isArray(item.mediaList)
      ? item.mediaList.filter((m: any) => m?.type === 'image' && m?.url).map((m: any) => m.url)
      : []),
  ];
  const videos = [
    ...(Array.isArray(item.videos) ? item.videos : []),
    ...(Array.isArray(item.mediaList)
      ? item.mediaList.filter((m: any) => m?.type === 'video' && m?.url).map((m: any) => m.url)
      : []),
  ];
  const primaryImage = item.imageUrl || photos[0] || '';
  const primaryVideo = item.videoUrl || item.video || videos[0];
  const rawPriceUSD = typeof item.priceUSD === 'number' ? item.priceUSD : (item.primaryPriceUSD ?? item.estimatedValueUSD ?? 0);
  const handleClean = String(item.sellerHandle || item.creatorHandle || item.sellerId || item.userId || 'member').replace(/^@/, '');

  return {
    id: item.id,
    title: item.title || 'Untitled Listing',
    description: item.description || '',
    priceUSD: rawPriceUSD,
    priceInNative: item.priceInNative || (item.finalCoinsPricing?.amount ? `${item.finalCoinsPricing.amount.toLocaleString()} ${item.finalCoinsPricing.symbol}` : undefined),
    category: (item.category || (item.itemType === 'service' ? 'services' : 'goods')) as any,
    itemType: item.itemType,
    listingIntent: item.listingIntent,
    auctionConfig: item.auctionConfig,
    primaryTradeMode: item.primaryTradeMode,
    primaryCurrency: item.primaryCurrency,
    acceptedSettlements: Array.isArray(item.acceptedSettlements) ? item.acceptedSettlements : undefined,
    acceptedCurrencyList: Array.isArray(item.acceptedCurrencyList) ? item.acceptedCurrencyList : undefined,
    sellerName: item.sellerName || item.creatorName || 'Sovereign Member',
    sellerId: item.sellerId || item.creatorHandle || item.userId || 'member',
    sellerHandle: item.sellerHandle || `@${handleClean}`,
    sellerAvatar: item.sellerAvatar || item.creatorAvatar || '',
    sellerVerified: typeof item.sellerVerified === 'boolean' ? item.sellerVerified : true,
    attributes: item.attributes && typeof item.attributes === 'object' ? item.attributes : {},
    status: item.status === 'sold' ? 'sold' : item.status === 'draft' ? 'draft' : 'active',
    imageUrl: primaryImage,
    photos: photos.length > 0 ? Array.from(new Set(photos)) : undefined,
    videoUrl: primaryVideo,
    videos: videos.length > 0 ? Array.from(new Set(videos)) : undefined,
    mediaList: Array.isArray(item.mediaList) ? item.mediaList : undefined,
    tags: Array.isArray(item.tags) ? item.tags : undefined,
    hashtags: Array.isArray(item.hashtags) ? item.hashtags : undefined,
    skills: Array.isArray(item.skills) ? item.skills : undefined,
    location: item.location,
    condition: item.condition,
    quantity: item.quantity,
    unitLabel: item.unitLabel,
    availableUnits: item.availableUnits,
    unitType: item.unitType,
    turnaroundTime: item.turnaroundTime,
    deliverables: item.deliverables,
    barterDesired: item.barterDesired || item.barterTerms?.desiredTrades,
    finalCoinsPricing: item.finalCoinsPricing,
    stableCoinsPricing: item.stableCoinsPricing,
    fiatPricing: item.fiatPricing,
    cryptoPricing: item.cryptoPricing,
    barterTerms: item.barterTerms,
    crossTransactionalTerms: item.crossTransactionalTerms,
    likes: typeof item.likes === 'number' ? item.likes : 0,
    views: typeof item.views === 'number' ? item.views : 0,
    appraisalGrade: item.appraisalGrade || 'A',
    modelUsed: item.modelUsed,
    imageResolution: item.imageResolution,
    createdAt: item.createdAt || new Date().toISOString(),
  };
}

function buildTradeTargetListing(item: any) {
  if (!item) return null;
  return {
    ...item,
    id: item.id || `prop-${Date.now()}`,
    title: item.title || item.name || 'Marketplace Listing',
    sellerId: item.sellerId || item.userId || 'counterparty',
    sellerName: item.sellerName || item.creatorName || 'Merchant',
    sellerHandle: item.sellerHandle || item.creatorHandle,
    primaryPriceUSD: item.primaryPriceUSD ?? item.priceUSD ?? item.estimatedValueUSD ?? 0,
    estimatedValueUSD: item.priceUSD ?? item.primaryPriceUSD ?? item.estimatedValueUSD ?? 0,
    auctionConfig: item.auctionConfig,
  };
}

function MainAppContent() {
  const { currentTab, setCurrentTab, setCurrentUser, previousTab, setPreviousTab, addToast, listings, setListings, returnListingId, setReturnListingId, chatReturnOrigin, setChatReturnOrigin } = useApp();

  // Auth session
  const [authSession, setAuthSession] = useState<AuthSession | null>(() => getCurrentSession());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Modals & Active Selections
  const [isNewListingModalOpen, setIsNewListingModalOpen] = useState(false);
  const [selectedVaultForDeposit, setSelectedVaultForDeposit] = useState<ReserveVault | null>(null);

  // Search product detail modal
  const [selectedProduct, setSelectedProduct] = useState<SearchableProduct | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [activeSearchQuery, setActiveSearchQuery] = useState<string>('');

  // Selected Stock for deep-linking
  const [selectedStockForDesk, setSelectedStockForDesk] = useState<StockItem | null>(null);
  const [quickBuyStockForDesk, setQuickBuyStockForDesk] = useState<StockItem | null>(null);
  const [selectedStockMarketWay, setSelectedStockMarketWay] = useState<StockMarketWay | 'all'>('all');
  const [portfolioOriginTab, setPortfolioOriginTab] = useState<'holdings' | 'derivatives' | 'tweeting' | null>(null);
  const [portfolioReturnPrimaryTab, setPortfolioReturnPrimaryTab] = useState<PortfolioPrimaryTab>('overview');
  const [stockMarketResetKey, setStockMarketResetKey] = useState<number>(0);
  const [savedTweetingSnapshot, setSavedTweetingSnapshot] = useState<TweetingViewSnapshot | null>(null);
  const [tweetingRestoreSnapshot, setTweetingRestoreSnapshot] = useState<TweetingViewSnapshot | null>(null);
  const [tweetingFocusContext, setTweetingFocusContext] = useState<SharedTweetFocusContext | null>(null);
  const [uploadsFocusRestore, setUploadsFocusRestore] = useState<UploadsFocusRestore | null>(null);
  const skipNextTabScrollTopRef = React.useRef<boolean>(false);

  interface ProfileNavFrame {
    tab: string;
    targetProfileUserId: string | null;
    scrollY: number;
    listing: MarketplaceListing | null;
    anchor: ProfileReturnAnchor;
  }
  const profileNavStackRef = React.useRef<ProfileNavFrame[]>([]);
  const [profileBackLabel, setProfileBackLabel] = useState<string>('Back');

  // Quick Swapper Modal State
  const [isSwapModalOpen, setIsSwapModalOpen] = useState(false);

  // Verification & Subscription Modal State ($2/month with 2 forms of ID)
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);

  // Barter Proposal Modal State
  const [isBarterModalOpen, setIsBarterModalOpen] = useState(false);
  const [barterTargetListing, setBarterTargetListing] = useState<any>(null);

  // Auction Bid & Award Modal State
  const [isAuctionModalOpen, setIsAuctionModalOpen] = useState(false);
  const [auctionTargetListing, setAuctionTargetListing] = useState<any>(null);

  const openTradeOrAuctionModal = (item: any) => {
    const target = buildTradeTargetListing(item);
    if (!target) return;
    if (target.listingIntent === 'auction') {
      setAuctionTargetListing(target);
      setIsAuctionModalOpen(true);
    } else {
      setBarterTargetListing(target);
      setIsBarterModalOpen(true);
    }
  };

  // Profile View Target
  const [targetProfileUserId, setTargetProfileUserId] = useState<string | null>(null);
  const [returnProfileUserId, setReturnProfileUserId] = useState<string | null>(null);

  // Selected Marketplace Good / Service Detail Page Target
  const [selectedListingDetail, setSelectedListingDetail] = useState<MarketplaceListing | null>(null);
  const [listingDetailReturnTab, setListingDetailReturnTab] = useState<string>('marketplace');
  const listingDetailBackLabel = (() => {
    if (listingDetailReturnTab === 'user_profile') return 'Back to Profile & Posts';
    if (listingDetailReturnTab === 'uploads') return 'Back to Uploads';
    if (listingDetailReturnTab === 'community') return 'Back to Community';
    if (listingDetailReturnTab === 'search') return 'Back to Search';
    return 'Back to Marketplace';
  })();

  const handleSelectListing = (listing: MarketplaceListing) => {
    const normalized = convertAnyListingToAppListing(listing);
    setListingDetailReturnTab(currentTab !== 'listing_detail' ? currentTab : 'marketplace');
    if (currentTab === 'user_profile') {
      setReturnProfileUserId(targetProfileUserId);
    }
    setSelectedListingDetail(normalized);
    setPreviousTab(currentTab);
    setReturnListingId(normalized.id);
    setUploadsFocusRestore({ listingId: normalized.id, key: Date.now() });
    setCurrentTab('listing_detail');
    if (typeof window !== 'undefined') {
      const nextUrl = new URL(window.location.href);
      nextUrl.searchParams.set('listing', normalized.id);
      nextUrl.searchParams.delete('profile');
      nextUrl.searchParams.delete('user');
      nextUrl.searchParams.delete('stock');
      nextUrl.searchParams.delete('tweet');
      nextUrl.searchParams.delete('community');
      nextUrl.searchParams.delete('news');
      window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectListingById = (listingId: string) => {
    const fromApp = listings.find((l) => l.id === listingId);
    if (fromApp) {
      handleSelectListing(fromApp);
      return;
    }
    const fromService = getAllMarketplaceListings().find((l) => l.id === listingId);
    if (fromService) {
      handleSelectListing(convertAnyListingToAppListing(fromService));
      return;
    }
    addToast({
      type: 'error',
      title: 'Listing Not Found',
      message: 'This marketplace listing is no longer available.',
    });
  };

  const handleDropdownNavigate = (view: any) => {
    profileNavStackRef.current = [];
    setProfileBackLabel('Back');
    clearProfileReturnAnchor();
    if (view === 'portfolio') {
      setPreviousTab(null);
    } else if (view !== currentTab) {
      setPreviousTab(currentTab);
    }
    if (view === 'messages') {
      setReturnListingId(null);
      setChatReturnOrigin(null);
    }
    if (view === 'tweeting') {
      setSavedTweetingSnapshot(null);
      setTweetingRestoreSnapshot(null);
      setTweetingFocusContext(null);
    }
    if (view === 'stocks') {
      setSelectedStockForDesk(null);
      setQuickBuyStockForDesk(null);
      setPortfolioOriginTab(null);
      setSavedTweetingSnapshot(null);
      setTweetingRestoreSnapshot(null);
      setSelectedStockMarketWay('final');
      setStockMarketResetKey((k) => k + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    setCurrentTab(view);
  };

  // Call Modal State (Voice / Video Conference)
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [callType, setCallType] = useState<'voice' | 'video'>('voice');
  const [callTargetUser, setCallTargetUser] = useState<{
    uid: string;
    userId: string;
    name: string;
    avatarUrl?: string;
  } | null>(null);
  const [callIsGroup, setCallIsGroup] = useState(false);
  const [callGroupParticipants, setCallGroupParticipants] = useState<any[]>([]);

  // Conversation target for messaging
  const [activeChatConversationId, setActiveChatConversationId] = useState<string | null>(null);

  React.useEffect(() => {
    const handleOpenConv = (e: Event) => {
      const custom = e as CustomEvent<string>;
      if (custom.detail) {
        setActiveChatConversationId(custom.detail);
      }
    };
    window.addEventListener('open_direct_conversation', handleOpenConv);
    return () => window.removeEventListener('open_direct_conversation', handleOpenConv);
  }, []);

  // Sync role-based routing when logged in (preserve explicit deep links like ?listing=, ?profile=, ?stock=, ?tweet=, ?community=, ?news=)
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (
        params.get('listing') ||
        params.get('profile') ||
        params.get('user') ||
        params.get('stock') ||
        params.get('tweet') ||
        params.get('community') ||
        params.get('news')
      ) {
        return;
      }
    }
    if (authSession && currentTab === 'landing') {
      const email = authSession.email?.trim().toLowerCase();
      if (email === 'ranmaanimaker@gmail.com' || authSession.role === 'super_admin') {
        setCurrentTab('superadmin');
      } else if (email === 'awesomedbz@gmail.com' || authSession.role === 'admin') {
        setCurrentTab('admin');
      } else {
        setCurrentTab('marketplace');
      }
    }
  }, [authSession, currentTab, setCurrentTab]);

  // Handle shared deep links (?listing=..., ?profile=..., ?user=..., ?stock=..., ?tweet=..., ?community=..., ?news=...) and in-app custom events
  React.useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const sharedListingId = params.get('listing');
    const sharedProfileId = params.get('profile') || params.get('user');
    const sharedStockTicker = params.get('stock');
    const sharedTweetId = params.get('tweet');
    const sharedCommunityId = params.get('community');
    const sharedNewsId = params.get('news');

    if (sharedListingId) {
      const found =
        listings.find((l) => l.id === sharedListingId) ||
        getAllMarketplaceListings().find((l) => l.id === sharedListingId);
      if (found) {
        setSelectedListingDetail(convertAnyListingToAppListing(found));
        setListingDetailReturnTab('marketplace');
        setCurrentTab('listing_detail');
      }
    } else if (sharedProfileId) {
      setTargetProfileUserId(sharedProfileId);
      setCurrentTab('user_profile');
    } else if (sharedStockTicker) {
      const upper = sharedStockTicker.toUpperCase();
      let pool = INITIAL_STOCKS;
      try {
        const storedStocks = localStorage.getItem('final_finance_stocks');
        if (storedStocks) {
          const parsed = JSON.parse(storedStocks);
          if (Array.isArray(parsed)) pool = [...parsed, ...INITIAL_STOCKS];
        }
      } catch {}
      const foundStock = pool.find((s) => s.ticker.toUpperCase() === upper);
      if (foundStock) {
        setSelectedStockForDesk(foundStock);
        if (foundStock.marketType) setSelectedStockMarketWay(foundStock.marketType);
        setCurrentTab('stocks');
      }
    } else if (sharedTweetId) {
      setCurrentTab('tweeting');
    } else if (sharedCommunityId) {
      setCurrentTab('community');
    } else if (sharedNewsId) {
      setCurrentTab('stocks');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  React.useEffect(() => {
    const onOpenSharedListingEvent = (e: Event) => {
      const custom = e as CustomEvent<string>;
      if (custom.detail) {
        handleSelectListingById(custom.detail);
      }
    };
    const onOpenSharedProfileEvent = (e: Event) => {
      const custom = e as CustomEvent<string>;
      if (custom.detail) {
        handleSelectUser(custom.detail);
      }
    };
    const onOpenSharedStockEvent = (e: Event) => {
      const custom = e as CustomEvent<string>;
      if (custom.detail) {
        const upper = custom.detail.toUpperCase();
        let pool = INITIAL_STOCKS;
        try {
          const storedStocks = localStorage.getItem('final_finance_stocks');
          if (storedStocks) {
            const parsed = JSON.parse(storedStocks);
            if (Array.isArray(parsed)) pool = [...parsed, ...INITIAL_STOCKS];
          }
        } catch {}
        const foundStock = pool.find((s) => s.ticker.toUpperCase() === upper);
        if (foundStock) {
          handleSelectStock(foundStock);
        }
      }
    };
    const onOpenTweetingFeed = (e: Event) => {
      const custom = e as CustomEvent<SharedTweetFocusContext | undefined>;
      const detail = custom?.detail && custom.detail.tweetId ? custom.detail : null;
      setTweetingFocusContext(detail);
      if (detail) {
        skipNextTabScrollTopRef.current = true;
      }
      setSavedTweetingSnapshot(null);
      setTweetingRestoreSnapshot(null);
      setPreviousTab(currentTab);
      setCurrentTab('tweeting');
    };
    window.addEventListener('open_shared_listing', onOpenSharedListingEvent);
    window.addEventListener('open_shared_profile', onOpenSharedProfileEvent);
    window.addEventListener('open_shared_stock', onOpenSharedStockEvent);
    window.addEventListener('open_tweeting_feed', onOpenTweetingFeed);
    return () => {
      window.removeEventListener('open_shared_listing', onOpenSharedListingEvent);
      window.removeEventListener('open_shared_profile', onOpenSharedProfileEvent);
      window.removeEventListener('open_shared_stock', onOpenSharedStockEvent);
      window.removeEventListener('open_tweeting_feed', onOpenTweetingFeed);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listings, currentTab]);

  // Scroll to top of page whenever tab changes (unless restoring exact post position)
  React.useEffect(() => {
    if (skipNextTabScrollTopRef.current) {
      skipNextTabScrollTopRef.current = false;
      return;
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [currentTab]);

  // Reset one-shot portfolio/tweeting return targets only when navigating away to unrelated tabs
  React.useEffect(() => {
    if (currentTab !== 'portfolio' && currentTab !== 'stocks' && currentTab !== 'user_profile') {
      setPortfolioReturnPrimaryTab('overview');
      setPortfolioOriginTab(null);
      if (currentTab !== 'tweeting') {
        setSavedTweetingSnapshot(null);
        setTweetingRestoreSnapshot(null);
        setTweetingFocusContext(null);
      }
    }
  }, [currentTab]);

  // Migration: Link legacy loan transactions to loan records
  React.useEffect(() => {
    if (authSession?.id) {
      migrateLoanIdsToLedger(authSession.id);
    }
  }, [authSession?.id]);

  // Periodic background friend/network tweet activity + cross-tab listener so user receives notifications across all tabs
  React.useEffect(() => {
    if (!authSession) return;
    // Demo notifications paused per user request (feature code preserved)
    /*
    const timer = setInterval(() => {
      try {
        simulateNetworkTweet();
      } catch (err) {
        console.debug('Background tweet simulation error:', err);
      }
    }, 75000);
    */

    const handleStorageTweets = (e: StorageEvent) => {
      if (e.key === TWEETS_STORAGE_KEY && e.newValue) {
        try {
          const nextTweets = JSON.parse(e.newValue);
          const prevTweets = e.oldValue ? JSON.parse(e.oldValue) : [];
          if (Array.isArray(nextTweets) && nextTweets.length > 0) {
            const prevIds = new Set((Array.isArray(prevTweets) ? prevTweets : []).map((t: any) => t.id));
            const newest = nextTweets[0];
            if (newest && !prevIds.has(newest.id)) {
              notifyIfTweetFromFriendOrFollowed(newest);
            }
          }
        } catch {}
      }
    };
    window.addEventListener('storage', handleStorageTweets);

    return () => {
      // clearInterval(timer);
      window.removeEventListener('storage', handleStorageTweets);
    };
  }, [authSession]);

  // Sync session changes & route to appropriate portal only on initial sign-in / login
  const handleUpdateSession = (updated: AuthSession, forceRedirect = false) => {
    setAuthSession(updated);
    setCurrentUser((prev) => ({
      ...prev,
      name: updated.name,
      handle: `@${updated.id}`,
      avatarUrl: updated.avatarUrl || prev.avatarUrl,
      email: updated.email,
      bio: updated.bio || prev.bio,
    }));
    if (forceRedirect) {
      const email = updated.email?.trim().toLowerCase();
      if (email === 'ranmaanimaker@gmail.com' || updated.role === 'super_admin') {
        setCurrentTab('superadmin');
      } else if (email === 'awesomedbz@gmail.com' || updated.role === 'admin') {
        setCurrentTab('admin');
      } else {
        setCurrentTab('marketplace');
      }
    }
  };

  const handleSignOut = () => {
    profileNavStackRef.current = [];
    setProfileBackLabel('Back');
    clearProfileReturnAnchor();
    signOut();
    setAuthSession(null);
    setCurrentUser((prev) => ({
      ...prev,
      name: 'Guest Explorer',
      handle: '@guest_trader',
      avatarUrl: '',
      email: '',
      bio: '',
    }));
    setCurrentTab('landing');
  };

  const handleSelectDemoAccount = async (key: keyof typeof DEMO_ACCOUNTS) => {
    const res = await signInWithDemoAccount(key);
    if (res.success && res.user) {
      handleUpdateSession(res.user);
    }
  };

  // Open Direct Message from anywhere
  const handleOpenDirectMessage = async (targetUser: UserPublicProfile) => {
    if (!authSession) {
      setIsAuthModalOpen(true);
      return;
    }
    const viewerIsAdmin = isAdminAccount(authSession);
    if (
      !viewerIsAdmin &&
      (areUsersBlockedEitherWay(authSession.uid, targetUser.uid) ||
        areUsersBlockedEitherWay(authSession.id, targetUser.userId))
    ) {
      addToast({
        type: 'error',
        title: 'Chat Unavailable',
        message: 'Cannot start chat: communication is blocked between these accounts.',
      });
      return;
    }
    try {
      const conv = await getOrCreateDirectConversation(authSession, targetUser);
      if (currentTab === 'listing_detail' && selectedListingDetail) {
        setReturnListingId(selectedListingDetail.id);
        setChatReturnOrigin('listing_detail');
      } else if (currentTab === 'marketplace') {
        setReturnListingId(null);
        setChatReturnOrigin('marketplace');
      } else {
        setReturnListingId(null);
        setChatReturnOrigin(null);
      }
      setActiveChatConversationId(conv.id);
      setCurrentTab('messages');
    } catch (err: any) {
      console.error('Error starting conversation:', err);
      addToast({
        type: 'error',
        title: 'Chat Unavailable',
        message: err?.message || 'Cannot start chat between these accounts.',
      });
    }
  };

  // Trigger Voice Call (Friends Only, except Admins/Super Admins can call anyone)
  const handleOpenVoiceCall = (
    targetUser: { uid: string; userId: string; name: string; avatarUrl?: string },
    _isGroup = false,
    _groupParticipants: any[] = []
  ) => {
    if (!authSession) {
      setIsAuthModalOpen(true);
      return;
    }
    const viewerIsAdmin = isAdminAccount(authSession);
    if (
      !viewerIsAdmin &&
      (areUsersBlockedEitherWay(authSession.uid, targetUser.uid) ||
        areUsersBlockedEitherWay(authSession.id, targetUser.userId))
    ) {
      addToast({
        type: 'error',
        title: 'Call Blocked',
        message: 'Cannot start call: communication is blocked between these accounts.',
      });
      return;
    }
    const isFriendVoice =
      viewerIsAdmin ||
      areUsersFriends(authSession.uid, targetUser.uid) ||
      areUsersFriends(authSession.id, targetUser.userId) ||
      areUsersFriends(authSession.uid, targetUser.userId) ||
      areUsersFriends(authSession.id, targetUser.uid);

    if (!isFriendVoice) {
      addToast({
        type: 'error',
        title: 'Friends Only',
        message: 'Audio and video calls are only available with your friends.',
      });
      return;
    }
    setCallType('voice');
    setCallTargetUser(targetUser);
    setCallIsGroup(false);
    setCallGroupParticipants([]);
    setIsCallModalOpen(true);
  };

  // Trigger Video Call (Friends Only, except Admins/Super Admins can video call anyone)
  const handleOpenVideoCall = (
    targetUser: { uid: string; userId: string; name: string; avatarUrl?: string },
    _isGroup = false,
    _groupParticipants: any[] = []
  ) => {
    if (!authSession) {
      setIsAuthModalOpen(true);
      return;
    }
    const viewerIsAdmin = isAdminAccount(authSession);
    if (
      !viewerIsAdmin &&
      (areUsersBlockedEitherWay(authSession.uid, targetUser.uid) ||
        areUsersBlockedEitherWay(authSession.id, targetUser.userId))
    ) {
      addToast({
        type: 'error',
        title: 'Video Call Blocked',
        message: 'Cannot start video call: communication is blocked between these accounts.',
      });
      return;
    }
    const isFriendVideo =
      viewerIsAdmin ||
      areUsersFriends(authSession.uid, targetUser.uid) ||
      areUsersFriends(authSession.id, targetUser.userId) ||
      areUsersFriends(authSession.uid, targetUser.userId) ||
      areUsersFriends(authSession.id, targetUser.uid);

    if (!isFriendVideo) {
      addToast({
        type: 'error',
        title: 'Friends Only',
        message: 'Audio and video calls are only available with your friends.',
      });
      return;
    }
    setCallType('video');
    setCallTargetUser(targetUser);
    setCallIsGroup(false);
    setCallGroupParticipants([]);
    setIsCallModalOpen(true);
  };

  // Handle Search Result Selection
  const handleSelectProduct = (product: SearchableProduct) => {
    setSelectedProduct(product);
    setIsProductModalOpen(true);
  };

  const getDefaultProfileBackLabel = (tab: string): string => {
    switch (tab) {
      case 'tweeting':
        return 'Back to Tweeting';
      case 'listing_detail':
        return 'Back to Posting';
      case 'marketplace':
        return 'Back to Marketplace';
      case 'portfolio':
      case 'holdings':
        return 'Back to Portfolio';
      case 'dashboard':
        return 'Back to Dashboard';
      case 'wallets':
        return 'Back to Wallets';
      case 'messages':
        return 'Back to Messages';
      case 'social':
        return 'Back to Social';
      case 'community_search':
        return 'Back to Community Search';
      case 'search_results':
        return 'Back to Search';
      case 'qrcodes':
        return 'Back to QR Codes';
      case 'ride_share':
        return 'Back to Ride-Share';
      case 'settings':
        return 'Back to Settings';
      case 'admin':
        return 'Back to Admin';
      case 'superadmin':
        return 'Back to Superadmin';
      case 'user_profile':
        return 'Back to Profile';
      default:
        return 'Back';
    }
  };

  const handleSelectUser = (userIdOrHandleInput: string | { uid?: string; userId?: string }) => {
    const userIdOrHandle =
      typeof userIdOrHandleInput === 'string'
        ? userIdOrHandleInput
        : (userIdOrHandleInput?.userId || userIdOrHandleInput?.uid || '');
    if (!userIdOrHandle) return;

    const pendingAnchor = getProfileReturnAnchor();
    const currentScrollY = typeof window !== 'undefined' ? window.scrollY : 0;
    const anchor: ProfileReturnAnchor = pendingAnchor
      ? {
          ...pendingAnchor,
          scrollY: pendingAnchor.scrollY ?? currentScrollY,
          sourceLabel: pendingAnchor.sourceLabel || getDefaultProfileBackLabel(currentTab),
          restoreActive: false,
        }
      : {
          sourceLabel: getDefaultProfileBackLabel(currentTab),
          scrollY: currentScrollY,
          listingId: currentTab === 'listing_detail' ? selectedListingDetail?.id : undefined,
          restoreActive: false,
        };
    clearProfileReturnAnchor();

    // Avoid pushing a duplicate frame if clicking the exact same profile we're already viewing
    if (currentTab !== 'user_profile' || targetProfileUserId !== userIdOrHandle) {
      profileNavStackRef.current.push({
        tab: currentTab,
        targetProfileUserId: currentTab === 'user_profile' ? targetProfileUserId : null,
        scrollY: currentScrollY,
        listing: currentTab === 'listing_detail' ? selectedListingDetail : null,
        anchor,
      });
      setProfileBackLabel(anchor.sourceLabel || getDefaultProfileBackLabel(currentTab));
    }

    setPreviousTab(currentTab !== 'user_profile' ? currentTab : previousTab || 'marketplace');
    setTargetProfileUserId(userIdOrHandle);
    setCurrentTab('user_profile');
    if (typeof window !== 'undefined') {
      const nextUrl = new URL(window.location.href);
      nextUrl.searchParams.set('profile', userIdOrHandle);
      nextUrl.searchParams.delete('user');
      nextUrl.searchParams.delete('listing');
      nextUrl.searchParams.delete('stock');
      nextUrl.searchParams.delete('tweet');
      nextUrl.searchParams.delete('community');
      nextUrl.searchParams.delete('news');
      window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
    }
  };

  const handleSelectStock = (stock: StockItem, origin?: 'holdings' | 'derivatives' | 'tweeting') => {
    const resolvedOrigin = origin || (currentTab === 'tweeting' ? 'tweeting' : null);
    setPreviousTab(currentTab !== 'stocks' ? currentTab : previousTab || 'marketplace');
    setPortfolioOriginTab(resolvedOrigin);
    setSelectedStockForDesk(stock);
    setQuickBuyStockForDesk(null);
    if (stock.marketType) {
      setSelectedStockMarketWay(stock.marketType);
    }
    if (typeof window !== 'undefined') {
      const nextUrl = new URL(window.location.href);
      nextUrl.searchParams.set('stock', stock.ticker);
      nextUrl.searchParams.delete('profile');
      nextUrl.searchParams.delete('user');
      nextUrl.searchParams.delete('listing');
      nextUrl.searchParams.delete('tweet');
      nextUrl.searchParams.delete('community');
      nextUrl.searchParams.delete('news');
      window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
    }
    setCurrentTab('stocks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickBuyStock = (stock: StockItem) => {
    setPreviousTab(currentTab);
    setPortfolioOriginTab(null);
    setSelectedStockForDesk(stock);
    setQuickBuyStockForDesk(stock);
    if (stock.marketType) {
      setSelectedStockMarketWay(stock.marketType);
    }
    setCurrentTab('stocks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenStockMarketWay = (marketWay?: StockMarketWay | 'all') => {
    setPreviousTab(currentTab);
    setPortfolioOriginTab(null);
    setSelectedStockMarketWay(marketWay || 'all');
    setSelectedStockForDesk(null);
    setQuickBuyStockForDesk(null);
    setCurrentTab('stocks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenFullSearch = (query: string) => {
    setPreviousTab(currentTab);
    setActiveSearchQuery(query);
    setCurrentTab('search_results');
  };

  return (
    <div className="w-full">
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-amber-500/30 selection:text-amber-900">
      {/* Top Bar Header */}
      <Header
        currentUserSession={authSession}
        onOpenNewListing={() => {
          if (!authSession) {
            setIsAuthModalOpen(true);
          } else {
            setIsNewListingModalOpen(true);
          }
        }}
        onOpenProfile={() => {
          if (!authSession) {
            setIsAuthModalOpen(true);
          } else {
            handleSelectUser(authSession.id || authSession.uid);
          }
        }}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onSelectProduct={handleSelectProduct}
        onSelectUser={handleSelectUser}
        onSelectStock={handleSelectStock}
        onQuickBuyStock={handleQuickBuyStock}
        onOpenFullSearch={handleOpenFullSearch}
        onSignOut={handleSignOut}
        onOpenInstantSwap={() => setIsSwapModalOpen(true)}
        onUpdateSession={handleUpdateSession}
        onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
        onNavigateFromDropdown={handleDropdownNavigate}
      />

      {/* Main View Container */}
      <main className={`flex-1 mx-auto w-full max-w-7xl ${currentTab === 'messages' ? 'px-2 sm:px-6 py-2 sm:py-3' : 'px-3 sm:px-6 lg:px-8 py-4 sm:py-6'}`}>
        {/* 0. Public Platform Homepage / Landing View */}
        {currentTab === 'landing' && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onAuthSuccess={(user) => handleUpdateSession(user, true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => {
              if (authSession) {
                setCurrentTab('marketplace');
              } else {
                setIsAuthModalOpen(true);
              }
            }}
            currentUserSession={authSession}
          />
        )}

        {/* 1. Marketplace Page (Default Home) */}
        {currentTab === 'marketplace' && (
          <MarketplaceView 
            onOpenNewListing={() => {
              if (!authSession) {
                setIsAuthModalOpen(true);
              } else {
                setIsNewListingModalOpen(true);
              }
            }}
            onOpenBarterModal={(item) => {
              if (!authSession) {
                setIsAuthModalOpen(true);
                return;
              }
              openTradeOrAuctionModal(item);
            }}
            onSelectListing={handleSelectListing}
            onSelectProduct={handleSelectProduct}
            onSelectUser={handleSelectUser}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
          />
        )}

        {/* 2. User Dashboard */}
        {currentTab === 'dashboard' && authSession && (
          <UserDashboardView
            currentUser={authSession}
            initialActiveTab="overview"
            onOpenNewListing={() => setIsNewListingModalOpen(true)}
            onOpenInstantSwap={() => setIsSwapModalOpen(true)}
            onOpenBarterModal={(item) => {
              openTradeOrAuctionModal(item);
            }}
            onOpenDepositModal={(vault) => setSelectedVaultForDeposit(vault || null)}
            onOpenVoiceCallDesk={() => {
              handleOpenVoiceCall({
                uid: 'desk-counterparty',
                userId: 'zurich_clearing_desk',
                name: 'Zurich Clearing Desk',
              });
            }}
            onViewPlatformOverview={() => setCurrentTab('landing')}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
          />
        )}

        {/* If user navigates to dashboard without session, show landing */}
        {currentTab === 'dashboard' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onAuthSuccess={(user) => handleUpdateSession(user, true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 3. 5 Reserve Vaults */}
        {currentTab === 'vaults' && (
          <VaultsView onOpenDepositModal={(vault) => setSelectedVaultForDeposit(vault)} />
        )}

        {/* 4a. Stock Portfolio (Dedicated clean view: Equities & Stock Portfolio) */}
        {currentTab === 'portfolio' && authSession && (
          <PortfolioPage
            currentUser={authSession}
            initialPrimaryTab={portfolioReturnPrimaryTab}
            onSelectStock={handleSelectStock}
            onOpenStockMarket={handleOpenStockMarketWay}
            onNavigateBack={previousTab === 'dashboard' ? () => setCurrentTab('dashboard') : undefined}
          />
        )}
        {currentTab === 'portfolio' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 4b. Purchased Equity Holdings (Dedicated view: Purchased Stock & Personal Equity Positions) */}
        {currentTab === 'holdings' && authSession && (
          <PortfolioPage
            currentUser={authSession}
            initialPrimaryTab="holdings"
            onSelectStock={handleSelectStock}
            onOpenStockMarket={handleOpenStockMarketWay}
          />
        )}
        {currentTab === 'holdings' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 4c. Asset Inventory */}
        {(currentTab as string) === 'asset_inventory' && authSession && (
          <AssetInventoryPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('dashboard')}
            onOpenDepositModal={(vault) => setSelectedVaultForDeposit(vault || null)}
            onOpenInstantSwap={() => setIsSwapModalOpen(true)}
            onOpenBarterModal={(item) => openTradeOrAuctionModal(item)}
            onSelectStock={handleSelectStock}
          />
        )}
        {(currentTab as string) === 'asset_inventory' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 4b. My Wallets */}
        {currentTab === 'wallets' && authSession && (
          <UserDashboardView
            currentUser={authSession}
            initialActiveTab="wallets"
            onOpenNewListing={() => setIsNewListingModalOpen(true)}
            onOpenInstantSwap={() => setIsSwapModalOpen(true)}
            onOpenBarterModal={(item) => {
              openTradeOrAuctionModal(item);
            }}
            onOpenDepositModal={(vault) => setSelectedVaultForDeposit(vault || null)}
            onOpenVoiceCallDesk={() => {
              handleOpenVoiceCall({
                uid: 'desk-counterparty',
                userId: 'zurich_clearing_desk',
                name: 'Zurich Clearing Desk',
              });
            }}
            onViewPlatformOverview={() => setCurrentTab('landing')}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
          />
        )}
        {currentTab === 'wallets' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 5. Uploads & Drafts */}
        {currentTab === 'uploads' && authSession && (
          <UploadsPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('marketplace')}
            onViewListingDetail={(listing) => handleSelectListing(convertAnyListingToAppListing(listing))}
            focusRestore={uploadsFocusRestore}
            onFocusRestored={() => setUploadsFocusRestore(null)}
          />
        )}
        {currentTab === 'uploads' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* QR Codes Tab */}
        {currentTab === 'qrcodes' && authSession && (
          <QRCodesPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('dashboard')}
            onViewUserProfile={handleSelectUser}
          />
        )}
        {currentTab === 'qrcodes' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* Point of Sale Tab (Below QR Codes in Workspace) */}
        {currentTab === 'point_of_sale' && authSession && (
          <PointOfSaleView
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('dashboard')}
            onViewQRCodes={() => setCurrentTab('qrcodes')}
          />
        )}
        {currentTab === 'point_of_sale' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* Ride-Share & Delivery Hub Tab (Below Point of Sale) */}
        {currentTab === 'ride_share' && authSession && (
          <RideShareView
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('dashboard')}
            onViewUserProfile={handleSelectUser}
          />
        )}
        {currentTab === 'ride_share' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 6. Social & Community Hub */}
        {currentTab === 'social' && authSession && (
          <SocialPage
            currentUser={authSession}
            onOpenDirectMessage={handleOpenDirectMessage}
            onOpenVoiceCall={handleOpenVoiceCall}
            onOpenVideoCall={handleOpenVideoCall}
            onOpenCommunitySearch={() => setCurrentTab('community_search')}
            onViewUserProfile={handleSelectUser}
          />
        )}
        {currentTab === 'social' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 7. Community Search & Member Discovery */}
        {currentTab === 'community_search' && authSession && (
          <CommunitySearchPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('social')}
            onOpenDirectMessage={handleOpenDirectMessage}
            onViewUserProfile={handleSelectUser}
            onSelectProduct={handleSelectProduct}
          />
        )}
        {currentTab === 'community_search' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 8. Community Broadcasts & Feed */}
        {currentTab === 'community' && (
          <CommunityView />
        )}

        {/* 9. OTC Messaging & Multi-Conferences */}
        {currentTab === 'messages' && authSession && (() => {
          const effectiveChatBackDest: 'marketplace' | 'listing_detail' | null =
            chatReturnOrigin
              ? chatReturnOrigin
              : previousTab === 'marketplace'
                ? 'marketplace'
                : previousTab === 'listing_detail' || Boolean(returnListingId)
                  ? 'listing_detail'
                  : null;

          const navigateToOriginListing = () => {
            if (returnListingId && (!selectedListingDetail || selectedListingDetail.id !== returnListingId)) {
              handleSelectListingById(returnListingId);
            } else if (selectedListingDetail) {
              setCurrentTab('listing_detail');
            } else {
              setCurrentTab('marketplace');
            }
          };

          return (
            <MessagesPage
              currentUser={authSession}
              initialConversationId={activeChatConversationId}
              onOpenVoiceCall={handleOpenVoiceCall}
              onOpenVideoCall={handleOpenVideoCall}
              onViewUserProfile={handleSelectUser}
              backDestination={effectiveChatBackDest}
              onNavigateBack={() => {
                if (effectiveChatBackDest === 'marketplace') {
                  setCurrentTab('marketplace');
                } else if (effectiveChatBackDest === 'listing_detail') {
                  navigateToOriginListing();
                } else if (previousTab && previousTab !== 'messages') {
                  setCurrentTab(previousTab);
                } else {
                  setCurrentTab('marketplace');
                }
              }}
              onBackToPosting={
                effectiveChatBackDest === 'listing_detail' && (selectedListingDetail || returnListingId)
                  ? navigateToOriginListing
                  : undefined
              }
              activePostingTitle={
                selectedListingDetail?.title ||
                (returnListingId
                  ? listings.find((l) => l.id === returnListingId)?.title ||
                    getAllMarketplaceListings().find((l) => l.id === returnListingId)?.title
                  : undefined)
              }
            />
          );
        })()}
        {currentTab === 'messages' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 9b. Tweeting Feed & Sovereign Wire */}
        {currentTab === 'tweeting' && (
          <TweetingView
            currentUser={authSession}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onNavigateBack={() => setCurrentTab('messages')}
            onViewUserProfile={handleSelectUser}
            onSelectStock={(stock) => handleSelectStock(stock, 'tweeting')}
            onOpenSharedListing={handleSelectListingById}
            restoreSnapshot={tweetingRestoreSnapshot}
            onSaveSnapshot={(snapshot) => setSavedTweetingSnapshot(snapshot)}
            onSnapshotRestored={() => {
              setTweetingRestoreSnapshot(null);
              setSavedTweetingSnapshot(null);
            }}
            focusedTweetId={tweetingFocusContext?.tweetId || null}
            focusedListingContext={tweetingFocusContext}
            onBackToSharedPost={
              tweetingFocusContext
                ? () => {
                    const ctx = tweetingFocusContext;
                    setTweetingFocusContext(null);
                    if (ctx.sourceTab === 'uploads') {
                      setUploadsFocusRestore({
                        listingId: ctx.listingId,
                        filterStatus: ctx.uploadsFilterStatus as UploadsFilterStatus | undefined,
                        boughtSubSection: ctx.uploadsBoughtSubSection,
                        myAuctionsSubTab: ctx.uploadsMyAuctionsSubTab,
                        key: Date.now(),
                      });
                      skipNextTabScrollTopRef.current = true;
                      setCurrentTab('uploads');
                    } else if (ctx.sourceTab === 'user_profile') {
                      if (ctx.profileUserId) {
                        setTargetProfileUserId(ctx.profileUserId);
                      }
                      setCurrentTab('user_profile');
                    }
                  }
                : undefined
            }
          />
        )}

        {/* 10. Sovereign Multi-Asset Fundraising */}
        {currentTab === 'fundraising' && (
          <FundraisingPage
            currentUser={authSession}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {/* Subsidies, Grants & Internal Banking */}
        {currentTab === 'subsidies' && authSession && (
          <SubsidiesGrantsPage
            currentUser={authSession}
            onNavigateBack={() => setCurrentTab('marketplace')}
            onNavigateToSettings={() => setCurrentTab('settings')}
          />
        )}
        {currentTab === 'subsidies' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 11. Full-Fledged Stock Market Page (4 Coin Stock Markets) */}
        {currentTab === 'stocks' && (
          <StockMarketView
            key={`stock-market-${selectedStockMarketWay}`}
            currentUser={authSession}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onNavigateBack={() => {
              if (typeof window !== 'undefined') {
                const nextUrl = new URL(window.location.href);
                nextUrl.searchParams.delete('stock');
                window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
              }
              setSelectedStockForDesk(null);
              setQuickBuyStockForDesk(null);
              setPortfolioOriginTab(null);
              setCurrentTab((previousTab && previousTab !== 'stocks' ? previousTab : (authSession ? 'marketplace' : 'landing')) as any);
            }}
            initialSelectedTicker={selectedStockForDesk?.ticker}
            initialSelectedStock={selectedStockForDesk}
            onClearSelectedStock={() => {
              if (typeof window !== 'undefined') {
                const nextUrl = new URL(window.location.href);
                nextUrl.searchParams.delete('stock');
                window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
              }
              setSelectedStockForDesk(null);
              setQuickBuyStockForDesk(null);
            }}
            portfolioReturnLabel={
              portfolioOriginTab === 'derivatives'
                ? 'Back to Derivatives'
                : portfolioOriginTab === 'holdings'
                ? 'Back to Equity'
                : portfolioOriginTab === 'tweeting'
                ? 'Back to Tweeting'
                : undefined
            }
            onBackToPortfolioTab={
              portfolioOriginTab
                ? () => {
                    if (typeof window !== 'undefined') {
                      const nextUrl = new URL(window.location.href);
                      nextUrl.searchParams.delete('stock');
                      window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
                    }
                    if (portfolioOriginTab === 'tweeting') {
                      if (savedTweetingSnapshot) {
                        setTweetingRestoreSnapshot(savedTweetingSnapshot);
                        skipNextTabScrollTopRef.current = true;
                      }
                      setSelectedStockForDesk(null);
                      setQuickBuyStockForDesk(null);
                      setPortfolioOriginTab(null);
                      setCurrentTab('tweeting');
                      return;
                    }
                    const targetTab: PortfolioPrimaryTab =
                      portfolioOriginTab === 'derivatives' ? 'derivatives' : 'holdings';
                    setPortfolioReturnPrimaryTab(targetTab);
                    setSelectedStockForDesk(null);
                    setQuickBuyStockForDesk(null);
                    setPortfolioOriginTab(null);
                    setCurrentTab('portfolio');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                : undefined
            }
            initialQuickBuyStock={quickBuyStockForDesk}
            initialMarketWay={selectedStockMarketWay}
            marketResetKey={stockMarketResetKey}
          />
        )}

        {/* 12. Dedicated Search Results & Universal Recommendations Page */}
        {currentTab === 'search_results' && (
          <SearchResultsPage
            initialQuery={activeSearchQuery}
            currentUser={authSession}
            onNavigateBack={() => {
              setCurrentTab(previousTab as any || 'marketplace');
            }}
            onSelectProduct={handleSelectProduct}
            onSelectUser={handleSelectUser}
            onSelectStock={handleSelectStock}
            onQuickBuyStock={handleQuickBuyStock}
            onOpenDirectMessage={handleOpenDirectMessage}
          />
        )}

        {/* 12. Account & Security Settings (Profile, Security, Verification, Notifications) */}
        {currentTab === 'settings' && authSession && (
          <SettingsPage
            currentUser={authSession}
            onUpdateSession={handleUpdateSession}
            onNavigateBack={() => setCurrentTab('marketplace')}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
            onViewPublicProfile={(userId) => handleSelectUser(userId)}
          />
        )}
        {currentTab === 'settings' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 13. Public User Profile View */}
        {currentTab === 'user_profile' && (
          <UserProfileView
            userIdOrHandle={targetProfileUserId || authSession?.id || 'public'}
            currentUser={authSession || ({
              uid: 'guest',
              id: 'guest',
              name: 'Guest User',
              email: 'guest@finalfinance.io',
              role: 'user',
              provider: 'demo',
              createdAt: new Date().toISOString()
            } as AuthSession)}
            onUpdateSession={handleUpdateSession}
            onOpenDirectMessage={handleOpenDirectMessage}
            onOpenVoiceCall={(user) => handleOpenVoiceCall(user, false)}
            onOpenVideoCall={(user) => handleOpenVideoCall(user, false)}
            onViewListingDetail={(listing) => handleSelectListing(convertAnyListingToAppListing(listing))}
            onOpenSharedListing={handleSelectListingById}
            onSelectStock={handleSelectStock}
            returnListingId={returnListingId}
            onListingFocusRestored={() => setReturnListingId(null)}
            onNavigateBack={() => {
              const frame = profileNavStackRef.current.pop();
              const nextTop = profileNavStackRef.current[profileNavStackRef.current.length - 1];
              setProfileBackLabel(
                nextTop?.anchor?.sourceLabel ||
                  (nextTop ? getDefaultProfileBackLabel(nextTop.tab) : 'Back')
              );

              if (frame && frame.tab === 'user_profile' && frame.targetProfileUserId) {
                setTargetProfileUserId(frame.targetProfileUserId);
                if (typeof window !== 'undefined') {
                  const nextUrl = new URL(window.location.href);
                  nextUrl.searchParams.set('profile', frame.targetProfileUserId);
                  nextUrl.searchParams.delete('user');
                  window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
                  setTimeout(() => {
                    window.scrollTo({ top: frame.scrollY || 0, behavior: 'instant' });
                  }, 60);
                }
                return;
              }

              if (typeof window !== 'undefined') {
                const nextUrl = new URL(window.location.href);
                nextUrl.searchParams.delete('profile');
                nextUrl.searchParams.delete('user');
                if (frame?.tab === 'listing_detail' && frame.listing?.id) {
                  nextUrl.searchParams.set('listing', frame.listing.id);
                }
                window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
              }

              const targetBackTab =
                frame?.tab && frame.tab !== 'user_profile'
                  ? frame.tab
                  : previousTab && previousTab !== 'user_profile'
                    ? previousTab
                    : 'marketplace';

              if (frame?.tab === 'listing_detail' && frame.listing) {
                setSelectedListingDetail(frame.listing);
              }

              if (frame?.anchor) {
                setPendingProfileReturnAnchor({
                  ...frame.anchor,
                  restoreActive: true,
                });
              }

              if (targetBackTab === 'tweeting' && savedTweetingSnapshot) {
                setTweetingRestoreSnapshot(savedTweetingSnapshot);
                skipNextTabScrollTopRef.current = true;
              } else if (frame) {
                skipNextTabScrollTopRef.current = true;
              }

              setCurrentTab(targetBackTab as any);

              if (frame?.anchor) {
                setTimeout(() => {
                  clearProfileReturnAnchor();
                }, 350);
              }

              if (frame && targetBackTab !== 'tweeting') {
                const hasSpecificCardFocus = Boolean(
                  frame.anchor?.finalCoinId && !frame.anchor?.openFinalCoinModal
                );
                if (!hasSpecificCardFocus && typeof window !== 'undefined') {
                  setTimeout(() => {
                    window.scrollTo({ top: frame.scrollY || 0, behavior: 'instant' });
                  }, 80);
                }
              }
            }}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
            backLabel={
              profileBackLabel !== 'Back'
                ? profileBackLabel
                : previousTab === 'tweeting'
                  ? 'Back to Tweeting'
                  : previousTab === 'listing_detail'
                    ? 'Back to Posting'
                    : previousTab === 'marketplace'
                      ? 'Back to Marketplace'
                      : 'Back'
            }
          />
        )}

        {/* 13b. Dedicated Marketplace Good / Service Detail Page */}
        {currentTab === 'listing_detail' && selectedListingDetail && (
          <ListingDetailPage
            listing={selectedListingDetail}
            backLabel={listingDetailBackLabel}
            onNavigateBack={() => {
              if (typeof window !== 'undefined') {
                const nextUrl = new URL(window.location.href);
                nextUrl.searchParams.delete('listing');
                window.history.replaceState({}, '', `${nextUrl.pathname}${nextUrl.search}`);
              }
              if (returnProfileUserId) {
                setTargetProfileUserId(returnProfileUserId);
              }
              setCurrentTab((listingDetailReturnTab as any) || 'marketplace');
            }}
            onOpenBarterModal={(item) => {
              if (!authSession) {
                setIsAuthModalOpen(true);
                return;
              }
              openTradeOrAuctionModal(item);
            }}
            onSelectUser={handleSelectUser}
          />
        )}

        {/* 14. Admin Portal */}
        {currentTab === 'admin' && authSession && (
          <AdminPage
            currentUser={authSession}
            onNavigateToVaults={() => setCurrentTab('vaults')}
            onNavigateToMarketplace={() => setCurrentTab('marketplace')}
            onNavigateToSuperadmin={() => setCurrentTab('superadmin')}
            onViewProfile={handleSelectUser}
          />
        )}
        {currentTab === 'admin' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}

        {/* 15. Superadmin Master Console */}
        {currentTab === 'superadmin' && authSession && (
          <SuperAdminPage
            currentUser={authSession}
            onNavigateToAdmin={() => setCurrentTab('admin')}
            onNavigateToVaults={() => setCurrentTab('vaults')}
            onNavigateToMarketplace={() => setCurrentTab('marketplace')}
          />
        )}
        {currentTab === 'superadmin' && !authSession && (
          <LandingHomePage
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onSelectDemoAccount={handleSelectDemoAccount}
            onEnterApp={() => setIsAuthModalOpen(true)}
            currentUserSession={null}
          />
        )}
      </main>

      {/* ================= MODALS & OVERLAYS ================= */}

      {/* Verification & $2/month Subscription Modal (2 Forms of ID) */}
      <VerificationModal
        isOpen={isVerificationModalOpen}
        currentUser={authSession}
        onClose={() => setIsVerificationModalOpen(false)}
        onVerificationSuccess={handleUpdateSession}
      />

      {/* Auth Modal (Sign In / Register / Google / Demo Switcher) */}
      <AuthModal
        initialView="signin"
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={(user) => handleUpdateSession(user, true)}
      />

      {/* Voice & Video Conference Modal */}
      <CallModal
        isOpen={
          isCallModalOpen &&
          Boolean(
            authSession &&
              callTargetUser &&
              (isAdminAccount(authSession) ||
                (!areUsersBlockedEitherWay(authSession.uid, callTargetUser.uid) &&
                  !areUsersBlockedEitherWay(authSession.id, callTargetUser.userId) &&
                  (areUsersFriends(authSession.uid, callTargetUser.uid) ||
                    areUsersFriends(authSession.id, callTargetUser.userId))))
          )
        }
        callType={callType}
        currentUser={authSession}
        remoteUser={callTargetUser as any}
        targetUser={callTargetUser as any}
        isGroup={callIsGroup}
        isGroupCall={callIsGroup}
        groupName={callTargetUser?.name || 'Multi-Conference Group Room'}
        groupParticipants={callGroupParticipants}
        onClose={() => {
          setIsCallModalOpen(false);
          setCallTargetUser(null);
          setCallGroupParticipants([]);
        }}
      />

      {/* Upload Goods/Services & Barter Draft Modal */}
      <CreateListingDraftModal
        isOpen={isNewListingModalOpen}
        currentUser={authSession}
        onClose={() => setIsNewListingModalOpen(false)}
        onSaved={(saved, status) => {
          if (status === 'uploaded') {
            const converted = convertAnyListingToAppListing(saved);
            setListings((prev) => {
              const exists = prev.some((l) => l.id === converted.id);
              return exists
                ? prev.map((l) => (l.id === converted.id ? { ...l, ...converted } : l))
                : [converted, ...prev];
            });
          }
          setIsNewListingModalOpen(false);
        }}
      />

      {/* Product Detail & Allocation Modal */}
      <ProductDetailModal
        product={selectedProduct}
        currentUser={authSession}
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onSelectAction={() => setIsProductModalOpen(false)}
      />

      {/* Vault Deposit Modal */}
      <DepositModal
        vault={selectedVaultForDeposit}
        onClose={() => setSelectedVaultForDeposit(null)}
      />

      {/* Barter Proposal Modal */}
      <BarterProposalModal
        isOpen={isBarterModalOpen}
        currentUser={authSession}
        targetListing={barterTargetListing}
        onClose={() => {
          setIsBarterModalOpen(false);
          setBarterTargetListing(null);
        }}
      />

      {/* Auction Bid & Seller Settlement Modal */}
      <AuctionBidModal
        isOpen={isAuctionModalOpen}
        currentUser={authSession}
        targetListing={auctionTargetListing}
        onClose={() => {
          setIsAuctionModalOpen(false);
          setAuctionTargetListing(null);
        }}
      />

      {/* Instant Multi-Vault Swapper Modal */}
      <InstantSwapModal
        isOpen={isSwapModalOpen}
        currentUser={authSession}
        onClose={() => setIsSwapModalOpen(false)}
      />

      {/* Offline Connectivity Banner */}
      <OfflineIndicator />

      {/* Toast Notification Container */}
      <ToastContainer />
    </div>
  </div>
);
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
