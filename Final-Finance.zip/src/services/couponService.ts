import {
  CouponCategory,
  CouponChannel,
  CouponDiscountType,
  CouponEvaluationResult,
  CouponIssuerRole,
  PendingCheckoutCoupon,
  PlatformCoupon,
  SavedCouponRecord,
} from '../types/coupon';
import { AuthSession } from '../types/auth';
import { getUserVerificationTier, isAdminOrSuperAdminUser } from '../utils/verificationTiers';

export const COUPONS_STORAGE_KEY = 'final_finance_coupons_v1';
export const SAVED_COUPONS_KEY_PREFIX = 'final_finance_saved_coupons_';
export const PENDING_COUPON_KEY = 'final_finance_pending_checkout_coupon';
export const COUPONS_UPDATED_EVENT = 'final_finance_coupons_updated';

export const COUPONS_MIGRATED_V2_KEY = 'final_finance_coupons_v2_migrated';
export const COUPONS_MIGRATED_V3_KEY = 'final_finance_coupons_v3_cleaned';

const REMOVED_MOCK_COUPON_IDS = new Set([
  'cpn-rest-neotokyo-20',
  'cpn-retail-zurich-10',
  'cpn-retail-tokyo-35',
  'cpn-rest-ranma-15',
]);

const SEEDED_COUPONS: PlatformCoupon[] = [
  {
    id: 'cpn-ride-vance-25',
    code: 'RIDE25',
    title: '25% Off Comfort EV Rides with Elena Vance',
    description: 'Save 25% on any online ride booking or in-person fare settlement with Elena Vance (Polestar 2 Long Range).',
    category: 'ride_share',
    issuerRole: 'driver',
    issuerId: 'drv-ev-1',
    issuerHandle: '@elena_vance',
    issuerName: 'Elena Vance',
    merchantName: 'Elena Vance · Comfort EV Fleet',
    vehicleType: 'Car · Comfort EV',
    discountType: 'percentage',
    discountValue: 25,
    currency: 'ANY',
    minOrderAmount: 8,
    maxDiscountAmount: 40,
    validChannels: 'both',
    expiresAt: '2027-12-31',
    maxRedemptions: 600,
    redemptionCount: 31,
    active: true,
    createdAt: '2026-03-06T08:00:00Z',
  },
  {
    id: 'cpn-ride-lukas-15',
    code: 'LUKAS15',
    title: '15% Off Economy EV Rides with Lukas Meyer',
    description: 'Save 15% on city trips and airport transfers with Lukas Meyer (VW ID.4 Pro Electric).',
    category: 'ride_share',
    issuerRole: 'driver',
    issuerId: 'drv-econ-1',
    issuerHandle: '@lukas_meyer',
    issuerName: 'Lukas Meyer',
    merchantName: 'Lukas Meyer · Economy EV',
    vehicleType: 'Car · Economy',
    discountType: 'percentage',
    discountValue: 15,
    currency: 'ANY',
    minOrderAmount: 8,
    maxDiscountAmount: 30,
    validChannels: 'both',
    expiresAt: '2027-12-31',
    maxRedemptions: 450,
    redemptionCount: 11,
    active: true,
    createdAt: '2026-03-06T12:00:00Z',
  },
  {
    id: 'cpn-ride-lux-20',
    code: 'LUX20',
    title: '20 AFNL Off Luxury Limousine (Marc-Antoine Weber)',
    description: '20 Final Coins off sovereign Maybach limousine bookings and in-person private chauffeur hails.',
    category: 'ride_share',
    issuerRole: 'driver',
    issuerId: 'drv-lux-1',
    issuerHandle: '@marc_antoine_weber',
    issuerName: 'Marc-Antoine Weber',
    merchantName: 'Marc-Antoine Weber · Luxury Limousine',
    vehicleType: 'Car · Luxury Limousine',
    discountType: 'fixed',
    discountValue: 20,
    currency: 'AFNL',
    minOrderAmount: 20,
    validChannels: 'both',
    expiresAt: '2027-12-31',
    maxRedemptions: 250,
    redemptionCount: 7,
    active: true,
    createdAt: '2026-03-06T15:00:00Z',
  },
  {
    id: 'cpn-ride-rick-5',
    code: 'RICK5',
    title: '5 AFNL Off Auto Rickshaw with Aarav Patel',
    description: 'Flat 5 Final Coins off Bajaj RE Electric Auto Rickshaw rides online or street hail.',
    category: 'ride_share',
    issuerRole: 'driver',
    issuerId: 'drv-rick-1',
    issuerHandle: '@aarav_patel',
    issuerName: 'Aarav Patel',
    merchantName: 'Aarav Patel · Auto Rickshaw',
    vehicleType: 'Auto Rickshaw',
    discountType: 'fixed',
    discountValue: 5,
    currency: 'AFNL',
    minOrderAmount: 6,
    validChannels: 'both',
    expiresAt: '2027-12-31',
    maxRedemptions: 300,
    redemptionCount: 9,
    active: true,
    createdAt: '2026-03-07T09:00:00Z',
  },
  {
    id: 'cpn-ride-moto-5',
    code: 'MOTO5',
    title: '5 Final Coins Off Moto Express with Matteo Rossi',
    description: 'Flat 5 Final Coins off express moto trips or in-person street hails settled with Final Wallet.',
    category: 'ride_share',
    issuerRole: 'driver',
    issuerId: 'drv-moto-1',
    issuerHandle: '@matteo_rossi',
    issuerName: 'Matteo Rossi',
    merchantName: 'Matteo Rossi · Moto Express',
    vehicleType: 'Motor Bike · Moto Express',
    discountType: 'fixed',
    discountValue: 5,
    currency: 'AFNL',
    minOrderAmount: 8,
    validChannels: 'both',
    expiresAt: '2027-12-31',
    maxRedemptions: 350,
    redemptionCount: 14,
    active: true,
    createdAt: '2026-03-07T11:00:00Z',
  },
];

function emitCouponsUpdated() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(COUPONS_UPDATED_EVENT));
  }
}

export function getAllPlatformCoupons(): PlatformCoupon[] {
  if (typeof window === 'undefined') return SEEDED_COUPONS;
  try {
    const raw = localStorage.getItem(COUPONS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(COUPONS_STORAGE_KEY, JSON.stringify(SEEDED_COUPONS));
      localStorage.setItem(COUPONS_MIGRATED_V2_KEY, '1');
      localStorage.setItem(COUPONS_MIGRATED_V3_KEY, '1');
      return SEEDED_COUPONS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      localStorage.setItem(COUPONS_STORAGE_KEY, JSON.stringify(SEEDED_COUPONS));
      localStorage.setItem(COUPONS_MIGRATED_V2_KEY, '1');
      localStorage.setItem(COUPONS_MIGRATED_V3_KEY, '1');
      return SEEDED_COUPONS;
    }
    if (!localStorage.getItem(COUPONS_MIGRATED_V3_KEY)) {
      const cleaned = (parsed as PlatformCoupon[]).filter((c) => !REMOVED_MOCK_COUPON_IDS.has(c.id));
      localStorage.setItem(COUPONS_STORAGE_KEY, JSON.stringify(cleaned));
      localStorage.setItem(COUPONS_MIGRATED_V2_KEY, '1');
      localStorage.setItem(COUPONS_MIGRATED_V3_KEY, '1');
      return cleaned;
    }
    return parsed;
  } catch {
    return SEEDED_COUPONS;
  }
}

export function saveAllPlatformCoupons(coupons: PlatformCoupon[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(COUPONS_STORAGE_KEY, JSON.stringify(coupons));
  } catch {
    // ignore storage quota errors
  }
  emitCouponsUpdated();
}

export function searchPlatformCoupons(params: {
  query?: string;
  category?: CouponCategory | 'all';
  channel?: CouponChannel | 'all';
  includeInactive?: boolean;
}): PlatformCoupon[] {
  const all = getAllPlatformCoupons();
  const q = (params.query || '').trim().toLowerCase();
  const cat = params.category || 'all';
  const ch = params.channel || 'all';

  return all.filter((c) => {
    if (!params.includeInactive && !c.active) return false;
    if (cat !== 'all' && c.category !== cat) return false;
    if (ch !== 'all') {
      if (ch === 'both' && c.validChannels !== 'both') return false;
      if (ch === 'online' && c.validChannels !== 'online' && c.validChannels !== 'both') return false;
      if (ch === 'in_person' && c.validChannels !== 'in_person' && c.validChannels !== 'both') return false;
    }
    if (!q) return true;
    return (
      c.code.toLowerCase().includes(q) ||
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.merchantName.toLowerCase().includes(q) ||
      c.issuerName.toLowerCase().includes(q) ||
      c.issuerHandle.toLowerCase().includes(q) ||
      (c.vehicleType && c.vehicleType.toLowerCase().includes(q))
    );
  });
}

export function getSavedCouponsForUser(userId: string): SavedCouponRecord[] {
  if (typeof window === 'undefined') return [];
  const key = `${SAVED_COUPONS_KEY_PREFIX}${userId || 'guest'}`;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeSavedCouponsForUser(userId: string, records: SavedCouponRecord[]): void {
  if (typeof window === 'undefined') return;
  const key = `${SAVED_COUPONS_KEY_PREFIX}${userId || 'guest'}`;
  try {
    localStorage.setItem(key, JSON.stringify(records));
  } catch {
    // ignore storage errors
  }
  emitCouponsUpdated();
}

export function isCouponSavedByUser(userId: string, couponId: string): boolean {
  return getSavedCouponsForUser(userId).some(
    (r) => r.couponId === couponId && r.status === 'saved'
  );
}

export function isCouponAlreadyClaimedOrRedeemedByUser(
  userId: string,
  couponId: string
): { saved: boolean; redeemed: boolean } {
  const records = getSavedCouponsForUser(userId).filter((r) => r.couponId === couponId);
  return {
    saved: records.some((r) => r.status === 'saved'),
    redeemed: records.some((r) => r.status === 'redeemed'),
  };
}

export function saveCouponForUser(userId: string, couponId: string): { success: boolean; message: string } {
  const existing = getSavedCouponsForUser(userId);
  const alreadySaved = existing.find((r) => r.couponId === couponId && r.status === 'saved');
  if (alreadySaved) {
    return { success: true, message: 'You already saved this coupon (limit 1 copy per coupon).' };
  }
  const alreadyRedeemed = existing.find((r) => r.couponId === couponId && r.status === 'redeemed');
  if (alreadyRedeemed) {
    return {
      success: false,
      message: 'You already redeemed this coupon. Each user can claim 1 copy per coupon.',
    };
  }
  const coupon = getAllPlatformCoupons().find((c) => c.id === couponId);
  if (!coupon) {
    return { success: false, message: 'Coupon not found.' };
  }
  const newRecord: SavedCouponRecord = {
    id: `saved-cpn-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    couponId,
    userId: userId || 'guest',
    savedAt: new Date().toISOString(),
    status: 'saved',
  };
  writeSavedCouponsForUser(userId, [newRecord, ...existing]);
  return { success: true, message: `Saved coupon ${coupon.code} to your wallet!` };
}

export function unsaveCouponForUser(userId: string, savedIdOrCouponId: string): void {
  const existing = getSavedCouponsForUser(userId);
  const next = existing.filter(
    (r) => !(r.status === 'saved' && (r.id === savedIdOrCouponId || r.couponId === savedIdOrCouponId))
  );
  writeSavedCouponsForUser(userId, next);
}

export function issuePlatformCoupon(input: {
  code: string;
  title: string;
  description: string;
  category: CouponCategory;
  issuerRole: CouponIssuerRole;
  issuerId: string;
  issuerHandle: string;
  issuerName: string;
  merchantLocationId?: string;
  merchantName: string;
  vehicleType?: string;
  discountType: CouponDiscountType;
  discountValue: number;
  currency: string;
  minOrderAmount: number;
  maxDiscountAmount?: number;
  validChannels: CouponChannel;
  expiresAt: string;
  maxRedemptions?: number;
}): { success: boolean; coupon?: PlatformCoupon; error?: string } {
  const normalizedCode = input.code.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
  if (!normalizedCode || normalizedCode.length < 3) {
    return { success: false, error: 'Coupon code must be at least 3 alphanumeric characters.' };
  }
  if (!input.title.trim()) {
    return { success: false, error: 'Please provide a coupon title.' };
  }
  if (isNaN(input.discountValue) || input.discountValue <= 0) {
    return { success: false, error: 'Discount value must be greater than 0.' };
  }
  if (input.discountType === 'percentage' && input.discountValue > 100) {
    return { success: false, error: 'Percentage discount cannot exceed 100%.' };
  }

  const all = getAllPlatformCoupons();
  if (all.some((c) => c.code.toUpperCase() === normalizedCode)) {
    return { success: false, error: `Coupon code "${normalizedCode}" already exists. Choose a unique code.` };
  }

  const created: PlatformCoupon = {
    id: `cpn-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    code: normalizedCode,
    title: input.title.trim(),
    description:
      input.description.trim() ||
      `Issued by ${input.merchantName} for ${
        input.validChannels === 'both'
          ? 'online and in-person'
          : input.validChannels === 'online'
            ? 'online'
            : 'in-person'
      } transactions.`,
    category: input.category,
    issuerRole: input.issuerRole,
    issuerId: input.issuerId,
    issuerHandle: input.issuerHandle.startsWith('@') ? input.issuerHandle : `@${input.issuerHandle}`,
    issuerName: input.issuerName,
    merchantLocationId: input.merchantLocationId,
    merchantName: input.merchantName.trim(),
    vehicleType: input.vehicleType,
    discountType: input.discountType,
    discountValue: Number(input.discountValue),
    currency: input.currency || 'ANY',
    minOrderAmount: Math.max(0, Number(input.minOrderAmount) || 0),
    maxDiscountAmount:
      input.maxDiscountAmount && input.maxDiscountAmount > 0 ? Number(input.maxDiscountAmount) : undefined,
    validChannels: input.validChannels,
    expiresAt: input.expiresAt || '2027-12-31',
    maxRedemptions:
      input.maxRedemptions && input.maxRedemptions > 0 ? Number(input.maxRedemptions) : undefined,
    redemptionCount: 0,
    active: true,
    createdAt: new Date().toISOString(),
  };

  saveAllPlatformCoupons([created, ...all]);
  return { success: true, coupon: created };
}

export function toggleCouponActiveStatus(couponId: string, issuerId: string): void {
  const all = getAllPlatformCoupons();
  const updated = all.map((c) => {
    if (c.id === couponId && (c.issuerId === issuerId || issuerId === 'admin' || issuerId === 'super_admin')) {
      return { ...c, active: !c.active };
    }
    return c;
  });
  saveAllPlatformCoupons(updated);
}

export function deleteIssuedCoupon(couponId: string, issuerId: string): void {
  const all = getAllPlatformCoupons();
  const updated = all.filter(
    (c) => !(c.id === couponId && (c.issuerId === issuerId || issuerId === 'admin' || issuerId === 'super_admin'))
  );
  saveAllPlatformCoupons(updated);
}

export function findCouponByCode(code: string): PlatformCoupon | undefined {
  const clean = code.trim().toUpperCase();
  if (!clean) return undefined;
  return getAllPlatformCoupons().find((c) => c.code.toUpperCase() === clean);
}

function normalizeMatchStr(val?: string): string {
  return (val || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function toCleanHandle(val?: string): string {
  return (val || '')
    .trim()
    .replace(/^@/, '')
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, '_');
}

export function doesCouponMatchMerchant(
  coupon: PlatformCoupon,
  ctx: { merchantLocationId?: string; merchantName?: string }
): boolean {
  if (coupon.merchantLocationId === 'any') return true;
  if (!ctx.merchantLocationId && !ctx.merchantName) return true;

  if (coupon.merchantLocationId && ctx.merchantLocationId) {
    if (coupon.merchantLocationId === ctx.merchantLocationId) return true;
    // Also check exact normalized merchantName fallback just in case IDs differ for renamed clones
    if (
      ctx.merchantName &&
      normalizeMatchStr(coupon.merchantName) &&
      normalizeMatchStr(coupon.merchantName) === normalizeMatchStr(ctx.merchantName)
    ) {
      return true;
    }
    return false;
  }

  // Coupon has no fixed merchantLocationId (e.g., custom store/restaurant name entered when issuing)
  const cName = normalizeMatchStr(coupon.merchantName);
  const targetName = normalizeMatchStr(ctx.merchantName);
  if (!cName || cName === 'all restaurants' || cName === 'all retail stores' || cName === 'all stores') {
    return true;
  }
  if (!targetName) return true;
  return cName === targetName || targetName.includes(cName) || cName.includes(targetName);
}

export function doesCouponMatchDriver(
  coupon: PlatformCoupon,
  ctx: { driverId?: string; driverName?: string; driverHandle?: string }
): boolean {
  if (coupon.merchantLocationId === 'any') return true;
  if (!ctx.driverId && !ctx.driverName && !ctx.driverHandle) return true;

  const targetId = (ctx.driverId || '').trim().toLowerCase();
  const cIssuerId = (coupon.issuerId || '').trim().toLowerCase();
  if (targetId && cIssuerId) {
    if (cIssuerId === targetId || targetId.startsWith(`${cIssuerId}:`)) {
      return true;
    }
  }

  const targetHandle = toCleanHandle(ctx.driverHandle || ctx.driverName);
  const cHandle = toCleanHandle(coupon.issuerHandle || coupon.issuerId);
  if (targetHandle && cHandle && targetHandle === cHandle) {
    return true;
  }

  const targetName = normalizeMatchStr(ctx.driverName);
  const cName = normalizeMatchStr(coupon.issuerName);
  if (targetName && cName && targetName === cName) {
    return true;
  }

  return false;
}

export function evaluateCouponForOrder(
  coupon: PlatformCoupon,
  ctx: {
    category: CouponCategory;
    channel: 'online' | 'in_person';
    subtotal: number;
    merchantLocationId?: string;
    merchantName?: string;
    driverId?: string;
    driverName?: string;
    driverHandle?: string;
  }
): CouponEvaluationResult {
  if (!coupon.active) {
    return { valid: false, reason: `Coupon ${coupon.code} is currently paused.`, discountAmount: 0 };
  }
  if (coupon.category !== ctx.category) {
    const label =
      coupon.category === 'restaurant'
        ? 'Restaurant'
        : coupon.category === 'retail'
          ? 'Retail Store'
          : 'Ride-Share';
    return {
      valid: false,
      reason: `Coupon ${coupon.code} is only valid for ${label} transactions.`,
      discountAmount: 0,
    };
  }
  if (coupon.validChannels !== 'both' && coupon.validChannels !== ctx.channel) {
    return {
      valid: false,
      reason: `Coupon ${coupon.code} is only valid for ${
        coupon.validChannels === 'online' ? 'online' : 'in-person'
      } transactions.`,
      discountAmount: 0,
    };
  }
  if (coupon.expiresAt) {
    const todayIso = new Date().toISOString().slice(0, 10);
    if (coupon.expiresAt < todayIso) {
      return { valid: false, reason: `Coupon ${coupon.code} expired on ${coupon.expiresAt}.`, discountAmount: 0 };
    }
  }
  if (coupon.maxRedemptions && coupon.redemptionCount >= coupon.maxRedemptions) {
    return { valid: false, reason: `Coupon ${coupon.code} has reached its redemption limit.`, discountAmount: 0 };
  }
  if ((ctx.category === 'restaurant' || ctx.category === 'retail') && (ctx.merchantLocationId || ctx.merchantName)) {
    if (!doesCouponMatchMerchant(coupon, ctx)) {
      return {
        valid: false,
        reason: `Coupon ${coupon.code} is exclusively for ${coupon.merchantName}.`,
        discountAmount: 0,
      };
    }
  }
  if (
    ctx.category === 'ride_share' &&
    coupon.issuerRole === 'driver' &&
    (ctx.driverId || ctx.driverName || ctx.driverHandle)
  ) {
    if (!doesCouponMatchDriver(coupon, ctx)) {
      return {
        valid: false,
        reason: `Coupon ${coupon.code} belongs to driver ${coupon.issuerName}.`,
        discountAmount: 0,
      };
    }
  }
  if (ctx.subtotal < coupon.minOrderAmount) {
    return {
      valid: false,
      reason: `Minimum order of ${coupon.minOrderAmount} Final Coins required for ${coupon.code}.`,
      discountAmount: 0,
    };
  }

  let discount =
    coupon.discountType === 'percentage'
      ? (ctx.subtotal * coupon.discountValue) / 100
      : coupon.discountValue;

  if (coupon.maxDiscountAmount && coupon.maxDiscountAmount > 0) {
    discount = Math.min(discount, coupon.maxDiscountAmount);
  }
  discount = Math.min(ctx.subtotal, Math.max(0, Math.round(discount * 100) / 100));

  return { valid: true, discountAmount: discount };
}

export function getApplicableSavedCoupons(
  userId: string,
  ctx: {
    category: CouponCategory;
    channel: 'online' | 'in_person';
    subtotal: number;
    merchantLocationId?: string;
    merchantName?: string;
    driverId?: string;
    driverName?: string;
    driverHandle?: string;
  }
): Array<{
  saved: SavedCouponRecord;
  coupon: PlatformCoupon;
  evaluation: CouponEvaluationResult;
  isMerchantOrDriverSpecific: boolean;
}> {
  const saved = getSavedCouponsForUser(userId).filter((s) => s.status === 'saved');
  const allCoupons = getAllPlatformCoupons();
  const couponMap = new Map(allCoupons.map((c) => [c.id, c]));

  const results: Array<{
    saved: SavedCouponRecord;
    coupon: PlatformCoupon;
    evaluation: CouponEvaluationResult;
    isMerchantOrDriverSpecific: boolean;
  }> = [];

  saved.forEach((s) => {
    const c = couponMap.get(s.couponId);
    if (!c) return;
    if (c.category !== ctx.category) return;
    if (c.validChannels !== 'both' && c.validChannels !== ctx.channel) return;

    // Filter out coupons belonging strictly to OTHER stores/restaurants or OTHER drivers
    let isSpecific = false;
    if (ctx.category === 'restaurant' || ctx.category === 'retail') {
      if (ctx.merchantLocationId || ctx.merchantName) {
        if (!doesCouponMatchMerchant(c, ctx)) return;
        isSpecific = c.merchantLocationId !== 'any';
      }
    } else if (ctx.category === 'ride_share') {
      if (ctx.driverId || ctx.driverName || ctx.driverHandle) {
        const matchesDriver = doesCouponMatchDriver(c, ctx);
        if (c.issuerRole === 'driver' && !matchesDriver) return;
        isSpecific = matchesDriver;
      }
    }

    const evaluation = evaluateCouponForOrder(c, ctx);
    results.push({ saved: s, coupon: c, evaluation, isMerchantOrDriverSpecific: isSpecific });
  });
  return results;
}

export interface RelevantCheckoutCouponEntry {
  coupon: PlatformCoupon;
  evaluation: CouponEvaluationResult;
  isSaved: boolean;
  isMerchantOrDriverSpecific: boolean;
}

export function searchRelevantCouponsForCheckout(
  userId: string,
  ctx: {
    category: CouponCategory;
    channel: 'online' | 'in_person';
    subtotal: number;
    query?: string;
    merchantLocationId?: string;
    merchantName?: string;
    driverId?: string;
    driverName?: string;
    driverHandle?: string;
  }
): RelevantCheckoutCouponEntry[] {
  const allCoupons = getAllPlatformCoupons();
  const savedRecords = getSavedCouponsForUser(userId);
  const savedIds = new Set(savedRecords.filter((r) => r.status === 'saved').map((r) => r.couponId));
  const redeemedIds = new Set(savedRecords.filter((r) => r.status === 'redeemed').map((r) => r.couponId));
  const todayIso = new Date().toISOString().slice(0, 10);
  const q = (ctx.query || '').trim().toLowerCase();

  const entries: RelevantCheckoutCouponEntry[] = [];

  allCoupons.forEach((c) => {
    if (!c.active) return;
    if (c.category !== ctx.category) return;
    if (c.validChannels !== 'both' && c.validChannels !== ctx.channel) return;
    if (c.expiresAt && c.expiresAt < todayIso) return;
    if (c.maxRedemptions && c.redemptionCount >= c.maxRedemptions) return;
    // Limit 1 copy per coupon per user: skip already-redeemed coupons
    if (redeemedIds.has(c.id)) return;

    let isSpecific = false;
    if (ctx.category === 'restaurant' || ctx.category === 'retail') {
      if (ctx.merchantLocationId || ctx.merchantName) {
        if (!doesCouponMatchMerchant(c, ctx)) return;
        isSpecific = c.merchantLocationId !== 'any';
      }
    } else if (ctx.category === 'ride_share') {
      if (ctx.driverId || ctx.driverName || ctx.driverHandle) {
        const matchesDriver = doesCouponMatchDriver(c, ctx);
        if (c.issuerRole === 'driver' && !matchesDriver) return;
        isSpecific = matchesDriver;
      }
    }

    if (q) {
      const discountText =
        c.discountType === 'percentage'
          ? `${c.discountValue}% off`
          : `${c.discountValue} ${c.currency} off`;
      const haystack = [
        c.code,
        c.title,
        c.description,
        c.merchantName,
        c.issuerName,
        c.issuerHandle,
        c.vehicleType || '',
        discountText,
      ]
        .join(' ')
        .toLowerCase();
      if (!haystack.includes(q)) return;
    }

    const evaluation = evaluateCouponForOrder(c, ctx);
    entries.push({
      coupon: c,
      evaluation,
      isSaved: savedIds.has(c.id),
      isMerchantOrDriverSpecific: isSpecific,
    });
  });

  entries.sort((a, b) => {
    if (a.isSaved !== b.isSaved) return a.isSaved ? -1 : 1;
    if (a.evaluation.valid !== b.evaluation.valid) return a.evaluation.valid ? -1 : 1;
    if (b.evaluation.discountAmount !== a.evaluation.discountAmount) {
      return b.evaluation.discountAmount - a.evaluation.discountAmount;
    }
    return b.coupon.discountValue - a.coupon.discountValue;
  });

  return entries;
}

export function redeemCouponForUser(
  userId: string,
  couponId: string,
  details: {
    channel: 'online' | 'in_person';
    orderRef: string;
    discountApplied: number;
    currency: string;
  }
): void {
  const existingSaved = getSavedCouponsForUser(userId);
  const targetSaved = existingSaved.find((r) => r.couponId === couponId && r.status === 'saved');
  const nowIso = new Date().toISOString();

  if (targetSaved) {
    const updatedSaved = existingSaved.map((r) =>
      r.id === targetSaved.id
        ? {
            ...r,
            status: 'redeemed' as const,
            redeemedAt: nowIso,
            redeemedChannel: details.channel,
            redeemedOrderRef: details.orderRef,
            discountApplied: details.discountApplied,
            redemptionCurrency: details.currency,
          }
        : r
    );
    writeSavedCouponsForUser(userId, updatedSaved);
  } else {
    const directRedemption: SavedCouponRecord = {
      id: `redeemed-cpn-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      couponId,
      userId: userId || 'guest',
      savedAt: nowIso,
      status: 'redeemed',
      redeemedAt: nowIso,
      redeemedChannel: details.channel,
      redeemedOrderRef: details.orderRef,
      discountApplied: details.discountApplied,
      redemptionCurrency: details.currency,
    };
    writeSavedCouponsForUser(userId, [directRedemption, ...existingSaved]);
  }

  const all = getAllPlatformCoupons();
  const updatedAll = all.map((c) =>
    c.id === couponId ? { ...c, redemptionCount: (c.redemptionCount || 0) + 1 } : c
  );
  saveAllPlatformCoupons(updatedAll);
}

export function setPendingCheckoutCoupon(payload: PendingCheckoutCoupon): void {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.setItem(PENDING_COUPON_KEY, JSON.stringify(payload));
  } catch {
    // ignore
  }
}

export function peekPendingCheckoutCoupon(category?: CouponCategory): PendingCheckoutCoupon | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = sessionStorage.getItem(PENDING_COUPON_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PendingCheckoutCoupon;
    if (category && parsed.category !== category) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function clearPendingCheckoutCoupon(): void {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.removeItem(PENDING_COUPON_KEY);
  } catch {
    // ignore
  }
}

export interface MerchantLocationSummary {
  id: string;
  name: string;
  type: 'retail' | 'restaurant';
  ownerId: string;
  ownerHandle?: string;
  ownerName?: string;
  cuisineOrCategory?: string;
  address?: string;
}

export interface DriverVehicleSummary {
  vehicleType: string;
  vehicleTypeLabel: string;
  vehicleClass: string;
  makeModel: string;
  plate: string;
}

export interface UserCouponIssuerCapabilities {
  userId: string;
  isTier2OrAdmin: boolean;
  ownedRestaurants: MerchantLocationSummary[];
  ownedRetailStores: MerchantLocationSummary[];
  allRestaurants: MerchantLocationSummary[];
  allRetailStores: MerchantLocationSummary[];
  driverVehicles: DriverVehicleSummary[];
  canIssueRestaurant: boolean;
  canIssueRetail: boolean;
  canIssueDriver: boolean;
}

function getUserIdentityAliases(currentUser: AuthSession | null): Set<string> {
  const aliases = new Set<string>();
  if (!currentUser) return aliases;
  [
    currentUser.uid,
    currentUser.id,
    currentUser.userId,
    currentUser.handle,
    currentUser.username,
    currentUser.name,
    currentUser.email,
  ].forEach((val) => {
    const clean = (val || '').trim().replace(/^@/, '').toLowerCase();
    if (clean) aliases.add(clean);
  });
  return aliases;
}

export function getCouponsIssuedByUser(
  currentUser: AuthSession | null,
  coupons: PlatformCoupon[] = getAllPlatformCoupons()
): PlatformCoupon[] {
  if (!currentUser) return [];
  if (isAdminOrSuperAdminUser(currentUser)) return coupons;
  const aliases = getUserIdentityAliases(currentUser);
  return coupons.filter((c) => {
    const cid = (c.issuerId || '').trim().toLowerCase();
    const chandle = (c.issuerHandle || '').trim().replace(/^@/, '').toLowerCase();
    const cname = (c.issuerName || '').trim().toLowerCase();
    return (cid && aliases.has(cid)) || (chandle && aliases.has(chandle)) || (cname && aliases.has(cname));
  });
}

export function getUserCouponIssuerCapabilities(
  currentUser: AuthSession | null
): UserCouponIssuerCapabilities {
  const userId = currentUser?.uid || currentUser?.id || 'guest';
  const tier = getUserVerificationTier(currentUser);
  const isTier2OrAdmin = isAdminOrSuperAdminUser(currentUser) || tier >= 2;

  let storedLocations: MerchantLocationSummary[] = [];
  try {
    const raw = localStorage.getItem('final_finance_merchant_locations');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) storedLocations = parsed;
    }
  } catch {
    // ignore
  }

  const allRestaurants = storedLocations.filter((l) => l.type === 'restaurant');
  const allRetailStores = storedLocations.filter((l) => l.type === 'retail');

  const aliases = getUserIdentityAliases(currentUser);
  const matchesOwner = (loc: MerchantLocationSummary) => {
    const oid = (loc.ownerId || '').trim().toLowerCase();
    const ohandle = (loc.ownerHandle || '').trim().replace(/^@/, '').toLowerCase();
    const oname = (loc.ownerName || '').trim().toLowerCase();
    return (
      (oid && aliases.has(oid)) ||
      (ohandle && aliases.has(ohandle)) ||
      (oname && aliases.has(oname))
    );
  };

  const ownedRestaurants = allRestaurants.filter(matchesOwner);
  const ownedRetailStores = allRetailStores.filter(matchesOwner);

  const driverVehicles: DriverVehicleSummary[] = [];
  try {
    const rawVeh = localStorage.getItem(`final_finance_driver_vehicles_${userId}`);
    if (rawVeh) {
      const parsed = JSON.parse(rawVeh);
      if (parsed && typeof parsed === 'object') {
        Object.values(parsed).forEach((slot: any) => {
          if (slot && slot.makeModel) {
            driverVehicles.push({
              vehicleType: slot.vehicleType || 'car',
              vehicleTypeLabel: slot.vehicleTypeLabel || 'Car',
              vehicleClass: slot.vehicleClass || 'Comfort EV',
              makeModel: slot.makeModel,
              plate: slot.plate || '',
            });
          }
        });
      }
    }
  } catch {
    // ignore
  }

  // Restaurant owners, retail store owners, and drivers (Tier 2+ verified or holding owned locations/vehicles) can issue coupons
  const canIssueRestaurant = isTier2OrAdmin || ownedRestaurants.length > 0;
  const canIssueRetail = isTier2OrAdmin || ownedRetailStores.length > 0;
  const canIssueDriver = isTier2OrAdmin || driverVehicles.length > 0;

  return {
    userId,
    isTier2OrAdmin,
    ownedRestaurants,
    ownedRetailStores,
    allRestaurants,
    allRetailStores,
    driverVehicles,
    canIssueRestaurant,
    canIssueRetail,
    canIssueDriver,
  };
}
