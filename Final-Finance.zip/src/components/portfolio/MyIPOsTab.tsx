import React, { useState } from 'react';
import { 
  Building2, 
  User, 
  Sparkles, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Lock, 
  Coins, 
  Scale, 
  TrendingUp, 
  DollarSign, 
  FileText, 
  ExternalLink,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  Film,
  Image as ImageIcon,
  Video,
  Upload,
  Activity,
  Play,
  Layers,
  Newspaper,
  Trash2
} from 'lucide-react';
import { IPORequest, IPOStatus, IPOMediaItem, StockNewsItem } from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { isAdminOrSuperAdminUser } from '../../utils/verificationTiers';
import {
  getLiveIPOValuation,
  cancelIPORequest,
  getStoredIPONews,
  deleteIPONewsItem,
  IPO_NEWS_UPDATED_EVENT
} from '../../data/stocksData';
import { ManageIPOMediaModal } from './ManageIPOMediaModal';
import { IssuerDividendAndSplitModal } from './IssuerDividendAndSplitModal';
import { PostIPONewsModal } from '../stocks/PostIPONewsModal';

interface MyIPOsTabProps {
  currentUser?: AuthSession | null;
  ipos: IPORequest[];
  onOpenReleaseModal: () => void;
  onRequestDelist: (ipo: IPORequest) => void;
  onIPOsUpdated?: () => void;
}

export const MyIPOsTab: React.FC<MyIPOsTabProps> = ({
  currentUser,
  ipos,
  onOpenReleaseModal,
  onRequestDelist,
  onIPOsUpdated
}) => {
  const isAdminUser = isAdminOrSuperAdminUser(currentUser);
  const [statusFilter, setStatusFilter] = useState<'all' | IPOStatus>('all');
  const [selectedMediaIpo, setSelectedMediaIpo] = useState<IPORequest | null>(null);
  const [selectedGovernanceIpo, setSelectedGovernanceIpo] = useState<IPORequest | null>(null);
  const [selectedNewsIpo, setSelectedNewsIpo] = useState<IPORequest | null>(null);
  const [activeLightboxMedia, setActiveLightboxMedia] = useState<IPOMediaItem | null>(null);
  const [ipoNewsList, setIpoNewsList] = useState<StockNewsItem[]>(() => getStoredIPONews());

  React.useEffect(() => {
    const refreshNews = () => setIpoNewsList(getStoredIPONews());
    window.addEventListener(IPO_NEWS_UPDATED_EVENT, refreshNews);
    window.addEventListener('storage', refreshNews);
    return () => {
      window.removeEventListener(IPO_NEWS_UPDATED_EVENT, refreshNews);
      window.removeEventListener('storage', refreshNews);
    };
  }, []);

  const handleCancelIPO = (ipoId: string) => {
    if (confirm('Are you sure you want to cancel this IPO request?')) {
      cancelIPORequest(ipoId);
      if (onIPOsUpdated) onIPOsUpdated();
    }
  };

  const getIPOFinalCurrencySymbol = (ipo: IPORequest): string => {
    if (ipo.ipoType === 'personal' && ipo.personalDetails?.backingFinalCoinSymbol) {
      return `₣${ipo.personalDetails.backingFinalCoinSymbol.replace(/^\$/, '').replace(/-FNL/gi, '')}`;
    }
    if (ipo.ipoType === 'business' && ipo.businessDetails?.backingCoinSymbol) {
      return `₣${ipo.businessDetails.backingCoinSymbol.replace(/^\$/, '').replace(/-FNL/gi, '')}`;
    }
    return `₣AFNL`;
  };

  const filteredIPOs = ipos.filter((ipo) => {
    if (statusFilter === 'all') return true;
    return ipo.status === statusFilter;
  });

  const getStatusBadge = (status: IPOStatus) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Active / Listed
          </span>
        );
      case 'pending_admin_approval':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
            <Clock className="w-3.5 h-3.5 text-amber-600 animate-spin" />
            Pending Admin Approval
          </span>
        );
      case 'delist_pending_admin_approval':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-rose-100 text-rose-900 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            Delist Request to Admin
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400 border border-slate-300 dark:border-slate-700">
            <XCircle className="w-3.5 h-3.5 text-rose-500" />
            Rejected by Admin
          </span>
        );
      case 'delisted':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
            <Lock className="w-3.5 h-3.5" />
            Delisted
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 text-left">
      
      {/* 1. TOP HEADER & ACTION BANNER */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4 text-center">
        <div className="flex flex-col items-center justify-center gap-3 text-center">
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            <h2 className="font-serif text-xl font-bold text-slate-900">
              Initial Public Offerings (IPO) Desk
            </h2>
            <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded-md border ${
              isAdminUser
                ? 'bg-emerald-100 text-emerald-900 border-emerald-200'
                : 'bg-amber-100 text-amber-900 border-amber-200'
            }`}>
              {isAdminUser ? 'Admin Instant Launch' : 'Admin Governed'}
            </span>
          </div>

          <button
            type="button"
            onClick={onOpenReleaseModal}
            className="px-5 py-2.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-900 text-slate-700 text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>+ Release New IPO</span>
          </button>
        </div>

        {/* 2. SPECIFICATION CARDS: PERSONAL VS BUSINESS RULES */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 text-center">
          {/* Personal IPO Rule */}
          <div className="p-5 rounded-2xl bg-white border border-slate-200 text-slate-900 space-y-2.5 shadow-sm flex flex-col items-center">
            <div className="flex items-center justify-center gap-2 text-xs font-bold text-amber-700">
              <User className="w-4 h-4 text-amber-600" />
              <span>👤 Personal IPO (Human Sovereign Equity)</span>
            </div>
            <div className="text-[11px] font-mono text-amber-700 font-semibold bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl w-full text-center">
              ✓ 1 Final Coin Backing &bull; ✓ 5-Mode NAV Solvency &bull; ✓ {isAdminUser ? 'Instant Admin Launch' : 'Admin Approval Required'}
            </div>
          </div>

          {/* Business IPO Rule */}
          <div className="p-5 rounded-2xl bg-white border border-slate-200 text-slate-900 space-y-2.5 shadow-sm flex flex-col items-center">
            <div className="flex items-center justify-center gap-2 text-xs font-bold text-sky-700">
              <Building2 className="w-4 h-4 text-sky-600" />
              <span>🏢 Business IPO (Corporate Enterprise)</span>
            </div>
            <div className="text-[11px] font-mono text-sky-700 font-semibold bg-sky-50 border border-sky-200 px-3 py-1.5 rounded-xl w-full text-center">
              ✓ Final Currency Backing Only &bull; ✓ Financial Audits &bull; ✓ Admin Delist Approval
            </div>
          </div>
        </div>
      </div>

      {/* 3. FILTER PILLS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 pr-1">
          Filter Status:
        </span>
        <button
          type="button"
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-white border border-slate-200 text-slate-800 shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          All Applications ({ipos.length})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('active')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
            statusFilter === 'active'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
          }`}
        >
          Active / Listed ({ipos.filter((i) => i.status === 'active').length})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('pending_admin_approval')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
            statusFilter === 'pending_admin_approval'
              ? 'bg-amber-700 text-white shadow-xs'
              : 'bg-amber-50 text-amber-900 hover:bg-amber-100'
          }`}
        >
          Pending Admin ({ipos.filter((i) => i.status === 'pending_admin_approval').length})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('delist_pending_admin_approval')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
            statusFilter === 'delist_pending_admin_approval'
              ? 'bg-rose-700 text-white shadow-xs'
              : 'bg-rose-50 text-rose-900 hover:bg-rose-100'
          }`}
        >
          Delist Requests ({ipos.filter((i) => i.status === 'delist_pending_admin_approval').length})
        </button>
      </div>

      {/* 4. IPO CARDS LIST */}
      {filteredIPOs.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white border border-slate-200 space-y-3">
          <Building2 className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-serif text-lg font-bold text-slate-800">
            No IPO applications found
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            You haven't issued any Initial Public Offerings matching this filter. Launch a Personal IPO or a Business IPO to issue public equities.
          </p>
          <button
            type="button"
            onClick={onOpenReleaseModal}
            className="px-5 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 hover:text-slate-900 transition-all cursor-pointer shadow-xs"
          >
            Release Your First IPO
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5">
          {filteredIPOs.map((ipo) => {
            const isPersonal = ipo.ipoType === 'personal';
            const personal = ipo.personalDetails;
            const business = ipo.businessDetails;
            const mediaItems = ipo.mediaGallery || 
              (isPersonal ? personal?.mediaGallery : business?.mediaGallery) || 
              [];
            const liveValuation = getLiveIPOValuation(ipo);
            const cleanTicker = ipo.ticker.replace(/^\$/, '').toUpperCase();
            const updatesForIpo = ipoNewsList.filter(
              (n) => n.ipoId === ipo.id || n.tickers?.some((t) => t.toUpperCase() === cleanTicker)
            );

            return (
              <div
                key={ipo.id}
                className="p-6 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-5 hover:border-slate-300 transition-all text-center"
              >
                {/* Top Row: Info & Status */}
                <div className="flex flex-col items-center justify-center text-center gap-3 pb-4 border-b border-slate-100">
                  <div className="flex flex-col items-center gap-2.5">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-base shadow-2xs ${
                      isPersonal 
                        ? 'bg-amber-500/15 text-amber-700 border border-amber-500/30' 
                        : 'bg-indigo-500/15 text-indigo-700 border border-indigo-500/30'
                    }`}>
                      {isPersonal ? '👤' : '🏢'}
                    </div>

                    <div className="flex flex-col items-center">
                      <div className="flex flex-wrap items-center justify-center gap-2">
                        <h3 className="font-serif text-base font-bold text-slate-900">
                          {ipo.equityName}
                        </h3>
                        <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                          ${ipo.ticker}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 flex flex-wrap items-center justify-center gap-2 mt-1">
                        <span className="font-semibold">
                          {isPersonal ? '👤 Personal Sovereign Equity (1 Allowed)' : `🏢 Corporate IPO (${business?.legalStructure || 'C-Corp'})`}
                        </span>
                        <span>&bull;</span>
                        <span className="font-mono text-[11px] font-bold text-indigo-700">
                          Settlement: {ipo.marketWay.toUpperCase()} Stocks
                        </span>
                        <span>&bull;</span>
                        <span className="text-[11px] text-slate-400">
                          Submitted: {new Date(ipo.submittedAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-2">
                    {ipo.status === 'pending_admin_approval' && (
                      <button
                        type="button"
                        onClick={() => handleCancelIPO(ipo.id)}
                        className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                    )}
                    {getStatusBadge(ipo.status)}
                  </div>
                </div>

                {/* LIVE REAL-TIME IPO VALUATION & MARKET WORTH */}
                {ipo.status === 'active' && (
                  <div className="p-4 rounded-2xl bg-gradient-to-b from-emerald-500/10 via-emerald-500/5 to-transparent border border-emerald-500/30 space-y-3 text-center">
                    <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                        <span className="font-mono text-xs font-bold uppercase tracking-wider text-emerald-950">
                          Live Stock Market Valuation &bull; Real-Time Worth
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-emerald-800 font-semibold flex items-center justify-center gap-1">
                        <Activity className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Real-time price feed synchronized</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="p-2.5 rounded-xl bg-white border border-emerald-200 shadow-2xs text-center">
                        <span className="text-[10px] uppercase font-mono text-slate-400 block">Current Live Price</span>
                        <div className="flex flex-wrap items-baseline justify-center gap-1 mt-0.5 tabular-nums">
                          <span className="text-xs sm:text-sm font-mono font-bold text-slate-900 truncate">
                            {getIPOFinalCurrencySymbol(ipo)} {liveValuation.livePrice.toFixed(2)}
                          </span>
                          <span className={`text-[10px] font-mono font-bold ${
                            liveValuation.changePercent >= 0 ? 'text-emerald-600' : 'text-rose-600'
                          }`}>
                            {liveValuation.changePercent >= 0 ? '+' : ''}{liveValuation.changePercent.toFixed(2)}%
                          </span>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-emerald-200 shadow-2xs text-center">
                        <span className="text-[10px] uppercase font-mono text-slate-400 block">Live Market Cap</span>
                        <div className="flex flex-wrap items-baseline justify-center gap-1 mt-0.5 tabular-nums">
                          <span className="text-xs sm:text-sm font-mono font-bold text-slate-900 truncate">
                            {getIPOFinalCurrencySymbol(ipo)} {(liveValuation.currentMarketCap / 1e6).toFixed(2)}M
                          </span>
                          <span className={`text-[10px] font-mono font-bold ${
                            liveValuation.changeUSD >= 0 ? 'text-emerald-600' : 'text-rose-600'
                          }`}>
                            ({liveValuation.changeUSD >= 0 ? '+' : ''}{getIPOFinalCurrencySymbol(ipo).charAt(0)}{liveValuation.changeUSD.toFixed(2)})
                          </span>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-emerald-200 shadow-2xs text-center">
                        <span className="text-[10px] uppercase font-mono text-slate-400 block">Circulating Valuation</span>
                        <div className="text-xs sm:text-sm font-mono font-bold text-slate-800 mt-0.5 truncate tabular-nums">
                          {getIPOFinalCurrencySymbol(ipo)} {(liveValuation.circulatingValuation / 1e6).toFixed(2)}M
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-white border border-emerald-200 shadow-2xs text-center">
                        <span className="text-[10px] uppercase font-mono text-slate-400 block">Founder Retained Worth</span>
                        <div className="text-xs sm:text-sm font-mono font-bold text-slate-800 mt-0.5 truncate tabular-nums">
                          {getIPOFinalCurrencySymbol(ipo)} {(liveValuation.founderRetainedValuation / 1e6).toFixed(2)}M
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Offering Terms Matrix */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 text-center">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-slate-400 block">Initial Offering Price</span>
                    <span className="text-sm font-mono font-bold text-slate-900 tabular-nums">
                      {getIPOFinalCurrencySymbol(ipo)} {ipo.offeringPriceUSD.toFixed(2)}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] uppercase font-mono text-slate-400 block">Total Shares Issued</span>
                    <span className="text-sm font-mono font-bold text-slate-900 tabular-nums">
                      {ipo.sharesOffered.toLocaleString()}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] uppercase font-mono text-slate-400 block">Initial Target Valuation</span>
                    <span className="text-sm font-mono font-bold text-slate-900 tabular-nums">
                      {getIPOFinalCurrencySymbol(ipo)} {(ipo.targetValuationUSD / 1e6).toFixed(2)}M
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] uppercase font-mono text-slate-400 block">Circulating Float</span>
                    <span className="text-sm font-mono font-bold text-slate-900 tabular-nums">
                      {ipo.circulatingFloat.toLocaleString()} shares (40%)
                    </span>
                  </div>
                </div>

                {/* VISUAL MEDIA GALLERY STRIP */}
                {mediaItems.length > 0 && (
                  <div className="space-y-2.5 pt-1 text-center">
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-2 text-xs">
                      <span className="font-bold text-slate-700 flex items-center justify-center gap-1.5">
                        <Film className="w-3.5 h-3.5 text-purple-600" />
                        <span>Attached Photos &amp; Video Prospectuses:</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => setSelectedMediaIpo(ipo)}
                        className="text-[11px] font-bold text-purple-600 hover:text-purple-800 cursor-pointer"
                      >
                        + Upload / Manage Media
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center justify-center gap-3 pb-1">
                      {mediaItems.map((m) => (
                        <div
                          key={m.id}
                          onClick={() => setActiveLightboxMedia(m)}
                          className="relative w-28 h-20 rounded-xl overflow-hidden bg-slate-100 shrink-0 border border-slate-200 hover:border-purple-400 cursor-pointer group shadow-2xs"
                        >
                          {m.type === 'video' ? (
                            <video src={m.url} className="w-full h-full object-cover" preload="metadata" />
                          ) : (
                            <img src={m.url} alt={m.title || 'media'} className="w-full h-full object-cover group-hover:scale-105 transition-transform" referrerPolicy="no-referrer" />
                          )}
                          <div className="absolute inset-0 bg-slate-900/10 group-hover:bg-transparent transition-colors flex items-center justify-center">
                            {m.type === 'video' && (
                              <div className="w-6 h-6 rounded-full bg-white/30 backdrop-blur-xs flex items-center justify-center">
                                <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                              </div>
                            )}
                          </div>
                          <span className="absolute bottom-1 left-1 px-1 py-0.5 rounded text-[7px] font-mono font-bold bg-black/80 text-white">
                            {m.type === 'video' ? 'VIDEO' : 'PHOTO'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Specific Details View */}
                {isPersonal && personal && (
                  <div className="space-y-3 pt-1 text-center">
                    <div className="text-xs text-slate-700 space-y-2 flex flex-col items-center">
                      <div className="flex flex-wrap items-center justify-center gap-2">
                        <span className="font-bold text-slate-900">Identity:</span>
                        <span>{personal.fullName}</span>
                        <span className="font-mono text-slate-500">{personal.handle}</span>
                        <span>&bull;</span>
                        <span className="font-semibold text-slate-800">{personal.profession}</span>
                      </div>

                      {personal.personalityTraits && personal.personalityTraits.length > 0 && (
                        <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                          <span className="text-[11px] font-bold text-slate-500">Traits:</span>
                          {personal.personalityTraits.map((t) => (
                            <span key={t} className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 font-semibold text-[10px] border border-amber-200">
                              {t}
                            </span>
                          ))}
                        </div>
                      )}

                      <p className="text-slate-600 text-xs italic bg-amber-50/50 p-2.5 rounded-xl border border-amber-100 text-center max-w-3xl mx-auto w-full">
                        "{personal.personaProfile}"
                      </p>
                    </div>

                    {/* 5-Mode Net Worth Solvency */}
                    {personal.fiveModeNetWorth && (
                      <div className="p-3.5 rounded-2xl bg-amber-50/40 border border-amber-200/60 space-y-2.5 text-center">
                        <div className="flex flex-wrap items-center justify-center gap-2 text-xs">
                          <span className="font-bold text-amber-950 flex items-center justify-center gap-1.5">
                            <Scale className="w-3.5 h-3.5 text-amber-600" />
                            <span>Verified 5-Mode Solvency NAV:</span>
                          </span>
                          <span className="font-mono font-bold text-amber-900 tabular-nums">
                            {getIPOFinalCurrencySymbol(ipo)} {personal.fiveModeNetWorth.totalNetWorthUSD.toLocaleString()}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[10px] font-mono text-center">
                          <div className="p-1.5 rounded-lg bg-white border border-amber-200">
                            <span className="text-slate-400 block">1. Fiat Reserve</span>
                            <span className="font-bold text-slate-800 tabular-nums">{getIPOFinalCurrencySymbol(ipo)} {(personal.fiveModeNetWorth.fiatUSD / 1e6).toFixed(2)}M</span>
                          </div>
                          <div className="p-1.5 rounded-lg bg-white border border-amber-200">
                            <span className="text-slate-400 block">2. Gold &amp; Vaults</span>
                            <span className="font-bold text-slate-800 tabular-nums">{getIPOFinalCurrencySymbol(ipo)} {(personal.fiveModeNetWorth.sovereignGoldBarter / 1e6).toFixed(2)}M</span>
                          </div>
                          <div className="p-1.5 rounded-lg bg-white border border-amber-200">
                            <span className="text-slate-400 block">3. Final Coins</span>
                            <span className="font-bold text-slate-800 tabular-nums">{getIPOFinalCurrencySymbol(ipo)} {(personal.fiveModeNetWorth.finalCoins / 1e6).toFixed(2)}M</span>
                          </div>
                          <div className="p-1.5 rounded-lg bg-white border border-amber-200">
                            <span className="text-slate-400 block">4. Sovereign Reserves</span>
                            <span className="font-bold text-slate-800 tabular-nums">{getIPOFinalCurrencySymbol(ipo)} {(personal.fiveModeNetWorth.stableCoins / 1e6).toFixed(2)}M</span>
                          </div>
                          <div className="p-1.5 rounded-lg bg-white border border-amber-200">
                            <span className="text-slate-400 block">5. Final Cryptos</span>
                            <span className="font-bold text-slate-800 tabular-nums">{getIPOFinalCurrencySymbol(ipo)} {(personal.fiveModeNetWorth.cryptoAssets / 1e6).toFixed(2)}M</span>
                          </div>
                        </div>

                        <div className="text-[11px] text-amber-800 flex flex-wrap items-center justify-center gap-1.5 font-semibold pt-1 text-center">
                          <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>Backing Final Currency: <strong>{personal.backingFinalCoinName || personal.backingFinalCoinSymbol}</strong> (Strict 1 Final Currency Rule)</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Business Details View */}
                {!isPersonal && business && (
                  <div className="space-y-3 pt-1 text-center">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs text-center">
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-400 block">Industry &amp; Sector</span>
                        <span className="font-semibold text-slate-800">{business.sector} &bull; {business.industry}</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-400 block">Registration &amp; HQ</span>
                        <span className="font-semibold text-slate-800">{business.registrationNumber} &bull; {business.headquarters}</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="text-[10px] text-slate-400 block">Backing Final Currency</span>
                        <span className="font-semibold text-indigo-700 flex flex-wrap items-center justify-center gap-1 mt-0.5">
                          <span>{business.backingCoinName || business.backingCoinSymbol}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-200">
                            ⚡ Final Coin
                          </span>
                        </span>
                      </div>
                    </div>

                    {/* Financial Metrics */}
                    <div className="p-3 rounded-2xl bg-indigo-50/40 border border-indigo-100 flex flex-col items-center justify-center gap-2 text-xs text-center">
                      <div className="flex flex-wrap items-center justify-center gap-2">
                        <TrendingUp className="w-4 h-4 text-indigo-600" />
                        <span className="font-bold text-slate-800">Financial Performance:</span>
                        <span className="text-slate-600">Annual Revenue: <strong>${(business.annualRevenueUSD / 1e6).toFixed(2)}M</strong></span>
                        <span>&bull;</span>
                        <span className="text-slate-600">Net Margin: <strong>{business.netProfitMarginPercent}%</strong></span>
                        <span>&bull;</span>
                        <span className="text-slate-600">YoY Growth: <strong>+{business.projectedGrowthPercent}%</strong></span>
                      </div>

                      <div className="text-[11px] text-slate-500">
                        Leadership: CEO {business.executives?.ceo || 'N/A'} {business.executives?.cto && `• CTO ${business.executives.cto}`}
                      </div>
                    </div>

                    <p className="text-slate-600 text-xs italic bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-center max-w-3xl mx-auto w-full">
                      "{business.businessModel}"
                    </p>
                  </div>
                )}

                {/* Status-specific actions & Admin Notices */}
                <div className="pt-3 border-t border-slate-100 flex flex-col items-center justify-center gap-3 text-center">
                  <div className="text-xs">
                    {ipo.status === 'active' && (
                      <span className="text-emerald-700 font-semibold flex flex-wrap items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>Trading live on Final Stock Exchange. Shareholders can trade shares in Final Currencies.</span>
                      </span>
                    )}

                    {ipo.status === 'pending_admin_approval' && (
                      <span className="text-amber-800 font-semibold flex flex-wrap items-center justify-center gap-1.5">
                        <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>Prospectus queued for Admin Review. Stock will be listed once Admin approves.</span>
                      </span>
                    )}

                    {ipo.status === 'delist_pending_admin_approval' && (
                      <span className="text-rose-800 font-semibold flex flex-wrap items-center justify-center gap-1.5">
                        <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>Delist application submitted to Admin. Reason: "{ipo.delistReason}"</span>
                      </span>
                    )}

                    {ipo.status === 'rejected' && (
                      <span className="text-slate-700 font-semibold flex flex-wrap items-center justify-center gap-1.5">
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>Admin Note: {ipo.adminNotes || 'Application did not meet compliance criteria.'}</span>
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    {ipo.status === 'active' && (
                      <button
                        type="button"
                        onClick={() => setSelectedGovernanceIpo(ipo)}
                        className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
                      >
                        <Coins className="w-3.5 h-3.5" />
                        <span>Dividend &amp; Splits Desk</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => setSelectedNewsIpo(ipo)}
                      className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
                    >
                      <Newspaper className="w-3.5 h-3.5" />
                      <span>Add News / Earnings</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedMediaIpo(ipo)}
                      className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5 text-slate-500" />
                      <span>Upload Photos/Videos</span>
                    </button>

                    {ipo.status === 'active' && (
                      <button
                        type="button"
                        onClick={() => onRequestDelist(ipo)}
                        className="px-4 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>Request Delisting</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Published News & Earnings Updates for this IPO */}
                {updatesForIpo.length > 0 && (
                  <div className="pt-3 border-t border-slate-100 space-y-2 text-center">
                    <div className="flex flex-wrap items-center justify-center gap-3 text-xs">
                      <span className="font-bold text-slate-700 flex items-center justify-center gap-1.5">
                        <Newspaper className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Published News &amp; Earnings Updates ({updatesForIpo.length})</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => setSelectedNewsIpo(ipo)}
                        className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                      >
                        + Post Another Update
                      </button>
                    </div>
                    <div className="space-y-1.5">
                      {updatesForIpo.slice(0, 3).map((upd) => (
                        <div
                          key={upd.id}
                          className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3 text-xs"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 font-bold text-[10px]">
                                {upd.category || 'Update'}
                              </span>
                              <span className="font-bold text-slate-900 truncate">{upd.title}</span>
                            </div>
                            <p className="text-[11px] text-slate-500 truncate mt-0.5">
                              {upd.time}
                              {upd.documents?.length ? ` • ${upd.documents.length} doc(s)` : ''}
                              {upd.photos?.length ? ` • ${upd.photos.length} photo(s)` : ''}
                              {upd.videos?.length ? ` • ${upd.videos.length} video(s)` : ''}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => deleteIPONewsItem(upd.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer shrink-0"
                            title="Delete update"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            );
          })}
        </div>
      )}

      {/* ISSUER DIVIDEND & SPLIT GOVERNANCE MODAL */}
      {selectedGovernanceIpo && (
        <IssuerDividendAndSplitModal
          isOpen={true}
          onClose={() => setSelectedGovernanceIpo(null)}
          ipo={selectedGovernanceIpo}
          currentUser={currentUser}
          onSuccess={() => {
            if (onIPOsUpdated) onIPOsUpdated();
          }}
        />
      )}

      {/* MANAGE MEDIA MODAL (ACCESSIBLE EVEN AFTER LAUNCH) */}
      {selectedMediaIpo && (
        <ManageIPOMediaModal
          isOpen={true}
          onClose={() => setSelectedMediaIpo(null)}
          ipo={selectedMediaIpo}
          onSaved={() => {
            if (onIPOsUpdated) onIPOsUpdated();
          }}
        />
      )}

      {/* POST IPO NEWS / EARNINGS REPORT MODAL */}
      {selectedNewsIpo && (
        <PostIPONewsModal
          isOpen={true}
          onClose={() => setSelectedNewsIpo(null)}
          ipos={ipos}
          initialIpo={selectedNewsIpo}
          currentUser={currentUser}
          onPublished={() => {
            setIpoNewsList(getStoredIPONews());
            if (onIPOsUpdated) onIPOsUpdated();
          }}
        />
      )}

      {/* QUICK LIGHTBOX PREVIEW */}
      {activeLightboxMedia && (
        <div 
          onClick={() => setActiveLightboxMedia(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div 
            onClick={(e) => e.stopPropagation()}
            className="max-w-3xl w-full bg-white text-slate-900 border border-slate-200 rounded-3xl overflow-hidden p-4 space-y-3 shadow-xl"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="font-bold text-xs">{activeLightboxMedia.title || 'Visual Media'}</span>
              <button 
                type="button"
                onClick={() => setActiveLightboxMedia(null)}
                className="text-slate-500 hover:text-slate-900"
              >
                ✕
              </button>
            </div>
            <div className="aspect-video w-full flex items-center justify-center bg-black rounded-2xl overflow-hidden">
              {activeLightboxMedia.type === 'video' ? (
                <video src={activeLightboxMedia.url} controls autoPlay className="w-full h-full object-contain" />
              ) : (
                <img src={activeLightboxMedia.url} alt="lightbox" className="w-full h-full object-contain" />
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
