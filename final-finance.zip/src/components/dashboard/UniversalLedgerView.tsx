import React, { useState, useMemo } from 'react';
import { 
  History, 
  Receipt, 
  Search, 
  Download, 
  Filter, 
  Coins, 
  Building2, 
  Banknote, 
  Sparkles, 
  Binary, 
  User, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CreditCard, 
  FileText, 
  CheckCircle2, 
  Calendar,
  ExternalLink,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ArrowRight,
  Layers,
  Repeat,
  ShoppingBag,
  Briefcase
} from 'lucide-react';
import { UniversalLedgerItem, TransactionCategory, TransactionMode } from '../../types/ledger';
import { exportLedgerToCSV } from '../../utils/universalLedgerBridge';
import { TransactionReceiptModal } from './TransactionReceiptModal';
import { getAllLoans } from '../../services/loanService';

interface UniversalLedgerViewProps {
  transactions: UniversalLedgerItem[];
  userId?: string;
}

export const UniversalLedgerView: React.FC<UniversalLedgerViewProps> = ({
  transactions,
  userId = 'guest'
}) => {
  const allLoans = useMemo(() => getAllLoans(), []);
  const [activeCategory, setActiveCategory] = useState<
    'all' | 
    'stock_trades' | 
    'personal_stocks' | 
    'business_stocks' | 
    'loans' | 
    'barter' | 
    'products_services' | 
    'grants_donations' |
    'deposits' | 
    'withdrawals' | 
    'taxable'
  >('all');
  const [selectedMode, setSelectedMode] = useState<'all' | TransactionMode>('all');
  const [selectedTaxYear, setSelectedTaxYear] = useState<'all' | number>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Active receipt modal state
  const [selectedReceipt, setSelectedReceipt] = useState<UniversalLedgerItem | null>(null);

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      // 1. Category Filter
      if (activeCategory === 'stock_trades') {
        if (tx.type !== 'stock_buy' && tx.type !== 'stock_sell') return false;
      } else if (activeCategory === 'personal_stocks') {
        if (!tx.isPersonalStock && tx.category !== 'personal_stock') return false;
      } else if (activeCategory === 'business_stocks') {
        if (!tx.isBusinessStock && tx.category !== 'business_stock') return false;
      } else if (activeCategory === 'loans') {
        if (
          tx.category === 'loan' ||
          tx.type === 'loan_issued' ||
          tx.type === 'loan_received' ||
          tx.type === 'loan_repaid' ||
          (tx.type as string) === 'loan_requested' ||
          tx.type === 'loan_written_off' ||
          tx.type === 'loan_defaulted' ||
          tx.title.toLowerCase().includes('loan') ||
          tx.description.toLowerCase().includes('loan') ||
          tx.description.toLowerCase().includes('lent') ||
          tx.description.toLowerCase().includes('borrow')
        ) {
          return true;
        }
        return false;
      } else if (activeCategory === 'barter') {
        if (
          tx.category === 'barter' ||
          tx.type === 'barter_swap' ||
          (tx.type as string) === 'barter_good_added' ||
          (tx.type as string) === 'barter_service_added' ||
          tx.type === 'vault_swap' ||
          tx.title.toLowerCase().includes('barter') ||
          tx.description.toLowerCase().includes('barter') ||
          tx.description.toLowerCase().includes('swap')
        ) {
          return true;
        }
        return false;
      } else if (activeCategory === 'products_services') {
        if (
          tx.category === 'product_service' ||
          tx.type === 'product_purchase' ||
          tx.type === 'service_payment' ||
          tx.type === 'marketplace_sale' ||
          tx.title.toLowerCase().includes('product') ||
          tx.title.toLowerCase().includes('service') ||
          tx.title.toLowerCase().includes('hardware') ||
          tx.title.toLowerCase().includes('audit') ||
          tx.title.toLowerCase().includes('license') ||
          tx.title.toLowerCase().includes('marketplace') ||
          tx.description.toLowerCase().includes('hardware') ||
          tx.description.toLowerCase().includes('product') ||
          tx.description.toLowerCase().includes('service')
        ) {
          return true;
        }
        return false;
      } else if (activeCategory === 'grants_donations') {
        if (
          tx.type === 'grant_claim' ||
          tx.type === 'grant_subsidy' ||
          tx.type === 'campaign_donation' ||
          tx.type === 'charity_donation' ||
          tx.category === 'grant_subsidy' ||
          tx.category === 'charity_donation' ||
          tx.title.toLowerCase().includes('grant') ||
          tx.title.toLowerCase().includes('subsidy') ||
          tx.title.toLowerCase().includes('donation') ||
          tx.description.toLowerCase().includes('grant') ||
          tx.description.toLowerCase().includes('subsidy') ||
          tx.description.toLowerCase().includes('donation') ||
          tx.description.toLowerCase().includes('campaign')
        ) {
          return true;
        }
        return false;
      } else if (activeCategory === 'deposits') {
        if (
          tx.type !== 'deposit' && 
          tx.type !== 'grant_claim' &&
          tx.type !== 'grant_subsidy' &&
          tx.type !== 'vault_deposit' &&
          tx.type !== 'card_topup' &&
          tx.type !== 'crypto_deposit' &&
          tx.category !== 'money_inflow' &&
          tx.category !== 'grant_subsidy'
        ) return false;
      } else if (activeCategory === 'withdrawals') {
        if (
          tx.type !== 'bank_withdraw' && 
          tx.type !== 'payment_settlement' && 
          tx.type !== 'vault_withdrawal' &&
          tx.category !== 'money_outflow'
        ) return false;
      } else if (activeCategory === 'taxable') {
        if (!tx.taxClassification.taxableEvent) return false;
      }

      // 2. Mode Filter (5 Modes)
      if (selectedMode !== 'all' && tx.mode !== selectedMode) {
        return false;
      }

      // 3. Tax Year Filter
      if (selectedTaxYear !== 'all' && tx.taxYear !== selectedTaxYear) {
        return false;
      }

      // 4. Search Filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesTitle = tx.title.toLowerCase().includes(query);
        const matchesReceipt = tx.receiptNumber.toLowerCase().includes(query);
        const matchesTicker = tx.stockTicker?.toLowerCase().includes(query);
        const matchesParty = tx.counterpartyOrIssuer.toLowerCase().includes(query);
        const matchesSource = tx.sourceOrDestination.toLowerCase().includes(query);
        const matchesForm = tx.taxClassification.formMapping.toLowerCase().includes(query);
        const matchesDesc = tx.description.toLowerCase().includes(query);

        if (!matchesTitle && !matchesReceipt && !matchesTicker && !matchesParty && !matchesSource && !matchesForm && !matchesDesc) {
          return false;
        }
      }

      return true;
    });
  }, [transactions, activeCategory, selectedMode, selectedTaxYear, searchQuery]);

  const handleExportCSV = () => {
    exportLedgerToCSV(filteredTransactions, `Sovereign_Tax_Ledger_${selectedTaxYear === 'all' ? 'All_Years' : selectedTaxYear}.csv`);
  };

  const getModeBadgeInfo = (mode: TransactionMode) => {
    switch (mode) {
      case 'final_coin':
        return { label: 'Final Coin ($AFNL)', style: 'bg-amber-50 text-amber-800 border-amber-200' };
      case 'fiat':
        return { label: 'Fiat ($USD)', style: 'bg-sky-50 text-sky-800 border-sky-200' };
      case 'stable_coin':
        return { label: 'Stablecoin ($USDC)', style: 'bg-emerald-50 text-emerald-800 border-emerald-200' };
      case 'crypto':
        return { label: 'Crypto ($BTC/ETH)', style: 'bg-indigo-50 text-indigo-800 border-indigo-200' };
      case 'gold_bullion':
        return { label: 'Gold Bullion', style: 'bg-amber-100/70 text-amber-900 border-amber-300' };
      default:
        return { label: 'Sovereign Clearing', style: 'bg-slate-50 text-slate-800 border-slate-200' };
    }
  };

  return (
    <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-6 text-left">
      {/* Header with Title & Export Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-slate-900 text-amber-400">
              <History className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2.5">
                <h2 className="font-serif text-xl font-bold text-slate-900 leading-tight">
                  Universal Financial Ledger &amp; Tax Receipts
                </h2>
                <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 whitespace-nowrap shrink-0">
                  {transactions.length} Verified Records
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Complete verifiable audit trail of all 5 transaction modes, personal &amp; business stocks, inflows, and withdrawals for tax accounting
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCSV}
            className="py-2 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Export Tax Ledger (CSV)</span>
          </button>
        </div>
      </div>

      {/* Primary Category Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 rounded-2xl bg-slate-100 border border-slate-200 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveCategory('all')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'all' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All Transactions ({transactions.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('stock_trades')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'stock_trades' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Stock Trades (5 Modes)
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('personal_stocks')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'personal_stocks' ? 'bg-purple-50 text-purple-900 shadow-2xs font-bold border border-purple-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Personal Stocks
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('business_stocks')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'business_stocks' ? 'bg-indigo-50 text-indigo-900 shadow-2xs font-bold border border-indigo-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Business Stocks
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('loans')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'loans' ? 'bg-teal-50 text-teal-900 shadow-2xs font-bold border border-teal-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Loans (Giving &amp; Receiving)
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('barter')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'barter' ? 'bg-amber-100 text-amber-900 shadow-2xs font-bold border border-amber-300' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Barter Trades (Swaps)
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('products_services')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'products_services' ? 'bg-cyan-50 text-cyan-900 shadow-2xs font-bold border border-cyan-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Products &amp; Services
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('grants_donations')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'grants_donations' ? 'bg-rose-50 text-rose-900 shadow-2xs font-bold border border-rose-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Grants &amp; Donations
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('deposits')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'deposits' ? 'bg-emerald-50 text-emerald-900 shadow-2xs font-bold border border-emerald-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Money Added (+Inflows)
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('withdrawals')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'withdrawals' ? 'bg-sky-50 text-sky-900 shadow-2xs font-bold border border-sky-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Money Withdrawn (-Outflows)
        </button>

        <button
          type="button"
          onClick={() => setActiveCategory('taxable')}
          className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
            activeCategory === 'taxable' ? 'bg-amber-50 text-amber-900 shadow-2xs font-bold border border-amber-200' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Taxable Events (1099/8949)
        </button>
      </div>

      {/* Filter Row: Search & Mode Filter & Year Filter */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
        {/* Search input */}
        <div className="sm:col-span-6 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Ticker, Receipt #, Issuer, Counterparty, or IRS Form..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all font-sans"
          />
        </div>

        {/* 5 Transaction Modes Filter */}
        <div className="sm:col-span-4">
          <select
            value={selectedMode}
            onChange={(e) => setSelectedMode(e.target.value as any)}
            className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all cursor-pointer"
          >
            <option value="all">All 5 Transaction Modes</option>
            <option value="final_coin">Mode 1: Final Coin ($AFNL)</option>
            <option value="fiat">Mode 2: Fiat Cash ($USD Fedwire)</option>
            <option value="stable_coin">Mode 3: Stablecoin ($USDC)</option>
            <option value="crypto">Mode 4: Crypto ($BTC/ETH)</option>
            <option value="gold_bullion">Mode 5: Gold Bullion (Zurich)</option>
          </select>
        </div>

        {/* Tax Year Filter */}
        <div className="sm:col-span-2">
          <select
            value={selectedTaxYear}
            onChange={(e) => setSelectedTaxYear(e.target.value === 'all' ? 'all' : Number(e.target.value))}
            className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all cursor-pointer"
          >
            <option value="all">All Tax Years</option>
            <option value="2026">Tax Year 2026</option>
            <option value="2025">Tax Year 2025</option>
          </select>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-100 bg-slate-50/80 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              <th className="py-3 px-4">Receipt / Transaction</th>
              <th className="py-3 px-3">Mode</th>
              <th className="py-3 px-3">Counterparty / Issuer</th>
              <th className="py-3 px-3">Stock Trade P&amp;L / Cost Basis</th>
              <th className="py-3 px-3">IRS Tax Classification</th>
              <th className="py-3 px-3 text-right">Net Settled</th>
              <th className="py-3 px-4 text-center">Receipt Proof</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {filteredTransactions.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-400 space-y-2">
                  <Receipt className="w-8 h-8 mx-auto text-slate-300 stroke-1" />
                  <p className="font-semibold text-slate-600">No transactions match your search or filter criteria.</p>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveCategory('all');
                      setSelectedMode('all');
                      setSelectedTaxYear('all');
                      setSearchQuery('');
                    }}
                    className="text-xs font-bold text-amber-700 hover:text-amber-800 cursor-pointer underline"
                  >
                    Reset all filters
                  </button>
                </td>
              </tr>
            ) : (
              filteredTransactions.map((tx) => {
                const modeInfo = getModeBadgeInfo(tx.mode) || { label: 'Sovereign Clearing', style: 'bg-slate-50 text-slate-800 border-slate-200' };
                const isLoan = tx.category === 'loan' || tx.type === 'loan_issued' || tx.type === 'loan_received' || tx.type === 'loan_repaid';
                const isBarter = tx.category === 'barter' || tx.type === 'barter_swap';
                const isProductService = tx.category === 'product_service' || tx.type === 'product_purchase' || tx.type === 'service_payment' || tx.type === 'marketplace_sale';
                const isPositive = tx.type === 'deposit' || tx.type === 'dividend' || tx.type === 'staking_reward' || tx.type === 'barter_swap' || tx.type === 'stock_sell' || tx.type === 'loan_received' || tx.type === 'loan_repaid' || tx.type === 'marketplace_sale';
                const isReversed = tx.status === 'Reversed';

                return (
                  <tr 
                    key={tx.id} 
                    onClick={() => setSelectedReceipt(tx)}
                    className={`hover:bg-slate-50/80 transition-colors cursor-pointer group ${isReversed ? 'opacity-70 grayscale-[0.3]' : ''}`}
                  >
                    {/* Column 1: Title & Receipt ID */}
                    <td className="py-4 px-4">
                      <div className="flex items-start gap-4">
                        <div className={`p-2.5 rounded-2xl mt-0.5 shrink-0 ${
                          tx.type === 'deposit' 
                            ? 'bg-emerald-50 text-emerald-700' 
                            : tx.type === 'bank_withdraw'
                            ? 'bg-sky-50 text-sky-700'
                            : tx.type === 'dividend' || tx.type === 'staking_reward'
                            ? 'bg-amber-50 text-amber-800'
                            : isLoan
                            ? 'bg-teal-50 text-teal-700'
                            : isBarter
                            ? 'bg-amber-100 text-amber-900'
                            : isProductService
                            ? 'bg-cyan-50 text-cyan-800'
                            : tx.isPersonalStock
                            ? 'bg-purple-50 text-purple-700'
                            : 'bg-slate-100 text-slate-800'
                        }`}>
                          {tx.type === 'deposit' ? <ArrowDownLeft className="w-4 h-4" /> :
                           tx.type === 'bank_withdraw' ? <ArrowUpRight className="w-4 h-4" /> :
                           tx.type === 'dividend' || tx.type === 'staking_reward' ? <Coins className="w-4 h-4" /> :
                           isLoan ? <CreditCard className="w-4 h-4" /> :
                           isBarter ? <Repeat className="w-4 h-4" /> :
                           isProductService ? (tx.type === 'service_payment' ? <Briefcase className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />) :
                           tx.isPersonalStock ? <User className="w-4 h-4" /> :
                           <Building2 className="w-4 h-4" />}
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-center gap-2.5 flex-wrap">
                            <span className={`font-bold text-slate-900 group-hover:text-amber-800 transition-colors ${isReversed ? 'line-through decoration-rose-500/50' : ''}`}>
                              {tx.title}
                            </span>
                            {isReversed && (
                              <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-rose-50 text-rose-700 border border-rose-200 animate-pulse">
                                REVERSED
                              </span>
                            )}
                            {tx.isPersonalStock && (
                              <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-purple-50 text-purple-700 border border-purple-200">
                                Personal Stock
                              </span>
                            )}
                            {tx.isBusinessStock && (
                              <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                                Business Stock
                              </span>
                            )}
                            {isLoan && (
                              <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                                tx.type === 'loan_issued' 
                                  ? 'bg-amber-50 text-amber-800 border-amber-200' 
                                  : tx.type === 'loan_repaid'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : 'bg-teal-50 text-teal-800 border-teal-200'
                              }`}>
                                {tx.type === 'loan_issued' ? 'Loan Given' : tx.type === 'loan_repaid' ? 'Loan Repaid' : 'Loan Received'}
                              </span>
                            )}
                            {isBarter && (
                              <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 border border-amber-300">
                                Barter Trade
                              </span>
                            )}
                            {isProductService && (
                              <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                                tx.type === 'service_payment'
                                  ? 'bg-cyan-50 text-cyan-800 border-cyan-200'
                                  : tx.type === 'marketplace_sale'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : 'bg-sky-50 text-sky-800 border-sky-200'
                              }`}>
                                {tx.type === 'service_payment' ? 'Service Contract' : tx.type === 'marketplace_sale' ? 'Product Revenue' : 'Product Equipment'}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2.5 text-[10px] text-slate-400 font-medium tracking-wide">
                            <span className="font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-md border border-slate-200 shadow-inner">{tx.receiptNumber}</span>
                            <span className="text-slate-300">&bull;</span>
                            <span className="font-mono">{tx.timestamp}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Column 2: Mode Badge */}
                    <td className="py-3.5 px-3">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${modeInfo.style}`}>
                        {modeInfo.label}
                      </span>
                    </td>

                    {/* Column 3: Counterparty / Issuer */}
                    <td className="py-3.5 px-3 font-medium text-slate-700">
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-900">{tx.counterpartyOrIssuer}</span>
                        <span className="text-[11px] text-slate-400 font-mono">{tx.sourceOrDestination}</span>
                      </div>
                    </td>

                    {/* Column 4: Stock Trade P&L / Cost Basis / Loan / Barter / Product Details */}
                    <td className="py-3.5 px-3">
                      {isLoan ? (
                        (() => {
                          const loan = allLoans.find(l => l.id === tx.loanId);
                          if (!loan) return (
                            <div className="flex flex-col gap-0.5">
                              <span className="text-[11px] font-mono font-semibold text-teal-800">
                                {tx.type === 'loan_issued' ? 'Lending Principal' : tx.type === 'loan_repaid' ? 'Loan Repaid' : 'Borrowed Principal'}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                ${tx.amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} {tx.paymentCoinSymbol || 'USD'}
                              </span>
                            </div>
                          );
                          return (
                            <div className="flex flex-col gap-0.5">
                              <span className="text-[11px] font-mono font-semibold text-teal-800">
                                {tx.type === 'loan_issued' ? 'Lending Principal' : tx.type === 'loan_repaid' ? 'Loan Repaid' : 'Borrowed Principal'}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                ${loan.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {loan.coinSymbol}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                Due: {new Date(loan.issuedAtMs + loan.termDays * 24 * 60 * 60 * 1000).toLocaleDateString()}
                              </span>
                              <span className={`text-[10px] font-mono font-bold ${loan.status === 'repaid' ? 'text-emerald-700' : loan.status === 'defaulted' ? 'text-rose-700' : 'text-amber-700'}`}>
                                Status: {loan.status.toUpperCase()}
                              </span>
                            </div>
                          );
                        })()
                      ) : isBarter ? (
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[11px] font-mono font-semibold text-amber-900">
                            Barter Asset Exchange
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            ${tx.amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} valuation
                          </span>
                        </div>
                      ) : isProductService ? (
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[11px] font-mono font-semibold text-cyan-900">
                            {tx.type === 'service_payment' ? 'Professional Service' : tx.type === 'marketplace_sale' ? 'Product Revenue' : 'Commercial Hardware'}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {tx.taxClassification.taxDeductible ? 'Tax-Deductible (Sched C)' : 'Commercial Item'}
                          </span>
                        </div>
                      ) : tx.type === 'stock_sell' || tx.realizedGainLossUSD !== undefined ? (
                        <div className="flex flex-col gap-0.5">
                          {(tx.realizedGainLossUSD ?? 0) >= 0 ? (
                            <div className="inline-flex items-center gap-1 font-mono font-bold text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200 w-fit">
                              <TrendingUp className="w-3 h-3 text-emerald-600" />
                              <span>
                                +${(tx.realizedGainLossUSD ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                {tx.realizedGainLossPercent !== undefined ? ` (+${tx.realizedGainLossPercent.toFixed(1)}%)` : ' Profit'}
                              </span>
                            </div>
                          ) : (
                            <div className="inline-flex items-center gap-1 font-mono font-bold text-[11px] text-rose-700 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-200 w-fit">
                              <TrendingDown className="w-3 h-3 text-rose-600" />
                              <span>
                                -${Math.abs(tx.realizedGainLossUSD ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                {tx.realizedGainLossPercent !== undefined ? ` (${tx.realizedGainLossPercent.toFixed(1)}%)` : ' Loss'}
                              </span>
                            </div>
                          )}
                          <span className="text-[10px] text-slate-400 font-mono">
                            Cost Basis: ${tx.costBasisUSD?.toLocaleString(undefined, { minimumFractionDigits: 2 }) || '0.00'}
                          </span>
                        </div>
                      ) : tx.type === 'stock_buy' ? (
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[11px] font-mono font-semibold text-slate-700">
                            Basis: ${tx.costBasisUSD ? tx.costBasisUSD.toLocaleString(undefined, { minimumFractionDigits: 2 }) : `$${tx.netAmountUSD.toFixed(2)}`}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {tx.shares ? `${tx.shares} shs @ $${tx.unitPriceUSD?.toFixed(2) || '0.00'}/sh` : 'Position Established'}
                          </span>
                        </div>
                      ) : tx.type === 'dividend' || tx.type === 'staking_reward' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          +${tx.netAmountUSD.toFixed(2)} Yield
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-mono">-</span>
                      )}
                    </td>

                    {/* Column 5: IRS Tax Classification */}
                    <td className="py-3.5 px-3">
                      <div className="flex flex-col gap-0.5">
                        <span className={`inline-flex items-center gap-1 text-[11px] font-mono font-bold px-2 py-0.5 rounded border max-w-fit ${
                          tx.taxClassification.taxableEvent 
                            ? 'bg-amber-50 text-amber-900 border-amber-200' 
                            : 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}>
                          <FileText className="w-3 h-3 text-slate-500" />
                          {tx.taxClassification.formMapping}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {tx.taxClassification.taxableEvent ? `Taxable: $${tx.taxClassification.taxableAmountUSD.toFixed(2)}` : 'Cost Basis Recorded'}
                        </span>
                      </div>
                    </td>

                    {/* Column 6: Net Amount */}
                    <td className={`py-3.5 px-3 text-right font-mono font-bold text-sm ${
                      isReversed ? 'text-slate-400 line-through' : isPositive ? 'text-emerald-700' : 'text-slate-900'
                    }`}>
                      {isReversed ? '' : (isPositive ? '+' : '-')}${tx.netAmountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>

                    {/* Column 7: View Receipt */}
                    <td className="py-3.5 px-4 text-center">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedReceipt(tx);
                        }}
                        className="py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-900 hover:text-white text-slate-800 text-[11px] font-bold transition-all inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                      >
                        <Receipt className="w-3 h-3" />
                        <span>View Slip</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Cryptographic Proof Verification Notice */}
      <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-600">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            All receipts contain irreversible SHA-256 cryptographic signatures compatible with IRS, HMRC, and Swiss FINMA tax filings.
          </span>
        </div>
        <button
          type="button"
          onClick={handleExportCSV}
          className="text-xs font-mono font-bold text-amber-700 hover:text-amber-800 shrink-0 cursor-pointer underline flex items-center gap-1"
        >
          <span>Download All Tax Schedules</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* Render Receipt Modal */}
      <TransactionReceiptModal
        isOpen={Boolean(selectedReceipt)}
        onClose={() => setSelectedReceipt(null)}
        transaction={selectedReceipt}
      />
    </div>
  );
};
