import { UserWalletData, LinkedCardItem, LinkedBankAccountItem, LinkedCryptoWalletItem } from '../types/wallet';

export const INITIAL_USER_WALLETS: UserWalletData = {
  barterGoods: [
    {
      id: 'bg-1',
      name: '100oz 24K Imperial Gold Ingot (999.9)',
      category: 'Precious Metals & Bullion',
      quantity: 5,
      unitLabel: 'ingots',
      estimatedUnitValue: 288000,
      condition: 'Mint',
      description: 'LBMA certified 100oz fine gold bullion hallmarked with Final Finance seal, stored in Zurich Freeport.',
      location: 'Swiss Alpine Vault 1',
      sku: 'GOLD-100OZ-001',
      tags: ['Gold', 'Bullion', 'LBMA', 'Allocated'],
      imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'bg-2',
      name: 'Geneva Celestial Tourbillon Platinum Horology',
      category: 'Luxury Goods & Watches',
      quantity: 2,
      unitLabel: 'pieces',
      estimatedUnitValue: 145000,
      condition: 'Certified Vault',
      description: 'Astronomical celestial complications with sapphire crystal casing and certificate of authenticity.',
      location: 'Geneva Freeport Custody',
      sku: 'WATCH-TOURB-02',
      tags: ['Horology', 'Platinum', 'Luxury'],
      imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'bg-3',
      name: 'Enterprise High-Density AI GPU Rig (8x H100 SXM5)',
      category: 'Hardware & Compute',
      quantity: 3,
      unitLabel: 'clusters',
      estimatedUnitValue: 320000,
      condition: 'Brand New',
      description: 'Liquid-cooled enterprise datacenter compute units with 640GB aggregate HBM3 VRAM.',
      location: 'Frankfurt Equinix DC',
      sku: 'GPU-H100-NODE',
      tags: ['Compute', 'AI Hardware', 'Enterprise'],
      imageUrl: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=800&q=80'
    }
  ],
  barterServices: [
    {
      id: 'bs-1',
      name: 'Smart Contract Formal Verification & Zero-Day Audit',
      category: 'Cybersecurity & Auditing',
      availableUnits: 40,
      unitType: 'Hours',
      hourlyRateValue: 350,
      deliverableDescription: 'Complete mathematical verification, EVM bytecode security proofs, and formal audit certification.',
      turnaroundTime: '3-5 Business Days',
      skills: ['EVM', 'Formal Verification', 'Security Audit', 'Rust', 'Solidity']
    },
    {
      id: 'bs-2',
      name: 'Sovereign Multi-Asset Legal & Cross-Border Escrow Retainer',
      category: 'Financial Advisory & Legal',
      availableUnits: 25,
      unitType: 'Hours',
      hourlyRateValue: 600,
      deliverableDescription: 'Institutional cross-border legal opinions, Freeport escrow title custody, and tax compliance structuring.',
      turnaroundTime: '24-48 Hours',
      skills: ['Swiss Law', 'Escrow Custody', 'Maritime Law', 'Tax Advisory']
    }
  ],
  finalCoins: [
    {
      id: 'fc-admin-subsidy-signup',
      name: 'Final Admin Coin',
      symbol: 'AFNL',
      balance: 142000,
      unitPriceUSD: 0,
      change24h: 3.84,
      utility: 'Initial 4000 AFNL signup grant & continuous 0.1 AFNL/min (~4,000/mo) subsidy accrual.'
    },

  ],
  stableCoins: [
    {
      id: 'sc-1',
      name: 'USD Coin (Centre Consortium)',
      symbol: 'USDC',
      balance: 350000,
      unitPriceUSD: 1.00,
      peggedCurrency: 'USD',
      yieldAPY: 5.4,
      network: 'Polygon & Ethereum'
    },
    {
      id: 'sc-2',
      name: 'PAX Gold (LBMA Gold Backed)',
      symbol: 'PAXG',
      balance: 120,
      unitPriceUSD: 2880.00,
      peggedCurrency: '1oz Fine Gold',
      yieldAPY: 3.8,
      network: 'Ethereum Mainnet'
    },
    {
      id: 'sc-3',
      name: 'Euro Coin (Circle)',
      symbol: 'EURC',
      balance: 100000,
      unitPriceUSD: 1.09,
      peggedCurrency: 'EUR',
      yieldAPY: 4.6,
      network: 'Base L2'
    }
  ],
  fiatCurrencies: [
    {
      id: 'fi-1',
      name: 'United States Dollar (Treasury Reserve)',
      code: 'USD',
      symbol: '$',
      balance: 482776,
      exchangeRateToUSD: 1.00,
      accountType: 'Prime Checking & Fedwire',
      institution: 'JPMorgan Chase N.A. (NY)'
    },
    {
      id: 'fi-2',
      name: 'Swiss Franc (Depository Escrow)',
      code: 'CHF',
      symbol: 'CHF ',
      balance: 0,
      exchangeRateToUSD: 1.15,
      accountType: 'Institutional Escrow',
      institution: 'UBS Switzerland AG (Zurich)'
    },
    {
      id: 'fi-3',
      name: 'British Pound Sterling',
      code: 'GBP',
      symbol: '£',
      balance: 0,
      exchangeRateToUSD: 1.30,
      accountType: 'Commercial Treasury',
      institution: 'Barclays Private Bank (London)'
    }
  ],
  cryptoCurrencies: [
    {
      id: 'cr-1',
      name: 'Bitcoin (Glacier Cold Storage)',
      symbol: 'BTC',
      balance: 8.54,
      unitPriceUSD: 94800.00,
      change24h: 3.45,
      network: 'Bitcoin Mainnet (SegWit)',
      walletAddress: 'bc1q9d83274fak9201f829a'
    },
    {
      id: 'cr-2',
      name: 'Ethereum (Validator Staking)',
      symbol: 'ETH',
      balance: 65.20,
      unitPriceUSD: 2820.00,
      change24h: 2.15,
      network: 'Ethereum Mainnet',
      walletAddress: '0x71C83952fA98246E28198751'
    },
    {
      id: 'cr-3',
      name: 'Solana (High Frequency Clearing)',
      symbol: 'SOL',
      balance: 420.00,
      unitPriceUSD: 195.00,
      change24h: 6.80,
      network: 'Solana Network',
      walletAddress: '7XwK8f921a9LzP201948xX'
    }
  ],
  linkedCards: [
    {
      id: 'card-1',
      cardholderName: 'ALEXANDER STERLING',
      cardNumberLast4: '4829',
      brand: 'visa',
      cardType: 'debit',
      expiryMonth: '08',
      expiryYear: '29',
      bankName: 'JPMorgan Chase Reserve',
      isDefault: true,
      addedAt: '2026-01-15T10:00:00Z',
      billingZip: '10005'
    },
    {
      id: 'card-2',
      cardholderName: 'ALEXANDER STERLING',
      cardNumberLast4: '9104',
      brand: 'mastercard',
      cardType: 'credit',
      expiryMonth: '11',
      expiryYear: '28',
      bankName: 'Black Card Sovereign World Elite',
      isDefault: false,
      addedAt: '2026-02-01T14:30:00Z',
      billingZip: '10005'
    }
  ],
  linkedBankAccounts: [
    {
      id: 'bank-1',
      accountHolderName: 'Alexander Sterling',
      bankName: 'JPMorgan Chase & Co.',
      accountType: 'Checking',
      routingNumberMasked: '••••0210',
      accountNumberLast4: '8831',
      currency: 'USD',
      country: 'United States',
      isDefault: true,
      status: 'Instant FedNow Connected',
      addedAt: '2026-01-12T08:00:00Z',
      balanceUSD: 145000
    },
    {
      id: 'bank-2',
      accountHolderName: 'Alexander Sterling Treasury LLC',
      bankName: 'UBS Switzerland AG (Zurich)',
      accountType: 'Escrow Deposit',
      routingNumberMasked: '••••UBSW',
      accountNumberLast4: '4920',
      currency: 'CHF',
      country: 'Switzerland',
      swiftBic: 'UBSWCHZH80A',
      isDefault: false,
      status: 'Verified',
      addedAt: '2026-01-20T14:15:00Z',
      balanceUSD: 310000
    }
  ],
  linkedCryptoWallets: [
    {
      id: 'cw-1',
      walletName: 'MetaMask',
      walletType: 'metamask',
      address: '0x71C83952fA98246E28198751B9204A81E99B3654',
      network: 'Ethereum',
      isPrimary: true,
      connectedAt: '2026-01-10T12:00:00Z',
      balanceUSD: 184500,
      ensOrDomain: 'alexander.eth'
    },
    {
      id: 'cw-2',
      walletName: 'Phantom Wallet',
      walletType: 'phantom',
      address: '7XwK8f921a9LzP201948xXkLmNpQrStUvWxYzAbCdEf',
      network: 'Solana',
      isPrimary: false,
      connectedAt: '2026-02-05T09:15:00Z',
      balanceUSD: 81900,
      ensOrDomain: 'sterling.sol'
    },
    {
      id: 'cw-3',
      walletName: 'Ledger Nano X (Hardware Cold)',
      walletType: 'ledger',
      address: 'bc1q9d83274fak9201f829amznq810482937401k9',
      network: 'Bitcoin',
      isPrimary: false,
      connectedAt: '2026-02-12T18:40:00Z',
      balanceUSD: 809592,
      ensOrDomain: 'glacier-vault-1'
    }
  ]
};

export function getStoredUserWallets(userId: string): UserWalletData {
  try {
    const saved = localStorage.getItem(`final_finance_wallets_${userId}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Clean and sanitize finalCoins
      const rawFinalCoins = parsed.finalCoins || INITIAL_USER_WALLETS.finalCoins;
      const sanitizedFinalCoins = (rawFinalCoins || [])
        .filter((c: any) => c.id !== 'fc-2' && c.symbol !== 'sAFNL' && c.symbol !== 'FLC' && c.name !== 'Final Liquidity Credit' && !c.name?.toLowerCase().includes('staked final'))
        .map((c: any) => {
          const updatedName = c.name === 'Admin Final Coin (Native Treasury)' ? 'Final Admin Coin' : (c.name === 'Admin Final Coin' ? 'Final Admin Coin' : c.name);
          const { apyReward, ...rest } = c;
          let utility = rest.utility;
          let balance = rest.balance;
          if (utility && typeof utility === 'string') {
            if (utility.includes('Final Liquidity Credit')) {
              utility = utility.replace('Final Liquidity Credit', 'Creator Initial Allocation');
            }
          }
          if (balance === 2000000) {
            balance = 0;
            if (utility && typeof utility === 'string') {
              utility = utility.replace('2,000,000', '0').replace('2000000', '0');
            }
          }
          if (updatedName === 'Final Admin Coin') {
            rest.unitPriceUSD = 0;
          }
          return { ...rest, name: updatedName, utility, balance, unitPriceUSD: rest.unitPriceUSD || 0 };
        });

      return {
        ...INITIAL_USER_WALLETS,
        ...parsed,
        barterGoods: parsed.barterGoods || INITIAL_USER_WALLETS.barterGoods,
        barterServices: parsed.barterServices || INITIAL_USER_WALLETS.barterServices,
        finalCoins: sanitizedFinalCoins.length > 0 ? sanitizedFinalCoins : INITIAL_USER_WALLETS.finalCoins,
        stableCoins: parsed.stableCoins || INITIAL_USER_WALLETS.stableCoins,
        fiatCurrencies: parsed.fiatCurrencies || INITIAL_USER_WALLETS.fiatCurrencies,
        cryptoCurrencies: parsed.cryptoCurrencies || INITIAL_USER_WALLETS.cryptoCurrencies,
        linkedCards: parsed.linkedCards || INITIAL_USER_WALLETS.linkedCards,
        linkedBankAccounts: parsed.linkedBankAccounts || INITIAL_USER_WALLETS.linkedBankAccounts,
        linkedCryptoWallets: parsed.linkedCryptoWallets || INITIAL_USER_WALLETS.linkedCryptoWallets,
      };
    }
  } catch (err) {
    console.warn('Failed to load wallets from localStorage', err);
  }
  return INITIAL_USER_WALLETS;
}

export function saveStoredUserWallets(userId: string, data: UserWalletData): void {
  try {
    localStorage.setItem(`final_finance_wallets_${userId}`, JSON.stringify(data));
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      try {
        const evt = typeof CustomEvent === 'function'
          ? new CustomEvent('final_finance_wallets_updated', { detail: { userId, data } })
          : new Event('final_finance_wallets_updated');
        window.dispatchEvent(evt);
      } catch {
        try {
          window.dispatchEvent(new Event('final_finance_wallets_updated'));
        } catch {
          // Ignore if dispatch is restricted
        }
      }
    }
  } catch (err) {
    console.warn('Failed to save wallets to localStorage', err);
  }
}
