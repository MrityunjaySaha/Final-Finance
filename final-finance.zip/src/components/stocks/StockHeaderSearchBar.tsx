import React, { useState, useRef, useEffect } from 'react';
import { StockItem, StockMarketWay } from '../../types/stocks';
import { Search, TrendingUp, TrendingDown, ChevronRight, X, Sparkles, Building2, Zap, ShieldCheck, Coins, User, Building } from 'lucide-react';
import { matchStockSearch } from '../../utils/stockWalletBridge';

interface StockHeaderSearchBarProps {
  stocks: StockItem[];
  watchlist: string[];
  ownedTickers: string[];
  activeMarket?: StockMarketWay | 'all' | 'social';
  onSelectStock: (stock: StockItem) => void;
  onQuickTrade?: (stock: StockItem, side: 'buy' | 'sell') => void;
}

export const StockHeaderSearchBar: React.FC<StockHeaderSearchBarProps> = ({
  stocks,
  watchlist,
  ownedTickers,
  activeMarket = 'all',
  onSelectStock,
  onQuickTrade,
}) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredStocks = query.trim()
    ? stocks.filter((s) => matchStockSearch(s, query))
    : [];

  const getMarketBadge = (marketType?: StockMarketWay) => {
    switch (marketType) {
      case 'final':
        return { label: 'Final Stock ($AFNL)', bg: 'bg-amber-100 text-amber-900 border-amber-300' };
      case 'stable':
        return { label: 'Stable Stock ($USDC)', bg: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
      case 'fiat':
        return { label: 'Fiat Stock ($USD)', bg: 'bg-indigo-100 text-indigo-900 border-indigo-300' };
      case 'crypto':
        return { label: 'Crypto Stock ($BTC)', bg: 'bg-purple-100 text-purple-900 border-purple-300' };
      default:
        return { label: 'Equity', bg: 'bg-slate-100 text-slate-800 border-slate-200' };
    }
  };

  const getPlaceholder = () => {
    switch (activeMarket) {
      case 'final':
        return 'Search Final & Personal Stocks ($ALEX, $HYPR, $AFNL-EQ, personal)...';
      case 'stable':
        return 'Search Stable & Business Stocks ($BSYN, $VLT-YLD, business)...';
      case 'fiat':
        return 'Search Fiat Business Stocks ($NEXA, $AERO, USD, corporate)...';
      case 'crypto':
        return 'Search Crypto Business Stocks ($SOLN, $QBIT, crypto)...';
      default:
        return 'Search stocks ($NVDA, $TSLA), category, or investor (e.g. Nancy Pelosi)...';
    }
  };

  return (
    <div ref={containerRef} className="relative w-full z-30">
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={query}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          placeholder={getPlaceholder()}
          className="w-full pl-10 pr-10 py-2.5 bg-white border border-slate-200 hover:border-slate-300 focus:border-amber-500 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-400/20 font-sans shadow-2xs transition-all"
        />
        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setIsOpen(false);
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Instant Dropdown Search Results */}
      {isOpen && query.trim() && (
        <div className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden max-h-[380px] overflow-y-auto divide-y divide-slate-100 z-50 animate-in fade-in zoom-in-95 duration-100">
          <div className="px-4 py-2 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-[11px] font-mono font-bold text-slate-500">
            <span className="flex items-center gap-1.5 text-slate-800">
              <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
              Equities &amp; ETFs ({filteredStocks.length})
            </span>
            <span className="text-emerald-700 text-[10px]">
              {activeMarket !== 'all' ? `Mode: ${activeMarket.toUpperCase()} MARKET` : 'Personal & Corporate Stocks'}
            </span>
          </div>

          {filteredStocks.length === 0 ? (
            <div className="py-8 px-4 text-center text-slate-500 text-xs">
              <Building2 className="w-6 h-6 mx-auto mb-2 text-slate-300" />
              <p className="font-semibold text-slate-700">No equities matching "{query}"</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Try searching by issuance coin ($AFNL, $USDC, $USD, $BTC), category ("personal", "business"), ticker, or company name.
              </p>
            </div>
          ) : (
            filteredStocks.map((stock) => {
              const isPos = stock.changeUSD >= 0;
              const isOwned = ownedTickers.includes(stock.ticker);
              const isFollowed = watchlist.includes(stock.ticker);
              const badge = getMarketBadge(stock.marketType);
              const isInCurrentMarket = activeMarket === 'all' || stock.marketType === activeMarket;
              const isPersonal = stock.issuanceType === 'personal' || stock.assetCategory === 'personal' || stock.sector === 'Sovereign Reserves';

              return (
                <div
                  key={stock.ticker}
                  onClick={() => {
                    onSelectStock(stock);
                    setIsOpen(false);
                    setQuery('');
                  }}
                  className={`p-3 transition-colors flex items-center justify-between gap-3 cursor-pointer group ${
                    isInCurrentMarket ? 'hover:bg-amber-50/40 bg-white' : 'hover:bg-slate-50 bg-slate-50/50 opacity-80'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center font-mono font-bold text-xs shrink-0 shadow-2xs group-hover:bg-amber-600 transition-colors">
                      {stock.ticker}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-mono font-bold text-xs text-slate-900 group-hover:text-amber-800">
                          ${stock.ticker}
                        </span>
                        <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${badge.bg}`}>
                          {badge.label}
                        </span>
                        {isPersonal && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-800 border border-purple-200">
                            Personal Stock
                          </span>
                        )}
                        {stock.issuanceCoinSymbol && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                            Coin: ${stock.issuanceCoinSymbol}
                          </span>
                        )}
                        {isOwned && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                            Owned
                          </span>
                        )}
                        {isFollowed && !isOwned && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                            ★ Watchlist
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 truncate font-medium mt-0.5">
                        {stock.name} • <span className="text-slate-400 text-[11px]">{stock.sector}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right font-mono">
                      <div className="text-xs sm:text-sm font-bold text-slate-900">
                        ${stock.price.toFixed(2)}
                      </div>
                      <div className={`text-[11px] font-bold ${isPos ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {isPos ? '+' : ''}{stock.changePercent.toFixed(2)}%
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-600 transition-colors" />
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
