import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  PieChart,
  RefreshCw,
  Coins,
  Hexagon,
  DollarSign,
  Bitcoin,
  Archive,
  Briefcase,
  TrendingUp,
  CreditCard,
  ArrowLeft,
  Search,
  BarChart3,
  Check,
  ArrowDownLeft,
  Building2,
  Clock,
  Plus,
  Wallet,
  Loader2,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { UserWalletData } from '../types/wallet';
import { getStoredUserWallets } from '../data/defaultWallets';
import { INITIAL_STOCKS, INITIAL_USER_STOCK_POSITIONS } from '../data/stocksData';
import { StockItem, StockPosition } from '../types/stocks';
import { getStoredStockPositions } from '../utils/stockWalletBridge';
import { getAllLoans, getLoanRemainingBalance } from '../services/loanService';
import { AccountDepositModal, DepositTargetAssetClass } from './dashboard/AccountDepositModal';
import { AccountPayModal } from './dashboard/AccountPayModal';
import { StripeSetupModal } from './settings/StripeSetupModal';
import { LinkBankCardModal } from './stocks/LinkBankCardModal';
import { StripeSavedPaymentMethod } from '../services/stripeClientService';
import { PrivyWalletBalancesResponse } from '../services/privyClientService';
import {
  PAYMENT_METHODS_UPDATED_EVENT,
  VerifiedCryptoWalletSummary,
  loadVerifiedPaymentSources,
} from '../utils/paymentMethodsBridge';
import { dispatchGlobalNotification } from '../utils/notificationService';
import { BarterIOUsPanel } from './common/BarterIOUsPanel';
import { PieChart as RePieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';

export type InventoryTab = 'overview' | 'stocks' | 'fiat' | 'stable' | 'final' | 'crypto' | 'barter';

export interface AssetInventoryPageProps {
  currentUser: AuthSession;
  onNavigateBack?: () => void;
  backLabel?: string;
  initialTab?: InventoryTab;
  onOpenDepositModal?: (vault?: any) => void;
  onOpenInstantSwap?: () => void;
  onOpenBarterModal?: (listing?: any) => void;
  onSelectStock?: (stock: StockItem) => void;
  onOpenFundraising?: () => void;
}

export const AssetInventoryPage: React.FC<AssetInventoryPageProps> = ({
  currentUser,
  onNavigateBack,
  backLabel = 'Back to Dashboard',
  initialTab = 'overview',
  onOpenDepositModal,
  onOpenBarterModal,
  onSelectStock,
  onOpenFundraising,
}) => {
  const userId = currentUser?.id || 'guest';
  const [activeTab, setActiveTab] = useState<InventoryTab>(initialTab);
  const [barterSubTab, setBarterSubTab] = useState<'goods' | 'services'>('goods');

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Live Wallet Data
  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(userId));

  // Verified Payment Methods (Stripe banks & cards + Privy crypto wallets + on-chain balances)
  const [verifiedBanks, setVerifiedBanks] = useState<StripeSavedPaymentMethod[]>([]);
  const [verifiedCards, setVerifiedCards] = useState<StripeSavedPaymentMethod[]>([]);
  const [verifiedCryptoWallets, setVerifiedCryptoWallets] = useState<VerifiedCryptoWalletSummary[]>([]);
  const [onChainBalances, setOnChainBalances] = useState<PrivyWalletBalancesResponse | null>(null);
  const [stripeConfigured, setStripeConfigured] = useState(false);
  const [isLoadingPaymentMethods, setIsLoadingPaymentMethods] = useState(false);

  // Live Stock Positions & Stocks
  const [stocks] = useState<StockItem[]>(INITIAL_STOCKS);
  const [positions, setPositions] = useState<StockPosition[]>(() =>
    getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS)
  );

  // Live Liabilities / Debt
  const [debt, setDebt] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(`final_debt_${userId}`);
      if (stored !== null) return Math.max(0, Number(stored) || 0);
    } catch {
      // ignore
    }
    return 140621.03;
  });

  // Loans from loanService
  const [loansVersion, setLoansVersion] = useState(0);
  const allLoans = useMemo(() => getAllLoans(), [loansVersion]);

  const activeBorrowedLoans = useMemo(() => {
    return allLoans.filter(
      (l) => (l.borrowerId === userId || l.borrowerHandle === `@${userId}`) && l.status === 'active'
    );
  }, [allLoans, userId]);

  const activeLentLoans = useMemo(() => {
    return allLoans.filter(
      (l) => (l.lenderId === userId || l.lenderHandle === `@${userId}`) && l.status === 'active'
    );
  }, [allLoans, userId]);

  const borrowedLoansUSD = useMemo(() => {
    return activeBorrowedLoans.reduce(
      (sum, l) => sum + (l.coinSymbol === 'AFNL' ? 0 : getLoanRemainingBalance(l)),
      0
    );
  }, [activeBorrowedLoans]);

  const lentLoansUSD = useMemo(() => {
    return activeLentLoans.reduce(
      (sum, l) => sum + (l.coinSymbol === 'AFNL' ? 0 : getLoanRemainingBalance(l)),
      0
    );
  }, [activeLentLoans]);

  // Modals & Feedback
  const [isDepositCurrencyModalOpen, setIsDepositCurrencyModalOpen] = useState(false);
  const [depositInitialClass, setDepositInitialClass] = useState<DepositTargetAssetClass>('fiat');
  const [depositInitialCurrency, setDepositInitialCurrency] = useState<string>('USD');

  const [isPayDebtModalOpen, setIsPayDebtModalOpen] = useState(false);
  const [payModalInitialSourceId, setPayModalInitialSourceId] = useState<string | undefined>(undefined);

  const [isStripeSetupOpen, setIsStripeSetupOpen] = useState(false);
  const [stripeSetupMode, setStripeSetupMode] = useState<'card' | 'us_bank_account'>('us_bank_account');
  const [isCryptoVerifyModalOpen, setIsCryptoVerifyModalOpen] = useState(false);

  const [toastMessage, setToastMessage] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3800);
  }, []);

  const refreshVerifiedSources = useCallback(
    async (withOnChain = false) => {
      if (!currentUser) return;
      setIsLoadingPaymentMethods(true);
      try {
        const res = await loadVerifiedPaymentSources(currentUser, {
          fetchOnChainBalances: withOnChain,
        });
        setStripeConfigured(res.stripeConfigured);
        setVerifiedBanks(res.banks);
        setVerifiedCards(res.cards);
        setVerifiedCryptoWallets(res.cryptoWallets);
        if (withOnChain) {
          setOnChainBalances(res.onChainBalances || null);
        }
        setWalletData(getStoredUserWallets(userId));
      } catch {
        // ignore network hiccups
      } finally {
        setIsLoadingPaymentMethods(false);
      }
    },
    [currentUser, userId]
  );

  // Re-fetch all dynamic data
  const refreshAllData = useCallback(() => {
    setIsRefreshing(true);
    setWalletData(getStoredUserWallets(userId));
    setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
    setLoansVersion((v) => v + 1);

    try {
      const stored = localStorage.getItem(`final_debt_${userId}`);
      if (stored !== null) setDebt(Math.max(0, Number(stored) || 0));
    } catch {
      // ignore
    }

    refreshVerifiedSources(true).finally(() => {
      setTimeout(() => setIsRefreshing(false), 300);
    });
  }, [userId, refreshVerifiedSources]);

  useEffect(() => {
    refreshVerifiedSources(true);
  }, [refreshVerifiedSources]);

  // Synchronize across events
  useEffect(() => {
    const handleWalletUpdate = () => {
      setWalletData(getStoredUserWallets(userId));
    };
    const handleStockUpdate = () => {
      setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
    };
    const handleDebtUpdate = (e: any) => {
      if (e.detail?.debt !== undefined) {
        setDebt(Math.max(0, Number(e.detail.debt) || 0));
      } else {
        try {
          const stored = localStorage.getItem(`final_debt_${userId}`);
          if (stored !== null) setDebt(Math.max(0, Number(stored) || 0));
        } catch {
          // ignore
        }
      }
    };
    const handleLoansUpdate = () => {
      setLoansVersion((v) => v + 1);
    };
    const handlePaymentMethodsUpdate = () => {
      refreshVerifiedSources(true);
    };

    window.addEventListener('final_finance_wallets_updated', handleWalletUpdate);
    window.addEventListener('final_finance_stock_positions_updated', handleStockUpdate);
    window.addEventListener('final_debt_updated', handleDebtUpdate);
    window.addEventListener('final_finance_loans_updated', handleLoansUpdate);
    window.addEventListener('final_finance_listings_updated', handleWalletUpdate);
    window.addEventListener(PAYMENT_METHODS_UPDATED_EVENT, handlePaymentMethodsUpdate);
    window.addEventListener('storage', refreshAllData);

    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleWalletUpdate);
      window.removeEventListener('final_finance_stock_positions_updated', handleStockUpdate);
      window.removeEventListener('final_debt_updated', handleDebtUpdate);
      window.removeEventListener('final_finance_loans_updated', handleLoansUpdate);
      window.removeEventListener('final_finance_listings_updated', handleWalletUpdate);
      window.removeEventListener(PAYMENT_METHODS_UPDATED_EVENT, handlePaymentMethodsUpdate);
      window.removeEventListener('storage', refreshAllData);
    };
  }, [userId, refreshAllData, refreshVerifiedSources]);

  const openCurrencyDeposit = (assetClass: DepositTargetAssetClass, currencyCode: string) => {
    setDepositInitialClass(assetClass);
    setDepositInitialCurrency(currencyCode);
    setIsDepositCurrencyModalOpen(true);
  };

  const openDebtPayoffWithSource = (sourceId?: string) => {
    setPayModalInitialSourceId(sourceId);
    setIsPayDebtModalOpen(true);
  };

  const handleOpenLinkRail = (type: 'bank' | 'card' | 'crypto') => {
    if (type === 'bank') {
      setStripeSetupMode('us_bank_account');
      setIsStripeSetupOpen(true);
    } else if (type === 'card') {
      setStripeSetupMode('card');
      setIsStripeSetupOpen(true);
    } else {
      setIsCryptoVerifyModalOpen(true);
    }
  };

  // Calculations
  const stocksTotalUSD = useMemo(() => {
    return positions.reduce((s, p) => {
      const stk = stocks.find((st) => st.ticker === p.ticker);
      return s + p.shares * (stk ? stk.price : p.avgCostUSD);
    }, 0);
  }, [positions, stocks]);

  const stocksTotalGainUSD = useMemo(() => {
    return positions.reduce((s, p) => s + (p.totalGainUSD || 0), 0);
  }, [positions]);

  const fiatTotalUSD = useMemo(
    () => walletData.fiatCurrencies.reduce((acc, curr) => acc + curr.balance * curr.exchangeRateToUSD, 0),
    [walletData]
  );
  const fiatTotalUnits = useMemo(
    () => walletData.fiatCurrencies.reduce((acc, curr) => acc + curr.balance, 0),
    [walletData]
  );

  const stableTotalUSD = useMemo(
    () => walletData.stableCoins.reduce((acc, curr) => acc + curr.balance * curr.unitPriceUSD, 0),
    [walletData]
  );
  const stableTotalUnits = useMemo(
    () => walletData.stableCoins.reduce((acc, curr) => acc + curr.balance, 0),
    [walletData]
  );

  const finalTotalUnits = useMemo(
    () => walletData.finalCoins.reduce((acc, curr) => acc + curr.balance, 0),
    [walletData]
  );

  const cryptoTotalUSD = useMemo(
    () => walletData.cryptoCurrencies.reduce((acc, curr) => acc + curr.balance * curr.unitPriceUSD, 0),
    [walletData]
  );
  const cryptoTotalUnits = useMemo(
    () => walletData.cryptoCurrencies.reduce((acc, curr) => acc + curr.balance, 0),
    [walletData]
  );

  const barterGoodsTotalUnits = useMemo(
    () => (walletData.barterGoods || []).reduce((acc, curr) => acc + curr.quantity, 0),
    [walletData]
  );
  const barterServicesTotalCount = useMemo(
    () => (walletData.barterServices || []).length,
    [walletData]
  );

  const barterGoodsTotalUSD = useMemo(
    () => (walletData.barterGoods || []).reduce((acc, curr) => acc + curr.quantity * (curr.estimatedUnitValue || 0), 0),
    [walletData]
  );

  const totalVaultCapital =
    fiatTotalUSD + stableTotalUSD + cryptoTotalUSD + stocksTotalUSD + barterGoodsTotalUSD + lentLoansUSD;
  const totalLiabilities = debt + borrowedLoansUSD;
  const totalNetWorth = totalVaultCapital - totalLiabilities;

  const chartData = useMemo(
    () =>
      [
        { name: 'Stocks & Equities', value: stocksTotalUSD, color: '#6366f1' },
        { name: 'Crypto-Currency', value: cryptoTotalUSD, color: '#8b5cf6' },
        { name: 'Fiat Treasury', value: fiatTotalUSD, color: '#0ea5e9' },
        { name: 'Stable Coins', value: stableTotalUSD, color: '#10b981' },
        { name: 'Physical Commodities', value: barterGoodsTotalUSD, color: '#f59e0b' },
      ].filter((d) => d.value > 0),
    [stocksTotalUSD, cryptoTotalUSD, fiatTotalUSD, stableTotalUSD, barterGoodsTotalUSD]
  );

  const filteredBarterGoods = useMemo(() => {
    return (walletData.barterGoods || []).filter((item) => {
      const matchesSearch =
        searchQuery === '' ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory =
        categoryFilter === 'all' ||
        (categoryFilter === 'bullion' && item.category?.toLowerCase().includes('bullion')) ||
        (categoryFilter === 'luxury' && item.category?.toLowerCase().includes('luxury')) ||
        (categoryFilter === 'hardware' &&
          (item.category?.toLowerCase().includes('hardware') || item.category?.toLowerCase().includes('compute'))) ||
        (categoryFilter === 'acquired' && item.id.includes('acq'));

      return matchesSearch && matchesCategory;
    });
  }, [walletData.barterGoods, searchQuery, categoryFilter]);

  const filteredBarterServices = useMemo(() => {
    return (walletData.barterServices || []).filter((item) => {
      return (
        searchQuery === '' ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.deliverableDescription.toLowerCase().includes(searchQuery.toLowerCase())
      );
    });
  }, [walletData.barterServices, searchQuery]);

  const TABS: { id: InventoryTab; label: string; icon: React.ElementType; count?: number | string }[] = [
    { id: 'overview', label: 'Portfolio Overview', icon: PieChart },
    { id: 'fiat', label: 'Fiat Treasury', icon: DollarSign, count: walletData.fiatCurrencies.length },
    { id: 'stable', label: 'Stable Coins', icon: Coins, count: walletData.stableCoins.length },
    { id: 'crypto', label: 'Crypto-Currency', icon: Bitcoin, count: walletData.cryptoCurrencies.length },
    { id: 'barter', label: 'Goods & Services', icon: RefreshCw, count: barterGoodsTotalUnits + barterServicesTotalCount },
  ];

  return (
    <div className="w-full max-w-full overflow-x-hidden bg-slate-50 flex flex-col text-left">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-semibold shadow-2xl flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Deposit Funds Modal (Fiat, Stablecoin, Crypto via verified Bank/Card/Wallet/Treasury) */}
      <AccountDepositModal
        isOpen={isDepositCurrencyModalOpen}
        onClose={() => setIsDepositCurrencyModalOpen(false)}
        currentUser={currentUser}
        walletData={walletData}
        verifiedBanks={verifiedBanks}
        verifiedCards={verifiedCards}
        verifiedCryptoWallets={verifiedCryptoWallets}
        initialAssetClass={depositInitialClass}
        initialCurrencyCode={depositInitialCurrency}
        onOpenLinkMethod={handleOpenLinkRail}
        onDepositCompleted={(res) => {
          setWalletData(getStoredUserWallets(userId));
          showToast(
            `Deposited ${res.addedUnits.toLocaleString(undefined, { maximumFractionDigits: res.targetClass === 'crypto' ? 6 : 2 })} ${res.targetCurrency} ($${res.amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}) via ${res.sourceLabel}.`
          );
        }}
      />

      {/* Debt Payoff Modal (Verified Bank/Card/Wallet OR any held Fiat/Stable/Crypto balance) */}
      <AccountPayModal
        isOpen={isPayDebtModalOpen}
        onClose={() => setIsPayDebtModalOpen(false)}
        negativeBalance={-totalLiabilities}
        accountDebtUSD={debt}
        borrowedLoans={activeBorrowedLoans}
        currentUser={currentUser}
        walletData={walletData}
        verifiedBanks={verifiedBanks}
        verifiedCards={verifiedCards}
        verifiedCryptoWallets={verifiedCryptoWallets}
        initialSourceId={payModalInitialSourceId}
        onOpenLinkMethod={handleOpenLinkRail}
        onPaymentCompleted={(res) => {
          setWalletData(getStoredUserWallets(userId));
          setLoansVersion((v) => v + 1);
          try {
            const stored = localStorage.getItem(`final_debt_${userId}`);
            if (stored !== null) setDebt(Math.max(0, Number(stored) || 0));
          } catch {
            // ignore
          }
          showToast(
            `Paid $${res.paymentAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} toward debt via ${res.sourceLabel}.`
          );
        }}
      />

      {/* Link Verified Bank / Card Modal (Stripe) */}
      <StripeSetupModal
        isOpen={isStripeSetupOpen}
        mode={stripeSetupMode}
        currentUser={currentUser}
        stripeConfigured={stripeConfigured}
        onClose={() => setIsStripeSetupOpen(false)}
        onSuccess={(msg) => {
          showToast(msg);
          dispatchGlobalNotification({
            title: stripeSetupMode === 'us_bank_account' ? 'Verified Bank Account Linked' : 'Verified Payment Card Linked',
            description: msg,
            type: 'wallet',
            targetTab: 'dashboard',
            showToast: false,
            tone: 'success',
          });
          refreshVerifiedSources(false);
        }}
      />

      {/* Verify Crypto Wallet Modal */}
      <LinkBankCardModal
        userId={userId}
        isOpen={isCryptoVerifyModalOpen}
        initialTab="crypto"
        lockTab={true}
        onClose={() => setIsCryptoVerifyModalOpen(false)}
        onSuccess={(_type, label) => {
          const msg = `Verified & connected ${label}.`;
          showToast(msg);
          dispatchGlobalNotification({
            title: 'Verified Crypto Wallet Connected',
            description: msg,
            type: 'wallet',
            targetTab: 'dashboard',
            showToast: false,
            tone: 'success',
          });
          refreshVerifiedSources(true);
        }}
      />

      {/* Top Sticky Header - Centered, without asset icon */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 rounded-t-2xl">
        <div className="max-w-7xl mx-auto px-3 sm:px-5 py-3 flex flex-wrap items-center justify-center gap-2.5 text-center">
          <div className="flex flex-wrap items-center justify-center gap-3 min-w-0">
            {onNavigateBack && (
              <button
                type="button"
                onClick={onNavigateBack}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer border border-slate-200 whitespace-nowrap shrink-0"
                title={backLabel}
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">{backLabel}</span>
                <span className="sm:hidden">Back</span>
              </button>
            )}
            <div className="min-w-0 text-center">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight truncate">
                Asset Inventory
              </h1>
              <p className="text-[11px] text-slate-500 hidden sm:block truncate">
                Multi-currency Fiat, Stablecoins &amp; Crypto · Verified Banks, Cards &amp; Debt Settlement
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 shrink-0">
            <button
              type="button"
              onClick={refreshAllData}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
              title="Refresh Assets & Verified Accounts"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-indigo-600' : 'text-slate-500'}`} />
              <span className="hidden md:inline">Sync Assets</span>
            </button>

            <button
              type="button"
              onClick={() => openCurrencyDeposit('fiat', 'USD')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <ArrowDownLeft className="w-3.5 h-3.5" />
              <span>Deposit Funds</span>
            </button>

            {totalLiabilities > 0 && (
              <button
                type="button"
                onClick={() => openDebtPayoffWithSource(undefined)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Pay Off Debt</span>
              </button>
            )}

            {onOpenDepositModal && (
              <button
                type="button"
                onClick={() => onOpenDepositModal()}
                className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <span>Deposit Vault Asset</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-2 sm:p-4 lg:p-5 flex flex-col lg:flex-row gap-4 lg:gap-5 min-w-0">
        {/* Left Sidebar - Centered */}
        <div className="lg:w-64 xl:w-72 shrink-0 text-center min-w-0">
          <div className="bg-white rounded-2xl border border-slate-200 p-4 sticky top-24 space-y-4 text-center">
            {/* Executive Valuation Summary */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3 text-center">
              <div className="space-y-0.5 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Total Vault Capital
                </span>
                <p className="text-lg font-bold text-slate-900 font-mono tabular-nums">
                  ${totalVaultCapital.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-[10px] text-slate-500">Gross asset valuation</p>
              </div>

              {totalLiabilities > 0 && (
                <div className="pt-2.5 border-t border-slate-200 space-y-1.5 text-center">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-[10px] font-bold text-rose-600 uppercase tracking-wider">
                      Outstanding Debt
                    </span>
                    <span className="text-[10px] font-mono font-bold text-rose-700">DUE</span>
                  </div>
                  <p className="text-sm font-bold text-rose-600 font-mono tabular-nums">
                    -${totalLiabilities.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <button
                    type="button"
                    onClick={() => openDebtPayoffWithSource(undefined)}
                    className="w-full mt-1 py-1.5 px-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Pay Off Debt</span>
                  </button>
                </div>
              )}

              <div className="pt-2.5 border-t border-slate-200 space-y-0.5 text-center">
                <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider block">
                  Net Asset Value (NAV)
                </span>
                <p className="text-xl font-extrabold text-slate-900 font-mono tabular-nums">
                  ${totalNetWorth.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>

            {/* Verified Linked Methods Quick Status */}
            <div className="p-3 rounded-xl border border-slate-200 bg-white space-y-2 text-center">
              <div className="flex items-center justify-center gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  Verified Funding Rails
                </span>
                {isLoadingPaymentMethods && <Loader2 className="w-3 h-3 animate-spin text-slate-400" />}
              </div>
              <div className="grid grid-cols-3 gap-1.5 text-center font-mono tabular-nums">
                <button
                  type="button"
                  onClick={() => (verifiedBanks.length > 0 ? setActiveTab('fiat') : handleOpenLinkRail('bank'))}
                  className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                >
                  <span className="text-xs font-bold text-slate-900 block">{verifiedBanks.length}</span>
                  <span className="text-[10px] font-sans text-slate-500">Banks</span>
                </button>
                <button
                  type="button"
                  onClick={() => (verifiedCards.length > 0 ? setActiveTab('fiat') : handleOpenLinkRail('card'))}
                  className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                >
                  <span className="text-xs font-bold text-slate-900 block">{verifiedCards.length}</span>
                  <span className="text-[10px] font-sans text-slate-500">Cards</span>
                </button>
                <button
                  type="button"
                  onClick={() => (verifiedCryptoWallets.length > 0 ? setActiveTab('crypto') : handleOpenLinkRail('crypto'))}
                  className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                >
                  <span className="text-xs font-bold text-slate-900 block">{verifiedCryptoWallets.length}</span>
                  <span className="text-[10px] font-sans text-slate-500">Wallets</span>
                </button>
              </div>
            </div>

            {/* Navigation Tabs - Centered */}
            <nav className="space-y-1">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer text-center ${
                      isActive
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{tab.label}</span>
                    {tab.count !== undefined && (
                      <span
                        className={`text-[10px] font-mono tabular-nums px-1.5 py-0.5 rounded font-bold ${
                          isActive ? 'bg-indigo-700 text-white' : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Right Content Area */}
        <div className="flex-1 space-y-5 min-w-0 overflow-hidden">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-5 min-w-0">
              {/* Asset Allocation Chart Card */}
              <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 flex flex-col md:flex-row items-center gap-6 min-w-0 overflow-hidden">
                <div className="w-full md:w-1/2 h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={75}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <RechartsTooltip
                        formatter={(value: any) => [
                          `$${Number(value || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                          'Valuation',
                        ]}
                      />
                      <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '10px' }} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>

                <div className="w-full md:w-1/2 grid grid-cols-2 gap-3">
                  {[
                    { label: 'Crypto Assets', value: cryptoTotalUSD, color: 'text-purple-600', sub: `${walletData.cryptoCurrencies.length} currencies held` },
                    { label: 'Fiat Reserves', value: fiatTotalUSD, color: 'text-sky-600', sub: `${walletData.fiatCurrencies.length} currencies held` },
                    { label: 'Stablecoins', value: stableTotalUSD, color: 'text-emerald-600', sub: `${walletData.stableCoins.length} currencies held` },
                    { label: 'Physical Commodities', value: barterGoodsTotalUSD, color: 'text-amber-600', sub: `${barterGoodsTotalUnits} Physical Units` },
                  ].map((stat, i) => (
                    <div key={i} className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-col justify-between text-center">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{stat.label}</p>
                      <div>
                        <p className={`text-sm sm:text-base font-bold font-mono tabular-nums ${stat.color}`}>
                          ${stat.value.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </p>
                        <p className="text-[10px] text-slate-500 mt-0.5">{stat.sub}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Per-Currency Holdings Breakdown across Fiat, Stablecoins & Crypto */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 min-w-0">
                {/* Fiat Currencies Breakdown */}
                <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col justify-between space-y-4 min-w-0 overflow-hidden">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-sky-600" />
                        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                          Fiat Currencies ({walletData.fiatCurrencies.length})
                        </h3>
                      </div>
                      <span className="text-xs font-bold font-mono tabular-nums text-slate-900">
                        ${fiatTotalUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                      {walletData.fiatCurrencies.map((fiat) => (
                        <div key={fiat.id} className="py-2 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <span className="text-xs font-bold font-mono text-slate-900">{fiat.code}</span>
                            <span className="text-[11px] text-slate-500 block truncate">{fiat.institution}</span>
                          </div>
                          <div className="text-right font-mono tabular-nums shrink-0">
                            <span className="text-xs font-bold text-slate-900 block">
                              {fiat.symbol}{fiat.balance.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              ${(fiat.balance * fiat.exchangeRateToUSD).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => openCurrencyDeposit('fiat', walletData.fiatCurrencies[0]?.code || 'USD')}
                      className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-slate-900 hover:bg-black text-white text-[11px] font-bold transition-colors cursor-pointer text-center"
                    >
                      + Deposit Fiat
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('fiat')}
                      className="py-2 px-3 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-[11px] font-semibold transition-colors cursor-pointer shrink-0"
                    >
                      Manage
                    </button>
                  </div>
                </div>

                {/* Stablecoins Breakdown */}
                <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col justify-between space-y-4 min-w-0 overflow-hidden">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <Coins className="w-4 h-4 text-emerald-600" />
                        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                          Stablecoins ({walletData.stableCoins.length})
                        </h3>
                      </div>
                      <span className="text-xs font-bold font-mono tabular-nums text-slate-900">
                        ${stableTotalUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                      {walletData.stableCoins.map((coin) => (
                        <div key={coin.id} className="py-2 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <span className="text-xs font-bold font-mono text-slate-900">{coin.symbol}</span>
                            <span className="text-[11px] text-slate-500 block truncate">
                              {coin.network} · {coin.yieldAPY}% APY
                            </span>
                          </div>
                          <div className="text-right font-mono tabular-nums shrink-0">
                            <span className="text-xs font-bold text-slate-900 block">
                              {coin.balance.toLocaleString(undefined, { maximumFractionDigits: 2 })} {coin.symbol}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              ${(coin.balance * coin.unitPriceUSD).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => openCurrencyDeposit('stable_coin', walletData.stableCoins[0]?.symbol || 'USDC')}
                      className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-slate-900 hover:bg-black text-white text-[11px] font-bold transition-colors cursor-pointer text-center"
                    >
                      + Deposit Stablecoin
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('stable')}
                      className="py-2 px-3 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-[11px] font-semibold transition-colors cursor-pointer shrink-0"
                    >
                      Manage
                    </button>
                  </div>
                </div>

                {/* Cryptocurrencies Breakdown */}
                <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col justify-between space-y-4 min-w-0 overflow-hidden">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <Bitcoin className="w-4 h-4 text-purple-600" />
                        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                          Crypto ({walletData.cryptoCurrencies.length})
                        </h3>
                      </div>
                      <span className="text-xs font-bold font-mono tabular-nums text-slate-900">
                        ${cryptoTotalUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                      {walletData.cryptoCurrencies.map((coin) => (
                        <div key={coin.id} className="py-2 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <span className="text-xs font-bold font-mono text-slate-900">{coin.symbol}</span>
                            <span className="text-[11px] text-slate-500 block truncate">{coin.network}</span>
                          </div>
                          <div className="text-right font-mono tabular-nums shrink-0">
                            <span className="text-xs font-bold text-slate-900 block">
                              {coin.balance.toLocaleString(undefined, { maximumFractionDigits: 4 })} {coin.symbol}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              ${(coin.balance * coin.unitPriceUSD).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => openCurrencyDeposit('crypto', walletData.cryptoCurrencies[0]?.symbol || 'BTC')}
                      className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-slate-900 hover:bg-black text-white text-[11px] font-bold transition-colors cursor-pointer text-center"
                    >
                      + Deposit Crypto
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('crypto')}
                      className="py-2 px-3 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-[11px] font-semibold transition-colors cursor-pointer shrink-0"
                    >
                      Manage
                    </button>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: STOCKS & EQUITIES */}
          {activeTab === 'stocks' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-indigo-600" />
                    Stocks &amp; Public Equities ({positions.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Live valuation of public shares, dividend allocations, and personal/corporate equity
                  </p>
                </div>
                <div className="font-mono tabular-nums text-left sm:text-right">
                  <p className="text-base font-bold text-slate-900">
                    ${stocksTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className={`text-xs font-bold ${stocksTotalGainUSD >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {stocksTotalGainUSD >= 0 ? '+' : ''}${stocksTotalGainUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} Unrealized P&amp;L
                  </p>
                </div>
              </div>

              {positions.length === 0 ? (
                <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
                  <BarChart3 className="w-10 h-10 text-slate-300 mx-auto" />
                  <h3 className="font-bold text-slate-800 text-sm">No Stock Positions Held</h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    You currently have no open equities. Open the Stock Market Exchange to acquire sovereign or market equities.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {positions.map((pos) => {
                    const stk = stocks.find((s) => s.ticker === pos.ticker);
                    const currentPrice = stk ? stk.price : pos.currentPriceUSD;
                    const positionVal = pos.shares * currentPrice;
                    const costBasis = pos.shares * pos.avgCostUSD;
                    const gainUSD = positionVal - costBasis;
                    const gainPct = costBasis > 0 ? (gainUSD / costBasis) * 100 : 0;

                    return (
                      <div
                        key={pos.ticker}
                        onClick={() => {
                          if (stk && onSelectStock) onSelectStock(stk);
                        }}
                        className={`bg-white p-5 rounded-2xl border border-slate-200 hover:border-indigo-300 transition-colors flex flex-col justify-between space-y-4 ${
                          stk && onSelectStock ? 'cursor-pointer' : ''
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold font-mono text-sm px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                                {pos.ticker}
                              </span>
                              <span className="text-xs text-slate-500">{pos.sector}</span>
                            </div>
                            <h3 className="font-bold text-slate-900 text-sm mt-1">{pos.name}</h3>
                          </div>
                          <div className="text-right font-mono tabular-nums">
                            <p className="text-sm font-bold text-slate-900">
                              ${positionVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                            <p className="text-[11px] text-slate-500">{pos.shares.toLocaleString()} shares</p>
                          </div>
                        </div>

                        <div className="pt-3 border-t border-slate-100 grid grid-cols-3 gap-2 text-xs font-mono tabular-nums">
                          <div>
                            <span className="text-[10px] text-slate-400 block uppercase">Avg Cost</span>
                            <span className="font-bold text-slate-700">${pos.avgCostUSD.toFixed(2)}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400 block uppercase">Market Price</span>
                            <span className="font-bold text-slate-900">${currentPrice.toFixed(2)}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] text-slate-400 block uppercase">Return</span>
                            <span className={`font-bold ${gainUSD >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {gainUSD >= 0 ? '+' : ''}${gainUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })} ({gainPct.toFixed(1)}%)
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: FIAT TREASURY */}
          {activeTab === 'fiat' && (
            <div className="space-y-5 text-center">
              <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-slate-200 text-center">
                <h2 className="text-lg font-bold text-slate-900 flex items-center justify-center gap-2 text-center">
                  <DollarSign className="w-5 h-5 text-sky-600 shrink-0" />
                  <span>Fiat Currency Treasury ({walletData.fiatCurrencies.length})</span>
                </h2>
                <div className="flex flex-col items-center justify-center gap-2.5 text-center">
                  <div className="font-mono tabular-nums text-center">
                    <p className="text-base font-bold text-slate-900">
                      ${fiatTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-slate-500">{fiatTotalUnits.toLocaleString()} total units</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => openCurrencyDeposit('fiat', walletData.fiatCurrencies[0]?.code || 'USD')}
                    className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <ArrowDownLeft className="w-3.5 h-3.5" />
                    <span>Deposit Fiat</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.fiatCurrencies.map((fiat) => {
                  const usdVal = fiat.balance * fiat.exchangeRateToUSD;
                  return (
                    <div key={fiat.id} className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between items-center text-center space-y-4">
                      <div className="flex flex-col items-center justify-center gap-2 text-center w-full">
                        <div className="flex flex-col items-center justify-center">
                          <div className="flex items-center justify-center gap-2 flex-wrap">
                            <span className="text-sm font-bold font-mono px-2 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-200">
                              {fiat.code}
                            </span>
                            <span className="text-xs text-slate-500">{fiat.accountType}</span>
                          </div>
                          <h3 className="font-bold text-slate-900 text-sm mt-1.5 text-center">{fiat.name}</h3>
                          <p className="text-[11px] text-slate-500 mt-0.5 flex items-center justify-center gap-1 text-center">
                            <Building2 className="w-3 h-3 shrink-0" />
                            <span>{fiat.institution}</span>
                          </p>
                        </div>
                        <div className="text-center font-mono tabular-nums pt-1">
                          <p className="text-base font-bold text-slate-900">
                            {fiat.symbol}{fiat.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </p>
                          <p className="text-xs text-slate-500">
                            ≈ ${usdVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                          </p>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-center gap-2 w-full">
                        <button
                          type="button"
                          onClick={() => openCurrencyDeposit('fiat', fiat.code)}
                          className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-slate-900 hover:bg-black text-white text-xs font-bold cursor-pointer whitespace-nowrap text-center"
                        >
                          Deposit {fiat.code}
                        </button>
                        {totalLiabilities > 0 && fiat.balance > 0 && (
                          <button
                            type="button"
                            onClick={() => openDebtPayoffWithSource(`inv-fiat-${fiat.code.toUpperCase()}`)}
                            className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer whitespace-nowrap text-center"
                          >
                            Pay Debt with {fiat.code}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Verified Bank Accounts & Payment Cards Section */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 text-center">
                <div className="flex flex-col items-center justify-center gap-3 pb-3 border-b border-slate-100 text-center">
                  <div className="text-center space-y-1">
                    <h3 className="text-sm font-bold text-slate-900 text-center">
                      Verified Bank Accounts &amp; Payment Cards
                    </h3>
                    <p className="text-xs text-slate-500 text-center">
                      Only issuer-verified cards and banks appear here and can be charged for deposits or debt payoff
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenLinkRail('bank')}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold text-slate-800 inline-flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
                    >
                      <Plus className="w-3.5 h-3.5 text-blue-600" />
                      <span>Link Bank</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenLinkRail('card')}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold text-slate-800 inline-flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
                    >
                      <Plus className="w-3.5 h-3.5 text-purple-600" />
                      <span>Link Card</span>
                    </button>
                  </div>
                </div>

                {verifiedBanks.length === 0 && verifiedCards.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">
                    No verified bank accounts or cards linked yet. Click Link Bank or Link Card to add one.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {verifiedBanks.map((bank) => (
                      <div key={bank.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col items-center justify-center gap-3 text-center">
                        <div className="flex flex-col items-center justify-center gap-2 min-w-0 text-center">
                          <div className="p-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 shrink-0">
                            <Building2 className="w-4 h-4" />
                          </div>
                          <div className="min-w-0 text-center">
                            <p className="text-xs font-bold text-slate-900 truncate">{bank.bankName || 'Verified Bank'}</p>
                            <p className="text-[11px] font-mono text-slate-500">
                              {bank.accountType || 'checking'} ••••{bank.last4} · Routing {bank.routingNumber || '••••'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center justify-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => openCurrencyDeposit('fiat', 'USD')}
                            className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-[11px] font-bold text-slate-800 cursor-pointer"
                          >
                            Deposit
                          </button>
                          {totalLiabilities > 0 && (
                            <button
                              type="button"
                              onClick={() => openDebtPayoffWithSource(`stripe-${bank.id}`)}
                              className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold cursor-pointer"
                            >
                              Pay Debt
                            </button>
                          )}
                        </div>
                      </div>
                    ))}

                    {verifiedCards.map((card) => (
                      <div key={card.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col items-center justify-center gap-3 text-center">
                        <div className="flex flex-col items-center justify-center gap-2 min-w-0 text-center">
                          <div className="p-2 rounded-lg bg-purple-50 border border-purple-200 text-purple-700 shrink-0">
                            <CreditCard className="w-4 h-4" />
                          </div>
                          <div className="min-w-0 text-center">
                            <p className="text-xs font-bold text-slate-900 uppercase truncate">
                              {card.brand || 'Card'} ••••{card.last4}
                            </p>
                            <p className="text-[11px] font-mono text-slate-500">
                              Exp {String(card.expMonth || 1).padStart(2, '0')}/{card.expYear || '----'} · {card.funding || 'card'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center justify-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => openCurrencyDeposit('fiat', 'USD')}
                            className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-[11px] font-bold text-slate-800 cursor-pointer"
                          >
                            Deposit
                          </button>
                          {totalLiabilities > 0 && (
                            <button
                              type="button"
                              onClick={() => openDebtPayoffWithSource(`stripe-${card.id}`)}
                              className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold cursor-pointer"
                            >
                              Pay Debt
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: STABLECOINS */}
          {activeTab === 'stable' && (
            <div className="space-y-5 text-center">
              <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-slate-200 text-center">
                <h2 className="text-lg font-bold text-slate-900 flex items-center justify-center gap-2 text-center">
                  <Coins className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>Yield-Bearing Stablecoins ({walletData.stableCoins.length})</span>
                </h2>
                <div className="flex flex-col items-center justify-center gap-2.5 text-center">
                  <div className="font-mono tabular-nums text-center">
                    <p className="text-base font-bold text-slate-900">
                      ${stableTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-emerald-600 font-bold">{stableTotalUnits.toLocaleString()} units</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => openCurrencyDeposit('stable_coin', walletData.stableCoins[0]?.symbol || 'USDC')}
                    className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <ArrowDownLeft className="w-3.5 h-3.5" />
                    <span>Deposit Stablecoin</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.stableCoins.map((coin) => {
                  const usdVal = coin.balance * coin.unitPriceUSD;
                  return (
                    <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between items-center text-center space-y-4">
                      <div className="flex flex-col items-center justify-center gap-2 text-center w-full">
                        <div className="flex flex-col items-center justify-center">
                          <div className="flex items-center justify-center gap-2 flex-wrap">
                            <span className="text-sm font-bold font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                              {coin.symbol}
                            </span>
                            <span className="text-[11px] font-mono text-slate-500">{coin.network}</span>
                          </div>
                          <h3 className="font-bold text-slate-900 text-sm mt-1.5 text-center">{coin.name}</h3>
                          <p className="text-[11px] text-slate-500 mt-0.5 text-center">
                            Peg: {coin.peggedCurrency} · +{coin.yieldAPY}% APY
                          </p>
                        </div>
                        <div className="text-center font-mono tabular-nums pt-1">
                          <p className="text-base font-bold text-slate-900">
                            {coin.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {coin.symbol}
                          </p>
                          <p className="text-xs text-slate-500">
                            ≈ ${usdVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                          </p>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-center gap-2 w-full">
                        <button
                          type="button"
                          onClick={() => openCurrencyDeposit('stable_coin', coin.symbol)}
                          className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-slate-900 hover:bg-black text-white text-xs font-bold cursor-pointer whitespace-nowrap text-center"
                        >
                          Deposit {coin.symbol}
                        </button>
                        {totalLiabilities > 0 && coin.balance > 0 && (
                          <button
                            type="button"
                            onClick={() => openDebtPayoffWithSource(`inv-stable-${coin.symbol.toUpperCase()}`)}
                            className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer whitespace-nowrap text-center"
                          >
                            Pay Debt with {coin.symbol}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: CRYPTO-CURRENCY */}
          {activeTab === 'crypto' && (
            <div className="space-y-5 text-center">
              <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-slate-200 text-center">
                <h2 className="text-lg font-bold text-slate-900 flex items-center justify-center gap-2 text-center">
                  <Bitcoin className="w-5 h-5 text-purple-600 shrink-0" />
                  <span>Digital Assets &amp; Crypto Vault ({walletData.cryptoCurrencies.length})</span>
                </h2>
                <div className="flex flex-col items-center justify-center gap-2.5 text-center">
                  <div className="font-mono tabular-nums text-center">
                    <p className="text-base font-bold text-slate-900">
                      ${cryptoTotalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-slate-500">{cryptoTotalUnits.toLocaleString()} units</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => openCurrencyDeposit('crypto', walletData.cryptoCurrencies[0]?.symbol || 'BTC')}
                    className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <ArrowDownLeft className="w-3.5 h-3.5" />
                    <span>Deposit Crypto</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.cryptoCurrencies.map((coin) => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between items-center text-center space-y-4">
                    <div className="flex flex-col items-center justify-center gap-2 text-center w-full">
                      <div className="flex flex-col items-center justify-center">
                        <div className="flex items-center justify-center gap-2 flex-wrap">
                          <span className="text-sm font-bold font-mono px-2 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
                            {coin.symbol}
                          </span>
                          <span
                            className={`text-xs font-mono font-bold ${
                              coin.change24h >= 0 ? 'text-emerald-600' : 'text-rose-600'
                            }`}
                          >
                            {coin.change24h > 0 ? '+' : ''}
                            {coin.change24h}% 24h
                          </span>
                        </div>
                        <h3 className="font-bold text-slate-900 text-sm mt-1.5 text-center">{coin.name}</h3>
                        <p className="text-[11px] text-slate-500 font-mono mt-0.5 text-center">
                          {coin.network} · ${coin.unitPriceUSD.toLocaleString()}/unit
                        </p>
                      </div>
                      <div className="text-center font-mono tabular-nums pt-1">
                        <p className="text-base font-bold text-slate-900">
                          {coin.balance.toLocaleString(undefined, { maximumFractionDigits: 6 })} {coin.symbol}
                        </p>
                        <p className="text-xs text-slate-500">
                          ≈ ${(coin.balance * coin.unitPriceUSD).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-center gap-2 w-full">
                      <button
                        type="button"
                        onClick={() => openCurrencyDeposit('crypto', coin.symbol)}
                        className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-slate-900 hover:bg-black text-white text-xs font-bold cursor-pointer whitespace-nowrap text-center"
                      >
                        Deposit {coin.symbol}
                      </button>
                      {totalLiabilities > 0 && coin.balance > 0 && (
                        <button
                          type="button"
                          onClick={() => openDebtPayoffWithSource(`inv-crypto-${coin.symbol.toUpperCase()}`)}
                          className="flex-1 min-w-[120px] py-2 px-3 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer whitespace-nowrap text-center"
                        >
                          Pay Debt with {coin.symbol}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Connected Verified Web3 Wallets & Live On-Chain Balances */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 text-center">
                <div className="flex flex-col items-center justify-center gap-3 pb-3 border-b border-slate-100 text-center">
                  <div className="text-center space-y-1">
                    <h3 className="text-sm font-bold text-slate-900 flex items-center justify-center gap-2 text-center">
                      <Wallet className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Verified Connected Crypto Wallets</span>
                    </h3>
                    <p className="text-xs text-slate-500 text-center">
                      Only verified 0x wallets that passed on-chain or signature checks appear here
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => refreshVerifiedSources(true)}
                      disabled={isLoadingPaymentMethods}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 inline-flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isLoadingPaymentMethods ? 'animate-spin' : ''}`} />
                      <span>Refresh On-Chain</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenLinkRail('crypto')}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-bold text-slate-800 inline-flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
                    >
                      <Plus className="w-3.5 h-3.5 text-amber-600" />
                      <span>Verify Wallet</span>
                    </button>
                  </div>
                </div>

                {verifiedCryptoWallets.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">
                    No verified crypto wallets connected yet. Click Verify Wallet to link an on-chain address.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {verifiedCryptoWallets.map((w) => (
                      <div key={w.address} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col items-center justify-center gap-3 text-center">
                        <div className="min-w-0 text-center">
                          <p className="text-xs font-bold text-slate-900 text-center">{w.label}</p>
                          <p className="text-[11px] font-mono text-slate-500 break-all text-center">
                            {w.address} · {w.network}
                          </p>
                        </div>
                        <div className="flex items-center justify-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => openCurrencyDeposit('crypto', 'ETH')}
                            className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-[11px] font-bold text-slate-800 cursor-pointer"
                          >
                            Deposit Crypto
                          </button>
                          {totalLiabilities > 0 && (
                            <button
                              type="button"
                              onClick={() => openDebtPayoffWithSource(`wallet-${w.address.toLowerCase()}`)}
                              className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold cursor-pointer"
                            >
                              Pay Debt
                            </button>
                          )}
                        </div>
                      </div>
                    ))}

                    {onChainBalances && onChainBalances.tokens.length > 0 && (
                      <div className="pt-2 border-t border-slate-100 text-center">
                        <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 text-center">
                          Live On-Chain Balances ({onChainBalances.networkName})
                        </p>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {onChainBalances.tokens.map((tok) => (
                            <div key={`${tok.symbol}-${tok.address || 'native'}`} className="p-2.5 rounded-lg border border-slate-200 bg-white font-mono tabular-nums text-center">
                              <span className="text-xs font-bold text-slate-900 block">{tok.symbol}</span>
                              <span className="text-[11px] text-slate-600">{tok.balanceFormatted}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: PHYSICAL GOODS & COMMODITIES (BARTER) */}
          {activeTab === 'barter' && (
            <div className="space-y-6 text-center">
              <div className="flex flex-col items-center justify-center gap-3 pb-4 border-b border-slate-200 text-center">
                <h2 className="text-lg font-bold text-slate-900 flex items-center justify-center gap-2 text-center">
                  <Briefcase className="w-5 h-5 text-amber-600 shrink-0" />
                  <span>Physical Custody, Commodities &amp; Retainers</span>
                </h2>

                <div className="flex items-center justify-center">
                  <div className="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200">
                    <button
                      type="button"
                      onClick={() => setBarterSubTab('goods')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        barterSubTab === 'goods' ? 'bg-white text-slate-900' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Goods &amp; Bullion ({barterGoodsTotalUnits})
                    </button>
                    <button
                      type="button"
                      onClick={() => setBarterSubTab('services')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        barterSubTab === 'services' ? 'bg-white text-slate-900' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Services ({barterServicesTotalCount})
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center gap-3 text-center">
                <div className="relative w-full max-w-xl mx-auto">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search goods by name, location, hallmark, or description..."
                    className="w-full pl-10 pr-4 py-2 rounded-xl bg-white border border-slate-200 text-xs focus:outline-hidden focus:border-indigo-500 text-slate-900 text-center"
                  />
                </div>
                {barterSubTab === 'goods' && (
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {[
                      { id: 'all', label: 'All Items' },
                      { id: 'bullion', label: 'Bullion & Gold' },
                      { id: 'luxury', label: 'Luxury' },
                      { id: 'hardware', label: 'Compute & Tech' },
                      { id: 'acquired', label: 'Acquired via Market' },
                    ].map((f) => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setCategoryFilter(f.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                          categoryFilter === f.id
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {barterSubTab === 'goods' && (
                <div className="space-y-4 text-center">
                  {filteredBarterGoods.length === 0 ? (
                    <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-2 flex flex-col items-center justify-center">
                      <Archive className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-xs text-slate-500">No goods match your search or filter criteria.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {filteredBarterGoods.map((good) => (
                        <div
                          key={good.id}
                          className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col items-center justify-center gap-4 text-center"
                        >
                          {good.imageUrl && (
                            <div className="w-36 h-36 rounded-xl overflow-hidden shrink-0 bg-slate-100 border border-slate-200 mx-auto">
                              <img src={good.imageUrl} alt={good.name} className="w-full h-full object-cover" />
                            </div>
                          )}
                          <div className="w-full flex flex-col items-center justify-between text-center">
                            <div className="space-y-2 text-center w-full">
                              <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                                <div className="flex items-center justify-center gap-1.5 flex-wrap">
                                  <span className="text-xs font-bold text-amber-800">{good.category}</span>
                                  <span className="text-xs text-slate-500">· {good.condition}</span>
                                </div>
                                <h3 className="font-bold text-slate-900 text-base text-center">{good.name}</h3>
                                <div className="text-center font-mono tabular-nums pt-0.5">
                                  <p className="font-bold text-slate-900 text-base">
                                    ${(good.estimatedUnitValue * good.quantity).toLocaleString()}
                                  </p>
                                  <p className="text-xs text-slate-500">
                                    ${good.estimatedUnitValue.toLocaleString()} / {good.unitLabel.replace(/s$/, '')}
                                  </p>
                                </div>
                              </div>
                              <p className="text-xs text-slate-600 line-clamp-2 max-w-2xl mx-auto leading-relaxed text-center">
                                {good.description}
                              </p>
                            </div>

                            <div className="pt-3 mt-3 border-t border-slate-100 flex flex-col sm:flex-row flex-wrap items-center justify-center gap-2 sm:gap-4 text-xs font-mono w-full text-center">
                              <span className="text-slate-500">
                                {good.location || 'Freeport Vault'} {good.sku ? `· SKU ${good.sku}` : ''}
                              </span>
                              <span className="font-bold text-emerald-700 tabular-nums">
                                {good.quantity} {good.unitLabel} available
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {barterSubTab === 'services' && (
                <div className="space-y-4 text-center">
                  {filteredBarterServices.length === 0 ? (
                    <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-2 flex flex-col items-center justify-center">
                      <TrendingUp className="w-10 h-10 text-slate-300 mx-auto" />
                      <p className="text-xs text-slate-500">No services match your search query.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {filteredBarterServices.map((service) => (
                        <div key={service.id} className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col items-center justify-between space-y-3 text-center">
                          <div className="flex flex-col items-center justify-center gap-1.5 text-center w-full">
                            <span className="text-xs font-bold text-indigo-700">{service.category}</span>
                            <h3 className="font-bold text-slate-900 text-base text-center">{service.name}</h3>
                            <div className="text-center font-mono tabular-nums pt-0.5">
                              <p className="font-bold text-slate-900 text-base">
                                ${(service.hourlyRateValue * service.availableUnits).toLocaleString()}
                              </p>
                              <p className="text-xs text-slate-500">
                                ${service.hourlyRateValue.toLocaleString()} / {service.unitType.replace(/s$/, '')}
                              </p>
                            </div>
                          </div>
                          <p className="text-xs text-slate-600 leading-relaxed max-w-2xl mx-auto text-center">{service.deliverableDescription}</p>
                          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-center gap-4 text-xs font-mono w-full text-center">
                            {service.turnaroundTime && (
                              <span className="text-slate-500 flex items-center justify-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>{service.turnaroundTime}</span>
                              </span>
                            )}
                            <span className="font-bold text-indigo-700 tabular-nums">
                              {service.availableUnits} {service.unitType}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Persistent Mutual Barter IOUs & Dual-Party Confirmations */}
              <div className="pt-4">
                <BarterIOUsPanel currentUser={currentUser} variant="light" />
              </div>
            </div>
          )}

          {/* TAB 7: FINAL COINS */}
          {activeTab === 'final' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <Hexagon className="w-5 h-5 text-amber-600" />
                    Final Coins Standard ({walletData.finalCoins.length})
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Non-convertible sovereign protocol units, continuous subsidy grants, and custom creator issuances
                  </p>
                </div>
                <div className="font-mono tabular-nums text-left sm:text-right">
                  <p className="text-base font-bold text-amber-900">{finalTotalUnits.toLocaleString()} AFNL</p>
                  <p className="text-xs text-emerald-600 font-bold">+0.1 AFNL/min active subsidy</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {walletData.finalCoins.map((coin) => (
                  <div key={coin.id} className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
                    <div className="flex justify-between items-start gap-3">
                      <div>
                        <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-200">
                          {coin.symbol}
                        </span>
                        <h3 className="font-bold text-slate-900 text-sm mt-1.5">{coin.name}</h3>
                        <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{coin.utility}</p>
                      </div>
                      <div className="text-right font-mono tabular-nums shrink-0">
                        <p className="text-base font-bold text-slate-900">
                          {coin.balance.toLocaleString()} {coin.symbol}
                        </p>
                        <p className="text-[11px] text-amber-800 font-semibold">Protocol Native</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
