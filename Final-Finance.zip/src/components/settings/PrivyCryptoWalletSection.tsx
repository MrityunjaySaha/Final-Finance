import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  useConnectWallet,
  usePrivy,
  useSendTransaction,
  useWallets,
} from '@privy-io/react-auth';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Coins,
  Copy,
  ExternalLink,
  Globe,
  Loader2,
  LogOut,
  Plus,
  RefreshCw,
  Send,
  ShieldCheck,
  Trash2,
  Wallet,
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import {
  DEFAULT_PRIVY_NETWORK_KEY,
  getPrivyNetworkByChainId,
  getPrivyNetworkByKey,
  PRIVY_NETWORKS,
  PrivyNetworkKey,
} from '../../config/privyConfig';
import {
  fetchPrivyServerConfig,
  fetchPrivyServerWallets,
  fetchPrivyWalletBalances,
  preparePrivyWalletTransfer,
  PrivyServerConfigResponse,
  PrivyServerManagedWallet,
  PrivyWalletBalancesResponse,
  sendPrivyServerWalletTx,
  syncPrivyWalletPreferences,
  verifyPrivySessionOnServer,
  verifyWalletAddressOnChain,
  verifyWalletSignatureOnServer,
  WalletTokenBalance,
} from '../../services/privyClientService';
import { emitPaymentMethodsUpdated } from '../../utils/paymentMethodsBridge';
import { calculatePrivyNetworkFee, formatInsufficientCurrencyError } from '../../utils/transactionFees';
import { applyCurrencyWalletDelta } from '../../utils/walletBalanceUpdater';
import { normalizeLedgerItem, recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { dispatchGlobalNotification } from '../../utils/notificationService';

interface PrivyCryptoWalletSectionProps {
  currentUser: AuthSession;
  onSuccessMessage?: (msg: string) => void;
  onSyncLegacyWallet?: (address: string, networkName: string, label: string) => void;
}

interface ManualExternalWallet {
  address: string;
  label: string;
  source: 'injected-browser' | 'manual-address';
  addedAt: string;
}

export const PrivyCryptoWalletSection: React.FC<PrivyCryptoWalletSectionProps> = ({
  currentUser,
  onSuccessMessage,
  onSyncLegacyWallet,
}) => {
  const { ready, authenticated, user, logout, getAccessToken } = usePrivy();
  const { wallets } = useWallets();
  const { sendTransaction } = useSendTransaction();

  const userStorageKey = currentUser.uid || currentUser.id || 'guest';
  const [selectedNetworkKey, setSelectedNetworkKey] = useState<PrivyNetworkKey>(DEFAULT_PRIVY_NETWORK_KEY);
  const [activeAddress, setActiveAddress] = useState<string>('');
  const [initTimedOut, setInitTimedOut] = useState(false);

  const [manualWallets, setManualWallets] = useState<ManualExternalWallet[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const raw = window.localStorage.getItem(`privy_manual_wallets_${userStorageKey}`);
      return raw ? (JSON.parse(raw) as ManualExternalWallet[]) : [];
    } catch {
      return [];
    }
  });
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualAddressInput, setManualAddressInput] = useState('');
  const [manualLabelInput, setManualLabelInput] = useState('');
  const [isVerifyingWallet, setIsVerifyingWallet] = useState(false);

  const [serverWallets, setServerWallets] = useState<PrivyServerManagedWallet[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const raw = window.localStorage.getItem(`privy_server_wallets_${userStorageKey}`);
      return raw ? (JSON.parse(raw) as PrivyServerManagedWallet[]) : [];
    } catch {
      return [];
    }
  });
  const [serverConfig, setServerConfig] = useState<PrivyServerConfigResponse | null>(null);
  const [balancesData, setBalancesData] = useState<PrivyWalletBalancesResponse | null>(null);
  const [isLoadingBalances, setIsLoadingBalances] = useState(false);
  const [isSwitchingNetwork, setIsSwitchingNetwork] = useState(false);
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [backendVerifyNote, setBackendVerifyNote] = useState('');

  const [customTokensByNetwork, setCustomTokensByNetwork] = useState<Record<string, string[]>>({});
  const [showAddTokenForm, setShowAddTokenForm] = useState(false);
  const [customTokenInput, setCustomTokenInput] = useState('');

  const [transferAsset, setTransferAsset] = useState<WalletTokenBalance | null>(null);
  const [transferTo, setTransferTo] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [isSendingTx, setIsSendingTx] = useState(false);
  const [lastTxHash, setLastTxHash] = useState<string | null>(null);

  const persistManualWallets = useCallback(
    (next: ManualExternalWallet[]) => {
      setManualWallets(next);
      if (typeof window !== 'undefined') {
        try {
          window.localStorage.setItem(`privy_manual_wallets_${userStorageKey}`, JSON.stringify(next));
        } catch {
          // ignore
        }
      }
      emitPaymentMethodsUpdated();
    },
    [userStorageKey]
  );


  const tryDirectInjectedConnect = useCallback(async (): Promise<boolean> => {
    if (typeof window === 'undefined') return false;
    const eth = (window as unknown as { ethereum?: { request?: (args: { method: string; params?: unknown[] }) => Promise<unknown> } }).ethereum;
    if (!eth?.request) return false;
    try {
      const accounts = (await eth.request({ method: 'eth_requestAccounts' })) as string[];
      const addr = Array.isArray(accounts) && accounts[0] ? accounts[0] : '';
      if (/^0x[a-fA-F0-9]{40}$/.test(addr)) {
        const challenge = `Verify wallet ownership for Final Finance\nAddress: ${addr}\nTimestamp: ${new Date().toISOString()}`;
        const signature = (await eth.request({
          method: 'personal_sign',
          params: [challenge, addr],
        })) as string;
        const verified = await verifyWalletSignatureOnServer({
          address: addr,
          message: challenge,
          signature,
        });
        const nextEntry: ManualExternalWallet = {
          address: verified.address,
          label: 'Verified Browser Wallet',
          source: 'injected-browser',
          addedAt: new Date().toISOString(),
        };
        persistManualWallets([
          nextEntry,
          ...manualWallets.filter((w) => w.address.toLowerCase() !== verified.address.toLowerCase()),
        ]);
        setActiveAddress(verified.address);
        setErrorMessage('');
        setShowManualForm(false);
        onSuccessMessage?.(`Verified & connected wallet ${verified.address.slice(0, 6)}...${verified.address.slice(-4)}.`);
        return true;
      }
    } catch (err: any) {
      if (err?.code === 4001) {
        setErrorMessage('Signature request cancelled. Wallet was not saved.');
        return true;
      }
      if (err?.message) {
        setErrorMessage(err.message);
        return true;
      }
    }
    return false;
  }, [manualWallets, onSuccessMessage, persistManualWallets]);

  const { connectWallet } = useConnectWallet({
    onSuccess: ({ wallet }) => {
      setErrorMessage('');
      setShowManualForm(false);
      onSuccessMessage?.(`Connected wallet ${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}.`);
      setActiveAddress(wallet.address);
    },
    onError: async (err) => {
      const rawErr = typeof err === 'string' ? err : '';
      const lower = rawErr.toLowerCase();
      if (lower.includes('exited') || lower.includes('user rejected') || lower.includes('cancel')) {
        setErrorMessage('');
        return;
      }

      if (lower.includes('generic_connect_wallet_error') || !rawErr) {
        const connectedDirectly = await tryDirectInjectedConnect();
        if (connectedDirectly) return;

        setErrorMessage('');
        setShowManualForm(true);
        return;
      }

      const connectedDirectly = await tryDirectInjectedConnect();
      if (connectedDirectly) return;

      setErrorMessage('');
      setShowManualForm(true);
    },
  });

  const selectedNetwork = useMemo(
    () => getPrivyNetworkByKey(selectedNetworkKey),
    [selectedNetworkKey]
  );

  useEffect(() => {
    if (ready) return;
    const timer = window.setTimeout(() => setInitTimedOut(true), 2000);
    return () => window.clearTimeout(timer);
  }, [ready]);

  const availableClientWallets = useMemo(() => {
    const seen = new Set<string>();
    return wallets.filter((w) => {
      const addr = w.address?.toLowerCase();
      if (!addr || seen.has(addr)) return false;
      seen.add(addr);
      return true;
    });
  }, [wallets]);

  type UnifiedWallet = {
    address: string;
    label: string;
    source: 'client-external' | 'privy-server-api' | 'injected-browser' | 'manual-address';
    chainId?: number | string;
    serverWalletId?: string;
    clientWallet?: (typeof availableClientWallets)[number];
  };

  const unifiedWallets: UnifiedWallet[] = useMemo(() => {
    const list: UnifiedWallet[] = [];
    const seen = new Set<string>();

    for (const w of availableClientWallets) {
      const isEmbedded = w.walletClientType === 'privy' || w.connectorType === 'embedded';
      if (isEmbedded) continue;
      const key = w.address.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      list.push({
        address: w.address,
        label: w.meta?.name || 'Connected Wallet',
        source: 'client-external',
        chainId: w.chainId,
        clientWallet: w,
      });
    }

    for (const mw of manualWallets) {
      const key = mw.address.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      list.push({
        address: mw.address,
        label: mw.label || 'External Wallet',
        source: mw.source,
      });
    }

    for (const sw of serverWallets) {
      const key = sw.address.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      list.push({
        address: sw.address,
        label: 'Connected Vault Wallet',
        source: 'privy-server-api',
        serverWalletId: sw.id,
      });
    }

    return list;
  }, [availableClientWallets, manualWallets, serverWallets]);

  const activeUnifiedWallet = useMemo(() => {
    if (unifiedWallets.length === 0) return null;
    if (activeAddress) {
      const found = unifiedWallets.find((w) => w.address.toLowerCase() === activeAddress.toLowerCase());
      if (found) return found;
    }
    return unifiedWallets[0];
  }, [unifiedWallets, activeAddress]);

  const activeClientWallet = activeUnifiedWallet?.clientWallet || null;

  useEffect(() => {
    let active = true;
    fetchPrivyServerConfig()
      .then((cfg) => {
        if (active) setServerConfig(cfg);
      })
      .catch(() => {});
    fetchPrivyServerWallets(userStorageKey)
      .then((list) => {
        if (active && Array.isArray(list) && list.length > 0) {
          setServerWallets((prev) => {
            const merged = [...list];
            for (const item of prev) {
              if (!merged.some((m) => m.address.toLowerCase() === item.address.toLowerCase())) {
                merged.push(item);
              }
            }
            try {
              window.localStorage.setItem(`privy_server_wallets_${userStorageKey}`, JSON.stringify(merged));
            } catch {
              // ignore
            }
            return merged;
          });
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [userStorageKey]);

  useEffect(() => {
    if (unifiedWallets.length > 0 && !activeUnifiedWallet) {
      setActiveAddress(unifiedWallets[0].address);
    } else if (activeUnifiedWallet && activeUnifiedWallet.address !== activeAddress) {
      setActiveAddress(activeUnifiedWallet.address);
    }
  }, [unifiedWallets, activeUnifiedWallet, activeAddress]);

  useEffect(() => {
    if (!activeUnifiedWallet?.address) return;
    const net = getPrivyNetworkByKey(selectedNetworkKey);
    onSyncLegacyWallet?.(activeUnifiedWallet.address, net.shortName, activeUnifiedWallet.label);
    syncPrivyWalletPreferences({
      userId: userStorageKey,
      walletAddress: activeUnifiedWallet.address,
      networkKey: selectedNetworkKey,
      customTokensByNetwork,
    }).catch(() => {});
  }, [activeUnifiedWallet?.address, activeUnifiedWallet?.label, selectedNetworkKey, customTokensByNetwork, userStorageKey]);

  useEffect(() => {
    if (!authenticated || !user?.id) {
      setBackendVerifyNote('');
      return;
    }
    let active = true;
    getAccessToken()
      .then((token) => {
        if (!token || !active) return null;
        return verifyPrivySessionOnServer({ accessToken: token, privyUserId: user.id });
      })
      .then((res) => {
        if (!active || !res) return;
        if (res.verified) {
          setBackendVerifyNote('Verified');
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [authenticated, user?.id, getAccessToken]);

  const loadBalances = useCallback(async () => {
    const addr = activeUnifiedWallet?.address;
    if (!addr) {
      setBalancesData(null);
      return;
    }
    setIsLoadingBalances(true);
    setErrorMessage('');
    try {
      const customTokens = customTokensByNetwork[selectedNetworkKey] || [];
      const data = await fetchPrivyWalletBalances({
        address: addr,
        network: selectedNetworkKey,
        customTokens,
      });
      setBalancesData(data);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Unable to load wallet balances.');
    } finally {
      setIsLoadingBalances(false);
    }
  }, [activeUnifiedWallet?.address, selectedNetworkKey, customTokensByNetwork]);

  useEffect(() => {
    loadBalances();
  }, [loadBalances]);

  const handleSelectNetwork = async (nextKey: PrivyNetworkKey) => {
    setSelectedNetworkKey(nextKey);
    setLastTxHash(null);
    setTransferAsset(null);
    setErrorMessage('');

    const target = getPrivyNetworkByKey(nextKey);
    if (activeClientWallet && typeof activeClientWallet.switchChain === 'function') {
      const walletChain = getPrivyNetworkByChainId(activeClientWallet.chainId);
      if (!walletChain || walletChain.chainId !== target.chainId) {
        setIsSwitchingNetwork(true);
        try {
          await activeClientWallet.switchChain(target.chainId);
        } catch (err: any) {
          console.debug('Wallet switchChain note:', err?.message || err);
        } finally {
          setIsSwitchingNetwork(false);
        }
      }
    }
  };

  const handleConnectButtonClick = async () => {
    setErrorMessage('');
    const connectedDirectly = await tryDirectInjectedConnect();
    if (connectedDirectly) return;

    if (ready) {
      try {
        connectWallet();
        return;
      } catch {
        // Fall through to inline 0x address form
      }
    }
    setShowManualForm(true);
  };

  const handleAddManualWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = manualAddressInput.trim();
    if (!/^0x[a-fA-F0-9]{40}$/.test(trimmed)) {
      setErrorMessage('Enter a valid 0x wallet address (42 characters).');
      return;
    }
    setErrorMessage('');
    setIsVerifyingWallet(true);
    try {
      const verified = await verifyWalletAddressOnChain({
        address: trimmed,
        network: selectedNetworkKey,
      });
      const nextEntry: ManualExternalWallet = {
        address: verified.address,
        label: manualLabelInput.trim() || 'Verified On-Chain Wallet',
        source: 'manual-address',
        addedAt: new Date().toISOString(),
      };
      const nextList = [
        nextEntry,
        ...manualWallets.filter((w) => w.address.toLowerCase() !== verified.address.toLowerCase()),
      ];
      persistManualWallets(nextList);
      setActiveAddress(verified.address);
      setManualAddressInput('');
      setManualLabelInput('');
      setShowManualForm(false);
      onSuccessMessage?.(
        `Verified wallet ${verified.address.slice(0, 6)}...${verified.address.slice(-4)} on-chain.`
      );
    } catch (err: any) {
      setErrorMessage(
        err?.message ||
          'This wallet address could not be verified on-chain and was not saved.'
      );
    } finally {
      setIsVerifyingWallet(false);
    }
  };

  const handleRemoveWallet = async (wallet: UnifiedWallet) => {
    setErrorMessage('');
    if (wallet.source === 'manual-address' || wallet.source === 'injected-browser') {
      const nextList = manualWallets.filter(
        (w) => w.address.toLowerCase() !== wallet.address.toLowerCase()
      );
      persistManualWallets(nextList);
      if (activeAddress.toLowerCase() === wallet.address.toLowerCase()) {
        setActiveAddress(nextList[0]?.address || '');
      }
      onSuccessMessage?.('Wallet disconnected.');
      return;
    }
    if (wallet.clientWallet && typeof wallet.clientWallet.disconnect === 'function') {
      try {
        await wallet.clientWallet.disconnect();
      } catch {
        // Fallback below
      }
    }
    if (authenticated) {
      await logout();
    }
    onSuccessMessage?.('Wallet disconnected.');
  };

  const handleCopyAddress = async () => {
    if (!activeUnifiedWallet?.address || typeof navigator === 'undefined') return;
    try {
      await navigator.clipboard.writeText(activeUnifiedWallet.address);
      setCopiedAddress(true);
      setTimeout(() => setCopiedAddress(false), 1800);
    } catch {
      // Ignore
    }
  };

  const handleAddCustomToken = (e: React.FormEvent) => {
    e.preventDefault();
    const addr = customTokenInput.trim();
    if (!/^0x[a-fA-F0-9]{40}$/.test(addr)) {
      setErrorMessage('Enter a valid token contract address starting with 0x (42 characters).');
      return;
    }
    setErrorMessage('');
    setCustomTokensByNetwork((prev) => {
      const existing = prev[selectedNetworkKey] || [];
      if (existing.some((a) => a.toLowerCase() === addr.toLowerCase())) return prev;
      return {
        ...prev,
        [selectedNetworkKey]: [...existing, addr],
      };
    });
    setCustomTokenInput('');
    setShowAddTokenForm(false);
  };

  const privyGas = useMemo(
    () =>
      calculatePrivyNetworkFee({
        networkKey: selectedNetworkKey,
        isErc20: transferAsset ? !transferAsset.isNative : false,
      }),
    [selectedNetworkKey, transferAsset]
  );

  const estimateTokenUSD = useCallback((symbol: string): number => {
    const sym = (symbol || '').toUpperCase();
    if (sym === 'USDC' || sym === 'USDT' || sym === 'DAI' || sym === 'PYUSD') return 1;
    if (sym === 'EURC') return 1.09;
    if (sym === 'PAXG') return 2880;
    if (sym === 'BTC' || sym === 'WBTC') return 94800;
    if (sym === 'ETH' || sym === 'WETH') return 2820;
    if (sym === 'SOL') return 195;
    if (sym === 'POL' || sym === 'MATIC') return 0.55;
    return 1;
  }, []);

  const recordPrivyTransferEffects = useCallback(
    (txHash: string, networkName: string, amountSent: number, recipientAddr: string) => {
      if (!transferAsset) return;
      const sym = transferAsset.symbol.toUpperCase();
      const unitUSD = estimateTokenUSD(sym);
      const baseUSD = Math.round(amountSent * unitUSD * 100) / 100;
      const totalUSD = Math.round((baseUSD + privyGas.feeUSD) * 100) / 100;
      const nowIso = new Date().toISOString();

      try {
        // Deduct from local wallet entry if present (non-blocking for external Web3 addresses)
        applyCurrencyWalletDelta({
          userId: userStorageKey,
          currencySymbol: sym,
          delta: -amountSent,
          requireSufficientBalance: false,
        });
      } catch {
        // ignore if external-only balance
      }

      try {
        const isStable = Boolean(transferAsset.isStablecoin);
        recordLedgerTransaction(
          userStorageKey,
          normalizeLedgerItem({
            id: `rec-privy-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            receiptNumber: `REC-WEB3-${Date.now().toString().slice(-6)}`,
            taxYear: new Date().getFullYear(),
            timestamp: nowIso.replace('T', ' ').slice(0, 19) + ' UTC',
            dateIso: nowIso,
            type: 'payment_settlement',
            category: 'money_outflow',
            mode: isStable ? 'stable_coin' : 'crypto',
            title: `Web3 Transfer: ${amountSent} ${sym} (${networkName})`,
            description: `Sent ${amountSent} ${sym} to ${recipientAddr} on ${networkName} via Privy Web3. Privy network gas fee: $${privyGas.feeUSD.toFixed(2)} (${privyGas.nativeUnits} ${privyGas.nativeSymbol}). Total: $${totalUSD.toFixed(2)}.`,
            amountUSD: baseUSD,
            feeUSD: privyGas.feeUSD,
            netAmountUSD: -totalUSD,
            sourceOrDestination: `Privy Web3 (${networkName})`,
            counterpartyOrIssuer: `${recipientAddr.slice(0, 6)}...${recipientAddr.slice(-4)}`,
            paymentCoinSymbol: sym,
            paymentCoinAmount: amountSent,
            taxClassification: {
              formMapping: 'Non-Taxable Transfer',
              taxableEvent: false,
              taxableAmountUSD: 0,
              holdingPeriod: 'N/A',
              taxDeductible: false,
              irsCategoryNote: 'On-chain Web3 transfer via Privy smart wallet with network gas fee recorded.',
            },
            status: 'Settled',
            clearingNode: `Privy ${networkName} RPC`,
            cryptographicHash: txHash,
            signature: `SIG-PRIVY-${txHash.slice(2, 10).toUpperCase()}`,
          })
        );
      } catch {
        // ignore ledger error
      }

      dispatchGlobalNotification({
        title: `Privy Web3 Transfer: ${amountSent} ${sym}`,
        description: `Sent to ${recipientAddr.slice(0, 6)}...${recipientAddr.slice(-4)} on ${networkName}. Privy Gas Fee: $${privyGas.feeUSD.toFixed(2)} (${privyGas.nativeUnits} ${privyGas.nativeSymbol}). Total: $${totalUSD.toFixed(2)}.`,
        type: 'wallet',
        targetTab: 'ledger',
        amount: totalUSD,
        currency: 'USD',
      });
    },
    [estimateTokenUSD, privyGas, transferAsset, userStorageKey]
  );

  const handleSubmitTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeUnifiedWallet?.address || !transferAsset) return;
    setErrorMessage('');
    setLastTxHash(null);

    const parsedAmount = parseFloat(transferAmount);
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) {
      setErrorMessage(`Please enter a valid ${transferAsset.symbol} amount greater than 0.`);
      return;
    }

    const availableAsset = Number(transferAsset.balanceFormatted || 0);
    if (transferAsset.isNative) {
      const requiredWithGas = parsedAmount + privyGas.nativeUnits;
      if (availableAsset + 1e-9 < requiredWithGas) {
        setErrorMessage(
          formatInsufficientCurrencyError({
            symbol: transferAsset.symbol,
            name: `${transferAsset.name} (incl. ${privyGas.nativeUnits} ${privyGas.nativeSymbol} Privy network fee)`,
            available: availableAsset,
            required: requiredWithGas,
            maxDecimals: 6,
          })
        );
        return;
      }
    } else {
      if (availableAsset + 1e-9 < parsedAmount) {
        setErrorMessage(
          formatInsufficientCurrencyError({
            symbol: transferAsset.symbol,
            name: transferAsset.name,
            available: availableAsset,
            required: parsedAmount,
            maxDecimals: 6,
          })
        );
        return;
      }
      const nativeGasAvail = Number(balancesData?.nativeToken?.balanceFormatted || 0);
      if (nativeGasAvail + 1e-9 < privyGas.nativeUnits) {
        setErrorMessage(
          formatInsufficientCurrencyError({
            symbol: privyGas.nativeSymbol,
            name: `${selectedNetwork.shortName} Privy Gas Fee`,
            available: nativeGasAvail,
            required: privyGas.nativeUnits,
            maxDecimals: 6,
          })
        );
        return;
      }
    }

    const recipientSnapshot = transferTo.trim();
    setIsSendingTx(true);

    try {
      if (activeUnifiedWallet.source === 'privy-server-api' && activeUnifiedWallet.serverWalletId) {
        const res = await sendPrivyServerWalletTx({
          walletId: activeUnifiedWallet.serverWalletId,
          fromAddress: activeUnifiedWallet.address,
          toAddress: recipientSnapshot,
          amount: transferAmount.trim(),
          network: selectedNetworkKey,
          assetType: transferAsset.isNative ? 'native' : 'erc20',
          tokenSymbol: transferAsset.symbol,
          tokenAddress: transferAsset.address,
          decimals: transferAsset.decimals,
        });

        setLastTxHash(res.hash);
        recordPrivyTransferEffects(res.hash, res.networkName, parsedAmount, recipientSnapshot);
        setTransferAmount('');
        setTransferTo('');
        onSuccessMessage?.(`Sent ${transferAsset.symbol} on ${res.networkName}.`);
        setTimeout(() => {
          loadBalances();
        }, 2500);
        return;
      }

      const prepared = await preparePrivyWalletTransfer({
        fromAddress: activeUnifiedWallet.address,
        toAddress: recipientSnapshot,
        amount: transferAmount.trim(),
        network: selectedNetworkKey,
        assetType: transferAsset.isNative ? 'native' : 'erc20',
        tokenSymbol: transferAsset.symbol,
        tokenAddress: transferAsset.address,
        decimals: transferAsset.decimals,
      });

      if (activeUnifiedWallet.source === 'injected-browser' || activeUnifiedWallet.source === 'manual-address') {
        const eth = (window as unknown as { ethereum?: { request?: (args: { method: string; params?: unknown[] }) => Promise<unknown> } }).ethereum;
        if (!eth?.request) {
          throw new Error('To send transactions from this address, connect a browser wallet extension like MetaMask or Coinbase Wallet.');
        }
        const txHash = (await eth.request({
          method: 'eth_sendTransaction',
          params: [
            {
              from: activeUnifiedWallet.address,
              to: prepared.transaction.to,
              data: prepared.transaction.data,
              value: prepared.transaction.value,
            },
          ],
        })) as string;
        setLastTxHash(txHash);
        recordPrivyTransferEffects(txHash, prepared.networkName, parsedAmount, recipientSnapshot);
        setTransferAmount('');
        setTransferTo('');
        onSuccessMessage?.(`Sent ${transferAsset.symbol} on ${prepared.networkName}.`);
        setTimeout(() => {
          loadBalances();
        }, 2500);
        return;
      }

      if (activeClientWallet && typeof activeClientWallet.switchChain === 'function') {
        try {
          await activeClientWallet.switchChain(prepared.chainId);
        } catch {
          // Proceed
        }
      }

      const result = await sendTransaction(
        {
          to: prepared.transaction.to,
          data: prepared.transaction.data,
          value: BigInt(prepared.transaction.value),
          chainId: prepared.chainId,
        },
        {
          address: activeUnifiedWallet.address,
        }
      );

      setLastTxHash(result.hash);
      recordPrivyTransferEffects(result.hash, prepared.networkName, parsedAmount, recipientSnapshot);
      setTransferAmount('');
      setTransferTo('');
      onSuccessMessage?.(`Sent ${transferAsset.symbol} on ${prepared.networkName}.`);
      setTimeout(() => {
        loadBalances();
      }, 2500);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Unable to submit wallet transaction.');
    } finally {
      setIsSendingTx(false);
    }
  };

  const allDisplayedTokens: WalletTokenBalance[] = useMemo(() => {
    if (!balancesData) return [];
    return [balancesData.nativeToken, ...balancesData.tokens];
  }, [balancesData]);

  return (
    <div className="p-4 sm:p-5 rounded-3xl border border-neutral-200 bg-white shadow-2xs text-center space-y-4">
      <div className="flex flex-col items-center justify-center text-center gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-700">
          <Wallet className="w-4 h-4" />
        </div>
        <div className="text-center">
          <div className="flex items-center justify-center gap-1.5 flex-wrap">
            <h3 className="text-sm font-bold text-slate-900">Crypto &amp; Stablecoins</h3>
            <span className="px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-bold inline-flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              <span>Web3</span>
            </span>
          </div>
        </div>

        {activeUnifiedWallet && (
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-xs">
              <Globe className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <select
                aria-label="Select blockchain network"
                value={selectedNetworkKey}
                onChange={(e) => handleSelectNetwork(e.target.value as PrivyNetworkKey)}
                disabled={isSwitchingNetwork}
                className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none cursor-pointer"
              >
                {PRIVY_NETWORKS.map((net) => (
                  <option key={net.key} value={net.key}>
                    {net.name}
                  </option>
                ))}
              </select>
              {isSwitchingNetwork && <Loader2 className="w-3 h-3 animate-spin text-emerald-600" />}
            </div>

            <button
              type="button"
              onClick={handleConnectButtonClick}
              className="px-3 py-1.5 rounded-xl border border-emerald-200 bg-emerald-50/60 hover:bg-emerald-100 text-emerald-900 text-xs font-bold transition-all inline-flex items-center justify-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Connect Another</span>
            </button>
            <button
              type="button"
              onClick={() => setShowManualForm((v) => !v)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-all inline-flex items-center justify-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add 0x Address</span>
            </button>
          </div>
        )}
      </div>

      {errorMessage && (
        <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex flex-col sm:flex-row items-center justify-center gap-2 text-center">
          <div className="flex items-center justify-center gap-1.5">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-700" />
            <span>{errorMessage}</span>
          </div>
          {activeUnifiedWallet && (
            <button
              type="button"
              onClick={loadBalances}
              className="px-2.5 py-1 rounded-lg bg-white border border-amber-200 text-amber-900 text-[11px] font-bold hover:bg-amber-100 cursor-pointer shrink-0"
            >
              Retry
            </button>
          )}
        </div>
      )}

      {showManualForm && (
        <form
          onSubmit={handleAddManualWallet}
          className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-2.5 max-w-md mx-auto text-left"
        >
          <p className="text-xs font-bold text-slate-800 text-center">Add Wallet Address</p>
          <input
            type="text"
            value={manualLabelInput}
            onChange={(e) => setManualLabelInput(e.target.value)}
            placeholder="Label (e.g. MetaMask Main)"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
          />
          <input
            type="text"
            required
            value={manualAddressInput}
            onChange={(e) => setManualAddressInput(e.target.value)}
            placeholder="Wallet address (0x...)"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono text-slate-900 focus:outline-none focus:border-emerald-500"
          />
          <div className="flex items-center justify-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowManualForm(false)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-slate-600 text-xs font-semibold hover:bg-slate-100 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isVerifyingWallet}
              className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold cursor-pointer disabled:opacity-50 inline-flex items-center gap-1.5"
            >
              {isVerifyingWallet ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Verifying On-Chain...</span>
                </>
              ) : (
                <span>Verify &amp; Save Wallet</span>
              )}
            </button>
          </div>
        </form>
      )}

      {!ready && !initTimedOut ? (
        <div className="p-6 rounded-2xl border border-neutral-200 text-center bg-neutral-50/60 flex items-center justify-center gap-2 text-xs text-slate-500">
          <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
          <span>Loading Crypto Wallets...</span>
        </div>
      ) : !activeUnifiedWallet ? (
        <div className="p-5 rounded-2xl border border-dashed border-neutral-200 text-center bg-neutral-50/60 flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={handleConnectButtonClick}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all cursor-pointer inline-flex items-center justify-center gap-1.5 shadow-xs"
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>Connect Wallet</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setErrorMessage('');
              setShowManualForm((v) => !v);
            }}
            className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-all cursor-pointer inline-flex items-center justify-center gap-1.5 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Enter 0x Address</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
            {unifiedWallets.length > 1 && (
              <div className="flex flex-wrap items-center justify-center gap-1.5 pb-2 border-b border-slate-200/70">
                {unifiedWallets.map((w) => {
                  const isCurrent = w.address.toLowerCase() === activeUnifiedWallet.address.toLowerCase();
                  return (
                    <button
                      key={w.address}
                      type="button"
                      onClick={() => setActiveAddress(w.address)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        isCurrent
                          ? 'bg-slate-900 text-white shadow-2xs'
                          : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {w.label} ({w.address.slice(0, 6)}...{w.address.slice(-4)})
                    </button>
                  );
                })}
              </div>
            )}

            <div className="flex flex-col items-center justify-center gap-2">
              <div className="flex items-center justify-center gap-1.5 flex-wrap">
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 text-[10px] font-bold uppercase tracking-wider">
                  {activeUnifiedWallet.label}
                </span>
                <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-900 text-[10px] font-bold">
                  {selectedNetwork.shortName}
                </span>
                {backendVerifyNote && (
                  <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-semibold inline-flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>{backendVerifyNote}</span>
                  </span>
                )}
              </div>

              <div className="flex items-center justify-center gap-2 flex-wrap">
                <code className="px-3 py-1 rounded-xl bg-white border border-slate-200 font-mono text-xs font-semibold text-slate-900 break-all">
                  {activeUnifiedWallet.address}
                </code>
                <button
                  type="button"
                  onClick={handleCopyAddress}
                  className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
                  title="Copy wallet address"
                >
                  {copiedAddress ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
                <a
                  href={`${selectedNetwork.explorerUrl}/address/${activeUnifiedWallet.address}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                  title={`View on ${selectedNetwork.shortName} explorer`}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={loadBalances}
                  disabled={isLoadingBalances}
                  className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${isLoadingBalances ? 'animate-spin' : ''}`} />
                  <span>Refresh Balances</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddTokenForm((v) => !v)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>Track Token</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleRemoveWallet(activeUnifiedWallet)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-200 text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                >
                  {activeUnifiedWallet.source === 'manual-address' ? (
                    <Trash2 className="w-3 h-3" />
                  ) : (
                    <LogOut className="w-3 h-3" />
                  )}
                  <span>Disconnect</span>
                </button>
              </div>
            </div>

            {showAddTokenForm && (
              <form
                onSubmit={handleAddCustomToken}
                className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-center gap-2 max-w-lg mx-auto"
              >
                <input
                  type="text"
                  value={customTokenInput}
                  onChange={(e) => setCustomTokenInput(e.target.value)}
                  placeholder={`Paste token contract address on ${selectedNetwork.shortName} (0x...)`}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-mono text-slate-800 focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold whitespace-nowrap cursor-pointer"
                >
                  Add Token
                </button>
              </form>
            )}
          </div>

          {isLoadingBalances && !balancesData ? (
            <div className="p-6 rounded-2xl border border-neutral-200 text-center bg-neutral-50/60 flex items-center justify-center gap-2 text-xs text-slate-500">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
              <span>Loading {selectedNetwork.shortName} token balances...</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-center">
              {allDisplayedTokens.map((token) => {
                const isSelectedForSend =
                  transferAsset?.symbol === token.symbol &&
                  transferAsset?.address === token.address;

                return (
                  <div
                    key={`${token.symbol}-${token.address || 'native'}`}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between items-center text-center ${
                      isSelectedForSend
                        ? 'border-emerald-400 bg-emerald-50/40 shadow-xs'
                        : 'border-slate-200 bg-slate-50/40 hover:bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="w-full space-y-2">
                      <div className="flex items-center justify-center gap-1.5">
                        <Coins
                          className={`w-4 h-4 ${
                            token.isNative
                              ? 'text-slate-700'
                              : token.symbol === 'USDC'
                                ? 'text-blue-600'
                                : 'text-emerald-600'
                          }`}
                        />
                        <span className="font-bold text-xs text-slate-900">{token.symbol}</span>
                        <span className="px-1.5 py-0.5 rounded-md bg-slate-200/80 text-slate-700 text-[10px] font-bold uppercase">
                          {token.isNative ? 'Native' : token.isStablecoin ? 'Stablecoin' : 'Token'}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-500">{token.name}</p>

                      <div className="py-1">
                        <p className="font-mono text-base font-bold text-slate-900">
                          {token.balanceFormatted} {token.symbol}
                        </p>
                        {token.address ? (
                          <p className="text-[10px] font-mono text-slate-400 mt-0.5">
                            {token.address.slice(0, 6)}...{token.address.slice(-4)}
                          </p>
                        ) : token.note ? (
                          <p className="text-[10px] text-amber-700 mt-1 leading-snug">{token.note}</p>
                        ) : null}
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={!token.available}
                      onClick={() =>
                        setTransferAsset(isSelectedForSend ? null : token)
                      }
                      className="w-full mt-2 pt-2 border-t border-slate-200/80 text-[11px] font-bold text-slate-700 hover:text-emerald-700 transition-colors flex items-center justify-center gap-1 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <Send className="w-3 h-3" />
                      <span>{isSelectedForSend ? 'Close Transfer' : `Send ${token.symbol}`}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {transferAsset && (
            <form
              onSubmit={handleSubmitTransfer}
              className="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/40 space-y-3 text-center"
            >
              <div className="flex items-center justify-center gap-2">
                <Send className="w-3.5 h-3.5 text-emerald-700" />
                <h4 className="text-xs font-bold text-slate-900">
                  Send {transferAsset.symbol} on {selectedNetwork.shortName}
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-xl mx-auto">
                <input
                  type="text"
                  required
                  value={transferTo}
                  onChange={(e) => setTransferTo(e.target.value)}
                  placeholder="Recipient address (0x...)"
                  className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono text-slate-900 focus:outline-none focus:border-emerald-500"
                />
                <input
                  type="number"
                  required
                  step="any"
                  min="0"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  placeholder={`Amount (${transferAsset.symbol})`}
                  className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-mono text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {(() => {
                const parsedAmt = parseFloat(transferAmount) || 0;
                const unitUSD = estimateTokenUSD(transferAsset.symbol);
                const subtotalUSD = parsedAmt * unitUSD;
                const totalUSD = subtotalUSD + privyGas.feeUSD;
                return (
                  <div className="max-w-xl mx-auto p-3 rounded-xl bg-white border border-emerald-200/80 text-xs font-mono space-y-1 text-left">
                    <div className="flex items-center justify-between text-slate-600">
                      <span>Transfer Amount</span>
                      <span>
                        {parsedAmt.toLocaleString(undefined, { maximumFractionDigits: 6 })} {transferAsset.symbol} (~${subtotalUSD.toFixed(2)})
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-amber-800">
                      <span>{privyGas.label}</span>
                      <span>
                        +${privyGas.feeUSD.toFixed(2)} (~{privyGas.nativeUnits} {privyGas.nativeSymbol})
                      </span>
                    </div>
                    <div className="pt-1 border-t border-slate-100 flex items-center justify-between font-bold text-slate-900">
                      <span>Total (incl. Privy Fee)</span>
                      <span>
                        ${totalUSD.toFixed(2)}{' '}
                        {transferAsset.isNative
                          ? `(${(parsedAmt + privyGas.nativeUnits).toFixed(6)} ${transferAsset.symbol})`
                          : `(+ ${privyGas.nativeUnits} ${privyGas.nativeSymbol})`}
                      </span>
                    </div>
                  </div>
                );
              })()}

              <div className="flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => setTransferAsset(null)}
                  className="px-3.5 py-1.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSendingTx}
                  className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSendingTx ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Signing &amp; Broadcasting...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Confirm Send</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {lastTxHash && (
            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex flex-wrap items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Transaction submitted:</span>
              <a
                href={`${selectedNetwork.explorerUrl}/tx/${lastTxHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono font-bold underline inline-flex items-center gap-1"
              >
                <span>
                  {lastTxHash.slice(0, 10)}...{lastTxHash.slice(-6)}
                </span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}

          {serverConfig && !serverConfig.appIdConfigured && (
            <p className="text-[11px] text-amber-700 font-medium">
              Privy App ID is not configured on the server.
            </p>
          )}
        </div>
      )}
    </div>
  );
};
