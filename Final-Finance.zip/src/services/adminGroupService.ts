import {
  clearAccountDeactivated,
  getDeletedAccounts,
  getSelfDeactivatedAccounts,
  isAccountDeactivated,
  isAccountLocked,
  setAccountLocked,
} from '../utils/accountStatusStorage';

export interface AdminMember {
  id: string;
  name: string;
  handle: string;
  email: string;
  avatarUrl?: string;
  role: 'super_admin' | 'admin';
  jobTitle?: string;
  secondaryJobTitle?: string;
  status: 'active' | 'locked' | 'deactivated';
  selfDeactivated?: boolean;
  deactivatedAt?: string;
  lockedAt?: string;
  lastActive: string;
  permissionsCount: number;
}

export interface AdminGroup {
  id: string;
  name: string;
  description: string;
  color: string;
  adminIds: string[]; // List of AdminMember ids
  memberSecondaryTitles?: Record<string, string>; // Maps adminId -> secondaryJobTitle in this group
  createdAt: string;
  updatedAt: string;
}

const ADMIN_MEMBERS_STORAGE_KEY = 'final_finance_admin_directory_v2';
const ADMIN_GROUPS_STORAGE_KEY = 'final_finance_admin_groups_v1';

export const DEFAULT_ADMIN_MEMBERS: AdminMember[] = [
  {
    id: 'adm-1',
    name: 'Ranma (Root Master)',
    handle: '@super_admin_ranma',
    email: 'ranmaanimaker@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    role: 'super_admin',
    jobTitle: 'Chief System Architect',
    status: 'active',
    lastActive: 'Just now',
    permissionsCount: 48,
  },
  {
    id: 'adm-2',
    name: 'Awesome DBZ',
    handle: '@officer_dbz',
    email: 'awesomedbz@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    role: 'admin',
    jobTitle: 'Senior Officer',
    status: 'active',
    lastActive: '2 mins ago',
    permissionsCount: 24,
  },
  {
    id: 'adm-3',
    name: 'Jordan Belfort',
    handle: '@jordan_belfort',
    email: 'jordan@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    role: 'admin',
    jobTitle: 'Senior Investment Officer',
    status: 'active',
    lastActive: '15 mins ago',
    permissionsCount: 18,
  },
  {
    id: 'adm-4',
    name: 'Satoshi Nakamoto',
    handle: '@satoshi_nakamoto',
    email: 'satoshi@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'admin',
    jobTitle: 'Cryptographic Reserve Officer',
    status: 'active',
    lastActive: '1 hour ago',
    permissionsCount: 24,
  },
  {
    id: 'adm-5',
    name: 'Elena Rostova',
    handle: '@elena_compliance',
    email: 'elena.rostova@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    role: 'admin',
    jobTitle: 'Compliance Lead',
    status: 'active',
    lastActive: '3 hours ago',
    permissionsCount: 16,
  },
  {
    id: 'adm-6',
    name: 'Marcus Vance',
    handle: '@marcus_vance',
    email: 'marcus.vance@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    role: 'admin',
    jobTitle: 'Junior Operations Admin',
    status: 'active',
    lastActive: '2 days ago',
    permissionsCount: 14,
  },
];

function resolveCustomProfileAvatar(keys: Array<string | undefined>): string | undefined {
  try {
    const raw = localStorage.getItem('final_finance_custom_profiles_map');
    if (!raw) return undefined;
    const map = JSON.parse(raw) as Record<string, { avatarUrl?: string; email?: string; userId?: string; uid?: string }>;
    const cleanKeys = keys
      .map((k) => (k || '').trim().toLowerCase().replace(/^@/, ''))
      .filter(Boolean);
    for (const k of cleanKeys) {
      const hit = map[k] || map[`user-${k}`] || map[`demo-${k}`];
      if (hit?.avatarUrl) return hit.avatarUrl;
    }
    for (const entry of Object.values(map)) {
      if (!entry?.avatarUrl) continue;
      const entryIds = [entry.uid, entry.userId, entry.email]
        .map((v) => (v || '').trim().toLowerCase().replace(/^@/, ''))
        .filter(Boolean);
      if (cleanKeys.some((k) => entryIds.includes(k))) {
        return entry.avatarUrl;
      }
    }
  } catch {
    // Ignore storage read errors
  }
  return undefined;
}

export function getAdminMembers(): AdminMember[] {
  let baseList: AdminMember[] = [];
  const defaultById = new Map(DEFAULT_ADMIN_MEMBERS.map((d) => [d.id, d]));
  const defaultByEmail = new Map(DEFAULT_ADMIN_MEMBERS.map((d) => [d.email.toLowerCase(), d]));
  const defaultByHandle = new Map(DEFAULT_ADMIN_MEMBERS.map((d) => [d.handle.toLowerCase(), d]));

  try {
    const raw = localStorage.getItem(ADMIN_MEMBERS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const existingIds = new Set(parsed.map((m: any) => m.id));
        const merged = [...parsed];
        for (const def of DEFAULT_ADMIN_MEMBERS) {
          if (!existingIds.has(def.id)) {
            merged.push(def);
          }
        }
        baseList = merged.map((m: any) => {
          const defMatch =
            defaultById.get(m.id) ||
            (m.email ? defaultByEmail.get(String(m.email).toLowerCase()) : undefined) ||
            (m.handle ? defaultByHandle.get(String(m.handle).toLowerCase()) : undefined);
          const customAvatar = resolveCustomProfileAvatar([m.id, m.handle, m.email]);
          const isSelfDeac =
            Boolean(m.selfDeactivated) ||
            isAccountDeactivated([m.email, m.handle, m.id]);
          const isLockedFlag =
            m.status === 'locked' || isAccountLocked([m.email, m.handle, m.id]);
          let normalizedStatus: 'active' | 'locked' | 'deactivated' = 'active';
          if (isSelfDeac) {
            normalizedStatus = 'deactivated';
          } else if (isLockedFlag) {
            normalizedStatus = 'locked';
          }
          return {
            ...m,
            avatarUrl: customAvatar || m.avatarUrl || defMatch?.avatarUrl,
            role: m.role === 'super_admin' ? 'super_admin' : 'admin',
            jobTitle: m.jobTitle || (m.role === 'super_admin' ? 'Chief System Architect' : 'Administrator'),
            status: normalizedStatus,
            selfDeactivated: isSelfDeac,
          } as AdminMember;
        });
      }
    }
  } catch (e) {
    console.warn('Error loading admin members from storage:', e);
  }

  if (baseList.length === 0) {
    baseList = DEFAULT_ADMIN_MEMBERS.map((m) => ({
      ...m,
      avatarUrl: resolveCustomProfileAvatar([m.id, m.handle, m.email]) || m.avatarUrl,
    }));
  }

  // Filter out admins that have been permanently deleted in Settings
  const deletedAdmins = getDeletedAccounts('admin');
  const deletedEmails = new Set(deletedAdmins.map((d) => (d.email || '').toLowerCase()).filter(Boolean));
  const deletedHandles = new Set(
    deletedAdmins.map((d) => `@${(d.userId || '').toLowerCase().replace(/^@/, '')}`).filter((h) => h !== '@')
  );

  let synced = baseList.filter((m) => {
    const emailMatch = m.email && deletedEmails.has(m.email.toLowerCase());
    const handleMatch = m.handle && deletedHandles.has(m.handle.toLowerCase());
    return !emailMatch && !handleMatch;
  });

  // Merge any self-deactivated admins recorded from Settings
  const selfDeactivatedAdmins = getSelfDeactivatedAccounts('admin');
  for (const rec of selfDeactivatedAdmins) {
    const recHandle = `@${rec.userId.toLowerCase().replace(/^@/, '')}`;
    const existingIdx = synced.findIndex(
      (m) =>
        (rec.email && m.email.toLowerCase() === rec.email.toLowerCase()) ||
        m.handle.toLowerCase() === recHandle
    );
    const defMatch =
      (rec.email ? defaultByEmail.get(rec.email.toLowerCase()) : undefined) ||
      defaultByHandle.get(recHandle);
    const resolvedAvatar =
      resolveCustomProfileAvatar([rec.uid, rec.userId, rec.email]) ||
      rec.avatarUrl ||
      defMatch?.avatarUrl;
    if (existingIdx >= 0) {
      synced[existingIdx] = {
        ...synced[existingIdx],
        avatarUrl: resolvedAvatar || synced[existingIdx].avatarUrl,
        status: 'deactivated',
        selfDeactivated: true,
        deactivatedAt: rec.deactivatedAt,
      };
    } else {
      synced.push({
        id: `adm-${rec.userId}`,
        name: rec.name || rec.userId,
        handle: recHandle,
        email: rec.email,
        avatarUrl: resolvedAvatar,
        role: rec.role === 'super_admin' ? 'super_admin' : 'admin',
        jobTitle: rec.role === 'super_admin' ? 'Chief System Architect' : 'Administrator',
        status: 'deactivated',
        selfDeactivated: true,
        deactivatedAt: rec.deactivatedAt,
        lastActive: 'Self-deactivated',
        permissionsCount: 24,
      });
    }
  }

  saveAdminMembers(synced);
  return synced;
}

export function saveAdminMembers(admins: AdminMember[]): void {
  try {
    localStorage.setItem(ADMIN_MEMBERS_STORAGE_KEY, JSON.stringify(admins));
  } catch (e) {
    console.error('Error saving admin members to storage:', e);
  }
}

export function updateAdminMemberTitle(adminId: string, jobTitle: string): AdminMember[] {
  const admins = getAdminMembers();
  const updated = admins.map((a) => (a.id === adminId ? { ...a, jobTitle: jobTitle.trim() } : a));
  saveAdminMembers(updated);
  return updated;
}

export function setAdminMemberStatus(
  adminId: string,
  status: 'active' | 'locked' | 'deactivated',
  options?: { selfDeactivated?: boolean }
): AdminMember[] {
  const admins = getAdminMembers();
  const target = admins.find((a) => a.id === adminId);
  const updated = admins.map((a) => {
    if (a.id !== adminId) return a;
    if (status === 'locked') {
      return {
        ...a,
        status: 'locked' as const,
        lockedAt: new Date().toISOString(),
      };
    }
    if (status === 'deactivated') {
      return {
        ...a,
        status: 'deactivated' as const,
        selfDeactivated: options?.selfDeactivated ?? true,
        deactivatedAt: new Date().toISOString(),
      };
    }
    return {
      ...a,
      status: 'active' as const,
      selfDeactivated: false,
      deactivatedAt: undefined,
      lockedAt: undefined,
    };
  });
  saveAdminMembers(updated);

  if (target) {
    const ids = [target.email, target.handle, target.handle.replace(/^@/, ''), target.id];
    const cleanHandle = target.handle.replace(/^@/, '');
    if (status === 'locked') {
      setAccountLocked(ids, true, {
        uid: target.id,
        userId: cleanHandle,
        name: target.name,
        email: target.email,
        avatarUrl: target.avatarUrl,
        source: 'super_admin_lock',
      });
    } else if (status === 'active') {
      setAccountLocked(ids, false, {
        source: 'super_admin_lock',
      });
      clearAccountDeactivated(ids);
    }
  }
  return updated;
}

export function markAdminSelfDeactivatedInDirectory(account: {
  id?: string;
  uid?: string;
  userId?: string;
  name?: string;
  email?: string;
  role?: string;
}): void {
  const admins = getAdminMembers();
  const cleanEmail = (account.email || '').trim().toLowerCase();
  const cleanHandle = `@${(account.userId || account.id || '').trim().toLowerCase().replace(/^@/, '')}`;
  const idx = admins.findIndex(
    (m) =>
      (cleanEmail && m.email.toLowerCase() === cleanEmail) ||
      (cleanHandle !== '@' && m.handle.toLowerCase() === cleanHandle)
  );
  if (idx >= 0) {
    admins[idx] = {
      ...admins[idx],
      status: 'deactivated',
      selfDeactivated: true,
      deactivatedAt: new Date().toISOString(),
    };
    saveAdminMembers(admins);
  }
}

export function removeDeletedAdminFromDirectory(account: {
  id?: string;
  userId?: string;
  email?: string;
}): void {
  const admins = getAdminMembers();
  const cleanEmail = (account.email || '').trim().toLowerCase();
  const cleanHandle = `@${(account.userId || account.id || '').trim().toLowerCase().replace(/^@/, '')}`;
  const filtered = admins.filter(
    (m) =>
      !(cleanEmail && m.email.toLowerCase() === cleanEmail) &&
      !(cleanHandle !== '@' && m.handle.toLowerCase() === cleanHandle)
  );
  saveAdminMembers(filtered);
}


const DEFAULT_ADMIN_GROUPS: AdminGroup[] = [
  {
    id: 'grp-adm-security',
    name: 'Security & Reserve Oversight',
    description: 'Oversees root protocol upgrades, multi-sig treasury sweeps, and cold vault reserves.',
    color: '#f59e0b', // amber
    adminIds: ['adm-1', 'adm-2', 'adm-4'],
    memberSecondaryTitles: {
      'adm-1': 'Root Key Signer',
      'adm-2': 'Cold Vault Custodian',
      'adm-4': 'Cryptographic Protocol Inspector',
    },
    createdAt: '2024-01-15T08:00:00.000Z',
    updatedAt: '2024-01-15T08:00:00.000Z'
  },
  {
    id: 'grp-adm-compliance',
    name: 'Financial Compliance Council',
    description: 'Coordinates AML/KYC policies, jurisdiction licensing, and regulatory advisories.',
    color: '#8b5cf6', // purple
    adminIds: ['adm-3', 'adm-5'],
    memberSecondaryTitles: {
      'adm-3': 'AML Lead Arbiter',
      'adm-5': 'Regulatory Affairs Inspector',
    },
    createdAt: '2024-01-20T10:30:00.000Z',
    updatedAt: '2024-01-20T10:30:00.000Z'
  },
  {
    id: 'grp-adm-liquidity',
    name: 'VIP Liquidity & Desk Taskforce',
    description: 'Handles high-volume bullion allocations, OTC clearing, and tier-1 partner disputes.',
    color: '#10b981', // emerald
    adminIds: ['adm-2', 'adm-3', 'adm-1'],
    memberSecondaryTitles: {
      'adm-2': 'OTC Desk Director',
      'adm-3': 'VIP Liquidity Allocator',
      'adm-1': 'Treasury Protocol Governor',
    },
    createdAt: '2024-02-05T14:15:00.000Z',
    updatedAt: '2024-02-05T14:15:00.000Z'
  }
];

export function getAdminGroups(): AdminGroup[] {
  try {
    const raw = localStorage.getItem(ADMIN_GROUPS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Error loading admin groups from storage:', e);
  }
  // Initialize with defaults
  saveAdminGroups(DEFAULT_ADMIN_GROUPS);
  return DEFAULT_ADMIN_GROUPS;
}

export function saveAdminGroups(groups: AdminGroup[]): void {
  try {
    localStorage.setItem(ADMIN_GROUPS_STORAGE_KEY, JSON.stringify(groups));
  } catch (e) {
    console.error('Error saving admin groups to storage:', e);
  }
}

export function setGroupMemberSecondaryTitle(
  groupId: string,
  adminId: string,
  secondaryTitle: string
): AdminGroup[] {
  const groups = getAdminGroups();
  const group = groups.find(g => g.id === groupId);
  if (group) {
    if (!group.memberSecondaryTitles) {
      group.memberSecondaryTitles = {};
    }
    const cleanTitle = secondaryTitle.trim();
    if (cleanTitle) {
      group.memberSecondaryTitles[adminId] = cleanTitle;
    } else {
      delete group.memberSecondaryTitles[adminId];
    }
    group.updatedAt = new Date().toISOString();
    saveAdminGroups(groups);
  }
  return groups;
}

export function createAdminGroup(data: {
  name: string;
  description?: string;
  color?: string;
  adminIds?: string[];
}): AdminGroup {
  const groups = getAdminGroups();
  const newGroup: AdminGroup = {
    id: `grp-adm-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    name: data.name.trim(),
    description: data.description?.trim() || '',
    color: data.color || '#3b82f6',
    adminIds: Array.from(new Set(data.adminIds || [])),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const updated = [newGroup, ...groups];
  saveAdminGroups(updated);
  return newGroup;
}

export function updateAdminGroup(
  id: string,
  updates: Partial<Omit<AdminGroup, 'id' | 'createdAt'>>
): AdminGroup | null {
  const groups = getAdminGroups();
  const idx = groups.findIndex(g => g.id === id);
  if (idx === -1) return null;

  const updatedGroup: AdminGroup = {
    ...groups[idx],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  groups[idx] = updatedGroup;
  saveAdminGroups(groups);
  return updatedGroup;
}

export function deleteAdminGroup(id: string): boolean {
  const groups = getAdminGroups();
  const filtered = groups.filter(g => g.id !== id);
  if (filtered.length !== groups.length) {
    saveAdminGroups(filtered);
    return true;
  }
  return false;
}

export function getGroupsForAdmin(adminId: string): AdminGroup[] {
  const groups = getAdminGroups();
  return groups.filter(g => g.adminIds.includes(adminId));
}

export function addAdminToGroup(groupId: string, adminId: string): void {
  const groups = getAdminGroups();
  const group = groups.find(g => g.id === groupId);
  if (group && !group.adminIds.includes(adminId)) {
    group.adminIds.push(adminId);
    group.updatedAt = new Date().toISOString();
    saveAdminGroups(groups);
  }
}

export function removeAdminFromGroup(groupId: string, adminId: string): void {
  const groups = getAdminGroups();
  const group = groups.find(g => g.id === groupId);
  if (group && group.adminIds.includes(adminId)) {
    group.adminIds = group.adminIds.filter(id => id !== adminId);
    group.updatedAt = new Date().toISOString();
    saveAdminGroups(groups);
  }
}

/**
 * Assigns an admin to multiple groups at once (or updates their memberships).
 * Groups not in targetGroupIds will have the admin removed.
 * Groups in targetGroupIds will have the admin added.
 */
export function setAdminGroups(adminId: string, targetGroupIds: string[]): void {
  const groups = getAdminGroups();
  let modified = false;

  for (const group of groups) {
    const shouldBeIn = targetGroupIds.includes(group.id);
    const isCurrentlyIn = group.adminIds.includes(adminId);

    if (shouldBeIn && !isCurrentlyIn) {
      group.adminIds.push(adminId);
      group.updatedAt = new Date().toISOString();
      modified = true;
    } else if (!shouldBeIn && isCurrentlyIn) {
      group.adminIds = group.adminIds.filter(id => id !== adminId);
      group.updatedAt = new Date().toISOString();
      modified = true;
    }
  }

  if (modified) {
    saveAdminGroups(groups);
  }
}

export interface AdminPermissionItem {
  id: string;
  category: string;
  title: string;
  description: string;
  level: 'root' | 'senior' | 'standard';
}

export const ALL_ADMIN_PERMISSIONS_CATALOG: AdminPermissionItem[] = [
  // 1. Root Authority & System Architecture (6)
  { id: 'perm-root-1', category: 'Root Authority & System Architecture', title: 'Root Key Signing', description: 'Authorize multi-sig sovereign root protocol transactions.', level: 'root' },
  { id: 'perm-root-2', category: 'Root Authority & System Architecture', title: 'System Protocol Upgrades', description: 'Deploy and activate core platform upgrades and consensus rules.', level: 'root' },
  { id: 'perm-root-3', category: 'Root Authority & System Architecture', title: 'Admin Privilege Promotion & Demotion', description: 'Grant or revoke administrator access and elevate roles.', level: 'root' },
  { id: 'perm-root-4', category: 'Root Authority & System Architecture', title: 'Lock & Unlock Administrators', description: 'Place or lift security locks on fellow administrator accounts.', level: 'root' },
  { id: 'perm-root-5', category: 'Root Authority & System Architecture', title: 'Reactivate Self-Deactivated Admins', description: 'Restore administrators who deactivated their account from Settings.', level: 'root' },
  { id: 'perm-root-6', category: 'Root Authority & System Architecture', title: 'Global Emergency Kill-Switch', description: 'Pause settlement rails, withdrawals, or market trading during incidents.', level: 'root' },

  // 2. Administrator Directory & Group Governance (6)
  { id: 'perm-gov-1', category: 'Directory & Group Governance', title: 'Create & Delete Admin Groups', description: 'Establish or retire functional governance councils and desks.', level: 'root' },
  { id: 'perm-gov-2', category: 'Directory & Group Governance', title: 'Assign Admins to Multiple Groups', description: 'Manage cross-functional memberships across admin councils.', level: 'root' },
  { id: 'perm-gov-3', category: 'Directory & Group Governance', title: 'Assign Primary Job Titles', description: 'Set official primary governance titles for administrators.', level: 'root' },
  { id: 'perm-gov-4', category: 'Directory & Group Governance', title: 'Assign Secondary Group Titles', description: 'Designate group-specific operational mandates per council.', level: 'root' },
  { id: 'perm-gov-5', category: 'Directory & Group Governance', title: 'Resolve Priority Admin Escalations', description: 'Respond to, investigate, and close escalated advisories.', level: 'root' },
  { id: 'perm-gov-6', category: 'Directory & Group Governance', title: 'Audit Deleted Admin Archives', description: 'Inspect archived administrator deletion and separation logs.', level: 'root' },

  // 3. Treasury, Reserve Vaults & Sweeps (6)
  { id: 'perm-vault-1', category: 'Treasury & Reserve Vaults', title: 'Cold Vault Custody Oversight', description: 'Monitor bullion, sovereign bond, and BTC cold storage vaults.', level: 'senior' },
  { id: 'perm-vault-2', category: 'Treasury & Reserve Vaults', title: 'Swiss Reserve Sweep Overrides', description: 'Authorize manual vault sweep transfers across depositories.', level: 'root' },
  { id: 'perm-vault-3', category: 'Treasury & Reserve Vaults', title: 'AFNL Treasury Mint & Burn Review', description: 'Audit AFNL reserve minting, supply caps, and coin redemptions.', level: 'senior' },
  { id: 'perm-vault-4', category: 'Treasury & Reserve Vaults', title: 'Bullion & Assay Verification', description: 'Verify physical commodity serial certificates and depository deeds.', level: 'standard' },
  { id: 'perm-vault-5', category: 'Treasury & Reserve Vaults', title: 'Multi-Sig Treasury Sign-Off', description: 'Co-sign institutional vault rebalancing and liquidity movements.', level: 'senior' },
  { id: 'perm-vault-6', category: 'Treasury & Reserve Vaults', title: 'Publish Reserve Attestations', description: 'Sign and publish cryptographic proof-of-reserve attestations.', level: 'senior' },

  // 4. Escrow, OTC & Barter Clearing (6)
  { id: 'perm-escrow-1', category: 'Escrow & Barter Clearing', title: 'Arbitrate Escrow Disputes', description: 'Review evidence and settle disputed bilateral barter trades.', level: 'standard' },
  { id: 'perm-escrow-2', category: 'Escrow & Barter Clearing', title: 'Freeze & Release Escrow Holds', description: 'Place investigative holds or release locked escrow funds.', level: 'senior' },
  { id: 'perm-escrow-3', category: 'Escrow & Barter Clearing', title: 'Reverse Flagged Settlements', description: 'Roll back fraudulent or misrouted OTC settlements.', level: 'root' },
  { id: 'perm-escrow-4', category: 'Escrow & Barter Clearing', title: 'Settle Expired Auctions', description: 'Finalize or void contested high-value barter auctions.', level: 'standard' },
  { id: 'perm-escrow-5', category: 'Escrow & Barter Clearing', title: 'Approve High-Value OTC Clearing', description: 'Clear VIP bullion and real-estate lien swaps above desk limits.', level: 'senior' },
  { id: 'perm-escrow-6', category: 'Escrow & Barter Clearing', title: 'Issue Clearing Override Receipts', description: 'Generate signed settlement override audit certificates.', level: 'senior' },

  // 5. KYC, AML & Compliance Oversight (6)
  { id: 'perm-kyc-1', category: 'KYC, AML & Compliance', title: 'Approve Tier 1–3 KYC Submissions', description: 'Verify identity documents and grant full platform verification tiers.', level: 'standard' },
  { id: 'perm-kyc-2', category: 'KYC, AML & Compliance', title: 'Reject or Request Re-Verification', description: 'Return incomplete compliance packets with remediation notes.', level: 'standard' },
  { id: 'perm-kyc-3', category: 'KYC, AML & Compliance', title: 'Lock & Unlock User Accounts', description: 'Enforce compliance holds or restore restricted member accounts.', level: 'standard' },
  { id: 'perm-kyc-4', category: 'KYC, AML & Compliance', title: 'AML Transaction Surveillance', description: 'Flag and trace anomalous velocity or cross-border flows.', level: 'senior' },
  { id: 'perm-kyc-5', category: 'KYC, AML & Compliance', title: 'Jurisdiction Licensing Controls', description: 'Configure regional eligibility and regulatory disclosures.', level: 'senior' },
  { id: 'perm-kyc-6', category: 'KYC, AML & Compliance', title: 'Inspect Deactivated & Deleted User Records', description: 'Audit historical compliance records for closed member accounts.', level: 'standard' },

  // 6. Marketplace, Listings & IPO Approvals (6)
  { id: 'perm-mkt-1', category: 'Marketplace & IPOs', title: 'Approve Corporate IPO Requests', description: 'Review filings and list approved Final Stock IPO offerings.', level: 'senior' },
  { id: 'perm-mkt-2', category: 'Marketplace & IPOs', title: 'Approve Stock Delisting Requests', description: 'Process issuer delisting requests and close order books cleanly.', level: 'senior' },
  { id: 'perm-mkt-3', category: 'Marketplace & IPOs', title: 'Moderate Marketplace Listings', description: 'Approve, pause, or remove flagged goods and service listings.', level: 'standard' },
  { id: 'perm-mkt-4', category: 'Marketplace & IPOs', title: 'Audit Merchant & Seller Reviews', description: 'Verify disputed buyer ratings and settlement-backed reviews.', level: 'standard' },
  { id: 'perm-mkt-5', category: 'Marketplace & IPOs', title: 'Inspect Draft & Private Listings', description: 'Review non-public listings during compliance audits.', level: 'standard' },
  { id: 'perm-mkt-6', category: 'Marketplace & IPOs', title: 'Verify Corporate Equity Issuers', description: 'Confirm corporate registration for equity and stock issuers.', level: 'senior' },

  // 7. Banking, Grants, Subsidies & Accounting (6)
  { id: 'perm-bank-1', category: 'Banking, Grants & Accounting', title: 'Issue UBI & Ecosystem Subsidies', description: 'Distribute program grants and UBI disbursements to eligible accounts.', level: 'senior' },
  { id: 'perm-bank-2', category: 'Banking, Grants & Accounting', title: 'Review Admin Self-Granted Subsidies', description: 'Audit all self-issued grants and subsidy logs across admins.', level: 'root' },
  { id: 'perm-bank-3', category: 'Banking, Grants & Accounting', title: 'Inspect Universal Accounting Ledgers', description: 'Audit per-user, stock, and currency ledger balances and receipts.', level: 'standard' },
  { id: 'perm-bank-4', category: 'Banking, Grants & Accounting', title: 'Oversee Internal Bank Lending', description: 'Monitor inter-bank loan offers, repayments, and default flags.', level: 'standard' },
  { id: 'perm-bank-5', category: 'Banking, Grants & Accounting', title: 'Approve Treasury Liquidity Injections', description: 'Authorize balance sheet adjustments and fee rebates.', level: 'root' },
  { id: 'perm-bank-6', category: 'Banking, Grants & Accounting', title: 'Export Global Tax & Audit Ledgers', description: 'Generate full Form 1099/8949-aligned cryptographic ledger exports.', level: 'senior' },

  // 8. Security Guard, Social & Communications (6)
  { id: 'perm-sec-1', category: 'Security & Communications', title: 'Bypass Communication Blocks for Audits', description: 'Reach any member via DM or call during active investigations.', level: 'standard' },
  { id: 'perm-sec-2', category: 'Security & Communications', title: 'Moderate Community Tweets & Polls', description: 'Audit public social posts, hashtags, and flagged threads.', level: 'standard' },
  { id: 'perm-sec-3', category: 'Security & Communications', title: 'Escalate Bulletins to Super Admin', description: 'Submit priority security advisories to the Root Master console.', level: 'standard' },
  { id: 'perm-sec-4', category: 'Security & Communications', title: 'Review User & Admin Feedback Queues', description: 'Triage and respond to bug reports and governance feedback.', level: 'standard' },
  { id: 'perm-sec-5', category: 'Security & Communications', title: 'Audit Ride-Share & POS Settlements', description: 'Investigate payment disputes across Point of Sale and Ride-Share.', level: 'standard' },
  { id: 'perm-sec-6', category: 'Security & Communications', title: 'Broadcast Platform System Notices', description: 'Publish global security and operational notifications.', level: 'root' },
];

export function getAdminPermissionsList(admin: Pick<AdminMember, 'role' | 'permissionsCount'>): AdminPermissionItem[] {
  const targetCount = Math.max(0, Math.min(ALL_ADMIN_PERMISSIONS_CATALOG.length, admin.permissionsCount || 0));
  if (admin.role === 'super_admin' || targetCount >= ALL_ADMIN_PERMISSIONS_CATALOG.length) {
    return ALL_ADMIN_PERMISSIONS_CATALOG.slice(0, targetCount || ALL_ADMIN_PERMISSIONS_CATALOG.length);
  }
  const ordered = [
    ...ALL_ADMIN_PERMISSIONS_CATALOG.filter((p) => p.level === 'standard'),
    ...ALL_ADMIN_PERMISSIONS_CATALOG.filter((p) => p.level === 'senior'),
    ...ALL_ADMIN_PERMISSIONS_CATALOG.filter((p) => p.level === 'root'),
  ];
  return ordered.slice(0, targetCount);
}

