import React, { useState } from 'react';
import {
  FolderHeart,
  Plus,
  Users,
  Pencil,
  Trash2,
  Check,
  X,
  Search,
  Shield,
  UserPlus,
  UserCheck,
  UserX,
  Mail,
  Crown,
  Briefcase,
  Tag
} from 'lucide-react';
import {
  AdminGroup,
  AdminMember,
  createAdminGroup,
  updateAdminGroup,
  deleteAdminGroup,
  getGroupsForAdmin,
  setGroupMemberSecondaryTitle
} from '../../services/adminGroupService';
import { AdminSecondaryTitleModal } from './AdminSecondaryTitleModal';
import { AdminGroupDeleteModal } from './AdminGroupDeleteModal';

interface AdminGroupsTabProps {
  groups: AdminGroup[];
  allAdmins: AdminMember[];
  onRefresh: () => void;
  onToast: (toast: { type: 'success' | 'error' | 'info'; title: string; message: string }) => void;
}

const PRESET_COLORS = ['#f59e0b', '#8b5cf6', '#10b981', '#3b82f6', '#ec4899', '#6366f1', '#14b8a6', '#64748b'];

export const AdminGroupsTab: React.FC<AdminGroupsTabProps> = ({
  groups,
  allAdmins,
  onRefresh,
  onToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<AdminGroup | null>(null);
  const [groupToDelete, setGroupToDelete] = useState<AdminGroup | null>(null);

  // Group modal form state (for create and edit)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: PRESET_COLORS[0],
    adminIds: [] as string[],
  });

  // Manage members specific modal state
  const [managingMembersGroup, setManagingMembersGroup] = useState<AdminGroup | null>(null);
  const [selectedAdminIdsForGroup, setSelectedAdminIdsForGroup] = useState<string[]>([]);
  const [adminSearchQuery, setAdminSearchQuery] = useState('');

  // Secondary job title modal state (Super Admin assigning secondary title to admin in group)
  const [secondaryTitleModalData, setSecondaryTitleModalData] = useState<{
    admin: AdminMember;
    group: AdminGroup;
  } | null>(null);

  const handleSaveSecondaryTitle = (groupId: string, adminId: string, secondaryTitle: string) => {
    setGroupMemberSecondaryTitle(groupId, adminId, secondaryTitle);
    onRefresh();
    setSecondaryTitleModalData(null);
    onToast({
      type: 'success',
      title: 'Secondary Job Title Saved',
      message: secondaryTitle
        ? `Assigned secondary title "${secondaryTitle}" for group.`
        : 'Removed secondary group title.',
    });
  };

  // Open Create Modal
  const handleOpenCreate = () => {
    setFormData({
      name: '',
      description: '',
      color: PRESET_COLORS[Math.floor(Math.random() * PRESET_COLORS.length)],
      adminIds: [],
    });
    setEditingGroup(null);
    setIsCreateModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (group: AdminGroup) => {
    setEditingGroup(group);
    setFormData({
      name: group.name,
      description: group.description,
      color: group.color,
      adminIds: [...group.adminIds],
    });
    setIsCreateModalOpen(true);
  };

  // Save Create or Edit
  const handleSaveGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    if (editingGroup) {
      updateAdminGroup(editingGroup.id, {
        name: formData.name.trim(),
        description: formData.description.trim(),
        color: formData.color,
        adminIds: formData.adminIds,
      });
      onToast({
        type: 'success',
        title: 'Group Updated',
        message: `Admin group "${formData.name.trim()}" updated with ${formData.adminIds.length} members.`,
      });
    } else {
      createAdminGroup({
        name: formData.name.trim(),
        description: formData.description.trim(),
        color: formData.color,
        adminIds: formData.adminIds,
      });
      onToast({
        type: 'success',
        title: 'Group Created',
        message: `Admin group "${formData.name.trim()}" created successfully.`,
      });
    }

    setIsCreateModalOpen(false);
    setEditingGroup(null);
    onRefresh();
  };

  // Delete Group with Confirmation Modal
  const handleRequestDelete = (group: AdminGroup) => {
    setGroupToDelete(group);
  };

  const handleConfirmDelete = () => {
    if (!groupToDelete) return;
    const name = groupToDelete.name;
    deleteAdminGroup(groupToDelete.id);
    setGroupToDelete(null);
    onToast({
      type: 'info',
      title: 'Group Deleted',
      message: `Admin group "${name}" has been removed.`,
    });
    onRefresh();
  };

  // Open Manage Members Modal
  const handleOpenManageMembers = (group: AdminGroup) => {
    setManagingMembersGroup(group);
    setSelectedAdminIdsForGroup([...group.adminIds]);
    setAdminSearchQuery('');
  };

  // Save Manage Members
  const handleSaveMembers = () => {
    if (!managingMembersGroup) return;

    updateAdminGroup(managingMembersGroup.id, {
      adminIds: selectedAdminIdsForGroup,
    });

    onToast({
      type: 'success',
      title: 'Group Members Saved',
      message: `"${managingMembersGroup.name}" now contains ${selectedAdminIdsForGroup.length} administrators.`,
    });

    setManagingMembersGroup(null);
    onRefresh();
  };

  const toggleAdminInManageModal = (adminId: string) => {
    setSelectedAdminIdsForGroup((prev) =>
      prev.includes(adminId) ? prev.filter((id) => id !== adminId) : [...prev, adminId]
    );
  };

  // Filter groups
  const filteredGroups = groups.filter((g) => {
    const q = searchQuery.toLowerCase();
    const matchName = g.name.toLowerCase().includes(q);
    const matchDesc = g.description.toLowerCase().includes(q);
    const matchMembers = g.adminIds.some((admId) => {
      const adm = allAdmins.find((a) => a.id === admId);
      return (
        adm &&
        (adm.name.toLowerCase().includes(q) ||
          adm.handle.toLowerCase().includes(q) ||
          adm.email.toLowerCase().includes(q))
      );
    });
    return matchName || matchDesc || matchMembers;
  });

  const totalMembersAssigned = groups.reduce((acc, g) => acc + g.adminIds.length, 0);

  return (
    <div className="space-y-4">
      {/* Consolidated Top Toolbar: Title, Quick Stats, Filter Search, and Action */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0 border border-indigo-200 shadow-2xs">
              <FolderHeart className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-serif text-base font-bold text-slate-900">
                  Administrator Groups &amp; Councils
                </h2>
                <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200 shrink-0">
                  {groups.length} {groups.length === 1 ? 'Group' : 'Groups'}
                </span>
                <span className="text-xs font-mono text-slate-400 hidden sm:inline">
                  • {totalMembersAssigned} total memberships
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate mt-0.5">
                Organize administrators into functional councils, departments, or review teams.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap sm:flex-nowrap">
            <div className="relative flex-1 sm:w-64 min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter groups or members..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
                  title="Clear filter"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={handleOpenCreate}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Create Group</span>
            </button>
          </div>
        </div>
      </div>

      {/* Groups Grid / List */}
      <div>
        {filteredGroups.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3 shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center border border-slate-200">
              <FolderHeart className="w-6 h-6" />
            </div>
            <p className="text-xs font-semibold text-slate-600">
              {searchQuery ? `No admin groups found matching "${searchQuery}"` : 'No admin groups created yet.'}
            </p>
            <button
              type="button"
              onClick={handleOpenCreate}
              className="px-4 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create First Admin Group</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredGroups.map((group) => {
              const memberAdmins = allAdmins.filter((adm) => group.adminIds.includes(adm.id));

              return (
                <div
                  key={group.id}
                  className="rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-all flex flex-col justify-between overflow-hidden shadow-2xs group"
                >
                  {/* Top colored accent line */}
                  <div className="h-1.5 w-full shrink-0" style={{ backgroundColor: group.color }} />

                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    {/* Group Header */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="w-3 h-3 rounded-full shrink-0 ring-2 ring-white shadow-xs"
                          style={{ backgroundColor: group.color }}
                        />
                        <h3 className="font-serif text-sm sm:text-base font-bold text-slate-900 truncate">
                          {group.name}
                        </h3>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-100 text-slate-700 border border-slate-200 shrink-0 inline-flex items-center gap-1.5">
                          <Users className="w-3 h-3 text-slate-400" />
                          <span>{memberAdmins.length} {memberAdmins.length === 1 ? 'Member' : 'Members'}</span>
                        </span>

                        {/* Action buttons (Manage, Edit, Trash) */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleOpenManageMembers(group)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-700 hover:bg-indigo-50 transition-colors cursor-pointer"
                            title="Manage assigned members"
                          >
                            <UserPlus className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(group)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                            title="Edit group details"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRequestDelete(group)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Delete group"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {group.description && (
                        <p className="text-[11px] text-slate-500 leading-snug line-clamp-2">
                          {group.description}
                        </p>
                      )}
                    </div>

                    {/* Member Admins Section */}
                    <div className="pt-2.5 border-t border-slate-100 space-y-2 flex-1">
                      {/* Member Admins Header */}
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-semibold">
                          Assigned Admins ({memberAdmins.length})
                        </span>
                      </div>

                      {memberAdmins.length === 0 ? (
                        <div className="py-4 px-3 bg-slate-50/70 rounded-xl text-center text-xs text-slate-400 border border-dashed border-slate-200">
                          No administrators assigned yet.
                        </div>
                      ) : (
                        <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                          {memberAdmins.map((adm) => {
                            const secondaryTitle = group.memberSecondaryTitles?.[adm.id];

                            return (
                              <div
                                key={adm.id}
                                className="p-2 rounded-xl bg-slate-50/70 border border-slate-200/70 hover:bg-indigo-50/20 hover:border-indigo-200/70 transition-all flex items-start gap-2.5 overflow-hidden"
                              >
                                {/* Avatar with Status Indicator Dot */}
                                <div className="relative shrink-0 mt-0.5">
                                  <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-800 font-bold flex items-center justify-center text-xs border border-amber-200">
                                    {adm.name.charAt(0)}
                                  </div>
                                  <span
                                    className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full ring-2 ring-white ${
                                      adm.status === 'active' ? 'bg-emerald-500' : 'bg-rose-400'
                                    }`}
                                    title={`Status: ${adm.status}`}
                                  />
                                </div>

                                {/* Admin Info & Stacked Roles */}
                                <div className="min-w-0 flex-1 space-y-1">
                                  {/* Line 1: Name and Handle */}
                                  <div className="flex items-center justify-between gap-1.5">
                                    <span className="font-bold text-xs text-slate-900 truncate">
                                      {adm.name}
                                    </span>
                                    <span className="font-mono text-[10px] text-amber-600 truncate shrink-0">
                                      {adm.handle}
                                    </span>
                                  </div>

                                  {/* Roles Section */}
                                  <div className="space-y-0.5 text-[11px]">
                                    {/* Primary Role */}
                                    <div className="flex items-center gap-1.5 leading-tight">
                                      <span className="text-[10px] font-mono text-slate-400 shrink-0">Primary:</span>
                                      <span className="font-medium text-slate-700 truncate">
                                        {adm.jobTitle || (adm.role === 'super_admin' ? 'Super Admin' : 'Admin')}
                                      </span>
                                    </div>

                                    {/* Secondary Role - Placed directly below primary role */}
                                    <div className="flex items-center gap-1.5 leading-tight">
                                      <span className="text-[10px] font-mono font-semibold text-indigo-600 shrink-0">Secondary:</span>
                                      {secondaryTitle ? (
                                        <button
                                          type="button"
                                          onClick={() => setSecondaryTitleModalData({ admin: adm, group })}
                                          className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 transition-colors cursor-pointer group/btn min-w-0 max-w-[170px]"
                                          title={`Secondary Role: "${secondaryTitle}". Click to edit.`}
                                        >
                                          <span className="truncate">{secondaryTitle}</span>
                                          <Pencil className="w-2.5 h-2.5 text-indigo-500 group-hover/btn:text-indigo-700 shrink-0" />
                                        </button>
                                      ) : (
                                        <button
                                          type="button"
                                          onClick={() => setSecondaryTitleModalData({ admin: adm, group })}
                                          className="text-[10px] font-medium text-slate-400 hover:text-indigo-600 hover:underline transition-colors cursor-pointer"
                                          title="Super Admin: Click to assign secondary role in this group"
                                        >
                                          + Assign
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ================= MODAL: CREATE / EDIT GROUP ================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
                  <FolderHeart className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-slate-900">
                    {editingGroup ? 'Edit Admin Group' : 'Create New Admin Group'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Define name, mandate description, and assign administrators
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveGroup} className="p-6 overflow-y-auto space-y-4 flex-1">
              <div>
                <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider font-semibold mb-1">
                  Group Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Protocol Upgrade Council, AML Compliance Desk..."
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider font-semibold mb-1">
                  Description / Mandate
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe the operational mandate or oversight responsibilities of this group..."
                  rows={2}
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 resize-none"
                />
              </div>

              {/* Color Picker */}
              <div>
                <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider font-semibold mb-1.5">
                  Badge Color
                </label>
                <div className="flex items-center gap-2 flex-wrap">
                  {PRESET_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormData({ ...formData, color: c })}
                      className={`w-7 h-7 rounded-full transition-transform cursor-pointer ${
                        formData.color === c
                          ? 'scale-120 ring-2 ring-indigo-500 ring-offset-2'
                          : 'opacity-80 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Assign Initial Admins */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] font-mono text-slate-500 uppercase tracking-wider font-semibold">
                    Select Administrators ({formData.adminIds.length} Selected)
                  </label>
                  <span className="text-[10px] text-slate-400">
                    Admins can be in multiple groups
                  </span>
                </div>

                <div className="space-y-1.5 max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-2xl border border-slate-200">
                  {allAdmins.map((adm) => {
                    const isChecked = formData.adminIds.includes(adm.id);
                    return (
                      <div
                        key={adm.id}
                        onClick={() => {
                          setFormData((prev) => ({
                            ...prev,
                            adminIds: isChecked
                              ? prev.adminIds.filter((id) => id !== adm.id)
                              : [...prev.adminIds, adm.id],
                          }));
                        }}
                        className={`p-2 rounded-xl flex items-center justify-between transition-colors cursor-pointer ${
                          isChecked ? 'bg-indigo-50/80 border border-indigo-200' : 'hover:bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-4 h-4 rounded-md flex items-center justify-center transition-colors border ${
                              isChecked
                                ? 'bg-indigo-600 border-indigo-600 text-white'
                                : 'border-slate-300 bg-white text-transparent'
                            }`}
                          >
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-900">{adm.name}</span>
                            <span className="text-[11px] font-mono text-amber-600 ml-1.5">
                              {adm.handle}
                            </span>
                          </div>
                        </div>

                        <span className="text-[10px] font-mono text-slate-500">
                          {adm.jobTitle || (adm.role === 'super_admin' ? 'Super Admin' : 'Admin')}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{editingGroup ? 'Update Group' : 'Create Group'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: MANAGE MEMBERS SPECIFIC GROUP ================= */}
      {managingMembersGroup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 shrink-0">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center text-white font-bold shadow-xs shrink-0"
                  style={{ backgroundColor: managingMembersGroup.color }}
                >
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-slate-900">
                    Manage Members: {managingMembersGroup.name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Admins can be selected into multiple groups
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setManagingMembersGroup(null)}
                className="w-8 h-8 rounded-full hover:bg-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Admin Filter Search */}
            <div className="px-6 py-3 border-b border-slate-100 bg-slate-50/50 shrink-0">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={adminSearchQuery}
                  onChange={(e) => setAdminSearchQuery(e.target.value)}
                  placeholder="Filter administrators by name or handle..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Admin Checklist */}
            <div className="p-6 overflow-y-auto space-y-2 flex-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono text-slate-500 uppercase tracking-wider font-semibold">
                  Administrator Directory ({selectedAdminIdsForGroup.length} Assigned)
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAdminIdsForGroup(allAdmins.map((a) => a.id))}
                    className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                  >
                    Select All
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    type="button"
                    onClick={() => setSelectedAdminIdsForGroup([])}
                    className="text-[11px] font-semibold text-slate-500 hover:text-slate-700 cursor-pointer"
                  >
                    Deselect All
                  </button>
                </div>
              </div>

              {allAdmins
                .filter(
                  (a) =>
                    a.name.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                    a.handle.toLowerCase().includes(adminSearchQuery.toLowerCase()) ||
                    a.email.toLowerCase().includes(adminSearchQuery.toLowerCase())
                )
                .map((adm) => {
                  const isChecked = selectedAdminIdsForGroup.includes(adm.id);

                  return (
                    <div
                      key={adm.id}
                      onClick={() => toggleAdminInManageModal(adm.id)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 overflow-hidden ${
                        isChecked
                          ? 'bg-indigo-50/50 border-indigo-300 ring-1 ring-indigo-500/20 shadow-2xs'
                          : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1 overflow-hidden">
                        <div
                          className={`w-5 h-5 rounded-lg flex items-center justify-center transition-colors border shrink-0 ${
                            isChecked
                              ? 'bg-indigo-600 border-indigo-600 text-white'
                              : 'border-slate-300 bg-white text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>

                        <div className="relative shrink-0">
                          <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-xs border border-amber-200">
                            {adm.name.charAt(0)}
                          </div>
                          <span
                            className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full ring-2 ring-white ${
                              adm.status === 'active' ? 'bg-emerald-500' : 'bg-rose-400'
                            }`}
                            title={`Status: ${adm.status}`}
                          />
                        </div>

                        <div className="space-y-0.5 min-w-0 flex-1 overflow-hidden">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="font-bold text-xs text-slate-900 truncate">{adm.name}</span>
                            <span className="font-mono text-[11px] text-amber-600 truncate shrink-0">{adm.handle}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[10px] text-slate-500 min-w-0">
                            <span className="text-slate-400 shrink-0 font-mono">Primary:</span>
                            <span className="font-medium text-slate-700 truncate">{adm.jobTitle || (adm.role === 'super_admin' ? 'Super Admin' : 'Admin')}</span>
                          </div>
                          {managingMembersGroup.memberSecondaryTitles?.[adm.id] && (
                            <div className="flex items-center gap-1.5 text-[10px] text-indigo-600 min-w-0">
                              <span className="font-mono text-indigo-500 font-semibold shrink-0">Secondary:</span>
                              <span
                                className="font-semibold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded border border-indigo-200/70 truncate max-w-[200px]"
                                title={managingMembersGroup.memberSecondaryTitles[adm.id]}
                              >
                                {managingMembersGroup.memberSecondaryTitles[adm.id]}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0 ${
                          adm.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {adm.status}
                      </span>
                    </div>
                  );
                })}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/70">
              <span className="text-xs text-slate-500 font-medium">
                {selectedAdminIdsForGroup.length} administrators assigned
              </span>
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setManagingMembersGroup(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveMembers}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save Members</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Secondary Job Title in Group Assignment */}
      {secondaryTitleModalData && (
        <AdminSecondaryTitleModal
          admin={secondaryTitleModalData.admin}
          group={secondaryTitleModalData.group}
          currentTitle={secondaryTitleModalData.group.memberSecondaryTitles?.[secondaryTitleModalData.admin.id] || ''}
          onClose={() => setSecondaryTitleModalData(null)}
          onSave={handleSaveSecondaryTitle}
        />
      )}

      {/* Modal: Delete Group Confirmation */}
      {groupToDelete && (
        <AdminGroupDeleteModal
          group={groupToDelete}
          onClose={() => setGroupToDelete(null)}
          onConfirm={handleConfirmDelete}
        />
      )}
    </div>
  );
};
