
import { PublicTradeAlertJSON, PublicDisclosureType, DisclosureAssetClass } from '../types/stocks';

export type CelebrityEntityCategory = 
  | 'Governmental Public Servant' 
  | 'Independent Entrepreneur' 
  | 'Institutional Allocator' 
  | 'Sovereign Pioneer';

export type OfficialAgencySeal = 'US_CONGRESS' | 'US_SENATE' | 'SEC' | 'SOVEREIGN';

export interface DetailedOfficialTransaction {
  securityTitle: string;
  transactionDate: string;
  filingDate: string;
  transactionCode: string; // e.g. "P - Open Market Purchase", "S - Open Market Sale"
  action: 'BUY' | 'SELL';
  shares: string;
  price: string;
  valuation: string;
  acquiredDisposed: 'A' | 'D';
  ownershipType: 'Direct (D)' | 'Indirect (I)';
  ownershipNature: string;
}

export interface TargetEntityProfile {
  id: string;
  name: string;
  identifier: string; // CIK or House/Senate Member ID
  sourceAgency: 'US House Public Disclosures' | 'SEC EDGAR' | 'US Senate Financial Disclosures' | 'Peer Syndicate Network';
  disclosureType: PublicDisclosureType;
  filingFeedUrl: string;
  avatarUrl: string;
  role: string;
  entityCategory: CelebrityEntityCategory;
  officialSeal: OfficialAgencySeal;
  filingAccessionNumber: string;
  issuerName: string;
  issuerTradingSymbol: string;
  relationship: string;
  footnotes: string[];
  certificationText: string;
  digitalSignature: string;
  ecdsaSignature: string;
  recentFilings: PublicTradeAlertJSON[];
  detailedTransactions: DetailedOfficialTransaction[];
}

export const TARGET_DISCLOSURE_ENTITIES: TargetEntityProfile[] = [
  // ================= 1. GOVERNMENTAL PUBLIC SERVANTS =================
  {
    id: 'famous-pelosi',
    name: 'Nancy Pelosi',
    identifier: 'Member ID: P000197',
    sourceAgency: 'US House Public Disclosures',
    disclosureType: 'STOCK Act PTR',
    filingFeedUrl: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025368.pdf',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    role: 'Member of Congress (CA-11), U.S. House of Representatives',
    entityCategory: 'Governmental Public Servant',
    officialSeal: 'US_CONGRESS',
    filingAccessionNumber: 'HOUSE-PTR-2024-20025368',
    issuerName: 'NVIDIA Corporation / Apple Inc.',
    issuerTradingSymbol: 'NVDA / AAPL',
    relationship: 'Member of the U.S. House of Representatives',
    certificationText: 'I CERTIFY that the statements I have made on the attached Periodic Transaction Report are true, complete, and correct to the best of my knowledge and belief pursuant to the STOCK Act of 2012 (P.L. 112-105).',
    digitalSignature: 'Digitally Signed by: Hon. Nancy Pelosi (Timestamp: 07/02/2024 14:28:11 EST)',
    ecdsaSignature: 'ECDSA Signature: 3045022100c8b91a473e518f921092efca52870198f12a3d84b726419e083c71c5ef9df3... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Transaction effected by spouse (Paul Pelosi) pursuant to personal investment discretion.',
      'Purchase of 50 Call options with a strike price of $100 expiring 12/20/2024.',
      'Filed within statutory 45-day reporting window mandated by 5 U.S.C. app. § 103(l).'
    ],
    detailedTransactions: [
      {
        securityTitle: 'NVIDIA Corporation - Call Options ($100 Strike, Exp 12/20/2024)',
        transactionDate: '2024-06-26',
        filingDate: '2024-07-02',
        transactionCode: 'P - Open Market Purchase',
        action: 'BUY',
        shares: '50 Call Options (5,000 underlying shares)',
        price: '$126.09 (Spot)',
        valuation: '$1,000,001 - $5,000,000',
        acquiredDisposed: 'A',
        ownershipType: 'Indirect (I)',
        ownershipNature: 'By Spouse (Paul Pelosi)'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock, $0.00001 Par Value',
        transactionDate: '2024-07-26',
        filingDate: '2024-07-30',
        transactionCode: 'P - Open Market Purchase',
        action: 'BUY',
        shares: '20,000 shares',
        price: '$217.96',
        valuation: '$1,000,001 - $5,000,000',
        acquiredDisposed: 'A',
        ownershipType: 'Indirect (I)',
        ownershipNature: 'By Spouse (Paul Pelosi)'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-26 | Filed: 2024-07-02',
        filer_name: 'Nancy Pelosi',
        disclosure_type: 'STOCK Act PTR',
        ticker: 'NVDA',
        action: 'BUY',
        share_quantity_or_value: '$1,000,001 - $5,000,000 (50 Call options, $100 strike)',
        asset_class: 'Option (Call)',
        source_document_url: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025368.pdf',
        cik_or_member_id: 'House Member ID: P000197'
      },
      {
        timestamp: 'Execution: 2024-07-26 | Filed: 2024-07-30',
        filer_name: 'Nancy Pelosi',
        disclosure_type: 'STOCK Act PTR',
        ticker: 'AAPL',
        action: 'BUY',
        share_quantity_or_value: '$1,000,001 - $5,000,000 (20,000 shares)',
        asset_class: 'Stock',
        source_document_url: 'https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/2024/20025368.pdf',
        cik_or_member_id: 'House Member ID: P000197'
      }
    ]
  },
  {
    id: 'famous-tuberville',
    name: 'Tommy Tuberville',
    identifier: 'Member ID: S001201',
    sourceAgency: 'US Senate Financial Disclosures',
    disclosureType: 'STOCK Act PTR',
    filingFeedUrl: 'https://efdsearch.senate.gov/search/view/ptr/e7893c34-0761-4c2b-ac52-e303f166517f/',
    avatarUrl: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=300&q=80',
    role: 'United States Senator (Alabama)',
    entityCategory: 'Governmental Public Servant',
    officialSeal: 'US_SENATE',
    filingAccessionNumber: 'SENATE-PTR-2024-4001982',
    issuerName: 'United States Steel Corp / Intel Corporation',
    issuerTradingSymbol: 'X / INTC',
    relationship: 'United States Senator (AL)',
    certificationText: 'I certify that the transactions reported herein comply with the ethics directives of the Select Committee on Ethics under the STOCK Act (Pub. L. 112-105).',
    digitalSignature: 'Digitally Signed by: Hon. Tommy Tuberville (Timestamp: 07/15/2024 11:14:02 EST)',
    ecdsaSignature: 'ECDSA Signature: 3045022100f14d82b9a7c3e560184b9e28f01a3982e5c82910fa728109d73ab8174f82... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Disclosed under Senate Rule XXXIV and Title I of the Ethics in Government Act.',
      'Commodity and option trades reported within statutory timeframe.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'United States Steel Corp. - Common Stock',
        transactionDate: '2024-07-10',
        filingDate: '2024-07-15',
        transactionCode: 'P - Open Market Purchase',
        action: 'BUY',
        shares: '15,000 shares',
        price: '$38.25',
        valuation: '$250,001 - $500,000',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Beneficial Owner'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-07-10 | Filed: 2024-07-15',
        filer_name: 'Tommy Tuberville',
        disclosure_type: 'STOCK Act PTR',
        ticker: 'X',
        action: 'BUY',
        share_quantity_or_value: '$250,001 - $500,000',
        asset_class: 'Stock',
        source_document_url: 'https://efdsearch.senate.gov/search/view/ptr/e7893c34-0761-4c2b-ac52-e303f166517f/',
        cik_or_member_id: 'Senate Member ID: S001201'
      }
    ]
  },

  // ================= 2. INDEPENDENT ENTREPRENEURS & FOUNDERS =================
  {
    id: 'famous-elon',
    name: 'Elon Musk',
    identifier: 'CIK: 0001494730',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 4',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1494730/000162828026044069/xslF345X06/wk-form4_1781740812.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    role: 'Technoking, CEO & Director, Tesla, Inc.',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001494730-24-000042',
    issuerName: 'Tesla, Inc. (CIK: 0001318605)',
    issuerTradingSymbol: 'TSLA',
    relationship: 'Officer: CEO / Technoking; Director; 10% Owner',
    certificationText: 'Reminder: Report on a separate line for each class of securities beneficially owned directly or indirectly. Filed pursuant to Section 16(a) of the Securities Exchange Act of 1934.',
    digitalSignature: '/s/ Elon Musk (Attorney-in-fact: Brandon Ehrhart, Date: 06/17/2024)',
    ecdsaSignature: 'ECDSA Signature: 3045022100a94e82cf5187d903a71b26c04f8e9182d634e0a781b294f83c19d084c7e2... (Sovereign Hash Proof Verified)',
    footnotes: [
      'The shares reported were acquired on the open market in accordance with the corporate insider trading policy.',
      'Reflects direct ownership in Tesla, Inc. common stock, par value $0.001 per share.',
      'No derivative instruments were utilized in connection with this reported transaction.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Tesla, Inc. - Common Stock, Par Value $0.001',
        transactionDate: '2024-06-13',
        filingDate: '2024-06-17',
        transactionCode: 'P - Open Market Purchase',
        action: 'BUY',
        shares: '2,000,000 shares',
        price: '$182.00',
        valuation: '$364,000,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Beneficial Owner'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-13 | Filed: 2024-06-17',
        filer_name: 'Elon Musk',
        disclosure_type: 'SEC Form 4',
        ticker: 'TSLA',
        action: 'BUY',
        share_quantity_or_value: '2,000,000 shares ($364,000,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1494730/000162828026044069/xslF345X06/wk-form4_1781740812.xml',
        cik_or_member_id: 'CIK: 0001494730'
      }
    ]
  },
  {
    id: 'famous-jensen',
    name: 'Jensen Huang',
    identifier: 'CIK: 0001188368',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 4',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1045810/000119764926000012/xslF345X06/wk-form4_1789765856.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'President, CEO & Director, NVIDIA Corporation',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001188368-24-000089',
    issuerName: 'NVIDIA Corporation (CIK: 0001045810)',
    issuerTradingSymbol: 'NVDA',
    relationship: 'Officer: President & CEO; Director',
    certificationText: 'Statement of Changes in Beneficial Ownership. Filed pursuant to Section 16(a) of the Securities Exchange Act of 1934 or Section 30(h) of the Investment Company Act of 1940.',
    digitalSignature: '/s/ Jen-Hsun Huang (Date: 07/08/2024)',
    ecdsaSignature: 'ECDSA Signature: 3045022100781a94ef20b63819d084c7e2b1093a8174f826d910a837e29b184b7e82... (Sovereign Hash Proof Verified)',
    footnotes: [
      'The sales reported in this Form 4 were effected pursuant to a Rule 10b5-1 trading plan adopted by the reporting person on March 14, 2024.',
      'Represents weighted average sale prices. Full details available upon request to the SEC staff or the issuer.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'NVIDIA Corporation - Common Stock, Par Value $0.001',
        transactionDate: '2024-07-05',
        filingDate: '2024-07-08',
        transactionCode: 'S - Open Market Sale (Rule 10b5-1 Plan)',
        action: 'SELL',
        shares: '240,000 shares',
        price: '$128.25',
        valuation: '$30,780,000.00',
        acquiredDisposed: 'D',
        ownershipType: 'Indirect (I)',
        ownershipNature: 'By J. & L. Huang Family Trust'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-07-05 | Filed: 2024-07-08',
        filer_name: 'Jensen Huang',
        disclosure_type: 'SEC Form 4',
        ticker: 'NVDA',
        action: 'SELL',
        share_quantity_or_value: '240,000 shares ($30,780,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1045810/000119764926000012/xslF345X06/wk-form4_1789765856.xml',
        cik_or_member_id: 'CIK: 0001188368'
      }
    ]
  },
  {
    id: 'famous-saylor',
    name: 'Michael Saylor',
    identifier: 'CIK: 0001050446',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 4',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1050446/000119312526398168/xslF345X06/ownership.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
    role: 'Executive Chairman & 10% Owner, MicroStrategy Inc.',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001050446-24-000031',
    issuerName: 'MicroStrategy Incorporated (CIK: 0001050446)',
    issuerTradingSymbol: 'MSTR',
    relationship: 'Officer: Executive Chairman; Director; 10% Owner',
    certificationText: 'Statement of Changes in Beneficial Ownership. Form 4 filed pursuant to Section 16(a) of the Exchange Act.',
    digitalSignature: '/s/ Michael J. Saylor (Date: 07/03/2024)',
    ecdsaSignature: 'ECDSA Signature: 3045022100d18f9a24e0b73819c628f9104b7e829103a846c927f810e93817a0c4f8... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Exercise of stock options granted under the 2013 Equity Incentive Plan.',
      'Proceeds allocated toward treasury Bitcoin reserve strategy.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'MicroStrategy Inc. - Class A Common Stock',
        transactionDate: '2024-07-01',
        filingDate: '2024-07-03',
        transactionCode: 'M - Option Exercise / Acquisition',
        action: 'BUY',
        shares: '12,500 shares',
        price: '$150.00 (Exercise)',
        valuation: '$18,750,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-07-01 | Filed: 2024-07-03',
        filer_name: 'Michael Saylor',
        disclosure_type: 'SEC Form 4',
        ticker: 'MSTR',
        action: 'BUY',
        share_quantity_or_value: '12,500 shares ($18,750,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1050446/000119312526398168/xslF345X06/ownership.xml',
        cik_or_member_id: 'CIK: 0001050446'
      }
    ]
  },
  {
    id: 'famous-bezos',
    name: 'Jeff Bezos',
    identifier: 'CIK: 0001043298',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 4',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1043298/000104329826000002/xslF345X06/wk-form4_1787862279.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    role: 'Executive Chair & 10% Owner, Amazon.com, Inc.',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001043298-24-000055',
    issuerName: 'Amazon.com, Inc. (CIK: 0001018724)',
    issuerTradingSymbol: 'AMZN',
    relationship: 'Officer: Executive Chair; Director; 10% Owner',
    certificationText: 'Statement of Changes in Beneficial Ownership. Filed pursuant to Section 16(a) of the Securities Exchange Act of 1934.',
    digitalSignature: '/s/ Jeffrey P. Bezos (Date: 07/12/2024)',
    ecdsaSignature: 'ECDSA Signature: 30450221005b82c9104f7a83e2910b84c7e2b1093a8174f826d910a837e29b184b7e... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Disclosed pursuant to a Rule 10b5-1 trading plan adopted on November 8, 2023.',
      'Shares sold in open market transactions at an average price of $198.42.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Amazon.com, Inc. - Common Stock, Par Value $0.01',
        transactionDate: '2024-07-10',
        filingDate: '2024-07-12',
        transactionCode: 'S - Open Market Sale',
        action: 'SELL',
        shares: '5,000,000 shares',
        price: '$198.42',
        valuation: '$992,100,000.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-07-10 | Filed: 2024-07-12',
        filer_name: 'Jeff Bezos',
        disclosure_type: 'SEC Form 4',
        ticker: 'AMZN',
        action: 'SELL',
        share_quantity_or_value: '5,000,000 shares ($992,100,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1043298/000104329826000002/xslF345X06/wk-form4_1787862279.xml',
        cik_or_member_id: 'CIK: 0001043298'
      }
    ]
  },

  // ================= 3. INSTITUTIONAL ALLOCATORS & HEDGE FUNDS =================
  {
    id: 'famous-gates',
    name: 'Bill Gates',
    identifier: 'CIK: 0001166559',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 13F',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1166559/000110465926097175/xslForm13F_X02/primary_doc.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=300&q=80',
    role: 'Bill & Melinda Gates Foundation Trust / Cascade Investment',
    entityCategory: 'Institutional Allocator',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001166559-24-000018',
    issuerName: 'Microsoft Corporation / Waste Management / Berkshire Hathaway',
    issuerTradingSymbol: 'MSFT / WM / BRK.B',
    relationship: 'Institutional Investment Manager (Form 13F Filer)',
    certificationText: 'The institutional investment manager filing this report and the person by whom it is signed hereby represent that all information contained herein is true, correct and complete.',
    digitalSignature: '/s/ Michael Larson (Business Manager, Bill & Melinda Gates Foundation Trust, Date: 08/14/2024)',
    ecdsaSignature: 'ECDSA Signature: 30450221003f91a82b7c094e8210b63819d084c7e2b1093a8174f826d910a837e29b... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Reported for the quarter ended June 30, 2024 pursuant to Section 13(f) of the Securities Exchange Act of 1934.',
      'Cascade Investment, LLC and Bill & Melinda Gates Foundation Trust portfolio holdings.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Microsoft Corp. - Common Stock, Par Value $0.00000625',
        transactionDate: '2024-06-30',
        filingDate: '2024-08-14',
        transactionCode: 'P - Institutional Portfolio Addition',
        action: 'BUY',
        shares: '34,600,000 shares',
        price: '$447.00',
        valuation: '$15,466,200,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Trust Portfolio'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-30 | Filed: 2024-08-14',
        filer_name: 'Bill & Melinda Gates Foundation Trust',
        disclosure_type: 'SEC Form 13F',
        ticker: 'MSFT',
        action: 'BUY',
        share_quantity_or_value: '34,600,000 shares ($15,466,200,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1166559/000110465926097175/xslForm13F_X02/primary_doc.xml',
        cik_or_member_id: 'CIK: 0001166559'
      }
    ]
  },
  {
    id: 'famous-buffett',
    name: 'Warren Buffett',
    identifier: 'CIK: 0001067983',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 13F',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1067983/000119312526352200/xslForm13F_X02/primary_doc.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'Chairman & CEO, Berkshire Hathaway Inc.',
    entityCategory: 'Institutional Allocator',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001067983-24-000052',
    issuerName: 'Berkshire Hathaway Inc. Consolidated Form 13F Portfolio',
    issuerTradingSymbol: 'AAPL / OXY / BAC',
    relationship: 'Institutional Manager & Chief Executive Officer',
    certificationText: 'Report for the Calendar Year or Quarter Ended: June 30, 2024. Institutional Investment Manager Holding Report.',
    digitalSignature: '/s/ Warren E. Buffett (Chairman & CEO, Date: 08/14/2024)',
    ecdsaSignature: 'ECDSA Signature: 3045022100918c72b0e4198f2a3d84b726419e083c617c5ef9df3a0c4f8d21b9134a... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Berkshire Hathaway Inc. institutional holding report filed under Section 13(f).',
      'Confidential treatment requested for certain positions as permitted by SEC regulations.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Apple Inc. - Common Stock',
        transactionDate: '2024-06-30',
        filingDate: '2024-08-14',
        transactionCode: 'S - Quarterly Portfolio Reduction',
        action: 'SELL',
        shares: '389,000,000 shares',
        price: '$216.45',
        valuation: '$84,200,000,000.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Berkshire Consolidated'
      },
      {
        securityTitle: 'Occidental Petroleum Corp. - Common Stock',
        transactionDate: '2024-06-30',
        filingDate: '2024-08-14',
        transactionCode: 'P - Portfolio Expansion',
        action: 'BUY',
        shares: '255,280,000 shares',
        price: '$60.00',
        valuation: '$15,316,000,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Berkshire Subsidiary'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-30 | Filed: 2024-08-14',
        filer_name: 'Berkshire Hathaway Inc.',
        disclosure_type: 'SEC Form 13F',
        ticker: 'AAPL',
        action: 'SELL',
        share_quantity_or_value: '389,000,000 shares ($84,200,000,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1067983/000119312526352200/xslForm13F_X02/primary_doc.xml',
        cik_or_member_id: 'CIK: 0001067983'
      },
      {
        timestamp: 'Execution: 2024-06-30 | Filed: 2024-08-14',
        filer_name: 'Berkshire Hathaway Inc.',
        disclosure_type: 'SEC Form 13F',
        ticker: 'OXY',
        action: 'BUY',
        share_quantity_or_value: '255,280,000 shares ($15,316,000,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1067983/000119312526352200/xslForm13F_X02/primary_doc.xml',
        cik_or_member_id: 'CIK: 0001067983'
      }
    ]
  },
  {
    id: 'famous-jim_simons',
    name: 'Jim Simons',
    identifier: 'CIK: 0001037389',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 13F',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1037389/000103738926000059/xslForm13F_X02/primary_doc.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    role: 'Founder, Renaissance Technologies LLC (Medallion Fund)',
    entityCategory: 'Institutional Allocator',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001037389-24-000067',
    issuerName: 'Renaissance Technologies LLC (Medallion & RIEF Funds)',
    issuerTradingSymbol: 'TSLA / NVDA',
    relationship: 'Institutional Quantitative Manager',
    certificationText: 'Form 13F Information Table. Disclosing institutional holdings managed under quantitative algorithmic investment strategies.',
    digitalSignature: '/s/ Mark Silber (General Counsel & CFO, Renaissance Technologies LLC, Date: 08/14/2024)',
    ecdsaSignature: 'ECDSA Signature: 3045022100b271a94e8210b63819d084c7e2b1093a8174f826d910a837e29b184b7e... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Algorithmic execution across multi-asset class equities for the quarter ended June 30, 2024.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Tesla, Inc. - Common Stock',
        transactionDate: '2024-06-30',
        filingDate: '2024-08-14',
        transactionCode: 'P - Quantitative Position Entry',
        action: 'BUY',
        shares: '1,250,000 shares',
        price: '$255.00',
        valuation: '$318,750,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Medallion Portfolio'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-30 | Filed: 2024-08-14',
        filer_name: 'Renaissance Technologies LLC',
        disclosure_type: 'SEC Form 13F',
        ticker: 'TSLA',
        action: 'BUY',
        share_quantity_or_value: '1,250,000 shares ($318,750,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1037389/000103738926000059/xslForm13F_X02/primary_doc.xml',
        cik_or_member_id: 'CIK: 0001037389'
      }
    ]
  },
  {
    id: 'famous-ackman',
    name: 'Bill Ackman',
    identifier: 'CIK: 0001336528',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 13F',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1336528/000117266126002336/xslForm13F_X02/primary_doc.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    role: 'CEO & Portfolio Manager, Pershing Square Capital Management',
    entityCategory: 'Institutional Allocator',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001336528-24-000021',
    issuerName: 'Alphabet Inc. / NVIDIA Corporation',
    issuerTradingSymbol: 'GOOGL / NVDA',
    relationship: 'Chief Executive Officer & Portfolio Manager',
    certificationText: 'Report for the Quarter Ended June 30, 2024. Pershing Square Capital Management, L.P.',
    digitalSignature: '/s/ William A. Ackman (CEO, Date: 08/14/2024)',
    ecdsaSignature: 'ECDSA Signature: 304502210084c7e2b1093a8174f826d910a837e29b184b7e829103a846c927f810e9... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Concentrated long-equity investments in large-cap compounders.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Alphabet Inc. - Class A Common Stock',
        transactionDate: '2024-06-30',
        filingDate: '2024-08-14',
        transactionCode: 'P - High Conviction Holding Addition',
        action: 'BUY',
        shares: '4,350,000 shares',
        price: '$182.07',
        valuation: '$792,000,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Pershing Square Funds'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-30 | Filed: 2024-08-14',
        filer_name: 'Pershing Square Capital Management, L.P.',
        disclosure_type: 'SEC Form 13F',
        ticker: 'GOOGL',
        action: 'BUY',
        share_quantity_or_value: '4,350,000 shares ($792,000,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1336528/000117266126002336/xslForm13F_X02/primary_doc.xml',
        cik_or_member_id: 'CIK: 0001336528'
      }
    ]
  },
  {
    id: 'famous-cathie',
    name: 'Cathie Wood',
    identifier: 'CIK: 0001605941',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 13F',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1697748/000110465926096910/xslForm13F_X02/primary_doc.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    role: 'Founder, CEO & CIO, ARK Investment Management LLC',
    entityCategory: 'Institutional Allocator',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001605941-24-000045',
    issuerName: 'ARK Innovation ETF Portfolio Holdings',
    issuerTradingSymbol: 'BSYN / TSLA',
    relationship: 'Chief Investment Officer & Portfolio Manager',
    certificationText: 'ARK Investment Management LLC Form 13F Information Table filed pursuant to Section 13(f).',
    digitalSignature: '/s/ Catherine D. Wood (Chief Executive Officer, Date: 08/14/2024)',
    ecdsaSignature: 'ECDSA Signature: 3045022100e4b85c184ad69cb2321481f33f671c5ef9df3a0c4f8d21b9134a6217... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Disruptive innovation focus across autonomous tech, genomics, and artificial intelligence.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Tesla, Inc. - Common Stock',
        transactionDate: '2024-06-30',
        filingDate: '2024-08-14',
        transactionCode: 'P - Innovation Basket Weighting',
        action: 'BUY',
        shares: '1,200,000 shares',
        price: '$255.00',
        valuation: '$306,000,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'ARK Active ETFs'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-30 | Filed: 2024-08-14',
        filer_name: 'ARK Investment Management LLC',
        disclosure_type: 'SEC Form 13F',
        ticker: 'TSLA',
        action: 'BUY',
        share_quantity_or_value: '1,200,000 shares ($306,000,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1697748/000110465926096910/xslForm13F_X02/primary_doc.xml',
        cik_or_member_id: 'CIK: 0001605941'
      }
    ]
  },
  {
    id: 'famous-dalio',
    name: 'Ray Dalio',
    identifier: 'CIK: 0001350694',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'SEC Form 13F',
    filingFeedUrl: 'https://www.sec.gov/Archives/edgar/data/1350694/000135069426000003/xslForm13F_X02/primary_doc.xml',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
    role: 'Founder & CIO Mentor, Bridgewater Associates, LP',
    entityCategory: 'Institutional Allocator',
    officialSeal: 'SEC',
    filingAccessionNumber: 'SEC-0001350694-24-000078',
    issuerName: 'Bridgewater Associates Pure Alpha & All Weather Portfolios',
    issuerTradingSymbol: 'HYPR / SPY',
    relationship: 'Founder & Senior Advisor',
    certificationText: 'Bridgewater Associates, LP Form 13F Institutional Holding Report for the Period Ended June 30, 2024.',
    digitalSignature: '/s/ Nir Bar Dea (CEO, Bridgewater Associates, Date: 08/14/2024)',
    ecdsaSignature: 'ECDSA Signature: 3045022100c628f9104b7e829103a846c927f810e93817a0c4f8d21b9134a6217c5e... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Macro asset allocation across diversified sovereign balance sheets and indices.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Hyperion Corp - Common Equity',
        transactionDate: '2024-06-30',
        filingDate: '2024-08-14',
        transactionCode: 'P - All Weather Macro Balance',
        action: 'BUY',
        shares: '850,000 shares',
        price: '$54.20',
        valuation: '$46,070,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Bridgewater LP'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-06-30 | Filed: 2024-08-14',
        filer_name: 'Bridgewater Associates, LP',
        disclosure_type: 'SEC Form 13F',
        ticker: 'HYPR',
        action: 'BUY',
        share_quantity_or_value: '850,000 shares ($46,070,000)',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/Archives/edgar/data/1350694/000135069426000003/xslForm13F_X02/primary_doc.xml',
        cik_or_member_id: 'CIK: 0001350694'
      }
    ]
  },

  // ================= 4. SOVEREIGN & CRYPTO PIONEERS =================
  {
    id: 'demo-satoshi-nakamoto',
    name: 'Satoshi Nakamoto',
    identifier: 'Genesis Reserve Key: 1A1zP1eP',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'On-Chain Proof of Reserve',
    filingFeedUrl: 'https://mempool.space/address/1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    role: 'Pioneer of Sovereign Digital Cash & Cryptographic Proof',
    entityCategory: 'Sovereign Pioneer',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'SOV-GENESIS-BLOCK-000000',
    issuerName: 'Satoshi Nakamoto Genesis Vault & Sovereign Reserve',
    issuerTradingSymbol: 'ALEX / BTC',
    relationship: 'Originator & Cryptographic Sovereign Signer',
    certificationText: 'CRYPTOGRAPHIC PROOF OF RESERVE: Verified on-chain ledger proof matching Genesis Block UTXO state.',
    digitalSignature: 'ECDSA Signature: 3045022100e4b85c184ad69cb2321481f33f6... (Sovereign Hash Proof Verified)',
    ecdsaSignature: 'ECDSA Signature: 3045022100e4b85c184ad69cb2321481f33f6... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Autonomous decentralized ledger entry with mathematical immutability.',
      'Proof of Reserve validated against public blockchain nodes worldwide.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Alexandria Sovereign Reserve Equity (ALEX)',
        transactionDate: '2024-08-01',
        filingDate: '2024-08-01',
        transactionCode: 'P - Genesis Mint Allocation',
        action: 'BUY',
        shares: '50,000 shares',
        price: '$28.75',
        valuation: '$1,437,500.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Genesis Vault'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-08-01 | Filed: 2024-08-01',
        filer_name: 'Satoshi Nakamoto Genesis Vault',
        disclosure_type: 'On-Chain Proof of Reserve',
        ticker: 'ALEX',
        action: 'BUY',
        share_quantity_or_value: '50,000 shares ($1,437,500)',
        asset_class: 'Sovereign Equity',
        source_document_url: 'https://mempool.space/address/1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
        cik_or_member_id: 'Genesis Key: 1A1zP1eP'
      }
    ]
  },
  {
    id: 'famous-vitalik',
    name: 'Vitalik Buterin',
    identifier: 'Public Wallet: 0xd8dA6BF269',
    sourceAgency: 'SEC EDGAR',
    disclosureType: 'On-Chain Proof of Reserve',
    filingFeedUrl: 'https://etherscan.io/address/0xd8da6bf26964af9d7eed9e03e53415d37aa96045',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    role: 'Co-Founder, Ethereum Protocol & Public Goods Steward',
    entityCategory: 'Sovereign Pioneer',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'ETH-PUBLIC-DISCLOSURE-2024',
    issuerName: 'Ethereum Public Goods & Kanro Biotech Reserve',
    issuerTradingSymbol: 'ETH / SOLN',
    relationship: 'Protocol Architect & Philanthropic Allocator',
    certificationText: 'Public Ethereum state verification confirming token transfer and public treasury allocation.',
    digitalSignature: 'EIP-712 Typed Signature: 0x82a981df... (Steward Verified)',
    ecdsaSignature: 'ECDSA Signature: 3045022100a7b910e82c3f9184b7e829103a846c927f810e93817a0c4f8d21b9134a... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Philanthropic treasury allocation for public epidemic defense and cryptographic infrastructure.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Solana Network Native Holdings (SOLN)',
        transactionDate: '2024-07-20',
        filingDate: '2024-07-20',
        transactionCode: 'P - Cross-Chain Strategic Reserve',
        action: 'BUY',
        shares: '15,000 tokens',
        price: '$180.00',
        valuation: '$2,700,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Vitalik.eth Wallet'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2024-07-20 | Filed: 2024-07-20',
        filer_name: 'Vitalik Buterin (vitalik.eth)',
        disclosure_type: 'On-Chain Proof of Reserve',
        ticker: 'SOLN',
        action: 'BUY',
        share_quantity_or_value: '15,000 tokens ($2,700,000)',
        asset_class: 'Sovereign Equity',
        source_document_url: 'https://etherscan.io/address/0xd8da6bf26964af9d7eed9e03e53415d37aa96045',
        cik_or_member_id: 'Wallet: 0xd8dA6BF269'
      }
    ]
  },
  // ================= 5. COMMUNITY FRIENDS & PEER SYNDICATE =================
  {
    id: 'user-elena_rostova',
    name: 'Elena Rostova',
    identifier: 'Peer Node: #0x82f14c9a',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    role: 'Lead Plasma Magnetics & Sovereign Trustee',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-ROSTOVA-2026-M09',
    issuerName: 'Synthetix Systems / Sovereign Equity',
    issuerTradingSymbol: 'NVDA / AAPL / TSLA',
    relationship: 'Verified Syndicate Mutual Peer (12 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: Verified trades executed in the past month recorded to mutual peer ledger.',
    digitalSignature: '/s/ Elena Rostova (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 304502210082f14c9a3b708e1920d84b726419e083c71c5ef9df3a0c4f8d21b9134a6217... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Verified executions within the past 30 days across liquid market equities.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-21',
        filingDate: '2026-09-21',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,200 shares',
        price: '$124.50',
        valuation: '$149,400.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-17',
        filingDate: '2026-09-17',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '850 shares',
        price: '$228.30',
        valuation: '$194,055.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Tesla, Inc. - Common Stock (TSLA)',
        transactionDate: '2026-09-10',
        filingDate: '2026-09-10',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '500 shares',
        price: '$245.00',
        valuation: '$122,500.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Microsoft Corporation - Common Stock (MSFT)',
        transactionDate: '2026-09-02',
        filingDate: '2026-09-02',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '600 shares',
        price: '$442.10',
        valuation: '$265,260.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Amazon.com, Inc. - Common Stock (AMZN)',
        transactionDate: '2026-08-27',
        filingDate: '2026-08-27',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,000 shares',
        price: '$185.20',
        valuation: '$185,200.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-21 | Filed: 2026-09-21',
        filer_name: 'Elena Rostova',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'NVDA',
        action: 'BUY',
        share_quantity_or_value: '1,200 shares ($149,400)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x82f14c9a'
      }
    ]
  },
  {
    id: 'user-1',
    name: 'Elena Rostova',
    identifier: 'Peer Node: #0x82f14c9a',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    role: 'Lead Plasma Magnetics & Sovereign Trustee',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-ROSTOVA-2026-M09',
    issuerName: 'Synthetix Systems / Sovereign Equity',
    issuerTradingSymbol: 'NVDA / AAPL / TSLA',
    relationship: 'Verified Syndicate Mutual Peer (12 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: Verified trades executed in the past month recorded to mutual peer ledger.',
    digitalSignature: '/s/ Elena Rostova (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 304502210082f14c9a3b708e1920d84b726419e083c71c5ef9df3a0c4f8d21b9134a6217... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Verified executions within the past 30 days across liquid market equities.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-21',
        filingDate: '2026-09-21',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,200 shares',
        price: '$124.50',
        valuation: '$149,400.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-17',
        filingDate: '2026-09-17',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '850 shares',
        price: '$228.30',
        valuation: '$194,055.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Tesla, Inc. - Common Stock (TSLA)',
        transactionDate: '2026-09-10',
        filingDate: '2026-09-10',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '500 shares',
        price: '$245.00',
        valuation: '$122,500.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Microsoft Corporation - Common Stock (MSFT)',
        transactionDate: '2026-09-02',
        filingDate: '2026-09-02',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '600 shares',
        price: '$442.10',
        valuation: '$265,260.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Amazon.com, Inc. - Common Stock (AMZN)',
        transactionDate: '2026-08-27',
        filingDate: '2026-08-27',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,000 shares',
        price: '$185.20',
        valuation: '$185,200.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-21 | Filed: 2026-09-21',
        filer_name: 'Elena Rostova',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'NVDA',
        action: 'BUY',
        share_quantity_or_value: '1,200 shares ($149,400)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x82f14c9a'
      }
    ]
  },
  {
    id: 'user-lord_sterling',
    name: 'Lord Sterling',
    identifier: 'Peer Node: #0x4a7b910e',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'Swiss Freeport Trustee & Sovereign Syndicate',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-STERLING-2026-M09',
    issuerName: 'Sterling Global Treasury',
    issuerTradingSymbol: 'VLT-YLD / NVDA / SPY',
    relationship: 'Verified Syndicate Mutual Peer (8 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: Certified peer execution record for the past month logged to immutable decentralized registry.',
    digitalSignature: '/s/ Lord Sterling (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 30450221004a7b910e82c3f9184b7e829103a846c927f810e93817a0c4f8d21b9134a62... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Past 30 days treasury rebalancing executed across equity and yield assets.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Global Vault Yield & Treasury Corp (VLT-YLD)',
        transactionDate: '2026-09-22',
        filingDate: '2026-09-22',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '2,500 shares',
        price: '$102.40',
        valuation: '$256,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-19',
        filingDate: '2026-09-19',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,500 shares',
        price: '$122.80',
        valuation: '$184,200.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Alphabet Inc. - Class A Common Stock (GOOGL)',
        transactionDate: '2026-09-14',
        filingDate: '2026-09-14',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '900 shares',
        price: '$179.50',
        valuation: '$161,550.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'SPDR S&P 500 ETF Trust (SPY)',
        transactionDate: '2026-09-05',
        filingDate: '2026-09-05',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '750 shares',
        price: '$562.00',
        valuation: '$421,500.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-08-29',
        filingDate: '2026-08-29',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,100 shares',
        price: '$226.40',
        valuation: '$249,040.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-22 | Filed: 2026-09-22',
        filer_name: 'Lord Sterling',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'VLT-YLD',
        action: 'BUY',
        share_quantity_or_value: '2,500 shares ($256,000)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x4a7b910e'
      }
    ]
  },
  {
    id: 'user-2',
    name: 'Lord Sterling',
    identifier: 'Peer Node: #0x4a7b910e',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'Swiss Freeport Trustee & Sovereign Syndicate',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-STERLING-2026-M09',
    issuerName: 'Sterling Global Treasury',
    issuerTradingSymbol: 'VLT-YLD / NVDA / SPY',
    relationship: 'Verified Syndicate Mutual Peer (8 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: Certified peer execution record for the past month logged to immutable decentralized registry.',
    digitalSignature: '/s/ Lord Sterling (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 30450221004a7b910e82c3f9184b7e829103a846c927f810e93817a0c4f8d21b9134a62... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Past 30 days treasury rebalancing executed across equity and yield assets.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Global Vault Yield & Treasury Corp (VLT-YLD)',
        transactionDate: '2026-09-22',
        filingDate: '2026-09-22',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '2,500 shares',
        price: '$102.40',
        valuation: '$256,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-19',
        filingDate: '2026-09-19',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,500 shares',
        price: '$122.80',
        valuation: '$184,200.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Alphabet Inc. - Class A Common Stock (GOOGL)',
        transactionDate: '2026-09-14',
        filingDate: '2026-09-14',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '900 shares',
        price: '$179.50',
        valuation: '$161,550.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'SPDR S&P 500 ETF Trust (SPY)',
        transactionDate: '2026-09-05',
        filingDate: '2026-09-05',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '750 shares',
        price: '$562.00',
        valuation: '$421,500.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-08-29',
        filingDate: '2026-08-29',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,100 shares',
        price: '$226.40',
        valuation: '$249,040.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-22 | Filed: 2026-09-22',
        filer_name: 'Lord Sterling',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'VLT-YLD',
        action: 'BUY',
        share_quantity_or_value: '2,500 shares ($256,000)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x4a7b910e'
      }
    ]
  },
  {
    id: 'user-marcus_vance',
    name: 'Dr. Marcus Vance',
    identifier: 'Peer Node: #0x29b8c710',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
    role: 'Founder & Chief Scientist, Hyperion Fusion',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-VANCE-2026-M09',
    issuerName: 'Vance Quant Research Portfolio',
    issuerTradingSymbol: 'AAPL / QBIT / NVDA',
    relationship: 'Verified Syndicate Mutual Peer (5 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: Model-driven systematic trade allocations in the past month verified and signed by algorithmic keystore.',
    digitalSignature: '/s/ Dr. Marcus Vance (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 304502210029b8c7104f918e3a7b82c9104f7a83e2910b84c7e2b1093a8174f826d910... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Executed algorithmically within the past 30 days based on statistical variance bounds.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-20',
        filingDate: '2026-09-20',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '800 shares',
        price: '$224.10',
        valuation: '$179,280.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Quantum Dynamics Core (QBIT)',
        transactionDate: '2026-09-18',
        filingDate: '2026-09-18',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '3,200 shares',
        price: '$88.50',
        valuation: '$283,200.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-12',
        filingDate: '2026-09-12',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '1,000 shares',
        price: '$126.00',
        valuation: '$126,000.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Microsoft Corporation - Common Stock (MSFT)',
        transactionDate: '2026-09-06',
        filingDate: '2026-09-06',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '450 shares',
        price: '$445.00',
        valuation: '$200,250.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Tesla, Inc. - Common Stock (TSLA)',
        transactionDate: '2026-08-28',
        filingDate: '2026-08-28',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '700 shares',
        price: '$238.90',
        valuation: '$167,230.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-20 | Filed: 2026-09-20',
        filer_name: 'Dr. Marcus Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'AAPL',
        action: 'BUY',
        share_quantity_or_value: '800 shares ($179,280)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x29b8c710'
      }
    ]
  },
  {
    id: 'user-3',
    name: 'Dr. Marcus Vance',
    identifier: 'Peer Node: #0x29b8c710',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
    role: 'Founder & Chief Scientist, Hyperion Fusion',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-VANCE-2026-M09',
    issuerName: 'Vance Quant Research Portfolio',
    issuerTradingSymbol: 'AAPL / QBIT / NVDA',
    relationship: 'Verified Syndicate Mutual Peer (5 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: Model-driven systematic trade allocations in the past month verified and signed by algorithmic keystore.',
    digitalSignature: '/s/ Dr. Marcus Vance (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 304502210029b8c7104f918e3a7b82c9104f7a83e2910b84c7e2b1093a8174f826d910... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Executed algorithmically within the past 30 days based on statistical variance bounds.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-20',
        filingDate: '2026-09-20',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '800 shares',
        price: '$224.10',
        valuation: '$179,280.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Quantum Dynamics Core (QBIT)',
        transactionDate: '2026-09-18',
        filingDate: '2026-09-18',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '3,200 shares',
        price: '$88.50',
        valuation: '$283,200.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-12',
        filingDate: '2026-09-12',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '1,000 shares',
        price: '$126.00',
        valuation: '$126,000.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Microsoft Corporation - Common Stock (MSFT)',
        transactionDate: '2026-09-06',
        filingDate: '2026-09-06',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '450 shares',
        price: '$445.00',
        valuation: '$200,250.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Tesla, Inc. - Common Stock (TSLA)',
        transactionDate: '2026-08-28',
        filingDate: '2026-08-28',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '700 shares',
        price: '$238.90',
        valuation: '$167,230.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-20 | Filed: 2026-09-20',
        filer_name: 'Dr. Marcus Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'AAPL',
        action: 'BUY',
        share_quantity_or_value: '800 shares ($179,280)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x29b8c710'
      }
    ]
  },
  {
    id: 'user-sophia_vance',
    name: 'Sophia Vance',
    identifier: 'Peer Node: #0x6e81a94f',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
    role: 'Algorithm Designer & Quant',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-SOPHIA-2026-M09',
    issuerName: 'Vance Growth Fund',
    issuerTradingSymbol: 'TSLA / AAPL / NVDA',
    relationship: 'Verified Syndicate Mutual Peer (3 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: High conviction growth position allocations executed in the past month recorded to mutual peer ledger.',
    digitalSignature: '/s/ Sophia Vance (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 30450221006e81a94f20b73819c628f9104b7e829103a846c927f810e93817a0c4f8d2... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Clean energy, large-cap tech and automated execution across the past 30 days.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'BioSynthetica Genomics - Stable Stock (BSYN)',
        transactionDate: '2026-09-23',
        filingDate: '2026-09-23',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,200 shares',
        price: '$32.40',
        valuation: '$38,880.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Quantum Dynamics Core - Crypto Stock (QBIT)',
        transactionDate: '2026-09-23',
        filingDate: '2026-09-23',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '800 shares',
        price: '$88.50',
        valuation: '$70,800.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-23',
        filingDate: '2026-09-23',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '200 shares',
        price: '$228.10',
        valuation: '$45,620.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Tesla, Inc. - Common Stock (TSLA)',
        transactionDate: '2026-09-22',
        filingDate: '2026-09-22',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '600 shares',
        price: '$242.40',
        valuation: '$145,440.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-16',
        filingDate: '2026-09-16',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '950 shares',
        price: '$227.00',
        valuation: '$215,650.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-09',
        filingDate: '2026-09-09',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,400 shares',
        price: '$121.50',
        valuation: '$170,100.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Amazon.com, Inc. - Common Stock (AMZN)',
        transactionDate: '2026-09-03',
        filingDate: '2026-09-03',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '800 shares',
        price: '$186.75',
        valuation: '$149,400.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Alphabet Inc. - Class A Common Stock (GOOGL)',
        transactionDate: '2026-08-26',
        filingDate: '2026-08-26',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,200 shares',
        price: '$178.20',
        valuation: '$213,840.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-23 | Filed: 2026-09-23',
        filer_name: 'Sophia Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'BSYN',
        action: 'BUY',
        share_quantity_or_value: '1,200 shares ($38,880)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x6e81a94f'
      },
      {
        timestamp: 'Execution: 2026-09-23 | Filed: 2026-09-23',
        filer_name: 'Sophia Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'QBIT',
        action: 'BUY',
        share_quantity_or_value: '800 shares ($70,800)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x6e81a94f'
      },
      {
        timestamp: 'Execution: 2026-09-23 | Filed: 2026-09-23',
        filer_name: 'Sophia Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'AAPL',
        action: 'SELL',
        share_quantity_or_value: '200 shares ($45,620)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x6e81a94f'
      },
      {
        timestamp: 'Execution: 2026-09-22 | Filed: 2026-09-22',
        filer_name: 'Sophia Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'TSLA',
        action: 'BUY',
        share_quantity_or_value: '600 shares ($145,440)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x6e81a94f'
      }
    ]
  },
  {
    id: 'user-4',
    name: 'Sophia Vance',
    identifier: 'Peer Node: #0x6e81a94f',
    sourceAgency: 'Peer Syndicate Network',
    disclosureType: 'Peer Portfolio Allocation',
    filingFeedUrl: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
    role: 'Algorithm Designer & Quant',
    entityCategory: 'Independent Entrepreneur',
    officialSeal: 'SOVEREIGN',
    filingAccessionNumber: 'PEER-SOPHIA-2026-M09',
    issuerName: 'Vance Growth Fund',
    issuerTradingSymbol: 'TSLA / AAPL / NVDA',
    relationship: 'Verified Syndicate Mutual Peer (3 mutuals)',
    certificationText: 'PEER VERIFICATION OATH: High conviction growth position allocations executed in the past month recorded to mutual peer ledger.',
    digitalSignature: '/s/ Sophia Vance (Verified Peer Signature)',
    ecdsaSignature: 'ECDSA Signature: 30450221006e81a94f20b73819c628f9104b7e829103a846c927f810e93817a0c4f8d2... (Sovereign Hash Proof Verified)',
    footnotes: [
      'Clean energy, large-cap tech and automated execution across the past 30 days.',
      'Cryptographically signed by peer hardware keystore.'
    ],
    detailedTransactions: [
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-23',
        filingDate: '2026-09-23',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '200 shares',
        price: '$228.10',
        valuation: '$45,620.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Tesla, Inc. - Common Stock (TSLA)',
        transactionDate: '2026-09-22',
        filingDate: '2026-09-22',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '600 shares',
        price: '$242.40',
        valuation: '$145,440.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Apple Inc. - Common Stock (AAPL)',
        transactionDate: '2026-09-16',
        filingDate: '2026-09-16',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '950 shares',
        price: '$227.00',
        valuation: '$215,650.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'NVIDIA Corporation - Common Stock (NVDA)',
        transactionDate: '2026-09-09',
        filingDate: '2026-09-09',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,400 shares',
        price: '$121.50',
        valuation: '$170,100.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Amazon.com, Inc. - Common Stock (AMZN)',
        transactionDate: '2026-09-03',
        filingDate: '2026-09-03',
        transactionCode: 'S - Open Market Disposition',
        action: 'SELL',
        shares: '800 shares',
        price: '$186.75',
        valuation: '$149,400.00',
        acquiredDisposed: 'D',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      },
      {
        securityTitle: 'Alphabet Inc. - Class A Common Stock (GOOGL)',
        transactionDate: '2026-08-26',
        filingDate: '2026-08-26',
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '1,200 shares',
        price: '$178.20',
        valuation: '$213,840.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Portfolio Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: 'Execution: 2026-09-23 | Filed: 2026-09-23',
        filer_name: 'Sophia Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'AAPL',
        action: 'SELL',
        share_quantity_or_value: '200 shares ($45,620)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x6e81a94f'
      },
      {
        timestamp: 'Execution: 2026-09-22 | Filed: 2026-09-22',
        filer_name: 'Sophia Vance',
        disclosure_type: 'Peer Portfolio Allocation',
        ticker: 'TSLA',
        action: 'BUY',
        share_quantity_or_value: '600 shares ($145,440)',
        asset_class: 'Stock',
        source_document_url: 'https://mempool.space/tx/4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
        cik_or_member_id: 'Peer Node: #0x6e81a94f'
      }
    ]
  }
];
export function generateDeterministicEcdsaSignature(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const hex1 = Math.abs(hash).toString(16).padStart(8, '0');
  const hex2 = Math.abs((hash * 31) | 0).toString(16).padStart(8, '0');
  const hex3 = Math.abs((hash * 67) | 0).toString(16).padStart(8, '0');
  const hex4 = Math.abs((hash * 89) | 0).toString(16).padStart(8, '0');
  const hex5 = Math.abs((hash * 101) | 0).toString(16).padStart(8, '0');
  return `ECDSA Signature: 3045022100${hex1}${hex2}${hex3}${hex4}${hex5}... (Sovereign Hash Proof Verified)`;
}

export function getEntityProfile(idOrName: string): TargetEntityProfile {
  const normalized = idOrName.toLowerCase().trim();
  const found = TARGET_DISCLOSURE_ENTITIES.find(
    (e) => e.id === idOrName || e.name.toLowerCase() === normalized
  );
  if (found) {
    return found;
  }

  // Smart fallback profile: inspect if entrepreneur, governmental official, or allocator
  const isGovernmental = normalized.includes('pelosi') || normalized.includes('senat') || normalized.includes('congress') || normalized.includes('tuberville');
  const isEntrepreneur = normalized.includes('musk') || normalized.includes('huang') || normalized.includes('bezos') || normalized.includes('zuck') || normalized.includes('saylor');
  const isCrypto = normalized.includes('satoshi') || normalized.includes('vitalik') || normalized.includes('nakamoto');
  const isFriend = normalized.includes('elena') || normalized.includes('sterling') || normalized.includes('marcus') || normalized.includes('sophia') || normalized.includes('friend');

  const sourceAgency = isFriend ? 'Peer Syndicate Network' : (isGovernmental ? 'US House Public Disclosures' : 'SEC EDGAR');

  const entityCategory: CelebrityEntityCategory = isGovernmental
    ? 'Governmental Public Servant'
    : isEntrepreneur
    ? 'Independent Entrepreneur'
    : isCrypto
    ? 'Sovereign Pioneer'
    : 'Institutional Allocator';

  const disclosureType: PublicDisclosureType = isGovernmental
    ? 'STOCK Act PTR'
    : isEntrepreneur
    ? 'SEC Form 4'
    : isCrypto
    ? 'On-Chain Proof of Reserve'
    : 'SEC Form 13F';

  const officialSeal: OfficialAgencySeal = isGovernmental
    ? 'US_CONGRESS'
    : isCrypto
    ? 'SOVEREIGN'
    : 'SEC';

  const identifier = isGovernmental 
    ? `Member ID: Assigned (Ethics Comm)` 
    : isCrypto 
    ? `Public Ledger Key: 0x${normalized.slice(0, 8)}`
    : `CIK: 000${Math.floor(1000000 + Math.random() * 9000000)}`;

  return {
    id: `custom-${normalized.replace(/\s+/g, '-')}`,
    name: idOrName,
    identifier,
    sourceAgency,
    disclosureType,
    filingFeedUrl: isGovernmental ? 'https://disclosures-clerk.house.gov' : 'https://www.sec.gov/edgar/search/#/forms=4',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    role: isGovernmental 
      ? 'Public Representative & Regulatory Stakeholder'
      : isEntrepreneur
      ? 'Founder, Chief Executive Officer & Major Shareholder'
      : isCrypto
      ? 'Cryptographic Architect & Ecosystem Builder'
      : 'Institutional Investment Manager & Portfolio Allocator',
    entityCategory,
    officialSeal,
    filingAccessionNumber: `${officialSeal}-DISC-2024-009182`,
    issuerName: `${idOrName} Enterprise Holdings`,
    issuerTradingSymbol: 'SPY',
    relationship: isGovernmental ? 'Elected Public Official' : isEntrepreneur ? 'Officer: CEO; Director' : 'Principal Manager',
    certificationText: 'Official public disclosure certified under statutory disclosure requirements.',
    digitalSignature: isFriend
      ? `/s/ ${idOrName} (Verified Peer Signature)`
      : `/s/ ${idOrName} (Verified Digital Certificate)`,
    ecdsaSignature: generateDeterministicEcdsaSignature(idOrName),
    footnotes: [
      'Executed under regulatory reporting disclosure requirements.',
      'Valuation calculated from weighted execution price and statutory volume reporting brackets.'
    ],
    detailedTransactions: [
      {
        securityTitle: `${idOrName} Enterprise Equities`,
        transactionDate: new Date().toISOString().slice(0, 10),
        filingDate: new Date().toISOString().slice(0, 10),
        transactionCode: 'P - Open Market Acquisition',
        action: 'BUY',
        shares: '25,000 shares',
        price: '$150.00',
        valuation: '$3,750,000.00',
        acquiredDisposed: 'A',
        ownershipType: 'Direct (D)',
        ownershipNature: 'Direct Holding'
      }
    ],
    recentFilings: [
      {
        timestamp: `Execution: ${new Date().toISOString().slice(0, 10)} | Filed: ${new Date().toISOString().slice(0, 10)}`,
        filer_name: idOrName,
        disclosure_type: disclosureType,
        ticker: 'SPY',
        action: 'BUY',
        share_quantity_or_value: '$1,000,001 - $5,000,000',
        asset_class: 'Stock',
        source_document_url: 'https://www.sec.gov/edgar/search/#/forms=4',
        cik_or_member_id: identifier
      }
    ]
  };
}

/**
 * Format the output into the exact notification card string requested:
 * "New Trade Alert: [filer_name] filed a [disclosure_type] reporting a [action] of [ticker] ([share_quantity_or_value]) on [timestamp]."
 */
export function formatTradeNotificationCard(alert: PublicTradeAlertJSON): string {
  if (alert.disclosure_type === 'Peer Portfolio Allocation') {
    const timeStr = alert.timestamp.includes('|') 
      ? alert.timestamp.split('|')[0].trim().replace('Execution: ', '')
      : alert.timestamp;
    return `New Trade Alert: ${alert.filer_name} reported a ${alert.action} of $${alert.ticker} (${alert.share_quantity_or_value}) on ${timeStr}.`;
  }
  return `New Trade Alert: ${alert.filer_name} filed a ${alert.disclosure_type} reporting a ${alert.action} of ${alert.ticker} (${alert.share_quantity_or_value}) on ${alert.timestamp}.`;
}

/**
 * Parses and generates a structured alert
 */
export function generateStructuredAlert(params: {
  filerName: string;
  disclosureType: PublicDisclosureType;
  ticker: string;
  action: 'BUY' | 'SELL';
  shareQuantityOrValue: string;
  assetClass: DisclosureAssetClass;
  executionDate: string;
  filingDate: string;
  sourceDocumentUrl: string;
  cikOrMemberId?: string;
}): PublicTradeAlertJSON {
  return {
    timestamp: `Execution: ${params.executionDate} | Filed: ${params.filingDate}`,
    filer_name: params.filerName,
    disclosure_type: params.disclosureType,
    ticker: params.ticker.toUpperCase(),
    action: params.action,
    share_quantity_or_value: params.shareQuantityOrValue,
    asset_class: params.assetClass,
    source_document_url: params.sourceDocumentUrl,
    cik_or_member_id: params.cikOrMemberId
  };
}
