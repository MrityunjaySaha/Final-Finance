import { TransactionMode, UniversalLedgerItem } from '../types/ledger';
import { UserWalletData, FinalCoinItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { getStoredCustomCoins, isFinalCoinCreatedByUser } from '../data/customCoinsData';
import { createLedgerItemFromP2PTransfer, recordLedgerTransaction, getStoredLedgerTransactions } from './universalLedgerBridge';
import { resolveTargetUserVerificationTier } from './verificationTiers';
import { inferCurrencyCategory } from './walletBalanceUpdater';
import { getFinalCoinUsdRate } from './tokenDollarEquivalence';

export interface TransferCurrencyOption {
  id: string;
  symbol: string;
  name: string;
  mode: TransactionMode;
  categoryLabel: 'Final Coins' | 'Stablecoins' | 'Fiat Currency' | 'Cryptocurrency';
  balance: number;
  unitPriceUSD: number;
  iconBg: string;
  badge: string;
  decimals: number;
}

export interface ExecuteTransferParams {
  senderId: string;
  senderName: string;
  senderHandle?: string;
  recipientId: string;
  recipientName: string;
  recipientHandle?: string;
  coinId: string;
  coinSymbol: string;
  coinName: string;
  mode: TransactionMode;
  amount: number;
  amountUSD: number;
  memo?: string;
}

export interface TransferResult {
  success: boolean;
  error?: string;
  receipt?: UniversalLedgerItem;
  remainingBalance?: number;
}

/**
  * Returns all Final Coins & Final Currencies in the user's Final Wallet with their exact balances.
  */
export function getTransferCurrenciesForUser(
  userId: string,
  currentUser?: { id?: string; uid?: string; username?: string; handle?: string; role?: string } | null
): {
  finalCoins: TransferCurrencyOption[];
  stableCoins: TransferCurrencyOption[];
  fiatCurrencies: TransferCurrencyOption[];
  cryptoCurrencies: TransferCurrencyOption[];
  all: TransferCurrencyOption[];
} {
  const wallet: UserWalletData = getStoredUserWallets(userId);
  const coinMap = new Map<string, TransferCurrencyOption>();

  (wallet.finalCoins || []).forEach((c: FinalCoinItem) => {
    const balance = Number(c.balance || 0);
    const cleanSymbol = c.symbol.trim().replace(/^\$/, '').toUpperCase();
    if (!cleanSymbol) return;
    const existing = coinMap.get(cleanSymbol);
    coinMap.set(cleanSymbol, {
      id: c.id,
      symbol: cleanSymbol,
      name: c.name,
      mode: 'final_coin' as TransactionMode,
      categoryLabel: 'Final Coins',
      balance: (existing?.balance || 0) + balance,
      unitPriceUSD: 0,
      iconBg: 'bg-amber-500 text-black',
      badge: 'Final Currency Asset',
      decimals: 2
    });
  });

  try {
    const customCoins = getStoredCustomCoins();
    const userRef = currentUser || { id: userId, handle: userId };
    customCoins.forEach((cc) => {
      if (cc.coinType !== 'final_coin') return;
      const cleanSymbol = (cc.symbol || '').trim().replace(/^\$/, '').toUpperCase();
      if (!cleanSymbol) return;
      const existing = coinMap.get(cleanSymbol);
      const isCreatedByUser = isFinalCoinCreatedByUser(cc, userRef);
      if (existing) {
        if (!existing.name && cc.name) {
          existing.name = cc.name;
        }
      } else if (isCreatedByUser) {
        coinMap.set(cleanSymbol, {
          id: cc.id,
          symbol: cleanSymbol,
          name: cc.name || `${cleanSymbol} Final Coin`,
          mode: 'final_coin' as TransactionMode,
          categoryLabel: 'Final Coins',
          balance: 0,
          unitPriceUSD: 0,
          iconBg: 'bg-amber-500 text-black',
          badge: 'Final Currency Asset',
          decimals: 2
        });
      }
    });
  } catch {
    // Ignore storage read issues
  }

  const finalCoins = Array.from(coinMap.values()).sort((a, b) => {
    if (b.balance !== a.balance) return b.balance - a.balance;
    return a.symbol.localeCompare(b.symbol);
  });

  return {
    finalCoins,
    stableCoins: [],
    fiatCurrencies: [],
    cryptoCurrencies: [],
    all: finalCoins
  };
}

/**
 * Executes a Peer-to-Peer Transfer:
 * 1. Checks balance in sender's wallet.
 * 2. Deducts from sender's wallet and saves.
 * 3. Credits recipient's wallet and saves.
 * 4. Records transaction in Universal Ledger for both sender and recipient.
 */
export function executePeerTransfer(params: ExecuteTransferParams): TransferResult {
  const {
    senderId,
    senderName,
    senderHandle,
    recipientId,
    recipientName,
    recipientHandle,
    coinSymbol,
    coinName,
    mode,
    amount,
    amountUSD,
    memo
  } = params;

  if (!amount || amount <= 0) {
    return { success: false, error: 'Transfer amount must be greater than 0.' };
  }

  const senderWallet = getStoredUserWallets(senderId);

  if (mode !== 'final_coin' || inferCurrencyCategory(coinSymbol, senderWallet) !== 'final_coin') {
    return {
      success: false,
      error: 'Money transfers are restricted exclusively to Final Currency and Final Coins.'
    };
  }

  const cleanCoinSymbol = coinSymbol.trim().replace(/^\$/, '').toUpperCase();
  const coinIdx = (senderWallet.finalCoins || []).findIndex(
    c => c.symbol.trim().replace(/^\$/, '').toUpperCase() === cleanCoinSymbol
  );
  if (coinIdx === -1) {
    return { success: false, error: `You do not have enough balance. Available: 0 ${cleanCoinSymbol}` };
  }

  const senderCoin = senderWallet.finalCoins[coinIdx];
  const availableBalance = senderCoin.balance;
  if (availableBalance < amount) {
    return {
      success: false,
      error: `You do not have enough balance. Available: ${availableBalance.toLocaleString()} ${cleanCoinSymbol}`
    };
  }

  senderWallet.finalCoins[coinIdx].balance -= amount;
  const remainingBalance = senderWallet.finalCoins[coinIdx].balance;

  // Save Sender Wallet
  saveStoredUserWallets(senderId, senderWallet);

  // 2. Credit Recipient Wallet (create FinalCoinItem entry if recipient doesn't hold this custom/user coin yet)
  if (recipientId && recipientId !== senderId) {
    const recipientWallet = getStoredUserWallets(recipientId);
    if (!recipientWallet.finalCoins) {
      recipientWallet.finalCoins = [];
    }
    const rCoinIdx = recipientWallet.finalCoins.findIndex(
      c => c.symbol.trim().replace(/^\$/, '').toUpperCase() === cleanCoinSymbol
    );
    if (rCoinIdx !== -1) {
      recipientWallet.finalCoins[rCoinIdx].balance += amount;
    } else {
      recipientWallet.finalCoins.push({
        id: `fc-p2p-${cleanCoinSymbol.toLowerCase()}-${Date.now()}`,
        name: coinName || senderCoin.name || `${cleanCoinSymbol} Final Coin`,
        symbol: cleanCoinSymbol,
        balance: amount,
        unitPriceUSD: 0,
        change24h: senderCoin.change24h || 0,
        utility: senderCoin.utility || `Final Currency received from ${senderName}`
      });
    }
    saveStoredUserWallets(recipientId, recipientWallet);
  }

  const computedUSD = Math.round(amount * getFinalCoinUsdRate(cleanCoinSymbol) * 100) / 100;

  // 3. Create & Record Universal Ledger Item for Sender
  const senderLedgerItem = createLedgerItemFromP2PTransfer({
    amount,
    amountUSD: computedUSD,
    coinSymbol: cleanCoinSymbol,
    coinName: coinName || senderCoin.name,
    mode: 'final_coin',
    senderUser: { id: senderId, name: senderName, handle: senderHandle },
    recipientUser: { id: recipientId, name: recipientName, handle: recipientHandle },
    memo,
    isSender: true
  });
  recordLedgerTransaction(senderId, senderLedgerItem);

  // 4. Create & Record Universal Ledger Item for Recipient
  if (recipientId && recipientId !== senderId) {
    const recipientLedgerItem = createLedgerItemFromP2PTransfer({
      amount,
      amountUSD: computedUSD,
      coinSymbol: cleanCoinSymbol,
      coinName: coinName || senderCoin.name,
      mode: 'final_coin',
      senderUser: { id: senderId, name: senderName, handle: senderHandle },
      recipientUser: { id: recipientId, name: recipientName, handle: recipientHandle },
      memo,
      isSender: false
    });
    recordLedgerTransaction(recipientId, recipientLedgerItem);
  }

  return {
    success: true,
    receipt: senderLedgerItem,
    remainingBalance
  };
}

export interface ExecuteAdminTransferParams {
  adminId: string;
  adminName: string;
  adminHandle?: string;
  targetUserId: string;
  targetName: string;
  targetHandle?: string;
  action: 'add' | 'deduct';
  coinSymbol: string;
  coinName: string;
  amount: number;
  unitPriceUSD?: number;
  reason?: string;
}

/**
 * Creates a formatted ledger record from an Admin Transfer (System Mint or Burn).
 */
export function createLedgerItemFromAdminTransfer(params: {
  amount: number;
  amountUSD: number;
  coinSymbol: string;
  coinName: string;
  adminUser: { id: string; name: string; handle?: string };
  targetUser: { id: string; name: string; handle?: string };
  action: 'add' | 'deduct';
  reason?: string;
  isForAdminView: boolean;
}): UniversalLedgerItem {
  const dateObj = new Date();
  const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  const recNum = `REC-2026-ADM-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

  const isAdd = params.action === 'add';
  const targetHandle = params.targetUser.handle || params.targetUser.name;
  
  let title = '';
  let description = '';

  if (params.isForAdminView) {
    title = isAdd
      ? `Admin System Mint: +${params.amount.toLocaleString()} ${params.coinSymbol} -> @${targetHandle}`
      : `Admin System Deduction: -${params.amount.toLocaleString()} ${params.coinSymbol} <- @${targetHandle}`;
    description = isAdd
      ? `System Admin Mint: Issued ${params.amount.toLocaleString()} ${params.coinSymbol} directly to user @${targetHandle}.${params.reason ? ` Note: "${params.reason}"` : ''}`
      : `System Admin Burn: Deducted ${params.amount.toLocaleString()} ${params.coinSymbol} from user @${targetHandle}.${params.reason ? ` Note: "${params.reason}"` : ''}`;
  } else {
    title = isAdd
      ? `Admin Credit Received: +${params.amount.toLocaleString()} ${params.coinSymbol}`
      : `Admin Adjustment Deduction: -${params.amount.toLocaleString()} ${params.coinSymbol}`;
    description = isAdd
      ? `System Protocol Mint: Credited ${params.amount.toLocaleString()} ${params.coinSymbol} to your account balance by Protocol Admin.${params.reason ? ` Note: "${params.reason}"` : ''}`
      : `System Protocol Adjustment: Deducted ${params.amount.toLocaleString()} ${params.coinSymbol} from your account balance by Protocol Admin.${params.reason ? ` Note: "${params.reason}"` : ''}`;
  }

  return {
    id: `rec-adm-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    receiptNumber: recNum,
    taxYear: dateObj.getFullYear(),
    timestamp: dateStr,
    dateIso: dateObj.toISOString(),
    type: isAdd ? 'deposit' : 'p2p_transfer',
    category: 'transfer',
    mode: 'final_coin',
    title,
    description,
    amountUSD: params.amountUSD,
    feeUSD: 0.00,
    netAmountUSD: params.amountUSD,
    sourceOrDestination: isAdd ? 'Sovereign Admin System Mint Vault' : 'Sovereign Admin System Burn Reserve',
    counterpartyOrIssuer: params.isForAdminView 
      ? `User @${targetHandle}` 
      : `Protocol Admin Console`,
    paymentCoinSymbol: params.coinSymbol,
    paymentCoinAmount: params.amount,
    taxClassification: {
      formMapping: 'Administrative Adjustment',
      taxableEvent: false,
      taxableAmountUSD: 0,
      holdingPeriod: 'N/A',
      taxDeductible: false,
      irsCategoryNote: 'Administrative protocol ledger mint / burn transaction.'
    },
    status: 'Settled',
    clearingNode: 'Sovereign Admin Console Node #00 (System Mint Gateway)',
    cryptographicHash: `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
    signature: `SIG-ADM-MINT-${Math.floor(100000 + Math.random() * 900000)}`
  };
}

/**
 * Executes an Admin Transfer (Mint or Burn) into/from a target user's wallet without altering the Admin's balance.
 */
export function executeAdminTransfer(params: ExecuteAdminTransferParams): TransferResult {
  const {
    adminId,
    adminName,
    adminHandle,
    targetUserId,
    targetName,
    targetHandle,
    action,
    coinSymbol,
    coinName,
    amount,
    unitPriceUSD = 0,
    reason
  } = params;

  if (!amount || amount <= 0) {
    return { success: false, error: 'Transfer amount must be greater than 0.' };
  }

  if (action === 'add') {
    const targetTier = resolveTargetUserVerificationTier([targetUserId, targetHandle, targetName]);
    if (targetTier < 1) {
      return {
        success: false,
        error: `Recipient user (@${targetHandle || targetName || targetUserId}) must be at least Tier 1 (1 Legal ID verified) to receive Admin Final Coins.`
      };
    }
  }

  const targetWallet = getStoredUserWallets(targetUserId);
  let updatedBalance = 0;

  // Ensure finalCoins exists
  if (!targetWallet.finalCoins) {
    targetWallet.finalCoins = [];
  }

  let coinIdx = targetWallet.finalCoins.findIndex(
    c => c.symbol.toLowerCase() === coinSymbol.toLowerCase()
  );

  if (coinIdx === -1) {
    const newBal = action === 'add' ? amount : 0;
    targetWallet.finalCoins.push({
      id: `fc-admin-${coinSymbol.toLowerCase()}-${Date.now()}`,
      name: coinName || `${coinSymbol} Sovereign Token`,
      symbol: coinSymbol,
      balance: newBal,
      unitPriceUSD,
      change24h: 3.5,
      utility: 'System Admin mint allocation'
    });
    updatedBalance = newBal;
  } else {
    if (action === 'add') {
      targetWallet.finalCoins[coinIdx].balance += amount;
    } else {
      targetWallet.finalCoins[coinIdx].balance = Math.max(
        0,
        targetWallet.finalCoins[coinIdx].balance - amount
      );
    }
    updatedBalance = targetWallet.finalCoins[coinIdx].balance;
  }

  // Save Target User Wallet
  saveStoredUserWallets(targetUserId, targetWallet);

  const amountUSD = amount * unitPriceUSD;

  // Target User Ledger Record
  const targetLedgerItem = createLedgerItemFromAdminTransfer({
    amount,
    amountUSD,
    coinSymbol,
    coinName,
    adminUser: { id: adminId, name: adminName, handle: adminHandle },
    targetUser: { id: targetUserId, name: targetName, handle: targetHandle },
    action,
    reason,
    isForAdminView: false
  });
  recordLedgerTransaction(targetUserId, targetLedgerItem);

  // Admin View Ledger Record
  const adminLedgerItem = createLedgerItemFromAdminTransfer({
    amount,
    amountUSD,
    coinSymbol,
    coinName,
    adminUser: { id: adminId, name: adminName, handle: adminHandle },
    targetUser: { id: targetUserId, name: targetName, handle: targetHandle },
    action,
    reason,
    isForAdminView: true
  });
  if (adminId && adminId !== targetUserId) {
    recordLedgerTransaction(adminId, adminLedgerItem);
  }

  // Ensure recording in global ledger
  recordLedgerTransaction('global', adminLedgerItem);

  // Dispatch wallet update event for live UI refresh
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('final_finance_wallets_updated'));
  }

  return {
    success: true,
    receipt: adminLedgerItem,
    remainingBalance: updatedBalance
  };
}

/**
 * Returns P2P transfers from the ledger associated with a particular user or between two users.
 */
export function getTransfersBetweenUsers(currentUserId: string, targetUserIdOrHandle?: string): UniversalLedgerItem[] {
  const transactions = getStoredLedgerTransactions(currentUserId);
  const p2pItems = transactions.filter(t => t.type === 'p2p_transfer' || t.category === 'transfer' || t.title.toLowerCase().includes('peer transfer'));
  
  if (!targetUserIdOrHandle) return p2pItems;

  const targetLower = targetUserIdOrHandle.toLowerCase().replace('@', '');
  return p2pItems.filter(t => 
    t.counterpartyOrIssuer.toLowerCase().includes(targetLower) ||
    t.sourceOrDestination.toLowerCase().includes(targetLower) ||
    t.description.toLowerCase().includes(targetLower)
  );
}
