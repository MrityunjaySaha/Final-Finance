import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Coins, ShieldCheck, DollarSign, Bitcoin, CheckCircle2, AlertCircle, Copy, Check, ArrowRight, Sparkles, Lock, Globe, FileText, Clock, ArrowUpRight, Shield } from 'lucide-react';
import { TransactionMode, UniversalLedgerItem } from '../../types/ledger';
import {
  getTransferCurrenciesForUser,
  executePeerTransfer,
  TransferCurrencyOption
} from '../../utils/transferService';
import { UserPublicProfile } from '../../types/social';
import { AuthSession } from '../../types/auth';
import { ConfirmModal } from '../common/ConfirmModal';

interface PeerTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipient: {
    uid: string;
    userId: string;
    name: string;
    avatarUrl?: string;
    isVerified?: boolean;
    role?: string;
  };
  currentUser: AuthSession | null;
  onTransferSuccess?: (receipt: UniversalLedgerItem) => void;
}

export const PeerTransferModal: React.FC<PeerTransferModalProps> = ({
  isOpen,
  onClose,
  recipient,
  currentUser,
  onTransferSuccess
}) => {
  const currentUserId = currentUser?.id || currentUser?.uid || 'guest';
  const currentUserName = currentUser?.name || 'Sovereign Member';
  const currentUserHandle = (currentUser as any)?.userId || (currentUser as any)?.handle || currentUserId;

  // Selected Transfer Mode: 'final_coin' | 'stable_coin' | 'fiat' | 'crypto'
  const [selectedMode, setSelectedMode] = useState<TransactionMode>('final_coin');
  const [selectedCoinSymbol, setSelectedCoinSymbol] = useState<string>('AFNL');
  const [transferAmount, setTransferAmount] = useState<string>('');
  const [memo, setMemo] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [completedReceipt, setCompletedReceipt] = useState<UniversalLedgerItem | null>(null);
  const [copiedHash, setCopiedHash] = useState<boolean>(false);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  // Available currencies from user wallet
  const [walletCurrencies, setWalletCurrencies] = useState(
    getTransferCurrenciesForUser(currentUserId)
  );

  // Refresh wallet data whenever modal opens or storage updates
  useEffect(() => {
    if (isOpen) {
      setWalletCurrencies(getTransferCurrenciesForUser(currentUserId));
      setErrorMessage('');
      setCompletedReceipt(null);
      setCopiedHash(false);
    }
  }, [isOpen, currentUserId]);

  useEffect(() => {
    const handleWalletUpdated = () => {
      setWalletCurrencies(getTransferCurrenciesForUser(currentUserId));
    };
    window.addEventListener('final_finance_wallets_updated', handleWalletUpdated);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleWalletUpdated);
    };
  }, [currentUserId]);

  // Mode tabs currency list
  const activeCurrenciesList = useMemo(() => {
    switch (selectedMode) {
      case 'final_coin':
        return walletCurrencies.finalCoins;
      case 'stable_coin':
        return walletCurrencies.stableCoins;
      case 'fiat':
        return walletCurrencies.fiatCurrencies;
      case 'crypto':
        return walletCurrencies.cryptoCurrencies;
      default:
        return walletCurrencies.finalCoins;
    }
  }, [selectedMode, walletCurrencies]);

  // Automatically select first coin in mode if current selection is not in list
  useEffect(() => {
    if (activeCurrenciesList.length > 0) {
      const exists = activeCurrenciesList.some(c => c.symbol === selectedCoinSymbol);
      if (!exists) {
        setSelectedCoinSymbol(activeCurrenciesList[0].symbol);
      }
    }
  }, [selectedMode, activeCurrenciesList, selectedCoinSymbol]);

  // Active selected coin option
  const activeCoinOption = useMemo(() => {
    return (
      activeCurrenciesList.find(c => c.symbol === selectedCoinSymbol) ||
      activeCurrenciesList[0] ||
      null
    );
  }, [activeCurrenciesList, selectedCoinSymbol]);

  // Numeric amount
  const parsedAmount = parseFloat(transferAmount) || 0;
  const availableBalance = activeCoinOption ? activeCoinOption.balance : 0;
  const isInsufficient = parsedAmount > availableBalance;

  // Set Percentage helper
  const handleSetPercentage = (percent: number) => {
    if (!activeCoinOption) return;
    const val = (availableBalance * (percent / 100));
    // Round decimals nicely
    const rounded = percent === 100
      ? availableBalance
      : Number(val.toFixed(activeCoinOption.decimals));
    setTransferAmount(rounded > 0 ? rounded.toString() : '');
    setErrorMessage('');
  };

  // Submit transfer
  const handleExecuteTransfer = () => {
    if (!activeCoinOption) {
      setErrorMessage('Please select a valid sovereign currency.');
      return;
    }
    if (parsedAmount <= 0) {
      setErrorMessage('Please enter an amount greater than 0.');
      return;
    }
    if (isInsufficient) {
      setErrorMessage(`Insufficient balance. You have ${availableBalance.toLocaleString()} ${activeCoinOption.symbol} available.`);
      return;
    }

    setShowConfirm(true);
  };

  const processTransfer = () => {
    setIsSubmitting(true);
    setErrorMessage('');

    // Simulate micro-clearing delay for atomic animation
    setTimeout(() => {
      const result = executePeerTransfer({
        senderId: currentUserId,
        senderName: currentUserName,
        senderHandle: currentUserHandle,
        recipientId: recipient.uid || recipient.userId,
        recipientName: recipient.name,
        recipientHandle: recipient.userId,
        coinId: activeCoinOption!.id,
        coinSymbol: activeCoinOption!.symbol,
        coinName: activeCoinOption!.name,
        mode: 'final_coin',
        amount: parsedAmount,
        amountUSD: 0, // Zero fiat equivalent for sovereign assets
        memo: memo.trim() || undefined
      });

      setIsSubmitting(false);

      if (result.success && result.receipt) {
        setCompletedReceipt(result.receipt);
        if (onTransferSuccess) {
          onTransferSuccess(result.receipt);
        }
      } else {
        setErrorMessage(result.error || 'Transfer failed. Please check your balance and try again.');
      }
    }, 500);
  };

  const handleCopyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        transition={{ duration: 0.2 }}
        className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-lg w-full overflow-hidden my-auto text-left"
      >
        {/* Header Bar */}
        <div className="bg-neutral-950 text-white px-5 sm:px-6 py-4 flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Send className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold tracking-tight text-white flex items-center gap-2">
                <span>Transfer Funds</span>
                <span className="text-[10px] uppercase font-mono font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
                  Universal Ledger
                </span>
              </h2>
              <p className="text-[11px] text-neutral-400">
                Direct zero-fee peer-to-peer sovereign settlement
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            aria-label="Close transfer modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* ================= COMPLETED RECEIPT SCREEN ================= */}
        {completedReceipt ? (
          <div className="p-5 sm:p-6 space-y-5">
            <div className="text-center space-y-2 py-2">
              <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-neutral-900">
                Transfer Settled &amp; Audited
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Transferred <strong className="text-neutral-900 font-mono">{parsedAmount.toLocaleString()} {activeCoinOption?.symbol}</strong> to <strong>@{recipient.userId}</strong>.
              </p>
            </div>

            {/* Receipt Details Card */}
            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2.5 text-xs font-mono">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-200/70 text-[11px]">
                <span className="text-neutral-500 font-sans">Receipt Number</span>
                <span className="font-bold text-neutral-900">{completedReceipt.receiptNumber}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-neutral-500 font-sans">Recipient Node</span>
                <span className="font-semibold text-neutral-800">@{recipient.userId} ({recipient.name})</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-neutral-500 font-sans">Gross / Net Sent</span>
                <span className="font-bold text-emerald-700">
                  {parsedAmount.toLocaleString()} {activeCoinOption?.symbol} ($0.00 Fee)
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-neutral-500 font-sans">Tax Classification</span>
                <span className="text-neutral-700">{completedReceipt.taxClassification.formMapping}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-neutral-500 font-sans">Ledger Status</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  {completedReceipt.status}
                </span>
              </div>

              {/* Cryptographic Hash */}
              <div className="pt-2 border-t border-neutral-200/70">
                <span className="text-[10px] text-neutral-400 font-sans block mb-1">
                  SHA-256 Ledger Hash
                </span>
                <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-xl border border-neutral-200 text-[10px] text-neutral-600">
                  <span className="truncate max-w-[280px]">{completedReceipt.cryptographicHash}</span>
                  <button
                    type="button"
                    onClick={() => handleCopyHash(completedReceipt.cryptographicHash)}
                    className="text-neutral-500 hover:text-black flex items-center gap-1 cursor-pointer pl-2"
                  >
                    {copiedHash ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span className="font-sans text-[10px]">{copiedHash ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setCompletedReceipt(null);
                  setTransferAmount('');
                  setMemo('');
                }}
                className="flex-1 py-2.5 px-4 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
              >
                Transfer Again
              </button>

              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 px-4 rounded-xl bg-neutral-950 hover:bg-black text-white text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* ================= TRANSFER INPUT FORM ================= */
          <div className="p-5 sm:p-6 space-y-5">
            {/* Recipient Header Card */}
            <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-neutral-900 text-white font-bold text-sm flex items-center justify-center overflow-hidden border border-neutral-200 shrink-0">
                  {recipient.avatarUrl ? (
                    <img src={recipient.avatarUrl} alt={recipient.name} className="w-full h-full object-cover" />
                  ) : (
                    recipient.name.charAt(0).toUpperCase()
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs sm:text-sm text-neutral-900">{recipient.name}</span>
                    {recipient.isVerified && (
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    )}
                  </div>
                  <span className="text-[11px] text-neutral-500 font-mono">
                    @{recipient.userId}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-neutral-400 block font-sans">Destination Node</span>
                <span className="text-[11px] font-mono font-semibold text-neutral-700">Verified Peer</span>
              </div>
            </div>

            {/* Select Final Coin Grid */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block">
                1. Select Final Coin
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {walletCurrencies.finalCoins.map((coin) => {
                  const isSelected = coin.symbol === selectedCoinSymbol;
                  return (
                    <button
                      key={coin.id}
                      type="button"
                      onClick={() => {
                        setSelectedCoinSymbol(coin.symbol);
                        setErrorMessage('');
                      }}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'border-neutral-900 bg-neutral-900 text-white shadow-md ring-2 ring-neutral-900/10'
                          : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-900'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-bold font-mono px-1.5 py-0.5 rounded ${
                          isSelected ? 'bg-white/20 text-white' : 'bg-neutral-100 text-neutral-800'
                        }`}>
                          {coin.symbol}
                        </span>
                      </div>

                      <div className="mt-2">
                        <span className={`text-[11px] font-mono font-semibold block ${isSelected ? 'text-white' : 'text-neutral-800'}`}>
                          {coin.balance.toLocaleString()} {coin.symbol}
                        </span>
                        <span className={`text-[10px] block truncate ${isSelected ? 'text-neutral-400' : 'text-neutral-500'}`}>
                          {coin.name}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Amount Input */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-500">
                  2. Enter Amount
                </label>
                <div className="text-[11px] text-neutral-500 flex items-center gap-1 font-mono">
                  <span>Available:</span>
                  <strong className="text-neutral-900">{availableBalance.toLocaleString()} {activeCoinOption?.symbol}</strong>
                </div>
              </div>

              <div className="relative">
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={transferAmount}
                  onChange={(e) => {
                    setTransferAmount(e.target.value);
                    setErrorMessage('');
                  }}
                  placeholder="0.00"
                  className={`w-full h-12 pl-4 pr-24 rounded-2xl bg-neutral-50 border text-sm font-mono font-bold text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:bg-white transition-all ${
                    isInsufficient
                      ? 'border-red-400 focus:border-red-500 focus:ring-1 focus:ring-red-400'
                      : 'border-neutral-300 focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900'
                  }`}
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
                  <span className="text-xs font-bold font-mono text-neutral-500">
                    {activeCoinOption?.symbol}
                  </span>
                </div>
              </div>

              {/* Percentage Shortcuts */}
              <div className="flex flex-wrap items-center justify-end gap-2 pt-0.5">
                <div className="flex items-center gap-1">
                  {[25, 50, 75, 100].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => handleSetPercentage(pct)}
                      className="px-2 py-1 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-[10px] font-bold font-mono transition-colors cursor-pointer"
                    >
                      {pct === 100 ? 'MAX' : `${pct}%`}
                    </button>
                  ))}
                </div>
              </div>

              {isInsufficient && (
                <div className="flex items-center gap-1.5 text-xs text-red-600 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>Amount exceeds your available {activeCoinOption?.symbol} balance.</span>
                </div>
              )}
            </div>

            {/* Memo Input */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 block">
                3. Transfer Memo / Note (Optional)
              </label>
              <input
                type="text"
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                placeholder="e.g. Escrow settlement, barter fee, gift..."
                className="w-full h-10 px-3.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:bg-white focus:border-neutral-900 transition-all"
              />
            </div>

            {/* Protocol Security Notice */}
            <div className="p-3 rounded-2xl bg-amber-50/60 border border-amber-200/70 text-amber-900 flex items-start gap-2.5 text-[11px]">
              <Shield className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div className="space-y-0.5 leading-relaxed">
                <span className="font-bold block">Zero-Fee Protocol Clearing &amp; Universal Ledger Bridge</span>
                <p className="text-amber-800/90 text-[10px]">
                  This transfer executes instantaneously with <strong>0% platform fees</strong>. An immutable cryptographic transaction receipt will be recorded to your Universal Ledger under non-taxable transfer classifications.
                </p>
              </div>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="button"
              onClick={handleExecuteTransfer}
              disabled={isSubmitting || parsedAmount <= 0 || isInsufficient}
              className={`w-full py-3.5 px-5 rounded-2xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                isSubmitting || parsedAmount <= 0 || isInsufficient
                  ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed border border-neutral-200'
                  : 'bg-neutral-950 hover:bg-black text-white cursor-pointer shadow-lg active:scale-[0.99]'
              }`}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Settling on Sovereign Node...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 text-amber-400" />
                  <span>
                    Send {parsedAmount > 0 ? `${parsedAmount.toLocaleString()} ${activeCoinOption?.symbol}` : 'Funds'} to @{recipient.userId}
                  </span>
                </>
              )}
            </button>
          </div>
        )}
      </motion.div>
      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processTransfer}
        title="Confirm Transfer"
        message={`Are you sure you want to transfer ${parsedAmount.toLocaleString()} ${activeCoinOption?.symbol} to @${recipient.userId}?`}
        confirmText="Confirm Transfer"
        type="info"
      />
    </div>
  );
};
