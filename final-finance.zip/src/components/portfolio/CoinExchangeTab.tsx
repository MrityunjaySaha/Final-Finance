import React, { useState, useEffect } from 'react';
import { RefreshCw, Coins, ArrowRight, CheckCircle2, AlertCircle, Sparkles, ShieldCheck, ArrowLeftRight, TrendingUp, DollarSign, Lock, Activity, ShieldAlert } from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../../data/defaultWallets';
import { getStoredCustomCoins, saveCustomCoins } from '../../data/customCoinsData';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';

interface CoinExchangeTabProps {
  currentUser: AuthSession | null;
  sovereignOnly?: boolean;
}

type ExchangeMode = 'final' | 'stable' | 'crypto';

export const CoinExchangeTab: React.FC<CoinExchangeTabProps> = ({ currentUser, sovereignOnly }) => {
  const userId = currentUser?.id || 'user_demo';
  const [walletData, setWalletData] = useState(() => getStoredUserWallets(userId));
  const [customCoins, setCustomCoins] = useState(() => getStoredCustomCoins());

  const [activeExchangeMode, setActiveExchangeMode] = useState<ExchangeMode>(() => {
    return 'final';
  });

  useEffect(() => {
    if (sovereignOnly && activeExchangeMode !== 'final') {
      setActiveExchangeMode('final');
    }
  }, [sovereignOnly]);

  // --- 1. Final Coins state ---
  // Section A: Final Admin Coin Exchange (AFNL -> Target Final Coin)
  const [adminTargetSymbol, setAdminTargetSymbol] = useState<string>('USDCF');
  const [adminAmount, setAdminAmount] = useState<string>('1000');

  // Section B: Peer Final Coin Exchange (Any Final Coin -> Another Final Coin)
  const [peerSourceSymbol, setPeerSourceSymbol] = useState<string>('USDCF');
  const [peerTargetSymbol, setPeerTargetSymbol] = useState<string>('');
  const [peerAmount, setPeerAmount] = useState<string>('1000');
  const [peerSearchQuery, setPeerSearchQuery] = useState('');
  const [showPeerSearch, setShowPeerSearch] = useState(false);

  // --- 2. Stablecoins state (Direct Multi-Currency Digital Asset Swaps) ---
  const [stableSourceId, setStableSourceId] = useState<string>('USDC');
  const [stableTargetId, setStableTargetId] = useState<string>('INR_STABLE');
  const [stableAmount, setStableAmount] = useState<string>('5000');
  
  // USD/INR valuation ratio baseline
  const [liveUsdInrRate] = useState<number>(86.20);

  // --- 3. Crypto state ---
  const [cryptoSourceSymbol, setCryptoSourceSymbol] = useState<string>('ETH');
  const [cryptoTargetSymbol, setCryptoTargetSymbol] = useState<string>('BTC');
  const [cryptoAmount, setCryptoAmount] = useState<string>('1.5');

  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // --- ALL AVAILABLE FINAL COINS ---
  const defaultFinalCoins = [
    { symbol: 'AFNL', name: 'Final Admin Coin', balance: walletData.finalCoins?.find((fc: any) => fc.symbol.toUpperCase() === 'AFNL')?.balance || 100000 },
    { symbol: 'USDCF', name: 'USD Final Coin', balance: walletData.finalCoins?.find((fc: any) => fc.symbol.toUpperCase() === 'USDCF')?.balance || 25000 },
    { symbol: 'GOLDF', name: 'Gold Final Coin', balance: walletData.finalCoins?.find((fc: any) => fc.symbol.toUpperCase() === 'GOLDF')?.balance || 5000 },
    { symbol: 'EUROF', name: 'Euro Final Coin', balance: walletData.finalCoins?.find((fc: any) => fc.symbol.toUpperCase() === 'EUROF')?.balance || 10000 },
    ...(walletData.finalCoins?.filter((fc: any) => !['AFNL', 'USDCF', 'GOLDF', 'EUROF'].includes(fc.symbol.toUpperCase())).map((fc: any) => ({ symbol: fc.symbol, name: fc.name || `${fc.symbol} Final Coin`, balance: fc.balance })) || []),
    ...(customCoins.filter(c => c.coinType === 'final_coin').map(c => ({ symbol: c.symbol, name: c.name, balance: c.totalSupply || 10000 })))
  ];
  const uniqueFinalCoins = Array.from(new Map(defaultFinalCoins.map(item => [item.symbol.toUpperCase(), item])).values());
  
  const otherFinalCoins = customCoins.filter(c => c.coinType === 'final_coin' && c.creatorId !== userId && c.creatorId !== 'you');
  const filteredOtherCoins = otherFinalCoins.filter(c => 
    c.name.toLowerCase().includes(peerSearchQuery.toLowerCase()) || 
    c.symbol.toLowerCase().includes(peerSearchQuery.toLowerCase())
  );

  
  // Update adminTargetSymbol if it's not in the allowed list
  useEffect(() => {
    const userCoins = customCoins.filter(c => c.coinType === 'final_coin' && (c.creatorId === userId || c.creatorId === 'you'));
    if (userCoins.length > 0 && !userCoins.find(c => c.symbol === adminTargetSymbol)) {
      setAdminTargetSymbol(userCoins[0].symbol);
    } else if (userCoins.length === 0) {
      setAdminTargetSymbol('');
    }
  }, [customCoins, userId]);

  
  // Update peerTargetSymbol and peerSourceSymbol if they're not in the allowed list
  useEffect(() => {
    const myCoins = customCoins.filter(c => c.coinType === 'final_coin' && (c.creatorId === userId || c.creatorId === 'you'));
    const otherCoins = customCoins.filter(c => c.coinType === 'final_coin' && c.creatorId !== userId && c.creatorId !== 'you');
    
    if (myCoins.length > 0 && !myCoins.find(c => c.symbol === peerSourceSymbol)) {
      setPeerSourceSymbol(myCoins[0].symbol);
    } else if (myCoins.length === 0) {
      setPeerSourceSymbol('');
    }
    
    if (otherCoins.length > 0 && !otherCoins.find(c => c.symbol === peerTargetSymbol)) {
      setPeerTargetSymbol(otherCoins[0].symbol);
    }
  }, [customCoins, uniqueFinalCoins, userId]);

  const getSourceFinalBalance = (symbol: string) => {
    const found = walletData.finalCoins?.find((fc: any) => fc.symbol.toUpperCase() === symbol.toUpperCase());
    if (found) return found.balance;
    const def = uniqueFinalCoins.find(c => c.symbol.toUpperCase() === symbol.toUpperCase());
    return def ? def.balance : 0;
  };

  // --- EXECUTE FINAL ADMIN COIN EXCHANGE (AFNL -> User Coin) ---
  const handleExecuteAdminFinalExchange = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    
    if (!adminTargetSymbol) {
      setErrorMsg('You must create a Final Coin first before you can exchange AFNL.');
      return;
    }
    
    const amount = parseFloat(adminAmount);

    if (isNaN(amount) || amount <= 0) {
      setErrorMsg('Please enter a valid positive exchange amount for Final Admin Coin.');
      return;
    }
    if (adminTargetSymbol.toUpperCase() === 'AFNL') {
      setErrorMsg('Target cannot be AFNL when converting from Admin AFNL balance.');
      return;
    }

    const afnlBalance = getSourceFinalBalance('AFNL');
    if (amount > afnlBalance) {
      setErrorMsg(`Insufficient AFNL balance. You have ${afnlBalance.toLocaleString()} AFNL available.`);
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const updatedWallet = getStoredUserWallets(userId);
        const receivedAmount = amount; // 1:1 parity
        
        let afnlIdx = updatedWallet.finalCoins.findIndex((fc: any) => fc.symbol.toUpperCase() === 'AFNL');
        if (afnlIdx === -1) {
          updatedWallet.finalCoins.push({
            id: `fc-afnl-${Date.now()}`,
            name: 'Final Admin Coin',
            symbol: 'AFNL',
            balance: 0,
            unitPriceUSD: 0,
            change24h: 0.0,
            utility: 'Sovereign Final Currency'
          });
          afnlIdx = updatedWallet.finalCoins.length - 1;
        }

        let tgtIdx = updatedWallet.finalCoins.findIndex((fc: any) => fc.symbol.toUpperCase() === adminTargetSymbol.toUpperCase());
        if (tgtIdx === -1) {
          updatedWallet.finalCoins.push({
            id: `fc-tgt-${Date.now()}`,
            name: `${adminTargetSymbol} Final Coin`,
            symbol: adminTargetSymbol,
            balance: 0,
            unitPriceUSD: 0,
            change24h: 0.0,
            utility: 'Sovereign Final Currency'
          });
          tgtIdx = updatedWallet.finalCoins.length - 1;
        }

        updatedWallet.finalCoins[afnlIdx].balance -= amount;
        updatedWallet.finalCoins[tgtIdx].balance += receivedAmount;

        saveStoredUserWallets(userId, updatedWallet);
        setWalletData(updatedWallet);

        recordLedgerTransaction(userId, {
          id: `ledger-adm-${Date.now()}`,
          receiptNumber: `REC-ADM-${Date.now()}`,
          taxYear: 2026,
          timestamp: new Date().toISOString(),
          dateIso: new Date().toISOString(),
          type: 'vault_swap',
          category: 'transfer',
          mode: 'final_coin',
          title: `Final Admin Coin Exchange: -${amount.toLocaleString()} AFNL → +${receivedAmount.toLocaleString()} ${adminTargetSymbol}`,
          description: `Exchanged Final Admin Coin (AFNL) for ${adminTargetSymbol} at 1:1 sovereign parity.`,
          amountUSD: 0,
          feeUSD: 0,
          netAmountUSD: 0,
          sourceOrDestination: `Admin Exchange Desk (AFNL to ${adminTargetSymbol})`,
          counterpartyOrIssuer: 'Final Finance Protocol',
          paymentCoinSymbol: adminTargetSymbol,
          paymentCoinAmount: receivedAmount,
          status: 'Settled',
          clearingNode: 'Final Ledger Subnet',
          cryptographicHash: `0xHASH${Date.now()}`,
          signature: `SIG-ADM-${Date.now()}`,
          taxClassification: { formMapping: 'Non-Taxable Transfer', taxableEvent: false, taxableAmountUSD: 0, irsCategoryNote: 'Final admin coin exchange' }
        });

        setSuccessMsg(`Successfully exchanged ${amount.toLocaleString()} AFNL for ${receivedAmount.toLocaleString()} ${adminTargetSymbol} at 1:1 parity!`);
      } catch (err: any) {
        setErrorMsg(err.message || 'Admin exchange failed.');
      } finally {
        setIsSubmitting(false);
      }
    }, 500);
  };

  // --- EXECUTE PEER FINAL COIN EXCHANGE (Any Final Coin -> Another Final Coin) ---
  const handleExecutePeerFinalExchange = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    
    if (!peerSourceSymbol) {
      setErrorMsg('You must create a Final Coin first before you can cross-exchange.');
      return;
    }
    
    const amount = parseFloat(peerAmount);

    if (isNaN(amount) || amount <= 0) {
      setErrorMsg('Please enter a valid positive exchange amount.');
      return;
    }
    if (peerSourceSymbol.toUpperCase() === peerTargetSymbol.toUpperCase()) {
      setErrorMsg('Source and target final currencies must be different.');
      return;
    }

    const sourceBalance = getSourceFinalBalance(peerSourceSymbol);
    if (amount > sourceBalance) {
      setErrorMsg(`Insufficient ${peerSourceSymbol} balance. You have ${sourceBalance.toLocaleString()} available.`);
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const updatedWallet = getStoredUserWallets(userId);
        
        // Deduct from source final coin
        let srcIdx = updatedWallet.finalCoins.findIndex((fc: any) => fc.symbol.toUpperCase() === peerSourceSymbol.toUpperCase());
        if (srcIdx !== -1) {
          updatedWallet.finalCoins[srcIdx].balance -= amount;
        } else {
          updatedWallet.finalCoins.push({
            id: `fc-src-${Date.now()}`,
            name: `${peerSourceSymbol} Final Coin`,
            symbol: peerSourceSymbol,
            balance: Math.max(0, sourceBalance - amount),
            unitPriceUSD: 0,
            change24h: 0.0,
            utility: 'Sovereign Final Currency'
          });
        }

        const receivedAmount = amount; // 1:1 parity ratio

        // Add to target final coin
        let tgtIdx = updatedWallet.finalCoins.findIndex((fc: any) => fc.symbol.toUpperCase() === peerTargetSymbol.toUpperCase());
        if (tgtIdx !== -1) {
          updatedWallet.finalCoins[tgtIdx].balance += receivedAmount;
        } else {
          updatedWallet.finalCoins.push({
            id: `fc-tgt-${Date.now()}`,
            name: `${peerTargetSymbol} Final Coin`,
            symbol: peerTargetSymbol,
            balance: receivedAmount,
            unitPriceUSD: 0,
            change24h: 0.0,
            utility: 'Sovereign Final Currency'
          });
        }

        saveStoredUserWallets(userId, updatedWallet);
        setWalletData(updatedWallet);

        recordLedgerTransaction(userId, {
          id: `ledger-fx-${Date.now()}`,
          receiptNumber: `REC-FX-${Date.now()}`,
          taxYear: 2026,
          timestamp: new Date().toISOString(),
          dateIso: new Date().toISOString(),
          type: 'vault_swap',
          category: 'transfer',
          mode: 'final_coin',
          title: `Final Currency Cross-Exchange: -${amount.toLocaleString()} ${peerSourceSymbol} → +${receivedAmount.toLocaleString()} ${peerTargetSymbol}`,
          description: `Exchanged ${amount.toLocaleString()} ${peerSourceSymbol} for ${receivedAmount.toLocaleString()} ${peerTargetSymbol} at sovereign 1:1 parity.`,
          amountUSD: 0,
          feeUSD: 0,
          netAmountUSD: 0,
          sourceOrDestination: `Final Exchange Desk (${peerSourceSymbol} to ${peerTargetSymbol})`,
          counterpartyOrIssuer: 'Final Finance Protocol',
          paymentCoinSymbol: peerTargetSymbol,
          paymentCoinAmount: receivedAmount,
          status: 'Settled',
          clearingNode: 'Final Ledger Subnet',
          cryptographicHash: `0xHASH${Date.now()}`,
          signature: `SIG-FX-${Date.now()}`,
          taxClassification: { formMapping: 'Non-Taxable Transfer', taxableEvent: false, taxableAmountUSD: 0, irsCategoryNote: 'Final coin 1:1 cross-exchange' }
        });

        setSuccessMsg(`Successfully exchanged ${amount.toLocaleString()} ${peerSourceSymbol} for ${receivedAmount.toLocaleString()} ${peerTargetSymbol} at 1:1 parity!`);
      } catch (err: any) {
        setErrorMsg(err.message || 'Exchange failed.');
      } finally {
        setIsSubmitting(false);
      }
    }, 500);
  };

  // --- 2. STABLECOINS EXCHANGE LOGIC ---
  const defaultStablecoins = [
    { id: 'USDC', symbol: 'USDC', name: 'USD Coin', peg: 'USD', rateUSD: 1.00 },
    { id: 'INR_STABLE', symbol: 'INR-S', name: 'Indian Rupee Sovereign Stable', peg: 'INR', rateUSD: 1 / liveUsdInrRate },
    { id: 'EURC', symbol: 'EURC', name: 'Euro Coin', peg: 'EUR', rateUSD: 1.09 },
    { id: 'PAXG', symbol: 'PAXG', name: 'PAX Gold Stable', peg: 'Gold', rateUSD: 2880.00 },
    ...(walletData.stableCoins?.map((sc: any) => ({ id: sc.symbol, symbol: sc.symbol, name: sc.name, peg: sc.peggedCurrency || sc.pegCurrency || 'USD', rateUSD: sc.unitPriceUSD || 1.0 })) || []),
    ...(customCoins.filter(c => c.coinType === 'stable_coin').map(c => ({ id: c.symbol, symbol: c.symbol, name: c.name, peg: c.pegCurrency || 'USD', rateUSD: c.pegCurrency === 'INR' ? 1 / liveUsdInrRate : 1.00 })))
  ];
  const uniqueStablecoins = Array.from(new Map(defaultStablecoins.map(item => [item.symbol, item])).values());

  const getTokenUsdValue = (coin: any) => {
    if (!coin) return 1.0;
    const peg = (coin.peg || coin.pegCurrency || coin.peggedCurrency || '').toUpperCase();
    if (peg === 'INR') return 1 / liveUsdInrRate;
    if (peg === 'EUR') return 1.09;
    if (peg === 'GOLD') return 2880.00;
    return coin.rateUSD || coin.unitPriceUSD || 1.00;
  };

  const getSourceStableBalance = (symbol: string) => {
    const found = walletData.stableCoins?.find((sc: any) => sc.symbol.toUpperCase() === symbol.toUpperCase());
    if (found) return found.balance;
    return 50000;
  };

  const handleExecuteStableExchange = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    const amount = parseFloat(stableAmount);

    if (isNaN(amount) || amount <= 0) {
      setErrorMsg('Please enter a valid positive stablecoin amount.');
      return;
    }
    if (stableSourceId === stableTargetId) {
      setErrorMsg('Source and target stable currencies must be different.');
      return;
    }

    const srcObj = uniqueStablecoins.find(s => s.symbol === stableSourceId);
    const tgtObj = uniqueStablecoins.find(s => s.symbol === stableTargetId);
    if (!srcObj || !tgtObj) {
      setErrorMsg('Invalid stablecoin selection.');
      return;
    }

    const sourceBalance = getSourceStableBalance(stableSourceId);
    if (amount > sourceBalance) {
      setErrorMsg(`Insufficient ${stableSourceId} balance (${sourceBalance.toLocaleString()} available).`);
      return;
    }

    const srcUsdVal = getTokenUsdValue(srcObj);
    const tgtUsdVal = getTokenUsdValue(tgtObj);
    const calculatedReceived = tgtUsdVal > 0 ? (amount * srcUsdVal) / tgtUsdVal : 0;
    const exchangeRateUsed = tgtUsdVal > 0 ? srcUsdVal / tgtUsdVal : 1;
    const ratioDescription = `Direct Oracle Valuation Ratio (1 ${stableSourceId} = ${exchangeRateUsed.toFixed(4)} ${stableTargetId})`;

    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const updatedWallet = getStoredUserWallets(userId);
        
        let srcFound = updatedWallet.stableCoins?.find((sc: any) => sc.symbol.toUpperCase() === stableSourceId.toUpperCase());
        if (srcFound) {
          srcFound.balance -= amount;
        }

        let tgtFound = updatedWallet.stableCoins?.find((sc: any) => sc.symbol.toUpperCase() === stableTargetId.toUpperCase());
        if (tgtFound) {
          tgtFound.balance += calculatedReceived;
        } else {
          updatedWallet.stableCoins.push({
            id: `sc-ex-${Date.now()}`,
            name: tgtObj.name,
            symbol: tgtObj.symbol,
            balance: calculatedReceived,
            unitPriceUSD: tgtUsdVal,
            peggedCurrency: tgtObj.peg,
            yieldAPY: 4.5,
            network: 'Final Protocol Subnet'
          });
        }

        saveStoredUserWallets(userId, updatedWallet);
        setWalletData(updatedWallet);

        recordLedgerTransaction(userId, {
          id: `ledger-stb-${Date.now()}`,
          receiptNumber: `REC-STB-${Date.now()}`,
          taxYear: 2026,
          timestamp: new Date().toISOString(),
          dateIso: new Date().toISOString(),
          type: 'vault_swap',
          category: 'transfer',
          mode: 'stable_coin',
          title: `Direct Stablecoin Swap: ${amount.toLocaleString()} ${stableSourceId} → ${calculatedReceived.toFixed(2)} ${stableTargetId}`,
          description: `You Swap: ${amount.toLocaleString()} ${stableSourceId}. You Receive: ${calculatedReceived.toFixed(2)} ${stableTargetId}. Valuation Ratio: 1 ${stableSourceId} = ${exchangeRateUsed.toFixed(4)} ${stableTargetId}. Zero fiat cashout enforced.`,
          amountUSD: amount * srcUsdVal,
          feeUSD: 0,
          netAmountUSD: amount * srcUsdVal,
          sourceOrDestination: `Stablecoin Swap Desk (${stableSourceId} to ${stableTargetId})`,
          counterpartyOrIssuer: 'Final Finance Protocol',
          paymentCoinSymbol: stableTargetId,
          paymentCoinAmount: calculatedReceived,
          status: 'Settled',
          clearingNode: 'Final Ledger Subnet',
          cryptographicHash: `0xHASH${Date.now()}`,
          signature: `SIG-STB-${Date.now()}`,
          taxClassification: { formMapping: 'Non-Taxable Transfer', taxableEvent: false, taxableAmountUSD: 0, irsCategoryNote: 'Multi-currency stablecoin swap' }
        });

        setSuccessMsg(`Successfully executed direct on-chain swap of ${amount.toLocaleString()} ${stableSourceId} for ${calculatedReceived.toFixed(2)} ${stableTargetId} (Valuation Ratio: 1 ${stableSourceId} = ${exchangeRateUsed.toFixed(4)} ${stableTargetId}). Zero fiat involvement.`);
      } catch (err: any) {
        setErrorMsg(err.message || 'Stablecoin exchange failed.');
      } finally {
        setIsSubmitting(false);
      }
    }, 500);
  };

  // --- 3. CRYPTOCURRENCY EXCHANGE LOGIC ---
  const defaultCryptos = [
    { symbol: 'BTC', name: 'Bitcoin', priceUSD: 94800.00 },
    { symbol: 'ETH', name: 'Ethereum', priceUSD: 2820.00 },
    { symbol: 'SOL', name: 'Solana', priceUSD: 195.00 },
    ...(walletData.cryptoCurrencies?.map((cc: any) => ({ symbol: cc.symbol, name: cc.name, priceUSD: cc.unitPriceUSD || 100 })) || []),
    ...(customCoins.filter(c => c.coinType === 'crypto').map(c => ({ symbol: c.symbol, name: c.name, priceUSD: c.priceUSD || 10.00 })))
  ];
  const uniqueCryptos = Array.from(new Map(defaultCryptos.map(item => [item.symbol, item])).values());

  const handleExecuteCryptoExchange = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    const amount = parseFloat(cryptoAmount);
    if (isNaN(amount) || amount <= 0) {
      setErrorMsg('Please enter a valid positive cryptocurrency amount.');
      return;
    }
    if (cryptoSourceSymbol === cryptoTargetSymbol) {
      setErrorMsg('Source and target cryptocurrencies must be different.');
      return;
    }

    const srcCrypto = uniqueCryptos.find(c => c.symbol === cryptoSourceSymbol);
    const tgtCrypto = uniqueCryptos.find(c => c.symbol === cryptoTargetSymbol);
    if (!srcCrypto || !tgtCrypto) {
      setErrorMsg('Invalid cryptocurrency selection.');
      return;
    }

    const totalUSDValue = amount * srcCrypto.priceUSD;
    const receivedCryptoAmount = totalUSDValue / tgtCrypto.priceUSD;
    const cryptoExchangeRate = srcCrypto.priceUSD / tgtCrypto.priceUSD;

    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const updatedWallet = getStoredUserWallets(userId);
        
        let srcFound = updatedWallet.cryptoCurrencies?.find((cc: any) => cc.symbol.toUpperCase() === cryptoSourceSymbol.toUpperCase());
        if (srcFound) {
          if (srcFound.balance < amount) {
            setErrorMsg(`Insufficient ${cryptoSourceSymbol} balance (${srcFound.balance.toLocaleString()} available).`);
            setIsSubmitting(false);
            return;
          }
          srcFound.balance -= amount;
        }

        let tgtFound = updatedWallet.cryptoCurrencies?.find((cc: any) => cc.symbol.toUpperCase() === cryptoTargetSymbol.toUpperCase());
        if (tgtFound) {
          tgtFound.balance += receivedCryptoAmount;
        } else {
          updatedWallet.cryptoCurrencies.push({
            id: `cr-ex-${Date.now()}`,
            name: tgtCrypto.name,
            symbol: tgtCrypto.symbol,
            balance: receivedCryptoAmount,
            unitPriceUSD: tgtCrypto.priceUSD,
            change24h: 2.5,
            network: 'Multi-Chain Protocol'
          });
        }

        saveStoredUserWallets(userId, updatedWallet);
        setWalletData(updatedWallet);

        recordLedgerTransaction(userId, {
          id: `ledger-crp-${Date.now()}`,
          receiptNumber: `REC-CRP-${Date.now()}`,
          taxYear: 2026,
          timestamp: new Date().toISOString(),
          dateIso: new Date().toISOString(),
          type: 'vault_swap',
          category: 'transfer',
          mode: 'crypto',
          title: `Crypto Swap: ${amount.toLocaleString()} ${cryptoSourceSymbol} → ${receivedCryptoAmount.toFixed(4)} ${cryptoTargetSymbol}`,
          description: `Exchanged digital assets using USD market valuation ratio. Zero fiat cashout enforced.`,
          amountUSD: totalUSDValue,
          feeUSD: 0,
          netAmountUSD: totalUSDValue,
          sourceOrDestination: `Crypto Swap Desk (${cryptoSourceSymbol} to ${cryptoTargetSymbol})`,
          counterpartyOrIssuer: 'Final Finance Protocol',
          paymentCoinSymbol: cryptoTargetSymbol,
          paymentCoinAmount: receivedCryptoAmount,
          status: 'Settled',
          clearingNode: 'Final Ledger Subnet',
          cryptographicHash: `0xHASH${Date.now()}`,
          signature: `SIG-CRP-${Date.now()}`,
          taxClassification: { formMapping: 'Non-Taxable Transfer', taxableEvent: true, taxableAmountUSD: totalUSDValue, irsCategoryNote: 'Crypto asset swap' }
        });

        setSuccessMsg(`Successfully swapped ${amount.toLocaleString()} ${cryptoSourceSymbol} for ${receivedCryptoAmount.toFixed(4)} ${cryptoTargetSymbol} at live valuation ratio (1 ${cryptoSourceSymbol} = ${cryptoExchangeRate.toFixed(4)} ${cryptoTargetSymbol}). No fiat currency involved.`);
      } catch (err: any) {
        setErrorMsg(err.message || 'Crypto exchange failed.');
      } finally {
        setIsSubmitting(false);
      }
    }, 500);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto text-left">
      {/* Exchange Mode Tabs */}
      <div className={`grid ${sovereignOnly ? 'grid-cols-1' : 'grid-cols-3'} gap-2 bg-slate-200/70 p-1.5 rounded-2xl`}>
        <button
          type="button"
          onClick={() => { setActiveExchangeMode('final'); setErrorMsg(null); setSuccessMsg(null); }}
          className={`py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeExchangeMode === 'final'
              ? 'bg-white text-slate-900 shadow-md'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Coins className="w-4 h-4 text-emerald-600" />
          <span>1. Final Coin Swap</span>
        </button>

        {!sovereignOnly && (
          <button
            type="button"
            onClick={() => { setActiveExchangeMode('stable'); setErrorMsg(null); setSuccessMsg(null); }}
            className={`py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeExchangeMode === 'stable'
                ? 'bg-white text-slate-900 shadow-md'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span>2. Stablecoin Swap</span>
          </button>
        )}

        {!sovereignOnly && (
          <button
            type="button"
            onClick={() => { setActiveExchangeMode('crypto'); setErrorMsg(null); setSuccessMsg(null); }}
            className={`py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeExchangeMode === 'crypto'
                ? 'bg-white text-slate-900 shadow-md'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-purple-600" />
            <span>3. Crypto Swap</span>
          </button>
        )}
      </div>

      {/* --- TAB 1: FINAL COINS EXCHANGE (Admin AFNL Exchange + Peer Final Coin Cross-Exchange) --- */}
      {activeExchangeMode === 'final' && (
        <div className="space-y-6">
          {/* SECTION A: FINAL ADMIN COIN EXCHANGE */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xl space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Final Coin Swap (Sovereign Unit Parity)</h3>
                <p className="text-[11px] text-slate-500">Atomic swap between sovereign protocol units.</p>
              </div>
              <div className="px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-mono font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                AFNL Balance: {getSourceFinalBalance('AFNL').toLocaleString()}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              {/* AFNL Fixed Source */}
              <div className="space-y-3 p-5 rounded-2xl bg-amber-50/70 border border-amber-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-amber-900 uppercase">Source Admin Coin</span>
                  <span className="text-[11px] font-mono text-amber-700 font-bold">
                    Available: {getSourceFinalBalance('AFNL').toLocaleString()} AFNL
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                    AFNL
                  </div>
                  <div className="flex-1">
                    <div className="w-full px-3 py-2.5 rounded-xl bg-white border border-amber-300 font-mono font-bold text-xs text-slate-900 flex items-center justify-between">
                      <span>AFNL (Final Admin Coin)</span>
                      <span className="text-[10px] bg-amber-100 px-2 py-0.5 rounded text-amber-900 font-bold">Fixed Source</span>
                    </div>
                  </div>
                </div>
                <div>
                  <input
                    type="number"
                    min="1"
                    value={adminAmount}
                    onChange={(e) => setAdminAmount(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-white border border-amber-300 font-mono font-bold text-base text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    placeholder="Enter AFNL amount..."
                  />
                </div>
              </div>

              {/* Target Final Coin (User's created coins) */}
              <div className="space-y-3 p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-emerald-900 uppercase">Target Final Currency</span>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold">
                    1:1 Parity Ratio
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                    {adminTargetSymbol || '-'}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <select
                      value={adminTargetSymbol}
                      onChange={(e) => setAdminTargetSymbol(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white border border-emerald-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    >
                      {customCoins.filter(c => c.coinType === 'final_coin' && (c.creatorId === userId || c.creatorId === 'you')).map((c) => (
                        <option key={c.symbol} value={c.symbol}>
                          {c.symbol} ({c.name})
                        </option>
                      ))}
                      {customCoins.filter(c => c.coinType === 'final_coin' && (c.creatorId === userId || c.creatorId === 'you')).length === 0 && (
                        <option value="">No Final Coins Created</option>
                      )}
                    </select>
                  </div>
                </div>
                <div>
                  <div className="w-full px-4 py-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300 font-mono font-extrabold text-base text-emerald-950 flex items-center justify-between">
                    <span>{parseFloat(adminAmount || '0').toLocaleString()} {adminTargetSymbol}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-600 text-white">1:1 Parity</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleExecuteAdminFinalExchange}
                className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-amber-600 hover:bg-amber-700 text-slate-950 font-bold text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>Processing Admin Exchange...</>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Execute Final Protocol Swap ({parseFloat(adminAmount || '0').toLocaleString()} AFNL → {adminTargetSymbol})</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* SECTION B: PEER / CROSS FINAL COIN EXCHANGE (Convert any final coin for another at 1:1) */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xl space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Peer Final Coin Cross-Swap</h3>
                <p className="text-[11px] text-slate-500">Protocol-level swap between creator-owned sovereign assets.</p>
              </div>
              <div className="px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-mono font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                1:1 Sovereign Parity
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              {/* Source Final Coin */}
              <div className="space-y-3 p-5 rounded-2xl bg-blue-50/70 border border-blue-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-blue-900 uppercase">Convert From</span>
                  <span className="text-[11px] font-mono text-blue-700 font-bold">
                    Available: {getSourceFinalBalance(peerSourceSymbol).toLocaleString()} {peerSourceSymbol}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                    {peerSourceSymbol}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <select
                      value={peerSourceSymbol}
                      onChange={(e) => setPeerSourceSymbol(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white border border-blue-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                    >
                      {customCoins.filter(c => c.coinType === 'final_coin' && (c.creatorId === userId || c.creatorId === 'you')).map((c) => (
                        <option key={c.symbol} value={c.symbol}>
                          {c.symbol} ({c.name})
                        </option>
                      ))}
                      {customCoins.filter(c => c.coinType === 'final_coin' && (c.creatorId === userId || c.creatorId === 'you')).length === 0 && (
                        <option value="">No Final Coins Created</option>
                      )}
                    </select>
                  </div>
                </div>
                <div>
                  <input
                    type="number"
                    min="1"
                    value={peerAmount}
                    onChange={(e) => setPeerAmount(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-white border border-blue-300 font-mono font-bold text-base text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter amount..."
                  />
                </div>
              </div>

              {/* Target Final Coin (Searchable) */}
              <div className="space-y-3 p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 relative">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-emerald-900 uppercase">Exchange To (Sovereign Units)</span>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold">
                    Ratio: Sovereign Parity
                  </span>
                </div>
                
                <div className="flex flex-col gap-2 relative">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                      {peerTargetSymbol || '?'}
                    </div>
                    <div className="flex-1 relative">
                      <input
                        type="text"
                        value={peerSearchQuery}
                        onChange={(e) => {
                          setPeerSearchQuery(e.target.value);
                          setShowPeerSearch(true);
                        }}
                        onFocus={() => setShowPeerSearch(true)}
                        placeholder="Search for a final coin..."
                        className="w-full px-3 py-2.5 rounded-xl bg-white border border-emerald-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                      />
                      
                      {/* Search Dropdown */}
                      {showPeerSearch && (
                        <div className="absolute top-full left-0 right-0 mt-2 max-h-48 overflow-y-auto bg-white border border-slate-200 rounded-xl shadow-xl z-50">
                          {filteredOtherCoins.length > 0 ? (
                            filteredOtherCoins.map(c => (
                              <button
                                key={c.symbol}
                                onClick={() => {
                                  setPeerTargetSymbol(c.symbol);
                                  setPeerSearchQuery(`${c.symbol} (${c.name})`);
                                  setShowPeerSearch(false);
                                }}
                                className="w-full px-3 py-2 text-left hover:bg-slate-50 flex items-center justify-between border-b border-slate-50 last:border-0"
                              >
                                <div>
                                  <div className="font-bold font-mono text-xs text-slate-900">{c.symbol}</div>
                                  <div className="text-[10px] text-slate-500">{c.name}</div>
                                </div>
                                <div className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded">
                                  Select
                                </div>
                              </button>
                            ))
                          ) : (
                            <div className="px-3 py-4 text-center text-[10px] text-slate-500">
                              No matching final coins found from other users.
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="w-full px-4 py-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300 font-mono font-extrabold text-base text-emerald-950 flex items-center justify-between mt-1">
                    <span>{parseFloat(peerAmount || '0').toLocaleString()} {peerTargetSymbol || '-'}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-600 text-white">1:1 Parity</span>
                  </div>
                </div>
                
                {/* Backdrop to close search */}
                {showPeerSearch && (
                  <div className="fixed inset-0 z-40" onClick={() => setShowPeerSearch(false)} />
                )}
              </div>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="leading-relaxed">{successMsg}</span>
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleExecutePeerFinalExchange}
                className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>Processing Exchange...</>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Execute Cross-Exchange ({parseFloat(peerAmount || '0').toLocaleString()} {peerSourceSymbol} → {peerTargetSymbol})</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 2: STABLECOINS EXCHANGE (Direct Multi-Currency Valuation Swaps) --- */}
      {activeExchangeMode === 'stable' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Stablecoin Swap</h3>
              <p className="text-[11px] text-slate-500">
                Execute direct cross-currency asset swaps based on USD valuation ratios.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-mono font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Asset-to-Asset Swap (Zero Fiat)</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            {/* Source Stable */}
            <div className="space-y-3 p-5 rounded-2xl bg-blue-50/70 border border-blue-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-blue-900 uppercase">You Pay (Source Stable)</span>
                <span className="text-[11px] font-mono text-blue-700 font-bold">
                  Available: {getSourceStableBalance(stableSourceId).toLocaleString()} {stableSourceId}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                  {stableSourceId}
                </div>
                <div className="flex-1 space-y-1.5">
                  <select
                    value={stableSourceId}
                    onChange={(e) => setStableSourceId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-blue-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  >
                    {uniqueStablecoins.map((s) => (
                      <option key={s.symbol} value={s.symbol}>
                        {s.symbol} ({s.name} - Peg: {s.peg})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <input
                  type="number"
                  min="1"
                  value={stableAmount}
                  onChange={(e) => setStableAmount(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-blue-300 font-mono font-bold text-base text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter amount..."
                />
              </div>
            </div>

            {/* Target Stable */}
            <div className="space-y-3 p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-emerald-900 uppercase">You Receive (Target Stable)</span>
                <span className="text-[11px] font-mono text-emerald-700 font-bold flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Zero Fiat Cashout
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                  {stableTargetId}
                </div>
                <div className="flex-1 space-y-1.5">
                  <select
                    value={stableTargetId}
                    onChange={(e) => setStableTargetId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-emerald-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    {uniqueStablecoins.map((s) => (
                      <option key={s.symbol} value={s.symbol}>
                        {s.symbol} ({s.name} - Peg: {s.peg})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                {(() => {
                  const srcObj = uniqueStablecoins.find(s => s.symbol === stableSourceId);
                  const tgtObj = uniqueStablecoins.find(s => s.symbol === stableTargetId);
                  const srcUsdVal = getTokenUsdValue(srcObj);
                  const tgtUsdVal = getTokenUsdValue(tgtObj);
                  const amt = parseFloat(stableAmount || '0');
                  const calc = tgtUsdVal > 0 ? (amt * srcUsdVal) / tgtUsdVal : 0;
                  return (
                    <div className="w-full px-4 py-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300 font-mono font-extrabold text-base text-emerald-950 flex items-center justify-between">
                      <span>{calc.toFixed(2)} {stableTargetId}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-600 text-white">Direct FX Output</span>
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>

          {/* Explicit Exchange Rate & Transparency Box */}
          {(() => {
            const srcObj = uniqueStablecoins.find(s => s.symbol === stableSourceId);
            const tgtObj = uniqueStablecoins.find(s => s.symbol === stableTargetId);
            const srcUsdVal = getTokenUsdValue(srcObj);
            const tgtUsdVal = getTokenUsdValue(tgtObj);
            const rate = tgtUsdVal > 0 ? srcUsdVal / tgtUsdVal : 1;
            const amt = parseFloat(stableAmount || '0');
            const rec = tgtUsdVal > 0 ? (amt * srcUsdVal) / tgtUsdVal : 0;
            const isUsdToInr = (srcObj?.peg === 'USD' || srcObj?.peg === 'none') && tgtObj?.peg === 'INR';
            return (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 font-mono text-xs">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-slate-700 pb-2 border-b border-slate-200 gap-1">
                  <span className="font-bold flex items-center gap-1.5 text-slate-900">
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                    Oracle Exchange Rate:
                  </span>
                  <span className="font-extrabold text-blue-900">
                    {isUsdToInr ? `1 USD = ${liveUsdInrRate.toFixed(2)} INR` : `1 ${stableSourceId} = ${rate.toFixed(4)} ${stableTargetId}`}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-600">
                  <div className="flex justify-between sm:justify-start sm:gap-4">
                    <span className="text-slate-500">You Pay:</span>
                    <span className="font-bold text-slate-900">{amt.toLocaleString()} {stableSourceId}</span>
                  </div>
                  <div className="flex justify-between sm:justify-start sm:gap-4">
                    <span className="text-slate-500">You Receive:</span>
                    <span className="font-bold text-emerald-700">{rec.toFixed(2)} {stableTargetId}</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[11px] text-slate-500">
                  <span>Chainlink / Pyth Forex Oracle Live Feeds Active</span>
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Direct On-Chain Swap (Zero Fiat Cashout)
                  </span>
                </div>
              </div>
            );
          })()}

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="leading-relaxed">{successMsg}</span>
            </div>
          )}

          <div className="pt-2 flex justify-end">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleExecuteStableExchange}
              className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>Executing Direct Swap...</>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Execute Direct On-Chain Swap ({stableAmount} {stableSourceId} → {stableTargetId})</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* --- TAB 3: CRYPTOCURRENCY SWAP --- */}
      {activeExchangeMode === 'crypto' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Sovereign Digital Asset Swaps</h3>
              <p className="text-[11px] text-slate-500">
                Swap major cryptocurrencies based on live USD market valuation ratios. Zero fiat currency involvement.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="px-3 py-1 rounded-full bg-purple-50 border border-purple-200 text-purple-800 text-[10px] font-mono font-bold flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-purple-600" />
                <span>No Fiat Involved</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            {/* Source Crypto */}
            <div className="space-y-3 p-5 rounded-2xl bg-purple-50/70 border border-purple-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-purple-900 uppercase">From Cryptocurrency</span>
                <span className="text-[11px] font-mono text-purple-700 font-bold">
                  Live Market Price
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                  {cryptoSourceSymbol}
                </div>
                <div className="flex-1 space-y-1.5">
                  <select
                    value={cryptoSourceSymbol}
                    onChange={(e) => setCryptoSourceSymbol(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-purple-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  >
                    {uniqueCryptos.map((c) => (
                      <option key={c.symbol} value={c.symbol}>
                        {c.symbol} ({c.name} - ${c.priceUSD.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <input
                  type="number"
                  step="0.001"
                  min="0.001"
                  value={cryptoAmount}
                  onChange={(e) => setCryptoAmount(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-purple-300 font-mono font-bold text-base text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  placeholder="Enter crypto amount..."
                />
              </div>
            </div>

            {/* Target Crypto */}
            <div className="space-y-3 p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-emerald-900 uppercase">To Cryptocurrency</span>
                <span className="text-[11px] font-mono text-emerald-700 font-bold flex items-center gap-1">
                  <Lock className="w-3 h-3" /> USD Conversion Ratio
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                  {cryptoTargetSymbol}
                </div>
                <div className="flex-1 space-y-1.5">
                  <select
                    value={cryptoTargetSymbol}
                    onChange={(e) => setCryptoTargetSymbol(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-emerald-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    {uniqueCryptos.map((c) => (
                      <option key={c.symbol} value={c.symbol}>
                        {c.symbol} ({c.name} - ${c.priceUSD.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                {(() => {
                  const srcCrypto = uniqueCryptos.find(c => c.symbol === cryptoSourceSymbol);
                  const tgtCrypto = uniqueCryptos.find(c => c.symbol === cryptoTargetSymbol);
                  const amt = parseFloat(cryptoAmount || '0');
                  const valUSD = amt * (srcCrypto?.priceUSD || 1);
                  const received = valUSD / (tgtCrypto?.priceUSD || 1);
                  return (
                    <div className="w-full px-4 py-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300 font-mono font-extrabold text-base text-emerald-950 flex items-center justify-between">
                      <span>{received.toFixed(4)} {cryptoTargetSymbol}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-600 text-white">${valUSD.toLocaleString()} USD Valued</span>
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="leading-relaxed">{successMsg}</span>
            </div>
          )}

          <div className="pt-2 flex justify-end">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleExecuteCryptoExchange}
              className="w-full sm:w-auto px-8 py-3 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>Swapping Cryptocurrencies...</>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Execute Crypto Swap ({cryptoAmount} {cryptoSourceSymbol} → {cryptoTargetSymbol})</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
