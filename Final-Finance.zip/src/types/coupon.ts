export type CouponCategory = 'restaurant' | 'retail' | 'ride_share';

export type CouponIssuerRole = 'restaurant_owner' | 'retail_owner' | 'driver';

export type CouponChannel = 'both' | 'online' | 'in_person';

export type CouponDiscountType = 'percentage' | 'fixed';

export interface PlatformCoupon {
  id: string;
  code: string;
  title: string;
  description: string;
  category: CouponCategory;
  issuerRole: CouponIssuerRole;
  issuerId: string;
  issuerHandle: string;
  issuerName: string;
  merchantLocationId?: string;
  merchantName: string;
  vehicleType?: string;
  discountType: CouponDiscountType;
  discountValue: number;
  currency: string;
  minOrderAmount: number;
  maxDiscountAmount?: number;
  validChannels: CouponChannel;
  expiresAt: string;
  maxRedemptions?: number;
  redemptionCount: number;
  active: boolean;
  createdAt: string;
}

export interface SavedCouponRecord {
  id: string;
  couponId: string;
  userId: string;
  savedAt: string;
  status: 'saved' | 'redeemed';
  redeemedAt?: string;
  redeemedChannel?: 'online' | 'in_person';
  redeemedOrderRef?: string;
  discountApplied?: number;
  redemptionCurrency?: string;
}

export interface PendingCheckoutCoupon {
  couponId: string;
  code: string;
  category: CouponCategory;
  channel: 'online' | 'in_person';
  merchantLocationId?: string;
}

export interface CouponEvaluationResult {
  valid: boolean;
  reason?: string;
  discountAmount: number;
}
