
import React, { useState, useEffect } from 'react';
import { Star, MessageSquare, Send, User, Trash2 } from 'lucide-react';
import { getRatingsForUser, addReview, getAverageRating, Review } from '../../services/ratingService';
import { AuthSession } from '../../types/auth';

interface UserRatingSectionProps {
  targetUserId: string;
  currentUser: AuthSession | null;
  onRatingSubmitted?: () => void;
}

export const UserRatingSection: React.FC<UserRatingSectionProps> = ({ targetUserId, currentUser, onRatingSubmitted }) => {
  const [ratings, setRatings] = useState<Review[]>([]);
  const [avgRating, setAvgRating] = useState({ average: 0, count: 0 });
  const [userRating, setUserRating] = useState(5);
  const [userComment, setUserComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);

  const loadRatings = () => {
    setRatings(getRatingsForUser(targetUserId));
    setAvgRating(getAverageRating(targetUserId));
  };

  useEffect(() => {
    loadRatings();
  }, [targetUserId]);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (userComment.trim().length < 3) return;

    setIsSubmitting(true);
    addReview({
      targetUserId,
      reviewerId: currentUser.id,
      reviewerName: currentUser.name,
      reviewerAvatar: currentUser.avatarUrl,
      rating: userRating,
      comment: userComment.trim()
    });

    setUserComment('');
    setUserRating(5);
    setIsSubmitting(false);
    loadRatings();
    onRatingSubmitted?.();
  };

  const renderStars = (rating: number, onStarClick?: (r: number) => void, onStarHover?: (r: number) => void) => {
    return (
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 cursor-pointer transition-colors ${
              (hoverRating || rating) >= star ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
            }`}
            onClick={() => onStarClick?.(star)}
            onMouseEnter={() => onStarHover?.(star)}
            onMouseLeave={() => onStarHover?.(0)}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Summary Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-50 flex items-center justify-center text-amber-600">
            <Star className="w-5 h-5 fill-amber-500" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">Peer Ratings & Reviews</h3>
            <div className="flex items-center gap-2 mt-0.5">
              <div className="flex items-center gap-1">
                {renderStars(avgRating.average)}
                <span className="text-xs font-bold text-slate-900 ml-1">{avgRating.average}</span>
              </div>
              <span className="text-[11px] text-slate-500">• {avgRating.count} reviews</span>
            </div>
          </div>
        </div>
      </div>

      {/* Write a Review */}
      {currentUser && currentUser.id !== targetUserId && (
        <form onSubmit={handleSubmitReview} className="bg-slate-50 rounded-2xl p-4 border border-slate-200/60 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700">Write a review</span>
            {renderStars(userRating, setUserRating, setHoverRating)}
          </div>
          <div className="relative">
            <textarea
              value={userComment}
              onChange={(e) => setUserComment(e.target.value)}
              placeholder="Share your experience with this member..."
              className="w-full min-h-[80px] p-3 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500 resize-none"
            />
            <button
              type="submit"
              disabled={isSubmitting || userComment.trim().length < 3}
              className="absolute bottom-2 right-2 p-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {/* Reviews List */}
      <div className="space-y-4">
        {ratings.length === 0 ? (
          <div className="py-10 text-center space-y-2">
            <MessageSquare className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-xs text-slate-500">No reviews yet. Be the first to rate!</p>
          </div>
        ) : (
          ratings.map((review) => (
            <div key={review.id} className="group p-4 rounded-2xl bg-white border border-slate-100 hover:border-slate-200 transition-all space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 overflow-hidden border border-slate-200">
                    {review.reviewerAvatar ? (
                      <img src={review.reviewerAvatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-slate-900 text-white text-[10px] font-bold">
                        {review.reviewerName.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">@{review.reviewerId}</div>
                    <div className="text-[10px] text-slate-500">{new Date(review.timestamp).toLocaleDateString()}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100">
                  <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                  <span className="text-[10px] font-bold text-amber-800">{review.rating}</span>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed italic">
                "{review.comment}"
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
