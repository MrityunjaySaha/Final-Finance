import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Zap,
  Coins,
  Plus,
  Flame,
  Send,
  Trash2,
  ExternalLink,
  Copy,
  Check,
  Layers,
  Lock,
  AlertTriangle,
  Sparkles,
  TrendingUp
} from 'lucide-react';
import { CustomCoin } from '../../types/coinLaunch';
import { AuthSession } from '../../types/auth';

interface ManageCoinModalProps {
  coin: CustomCoin | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthSession | null;
  onUpdateCoin: (updatedCoin: CustomCoin) => void;
  onDeleteCoin: (coinId: string) => void;
}

export const ManageCoinModal: React.FC<ManageCoinModalProps> = ({
  coin,
  isOpen,
  onClose,
  currentUser,
  onUpdateCoin,
  onDeleteCoin
}) => {
  const [activeAction, setActiveAction] = useState<'overview' | 'mint' | 'burn' | 'transfer'>('overview');
  const [actionAmount, setActionAmount] = useState<number>(100000);
  const [recipientAddress, setRecipientAddress] = useState('');
  const [copied, setCopied] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  if (!isOpen || !coin) return null;

  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';
  const isOwner = coin.creatorId === currentUser?.id || (coin.isAdminCoin && isAdmin);

  const showNotification = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 3000);
  };

  const handleCopyContract = () => {
    navigator.clipboard.writeText(coin.contractAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleMint = (e: React.FormEvent) => {
    e.preventDefault();
    if (actionAmount <= 0) return;
    const updated: CustomCoin = {
      ...coin,
      totalSupply: coin.totalSupply + actionAmount,
      circulatingSupply: coin.circulatingSupply + actionAmount,
    };
    onUpdateCoin(updated);
    showNotification(`Successfully minted +${actionAmount.toLocaleString()} $${coin.symbol}`);
    setActiveAction('overview');
  };

  const handleBurn = (e: React.FormEvent) => {
    e.preventDefault();
    if (actionAmount <= 0 || actionAmount > coin.circulatingSupply) {
      alert('Burn amount cannot exceed circulating supply.');
      return;
    }
    const updated: CustomCoin = {
      ...coin,
      circulatingSupply: coin.circulatingSupply - actionAmount,
      totalSupply: Math.max(0, coin.totalSupply - actionAmount),
      burnedSupply: (coin.burnedSupply || 0) + actionAmount,
    };
    onUpdateCoin(updated);
    showNotification(`Successfully burned ${actionAmount.toLocaleString()} $${coin.symbol}`);
    setActiveAction('overview');
  };

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (actionAmount <= 0 || !recipientAddress.trim()) {
      alert('Please enter a recipient address and valid amount.');
      return;
    }
    showNotification(`Dispatched ${actionAmount.toLocaleString()} $${coin.symbol} to ${recipientAddress.slice(0, 10)}...`);
    setActiveAction('overview');
  };

  const handleDelete = () => {
    if (confirm(`Are you sure you want to delist and archive ${coin.name} ($${coin.symbol})? This will free up 1 of your 10 coin quota slots.`)) {
      onDeleteCoin(coin.id);
      onClose();
    }
  };

  const marketCapUSD = coin.circulatingSupply * coin.priceUSD;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200 text-left">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-8">
        
        {/* Toast */}
        {toastMsg && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-slate-900 text-white rounded-xl shadow-lg border border-slate-700 text-xs font-mono flex items-center gap-2">
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* Top Banner */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            {coin.logoUrl ? (
              <div className="w-12 h-12 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-md shrink-0 bg-slate-900">
                <img src={coin.logoUrl} alt={coin.name} className="w-full h-full object-cover" />
              </div>
            ) : (
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${coin.logoBg} flex items-center justify-center text-2xl font-bold shadow-md shrink-0`}>
                {coin.iconSymbol}
              </div>
            )}
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-serif text-lg sm:text-xl font-bold text-white">{coin.name}</h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-full bg-white/10 text-amber-300">
                  ${coin.symbol}
                </span>
                {coin.isAdminCoin ? (
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                    👑 ADMIN MASTER COIN
                  </span>
                ) : (
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Sovereign Creator Token
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300 mt-0.5">{coin.pegTargetDisplay}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Tabs */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto text-xs">
          <button
            type="button"
            onClick={() => setActiveAction('overview')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              activeAction === 'overview'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-200/70 text-slate-700 hover:bg-slate-300'
            }`}
          >
            Token Overview
          </button>
          
          {isOwner && (
            <>
              <button
                type="button"
                onClick={() => setActiveAction('mint')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeAction === 'mint'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Mint Supply</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveAction('burn')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeAction === 'burn'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-200'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Burn Tokens</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveAction('transfer')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeAction === 'transfer'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border border-indigo-200'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span>Airdrop / Transfer</span>
              </button>
            </>
          )}
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          
          {/* TAB 1: OVERVIEW */}
          {activeAction === 'overview' && (
            <div className="space-y-5">
              
              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono block">Unit Price</span>
                  <span className="font-mono text-base font-bold text-slate-900 block mt-0.5">
                    {coin.priceUSD >= 1 ? `$${coin.priceUSD.toFixed(2)}` : `$${coin.priceUSD.toFixed(4)}`}
                  </span>
                  <span className="text-[10px] text-emerald-600 font-mono font-bold">
                    {coin.change24h >= 0 ? '+' : ''}{coin.change24h}% 24h
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono block">Market Cap</span>
                  <span className="font-mono text-base font-bold text-slate-900 block mt-0.5">
                    ${(marketCapUSD / 1000000).toFixed(2)}M
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">Circulating Total</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono block">Circulation</span>
                  <span className="font-mono text-base font-bold text-slate-900 block mt-0.5">
                    {(coin.circulatingSupply / 1000000).toFixed(1)}M
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">of {(coin.totalSupply / 1000000).toFixed(1)}M Max</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-[10px] font-bold uppercase text-slate-400 font-mono block">Backing Ratio</span>
                  <span className="font-mono text-base font-bold text-emerald-600 block mt-0.5">
                    {coin.reserveRatioPercent}%
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">Audited Reserve</span>
                </div>
              </div>

              {/* Peg & Reserve Breakdown */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Collateral &amp; Reserve Specifications</span>
                  </h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                    Audit: {coin.auditScore}/100
                  </span>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">{coin.reserveBackingDescription}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-400 text-[11px] block">Collateral Classification</span>
                    <span className="font-bold text-slate-800">{coin.collateralAssetType || 'Protocol Sovereign Vault'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px] block">Peg Anchor Mechanism</span>
                    <span className="font-bold text-slate-800">
                      {coin.coinType === 'stable_coin'
                        ? coin.pegCurrency === 'USD' ? '1:1 Fixed USD Clearing' : '1:1 Fixed INR Clearing'
                        : coin.coinType === 'final_coin'
                        ? '1:1 AFNL Sovereign Peg'
                        : 'Unpegged Free Sovereign Valuation'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Contract & Creator Info */}
              <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Smart Contract Address:</span>
                  <button
                    type="button"
                    onClick={handleCopyContract}
                    className="flex items-center gap-1 text-[11px] font-mono text-amber-400 hover:text-amber-300 cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="font-mono text-xs text-slate-300 break-all p-2 rounded-xl bg-slate-950 border border-slate-800">
                  {coin.contractAddress}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                  <span>Issued by: <strong className="text-white">{coin.creatorName}</strong> (@{coin.creatorHandle})</span>
                  <span>Network: <strong className="text-white">{coin.network}</strong></span>
                </div>
              </div>

              {/* Small Description & Pitch Pitch */}
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    📝 Coin Pitch &amp; Description
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed italic">
                    "{coin.description || `${coin.name} (${coin.symbol.toUpperCase()}) is a sovereign token issued on ${coin.network}.`}"
                  </p>
                </div>

                {/* Photos Gallery */}
                {coin.photos && coin.photos.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      🖼️ Pitch Gallery ({coin.photos.length})
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {coin.photos.map((photo, idx) => (
                        <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-slate-100 dark:border-slate-800 group shadow-2xs">
                          <img src={photo} alt={`${coin.name} pitch ${idx + 1}`} className="w-full h-full object-cover" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Videos Gallery */}
                {coin.videos && coin.videos.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      🎥 Video Presentation ({coin.videos.length})
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {coin.videos.map((video, idx) => (
                        <div key={idx} className="relative aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-200 dark:border-slate-800 group shadow-2xs">
                          <video src={video} controls className="w-full h-full object-contain" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Delist & Free Quota Slot (if creator and not default admin master) */}
              {isOwner && !coin.isAdminCoin && (
                <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-between">
                  <div>
                    <h5 className="font-bold text-xs text-rose-900">Delist &amp; Archive Coin</h5>
                    <p className="text-[11px] text-rose-700">Removes coin and frees up 1 of your 10 category launch quotas.</p>
                  </div>
                  <button
                    type="button"
                    onClick={handleDelete}
                    className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delist Coin</span>
                  </button>
                </div>
              )}

            </div>
          )}

          {/* TAB 2: MINT ADDITIONAL SUPPLY */}
          {activeAction === 'mint' && (
            <form onSubmit={handleMint} className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-1">
                <h4 className="font-bold flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-emerald-600" />
                  <span>Mint New ${coin.symbol} Tokens</span>
                </h4>
                <p>Increase the circulating and total supply of your coin by locking collateral or expanding liquidity.</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Amount to Mint</label>
                <input
                  type="number"
                  min={1}
                  value={actionAmount}
                  onChange={(e) => setActionAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-100 text-xs space-y-1 font-mono">
                <div className="flex justify-between text-slate-600">
                  <span>Current Total Supply:</span>
                  <span>{coin.totalSupply.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold text-emerald-700">
                  <span>New Total Supply:</span>
                  <span>{(coin.totalSupply + actionAmount).toLocaleString()}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setActiveAction('overview')}
                  className="px-5 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-7 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-extrabold shadow-lg shadow-emerald-600/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Confirm Minting</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: BURN SUPPLY */}
          {activeAction === 'burn' && (
            <form onSubmit={handleBurn} className="space-y-4">
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-900 space-y-1">
                <h4 className="font-bold flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-rose-600" />
                  <span>Burn ${coin.symbol} Tokens</span>
                </h4>
                <p>Permanently remove tokens from circulation to enforce deflationary dynamics or redemption.</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Amount to Burn</label>
                <input
                  type="number"
                  min={1}
                  max={coin.circulatingSupply}
                  value={actionAmount}
                  onChange={(e) => setActionAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono text-slate-900 font-bold focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-100 text-xs space-y-1 font-mono">
                <div className="flex justify-between text-slate-600">
                  <span>Circulating Supply:</span>
                  <span>{coin.circulatingSupply.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold text-rose-700">
                  <span>Circulating After Burn:</span>
                  <span>{(coin.circulatingSupply - actionAmount).toLocaleString()}</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setActiveAction('overview')}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Permanently Burn Tokens
                </button>
              </div>
            </form>
          )}

          {/* TAB 4: TRANSFER / AIRDROP */}
          {activeAction === 'transfer' && (
            <form onSubmit={handleTransfer} className="space-y-4">
              <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-900 space-y-1">
                <h4 className="font-bold flex items-center gap-1.5">
                  <Send className="w-4 h-4 text-indigo-600" />
                  <span>Airdrop or Transfer Tokens</span>
                </h4>
                <p>Transfer minted tokens to a sovereign community wallet or investor account.</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Recipient Address</label>
                <input
                  type="text"
                  required
                  placeholder="0x..."
                  value={recipientAddress}
                  onChange={(e) => setRecipientAddress(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono text-slate-900"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Transfer Amount</label>
                <input
                  type="number"
                  min={1}
                  value={actionAmount}
                  onChange={(e) => setActionAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-mono text-slate-900 font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setActiveAction('overview')}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Send Tokens
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
