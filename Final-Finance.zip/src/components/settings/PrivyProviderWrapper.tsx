import React from 'react';
import { PrivyProvider } from '@privy-io/react-auth';
import { mainnet } from 'viem/chains';
import { getPrivyAppId, PRIVY_SUPPORTED_CHAINS } from '../../config/privyConfig';

class PrivyErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(err: unknown) {
    console.warn('[PrivyProviderWrapper] Non-fatal Privy initialization error:', err);
  }

  render() {
    if (this.state.hasError) {
      return <>{this.props.children}</>;
    }
    return this.props.children;
  }
}

export const PrivyProviderWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const appId = getPrivyAppId();

  return (
    <PrivyErrorBoundary>
      <PrivyProvider
        appId={appId}
        config={{
          appearance: {
            theme: 'light',
            accentColor: '#0f172a',
            landingHeader: 'Connect Crypto Wallet',
            walletChainType: 'ethereum-only',
            walletList: ['detected_ethereum_wallets', 'metamask', 'rainbow', 'uniswap', 'wallet_connect'],
          },
          loginMethods: ['wallet'],
          defaultChain: mainnet,
          supportedChains: PRIVY_SUPPORTED_CHAINS,
        }}
      >
        {children}
      </PrivyProvider>
    </PrivyErrorBoundary>
  );
};
