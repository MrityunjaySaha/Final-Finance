import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  AlertCircle, 
  ShieldCheck,
  Sparkles,
  Lock,
  Mail,
  User,
  AtSign,
  KeyRound,
  ArrowRight,
  Loader2,
  Crown,
  Shield,
  Gem,
  Compass,
  CheckCircle2
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { GoogleAuthButton } from './GoogleAuthButton';
import { 
  signInWithCredentials, 
  registerWithCredentials, 
  requestPasswordReset, 
  signInWithDemoAccount, 
  DEMO_ACCOUNTS 
} from '../services/firebaseAuth';

interface AuthModalProps {
  initialView: 'signin' | 'signup';
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: AuthSession) => void;
}

type AuthTab = 'signin' | 'signup' | 'forgot';

export const AuthModal: React.FC<AuthModalProps> = ({
  initialView,
  isOpen,
  onClose,
  onAuthSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<AuthTab>(initialView === 'signup' ? 'signup' : 'signin');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form Fields
  const [emailOrUserId, setEmailOrUserId] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [signUpUserId, setSignUpUserId] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [resetIdentifier, setResetIdentifier] = useState('');

  if (!isOpen) return null;

  const handleCredentialsSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrUserId.trim() || !password) {
      setErrorMessage('Please enter both your Email / User ID and Password.');
      return;
    }
    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = await signInWithCredentials(emailOrUserId, password);
      if (res.success && res.user) {
        onAuthSuccess(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Sign in failed. Please check your credentials.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Sign in encountered an error.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCredentialsSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !signUpUserId.trim() || !signUpEmail.trim() || !signUpPassword) {
      setErrorMessage('Please complete all required fields.');
      return;
    }
    if (signUpPassword.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }
    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = await registerWithCredentials({
        fullName: fullName.trim(),
        userId: signUpUserId.trim(),
        email: signUpEmail.trim(),
        password: signUpPassword,
      });
      if (res.success && res.user) {
        onAuthSuccess(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Account registration failed.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Registration encountered an error.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasswordResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetIdentifier.trim()) {
      setErrorMessage('Please enter your User ID or Email address.');
      return;
    }
    setIsSubmitting(true);
    setErrorMessage('');
    setSuccessMessage('');
    try {
      const res = await requestPasswordReset(resetIdentifier.trim());
      if (res.success) {
        setSuccessMessage(`Password reset link sent to ${res.emailSentTo || resetIdentifier}. Check your inbox!`);
      } else {
        setErrorMessage(res.error || 'Failed to send reset link.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Password reset encountered an error.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="auth-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        id="auth-modal-card"
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 12 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative text-left my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-auth-modal"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 sm:top-5 sm:right-5 min-h-[38px] min-w-[38px] flex items-center justify-center rounded-full text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer z-10"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* View Switcher Tabs */}
        <div className="flex border-b border-slate-200 mb-5 pb-1 gap-6 overflow-x-auto no-scrollbar">
          <button
            id="tab-signin"
            type="button"
            onClick={() => {
              setActiveTab('signin');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`min-h-[40px] text-xs sm:text-sm font-semibold pb-2 -mb-1 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'signin'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Sign In
          </button>

          <button
            id="tab-signup"
            type="button"
            onClick={() => {
              setActiveTab('signup');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`min-h-[40px] text-xs sm:text-sm font-semibold pb-2 -mb-1 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'signup'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto pr-1 space-y-4 flex-1">
          {/* Header content */}
          <div>
            <h2 className="font-serif text-2xl font-bold text-slate-900 tracking-tight">
              {activeTab === 'signin' && 'Welcome to Final Finance'}
              {activeTab === 'signup' && 'Create Your Portfolio'}
              {activeTab === 'forgot' && 'Reset Your Password'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              {activeTab === 'signin' && 'Sign in to access your reserve vaults, barter desk, and encrypted messaging.'}
              {activeTab === 'signup' && 'Register your verified participant handle across our 5-vault ecosystem.'}
              {activeTab === 'forgot' && 'Enter your registered email or handle to receive recovery instructions.'}
            </p>
          </div>

          {/* Error Notification */}
          {errorMessage && (
            <div
              id="auth-error-alert"
              className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm flex items-start gap-2.5"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Success Notification */}
          {successMessage && (
            <div
              id="auth-success-alert"
              className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm flex items-start gap-2.5"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* ================= TAB 2: SIGN IN ================= */}
          {activeTab === 'signin' && (
            <div className="space-y-4">
              {/* Google Auth Button */}
              <GoogleAuthButton
                mode="signin"
                onSuccess={(user) => {
                  onAuthSuccess(user);
                  onClose();
                }}
                onError={(err) => setErrorMessage(err)}
                disabled={isSubmitting}
              />

              <div className="flex items-center gap-3 my-2">
                <div className="h-px bg-slate-200 flex-1" />
                <span className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">or continue with email</span>
                <div className="h-px bg-slate-200 flex-1" />
              </div>

              <form onSubmit={handleCredentialsSignIn} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Email or User ID</label>
                  <div className="relative">
                    <input
                      type="text"
                      id="signin-identifier-input"
                      value={emailOrUserId}
                      onChange={(e) => setEmailOrUserId(e.target.value)}
                      placeholder="e.g. alex_morgan or name@domain.com"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white"
                      required
                    />
                    <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-xs font-medium text-slate-700">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('forgot');
                        setErrorMessage('');
                      }}
                      className="text-[11px] text-slate-500 hover:text-slate-900 transition-colors"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type="password"
                      id="signin-password-input"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white"
                      required
                    />
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <button
                  type="submit"
                  id="submit-credentials-signin"
                  disabled={isSubmitting}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <>
                      <span>Sign In</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* ================= TAB 3: CREATE ACCOUNT ================= */}
          {activeTab === 'signup' && (
            <div className="space-y-4">
              <GoogleAuthButton
                mode="signup"
                onSuccess={(user) => {
                  onAuthSuccess(user);
                  onClose();
                }}
                onError={(err) => setErrorMessage(err)}
                disabled={isSubmitting}
              />

              <div className="flex items-center gap-3 my-2">
                <div className="h-px bg-slate-200 flex-1" />
                <span className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">or register credentials</span>
                <div className="h-px bg-slate-200 flex-1" />
              </div>

              <form onSubmit={handleCredentialsSignUp} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                  <div className="relative">
                    <input
                      type="text"
                      id="signup-fullname-input"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Jordan Belfort"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white"
                      required
                    />
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Desired User ID / Handle</label>
                  <div className="relative">
                    <input
                      type="text"
                      id="signup-userid-input"
                      value={signUpUserId}
                      onChange={(e) => setSignUpUserId(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                      placeholder="e.g. jordan_trader"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white"
                      required
                    />
                    <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Shown in header and used for direct mentions (@handle).</p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
                  <div className="relative">
                    <input
                      type="email"
                      id="signup-email-input"
                      value={signUpEmail}
                      onChange={(e) => setSignUpEmail(e.target.value)}
                      placeholder="name@domain.com"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white"
                      required
                    />
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Password (min 8 characters)</label>
                  <div className="relative">
                    <input
                      type="password"
                      id="signup-password-input"
                      value={signUpPassword}
                      onChange={(e) => setSignUpPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white"
                      required
                      minLength={8}
                    />
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <button
                  type="submit"
                  id="submit-credentials-signup"
                  disabled={isSubmitting}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60 mt-1"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <>
                      <span>Create Final Finance Account</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* ================= TAB 4: FORGOT PASSWORD ================= */}
          {activeTab === 'forgot' && (
            <div className="space-y-4">
              <form onSubmit={handlePasswordResetSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Your Registered User ID or Email</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={resetIdentifier}
                      onChange={(e) => setResetIdentifier(e.target.value)}
                      placeholder="e.g. jordan_trader or name@domain.com"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white"
                      required
                    />
                    <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <span>Send Password Reset Link</span>
                  )}
                </button>
              </form>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('signin');
                    setErrorMessage('');
                    setSuccessMessage('');
                  }}
                  className="text-xs text-slate-600 hover:text-slate-900 font-medium transition-colors"
                >
                  &larr; Back to Sign In
                </button>
              </div>
            </div>
          )}

          {/* Security & Benefits Badges */}
          <div className="pt-3 border-t border-slate-200 space-y-1.5">
            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Multi-vault cryptographic account security</span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Institutional 5-vault liquidity and barter desk</span>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <p className="text-[11px] text-slate-400 text-center mt-3 shrink-0">
          By continuing, you agree to Final Finance Terms of Service and Privacy Policy.
        </p>
      </motion.div>
    </div>
  );
};
