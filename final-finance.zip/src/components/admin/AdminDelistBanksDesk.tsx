import React, { useState } from 'react';
import { Search, Building2, Trash2 } from 'lucide-react';
import { ConfirmModal } from '../common/ConfirmModal';

interface BankUser {
  id: string;
  userName: string;
  userHandle: string;
  status: 'active' | 'delisted';
}

export const AdminDelistBanksDesk: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<BankUser[]>([
    { id: 'u1', userName: 'Swiss Sovereign Reserve', userHandle: '@swiss_reserve', status: 'active' },
    { id: 'u2', userName: 'Neo Tokyo Trust', userHandle: '@tokyo_trust', status: 'active' },
    { id: 'u3', userName: 'Global Clear Corp', userHandle: '@global_clear', status: 'active' },
  ]);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    userId: string | null;
  }>({ isOpen: false, userId: null });

  const filteredUsers = users.filter(u => 
    u.userName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.userHandle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeBankCount = users.filter(u => u.status === 'active').length;

  const handleDelist = (id: string) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, status: 'delisted' } : u));
    setConfirmModal({ isOpen: false, userId: null });
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <div>
          <h2 className="font-serif text-xl font-bold text-slate-900">Manage Licensed Banks</h2>
          <p className="text-sm text-slate-500">Search and manage authorized banking institutions.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="px-4 py-2 bg-emerald-50 border border-emerald-100 rounded-xl">
            <span className="text-xs font-bold text-emerald-700">Active Banks: {activeBankCount}</span>
          </div>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search banks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-64"
            />
          </div>
        </div>
      </div>

      <div className="grid gap-3">
        {filteredUsers.map(user => (
          <div key={user.id} className="flex items-center justify-between p-4 bg-white hover:bg-slate-50 rounded-2xl border border-slate-100 transition-colors">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-600">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">{user.userName}</h3>
                <p className="text-xs text-slate-500 mb-1">{user.userHandle}</p>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                  user.status === 'active' 
                    ? 'bg-emerald-50 text-emerald-700' 
                    : 'bg-rose-50 text-rose-700'
                }`}>
                  {user.status.toUpperCase()}
                </span>
              </div>
            </div>
            {user.status === 'active' && (
              <button
                onClick={() => setConfirmModal({ isOpen: true, userId: user.id })}
                className="px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delist
              </button>
            )}
          </div>
        ))}
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal({ isOpen: false, userId: null })}
        onConfirm={() => confirmModal.userId && handleDelist(confirmModal.userId)}
        title="Delist Banking License"
        message="Are you sure you want to delist this institution? This action will revoke all associated clearing privileges and is irreversible."
        type="danger"
        confirmText="Delist Bank"
      />
    </div>
  );
};
