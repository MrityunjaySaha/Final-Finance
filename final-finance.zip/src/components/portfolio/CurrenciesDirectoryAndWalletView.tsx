import React, { useState, useEffect, useMemo } from 'react';
import {
  Wallet,
  Building2,
  Trash2,
  Eye,
  Zap,
  ArrowRightLeft,
  ShieldCheck,
  Coins,
  Send
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { UserWalletData } from '../../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../../data/defaultWallets';
import { FinalCoinMintStudio } from './FinalCoinMintStudio';
import { FinalCoinDetailsModal } from './FinalCoinDetailsModal';
import { FinalCoinTransferModal } from './FinalCoinTransferModal';
import { CoinExchangeTab } from './CoinExchangeTab';
import { getStoredCustomCoins } from '../../data/customCoinsData';
import { CustomCoin, MAX_FINAL_COINS_PER_USER } from '../../types/coinLaunch';

interface CurrenciesDirectoryAndWalletViewProps {
  currentUser: AuthSession | null;
  onOpenExchange?: (payload: { symbol: string; name: string; balance: number; category: string }) => void;
  hideSovereignTools?: boolean;
  sovereignOnly?: boolean;
}

export const CurrenciesDirectoryAndWalletView: React.FC<CurrenciesDirectoryAndWalletViewProps> = ({
  currentUser,
  onOpenExchange,
  hideSovereignTools = false,
  sovereignOnly = false
}) => {
  const userId = currentUser?.id || 'guest';
  const userName = currentUser?.name || 'Guest User';

  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(userId));
  const [allCustomCoins, setAllCustomCoins] = useState(() => getStoredCustomCoins());
  const [selectedFinalCoinForDetails, setSelectedFinalCoinForDetails] = useState<CustomCoin | null>(null);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [selectedCoinForTransfer, setSelectedCoinForTransfer] = useState<string | null>(null);

  // Sync wallet data on window events
  useEffect(() => {
    const handleUpdate = () => {
      setWalletData(getStoredUserWallets(userId));
      setAllCustomCoins(getStoredCustomCoins());
    };

    window.addEventListener('final_finance_wallets_updated', handleUpdate);
    window.addEventListener('final_finance_custom_coins_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleUpdate);
      window.removeEventListener('final_finance_custom_coins_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [userId]);

  // Main View Toggle: 'my_holdings' vs 'final_coins_studio' vs 'swap'
  const [activeMainTab, setActiveMainTab] = useState<'my_holdings' | 'final_coins_studio' | 'swap'>('my_holdings');

  // Holdings Category Filter
  const [holdingsCategoryFilter, setHoldingsCategoryFilter] = useState<'all' | 'final' | 'stable' | 'crypto' | 'fiat'>(
    sovereignOnly ? 'final' : 'all'
  );

  // Computed Portfolio Valuations
  const finalCoinsHoldings = walletData.finalCoins || [];
  const stableCoinsHoldings = walletData.stableCoins || [];
  const cryptoHoldings = walletData.cryptoCurrencies || [];
  const fiatHoldings = walletData.fiatCurrencies || [];

  const totalFinalUSD = 0; // Sovereign final coins have no fiat equivalent
  const totalStableUSD = stableCoinsHoldings.reduce((acc, c) => acc + (c.balance * (c.unitPriceUSD || 1)), 0);
  const totalCryptoUSD = cryptoHoldings.reduce((acc, c) => acc + (c.balance * (c.unitPriceUSD || 1)), 0);
  const totalFiatUSD = fiatHoldings.reduce((acc, c) => acc + (c.balance * 1), 0);
  
  const grandTotalUSD = totalFinalUSD + totalStableUSD + totalCryptoUSD + totalFiatUSD;
  const totalAssetsCount = finalCoinsHoldings.length + stableCoinsHoldings.length + cryptoHoldings.length + fiatHoldings.length;

  const userCreatedFinalCoins = useMemo(() => {
    return allCustomCoins.filter(c => c.creatorId === userId);
  }, [allCustomCoins, userId]);

  // Action Buttons
  const renderSwapButton = (payload: { symbol: string; name: string; balance: number; category: string }) => {
    if (hideSovereignTools) return null;
    return (
      <button
        type="button"
        onClick={() => {
          setActiveMainTab('swap');
          if (onOpenExchange) onOpenExchange(payload);
        }}
        className="py-1.5 px-2 rounded-lg bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-800 text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
      >
        <ArrowRightLeft className="w-3 h-3" />
        <span>Swap</span>
      </button>
    );
  };

  // Handler: Remove Holding
  const handleRemoveHolding = (symbol: string, category: 'final' | 'stable' | 'crypto' | 'fiat') => {
    if (!window.confirm(`Are you sure you want to hide ${symbol} from your active wallet view? You can add it back later.`)) {
      return;
    }
    const w = { ...walletData };
    if (category === 'final') w.finalCoins = w.finalCoins.filter(c => c.symbol !== symbol);
    if (category === 'stable') w.stableCoins = w.stableCoins.filter(c => c.symbol !== symbol);
    if (category === 'crypto') w.cryptoCurrencies = w.cryptoCurrencies.filter(c => c.symbol !== symbol);
    if (category === 'fiat') w.fiatCurrencies = w.fiatCurrencies.filter(c => c.code !== symbol);
    saveStoredUserWallets(userId, w);
    setWalletData(w);
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER REMOVED FOR INTEGRATED VIEW */}
      <div className="pb-4 border-b border-slate-200">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-2 overflow-x-auto whitespace-nowrap scrollbar-hide pb-1">
            {!sovereignOnly && (
              <button
                type="button"
                onClick={() => {
                  setActiveMainTab('my_holdings');
                  setHoldingsCategoryFilter('all');
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  activeMainTab === 'my_holdings' && holdingsCategoryFilter === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>All Holdings ({totalAssetsCount})</span>
              </button>
            )}

            {!hideSovereignTools && (
              <button
                type="button"
                onClick={() => {
                  setActiveMainTab('my_holdings');
                  setHoldingsCategoryFilter('final');
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  activeMainTab === 'my_holdings' && holdingsCategoryFilter === 'final'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Final Coins ({finalCoinsHoldings.length})</span>
              </button>
            )}

            {!sovereignOnly && (
              <button
                type="button"
                onClick={() => {
                  setActiveMainTab('my_holdings');
                  setHoldingsCategoryFilter('stable');
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  activeMainTab === 'my_holdings' && holdingsCategoryFilter === 'stable'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Stablecoins ({stableCoinsHoldings.length})</span>
              </button>
            )}

            {!sovereignOnly && (
              <button
                type="button"
                onClick={() => {
                  setActiveMainTab('my_holdings');
                  setHoldingsCategoryFilter('crypto');
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  activeMainTab === 'my_holdings' && holdingsCategoryFilter === 'crypto'
                    ? 'bg-purple-600 text-white'
                    : 'bg-purple-50 text-purple-800 hover:bg-purple-100 border border-purple-200'
                }`}
              >
                <Coins className="w-3.5 h-3.5" />
                <span>Cryptocurrencies ({cryptoHoldings.length})</span>
              </button>
            )}

            {!sovereignOnly && (
              <button
                type="button"
                onClick={() => {
                  setActiveMainTab('my_holdings');
                  setHoldingsCategoryFilter('fiat');
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  activeMainTab === 'my_holdings' && holdingsCategoryFilter === 'fiat'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border border-indigo-200'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Sovereign Fiat ({fiatHoldings.length})</span>
              </button>
            )}

            {!hideSovereignTools && (
              <>
                <div className="w-px h-6 bg-slate-200 mx-1 shrink-0" />

                <button
                  type="button"
                  onClick={() => setActiveMainTab('final_coins_studio')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 ${
                    activeMainTab === 'final_coins_studio'
                      ? 'bg-amber-600 text-white'
                      : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5 fill-current" />
                  <span>Mint Final Coin ({userCreatedFinalCoins.length}/5)</span>
                </button>

                {!sovereignOnly && (
                  <button
                    type="button"
                    onClick={() => setShowTransferModal(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Transfer</span>
                  </button>
                )}
              </>
            )}

            {!hideSovereignTools && (
              <>
                <div className="w-px h-6 bg-slate-200 mx-1 shrink-0" />

                <button
                  type="button"
                  onClick={() => setActiveMainTab('swap')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0 ${
                    activeMainTab === 'swap'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
                  }`}
                >
                  <ArrowRightLeft className="w-3.5 h-3.5" />
                  <span>Swap Assets</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* VIEW 1: MY WALLET HOLDINGS (FINAL COINS, STABLECOINS & CRYPTOCURRENCIES)  */}
      {/* ========================================================================= */}
      {activeMainTab === 'my_holdings' && (
        <div className="space-y-6">
          {/* Holdings Cards List */}
          <div className="space-y-3">
            
            {/* 0. FINAL COINS LIST */}
            {!hideSovereignTools && (holdingsCategoryFilter === 'all' || holdingsCategoryFilter === 'final') && finalCoinsHoldings.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-600 fill-current" /> 
                  Sovereign Final Coins (L1)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {finalCoinsHoldings.map((fc) => {
                    return (
                      <div key={fc.symbol} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between group">
                        <div className="space-y-3 pb-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center font-bold text-white shadow-xs">
                                {fc.symbol[0]}
                              </div>
                              <div>
                                <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                                  {fc.name}
                                </h4>
                                <span className="text-[10px] text-slate-500 font-mono block">
                                  {fc.contractAddress || 'Native Treasury'}
                                </span>
                              </div>
                            </div>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                              {fc.network || 'Final Protocol L1'}
                            </span>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="flex items-baseline justify-between">
                              <span className="text-[11px] text-slate-500">Balance:</span>
                              <span className="font-mono font-extrabold text-amber-700 text-sm">
                                {fc.balance.toLocaleString()} {fc.symbol}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100 flex-wrap">
                          {renderSwapButton({ symbol: fc.symbol, name: fc.name, balance: fc.balance, category: 'final' })}
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedCoinForTransfer(fc.symbol);
                              setShowTransferModal(true);
                            }}
                            className="py-1.5 px-2 rounded-lg bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <Send className="w-3 h-3" />
                            <span>Transfer</span>
                          </button>
                          {allCustomCoins.find(c => c.symbol === fc.symbol) && (
                            <button
                              type="button"
                              onClick={() => setSelectedFinalCoinForDetails(allCustomCoins.find(c => c.symbol === fc.symbol) || null)}
                              className="py-1.5 px-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <Eye className="w-3 h-3" />
                              <span>Details</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 1. STABLECOINS LIST */}
            {!sovereignOnly && (holdingsCategoryFilter === 'all' || holdingsCategoryFilter === 'stable') && stableCoinsHoldings.length > 0 && (
              <div className="space-y-2 pt-2">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Stablecoins &amp; Reserves
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {stableCoinsHoldings.map((sc) => {
                    const totalUSD = sc.balance * (sc.unitPriceUSD || 1);
                    return (
                      <div key={sc.symbol} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
                        <div className="space-y-3 pb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs border border-emerald-200">
                              {sc.symbol}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-900">{sc.name}</h4>
                              <span className="text-[10px] text-slate-500 font-mono block">
                                {sc.network || 'Cross-chain'}
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex items-baseline justify-between border-b border-slate-50 pb-2">
                            <span className="text-[11px] text-slate-500">Balance:</span>
                            <span className="font-mono font-extrabold text-slate-900 text-sm">
                              {(sc.balance || 0).toLocaleString()} {sc.symbol}
                            </span>
                          </div>
                          <div className="flex items-baseline justify-between text-[11px]">
                            <span className="text-slate-500">USD Valuation:</span>
                            <span className="font-mono font-bold text-emerald-700">
                              ${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100 flex-wrap">
                          {renderSwapButton({ symbol: sc.symbol, name: sc.name, balance: sc.balance, category: 'stable' })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 2. CRYPTOCURRENCIES LIST */}
            {!sovereignOnly && (holdingsCategoryFilter === 'all' || holdingsCategoryFilter === 'crypto') && cryptoHoldings.length > 0 && (
              <div className="space-y-2 pt-2">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Coins className="w-4 h-4 text-purple-600" />
                  Base Cryptocurrencies
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {cryptoHoldings.map((cr) => {
                    const totalUSD = cr.balance * (cr.unitPriceUSD || 1);
                    return (
                      <div key={cr.symbol} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
                        <div className="space-y-3 pb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs shadow-xs border border-slate-700">
                              {cr.symbol}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-900">{cr.name}</h4>
                              <span className="text-[10px] text-slate-500 font-mono block">
                                {cr.network || 'L1 Protocol'}
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex items-baseline justify-between border-b border-slate-50 pb-2">
                            <span className="text-[11px] text-slate-500">Balance:</span>
                            <span className="font-mono font-extrabold text-slate-900 text-sm">
                              {cr.symbol} {(cr.balance || 0).toLocaleString()}
                            </span>
                          </div>
                          <div className="flex items-baseline justify-between text-[11px]">
                            <span className="text-slate-500">USD Valuation:</span>
                            <span className="font-mono font-bold text-purple-900">
                              ${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100 flex-wrap">
                          {renderSwapButton({ symbol: cr.symbol, name: cr.name, balance: cr.balance, category: 'crypto' })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 3. SOVEREIGN FIAT LIST */}
            {!sovereignOnly && (holdingsCategoryFilter === 'all' || holdingsCategoryFilter === 'fiat') && fiatHoldings.length > 0 && (
              <div className="space-y-2 pt-2">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-indigo-600" />
                  Sovereign Fiat Accounts
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {fiatHoldings.map((fi) => {
                    const totalUSD = fi.balance * 1;
                    return (
                      <div key={fi.code} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
                        <div className="space-y-3 pb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-xs border border-indigo-200">
                              {fi.code}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-900">{fi.name}</h4>
                              <span className="text-[10px] text-slate-500 font-mono block">
                                {fi.accountType || 'Treasury'}
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex items-baseline justify-between border-b border-slate-50 pb-2">
                            <span className="text-[11px] text-slate-500">Balance:</span>
                            <span className="font-mono font-extrabold text-slate-900 text-sm">
                              {fi.symbol} {(fi.balance || 0).toLocaleString()} {fi.code}
                            </span>
                          </div>
                          <div className="flex items-baseline justify-between text-[11px]">
                            <span className="text-slate-500">USD Valuation:</span>
                            <span className="font-mono font-bold text-indigo-900">
                              ${totalUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100 flex-wrap">
                          {renderSwapButton({ symbol: fi.code, name: fi.name, balance: fi.balance, category: 'fiat' })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW 2: FINAL COIN MINT STUDIO (MAX 5 CREATED, 1 DEPLOYING AT A TIME)    */}
      {/* ========================================================================= */}
      {activeMainTab === 'final_coins_studio' && (
        <FinalCoinMintStudio
          currentUser={currentUser}
          onOpenExchange={() => setActiveMainTab('swap')}
          onOpenHoldings={() => setActiveMainTab('my_holdings')}
        />
      )}

      {/* ========================================================================= */}
      {/* VIEW 3: ASSET SWAP STUDIO                                                */}
      {/* ========================================================================= */}
      {activeMainTab === 'swap' && (
        <CoinExchangeTab currentUser={currentUser} sovereignOnly={sovereignOnly} />
      )}

      {/* ========================================================================= */}
      {/* FINAL COIN DETAILS MODAL                                                */}
      {/* ========================================================================= */}
      {selectedFinalCoinForDetails && (
        <FinalCoinDetailsModal isOpen={true}
          coin={selectedFinalCoinForDetails}
          onClose={() => setSelectedFinalCoinForDetails(null)}
          currentUser={currentUser}
        />
      )}

      {/* FINAL COIN TRANSFER MODAL */}
      {showTransferModal && (
        <FinalCoinTransferModal
          userId={userId}
          userName={userName}
          finalCoinsHoldings={finalCoinsHoldings}
          initialCoinSymbol={selectedCoinForTransfer}
          onClose={() => {
            setShowTransferModal(false);
            setSelectedCoinForTransfer(null);
          }}
          onTransferComplete={() => {
            // refresh data if needed, but standard state update should handle it
          }}
        />
      )}
    </div>
  );
};
