import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  X, 
  Sparkles, 
  ArrowRight, 
  Coins, 
  User, 
  ChevronRight
} from 'lucide-react';
import { SEARCHABLE_PRODUCTS, SearchableProduct } from '../data/searchCatalog';
import { UserPublicProfile } from '../types/social';
import { getAllUsers } from '../services/socialService';

interface UniversalSearchBarProps {
  currentUserId?: string;
  onSelectProduct: (product: SearchableProduct) => void;
  onSelectUser: (userIdOrHandle: string) => void;
  onSelectStock?: (stock: any) => void;
  onQuickBuyStock?: (stock: any) => void;
  onOpenFullSearch?: (query: string) => void;
  placeholder?: string;
}

export const UniversalSearchBar: React.FC<UniversalSearchBarProps> = ({
  currentUserId,
  onSelectProduct,
  onSelectUser,
  onOpenFullSearch,
  placeholder = 'Search vaults, reserve assets, products, or @members...',
}) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'products' | 'members'>('all');
  const [allUsers, setAllUsers] = useState<UserPublicProfile[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  // Load public users for autocomplete
  useEffect(() => {
    getAllUsers(currentUserId || '').then(setAllUsers).catch(console.error);
  }, [currentUserId]);

  // Click outside and Escape key listener to dismiss dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('keydown', handleGlobalKeyDown);
    };
  }, []);

  const handleTriggerFullSearch = (searchQueryToSubmit?: string) => {
    const finalQuery = searchQueryToSubmit !== undefined ? searchQueryToSubmit : query;
    if (onOpenFullSearch) {
      onOpenFullSearch(finalQuery.trim());
      setIsOpen(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleTriggerFullSearch();
    }
  };

  const cleanQuery = query.trim().toLowerCase();

  // Matched products
  const matchedProducts = cleanQuery
    ? SEARCHABLE_PRODUCTS.filter((p) => {
        const q = cleanQuery.replace(/^#/, '');
        return (
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
        );
      })
    : [];

  // Matched members
  const matchedUsers = cleanQuery
    ? allUsers.filter((u) => {
        const q = cleanQuery.replace(/^@/, '');
        return (
          u.name.toLowerCase().includes(q) ||
          u.userId.toLowerCase().includes(q) ||
          (u.bio && u.bio.toLowerCase().includes(q))
        );
      })
    : [];

  const totalResults = matchedProducts.length + matchedUsers.length;
  const hasResults = totalResults > 0;

  const showProducts = (activeFilter === 'all' || activeFilter === 'products') && matchedProducts.length > 0;
  const showUsers = (activeFilter === 'all' || activeFilter === 'members') && matchedUsers.length > 0;

  return (
    <div ref={containerRef} className="relative w-full max-w-md">
      {/* Input container */}
      <div className="relative flex items-center">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
        <input
          id="universal-search-input"
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full min-h-[38px] pl-9 pr-8 py-1.5 rounded-full bg-slate-100/90 border border-slate-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-slate-900 focus:border-slate-900 transition-all shadow-2xs"
        />

        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setIsOpen(false);
            }}
            className="absolute right-2.5 text-slate-400 hover:text-slate-900 p-1 cursor-pointer"
            aria-label="Clear search"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Autocomplete Suggestions Dropdown */}
      {isOpen && query.trim() && (
        <div
          id="universal-search-dropdown"
          className="absolute left-0 -right-4 sm:right-auto sm:w-[540px] top-full mt-2 bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden z-50 max-h-[32rem] flex flex-col text-left animate-in fade-in zoom-in-95 duration-150"
        >
          {/* Quick Filter Header Chips */}
          {hasResults && (
            <div className="px-4 pt-3 pb-2 border-b border-slate-100 bg-slate-50/90 flex items-center gap-1.5 overflow-x-auto text-[11px]">
              <button
                type="button"
                onClick={() => setActiveFilter('all')}
                className={`px-3 py-1 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
                  activeFilter === 'all'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                All Results ({totalResults})
              </button>
              {matchedProducts.length > 0 && (
                <button
                  type="button"
                  onClick={() => setActiveFilter('products')}
                  className={`px-3 py-1 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                    activeFilter === 'products'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>Assets ({matchedProducts.length})</span>
                </button>
              )}
              {matchedUsers.length > 0 && (
                <button
                  type="button"
                  onClick={() => setActiveFilter('members')}
                  className={`px-3 py-1 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                    activeFilter === 'members'
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  <span>Members ({matchedUsers.length})</span>
                </button>
              )}
            </div>
          )}

          {/* Results Scroll Area */}
          <div className="overflow-y-auto flex-1 divide-y divide-slate-100">
            {!hasResults ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                <Search className="w-8 h-8 mx-auto mb-2.5 text-slate-300 stroke-[1.5]" />
                <p className="font-semibold text-slate-800 text-sm">No exact matches found</p>
                <p className="mt-1 text-xs text-slate-400">
                  Try searching with a different keyword, category, or @member handle.
                </p>
              </div>
            ) : (
              <>
                {/* Products Section */}
                {showProducts && (
                  <div className="py-2">
                    <div className="px-3.5 py-1.5 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold bg-slate-50/50">
                      Reserve Assets &amp; Services ({matchedProducts.length})
                    </div>
                    {matchedProducts.map((prod) => (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => {
                          onSelectProduct(prod);
                          setIsOpen(false);
                          setQuery('');
                        }}
                        className="w-full px-3.5 py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 transition-colors text-left cursor-pointer group"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700 shrink-0 group-hover:bg-slate-900 group-hover:text-white transition-colors">
                            <Coins className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-900 truncate group-hover:underline">
                              {prod.name}
                            </p>
                            <p className="text-[10px] text-slate-400 font-mono truncate">
                              {prod.category} • {prod.price}
                            </p>
                          </div>
                        </div>

                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 font-mono text-slate-700 shrink-0">
                          {prod.badge || 'DETAILS'}
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {/* Members Section */}
                {showUsers && (
                  <div className="py-2">
                    <div className="px-3.5 py-1.5 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold bg-slate-50/50">
                      Ecosystem Members ({matchedUsers.length})
                    </div>
                    {matchedUsers.map((user) => (
                      <button
                        key={user.uid}
                        type="button"
                        onClick={() => {
                          onSelectUser(user.userId);
                          setIsOpen(false);
                          setQuery('');
                        }}
                        className="w-full px-3.5 py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 transition-colors text-left cursor-pointer group"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {user.avatarUrl ? (
                            <img
                              src={user.avatarUrl}
                              alt={user.name}
                              className="w-7 h-7 rounded-full object-cover shrink-0"
                            />
                          ) : (
                            <div className="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-serif shrink-0">
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-900 truncate group-hover:underline">
                              {user.name}
                            </p>
                            <p className="text-[10px] text-slate-400 font-mono truncate">
                              @{user.userId}
                            </p>
                          </div>
                        </div>

                        <span className="text-[10px] text-slate-400 group-hover:text-slate-900 font-mono">
                          View Profile &rarr;
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>

          {/* View all on dedicated results page footer button */}
          <div className="p-2.5 bg-slate-50 border-t border-slate-100">
            <button
              type="button"
              onClick={() => handleTriggerFullSearch()}
              className="w-full py-2 px-3 rounded-2xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Open Full Results for "{query}"</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
