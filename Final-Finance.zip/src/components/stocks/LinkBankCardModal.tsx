import React, { useState } from 'react';
import {
  Building2,
  CreditCard,
  Wallet,
  X,
  ShieldCheck,
  Lock,
  AlertCircle,
  Zap,
  Globe,
  Loader2,
} from 'lucide-react';
import { LinkedBankAccountItem, LinkedCryptoWalletItem } from '../../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../../data/defaultWallets';
import { getStripeConfigSafe, linkBankAccountViaStripe } from '../../services/stripeClientService';
import { verifyWalletAddressOnChain } from '../../services/privyClientService';
import {
  validatePaymentCardInput,
  validateUsBankAccountInput,
} from '../../utils/paymentValidation';
import { emitPaymentMethodsUpdated } from '../../utils/paymentMethodsBridge';

interface LinkBankCardModalProps {
  userId: string;
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'bank' | 'card' | 'crypto';
  lockTab?: boolean;
  onSuccess: (type: 'bank' | 'card' | 'crypto', label: string) => void;
}

const MAJOR_BANK_ROUTINGS: Record<string, string> = {
  'Bank of America': '026009593',
  'JPMorgan Chase & Co.': '021000021',
  'Wells Fargo Bank N.A.': '121000248',
  Citibank: '021000089',
  'Capital One': '051405515',
  'U.S. Bank': '091000022',
  'PNC Bank': '043000096',
  'TD Bank': '031101266',
};

export const LinkBankCardModal: React.FC<LinkBankCardModalProps> = ({
  userId,
  isOpen,
  onClose,
  initialTab = 'bank',
  lockTab = false,
  onSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<'bank' | 'card' | 'crypto'>(initialTab);

  // Bank Form State
  const [bankName, setBankName] = useState('Bank of America');
  const [accountType, setAccountType] = useState<'Checking' | 'Savings'>('Checking');
  const [routingNumber, setRoutingNumber] = useState('026009593');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountHolder, setAccountHolder] = useState('');

  // Extensive Card Form State
  const [cardEmail, setCardEmail] = useState('');
  const [cardPhone, setCardPhone] = useState('');
  const [cardholderName, setCardholderName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('');
  const [expiryYear, setExpiryYear] = useState('');
  const [cvv, setCvv] = useState('');
  const [cardType, setCardType] = useState<'debit' | 'credit'>('debit');
  const [country, setCountry] = useState('US');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');

  // Crypto Form State
  const [walletType, setWalletType] = useState<'metamask' | 'coinbase' | 'walletconnect' | 'custom'>('metamask');
  const [walletNetwork, setWalletNetwork] = useState<'Ethereum' | 'Polygon' | 'Base' | 'Arbitrum'>('Ethereum');
  const [cryptoAddress, setCryptoAddress] = useState('');
  const [ensOrDomain, setEnsOrDomain] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  React.useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isSubmitting) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isSubmitting, onClose]);

  React.useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
      setErrorMsg('');
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const handleLinkBank = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const bankCheck = validateUsBankAccountInput({
      accountHolderName: accountHolder,
      routingNumber,
      accountNumber,
      accountType: accountType.toLowerCase(),
    });
    if (!bankCheck.valid) {
      setErrorMsg(bankCheck.error);
      return;
    }

    setIsSubmitting(true);
    try {
      const cfg = await getStripeConfigSafe();
      if (!cfg.reachable || !cfg.configured) {
        setErrorMsg(
          'Routing checksum passed, but verifying that this bank account actually exists requires STRIPE_SECRET_KEY on the server. Unverified bank accounts cannot be saved.'
        );
        return;
      }

      const res = await linkBankAccountViaStripe(
        { id: userId, uid: userId, email: undefined, name: accountHolder.trim() },
        {
          bankName,
          accountHolderName: accountHolder.trim(),
          accountType: accountType.toLowerCase() as 'checking' | 'savings',
          routingNumber: bankCheck.routingNumber,
          accountNumber: bankCheck.accountNumber,
        }
      );

      if (res.pendingVerification) {
        setErrorMsg(
          'Bank requires micro-deposit verification before it can be saved. Please complete verification under Settings → Banks, Cards & Crypto.'
        );
        return;
      }

      const walletData = getStoredUserWallets(userId);
      const newBank: LinkedBankAccountItem = {
        id: res.paymentMethodId || `bank-${Date.now()}`,
        accountHolderName: accountHolder.trim(),
        bankName,
        accountType: accountType as any,
        routingNumberMasked: `••••${bankCheck.routingNumber.slice(-4)}`,
        accountNumberLast4: bankCheck.last4,
        currency: 'USD',
        country: 'United States',
        isDefault: (walletData.linkedBankAccounts?.length || 0) === 0,
        status: 'Verified',
        addedAt: new Date().toISOString(),
      };
      walletData.linkedBankAccounts = [newBank, ...(walletData.linkedBankAccounts || [])];
      saveStoredUserWallets(userId, walletData);

      onSuccess('bank', `${bankName} (••••${bankCheck.last4})`);
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Bank account could not be verified and was not saved.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLinkCard = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cardCheck = validatePaymentCardInput({
      cardholderName,
      email: cardEmail,
      phone: cardPhone,
      cardNumber,
      expMonth: expiryMonth,
      expYear: expiryYear,
      cvc: cvv,
      country,
      addressLine1,
      addressLine2,
      city,
      state,
      postalCode,
    });
    if (!cardCheck.valid) {
      setErrorMsg(cardCheck.error);
      return;
    }

    setErrorMsg(
      'Card format & billing details passed checks, but verifying with Visa/Mastercard that this card account exists requires STRIPE_SECRET_KEY and STRIPE_PUBLISHABLE_KEY on the server. Unverified cards cannot be saved.'
    );
  };

  const handleLinkCrypto = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const addr = cryptoAddress.trim();
    if (!/^0x[a-fA-F0-9]{40}$/.test(addr)) {
      setErrorMsg('Enter a valid 0x EVM wallet address (42 characters).');
      return;
    }

    setIsSubmitting(true);
    try {
      const netKey = walletNetwork.toLowerCase() as 'ethereum' | 'polygon' | 'base' | 'arbitrum';
      const verified = await verifyWalletAddressOnChain({
        address: addr,
        network: netKey,
      });

      const walletData = getStoredUserWallets(userId);
      const walletNames: Record<string, string> = {
        metamask: 'MetaMask Wallet',
        coinbase: 'Coinbase Wallet',
        walletconnect: 'WalletConnect Wallet',
        custom: `${walletNetwork} Verified Wallet`,
      };

      const newCrypto: LinkedCryptoWalletItem = {
        id: `cw-${Date.now()}`,
        walletName: walletNames[walletType] || 'Verified Crypto Wallet',
        walletType: walletType as any,
        address: verified.address,
        network: walletNetwork,
        isPrimary: (walletData.linkedCryptoWallets?.length || 0) === 0,
        connectedAt: new Date().toISOString(),
        balanceUSD: 0,
        ensOrDomain: ensOrDomain.trim() || undefined,
      };

      walletData.linkedCryptoWallets = [newCrypto, ...(walletData.linkedCryptoWallets || [])];
      saveStoredUserWallets(userId, walletData);
      emitPaymentMethodsUpdated();

      onSuccess('crypto', `${newCrypto.walletName} (${newCrypto.network})`);
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Wallet address could not be verified on-chain and was not saved.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg rounded-3xl bg-white border border-slate-200 shadow-2xl p-6 sm:p-7 overflow-y-auto max-h-[92vh] my-auto"
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer z-10"
          title="Close (Esc)"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center pb-4 border-b border-slate-100">
          <h3 className="text-lg sm:text-xl font-serif font-bold text-slate-900">
            {lockTab
              ? activeTab === 'bank'
                ? 'Link Bank Account'
                : activeTab === 'card'
                ? 'Link Payment Card'
                : 'Link Crypto Wallet'
              : 'Link Verified Account or Wallet'}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Only verified accounts and wallets can be saved and used.
          </p>
        </div>

        {!lockTab && (
          <div className="grid grid-cols-3 gap-1 p-1 rounded-2xl bg-slate-100 border border-slate-200 mt-4">
            <button
              type="button"
              onClick={() => {
                setActiveTab('bank');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeTab === 'bank'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="truncate">Bank</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('card');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeTab === 'card'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5 text-purple-600 shrink-0" />
              <span className="truncate">Card</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('crypto');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                activeTab === 'crypto'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Wallet className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span className="truncate">Crypto</span>
            </button>
          </div>
        )}

        {errorMsg && (
          <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center justify-center gap-2 text-center">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {activeTab === 'bank' && (
          <form onSubmit={handleLinkBank} className="mt-4 space-y-3 text-center">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Select Financial Institution *
              </label>
              <select
                value={bankName}
                onChange={(e) => {
                  const name = e.target.value;
                  setBankName(name);
                  if (MAJOR_BANK_ROUTINGS[name]) {
                    setRoutingNumber(MAJOR_BANK_ROUTINGS[name]);
                  }
                }}
                className="w-full h-10 px-3 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
              >
                {Object.keys(MAJOR_BANK_ROUTINGS).map((name) => (
                  <option key={name} value={name}>
                    {name}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Account Holder Legal Name *
                </label>
                <input
                  type="text"
                  value={accountHolder}
                  onChange={(e) => setAccountHolder(e.target.value)}
                  className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                  placeholder="First & Last Name"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Account Type *
                </label>
                <select
                  value={accountType}
                  onChange={(e) => setAccountType(e.target.value as 'Checking' | 'Savings')}
                  className="w-full h-10 px-3 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                >
                  <option value="Checking">Checking</option>
                  <option value="Savings">Savings</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                ABA Routing Number (9 Digits) *
              </label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={9}
                value={routingNumber}
                onChange={(e) => setRoutingNumber(e.target.value.replace(/\D/g, ''))}
                className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                placeholder="026009593"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Account Number (6–17 Digits) *
              </label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={17}
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ''))}
                className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                placeholder="Enter bank account number"
                required
              />
            </div>

            <div className="p-2.5 rounded-xl bg-blue-50/70 border border-blue-100 text-[11px] text-blue-900 flex items-center justify-center gap-2 text-center">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
              <span>Routing checksum and bank verification are required before saving.</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm mt-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Bank Account...</span>
                </>
              ) : (
                <>
                  <Building2 className="w-4 h-4" />
                  <span>Verify &amp; Link Bank Account</span>
                </>
              )}
            </button>
          </form>
        )}

        {activeTab === 'card' && (
          <form onSubmit={handleLinkCard} className="mt-4 space-y-2.5 text-center">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={cardEmail}
                  onChange={(e) => setCardEmail(e.target.value)}
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs text-slate-800 bg-slate-50/50"
                  placeholder="you@example.com"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={cardPhone}
                  onChange={(e) => setCardPhone(e.target.value)}
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs text-slate-800 bg-slate-50/50"
                  placeholder="(555) 234-5678"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                Full Legal Name on Card *
              </label>
              <input
                type="text"
                value={cardholderName}
                onChange={(e) => setCardholderName(e.target.value)}
                className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs uppercase font-semibold text-slate-800 bg-slate-50/50"
                placeholder="FIRST AND LAST NAME"
                required
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                Card Number *
              </label>
              <input
                type="text"
                inputMode="numeric"
                value={cardNumber}
                onChange={(e) => {
                  const digits = e.target.value.replace(/\D/g, '').slice(0, 19);
                  setCardNumber(digits.replace(/(\d{4})(?=\d)/g, '$1 '));
                }}
                className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                placeholder="1234 5678 9012 3456"
                maxLength={23}
                required
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Card Type *
                </label>
                <select
                  value={cardType}
                  onChange={(e) => setCardType(e.target.value as 'debit' | 'credit')}
                  className="w-full h-9 px-2 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                >
                  <option value="debit">Debit</option>
                  <option value="credit">Credit</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Expiry (MM/YY) *
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    inputMode="numeric"
                    value={expiryMonth}
                    onChange={(e) => setExpiryMonth(e.target.value.replace(/\D/g, ''))}
                    className="w-full h-9 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                    placeholder="MM"
                    maxLength={2}
                    required
                  />
                  <span>/</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={expiryYear}
                    onChange={(e) => setExpiryYear(e.target.value.replace(/\D/g, ''))}
                    className="w-full h-9 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                    placeholder="YY"
                    maxLength={2}
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  CVC *
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                  className="w-full h-9 px-2 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                  placeholder="•••"
                  maxLength={4}
                  required
                />
              </div>
            </div>

            <div className="pt-1 border-t border-slate-100 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Country *
                  </label>
                  <select
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full h-9 px-2.5 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
                  >
                    <option value="US">United States</option>
                    <option value="CA">Canada</option>
                    <option value="GB">United Kingdom</option>
                    <option value="AU">Australia</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    ZIP / Postal *
                  </label>
                  <input
                    type="text"
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full h-9 px-2.5 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                    placeholder="10001"
                    required
                  />
                </div>
              </div>
              <input
                type="text"
                value={addressLine1}
                onChange={(e) => setAddressLine1(e.target.value)}
                className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs text-slate-800 bg-slate-50/50"
                placeholder="Street Address *"
                required
              />
              <input
                type="text"
                value={addressLine2}
                onChange={(e) => setAddressLine2(e.target.value)}
                className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs text-slate-800 bg-slate-50/50"
                placeholder="Apt, Suite, Unit (Optional)"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs text-slate-800 bg-slate-50/50"
                  placeholder="City *"
                  required
                />
                <input
                  type="text"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full h-9 px-3 text-center rounded-xl border border-slate-200 text-xs text-slate-800 bg-slate-50/50"
                  placeholder="State / Province *"
                  required
                />
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-purple-50/70 border border-purple-100 text-[11px] text-purple-900 flex items-center justify-center gap-2 text-center">
              <Lock className="w-4 h-4 text-purple-600 shrink-0" />
              <span>Cards are only saved after full checksum, billing, and issuer verification.</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm mt-2"
            >
              <CreditCard className="w-4 h-4" />
              <span>Verify &amp; Link Card</span>
            </button>
          </form>
        )}

        {activeTab === 'crypto' && (
          <form onSubmit={handleLinkCrypto} className="mt-4 space-y-3 text-center">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Wallet Provider
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'metamask', label: 'MetaMask' },
                  { id: 'coinbase', label: 'Coinbase Wallet' },
                  { id: 'walletconnect', label: 'WalletConnect' },
                  { id: 'custom', label: 'Verified 0x Address' },
                ].map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => setWalletType(w.id as any)}
                    className={`p-2 rounded-xl border text-xs font-bold text-center transition-all cursor-pointer ${
                      walletType === w.id
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-2xs'
                        : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                    }`}
                  >
                    {w.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Blockchain Network
              </label>
              <select
                value={walletNetwork}
                onChange={(e) => setWalletNetwork(e.target.value as any)}
                className="w-full h-10 px-3 text-center [text-align-last:center] rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50/50"
              >
                <option value="Ethereum">Ethereum Mainnet</option>
                <option value="Base">Base Mainnet</option>
                <option value="Polygon">Polygon PoS</option>
                <option value="Arbitrum">Arbitrum One</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Public Wallet Address (0x...) *
              </label>
              <input
                type="text"
                required
                value={cryptoAddress}
                onChange={(e) => setCryptoAddress(e.target.value)}
                className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                placeholder="0x..."
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                ENS Handle (Optional)
              </label>
              <input
                type="text"
                value={ensOrDomain}
                onChange={(e) => setEnsOrDomain(e.target.value)}
                className="w-full h-10 px-3 text-center rounded-xl border border-slate-200 text-xs font-mono text-slate-800 bg-slate-50/50"
                placeholder="name.eth"
              />
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-100 text-[11px] text-emerald-900 flex items-center justify-center gap-2 text-center">
              <Globe className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Address is verified on-chain on Mainnet before it can be saved.</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm mt-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying On-Chain...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-emerald-400" />
                  <span>Verify &amp; Link Crypto Wallet</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
