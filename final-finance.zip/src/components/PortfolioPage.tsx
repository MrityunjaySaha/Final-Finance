import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, 
  Briefcase, 
  Check, 
  ExternalLink, 
  Zap, 
  ShieldCheck, 
  Coins, 
  Building2, 
  Building, 
  User, 
  Globe,
  Star,
  Layers,
  Sparkles,
  Users,
  ArrowRight
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { StockItem, StockOrder, StockPosition, StockMarketWay, IPORequest } from '../types/stocks';
import { 
  INITIAL_STOCKS, 
  INITIAL_USER_STOCK_POSITIONS, 
  STOCK_MARKET_WAYS, 
  getStoredIPORequests, 
  IPO_UPDATED_EVENT,
  getAllActiveMarketStocks 
} from '../data/stocksData';
import { 
  getStoredStockPositions, 
  saveStoredStockPositions, 
  getStoredStockOrders, 
  saveStoredStockOrders,
  getStoredWatchlist,
  toggleStoredWatchlist,
  WATCHLIST_UPDATED_EVENT,
  matchStockSearch,
  categorizeStockHolding
} from '../utils/stockWalletBridge';
import { QuickBuyStockModal } from './stocks/QuickBuyStockModal';
import { TradeConfirmationModal } from './stocks/TradeConfirmationModal';
import { ReleaseIPOModal } from './stocks/ReleaseIPOModal';
import { DelistIPOModal } from './stocks/DelistIPOModal';
import { PurchasedEquityHoldingsView } from './portfolio/PurchasedEquityHoldingsView';
import { DerivativesPortfolioTab } from './portfolio/DerivativesPortfolioTab';
import { AlpacaPortfolioView } from './portfolio/AlpacaPortfolioView';

export type PortfolioPrimaryTab = 'overview' | 'holdings' | 'portfolio' | 'derivatives' | 'alpaca';

interface PortfolioPageProps {
  currentUser?: AuthSession | null;
  onSelectStock?: (stock: StockItem) => void;
  onOpenStockMarket?: (marketWay?: StockMarketWay | 'all') => void;
  initialPrimaryTab?: PortfolioPrimaryTab;
  initialTab?: 'invested' | 'owned' | 'following' | 'social_trades' | 'coin_launchpad' | 'my_ipos' | 'currencies';
  initialMarketFilter?: StockMarketWay | null;
  onNavigateBack?: () => void;
}

export const PortfolioPage: React.FC<PortfolioPageProps> = ({
  currentUser,
  onSelectStock,
  onOpenStockMarket,
  initialPrimaryTab,
  initialTab = 'owned',
  initialMarketFilter = null,
  onNavigateBack,
}) => {
  const userId = currentUser?.id || 'guest';

  // Primary 4-Tab Split: 'overview' (Portfolio Summary) vs 'portfolio' (Stocks) vs 'holdings' (Equity) vs 'derivatives'
  const [primaryTab, setPrimaryTab] = useState<PortfolioPrimaryTab>(() => {
    if (initialPrimaryTab) return initialPrimaryTab;
    if (initialTab === 'following' || initialTab === 'social_trades' || initialTab === 'coin_launchpad' || initialTab === 'my_ipos') {
      return 'portfolio';
    }
    return 'overview';
  });

  useEffect(() => {
    if (initialPrimaryTab) {
      setPrimaryTab(initialPrimaryTab);
    }
  }, [initialPrimaryTab]);

  // Sub-tabs within Equities & Stock Portfolio: 'owned' | 'following' | 'social_trades' | 'coin_launchpad' | 'my_ipos' | 'currencies'
  const [activeTab, setActiveTab] = useState<'owned' | 'following' | 'social_trades' | 'coin_launchpad' | 'my_ipos' | 'currencies'>(() => {
    if (initialTab === 'invested' || initialTab === 'owned') return 'owned';
    if (initialTab) return initialTab as any;
    return 'owned';
  });

  // 4 Coin Stock Market Filter: Strictly 'final' for Equity, others for general browsing
  const [selectedMarketFilter, setSelectedMarketFilter] = useState<StockMarketWay | null>(initialMarketFilter || 'final');

  // Asset category filter for holdings: 'all' | 'business' | 'personal'
  const [assetCategoryFilter, setAssetCategoryFilter] = useState<'all' | 'business' | 'personal'>('all');

  // Search Filter Query
  const [searchQuery, setSearchQuery] = useState('');

  // IPO Requests and Modals
  const [ipos, setIpos] = useState<IPORequest[]>(() => getStoredIPORequests());
  const [isReleaseIPOModalOpen, setIsReleaseIPOModalOpen] = useState(false);
  const [delistingIPO, setDelistingIPO] = useState<IPORequest | null>(null);

  // Stocks Master Data, User Positions & Orders
  const [stocks, setStocks] = useState<StockItem[]>(() => getAllActiveMarketStocks());
  const [positions, setPositions] = useState<StockPosition[]>(() =>
    getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS)
  );
  const [orders, setOrders] = useState<StockOrder[]>(() =>
    getStoredStockOrders(userId)
  );

  // Followed / Watchlist Tickers
  const [watchlist, setWatchlist] = useState<string[]>(() =>
    getStoredWatchlist(userId)
  );

  // Quick Trade Modal State (Buy / Sell)
  const [quickTradeStock, setQuickTradeStock] = useState<StockItem | null>(null);
  const [quickTradeSide, setQuickTradeSide] = useState<'buy' | 'sell'>('buy');
  const [isTradeConfirmationOpen, setIsTradeConfirmationOpen] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<StockOrder | null>(null);
  const [toastMessage, setToastMessage] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 4000);
  };

  // Sync positions, orders & watchlist with localStorage when user changes
  useEffect(() => {
    setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
    setOrders(getStoredStockOrders(userId));
    setWatchlist(getStoredWatchlist(userId));
  }, [userId]);

  // Listen to external watchlist updates across tabs/components
  useEffect(() => {
    const handleWatchlistUpdate = () => {
      setWatchlist(getStoredWatchlist(userId));
    };

    window.addEventListener(WATCHLIST_UPDATED_EVENT, handleWatchlistUpdate);
    window.addEventListener('storage', handleWatchlistUpdate);
    return () => {
      window.removeEventListener(WATCHLIST_UPDATED_EVENT, handleWatchlistUpdate);
      window.removeEventListener('storage', handleWatchlistUpdate);
    };
  }, [userId]);

  // Listen to IPO status updates & dynamic coin IPO additions
  useEffect(() => {
    const handleIPOUpdate = () => {
      const updatedIPOs = getStoredIPORequests();
      setIpos(updatedIPOs);
      setStocks(getAllActiveMarketStocks());
    };

    window.addEventListener(IPO_UPDATED_EVENT, handleIPOUpdate);
    return () => window.removeEventListener(IPO_UPDATED_EVENT, handleIPOUpdate);
  }, []);

  // Listen to stock positions & orders updates across tabs/components
  useEffect(() => {
    const handlePositionsUpdate = () => {
      setPositions(getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS));
      setOrders(getStoredStockOrders(userId));
    };

    window.addEventListener('final_finance_stock_positions_updated', handlePositionsUpdate);
    return () => window.removeEventListener('final_finance_stock_positions_updated', handlePositionsUpdate);
  }, [userId]);

  // Save watchlist to localStorage & broadcast event
  const handleToggleWatchlist = (ticker: string) => {
    const next = toggleStoredWatchlist(userId, ticker);
    setWatchlist(next);
  };

  // Stock price lookup map
  const stockMap = useMemo(() => {
    const map = new Map<string, StockItem>();
    stocks.forEach((s) => map.set(s.ticker, s));
    return map;
  }, [stocks]);

  // Enriched Positions with Market Way & Asset Category (Categorized strictly into spot vs personal/business equity)
  const enrichedPositions = useMemo(() => {
    return positions.map((pos) => {
      const s = stockMap.get(pos.ticker);
      const currentPriceUSD = s ? s.price : pos.currentPriceUSD;
      const totalValueUSD = pos.shares * currentPriceUSD;
      const totalCostUSD = pos.shares * pos.avgCostUSD;
      const totalGainUSD = totalValueUSD - totalCostUSD;
      const totalGainPercent = totalCostUSD > 0 ? (totalGainUSD / totalCostUSD) * 100 : 0;

      const sAny = s as any;
      const ipoDetails = sAny?.ipoRefId ? ipos.find(i => i.id === sAny.ipoRefId) : (sAny?.ipoId ? ipos.find(i => i.id === sAny.ipoId) : null);
      const cat = categorizeStockHolding(pos.ticker, s, ipos);

      const isEquity = cat.isEquity;
      const isSpotStock = cat.isSpotStock;
      const assetCategory: 'business' | 'personal' | 'spot' = cat.assetCategory;

      const rawMarket = s?.marketType || pos.marketType;
      const normalizedMarket: StockMarketWay = (rawMarket === 'global' || !rawMarket) 
        ? 'fiat' 
        : (rawMarket as StockMarketWay);

      return {
        ...pos,
        name: s ? s.name : (pos.name || pos.ticker),
        currentPriceUSD,
        totalValueUSD,
        totalGainUSD,
        totalGainPercent,
        sector: s ? s.sector : (pos.sector || 'General'),
        subSector: s?.subSector,
        marketType: normalizedMarket,
        settlementMethod: s?.settlementMethod || pos.settlementMethod || (isSpotStock ? 'USD Brokerage Clearing' : 'Final Coin (AFNL)'),
        assetCategory,
        isSpotStock,
        isEquity,
        issuerName: ipoDetails?.issuerName || sAny?.issuerName,
        issuerHandle: ipoDetails?.issuerHandle || sAny?.issuerHandle,
        issuerAvatar: ipoDetails?.issuerAvatar || sAny?.issuerAvatar,
        ipoDetails
      };
    });
  }, [positions, stockMap, ipos]);

  // 1. Equity Positions (Platform-issued Personal and Business IPOs backed by FINAL COINS ONLY - Regular stocks strictly excluded!)
  const equityPositions = useMemo(() => {
    return enrichedPositions.filter(p => p.isEquity && !p.isSpotStock && p.assetCategory !== 'spot');
  }, [enrichedPositions]);

  // 2. Breakdown by Business vs Personal Equities
  const businessPositions = useMemo(() => {
    return equityPositions.filter(p => p.assetCategory === 'business');
  }, [equityPositions]);

  const personalPositions = useMemo(() => {
    return equityPositions.filter(p => p.assetCategory === 'personal');
  }, [equityPositions]);

  // 3. Regular Stocks (Regular stock positions - Spot stocks strictly excluding Final-backed Equities)
  const regularStockPositions = useMemo(() => {
    return enrichedPositions.filter(p => !p.isEquity && (p.isSpotStock || p.assetCategory === 'spot'));
  }, [enrichedPositions]);

  const regularStockNAV = useMemo(() => regularStockPositions.reduce((s, p) => s + p.totalValueUSD, 0), [regularStockPositions]);
  const regularStockCostBasis = useMemo(() => regularStockPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0), [regularStockPositions]);
  const regularStockGainUSD = regularStockNAV - regularStockCostBasis;
  const regularStockGainPercent = regularStockCostBasis > 0 ? (regularStockGainUSD / regularStockCostBasis) * 100 : 0;

  const businessNAV = useMemo(() => businessPositions.reduce((s, p) => s + p.totalValueUSD, 0), [businessPositions]);
  const businessCostBasis = useMemo(() => businessPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0), [businessPositions]);
  const businessGainUSD = businessNAV - businessCostBasis;
  const businessGainPercent = businessCostBasis > 0 ? (businessGainUSD / businessCostBasis) * 100 : 0;

  const personalNAV = useMemo(() => personalPositions.reduce((s, p) => s + p.totalValueUSD, 0), [personalPositions]);
  const personalCostBasis = useMemo(() => personalPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0), [personalPositions]);
  const personalGainUSD = personalNAV - personalCostBasis;
  const personalGainPercent = personalCostBasis > 0 ? (personalGainUSD / personalCostBasis) * 100 : 0;

  // Equity portfolio totals (Strictly personal & business stocks backed by Final Coins)
  const equityNAV = useMemo(() => equityPositions.reduce((s, p) => s + p.totalValueUSD, 0), [equityPositions]);
  const equityCostBasis = useMemo(() => equityPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0), [equityPositions]);
  const equityGainUSD = equityNAV - equityCostBasis;
  const equityGainPercent = equityCostBasis > 0 ? (equityGainUSD / equityCostBasis) * 100 : 0;

  // Followed stocks list (Favorite Stocks)
  const followedStocks = useMemo(() => {
    return stocks.filter((s) => watchlist.some((t) => t.toUpperCase() === s.ticker.toUpperCase()));
  }, [stocks, watchlist]);

  // Overall Portfolio Totals
  const totalStockPositionsUSD = enrichedPositions.reduce((s, p) => s + p.totalValueUSD, 0);
  const totalStockGainUSD = enrichedPositions.reduce((s, p) => s + p.totalGainUSD, 0);
  const totalStockCostBasisUSD = enrichedPositions.reduce((s, p) => s + (p.shares * p.avgCostUSD), 0);
  const totalStockGainPercent = totalStockCostBasisUSD > 0 
    ? (totalStockGainUSD / totalStockCostBasisUSD) * 100 
    : 0;

  // Filtered Followed Stocks
  const filteredFollowedStocks = useMemo(() => {
    return followedStocks.filter((s) => {
      if (selectedMarketFilter && s.marketType !== selectedMarketFilter) {
        return false;
      }
      return matchStockSearch(s, searchQuery);
    });
  }, [followedStocks, selectedMarketFilter, searchQuery]);

  // Handle Quick Trade Modal Trigger
  const handleOpenTradeModal = (tickerOrStock: string | StockItem, side: 'buy' | 'sell' = 'buy') => {
    const stock = typeof tickerOrStock === 'string'
      ? stockMap.get(tickerOrStock) || {
          ticker: tickerOrStock,
          name: tickerOrStock,
          price: 100,
          changeUSD: 0,
          changePercent: 0,
          marketCap: 'N/A',
          volume: 'N/A',
          sector: 'Equities',
          dayRange: '$100.00 - $100.00',
          marketType: 'final' as StockMarketWay,
          settlementMethod: 'Final Coins ($AFNL)',
        }
      : tickerOrStock;

    setQuickTradeStock(stock as any);
    setQuickTradeSide(side);
  };

  // Callback when order executes in QuickBuyStockModal
  const handleOrderExecuted = (order: StockOrder, updatedPositions?: StockPosition[]) => {
    const finalPositions = updatedPositions || getStoredStockPositions(userId, INITIAL_USER_STOCK_POSITIONS);
    setPositions(finalPositions);
    saveStoredStockPositions(userId, finalPositions);

    const updatedOrders = [order, ...orders];
    setOrders(updatedOrders);
    saveStoredStockOrders(userId, updatedOrders);

    setQuickTradeStock(null);
    setConfirmedOrder(order);
    setIsTradeConfirmationOpen(true);
    showToast(`Order executed: ${order.side.toUpperCase()} ${order.shares} ${order.ticker} for $${order.totalUSD.toLocaleString()}`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200 text-left">
      {onNavigateBack && (
        <button
          onClick={onNavigateBack}
          className="mb-4 flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900 transition-colors"
        >
          <ArrowRight className="w-4 h-4 rotate-180" />
          Back to Dashboard
        </button>
      )}
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-3 bg-slate-900 text-white rounded-2xl shadow-xl flex items-center gap-3 border border-slate-700 text-xs animate-in slide-in-from-bottom-3 duration-200">
          <Check className="w-4 h-4 text-emerald-400" />
          <span className="font-mono">{toastMessage}</span>
        </div>
      )}

      {/* ================= MASTER 4-TAB SEGMENTED CONTROLLER ================= */}
      <div className="bg-white p-1.5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="grid grid-cols-4 gap-2">
          {/* Tab 0: Portfolio Overview */}
          <button
            type="button"
            id="tab-portfolio-overview"
            onClick={() => {
              setPrimaryTab('overview');
              setSearchQuery('');
            }}
            className={`px-2.5 sm:px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              primaryTab === 'overview'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/60'
            }`}
          >
            <Briefcase className={`w-4 h-4 shrink-0 ${primaryTab === 'overview' ? 'text-slate-900' : 'text-slate-500'}`} />
            <span className="truncate">Portfolio</span>
          </button>

          {/* Tab 1: Stocks */}
          <button
            type="button"
            id="tab-equities-portfolio"
            onClick={() => {
              setPrimaryTab('portfolio');
              setSearchQuery('');
            }}
            className={`px-2.5 sm:px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              primaryTab === 'portfolio'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/60'
            }`}
          >
            <TrendingUp className={`w-4 h-4 shrink-0 ${primaryTab === 'portfolio' ? 'text-indigo-400' : 'text-slate-500'}`} />
            <span className="truncate">Stocks</span>
          </button>

          {/* Tab 2: Equity */}
          <button
            type="button"
            id="tab-purchased-holdings"
            onClick={() => {
              setPrimaryTab('holdings');
              setSearchQuery('');
            }}
            className={`px-2.5 sm:px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              primaryTab === 'holdings'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/60'
            }`}
          >
            <Zap className={`w-4 h-4 shrink-0 ${primaryTab === 'holdings' ? 'text-emerald-200' : 'text-slate-500'}`} />
            <span className="truncate">Equity</span>
          </button>

          {/* Tab 3: Derivatives */}
          <button
            type="button"
            id="tab-derivatives-portfolio"
            onClick={() => {
              setPrimaryTab('derivatives');
              setSearchQuery('');
            }}
            className={`px-2.5 sm:px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              primaryTab === 'derivatives'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/60'
            }`}
          >
            <Layers className={`w-4 h-4 shrink-0 ${primaryTab === 'derivatives' ? 'text-indigo-200' : 'text-slate-500'}`} />
            <span className="truncate">Derivatives</span>
          </button>
        </div>
      </div>

      {/* ================= PRIMARY TAB CONTENT ================= */}
      {primaryTab === 'overview' ? (
        <AlpacaPortfolioView 
          stocks={stocks}
          watchlist={watchlist}
          currentUser={currentUser || null}
          onSelectStock={onSelectStock}
          onToggleWatchlist={handleToggleWatchlist}
          onOpenStockMarket={onOpenStockMarket}
          filteredFollowedStocks={filteredFollowedStocks}
          showOnlySummary={true}
        />
      ) : primaryTab === 'derivatives' ? (
        <DerivativesPortfolioTab
          userId={userId}
          orders={orders}
          stocks={stocks}
          onSelectStock={onSelectStock}
          onOpenTradeModal={handleOpenTradeModal}
          onRefreshOrders={() => setOrders(getStoredStockOrders(userId))}
        />
      ) : primaryTab === 'portfolio' ? (
        <div className="space-y-8">
          <AlpacaPortfolioView 
            stocks={stocks}
            watchlist={watchlist}
            currentUser={currentUser || null}
            onSelectStock={onSelectStock}
            onToggleWatchlist={handleToggleWatchlist}
            onOpenStockMarket={onOpenStockMarket}
            filteredFollowedStocks={filteredFollowedStocks}
          />
        </div>
      ) : (
        <PurchasedEquityHoldingsView
          enrichedPositions={equityPositions}
          businessPositions={businessPositions}
          personalPositions={personalPositions}
          businessNAV={businessNAV}
          personalNAV={personalNAV}
          businessGainUSD={businessGainUSD}
          personalGainUSD={personalGainUSD}
          businessGainPercent={businessGainPercent}
          personalGainPercent={personalGainPercent}
          totalStockPositionsUSD={equityNAV}
          totalStockGainUSD={equityGainUSD}
          totalStockCostBasisUSD={equityCostBasis}
          totalStockGainPercent={equityGainPercent}
          selectedMarketFilter={selectedMarketFilter}
          onSelectMarketFilter={setSelectedMarketFilter}
          assetCategoryFilter={assetCategoryFilter}
          onSelectAssetCategoryFilter={setAssetCategoryFilter}
          searchQuery={searchQuery}
          onSearchQueryChange={setSearchQuery}
          stocks={stocks}
          watchlist={watchlist}
          ipos={ipos}
          onToggleWatchlist={handleToggleWatchlist}
          filteredFollowedStocks={filteredFollowedStocks}
          currentUser={currentUser}
          activeSubTab={activeTab}
          onSelectSubTab={setActiveTab}
          onSelectStock={onSelectStock}
          onOpenTradeModal={handleOpenTradeModal}
          onOpenStockMarket={onOpenStockMarket}
          onOpenReleaseModal={() => setIsReleaseIPOModalOpen(true)}
          onRequestDelist={(ipo) => setDelistingIPO(ipo)}
          onSwitchToPortfolioTab={() => {
            setPrimaryTab('portfolio');
            setSearchQuery('');
          }}
          onSwitchToDerivativesTab={() => setPrimaryTab('derivatives')}
        />
      )}

      {/* ================= TRADE & IPO MODALS ================= */}
      {quickTradeStock && (
        <QuickBuyStockModal
          isOpen={Boolean(quickTradeStock)}
          onClose={() => setQuickTradeStock(null)}
          stock={quickTradeStock}
          initialSide={quickTradeSide}
          currentUser={currentUser || null}
          positions={positions}
          onOpenAuthModal={() => {}}
          onExecuteBuy={handleOrderExecuted}
        />
      )}

      {isTradeConfirmationOpen && confirmedOrder && (
        <TradeConfirmationModal
          order={confirmedOrder}
          onClose={() => {
            setIsTradeConfirmationOpen(false);
            setConfirmedOrder(null);
          }}
          onViewPortfolio={() => {
            setIsTradeConfirmationOpen(false);
            setConfirmedOrder(null);
          }}
        />
      )}

      {/* Release IPO Modal */}
      {isReleaseIPOModalOpen && (
        <ReleaseIPOModal
          isOpen={isReleaseIPOModalOpen}
          onClose={() => setIsReleaseIPOModalOpen(false)}
          currentUser={currentUser || { id: 'you', uid: 'you', name: 'Sovereign Trader', email: 'trader@final.finance', role: 'user', provider: 'demo' }}
          onSuccess={(createdIPO) => {
            showToast(`IPO application for $${createdIPO.ticker} submitted for Admin Review.`);
            setIpos(getStoredIPORequests());
          }}
        />
      )}

      {/* Delist IPO Modal */}
      {delistingIPO && (
        <DelistIPOModal
          isOpen={Boolean(delistingIPO)}
          onClose={() => setDelistingIPO(null)}
          ipo={delistingIPO}
          onSuccess={() => {
            showToast(`Delisting request for $${delistingIPO.ticker} routed to Admin.`);
            setIpos(getStoredIPORequests());
          }}
        />
      )}
    </div>
  );
};
