import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  StockItem, 
  StockOrder, 
  StockPaymentSource,
  StockPosition,
  DerivativeType
} from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import { 
  Building2, 
  CreditCard, 
  Wallet, 
  X, 
  ShieldCheck, 
  Zap, 
  Check, 
  TrendingUp, 
  TrendingDown,
  AlertCircle,
  Plus,
  Lock,
  ArrowUpRight,
  RefreshCw,
  BarChart3,
  Newspaper,
  ArrowRight,
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { 
  getAvailableStockPaymentSources, 
  processStockPayment, 
  getStoredStockPositions 
} from '../../utils/stockWalletBridge';
import { INITIAL_USER_STOCK_POSITIONS } from '../../data/stocksData';
import { useApp } from '../../context/AppContext';
import { getLocalStockMarketStatus } from '../../utils/marketHours';
import { formatStockPrice, formatStockAmount, getUSDEquivalentString } from '../../utils/stockCurrencyFormatter';

import { ConfirmModal } from '../common/ConfirmModal';

interface QuickBuyStockModalProps {
  stock: StockItem | null;
  currentUser: AuthSession | null;
  isOpen: boolean;
  initialSide?: 'buy' | 'sell';
  positions?: StockPosition[];
  onClose: () => void;
  onOpenAuthModal: () => void;
  onOpenLinkBankModal?: () => void;
  onLookUpChart?: (stock: StockItem) => void;
  onExecuteBuy: (order: StockOrder) => void;
}

export const QuickBuyStockModal: React.FC<QuickBuyStockModalProps> = ({
  stock,
  currentUser,
  isOpen,
  initialSide = 'buy',
  positions,
  onClose,
  onOpenAuthModal,
  onOpenLinkBankModal,
  onLookUpChart,
  onExecuteBuy,
}) => {
  const { setCurrentTab, addTransaction } = useApp();
  const [tradeSide, setTradeSide] = useState<'buy' | 'sell'>(initialSide);
  const [derivativeType, setDerivativeType] = useState<DerivativeType>('spot');
  const [strikePriceInput, setStrikePriceInput] = useState<string>(stock?.price ? stock.price.toFixed(2) : '100');
  const [expiryDate, setExpiryDate] = useState<string>('2026-09-30');
  const [leverage, setLeverage] = useState<number>(10);

  const [inputMode, setInputMode] = useState<'dollars' | 'shares'>('dollars');
  const [dollarAmount, setDollarAmount] = useState<string>('500');
  const [sharesAmount, setSharesAmount] = useState<string>('5');
  const [selectedSourceId, setSelectedSourceId] = useState<string>('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [sourcesVersion, setSourcesVersion] = useState(0);
  const [showConfirm, setShowConfirm] = useState(false);

  // Sync side when initialSide or stock changes
  useEffect(() => {
    if (initialSide) {
      setTradeSide(initialSide);
    }
    if (stock && stock.price > 0) {
      setStrikePriceInput(stock.price.toFixed(2));
    }
  }, [initialSide, stock?.ticker, stock?.price]);

  // Load user positions
  const currentPositions = useMemo(() => {
    if (positions && positions.length > 0) return positions;
    return getStoredStockPositions(currentUser?.id || 'guest', INITIAL_USER_STOCK_POSITIONS);
  }, [positions, currentUser?.id, sourcesVersion]);

  // Check if user currently holds shares of this stock
  const userHolding = useMemo(() => {
    if (!stock) return null;
    return currentPositions.find(p => p.ticker === stock.ticker) || null;
  }, [currentPositions, stock?.ticker]);

  const userSharesOwned = userHolding?.shares || 0;
  const hasSharesToSell = userSharesOwned > 0;

  // Sync initial dollar & shares amounts whenever stock or tradeSide changes
  useEffect(() => {
    if (stock && stock.price > 0) {
      if (tradeSide === 'sell' && hasSharesToSell) {
        const defaultSellShares = Math.min(5, userSharesOwned);
        setSharesAmount(defaultSellShares.toString());
        setDollarAmount((defaultSellShares * stock.price).toFixed(2));
      } else {
        const initialDollars = 500;
        setDollarAmount(initialDollars.toString());
        setSharesAmount((initialDollars / stock.price).toFixed(2));
      }
    }
  }, [stock?.ticker, stock?.price, tradeSide, hasSharesToSell, userSharesOwned]);

  // Listen for storage / wallet updates
  useEffect(() => {
    const handleUpdate = () => setSourcesVersion((v) => v + 1);
    window.addEventListener('final_finance_wallets_updated', handleUpdate);
    window.addEventListener('final_finance_stocks_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleUpdate);
      window.removeEventListener('final_finance_stocks_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  // Listen for Escape key to close modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isExecuting) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isExecuting, onClose]);

  // Available funding / deposit sources
  const availableSources = useMemo(
    () => getAvailableStockPaymentSources(currentUser?.id || 'guest'),
    [currentUser?.id, sourcesVersion]
  );
  
  const activeSource: StockPaymentSource = useMemo(() => {
    if (selectedSourceId) {
      const found = availableSources.find(s => s.id === selectedSourceId);
      if (found) return found;
    }
    return availableSources[0] || {
      id: 'default-balance',
      type: 'balance' as any,
      label: 'Direct Settlement Vault',
      subtitle: 'Primary Reserves',
      balanceUSD: 250000,
      iconType: 'bank',
      isDefault: true,
    };
  }, [availableSources, selectedSourceId]);

  const stockPrice = Math.max(0.01, stock?.price || 1);

  const calculatedShares = inputMode === 'dollars'
    ? Number(((parseFloat(dollarAmount) || 0) / stockPrice).toFixed(4))
    : parseFloat(sharesAmount) || 0;

  const baseUSD = inputMode === 'dollars'
    ? parseFloat(dollarAmount) || 0
    : (parseFloat(sharesAmount) || 0) * stockPrice;

  // Calculate derivative cost (Options premium = 5% of notional, Futures margin = notional / leverage)
  const strikePrice = parseFloat(strikePriceInput) || stockPrice;
  const marketStatus = getLocalStockMarketStatus();

  const totalUSD = useMemo(() => {
    if (derivativeType === 'call_option' || derivativeType === 'put_option') {
      return baseUSD * 0.05; // 5% option premium
    } else if (derivativeType === 'futures_long' || derivativeType === 'futures_short') {
      return baseUSD / leverage; // leveraged margin
    } else {
      return baseUSD;
    }
  }, [derivativeType, baseUSD, leverage]);

  if (!isOpen || !stock) return null;

  const availableBalance = activeSource?.balanceUSD ?? 0;
  
  const canAffordBuy = tradeSide === 'buy' ? (availableBalance >= totalUSD && totalUSD > 0 && calculatedShares > 0) : true;
  const canSellShares = tradeSide === 'sell' ? (userSharesOwned > 0 && calculatedShares > 0 && calculatedShares <= userSharesOwned + 0.0001) : true;
  const isValidTrade = tradeSide === 'buy' ? canAffordBuy : canSellShares;

  const estimatedCostBasis = userHolding ? calculatedShares * userHolding.avgCostUSD : 0;
  const estimatedRealizedGainUSD = totalUSD - estimatedCostBasis;
  const estimatedRealizedGainPct = estimatedCostBasis > 0 ? (estimatedRealizedGainUSD / estimatedCostBasis) * 100 : 0;

  const handleToggleInputMode = (newMode: 'dollars' | 'shares') => {
    if (newMode === 'dollars') {
      const currentDollars = (parseFloat(sharesAmount) || 0) * stockPrice;
      setDollarAmount(currentDollars > 0 ? currentDollars.toFixed(2) : '500');
    } else {
      const currentShares = (parseFloat(dollarAmount) || 0) / stockPrice;
      setSharesAmount(currentShares > 0 ? currentShares.toFixed(2) : '5');
    }
    setInputMode(newMode);
  };

  const handleQuickDollarPreset = (amount: number) => {
    setInputMode('dollars');
    setDollarAmount(amount.toString());
    setSharesAmount((amount / stockPrice).toFixed(2));
  };

  const handleQuickSharesPreset = (shares: number) => {
    setInputMode('shares');
    setSharesAmount(shares.toString());
    setDollarAmount((shares * stockPrice).toFixed(2));
  };

  const handlePercentBalanceBuy = (pct: number) => {
    const targetDollars = Math.floor(availableBalance * pct);
    setInputMode('dollars');
    setDollarAmount(Math.max(10, targetDollars).toString());
    setSharesAmount((Math.max(10, targetDollars) / stockPrice).toFixed(2));
  };

  const handlePercentHoldingsSell = (pct: number) => {
    if (!userSharesOwned) return;
    const targetShares = Number((userSharesOwned * pct).toFixed(4));
    setInputMode('shares');
    setSharesAmount(targetShares.toString());
    setDollarAmount((targetShares * stockPrice).toFixed(2));
  };

  const handleExecute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    if (totalUSD <= 0 || calculatedShares <= 0 || !isValidTrade) return;

    setShowConfirm(true);
  };

  const processExecution = () => {
    setIsExecuting(true);

    setTimeout(() => {
      processStockPayment(currentUser!.id, activeSource, totalUSD, tradeSide);

      const derivativeName = 
        derivativeType === 'call_option' ? `Call Option (${strikePrice} Strike)` :
        derivativeType === 'put_option' ? `Put Option (${strikePrice} Strike)` :
        derivativeType === 'futures_long' ? `Futures Long (${leverage}x)` :
        derivativeType === 'futures_short' ? `Futures Short (${leverage}x)` :
        `Spot Equity`;

      const isMarketOpen = marketStatus.isOpen;
      const orderStatus: 'filled' | 'open' = isMarketOpen ? 'filled' : 'open';

      const newOrder: StockOrder = {
        id: `ord-${Date.now()}`,
        ticker: stock.ticker,
        stockName: `${stock.name} [${derivativeName}]`,
        side: tradeSide,
        orderType: 'market',
        derivativeType: derivativeType,
        strikePrice: derivativeType.includes('option') ? strikePrice : undefined,
        expiryDate: derivativeType.includes('option') || derivativeType.includes('futures') ? expiryDate : undefined,
        leverage: derivativeType.includes('futures') ? leverage : undefined,
        premiumUSD: derivativeType.includes('option') ? totalUSD : undefined,
        shares: calculatedShares,
        price: stockPrice,
        totalUSD: totalUSD,
        paymentSource: activeSource,
        status: orderStatus,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        dateIso: new Date().toISOString(),
        sector: stock.sector,
        tradeSlipId: `SLIP-${Date.now().toString().slice(-8)}`
      };

      onExecuteBuy(newOrder);

      // Add to global ledger
      addTransaction({
        taxYear: new Date().getFullYear(),
        type: tradeSide === 'buy' ? 'stock_buy' : 'stock_sell',
        category: 'trade',
        mode: (activeSource.type as string) === 'crypto' ? 'crypto' : 'fiat_currency',
        title: `${tradeSide.toUpperCase()} ${stock.ticker} - ${derivativeName} (${isMarketOpen ? 'Regular Hours' : 'After-Hours Queue'})`,
        description: isMarketOpen 
          ? `Quick execution of ${tradeSide.toUpperCase()} order for ${calculatedShares} units of ${stock.ticker} at $${stockPrice.toFixed(2)}.`
          : `Queued ${tradeSide.toUpperCase()} order for ${calculatedShares} units of ${stock.ticker} at $${stockPrice.toFixed(2)}. Will fill when regular stock market hours resume (Mon–Fri 9:30 AM – 4:00 PM local time).`,
        amountUSD: totalUSD,
        feeUSD: 0,
        netAmountUSD: tradeSide === 'buy' ? -totalUSD : totalUSD,
        sourceOrDestination: currentUser!.name,
        counterpartyOrIssuer: 'Global Stock Exchange',
        issuerHandle: currentUser!.handle,
        status: isMarketOpen ? 'Settled' : 'Pending Open',
        clearingNode: 'QUICK-EX-NODE-1',
        taxClassification: {
          formMapping: 'Securities Transaction',
          taxableEvent: true,
          taxableAmountUSD: totalUSD,
          irsCategoryNote: `Quick buy ${tradeSide} execution`
        }
      });

      setIsExecuting(false);
      onClose();
    }, 500);
  };

  return (
    <AnimatePresence>
      <div 
        id="quick-trade-modal-backdrop"
        onClick={(e) => {
          if (e.target === e.currentTarget && !isExecuting) {
            onClose();
          }
        }}
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-md overflow-y-auto"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 12 }}
          transition={{ duration: 0.18 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-lg rounded-3xl bg-white border border-slate-200 shadow-2xl p-5 sm:p-7 overflow-hidden my-auto text-left max-h-[90vh] overflow-y-auto"
        >
          {/* Close Button */}
          <button
            type="button"
            id="close-quick-trade-modal-btn"
            onClick={onClose}
            disabled={isExecuting}
            className="absolute top-4 right-4 sm:top-5 sm:right-5 min-h-[36px] min-w-[36px] flex items-center justify-center rounded-full text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer z-20"
            title="Close Window (Esc)"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Stock Header */}
          <div className="flex items-center gap-3.5 pb-3.5 border-b border-slate-100 pr-10">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-300 text-amber-950 flex items-center justify-center font-mono font-bold text-base shadow-2xs shrink-0">
              {(stock.ticker || '').slice(0, 3)}
            </div>
            <div className="min-w-0 flex-1 space-y-0.5">
              <span className="font-mono font-bold text-base text-slate-900 block leading-tight">
                ${stock.ticker}
              </span>
              <span className="text-[9px] font-bold text-slate-500 font-mono block">
                {stock.exchange}
              </span>
              <span className="text-[10px] font-semibold text-emerald-700 block">
                {stock.sector}
              </span>
              <h3 className="text-xs font-semibold text-slate-600 truncate pt-0.5">
                {stock.name}
              </h3>
            </div>

            <div className="text-right shrink-0">
              <span className="font-mono font-bold text-base text-slate-900 block">
                {formatStockPrice(stockPrice, stock, false)}
              </span>
              {getUSDEquivalentString(stockPrice, stock) && (
                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                  {getUSDEquivalentString(stockPrice, stock)}
                </span>
              )}
              <span className={`text-xs font-mono font-bold ${(stock.changeUSD || 0) >= 0 ? 'text-emerald-600' : 'text-rose-600'} block mt-0.5`}>
                {(stock.changeUSD || 0) >= 0 ? '+' : ''}{(stock.changePercent || 0).toFixed(2)}%
              </span>
            </div>
          </div>

          {/* Local Market Hours Notice Banner */}
          <div className={`mt-3 p-2.5 rounded-2xl border text-xs flex items-center justify-between gap-2 ${
            marketStatus.isOpen 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${marketStatus.isOpen ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
              <div>
                <span className="font-bold">{marketStatus.isOpen ? 'Regular Market Open' : 'Regular Market Closed'}</span>
                <span className="text-[11px] block text-slate-600 font-normal">
                  Regular trading hours: Mon–Fri, 9:30 AM – 4:00 PM local time ({marketStatus.timeZone})
                </span>
              </div>
            </div>
            {!marketStatus.isOpen && (
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-200/60 text-amber-950 shrink-0">
                After-Hours Order
              </span>
            )}
          </div>

          {/* Derivative Instrument Selector (Spot, Call, Put, Futures Long, Futures Short) */}
          <div className="mt-3.5 space-y-1.5">
            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Instrument &amp; Derivatives Engine
            </label>
            <div className="grid grid-cols-5 gap-1 p-1 bg-slate-100 rounded-2xl text-[11px] font-bold">
              <button
                type="button"
                onClick={() => setDerivativeType('spot')}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                  derivativeType === 'spot'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Spot
              </button>
              <button
                type="button"
                onClick={() => setDerivativeType('call_option')}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                  derivativeType === 'call_option'
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Call ↗
              </button>
              <button
                type="button"
                onClick={() => setDerivativeType('put_option')}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                  derivativeType === 'put_option'
                    ? 'bg-rose-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Put ↘
              </button>
              <button
                type="button"
                onClick={() => setDerivativeType('futures_long')}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                  derivativeType === 'futures_long'
                    ? 'bg-amber-500 text-slate-950 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Long Fut
              </button>
              <button
                type="button"
                onClick={() => setDerivativeType('futures_short')}
                className={`py-2 px-1 rounded-xl transition-all cursor-pointer text-center truncate ${
                  derivativeType === 'futures_short'
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Short Fut
              </button>
            </div>
          </div>

          {/* Derivative Parameter Controls */}
          {(derivativeType === 'call_option' || derivativeType === 'put_option') && (
            <div className="mt-3 p-3 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2.5">
              <div className="flex items-center justify-between text-xs font-bold text-amber-900">
                <span>Options Contract Details</span>
                <span className="text-[10px] font-mono bg-amber-200/60 px-2 py-0.5 rounded text-amber-950">5% Premium Cost</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Strike ($)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={strikePriceInput}
                    onChange={(e) => setStrikePriceInput(e.target.value)}
                    className="w-full h-8 px-2.5 rounded-xl border border-amber-300 bg-white font-mono text-xs font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Expiry</label>
                  <input
                    type="date"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full h-8 px-2.5 rounded-xl border border-amber-300 bg-white font-mono text-xs font-bold text-slate-900"
                  />
                </div>
              </div>
            </div>
          )}

          {(derivativeType === 'futures_long' || derivativeType === 'futures_short') && (
            <div className="mt-3 p-3 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2.5">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-950">
                <span>Futures Leverage</span>
                <span className="text-[10px] font-mono bg-indigo-200/60 px-2 py-0.5 rounded text-indigo-950">{leverage}x Leverage</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {[2, 5, 10, 20].map((lev) => (
                  <button
                    key={lev}
                    type="button"
                    onClick={() => setLeverage(lev)}
                    className={`py-1.5 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                      leverage === lev
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-white text-indigo-900 border-indigo-200 hover:bg-indigo-100'
                    }`}
                  >
                    {lev}x
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Buy vs Sell Switcher Tabs */}
          <div className="mt-3.5 grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-slate-100 border border-slate-200">
            <button
              type="button"
              onClick={() => setTradeSide('buy')}
              className={`py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                tradeSide === 'buy'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Buy / Long</span>
            </button>

            <button
              type="button"
              onClick={() => setTradeSide('sell')}
              className={`py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                tradeSide === 'sell'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : hasSharesToSell 
                  ? 'text-amber-800 hover:text-amber-950 font-bold'
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Sell / Close {hasSharesToSell ? `(${userSharesOwned} shs)` : ''}</span>
            </button>
          </div>

          <form onSubmit={handleExecute} className="mt-3.5 space-y-3.5">
            {/* Toggle: In Dollars vs In Shares */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">
                {tradeSide === 'buy' ? 'Order Method:' : 'Selling Quantity Method:'}
              </span>
              <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => handleToggleInputMode('dollars')}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                    inputMode === 'dollars' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Dollars ($)
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleInputMode('shares')}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                    inputMode === 'shares' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Shares (Qty)
                </button>
              </div>
            </div>

            {/* Amount Input */}
            {inputMode === 'dollars' ? (
              <div>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-mono text-lg font-bold text-slate-400">$</span>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={dollarAmount}
                    onChange={(e) => {
                      const val = e.target.value;
                      setDollarAmount(val);
                      const num = parseFloat(val) || 0;
                      setSharesAmount((num / stockPrice).toFixed(2));
                    }}
                    className="w-full h-12 pl-9 pr-28 rounded-2xl border border-slate-200 bg-slate-50/50 text-slate-900 font-mono font-bold text-base focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                    placeholder="500"
                    required
                  />
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-right pointer-events-none">
                    <span className="text-xs font-mono font-bold text-slate-500 block">
                      ≈ {calculatedShares} units
                    </span>
                  </div>
                </div>

                {/* Quick Presets */}
                {tradeSide === 'buy' ? (
                  <div className="grid grid-cols-5 gap-1.5 mt-2">
                    {[50, 100, 250, 500, 1000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => handleQuickDollarPreset(amt)}
                        className={`py-1.5 text-xs font-mono font-bold rounded-xl border transition-colors cursor-pointer ${
                          dollarAmount === amt.toString()
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        ${amt}
                      </button>
                    ))}
                  </div>
                ) : (
                  hasSharesToSell && (
                    <div className="grid grid-cols-4 gap-1.5 mt-2">
                      {[0.25, 0.50, 0.75, 1.0].map((pct) => (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => handlePercentHoldingsSell(pct)}
                          className="py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer"
                        >
                          {pct === 1.0 ? '100% (All)' : `${pct * 100}%`}
                        </button>
                      ))}
                    </div>
                  )
                )}
              </div>
            ) : (
              <div>
                <div className="relative">
                  <input
                    type="number"
                    min="0.01"
                    step="any"
                    value={sharesAmount}
                    onChange={(e) => {
                      const val = e.target.value;
                      setSharesAmount(val);
                      const num = parseFloat(val) || 0;
                      setDollarAmount((num * stockPrice).toFixed(2));
                    }}
                    className="w-full h-12 px-4 pr-28 rounded-2xl border border-slate-200 bg-slate-50/50 text-slate-900 font-mono font-bold text-base focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                    placeholder="5"
                    required
                  />
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-right pointer-events-none">
                    <span className="text-xs font-mono font-bold text-slate-500 block">
                      ≈ {formatStockAmount(baseUSD, stock, false)}
                    </span>
                  </div>
                </div>

                {tradeSide === 'buy' ? (
                  <div className="grid grid-cols-5 gap-1.5 mt-2">
                    {[1, 5, 10, 25, 50].map((sh) => (
                      <button
                        key={sh}
                        type="button"
                        onClick={() => handleQuickSharesPreset(sh)}
                        className={`py-1.5 text-xs font-mono font-bold rounded-xl border transition-colors cursor-pointer ${
                          sharesAmount === sh.toString()
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        {sh} Shs
                      </button>
                    ))}
                  </div>
                ) : (
                  hasSharesToSell && (
                    <div className="grid grid-cols-4 gap-1.5 mt-2">
                      {[0.25, 0.50, 0.75, 1.0].map((pct) => (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => handlePercentHoldingsSell(pct)}
                          className="py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer"
                        >
                          {pct === 1.0 ? '100% (All)' : `${pct * 100}%`}
                        </button>
                      ))}
                    </div>
                  )
                )}
              </div>
            )}

            {/* Payment Source */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700">
                  {tradeSide === 'buy' ? 'Funding Source' : 'Deposit Proceeds To'}
                </label>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    setCurrentTab('settings');
                  }}
                  className="text-[11px] font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
                >
                  <span>Manage →</span>
                </button>
              </div>

              <select
                value={activeSource?.id}
                onChange={(e) => setSelectedSourceId(e.target.value)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/50 cursor-pointer"
              >
                {availableSources.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label} — ${s.balanceUSD.toLocaleString()} available
                  </option>
                ))}
              </select>
            </div>

            {/* Order Summary Box */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs space-y-1.5 font-mono">
              <div className="flex items-center justify-between text-slate-500 font-sans">
                <span>Instrument</span>
                <span className="font-bold text-slate-900 uppercase">{derivativeType.replace('_', ' ')}</span>
              </div>
              <div className="flex items-center justify-between text-slate-500 font-sans">
                <span>Notional Value</span>
                <div className="text-right">
                  <span className="font-mono text-slate-900 block">{formatStockAmount(baseUSD, stock, false)}</span>
                  {getUSDEquivalentString(baseUSD, stock) && (
                    <span className="font-mono text-[10px] text-slate-400 block mt-0.5">{getUSDEquivalentString(baseUSD, stock)}</span>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between text-slate-500 font-sans">
                <span>Platform Commission</span>
                <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded">0.00</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-sm font-bold text-slate-900 font-sans">
                <span>{tradeSide === 'buy' ? 'Total Cost' : 'Net Proceeds'}</span>
                <div className="text-right">
                  <span className="font-mono text-base text-slate-900 block">
                    {formatStockAmount(totalUSD, stock, false)}
                  </span>
                  {getUSDEquivalentString(totalUSD, stock) && (
                    <span className="font-mono text-[11px] text-slate-500 block mt-0.5">
                      {getUSDEquivalentString(totalUSD, stock)}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                disabled={isExecuting}
                className="py-3 px-4 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer shrink-0"
              >
                Cancel
              </button>

              {currentUser ? (
                <button
                  type="submit"
                  disabled={isExecuting || (tradeSide === 'buy' && !canAffordBuy)}
                  className={`flex-1 py-3 px-4 rounded-2xl text-xs font-bold transition-all shadow-sm cursor-pointer flex items-center justify-center gap-2 ${
                    tradeSide === 'buy'
                      ? canAffordBuy
                        ? 'bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-slate-950 font-bold'
                        : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-amber-600 hover:bg-amber-500 active:scale-[0.99] text-white font-bold'
                  }`}
                >
                  {isExecuting ? (
                    <span>Processing Trade...</span>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>Execute {derivativeType.replace('_', ' ')} ({formatStockAmount(totalUSD, stock, false)})</span>
                    </>
                  )}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onOpenAuthModal}
                  className="flex-1 py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-sm cursor-pointer flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>Sign In to Trade</span>
                </button>
              )}
            </div>
          </form>
        </motion.div>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title={tradeSide === 'buy' ? 'Confirm Stock Purchase' : 'Confirm Stock Sale'}
        message={`Are you sure you want to ${tradeSide === 'buy' ? 'buy' : 'sell'} ${calculatedShares} ${tradeSide === 'buy' ? 'shares of' : 'shares from'} ${stock.name} (${stock.ticker}) for a total of ${formatStockAmount(totalUSD, stock)}?`}
        confirmText={tradeSide === 'buy' ? 'Execute Buy' : 'Execute Sell'}
        type={tradeSide === 'buy' ? 'info' : 'warning'}
      />
    </AnimatePresence>
  );
};
