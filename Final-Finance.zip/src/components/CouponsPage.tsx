import React, { useState, useEffect, useMemo } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  Ticket,
  Search,
  Bookmark,
  BookmarkCheck,
  UtensilsCrossed,
  Store,
  Car,
  Globe,
  QrCode,
  CheckCircle2,
  Copy,
  Check,
  X,
  Trash2,
  PlusCircle,
  History,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import {
  CouponCategory,
  CouponChannel,
  PlatformCoupon,
  SavedCouponRecord,
} from '../types/coupon';
import {
  COUPONS_UPDATED_EVENT,
  getAllPlatformCoupons,
  getSavedCouponsForUser,
  redeemCouponForUser,
  saveCouponForUser,
  searchPlatformCoupons,
  setPendingCheckoutCoupon,
  unsaveCouponForUser,
} from '../services/couponService';
import { CouponIssuerWidget } from './CouponIssuerWidget';
import { dispatchGlobalNotification } from '../utils/notificationService';

interface CouponsPageProps {
  currentUser: AuthSession | null;
  onNavigateBack?: () => void;
  onUseOnlineCoupon?: (
    category: CouponCategory,
    coupon: PlatformCoupon
  ) => void;
  onOpenVerificationModal?: (tier?: 1 | 2 | 3) => void;
  onNavigateToPOS?: (tab?: 'retail' | 'restaurant') => void;
  onNavigateToRideShare?: () => void;
}

export const CouponsPage: React.FC<CouponsPageProps> = ({
  currentUser,
  onUseOnlineCoupon,
  onOpenVerificationModal,
  onNavigateToPOS,
  onNavigateToRideShare,
}) => {
  const userId = currentUser?.id || currentUser?.uid || 'guest';

  const [activeTab, setActiveTab] = useState<'browse' | 'saved' | 'issue' | 'history'>('browse');

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<CouponCategory | 'all'>('all');
  const [channelFilter, setChannelFilter] = useState<CouponChannel | 'all'>('all');

  const [allCoupons, setAllCoupons] = useState<PlatformCoupon[]>(() => getAllPlatformCoupons());
  const [savedRecords, setSavedRecords] = useState<SavedCouponRecord[]>(() =>
    getSavedCouponsForUser(userId)
  );
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [inPersonPassCoupon, setInPersonPassCoupon] = useState<PlatformCoupon | null>(null);

  useEffect(() => {
    const sync = () => {
      setAllCoupons(getAllPlatformCoupons());
      setSavedRecords(getSavedCouponsForUser(userId));
    };
    sync();
    window.addEventListener(COUPONS_UPDATED_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(COUPONS_UPDATED_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, [userId]);

  const filteredCoupons = useMemo(
    () =>
      searchPlatformCoupons({
        query: searchQuery,
        category: categoryFilter,
        channel: channelFilter,
      }),
    [searchQuery, categoryFilter, channelFilter, allCoupons]
  );

  const savedCouponIds = useMemo(
    () => new Set(savedRecords.filter((r) => r.status === 'saved').map((r) => r.couponId)),
    [savedRecords]
  );

  const redeemedCouponIds = useMemo(
    () => new Set(savedRecords.filter((r) => r.status === 'redeemed').map((r) => r.couponId)),
    [savedRecords]
  );

  const couponById = useMemo(
    () => new Map(allCoupons.map((c) => [c.id, c])),
    [allCoupons]
  );

  const activeSavedCoupons = useMemo(() => {
    return savedRecords
      .filter((r) => r.status === 'saved')
      .map((r) => ({ record: r, coupon: couponById.get(r.couponId) }))
      .filter((entry): entry is { record: SavedCouponRecord; coupon: PlatformCoupon } => !!entry.coupon);
  }, [savedRecords, couponById]);

  const savedRetailCoupons = useMemo(
    () => activeSavedCoupons.filter(({ coupon }) => coupon.category === 'retail'),
    [activeSavedCoupons]
  );
  const savedRestaurantCoupons = useMemo(
    () => activeSavedCoupons.filter(({ coupon }) => coupon.category === 'restaurant'),
    [activeSavedCoupons]
  );
  const savedDriverCoupons = useMemo(
    () => activeSavedCoupons.filter(({ coupon }) => coupon.category === 'ride_share'),
    [activeSavedCoupons]
  );

  const redeemedHistoryCoupons = useMemo(() => {
    return savedRecords
      .filter((r) => r.status === 'redeemed')
      .map((r) => ({ record: r, coupon: couponById.get(r.couponId) }))
      .filter((entry): entry is { record: SavedCouponRecord; coupon: PlatformCoupon } => !!entry.coupon);
  }, [savedRecords, couponById]);

  const redeemedRetailCoupons = useMemo(
    () => redeemedHistoryCoupons.filter(({ coupon }) => coupon.category === 'retail'),
    [redeemedHistoryCoupons]
  );
  const redeemedRestaurantCoupons = useMemo(
    () => redeemedHistoryCoupons.filter(({ coupon }) => coupon.category === 'restaurant'),
    [redeemedHistoryCoupons]
  );
  const redeemedDriverCoupons = useMemo(
    () => redeemedHistoryCoupons.filter(({ coupon }) => coupon.category === 'ride_share'),
    [redeemedHistoryCoupons]
  );

  const handleToggleSave = (coupon: PlatformCoupon) => {
    if (savedCouponIds.has(coupon.id)) {
      unsaveCouponForUser(userId, coupon.id);
      dispatchGlobalNotification({
        title: `Removed ${coupon.code}`,
        description: `Removed ${coupon.code} from your Saved Coupons.`,
        type: 'system',
        targetTab: 'coupons',
        showToast: true,
        tone: 'default',
      });
    } else {
      const res = saveCouponForUser(userId, coupon.id);
      dispatchGlobalNotification({
        title: res.success ? `Saved Coupon: ${coupon.code}` : `Limit Reached: ${coupon.code}`,
        description: res.message,
        type: 'system',
        targetTab: 'coupons',
        showToast: true,
        tone: res.success ? 'success' : 'alert',
      });
    }
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 1500);
  };

  const handleUseOnline = (coupon: PlatformCoupon) => {
    if (!savedCouponIds.has(coupon.id)) {
      const res = saveCouponForUser(userId, coupon.id);
      if (!res.success) {
        dispatchGlobalNotification({
          title: `Limit Reached: ${coupon.code}`,
          description: res.message,
          type: 'system',
          targetTab: 'coupons',
          showToast: true,
          tone: 'alert',
        });
        return;
      }
    }
    setPendingCheckoutCoupon({
      couponId: coupon.id,
      code: coupon.code,
      category: coupon.category,
      channel: 'online',
      merchantLocationId: coupon.merchantLocationId,
    });
    if (onUseOnlineCoupon) {
      onUseOnlineCoupon(coupon.category, coupon);
    } else if (coupon.category === 'ride_share' && onNavigateToRideShare) {
      onNavigateToRideShare();
    } else if (onNavigateToPOS) {
      onNavigateToPOS(coupon.category === 'retail' ? 'retail' : 'restaurant');
    }
  };

  const handleUseInPersonTerminal = (coupon: PlatformCoupon) => {
    if (!savedCouponIds.has(coupon.id)) {
      const res = saveCouponForUser(userId, coupon.id);
      if (!res.success) {
        dispatchGlobalNotification({
          title: `Limit Reached: ${coupon.code}`,
          description: res.message,
          type: 'system',
          targetTab: 'coupons',
          showToast: true,
          tone: 'alert',
        });
        return;
      }
    }
    setPendingCheckoutCoupon({
      couponId: coupon.id,
      code: coupon.code,
      category: coupon.category,
      channel: 'in_person',
      merchantLocationId: coupon.merchantLocationId,
    });
    setInPersonPassCoupon(null);
    if (coupon.category === 'ride_share' && onNavigateToRideShare) {
      onNavigateToRideShare();
    } else if (onNavigateToPOS) {
      onNavigateToPOS(coupon.category === 'retail' ? 'retail' : 'restaurant');
    }
  };

  const handleMarkRedeemedInPerson = (coupon: PlatformCoupon) => {
    redeemCouponForUser(userId, coupon.id, {
      channel: 'in_person',
      orderRef: `INPERSON-${Math.floor(100000 + Math.random() * 900000)}`,
      discountApplied: coupon.discountValue,
      currency: coupon.currency === 'ANY' ? 'AFNL' : coupon.currency,
    });
    setInPersonPassCoupon(null);
    dispatchGlobalNotification({
      title: `Coupon Redeemed In-Person: ${coupon.code}`,
      description: `${coupon.code} was marked redeemed for your in-person ${coupon.merchantName} transaction.`,
      type: coupon.category === 'ride_share' ? 'ride_share' : 'pos',
      targetTab: 'coupons',
      showToast: true,
      tone: 'success',
    });
  };

  const getCategoryIcon = (cat: CouponCategory) => {
    if (cat === 'restaurant') return <UtensilsCrossed className="w-3.5 h-3.5 text-amber-600 shrink-0" />;
    if (cat === 'retail') return <Store className="w-3.5 h-3.5 text-indigo-600 shrink-0" />;
    return <Car className="w-3.5 h-3.5 text-emerald-600 shrink-0" />;
  };

  const getCategoryLabel = (cat: CouponCategory) => {
    if (cat === 'restaurant') return 'Restaurant';
    if (cat === 'retail') return 'Retail Store';
    return 'Driving';
  };

  const getChannelLabel = (ch: CouponChannel) => {
    if (ch === 'both') return 'Online & In-Person';
    if (ch === 'online') return 'Online Only';
    return 'In-Person Only';
  };

  const renderSavedCouponCard = ({ record, coupon }: { record: SavedCouponRecord; coupon: PlatformCoupon }) => (
    <div
      key={record.id}
      className="w-full min-w-0 overflow-hidden bg-white border border-neutral-200 rounded-3xl p-5 shadow-xs space-y-4 flex flex-col items-center justify-between text-center"
    >
      <div className="space-y-2 text-center w-full min-w-0 flex flex-col items-center">
        <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px] font-semibold text-neutral-600">
          {getCategoryIcon(coupon.category)}
          <span>{getCategoryLabel(coupon.category)}</span>
          <span className="text-neutral-300">·</span>
          <span className="text-emerald-700">{getChannelLabel(coupon.validChannels)}</span>
        </div>

        <div className="text-2xl font-mono font-extrabold text-emerald-700 tabular-nums">
          {coupon.discountType === 'percentage'
            ? `${coupon.discountValue}% OFF${coupon.currency && coupon.currency !== 'ANY' ? ` (${coupon.currency})` : ''}`
            : `${coupon.discountValue} ${coupon.currency === 'ANY' ? 'FC' : coupon.currency} OFF`}
        </div>

        <h3 className="w-full text-sm font-bold text-neutral-900 break-words leading-snug">{coupon.title}</h3>
        <p className="w-full text-xs font-semibold text-amber-800 break-words">{coupon.merchantName}</p>
        {coupon.vehicleType && (
          <p className="w-full text-[11px] font-mono text-indigo-700 break-words">{coupon.vehicleType}</p>
        )}
        <p className="w-full text-[11px] text-neutral-500 break-words leading-relaxed">{coupon.description}</p>

        <div className="flex items-center justify-center gap-2">
          <span className="px-3 py-1 rounded-xl bg-neutral-100 border border-neutral-200 text-xs font-mono font-bold text-neutral-900">
            {coupon.code}
          </span>
          <button
            type="button"
            onClick={() => handleCopyCode(coupon.code)}
            className="p-1.5 rounded-xl bg-neutral-50 border border-neutral-200 hover:bg-neutral-100 text-neutral-600 cursor-pointer"
            title="Copy coupon code"
          >
            {copiedCode === coupon.code ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
        <p className="text-[10px] font-mono text-neutral-400 tabular-nums">
          Saved {new Date(record.savedAt).toLocaleDateString()} · Min {coupon.minOrderAmount} FC · Exp {coupon.expiresAt}
        </p>
      </div>

      <div className="w-full space-y-2 pt-3 border-t border-neutral-100">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 w-full">
          {(coupon.validChannels === 'both' || coupon.validChannels === 'online') && (
            <button
              type="button"
              onClick={() => handleUseOnline(coupon)}
              className="w-full sm:flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 shrink-0" />
              <span>Use Online</span>
            </button>
          )}
          {(coupon.validChannels === 'both' || coupon.validChannels === 'in_person') && (
            <button
              type="button"
              onClick={() => setInPersonPassCoupon(coupon)}
              className="w-full sm:flex-1 py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <QrCode className="w-3.5 h-3.5 shrink-0" />
              <span>Use In-Person</span>
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={() => unsaveCouponForUser(userId, record.id)}
          className="w-full py-2 rounded-xl bg-neutral-100 hover:bg-rose-50 hover:text-rose-700 text-neutral-600 text-[11px] font-bold inline-flex items-center justify-center gap-1 cursor-pointer transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Remove Saved Coupon</span>
        </button>
      </div>
    </div>
  );

  const renderRedeemedCouponCard = ({ record, coupon }: { record: SavedCouponRecord; coupon: PlatformCoupon }) => (
    <div
      key={record.id}
      className="w-full min-w-0 overflow-hidden bg-white border border-neutral-200 rounded-3xl p-5 shadow-xs space-y-2 text-center flex flex-col items-center"
    >
      <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-700">
        <CheckCircle2 className="w-4 h-4 shrink-0" />
        <span>
          Redeemed ({record.redeemedChannel === 'in_person' ? 'In-Person' : 'Online'})
        </span>
      </div>
      <p className="w-full text-sm font-bold text-neutral-900 break-words leading-snug">{coupon.title}</p>
      <p className="w-full text-xs font-mono font-bold text-neutral-700 break-words">
        Code: {coupon.code} · {coupon.merchantName}
      </p>
      {record.discountApplied !== undefined && (
        <p className="text-xs font-mono font-bold text-emerald-700 tabular-nums">
          Saved {record.discountApplied.toLocaleString()} {record.redemptionCurrency || 'AFNL'}
        </p>
      )}
      <p className="w-full text-[10px] font-mono text-neutral-400 break-words">
        Ref: {record.redeemedOrderRef || 'N/A'} ·{' '}
        {record.redeemedAt ? new Date(record.redeemedAt).toLocaleString() : ''}
      </p>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-2 pb-8 space-y-5 text-center">
      {/* Centered Header with Logo in front of Title */}
      <div className="flex flex-col items-center justify-center gap-2 text-center">
        <div className="inline-flex items-center justify-center gap-3 mx-auto">
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center shrink-0">
            <Ticket className="w-5 h-5" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-neutral-900 tracking-tight text-center">
            Coupons Marketplace
          </h1>
        </div>

        {/* Centered Main Sub-Tabs */}
        <div className="inline-flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-neutral-100 rounded-2xl mx-auto mt-1">
          <button
            type="button"
            onClick={() => setActiveTab('browse')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'browse'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>Search Coupons ({allCoupons.filter((c) => c.active).length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('saved')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'saved'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <BookmarkCheck className="w-3.5 h-3.5" />
            <span>Saved Coupons ({activeSavedCoupons.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('issue')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'issue'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Issue Coupons</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'history'
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>History ({redeemedHistoryCoupons.length})</span>
          </button>
        </div>
      </div>

      {/* ======================================================= */}
      {/* TAB 1: SEARCH & SAVE COUPONS                            */}
      {/* ======================================================= */}
      {activeTab === 'browse' && (
        <div className="space-y-6 text-center">
          {/* Centered Search & Filters */}
          <div className="bg-white border border-neutral-200 rounded-3xl p-5 shadow-xs space-y-4 max-w-3xl mx-auto text-center">
            <div className="relative max-w-lg mx-auto">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by code, restaurant, retail store, or driver..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-900 text-center focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="flex flex-wrap items-center justify-center gap-1.5">
              {([
                { id: 'all', label: 'All Categories' },
                { id: 'restaurant', label: 'Restaurants' },
                { id: 'retail', label: 'Retail Stores' },
                { id: 'ride_share', label: 'Ride-Share' },
              ] as const).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCategoryFilter(item.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border cursor-pointer transition-all ${
                    categoryFilter === item.id
                      ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                      : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-center gap-1.5">
              {([
                { id: 'all', label: 'All Channels' },
                { id: 'both', label: 'Online & In-Person' },
                { id: 'online', label: 'Online Usable' },
                { id: 'in_person', label: 'In-Person Usable' },
              ] as const).map((ch) => (
                <button
                  key={ch.id}
                  type="button"
                  onClick={() => setChannelFilter(ch.id)}
                  className={`px-3 py-1 rounded-xl text-[11px] font-bold border cursor-pointer transition-all ${
                    channelFilter === ch.id
                      ? 'bg-neutral-900 text-white border-neutral-900'
                      : 'bg-white text-neutral-600 border-neutral-200 hover:bg-neutral-50'
                  }`}
                >
                  {ch.label}
                </button>
              ))}
            </div>
          </div>

          {/* Coupon Results Grid */}
          {filteredCoupons.length === 0 ? (
            <div className="bg-white border border-neutral-200 rounded-3xl p-10 max-w-lg mx-auto text-center space-y-2">
              <Ticket className="w-8 h-8 text-neutral-400 mx-auto" />
              <p className="text-sm font-bold text-neutral-900">No Matching Coupons Found</p>
              <p className="text-xs text-neutral-500">
                Try clearing your search query or switching category/channel filters.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-center">
              {filteredCoupons.map((coupon) => {
                const isSaved = savedCouponIds.has(coupon.id);
                const isAlreadyRedeemed = !isSaved && redeemedCouponIds.has(coupon.id);
                return (
                  <div
                    key={coupon.id}
                    className="w-full min-w-0 overflow-hidden bg-white border border-neutral-200 rounded-3xl p-5 shadow-xs flex flex-col items-center justify-between gap-4 text-center hover:border-amber-300 transition-colors"
                  >
                    <div className="space-y-2.5 w-full min-w-0 flex flex-col items-center text-center">
                      <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px] font-semibold text-neutral-600">
                        {getCategoryIcon(coupon.category)}
                        <span>{getCategoryLabel(coupon.category)}</span>
                        <span className="text-neutral-300">·</span>
                        <span className="text-emerald-700">{getChannelLabel(coupon.validChannels)}</span>
                      </div>

                      <div className="text-2xl font-mono font-extrabold text-emerald-700 tabular-nums">
                        {coupon.discountType === 'percentage'
                          ? `${coupon.discountValue}% OFF${coupon.currency && coupon.currency !== 'ANY' ? ` (${coupon.currency})` : ''}`
                          : `${coupon.discountValue} ${coupon.currency === 'ANY' ? 'FC' : coupon.currency} OFF`}
                      </div>

                      <div className="w-full min-w-0 space-y-1 text-center">
                        <h3 className="w-full text-sm font-bold text-neutral-900 text-center break-words leading-snug">
                          {coupon.title}
                        </h3>
                        <p className="w-full text-xs font-semibold text-amber-800 text-center break-words">
                          {coupon.merchantName}
                        </p>
                        {coupon.vehicleType && (
                          <p className="w-full text-[11px] font-mono text-indigo-700 text-center break-words">
                            {coupon.vehicleType}
                          </p>
                        )}
                        <p className="w-full text-[11px] text-neutral-500 leading-relaxed text-center break-words">
                          {coupon.description}
                        </p>
                      </div>

                      <div className="flex items-center justify-center gap-2 pt-1">
                        <span className="px-3 py-1 rounded-xl bg-neutral-100 border border-neutral-200 text-xs font-mono font-bold text-neutral-900 tracking-wider">
                          {coupon.code}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopyCode(coupon.code)}
                          className="p-1.5 rounded-xl bg-neutral-50 border border-neutral-200 hover:bg-neutral-100 text-neutral-600 cursor-pointer"
                          title="Copy coupon code"
                        >
                          {copiedCode === coupon.code ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      <p className="text-[10px] font-mono text-neutral-400 tabular-nums text-center">
                        Min {coupon.minOrderAmount} FC · Expires {coupon.expiresAt} · By {coupon.issuerHandle}
                      </p>
                    </div>

                    <div className="w-full space-y-2 pt-2 border-t border-neutral-100 flex flex-col items-center">
                      {isAlreadyRedeemed ? (
                        <div className="w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 bg-neutral-100 border border-neutral-200 text-neutral-500">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Already Claimed (1 Copy Per Coupon)</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleToggleSave(coupon)}
                          className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                            isSaved
                              ? 'bg-emerald-50 border border-emerald-300 text-emerald-800 hover:bg-emerald-100'
                              : 'bg-neutral-900 hover:bg-black text-white'
                          }`}
                        >
                          {isSaved ? (
                            <>
                              <BookmarkCheck className="w-4 h-4" />
                              <span>Saved (1 Copy · Click to Unsave)</span>
                            </>
                          ) : (
                            <>
                              <Bookmark className="w-4 h-4" />
                              <span>Save Coupon</span>
                            </>
                          )}
                        </button>
                      )}

                      {isSaved && (
                        <div className="flex flex-col sm:flex-row gap-2 w-full">
                          {(coupon.validChannels === 'both' || coupon.validChannels === 'online') && (
                            <button
                              type="button"
                              onClick={() => handleUseOnline(coupon)}
                              className="w-full sm:flex-1 py-2 px-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-800 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Globe className="w-3.5 h-3.5 shrink-0" />
                              <span>Use Online</span>
                            </button>
                          )}
                          {(coupon.validChannels === 'both' || coupon.validChannels === 'in_person') && (
                            <button
                              type="button"
                              onClick={() => setInPersonPassCoupon(coupon)}
                              className="w-full sm:flex-1 py-2 px-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <QrCode className="w-3.5 h-3.5 shrink-0" />
                              <span>Use In-Person</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ======================================================= */}
      {/* TAB 2: MY SAVED COUPONS (3 SECTIONS: RETAIL, REST, DRV) */}
      {/* ======================================================= */}
      {activeTab === 'saved' && (
        <div className="space-y-6 max-w-4xl mx-auto text-center">
          {/* 1. Retail */}
          <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
            <div className="inline-flex items-center justify-center gap-1.5 text-sm font-bold text-indigo-800">
              <Store className="w-4 h-4 text-indigo-600" />
              <span>Retail ({savedRetailCoupons.length})</span>
            </div>
            {savedRetailCoupons.length === 0 ? (
              <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                <p className="text-xs text-neutral-500">No saved retail coupons.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                {savedRetailCoupons.map(renderSavedCouponCard)}
              </div>
            )}
          </div>

          {/* 2. Restaurants */}
          <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
            <div className="inline-flex items-center justify-center gap-1.5 text-sm font-bold text-amber-800">
              <UtensilsCrossed className="w-4 h-4 text-amber-600" />
              <span>Restaurants ({savedRestaurantCoupons.length})</span>
            </div>
            {savedRestaurantCoupons.length === 0 ? (
              <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                <p className="text-xs text-neutral-500">No saved restaurant coupons.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                {savedRestaurantCoupons.map(renderSavedCouponCard)}
              </div>
            )}
          </div>

          {/* 3. Driving */}
          <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
            <div className="inline-flex items-center justify-center gap-1.5 text-sm font-bold text-emerald-800">
              <Car className="w-4 h-4 text-emerald-600" />
              <span>Driving ({savedDriverCoupons.length})</span>
            </div>
            {savedDriverCoupons.length === 0 ? (
              <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                <p className="text-xs text-neutral-500">No saved driving coupons.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                {savedDriverCoupons.map(renderSavedCouponCard)}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================= */}
      {/* TAB 3: ISSUE COUPONS (OWNERS & DRIVERS)                 */}
      {/* ======================================================= */}
      {activeTab === 'issue' && (
        <CouponIssuerWidget
          currentUser={currentUser}
          onOpenVerificationModal={onOpenVerificationModal}
          onNavigateToPOS={onNavigateToPOS}
          onNavigateToRideShare={onNavigateToRideShare}
        />
      )}

      {/* ======================================================= */}
      {/* TAB 4: REDEEMED COUPONS HISTORY (RETAIL, REST, DRIVING) */}
      {/* ======================================================= */}
      {activeTab === 'history' && (
        <div className="space-y-6 max-w-4xl mx-auto text-center">
          <div className="space-y-1 text-center">
            <h2 className="text-base font-bold text-neutral-900">
              Redeemed Coupons History ({redeemedHistoryCoupons.length})
            </h2>
          </div>

          {/* 1. Retail */}
          <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
            <div className="inline-flex items-center justify-center gap-1.5 text-sm font-bold text-indigo-800">
              <Store className="w-4 h-4 text-indigo-600" />
              <span>Retail ({redeemedRetailCoupons.length})</span>
            </div>
            {redeemedRetailCoupons.length === 0 ? (
              <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                <p className="text-xs text-neutral-500">No redeemed retail coupons yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                {redeemedRetailCoupons.map(renderRedeemedCouponCard)}
              </div>
            )}
          </div>

          {/* 2. Restaurants */}
          <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
            <div className="inline-flex items-center justify-center gap-1.5 text-sm font-bold text-amber-800">
              <UtensilsCrossed className="w-4 h-4 text-amber-600" />
              <span>Restaurants ({redeemedRestaurantCoupons.length})</span>
            </div>
            {redeemedRestaurantCoupons.length === 0 ? (
              <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                <p className="text-xs text-neutral-500">No redeemed restaurant coupons yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                {redeemedRestaurantCoupons.map(renderRedeemedCouponCard)}
              </div>
            )}
          </div>

          {/* 3. Driving */}
          <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 text-center">
            <div className="inline-flex items-center justify-center gap-1.5 text-sm font-bold text-emerald-800">
              <Car className="w-4 h-4 text-emerald-600" />
              <span>Driving ({redeemedDriverCoupons.length})</span>
            </div>
            {redeemedDriverCoupons.length === 0 ? (
              <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200 text-center">
                <p className="text-xs text-neutral-500">No redeemed driving coupons yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                {redeemedDriverCoupons.map(renderRedeemedCouponCard)}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================= */}
      {/* IN-PERSON COUPON QR PASS MODAL (CENTERED)               */}
      {/* ======================================================= */}
      {inPersonPassCoupon && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl space-y-5 text-center border border-neutral-200">
            <div className="relative flex flex-col items-center justify-center text-center pt-1">
              <button
                type="button"
                onClick={() => setInPersonPassCoupon(null)}
                aria-label="Close modal"
                className="absolute right-0 top-0 w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="inline-flex items-center justify-center gap-1.5 text-xs font-bold text-amber-700 mb-1">
                {getCategoryIcon(inPersonPassCoupon.category)}
                <span>In-Person Coupon Pass</span>
              </div>
              <h3 className="text-lg font-bold text-neutral-900 text-center">
                {inPersonPassCoupon.merchantName}
              </h3>
              <p className="text-xs text-neutral-500 text-center mt-0.5">
                {inPersonPassCoupon.title}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 inline-flex flex-col items-center gap-2 mx-auto">
              <QRCodeSVG
                value={`ff:coupon:${inPersonPassCoupon.code}:${inPersonPassCoupon.id}:${inPersonPassCoupon.category}`}
                size={168}
                level="M"
              />
              <span className="text-sm font-mono font-extrabold text-neutral-900 tracking-widest">
                {inPersonPassCoupon.code}
              </span>
            </div>

            <div className="space-y-1 text-center">
              <p className="text-sm font-mono font-extrabold text-emerald-700 tabular-nums">
                {inPersonPassCoupon.discountType === 'percentage'
                  ? `${inPersonPassCoupon.discountValue}% Off`
                  : `${inPersonPassCoupon.discountValue} ${inPersonPassCoupon.currency === 'ANY' ? 'Final Coins' : inPersonPassCoupon.currency} Off`}
              </p>
              <p className="text-[11px] text-neutral-500 max-w-xs mx-auto">
                Present this QR code or coupon code in person at checkout, or apply it directly in the POS / In-Person Ride Settlement terminal.
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => handleUseInPersonTerminal(inPersonPassCoupon)}
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer flex items-center justify-center gap-1.5"
              >
                <QrCode className="w-4 h-4" />
                <span>
                  {inPersonPassCoupon.category === 'ride_share'
                    ? 'Open Ride-Share In-Person Fare Pay'
                    : 'Open POS In-Person Terminal'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => handleMarkRedeemedInPerson(inPersonPassCoupon)}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Mark Redeemed In-Person Now</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


