export type WalletSectionType = 'barter' | 'final_coins' | 'stable_coins' | 'fiat' | 'crypto';

export interface BarterGoodItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unitLabel: string;
  estimatedUnitValue: number;
  condition: 'Brand New' | 'Mint' | 'Near Mint' | 'Refurbished' | 'Excellent' | 'Certified Vault' | 'Good';
  description: string;
  location?: string;
  sku?: string;
  tags?: string[];
  imageUrl?: string;
}

export interface BarterServiceItem {
  id: string;
  name: string;
  category: string;
  availableUnits: number;
  unitType: 'Hours' | 'Sessions' | 'Consultations' | 'Deliverables' | 'Credits';
  hourlyRateValue: number;
  deliverableDescription: string;
  turnaroundTime: string;
  skills: string[];
}

export interface FinalCoinItem {
  id: string;
  name: string;
  symbol: string;
  balance: number;
  unitPriceUSD: number;
  change24h: number;
  utility: string;
  contractAddress?: string;
  network?: string;
}

export type FinalCoinHoldingItem = FinalCoinItem;

export interface StableCoinItem {
  id: string;
  name: string;
  symbol: string;
  balance: number;
  unitPriceUSD: number;
  peggedCurrency: string;
  yieldAPY: number;
  network: string;
}

export interface FiatCurrencyItem {
  id: string;
  name: string;
  code: string;
  symbol: string;
  balance: number;
  exchangeRateToUSD: number;
  accountType: string;
  institution: string;
}

export interface CryptoCurrencyItem {
  id: string;
  name: string;
  symbol: string;
  balance: number;
  unitPriceUSD: number;
  change24h: number;
  network: string;
  walletAddress?: string;
}

export interface LinkedCardItem {
  id: string;
  cardholderName: string;
  cardNumberLast4: string;
  brand: 'visa' | 'mastercard' | 'amex' | 'discover' | 'unionpay';
  cardType: 'credit' | 'debit';
  expiryMonth: string;
  expiryYear: string;
  bankName?: string;
  isDefault?: boolean;
  addedAt: string;
  billingZip?: string;
}

export interface LinkedBankAccountItem {
  id: string;
  accountHolderName: string;
  bankName: string;
  accountType: 'Checking' | 'Savings' | 'Business Treasury' | 'Escrow Deposit';
  routingNumberMasked: string;
  accountNumberLast4: string;
  currency: 'USD' | 'EUR' | 'GBP' | 'CHF' | 'CAD' | 'AUD' | 'JPY';
  country: string;
  swiftBic?: string;
  isDefault?: boolean;
  status: 'Verified' | 'Instant FedNow Connected' | 'SEPA Instant' | 'Plaid Linked';
  addedAt: string;
  balanceUSD?: number;
}

export interface LinkedCryptoWalletItem {
  id: string;
  walletName: string;
  walletType: 'metamask' | 'phantom' | 'coinbase' | 'walletconnect' | 'ledger' | 'trust' | 'custom';
  address: string;
  network: 'Ethereum' | 'Polygon' | 'Solana' | 'Bitcoin' | 'Base' | 'Arbitrum' | 'Multi-Chain';
  isPrimary?: boolean;
  connectedAt: string;
  balanceUSD?: number;
  ensOrDomain?: string;
}

export interface UserWalletData {
  barterGoods: BarterGoodItem[];
  barterServices: BarterServiceItem[];
  finalCoins: FinalCoinItem[];
  stableCoins: StableCoinItem[];
  fiatCurrencies: FiatCurrencyItem[];
  cryptoCurrencies: CryptoCurrencyItem[];
  linkedCards?: LinkedCardItem[];
  linkedBankAccounts?: LinkedBankAccountItem[];
  linkedCryptoWallets?: LinkedCryptoWalletItem[];
}
