import { CallLog, CallType, CallScope, CallStatus } from '../types/callLog';

const STORAGE_KEY = 'FNL_SOVEREIGN_CALL_LOGS_v3';

const now = Date.now();

const SEED_CALL_LOGS: CallLog[] = [
  {
    id: 'call-log-1',
    type: 'video',
    scope: 'group',
    direction: 'outgoing',
    status: 'completed',
    targetName: 'Global Vault & Escrow Syndicate',
    groupName: 'Global Vault & Escrow Syndicate',
    participantsCount: 4,
    participants: [
      { uid: 'demo-vip-alex', name: 'Alex Morgan', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', role: 'Host' },
      { uid: 'user-lord_sterling', name: 'Lord Sterling', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' },
      { uid: 'user-elena_rostova', name: 'Elena Rostova', avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80' },
      { uid: 'user-marcus_vance', name: 'Marcus Vance', avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80' }
    ],
    initiatedBy: {
      uid: 'demo-vip-alex',
      name: 'Alex Morgan',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
    },
    durationSeconds: 1240, // 20m 40s
    timestamp: new Date(now - 1000 * 60 * 25).toISOString() // 25 mins ago
  },
  {
    id: 'call-log-2',
    type: 'voice',
    scope: 'direct',
    direction: 'outgoing',
    status: 'completed',
    targetName: 'Lord Sterling',
    targetHandle: 'sterling_vault',
    targetAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    targetUid: 'user-lord_sterling',
    participantsCount: 2,
    initiatedBy: {
      uid: 'demo-vip-alex',
      name: 'Alex Morgan'
    },
    durationSeconds: 372, // 6m 12s
    timestamp: new Date(now - 1000 * 60 * 120).toISOString() // 2 hours ago
  },
  {
    id: 'call-log-3',
    type: 'video',
    scope: 'direct',
    direction: 'incoming',
    status: 'completed',
    targetName: 'Elena Rostova',
    targetHandle: 'elena_rostova',
    targetAvatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    targetUid: 'user-elena_rostova',
    participantsCount: 2,
    initiatedBy: {
      uid: 'user-elena_rostova',
      name: 'Elena Rostova',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80'
    },
    durationSeconds: 765, // 12m 45s
    timestamp: new Date(now - 1000 * 60 * 60 * 26).toISOString() // Yesterday
  },
  {
    id: 'call-log-4',
    type: 'voice',
    scope: 'direct',
    direction: 'incoming',
    status: 'missed',
    targetName: 'Chief Audit Officer',
    targetHandle: 'officer_dbz',
    targetAvatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    targetUid: 'demo-admin-officer',
    participantsCount: 2,
    initiatedBy: {
      uid: 'demo-admin-officer',
      name: 'Chief Audit Officer',
      avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80'
    },
    durationSeconds: 0,
    timestamp: new Date(now - 1000 * 60 * 60 * 30).toISOString() // Yesterday morning
  },
  {
    id: 'call-log-5',
    type: 'voice',
    scope: 'direct',
    direction: 'outgoing',
    status: 'completed',
    targetName: 'Marcus Vance',
    targetHandle: 'marcus_vance',
    targetAvatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    targetUid: 'user-marcus_vance',
    participantsCount: 2,
    initiatedBy: {
      uid: 'demo-vip-alex',
      name: 'Alex Morgan'
    },
    durationSeconds: 270, // 4m 30s
    timestamp: new Date(now - 1000 * 60 * 60 * 72).toISOString() // 3 days ago
  }
];

let callLogsStore: CallLog[] = [];
const subscribers: Array<(logs: CallLog[]) => void> = [];

function loadFromStorage(): CallLog[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load call logs from storage', err);
  }
  // Initialize with seed data
  saveToStorage(SEED_CALL_LOGS);
  return SEED_CALL_LOGS;
}

function saveToStorage(logs: CallLog[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(logs));
  } catch (err) {
    console.error('Failed to save call logs to storage', err);
  }
}

function notifySubscribers() {
  subscribers.forEach((cb) => cb([...callLogsStore]));
}

// Initialize on module load
callLogsStore = loadFromStorage();

export function getCallLogs(): CallLog[] {
  return [...callLogsStore].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function addCallLog(
  log: Omit<CallLog, 'id' | 'timestamp'> & { timestamp?: string }
): CallLog {
  const newEntry: CallLog = {
    id: `call-log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: log.timestamp || new Date().toISOString(),
    ...log,
  };

  callLogsStore = [newEntry, ...callLogsStore];
  saveToStorage(callLogsStore);
  notifySubscribers();
  return newEntry;
}

export function deleteCallLog(id: string): void {
  callLogsStore = callLogsStore.filter((c) => c.id !== id);
  saveToStorage(callLogsStore);
  notifySubscribers();
}

export function clearCallLogs(): void {
  callLogsStore = [];
  saveToStorage([]);
  notifySubscribers();
}

export function resetToDefaultLogs(): void {
  callLogsStore = [...SEED_CALL_LOGS];
  saveToStorage(callLogsStore);
  notifySubscribers();
}

export function subscribeToCallLogs(callback: (logs: CallLog[]) => void): () => void {
  subscribers.push(callback);
  callback(getCallLogs());

  return () => {
    const idx = subscribers.indexOf(callback);
    if (idx !== -1) {
      subscribers.splice(idx, 1);
    }
  };
}
