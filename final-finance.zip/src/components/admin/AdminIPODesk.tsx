import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  User, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Scale, 
  Coins, 
  TrendingUp, 
  DollarSign, 
  FileText, 
  ShieldAlert, 
  Check, 
  X, 
  Search, 
  Globe, 
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Info,
  Film,
  Play,
  Activity
} from 'lucide-react';
import { IPORequest, IPOStatus, IPOMediaItem } from '../../types/stocks';
import { 
  getStoredIPORequests, 
  adminApproveIPO, 
  adminRejectIPO, 
  adminApproveDelist, 
  adminRejectDelist,
  getLiveIPOValuation,
  IPO_UPDATED_EVENT
} from '../../data/stocksData';
import { useApp } from '../../context/AppContext';
import { ConfirmModal } from '../common/ConfirmModal';

interface AdminIPODeskProps {
  onNotify?: (msg: string, type?: 'success' | 'warning' | 'error') => void;
}

export const AdminIPODesk: React.FC<AdminIPODeskProps> = ({ onNotify }) => {
  const { addTransaction } = useApp();
  const [ipos, setIpos] = useState<IPORequest[]>(() => getStoredIPORequests());
  const [searchQuery, setSearchQuery] = useState('');
  const [subTab, setSubTab] = useState<'pending' | 'delists' | 'active' | 'archive'>('pending');
  const [expandedIpoId, setExpandedIpoId] = useState<string | null>(null);
  const [rejectionNotes, setRejectionNotes] = useState<{ [id: string]: string }>({});
  const [activeRejectId, setActiveRejectId] = useState<string | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    type: 'info' | 'warning' | 'danger';
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
    type: 'info'
  });

  const refreshIPOs = () => {
    setIpos(getStoredIPORequests());
  };

  useEffect(() => {
    window.addEventListener(IPO_UPDATED_EVENT, refreshIPOs);
    window.addEventListener('storage', refreshIPOs);
    return () => {
      window.removeEventListener(IPO_UPDATED_EVENT, refreshIPOs);
      window.removeEventListener('storage', refreshIPOs);
    };
  }, []);

  const pendingLaunchIPOs = ipos.filter((i) => i.status === 'pending_admin_approval');
  const pendingDelistIPOs = ipos.filter((i) => i.status === 'delist_pending_admin_approval');
  const activeIPOs = ipos.filter((i) => i.status === 'active');
  const archivedIPOs = ipos.filter((i) => i.status === 'rejected' || i.status === 'delisted');

  const handleApproveLaunch = (ipo: IPORequest) => {
    setConfirmModal({
      isOpen: true,
      title: 'Authorize IPO Launch',
      message: `Are you sure you want to approve the IPO for ${ipo.equityName} ($${ipo.ticker})? This will list the security on the public exchange with a target valuation of $${ipo.targetValuationUSD.toLocaleString()}.`,
      type: 'info',
      onConfirm: () => {
        const success = adminApproveIPO(ipo.id);
        if (success) {
          refreshIPOs();
          
          addTransaction({
            taxYear: 2024,
            type: 'ipo',
            category: 'trade',
            mode: 'final_coin',
            title: `IPO Authorization: ${ipo.equityName}`,
            description: `Primary issuance of ${ipo.sharesOffered.toLocaleString()} shares of $${ipo.ticker} @ $${ipo.offeringPriceUSD}/share.`,
            amountUSD: ipo.targetValuationUSD,
            feeUSD: ipo.targetValuationUSD * 0.02, // 2% protocol listing fee
            netAmountUSD: ipo.targetValuationUSD,
            sourceOrDestination: ipo.issuerName,
            counterpartyOrIssuer: 'Global Stock Exchange',
            issuerHandle: ipo.issuerHandle || ipo.ticker,
            status: 'Settled',
            clearingNode: 'ADMIN-EXCHANGE-01',
            taxClassification: {
              formMapping: 'Securities Issuance',
              taxableEvent: true,
              taxableAmountUSD: ipo.targetValuationUSD,
              irsCategoryNote: 'Primary capital formation'
            }
          });

          if (onNotify) {
            onNotify(`IPO for $${ipo.ticker} (${ipo.equityName}) approved and listed on public stock exchange!`, 'success');
          }
        }
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleRejectLaunch = (ipo: IPORequest) => {
    const notes = rejectionNotes[ipo.id] || 'Did not fulfill sovereign compliance or capital backing verification requirements.';
    setConfirmModal({
      isOpen: true,
      title: 'Reject IPO Application',
      message: `Are you sure you want to REJECT the IPO for ${ipo.equityName}? This action is final and will notify the issuer.`,
      type: 'warning',
      onConfirm: () => {
        const success = adminRejectIPO(ipo.id, notes);
        if (success) {
          setActiveRejectId(null);
          refreshIPOs();
          if (onNotify) {
            onNotify(`IPO application for $${ipo.ticker} has been rejected.`, 'warning');
          }
        }
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleApproveDelist = (ipo: IPORequest) => {
    setConfirmModal({
      isOpen: true,
      title: 'Confirm Delisting Action',
      message: `Are you sure you want to delist $${ipo.ticker} from the market? This will suspend all trading activity for this security.`,
      type: 'danger',
      onConfirm: () => {
        const success = adminApproveDelist(ipo.id);
        if (success) {
          refreshIPOs();
          if (onNotify) {
            onNotify(`Stock $${ipo.ticker} has been delisted from the stock market.`, 'success');
          }
        }
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleRejectDelist = (ipo: IPORequest) => {
    const notes = rejectionNotes[ipo.id] || 'Delisting request denied by Admin to protect ongoing public shareholder liquidity.';
    setConfirmModal({
      isOpen: true,
      title: 'Deny Delisting Request',
      message: `Are you sure you want to deny the delisting request for $${ipo.ticker}? The stock will remain active in the market.`,
      type: 'info',
      onConfirm: () => {
        const success = adminRejectDelist(ipo.id, notes);
        if (success) {
          setActiveRejectId(null);
          refreshIPOs();
          if (onNotify) {
            onNotify(`Delisting request for $${ipo.ticker} was denied. Stock remains listed.`, 'warning');
          }
        }
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const toggleExpand = (id: string) => {
    setExpandedIpoId(expandedIpoId === id ? null : id);
  };

  return (
    <div className="space-y-6 text-left">
      
      {/* 1. HEADER & SUMMARY METRICS */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-2xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="font-serif text-lg font-bold text-slate-900">
                IPO &amp; Public Equities Governance Desk
              </h2>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-200">
                Protocol Authority
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Audit and authorize Personal Sovereign Equities (backed by 5-mode net worth &amp; Final Coins) and Corporate Business IPOs.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200/70 text-right">
              <span className="text-[10px] uppercase font-mono text-amber-700 block">Pending Reviews</span>
              <span className="text-lg font-mono font-bold text-amber-900 block">
                {pendingLaunchIPOs.length + pendingDelistIPOs.length} Requests
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200/70 text-right">
              <span className="text-[10px] uppercase font-mono text-emerald-700 block">Listed Equities</span>
              <span className="text-lg font-mono font-bold text-emerald-900 block">
                {activeIPOs.length} Active
              </span>
            </div>
          </div>
        </div>

        {/* 2. SUB-TABS */}
        <div className="pt-2 flex border-b border-slate-100 gap-3 overflow-x-auto text-xs font-bold">
          <button
            type="button"
            onClick={() => setSubTab('pending')}
            className={`pb-3 transition-all flex items-center gap-2 cursor-pointer border-b-2 whitespace-nowrap ${
              subTab === 'pending'
                ? 'border-amber-600 text-amber-800'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4 text-amber-600" />
            <span>Pending IPO Launches</span>
            <span className="px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-mono">
              {pendingLaunchIPOs.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('delists')}
            className={`pb-3 transition-all flex items-center gap-2 cursor-pointer border-b-2 whitespace-nowrap ${
              subTab === 'delists'
                ? 'border-rose-600 text-rose-800'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <ShieldAlert className="w-4 h-4 text-rose-600" />
            <span>Delisting Requests</span>
            <span className="px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-mono">
              {pendingDelistIPOs.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('active')}
            className={`pb-3 transition-all flex items-center gap-2 cursor-pointer border-b-2 whitespace-nowrap ${
              subTab === 'active'
                ? 'border-emerald-600 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Active Market Equities</span>
            <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-mono">
              {activeIPOs.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('archive')}
            className={`pb-3 transition-all flex items-center gap-2 cursor-pointer border-b-2 whitespace-nowrap ${
              subTab === 'archive'
                ? 'border-slate-800 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4 text-slate-500" />
            <span>Rejected &amp; Archived</span>
            <span className="px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[10px] font-mono">
              {archivedIPOs.length}
            </span>
          </button>
        </div>
      </div>

      {/* ================= SUB-TAB 1: PENDING LAUNCHES ================= */}
      {subTab === 'pending' && (
        <div className="space-y-4">
          {pendingLaunchIPOs.length === 0 ? (
            <div className="p-10 text-center rounded-3xl bg-white border border-slate-200 space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="font-serif text-base font-bold text-slate-900">
                IPO Launch Review Queue is Clear
              </h3>
              <p className="text-xs text-slate-500">
                All submitted Personal and Business IPO applications have been processed.
              </p>
            </div>
          ) : (
            pendingLaunchIPOs.map((ipo) => {
              const isPersonal = ipo.ipoType === 'personal';
              const personal = ipo.personalDetails;
              const business = ipo.businessDetails;
              const isExpanded = expandedIpoId === ipo.id;

              return (
                <div
                  key={ipo.id}
                  className="p-5 sm:p-6 rounded-3xl bg-white border border-amber-200/80 shadow-2xs space-y-4"
                >
                  {/* Top Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-base shadow-2xs ${
                        isPersonal 
                          ? 'bg-amber-500/15 text-amber-700 border border-amber-500/30' 
                          : 'bg-indigo-500/15 text-indigo-700 border border-indigo-500/30'
                      }`}>
                        {isPersonal ? '👤' : '🏢'}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-serif text-base font-bold text-slate-900">
                            {ipo.equityName}
                          </h3>
                          <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                            ${ipo.ticker}
                          </span>
                          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                            ⏳ Pending Audit
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                          <span className="font-semibold">
                            {isPersonal ? '👤 Personal Sovereign Human Equity' : `🏢 Corporate IPO (${business?.legalStructure || 'C-Corp'})`}
                          </span>
                          <span>&bull;</span>
                          <span>Issuer: {ipo.issuerName}</span>
                          <span>&bull;</span>
                          <span className="text-[11px] font-mono text-slate-400">
                            Submitted: {new Date(ipo.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => toggleExpand(ipo.id)}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
                    >
                      <span>{isExpanded ? 'Collapse Prospectus' : 'Inspect Prospectus'}</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {/* Financial & Solvency Quick Strip */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase block">Target Valuation</span>
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        ${(ipo.targetValuationUSD / 1e6).toFixed(2)}M USD
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase block">Offering Price</span>
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        ${ipo.offeringPriceUSD.toFixed(2)} / share
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase block">Shares to Issue</span>
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        {ipo.sharesOffered.toLocaleString()}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase block">Backing Asset</span>
                      <span className="font-bold text-indigo-700 text-xs">
                        {isPersonal 
                          ? `⚡ ${personal?.backingFinalCoinName || personal?.backingFinalCoinSymbol}` 
                          : `🪙 ${business?.backingCoinName || business?.backingCoinSymbol}`}
                      </span>
                    </div>
                  </div>

                  {/* EXPANDED PROSPECTUS AUDIT DATA */}
                  {isExpanded && (
                    <div className="p-4 rounded-2xl bg-slate-100/60 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-4 animate-in fade-in duration-150 text-xs">
                      {isPersonal && personal && (
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 font-bold text-slate-900">
                            <User className="w-4 h-4 text-amber-600" />
                            <span>Sovereign Identity &amp; Personality Audit</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-white p-3 rounded-xl border border-slate-200">
                            <div>
                              <span className="text-[10px] text-slate-400 block">Full Legal / Sovereign Name</span>
                              <span className="font-semibold text-slate-800">{personal.fullName} ({personal.handle})</span>
                            </div>

                            <div>
                              <span className="text-[10px] text-slate-400 block">Core Profession</span>
                              <span className="font-semibold text-slate-800">{personal.profession}</span>
                            </div>
                          </div>

                          {personal.personalityTraits && (
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="text-[11px] font-bold text-slate-500">Verified Traits:</span>
                              {personal.personalityTraits.map((t) => (
                                <span key={t} className="px-2 py-0.5 rounded-lg bg-amber-100 text-amber-900 font-semibold text-[10px]">
                                  {t}
                                </span>
                              ))}
                            </div>
                          )}

                          <div className="bg-white p-3 rounded-xl border border-slate-200">
                            <span className="text-[10px] text-slate-400 block font-mono">Persona Bio &amp; Pitch</span>
                            <p className="text-slate-700 mt-1 italic">"{personal.personaProfile}"</p>
                          </div>

                          {/* 5-Mode Net Worth Solvency Audit */}
                          {personal.fiveModeNetWorth && (
                            <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-amber-950 flex items-center gap-1.5">
                                  <Scale className="w-4 h-4 text-amber-600" />
                                  <span>5-Mode Net Worth Verification (Total NAV: ${personal.fiveModeNetWorth.totalNetWorthUSD.toLocaleString()} USD)</span>
                                </span>
                                <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                                  Solvency Ratio: {((personal.fiveModeNetWorth.totalNetWorthUSD / ipo.targetValuationUSD) * 100).toFixed(0)}%
                                </span>
                              </div>

                              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[10px] font-mono">
                                <div className="p-2 bg-white rounded-lg border border-amber-200">
                                  <span className="text-slate-400 block">1. Fiat USD</span>
                                  <span className="font-bold text-slate-800">${(personal.fiveModeNetWorth.fiatUSD / 1e6).toFixed(2)}M</span>
                                </div>
                                <div className="p-2 bg-white rounded-lg border border-amber-200">
                                  <span className="text-slate-400 block">2. Sovereign Gold</span>
                                  <span className="font-bold text-slate-800">${(personal.fiveModeNetWorth.sovereignGoldBarter / 1e6).toFixed(2)}M</span>
                                </div>
                                <div className="p-2 bg-white rounded-lg border border-amber-200">
                                  <span className="text-slate-400 block">3. Final Coins</span>
                                  <span className="font-bold text-slate-800">${(personal.fiveModeNetWorth.finalCoins / 1e6).toFixed(2)}M</span>
                                </div>
                                <div className="p-2 bg-white rounded-lg border border-amber-200">
                                  <span className="text-slate-400 block">4. Stablecoins</span>
                                  <span className="font-bold text-slate-800">${(personal.fiveModeNetWorth.stableCoins / 1e6).toFixed(2)}M</span>
                                </div>
                                <div className="p-2 bg-white rounded-lg border border-amber-200">
                                  <span className="text-slate-400 block">5. Crypto Assets</span>
                                  <span className="font-bold text-slate-800">${(personal.fiveModeNetWorth.cryptoAssets / 1e6).toFixed(2)}M</span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {!isPersonal && business && (
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 font-bold text-slate-900">
                            <Building2 className="w-4 h-4 text-indigo-600" />
                            <span>Corporate Commercial Audit</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-3 rounded-xl border border-slate-200">
                            <div>
                              <span className="text-[10px] text-slate-400 block">Legal Entity &amp; Sector</span>
                              <span className="font-semibold text-slate-800">{business.companyName} ({business.legalStructure})</span>
                              <div className="text-[10px] text-slate-500">{business.sector} &bull; {business.industry}</div>
                            </div>

                            <div>
                              <span className="text-[10px] text-slate-400 block">Registration &amp; HQ</span>
                              <span className="font-semibold text-slate-800">{business.registrationNumber}</span>
                              <div className="text-[10px] text-slate-500">{business.headquarters}</div>
                            </div>

                            <div>
                              <span className="text-[10px] text-slate-400 block">Executive Leadership</span>
                              <span className="font-semibold text-slate-800">CEO: {business.executives.ceo}</span>
                              {business.executives.cto && <div className="text-[10px] text-slate-500">CTO: {business.executives.cto}</div>}
                            </div>
                          </div>

                          {/* Financials Strip */}
                          <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <div>
                              <span className="text-[10px] text-indigo-600 uppercase font-mono block">Annual Revenue</span>
                              <span className="font-mono font-bold text-slate-900">${(business.annualRevenueUSD / 1e6).toFixed(2)}M USD</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-indigo-600 uppercase font-mono block">Net Margin</span>
                              <span className="font-mono font-bold text-slate-900">{business.netProfitMarginPercent}%</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-indigo-600 uppercase font-mono block">Projected Growth</span>
                              <span className="font-mono font-bold text-slate-900">+{business.projectedGrowthPercent}% YoY</span>
                            </div>
                          </div>

                          <div className="bg-white p-3 rounded-xl border border-slate-200">
                            <span className="text-[10px] text-slate-400 block font-mono">Business Model &amp; Moat</span>
                            <p className="text-slate-700 mt-1 italic">"{business.businessModel}"</p>
                          </div>
                        </div>
                      )}

                      {/* ATTACHED PHOTOS & VIDEOS AUDIT */}
                      {((ipo.mediaGallery && ipo.mediaGallery.length > 0) || 
                        (isPersonal && personal?.mediaGallery && personal.mediaGallery.length > 0) || 
                        (!isPersonal && business?.mediaGallery && business.mediaGallery.length > 0)) && (
                        <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                          <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                            <Film className="w-4 h-4 text-purple-600" />
                            <span>Submitted Visual Media &amp; Pitch Assets</span>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                            {(ipo.mediaGallery || (isPersonal ? personal?.mediaGallery : business?.mediaGallery) || []).map((m) => (
                              <div key={m.id} className="relative rounded-xl overflow-hidden bg-slate-900 border border-slate-200 aspect-video flex flex-col justify-end p-1.5">
                                {m.type === 'video' ? (
                                  <video src={m.url} controls className="absolute inset-0 w-full h-full object-cover" preload="metadata" />
                                ) : (
                                  <img src={m.url} alt={m.title || 'media'} className="absolute inset-0 w-full h-full object-cover" />
                                )}
                                <span className="relative z-10 text-[8px] font-mono font-bold bg-black/80 text-white px-1.5 py-0.5 rounded self-start">
                                  {m.type === 'video' ? '🎬 VIDEO' : '📷 PHOTO'} {m.isCover ? '• COVER' : ''}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Rejection input if active */}
                  {activeRejectId === ipo.id && (
                    <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-2 text-xs">
                      <label className="block font-bold text-rose-900">
                        Specify Reason for Rejection:
                      </label>
                      <input
                        type="text"
                        value={rejectionNotes[ipo.id] || ''}
                        onChange={(e) => setRejectionNotes({ ...rejectionNotes, [ipo.id]: e.target.value })}
                        placeholder="e.g. Incomplete 5-mode net worth documentation, insufficient backing collateral..."
                        className="w-full px-3 py-2 rounded-xl border border-rose-300 bg-white text-slate-900 text-xs"
                      />
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setActiveRejectId(null)}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 font-semibold cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRejectLaunch(ipo)}
                          className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold cursor-pointer"
                        >
                          Confirm Rejection
                        </button>
                      </div>
                    </div>
                  )}

                  {/* ACTION CONTROLS */}
                  {activeRejectId !== ipo.id && (
                    <div className="pt-2 flex items-center justify-end gap-3">
                      <button
                        type="button"
                        onClick={() => setActiveRejectId(ipo.id)}
                        className="px-4 py-2 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Reject Application</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApproveLaunch(ipo)}
                        className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve &amp; List on Stock Exchange</span>
                      </button>
                    </div>
                  )}

                </div>
              );
            })
          )}
        </div>
      )}

      {/* ================= SUB-TAB 2: DELISTING REQUESTS ================= */}
      {subTab === 'delists' && (
        <div className="space-y-4">
          {pendingDelistIPOs.length === 0 ? (
            <div className="p-10 text-center rounded-3xl bg-white border border-slate-200 space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="font-serif text-base font-bold text-slate-900">
                No Pending Delisting Requests
              </h3>
              <p className="text-xs text-slate-500">
                All equities currently in circulation are in healthy trading order.
              </p>
            </div>
          ) : (
            pendingDelistIPOs.map((ipo) => (
              <div
                key={ipo.id}
                className="p-5 sm:p-6 rounded-3xl bg-white border border-rose-200 shadow-2xs space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-rose-300 flex items-center justify-center font-bold text-rose-700">
                      <ShieldAlert className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-serif text-base font-bold text-slate-900">
                          {ipo.equityName}
                        </h3>
                        <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                          ${ipo.ticker}
                        </span>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-900">
                          ⚠️ Delist Requested
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        Market: {ipo.marketWay.toUpperCase()} &bull; Market Valuation: ${(ipo.targetValuationUSD / 1e6).toFixed(2)}M USD
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-950 space-y-1">
                  <span className="font-bold block">Issuer's Reason for Delisting:</span>
                  <p className="italic">"{ipo.delistReason}"</p>
                </div>

                {/* Actions */}
                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => handleRejectDelist(ipo)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
                  >
                    Deny Delist (Keep Listed)
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApproveDelist(ipo)}
                    className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Approve Delisting (Remove from Stock Market)</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* ================= SUB-TAB 3: ACTIVE MARKET EQUITIES ================= */}
      {subTab === 'active' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {activeIPOs.map((ipo) => {
              const liveVal = getLiveIPOValuation(ipo);
              return (
                <div
                  key={ipo.id}
                  className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center font-bold">
                      {ipo.ipoType === 'personal' ? '👤' : '🏢'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{ipo.equityName}</span>
                        <span className="font-mono font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">${ipo.ticker}</span>
                        <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">Active</span>
                      </div>
                      <div className="text-slate-500 text-[11px] mt-0.5">
                        {ipo.ipoType === 'personal' ? 'Personal Sovereign Equity' : 'Corporate Enterprise IPO'} &bull; Initial Target: ${(ipo.targetValuationUSD / 1e6).toFixed(2)}M USD
                      </div>
                    </div>
                  </div>

                  {/* Real-time live worth badge */}
                  <div className="flex items-center gap-4 bg-emerald-50/60 border border-emerald-200 px-3 py-2 rounded-xl">
                    <div>
                      <span className="text-[9px] font-mono uppercase text-emerald-800 block">Live Price</span>
                      <span className="font-mono font-bold text-slate-900">${liveVal.livePrice.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-mono uppercase text-emerald-800 block">Live Cap</span>
                      <span className="font-mono font-bold text-slate-900">${(liveVal.currentMarketCap / 1e6).toFixed(2)}M</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-mono uppercase text-emerald-800 block">24h Gain</span>
                      <span className={`font-mono font-bold ${liveVal.changePercent >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {liveVal.changePercent >= 0 ? '+' : ''}{liveVal.changePercent.toFixed(2)}%
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleApproveDelist(ipo)}
                      className="px-3 py-1.5 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-bold transition-all cursor-pointer"
                    >
                      Admin Delist Action
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= SUB-TAB 4: ARCHIVE & REJECTED ================= */}
      {subTab === 'archive' && (
        <div className="space-y-4">
          {archivedIPOs.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-white border border-slate-200 text-xs text-slate-500">
              No archived or rejected IPO records found.
            </div>
          ) : (
            archivedIPOs.map((ipo) => (
              <div
                key={ipo.id}
                className="p-4 rounded-2xl bg-white border border-slate-200 text-xs flex items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{ipo.equityName} (${ipo.ticker})</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-bold uppercase">
                      {ipo.status}
                    </span>
                  </div>
                  {ipo.adminNotes && (
                    <p className="text-slate-500 mt-1 italic text-[11px]">
                      Reason: "{ipo.adminNotes}"
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Archive Section Footer */}
      <div className="h-4" />

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        type={confirmModal.type}
      />
    </div>
  );
};
