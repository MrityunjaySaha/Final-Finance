export interface AdminSelfGrantAttachment {
  type: 'image' | 'video';
  url: string;
  name: string;
}

export interface AdminSelfGrantRecord {
  id: string;
  adminId: string;
  adminUid?: string;
  adminName: string;
  adminHandle: string;
  adminEmail: string;
  adminRole: 'admin' | 'super_admin';
  grantName: string;
  description: string;
  amountAFNL: number;
  date: string;
  timestampIso: string;
  mediaAttachments?: AdminSelfGrantAttachment[];
  status: 'Granted';
}

export const ADMIN_SELF_GRANTS_STORAGE_KEY = 'final_finance_admin_self_grants_v1';
export const ADMIN_SELF_GRANTS_UPDATED_EVENT = 'final_finance_admin_self_grants_updated';

export function getAdminSelfGrants(): AdminSelfGrantRecord[] {
  try {
    const raw = localStorage.getItem(ADMIN_SELF_GRANTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function recordAdminSelfGrant(
  grant: Omit<AdminSelfGrantRecord, 'id' | 'timestampIso' | 'date' | 'status'> & {
    id?: string;
    date?: string;
    timestampIso?: string;
  }
): AdminSelfGrantRecord {
  const now = new Date();
  const entry: AdminSelfGrantRecord = {
    id: grant.id || `admin-grant-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    adminId: grant.adminId,
    adminUid: grant.adminUid,
    adminName: grant.adminName,
    adminHandle: grant.adminHandle.startsWith('@') ? grant.adminHandle : `@${grant.adminHandle}`,
    adminEmail: grant.adminEmail,
    adminRole: grant.adminRole,
    grantName: grant.grantName,
    description: grant.description,
    amountAFNL: grant.amountAFNL,
    date: grant.date || now.toISOString().split('T')[0],
    timestampIso: grant.timestampIso || now.toISOString(),
    mediaAttachments: grant.mediaAttachments,
    status: 'Granted',
  };

  try {
    const existing = getAdminSelfGrants();
    const next = [entry, ...existing.filter((item) => item.id !== entry.id)];
    localStorage.setItem(ADMIN_SELF_GRANTS_STORAGE_KEY, JSON.stringify(next));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent(ADMIN_SELF_GRANTS_UPDATED_EVENT, { detail: entry })
      );
    }
  } catch (e) {
    console.warn('Failed to persist admin self grant record:', e);
  }

  return entry;
}
