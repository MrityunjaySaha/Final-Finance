import React, { useMemo, useState, useEffect } from 'react';
import { StockItem } from '../../types/stocks';
import { Tweet, TweetSharedPost, TweetLinkPreview } from '../../types/tweet';
import {
  ExternalLinkPreviewData,
  extractExternalUrls,
  buildInitialLinkPreview,
  fetchExternalLinkPreview,
} from '../../utils/linkPreviewUtils';
import { INITIAL_STOCKS, getAllActiveMarketStocks } from '../../data/stocksData';
import { isFinalStock, formatFinalStockTagPrice } from '../../utils/stockCurrencyFormatter';
import { useApp } from '../../context/AppContext';
import { getAllMarketplaceListings } from '../../services/marketplaceService';
import { areUsersBlockedEitherWay, isUserBlockedByTarget, getUserProfile, isAdminAccount, isCurrentSessionAdmin } from '../../services/socialService';
import { getAverageRating } from '../../services/ratingService';
import {
  getAverageRatingForListing,
  getReviewsForListing,
  POST_RATINGS_UPDATED_EVENT
} from '../../services/postRatingService';
import {
  Package,
  Briefcase,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  Coins,
  ExternalLink,
  Cpu,
  Landmark,
  ShieldCheck,
  Sparkles,
  Video as VideoIcon,
  Star,
  Users,
  MessageSquare,
  Gavel,
  Play,
  Pencil,
  Check,
  RotateCcw
} from 'lucide-react';

export interface RichEmbedPerson {
  uid: string;
  userId: string;
  name: string;
  avatarUrl: string;
  bio?: string;
  isVerified?: boolean;
  followersCount?: number;
  role?: string;
}

interface TweetRichEmbedsProps {
  content: string;
  mentions?: string[];
  tickers?: string[];
  stockCurrencies?: Record<string, string>;
  sharedPost?: TweetSharedPost;
  quotedTweet?: Tweet;
  savedLinkPreviews?: Record<string, TweetLinkPreview>;
  onLinkPreviewsResolved?: (previews: Record<string, ExternalLinkPreviewData>) => void;
  editableLinks?: boolean;
  onEditLinkPreview?: (url: string, override: Partial<ExternalLinkPreviewData> | null) => void;
  knownPeople?: RichEmbedPerson[];
  currentUserId?: string;
  onOpenSharedListing?: (listingId: string) => void;
  onSelectStock?: (stock: StockItem) => void;
  onViewUserProfile?: (user: string | { uid: string; userId: string; name: string; avatarUrl?: string }) => void;
  compact?: boolean;
}

const FALLBACK_DIRECTORY_PEOPLE: RichEmbedPerson[] = [
  {
    uid: 'user-lord_sterling',
    userId: 'sterling_vault',
    name: 'Lord Sterling',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Swiss Freeport Trustee & Gold Bullion Syndicate Master',
    isVerified: true,
  },
  {
    uid: 'demo-alex-morgan',
    userId: 'alex_morgan',
    name: 'Alex Morgan',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Institutional Commodity Desk Arbiter & Smart Contract Auditor',
    isVerified: true,
  },
  {
    uid: 'creator_alex_chen',
    userId: 'alex_chen',
    name: 'Alex Chen',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    bio: 'Quantitative System Architect & AI Research Fellow',
    isVerified: true,
  },
  {
    uid: 'demo-satoshi-nakamoto',
    userId: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Pioneer of Sovereign Digital Cash & Autonomous Barter Networks',
    isVerified: true,
  },
  {
    uid: 'creator_satoshi',
    userId: 'satoshi',
    name: 'Satoshi Nakamoto',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    bio: 'Decentralized Sovereign Infrastructure',
    isVerified: true,
  },
  {
    uid: 'user-elena_rostova',
    userId: 'elena_rostova',
    name: 'Elena Rostova',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    bio: 'Zurich Gold Bullion & Global Maritime Barter Broker',
    isVerified: true,
  },
  {
    uid: 'creator_elena',
    userId: 'elena',
    name: 'Elena Rostova',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    bio: 'Zurich Gold Bullion & Vault Custody Desk',
    isVerified: true,
  },
  {
    uid: 'demo-jordan-belfort',
    userId: 'jordan_belfort',
    name: 'Jordan Belfort',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Chief Reserve Allocator at Final Finance',
    isVerified: true,
  },
  {
    uid: 'user-marcus_vance',
    userId: 'marcus_vance',
    name: 'Marcus Vance',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Quantitative Barter Arbitrageur & Bitcoin Custodian',
    isVerified: true,
  },
  {
    uid: 'quant_trader_mark',
    userId: 'vance_capital',
    name: 'Marcus Vance',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    bio: 'Macro Portfolio & Sovereign Equities Strategist',
    isVerified: false,
  },
  {
    uid: 'user-gholu653',
    userId: 'gholu653',
    name: 'Gholu',
    avatarUrl: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    bio: 'Sovereign Marketplace & Equities Participant',
    isVerified: true,
  },
];

function getStockLogoTheme(stock: StockItem) {
  const sector = (stock.sector || '').toLowerCase();
  if (sector.includes('gold') || sector.includes('commodit') || stock.marketType === 'final') {
    return {
      bg: 'bg-gradient-to-br from-amber-500 to-amber-700 text-slate-950',
      Icon: Coins,
    };
  }
  if (sector.includes('tech') || sector.includes('semiconductor')) {
    return {
      bg: 'bg-gradient-to-br from-indigo-600 to-slate-900 text-white',
      Icon: Cpu,
    };
  }
  if (sector.includes('bank') || sector.includes('treasur') || stock.marketType === 'stable') {
    return {
      bg: 'bg-gradient-to-br from-emerald-600 to-teal-900 text-white',
      Icon: Landmark,
    };
  }
  if (stock.marketType === 'crypto') {
    return {
      bg: 'bg-gradient-to-br from-violet-600 to-slate-900 text-white',
      Icon: Sparkles,
    };
  }
  return {
    bg: 'bg-gradient-to-br from-slate-800 to-slate-950 text-amber-300',
    Icon: ShieldCheck,
  };
}

const ExternalLinkCard: React.FC<{
  link: ExternalLinkPreviewData;
  editable?: boolean;
  onEdit?: (url: string, override: Partial<ExternalLinkPreviewData> | null) => void;
}> = ({ link, editable, onEdit }) => {
  const [activeImageUrl, setActiveImageUrl] = useState<string | undefined>(link.imageUrl);
  const [imageHidden, setImageHidden] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [draftTitle, setDraftTitle] = useState(link.title);
  const [draftImage, setDraftImage] = useState(link.imageUrl || '');

  useEffect(() => {
    setActiveImageUrl(link.imageUrl);
    setImageHidden(false);
  }, [link.imageUrl]);

  useEffect(() => {
    if (!isEditing) {
      setDraftTitle(link.title);
      setDraftImage(link.imageUrl || '');
    }
  }, [link.title, link.imageUrl, isEditing]);

  const handleImageFallback = () => {
    if (link.fallbackImageUrl && activeImageUrl !== link.fallbackImageUrl) {
      setActiveImageUrl(link.fallbackImageUrl);
    } else {
      setImageHidden(true);
    }
  };

  const isVideo = link.mediaType === 'video';
  const showImage = Boolean(activeImageUrl) && !imageHidden;

  return (
    <div className="rounded-3xl border border-slate-200/90 bg-white hover:border-emerald-300 transition-all overflow-hidden shadow-2xs group text-left my-2">
      <a
        href={link.url}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => {
          e.stopPropagation();
        }}
        className="block"
      >
        {showImage && (
          <div
            className={`w-full overflow-hidden bg-slate-950 relative ${
              isVideo ? 'aspect-video' : 'aspect-[1.91/1] max-h-72'
            }`}
          >
            <img
              src={activeImageUrl}
              alt={link.title}
              referrerPolicy="no-referrer"
              onLoad={(e) => {
                // YouTube serves a 120x90 gray placeholder when maxresdefault.jpg does not exist
                if (
                  link.videoId &&
                  e.currentTarget.naturalWidth <= 120 &&
                  link.fallbackImageUrl &&
                  activeImageUrl !== link.fallbackImageUrl
                ) {
                  setActiveImageUrl(link.fallbackImageUrl);
                }
              }}
              onError={handleImageFallback}
              className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
            />
            {isVideo && (
              <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent pointer-events-none flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-black/75 border border-white/25 text-white flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                  <Play className="w-5 h-5 fill-white ml-0.5" />
                </div>
              </div>
            )}
            <div className="absolute bottom-2.5 left-3 px-2.5 py-0.5 rounded-md bg-black/75 backdrop-blur-sm text-white font-mono text-[10px] font-semibold border border-white/15">
              {link.siteName || link.domain}
            </div>
          </div>
        )}
        <div className="p-4 space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-emerald-700 font-semibold min-w-0">
              <ExternalLink className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">
                {link.siteName || link.domain}
                {link.authorName ? ` · ${link.authorName}` : ''}
              </span>
            </div>
            {link.isLoading && (
              <span className="text-[10px] font-mono text-slate-400 shrink-0">Resolving…</span>
            )}
          </div>
          {link.isLoading && link.title.startsWith('Loading') ? (
            <div className="h-4 w-3/4 bg-slate-200 rounded animate-pulse" />
          ) : (
            <h4 className="font-bold text-slate-900 group-hover:text-emerald-700 transition-colors text-xs sm:text-sm line-clamp-2 leading-snug">
              {link.title}
            </h4>
          )}
          {link.description && (
            <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
              {link.description}
            </p>
          )}
        </div>
      </a>

      {editable && onEdit && (
        <div
          className="px-4 py-2 border-t border-slate-100 bg-slate-50/70"
          onClick={(e) => e.stopPropagation()}
        >
          {!isEditing ? (
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-500 truncate">
                {link.resolved ? 'Precise preview loaded' : 'Preview ready — customize if needed'}
              </span>
              <button
                type="button"
                onClick={() => setIsEditing(true)}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Pencil className="w-3 h-3" />
                <span>Refine Title / Thumbnail</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2 py-1">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
                  Precise Title
                </label>
                <input
                  type="text"
                  value={draftTitle}
                  onChange={(e) => setDraftTitle(e.target.value)}
                  placeholder="Enter exact video or article title"
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
                  Thumbnail Image URL
                </label>
                <input
                  type="url"
                  value={draftImage}
                  onChange={(e) => setDraftImage(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-0.5">
                <button
                  type="button"
                  onClick={() => {
                    onEdit(link.url, null);
                    setIsEditing(false);
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium text-slate-600 hover:bg-slate-200/70 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const cleanImg = draftImage.trim();
                    onEdit(link.url, {
                      title: draftTitle.trim() || link.title,
                      imageUrl: cleanImg && /^https?:\/\//i.test(cleanImg) ? cleanImg : link.imageUrl,
                      resolved: true,
                    });
                    setIsEditing(false);
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[11px] font-semibold bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer"
                >
                  <Check className="w-3 h-3" />
                  <span>Apply</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export const TweetRichEmbeds: React.FC<TweetRichEmbedsProps> = ({
  content,
  mentions = [],
  tickers = [],
  stockCurrencies,
  sharedPost,
  quotedTweet,
  savedLinkPreviews,
  onLinkPreviewsResolved,
  editableLinks = false,
  onEditLinkPreview,
  knownPeople = [],
  currentUserId = '',
  onOpenSharedListing,
  onSelectStock,
  onViewUserProfile,
  compact = false,
}) => {
  const { listings } = useApp();
  const [asyncResolvedProfiles, setAsyncResolvedProfiles] = useState<Record<string, RichEmbedPerson>>({});
  const [resolvedLinkMap, setResolvedLinkMap] = useState<Record<string, ExternalLinkPreviewData>>({});
  const [ratingsVersion, setRatingsVersion] = useState(0);

  useEffect(() => {
    const sync = () => setRatingsVersion((v) => v + 1);
    window.addEventListener(POST_RATINGS_UPDATED_EVENT, sync);
    window.addEventListener('final_finance_custom_coins_updated', sync);
    window.addEventListener('final_finance_ipo_updated', sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(POST_RATINGS_UPDATED_EVENT, sync);
      window.removeEventListener('final_finance_custom_coins_updated', sync);
      window.removeEventListener('final_finance_ipo_updated', sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  // 1. Resolve shared marketplace Goods / Services links from tweet text
  const embeddedListings = useMemo(() => {
    if (!content) return [];
    const urlMatches = content.match(/https?:\/\/[^\s]+/gi) || [];
    const listingIds: string[] = [];
    urlMatches.forEach((rawUrl) => {
      try {
        const parsed = new URL(rawUrl);
        const paramId = parsed.searchParams.get('listing');
        if (paramId && !listingIds.includes(paramId)) {
          listingIds.push(paramId);
        }
      } catch {}
    });

    if (listingIds.length === 0) return [];
    const serviceListings = getAllMarketplaceListings();

    return listingIds
      .map((id) => {
        const appItem = listings.find((l) => l.id === id);
        const svcItem = serviceListings.find((l) => l.id === id);
        if (!appItem && !svcItem) return null;

        const merged: any = { ...svcItem, ...appItem };
        const mediaPhoto = Array.isArray(merged.mediaList)
          ? merged.mediaList.find((m: any) => m?.type === 'image' && m?.url)?.url
          : undefined;
        const primaryPhoto =
          merged.imageUrl ||
          (Array.isArray(merged.photos) && merged.photos[0]) ||
          mediaPhoto ||
          '';
        const hasVideo = Boolean(
          merged.videoUrl ||
            merged.video ||
            (Array.isArray(merged.videos) && merged.videos.length > 0) ||
            (Array.isArray(merged.mediaList) && merged.mediaList.some((m: any) => m?.type === 'video'))
        );
        const priceUSD =
          typeof merged.priceUSD === 'number'
            ? merged.priceUSD
            : merged.primaryPriceUSD ?? merged.estimatedValueUSD ?? 0;
        const nativePrice =
          merged.priceInNative ||
          (merged.finalCoinsPricing?.amount
            ? `${merged.finalCoinsPricing.amount.toLocaleString()} ${merged.finalCoinsPricing.symbol}`
            : undefined);
        const isService =
          merged.itemType === 'service' || String(merged.category).toLowerCase() === 'services';

        return {
          id: merged.id || id,
          title: merged.title || 'Marketplace Listing',
          imageUrl: primaryPhoto,
          hasVideo,
          isService,
          category: merged.category || (isService ? 'Service' : 'Product'),
          priceUSD,
          nativePrice,
          acceptedCurrencies: Array.isArray(merged.acceptedCurrencyList) ? merged.acceptedCurrencyList : [],
          sellerName: merged.sellerName || merged.creatorName || 'Verified Seller',
          sellerHandle: String(merged.sellerHandle || merged.creatorHandle || merged.sellerId || '').replace(/^@/, ''),
          listingIntent: merged.listingIntent,
        };
      })
      .filter((x): x is NonNullable<typeof x> => Boolean(x));
  }, [content, listings]);

  // 2. Resolve tagged Final Stocks (from ?stock= URLs, F:TICKER / ₣TICKER in text, + tickers array)
  const embeddedStocks = useMemo(() => {
    const stockUrlTickers: string[] = [];
    if (content) {
      const urls = content.match(/https?:\/\/[^\s]+/gi) || [];
      urls.forEach((raw) => {
        try {
          const u = new URL(raw);
          const stockParam = u.searchParams.get('stock');
          if (stockParam) {
            stockUrlTickers.push(stockParam.replace(/^(?:[Ff]:|[₣$])/, '').trim().toUpperCase());
          }
        } catch {}
      });
    }

    const tokenMatches = content.match(/(?:^|[\s(])(?:[Ff]:|₣)([a-zA-Z][a-zA-Z0-9_-]{0,16})/g) || [];
    const tokenTickers = tokenMatches.map((t) =>
      t.replace(/^[\s(]*(?:[Ff]:|₣)/, '').toUpperCase()
    );
    const allTickers = Array.from(
      new Set([
        ...stockUrlTickers,
        ...tokenTickers,
        ...(tickers || []).map((t) => t.replace(/^(?:[Ff]:|[₣$])/, '').toUpperCase()),
      ])
    );
    if (allTickers.length === 0) return [];

    // Include ONLY Final Stocks (settled in Final Currency, never fiat/stable/crypto/USD)
    let customStocks: StockItem[] = [];
    try {
      const savedStocks = localStorage.getItem('final_finance_stocks');
      if (savedStocks) {
        const parsed = JSON.parse(savedStocks);
        if (Array.isArray(parsed)) customStocks = parsed;
      }
    } catch {}
    const pool = [...customStocks, ...getAllActiveMarketStocks(), ...INITIAL_STOCKS].filter((s) =>
      isFinalStock(s)
    );

    return allTickers
      .map((tk) => pool.find((s) => s.ticker.toUpperCase() === tk))
      .filter((s): s is StockItem => Boolean(s));
  }, [content, tickers, ratingsVersion]);

  // 3. Resolve tagged @USERS and shared ?profile= / ?user= links
  const profileLinkTargets = useMemo(() => {
    if (!content) return [] as string[];
    const urls = content.match(/https?:\/\/[^\s]+/gi) || [];
    const targets: string[] = [];
    urls.forEach((raw) => {
      try {
        const u = new URL(raw);
        const param = u.searchParams.get('profile') || u.searchParams.get('user');
        if (param) {
          targets.push(param.replace(/^@/, '').trim());
        }
      } catch {}
    });
    return targets;
  }, [content]);

  // Async resolve any profile links or mentions not found in synchronous lookup
  React.useEffect(() => {
    const candidates = Array.from(
      new Set([
        ...profileLinkTargets,
        ...(content.match(/@[a-zA-Z0-9_]+/g) || []).map((h) => h.slice(1)),
      ])
    );
    if (candidates.length === 0) return;

    let active = true;
    candidates.forEach(async (idOrHandle) => {
      const key = idOrHandle.toLowerCase();
      if (asyncResolvedProfiles[key]) return;
      try {
        const p = await getUserProfile(idOrHandle);
        if (!active || !p) return;
        setAsyncResolvedProfiles((prev) => ({
          ...prev,
          [key]: {
            uid: p.uid,
            userId: p.userId,
            name: p.name,
            avatarUrl:
              p.avatarUrl ||
              `https://ui-avatars.com/api/?name=${encodeURIComponent(p.name)}&background=059669&color=fff`,
            bio: p.bio,
            isVerified: p.role === 'admin' || p.role === 'super_admin' || true,
            followersCount: p.followersCount,
            role: p.role,
          },
        }));
      } catch {}
    });
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profileLinkTargets.join(','), content]);

  const embeddedUsers = useMemo(() => {
    const tokenHandles = (content.match(/@[a-zA-Z0-9_]+/g) || []).map((h) =>
      h.slice(1).toLowerCase()
    );
    const allTargets = Array.from(
      new Set([
        ...profileLinkTargets.map((p) => p.toLowerCase()),
        ...tokenHandles,
        ...(mentions || []).map((m) => m.replace(/^@/, '').toLowerCase()),
      ])
    );
    if (allTargets.length === 0) return [];

    const directoryMap = new Map<string, RichEmbedPerson>();
    const addPerson = (p: RichEmbedPerson) => {
      const cleanHandle = p.userId.replace(/^@/, '').toLowerCase();
      const cleanUid = (p.uid || '').replace(/^@/, '').toLowerCase();
      if (cleanHandle) directoryMap.set(cleanHandle, p);
      if (cleanUid) directoryMap.set(cleanUid, p);
    };

    FALLBACK_DIRECTORY_PEOPLE.forEach(addPerson);
    knownPeople.forEach((p) => addPerson({ ...p, userId: p.userId.replace(/^@/, '') }));
    Object.values(asyncResolvedProfiles).forEach(addPerson);

    // Include marketplace listing creators so tagging or linking any seller shows their photo & name
    listings.forEach((l) => {
      const clean = String(l.sellerHandle || l.sellerId || '').replace(/^@/, '');
      if (clean) {
        addPerson({
          uid: l.sellerId || clean,
          userId: clean,
          name: l.sellerName || clean,
          avatarUrl:
            l.sellerAvatar ||
            `https://ui-avatars.com/api/?name=${encodeURIComponent(l.sellerName || clean)}&background=0f172a&color=fff`,
          isVerified: l.sellerVerified,
        });
      }
    });

    // Check registered & custom profiles in localStorage synchronously
    try {
      const storedReg = localStorage.getItem('final_finance_registered_users');
      if (storedReg) {
        const regList = JSON.parse(storedReg);
        if (Array.isArray(regList)) {
          regList.forEach((u: any) => {
            const handle = String(u.userId || u.id || '').replace(/^@/, '');
            if (handle) {
              addPerson({
                uid: u.uid || u.id || handle,
                userId: handle,
                name: u.name || handle,
                avatarUrl:
                  u.avatarUrl ||
                  `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name || handle)}&background=059669&color=fff`,
                bio: u.bio,
                isVerified: u.role === 'admin' || u.role === 'super_admin' || u.isVerified,
                followersCount: u.followersCount,
                role: u.role,
              });
            }
          });
        }
      }
    } catch {}

    try {
      const customProfilesRaw = localStorage.getItem('final_finance_custom_profiles_map');
      if (customProfilesRaw) {
        const customMap = JSON.parse(customProfilesRaw);
        Object.values(customMap || {}).forEach((u: any) => {
          if (u && (u.userId || u.uid)) {
            const existing = directoryMap.get(String(u.userId || u.uid).toLowerCase());
            addPerson({
              ...existing,
              uid: u.uid || existing?.uid || u.userId,
              userId: String(u.userId || existing?.userId || u.uid).replace(/^@/, ''),
              name: u.name || existing?.name || u.userId,
              avatarUrl: u.avatarUrl || existing?.avatarUrl || '',
              bio: u.bio || existing?.bio,
              isVerified: existing?.isVerified ?? true,
              followersCount: u.followersCount ?? existing?.followersCount,
            });
          }
        });
      }
    } catch {}

    const seenKeys = new Set<string>();
    const results: RichEmbedPerson[] = [];
    allTargets.forEach((key) => {
      const viewerIsAdmin = isAdminAccount(currentUserId) || isCurrentSessionAdmin();
      if (
        !viewerIsAdmin &&
        currentUserId &&
        (areUsersBlockedEitherWay(currentUserId, key) || isUserBlockedByTarget(currentUserId, key))
      ) {
        return;
      }
      const match = directoryMap.get(key);
      if (match) {
        const dedupeKey = match.userId.toLowerCase();
        if (!seenKeys.has(dedupeKey)) {
          seenKeys.add(dedupeKey);
          results.push(match);
        }
      }
    });
    return results;
  }, [content, mentions, knownPeople, listings, currentUserId, profileLinkTargets, asyncResolvedProfiles]);

  const sharedPostLiveData = useMemo(() => {
    if (!sharedPost) return null;
    const liveAvg = getAverageRatingForListing(sharedPost.listingId);
    const liveReviews = getReviewsForListing(sharedPost.listingId);
    const avg = liveAvg.count > 0 ? liveAvg.average : sharedPost.averageRating;
    const count = liveAvg.count > 0 ? liveAvg.count : sharedPost.ratingCount;
    const reviews =
      liveReviews.length > 0
        ? liveReviews.map((r) => ({
            reviewerName: r.reviewerName,
            reviewerAvatar: r.reviewerAvatar,
            rating: r.rating,
            comment: r.comment,
          }))
        : sharedPost.comments || [];
    return { avg, count, reviews };
  }, [sharedPost, ratingsVersion]);

  const externalUrls = useMemo(() => extractExternalUrls(content), [content]);

  useEffect(() => {
    if (externalUrls.length === 0) return;
    let active = true;

    externalUrls.forEach((url) => {
      const saved = savedLinkPreviews?.[url];
      if (saved && saved.resolved) return;
      const alreadyResolved = resolvedLinkMap[url];
      if (alreadyResolved && !alreadyResolved.isLoading) return;

      fetchExternalLinkPreview(url).then((data) => {
        if (!active) return;
        setResolvedLinkMap((prev) => {
          const next = { ...prev, [url]: data };
          if (onLinkPreviewsResolved) {
            onLinkPreviewsResolved(next);
          }
          return next;
        });
      });
    });

    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalUrls.join('|')]);

  const externalLinks = useMemo<ExternalLinkPreviewData[]>(() => {
    return externalUrls.map((url) => {
      const saved = savedLinkPreviews?.[url];
      if (saved && saved.title) {
        return { ...saved, isLoading: false };
      }
      if (resolvedLinkMap[url]) {
        return resolvedLinkMap[url];
      }
      return buildInitialLinkPreview(url);
    });
  }, [externalUrls, savedLinkPreviews, resolvedLinkMap]);

  if (!sharedPost && !quotedTweet && embeddedListings.length === 0 && embeddedStocks.length === 0 && embeddedUsers.length === 0 && externalLinks.length === 0) {
    return null;
  }

  return (
    <div className={`space-y-2.5 w-full max-w-xl mx-auto ${compact ? 'pt-1' : ''}`}>
      {/* 0. Retweeted / Embedded Original Tweet Card */}
      {quotedTweet && (() => {
        const firstQuotedLink = quotedTweet.linkPreviews ? Object.values(quotedTweet.linkPreviews)[0] : undefined;
        const previewImg =
          quotedTweet.photos?.[0] ||
          quotedTweet.sharedPost?.imageUrl ||
          firstQuotedLink?.imageUrl ||
          firstQuotedLink?.fallbackImageUrl;
        const previewVideo = (quotedTweet.videos && quotedTweet.videos[0]) || quotedTweet.video;

        return (
          <div
            role="button"
            tabIndex={0}
            onClick={(e) => {
              e.stopPropagation();
              window.dispatchEvent(new CustomEvent('open_tweeting_feed', { detail: { tweetId: quotedTweet.id } }));
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                e.stopPropagation();
                window.dispatchEvent(new CustomEvent('open_tweeting_feed', { detail: { tweetId: quotedTweet.id } }));
              }
            }}
            className="rounded-2xl border border-slate-200 hover:border-emerald-300 bg-slate-50/90 p-3.5 sm:p-4 space-y-2.5 text-left shadow-2xs transition-colors cursor-pointer"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <img
                  src={quotedTweet.authorAvatar}
                  alt={quotedTweet.authorName}
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-full object-cover border border-slate-200 shrink-0"
                />
                <span className="font-bold text-xs text-slate-900 truncate">{quotedTweet.authorName}</span>
                {quotedTweet.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                <span className="text-[11px] font-mono text-slate-500 truncate">@{quotedTweet.authorHandle}</span>
              </div>
              <span className="text-[11px] text-slate-400 shrink-0">{quotedTweet.timestamp}</span>
            </div>

            {quotedTweet.content && (
              <p className="text-xs text-slate-800 line-clamp-3 leading-relaxed whitespace-pre-line">
                {quotedTweet.content}
              </p>
            )}

            {quotedTweet.tradeReceipt && (
              <div className="px-3 py-2 rounded-xl bg-white border border-emerald-200/80 text-[11px] font-mono text-slate-700 flex items-center justify-between gap-2">
                <span className="font-bold text-emerald-800">
                  {quotedTweet.tradeReceipt.side.toUpperCase()} {quotedTweet.tradeReceipt.shares} {quotedTweet.tradeReceipt.ticker}
                </span>
                <span className="tabular-nums text-slate-600">
                  {quotedTweet.tradeReceipt.totalValue.toLocaleString(undefined, { maximumFractionDigits: 2 })} {quotedTweet.tradeReceipt.coinLabel}
                </span>
              </div>
            )}

            {quotedTweet.poll && (
              <div className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-[11px] text-slate-600 font-medium">
                Poll · {quotedTweet.poll.options.length} options · {quotedTweet.poll.totalVotes} votes
              </div>
            )}

            {previewImg && (
              <div className="relative h-36 rounded-xl overflow-hidden bg-slate-950 flex items-center justify-center">
                <img
                  src={previewImg}
                  alt={quotedTweet.sharedPost?.title || `Media from @${quotedTweet.authorHandle}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                {quotedTweet.sharedPost && (
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-3 py-2 text-white">
                    <p className="text-[11px] font-semibold truncate">{quotedTweet.sharedPost.title}</p>
                  </div>
                )}
              </div>
            )}

            {!previewImg && previewVideo && (
              <div className="relative h-36 rounded-xl overflow-hidden bg-black border border-slate-200 flex items-center justify-center">
                <video src={previewVideo} muted playsInline preload="metadata" className="w-full h-full object-cover opacity-80" />
                <span className="absolute inset-0 flex items-center justify-center">
                  <span className="w-9 h-9 rounded-full bg-black/75 border border-white/30 text-white flex items-center justify-center">
                    <Play className="w-4 h-4 fill-white ml-0.5" />
                  </span>
                </span>
              </div>
            )}
          </div>
        );
      })()}

      {/* External Link Previews (Precise Title & Thumbnail) */}
      {externalLinks.map((link) => (
        <ExternalLinkCard
          key={link.url}
          link={link}
          editable={editableLinks}
          onEdit={onEditLinkPreview}
        />
      ))}
      {/* 0. Full Shared Marketplace / Transacted Item / Campaign Card */}
      {sharedPost && sharedPostLiveData && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            if (sharedPost.listingId) {
              if (sharedPost.itemType === 'campaign' || sharedPost.listingId.startsWith('camp-')) {
                window.dispatchEvent(new CustomEvent('open_shared_campaign', { detail: sharedPost.listingId }));
              } else if (sharedPost.itemType === 'retail' || sharedPost.itemType === 'restaurant') {
                window.dispatchEvent(new CustomEvent('open_shared_pos_item', {
                  detail: {
                    itemId: sharedPost.listingId,
                    locationId: sharedPost.locationId,
                    itemType: sharedPost.itemType,
                  },
                }));
              } else if (onOpenSharedListing) {
                onOpenSharedListing(sharedPost.listingId);
              } else {
                window.dispatchEvent(new CustomEvent('open_shared_listing', { detail: sharedPost.listingId }));
              }
            }
          }}
          className="rounded-3xl overflow-hidden border border-neutral-200 hover:border-amber-400 bg-white transition-all cursor-pointer shadow-2xs text-left"
        >
          {/* Media Header */}
          <div className="relative h-48 w-full bg-neutral-950 overflow-hidden">
            {sharedPost.imageUrl ? (
              <img
                src={sharedPost.imageUrl}
                alt={sharedPost.title}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-neutral-500">
                {sharedPost.itemType === 'service' ? (
                  <Briefcase className="w-8 h-8" />
                ) : sharedPost.itemType === 'auction' ? (
                  <Gavel className="w-8 h-8" />
                ) : (
                  <Package className="w-8 h-8" />
                )}
              </div>
            )}
            <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg bg-emerald-600 text-white border border-emerald-400 uppercase">
                {sharedPost.channelLabel || sharedPost.statusLabel || 'ACTIVE'}
              </span>
              <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg uppercase ${
                sharedPost.itemType === 'campaign'
                  ? 'bg-sky-600 text-white border border-sky-400'
                  : sharedPost.itemType === 'retail'
                  ? 'bg-indigo-600 text-white border border-indigo-400'
                  : sharedPost.itemType === 'restaurant'
                  ? 'bg-amber-600 text-white border border-amber-400'
                  : 'bg-purple-700 text-white border border-purple-400'
              }`}>
                {sharedPost.itemType || 'good'}
              </span>
            </div>
            {sharedPost.sellerHandle && (
              <div className="absolute top-2.5 right-2.5">
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md text-amber-300 border border-white/20">
                  @{sharedPost.sellerHandle.replace(/^@/, '')}
                </span>
              </div>
            )}
          </div>

          {/* Card Content */}
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between gap-2 text-[11px] text-neutral-500 font-mono flex-wrap">
              <span className="uppercase font-bold text-neutral-700">
                {sharedPost.category || 'Marketplace'}
                {sharedPost.locationName ? ` • ${sharedPost.locationName}` : ''}
              </span>
              <span className="text-emerald-700 font-bold">
                {sharedPost.itemType === 'campaign' ? 'Target: ' : ''}
                {sharedPost.currencySymbol === 'FC' || sharedPost.itemType === 'campaign'
                  ? `F ${Number(sharedPost.priceUSD || 0).toLocaleString()} ${sharedPost.currencySymbol || 'FC'}`
                  : sharedPost.currencySymbol
                  ? `${Number(sharedPost.priceUSD || 0).toLocaleString()} ${sharedPost.currencySymbol}`
                  : `$${Number(sharedPost.priceUSD || 0).toLocaleString()} USD`}
              </span>
            </div>

            <div>
              <h4 className="font-serif-lux text-base font-bold text-neutral-900 tracking-tight">
                {sharedPost.title}
              </h4>
              {sharedPost.description && (
                <p className="text-xs text-neutral-600 mt-1 leading-relaxed">
                  {sharedPost.description}
                </p>
              )}
              {sharedPost.acceptedCurrencies && sharedPost.acceptedCurrencies.length > 0 && (
                <p className="text-[11px] font-mono font-semibold text-emerald-700 mt-1.5">
                  Accepts ({sharedPost.acceptedCurrencies.length}/5): {sharedPost.acceptedCurrencies.join(', ')}
                </p>
              )}
            </div>

            {/* Campaign Trust Badge vs Product Rating Box */}
            {sharedPost.itemType === 'campaign' ? (
              <div className="p-2.5 rounded-2xl bg-emerald-50/80 border border-emerald-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-emerald-800 font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Audited Escrow Vault · Final Currency Only</span>
                </div>
                <span className="text-[10px] font-mono font-bold text-emerald-700 bg-white px-2 py-0.5 rounded-md border border-emerald-200">
                  Verified
                </span>
              </div>
            ) : (sharedPost.itemType === 'retail' || sharedPost.itemType === 'restaurant') ? (
              <div className="p-2.5 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center justify-between gap-2 text-xs">
                <span className="font-semibold text-neutral-800 truncate">
                  {sharedPost.itemType === 'restaurant' ? 'Served at: ' : 'Sold at: '}
                  {sharedPost.locationName || sharedPost.sellerName || 'Merchant'}
                </span>
                <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 shrink-0">
                  {sharedPost.channelLabel || 'Final Currency POS'}
                </span>
              </div>
            ) : (
              (sharedPostLiveData.count > 0 || typeof sharedPost.userRating === 'number' || typeof sharedPost.averageRating === 'number') && (
                <div className="p-2.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex items-center text-amber-500">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={`w-3.5 h-3.5 ${
                            s <= Math.round(sharedPostLiveData.avg || sharedPost.userRating || 5)
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-neutral-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="font-mono text-xs font-bold text-neutral-900">
                      {sharedPostLiveData.count > 0
                        ? sharedPostLiveData.avg.toFixed(1)
                        : (sharedPost.userRating ? sharedPost.userRating.toFixed(1) : '5.0')}
                    </span>
                    <span className="text-[11px] text-neutral-500 font-mono">
                      ({sharedPostLiveData.count} {sharedPostLiveData.count === 1 ? 'rating' : 'ratings'})
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-900 font-semibold">
                    Post Rating
                  </span>
                </div>
              )
            )}

            {/* Sharer's Specific Rating & Comment if included */}
            {(typeof sharedPost.userRating === 'number' || sharedPost.userComment) && (
              <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-800">
                    Buyer Rating &amp; Review
                  </span>
                  {typeof sharedPost.userRating === 'number' && (
                    <div className="flex items-center gap-1.5">
                      <div className="flex items-center text-amber-400">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`w-3.5 h-3.5 ${
                              s <= (sharedPost.userRating || 5) ? 'fill-amber-400 text-amber-400' : 'text-neutral-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs font-mono font-bold text-neutral-800">
                        {sharedPost.userRating} / 5 Stars
                      </span>
                    </div>
                  )}
                </div>
                {sharedPost.userComment && (
                  <p className="text-xs text-neutral-700 italic leading-relaxed">
                    &ldquo;{sharedPost.userComment}&rdquo;
                  </p>
                )}
              </div>
            )}

            {/* All Comments Involved */}
            {sharedPostLiveData.reviews.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-700">
                  <MessageSquare className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Comments ({sharedPostLiveData.reviews.length})</span>
                </div>
                <div className="space-y-1.5">
                  {sharedPostLiveData.reviews.slice(0, 4).map((rev, idx) => (
                    <div key={idx} className="p-2 rounded-xl bg-neutral-50 border border-neutral-100 text-xs">
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <div className="flex items-center gap-1.5">
                          {rev.reviewerAvatar ? (
                            <img src={rev.reviewerAvatar} alt="" className="w-4 h-4 rounded-full object-cover" />
                          ) : (
                            <div className="w-4 h-4 rounded-full bg-neutral-300 text-[9px] flex items-center justify-center font-bold">
                              {rev.reviewerName.charAt(0)}
                            </div>
                          )}
                          <span className="font-bold text-[11px] text-neutral-800">{rev.reviewerName}</span>
                        </div>
                        <div className="flex items-center text-amber-500 text-[10px]">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-2.5 h-2.5 ${s <= rev.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-200'}`}
                            />
                          ))}
                        </div>
                      </div>
                      {rev.comment && (
                        <p className="text-[11px] text-neutral-600 italic">
                          &ldquo;{rev.comment}&rdquo;
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 1. Shared Goods / Service Rich Link Cards */}
      {embeddedListings.map((item) => (
        <div
          key={`embed-listing-${item.id}`}
          onClick={(e) => {
            e.stopPropagation();
            if (onOpenSharedListing) {
              onOpenSharedListing(item.id);
            } else {
              window.dispatchEvent(new CustomEvent('open_shared_listing', { detail: item.id }));
            }
          }}
          className="rounded-2xl overflow-hidden border border-slate-200 hover:border-amber-400 bg-slate-50/90 hover:bg-amber-50/30 transition-all cursor-pointer shadow-2xs group text-center"
        >
          {item.imageUrl ? (
            <div className="relative bg-slate-950 overflow-hidden flex items-center justify-center">
              <img
                src={item.imageUrl}
                alt={item.title}
                className={compact ? 'w-full max-h-44 object-contain' : 'w-full max-h-64 object-contain group-hover:scale-[1.01] transition-transform duration-300'}
              />
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase shadow-xs ${
                    item.isService
                      ? 'bg-indigo-950/90 text-indigo-100'
                      : 'bg-slate-900/90 text-amber-200'
                  }`}
                >
                  {item.isService ? <Briefcase className="w-3 h-3" /> : <Package className="w-3 h-3" />}
                  <span>{item.isService ? 'Service' : 'Good'}</span>
                </span>
                {item.hasVideo && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/80 text-white text-[10px] font-mono">
                    <VideoIcon className="w-3 h-3" />
                    <span>Video</span>
                  </span>
                )}
              </div>
            </div>
          ) : (
            <div className="py-5 bg-slate-900 text-amber-300 flex items-center justify-center gap-2 text-xs font-mono">
              {item.isService ? <Briefcase className="w-5 h-5" /> : <Package className="w-5 h-5" />}
              <span>{item.isService ? 'Service Listing' : 'Product Listing'}</span>
            </div>
          )}

          <div className="p-3.5 sm:p-4 space-y-2 text-center">
            <div className="flex items-center justify-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-slate-500">
              <span>{String(item.category).replace(/_/g, ' ')}</span>
              {item.listingIntent === 'buy' && (
                <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 font-bold">
                  Wanted
                </span>
              )}
              <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-amber-600" />
            </div>

            <h4 className="font-serif text-sm sm:text-base font-bold text-slate-900 group-hover:text-amber-800 transition-colors leading-snug">
              {item.title}
            </h4>

            {/* Prices */}
            <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 pt-0.5">
              <span className="font-mono text-sm font-black text-amber-700">
                ${Number(item.priceUSD || 0).toLocaleString()} USD
              </span>
              {item.nativePrice && (
                <span className="font-mono text-xs font-bold text-slate-700 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                  {item.nativePrice}
                </span>
              )}
            </div>

            {item.acceptedCurrencies.length > 0 && (
              <div className="flex flex-wrap items-center justify-center gap-1 pt-0.5">
                {item.acceptedCurrencies.map((cur: string) => (
                  <span
                    key={cur}
                    className="px-2 py-0.5 rounded-md bg-amber-50 border border-amber-200/80 text-[10px] font-mono font-bold text-amber-900"
                  >
                    {cur}
                  </span>
                ))}
              </div>
            )}

            <p className="text-[11px] text-slate-500">
              Listed by <span className="font-semibold text-slate-700">{item.sellerName}</span>
            </p>
          </div>
        </div>
      ))}

      {/* 2. Tagged $STOCKS Cards (Logo, Title/Name, Ticker & Value) */}
      {embeddedStocks.length > 0 && (
        <div className={`grid gap-2 ${embeddedStocks.length === 1 ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}>
          {embeddedStocks.map((stock) => {
            const isPos = stock.changePercent >= 0;
            const theme = getStockLogoTheme(stock);
            const ThemeIcon = theme.Icon;
            return (
              <div
                key={`embed-stock-${stock.ticker}`}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onSelectStock) {
                    onSelectStock(stock);
                  } else {
                    window.dispatchEvent(new CustomEvent('open_shared_stock', { detail: stock.ticker }));
                  }
                }}
                className="p-3.5 rounded-2xl border border-emerald-200/80 bg-gradient-to-b from-white to-emerald-50/40 hover:border-emerald-400 transition-all shadow-2xs flex flex-col items-center justify-center text-center gap-2 cursor-pointer"
              >
                {/* Stock Logo */}
                {stock.issuerAvatar ? (
                  <img
                    src={stock.issuerAvatar}
                    alt={stock.name}
                    className="w-10 h-10 rounded-xl object-cover border border-emerald-200 shadow-2xs"
                  />
                ) : (
                  <div className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center font-mono font-black text-[10px] shadow-2xs ${theme.bg}`}>
                    <ThemeIcon className="w-4 h-4 mb-0.5" />
                    <span className="leading-none text-[8px]">{stock.ticker.slice(0, 4)}</span>
                  </div>
                )}

                {/* Title & Ticker */}
                <div className="space-y-0.5">
                  <div className="flex items-center justify-center gap-1.5 flex-wrap">
                    <span className="font-bold text-xs sm:text-sm text-slate-900">{stock.name}</span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 border border-emerald-200 font-mono font-bold text-[11px] text-emerald-900">
                      F:{stock.ticker}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 font-mono">
                    {stock.sector} • {stock.exchange}
                  </p>
                </div>

                {/* Stock Value & Change */}
                <div className="flex items-center justify-center gap-2.5 flex-wrap pt-0.5">
                  <span className="font-mono text-sm sm:text-base font-black text-slate-900">
                    {formatFinalStockTagPrice(
                      stock.price,
                      stock,
                      stockCurrencies?.[stock.ticker.toUpperCase()]
                    )}
                  </span>
                  <span
                    className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[11px] font-mono font-bold ${
                      isPos
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {isPos ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    <span>
                      {isPos ? '+' : ''}
                      {stock.changePercent.toFixed(2)}%
                    </span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 3. Tagged or Shared @USERS Profile Cards (Photo, Name, Handle, Followers, Rating, Bio) */}
      {embeddedUsers.length > 0 && (
        <div className={`grid gap-2 ${embeddedUsers.length === 1 ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}>
          {embeddedUsers.map((person) => {
            const ratingInfo = getAverageRating(person.userId);
            return (
              <div
                key={`embed-user-${person.userId}`}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onViewUserProfile) {
                    onViewUserProfile(person.userId);
                  } else {
                    window.dispatchEvent(new CustomEvent('open_shared_profile', { detail: person.userId }));
                  }
                }}
                className="p-4 rounded-2xl border border-sky-200/80 bg-gradient-to-b from-white to-sky-50/40 hover:border-sky-400 transition-all shadow-2xs flex flex-col items-center justify-center text-center gap-2 cursor-pointer"
              >
                {person.avatarUrl ? (
                  <img
                    src={person.avatarUrl}
                    alt={person.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-sky-200 shadow-2xs"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center font-serif font-bold text-sm">
                    {person.name.charAt(0)}
                  </div>
                )}

                <div className="space-y-1">
                  <div className="flex items-center justify-center gap-1">
                    <span className="font-bold text-xs sm:text-sm text-slate-900">{person.name}</span>
                    {person.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                  </div>
                  <p className="text-[11px] font-mono text-sky-700 font-semibold">@{person.userId}</p>
                  {person.bio && !compact && (
                    <p className="text-[11px] text-slate-600 line-clamp-2 max-w-sm mx-auto leading-relaxed">{person.bio}</p>
                  )}
                  {(ratingInfo.count > 0 || typeof person.followersCount === 'number') && (
                    <div className="flex items-center justify-center gap-2.5 flex-wrap pt-0.5 text-[10px] font-mono text-slate-500">
                      {typeof person.followersCount === 'number' && (
                        <span className="inline-flex items-center gap-1">
                          <Users className="w-3 h-3 text-slate-400" />
                          <span>{person.followersCount.toLocaleString()} followers</span>
                        </span>
                      )}
                      {ratingInfo.count > 0 && (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-800 font-bold">
                          <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                          <span>{ratingInfo.average} ({ratingInfo.count})</span>
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
