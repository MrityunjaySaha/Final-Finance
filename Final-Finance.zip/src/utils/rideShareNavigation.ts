/**
 * Shared Navigation, Turn-by-Turn Directions & Address Autocomplete Engine
 * for Sovereign Ride-Share & Merchant Delivery Dispatches.
 */

export interface AddressSuggestion {
  id: string;
  label: string;
  address: string;
  district: string;
  category: 'hub' | 'landmark' | 'street' | 'saved' | 'merchant';
  coords: { x: number; y: number };
}

export interface TurnByTurnStep {
  id: string;
  instruction: string;
  detail: string;
  distanceLabel: string;
  maneuver: 'depart' | 'straight' | 'left' | 'right' | 'merge' | 'pickup' | 'arrive';
  phase: 'to_pickup' | 'in_transit' | 'dropoff';
}

export interface TurnByTurnRoute {
  pickup: string;
  dropoff: string;
  distanceMiles: number;
  pickupApproachMiles: number;
  totalMiles: number;
  estimatedMinutes: number;
  toPickupMinutes: number;
  deliveryLegMinutes: number;
  totalMinutes: number;
  steps: TurnByTurnStep[];
}

export const ADDRESS_CATALOG: AddressSuggestion[] = [
  {
    id: 'addr-zurich-freeport-4b',
    label: 'Zurich Freeport Terminal 4B',
    address: 'Zurich Freeport Terminal 4B, 8048 Zürich',
    district: 'Zürich-Altstetten · Sovereign Hub',
    category: 'hub',
    coords: { x: 18, y: 74 }
  },
  {
    id: 'addr-zurich-vault-4b',
    label: 'Zurich Freeport Vault 4B',
    address: 'Zurich Freeport Depository Vault 4B, 8048 Zürich',
    district: 'Zürich-Altstetten · Bullion Depository',
    category: 'hub',
    coords: { x: 20, y: 72 }
  },
  {
    id: 'addr-zurich-freeport-hub',
    label: 'Zurich Freeport Hub Sector 4',
    address: 'Zurich Freeport Hub, Sector 4, 8048 Zürich',
    district: 'Zürich-West · Logistics Hub',
    category: 'hub',
    coords: { x: 22, y: 68 }
  },
  {
    id: 'addr-bahnhofstrasse-district',
    label: 'Bahnhofstrasse Luxury Financial District',
    address: 'Bahnhofstrasse Luxury Financial District, 8001 Zürich',
    district: 'Zürich Kreis 1 · Financial Core',
    category: 'landmark',
    coords: { x: 76, y: 26 }
  },
  {
    id: 'addr-bahnhofstrasse-45',
    label: 'Bahnhofstrasse 45',
    address: 'Bahnhofstrasse 45, 8001 Zürich',
    district: 'Zürich Kreis 1 · City Center',
    category: 'street',
    coords: { x: 74, y: 30 }
  },
  {
    id: 'addr-bahnhofstrasse-102',
    label: 'Bahnhofstrasse 102',
    address: 'Bahnhofstrasse 102, 8001 Zürich',
    district: 'Zürich Kreis 1 · Near HB',
    category: 'street',
    coords: { x: 72, y: 24 }
  },
  {
    id: 'addr-zurich-hb',
    label: 'Zürich Hauptbahnhof (HB)',
    address: 'Bahnhofplatz 15, 8001 Zürich',
    district: 'Zürich Kreis 1 · Main Station',
    category: 'hub',
    coords: { x: 70, y: 20 }
  },
  {
    id: 'addr-paradeplatz',
    label: 'Paradeplatz Banking Square',
    address: 'Paradeplatz 8, 8001 Zürich',
    district: 'Zürich Kreis 1 · Banking Square',
    category: 'landmark',
    coords: { x: 78, y: 36 }
  },
  {
    id: 'addr-gessnerallee-28',
    label: "Ranma's Sovereign Dining · Gessnerallee",
    address: 'Gessnerallee 28, 8001 Zürich',
    district: 'Zürich Kreis 1 · Sihl Promenade',
    category: 'merchant',
    coords: { x: 64, y: 28 }
  },
  {
    id: 'addr-limmatquai-112',
    label: 'Limmatquai 112',
    address: 'Limmatquai 112, 8001 Zürich',
    district: 'Zürich Niederdorf · Old Town',
    category: 'street',
    coords: { x: 82, y: 28 }
  },
  {
    id: 'addr-seefeld-120',
    label: 'Seefeldstrasse 120',
    address: 'Seefeldstrasse 120, 8008 Zürich',
    district: 'Zürich Kreis 8 · Seefeld',
    category: 'street',
    coords: { x: 88, y: 54 }
  },
  {
    id: 'addr-talstrasse-82',
    label: 'Talstrasse 82',
    address: 'Talstrasse 82, 8001 Zürich',
    district: 'Zürich Kreis 1 · Paradeplatz West',
    category: 'street',
    coords: { x: 71, y: 38 }
  },
  {
    id: 'addr-bleicherweg-18',
    label: 'Bleicherweg 18',
    address: 'Bleicherweg 18, 8002 Zürich',
    district: 'Zürich Enge · Financial Corridor',
    category: 'street',
    coords: { x: 74, y: 44 }
  },
  {
    id: 'addr-pfingstweid-60',
    label: 'Pfingstweidstrasse 60',
    address: 'Pfingstweidstrasse 60, 8005 Zürich',
    district: 'Zürich-West · Technopark',
    category: 'street',
    coords: { x: 42, y: 48 }
  },
  {
    id: 'addr-hardturm-161',
    label: 'Hardturmstrasse 161',
    address: 'Hardturmstrasse 161, 8005 Zürich',
    district: 'Zürich-West · Escher-Wyss',
    category: 'street',
    coords: { x: 38, y: 42 }
  },
  {
    id: 'addr-zrh-airport',
    label: 'Zurich Airport (ZRH) Terminal 1',
    address: 'Flughafenstrasse 90, 8302 Kloten, Zürich',
    district: 'Kloten · International Arrivals',
    category: 'hub',
    coords: { x: 84, y: 12 }
  },
  {
    id: 'addr-enge-station',
    label: 'Zürich Enge Station & Promenade',
    address: 'Tessinerplatz 10, 8002 Zürich',
    district: 'Zürich Enge · Lakefront',
    category: 'landmark',
    coords: { x: 68, y: 58 }
  },
  {
    id: 'addr-bellevue',
    label: 'Bellevueplatz & Opera House',
    address: 'Bellevueplatz 1, 8001 Zürich',
    district: 'Zürich Lakefront · Bellevue',
    category: 'landmark',
    coords: { x: 85, y: 40 }
  },
  {
    id: 'addr-eth-zurich',
    label: 'ETH Zürich Main Campus',
    address: 'Rämistrasse 101, 8092 Zürich',
    district: 'Zürich Hochschulquartier',
    category: 'landmark',
    coords: { x: 84, y: 22 }
  },
  {
    id: 'addr-tokyo-akihabara',
    label: 'Tokyo Cybernetic Vault Hardware',
    address: 'Akihabara Tech District Floor 9, Chiyoda-ku, Tokyo',
    district: 'Tokyo · Akihabara Electric Town',
    category: 'merchant',
    coords: { x: 30, y: 56 }
  },
  {
    id: 'addr-neo-tokyo-tower',
    label: 'Neo Tokyo Sovereign Teppanyaki',
    address: 'Neo Tokyo Tower Floor 42, Minato-ku, Tokyo',
    district: 'Tokyo · Sovereign District',
    category: 'merchant',
    coords: { x: 74, y: 42 }
  },
  {
    id: 'addr-tokyo-station',
    label: 'Tokyo Station Marunouchi South',
    address: '1-9-1 Marunouchi, Chiyoda-ku, Tokyo',
    district: 'Tokyo · Central Hub',
    category: 'hub',
    coords: { x: 54, y: 48 }
  },
  {
    id: 'addr-ginza-six',
    label: 'Ginza Six Luxury Promenade',
    address: '6-10-1 Ginza, Chuo-ku, Tokyo',
    district: 'Tokyo · Ginza',
    category: 'landmark',
    coords: { x: 64, y: 58 }
  },
  {
    id: 'addr-london-canary',
    label: 'One Canada Square, Canary Wharf',
    address: 'One Canada Square, Canary Wharf, London E14 5AB',
    district: 'London · Financial District',
    category: 'landmark',
    coords: { x: 78, y: 34 }
  },
  {
    id: 'addr-nyc-wall-st',
    label: '40 Wall Street Sovereign Exchange',
    address: '40 Wall Street, Financial District, New York, NY 10005',
    district: 'New York · Lower Manhattan',
    category: 'landmark',
    coords: { x: 70, y: 30 }
  },
  {
    id: 'addr-sg-marina-bay',
    label: 'Marina Bay Financial Centre Tower 1',
    address: '8 Marina Boulevard, Singapore 018981',
    district: 'Singapore · Marina Bay',
    category: 'landmark',
    coords: { x: 72, y: 44 }
  }
];

function hashString(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export function loadSavedAndMerchantAddresses(): AddressSuggestion[] {
  const dynamic: AddressSuggestion[] = [];
  const seen = new Set<string>(ADDRESS_CATALOG.map(a => a.address.toLowerCase()));

  try {
    const rawLocations = localStorage.getItem('final_finance_merchant_locations');
    if (rawLocations) {
      const locs = JSON.parse(rawLocations);
      if (Array.isArray(locs)) {
        locs.forEach((loc: any, idx: number) => {
          if (loc?.address && !seen.has(String(loc.address).toLowerCase())) {
            seen.add(String(loc.address).toLowerCase());
            const h = hashString(loc.address);
            dynamic.push({
              id: `merchant-addr-${loc.id || idx}`,
              label: loc.name || loc.address,
              address: loc.address,
              district: loc.type === 'restaurant' ? 'Partner Restaurant' : 'Partner Retail Store',
              category: 'merchant',
              coords: { x: 20 + (h % 62), y: 20 + ((h >> 4) % 58) }
            });
          }
        });
      }
    }
  } catch {}

  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('final_finance_pos_delivery_addresses_')) {
        const raw = localStorage.getItem(key);
        if (raw) {
          const addrs = JSON.parse(raw);
          if (Array.isArray(addrs)) {
            addrs.forEach((a: any, idx: number) => {
              if (a?.address && !seen.has(String(a.address).toLowerCase())) {
                seen.add(String(a.address).toLowerCase());
                const h = hashString(a.address);
                dynamic.push({
                  id: `saved-addr-${a.id || idx}`,
                  label: a.label ? `${a.label} (${a.fullName || 'Saved'})` : (a.fullName || 'Saved Address'),
                  address: a.address,
                  district: 'Saved Delivery Address',
                  category: 'saved',
                  coords: { x: 22 + (h % 60), y: 22 + ((h >> 3) % 55) }
                });
              }
            });
          }
        }
      }
    }
  } catch {}

  return [...dynamic, ...ADDRESS_CATALOG];
}

export function getAddressSuggestions(query: string, extraAddresses: string[] = []): AddressSuggestion[] {
  const allKnown = loadSavedAndMerchantAddresses();
  const seen = new Set(allKnown.map(a => a.address.toLowerCase()));

  extraAddresses.forEach((addr, idx) => {
    const clean = (addr || '').trim();
    if (clean && !seen.has(clean.toLowerCase())) {
      seen.add(clean.toLowerCase());
      const h = hashString(clean);
      allKnown.unshift({
        id: `recent-addr-${idx}`,
        label: clean.split(',')[0],
        address: clean,
        district: 'Recent Location',
        category: 'saved',
        coords: { x: 20 + (h % 62), y: 20 + ((h >> 4) % 58) }
      });
    }
  });

  const q = query.trim().toLowerCase();
  if (!q) {
    return allKnown.slice(0, 7);
  }

  const tokens = q.split(/\s+/).filter(Boolean);
  const scored = allKnown
    .map(item => {
      const hay = `${item.label} ${item.address} ${item.district}`.toLowerCase();
      let score = 0;
      if (item.address.toLowerCase().startsWith(q) || item.label.toLowerCase().startsWith(q)) {
        score += 100;
      } else if (hay.includes(q)) {
        score += 65;
      } else {
        let tokenMatches = 0;
        for (const t of tokens) {
          if (hay.includes(t)) tokenMatches++;
        }
        if (tokenMatches > 0) {
          score += tokenMatches * 22;
        }
      }
      if (item.category === 'saved' || item.category === 'merchant') score += 4;
      return { item, score };
    })
    .filter(s => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(s => s.item);

  // If few exact matches, synthesize probable street/district completions for what the user is typing
  const cleanRaw = query.trim().replace(/\s+/g, ' ');
  if (scored.length < 5 && cleanRaw.length >= 2) {
    const titled = cleanRaw
      .split(' ')
      .map(w => (w.length > 0 ? w[0].toUpperCase() + w.slice(1) : w))
      .join(' ');
    const hasStreetType = /\b(st|street|ave|avenue|strasse|str|rd|road|blvd|boulevard|way|plaza|platz|quai|allee|lane|ln|dr|drive)\b/i.test(cleanRaw);
    const hasCity = /\b(zürich|zurich|tokyo|london|new york|singapore|kloten)\b/i.test(cleanRaw);

    const probableCandidates: AddressSuggestion[] = [];
    if (!hasCity) {
      if (hasStreetType) {
        probableCandidates.push(
          {
            id: `prob-zh-${cleanRaw}`,
            label: titled,
            address: `${titled}, 8001 Zürich`,
            district: 'Suggested Address · Zürich Kreis 1',
            category: 'street',
            coords: { x: 68, y: 32 }
          },
          {
            id: `prob-zhw-${cleanRaw}`,
            label: `${titled} (Zürich-West)`,
            address: `${titled}, 8005 Zürich`,
            district: 'Suggested Address · Zürich-West',
            category: 'street',
            coords: { x: 42, y: 46 }
          }
        );
      } else {
        const startsWithNumber = /^\d+\s+/.test(cleanRaw);
        probableCandidates.push(
          {
            id: `prob-str-1-${cleanRaw}`,
            label: startsWithNumber ? `${titled} Street` : `${titled}strasse`,
            address: startsWithNumber ? `${titled} Street, 8001 Zürich` : `${titled}strasse 24, 8001 Zürich`,
            district: 'Probable Street · Zürich Center',
            category: 'street',
            coords: { x: 70, y: 34 }
          },
          {
            id: `prob-str-2-${cleanRaw}`,
            label: startsWithNumber ? `${titled} Avenue` : `${titled} Hub Terminal`,
            address: startsWithNumber ? `${titled} Avenue, Financial District` : `${titled} Hub Terminal, 8048 Zürich`,
            district: 'Probable Address · Commercial District',
            category: 'street',
            coords: { x: 34, y: 62 }
          },
          {
            id: `prob-str-3-${cleanRaw}`,
            label: `${titled} Plaza`,
            address: `${titled} Plaza, Sovereign District`,
            district: 'Probable Landmark · Sovereign Corridor',
            category: 'landmark',
            coords: { x: 60, y: 38 }
          }
        );
      }
    }

    for (const cand of probableCandidates) {
      if (!scored.some(s => s.address.toLowerCase() === cand.address.toLowerCase())) {
        scored.push(cand);
      }
    }
  }

  return scored.slice(0, 7);
}

const CORRIDOR_STREETS = [
  'Pfingstweidstrasse',
  'Hardturmstrasse',
  'Sihlstrasse',
  'Uraniastrasse',
  'Talstrasse',
  'Limmatquai',
  'Bleicherweg',
  'Gessnerallee',
  'Hafnerstrasse'
];

export function buildTurnByTurnRoute(
  pickup: string,
  dropoff: string,
  mode: 'customer_ride' | 'driver_ride' | 'driver_delivery',
  options?: {
    merchantName?: string;
    customerName?: string;
    baseDistanceMiles?: number;
  }
): TurnByTurnRoute {
  const cleanPickup = (pickup || 'Zurich Freeport Terminal 4B').trim();
  const cleanDropoff = (dropoff || 'Bahnhofstrasse Luxury Financial District').trim();
  const seed = hashString(`${cleanPickup}=>${cleanDropoff}`);

  const known = ADDRESS_CATALOG;
  const pMatch = known.find(a => cleanPickup.toLowerCase().includes(a.label.toLowerCase()) || a.address.toLowerCase() === cleanPickup.toLowerCase());
  const dMatch = known.find(a => cleanDropoff.toLowerCase().includes(a.label.toLowerCase()) || a.address.toLowerCase() === cleanDropoff.toLowerCase());

  let computedDistance = options?.baseDistanceMiles;
  if (!computedDistance || computedDistance <= 0) {
    if (pMatch && dMatch && pMatch.id !== dMatch.id) {
      const dx = pMatch.coords.x - dMatch.coords.x;
      const dy = pMatch.coords.y - dMatch.coords.y;
      const raw = Math.sqrt(dx * dx + dy * dy) / 14;
      computedDistance = Math.max(1.2, Math.round(raw * 10) / 10);
    } else {
      computedDistance = Math.round((2.2 + ((seed % 48) / 10)) * 10) / 10;
    }
  }

  const pickupApproachMiles = Math.round((0.7 + ((seed % 11) / 10)) * 10) / 10;
  const totalMiles = Math.round((pickupApproachMiles + computedDistance) * 10) / 10;
  const leg1 = Math.max(0.3, Math.round(computedDistance * 0.18 * 10) / 10);
  const leg2 = Math.max(0.5, Math.round(computedDistance * 0.48 * 10) / 10);
  const leg3 = Math.max(0.3, Math.round((computedDistance - leg1 - leg2) * 10) / 10);

  const arterialA = CORRIDOR_STREETS[seed % CORRIDOR_STREETS.length];
  const arterialB = CORRIDOR_STREETS[(seed + 3) % CORRIDOR_STREETS.length];
  const turnDir = seed % 2 === 0 ? 'right' : 'left';
  const toPickupMinutes = Math.max(3, Math.round(pickupApproachMiles * 3.1 + 1));
  const deliveryLegMinutes = Math.max(5, Math.round(computedDistance * 3.2 + 2));
  const totalMinutes = toPickupMinutes + deliveryLegMinutes;
  const estimatedMinutes = mode === 'customer_ride' ? deliveryLegMinutes : totalMinutes;

  if (mode === 'driver_delivery') {
    const merchantLabel = options?.merchantName ? `${options.merchantName} (${cleanPickup})` : cleanPickup;
    const customerLabel = options?.customerName ? `${options.customerName} — ${cleanDropoff}` : cleanDropoff;

    return {
      pickup: cleanPickup,
      dropoff: cleanDropoff,
      distanceMiles: computedDistance,
      pickupApproachMiles,
      totalMiles,
      estimatedMinutes,
      toPickupMinutes,
      deliveryLegMinutes,
      totalMinutes,
      steps: [
        {
          id: 'del-step-1',
          instruction: `Drive to merchant & pickup items from ${merchantLabel} (~${toPickupMinutes} mins · ${pickupApproachMiles} mi)`,
          detail: `Travel via ${arterialA} to merchant location, verify sealed order manifest & scan handoff QR`,
          distanceLabel: `${pickupApproachMiles} mi · ~${toPickupMinutes}m`,
          maneuver: 'pickup',
          phase: 'to_pickup'
        },
        {
          id: 'del-step-2',
          instruction: `Depart merchant onto ${arterialA} toward primary delivery corridor`,
          detail: `Leave ${cleanPickup} and merge smoothly onto ${arterialA} (~${deliveryLegMinutes} mins delivery leg)`,
          distanceLabel: `${leg1} mi`,
          maneuver: 'depart',
          phase: 'in_transit'
        },
        {
          id: 'del-step-3',
          instruction: `Navigate via primary delivery corridor (${arterialB}) to customer address`,
          detail: `Turn ${turnDir} onto ${arterialB} and continue for ${leg2} mi toward destination sector`,
          distanceLabel: `${leg2} mi`,
          maneuver: turnDir,
          phase: 'in_transit'
        },
        {
          id: 'del-step-4',
          instruction: `Final approach to ${cleanDropoff}`,
          detail: `Continue ${leg3} mi; drop-off pin will be on your ${turnDir === 'right' ? 'right' : 'left'}`,
          distanceLabel: `${leg3} mi`,
          maneuver: 'straight',
          phase: 'dropoff'
        },
        {
          id: 'del-step-5',
          instruction: `Hand over food/product securely and collect settlement`,
          detail: `Deliver to ${customerLabel} and mark contract settled`,
          distanceLabel: 'Arrived',
          maneuver: 'arrive',
          phase: 'dropoff'
        }
      ]
    };
  }

  if (mode === 'driver_ride') {
    return {
      pickup: cleanPickup,
      dropoff: cleanDropoff,
      distanceMiles: computedDistance,
      pickupApproachMiles,
      totalMiles,
      estimatedMinutes,
      toPickupMinutes,
      deliveryLegMinutes,
      totalMinutes,
      steps: [
        {
          id: 'drv-step-1',
          instruction: `Drive to passenger pickup location (${pickupApproachMiles} mi away · ~${toPickupMinutes} mins)`,
          detail: `Head via ${arterialA} to meet passenger at ${cleanPickup}`,
          distanceLabel: `${pickupApproachMiles} mi`,
          maneuver: 'pickup',
          phase: 'to_pickup'
        },
        {
          id: 'drv-step-2',
          instruction: `Depart pickup and merge onto ${arterialA}`,
          detail: `Confirm passenger onboard at ${cleanPickup} and begin trip`,
          distanceLabel: `${leg1} mi`,
          maneuver: 'depart',
          phase: 'in_transit'
        },
        {
          id: 'drv-step-3',
          instruction: `Proceed on main arterial route (${arterialB}) toward dropoff destination (${computedDistance} mi)`,
          detail: `Turn ${turnDir} onto ${arterialB} and follow sovereign transit lane`,
          distanceLabel: `${leg2} mi`,
          maneuver: turnDir,
          phase: 'in_transit'
        },
        {
          id: 'drv-step-4',
          instruction: `Continue toward ${cleanDropoff}`,
          detail: `Follow signs for final approach (${leg3} mi remaining)`,
          distanceLabel: `${leg3} mi`,
          maneuver: 'straight',
          phase: 'dropoff'
        },
        {
          id: 'drv-step-5',
          instruction: `Arrive at passenger destination and complete trip`,
          detail: `Drop off safely at ${cleanDropoff} and settle fare`,
          distanceLabel: 'Arrived',
          maneuver: 'arrive',
          phase: 'dropoff'
        }
      ]
    };
  }

  // customer_ride
  return {
    pickup: cleanPickup,
    dropoff: cleanDropoff,
    distanceMiles: computedDistance,
    pickupApproachMiles,
    totalMiles,
    estimatedMinutes,
    toPickupMinutes,
    deliveryLegMinutes,
    totalMinutes,
    steps: [
      {
        id: 'cust-step-1',
        instruction: `Driver approaching pickup at ${cleanPickup}`,
        detail: `Vehicle is ${pickupApproachMiles} mi away via ${arterialA} (~${toPickupMinutes} mins)`,
        distanceLabel: `${pickupApproachMiles} mi`,
        maneuver: 'pickup',
        phase: 'to_pickup'
      },
      {
        id: 'cust-step-2',
        instruction: `Depart from ${cleanPickup} onto ${arterialA}`,
        detail: `Begin route along primary transit corridor`,
        distanceLabel: `${leg1} mi`,
        maneuver: 'depart',
        phase: 'in_transit'
      },
      {
        id: 'cust-step-3',
        instruction: `Turn ${turnDir} onto ${arterialB} toward destination`,
        detail: `Main arterial segment (${leg2} mi)`,
        distanceLabel: `${leg2} mi`,
        maneuver: turnDir,
        phase: 'in_transit'
      },
      {
        id: 'cust-step-4',
        instruction: `Final approach to ${cleanDropoff}`,
        detail: `Approaching destination block (${leg3} mi remaining)`,
        distanceLabel: `${leg3} mi`,
        maneuver: 'straight',
        phase: 'dropoff'
      },
      {
        id: 'cust-step-5',
        instruction: `Arrive at destination: ${cleanDropoff}`,
        detail: `Trip complete — rate driver and view settlement receipt`,
        distanceLabel: 'Arrived',
        maneuver: 'arrive',
        phase: 'dropoff'
      }
    ]
  };
}

export function estimateDeliveryTiming(
  pickup: string,
  dropoff: string,
  baseDistanceMiles?: number
): {
  toPickupMiles: number;
  toPickupMinutes: number;
  deliveryMiles: number;
  deliveryMinutes: number;
  totalMiles: number;
  totalMinutes: number;
} {
  const route = buildTurnByTurnRoute(pickup, dropoff, 'driver_delivery', { baseDistanceMiles });
  return {
    toPickupMiles: route.pickupApproachMiles,
    toPickupMinutes: route.toPickupMinutes,
    deliveryMiles: route.distanceMiles,
    deliveryMinutes: route.deliveryLegMinutes,
    totalMiles: route.totalMiles,
    totalMinutes: route.totalMinutes
  };
}
