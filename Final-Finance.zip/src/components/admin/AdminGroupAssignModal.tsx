import React, { useMemo, useState } from 'react';
import { X, Check, FolderHeart, Plus, Shield } from 'lucide-react';
import {
  AdminGroup,
  AdminMember,
  DEFAULT_ADMIN_MEMBERS,
  createAdminGroup,
  setAdminGroups,
} from '../../services/adminGroupService';
import { maskProtectedEmailForViewer } from '../../utils/privacyShield';

interface AdminGroupAssignModalProps {
  admin: AdminMember;
  allGroups: AdminGroup[];
  onClose: () => void;
  onGroupsUpdated: () => void;
  onToast: (toast: { type: 'success' | 'error' | 'info'; title: string; message: string }) => void;
}

const PRESET_COLORS = ['#f59e0b', '#8b5cf6', '#10b981', '#3b82f6', '#ec4899', '#6366f1', '#14b8a6', '#64748b'];

export const AdminGroupAssignModal: React.FC<AdminGroupAssignModalProps> = ({
  admin,
  allGroups,
  onClose,
  onGroupsUpdated,
  onToast,
}) => {
  // Initialize with the IDs of groups this admin currently belongs to
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>(() =>
    allGroups.filter((g) => g.adminIds.includes(admin.id)).map((g) => g.id)
  );

  // State for inline "Create New Group"
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [newGroupColor, setNewGroupColor] = useState(PRESET_COLORS[0]);
  const [avatarFailed, setAvatarFailed] = useState(false);

  const avatarSrc = useMemo(() => {
    if (admin.avatarUrl) return admin.avatarUrl;
    const cleanEmail = (admin.email || '').trim().toLowerCase();
    const cleanHandle = (admin.handle || '').trim().toLowerCase().replace(/^@/, '');
    const defMatch = DEFAULT_ADMIN_MEMBERS.find(
      (d) =>
        d.id === admin.id ||
        (cleanEmail && d.email.toLowerCase() === cleanEmail) ||
        (cleanHandle && d.handle.toLowerCase().replace(/^@/, '') === cleanHandle)
    );
    return defMatch?.avatarUrl;
  }, [admin]);

  const toggleGroup = (groupId: string) => {
    setSelectedGroupIds((prev) =>
      prev.includes(groupId) ? prev.filter((id) => id !== groupId) : [...prev, groupId]
    );
  };

  const handleSave = () => {
    setAdminGroups(admin.id, selectedGroupIds);
    onToast({
      type: 'success',
      title: 'Admin Groups Updated',
      message: `${admin.name} is now assigned to ${selectedGroupIds.length} ${
        selectedGroupIds.length === 1 ? 'group' : 'groups'
      }.`,
    });
    onGroupsUpdated();
    onClose();
  };

  const handleCreateNewGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    const created = createAdminGroup({
      name: newGroupName.trim(),
      description: newGroupDesc.trim(),
      color: newGroupColor,
      adminIds: [admin.id], // automatically assign this admin
    });

    setSelectedGroupIds((prev) => [...prev, created.id]);
    setNewGroupName('');
    setNewGroupDesc('');
    setIsCreatingNew(false);
    onGroupsUpdated();

    onToast({
      type: 'success',
      title: 'Group Created',
      message: `Created group "${created.name}" and assigned ${admin.name}.`,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] text-center">
        {/* Modal Header (Centered) */}
        <div className="relative px-6 py-5 border-b border-slate-100 flex flex-col items-center justify-center gap-2 bg-slate-50/70 text-center shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="absolute right-4 top-4 w-8 h-8 rounded-full hover:bg-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
            <FolderHeart className="w-5 h-5" />
          </div>
          <div className="space-y-0.5 text-center">
            <h3 className="font-serif text-base font-bold text-slate-900">
              Group Assignment for Admin
            </h3>
            <p className="text-xs text-slate-500">
              Assign to multiple groups simultaneously
            </p>
          </div>
        </div>

        {/* Admin Info Card (Centered) */}
        <div className="px-6 py-4 bg-slate-50/50 border-b border-slate-100 flex flex-col items-center justify-center gap-2.5 text-center shrink-0">
          {avatarSrc && !avatarFailed ? (
            <img
              src={avatarSrc}
              alt={admin.name}
              referrerPolicy="no-referrer"
              onError={() => setAvatarFailed(true)}
              className="w-12 h-12 rounded-2xl object-cover border-2 border-amber-200 shadow-2xs shrink-0"
            />
          ) : (
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-base border border-amber-200 shrink-0">
              {admin.name.charAt(0)}
            </div>
          )}

          <div className="space-y-1 flex flex-col items-center justify-center text-center">
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <span className="font-bold text-xs sm:text-sm text-slate-900">{admin.name}</span>
              <span className="font-mono text-[11px] text-amber-600">{admin.handle}</span>
              {admin.jobTitle && (
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-200/70 text-slate-700">
                  {admin.jobTitle}
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 font-mono text-center">
              {maskProtectedEmailForViewer(admin.email)}
            </p>
          </div>

          <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200">
            {selectedGroupIds.length} {selectedGroupIds.length === 1 ? 'Group' : 'Groups'} Selected
          </span>
        </div>

        {/* Groups List (Centered) */}
        <div className="p-6 overflow-y-auto space-y-3 flex-1 text-center">
          <div className="flex flex-col items-center justify-center gap-1.5 mb-2 text-center">
            <label className="text-[11px] font-mono text-slate-500 uppercase tracking-wider font-semibold">
              Available Admin Groups
            </label>
            {!isCreatingNew && (
              <button
                type="button"
                onClick={() => setIsCreatingNew(true)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 inline-flex items-center justify-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Group</span>
              </button>
            )}
          </div>

          {/* Inline Create Form (Centered) */}
          {isCreatingNew && (
            <form
              onSubmit={handleCreateNewGroup}
              className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-200 space-y-3 mb-3 animate-in fade-in text-center"
            >
              <div className="flex flex-col items-center justify-center gap-1">
                <span className="text-xs font-bold text-indigo-950 flex items-center justify-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-indigo-600" />
                  Create New Admin Group
                </span>
              </div>

              <div>
                <input
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="Group Name (e.g. Audit & Clearing Desk)..."
                  className="w-full px-3 py-2 text-xs text-center bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <input
                  type="text"
                  value={newGroupDesc}
                  onChange={(e) => setNewGroupDesc(e.target.value)}
                  placeholder="Optional brief description or mandate..."
                  className="w-full px-3 py-2 text-xs text-center bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              {/* Color choices */}
              <div className="flex flex-col items-center justify-center gap-1.5">
                <span className="text-[11px] text-slate-500 font-mono">Color</span>
                <div className="flex items-center justify-center gap-1.5 flex-wrap">
                  {PRESET_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewGroupColor(c)}
                      className={`w-5 h-5 rounded-full transition-transform cursor-pointer ${
                        newGroupColor === c ? 'scale-125 ring-2 ring-indigo-500 ring-offset-1' : 'opacity-80 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsCreatingNew(false)}
                  className="px-3.5 py-1.5 rounded-xl text-slate-500 hover:text-slate-700 hover:bg-white/70 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold cursor-pointer shadow-xs transition-colors"
                >
                  Create &amp; Assign
                </button>
              </div>
            </form>
          )}

          {allGroups.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              No groups available. Create your first group above!
            </div>
          ) : (
            allGroups.map((group) => {
              const isSelected = selectedGroupIds.includes(group.id);
              const otherMembersCount = group.adminIds.filter((id) => id !== admin.id).length;

              return (
                <div
                  key={group.id}
                  onClick={() => toggleGroup(group.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col items-center justify-center text-center gap-2 ${
                    isSelected
                      ? 'bg-indigo-50/40 border-indigo-300 ring-1 ring-indigo-500/30'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center justify-center gap-2 flex-wrap">
                    {/* Checkbox */}
                    <div
                      className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 transition-colors border ${
                        isSelected
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-slate-300 bg-white text-transparent'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: group.color }}
                    />
                    <span className="font-bold text-xs text-slate-900">
                      {group.name}
                    </span>
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                      {otherMembersCount + (isSelected ? 1 : 0)} admins
                    </span>
                  </div>

                  {group.memberSecondaryTitles?.[admin.id] && (
                    <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-md border border-indigo-200/60">
                      Role: {group.memberSecondaryTitles[admin.id]}
                    </span>
                  )}

                  {group.description && (
                    <p className="text-[11px] text-slate-500 leading-relaxed max-w-md mx-auto text-center">
                      {group.description}
                    </p>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer (Centered) */}
        <div className="px-6 py-4 border-t border-slate-100 flex flex-col items-center justify-center gap-3 bg-slate-50/70 shrink-0 text-center">
          <p className="text-[11px] text-slate-500 text-center">
            Admins can belong to <strong className="text-slate-700">multiple groups</strong>.
          </p>
          <div className="flex items-center justify-center gap-2.5 flex-wrap">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors cursor-pointer inline-flex items-center justify-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Save Assignments</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

