import { isAdminOrSuperAdminUser } from '../utils/verificationTiers';

export interface LoanRecord {
  id: string;
  lenderId: string;
  lenderHandle: string;
  lenderName?: string;
  lenderAvatar?: string;
  borrowerId: string;
  borrowerHandle: string;
  borrowerName?: string;
  borrowerAvatar?: string;
  amount: number;
  coinSymbol: string;
  interestRate: number;
  termDays: number;
  monthlyInstallment?: number;
  status: 'pending_offer' | 'active' | 'repaid' | 'defaulted' | 'declined';
  timestamp: string; // ISO or human readable
  issuedAtMs: number;
  amountPaid?: number;
  nextDueDateMs?: number;
  lastPaymentAtMs?: number;
  isExample?: boolean;
}

const LOANS_KEY = 'ff_global_loans';
const SAMPLE_SEED_FLAG_PREFIX = 'ff_sample_loans_seeded_v2_';

const SAMPLE_COUNTERPARTIES = [
  {
    id: 'demo-jordan-belfort',
    handle: 'jordan_belfort',
    name: 'Jordan Belfort',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 'demo-alex-morgan',
    handle: 'alex_morgan',
    name: 'Alex Morgan',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 'demo-satoshi-nakamoto',
    handle: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 'user-elena_rostova',
    handle: 'elena_rostova',
    name: 'Elena Rostova',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 'user-marcus_vance',
    handle: 'marcus_vance',
    name: 'Marcus Vance',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 'user-lord_sterling',
    handle: 'sterling_vault',
    name: 'Lord Sterling',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 'user-alex_chen',
    handle: 'alex_chen',
    name: 'Alex Chen',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
  },
];

function buildIdentityAliases(idOrHandle?: string, extraId?: string): string[] {
  const aliases = new Set<string>();
  const addId = (val?: string) => {
    if (!val) return;
    const raw = val.trim();
    const lower = raw.toLowerCase();
    const clean = lower.replace(/^@/, '');
    if (raw) aliases.add(raw);
    if (lower) aliases.add(lower);
    if (clean) {
      aliases.add(clean);
      aliases.add(`@${clean}`);
      if (clean.startsWith('user-')) aliases.add(clean.slice(5));
      else if (clean.startsWith('demo-')) aliases.add(clean.slice(5));
      else aliases.add(`user-${clean}`);
    }
  };
  addId(idOrHandle);
  addId(extraId);
  return Array.from(aliases).filter(Boolean);
}

export function isRegisteredInternalBank(userIdOrHandle?: string): boolean {
  if (!userIdOrHandle) return false;
  const aliases = buildIdentityAliases(userIdOrHandle);
  const cleanAliases = new Set(aliases.map((a) => a.toLowerCase().replace(/^@/, '')));

  // Explicitly delisted check
  try {
    const isDelisted = aliases.some((a) => {
      const clean = a.replace(/^@/, '');
      return (
        localStorage.getItem(`ff_bank_app_status_${a}`) === 'delisted' ||
        localStorage.getItem(`ff_bank_app_status_${clean}`) === 'delisted'
      );
    });
    if (isDelisted) return false;
  } catch {
    // ignore storage errors
  }

  const presetMatch = aliases.some((a) => {
    const clean = a.toLowerCase().replace(/^@/, '');
    return (
      clean.includes('satoshi') ||
      clean.includes('sterling') ||
      clean.includes('belfort') ||
      clean.includes('morgan') ||
      clean === 'super_admin_ranma' ||
      clean === 'demo-ranma-superadmin' ||
      clean === 'demo-super-admin' ||
      clean === 'ranmaanimaker@gmail.com' ||
      clean === 'officer_dbz' ||
      clean === 'demo-dbz-admin' ||
      clean === 'demo-admin-officer' ||
      clean === 'awesomedbz@gmail.com' ||
      clean === 'demo-satoshi-nakamoto' ||
      clean === 'user-lord_sterling' ||
      clean === 'demo-jordan-belfort' ||
      clean === 'demo-alex-morgan'
    );
  });
  if (presetMatch || isAdminOrSuperAdminUser({ id: userIdOrHandle, handle: userIdOrHandle })) return true;

  // Active admins/super admins in session, registered registry, or admin members directory are exempt and bank-authorized
  try {
    const sessRaw = localStorage.getItem('final_finance_auth_session');
    if (sessRaw) {
      const sess = JSON.parse(sessRaw);
      if (sess?.role === 'admin' || sess?.role === 'super_admin') {
        const sKeys = [sess.id, sess.uid, sess.handle, sess.email]
          .filter(Boolean)
          .map((s: string) => s.toLowerCase().replace(/^@/, ''));
        if (sKeys.some((k: string) => cleanAliases.has(k))) return true;
      }
    }
    const adminsRaw = localStorage.getItem('ff_admin_members_v1');
    if (adminsRaw) {
      const members = JSON.parse(adminsRaw);
      if (Array.isArray(members)) {
        const isAdminMember = members.some((m: any) => {
          if (m?.status === 'deactivated') return false;
          const mKeys = [m?.id, m?.handle, m?.email]
            .filter(Boolean)
            .map((s: string) => s.toLowerCase().replace(/^@/, ''));
          return mKeys.some((mk: string) => cleanAliases.has(mk));
        });
        if (isAdminMember) return true;
      }
    }
    const registryRaw = localStorage.getItem('final_finance_users_registry');
    if (registryRaw) {
      const registry = JSON.parse(registryRaw);
      if (Array.isArray(registry)) {
        const isRegAdmin = registry.some((u: any) => {
          if (u?.role !== 'admin' && u?.role !== 'super_admin') return false;
          const uKeys = [u?.id, u?.uid, u?.handle, u?.email]
            .filter(Boolean)
            .map((s: string) => s.toLowerCase().replace(/^@/, ''));
          return uKeys.some((uk: string) => cleanAliases.has(uk));
        });
        if (isRegAdmin) return true;
      }
    }
    const reqsRaw = localStorage.getItem('ff_admin_banking_requests');
    if (reqsRaw) {
      const reqs = JSON.parse(reqsRaw);
      if (Array.isArray(reqs)) {
        const isApprovedReq = reqs.some((r: any) => {
          if (r?.status !== 'approved') return false;
          const rKeys = [r?.userId, r?.uid, r?.userHandle]
            .filter(Boolean)
            .map((s: string) => s.toLowerCase().replace(/^@/, ''));
          return rKeys.some((rk: string) => cleanAliases.has(rk));
        });
        if (isApprovedReq) return true;
      }
    }
  } catch {
    // ignore storage errors
  }

  try {
    return aliases.some((a) => {
      const clean = a.replace(/^@/, '');
      return (
        localStorage.getItem(`ff_bank_app_status_${a}`) === 'approved' ||
        localStorage.getItem(`ff_bank_app_status_${clean}`) === 'approved'
      );
    });
  } catch {
    return false;
  }
}

export function getApprovedBankInstitutionName(identifiers: Array<string | undefined>): string | null {
  const aliasSet = new Set<string>();
  const rawList: string[] = [];
  identifiers.filter(Boolean).forEach((id) => {
    const val = String(id).trim();
    if (!val) return;
    rawList.push(val);
    buildIdentityAliases(val).forEach((a) => aliasSet.add(a.toLowerCase().replace(/^@/, '')));
  });

  try {
    for (const id of rawList) {
      const clean = id.replace(/^@/, '');
      const direct =
        localStorage.getItem(`ff_bank_app_name_${id}`) ||
        localStorage.getItem(`ff_bank_app_name_${clean}`);
      if (direct && direct.trim()) return direct.trim();
    }

    const reqsRaw = localStorage.getItem('ff_admin_banking_requests');
    if (reqsRaw) {
      const reqs = JSON.parse(reqsRaw);
      if (Array.isArray(reqs)) {
        const match = reqs.find((r: any) => {
          if (r?.status !== 'approved' || !r?.institutionName) return false;
          const rKeys = [r?.userId, r?.uid, r?.userHandle]
            .filter(Boolean)
            .map((s: string) => s.toLowerCase().replace(/^@/, ''));
          return rKeys.some((rk: string) => aliasSet.has(rk));
        });
        if (match?.institutionName) return String(match.institutionName).trim();
      }
    }
  } catch {
    // ignore storage errors
  }

  return null;
}

export interface ApprovedInternalBankPartner {
  id: string;
  uid?: string;
  name: string;
  handle: string;
  avatarUrl: string;
  role: string;
  bankName: string;
  capacityUSD: string;
  bio: string;
  isSelf?: boolean;
}

const PRESET_BANK_PARTNERS: ApprovedInternalBankPartner[] = [
  {
    id: 'demo-satoshi-nakamoto',
    uid: 'demo-satoshi-nakamoto',
    name: 'Satoshi Nakamoto',
    handle: 'satoshi_nakamoto',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'Sovereign Protocol Pioneer',
    bankName: 'Neo Tokyo Trust',
    capacityUSD: '125,000,000 AFNL',
    bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic ledger consensus and decentralized consumer banking.',
  },
  {
    id: 'user-lord_sterling',
    uid: 'user-lord_sterling',
    name: 'Lord Sterling',
    handle: 'sterling_vault',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'Swiss Freeport Trustee',
    bankName: 'Swiss Sovereign Reserve',
    capacityUSD: '500,000,000 AFNL',
    bio: 'Sovereign Inter-Bank Clearing Node. Direct physical gold depository bullion backing, multi-signature trust structures.',
  },
  {
    id: 'demo-jordan-belfort',
    uid: 'demo-jordan-belfort',
    name: 'Jordan Belfort',
    handle: 'jordan_belfort',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    role: 'Escrow Lead & Vault Allocator',
    bankName: 'Wall Street Liquidity Partners',
    capacityUSD: '250,000,000 AFNL',
    bio: 'Active reserve market-making vault and bilateral sovereign escrow authority. Specializing in high-velocity liquidity allocation.',
  },
  {
    id: 'demo-alex-morgan',
    uid: 'demo-alex-morgan',
    name: 'Alex Morgan',
    handle: 'alex_morgan',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    role: 'Institutional Commodity Desk Arbiter',
    bankName: 'Zurich Freeport Clearing',
    capacityUSD: '150,000,000 AFNL',
    bio: 'Precious metal clearing vault. Fully licensed and certified for gold bullion allocations, settlement audits, and sovereign clearing.',
  },
  {
    id: 'demo-super-admin',
    uid: 'demo-super-admin',
    name: 'Ranma (Root Master)',
    handle: 'super_admin_ranma',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    role: 'Super Admin · Protocol Treasury',
    bankName: 'Sovereign Root Reserve',
    capacityUSD: '1,000,000,000 AFNL',
    bio: 'Root Protocol Clearing Authority. Authorized to issue Final Coin loans, underwrite treasury liquidity, and oversee sovereign settlements.',
  },
  {
    id: 'demo-admin-officer',
    uid: 'demo-admin-officer',
    name: 'Awesome DBZ',
    handle: 'officer_dbz',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    role: 'Protocol Admin · Audit Officer',
    bankName: 'Custodial Reserve Node',
    capacityUSD: '350,000,000 AFNL',
    bio: 'Authorized Protocol Admin & Custodial Verification Clearing Bank. Issuing verified Final Coin credit facilities across the network.',
  },
];

function canonicalPartnerKey(val?: string): string {
  const clean = (val || '')
    .trim()
    .toLowerCase()
    .replace(/^@+/, '')
    .replace(/^user-/, '')
    .replace(/^demo-/, '');
  if (clean === 'ranma-superadmin' || clean === 'super-admin' || clean === 'super_admin_ranma') {
    return 'super_admin_ranma';
  }
  if (clean === 'dbz-admin' || clean === 'admin-officer' || clean === 'officer_dbz') {
    return 'officer_dbz';
  }
  if (clean === 'satoshi-nakamoto' || clean === 'satoshi_nakamoto') {
    return 'satoshi_nakamoto';
  }
  if (clean === 'jordan-belfort' || clean === 'jordan_belfort') {
    return 'jordan_belfort';
  }
  if (clean === 'alex-morgan' || clean === 'alex_morgan') {
    return 'alex_morgan';
  }
  if (clean === 'lord_sterling' || clean === 'sterling_vault') {
    return 'sterling_vault';
  }
  return clean;
}

export function getAllApprovedInternalBankPartners(
  platformUsers: Array<{
    uid?: string;
    userId?: string;
    name?: string;
    email?: string;
    avatarUrl?: string;
    bio?: string;
    role?: string;
  }> = [],
  currentUser?: {
    id?: string;
    uid?: string;
    handle?: string;
    name?: string;
    email?: string;
    avatarUrl?: string;
    role?: string;
  } | null
): ApprovedInternalBankPartner[] {
  const partnersByKey = new Map<string, ApprovedInternalBankPartner>();

  const registerPartner = (candidate: ApprovedInternalBankPartner, aliases: Array<string | undefined> = [], prioritize = false) => {
    const cleanHandle = (candidate.handle || candidate.id || 'user').replace(/^@+/, '');
    const allKeys = [candidate.id, candidate.uid, cleanHandle, ...aliases]
      .filter(Boolean)
      .map((k) => canonicalPartnerKey(String(k)));

    const existingKey = allKeys.find((k) => partnersByKey.has(k));
    const canonical = existingKey || canonicalPartnerKey(cleanHandle || candidate.id);
    if (!canonical) return;

    const normalized: ApprovedInternalBankPartner = {
      ...candidate,
      handle: cleanHandle,
    };

    if (existingKey) {
      const prev = partnersByKey.get(existingKey)!;
      if (prioritize) {
        partnersByKey.set(existingKey, { ...prev, ...normalized });
      } else {
        partnersByKey.set(existingKey, {
          ...normalized,
          ...prev,
          name: prev.name || normalized.name,
          bankName: prev.bankName || normalized.bankName,
          avatarUrl: prev.avatarUrl || normalized.avatarUrl,
          isSelf: prev.isSelf || normalized.isSelf,
        });
      }
    } else {
      partnersByKey.set(canonical, normalized);
    }
  };

  // 1. Current signed-in user if approved for internal banking (shown first with real bank node name)
  if (currentUser) {
    const selfApproved =
      currentUser.role === 'admin' ||
      currentUser.role === 'super_admin' ||
      isRegisteredInternalBank(currentUser.id) ||
      isRegisteredInternalBank(currentUser.uid) ||
      isRegisteredInternalBank(currentUser.handle) ||
      isRegisteredInternalBank(currentUser.email);

    if (selfApproved) {
      const selfCleanHandle = (currentUser.handle || currentUser.id || 'user').replace(/^@+/, '');
      const customBankName = getApprovedBankInstitutionName([
        currentUser.id,
        currentUser.uid,
        selfCleanHandle,
        currentUser.email,
      ]);
      registerPartner(
        {
          id: currentUser.id || currentUser.uid || selfCleanHandle,
          uid: currentUser.uid,
          name: currentUser.name || selfCleanHandle,
          handle: selfCleanHandle,
          avatarUrl:
            currentUser.avatarUrl ||
            `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name || selfCleanHandle)}&background=0f172a&color=f8fafc&bold=true&size=128`,
          role:
            currentUser.role === 'super_admin'
              ? 'Super Admin · Clearing Bank'
              : currentUser.role === 'admin'
                ? 'Protocol Admin · Clearing Bank'
                : 'Approved Clearing Bank',
          bankName: customBankName || 'Your Sovereign Treasury Node',
          capacityUSD: '100,000,000 AFNL',
          bio: 'Authorized Sovereign Clearing Bank. Licensed by Protocol Admin to issue sovereign credit, provide Final Coin loans, and process settlement clearances.',
          isSelf: true,
        },
        [currentUser.email],
        true
      );
    }
  }

  // 2. Preset & seeded bank partners (respecting delist checks)
  PRESET_BANK_PARTNERS.forEach((p) => {
    if (isRegisteredInternalBank(p.id) || isRegisteredInternalBank(p.handle)) {
      const overrideName = getApprovedBankInstitutionName([p.id, p.uid, p.handle]);
      registerPartner({ ...p, bankName: overrideName || p.bankName }, [p.uid]);
    }
  });

  // 3. Active admin / super admin members from ff_admin_members_v1
  try {
    const adminsRaw = localStorage.getItem('ff_admin_members_v1');
    if (adminsRaw) {
      const members = JSON.parse(adminsRaw);
      if (Array.isArray(members)) {
        members.forEach((m: any) => {
          if (!m || m.status === 'deactivated') return;
          const cleanH = (m.handle || m.id || '').replace(/^@+/, '');
          if (!cleanH) return;
          if (!isRegisteredInternalBank(cleanH) && !isRegisteredInternalBank(m.id)) return;
          const customName = getApprovedBankInstitutionName([m.id, cleanH, m.email]);
          registerPartner(
            {
              id: cleanH,
              uid: m.id,
              name: m.name || cleanH,
              handle: cleanH,
              avatarUrl:
                m.avatarUrl ||
                `https://ui-avatars.com/api/?name=${encodeURIComponent(m.name || cleanH)}&background=0f172a&color=f8fafc&bold=true&size=128`,
              role: m.role === 'super_admin' ? `Super Admin · ${m.title || 'Treasury'}` : `Protocol Admin · ${m.title || 'Officer'}`,
              bankName: customName || (m.role === 'super_admin' ? 'Sovereign Root Reserve' : 'Protocol Reserve Node'),
              capacityUSD: m.role === 'super_admin' ? '500,000,000 AFNL' : '200,000,000 AFNL',
              bio: `${m.title || 'Authorized Protocol Administrator'} operating an internal clearing node for Final Coin lending and bilateral settlement.`,
            },
            [m.email, m.id]
          );
        });
      }
    }
  } catch {
    // ignore storage errors
  }

  // 4. Platform users passed in (SAMPLE_USERS etc.) who are approved internal banks
  platformUsers.forEach((u) => {
    const isBank =
      u.role === 'admin' ||
      u.role === 'super_admin' ||
      isRegisteredInternalBank(u.userId) ||
      isRegisteredInternalBank(u.uid) ||
      isRegisteredInternalBank(u.email);
    if (!isBank) return;
    const cleanH = (u.userId || u.uid || 'user').replace(/^@+/, '');
    const customName = getApprovedBankInstitutionName([u.userId, u.uid, cleanH, u.email]);
    registerPartner(
      {
        id: u.userId || u.uid || cleanH,
        uid: u.uid,
        name: u.name || cleanH,
        handle: cleanH,
        avatarUrl:
          u.avatarUrl ||
          `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name || cleanH)}&background=0f172a&color=f8fafc&bold=true&size=128`,
        role:
          u.role === 'super_admin'
            ? 'Super Admin · Clearing Bank'
            : u.role === 'admin'
              ? 'Protocol Admin · Clearing Bank'
              : 'Approved Clearing Bank',
        bankName: customName || 'Sovereign Clearing Vault',
        capacityUSD: '100,000,000 AFNL',
        bio: u.bio || 'Authorized Sovereign Clearing Bank licensed to provide Final Coin loans and manage bilateral credit agreements.',
      },
      [u.email]
    );
  });

  // 5. Locally registered users from final_finance_users_registry
  try {
    const regRaw = localStorage.getItem('final_finance_users_registry');
    if (regRaw) {
      const regUsers = JSON.parse(regRaw);
      if (Array.isArray(regUsers)) {
        regUsers.forEach((u: any) => {
          if (!u) return;
          const isBank =
            u.role === 'admin' ||
            u.role === 'super_admin' ||
            isRegisteredInternalBank(u.id) ||
            isRegisteredInternalBank(u.uid) ||
            isRegisteredInternalBank(u.handle) ||
            isRegisteredInternalBank(u.email);
          if (!isBank) return;
          const cleanH = (u.handle || u.id || u.uid || 'member').replace(/^@+/, '');
          const customName = getApprovedBankInstitutionName([u.id, u.uid, cleanH, u.email]);
          registerPartner(
            {
              id: u.id || cleanH,
              uid: u.uid,
              name: u.name || cleanH,
              handle: cleanH,
              avatarUrl:
                u.avatarUrl ||
                `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name || cleanH)}&background=0f172a&color=f8fafc&bold=true&size=128`,
              role: u.role === 'admin' || u.role === 'super_admin' ? 'Protocol Admin · Clearing Bank' : 'Approved Clearing Bank',
              bankName: customName || 'Sovereign Clearing Vault',
              capacityUSD: '100,000,000 AFNL',
              bio: u.bio || 'Authorized Sovereign Clearing Bank licensed by Protocol Admin to provide Final Coin loans.',
            },
            [u.email]
          );
        });
      }
    }
  } catch {
    // ignore storage errors
  }

  // 6. Approved banking requests in ff_admin_banking_requests
  try {
    const reqsRaw = localStorage.getItem('ff_admin_banking_requests');
    if (reqsRaw) {
      const reqs = JSON.parse(reqsRaw);
      if (Array.isArray(reqs)) {
        reqs.forEach((r: any) => {
          if (!r || r.status !== 'approved') return;
          const cleanH = (r.userHandle || r.userId || r.uid || '').replace(/^@+/, '');
          if (!cleanH) return;
          if (localStorage.getItem(`ff_bank_app_status_${cleanH}`) === 'delisted') return;
          const displayName =
            r.userName ||
            cleanH
              .split(/[_\-\s]+/)
              .map((w: string) => w.charAt(0).toUpperCase() + w.slice(1))
              .join(' ');
          registerPartner(
            {
              id: r.userId || cleanH,
              uid: r.uid,
              name: displayName,
              handle: cleanH,
              avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=4f46e5&color=ffffff&bold=true&size=128`,
              role: 'Approved Clearing Bank',
              bankName: r.institutionName || 'Authorized Clearing Bank',
              capacityUSD: r.capitalReserves || 'Held Final Wallet Balances',
              bio: r.reason || 'Authorized Sovereign Clearing Bank licensed to provide Final Coin loans and manage bilateral credit.',
            },
            [r.userId, r.uid]
          );
        });
      }
    }
  } catch {
    // ignore storage errors
  }

  // 7. Catch-all scan of localStorage ff_bank_app_status_* === 'approved'
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || !key.startsWith('ff_bank_app_status_')) continue;
      if (localStorage.getItem(key) !== 'approved') continue;
      const rawId = key.slice('ff_bank_app_status_'.length);
      const cleanH = rawId.replace(/^@+/, '').replace(/^user-/, '');
      if (!cleanH) continue;
      const customName = getApprovedBankInstitutionName([rawId, cleanH]);
      const formattedName = cleanH
        .split(/[_\-\s]+/)
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ');
      registerPartner(
        {
          id: cleanH,
          uid: rawId.startsWith('user-') ? rawId : `user-${cleanH}`,
          name: formattedName || cleanH,
          handle: cleanH,
          avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(formattedName || cleanH)}&background=0f172a&color=f8fafc&bold=true&size=128`,
          role: 'Approved Clearing Bank',
          bankName: customName || 'Sovereign Clearing Vault',
          capacityUSD: '100,000,000 AFNL',
          bio: 'Authorized Sovereign Clearing Bank licensed by Protocol Admin to provide Final Coin loans.',
        },
        [rawId]
      );
    }
  } catch {
    // ignore storage errors
  }

  return Array.from(partnersByKey.values());
}

export function isFinalLoanCoin(coinSymbol?: string): boolean {
  if (!coinSymbol) return true;
  const sym = coinSymbol.trim().toUpperCase();
  return (
    sym === 'AFNL' ||
    sym === 'FNL' ||
    sym === 'FINAL' ||
    sym.endsWith('FNL') ||
    sym.includes('FINAL')
  );
}

export function calculateMonthlyInstallment(
  amount: number,
  interestRateApr: number,
  termDays: number
): number {
  const principal = Math.max(0, amount || 0);
  if (principal <= 0) return 0;
  const apr = Math.max(0, interestRateApr || 0);
  const months = Math.max(1, (termDays || 30) / 30);
  if (apr === 0) {
    return Math.round((principal / months) * 100) / 100;
  }
  const monthlyRate = apr / 100 / 12;
  const factor = Math.pow(1 + monthlyRate, months);
  const monthly = (principal * monthlyRate * factor) / (factor - 1);
  return Math.round(monthly * 100) / 100;
}

function emitLoansUpdated() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('final_finance_loans_updated'));
  }
}

export function getAllLoans(): LoanRecord[] {
  const data = localStorage.getItem(LOANS_KEY);
  if (!data) return [];
  try { return JSON.parse(data); } catch { return []; }
}

export function saveAllLoans(loans: LoanRecord[]) {
  localStorage.setItem(LOANS_KEY, JSON.stringify(loans));
}

export function createLoan(loan: LoanRecord) {
  const all = getAllLoans();
  const normalized: LoanRecord = {
    ...loan,
    monthlyInstallment:
      typeof loan.monthlyInstallment === 'number'
        ? loan.monthlyInstallment
        : calculateMonthlyInstallment(loan.amount, loan.interestRate, loan.termDays),
  };
  all.unshift(normalized);
  saveAllLoans(all);
  emitLoansUpdated();
}

export function acceptLoanOffer(loanId: string): LoanRecord | null {
  const all = getAllLoans();
  const idx = all.findIndex((l) => l.id === loanId);
  if (idx === -1) return null;

  const now = Date.now();
  const termDays = Math.max(1, all[idx].termDays || 30);
  all[idx].status = 'active';
  all[idx].issuedAtMs = now;
  all[idx].timestamp = new Date(now).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  all[idx].nextDueDateMs = now + Math.min(30, termDays) * 24 * 60 * 60 * 1000;
  all[idx].amountPaid = all[idx].amountPaid || 0;
  if (typeof all[idx].monthlyInstallment !== 'number') {
    all[idx].monthlyInstallment = calculateMonthlyInstallment(
      all[idx].amount,
      all[idx].interestRate,
      all[idx].termDays
    );
  }
  saveAllLoans(all);
  emitLoansUpdated();
  return all[idx];
}

export function declineLoanOffer(loanId: string): LoanRecord | null {
  const all = getAllLoans();
  const idx = all.findIndex((l) => l.id === loanId);
  if (idx === -1) return null;

  all[idx].status = 'declined';
  saveAllLoans(all);
  emitLoansUpdated();
  return all[idx];
}

export function getLoanTotalDue(loan: LoanRecord): number {
  return Math.round((loan.amount + loan.amount * ((loan.interestRate || 0) / 100)) * 100) / 100;
}

export function getLoanRemainingBalance(loan: LoanRecord): number {
  const totalDue = getLoanTotalDue(loan);
  const paid = loan.amountPaid || 0;
  return Math.max(0, Math.round((totalDue - paid) * 100) / 100);
}

export function getLoanNextDueDateMs(loan: LoanRecord): number {
  if (typeof loan.nextDueDateMs === 'number' && loan.nextDueDateMs > 0) {
    return loan.nextDueDateMs;
  }
  const issuedMs = loan.issuedAtMs || Date.now();
  const termDays = loan.termDays || 30;
  return issuedMs + termDays * 24 * 60 * 60 * 1000;
}

export interface LoanTimelineMetrics {
  issuedMs: number;
  finalDueMs: number;
  nextDueMs: number;
  totalDurationDays: number;
  elapsedDays: number;
  daysUntilNextDue: number;
  daysUntilFinalDue: number;
  timeElapsedPct: number;
  repaymentPct: number;
  totalDue: number;
  amountPaid: number;
  remainingBalance: number;
  monthlyInstallment: number;
  isOverdue: boolean;
}

export function getLoanTimelineMetrics(loan: LoanRecord, nowMs: number = Date.now()): LoanTimelineMetrics {
  const dayMs = 24 * 60 * 60 * 1000;
  const issuedMs = loan.issuedAtMs || nowMs;
  const totalDurationDays = Math.max(1, loan.termDays || 30);
  const finalDueMs = Math.max(issuedMs + totalDurationDays * dayMs, getLoanNextDueDateMs(loan));
  const nextDueMs = getLoanNextDueDateMs(loan);

  const totalWindowMs = Math.max(dayMs, finalDueMs - issuedMs);
  const elapsedMs = loan.status === 'pending_offer' ? 0 : Math.max(0, nowMs - issuedMs);
  const elapsedDays = Math.max(0, Math.floor(elapsedMs / dayMs));
  const daysUntilNextDue = Math.ceil((nextDueMs - nowMs) / dayMs);
  const daysUntilFinalDue = Math.ceil((finalDueMs - nowMs) / dayMs);
  const timeElapsedPct = loan.status === 'pending_offer'
    ? 0
    : Math.min(100, Math.max(0, Math.round((elapsedMs / totalWindowMs) * 100)));

  const totalDue = getLoanTotalDue(loan);
  const amountPaid = loan.status === 'repaid' ? totalDue : (loan.amountPaid || 0);
  const remainingBalance = loan.status === 'repaid' ? 0 : getLoanRemainingBalance(loan);
  const repaymentPct = totalDue > 0 ? Math.min(100, Math.max(0, Math.round((amountPaid / totalDue) * 100))) : 0;
  const isOverdue = loan.status === 'active' && nowMs > nextDueMs;
  const monthlyInstallment =
    typeof loan.monthlyInstallment === 'number'
      ? loan.monthlyInstallment
      : calculateMonthlyInstallment(loan.amount, loan.interestRate, loan.termDays);

  return {
    issuedMs,
    finalDueMs,
    nextDueMs,
    totalDurationDays,
    elapsedDays,
    daysUntilNextDue,
    daysUntilFinalDue,
    timeElapsedPct,
    repaymentPct,
    totalDue,
    amountPaid,
    remainingBalance,
    monthlyInstallment,
    isOverdue,
  };
}

export interface LoanInstallmentItem {
  installmentNumber: number;
  totalInstallments: number;
  dayOffset: number;
  dueDateMs: number;
  amountDue: number;
  amountPaid: number;
  amountRemaining: number;
  status: 'paid' | 'partial' | 'overdue' | 'due_next' | 'upcoming' | 'pending_approval' | 'declined' | 'defaulted';
}

export function getLoanInstallmentSchedule(
  loan: LoanRecord,
  nowMs: number = Date.now()
): LoanInstallmentItem[] {
  const dayMs = 24 * 60 * 60 * 1000;
  const termDays = Math.max(1, loan.termDays || 30);
  const numInstallments = Math.max(1, Math.ceil(termDays / 30));
  const totalDue = getLoanTotalDue(loan);
  const issuedMs = loan.issuedAtMs || nowMs;

  const totalPaid =
    loan.status === 'repaid'
      ? totalDue
      : loan.status === 'pending_offer' || loan.status === 'declined'
      ? 0
      : Math.min(totalDue, loan.amountPaid || 0);

  const baseInstallment = Math.floor((totalDue / numInstallments) * 100) / 100;
  let allocatedTotal = 0;
  let remainingPaidPool = totalPaid;
  let assignedDueNext = false;

  const items: LoanInstallmentItem[] = [];

  for (let i = 1; i <= numInstallments; i++) {
    const isLast = i === numInstallments;
    const amountDue = isLast
      ? Math.max(0, Math.round((totalDue - allocatedTotal) * 100) / 100)
      : baseInstallment;
    allocatedTotal = Math.round((allocatedTotal + amountDue) * 100) / 100;

    const dayOffset = isLast ? termDays : Math.min(termDays, i * 30);
    const dueDateMs = issuedMs + dayOffset * dayMs;

    const paidTowardThis = Math.min(amountDue, Math.max(0, Math.round(remainingPaidPool * 100) / 100));
    remainingPaidPool = Math.max(0, Math.round((remainingPaidPool - paidTowardThis) * 100) / 100);
    const amountRemaining = Math.max(0, Math.round((amountDue - paidTowardThis) * 100) / 100);

    let status: LoanInstallmentItem['status'];
    if (loan.status === 'pending_offer') {
      status = 'pending_approval';
    } else if (loan.status === 'declined') {
      status = 'declined';
    } else if (loan.status === 'defaulted') {
      status = amountRemaining <= 0.009 ? 'paid' : 'defaulted';
    } else if (loan.status === 'repaid' || amountRemaining <= 0.009) {
      status = 'paid';
    } else if (paidTowardThis > 0.009) {
      status = 'partial';
    } else if (nowMs > dueDateMs) {
      status = 'overdue';
    } else if (!assignedDueNext) {
      status = 'due_next';
      assignedDueNext = true;
    } else {
      status = 'upcoming';
    }

    items.push({
      installmentNumber: i,
      totalInstallments: numInstallments,
      dayOffset,
      dueDateMs,
      amountDue,
      amountPaid: paidTowardThis,
      amountRemaining,
      status,
    });
  }

  return items;
}

export interface ActiveCoinLoanCirculation {
  coinSymbol: string;
  activePrincipal: number;
  activeRemainingOwed: number;
  activeCount: number;
}

export function getActiveLoanCirculationByCoin(): Record<string, ActiveCoinLoanCirculation> {
  const all = getAllLoans();
  const map: Record<string, ActiveCoinLoanCirculation> = {};

  all.forEach((loan) => {
    if (loan.status !== 'active') return;
    const sym = (loan.coinSymbol || 'AFNL').trim().toUpperCase();
    const remaining = getLoanRemainingBalance(loan);
    if (!map[sym]) {
      map[sym] = {
        coinSymbol: sym,
        activePrincipal: 0,
        activeRemainingOwed: 0,
        activeCount: 0,
      };
    }
    map[sym].activePrincipal = Math.round((map[sym].activePrincipal + (loan.amount || 0)) * 100) / 100;
    map[sym].activeRemainingOwed = Math.round((map[sym].activeRemainingOwed + remaining) * 100) / 100;
    map[sym].activeCount += 1;
  });

  return map;
}

export interface AnonymousCurrencyDebtBreakdown {
  coinSymbol: string;
  totalOwed: number;
  activeCount: number;
  overdueCount: number;
  defaultedCount: number;
}

export interface AnonymousIssuerDebtSummary {
  totalActiveLoans: number;
  totalOverdueLoans: number;
  totalDefaultedLoans: number;
  totalRepaidLoans: number;
  byCurrency: AnonymousCurrencyDebtBreakdown[];
}

export function getAnonymousIssuerDebtSummary(
  identifiers: Array<string | undefined>,
  nowMs: number = Date.now()
): AnonymousIssuerDebtSummary {
  const targetAliases = new Set<string>();
  identifiers.forEach((id) => {
    buildIdentityAliases(id).forEach((alias) => {
      targetAliases.add(alias.toLowerCase().replace(/^@/, ''));
    });
  });

  if (targetAliases.size === 0) {
    return {
      totalActiveLoans: 0,
      totalOverdueLoans: 0,
      totalDefaultedLoans: 0,
      totalRepaidLoans: 0,
      byCurrency: [],
    };
  }

  const all = getAllLoans();
  const currencyMap = new Map<string, AnonymousCurrencyDebtBreakdown>();
  let totalActiveLoans = 0;
  let totalOverdueLoans = 0;
  let totalDefaultedLoans = 0;
  let totalRepaidLoans = 0;

  all.forEach((loan) => {
    const borrowerAliases = [
      ...buildIdentityAliases(loan.borrowerId),
      ...buildIdentityAliases(loan.borrowerHandle),
      ...buildIdentityAliases(loan.borrowerName),
    ].map((a) => a.toLowerCase().replace(/^@/, ''));

    if (!borrowerAliases.some((a) => targetAliases.has(a))) return;

    if (loan.status === 'repaid') {
      totalRepaidLoans += 1;
      return;
    }

    if (loan.status !== 'active' && loan.status !== 'defaulted') {
      return;
    }

    const sym = (loan.coinSymbol || 'AFNL').trim().toUpperCase();
    const remaining = getLoanRemainingBalance(loan);
    if (remaining <= 0 && loan.status !== 'defaulted') return;

    const isOverdue = loan.status === 'active' && nowMs > getLoanNextDueDateMs(loan);
    if (loan.status === 'active') totalActiveLoans += 1;
    if (isOverdue) totalOverdueLoans += 1;
    if (loan.status === 'defaulted') totalDefaultedLoans += 1;

    const prev = currencyMap.get(sym) || {
      coinSymbol: sym,
      totalOwed: 0,
      activeCount: 0,
      overdueCount: 0,
      defaultedCount: 0,
    };

    prev.totalOwed = Math.round((prev.totalOwed + remaining) * 100) / 100;
    if (loan.status === 'active') prev.activeCount += 1;
    if (isOverdue) prev.overdueCount += 1;
    if (loan.status === 'defaulted') prev.defaultedCount += 1;

    currencyMap.set(sym, prev);
  });

  return {
    totalActiveLoans,
    totalOverdueLoans,
    totalDefaultedLoans,
    totalRepaidLoans,
    byCurrency: Array.from(currencyMap.values()).sort((a, b) => b.totalOwed - a.totalOwed),
  };
}

export function payAheadLoan(loanId: string, paymentAmount: number): { updatedLoan: LoanRecord | null; fullyPaid: boolean } {
  const all = getAllLoans();
  const idx = all.findIndex((l) => l.id === loanId);
  if (idx === -1) return { updatedLoan: null, fullyPaid: false };

  const loan = all[idx];
  const totalDue = getLoanTotalDue(loan);
  const prevPaid = loan.amountPaid || 0;
  const nextPaid = Math.min(totalDue, Math.round((prevPaid + paymentAmount) * 100) / 100);
  const remaining = Math.max(0, Math.round((totalDue - nextPaid) * 100) / 100);
  const fullyPaid = remaining <= 0.009;

  loan.amountPaid = nextPaid;
  loan.lastPaymentAtMs = Date.now();

  if (fullyPaid) {
    loan.status = 'repaid';
  } else {
    const currentDue = getLoanNextDueDateMs(loan);
    const termDays = loan.termDays || 30;
    const daysAdvanced = Math.max(1, Math.round((paymentAmount / Math.max(1, totalDue)) * termDays));
    loan.nextDueDateMs = Math.max(currentDue, Date.now()) + daysAdvanced * 24 * 60 * 60 * 1000;
  }

  saveAllLoans(all);
  emitLoansUpdated();
  return { updatedLoan: loan, fullyPaid };
}

export function updateLoanStatus(loanId: string, status: 'repaid' | 'defaulted') {
  const all = getAllLoans();
  const idx = all.findIndex(l => l.id === loanId);
  if (idx !== -1) {
    all[idx].status = status;
    if (status === 'repaid') {
      all[idx].amountPaid = getLoanTotalDue(all[idx]);
      all[idx].lastPaymentAtMs = Date.now();
    }
    saveAllLoans(all);

    const loan = all[idx];
    if (
      status === 'defaulted' &&
      isFinalLoanCoin(loan.coinSymbol) &&
      (isRegisteredInternalBank(loan.lenderId) || isRegisteredInternalBank(loan.lenderHandle))
    ) {
      const borrowerId = loan.borrowerId;
      const key = `ff_default_count_${borrowerId}`;
      const current = parseInt(localStorage.getItem(key) || '0', 10);
      localStorage.setItem(key, (current + 1).toString());
    }
    emitLoansUpdated();
  }
}

export function getUserDefaultCount(userId: string, uid?: string): number {
  return getUserFinalLoanDefaultCount(userId, uid);
}

export function getUserFinalLoanDefaultCount(userId: string, uid?: string): number {
  const borrowerAliases = new Set(
    buildIdentityAliases(userId, uid).map((a) => a.toLowerCase().replace(/^@/, ''))
  );

  const allLoans = getAllLoans();
  const defaultedFinalLoansFromBanks = allLoans.filter((loan) => {
    if (loan.status !== 'defaulted') return false;
    if (!isFinalLoanCoin(loan.coinSymbol)) return false;

    const lenderRegistered =
      isRegisteredInternalBank(loan.lenderId) || isRegisteredInternalBank(loan.lenderHandle);
    if (!lenderRegistered) return false;

    const loanBorrowerAliases = buildIdentityAliases(loan.borrowerId, loan.borrowerHandle).map((a) =>
      a.toLowerCase().replace(/^@/, '')
    );
    return loanBorrowerAliases.some((a) => borrowerAliases.has(a));
  });

  let storedCount = 0;
  try {
    buildIdentityAliases(userId, uid).forEach((alias) => {
      const clean = alias.replace(/^@/, '');
      const val = parseInt(localStorage.getItem(`ff_default_count_${clean}`) || '0', 10);
      if (!isNaN(val) && val > storedCount) {
        storedCount = val;
      }
    });
  } catch {
    // ignore storage errors
  }

  return Math.max(defaultedFinalLoansFromBanks.length, storedCount);
}

export function getLoansForUser(userId: string, extraHandles: Array<string | undefined> = []) {
  const userAliases = new Set<string>();
  buildIdentityAliases(userId).forEach((a) => userAliases.add(a.toLowerCase().replace(/^@/, '')));
  extraHandles.forEach((h) => {
    buildIdentityAliases(h).forEach((a) => userAliases.add(a.toLowerCase().replace(/^@/, '')));
  });

  const all = getAllLoans();
  const matchesAliases = (idVal?: string, handleVal?: string) => {
    const cand = [...buildIdentityAliases(idVal), ...buildIdentityAliases(handleVal)].map((a) =>
      a.toLowerCase().replace(/^@/, '')
    );
    return cand.some((c) => userAliases.has(c));
  };

  return {
    issued: all.filter((l) => matchesAliases(l.lenderId, l.lenderHandle)),
    received: all.filter((l) => matchesAliases(l.borrowerId, l.borrowerHandle)),
  };
}

export function seedExampleLoansForUser(
  userId: string,
  options?: { uid?: string; handle?: string; name?: string; avatarUrl?: string; reset?: boolean }
): boolean {
  if (!userId) return false;
  const cleanKey = userId.toLowerCase().replace(/^@/, '');
  const seedFlagKey = `${SAMPLE_SEED_FLAG_PREFIX}${cleanKey}`;

  if (!options?.reset) {
    try {
      if (localStorage.getItem(seedFlagKey) === '1') {
        return false;
      }
    } catch {
      // ignore storage errors
    }
  }

  const userAliases = new Set(
    [
      ...buildIdentityAliases(userId, options?.uid),
      ...buildIdentityAliases(options?.handle),
    ].map((a) => a.toLowerCase().replace(/^@/, ''))
  );

  const pickCounterparty = (preferredHandle: string, fallbackHandle: string) => {
    const preferred = SAMPLE_COUNTERPARTIES.find((c) => c.handle === preferredHandle);
    if (preferred && !userAliases.has(preferred.handle) && !userAliases.has(preferred.id)) {
      return preferred;
    }
    const fallback = SAMPLE_COUNTERPARTIES.find((c) => c.handle === fallbackHandle);
    if (fallback && !userAliases.has(fallback.handle) && !userAliases.has(fallback.id)) {
      return fallback;
    }
    return SAMPLE_COUNTERPARTIES.find((c) => !userAliases.has(c.handle)) || SAMPLE_COUNTERPARTIES[0];
  };

  const dayMs = 24 * 60 * 60 * 1000;
  const now = Date.now();
  const fmtTs = (ms: number) => new Date(ms).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';

  const selfHandle = (options?.handle || userId).replace(/^@/, '');
  const selfAtHandle = `@${selfHandle}`;
  const selfName = options?.name || selfHandle;
  const selfAvatar =
    options?.avatarUrl ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(selfName)}&background=f59e0b&color=0f172a&bold=true&size=128`;

  const lender1 = pickCounterparty('jordan_belfort', 'alex_chen');
  const lender2 = pickCounterparty('alex_morgan', 'satoshi_nakamoto');
  const lender3 = pickCounterparty('satoshi_nakamoto', 'sterling_vault');
  const offerProvider = pickCounterparty('satoshi_nakamoto', 'jordan_belfort');
  const borrower1 = pickCounterparty('elena_rostova', 'alex_chen');
  const borrower2 = pickCounterparty('marcus_vance', 'jordan_belfort');
  const borrower3 = pickCounterparty('sterling_vault', 'alex_morgan');

  const sampleBatch: LoanRecord[] = [
    // 0. Pending Loan Offer awaiting user's final approval in Ongoing Loans I've Taken
    {
      id: `sample-loan-${cleanKey}-offer-1`,
      lenderId: offerProvider.id,
      lenderHandle: `@${offerProvider.handle}`,
      lenderName: offerProvider.name,
      lenderAvatar: offerProvider.avatar,
      borrowerId: userId,
      borrowerHandle: selfAtHandle,
      borrowerName: selfName,
      borrowerAvatar: selfAvatar,
      amount: 1800,
      coinSymbol: 'AFNL',
      interestRate: 4.5,
      termDays: 90,
      monthlyInstallment: calculateMonthlyInstallment(1800, 4.5, 90),
      status: 'pending_offer',
      timestamp: fmtTs(now - 2 * 60 * 60 * 1000),
      issuedAtMs: now - 2 * 60 * 60 * 1000,
      nextDueDateMs: now + 30 * dayMs,
      amountPaid: 0,
      isExample: true,
    },
    // 1. Ongoing loan user took from Jordan Belfort (payable ahead in full or partial)
    {
      id: `sample-loan-${cleanKey}-taken-1`,
      lenderId: lender1.id,
      lenderHandle: `@${lender1.handle}`,
      lenderName: lender1.name,
      lenderAvatar: lender1.avatar,
      borrowerId: userId,
      borrowerHandle: selfAtHandle,
      borrowerName: selfName,
      borrowerAvatar: selfAvatar,
      amount: 2500,
      coinSymbol: 'AFNL',
      interestRate: 5.0,
      termDays: 30,
      monthlyInstallment: calculateMonthlyInstallment(2500, 5.0, 30),
      status: 'active',
      timestamp: fmtTs(now - 10 * dayMs),
      issuedAtMs: now - 10 * dayMs,
      nextDueDateMs: now + 20 * dayMs,
      amountPaid: 0,
      isExample: true,
    },
    // 2. Ongoing loan user took from Alex Morgan (already partially paid ahead so progress shows)
    {
      id: `sample-loan-${cleanKey}-taken-2`,
      lenderId: lender2.id,
      lenderHandle: `@${lender2.handle}`,
      lenderName: lender2.name,
      lenderAvatar: lender2.avatar,
      borrowerId: userId,
      borrowerHandle: selfAtHandle,
      borrowerName: selfName,
      borrowerAvatar: selfAvatar,
      amount: 1200,
      coinSymbol: 'AFNL',
      interestRate: 4.0,
      termDays: 45,
      monthlyInstallment: calculateMonthlyInstallment(1200, 4.0, 45),
      status: 'active',
      timestamp: fmtTs(now - 18 * dayMs),
      issuedAtMs: now - 18 * dayMs,
      nextDueDateMs: now + 27 * dayMs,
      amountPaid: 420,
      lastPaymentAtMs: now - 3 * dayMs,
      isExample: true,
    },
    // 3. Concluded repaid loan user took from Satoshi Nakamoto
    {
      id: `sample-loan-${cleanKey}-taken-repaid`,
      lenderId: lender3.id,
      lenderHandle: `@${lender3.handle}`,
      lenderName: lender3.name,
      lenderAvatar: lender3.avatar,
      borrowerId: userId,
      borrowerHandle: selfAtHandle,
      borrowerName: selfName,
      borrowerAvatar: selfAvatar,
      amount: 1500,
      coinSymbol: 'AFNL',
      interestRate: 3.5,
      termDays: 30,
      monthlyInstallment: calculateMonthlyInstallment(1500, 3.5, 30),
      status: 'repaid',
      timestamp: fmtTs(now - 42 * dayMs),
      issuedAtMs: now - 42 * dayMs,
      nextDueDateMs: now - 12 * dayMs,
      amountPaid: 1552.5,
      lastPaymentAtMs: now - 15 * dayMs,
      isExample: true,
    },
    // 4. Ongoing loan someone took from the user (Elena Rostova)
    {
      id: `sample-loan-${cleanKey}-lent-1`,
      lenderId: userId,
      lenderHandle: selfAtHandle,
      lenderName: selfName,
      lenderAvatar: selfAvatar,
      borrowerId: borrower1.id,
      borrowerHandle: `@${borrower1.handle}`,
      borrowerName: borrower1.name,
      borrowerAvatar: borrower1.avatar,
      amount: 4000,
      coinSymbol: 'AFNL',
      interestRate: 4.5,
      termDays: 30,
      monthlyInstallment: calculateMonthlyInstallment(4000, 4.5, 30),
      status: 'active',
      timestamp: fmtTs(now - 8 * dayMs),
      issuedAtMs: now - 8 * dayMs,
      nextDueDateMs: now + 22 * dayMs,
      amountPaid: 1000,
      lastPaymentAtMs: now - 2 * dayMs,
      isExample: true,
    },
    // 5. Overdue ongoing loan someone took from the user (Marcus Vance - allows testing Declare Default!)
    {
      id: `sample-loan-${cleanKey}-lent-overdue`,
      lenderId: userId,
      lenderHandle: selfAtHandle,
      lenderName: selfName,
      lenderAvatar: selfAvatar,
      borrowerId: borrower2.id,
      borrowerHandle: `@${borrower2.handle}`,
      borrowerName: borrower2.name,
      borrowerAvatar: borrower2.avatar,
      amount: 3000,
      coinSymbol: 'AFNL',
      interestRate: 6.0,
      termDays: 14,
      monthlyInstallment: calculateMonthlyInstallment(3000, 6.0, 14),
      status: 'active',
      timestamp: fmtTs(now - 20 * dayMs),
      issuedAtMs: now - 20 * dayMs,
      nextDueDateMs: now - 6 * dayMs,
      amountPaid: 0,
      isExample: true,
    },
    // 6. Concluded repaid loan someone took from the user (Lord Sterling)
    {
      id: `sample-loan-${cleanKey}-lent-repaid`,
      lenderId: userId,
      lenderHandle: selfAtHandle,
      lenderName: selfName,
      lenderAvatar: selfAvatar,
      borrowerId: borrower3.id,
      borrowerHandle: `@${borrower3.handle}`,
      borrowerName: borrower3.name,
      borrowerAvatar: borrower3.avatar,
      amount: 5000,
      coinSymbol: 'AFNL',
      interestRate: 4.0,
      termDays: 30,
      monthlyInstallment: calculateMonthlyInstallment(5000, 4.0, 30),
      status: 'repaid',
      timestamp: fmtTs(now - 50 * dayMs),
      issuedAtMs: now - 50 * dayMs,
      nextDueDateMs: now - 20 * dayMs,
      amountPaid: 5200,
      lastPaymentAtMs: now - 22 * dayMs,
      isExample: true,
    },
  ];

  const existing = getAllLoans();
  const sampleIds = new Set(sampleBatch.map((s) => s.id));
  const preserved = options?.reset
    ? existing.filter((l) => !sampleIds.has(l.id))
    : existing;
  const existingIds = new Set(preserved.map((l) => l.id));
  const toInsert = sampleBatch.filter((s) => !existingIds.has(s.id));

  if (toInsert.length > 0 || options?.reset) {
    saveAllLoans([...toInsert, ...preserved]);
    emitLoansUpdated();
  }

  try {
    localStorage.setItem(seedFlagKey, '1');
  } catch {
    // ignore storage errors
  }

  return toInsert.length > 0;
}




