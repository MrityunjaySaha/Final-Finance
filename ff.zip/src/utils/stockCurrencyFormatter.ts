import { StockItem } from '../types/stocks';

export interface StockCurrencyInfo {
  code: string;
  isFinal: boolean;
  isUSD: boolean;
  isStable: boolean;
  isCrypto: boolean;
  cryptoRateUSD: number;
}

/**
 * Standard exchange rates in USD for cryptocurrencies.
 */
export const CRYPTO_RATES_USD: Record<string, number> = {
  BTC: 65000.0,  // 1 BTC = $65,000.00 USD
  ETH: 3400.0,   // 1 ETH = $3,400.00 USD
  SOL: 180.0,    // 1 SOL = $180.00 USD
};

/**
 * Inspects a stock item and determines its currency code, market category, and exchange rate.
 */
export function getStockCurrencyInfo(stock?: StockItem | null): StockCurrencyInfo {
  if (!stock) {
    return { code: 'USD', isFinal: false, isUSD: true, isStable: false, isCrypto: false, cryptoRateUSD: 1.0 };
  }

  const rawSymbol = stock.issuanceCoinSymbol || '';
  const cleanedSymbol = rawSymbol.replace('$', '').trim();
  const marketType = stock.marketType;

  // 1. Stablecoins (1:1 USD Pegged)
  const isStable =
    marketType === 'stable' ||
    cleanedSymbol === 'USDC' ||
    cleanedSymbol === 'USDT';

  // 2. Cryptocurrencies (Convertible to USD)
  const isCrypto =
    marketType === 'crypto' ||
    cleanedSymbol === 'BTC' ||
    cleanedSymbol === 'ETH' ||
    cleanedSymbol === 'SOL';

  // 3. Fiat (US Equities / US Dollar)
  const isUSD =
    marketType === 'fiat' ||
    marketType === 'global' ||
    cleanedSymbol === 'USD' ||
    stock.exchange === 'NASDAQ' ||
    stock.exchange === 'NYSE';

  // 4. Final Coins (Unpegged Sovereign Assets)
  const isFinal =
    !isStable &&
    !isCrypto &&
    !isUSD &&
    (marketType === 'final' ||
     cleanedSymbol === 'AFNL' ||
     cleanedSymbol === 'AFNL' ||
     stock.exchange === 'SOVEREIGN_NODE');

  if (isFinal) {
    return {
      code: cleanedSymbol || 'AFNL',
      isFinal: true,
      isUSD: false,
      isStable: false,
      isCrypto: false,
      cryptoRateUSD: 1.0,
    };
  }

  if (isStable) {
    return {
      code: cleanedSymbol || 'USDC',
      isFinal: false,
      isUSD: false,
      isStable: true,
      isCrypto: false,
      cryptoRateUSD: 1.0,
    };
  }

  if (isCrypto) {
    const code = cleanedSymbol || 'BTC';
    const cryptoRateUSD = CRYPTO_RATES_USD[code] || 65000.0;
    return {
      code,
      isFinal: false,
      isUSD: false,
      isStable: false,
      isCrypto: true,
      cryptoRateUSD,
    };
  }

  // Fallback to USD Fiat
  return {
    code: 'USD',
    isFinal: false,
    isUSD: true,
    isStable: false,
    isCrypto: false,
    cryptoRateUSD: 1.0,
  };
}

/**
 * Checks if a stock is a Final Stock (settled in Final Coins like AFNL/AFNL).
 */
export function isFinalStock(stock: StockItem): boolean {
  return getStockCurrencyInfo(stock).isFinal;
}

/**
 * Returns the currency symbol or ticker code for a given stock.
 */
export function getStockCurrencyCode(stock: StockItem): string {
  return getStockCurrencyInfo(stock).code;
}

/**
 * Returns the US Dollar equivalent string for stable coins and crypto.
 * Returns null for Final Coins (unpegged sovereign assets) and US Dollar itself.
 */
export function getUSDEquivalentString(_amountUSD: number, _stock?: StockItem | null): string | null {
  return null;
}

/**
 * Formats a numerical stock price as plain sovereign unit value (all final currencies are equal 1:1).
 */
export function formatStockPrice(priceUSD: number, stock?: StockItem | null, _showEquivalent: boolean = true): string {
  if (priceUSD === undefined || priceUSD === null || isNaN(priceUSD)) return '0.00';
  const formattedNum = priceUSD.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const code = stock ? getStockCurrencyCode(stock) : 'USD';
  return `${code} ${formattedNum}`;
}

/**
 * Formats market cap without a single currency symbol.
 */
export function formatStockMarketCap(stock: StockItem, _showEquivalent: boolean = true): string {
  if (!stock) return 'N/A';
  const rawCap = stock.marketCap || 'N/A';
  const cleanCap = rawCap.replace(/^[₣$]/, '').trim();
  return cleanCap;
}

/**
 * Formats an order or trade amount with the stock's final currency.
 */
export function formatStockAmount(amountUSD: number, stock?: StockItem | null, _showEquivalent: boolean = true): string {
  if (amountUSD === undefined || amountUSD === null || isNaN(amountUSD)) return '0.00';
  const formattedNum = Math.abs(amountUSD).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const sign = amountUSD < 0 ? '-' : '';
  if (stock) {
    const code = getStockCurrencyCode(stock);
    return `${sign}${code} ${formattedNum}`;
  }
  return `${sign}${formattedNum}`;
}
