import React, { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Target,
  Plus,
  Users,
  Coins,
  Search,
  Clock,
  ShieldCheck,
  PauseCircle,
  PlayCircle,
  Image as ImageIcon,
  Video,
  UploadCloud,
  X,
  HeartHandshake,
  Sparkles,
  ArrowUpRight,
  Receipt,
  Flame,
  Power,
  RotateCcw,
  Eye,
  Bookmark,
  Twitter,
  ChevronDown,
  MessageSquare,
  Check
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { useApp } from '../context/AppContext';
import { formatInsufficientCurrencyError } from '../utils/transactionFees';
import {
  UserCampaign,
  UploadedMedia,
  getUserInvolvedCampaigns,
  isUserCampaignInitiator,
  isUserCampaignDonor,
  getUserDonationsForCampaign,
  getUserTotalDonatedToCampaign,
  createCampaign,
  updateCampaignStatus,
  updateCampaignCover,
  addCampaignMediaAndSetCover,
  donateToCampaign,
  cancelAndRefundCampaign,
  getAllCampaigns,
  getTrendingCampaigns,
  incrementCampaignViews,
  getBookmarkedCampaignIds,
  toggleBookmarkCampaign,
  getAllPlatformFinalCoins
} from '../services/fundraisingService';
import { CampaignDetailPage } from './CampaignDetailPage';
import { ShareOnTweetingModal } from './ShareOnTweetingModal';

interface FundraisingPageProps {
  currentUser?: AuthSession | null;
  onOpenAuthModal?: () => void;
}

export const FundraisingPage: React.FC<FundraisingPageProps> = ({
  currentUser,
  onOpenAuthModal,
}) => {
  const { addToast, addNotification } = useApp();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const activeUserId = currentUser?.username || currentUser?.id || 'super_admin_ranma';
  const walletUserId = currentUser?.id || currentUser?.uid || activeUserId;

  // Role filter: all / initiated / donated / paused_by_me / others
  const [roleFilter, setRoleFilter] = useState<'all' | 'initiated' | 'donated' | 'paused_by_me' | 'others'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'completed' | 'saved'>('all');
  const [showTrending, setShowTrending] = useState(false);
  const [savedCampaignIds, setSavedCampaignIds] = useState<string[]>(() => getBookmarkedCampaignIds());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCampaignForDetail, setSelectedCampaignForDetail] = useState<UserCampaign | null>(null);
  const [selectedShareCampaign, setSelectedShareCampaign] = useState<UserCampaign | null>(null);
  const [walletVersion, setWalletVersion] = useState(0);

  useEffect(() => {
    const syncBookmarks = () => setSavedCampaignIds(getBookmarkedCampaignIds());
    const syncWallets = () => setWalletVersion((v) => v + 1);
    window.addEventListener('fundraising_bookmarks_updated', syncBookmarks);
    window.addEventListener('final_finance_wallets_updated', syncWallets);
    return () => {
      window.removeEventListener('fundraising_bookmarks_updated', syncBookmarks);
      window.removeEventListener('final_finance_wallets_updated', syncWallets);
    };
  }, []);

  const handleToggleSaveCampaign = (camp: UserCampaign, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const isNowSaved = toggleBookmarkCampaign(camp.id);
    setSavedCampaignIds(getBookmarkedCampaignIds());
    addToast({
      type: 'info',
      title: isNowSaved ? 'Saved Fundraiser' : 'Removed from Saved',
      message: isNowSaved
        ? `"${camp.title}" added to your Saved fundraisers.`
        : `"${camp.title}" removed from your Saved fundraisers.`,
    });
  };

  const openCampaignDetail = (campaignToOpen: UserCampaign) => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const nextViews = incrementCampaignViews(campaignToOpen.id);
    refreshCampaigns();
    setSelectedCampaignForDetail({
      ...campaignToOpen,
      viewsCount: nextViews || (campaignToOpen.viewsCount || 0) + 1,
    });
  };

  // Listen for focus campaign events from Tweeting or external links
  useEffect(() => {
    const handleFocusCampaign = (e: Event) => {
      const custom = e as CustomEvent<string>;
      if (custom.detail) {
        const all = getAllCampaigns();
        const found = all.find((c) => c.id === custom.detail);
        if (found) {
          openCampaignDetail(found);
        }
      }
    };
    window.addEventListener('focus_fundraising_campaign', handleFocusCampaign);
    return () => window.removeEventListener('focus_fundraising_campaign', handleFocusCampaign);
  }, []);
  
  // Campaigns list state
  const [campaigns, setCampaigns] = useState<UserCampaign[]>(() => {
    return getAllCampaigns();
  });

  // Reload data when user or filter changes
  useEffect(() => {
    const all = getAllCampaigns();
    if (roleFilter === 'all') {
      setCampaigns(all);
    } else if (roleFilter === 'initiated') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId)));
    } else if (roleFilter === 'donated') {
      setCampaigns(all.filter((c) => isUserCampaignDonor(c, activeUserId)));
    } else if (roleFilter === 'paused_by_me') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId) && c.status === 'paused'));
    } else if (roleFilter === 'others') {
      setCampaigns(all.filter((c) => !isUserCampaignInitiator(c, activeUserId) && !isUserCampaignDonor(c, activeUserId)));
    }
  }, [activeUserId, roleFilter]);

  const refreshCampaigns = () => {
    const all = getAllCampaigns();
    if (roleFilter === 'all') {
      setCampaigns(all);
    } else if (roleFilter === 'initiated') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId)));
    } else if (roleFilter === 'donated') {
      setCampaigns(all.filter((c) => isUserCampaignDonor(c, activeUserId)));
    } else if (roleFilter === 'paused_by_me') {
      setCampaigns(all.filter((c) => isUserCampaignInitiator(c, activeUserId) && c.status === 'paused'));
    } else if (roleFilter === 'others') {
      setCampaigns(all.filter((c) => !isUserCampaignInitiator(c, activeUserId) && !isUserCampaignDonor(c, activeUserId)));
    }
  };

  // Platform final coins for creation & donation (user's held Final Coins sorted first)
  const platformFinalCoins = useMemo(() => {
    return getAllPlatformFinalCoins(walletUserId);
  }, [walletUserId, walletVersion]);

  // Create Campaign Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'Tech & AI' | 'Clean Energy' | 'Community' | 'Infrastructure' | 'Creative'>('Tech & AI');
  const [newShortDesc, setNewShortDesc] = useState('');

  // Target State: Final Currency & Final Coins Only
  const [finalCoinsAmount, setFinalCoinsAmount] = useState('25000');
  const [acceptAllFinalCoins, setAcceptAllFinalCoins] = useState(true);
  const [selectedFinalCoins, setSelectedFinalCoins] = useState<string[]>(['AFNL']);
  const [finalCoinSearch, setFinalCoinSearch] = useState('');

  // End Date & Time State
  const [endDateTime, setEndDateTime] = useState('2026-12-21T18:00');

  // Uploaded Photos & Videos + Selected Cover Image
  const [uploadedMediaList, setUploadedMediaList] = useState<UploadedMedia[]>([]);
  const [selectedCoverMediaId, setSelectedCoverMediaId] = useState<string | null>(null);

  // Donation / Backing Modal State (Final Currency & Final Coins Only)
  const [selectedDonationCampaign, setSelectedDonationCampaign] = useState<UserCampaign | null>(null);
  const [selectedDonationCoin, setSelectedDonationCoin] = useState<string>('AFNL');
  const [donationCoinSearch, setDonationCoinSearch] = useState('');
  const [donationAmount, setDonationAmount] = useState<string>('500');
  const [donationMessage, setDonationMessage] = useState<string>('');

  // Coins eligible for donation modal on the selected campaign
  const donationEligibleCoins = useMemo(() => {
    if (!selectedDonationCampaign) return platformFinalCoins;
    const restricted = selectedDonationCampaign.acceptedFinalCoinSymbols;
    if (restricted && restricted.length > 0) {
      const filtered = platformFinalCoins.filter((c) =>
        restricted.some((s) => s.toUpperCase() === c.symbol.toUpperCase())
      );
      return filtered.length > 0 ? filtered : platformFinalCoins;
    }
    return platformFinalCoins;
  }, [selectedDonationCampaign, platformFinalCoins]);

  // Audit Ledger Modal State + Expandable Donor Note
  const [selectedAuditCampaign, setSelectedAuditCampaign] = useState<UserCampaign | null>(null);
  const [expandedAuditDonorId, setExpandedAuditDonorId] = useState<string | null>(null);

  // Quick Change Cover Modal (for initiators)
  const [coverEditCampaign, setCoverEditCampaign] = useState<UserCampaign | null>(null);
  const coverEditFileInputRef = useRef<HTMLInputElement | null>(null);

  // End / Refund Campaign Modal State
  const [campaignToEnd, setCampaignToEnd] = useState<UserCampaign | null>(null);
  const [isEndingCampaign, setIsEndingCampaign] = useState(false);

  // Calculated Target in Final Currency (FC)
  const calculatedTotalFC = useMemo(() => {
    return Math.round((parseFloat(finalCoinsAmount) || 0) * 100) / 100;
  }, [finalCoinsAmount]);

  // Handle File Upload (Photos & Videos — Images read as persistent Data URLs)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isImage && !isVideo) {
        addToast({
          type: 'error',
          title: 'Unsupported File Format',
          message: `${file.name} is not a valid image or video file.`,
        });
        return;
      }

      const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
      const itemId = `media-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      if (isImage) {
        const reader = new FileReader();
        reader.onload = () => {
          const url = typeof reader.result === 'string' ? reader.result : URL.createObjectURL(file);
          const item: UploadedMedia = {
            id: itemId,
            url,
            name: file.name,
            type: 'image',
            sizeFormatted: `${sizeInMB} MB`,
          };
          setUploadedMediaList((prev) => [...prev, item]);
          setSelectedCoverMediaId((prev) => prev || itemId);
        };
        reader.readAsDataURL(file);
      } else {
        const item: UploadedMedia = {
          id: itemId,
          url: URL.createObjectURL(file),
          name: file.name,
          type: 'video',
          sizeFormatted: `${sizeInMB} MB`,
        };
        setUploadedMediaList((prev) => [...prev, item]);
      }
    });

    addToast({
      type: 'success',
      title: 'Media Uploaded',
      message: `Added ${files.length} file(s) to campaign gallery.`,
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveMedia = (id: string) => {
    setUploadedMediaList((prev) => {
      const remaining = prev.filter((m) => m.id !== id);
      if (selectedCoverMediaId === id) {
        const nextImg = remaining.find(m => m.type === 'image');
        setSelectedCoverMediaId(nextImg ? nextImg.id : null);
      }
      return remaining;
    });
  };

  // Helper to format remaining time
  const formatTimeRemaining = (isoString: string) => {
    const target = new Date(isoString).getTime();
    const now = Date.now();
    const diffMs = target - now;

    if (diffMs <= 0) {
      return { text: 'Campaign Concluded', expired: true };
    }

    const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (days > 0) {
      return { text: `${days}d ${hours}h left`, expired: false };
    }
    return { text: `${hours}h ${minutes}m left`, expired: false };
  };

  // Trending fundraisers shown above search bar
  const trendingCampaigns = useMemo(() => {
    return getTrendingCampaigns();
  }, [campaigns]);

  // Filtered campaigns: when searching, search across ALL campaigns (including others') regardless of role/saved filters
  const filteredCampaigns = useMemo(() => {
    const trimmed = searchQuery.trim().toLowerCase();
    if (trimmed.length > 0) {
      const tokens = trimmed.split(/\s+/).filter(Boolean);
      const all = getAllCampaigns();
      const matches = all.filter((c) => {
        const searchableText = [
          c.title,
          c.shortDescription,
          c.fullStory,
          c.category,
          c.creatorName,
          c.creatorHandle,
          c.creatorBio || '',
          ...(c.acceptedModalities || []),
          ...(c.acceptedFinalCoinSymbols || []),
        ]
          .join(' ')
          .toLowerCase();
        return tokens.every((tok) => searchableText.includes(tok));
      });
      return matches.sort((a, b) => {
        const aTitle = a.title.toLowerCase().includes(trimmed) ? 0 : 1;
        const bTitle = b.title.toLowerCase().includes(trimmed) ? 0 : 1;
        if (aTitle !== bTitle) return aTitle - bTitle;
        return (b.viewsCount || 0) - (a.viewsCount || 0);
      });
    }

    return campaigns.filter((c) => {
      const matchStatus =
        filterStatus === 'all'
          ? true
          : filterStatus === 'saved'
          ? savedCampaignIds.includes(c.id)
          : c.status === filterStatus;
      return matchStatus;
    });
  }, [campaigns, filterStatus, savedCampaignIds, searchQuery]);

  // Aggregate Stats
  const stats = useMemo(() => {
    const all = getAllCampaigns();
    const allInvolved = getUserInvolvedCampaigns(activeUserId, 'all');
    const initiated = all.filter((c) => isUserCampaignInitiator(c, activeUserId));
    const backed = all.filter((c) => isUserCampaignDonor(c, activeUserId));
    const pausedByMe = initiated.filter((c) => c.status === 'paused');

    const totalTarget = allInvolved.reduce((sum, c) => sum + c.targetAmountUSD, 0);
    const totalRaised = allInvolved.reduce((sum, c) => sum + c.raisedAmountUSD, 0);
    const totalBackers = allInvolved.reduce((sum, c) => sum + c.backersCount, 0);
    const activeCount = all.filter((c) => c.status === 'active').length;
    const completedCount = all.filter((c) => c.status === 'completed').length;
    
    let userDonatedTotal = 0;
    all.forEach((c) => {
      userDonatedTotal += getUserTotalDonatedToCampaign(c, activeUserId);
    });

    const overallProgress = totalTarget > 0 ? Math.min(100, Math.round((totalRaised / totalTarget) * 100)) : 0;
    return {
      totalTarget,
      totalRaised,
      totalBackers,
      activeCount,
      completedCount,
      overallProgress,
      initiatedCount: initiated.length,
      backedCount: backed.length,
      pausedByMeCount: pausedByMe.length,
      othersCount: all.filter(c => !isUserCampaignInitiator(c, activeUserId) && !isUserCampaignDonor(c, activeUserId)).length,
      userDonatedTotal,
      allCount: all.length,
    };
  }, [campaigns, activeUserId]);

  // Toggle status handler (pause / resume)
  const handleToggleStatus = (campId: string, nextStatus: 'active' | 'paused') => {
    updateCampaignStatus(campId, nextStatus);
    refreshCampaigns();
    addToast({
      type: 'info',
      title: 'Campaign Status Updated',
      message: `Campaign has been set to ${nextStatus.toUpperCase()}.`,
    });
  };

  // End campaign & refund 100% of Final Coins to all backers
  const handleConfirmEndCampaign = () => {
    if (!campaignToEnd) return;
    setIsEndingCampaign(true);
    setTimeout(() => {
      const result = cancelAndRefundCampaign(campaignToEnd.id, activeUserId);
      setIsEndingCampaign(false);
      setCampaignToEnd(null);

      if (result.success) {
        addToast({
          type: 'info',
          title: 'Campaign Cancelled & Escrow Refunded',
          message: `All ${result.refundedCount} backer contribution(s) totaling F ${result.refundedTotalUSD.toLocaleString()} FC have been 100% returned to donor Final Coin wallets.`
        });
        addNotification({
          title: `🛡️ Campaign Escrow Returned: ${campaignToEnd.title}`,
          description: `Campaign ended by initiator. F ${result.refundedTotalUSD.toLocaleString()} FC was refunded across ${result.refundedCount} donors' Final Coin wallets.`,
          type: 'fundraising',
          targetTab: 'fundraising'
        });
        refreshCampaigns();
      } else {
        addToast({
          type: 'error',
          title: 'Error Ending Campaign',
          message: result.error || 'Failed to process refund.',
        });
      }
    }, 400);
  };

  // Toggle coin selection for creation (max 5 coins)
  const toggleCoinSelection = (symbol: string) => {
    if (selectedFinalCoins.includes(symbol)) {
      setSelectedFinalCoins(prev => prev.filter(s => s !== symbol));
    } else {
      if (selectedFinalCoins.length >= 5) {
        addToast({
          type: 'info',
          title: 'Limit Reached',
          message: 'You can select up to 5 Final Coins anywhere on our platform.'
        });
        return;
      }
      setSelectedFinalCoins(prev => [...prev, symbol]);
    }
  };

  // Create Campaign Submit (Strictly Final Currency & Final Coins Only)
  const handleCreateCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuthModal?.();
      return;
    }

    if (!newTitle.trim()) {
      addToast({
        type: 'error',
        title: 'Validation Error',
        message: 'Please provide a campaign title.',
      });
      return;
    }

    if (!acceptAllFinalCoins && selectedFinalCoins.length === 0) {
      addToast({
        type: 'error',
        title: 'Final Coin Required',
        message: 'Please select at least 1 Final Coin or choose Accept All Final Coins.',
      });
      return;
    }

    if (calculatedTotalFC <= 0) {
      addToast({
        type: 'error',
        title: 'Invalid Target',
        message: 'Please specify a Final Currency target amount greater than 0.',
      });
      return;
    }

    const acceptedCoinsForCampaign = acceptAllFinalCoins ? undefined : selectedFinalCoins;
    const coinsLabel = acceptedCoinsForCampaign && acceptedCoinsForCampaign.length > 0
      ? acceptedCoinsForCampaign.join(', ')
      : 'All Final Coins';
    const modalities = [`Final Currency (${calculatedTotalFC.toLocaleString()} FC · ${coinsLabel})`];

    let banner = 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80';
    const chosenCover =
      uploadedMediaList.find(m => m.id === selectedCoverMediaId && m.type === 'image') ||
      uploadedMediaList.find(m => m.type === 'image');
    if (chosenCover) {
      banner = chosenCover.url;
    }

    const created = createCampaign({
      title: newTitle.trim(),
      creatorId: currentUser.id || 'super_admin_ranma',
      creatorName: currentUser.name || 'Ranma',
      creatorHandle: currentUser.id || 'super_admin_ranma',
      creatorAvatar: currentUser.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
      category: newCategory,
      shortDescription: newShortDesc.trim() || 'Community-backed sovereign initiative on Final Finance.',
      fullStory: newShortDesc.trim() || 'Autonomous verified protocol on Final Finance. Funding is accepted exclusively in Final Currency and Final Coins (FC).',
      targetBreakdown: {
        acceptsFiat: false,
        fiatAmount: 0,
        acceptsFinalCoins: true,
        finalCoinsAmount: calculatedTotalFC,
        acceptsStablecoins: false,
        stablecoinsAmount: 0,
        acceptsCrypto: false,
        cryptoAmount: 0,
        acceptsBarter: false,
        barterDescription: '',
        barterEstimatedValueUSD: 0,
      },
      targetAmountUSD: calculatedTotalFC,
      raisedAmountUSD: 0,
      backersCount: 0,
      endDateTime: endDateTime || '2026-12-21T18:00',
      status: 'active',
      acceptedModalities: modalities,
      acceptedFiatCurrencies: [],
      acceptedFinalCoinSymbols: acceptedCoinsForCampaign,
      mediaList: uploadedMediaList.length > 0 ? uploadedMediaList : [
        {
          id: `media-${Date.now()}`,
          url: banner,
          name: 'campaign_media.jpg',
          type: 'image',
          sizeFormatted: '2.5 MB',
          caption: newTitle.trim()
        }
      ],
      bannerUrl: banner,
      verifiedCreator: true,
      featured: true,
      updates: [
        {
          id: `up-${Date.now()}`,
          title: 'Campaign Launched on Final Finance',
          date: new Date().toISOString().split('T')[0],
          author: currentUser.name || 'Ranma',
          content: 'Campaign is live and open for Final Currency & Final Coins backing. Thank you to our initial community supporters.'
        }
      ],
      faqs: [
        {
          question: 'How are backer funds safeguarded?',
          answer: 'All Final Coin contributions are locked in multi-signature smart contract escrow vaults. Funds are only unlocked upon independent verification of milestones.'
        },
        {
          question: 'Can I request a refund if milestones fail?',
          answer: 'Yes. If a project fails milestone verification or is cancelled, remaining escrow capital is returned proportionally to donors in their original Final Coin.'
        }
      ]
    });

    refreshCampaigns();
    setIsCreateModalOpen(false);

    // Reset fields
    setNewTitle('');
    setNewShortDesc('');
    setFinalCoinsAmount('25000');
    setAcceptAllFinalCoins(true);
    setSelectedFinalCoins(['AFNL']);
    setUploadedMediaList([]);
    setSelectedCoverMediaId(null);

    addToast({
      type: 'success',
      title: 'Campaign Created',
      message: `"${created.title}" with target F ${created.targetAmountUSD.toLocaleString()} FC is now live!`,
    });

    addNotification({
      title: `🚀 Fundraising Campaign Launched: ${created.title}`,
      description: `Target of F ${created.targetAmountUSD.toLocaleString()} FC opened for backing in Final Currency & Final Coins.`,
      type: 'fundraising',
      targetTab: 'fundraising',
      amount: created.targetAmountUSD,
      currency: 'FC',
    });
  };

  // Handle Donation Submit (Strictly Final Currency & Final Coins Only)
  const handleDonateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDonationCampaign) return;
    if (!currentUser) {
      onOpenAuthModal?.();
      return;
    }

    const amt = parseFloat(donationAmount);
    if (!amt || amt <= 0) {
      addToast({
        type: 'error',
        title: 'Invalid Contribution',
        message: 'Please enter a valid contribution amount greater than 0.',
      });
      return;
    }

    if (
      selectedDonationCampaign.acceptedFinalCoinSymbols &&
      selectedDonationCampaign.acceptedFinalCoinSymbols.length > 0 &&
      !selectedDonationCampaign.acceptedFinalCoinSymbols.some(
        (s) => s.toUpperCase() === selectedDonationCoin.toUpperCase()
      )
    ) {
      addToast({
        type: 'error',
        title: 'Final Coin Not Accepted',
        message: `This campaign only accepts Final Coins: ${selectedDonationCampaign.acceptedFinalCoinSymbols.join(', ')}.`,
      });
      return;
    }

    const selectedCoinObj = platformFinalCoins.find(
      (c) => c.symbol.toUpperCase() === selectedDonationCoin.toUpperCase()
    );
    const availableBalance = selectedCoinObj?.balance || 0;
    if (amt > availableBalance) {
      addToast({
        type: 'error',
        title: availableBalance <= 0 ? `No ${selectedDonationCoin} Held` : `Insufficient ${selectedDonationCoin}`,
        message: formatInsufficientCurrencyError({
          symbol: selectedDonationCoin,
          name: selectedCoinObj?.name,
          available: availableBalance,
          required: amt,
        }),
      });
      return;
    }

    const finalModality = `Final Coins (${selectedDonationCoin})`;
    const donorWalletKey = currentUser.id || currentUser.uid || 'super_admin_ranma';

    const success = donateToCampaign(selectedDonationCampaign.id, {
      donorId: donorWalletKey,
      donorHandle: currentUser.username || currentUser.id || 'super_admin_ranma',
      donorName: currentUser.name || 'Ranma',
      donorAvatar: currentUser.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
      amountUSD: amt,
      originalAmount: amt,
      originalCurrency: selectedDonationCoin,
      modality: finalModality,
      message: donationMessage.trim() || undefined,
    });

    if (success) {
      const displayContribution = `${amt.toLocaleString()} ${selectedDonationCoin}`;

      addToast({
        type: 'success',
        title: 'Donation Confirmed',
        message: `You successfully contributed ${displayContribution} via ${finalModality} to "${selectedDonationCampaign.title}".`,
      });
      addNotification({
        title: `🤝 Contribution Confirmed: ${displayContribution}`,
        description: `You backed "${selectedDonationCampaign.title}" via ${finalModality}.`,
        type: 'fundraising',
        targetTab: 'fundraising',
        amount: amt,
        currency: selectedDonationCoin,
      });
      refreshCampaigns();
      setSelectedDonationCampaign(null);
      setDonationAmount('500');
      setDonationMessage('');
    } else {
      addToast({
        type: 'error',
        title: 'Contribution Failed',
        message: `Could not complete pledge in ${selectedDonationCoin}. Please check your Final Coin wallet balance.`,
      });
    }
  };

  // Filter coins for modal selection
  const filteredCreateCoins = useMemo(() => {
    return platformFinalCoins.filter(c =>
      c.symbol.toLowerCase().includes(finalCoinSearch.toLowerCase()) ||
      c.name.toLowerCase().includes(finalCoinSearch.toLowerCase())
    );
  }, [platformFinalCoins, finalCoinSearch]);

  if (selectedCampaignForDetail) {
    return (
      <div className="space-y-6">
        <CampaignDetailPage
          campaign={selectedCampaignForDetail}
          currentUser={currentUser}
          onBack={() => {
            window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
            if (document.documentElement) document.documentElement.scrollTop = 0;
            if (document.body) document.body.scrollTop = 0;
            setSelectedCampaignForDetail(null);
          }}
          onRefresh={() => {
            refreshCampaigns();
            const all = getAllCampaigns();
            const updated = all.find((c) => c.id === selectedCampaignForDetail.id);
            if (updated) setSelectedCampaignForDetail(updated);
          }}
          onOpenAuthModal={onOpenAuthModal}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-16 text-center flex flex-col items-center w-full overflow-x-hidden">
      {/* Search Bar - Centered at Top */}
      <div className="max-w-2xl mx-auto w-full">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search all campaigns by title, creator, category, or coin..."
            className="w-full pl-9.5 pr-8 py-2.5 text-xs sm:text-sm rounded-2xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-xs"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 rounded-lg cursor-pointer"
              title="Clear search query"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Sovereign Header with Launch Fundraising Campaign + Trending Button on One Line */}
      <div className="flex flex-col items-center justify-center gap-3 border-b border-slate-100 pb-5 max-w-4xl mx-auto w-full text-center">
        <div className="text-center space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-slate-950 tracking-tight text-center">
            Campaigns
          </h1>
          <p className="text-xs text-slate-500 text-center">
            Create, fund, and manage community backing initiatives with Final Currency &amp; Final Coins.
          </p>
        </div>

        {/* Single-Line Action Row: Launch Fundraising Campaign + Trending */}
        <div className="flex flex-nowrap items-center justify-center gap-2 w-full max-w-full px-1">
          <button
            type="button"
            onClick={() => {
              if (!currentUser) {
                onOpenAuthModal?.();
              } else {
                setIsCreateModalOpen(true);
              }
            }}
            className="px-3 sm:px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] sm:text-xs tracking-tight transition-all inline-flex items-center justify-center cursor-pointer shadow-xs whitespace-nowrap shrink-0"
          >
            <span>Launch Fundraising Campaign</span>
          </button>

          <button
            type="button"
            onClick={() => setShowTrending((prev) => !prev)}
            aria-expanded={showTrending}
            className={`px-3 sm:px-4 py-2 rounded-xl font-semibold text-[11px] sm:text-xs tracking-tight transition-all inline-flex items-center justify-center gap-1.5 cursor-pointer shadow-xs whitespace-nowrap shrink-0 border ${
              showTrending
                ? 'bg-amber-500 border-amber-600 text-slate-950'
                : 'bg-white border-amber-300 text-amber-900 hover:bg-amber-50'
            }`}
          >
            <Flame className={`w-3.5 h-3.5 shrink-0 ${showTrending ? 'text-slate-950' : 'text-amber-500'}`} />
            <span>Trending</span>
            <span
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono tabular-nums ${
                showTrending
                  ? 'bg-slate-950/15 text-slate-950 font-bold'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {trendingCampaigns.length}
            </span>
          </button>
        </div>

        {/* Trending Campaigns Panel Directly Under Launch & Trending Buttons */}
        <AnimatePresence>
          {showTrending && trendingCampaigns.length > 0 && (
            <motion.section
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16 }}
              aria-label="Trending Campaigns"
              className="w-full max-w-5xl mx-auto pt-3 space-y-3 text-left"
            >
              <div className="flex items-center justify-between gap-2 px-1">
                <div className="flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-500 shrink-0" />
                  <h2 className="font-serif text-sm sm:text-base font-bold text-slate-900">
                    Trending Campaigns
                  </h2>
                </div>
                <span className="text-xs font-mono tabular-nums text-slate-500">
                  {trendingCampaigns.length} trending
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {trendingCampaigns.map((trendCamp, idx) => {
                  const trendPct = Math.min(100, Math.round((trendCamp.raisedAmountUSD / (trendCamp.targetAmountUSD || 1)) * 100));
                  const isTrendSaved = savedCampaignIds.includes(trendCamp.id);
                  return (
                    <div
                      key={`trend-${trendCamp.id}`}
                      onClick={() => openCampaignDetail(trendCamp)}
                      className="bg-white rounded-2xl border border-slate-200 hover:border-emerald-400 hover:shadow-md transition-all cursor-pointer overflow-hidden flex flex-col justify-between group text-left"
                    >
                      <div>
                        <div className="relative h-28 w-full bg-slate-100 overflow-hidden">
                          <img
                            src={trendCamp.bannerUrl}
                            alt={trendCamp.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent" />
                          <div className="absolute top-2 left-2 flex items-center gap-1.5">
                            <span className="px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 text-[10px] font-mono font-bold">
                              #{trendCamp.trendingRank || idx + 1}
                            </span>
                            {trendCamp.trendingGrowth24h && (
                              <span className="px-2 py-0.5 rounded-md bg-slate-950/80 text-emerald-300 text-[10px] font-mono font-semibold">
                                {trendCamp.trendingGrowth24h}
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={(e) => handleToggleSaveCampaign(trendCamp, e)}
                            className={`absolute top-2 right-2 p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              isTrendSaved
                                ? 'bg-amber-500 border-amber-400 text-white'
                                : 'bg-slate-950/70 border-white/20 text-white hover:bg-slate-900'
                            }`}
                            title={isTrendSaved ? 'Remove from Saved' : 'Save fundraiser'}
                          >
                            <Bookmark className={`w-3.5 h-3.5 ${isTrendSaved ? 'fill-white' : ''}`} />
                          </button>
                          <div className="absolute bottom-2 left-2.5 right-2.5 flex items-center justify-between text-[11px] font-mono text-white">
                            <span className="truncate">{trendCamp.category}</span>
                            <span className="inline-flex items-center gap-1 shrink-0 tabular-nums">
                              <Eye className="w-3 h-3 text-emerald-300" />
                              {(trendCamp.viewsCount || 0).toLocaleString()} views
                            </span>
                          </div>
                        </div>

                        <div className="p-3.5 space-y-1.5 text-center flex flex-col items-center">
                          <h3 className="font-serif text-sm font-bold text-slate-900 leading-snug group-hover:text-emerald-700 transition-colors text-center text-balance break-words w-full">
                            {trendCamp.title}
                          </h3>
                          <p className="text-[11px] text-slate-500 text-center">
                            by {trendCamp.creatorName}
                          </p>
                        </div>
                      </div>

                      <div className="px-3.5 pb-3.5 space-y-1.5">
                        <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-emerald-500"
                            style={{ width: `${trendPct}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[11px] font-mono tabular-nums">
                          <span className="font-bold text-emerald-700">
                            F {trendCamp.raisedAmountUSD.toLocaleString()}
                          </span>
                          <span className="text-slate-500">
                            {trendPct}% · {trendCamp.backersCount.toLocaleString()} backers
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.section>
          )}
        </AnimatePresence>
      </div>

      {/* Filter Rows: Role Selector Tabs + Single-Line Status Tabs (All / Active / Completed / Saved) */}
      <div className="w-full max-w-5xl space-y-3 flex flex-col items-center">
        {/* Row 1: Involvement Filters (Wraps cleanly on narrow screens, zero horizontal scroll) */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 w-full text-xs px-1">
          <button
            type="button"
            onClick={() => setRoleFilter('all')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
              roleFilter === 'all'
                ? 'bg-neutral-900 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <span>All Campaigns</span>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono tabular-nums ${roleFilter === 'all' ? 'bg-neutral-800 text-emerald-400' : 'bg-neutral-100 text-neutral-600'}`}>
              {getAllCampaigns().length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setRoleFilter('initiated')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
              roleFilter === 'initiated'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
            <span>Initiated by Me</span>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono tabular-nums ${roleFilter === 'initiated' ? 'bg-emerald-700 text-white' : 'bg-neutral-100 text-neutral-600'}`}>
              {stats.initiatedCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setRoleFilter('donated')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
              roleFilter === 'donated'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <HeartHandshake className="w-3.5 h-3.5 text-blue-300" />
            <span>Backed by Me</span>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono tabular-nums ${roleFilter === 'donated' ? 'bg-blue-700 text-white' : 'bg-neutral-100 text-neutral-600'}`}>
              {stats.backedCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setRoleFilter('paused_by_me')}
            className={`px-3 py-1.5 rounded-full font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-1.5 ${
              roleFilter === 'paused_by_me'
                ? 'bg-amber-600 text-white shadow-2xs'
                : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-50'
            }`}
          >
            <PauseCircle className="w-3.5 h-3.5 text-amber-300" />
            <span>Paused by Me</span>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono tabular-nums ${roleFilter === 'paused_by_me' ? 'bg-amber-700 text-white' : 'bg-neutral-100 text-neutral-600'}`}>
              {stats.pausedByMeCount}
            </span>
          </button>
        </div>

        {/* Row 2: Status Filters (Single-Line Guaranteed, Zero Horizontal Scroll) */}
        <div className="w-full flex justify-center px-1">
          <div className="inline-flex flex-nowrap items-center justify-center gap-0.5 sm:gap-1 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/80 max-w-full">
            {[
              { id: 'all', label: 'All', count: campaigns.length },
              { id: 'active', label: 'Active', count: campaigns.filter((c) => c.status === 'active').length },
              { id: 'completed', label: 'Completed', count: campaigns.filter((c) => c.status === 'completed').length },
              { id: 'saved', label: 'Saved', count: campaigns.filter((c) => savedCampaignIds.includes(c.id)).length },
            ].map((tab) => {
              const isActive = filterStatus === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilterStatus(tab.id as any)}
                  className={`px-2 sm:px-3 py-1.5 rounded-xl text-[11px] sm:text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer inline-flex items-center gap-1 sm:gap-1.5 ${
                    isActive ? 'bg-neutral-900 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span className="whitespace-nowrap">{tab.label}</span>
                  <span
                    className={`px-1 sm:px-1.5 py-0.5 rounded text-[10px] font-mono tabular-nums whitespace-nowrap ${
                      isActive
                        ? 'bg-neutral-800 text-emerald-400 font-bold'
                        : 'bg-white/80 text-slate-500 border border-slate-200/60'
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Campaigns List (Cards / Rows) - Fully Centered */}
      <div className="space-y-4 max-w-4xl w-full">
        {searchQuery.trim().length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
            <span>
              Searching across all campaigns (yours &amp; others) for{' '}
              <strong className="text-slate-900">&ldquo;{searchQuery.trim()}&rdquo;</strong>{' '}
              <span className="font-mono tabular-nums text-slate-500">({filteredCampaigns.length} found)</span>
            </span>
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="text-emerald-700 hover:text-emerald-800 font-semibold cursor-pointer"
            >
              Clear search
            </button>
          </div>
        )}

        {filteredCampaigns.map((camp) => {
          const isInitiator = isUserCampaignInitiator(camp, activeUserId);
          const isDonor = isUserCampaignDonor(camp, activeUserId);
          const userDonations = getUserDonationsForCampaign(camp, activeUserId);
          const userTotalDonated = getUserTotalDonatedToCampaign(camp, activeUserId);

          const progressPercent = Math.min(100, Math.round((camp.raisedAmountUSD / camp.targetAmountUSD) * 100));
          const timeInfo = formatTimeRemaining(camp.endDateTime);

          return (
            <div
              key={camp.id}
              className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:border-slate-300 hover:shadow-md transition-all space-y-4 flex flex-col items-center text-center w-full"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 w-full text-center">
                {/* Left: Large Landscape Cover Photo (No overlaid pills) + Main Info */}
                <div className="flex flex-col md:flex-row items-center gap-5 min-w-0 flex-1 text-center">
                  <div className="flex flex-col items-center gap-2 shrink-0 w-full md:w-72">
                    <div
                      onClick={() => openCampaignDetail(camp)}
                      className="relative w-full h-44 rounded-2xl bg-slate-100 overflow-hidden border border-slate-200 cursor-pointer group mx-auto shadow-2xs"
                      title="Click to view full campaign details"
                    >
                      <img
                        src={camp.bannerUrl}
                        alt={camp.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    {isInitiator && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCoverEditCampaign(camp);
                        }}
                        className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <ImageIcon className="w-3 h-3" />
                        <span>Change Cover Photo</span>
                      </button>
                    )}
                  </div>

                  <div className="min-w-0 space-y-2 flex-1 flex flex-col items-center text-center w-full">
                    {/* Status, Video, Role & Category Labels — All Cleanly Outside the Photo */}
                    <div className="flex flex-wrap items-center justify-center gap-2 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold uppercase ${
                          camp.isCancelledAndRefunded
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : camp.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : camp.status === 'completed'
                            ? 'bg-sky-100 text-sky-800 border border-sky-200'
                            : 'bg-amber-100 text-amber-800 border border-amber-200'
                        }`}
                      >
                        {camp.isCancelledAndRefunded ? 'Refunded' : camp.status}
                      </span>

                      {camp.mediaList && camp.mediaList.some((m) => m.type === 'video') && (
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold uppercase bg-purple-100 text-purple-800 border border-purple-200 inline-flex items-center gap-1">
                          <Video className="w-3 h-3 text-purple-600" />
                          <span>Video</span>
                        </span>
                      )}

                      {isInitiator && camp.status === 'paused' && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold shadow-2xs">
                          <PauseCircle className="w-3.5 h-3.5 text-amber-700" />
                          <span>Paused by Me</span>
                        </span>
                      )}

                      {isInitiator && isDonor ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-950 border border-emerald-300 font-bold shadow-2xs">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Initiated &amp; Co-Backed (F {userTotalDonated.toLocaleString()})</span>
                        </span>
                      ) : isInitiator ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold shadow-2xs">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Initiated by Me</span>
                        </span>
                      ) : isDonor ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 border border-blue-300 font-bold shadow-2xs">
                          <HeartHandshake className="w-3.5 h-3.5 text-blue-700" />
                          <span>Backed by Me · F {userTotalDonated.toLocaleString()} Contributed</span>
                        </span>
                      ) : null}

                      {camp.isTrendingToday && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold shadow-2xs">
                          <Flame className="w-3.5 h-3.5 text-amber-600" />
                          <span>Top Trending Charity ({camp.trendingGrowth24h || '+520% today'})</span>
                        </span>
                      )}

                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 font-semibold">
                        {camp.category}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">
                        Lead: {camp.creatorName}
                      </span>
                    </div>

                    <h3
                      onClick={() => openCampaignDetail(camp)}
                      className="font-serif text-base sm:text-lg font-bold text-slate-900 hover:text-emerald-700 transition-colors cursor-pointer text-center text-balance break-words leading-snug w-full group/title"
                    >
                      <span>{camp.title}</span>
                      <ArrowUpRight className="inline-block w-4 h-4 ml-1 -mt-0.5 opacity-0 group-hover/title:opacity-100 transition-opacity text-emerald-600 shrink-0" />
                    </h3>

                    <p
                      onClick={() => openCampaignDetail(camp)}
                      className="text-xs text-slate-600 line-clamp-2 leading-relaxed cursor-pointer hover:text-slate-900 text-center max-w-xl"
                    >
                      {camp.shortDescription}
                    </p>

                    {/* Target Modalities Breakdown Chips - Centered */}
                    <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1 text-center">
                      <span className="text-[10px] font-mono text-slate-400 mr-0.5">Target Mix:</span>
                      {camp.acceptedModalities.map((mod, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-50 text-slate-700 border border-slate-200"
                        >
                          {mod}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Middle: Progress Bar & Numeric Data - Centered */}
                <div
                  onClick={() => openCampaignDetail(camp)}
                  className="lg:w-64 space-y-2 lg:px-4 lg:border-l lg:border-r border-slate-100 shrink-0 cursor-pointer text-center flex flex-col items-center justify-center"
                >
                  <div className="flex items-center justify-center gap-2 text-xs">
                    <div>
                      <span className="font-mono font-bold text-emerald-700 text-sm">
                        F {camp.raisedAmountUSD.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono ml-1">
                        / F {camp.targetAmountUSD.toLocaleString()}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-slate-900 text-xs">
                      {progressPercent}%
                    </span>
                  </div>

                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 mx-auto ${
                        camp.isCancelledAndRefunded
                          ? 'bg-rose-500'
                          : camp.status === 'completed'
                          ? 'bg-sky-500'
                          : camp.status === 'paused'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[11px] font-mono tabular-nums text-slate-500 pt-0.5">
                    <div className="flex items-center gap-1 whitespace-nowrap">
                      <Users className="w-3.5 h-3.5 text-slate-400" />
                      <span>{camp.backersCount.toLocaleString()} Backers</span>
                    </div>
                    <div className="flex items-center gap-1 whitespace-nowrap">
                      <Eye className="w-3.5 h-3.5 text-slate-400" />
                      <span>{(camp.viewsCount || 0).toLocaleString()} Views</span>
                    </div>
                    <div className="flex items-center gap-1 whitespace-nowrap">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span className={timeInfo.expired ? 'text-amber-700 font-semibold' : 'text-slate-600'}>
                        {camp.status === 'completed' ? 'Campaign Concluded' : timeInfo.text}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: Actions Stack: Back / Donate -> Save -> Pause (if mine) -> End Campaign (if mine) -> Audit Vault (if mine) -> Share on Tweet */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:flex lg:flex-col gap-2 shrink-0 w-full lg:w-44 items-center justify-center text-center">
                  {/* Donate / Back Campaign Button */}
                  <button
                    type="button"
                    onClick={() => {
                      const restricted = camp.acceptedFinalCoinSymbols;
                      const eligible = restricted && restricted.length > 0
                        ? platformFinalCoins.filter((c) => restricted.some((s) => s.toUpperCase() === c.symbol.toUpperCase()))
                        : platformFinalCoins;
                      const preferred = eligible.find((c) => (c.balance || 0) > 0) || eligible[0] || platformFinalCoins[0];
                      if (preferred) setSelectedDonationCoin(preferred.symbol);
                      setDonationCoinSearch('');
                      setSelectedDonationCampaign(camp);
                    }}
                    disabled={camp.isCancelledAndRefunded || camp.status === 'completed' || camp.status === 'paused'}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer w-full shadow-xs whitespace-nowrap ${
                      camp.isCancelledAndRefunded || camp.status === 'completed' || camp.status === 'paused'
                        ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>{isDonor ? 'Contribute More' : 'Back / Donate'}</span>
                  </button>

                  {/* Save / Bookmark Campaign Button */}
                  <button
                    type="button"
                    onClick={(e) => handleToggleSaveCampaign(camp, e)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer w-full whitespace-nowrap ${
                      savedCampaignIds.includes(camp.id)
                        ? 'border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${savedCampaignIds.includes(camp.id) ? 'text-amber-600 fill-amber-500' : 'text-slate-500'}`} />
                    <span>{savedCampaignIds.includes(camp.id) ? 'Saved' : 'Save'}</span>
                  </button>

                  {/* If user is initiator: Pause / End Campaign / Audit Vault */}
                  {isInitiator && !camp.isCancelledAndRefunded && (
                    <>
                      {camp.status === 'active' ? (
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(camp.id, 'paused')}
                          className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer w-full whitespace-nowrap"
                        >
                          <PauseCircle className="w-3.5 h-3.5 text-amber-600" />
                          <span>Pause</span>
                        </button>
                      ) : camp.status === 'paused' ? (
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(camp.id, 'active')}
                          className="px-3 py-1.5 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer w-full whitespace-nowrap"
                        >
                          <PlayCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Resume</span>
                        </button>
                      ) : null}

                      <button
                        type="button"
                        onClick={() => setCampaignToEnd(camp)}
                        className="px-3 py-1.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer w-full whitespace-nowrap"
                        title="End Campaign and refund escrow back to people."
                      >
                        <Power className="w-3.5 h-3.5 text-rose-600" />
                        <span>End Campaign</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setExpandedAuditDonorId(null);
                          setSelectedAuditCampaign(camp);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer w-full border border-slate-200 whitespace-nowrap"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Audit Vault</span>
                      </button>
                    </>
                  )}

                  {/* Tweeting (On-Platform Quote Tweet with Note & Media) */}
                  <button
                    type="button"
                    onClick={() => setSelectedShareCampaign(camp)}
                    className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer w-full shadow-2xs whitespace-nowrap"
                  >
                    <span className="w-4 h-4 rounded bg-emerald-600 text-white flex items-center justify-center shrink-0">
                      <Twitter className="w-2.5 h-2.5 -scale-x-100 -rotate-12 fill-white" />
                    </span>
                    <span>Tweet</span>
                  </button>
                </div>
              </div>

              {/* Donor Contribution Sub-Panel (if user has donated) */}
              {isDonor && userDonations.length > 0 && (
                <div className="pt-3 border-t border-slate-100 bg-slate-50/60 -mx-5 sm:-mx-6 -mb-5 sm:-mb-6 p-4 rounded-b-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs w-full">
                  <div className="flex items-center justify-center gap-2 mx-auto sm:mx-0">
                    <Receipt className="w-4 h-4 text-blue-600 shrink-0" />
                    <span className="font-semibold text-slate-800">
                      Your Contribution Receipt:
                    </span>
                    <span className="font-mono font-bold text-blue-700">
                      F {userTotalDonated.toLocaleString()} FC
                    </span>
                    <span className="text-slate-500 font-mono text-[11px]">
                      ({userDonations.length} transaction{userDonations.length > 1 ? 's' : ''})
                    </span>
                  </div>

                  <div className="flex items-center justify-center gap-2 mx-auto sm:mx-0">
                    <span className="text-[11px] text-slate-500">
                      Last: {userDonations[0].modality} on {new Date(userDonations[0].timestamp).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {filteredCampaigns.length === 0 && (
          <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 max-w-lg mx-auto space-y-4">
            <Target className="w-12 h-12 text-slate-300 mx-auto" />
            <div>
              <h3 className="text-base font-bold text-slate-900">No campaigns found</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                {filterStatus === 'saved'
                  ? "You haven't saved any fundraisers yet. Click Save on any campaign to bookmark it here."
                  : roleFilter === 'initiated'
                  ? "You haven't initiated any fundraising campaigns yet."
                  : roleFilter === 'donated'
                  ? "You haven't contributed to any campaigns as a donor yet."
                  : "No campaigns matching your filter."}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* ================= MODAL: DONATE / BACK CAMPAIGN ================= */}
      <AnimatePresence>
        {selectedDonationCampaign && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden text-center flex flex-col items-center"
            >
              <div className="p-5 bg-neutral-900 text-white flex items-center justify-between gap-2 w-full">
                <div className="flex items-center gap-2.5 text-left min-w-0 flex-1">
                  <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
                    <HeartHandshake className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1 text-center">
                    <span className="text-[10px] font-mono uppercase text-emerald-400 font-semibold block">
                      Escrow Backing Pledge
                    </span>
                    <h3 className="font-serif text-base font-bold text-white leading-snug text-balance break-words">
                      {selectedDonationCampaign.title}
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedDonationCampaign(null)}
                  className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleDonateSubmit} className="p-6 space-y-4 w-full text-center">
                {/* Final Currency Only Banner */}
                <div className="inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-mono font-bold">
                  <Coins className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Final Currency &amp; Final Coins Only</span>
                </div>

                {/* Final Coins Search & Choice */}
                <div className="space-y-2 text-center bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-[11px] font-mono text-slate-600 block text-center font-semibold">
                    {selectedDonationCampaign.acceptedFinalCoinSymbols && selectedDonationCampaign.acceptedFinalCoinSymbols.length > 0
                      ? `Select Accepted Final Coin (${selectedDonationCampaign.acceptedFinalCoinSymbols.join(', ')}):`
                      : 'Select Any Final Coin in Your Wallet:'}
                  </span>

                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={donationCoinSearch}
                      onChange={(e) => setDonationCoinSearch(e.target.value)}
                      placeholder="Search your Final Coins (e.g. AFNL, VANC, ASOV)..."
                      className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-center font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>

                  <div className="max-h-40 overflow-y-auto space-y-1 text-left">
                    {donationEligibleCoins
                      .filter(c =>
                        c.symbol.toLowerCase().includes(donationCoinSearch.toLowerCase()) ||
                        c.name.toLowerCase().includes(donationCoinSearch.toLowerCase())
                      )
                      .map((coin) => {
                        const isSelected = selectedDonationCoin === coin.symbol;
                        const hasBalance = (coin.balance || 0) > 0;
                        return (
                          <div
                            key={coin.symbol}
                            onClick={() => setSelectedDonationCoin(coin.symbol)}
                            className={`p-2 rounded-lg border text-xs flex items-center justify-between cursor-pointer transition-colors ${
                              isSelected
                                ? 'bg-emerald-100/70 border-emerald-500 text-emerald-950 font-bold'
                                : 'bg-white border-slate-200 hover:bg-slate-100 text-slate-800'
                            }`}
                          >
                            <div className="flex items-center gap-1.5">
                              <span>{coin.icon || '🪙'}</span>
                              <span className="font-mono font-bold">{coin.symbol}</span>
                              <span className="text-[10px] text-slate-500 truncate max-w-[130px]">
                                {coin.name}
                              </span>
                            </div>
                            <span className={`font-mono text-[10px] ${hasBalance ? 'text-emerald-700 font-semibold' : 'text-slate-500'}`}>
                              {hasBalance ? `${coin.balance?.toLocaleString()} in wallet` : '0 in wallet'}
                            </span>
                          </div>
                        );
                      })}
                  </div>
                </div>

                {/* Amount */}
                {(() => {
                  const selectedCoinObj = donationEligibleCoins.find(
                    (c) => c.symbol.toUpperCase() === selectedDonationCoin.toUpperCase()
                  );
                  const availableBal = Number(selectedCoinObj?.balance || 0);
                  const parsedAmt = parseFloat(donationAmount) || 0;
                  const exceedsBalance = parsedAmt > availableBal;
                  return (
                    <div className="space-y-1 text-center">
                      <label className="text-xs font-bold text-slate-900 block text-center">
                        Contribution Amount ({selectedDonationCoin} · Available: {availableBal.toLocaleString()} {selectedDonationCoin})
                      </label>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-mono font-semibold text-slate-500">
                          {selectedDonationCoin}
                        </span>
                        <input
                          type="number"
                          min="1"
                          step="any"
                          value={donationAmount}
                          onChange={(e) => setDonationAmount(e.target.value)}
                          placeholder="500"
                          className={`w-full pl-16 pr-3.5 py-2.5 rounded-xl border text-xs font-mono text-center focus:outline-none focus:ring-2 tabular-nums ${
                            exceedsBalance
                              ? 'border-rose-400 bg-rose-50/40 text-rose-900 focus:ring-rose-500/20 focus:border-rose-500'
                              : 'border-slate-200 focus:ring-emerald-500/20 focus:border-emerald-500'
                          }`}
                          required
                        />
                      </div>
                      {exceedsBalance && (
                        <p className="text-xs font-semibold text-rose-600 pt-0.5">
                          You do not have that much balance. Available: {availableBal.toLocaleString()} {selectedDonationCoin}.
                        </p>
                      )}
                    </div>
                  );
                })()}

                <div className="space-y-1 text-center">
                  <label className="text-xs font-bold text-slate-900 block text-center">
                    Contribution Note / Message (Optional)
                  </label>
                  <input
                    type="text"
                    value={donationMessage}
                    onChange={(e) => setDonationMessage(e.target.value)}
                    placeholder="e.g. Backing green tech milestone with verified nodes."
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  />
                </div>

                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-900 leading-relaxed text-center">
                  <span className="font-bold block">Sovereign Vault Guarantee:</span>
                  All donations are locked in smart contract escrow vaults. If cancelled or unverified, 100% of capital is returned to backer wallets.
                </div>

                <div className="flex items-center justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedDonationCampaign(null)}
                    className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/20"
                  >
                    <HeartHandshake className="w-4 h-4" />
                    <span>Confirm Pledge</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: END CAMPAIGN & REFUND ALL BACKERS ================= */}
      <AnimatePresence>
        {campaignToEnd && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-200 space-y-4 text-center flex flex-col items-center"
            >
              <div className="flex items-center justify-center gap-2 text-rose-700">
                <Power className="w-6 h-6 shrink-0" />
                <h3 className="font-serif text-lg font-bold text-slate-900">
                  End Campaign & Refund Escrow
                </h3>
              </div>

              <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 text-xs text-rose-900 space-y-1.5 text-center">
                <div className="font-bold text-sm">100% Backer Refund Protocol</div>
                <p className="leading-relaxed">
                  If this campaign is cancelled by you, all escrowed funds (F {campaignToEnd.raisedAmountUSD.toLocaleString()} FC across {campaignToEnd.backersCount} backer{campaignToEnd.backersCount !== 1 ? 's' : ''}) will be automatically returned in full to all donors in their original Final Coin wallets.
                </p>
              </div>

              <div className="flex items-center justify-center gap-2 pt-2 w-full">
                <button
                  type="button"
                  onClick={() => setCampaignToEnd(null)}
                  className="flex-1 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer border border-slate-200"
                >
                  Keep Active
                </button>
                <button
                  type="button"
                  onClick={handleConfirmEndCampaign}
                  disabled={isEndingCampaign}
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs"
                >
                  {isEndingCampaign ? 'Refunding...' : 'Confirm End & Refund'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: AUDIT VAULT LEDGER (RESPONSIVE & CENTERED) ================= */}
      <AnimatePresence>
        {selectedAuditCampaign && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full max-h-[88vh] overflow-hidden text-center flex flex-col items-center mx-auto my-auto relative"
            >
              {/* Header - Centered & Safe Absolute Close Button */}
              <div className="relative w-full bg-neutral-950 text-white pt-6 pb-5 px-6 border-b border-neutral-800 flex flex-col items-center text-center">
                <button
                  type="button"
                  onClick={() => setSelectedAuditCampaign(null)}
                  className="absolute right-4 top-4 p-2 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer z-10"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold uppercase tracking-wider mb-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Audited Escrow Ledger</span>
                </div>

                <h3 className="font-serif text-base sm:text-lg font-bold text-white text-center leading-snug max-w-md break-words px-2 text-balance">
                  {selectedAuditCampaign.title}
                </h3>

                <div className="mt-1.5 flex items-center justify-center gap-2 text-xs text-neutral-400 font-mono">
                  <span className="text-emerald-400 font-semibold">{selectedAuditCampaign.category}</span>
                  <span>•</span>
                  <span>Lead: {selectedAuditCampaign.creatorName}</span>
                </div>
              </div>

              {/* Body - Scrollable & Perfectly Sized */}
              <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[calc(88vh-130px)] w-full text-center flex flex-col items-center">
                {/* 3 Metric Cards */}
                <div className="grid grid-cols-3 gap-2.5 w-full text-center">
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">Target Goal</span>
                    <span className="text-sm sm:text-base font-bold font-mono text-slate-900 truncate max-w-full">
                      F {selectedAuditCampaign.targetAmountUSD.toLocaleString()}
                    </span>
                  </div>
                  <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-mono text-emerald-700 block uppercase">In Escrow</span>
                    <span className="text-sm sm:text-base font-bold font-mono text-emerald-800 truncate max-w-full">
                      F {selectedAuditCampaign.raisedAmountUSD.toLocaleString()}
                    </span>
                  </div>
                  <div className="p-3 rounded-2xl bg-sky-50 border border-sky-200 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-mono text-sky-700 block uppercase">Funded</span>
                    <span className="text-sm sm:text-base font-bold font-mono text-sky-800">
                      {Math.min(100, Math.round((selectedAuditCampaign.raisedAmountUSD / (selectedAuditCampaign.targetAmountUSD || 1)) * 100))}%
                    </span>
                  </div>
                </div>

                {/* Accepted Modalities */}
                <div className="w-full p-3 rounded-2xl bg-slate-50/80 border border-slate-200 text-center space-y-2">
                  <span className="text-[11px] font-mono uppercase text-slate-500 font-bold block">
                    Accepted Modality Channels
                  </span>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {selectedAuditCampaign.acceptedModalities.map((m) => (
                      <span
                        key={m}
                        className="text-[11px] font-mono bg-white text-slate-700 px-2 py-0.5 rounded-md border border-slate-200"
                      >
                        {m}
                      </span>
                    ))}
                    {selectedAuditCampaign.acceptedFinalCoinSymbols && selectedAuditCampaign.acceptedFinalCoinSymbols.length > 0 && (
                      <span className="text-[11px] font-mono bg-amber-50 text-amber-800 px-2 py-0.5 rounded-md border border-amber-200 font-semibold">
                        Coins: {selectedAuditCampaign.acceptedFinalCoinSymbols.join(', ')}
                      </span>
                    )}
                  </div>
                </div>

                {/* Verified Donor Transactions List */}
                <div className="w-full text-center">
                  <div className="flex items-center justify-between mb-2 px-1">
                    <h4 className="text-xs font-mono uppercase font-bold text-slate-700">
                      Verified Donor Contributions ({selectedAuditCampaign.donations?.length || 0})
                    </h4>
                    <span className="text-[10px] font-mono text-emerald-700 font-semibold">
                      Cryptographically Logged
                    </span>
                  </div>
                  {selectedAuditCampaign.donations && selectedAuditCampaign.donations.length > 0 ? (
                    <div className="space-y-2 w-full">
                      {selectedAuditCampaign.donations.map((don) => {
                        const isExpanded = expandedAuditDonorId === don.id;
                        return (
                          <div
                            key={don.id}
                            onClick={() => setExpandedAuditDonorId(prev => prev === don.id ? null : don.id)}
                            className={`p-3 rounded-2xl border transition-colors cursor-pointer text-xs space-y-2 ${
                              isExpanded
                                ? 'border-emerald-400 bg-emerald-50/40'
                                : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2.5 text-left min-w-0">
                                <img
                                  src={don.donorAvatar}
                                  alt={don.donorName}
                                  className="w-7 h-7 rounded-full object-cover border border-slate-200 shrink-0"
                                />
                                <div className="min-w-0">
                                  <span className="font-semibold text-slate-900 block truncate">{don.donorName}</span>
                                  <span className="text-[10px] font-mono text-slate-500 block truncate">
                                    @{don.donorHandle || 'anonymous'} · {new Date(don.timestamp).toLocaleDateString()}
                                    {don.message ? ' · Note attached' : ''}
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <div className="text-right">
                                  <span className="font-mono font-bold text-emerald-700 block tabular-nums">
                                    +F {don.amountUSD.toLocaleString()} FC
                                  </span>
                                  <span className="text-[10px] font-mono text-slate-600 block mt-0.5">
                                    {don.originalAmount && don.originalCurrency
                                      ? `${don.originalAmount.toLocaleString()} ${don.originalCurrency}`
                                      : don.modality}
                                  </span>
                                </div>
                                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isExpanded ? 'rotate-180 text-emerald-600' : ''}`} />
                              </div>
                            </div>

                            {isExpanded && (
                              <div className="pt-2 border-t border-slate-200/80 text-left space-y-1">
                                <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase text-slate-500 font-semibold">
                                  <MessageSquare className="w-3 h-3 text-emerald-600" />
                                  <span>Contribution Note / Message</span>
                                </div>
                                <p className={`text-xs leading-relaxed ${don.message ? 'text-slate-800 italic' : 'text-slate-400'}`}>
                                  {don.message ? `"${don.message}"` : 'No contribution note / message was included with this pledge.'}
                                </p>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-4 text-center rounded-2xl bg-slate-50 border border-slate-200 text-slate-500 text-xs">
                      No public donor transactions recorded yet for this vault.
                    </div>
                  )}
                </div>

                {/* Trust Seal */}
                <div className="flex items-center justify-center gap-2 text-[11px] font-mono text-emerald-700 bg-emerald-50/70 border border-emerald-200/80 p-2.5 rounded-2xl w-full">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>On-Chain Multi-Signature Escrow Vault Active</span>
                </div>

                {/* Close Button */}
                <button
                  type="button"
                  onClick={() => setSelectedAuditCampaign(null)}
                  className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  Close Audit Ledger
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: LAUNCH NEW CAMPAIGN (CENTER ALIGNED) ================= */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full my-8 overflow-hidden text-center flex flex-col items-center"
            >
              {/* Modal Header - Centered */}
              <div className="p-6 bg-neutral-900 text-white flex flex-col items-center justify-center text-center relative w-full">
                <div className="text-center">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-semibold block text-center">
                    Final Currency &amp; Final Coins Only
                  </span>
                  <h3 className="font-serif text-lg font-bold text-white mt-0.5 text-center">
                    Launch Fundraising Campaign
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="absolute right-4 top-4 p-1.5 rounded-full hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form Body - Fully Center-Aligned */}
              <form onSubmit={handleCreateCampaign} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto w-full text-center flex flex-col items-center">
                {/* 1. Campaign Overview */}
                <div className="space-y-3 w-full text-center flex flex-col items-center">
                  <h4 className="text-xs font-mono uppercase font-bold text-slate-500 tracking-wider text-center">
                    1. Campaign Overview
                  </h4>

                  <div className="w-full">
                    <label className="text-xs font-bold text-slate-900 block mb-1 text-center">
                      Campaign Title
                    </label>
                    <input
                      type="text"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="e.g., Autonomous Solar Microgrid Protocol"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
                    <div>
                      <label className="text-xs font-bold text-slate-900 block mb-1 text-center">
                        Category
                      </label>
                      <select
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value as any)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
                      >
                        <option value="Tech & AI">Tech &amp; AI</option>
                        <option value="Clean Energy">Clean Energy</option>
                        <option value="Community">Community</option>
                        <option value="Infrastructure">Infrastructure</option>
                        <option value="Creative">Creative</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-900 block mb-1 text-center">
                        Campaign End Date &amp; Time
                      </label>
                      <div className="relative">
                        <input
                          type="datetime-local"
                          value={endDateTime}
                          onChange={(e) => setEndDateTime(e.target.value)}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 font-mono text-xs text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white"
                          required
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono block mt-0.5 text-center">Exact Expiry: 12/21/2026, 06:00 PM</span>
                    </div>
                  </div>

                  <div className="w-full">
                    <label className="text-xs font-bold text-slate-900 block mb-1 text-center">
                      Short Description &amp; Deliverables
                    </label>
                    <textarea
                      value={newShortDesc}
                      onChange={(e) => setNewShortDesc(e.target.value)}
                      placeholder="Explain the project scope, hardware deliverables, or barter milestones..."
                      rows={3}
                      className="w-full p-3 rounded-xl border border-slate-200 text-xs text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>

                {/* 2. Funding Target & Final Currency Selection */}
                <div className="space-y-4 pt-4 border-t border-slate-100 w-full text-center flex flex-col items-center">
                  <div className="text-center">
                    <h4 className="text-xs font-mono uppercase font-bold text-slate-500 tracking-wider text-center">
                      2. Funding Target (Final Currency &amp; Final Coins Only)
                    </h4>
                    <p className="text-[11px] text-slate-500 text-center">
                      Campaigns accept exclusively Final Currency and Final Coins.
                    </p>
                    <div className="mt-2 text-center">
                      <span className="text-[10px] font-mono text-slate-400 block uppercase">Total Target Value</span>
                      <span className="text-base font-bold font-mono text-emerald-700">
                        F {calculatedTotalFC.toLocaleString()} FC
                      </span>
                    </div>
                  </div>

                  {/* Final Coins Target + Accepted Coins Picker */}
                  <div className="w-full rounded-2xl border border-emerald-500 bg-emerald-50/30 p-4 space-y-3 transition-all text-center flex flex-col items-center">
                    <div className="flex items-center justify-center gap-2">
                      <Coins className="w-4 h-4 text-emerald-700" />
                      <span className="text-xs font-bold text-slate-900">Final Currency &amp; Final Coins (FC)</span>
                    </div>

                    <div className="relative w-full max-w-xs">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-emerald-700">
                        FC
                      </span>
                      <input
                        type="number"
                        min="1"
                        step="any"
                        value={finalCoinsAmount}
                        onChange={(e) => setFinalCoinsAmount(e.target.value)}
                        placeholder="25000"
                        className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs font-mono text-center bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 tabular-nums"
                        required
                      />
                    </div>

                    <div className="flex items-center justify-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setAcceptAllFinalCoins(true)}
                        className={`px-3 py-1.5 rounded-xl text-[11px] font-mono font-semibold border cursor-pointer transition-all ${
                          acceptAllFinalCoins
                            ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        Accept All Final Coins
                      </button>
                      <button
                        type="button"
                        onClick={() => setAcceptAllFinalCoins(false)}
                        className={`px-3 py-1.5 rounded-xl text-[11px] font-mono font-semibold border cursor-pointer transition-all ${
                          !acceptAllFinalCoins
                            ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        Select Specific Coins (up to 5)
                      </button>
                    </div>

                    {acceptAllFinalCoins ? (
                      <p className="text-[11px] text-emerald-800 font-mono text-center pt-1">
                        Backers can contribute using any Final Coin from their wallet (including user-minted Final Coins).
                      </p>
                    ) : (
                      <div className="w-full pt-2 border-t border-emerald-200/60 space-y-3 text-center flex flex-col items-center">
                        <div className="space-y-0.5 text-center">
                          <span className="text-xs font-bold text-slate-900 block text-center">
                            Select Up to 5 Final Coins Anywhere on Our Platform
                          </span>
                          <p className="text-[11px] text-slate-500 text-center">
                            Donors can back your campaign using any of these {selectedFinalCoins.length}/5 selected Final Coins.
                          </p>
                        </div>

                        {/* Selected Chips */}
                        <div className="flex flex-wrap items-center justify-center gap-1.5 w-full">
                          {selectedFinalCoins.map((sym) => (
                            <span
                              key={sym}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 text-xs font-mono font-bold border border-emerald-300"
                            >
                              <span>{sym}</span>
                              <button
                                type="button"
                                onClick={() => toggleCoinSelection(sym)}
                                className="hover:text-rose-600 p-0.5 cursor-pointer"
                                title="Remove coin"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </span>
                          ))}
                        </div>

                        {/* Search Input */}
                        <div className="relative w-full max-w-md">
                          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            value={finalCoinSearch}
                            onChange={(e) => setFinalCoinSearch(e.target.value)}
                            placeholder="Search Final Coins (e.g. AFNL, VANC, ASOV, WOLF)..."
                            className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs text-center font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                          />
                        </div>

                        {/* Coin Results Grid */}
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 w-full max-h-40 overflow-y-auto">
                          {filteredCreateCoins.map((coin) => {
                            const isSelected = selectedFinalCoins.includes(coin.symbol);
                            return (
                              <button
                                key={coin.symbol}
                                type="button"
                                onClick={() => toggleCoinSelection(coin.symbol)}
                                className={`p-2 rounded-xl border text-xs font-mono flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                                  isSelected
                                    ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs font-bold'
                                    : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-100'
                                }`}
                              >
                                <span className="text-sm">{coin.icon || '🪙'}</span>
                                <span className="font-bold">{coin.symbol}</span>
                                <span className={`text-[10px] truncate max-w-full ${isSelected ? 'text-emerald-100' : 'text-slate-500'}`}>
                                  {coin.name}
                                </span>
                                {coin.balance !== undefined && (
                                  <span className={`text-[9px] ${isSelected ? 'text-emerald-200' : 'text-emerald-700'}`}>
                                    {coin.balance.toLocaleString()} in wallet
                                  </span>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* 3. Campaign Media (Upload Photos & Videos) */}
                <div className="space-y-3 pt-4 border-t border-slate-100 w-full text-center flex flex-col items-center">
                  <div className="text-center">
                    <h4 className="text-xs font-mono uppercase font-bold text-slate-500 tracking-wider text-center">
                      3. Campaign Media (Upload Photos &amp; Videos)
                    </h4>
                    <p className="text-[11px] text-slate-500 text-center">
                      Upload high-resolution images, architectural renders, or pitch video clips.
                    </p>
                    <span className="text-[10px] font-mono text-slate-400 block mt-0.5 text-center">
                      {uploadedMediaList.length} file(s) added
                    </span>
                  </div>

                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    multiple
                    accept="image/*,video/*"
                    className="hidden"
                  />

                  {/* Drag & Drop Zone */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-6 rounded-2xl border-2 border-dashed border-slate-200 hover:border-emerald-500 bg-slate-50/60 hover:bg-emerald-50/20 transition-all text-center cursor-pointer group w-full"
                  >
                    <div className="flex items-center justify-center gap-3 mb-2">
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-emerald-600 shadow-xs group-hover:scale-105 transition-transform">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-purple-600 shadow-xs group-hover:scale-105 transition-transform">
                        <Video className="w-5 h-5" />
                      </div>
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-sky-600 shadow-xs group-hover:scale-105 transition-transform">
                        <UploadCloud className="w-5 h-5" />
                      </div>
                    </div>
                    <span className="text-xs font-bold text-slate-900 block text-center">
                      Click or Drag &amp; Drop to Upload Photos &amp; Videos
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-1 font-mono text-center">
                      PNG, JPG, WebP, MP4, MOV, WebM supported (Up to 50MB per file)
                    </span>
                  </div>

                  {uploadedMediaList.length > 0 && (
                    <div className="space-y-2 w-full pt-2">
                      <span className="text-[11px] font-mono text-slate-600 font-semibold block text-center">
                        Choose which uploaded picture to use as the Fundraiser Cover Photo:
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full">
                        {uploadedMediaList.map((media) => {
                          const isCover = media.type === 'image' && selectedCoverMediaId === media.id;
                          return (
                            <div
                              key={media.id}
                              onClick={() => {
                                if (media.type === 'image') setSelectedCoverMediaId(media.id);
                              }}
                              className={`relative rounded-xl border overflow-hidden group flex flex-col bg-white transition-all ${
                                media.type === 'image' ? 'cursor-pointer' : ''
                              } ${
                                isCover
                                  ? 'border-emerald-500 ring-2 ring-emerald-500/25'
                                  : 'border-slate-200 hover:border-slate-300'
                              }`}
                            >
                              <div className="relative h-24 w-full bg-slate-100 overflow-hidden">
                                {media.type === 'video' ? (
                                  <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center text-white p-2">
                                    <Video className="w-6 h-6 text-purple-400 mb-1" />
                                    <span className="text-[9px] font-mono text-center truncate max-w-full">
                                      {media.name}
                                    </span>
                                  </div>
                                ) : (
                                  <img
                                    src={media.url}
                                    alt={media.name}
                                    className="w-full h-full object-cover"
                                  />
                                )}

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRemoveMedia(media.id);
                                  }}
                                  className="absolute top-1.5 right-1.5 p-1 rounded-full bg-red-600 text-white hover:bg-red-700 transition-colors shadow-xs cursor-pointer"
                                  title="Remove media"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              </div>

                              {media.type === 'image' && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedCoverMediaId(media.id);
                                  }}
                                  className={`w-full py-1 px-2 text-[10px] font-semibold inline-flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                                    isCover
                                      ? 'bg-emerald-600 text-white'
                                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                                  }`}
                                >
                                  {isCover ? (
                                    <>
                                      <Check className="w-3 h-3" />
                                      <span>Cover Photo</span>
                                    </>
                                  ) : (
                                    <span>Set as Cover</span>
                                  )}
                                </button>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                {/* Submit & Cancel Buttons - Centered */}
                <div className="flex items-center justify-center gap-3 pt-4 border-t border-slate-100 w-full">
                  <button
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="flex-1 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/20"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Publish Sovereign Campaign</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: CHANGE CAMPAIGN COVER PHOTO ================= */}
      <AnimatePresence>
        {coverEditCampaign && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full p-6 space-y-4 text-center flex flex-col items-center"
            >
              <div className="flex items-center justify-between w-full">
                <div className="text-left">
                  <h3 className="font-serif text-lg font-bold text-slate-900">Change Cover Photo</h3>
                  <p className="text-xs text-slate-500 font-mono">{coverEditCampaign.title}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setCoverEditCampaign(null)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <input
                type="file"
                ref={coverEditFileInputRef}
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file || !file.type.startsWith('image/')) return;
                  const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
                  const reader = new FileReader();
                  reader.onload = () => {
                    const url = typeof reader.result === 'string' ? reader.result : URL.createObjectURL(file);
                    const newMed: UploadedMedia = {
                      id: `cover-${Date.now()}`,
                      url,
                      name: file.name,
                      type: 'image',
                      sizeFormatted: `${sizeInMB} MB`,
                      caption: `${coverEditCampaign.title} Cover`,
                    };
                    if (addCampaignMediaAndSetCover(coverEditCampaign.id, newMed, true)) {
                      refreshCampaigns();
                      setCoverEditCampaign(null);
                      addToast({
                        type: 'success',
                        title: 'Cover Photo Updated',
                        message: `"${file.name}" is now your fundraiser cover photo.`,
                      });
                    }
                  };
                  reader.readAsDataURL(file);
                  if (coverEditFileInputRef.current) coverEditFileInputRef.current.value = '';
                }}
              />

              <button
                type="button"
                onClick={() => coverEditFileInputRef.current?.click()}
                className="w-full p-4 rounded-2xl border-2 border-dashed border-slate-200 hover:border-emerald-500 bg-slate-50 hover:bg-emerald-50/30 transition-all cursor-pointer flex flex-col items-center gap-1.5"
              >
                <UploadCloud className="w-5 h-5 text-emerald-600" />
                <span className="text-xs font-bold text-slate-900">Upload New Cover Photo</span>
                <span className="text-[10px] font-mono text-slate-500">PNG, JPG, WebP</span>
              </button>

              {coverEditCampaign.mediaList?.some((m) => m.type === 'image') && (
                <div className="w-full space-y-2">
                  <span className="text-[11px] font-mono font-semibold text-slate-600 block">
                    Or pick from existing campaign pictures:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto">
                    {coverEditCampaign.mediaList
                      .filter((m) => m.type === 'image')
                      .map((imgMed) => {
                        const isCurrent = imgMed.url === coverEditCampaign.bannerUrl;
                        return (
                          <button
                            key={imgMed.id}
                            type="button"
                            onClick={() => {
                              if (updateCampaignCover(coverEditCampaign.id, imgMed.url)) {
                                refreshCampaigns();
                                setCoverEditCampaign(null);
                                addToast({
                                  type: 'success',
                                  title: 'Cover Photo Updated',
                                  message: 'Fundraiser cover photo updated.',
                                });
                              }
                            }}
                            className={`rounded-xl overflow-hidden border text-center cursor-pointer transition-all ${
                              isCurrent
                                ? 'border-emerald-500 ring-2 ring-emerald-500/25'
                                : 'border-slate-200 hover:border-emerald-400'
                            }`}
                          >
                            <img src={imgMed.url} alt={imgMed.name} className="w-full h-24 object-cover" />
                            <span
                              className={`block py-1 text-[10px] font-semibold ${
                                isCurrent ? 'bg-emerald-600 text-white' : 'bg-slate-50 text-slate-700'
                              }`}
                            >
                              {isCurrent ? 'Current Cover ✓' : 'Use as Cover'}
                            </span>
                          </button>
                        );
                      })}
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: SHARE ON TWEETING (WITH NOTE) ================= */}
      <ShareOnTweetingModal
        isOpen={!!selectedShareCampaign}
        onClose={() => setSelectedShareCampaign(null)}
        campaign={selectedShareCampaign}
        currentUser={currentUser}
      />
    </div>
  );
};
