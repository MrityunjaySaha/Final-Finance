import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { AssetClass } from '../types';
import { 
  Sparkles, 
  Layers, 
  X, 
  Upload, 
  Wand2, 
  CheckCircle2, 
  ShieldCheck, 
  RefreshCw 
} from 'lucide-react';

interface NewListingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewListingModal: React.FC<NewListingModalProps> = ({ isOpen, onClose }) => {
  const { createListing, stagedAssetForDraft, setStagedAssetForDraft, addToast } = useApp();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<AssetClass>('final_coins');
  const [priceUSD, setPriceUSD] = useState<number>(250000);
  const [priceInNative, setPriceInNative] = useState('12,500 AFNL');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80');
  const [imageResolution, setImageResolution] = useState('4K Ultra-HD');
  const [modelUsed, setModelUsed] = useState('gemini-3-pro-image-preview');
  const [appraisalGrade, setAppraisalGrade] = useState('AAA');
  const [isGeneratingInstantAI, setIsGeneratingInstantAI] = useState(false);

  // Sync staged asset if coming from AI studio
  useEffect(() => {
    if (stagedAssetForDraft) {
      setTitle(stagedAssetForDraft.title || '');
      setDescription(stagedAssetForDraft.description || '');
      setCategory(stagedAssetForDraft.category || 'final_coins');
      setImageUrl(stagedAssetForDraft.imageUrl || '');
      if (stagedAssetForDraft.imageResolution) setImageResolution(stagedAssetForDraft.imageResolution);
      if (stagedAssetForDraft.modelUsed) setModelUsed(stagedAssetForDraft.modelUsed);
    }
  }, [stagedAssetForDraft]);

  if (!isOpen) return null;

  const handleInstantAIGenerate = async () => {
    if (!title.trim()) {
      addToast({ type: 'error', title: 'Asset Title Required', message: 'Enter an asset title first to generate matching visual.' });
      return;
    }

    setIsGeneratingInstantAI(true);
    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Masterpiece luxury physical reserve asset: ${title}. ${description || 'Refined gold bullion, obsidian stand, cinematic studio lighting.'}`,
          model: 'gemini-3-pro-image-preview',
          imageSize: '4K',
          aspectRatio: '1:1',
          useSearch: true,
        }),
      });
      const data = await res.json();
      if (data.success && data.imageUrl) {
        setImageUrl(data.imageUrl);
        setImageResolution('4K Ultra-HD');
        setModelUsed('gemini-3-pro-image-preview');
        addToast({
          type: 'gold',
          title: '4K Visual Generated',
          message: 'Asset rendered via gemini-3-pro-image-preview.'
        });
      }
    } catch (err: any) {
      addToast({ type: 'error', title: 'AI Generation Failed', message: err?.message });
    } finally {
      setIsGeneratingInstantAI(false);
    }
  };

  const handleSubmit = (status: 'active' | 'draft') => {
    if (!title.trim() || !priceUSD || !imageUrl) {
      addToast({ type: 'error', title: 'Incomplete Asset Details', message: 'Title, valuation, and visual asset are required.' });
      return;
    }

    createListing({
      title,
      category,
      priceUSD,
      priceInNative,
      description: description || `Certified institutional reserve asset in Vault: ${category.toUpperCase()}.`,
      imageUrl,
      imageResolution,
      modelUsed,
      attributes: {
        'Category': category.toUpperCase().replace('_', ' '),
        'Appraisal': `${appraisalGrade} Sovereign Grade`,
        'Audited Custody': 'Swiss Depository / L1 Smart Escrow',
        'Model Engine': modelUsed
      },
      status,
      appraisalGrade
    });

    setStagedAssetForDraft(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl border border-amber-500/30 bg-[#0d1017] p-6 shadow-2xl space-y-5 my-8">
        
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div>
            <h3 className="font-serif text-lg font-bold text-white flex items-center gap-2">
              <Layers className="h-5 w-5 text-amber-400" />
              <span>Create Marketplace Asset Draft & Upload</span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Draft any physical commodity, minted coin, currency voucher, or cryptographic reserve token.
            </p>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white text-sm">✕</button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Left Column: Details */}
          <div className="space-y-3.5">
            <div>
              <label className="text-xs font-semibold text-white block mb-1">Asset Name / Title</label>
              <input
                type="text"
                placeholder="e.g. 100oz Sovereign Gold Bullion Ingot"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-white block mb-1">Reserve Vault Asset Class</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as AssetClass)}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none"
              >
                <option value="final_coins">Final Coins (AFNL)</option>
                <option value="barter">Barter Goods & Services (Physical Commodities & Horology)</option>
                <option value="stable_coins">Stable Coins (Attested Parity)</option>
                <option value="fiat">Fiat Currency (Sovereign Depository)</option>
                <option value="crypto">Cryptocurrency (Cold Storage Multi-Sig)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold text-white block mb-1">Valuation (USD)</label>
                <input
                  type="number"
                  value={priceUSD}
                  onChange={(e) => setPriceUSD(Number(e.target.value))}
                  className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white font-mono focus:border-amber-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-white block mb-1">Native Denomination</label>
                <input
                  type="text"
                  placeholder="e.g. 12,500 AFNL"
                  value={priceInNative}
                  onChange={(e) => setPriceInNative(e.target.value)}
                  className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white font-mono focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-white block mb-1">Description & Provenance</label>
              <textarea
                rows={3}
                placeholder="Physical purity, serial matrix, vault custody facility..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Right Column: Visual Asset & AI Generator */}
          <div className="space-y-3.5">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-white">Visual Asset Representation</label>
                <span className="text-[10px] font-mono text-amber-300">{imageResolution}</span>
              </div>
              
              <div className="relative h-44 w-full rounded-xl border border-neutral-800 bg-neutral-950 overflow-hidden flex items-center justify-center">
                {isGeneratingInstantAI ? (
                  <div className="p-4 text-center space-y-2 animate-pulse">
                    <div className="h-8 w-8 mx-auto rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
                    <p className="text-xs font-semibold text-amber-300">Rendering with gemini-3-pro-image-preview (4K)...</p>
                  </div>
                ) : (
                  <img src={imageUrl} alt="Preview" className="h-full w-full object-cover" />
                )}
              </div>
            </div>

            {/* Trigger AI Visual Generator Button */}
            <button
              type="button"
              onClick={handleInstantAIGenerate}
              disabled={isGeneratingInstantAI}
              className="w-full flex items-center justify-center gap-1.5 rounded-lg border border-amber-500/40 bg-amber-500/10 py-2 text-xs font-bold text-amber-300 hover:bg-amber-500/20 transition-colors"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Generate New 4K AI Visual (Pro Engine)</span>
            </button>

            <div className="rounded-lg bg-neutral-900/80 p-2.5 text-[11px] space-y-1 text-neutral-400">
              <div className="flex justify-between">
                <span>Model Engine:</span>
                <span className="font-mono text-amber-300">{modelUsed}</span>
              </div>
              <div className="flex justify-between">
                <span>Attestation Grade:</span>
                <span className="font-mono text-emerald-400">AAA+ Institutional Backing</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-between border-t border-neutral-800 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-neutral-800 bg-neutral-900 px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white"
          >
            Cancel
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => handleSubmit('draft')}
              className="rounded-xl border border-neutral-700 bg-neutral-800 px-4 py-2 text-xs font-semibold text-neutral-200 hover:bg-neutral-700 transition-colors"
            >
              Save as Private Draft
            </button>
            <button
              type="button"
              onClick={() => handleSubmit('active')}
              className="rounded-xl border border-amber-500 bg-gradient-to-r from-amber-500 to-amber-600 px-5 py-2 text-xs font-bold text-black hover:opacity-95 transition-opacity shadow-lg shadow-amber-500/20"
            >
              Publish Live to Marketplace
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
