import React, { useState, useEffect } from 'react';
import { Star, MessageSquare, Send, CheckCircle2 } from 'lucide-react';
import {
  getRatingsForUser,
  addReview,
  getAverageRating,
  getExistingReviewByReviewer,
  Review,
} from '../../services/ratingService';
import { AuthSession } from '../../types/auth';
import { getIdentityAliases } from '../../services/socialService';

interface UserRatingSectionProps {
  targetUserId: string;
  currentUser: AuthSession | null;
  onRatingSubmitted?: () => void;
}

export const UserRatingSection: React.FC<UserRatingSectionProps> = ({
  targetUserId,
  currentUser,
  onRatingSubmitted,
}) => {
  const [ratings, setRatings] = useState<Review[]>([]);
  const [avgRating, setAvgRating] = useState({ average: 0, count: 0 });
  const [existingReview, setExistingReview] = useState<Review | null>(null);
  const [userRating, setUserRating] = useState(5);
  const [userComment, setUserComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const loadRatings = () => {
    setRatings(getRatingsForUser(targetUserId));
    setAvgRating(getAverageRating(targetUserId));
    if (currentUser) {
      const existing = getExistingReviewByReviewer(targetUserId, [
        currentUser.id,
        currentUser.uid,
        currentUser.handle,
      ]);
      setExistingReview(existing);
      if (existing) {
        setUserRating(existing.rating);
        setUserComment(existing.comment);
      } else {
        setUserRating(5);
        setUserComment('');
      }
    } else {
      setExistingReview(null);
    }
  };

  useEffect(() => {
    loadRatings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetUserId, currentUser?.id, currentUser?.uid]);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (userComment.trim().length < 3) return;

    setIsSubmitting(true);
    const res = addReview({
      targetUserId,
      reviewerId: currentUser.id,
      reviewerUid: currentUser.uid,
      reviewerName: currentUser.name,
      reviewerAvatar: currentUser.avatarUrl,
      rating: userRating,
      comment: userComment.trim(),
    });

    setIsSubmitting(false);
    setFeedbackMessage(res.isUpdate ? 'Your rating & review was updated.' : 'Your rating & review was submitted.');
    setTimeout(() => setFeedbackMessage(null), 3000);
    loadRatings();
    onRatingSubmitted?.();
  };

  const renderStars = (rating: number, onStarClick?: (r: number) => void, onStarHover?: (r: number) => void) => {
    return (
      <div className="flex items-center justify-center gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${onStarClick ? 'cursor-pointer' : ''} transition-colors ${
              (onStarHover ? hoverRating || rating : rating) >= star
                ? 'fill-amber-400 text-amber-400'
                : 'text-slate-300'
            }`}
            onClick={() => onStarClick?.(star)}
            onMouseEnter={() => onStarHover?.(star)}
            onMouseLeave={() => onStarHover?.(0)}
          />
        ))}
      </div>
    );
  };

  const normPeerId = (val?: string) =>
    String(val || '').replace(/^@/, '').replace(/^user-/, '').trim().toLowerCase().replace(/[_\-\s]/g, '');

  const isSameAsTarget = (() => {
    if (!currentUser) return false;
    const targetAliases = new Set(
      [targetUserId, ...getIdentityAliases(targetUserId)].map(normPeerId).filter(Boolean)
    );
    const viewerIds = [
      currentUser.id,
      currentUser.uid,
      currentUser.handle,
      ...getIdentityAliases(currentUser.id),
      ...(currentUser.uid ? getIdentityAliases(currentUser.uid) : []),
    ]
      .map(normPeerId)
      .filter(Boolean);
    return viewerIds.some((v) => targetAliases.has(v));
  })();

  return (
    <div className="space-y-6">
      {/* Centered Summary Header */}
      <div className="flex flex-col items-center justify-center text-center border-b border-slate-100 pb-5 gap-2">
        <div className="w-11 h-11 rounded-2xl bg-amber-50 border border-amber-200/70 flex items-center justify-center text-amber-600 mx-auto">
          <Star className="w-5 h-5 fill-amber-500" />
        </div>
        <div className="space-y-1 text-center">
          <h3 className="text-base font-bold text-slate-900">Peer Ratings &amp; Reviews</h3>
          <div className="flex items-center justify-center gap-2 flex-wrap">
            <div className="flex items-center justify-center gap-1.5">
              {renderStars(Math.round(avgRating.average))}
              <span className="text-xs font-bold text-slate-900">{avgRating.average}</span>
            </div>
            <span className="text-[11px] text-slate-500">
              • {avgRating.count} {avgRating.count === 1 ? 'review' : 'reviews'}
            </span>
          </div>
        </div>
      </div>

      {/* Write / Update a Single Review */}
      {currentUser && !isSameAsTarget && (
        <form onSubmit={handleSubmitReview} className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200/60 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="text-left">
              <span className="text-xs font-bold text-slate-800 block">
                {existingReview ? 'Update your review' : 'Write a review'}
              </span>
              <span className="text-[11px] text-slate-500">
                {existingReview
                  ? 'You can leave one review per member and update it anytime.'
                  : 'One rating & review per member (updatable anytime).'}
              </span>
            </div>
            {renderStars(userRating, setUserRating, setHoverRating)}
          </div>

          <div className="relative">
            <textarea
              value={userComment}
              onChange={(e) => setUserComment(e.target.value)}
              placeholder="Share your experience with this member..."
              className="w-full min-h-[84px] p-3 pb-11 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500 resize-none"
            />
            <button
              type="submit"
              disabled={isSubmitting || userComment.trim().length < 3}
              className="absolute bottom-2.5 right-2.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-[11px] font-bold inline-flex items-center gap-1.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{existingReview ? 'Update Rating' : 'Submit Rating'}</span>
            </button>
          </div>

          {feedbackMessage && (
            <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl py-2 px-3">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{feedbackMessage}</span>
            </div>
          )}
        </form>
      )}

      {/* Reviews List */}
      <div className="space-y-4">
        {ratings.length === 0 ? (
          <div className="py-10 text-center space-y-2">
            <MessageSquare className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-xs text-slate-500">No reviews yet. Be the first to rate!</p>
          </div>
        ) : (
          ratings.map((review) => (
            <div
              key={review.id}
              className="group p-4 rounded-2xl bg-white border border-slate-100 hover:border-slate-200 transition-all space-y-2.5 text-left"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 overflow-hidden border border-slate-200 shrink-0">
                    {review.reviewerAvatar ? (
                      <img src={review.reviewerAvatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-slate-900 text-white text-[10px] font-bold">
                        {review.reviewerName.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">@{review.reviewerId}</div>
                    <div className="text-[10px] text-slate-500">
                      {new Date(review.updatedAt || review.timestamp).toLocaleDateString()}
                      {review.updatedAt ? ' (Edited)' : ''}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100">
                  <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                  <span className="text-[10px] font-bold text-amber-800">{review.rating}</span>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed italic">
                &quot;{review.comment}&quot;
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
