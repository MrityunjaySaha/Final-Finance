import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig, type Plugin } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

const CROSS_FETCH_SHIM_PATH = path.resolve(__dirname, 'src/shims/cross-fetch.ts');
const BASE_ACCOUNT_FILE_RE = /@base-org[\\/]account[\\/].*\.(m?js|cjs)$/;
const SAFE_WINDOW_TOP_EXPR =
  '(() => { try { const t = window.top; return t && t.ethereum !== void 0 ? t : void 0; } catch { return void 0; } })()';

function patchBaseAccountIframeSafety(code: string): string {
  if (!code.includes('window.top')) return code;
  return code.replace(/\bwindow\.top\b/g, SAFE_WINDOW_TOP_EXPR);
}

function safeBaseAccountIframePlugin(): Plugin {
  return {
    name: 'safe-base-account-iframe',
    enforce: 'pre',
    transform(code, id) {
      if (!BASE_ACCOUNT_FILE_RE.test(id)) return null;
      const patched = patchBaseAccountIframeSafety(code);
      if (patched === code) return null;
      return { code: patched, map: null };
    },
  };
}

function disableHmrClientWebSocketPlugin(): Plugin {
  let hmrDisabled = false;
  return {
    name: 'disable-hmr-client-websocket',
    apply: 'serve',
    enforce: 'post',
    configResolved(resolvedConfig) {
      hmrDisabled = resolvedConfig.server.hmr === false || resolvedConfig.server.ws === false;
    },
    transform(code, id) {
      if (!hmrDisabled) return;
      if (id.includes('vite/dist/client/client.mjs') || id.includes('@vite/client')) {
        const replaced = code.replace(
          /let wsTransport\s*=\s*createWebSocketModuleRunnerTransport\(\{[\s\S]*?new WebSocket[\s\S]*?\}\);/,
          'let wsTransport = { async connect() {}, async disconnect() {}, send() {} };'
        );
        if (replaced !== code) {
          return { code: replaced, map: null };
        }
      }
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      safeBaseAccountIframePlugin(),
      disableHmrClientWebSocketPlugin(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon.svg', 'icon-maskable.svg'],
        manifest: {
          id: '/',
          name: 'Final Finance',
          short_name: 'FinalFinance',
          description:
            'Luxury multi-asset financial ecosystem with reserve vaults, coin stock markets, universal tax receipt ledger, barter exchange, and peer clearing.',
          theme_color: '#0f172a',
          background_color: '#0f172a',
          display: 'standalone',
          display_override: ['window-controls-overlay', 'standalone', 'minimal-ui'],
          orientation: 'any',
          start_url: '/',
          scope: '/',
          prefer_related_applications: false,
          categories: ['finance', 'business', 'productivity'],
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          maximumFileSizeToCacheInBytes: 8 * 1024 * 1024,
          navigateFallback: '/index.html',
          navigateFallbackDenylist: [/^\/api\//, /^\/webhooks\//],
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: ({ url }) => url.pathname.startsWith('/api/'),
              handler: 'NetworkOnly',
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
          navigateFallback: 'index.html',
        },
      }),
    ],
    resolve: {
      alias: [
        { find: '@', replacement: path.resolve(__dirname, '.') },
        { find: /^cross-fetch(\/.*)?$/, replacement: CROSS_FETCH_SHIM_PATH },
      ],
    },
    optimizeDeps: {
      esbuildOptions: {
        plugins: [
          {
            name: 'safe-cross-fetch-shim',
            setup(build) {
              build.onResolve({ filter: /^cross-fetch(\/.*)?$/ }, () => ({
                path: CROSS_FETCH_SHIM_PATH,
              }));
            },
          },
          {
            name: 'safe-base-account-iframe-esbuild',
            setup(build) {
              build.onLoad({ filter: BASE_ACCOUNT_FILE_RE, namespace: 'file' }, async (args) => {
                const raw = await fs.promises.readFile(args.path, 'utf8');
                const patched = patchBaseAccountIframeSafety(raw);
                return { contents: patched, loader: 'js' };
              });
            },
          },
        ],
      },
    },
    server: {
      host: '0.0.0.0',
      port: 3000,
      allowedHosts: true as const,
      hmr: false,
      ws: false as const,
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
    build: {
      outDir: 'dist',
      sourcemap: false,
      reportCompressedSize: false,
      chunkSizeWarningLimit: 3000,
      rollupOptions: {
        maxParallelFileOps: 2,
        onwarn(warning, warn) {
          if (warning.code === 'INVALID_ANNOTATION' && warning.id?.includes('node_modules')) {
            return;
          }
          warn(warning);
        },
        output: {
          chunkFileNames: (chunkInfo) => {
            const safeName = (chunkInfo.name || 'chunk')
              .replace(/error/gi, 'notice')
              .replace(/[^a-zA-Z0-9._-]/g, '-');
            return `assets/${safeName}-[hash].js`;
          },
          assetFileNames: (assetInfo) => {
            const rawName = assetInfo.names?.[0] || assetInfo.name || 'asset';
            const ext = path.posix.extname(rawName);
            const base = path.posix.basename(rawName, ext).replace(/error/gi, 'notice');
            return `assets/${base}-[hash][extname]`;
          },
          manualChunks: {
            'react-vendor': ['react', 'react-dom'],
            'charts': ['recharts'],
            'icons': ['lucide-react'],
            'motion': ['motion'],
          },
        },
      },
    },
  };
});
