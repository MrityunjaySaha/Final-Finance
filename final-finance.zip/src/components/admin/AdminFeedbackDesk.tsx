import React, { useState } from 'react';
import { 
  MessageSquare, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  Trash2, 
  AlertCircle,
  HelpCircle,
  Sparkles,
  Crown,
  Send,
  AlertOctagon,
  ShieldAlert
} from 'lucide-react';
import { 
  getFeedbackList, 
  updateFeedbackStatus, 
  deleteFeedback, 
  AppFeedback,
  getAdminEscalations,
  submitAdminEscalation,
  AdminEscalation
} from '../../services/feedbackService';
import { useApp } from '../../context/AppContext';

interface AdminFeedbackDeskProps {
  onNotify: (msg: string, type: 'success' | 'error' | 'info') => void;
  currentUser: any;
}

export const AdminFeedbackDesk: React.FC<AdminFeedbackDeskProps> = ({ onNotify, currentUser }) => {
  const { addNotification } = useApp();
  const [feedbacks, setFeedbacks] = useState<AppFeedback[]>(() => getFeedbackList());
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState('');

  // Escalation to Super Admin States
  const [escalations, setEscalations] = useState<AdminEscalation[]>(() => getAdminEscalations());
  const [isEscalating, setIsEscalating] = useState(false);
  const [escalationSubject, setEscalationSubject] = useState('');
  const [escalationMessage, setEscalationMessage] = useState('');
  const [escalationSeverity, setEscalationSeverity] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [activeSubView, setActiveSubView] = useState<'user_feedback' | 'super_admin_feedback'>('user_feedback');

  const handleSendEscalation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!escalationSubject.trim() || !escalationMessage.trim()) {
      onNotify('Please complete both subject and content message.', 'error');
      return;
    }
    submitAdminEscalation({
      admin: currentUser || { name: 'Admin Officer', email: 'admin@finalfinance.io', id: 'adm-guest' },
      subject: escalationSubject,
      message: escalationMessage,
      severity: escalationSeverity
    });
    addNotification({
      title: `Escalation Sent: ${escalationSubject.slice(0, 30)}${escalationSubject.length > 30 ? '...' : ''}`,
      description: `Urgent advisory transmitted directly to Super Admin under [${escalationSeverity.toUpperCase()}] priority.`,
      type: 'system',
      targetTab: 'feedback'
    });
    setEscalations(getAdminEscalations());
    setEscalationSubject('');
    setEscalationMessage('');
    setIsEscalating(false);
    onNotify('Ecosystem escalation report successfully transmitted to Super Admin!', 'success');
  };

  const refreshList = () => {
    setFeedbacks(getFeedbackList());
  };

  const handleUpdateStatus = (id: string, nextStatus: AppFeedback['status'], message?: string) => {
    const success = updateFeedbackStatus(id, nextStatus, undefined, message);
    if (success) {
      refreshList();
      setResolvingId(null);
      setReviewingId(null);
      setStatusMessage('');
      onNotify(`Feedback status updated to ${nextStatus.toUpperCase()}`, 'success');
    } else {
      onNotify('Failed to update status', 'error');
    }
  };

  const handleDelete = (id: string) => {
    const success = deleteFeedback(id);
    if (success) {
      refreshList();
      setDeletingId(null);
      onNotify('Feedback entry deleted successfully.', 'success');
    } else {
      onNotify('Failed to delete feedback entry.', 'error');
    }
  };

  // Filter Logic
  const filteredFeedbacks = feedbacks.filter((fb) => {
    // Search match (username, handle, comments, suggestions)
    const matchesSearch = 
      fb.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fb.userHandle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fb.comments.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (fb.suggestions && fb.suggestions.toLowerCase().includes(searchQuery.toLowerCase()));

    // Category match
    const matchesCategory = categoryFilter === 'all' || fb.category === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Header Panel */}
      <div className="p-6 border-b border-slate-200 bg-slate-50/50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-600" />
              <span>Administrative Feedback Console</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Review user experience logs or route direct priority escalation reports to Super Admin
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveSubView('user_feedback')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                activeSubView === 'user_feedback'
                  ? 'bg-indigo-50 text-indigo-700 border-indigo-200 font-bold shadow-2xs'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              User Feedback ({feedbacks.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveSubView('super_admin_feedback')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSubView === 'super_admin_feedback'
                  ? 'bg-amber-50 text-amber-700 border-amber-200 font-bold shadow-2xs'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-amber-500" />
              <span>To Super Admin ({escalations.length})</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar only visible for user_feedback */}
        {activeSubView === 'user_feedback' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search comments or users..."
                className="w-full pl-9 pr-4 py-1.5 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Category Filter */}
            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="w-full px-2 py-1.5 rounded-xl border border-slate-200 text-xs focus:outline-hidden"
              >
                <option value="all">All Feedback Types</option>
                <option value="general">General Thoughts</option>
                <option value="bug">Bug Reports</option>
                <option value="feature">Feature Requests</option>
                <option value="ui">UI/UX Polish</option>
                <option value="other">Other Ideas</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Logs Table / Cards */}
      <div className="p-6">
        {activeSubView === 'super_admin_feedback' ? (
          <div className="space-y-6 animate-fade-in">
            {/* Compose Escalation Form */}
            <form onSubmit={handleSendEscalation} className="bg-slate-50/40 p-5 rounded-2xl border border-slate-200 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Draft New System Advisory</h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Brief Subject / Alert Title</label>
                  <input
                    type="text"
                    required
                    value={escalationSubject}
                    onChange={(e) => setEscalationSubject(e.target.value)}
                    placeholder="e.g. Depository Vault Liquid Reserves Alert"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs focus:outline-hidden focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Severity / Urgency Classification</label>
                  <select
                    value={escalationSeverity}
                    onChange={(e) => setEscalationSeverity(e.target.value as any)}
                    className="w-full px-2 py-2 rounded-xl border border-slate-200 bg-white text-xs focus:outline-hidden"
                  >
                    <option value="low">Low - General Feedback</option>
                    <option value="medium">Medium - Depository / UX</option>
                    <option value="high">High - Action Required</option>
                    <option value="critical">Critical - System Lock Risk</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Details & Message Payload</label>
                <textarea
                  required
                  rows={4}
                  value={escalationMessage}
                  onChange={(e) => setEscalationMessage(e.target.value)}
                  placeholder="Provide precise details, accounts of interest, log identifiers, and requested super-admin intervention actions..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs focus:outline-hidden focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5 text-amber-400" />
                  <span>Transmit to Super Admin</span>
                </button>
              </div>
            </form>

            {/* List of Sent Escalations */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Advisory Transmissions &amp; Status</h4>
              
              {escalations.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs border border-dashed border-slate-200 rounded-2xl">
                  No active advisory briefs or escalations logged.
                </div>
              ) : (
                <div className="space-y-3">
                  {escalations.map((esc) => (
                    <div key={esc.id} className="p-4 rounded-xl border border-slate-200 bg-white hover:shadow-2xs transition-shadow space-y-3">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-xs text-slate-900">{esc.subject}</span>
                            <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                              esc.severity === 'critical' ? 'bg-red-100 text-red-800 border border-red-200' :
                              esc.severity === 'high' ? 'bg-orange-100 text-orange-800 border border-orange-200' :
                              esc.severity === 'medium' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                              'bg-slate-100 text-slate-800 border border-slate-200'
                            }`}>
                              {esc.severity}
                            </span>
                            <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider ${
                              esc.status === 'resolved' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                              esc.status === 'investigating' ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' :
                              'bg-amber-100 text-amber-800 border border-amber-200'
                            }`}>
                              {esc.status}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">
                            Logged by {esc.adminName} ({esc.adminEmail}) • {new Date(esc.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400">ID: {esc.id}</span>
                      </div>

                      <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                        <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap">{esc.message}</p>
                      </div>

                      {(esc.investigatingNotes || esc.resolvedNotes || esc.superAdminNotes) && (
                        <div className="space-y-2">
                          {esc.investigatingNotes && (
                            <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl flex gap-2">
                              <Crown className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                              <div className="space-y-0.5">
                                <span className="text-[9px] font-mono uppercase tracking-wider text-indigo-800 font-bold">Investigating Response</span>
                                <p className="text-xs text-slate-700 italic">"{esc.investigatingNotes}"</p>
                              </div>
                            </div>
                          )}
                          
                          {esc.resolvedNotes && (
                            <div className="p-3 bg-emerald-50/50 border border-emerald-100 rounded-xl flex gap-2">
                              <Crown className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                              <div className="space-y-0.5">
                                <span className="text-[9px] font-mono uppercase tracking-wider text-emerald-800 font-bold">Resolution Notes</span>
                                <p className="text-xs text-slate-700 italic">"{esc.resolvedNotes}"</p>
                              </div>
                            </div>
                          )}

                          {esc.superAdminNotes && !esc.investigatingNotes && !esc.resolvedNotes && (
                            <div className="p-3 bg-amber-50/50 border border-amber-100 rounded-xl flex gap-2">
                              <Crown className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                              <div className="space-y-0.5">
                                <span className="text-[9px] font-mono uppercase tracking-wider text-amber-800 font-bold">Super Admin Response</span>
                                <p className="text-xs text-slate-700 italic">"{esc.superAdminNotes}"</p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* User Feedback Logs */
          filteredFeedbacks.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs space-y-2">
              <AlertCircle className="w-8 h-8 text-slate-300 mx-auto" />
              <p>No feedback matching the selected filters was found.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredFeedbacks.map((fb) => (
                <div 
                  key={fb.id} 
                  className={`p-5 rounded-2xl border transition-all flex flex-col md:flex-row justify-between gap-4 ${
                    fb.status === 'resolved' 
                      ? 'border-emerald-200/60 bg-emerald-50/10' 
                      : fb.status === 'reviewed'
                      ? 'border-slate-200 bg-slate-50/30'
                      : 'border-indigo-100 bg-indigo-50/5'
                  }`}
                >
                  {/* Left: User details, Category, Comments */}
                  <div className="space-y-3 flex-1">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <img
                        src={fb.userAvatar}
                        alt={fb.userName}
                        className="w-7 h-7 rounded-full object-cover border border-slate-200 shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs text-slate-900">{fb.userName}</span>
                          {!fb.isAnonymous && (
                            <span className="text-[10px] font-mono text-slate-400">@{fb.userHandle}</span>
                          )}
                        </div>
                        <span className="text-[9px] font-mono text-slate-400 block">
                          {new Date(fb.timestamp).toLocaleString()}
                        </span>
                      </div>

                      <div className="ml-auto md:ml-0 flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                          fb.category === 'bug' ? 'bg-red-50 text-red-700 border border-red-100' :
                          fb.category === 'feature' ? 'bg-purple-50 text-purple-700 border border-purple-100' :
                          fb.category === 'ui' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                          fb.category === 'general' ? 'bg-teal-50 text-teal-700 border border-teal-100' :
                          'bg-slate-50 text-slate-700 border border-slate-100'
                        }`}>
                          {fb.category}
                        </span>

                        <div className="flex items-center">
                          <span className="text-[10px] font-mono text-slate-400">Feedback Entry</span>
                        </div>
                      </div>
                    </div>

                    {/* Comments Block */}
                    <div className="space-y-2">
                      <div className="p-3 bg-white border border-slate-200/80 rounded-xl">
                        <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block mb-0.5">User Comments</span>
                        <p className="text-xs text-slate-700 leading-relaxed italic">"{fb.comments}"</p>
                      </div>

                      {fb.suggestions && (
                        <div className="p-3 bg-slate-50/50 border border-slate-150 rounded-xl">
                          <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block mb-0.5">Usability Suggestion</span>
                          <p className="text-xs text-slate-600 leading-relaxed">"{fb.suggestions}"</p>
                        </div>
                      )}
                    </div>

                    {/* Admin messages view */}
                    <div className="pt-1.5 border-t border-slate-100 space-y-2">
                      {fb.reviewMessage && (
                        <div className="p-3 bg-blue-50/40 border border-blue-100 rounded-xl flex gap-2">
                          <Clock className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                          <div className="space-y-0.5">
                            <span className="text-[9px] font-mono uppercase tracking-wider text-blue-800 font-bold">Review Message to User</span>
                            <p className="text-xs text-slate-700 italic">"{fb.reviewMessage}"</p>
                            {fb.reviewedAt && (
                              <span className="text-[8px] text-slate-400 block mt-0.5">Reviewed at: {new Date(fb.reviewedAt).toLocaleString()}</span>
                            )}
                          </div>
                        </div>
                      )}

                      {fb.resolutionMessage && (
                        <div className="p-3 bg-emerald-50/40 border border-emerald-100 rounded-xl flex gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                          <div className="space-y-0.5">
                            <span className="text-[9px] font-mono uppercase tracking-wider text-emerald-800 font-bold">Resolution Message to User</span>
                            <p className="text-xs text-slate-700 italic">"{fb.resolutionMessage}"</p>
                            {fb.resolvedAt && (
                              <span className="text-[8px] text-slate-400 block mt-0.5">Resolved at: {new Date(fb.resolvedAt).toLocaleString()}</span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex flex-row md:flex-col justify-end md:justify-center items-center gap-2.5 shrink-0 border-t md:border-t-0 md:border-l border-slate-200/60 pt-3 md:pt-0 md:pl-4">
                    <div className="flex flex-col gap-2.5 w-full pt-1">
                      {/* 1. Mark Reviewed Block */}
                      <div className="w-full">
                        {reviewingId === fb.id ? (
                          <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl space-y-3 animate-in fade-in slide-in-from-top-1 duration-200 shadow-xs">
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold text-blue-800 uppercase block">Review Note to User</label>
                              <textarea
                                value={statusMessage}
                                onChange={(e) => setStatusMessage(e.target.value)}
                                placeholder="Acknowledge the feedback and explain next steps..."
                                className="w-full px-3 py-2 rounded-xl border border-blue-300 bg-white text-xs focus:outline-hidden focus:ring-1 focus:ring-blue-500 min-h-[60px]"
                              />
                              <p className="text-[9px] text-blue-600 font-medium">Sending review acknowledgment and updating status.</p>
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => handleUpdateStatus(fb.id, 'reviewed', statusMessage)}
                                className="flex-1 py-1.5 bg-blue-600 text-white rounded-lg text-[10px] font-bold hover:bg-blue-700 transition-colors cursor-pointer shadow-2xs"
                              >
                                Confirm Review
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setReviewingId(null);
                                  setStatusMessage('');
                                }}
                                className="px-3 py-1.5 bg-white text-slate-500 rounded-lg text-[10px] border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setReviewingId(fb.id);
                              setResolvingId(null);
                              setDeletingId(null);
                              setStatusMessage('');
                            }}
                            className={`px-2.5 py-1.5 rounded-lg border text-[10px] font-bold transition-all cursor-pointer w-full text-center shadow-3xs ${
                              fb.status === 'reviewed' 
                                ? 'bg-blue-50 border-blue-200 text-blue-700 opacity-60' 
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            Mark Reviewed
                          </button>
                        )}
                      </div>

                      {/* 2. Mark Resolved Block */}
                      <div className="w-full">
                        {resolvingId === fb.id ? (
                          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-3 animate-in fade-in slide-in-from-top-1 duration-200 shadow-xs">
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold text-emerald-800 uppercase block">Resolution Note to User</label>
                              <textarea
                                value={statusMessage}
                                onChange={(e) => setStatusMessage(e.target.value)}
                                placeholder="Explain how this issue was resolved..."
                                className="w-full px-3 py-2 rounded-xl border border-emerald-300 bg-white text-xs focus:outline-hidden focus:ring-1 focus:ring-emerald-500 min-h-[60px]"
                              />
                              <p className="text-[9px] text-emerald-600 font-medium">Finalizing resolution and notifying user.</p>
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => handleUpdateStatus(fb.id, 'resolved', statusMessage)}
                                className="flex-1 py-1.5 bg-emerald-600 text-white rounded-lg text-[10px] font-bold hover:bg-emerald-700 transition-colors cursor-pointer shadow-2xs"
                              >
                                Confirm Resolution
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setResolvingId(null);
                                  setStatusMessage('');
                                }}
                                className="px-3 py-1.5 bg-white text-slate-500 rounded-lg text-[10px] border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setResolvingId(fb.id);
                              setReviewingId(null);
                              setDeletingId(null);
                              setStatusMessage('');
                            }}
                            className={`px-2.5 py-1.5 rounded-lg border text-[10px] font-bold transition-all cursor-pointer w-full text-center shadow-3xs ${
                              fb.status === 'resolved' 
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-700 opacity-60' 
                                : 'bg-emerald-50/50 border-emerald-100 text-emerald-900 hover:bg-emerald-100'
                            }`}
                          >
                            Mark Resolved
                          </button>
                        )}
                      </div>

                      {/* 3. Trash Block */}
                      <div className="w-full pt-1">
                        {deletingId === fb.id ? (
                          <div className="w-full p-3 bg-red-50 border border-red-200 rounded-2xl space-y-3 animate-in fade-in zoom-in-95 duration-200 shadow-xs">
                            <div className="flex items-center gap-2 text-red-600">
                              <AlertCircle className="w-3.5 h-3.5" />
                              <div className="space-y-0.5">
                                <span className="text-[10px] font-bold uppercase tracking-tight block">Confirm Deletion?</span>
                                <p className="text-[9px] text-red-500/80 font-medium leading-tight">Permanent removal of feedback log.</p>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => handleDelete(fb.id)}
                                className="flex-1 py-1.5 bg-red-600 text-white rounded-lg text-[10px] font-bold hover:bg-red-700 transition-colors cursor-pointer shadow-2xs"
                              >
                                Confirm Trash
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeletingId(null)}
                                className="px-3 py-1.5 bg-white text-slate-500 rounded-lg text-[10px] border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setDeletingId(fb.id);
                              setResolvingId(null);
                              setReviewingId(null);
                            }}
                            className="px-2.5 py-1.5 rounded-lg border border-red-100 bg-red-50/30 hover:bg-red-50 text-red-600 text-[10px] font-bold transition-all cursor-pointer w-full text-center shadow-3xs flex items-center justify-center gap-1.5"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Trash Feedback</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
};
