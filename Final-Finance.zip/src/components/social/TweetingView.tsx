import React, { useState, useEffect, useMemo, useRef } from 'react';
import { AuthSession } from '../../types/auth';
import { Tweet, TweetLinkPreview, TWEETING_MAX_CHARS } from '../../types/tweet';
import { ExternalLinkPreviewData, extractExternalUrls } from '../../utils/linkPreviewUtils';
import { StockItem } from '../../types/stocks';
import { UserPublicProfile } from '../../types/social';
import { getAllActiveMarketStocks } from '../../data/stocksData';
import { isFinalStock, formatFinalStockTagPrice, getAllFinalCoins, getStockCurrencyCode } from '../../utils/stockCurrencyFormatter';
import {
  getAllUsers,
  getFollowingList,
  getFriendsList,
  followUser,
  unfollowUser,
  areUsersBlockedEitherWay,
  isUserBlockedByTarget,
  isUserFollowing,
  areUsersFriends,
  isAdminAccount,
  isCurrentSessionAdmin
} from '../../services/socialService';
import { getCurrentSession } from '../../services/firebaseAuth';
import {
  getStoredTweets,
  createTweet,
  toggleTweetLike,
  toggleTweetRetweet,
  toggleTweetBookmark,
  voteInTweetPoll,
  addTweetReply,
  toggleTweetReplyLike,
  deleteTweet,
  extractMentions,
  extractTickers,
  formatOrdinalDay,
  formatPollTimeRemaining,
  buildSharedTweetCardData,
  resolveRootTweet,
  TWEETS_UPDATED_EVENT
} from '../../services/tweetingService';
import { readFileAsDataUrl } from '../../utils/stockMediaStorage';
import { TweetRichEmbeds } from './TweetRichEmbeds';
import { TweetingComposerModal } from '../TweetingComposerModal';
import { RetweetActionControl } from './RetweetActionControl';
import { ShareTweetModal } from './ShareTweetModal';
import { SharedTweetPreviewCard } from './SharedTweetPreviewCard';
import {
  Twitter,
  Image as ImageIcon,
  Video,
  BarChart2,
  Heart,
  Repeat2,
  MessageCircle,
  Bookmark,
  Share2,
  Search,
  CheckCircle2,
  X,
  Plus,
  Send,
  Eye,
  Trash2,
  Hash,
  AtSign,
  Flame,
  Check,
  ShieldAlert,
  ExternalLink,
  Clock,
  Users,
  ArrowLeft
} from 'lucide-react';

export interface SharedTweetFocusContext {
  tweetId: string;
  listingId?: string;
  listingTitle?: string;
  sourceTab: 'uploads' | 'user_profile' | 'messages' | 'url';
  uploadsFilterStatus?: string;
  uploadsBoughtSubSection?: 'all' | 'goods' | 'services' | 'auctions';
  uploadsMyAuctionsSubTab?: 'active' | 'done';
  profileUserId?: string;
}

export interface TweetingViewSnapshot {
  activeTab: 'for_you' | 'following' | 'trending' | 'my_tweets' | 'media' | 'polls' | 'bookmarks';
  searchQuery: string;
  searchSubTab: 'top' | 'latest' | 'people' | 'stocks' | 'media' | 'polls';
  selectedHashtag: string | null;
  selectedTicker: string | null;
  expandedThreadId: string | null;
  tweetId?: string;
  tweetViewportTop?: number;
  scrollY: number;
}

interface TweetingViewProps {
  currentUser?: AuthSession | null;
  embedded?: boolean;
  onOpenAuthModal?: () => void;
  onNavigateBack?: () => void;
  onViewUserProfile?: (user: string | { uid: string; userId: string; name: string; avatarUrl?: string }) => void;
  onSelectStock?: (stock: StockItem) => void;
  onOpenSharedListing?: (listingId: string) => void;
  restoreSnapshot?: TweetingViewSnapshot | null;
  onSaveSnapshot?: (snapshot: TweetingViewSnapshot) => void;
  onSnapshotRestored?: () => void;
  focusedTweetId?: string | null;
  focusedListingContext?: SharedTweetFocusContext | null;
  onBackToSharedPost?: () => void;
}

interface TaggablePerson {
  uid: string;
  userId: string;
  name: string;
  avatarUrl: string;
  bio?: string;
  isVerified?: boolean;
}

const DEFAULT_SEED_ACCOUNTS: TaggablePerson[] = [
  {
    uid: 'creator_alex_chen',
    userId: 'alex_chen',
    name: 'Alex Chen',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    bio: 'Quantitative System Architect & AI Research Fellow',
    isVerified: true
  },
  {
    uid: 'creator_satoshi',
    userId: 'satoshi',
    name: 'Satoshi Nakamoto',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    bio: 'Decentralized Sovereign Infrastructure',
    isVerified: true
  },
  {
    uid: 'creator_elena',
    userId: 'elena',
    name: 'Elena Rostova',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    bio: 'Zurich Gold Bullion & Vault Custody Desk',
    isVerified: true
  },
  {
    uid: 'quant_trader_mark',
    userId: 'vance_capital',
    name: 'Marcus Vance',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    bio: 'Macro Portfolio & Sovereign Equities Strategist',
    isVerified: false
  },
  {
    uid: 'user-lord_sterling',
    userId: 'sterling_vault',
    name: 'Lord Sterling',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Swiss Freeport Trustee & 1st Edition Imperial Gold Bullion Syndicate Master',
    isVerified: true
  },
  {
    uid: 'demo-alex-morgan',
    userId: 'alex_morgan',
    name: 'Alex Morgan',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Institutional Commodity Desk Arbiter & Smart Contract Auditor',
    isVerified: true
  }
];

export const TweetingView: React.FC<TweetingViewProps> = ({
  currentUser,
  embedded = false,
  onOpenAuthModal,
  onNavigateBack,
  onViewUserProfile,
  onSelectStock,
  onOpenSharedListing,
  restoreSnapshot,
  onSaveSnapshot,
  onSnapshotRestored,
  focusedTweetId,
  focusedListingContext,
  onBackToSharedPost
}) => {
  const [tweets, setTweets] = useState<Tweet[]>(() => getStoredTweets());
  const [activeTab, setActiveTab] = useState<'for_you' | 'following' | 'trending' | 'my_tweets' | 'media' | 'polls' | 'bookmarks'>(
    () => restoreSnapshot?.activeTab ?? 'for_you'
  );
  const [searchQuery, setSearchQuery] = useState(() => restoreSnapshot?.searchQuery ?? '');
  const [searchSubTab, setSearchSubTab] = useState<'top' | 'latest' | 'people' | 'stocks' | 'media' | 'polls'>(
    () => restoreSnapshot?.searchSubTab ?? 'top'
  );
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [selectedHashtag, setSelectedHashtag] = useState<string | null>(() => restoreSnapshot?.selectedHashtag ?? null);
  const [selectedTicker, setSelectedTicker] = useState<string | null>(() => restoreSnapshot?.selectedTicker ?? null);

  // Composer State
  const [tweetContent, setTweetContent] = useState('');
  const [cursorPosition, setCursorPosition] = useState<number>(0);
  const [attachedPhotos, setAttachedPhotos] = useState<string[]>([]);
  const [attachedVideo, setAttachedVideo] = useState<string | null>(null);
  const [isPollOpen, setIsPollOpen] = useState(false);
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);
  const [pollDays, setPollDays] = useState(1);
  const [pollDaysInput, setPollDaysInput] = useState('1');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [composerError, setComposerError] = useState<string | null>(null);
  const [composerLinkPreviews, setComposerLinkPreviews] = useState<Record<string, ExternalLinkPreviewData>>({});
  const [composerLinkOverrides, setComposerLinkOverrides] = useState<Record<string, Partial<ExternalLinkPreviewData>>>({});
  const [composerStockCurrencies, setComposerStockCurrencies] = useState<Record<string, string>>({});
  const [marketRefreshVersion, setMarketRefreshVersion] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const searchWrapperRef = useRef<HTMLDivElement>(null);

  const mergedComposerLinkPreviews = useMemo(() => {
    const urls = extractExternalUrls(tweetContent);
    if (urls.length === 0) return undefined;
    const out: Record<string, TweetLinkPreview> = {};
    for (const url of urls) {
      const base = composerLinkPreviews[url];
      const override = composerLinkOverrides[url];
      if (base || override) {
        out[url] = {
          ...(base || {
            url,
            domain: (() => {
              try {
                return new URL(url).hostname.replace(/^www\./, '');
              } catch {
                return 'external';
              }
            })(),
            title: url,
            description: '',
          }),
          ...(override || {}),
          url,
          resolved: Boolean(base?.resolved || override),
        };
      }
    }
    return Object.keys(out).length > 0 ? out : undefined;
  }, [tweetContent, composerLinkPreviews, composerLinkOverrides]);

  // Replying, Retweet & Share state
  const [replyingTweetId, setReplyingTweetId] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [expandedThreadId, setExpandedThreadId] = useState<string | null>(() => restoreSnapshot?.expandedThreadId ?? null);
  const [retweetingTweet, setRetweetingTweet] = useState<Tweet | null>(null);
  const [sharingTweet, setSharingTweet] = useState<Tweet | null>(null);

  const hasRestoredSnapshotRef = useRef<TweetingViewSnapshot | null>(null);
  useEffect(() => {
    if (!restoreSnapshot || hasRestoredSnapshotRef.current === restoreSnapshot) return;
    hasRestoredSnapshotRef.current = restoreSnapshot;

    setActiveTab(restoreSnapshot.activeTab);
    setSearchQuery(restoreSnapshot.searchQuery);
    setSearchSubTab(restoreSnapshot.searchSubTab);
    setSelectedHashtag(restoreSnapshot.selectedHashtag);
    setSelectedTicker(restoreSnapshot.selectedTicker);
    setExpandedThreadId(restoreSnapshot.expandedThreadId);

    const restorePosition = () => {
      if (restoreSnapshot.tweetId && typeof document !== 'undefined') {
        const el = document.querySelector(`[data-tweet-id="${restoreSnapshot.tweetId}"]`);
        if (el) {
          const rect = el.getBoundingClientRect();
          const targetViewportTop =
            typeof restoreSnapshot.tweetViewportTop === 'number'
              ? restoreSnapshot.tweetViewportTop
              : 120;
          const nextScrollY = Math.max(0, window.scrollY + rect.top - targetViewportTop);
          window.scrollTo({ top: nextScrollY, left: 0, behavior: 'instant' as ScrollBehavior });
          return;
        }
      }
      if (typeof restoreSnapshot.scrollY === 'number') {
        window.scrollTo({ top: restoreSnapshot.scrollY, left: 0, behavior: 'instant' as ScrollBehavior });
      }
    };

    const rafId = requestAnimationFrame(() => {
      restorePosition();
      setTimeout(() => {
        restorePosition();
        onSnapshotRestored?.();
      }, 60);
    });

    return () => cancelAnimationFrame(rafId);
  }, [restoreSnapshot, onSnapshotRestored]);

  // Focus & scroll directly to newly shared tweet when navigated from My Uploads & Drafts / Profile
  // (Skip resetting filters when returning via a saved snapshot)
  const lastAppliedFocusIdRef = useRef<string | null>(restoreSnapshot ? (focusedTweetId || null) : null);
  useEffect(() => {
    if (!focusedTweetId || lastAppliedFocusIdRef.current === focusedTweetId) return;
    lastAppliedFocusIdRef.current = focusedTweetId;
    setTweets(getStoredTweets());
    setActiveTab('for_you');
    setSearchQuery('');
    setSelectedHashtag(null);
    setSelectedTicker(null);
    setSearchSubTab('top');

    const scrollToFocusedTweet = () => {
      if (typeof document === 'undefined') return;
      const el = document.querySelector(`[data-tweet-id="${focusedTweetId}"]`);
      if (el) {
        el.scrollIntoView({ behavior: 'instant' as ScrollBehavior, block: 'center' });
      }
    };

    const rafId = requestAnimationFrame(() => {
      scrollToFocusedTweet();
      setTimeout(scrollToFocusedTweet, 90);
    });
    return () => cancelAnimationFrame(rafId);
  }, [focusedTweetId]);

  // Lightbox Media state
  const [lightboxMedia, setLightboxMedia] = useState<{ type: 'photo' | 'video'; url: string; title?: string } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Social users, friends & following state (single source of truth via socialService, respecting blocks)
  const [platformUsers, setPlatformUsers] = useState<UserPublicProfile[]>([]);
  const [followedHandles, setFollowedHandles] = useState<string[]>([]);
  const [friendHandles, setFriendHandles] = useState<string[]>([]);
  const [blockVersion, setBlockVersion] = useState(0);

  const currentUserId = currentUser?.uid || currentUser?.id || 'guest_user';
  const currentUserName = currentUser?.name || 'Sovereign Trader';
  const currentUserHandle = (currentUser?.handle || currentUser?.id || currentUser?.email?.split('@')[0] || 'trader').replace(/^@/, '');
  const currentUserAvatar = currentUser?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80';

  // Sync tweets from localStorage & events
  useEffect(() => {
    const handleUpdate = () => {
      setTweets(getStoredTweets());
    };
    const handleBlockUpdate = () => {
      setBlockVersion((v) => v + 1);
    };
    window.addEventListener(TWEETS_UPDATED_EVENT, handleUpdate);
    window.addEventListener('storage', handleUpdate);
    window.addEventListener('final_finance_block_updated', handleBlockUpdate);
    window.addEventListener('final_finance_friends_updated', handleBlockUpdate);
    return () => {
      window.removeEventListener(TWEETS_UPDATED_EVENT, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
      window.removeEventListener('final_finance_block_updated', handleBlockUpdate);
      window.removeEventListener('final_finance_friends_updated', handleBlockUpdate);
    };
  }, []);

  // Sync followed handles to storage for notification engine
  useEffect(() => {
    try {
      localStorage.setItem('final_finance_followed_tweet_handles', JSON.stringify(followedHandles));
    } catch {}
  }, [followedHandles]);

  // Sync friend handles to storage for notification engine
  useEffect(() => {
    try {
      localStorage.setItem('final_finance_friend_tweet_handles', JSON.stringify(friendHandles));
    } catch {}
  }, [friendHandles]);


  // Load platform users, friends & following list
  useEffect(() => {
    let active = true;
    const loadSocial = async () => {
      try {
        const [users, following, friends] = await Promise.all([
          getAllUsers(currentUserId),
          getFollowingList(currentUserId),
          getFriendsList(currentUserId)
        ]);
        if (!active) return;
        setPlatformUsers(users);
        const syncedFollowed = Array.from(
          new Set(following.map((f) => f.userId.toLowerCase().replace(/^@/, '')))
        );
        const syncedFriends = Array.from(
          new Set(friends.map((f) => f.userId.toLowerCase().replace(/^@/, '')))
        );
        setFollowedHandles(syncedFollowed);
        setFriendHandles(syncedFriends);
        try {
          localStorage.setItem('final_finance_followed_tweet_handles', JSON.stringify(syncedFollowed));
          localStorage.setItem('final_finance_friend_tweet_handles', JSON.stringify(syncedFriends));
        } catch {}
      } catch (err) {
        console.error('Failed loading users for Tweeting:', err);
      }
    };
    loadSocial();
    return () => {
      active = false;
    };
  }, [currentUserId, blockVersion]);

  // Close search dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchWrapperRef.current && !searchWrapperRef.current.contains(e.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Sync Final Coins and IPO stocks when custom coins or IPOs change
  useEffect(() => {
    const syncMarket = () => setMarketRefreshVersion((v) => v + 1);
    window.addEventListener('final_finance_custom_coins_updated', syncMarket);
    window.addEventListener('final_finance_ipo_updated', syncMarket);
    window.addEventListener('storage', syncMarket);
    return () => {
      window.removeEventListener('final_finance_custom_coins_updated', syncMarket);
      window.removeEventListener('final_finance_ipo_updated', syncMarket);
      window.removeEventListener('storage', syncMarket);
    };
  }, []);

  // Helper: check if another user is blocked in either direction (Admins see all contents)
  const isUserBlockedWithMe = (uidOrHandle?: string, handle?: string): boolean => {
    if (isAdminAccount(currentUser) || isCurrentSessionAdmin()) {
      return false;
    }
    const candidates = [uidOrHandle, handle].filter(Boolean) as string[];
    const myIds = [currentUserId, currentUserHandle].filter(Boolean);
    for (const mine of myIds) {
      for (const target of candidates) {
        if (
          areUsersBlockedEitherWay(mine, target) ||
          isUserBlockedByTarget(mine, target)
        ) {
          return true;
        }
      }
    }
    return false;
  };

  // All known taggable accounts (combining platform users + seed/tweet authors, excluding blocked & self)
  const allKnownPeople = useMemo<TaggablePerson[]>(() => {
    const map = new Map<string, TaggablePerson>();

    DEFAULT_SEED_ACCOUNTS.forEach((acc) => {
      map.set(acc.userId.toLowerCase(), acc);
    });

    platformUsers.forEach((u) => {
      const cleanHandle = u.userId.replace(/^@/, '').toLowerCase();
      map.set(cleanHandle, {
        uid: u.uid,
        userId: u.userId.replace(/^@/, ''),
        name: u.name,
        avatarUrl: u.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name)}&background=059669&color=fff`,
        bio: u.bio,
        isVerified: u.role === 'admin' || u.role === 'super_admin'
      });
    });

    tweets.forEach((t) => {
      const cleanHandle = t.authorHandle.replace(/^@/, '').toLowerCase();
      if (!map.has(cleanHandle)) {
        map.set(cleanHandle, {
          uid: t.authorId,
          userId: t.authorHandle.replace(/^@/, ''),
          name: t.authorName,
          avatarUrl: t.authorAvatar,
          isVerified: t.isVerified
        });
      }
    });

    return Array.from(map.values()).filter(
      (person) =>
        person.userId.toLowerCase() !== currentUserHandle.toLowerCase() &&
        person.uid !== currentUserId &&
        !isUserBlockedWithMe(person.uid, person.userId)
    );
  }, [platformUsers, tweets, currentUserId, currentUserHandle, blockVersion]);

  // All hashtags across tweets + defaults
  const allKnownHashtags = useMemo(() => {
    const map = new Map<string, number>();
    const defaults: Record<string, number> = {
      FinalFinance: 1840,
      AFNL: 1420,
      SovereignEquity: 980,
      GoldVaults: 850,
      Decentralized: 620,
      Bullish: 540
    };
    Object.entries(defaults).forEach(([k, v]) => map.set(k, v));

    tweets.forEach((t) => {
      t.hashtags.forEach((h) => {
        const existingKey = Array.from(map.keys()).find((k) => k.toLowerCase() === h.toLowerCase());
        const key = existingKey || h;
        map.set(key, (map.get(key) || 10) + 12);
      });
    });

    return Array.from(map.entries())
      .map(([tag, posts]) => ({ tag, posts }))
      .sort((a, b) => b.posts - a.posts);
  }, [tweets]);

  const MAX_CHARS = TWEETING_MAX_CHARS;
  const charsRemaining = MAX_CHARS - tweetContent.length;
  const isOverLimit = charsRemaining < 0;
  const isNearLimit = charsRemaining <= 20 && charsRemaining >= 0;
  const progressPct = Math.min(100, Math.round((tweetContent.length / MAX_CHARS) * 100));

  const finalStocksPool = useMemo(
    () => getAllActiveMarketStocks().filter((s) => isFinalStock(s)),
    [marketRefreshVersion]
  );

  const availableFinalCoins = useMemo(() => getAllFinalCoins(), [marketRefreshVersion]);

  const composerTaggedFinalStocks = useMemo(() => {
    const taggedTickers = extractTickers(tweetContent);
    return taggedTickers
      .map((tk) => finalStocksPool.find((s) => s.ticker.toUpperCase() === tk))
      .filter((s): s is StockItem => Boolean(s));
  }, [tweetContent, finalStocksPool]);

  // Detect active trigger token (@mention, F: final stock, #hashtag) at cursor in composer
  const activeTagToken = useMemo(() => {
    const textBeforeCursor = tweetContent.slice(0, cursorPosition);
    const match = textBeforeCursor.match(/(?:^|\s)(@|#|F:|f:|₣)([a-zA-Z0-9_-]*)$/);
    if (!match) return null;
    const rawPrefix = match[1];
    const prefix: '@' | 'F:' | '#' =
      rawPrefix === '@' ? '@' : rawPrefix === '#' ? '#' : 'F:';
    const query = match[2];
    const tokenStart = textBeforeCursor.lastIndexOf(rawPrefix);
    return { prefix, query, tokenStart };
  }, [tweetContent, cursorPosition]);

  // Blocked mentions check inside composer text
  const blockedMentionsInComposer = useMemo(() => {
    const mentions = extractMentions(tweetContent);
    return mentions.filter((handle) => {
      const clean = handle.toLowerCase();
      const matchedKnown = [...DEFAULT_SEED_ACCOUNTS, ...platformUsers.map((u) => ({ uid: u.uid, userId: u.userId }))].find(
        (u) => u.userId.replace(/^@/, '').toLowerCase() === clean
      );
      return isUserBlockedWithMe(matchedKnown?.uid, clean);
    });
  }, [tweetContent, platformUsers, currentUserId, currentUserHandle, blockVersion]);

  // Suggestions for active trigger token
  const mentionSuggestions = useMemo(() => {
    if (!activeTagToken || activeTagToken.prefix !== '@') return [];
    const q = activeTagToken.query.toLowerCase();
    return allKnownPeople
      .filter(
        (p) =>
          p.userId.toLowerCase().includes(q) ||
          p.name.toLowerCase().includes(q)
      )
      .slice(0, 6);
  }, [activeTagToken, allKnownPeople]);

  const stockSuggestions = useMemo(() => {
    if (!activeTagToken || activeTagToken.prefix !== 'F:') return [];
    const q = activeTagToken.query.toLowerCase();
    return finalStocksPool
      .filter(
        (s) =>
          s.ticker.toLowerCase().includes(q) ||
          s.name.toLowerCase().includes(q) ||
          s.sector.toLowerCase().includes(q) ||
          (s.issuanceCoinSymbol || '').toLowerCase().includes(q)
      )
      .slice(0, 6);
  }, [activeTagToken, finalStocksPool]);

  const hashtagSuggestions = useMemo(() => {
    if (!activeTagToken || activeTagToken.prefix !== '#') return [];
    const q = activeTagToken.query.toLowerCase();
    return allKnownHashtags
      .filter((h) => h.tag.toLowerCase().includes(q))
      .slice(0, 6);
  }, [activeTagToken, allKnownHashtags]);

  // Insert a selected tag cleanly replacing the active token
  const insertTagAtCursor = (prefix: '@' | 'F:' | '#', value: string) => {
    const pos = cursorPosition;
    const before = tweetContent.slice(0, pos);
    const after = tweetContent.slice(pos);

    let nextBefore = before;
    if (activeTagToken && activeTagToken.prefix === prefix) {
      nextBefore = before.slice(0, activeTagToken.tokenStart) + `${prefix}${value} `;
    } else {
      const needsSpace = before.length > 0 && !/\s$/.test(before);
      nextBefore = `${before}${needsSpace ? ' ' : ''}${prefix}${value} `;
    }

    const updated = nextBefore + after;
    setTweetContent(updated);
    const newCursor = nextBefore.length;
    setCursorPosition(newCursor);
    setComposerError(null);

    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(newCursor, newCursor);
      }
    }, 10);
  };

  // Trigger a prefix (@, F:, #) from toolbar button
  const triggerPrefixButton = (prefix: '@' | 'F:' | '#') => {
    const el = textareaRef.current;
    const pos = el ? el.selectionStart : tweetContent.length;
    const before = tweetContent.slice(0, pos);
    const after = tweetContent.slice(pos);
    const needsSpace = before.length > 0 && !/\s$/.test(before);
    const inserted = `${needsSpace ? ' ' : ''}${prefix}`;
    const nextText = before + inserted + after;
    const newCursor = before.length + inserted.length;

    setTweetContent(nextText);
    setCursorPosition(newCursor);

    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(newCursor, newCursor);
      }
    }, 10);
  };

  // Helper: synchronous single-source-of-truth checks against socialService
  const isPersonFollowed = (uidOrHandle?: string, handle?: string): boolean => {
    void blockVersion;
    const candidates = [handle, uidOrHandle].filter(Boolean) as string[];
    return candidates.some((c) => isUserFollowing(currentUserId, c));
  };

  const isPersonFriend = (uidOrHandle?: string, handle?: string): boolean => {
    void blockVersion;
    const candidates = [handle, uidOrHandle].filter(Boolean) as string[];
    return candidates.some((c) => areUsersFriends(currentUserId, c));
  };

  // Toggle Follow
  const handleToggleFollow = async (person: TaggablePerson) => {
    if (isUserBlockedWithMe(person.uid, person.userId)) return;
    const clean = person.userId.toLowerCase().replace(/^@/, '');
    const isFollowingNow = isPersonFollowed(person.uid, clean);
    if (isFollowingNow) {
      setFollowedHandles((prev) => prev.filter((h) => h !== clean));
      try {
        await unfollowUser(currentUserId, clean || person.uid);
      } catch {}
    } else {
      setFollowedHandles((prev) => Array.from(new Set([...prev, clean])));
      try {
        await followUser(currentUser || currentUserId, {
          uid: person.uid || `user-${clean}`,
          userId: clean,
        });
      } catch {}
    }
    setBlockVersion((v) => v + 1);
  };

  // File Upload Handlers
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    for (const f of files.slice(0, 4 - attachedPhotos.length)) {
      try {
        const url = await readFileAsDataUrl(f);
        setAttachedPhotos((prev) => [...prev, url].slice(0, 4));
      } catch (err) {
        console.error('Failed reading photo:', err);
      }
    }
    e.target.value = '';
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    try {
      const url = await readFileAsDataUrl(e.target.files[0]);
      setAttachedVideo(url);
    } catch (err) {
      console.error('Failed reading video:', err);
    }
    e.target.value = '';
  };

  // Submit Tweet
  const handlePostTweet = (e: React.FormEvent) => {
    e.preventDefault();
    setComposerError(null);

    if (!currentUser && onOpenAuthModal) {
      onOpenAuthModal();
      return;
    }

    if (blockedMentionsInComposer.length > 0) {
      setComposerError(
        `You cannot tag @${blockedMentionsInComposer[0]} because interactions are blocked between your accounts.`
      );
      return;
    }

    if ((!tweetContent.trim() && attachedPhotos.length === 0 && !attachedVideo && !isPollOpen) || isOverLimit) {
      return;
    }

    if (isPollOpen && pollOptions.filter((o) => o.trim().length > 0).length < 2) {
      setComposerError('Please enter at least 2 poll options or close the poll builder.');
      return;
    }

    setIsSubmitting(true);
    try {
      const clampedPollDays = Math.min(365, Math.max(1, Math.round(pollDays || 1)));
      createTweet({
        authorId: currentUserId,
        authorName: currentUserName,
        authorHandle: currentUserHandle,
        authorAvatar: currentUserAvatar,
        content: tweetContent,
        photos: attachedPhotos,
        video: attachedVideo || undefined,
        pollOptions: isPollOpen ? pollOptions : undefined,
        pollDurationDays: clampedPollDays,
        linkPreviews: mergedComposerLinkPreviews,
        stockCurrencies: composerStockCurrencies
      });

      // Reset composer
      setTweetContent('');
      setCursorPosition(0);
      setAttachedPhotos([]);
      setAttachedVideo(null);
      setIsPollOpen(false);
      setPollOptions(['', '']);
      setPollDays(1);
      setPollDaysInput('1');
      setComposerLinkPreviews({});
      setComposerLinkOverrides({});
      setComposerStockCurrencies({});
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Reply
  const handleSendReply = (tweetId: string) => {
    if (!currentUser && onOpenAuthModal) {
      onOpenAuthModal();
      return;
    }
    const cleanReply = replyContent.trim();
    if (!cleanReply || cleanReply.length > MAX_CHARS) return;

    const blockedInReply = extractMentions(cleanReply).filter((h) => isUserBlockedWithMe(undefined, h));
    if (blockedInReply.length > 0) {
      setComposerError(`Cannot mention @${blockedInReply[0]} due to account block settings.`);
      return;
    }

    addTweetReply({
      tweetId,
      authorId: currentUserId,
      authorName: currentUserName,
      authorHandle: currentUserHandle,
      authorAvatar: currentUserAvatar,
      content: cleanReply
    });

    setReplyContent('');
    setReplyingTweetId(null);
    setExpandedThreadId(tweetId);
  };

  // Handle Share Tweet (opens rich DM & link sharing sheet)
  const handleShareTweet = (t: Tweet, e: React.MouseEvent) => {
    e.stopPropagation();
    setSharingTweet(t);
  };

  // Clear all active search/tag filters
  const clearAllFilters = () => {
    setSearchQuery('');
    setSelectedHashtag(null);
    setSelectedTicker(null);
    setSearchSubTab('top');
  };

  const captureSnapshot = (tweetId?: string): TweetingViewSnapshot => {
    let tweetViewportTop: number | undefined;
    if (tweetId && typeof document !== 'undefined') {
      const el = document.querySelector(`[data-tweet-id="${tweetId}"]`);
      if (el) {
        tweetViewportTop = el.getBoundingClientRect().top;
      }
    }
    return {
      activeTab,
      searchQuery,
      searchSubTab,
      selectedHashtag,
      selectedTicker,
      expandedThreadId,
      tweetId,
      tweetViewportTop,
      scrollY: typeof window !== 'undefined' ? window.scrollY : 0,
    };
  };

  const triggerSelectStock = (stock: StockItem, tweetId?: string) => {
    if (onSaveSnapshot) {
      onSaveSnapshot(captureSnapshot(tweetId));
    }
    if (onSelectStock) {
      onSelectStock(stock);
    } else {
      window.dispatchEvent(new CustomEvent('open_shared_stock', { detail: stock.ticker }));
    }
  };

  const triggerViewUserProfile = (
    user: string | { uid: string; userId: string; name: string; avatarUrl?: string },
    tweetId?: string
  ) => {
    if (onSaveSnapshot) {
      onSaveSnapshot(captureSnapshot(tweetId));
    }
    if (onViewUserProfile) {
      onViewUserProfile(user);
    }
  };

  // Format Text with Clickable URLs, Hashtags (#), Mentions (@ respecting blocks), and Final Stock Tags (F:)
  const renderFormattedText = (text: string, tweetId?: string, stockCurrencies?: Record<string, string>) => {
    const parts = text.split(/(https?:\/\/[^\s]+|[@#][a-zA-Z0-9_]+|(?:[Ff]:|₣)[a-zA-Z][a-zA-Z0-9_-]*)/g);
    return parts.map((part, index) => {
      if (part.startsWith('http://') || part.startsWith('https://')) {
        let listingParam: string | null = null;
        let profileParam: string | null = null;
        let stockParam: string | null = null;
        try {
          const parsedUrl = new URL(part);
          listingParam = parsedUrl.searchParams.get('listing');
          profileParam = parsedUrl.searchParams.get('profile') || parsedUrl.searchParams.get('user');
          stockParam = parsedUrl.searchParams.get('stock');
        } catch {}
        if (listingParam && onOpenSharedListing) {
          return (
            <button
              key={index}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenSharedListing(listingParam!);
              }}
              className="text-amber-700 hover:text-amber-800 underline font-mono text-xs break-all cursor-pointer inline"
            >
              {part}
            </button>
          );
        }
        if (profileParam && onViewUserProfile) {
          return (
            <button
              key={index}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                triggerViewUserProfile(profileParam!, tweetId);
              }}
              className="text-sky-700 hover:text-sky-800 underline font-mono text-xs break-all cursor-pointer inline"
            >
              {part}
            </button>
          );
        }
        if (stockParam) {
          const upper = stockParam.replace(/^(?:[Ff]:|[₣$])/, '').toUpperCase();
          const stockMatch = finalStocksPool.find((s) => s.ticker.toUpperCase() === upper);
          if (stockMatch) {
            return (
              <button
                key={index}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerSelectStock(stockMatch, tweetId);
                }}
                className="text-emerald-700 hover:text-emerald-800 underline font-mono text-xs break-all cursor-pointer inline"
              >
                {part}
              </button>
            );
          }
        }
        return (
          <a
            key={index}
            href={part}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="text-sky-600 hover:text-sky-700 underline break-all inline"
          >
            {part}
          </a>
        );
      }
      if (part.startsWith('#') && part.length > 1) {
        const tag = part.slice(1);
        return (
          <button
            key={index}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedTicker(null);
              setSelectedHashtag(tag);
              setSearchQuery(`#${tag}`);
            }}
            className="text-emerald-700 hover:text-emerald-800 hover:underline font-semibold cursor-pointer inline"
          >
            {part}
          </button>
        );
      }
      if (part.startsWith('@') && part.length > 1) {
        const handle = part.slice(1);
        const blocked = isUserBlockedWithMe(undefined, handle);
        if (blocked) {
          return (
            <span
              key={index}
              title="Account interaction blocked"
              className="text-slate-400 font-normal inline cursor-not-allowed"
            >
              {part}
            </span>
          );
        }
        return (
          <button
            key={index}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (onViewUserProfile) {
                triggerViewUserProfile(handle, tweetId);
              } else {
                setSelectedHashtag(null);
                setSelectedTicker(null);
                setSearchQuery(`@${handle}`);
              }
            }}
            className="text-sky-600 hover:text-sky-700 hover:underline font-semibold cursor-pointer inline"
          >
            {part}
          </button>
        );
      }
      if (/^(?:[Ff]:|₣)[a-zA-Z][a-zA-Z0-9_-]*$/.test(part)) {
        const ticker = part.replace(/^(?:[Ff]:|₣)/, '').toUpperCase();
        const stockMatch = finalStocksPool.find((s) => s.ticker.toUpperCase() === ticker);
        if (!stockMatch) {
          return <span key={index}>{part}</span>;
        }
        const finalPriceLabel = formatFinalStockTagPrice(
          stockMatch.price,
          stockMatch,
          stockCurrencies?.[ticker]
        );
        return (
          <button
            key={index}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedHashtag(null);
              setSelectedTicker(ticker);
              setSearchQuery(`F:${ticker}`);
            }}
            title={`${stockMatch.name} (${finalPriceLabel}) — Click to filter tweets`}
            className="text-emerald-900 font-mono font-bold inline-flex items-center gap-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 px-1.5 py-0.2 rounded-md cursor-pointer transition-colors"
          >
            <span>F:{ticker}</span>
            <span className={`text-[10px] ${stockMatch.changePercent >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              {finalPriceLabel}
            </span>
          </button>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  // Search Matches: People, Final Stocks, Hashtags (for Twitter/X rich search)
  const cleanSearch = searchQuery.trim();
  const normalizedSearch = cleanSearch.toLowerCase();

  const matchingSearchPeople = useMemo(() => {
    if (!normalizedSearch) return [];
    const bare = normalizedSearch.replace(/^(?:[@#]|f:|₣|\$)/, '');
    return allKnownPeople.filter(
      (p) =>
        p.name.toLowerCase().includes(bare) ||
        p.userId.toLowerCase().includes(bare) ||
        (p.bio && p.bio.toLowerCase().includes(bare))
    );
  }, [normalizedSearch, allKnownPeople]);

  const matchingSearchStocks = useMemo(() => {
    if (!normalizedSearch) return [];
    const bare = normalizedSearch.replace(/^(?:[@#]|f:|₣|\$)/, '');
    return finalStocksPool
      .filter(
        (s) =>
          s.ticker.toLowerCase().includes(bare) ||
          s.name.toLowerCase().includes(bare) ||
          s.sector.toLowerCase().includes(bare) ||
          (s.issuanceCoinSymbol || '').toLowerCase().includes(bare)
      )
      .slice(0, 6);
  }, [normalizedSearch, finalStocksPool]);

  const matchingSearchHashtags = useMemo(() => {
    if (!normalizedSearch) return [];
    const bare = normalizedSearch.replace(/^(?:[@#]|f:|₣|\$)/, '');
    return allKnownHashtags.filter((h) => h.tag.toLowerCase().includes(bare)).slice(0, 6);
  }, [normalizedSearch, allKnownHashtags]);

  // Filtered Tweets (respecting blocks, active feed tab, and comprehensive Twitter-style search)
  const filteredTweets = useMemo(() => {
    // 1. Exclude tweets by blocked accounts
    let list = tweets.filter((t) => !isUserBlockedWithMe(t.authorId, t.authorHandle));

    // 2. If user is actively searching, apply Twitter/X search sub-tabs & deep content matching
    if (normalizedSearch) {
      const bare = normalizedSearch.replace(/^(?:[@#]|f:|₣|\$)/, '');

      list = list.filter((t) => {
        if (normalizedSearch.startsWith('#')) {
          const splitWords = bare
            .replace(/([a-z])([A-Z])/g, '$1 $2')
            .split(/[\s_]+/)
            .filter((w) => w.length >= 2);
          const lowerContent = t.content.toLowerCase();
          const hasExactHash = t.hashtags.some((h) => h.toLowerCase().includes(bare));
          const hasTextTag = lowerContent.includes(`#${bare}`) || lowerContent.includes(bare);
          const hasTickerMatch = t.tickers?.some((tk) => tk.toLowerCase().includes(bare));
          const hasCamelWords =
            splitWords.length > 1 && splitWords.every((w) => lowerContent.includes(w.toLowerCase()));
          const hasBullishSemantic =
            bare === 'bullish' &&
            (lowerContent.includes('reached') ||
              lowerContent.includes('milestone') ||
              lowerContent.includes('expansion') ||
              lowerContent.includes('growth') ||
              lowerContent.includes('🚀'));
          const hasReplyMatch = t.replies.some(
            (r) =>
              !isUserBlockedWithMe(r.authorId, r.authorHandle) &&
              (r.content.toLowerCase().includes(`#${bare}`) || r.content.toLowerCase().includes(bare))
          );
          return hasExactHash || hasTextTag || Boolean(hasTickerMatch) || hasCamelWords || hasBullishSemantic || hasReplyMatch;
        }
        if (normalizedSearch.startsWith('@')) {
          return (
            t.authorHandle.toLowerCase().includes(bare) ||
            t.mentions.some((m) => m.toLowerCase().includes(bare)) ||
            t.content.toLowerCase().includes(normalizedSearch) ||
            t.replies.some((r) => r.authorHandle.toLowerCase().includes(bare) || r.content.toLowerCase().includes(normalizedSearch))
          );
        }
        if (normalizedSearch.startsWith('f:') || normalizedSearch.startsWith('₣')) {
          return (
            (t.tickers && t.tickers.some((tk) => tk.toLowerCase().includes(bare))) ||
            t.content.toLowerCase().includes(normalizedSearch)
          );
        }

        // General search across ALL tweet content: body, author, handle, hashtags, tickers, Final stock names, poll options, and replies
        const matchingTickerNames = finalStocksPool
          .filter((s) => s.name.toLowerCase().includes(bare) || s.ticker.toLowerCase().includes(bare))
          .map((s) => s.ticker.toLowerCase());

        return (
          t.content.toLowerCase().includes(normalizedSearch) ||
          t.authorName.toLowerCase().includes(normalizedSearch) ||
          t.authorHandle.toLowerCase().includes(normalizedSearch) ||
          t.hashtags.some((h) => h.toLowerCase().includes(bare)) ||
          t.mentions.some((m) => m.toLowerCase().includes(bare)) ||
          (t.tickers && t.tickers.some((tk) => tk.toLowerCase().includes(bare) || matchingTickerNames.includes(tk.toLowerCase()))) ||
          (t.poll && t.poll.options.some((opt) => opt.text.toLowerCase().includes(normalizedSearch))) ||
          t.replies.some(
            (r) =>
              !isUserBlockedWithMe(r.authorId, r.authorHandle) &&
              (r.content.toLowerCase().includes(normalizedSearch) ||
                r.authorName.toLowerCase().includes(normalizedSearch) ||
                r.authorHandle.toLowerCase().includes(normalizedSearch))
          )
        );
      });

      if (searchSubTab === 'media') {
        list = list.filter((t) => (t.photos && t.photos.length > 0) || t.video);
      } else if (searchSubTab === 'polls') {
        list = list.filter((t) => t.poll);
      } else if (searchSubTab === 'latest') {
        list = [...list].sort((a, b) => b.createdAt - a.createdAt);
      } else {
        // 'top' default: engagement score
        list = [...list].sort((a, b) => b.likes + b.retweets * 2 - (a.likes + a.retweets * 2));
      }
      return list;
    }

    // 3. Standard Feed Tabs when not searching
    const isNetworkAuthor = (t: Tweet) => {
      return (
        isPersonFriend(t.authorId, t.authorHandle) ||
        isPersonFollowed(t.authorId, t.authorHandle) ||
        t.authorId === currentUserId
      );
    };

    if (activeTab === 'trending') {
      // Show trending tweets along with tweets from friends & people they follow
      list = [...list].sort((a, b) => {
        const scoreA = a.likes + a.retweets * 2 + a.views * 0.1 + (isNetworkAuthor(a) ? 250 : 0);
        const scoreB = b.likes + b.retweets * 2 + b.views * 0.1 + (isNetworkAuthor(b) ? 250 : 0);
        return scoreB - scoreA;
      });
    } else if (activeTab === 'following') {
      list = list.filter((t) => isNetworkAuthor(t));
    } else if (activeTab === 'my_tweets') {
      list = list.filter(
        (t) =>
          t.authorId === currentUserId ||
          t.authorHandle.toLowerCase() === currentUserHandle.toLowerCase() ||
          t.retweetedBy.includes(currentUserId)
      );
    } else if (activeTab === 'media') {
      list = list.filter((t) => (t.photos && t.photos.length > 0) || t.video);
    } else if (activeTab === 'polls') {
      list = list.filter((t) => t.poll);
    } else if (activeTab === 'bookmarks') {
      list = list.filter((t) => t.bookmarkedBy.includes(currentUserId));
    }

    return list;
  }, [tweets, activeTab, normalizedSearch, searchSubTab, followedHandles, friendHandles, currentUserId, currentUserHandle, blockVersion]);

  // User's own tweet history + extracted tags summary
  const myTweets = useMemo(() => {
    return tweets.filter(
      (t) =>
        t.authorId === currentUserId ||
        t.authorHandle.toLowerCase() === currentUserHandle.toLowerCase()
    );
  }, [tweets, currentUserId, currentUserHandle]);

  const myHistorySummary = useMemo(() => {
    const hashtags = Array.from(new Set(myTweets.flatMap((t) => t.hashtags)));
    const mentions = Array.from(new Set(myTweets.flatMap((t) => t.mentions)));
    const tickers = Array.from(new Set(myTweets.flatMap((t) => t.tickers || [])));
    const totalLikes = myTweets.reduce((sum, t) => sum + t.likes, 0);
    const totalViews = myTweets.reduce((sum, t) => sum + t.views, 0);
    return { hashtags, mentions, tickers, totalLikes, totalViews };
  }, [myTweets]);

  const activeStockObject = useMemo(() => {
    const searchTicker =
      normalizedSearch.startsWith('f:')
        ? normalizedSearch.slice(2).toUpperCase()
        : normalizedSearch.startsWith('₣')
          ? normalizedSearch.slice(1).toUpperCase()
          : null;
    const ticker = selectedTicker || searchTicker;
    if (!ticker) return null;
    return finalStocksPool.find((s) => s.ticker.toUpperCase() === ticker) || null;
  }, [selectedTicker, normalizedSearch, finalStocksPool]);

  // Trending Topics Card
  const renderTrendingCard = () => (
    <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3.5 text-center">
      <h3 className="font-serif font-bold text-sm sm:text-base text-slate-900 flex items-center justify-center gap-2">
        <Flame className="w-4 h-4 text-emerald-600" />
        <span>Trending in Sovereign Finance</span>
      </h3>

      <div className="divide-y divide-slate-100">
        {allKnownHashtags.slice(0, 6).map((item, idx) => (
          <button
            key={item.tag}
            type="button"
            onClick={() => {
              setSelectedTicker(null);
              setSelectedHashtag(item.tag);
              setSearchSubTab('top');
              setSearchQuery(`#${item.tag}`);
              setIsSearchFocused(false);
            }}
            className="w-full py-2.5 first:pt-0 last:pb-0 text-center hover:bg-emerald-50/60 px-2 rounded-xl transition-colors cursor-pointer group flex flex-col items-center justify-center"
          >
            <p className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">
              Trending Topic #{idx + 1}
            </p>
            <p className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-700 transition-colors">
              #{item.tag}
            </p>
            <p className="text-[10px] text-slate-400 font-mono mt-0.5">
              {item.posts.toLocaleString()} posts
            </p>
          </button>
        ))}
      </div>
    </div>
  );

  // My Tweet History & Tags Card (Replaces Who to Follow)
  const renderMyTweetHistoryCard = () => (
    <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3.5 text-center">
      <h3 className="font-serif font-bold text-sm sm:text-base text-slate-900 flex items-center justify-center gap-2">
        <Clock className="w-4 h-4 text-emerald-600" />
        <span>My Tweet History &amp; Tags</span>
      </h3>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="p-2 rounded-2xl bg-slate-50 border border-slate-100">
          <p className="font-mono font-bold text-xs text-slate-900">{myTweets.length}</p>
          <p className="text-[10px] text-slate-400">Tweets</p>
        </div>
        <div className="p-2 rounded-2xl bg-slate-50 border border-slate-100">
          <p className="font-mono font-bold text-xs text-rose-600">{myHistorySummary.totalLikes}</p>
          <p className="text-[10px] text-slate-400">Likes</p>
        </div>
        <div className="p-2 rounded-2xl bg-slate-50 border border-slate-100">
          <p className="font-mono font-bold text-xs text-emerald-700">{myHistorySummary.totalViews}</p>
          <p className="text-[10px] text-slate-400">Views</p>
        </div>
      </div>

      {/* Tags Created & Used by User */}
      {(myHistorySummary.hashtags.length > 0 || myHistorySummary.mentions.length > 0 || myHistorySummary.tickers.length > 0) && (
        <div className="space-y-2 pt-1 border-t border-slate-100">
          <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">
            Your Hashes &amp; Tags
          </p>
          <div className="flex flex-wrap items-center justify-center gap-1.5">
            {myHistorySummary.hashtags.map((h) => (
              <button
                key={`my-h-${h}`}
                type="button"
                onClick={() => {
                  setSelectedHashtag(h);
                  setSearchQuery(`#${h}`);
                }}
                className="px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-semibold cursor-pointer hover:bg-emerald-100"
              >
                #{h}
              </button>
            ))}
            {myHistorySummary.tickers.map((tk) => (
              <button
                key={`my-tk-${tk}`}
                type="button"
                onClick={() => {
                  setSelectedTicker(tk);
                  setSearchQuery(`F:${tk}`);
                }}
                className="px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-[10px] font-mono font-bold cursor-pointer hover:bg-amber-100"
              >
                F:{tk}
              </button>
            ))}
            {myHistorySummary.mentions.map((m) => (
              <button
                key={`my-m-${m}`}
                type="button"
                onClick={() => setSearchQuery(`@${m}`)}
                className="px-2 py-0.5 rounded-full bg-sky-50 border border-sky-200 text-sky-800 text-[10px] font-semibold cursor-pointer hover:bg-sky-100"
              >
                @{m}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Chronological History List */}
      <div className="space-y-2 pt-1 border-t border-slate-100">
        {myTweets.length === 0 ? (
          <p className="text-xs text-slate-400 py-3">
            You haven&apos;t posted any tweets yet. Post above to build your tweet history!
          </p>
        ) : (
          myTweets.slice(0, 4).map((mt) => (
            <div
              key={`hist-${mt.id}`}
              className="p-2.5 rounded-2xl bg-slate-50/80 border border-slate-100 space-y-1.5 text-center"
            >
              <p className="text-[10px] font-mono text-slate-400">{mt.timestamp}</p>
              <p className="text-xs text-slate-800 line-clamp-2 leading-relaxed">
                {mt.content || (mt.photos?.length ? 'Shared photo(s)' : mt.video ? 'Shared video' : 'Posted poll')}
              </p>
              <div className="flex flex-wrap items-center justify-center gap-1">
                {mt.hashtags.map((h) => (
                  <span key={h} className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded">
                    #{h}
                  </span>
                ))}
                {mt.tickers?.map((tk) => (
                  <span key={tk} className="text-[10px] font-mono font-bold text-amber-900 bg-amber-50 px-1.5 py-0.2 rounded">
                    F:{tk}
                  </span>
                ))}
                {mt.mentions.map((m) => (
                  <span key={m} className="text-[10px] font-semibold text-sky-700 bg-sky-50 px-1.5 py-0.2 rounded">
                    @{m}
                  </span>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {myTweets.length > 0 && (
        <button
          type="button"
          onClick={() => {
            clearAllFilters();
            setActiveTab('my_tweets');
          }}
          className="w-full py-2 rounded-xl bg-slate-900 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer transition-colors"
        >
          View Full Tweet History ({myTweets.length})
        </button>
      )}
    </div>
  );

  return (
    <div className="w-full max-w-6xl mx-auto space-y-4 pb-12 text-center">
      {/* ================= 1. CENTERED HEADER ("TWEETING / SOVEREIGN WIRE") ================= */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col items-center justify-center text-center gap-2 relative">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-green-600 text-white flex items-center justify-center shadow-md ring-4 ring-emerald-100">
          <Twitter className="w-6 h-6 -scale-x-100 -rotate-12 fill-white" />
        </div>
        <div className="flex flex-col items-center justify-center gap-1.5">
          <h2 className="font-serif font-bold text-xl sm:text-2xl text-slate-900">
            Tweeting
          </h2>
          <span className="text-[10px] uppercase font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 px-2.5 py-0.5 rounded-full">
            Sovereign Wire
          </span>
        </div>
      </div>

      {/* ================= 2. COMPOSER ================= */}
      <div className="w-full overflow-hidden p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3 text-center">
        {/* Composer Author Header */}
        <div className="flex items-center justify-center gap-2.5">
          <img
            src={currentUserAvatar}
            alt={currentUserName}
            className="w-9 h-9 rounded-full object-cover border border-slate-200 shrink-0"
          />
          <div className="text-center">
            <p className="text-xs font-bold text-slate-900 leading-tight">{currentUserName}</p>
            <p className="text-[10px] font-mono text-slate-400">@{currentUserHandle}</p>
          </div>
        </div>

        <div className="w-full min-w-0 space-y-3">
          <textarea
            ref={textareaRef}
            value={tweetContent}
            onChange={(e) => {
              setTweetContent(e.target.value);
              setCursorPosition(e.target.selectionStart || e.target.value.length);
              setComposerError(null);
            }}
            onClick={(e) => setCursorPosition((e.target as HTMLTextAreaElement).selectionStart || 0)}
            onKeyUp={(e) => setCursorPosition((e.target as HTMLTextAreaElement).selectionStart || 0)}
            placeholder="What is happening?! Use @ to tag people, F: for Final stocks, # to create hashtags..."
            rows={3}
            className="w-full box-border p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all resize-none leading-relaxed text-center"
          />

          {/* Blocked Mention Warning */}
          {blockedMentionsInComposer.length > 0 && (
            <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center justify-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
              <span>
                Cannot tag <strong>@{blockedMentionsInComposer[0]}</strong> — interactions are blocked between your accounts.
              </span>
            </div>
          )}

          {composerError && (
            <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center justify-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{composerError}</span>
            </div>
          )}

          {/* Live Autocomplete Dropdown for @People, $Stocks, and #Hashtags (In-flow so it never clips) */}
          {activeTagToken && (
            <div className="w-full p-2.5 rounded-2xl bg-slate-50 border border-emerald-200 space-y-2 text-center">
              {activeTagToken.prefix === '@' && (
                <>
                  <p className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">
                    Tag People (Blocked accounts hidden)
                  </p>
                  {mentionSuggestions.length === 0 ? (
                    <p className="text-xs text-slate-400">No matching non-blocked accounts found.</p>
                  ) : (
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      {mentionSuggestions.map((person) => (
                        <button
                          key={person.uid}
                          type="button"
                          onClick={() => insertTagAtCursor('@', person.userId)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-xs cursor-pointer transition-colors"
                        >
                          <img src={person.avatarUrl} alt={person.name} className="w-4 h-4 rounded-full object-cover" />
                          <span className="font-bold text-slate-900">{person.name}</span>
                          <span className="text-[10px] font-mono text-slate-400">@{person.userId}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}

              {activeTagToken.prefix === 'F:' && (
                <>
                  <p className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">
                    Tag Final Stocks (Final Currency)
                  </p>
                  {stockSuggestions.length === 0 ? (
                    <p className="text-xs text-slate-400">No matching Final Stocks found.</p>
                  ) : (
                    <div className="flex flex-wrap items-center justify-center gap-1.5">
                      {stockSuggestions.map((stock) => (
                        <button
                          key={stock.ticker}
                          type="button"
                          onClick={() => insertTagAtCursor('F:', stock.ticker)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-xs cursor-pointer transition-colors"
                        >
                          <span className="font-mono font-bold text-emerald-800">F:{stock.ticker}</span>
                          <span className="text-slate-600 truncate max-w-[120px]">{stock.name}</span>
                          <span className="text-[10px] font-mono text-slate-500">
                            {formatFinalStockTagPrice(stock.price, stock)}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}

              {activeTagToken.prefix === '#' && (
                <>
                  <p className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">
                    Select or Create Hashtag
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {activeTagToken.query.trim().length > 0 &&
                      !hashtagSuggestions.some(
                        (h) => h.tag.toLowerCase() === activeTagToken.query.toLowerCase()
                      ) && (
                        <button
                          type="button"
                          onClick={() => insertTagAtCursor('#', activeTagToken.query)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          <span>Create #{activeTagToken.query}</span>
                        </button>
                      )}
                    {hashtagSuggestions.map((h) => (
                      <button
                        key={h.tag}
                        type="button"
                        onClick={() => insertTagAtCursor('#', h.tag)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-xs font-semibold text-emerald-800 cursor-pointer"
                      >
                        <span>#{h.tag}</span>
                        <span className="text-[10px] font-mono text-slate-400">{h.posts}</span>
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Final Currency Picker for Tagged Final Stocks (Supports Any Final Currency, Not Just Admin Coins) */}
          {composerTaggedFinalStocks.length > 0 && availableFinalCoins.length > 0 && (
            <div className="p-2.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-2 max-w-xl mx-auto">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11px] font-bold text-amber-950 font-mono uppercase tracking-wider">
                  Final Currency for Shared Stock{composerTaggedFinalStocks.length > 1 ? 's' : ''}
                </span>
                <span className="text-[10px] text-amber-800">
                  Any Final Currency (Admin, Custom, or Community)
                </span>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {composerTaggedFinalStocks.map((stk) => {
                  const tk = stk.ticker.toUpperCase();
                  const defaultCode = getStockCurrencyCode(stk).toUpperCase();
                  const selectedCoin = composerStockCurrencies[tk] || defaultCode;
                  return (
                    <div
                      key={`comp-fc-${tk}`}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white border border-amber-200 text-xs"
                    >
                      <span className="font-mono font-bold text-emerald-900">F:{tk}</span>
                      <span className="text-slate-400">in</span>
                      <select
                        value={selectedCoin}
                        onChange={(e) =>
                          setComposerStockCurrencies((prev) => ({
                            ...prev,
                            [tk]: e.target.value,
                          }))
                        }
                        className="bg-transparent font-mono font-bold text-amber-900 text-xs focus:outline-none cursor-pointer"
                        aria-label={`Select Final Currency for ${tk}`}
                      >
                        {availableFinalCoins.map((coin) => (
                          <option key={coin.id} value={coin.symbol.toUpperCase()}>
                            F {coin.symbol.toUpperCase()} — {coin.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Live Rich Embeds Preview in Composer (Product/Service link, Final Stock, @User, External Link) */}
          <TweetRichEmbeds
            content={tweetContent}
            stockCurrencies={composerStockCurrencies}
            savedLinkPreviews={mergedComposerLinkPreviews}
            onLinkPreviewsResolved={(resolved) => {
              setComposerLinkPreviews((prev) => ({ ...prev, ...resolved }));
            }}
            editableLinks
            onEditLinkPreview={(url, override) => {
              setComposerLinkOverrides((prev) => {
                if (!override) {
                  const next = { ...prev };
                  delete next[url];
                  return next;
                }
                return { ...prev, [url]: override };
              });
            }}
            knownPeople={allKnownPeople}
            currentUserId={currentUserId}
            onOpenSharedListing={onOpenSharedListing}
            onSelectStock={(stk) => triggerSelectStock(stk)}
            onViewUserProfile={onViewUserProfile ? (u) => triggerViewUserProfile(u) : undefined}
            compact
          />

          {/* Attached Photos Previews */}
          {attachedPhotos.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {attachedPhotos.map((url, idx) => (
                <div key={idx} className="relative rounded-xl overflow-hidden border border-slate-200 h-20">
                  <img src={url} alt={`Upload ${idx + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setAttachedPhotos((prev) => prev.filter((_, i) => i !== idx))}
                    className="absolute top-1 right-1 p-1 bg-black/70 text-white rounded-full hover:bg-black cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Attached Video Preview */}
          {attachedVideo && (
            <div className="relative rounded-2xl overflow-hidden bg-black border border-slate-200 max-w-md mx-auto">
              <video src={attachedVideo} controls playsInline className="w-full max-h-48 object-contain" />
              <button
                type="button"
                onClick={() => setAttachedVideo(null)}
                className="absolute top-2 right-2 p-1.5 bg-black/80 text-white rounded-full hover:bg-black cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Poll Creator Box (Unlimited Options + Precise 1 to 365 Days Duration) */}
          {isPollOpen && (
            <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200/80 space-y-3.5 max-w-lg mx-auto text-center">
              <div className="relative flex items-center justify-center">
                <div className="flex flex-col items-center justify-center gap-1">
                  <span className="text-xs font-bold text-emerald-950 flex items-center justify-center gap-1.5 font-serif">
                    <BarChart2 className="w-4 h-4 text-emerald-600" />
                    <span>Create Community Poll</span>
                  </span>
                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                    {pollOptions.length} options
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsPollOpen(false)}
                  className="absolute right-0 top-0 text-slate-400 hover:text-slate-700 cursor-pointer p-1"
                  title="Close poll creator"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className={`space-y-2 ${pollOptions.length > 6 ? 'max-h-72 overflow-y-auto px-1' : ''}`}>
                {pollOptions.map((opt, idx) => (
                  <div key={idx} className="flex items-center justify-center gap-2 max-w-md mx-auto">
                    <span className="text-[10px] font-mono text-slate-400 w-5 text-center shrink-0">
                      {idx + 1}.
                    </span>
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const copy = [...pollOptions];
                        copy[idx] = e.target.value;
                        setPollOptions(copy);
                      }}
                      placeholder={`Option ${idx + 1}`}
                      className="flex-1 min-w-0 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-center"
                    />
                    {pollOptions.length > 2 ? (
                      <button
                        type="button"
                        onClick={() => setPollOptions((prev) => prev.filter((_, i) => i !== idx))}
                        className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer shrink-0"
                        title={`Remove Option ${idx + 1}`}
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <span className="w-5 shrink-0" aria-hidden="true" />
                    )}
                  </div>
                ))}
              </div>

              <div className="flex flex-col items-center justify-center gap-1.5 pt-0.5 text-center">
                <button
                  type="button"
                  onClick={() => setPollOptions((prev) => [...prev, ''])}
                  className="px-3 py-1.5 rounded-xl bg-white border border-emerald-200 hover:bg-emerald-50 text-xs font-bold text-emerald-700 hover:text-emerald-800 inline-flex items-center justify-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Option</span>
                </button>
                <span className="text-[10px] text-slate-400 font-mono">
                  Unlimited options supported
                </span>
              </div>

              {/* Precise Poll Length Selector: Any Day from 1st to 365th Day (1 Year) */}
              <div className="pt-3 border-t border-emerald-200/70 space-y-2.5 text-center">
                <div className="flex flex-col items-center justify-center gap-2">
                  <span className="text-[11px] font-bold text-slate-700 inline-flex items-center justify-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Poll Duration (1 day – 1 year):</span>
                  </span>
                  <div className="flex items-center justify-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={365}
                      step={1}
                      value={pollDaysInput}
                      onChange={(e) => {
                        const raw = e.target.value;
                        setPollDaysInput(raw);
                        const parsed = parseInt(raw, 10);
                        if (!isNaN(parsed)) {
                          setPollDays(Math.min(365, Math.max(1, parsed)));
                        }
                      }}
                      onBlur={() => {
                        const parsed = parseInt(pollDaysInput, 10);
                        const clamped = isNaN(parsed) ? 1 : Math.min(365, Math.max(1, parsed));
                        setPollDays(clamped);
                        setPollDaysInput(String(clamped));
                      }}
                      aria-label="Exact poll duration in days (1 to 365)"
                      className="w-16 px-2 py-1 rounded-lg bg-white border border-emerald-300 text-xs font-mono font-bold text-emerald-900 text-center focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <span className="text-[11px] font-mono font-bold text-emerald-900">
                      {formatOrdinalDay(pollDays)} day{pollDays === 365 ? ' (1 yr)' : ''}
                    </span>
                  </div>
                </div>

                <div className="max-w-md mx-auto">
                  <input
                    type="range"
                    min={1}
                    max={365}
                    value={pollDays}
                    onChange={(e) => {
                      const next = parseInt(e.target.value, 10) || 1;
                      setPollDays(next);
                      setPollDaysInput(String(next));
                    }}
                    aria-label="Slide to select poll duration between 1 and 365 days"
                    className="w-full accent-emerald-600 cursor-pointer h-1.5"
                  />
                </div>

                <div className="flex flex-col items-center justify-center gap-2">
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {[1, 7, 30, 90, 180, 250, 365].map((days) => (
                      <button
                        key={days}
                        type="button"
                        onClick={() => {
                          setPollDays(days);
                          setPollDaysInput(String(days));
                        }}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold cursor-pointer transition-colors ${
                          pollDays === days
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        {days === 365 ? '365d (1y)' : `${days}d`}
                      </button>
                    ))}
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 text-center">
                    Ends {new Date(Date.now() + pollDays * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Composer Toolbar (Responsive Wrapping - Strictly Stays Inside Box) */}
          <div className="flex flex-wrap items-center justify-center sm:justify-between gap-2.5 pt-2.5 border-t border-slate-100">
            <div className="flex flex-wrap items-center justify-center gap-1 text-emerald-700">
              {/* Add Photo */}
              <label className="p-2 rounded-xl hover:bg-emerald-50 cursor-pointer transition-colors" title="Attach Photos">
                <ImageIcon className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>

              {/* Add Video */}
              <label className="p-2 rounded-xl hover:bg-emerald-50 cursor-pointer transition-colors" title="Attach Video">
                <Video className="w-4 h-4" />
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                />
              </label>

              {/* Toggle Poll */}
              <button
                type="button"
                onClick={() => setIsPollOpen(!isPollOpen)}
                className={`p-2 rounded-xl hover:bg-emerald-50 cursor-pointer transition-colors ${
                  isPollOpen ? 'bg-emerald-100 text-emerald-900' : ''
                }`}
                title="Create Poll"
              >
                <BarChart2 className="w-4 h-4" />
              </button>

              {/* Quick Hash Tag */}
              <button
                type="button"
                onClick={() => triggerPrefixButton('#')}
                className="p-2 rounded-xl hover:bg-emerald-50 cursor-pointer transition-colors font-bold text-xs"
                title="Add / Create Hashtag (#)"
              >
                <Hash className="w-4 h-4" />
              </button>

              {/* Quick Mention */}
              <button
                type="button"
                onClick={() => triggerPrefixButton('@')}
                className="p-2 rounded-xl hover:bg-emerald-50 cursor-pointer transition-colors font-bold text-xs"
                title="Tag Person (@)"
              >
                <AtSign className="w-4 h-4" />
              </button>

              {/* Quick Final Stock Tag */}
              <button
                type="button"
                onClick={() => triggerPrefixButton('F:')}
                className="p-2 rounded-xl hover:bg-emerald-50 cursor-pointer transition-colors font-mono font-black text-sm leading-none flex items-center justify-center w-8 h-8"
                title="Tag Final Stock (F:)"
                aria-label="Tag Final Stock"
              >
                F
              </button>
            </div>

            <div className="flex items-center justify-center gap-3 shrink-0">
              {/* Character Limit Ring + Counter */}
              <div className="flex items-center gap-1.5 font-mono text-xs" title={`${charsRemaining} characters remaining`}>
                <svg className="w-5 h-5 -rotate-90" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="9" fill="none" stroke="#e2e8f0" strokeWidth="2.5" />
                  <circle
                    cx="12"
                    cy="12"
                    r="9"
                    fill="none"
                    stroke={isOverLimit ? '#e11d48' : isNearLimit ? '#d97706' : '#059669'}
                    strokeWidth="2.5"
                    strokeDasharray={56.5}
                    strokeDashoffset={56.5 - (56.5 * progressPct) / 100}
                    strokeLinecap="round"
                  />
                </svg>
                <span
                  className={`font-bold ${
                    isOverLimit
                      ? 'text-rose-600'
                      : isNearLimit
                      ? 'text-amber-600'
                      : 'text-slate-500'
                  }`}
                >
                  {charsRemaining}
                </span>
              </div>

              <button
                type="button"
                onClick={handlePostTweet}
                disabled={
                  isSubmitting ||
                  isOverLimit ||
                  blockedMentionsInComposer.length > 0 ||
                  (!tweetContent.trim() && attachedPhotos.length === 0 && !attachedVideo && !isPollOpen)
                }
                className="px-5 py-2 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Post</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================= 3. SEARCH BAR ================= */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col items-center justify-center text-center relative">
        {/* Twitter / X Full Search Bar */}
        <div ref={searchWrapperRef} className="w-full max-w-xl mx-auto relative">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onFocus={() => setIsSearchFocused(true)}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (!e.target.value) {
                  setSelectedHashtag(null);
                  setSelectedTicker(null);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  setIsSearchFocused(false);
                }
              }}
              placeholder="Search tweets, replies, @people, F:stocks, #hashtags, or polls..."
              className="w-full pl-10 pr-16 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all text-center sm:text-left"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={clearAllFilters}
                className="absolute right-3 px-2 py-0.5 rounded-lg bg-slate-200/80 hover:bg-slate-300 text-slate-700 text-[11px] font-bold cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          {/* Search Suggestions Dropdown when Focused */}
          {isSearchFocused && (
            <div className="mt-2 w-full rounded-2xl bg-white border border-slate-200 shadow-lg p-3 space-y-2.5 text-center z-30">
              {!normalizedSearch ? (
                <div className="space-y-2">
                  <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">
                    Quick Twitter / X Search
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {allKnownHashtags.slice(0, 4).map((h) => (
                      <button
                        key={h.tag}
                        type="button"
                        onClick={() => {
                          setSelectedHashtag(h.tag);
                          setSearchQuery(`#${h.tag}`);
                          setIsSearchFocused(false);
                        }}
                        className="px-2.5 py-1 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-semibold cursor-pointer"
                      >
                        #{h.tag}
                      </button>
                    ))}
                    {finalStocksPool.slice(0, 3).map((s) => (
                      <button
                        key={s.ticker}
                        type="button"
                        onClick={() => {
                          setSelectedTicker(s.ticker);
                          setSearchQuery(`F:${s.ticker}`);
                          setIsSearchFocused(false);
                        }}
                        className="px-2.5 py-1 rounded-full bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-mono font-bold cursor-pointer"
                      >
                        F:{s.ticker}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {matchingSearchPeople.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">
                        People
                      </p>
                      <div className="flex flex-wrap items-center justify-center gap-1.5">
                        {matchingSearchPeople.slice(0, 4).map((p) => (
                          <button
                            key={p.uid}
                            type="button"
                            onClick={() => {
                              setSearchQuery(`@${p.userId}`);
                              setIsSearchFocused(false);
                            }}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-50 hover:bg-emerald-50 border border-slate-200 text-xs cursor-pointer"
                          >
                            <img src={p.avatarUrl} alt={p.name} className="w-4 h-4 rounded-full object-cover" />
                            <span className="font-bold text-slate-800">{p.name}</span>
                            <span className="text-[10px] font-mono text-slate-400">@{p.userId}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {matchingSearchStocks.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">
                        Final Stocks
                      </p>
                      <div className="flex flex-wrap items-center justify-center gap-1.5">
                        {matchingSearchStocks.slice(0, 4).map((s) => (
                          <button
                            key={s.ticker}
                            type="button"
                            onClick={() => {
                              setSelectedTicker(s.ticker);
                              setSearchQuery(`F:${s.ticker}`);
                              setIsSearchFocused(false);
                            }}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-xs font-mono font-bold text-emerald-900 cursor-pointer"
                          >
                            <span>F:{s.ticker}</span>
                            <span className="text-[10px] text-slate-600 font-sans font-normal">{s.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {matchingSearchHashtags.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">
                        Hashtags
                      </p>
                      <div className="flex flex-wrap items-center justify-center gap-1.5">
                        {matchingSearchHashtags.map((h) => (
                          <button
                            key={h.tag}
                            type="button"
                            onClick={() => {
                              setSelectedHashtag(h.tag);
                              setSearchQuery(`#${h.tag}`);
                              setIsSearchFocused(false);
                            }}
                            className="px-2.5 py-1 rounded-full bg-sky-50 hover:bg-sky-100 border border-sky-200 text-xs font-semibold text-sky-800 cursor-pointer"
                          >
                            #{h.tag}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setIsSearchFocused(false)}
                    className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer pt-1"
                  >
                    Show all matching results for &ldquo;{cleanSearch}&rdquo; ({filteredTweets.length})
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ================= MAIN GRID / CENTERED COLUMN ================= */}
      <div className={embedded ? 'max-w-3xl mx-auto space-y-5' : 'grid grid-cols-1 lg:grid-cols-3 gap-5 items-start'}>
        {/* Feed & Composer Column */}
        <div className={embedded ? 'w-full min-w-0 space-y-4' : 'lg:col-span-2 w-full min-w-0 space-y-4'}>
          {/* Feed Filter Tabs OR Search Sub-Tabs */}
          {normalizedSearch ? (
            <div className="p-3 rounded-3xl bg-white border border-emerald-200 shadow-2xs space-y-3 text-center">
              <div className="flex flex-wrap items-center justify-center gap-2 text-xs">
                <span className="font-bold text-slate-800">
                  Search results for <span className="text-emerald-700 font-mono">&ldquo;{cleanSearch}&rdquo;</span>
                </span>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-mono text-[11px]">
                  {filteredTweets.length} tweet{filteredTweets.length === 1 ? '' : 's'}
                </span>
                {activeStockObject && onSelectStock && (
                  <button
                    type="button"
                    onClick={() => triggerSelectStock(activeStockObject)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer"
                  >
                    <span>Open F:{activeStockObject.ticker} Stock</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={clearAllFilters}
                  className="text-rose-600 hover:text-rose-700 font-bold cursor-pointer text-[11px]"
                >
                  Clear Search
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-1">
                {[
                  { id: 'top', label: 'Top' },
                  { id: 'latest', label: 'Latest' },
                  { id: 'people', label: `People (${matchingSearchPeople.length})` },
                  { id: 'stocks', label: `Stocks (${matchingSearchStocks.length})` },
                  { id: 'media', label: 'Media' },
                  { id: 'polls', label: 'Polls' }
                ].map((sub) => (
                  <button
                    key={sub.id}
                    type="button"
                    onClick={() => setSearchSubTab(sub.id as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      searchSubTab === sub.id
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {sub.label}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-1.5 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-wrap items-center justify-center gap-1">
              {[
                { id: 'for_you', label: 'For You' },
                { id: 'following', label: 'Friends & Following' },
                { id: 'trending', label: '🔥 Trending' },
                { id: 'my_tweets', label: `📝 My Tweets (${myTweets.length})` },
                { id: 'media', label: '📷 Media' },
                { id: 'polls', label: '📊 Polls' },
                { id: 'bookmarks', label: '🔖 Saved' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-2 px-3 sm:px-3.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer text-center ${
                    activeTab === tab.id
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          )}

          {/* Search People Results Panel (when searching People or Top with matching accounts) */}
          {normalizedSearch && (searchSubTab === 'people' || (searchSubTab === 'top' && matchingSearchPeople.length > 0)) && (
            <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3 text-center">
              <p className="text-xs font-bold text-slate-900">Matching People</p>
              {matchingSearchPeople.length === 0 ? (
                <p className="text-xs text-slate-400">No matching users found (blocked accounts are hidden).</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {matchingSearchPeople.map((p) => {
                    const isFollowing = isPersonFollowed(p.uid, p.userId);
                    return (
                      <div
                        key={p.uid}
                        className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col items-center justify-center gap-2 text-center"
                      >
                        <img src={p.avatarUrl} alt={p.name} className="w-10 h-10 rounded-full object-cover border border-slate-200" />
                        <div>
                          <p className="font-bold text-xs text-slate-900 flex items-center justify-center gap-1">
                            <span>{p.name}</span>
                            {p.isVerified && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                          </p>
                          <p className="text-[11px] text-slate-400 font-mono">@{p.userId}</p>
                        </div>
                        <div className="flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleToggleFollow(p)}
                            className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer ${
                              isFollowing
                                ? 'bg-emerald-100 text-emerald-900'
                                : 'bg-slate-900 text-white hover:bg-emerald-700'
                            }`}
                          >
                            {isFollowing ? 'Following' : 'Follow'}
                          </button>
                          {onViewUserProfile && (
                            <button
                              type="button"
                              onClick={() => triggerViewUserProfile(p.userId)}
                              className="px-3 py-1 rounded-full bg-white border border-slate-200 text-[11px] font-semibold text-slate-700 hover:border-emerald-300 cursor-pointer"
                            >
                              Profile
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Search Stocks Results Panel (when searching Stocks or Top with matching stocks) */}
          {normalizedSearch && (searchSubTab === 'stocks' || (searchSubTab === 'top' && matchingSearchStocks.length > 0)) && (
            <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3 text-center">
              <p className="text-xs font-bold text-slate-900">Matching Final Stocks</p>
              {matchingSearchStocks.length === 0 ? (
                <p className="text-xs text-slate-400">No matching Final Stocks found.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {matchingSearchStocks.map((s) => (
                    <div
                      key={s.ticker}
                      className="p-3 rounded-2xl bg-emerald-50/50 border border-emerald-200/70 flex flex-col items-center justify-center gap-1.5 text-center"
                    >
                      <div className="flex items-center justify-center gap-2">
                        <span className="font-mono font-bold text-xs text-emerald-900 bg-emerald-100 px-2 py-0.5 rounded-md">
                          F:{s.ticker}
                        </span>
                        <span className="font-bold text-xs text-slate-900">
                          {formatFinalStockTagPrice(s.price, s)}
                        </span>
                        <span
                          className={`text-[11px] font-mono font-bold ${
                            s.changePercent >= 0 ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {s.changePercent >= 0 ? '+' : ''}
                          {s.changePercent}%
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 truncate max-w-full">{s.name}</p>
                      <div className="flex items-center justify-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedTicker(s.ticker);
                            setSearchQuery(`F:${s.ticker}`);
                            setSearchSubTab('top');
                          }}
                          className="px-2.5 py-1 rounded-full bg-white border border-slate-200 hover:border-emerald-300 text-[11px] font-bold text-slate-700 cursor-pointer"
                        >
                          Filter Tweets
                        </button>
                        {onSelectStock && (
                          <button
                            type="button"
                            onClick={() => triggerSelectStock(s)}
                            className="px-2.5 py-1 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold cursor-pointer"
                          >
                            View Stock
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= TWEETS FEED ================= */}
          {searchSubTab !== 'people' && searchSubTab !== 'stocks' && (
            <div className="space-y-3">
              {filteredTweets.length === 0 ? (
                <div className="p-10 text-center rounded-3xl bg-white border border-slate-200 text-slate-400 space-y-2">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                    <Twitter className="w-5 h-5 -scale-x-100 -rotate-12" />
                  </div>
                  <p className="text-sm font-semibold text-slate-700">No tweets match this filter.</p>
                  <p className="text-xs text-slate-400">
                    Try another search keyword, clear your filter, or post your thoughts above!
                  </p>
                  {(searchQuery || selectedHashtag || selectedTicker) && (
                    <button
                      type="button"
                      onClick={clearAllFilters}
                      className="mt-2 px-4 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-bold cursor-pointer"
                    >
                      Reset Filters
                    </button>
                  )}
                </div>
              ) : (
                filteredTweets.map((rawTweet) => {
                  const isDirectRepostCard = Boolean(rawTweet.isDirectRetweet && rawTweet.quotedTweet);
                  const t = isDirectRepostCard ? resolveRootTweet(rawTweet, tweets) : rawTweet;
                  const isLiked = t.likedBy.includes(currentUserId);
                  const isRetweeted = t.retweetedBy.includes(currentUserId);
                  const isBookmarked = t.bookmarkedBy.includes(currentUserId);
                  const isReplying = replyingTweetId === rawTweet.id;
                  const isThreadExpanded = expandedThreadId === rawTweet.id || expandedThreadId === t.id;
                  const userVotedOptionId = t.poll?.voterIds[currentUserId];
                  const isFollowingAuthor = isPersonFollowed(t.authorId, t.authorHandle);
                  const isFriendAuthor = isPersonFriend(t.authorId, t.authorHandle);
                  const visibleReplies = t.replies.filter((rep) => !isUserBlockedWithMe(rep.authorId, rep.authorHandle));
                  const isFocusedSharedTweet = Boolean(
                    focusedTweetId && (rawTweet.id === focusedTweetId || t.id === focusedTweetId)
                  );

                  return (
                    <div
                      key={rawTweet.id}
                      data-tweet-id={rawTweet.id}
                      className={`p-4 sm:p-5 rounded-3xl bg-white border shadow-2xs space-y-3.5 transition-all text-center relative overflow-visible ${
                        isFocusedSharedTweet
                          ? 'border-sky-400 ring-2 ring-sky-200'
                          : 'border-slate-200 hover:border-emerald-200'
                      }`}
                    >
                      {/* Focused Shared Post Return Bar */}
                      {isFocusedSharedTweet && onBackToSharedPost && (
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-1 border-b border-sky-100 bg-sky-50/70 -mx-4 sm:-mx-5 -mt-4 sm:-mt-5 px-4 sm:px-5 py-3 rounded-t-3xl">
                          <button
                            type="button"
                            onClick={onBackToSharedPost}
                            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white hover:bg-neutral-50 border border-sky-200 text-slate-900 text-xs font-bold shadow-2xs transition-colors cursor-pointer"
                          >
                            <ArrowLeft className="w-3.5 h-3.5 text-sky-700" />
                            <span>
                              {focusedListingContext?.sourceTab === 'user_profile'
                                ? 'Back to Post in Profile'
                                : focusedListingContext?.sourceTab === 'messages'
                                  ? 'Back to Messages'
                                  : focusedListingContext?.sourceTab === 'url'
                                    ? 'All Tweets'
                                    : 'Back to Post in My Uploads & Drafts'}
                            </span>
                          </button>
                          <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-sky-700 bg-white px-2.5 py-1 rounded-full border border-sky-200">
                            Shared Post
                          </span>
                        </div>
                      )}

                      {/* Direct Retweet Attribution Header */}
                      {isDirectRepostCard && (
                        <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-700 pb-1">
                          <Repeat2 className="w-3.5 h-3.5" />
                          <button
                            type="button"
                            onClick={() => triggerViewUserProfile(rawTweet.authorHandle, rawTweet.id)}
                            className="hover:underline cursor-pointer"
                          >
                            {rawTweet.authorId === currentUserId
                              ? 'You Retweeted'
                              : `${rawTweet.authorName} (@${rawTweet.authorHandle}) Retweeted`}
                          </button>
                        </div>
                      )}

                      {/* Own Tweet Delete Button */}
                      {rawTweet.authorId === currentUserId && (
                        <button
                          type="button"
                          onClick={() => deleteTweet(rawTweet.id)}
                          className={`absolute ${isFocusedSharedTweet && onBackToSharedPost ? 'top-16' : 'top-4'} right-4 p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer`}
                          title={isDirectRepostCard ? 'Remove Retweet' : 'Delete Tweet'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {/* Centered Author Header */}
                      <div className="flex flex-col items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            if (onViewUserProfile) {
                              triggerViewUserProfile(t.authorHandle, rawTweet.id);
                            } else {
                              setSearchQuery(`@${t.authorHandle}`);
                            }
                          }}
                          className="flex flex-col items-center gap-1.5 cursor-pointer group"
                        >
                          <img
                            src={t.authorAvatar}
                            alt={t.authorName}
                            className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                          />
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            <span className="font-bold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-700">
                              {t.authorName}
                            </span>
                            {t.isVerified && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            )}
                            <span className="text-xs text-slate-400 font-mono">
                              @{t.authorHandle}
                            </span>
                            <span className="text-slate-300">•</span>
                            <span className="text-xs text-slate-400">{t.timestamp}</span>
                          </div>
                        </button>

                        {t.authorId !== currentUserId && (
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            {isFriendAuthor && (
                              <span className="px-2 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200 text-[10px] font-bold inline-flex items-center gap-1">
                                <Users className="w-2.5 h-2.5" />
                                <span>Friend</span>
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() =>
                                handleToggleFollow({
                                  uid: t.authorId,
                                  userId: t.authorHandle,
                                  name: t.authorName,
                                  avatarUrl: t.authorAvatar
                                })
                              }
                              className={`px-3 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition-colors ${
                                isFollowingAuthor
                                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                  : 'bg-slate-100 text-slate-700 hover:bg-emerald-600 hover:text-white'
                              }`}
                            >
                              {isFollowingAuthor ? 'Following' : '+ Follow'}
                            </button>
                          </div>
                        )}
                      </div>

                      {/* Centered Content Text */}
                      {t.content && (
                        <p className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line font-sans text-center max-w-xl mx-auto">
                          {renderFormattedText(t.content, t.id, t.stockCurrencies)}
                        </p>
                      )}

                      {/* Hashtags, Cashtags & Tags Row */}
                      {(t.hashtags.length > 0 || (t.tickers && t.tickers.length > 0) || t.mentions.length > 0) && (
                        <div className="flex flex-wrap items-center justify-center gap-1.5 max-w-xl mx-auto">
                          {t.hashtags.map((h) => (
                            <button
                              key={`tag-h-${h}`}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedTicker(null);
                                setSelectedHashtag(h);
                                setSearchQuery(`#${h}`);
                              }}
                              className="px-2.5 py-0.5 rounded-full bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-[11px] font-semibold cursor-pointer transition-colors"
                            >
                              #{h}
                            </button>
                          ))}
                          {t.tickers?.map((tk) => (
                            <button
                              key={`tag-tk-${tk}`}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedHashtag(null);
                                setSelectedTicker(tk.toUpperCase());
                                setSearchQuery(`F:${tk.toUpperCase()}`);
                              }}
                              className="px-2.5 py-0.5 rounded-full bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 font-mono text-[11px] font-bold cursor-pointer transition-colors"
                            >
                              F:{tk.toUpperCase()}
                            </button>
                          ))}
                          {t.mentions.map((m) => (
                            <button
                              key={`tag-m-${m}`}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (onViewUserProfile) {
                                  triggerViewUserProfile(m, t.id);
                                } else {
                                  setSearchQuery(`@${m}`);
                                }
                              }}
                              className="px-2.5 py-0.5 rounded-full bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-700 text-[11px] font-semibold cursor-pointer transition-colors"
                            >
                              @{m}
                            </button>
                          ))}
                        </div>
                      )}

                      {/* Structured Trade Details Table (Asset & Ticker | Side | Shares | Price | Total Value) */}
                      {t.tradeReceipt && (
                        <div className="w-full max-w-xl mx-auto rounded-2xl border border-emerald-200/90 bg-gradient-to-b from-emerald-50/50 to-white p-3.5 shadow-2xs space-y-2.5 text-center">
                          <div className="flex items-center justify-between gap-2 flex-wrap border-b border-emerald-100 pb-2">
                            <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-emerald-700">
                              {t.tradeReceipt.instrumentCategory === 'derivatives' ? 'Derivatives Trade' : 'Equity Spot Trade'}
                            </span>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {t.tradeReceipt.derivativeLabel && (
                                <span className="px-2 py-0.5 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-800 text-[10px] font-bold">
                                  {t.tradeReceipt.derivativeLabel}
                                </span>
                              )}
                              {typeof t.tradeReceipt.strikePrice === 'number' && (
                                <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono text-[10px] font-bold">
                                  {t.tradeReceipt.strikePrice.toFixed(2)} Strike
                                </span>
                              )}
                              {typeof t.tradeReceipt.leverage === 'number' && (
                                <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-mono text-[10px] font-bold">
                                  {t.tradeReceipt.leverage}x Leverage
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="w-full overflow-x-auto">
                            <table className="w-full text-center border-collapse text-xs">
                              <thead>
                                <tr className="text-[10px] font-mono uppercase tracking-wider text-slate-400 border-b border-slate-100">
                                  <th className="py-1.5 px-2 text-left">Asset &amp; Ticker</th>
                                  <th className="py-1.5 px-2 text-center">Side</th>
                                  <th className="py-1.5 px-2 text-center">Shares</th>
                                  <th className="py-1.5 px-2 text-center">Price</th>
                                  <th className="py-1.5 px-2 text-right">Total Value</th>
                                </tr>
                              </thead>
                              <tbody>
                                {(() => {
                                  const upperTicker = t.tradeReceipt!.ticker.toUpperCase();
                                  const matched = getAllActiveMarketStocks().find(
                                    (s) => s.ticker.toUpperCase() === upperTicker
                                  );
                                  const isReceiptFinal = Boolean(matched && isFinalStock(matched));
                                  const tickerDisplay = isReceiptFinal
                                    ? `F:${t.tradeReceipt!.ticker}`
                                    : t.tradeReceipt!.ticker;
                                  const rawCoin = t.tradeReceipt!.coinLabel || '';
                                  const cleanedCoin = isReceiptFinal ? rawCoin.replace(/^\$/, '') : rawCoin;
                                  return (
                                    <tr>
                                      <td className="py-2 px-2 text-left">
                                        <button
                                          type="button"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            if (matched) {
                                              triggerSelectStock(matched, t.id);
                                            } else {
                                              onSaveSnapshot?.(captureSnapshot(t.id));
                                              window.dispatchEvent(
                                                new CustomEvent('open_shared_stock', { detail: upperTicker })
                                              );
                                            }
                                          }}
                                          className="text-left group cursor-pointer hover:text-emerald-700 transition-colors"
                                          title={`Open ${tickerDisplay} stock page`}
                                        >
                                          <div className="font-mono font-bold text-slate-900 group-hover:text-emerald-700 group-hover:underline">
                                            {tickerDisplay}
                                          </div>
                                          <div className="text-[11px] text-slate-500 group-hover:text-emerald-600 truncate max-w-[160px]">
                                            {t.tradeReceipt!.assetName}
                                          </div>
                                        </button>
                                      </td>
                                      <td className="py-2 px-2 text-center">
                                        <span
                                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                            t.tradeReceipt!.side === 'buy'
                                              ? 'bg-emerald-100 text-emerald-800'
                                              : 'bg-rose-100 text-rose-800'
                                          }`}
                                        >
                                          {t.tradeReceipt!.side}
                                        </span>
                                      </td>
                                      <td className="py-2 px-2 text-center font-mono font-bold text-slate-900">
                                        {Number(t.tradeReceipt!.shares.toFixed(4)).toLocaleString(undefined, { maximumFractionDigits: 4 })}
                                      </td>
                                      <td className="py-2 px-2 text-center font-mono font-bold text-slate-900 whitespace-nowrap">
                                        {isReceiptFinal ? 'F ' : ''}
                                        {t.tradeReceipt!.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {cleanedCoin}
                                      </td>
                                      <td className="py-2 px-2 text-right font-mono font-black text-slate-900 whitespace-nowrap">
                                        {isReceiptFinal ? 'F ' : ''}
                                        {t.tradeReceipt!.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {cleanedCoin}
                                      </td>
                                    </tr>
                                  );
                                })()}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}

                      {/* Rich Link & Tag Cards (Product/Service Photo+Title+Prices, Stock Logo+Ticker+Value, User Photo+Name) */}
                      <TweetRichEmbeds
                        content={t.content}
                        mentions={t.mentions}
                        tickers={t.tickers}
                        stockCurrencies={t.stockCurrencies}
                        sharedPost={t.sharedPost}
                        quotedTweet={t.quotedTweet}
                        savedLinkPreviews={t.linkPreviews}
                        knownPeople={allKnownPeople}
                        currentUserId={currentUserId}
                        onOpenSharedListing={onOpenSharedListing}
                        onSelectStock={(stk) => triggerSelectStock(stk, t.id)}
                        onViewUserProfile={onViewUserProfile ? (u) => triggerViewUserProfile(u, t.id) : undefined}
                      />

                      {/* All Photos Gallery (Full Uncropped Visibility) */}
                      {t.photos && t.photos.length > 0 && (
                        <div
                          className={`grid gap-2 rounded-2xl overflow-hidden border border-slate-100 max-w-xl mx-auto ${
                            t.photos.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                          }`}
                        >
                          {t.photos.map((pUrl, pIdx) => (
                            <div
                              key={pIdx}
                              onClick={() => setLightboxMedia({ type: 'photo', url: pUrl, title: t.content })}
                              className="relative overflow-hidden bg-slate-950 cursor-pointer group/p flex items-center justify-center"
                            >
                              <img
                                src={pUrl}
                                alt={`Photo ${pIdx + 1}`}
                                className={
                                  t.photos!.length === 1
                                    ? 'w-full max-h-[480px] object-contain group-hover/p:scale-[1.02] transition-transform duration-300'
                                    : 'w-full h-56 object-contain bg-slate-950 group-hover/p:scale-[1.02] transition-transform duration-300'
                                }
                              />
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Video Player(s) */}
                      {((t.videos && t.videos.length > 0) || t.video) && (() => {
                        const vids = t.videos && t.videos.length > 0 ? t.videos : (t.video ? [t.video] : []);
                        return (
                          <div className={`grid gap-2 max-w-xl mx-auto ${vids.length === 1 ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}>
                            {vids.map((vUrl, vIdx) => (
                              <div key={vIdx} className="rounded-2xl overflow-hidden bg-black border border-slate-200">
                                <video src={vUrl} controls playsInline preload="metadata" className="w-full max-h-[420px] object-contain" />
                              </div>
                            ))}
                          </div>
                        );
                      })()}

                      {/* Poll Widget */}
                      {t.poll && (() => {
                        const pollStatus = formatPollTimeRemaining(t.poll);
                        return (
                          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2.5 max-w-lg mx-auto">
                            <div className={`space-y-2 ${t.poll.options.length > 6 ? 'max-h-80 overflow-y-auto pr-1' : ''}`}>
                              {t.poll.options.map((opt) => {
                                const isVoted = userVotedOptionId === opt.id;
                                const pct = t.poll!.totalVotes > 0 ? Math.round((opt.votes / t.poll!.totalVotes) * 100) : 0;

                                return (
                                  <button
                                    key={opt.id}
                                    type="button"
                                    disabled={pollStatus.isEnded}
                                    onClick={() => voteInTweetPoll(t.id, opt.id, currentUserId)}
                                    className={`w-full relative overflow-hidden rounded-xl p-2.5 text-xs font-semibold flex items-center justify-between text-left transition-all border ${
                                      pollStatus.isEnded ? 'cursor-default opacity-90' : 'cursor-pointer'
                                    } ${
                                      isVoted
                                        ? 'border-emerald-500 bg-emerald-50 text-emerald-950 font-bold'
                                        : 'border-slate-200 bg-white hover:border-slate-300 text-slate-800'
                                    }`}
                                  >
                                    {userVotedOptionId || pollStatus.isEnded ? (
                                      <div
                                        className={`absolute inset-y-0 left-0 transition-all ${
                                          isVoted ? 'bg-emerald-200/50' : 'bg-slate-200/40'
                                        }`}
                                        style={{ width: `${pct}%` }}
                                      />
                                    ) : null}

                                    <span className="relative z-10 flex items-center gap-2">
                                      {isVoted && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                                      <span>{opt.text}</span>
                                    </span>

                                    {userVotedOptionId || pollStatus.isEnded ? (
                                      <span className="relative z-10 font-mono font-bold text-[11px] text-slate-600">
                                        {pct}% ({opt.votes})
                                      </span>
                                    ) : null}
                                  </button>
                                );
                              })}
                            </div>

                            <div className="flex items-center justify-between gap-2 flex-wrap text-[11px] text-slate-400 font-mono">
                              <span>{t.poll.totalVotes} total votes · {pollStatus.label}</span>
                              <span>
                                {pollStatus.isEnded
                                  ? 'Poll Closed'
                                  : userVotedOptionId
                                  ? 'Vote Recorded'
                                  : 'Click to vote'}
                              </span>
                            </div>
                          </div>
                        );
                      })()}

                      {/* Centered Action Toolbar */}
                      <div className="flex items-center justify-center gap-3 sm:gap-7 flex-wrap pt-2.5 border-t border-slate-100 text-slate-400 text-xs">
                        {/* Reply Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setReplyingTweetId(isReplying ? null : rawTweet.id);
                            setExpandedThreadId(rawTweet.id);
                          }}
                          className="flex items-center gap-1 hover:text-sky-600 transition-colors cursor-pointer group"
                          title="Reply"
                        >
                          <div className="p-1.5 rounded-full group-hover:bg-sky-50 transition-colors">
                            <MessageCircle className="w-4 h-4" />
                          </div>
                          <span className="font-mono text-[11px]">{visibleReplies.length}</span>
                        </button>

                        {/* Unified Retweet Control (1-tap Retweet or Retweet with Commentary) */}
                        <RetweetActionControl
                          tweet={t}
                          isRetweeted={isRetweeted}
                          onDirectRetweet={() => {
                            if (!currentUser && onOpenAuthModal) {
                              onOpenAuthModal();
                              return;
                            }
                            toggleTweetRetweet(t.id, currentUserId, {
                              authorName: currentUserName,
                              authorHandle: currentUserHandle,
                              authorAvatar: currentUserAvatar,
                            });
                            setTweets(getStoredTweets());
                          }}
                          onRetweetWithComment={() => {
                            if (!currentUser && onOpenAuthModal) {
                              onOpenAuthModal();
                              return;
                            }
                            setRetweetingTweet(t);
                          }}
                        />

                        {/* Like Button */}
                        <button
                          type="button"
                          onClick={() => toggleTweetLike(t.id, currentUserId)}
                          className={`flex items-center gap-1 hover:text-rose-600 transition-colors cursor-pointer group ${
                            isLiked ? 'text-rose-600 font-bold' : ''
                          }`}
                          title="Like"
                        >
                          <div className="p-1.5 rounded-full group-hover:bg-rose-50 transition-colors">
                            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                          </div>
                          <span className="font-mono text-[11px]">{t.likes}</span>
                        </button>

                        {/* Views Count */}
                        <div className="flex items-center gap-1 text-slate-400" title="Views">
                          <Eye className="w-4 h-4" />
                          <span className="font-mono text-[11px]">{t.views > 999 ? `${(t.views / 1000).toFixed(1)}K` : t.views}</span>
                        </div>

                        {/* Bookmark */}
                        <button
                          type="button"
                          onClick={() => toggleTweetBookmark(t.id, currentUserId)}
                          className={`p-1.5 rounded-full hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer ${
                            isBookmarked ? 'text-amber-600' : ''
                          }`}
                          title="Bookmark"
                        >
                          <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                        </button>

                        {/* Share with Friends / Allowed Message Recipients & Link */}
                        <button
                          type="button"
                          onClick={(e) => handleShareTweet(t, e)}
                          className="flex items-center gap-1 px-2 py-1 rounded-full hover:text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                          title="Share Tweet to Friends & Messages"
                        >
                          {copiedId === t.id ? (
                            <Check className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Share2 className="w-4 h-4" />
                          )}
                          <span className="text-[11px] font-medium hidden sm:inline">Share</span>
                        </button>
                      </div>

                      {/* Inline Reply Composer */}
                      {isReplying && (
                        <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-center gap-2 max-w-lg mx-auto">
                          <input
                            type="text"
                            maxLength={MAX_CHARS}
                            value={replyContent}
                            onChange={(e) => setReplyContent(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handleSendReply(t.id);
                              }
                            }}
                            placeholder={`Reply to @${t.authorHandle} (use @, F:, #)...`}
                            className="flex-1 min-w-[180px] px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-center"
                          />
                          <button
                            type="button"
                            onClick={() => handleSendReply(t.id)}
                            disabled={!replyContent.trim()}
                            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs cursor-pointer shadow-2xs"
                          >
                            Reply
                          </button>
                        </div>
                      )}

                      {/* Centered Replies Thread */}
                      {visibleReplies.length > 0 && (
                        <div className="pt-2.5 border-t border-slate-100 space-y-2 max-w-lg mx-auto">
                          {(!isThreadExpanded ? visibleReplies.slice(0, 1) : visibleReplies).map((rep) => {
                            const isReplyLiked = rep.likedBy.includes(currentUserId);
                            return (
                              <div
                                key={rep.id}
                                className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col items-center gap-1.5 text-xs text-center"
                              >
                                <div className="flex items-center justify-center gap-1.5 flex-wrap">
                                  <img
                                    src={rep.authorAvatar}
                                    alt={rep.authorName}
                                    className="w-5 h-5 rounded-full object-cover shrink-0"
                                  />
                                  <span className="font-bold text-slate-900">{rep.authorName}</span>
                                  <span className="text-[10px] text-slate-400 font-mono">@{rep.authorHandle}</span>
                                  <span className="text-[10px] text-slate-400">• {rep.timestamp}</span>
                                </div>
                                <p className="text-slate-700 leading-relaxed">
                                  {renderFormattedText(rep.content, t.id)}
                                </p>
                                <button
                                  type="button"
                                  onClick={() => toggleTweetReplyLike(t.id, rep.id, currentUserId)}
                                  className={`inline-flex items-center gap-1 text-[10px] font-mono cursor-pointer ${
                                    isReplyLiked ? 'text-rose-600 font-bold' : 'text-slate-400 hover:text-rose-600'
                                  }`}
                                >
                                  <Heart className={`w-3 h-3 ${isReplyLiked ? 'fill-current' : ''}`} />
                                  <span>{rep.likes}</span>
                                </button>
                              </div>
                            );
                          })}

                          {visibleReplies.length > 1 && (
                            <button
                              type="button"
                              onClick={() => setExpandedThreadId(isThreadExpanded ? null : t.id)}
                              className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer pt-1"
                            >
                              {isThreadExpanded ? 'Hide replies' : `View all ${visibleReplies.length} replies`}
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>

        {/* ================= RIGHT / BOTTOM WIDGETS: TRENDING & MY TWEET HISTORY ================= */}
        <div className={embedded ? 'grid grid-cols-1 md:grid-cols-2 gap-4 items-start' : 'space-y-4'}>
          {renderTrendingCard()}
          {renderMyTweetHistoryCard()}
        </div>
      </div>

      {/* Lightbox Preview Modal */}
      {lightboxMedia && (
        <div
          onClick={() => setLightboxMedia(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-4xl w-full bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl flex flex-col max-h-[90vh]"
          >
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <span className="font-bold text-xs text-slate-900 truncate mx-auto">{lightboxMedia.title || 'Attached Media'}</span>
              <button
                type="button"
                onClick={() => setLightboxMedia(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="bg-slate-950 flex items-center justify-center p-2 flex-1 min-h-[300px]">
              {lightboxMedia.type === 'video' ? (
                <video
                  src={lightboxMedia.url}
                  controls
                  autoPlay
                  playsInline
                  className="max-h-[75vh] w-auto max-w-full object-contain"
                />
              ) : (
                <img
                  src={lightboxMedia.url}
                  alt="Enlarged media"
                  className="max-h-[75vh] w-auto max-w-full object-contain"
                />
              )}
            </div>
          </div>
        </div>
      )}

      {retweetingTweet && (
        <TweetingComposerModal
          isOpen={Boolean(retweetingTweet)}
          onClose={() => setRetweetingTweet(null)}
          title="Retweet"
          subtitle="Add optional commentary, photos, or videos to your retweet (up to 500 chars)"
          badgeText="Retweet"
          placeholder="Add your thoughts to this retweet (optional)..."
          submitLabel="Retweet"
          currentUser={currentUser}
          previewLabel="Original Tweet"
          previewCard={<SharedTweetPreviewCard data={buildSharedTweetCardData(retweetingTweet)} compact />}
          onPost={async (payload) => {
            const currentSession = currentUser || getCurrentSession();
            const root = resolveRootTweet(retweetingTweet, tweets);
            const hasCommentaryOrMedia = Boolean(
              payload.content.trim() || payload.photos.length > 0 || payload.videos.length > 0
            );
            createTweet({
              authorId: currentSession?.uid || currentSession?.id || 'guest',
              authorName: currentSession?.name || 'Sovereign User',
              authorHandle: currentSession?.handle || currentSession?.id || 'user',
              authorAvatar: currentSession?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
              content: payload.content,
              photos: payload.photos,
              videos: payload.videos,
              quotedTweet: root,
              retweetedTweetId: root.id,
              isDirectRetweet: !hasCommentaryOrMedia,
              linkPreviews: payload.linkPreviews,
            });
            setTweets(getStoredTweets());
            setRetweetingTweet(null);
          }}
        />
      )}

      <ShareTweetModal
        tweet={sharingTweet}
        currentUser={currentUser}
        onClose={() => setSharingTweet(null)}
        onOpenAuthModal={onOpenAuthModal}
      />
    </div>
  );
};
