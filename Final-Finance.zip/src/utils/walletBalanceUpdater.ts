import { UserWalletData, FinalCoinItem } from '../types/wallet';
import { getStoredUserWallets, saveStoredUserWallets } from '../data/defaultWallets';
import { getStoredCustomCoins } from '../data/customCoinsData';
import { formatInsufficientCurrencyError } from './transactionFees';

export type WalletCurrencyCategory = 'final_coin' | 'stable_coin' | 'fiat' | 'crypto';

const BASE_FINAL_COIN_METADATA: Record<string, { name: string; utility: string }> = {
  AFNL: {
    name: 'Final Admin Coin',
    utility: 'Initial 4000 AFNL signup grant & continuous 0.1 AFNL/min (~4,000/mo) subsidy accrual.'
  },
  'FNL-GOLD': {
    name: 'Imperial Gold Bullion Coin',
    utility: 'Sovereign gold-ecosystem Final Currency used for retail, dining, and ride settlements.'
  },
  'FNL-SILVER': {
    name: 'Fine Silver Sovereign Coin',
    utility: 'Sovereign silver-ecosystem Final Currency for merchant and transport clearing.'
  },
  'FNL-SWISS': {
    name: 'Zurich Reserve Sovereign Coin',
    utility: 'Zurich Freeport commercial Final Currency for retail, hospitality, and transit.'
  },
  'FNL-TECH': {
    name: 'AI & Quantum Compute Coin',
    utility: 'Compute network Final Currency accepted across sovereign merchants.'
  },
  'FNL-ALPHA': {
    name: 'Alpha Liquid Reserve Coin',
    utility: 'Alpha Reserve Final Currency for peer, merchant, and mobility settlements.'
  },
  'FNL-PLAT': {
    name: 'Zurich Vault Platinum Sovereign',
    utility: 'Zurich Freeport Platinum Bullion Settlement Coin.'
  },
  'FNL-SILICON': {
    name: 'Zurich Electronics Sovereign Coin',
    utility: 'Zurich Freeport High-Density Electronics Settlement Coin.'
  },
  VANC: {
    name: 'Vance Sovereign Gold Final Coin',
    utility: 'Personal creator final currency.'
  },
  ASOV: {
    name: 'Aurora Sovereign Final Coin',
    utility: 'Holding of Sarah Lin issue. Rate and comment available.'
  },
  WOLF: {
    name: 'Wolf Sovereign Final Coin',
    utility: 'Holding of Jordan Belfort issue. Rate and comment available.'
  },
  STRL: {
    name: 'Sterling Bullion Final Coin',
    utility: 'Holding of Lord Sterling issue. Rate and comment available.'
  }
};

const KNOWN_STABLECOINS: Record<
  string,
  { name: string; peggedCurrency: string; yieldAPY: number; network: string; unitPriceUSD: number }
> = {
  USDC: { name: 'USD Coin (Centre Consortium)', peggedCurrency: 'USD', yieldAPY: 5.4, network: 'Polygon & Ethereum', unitPriceUSD: 1.0 },
  USDT: { name: 'Tether USD', peggedCurrency: 'USD', yieldAPY: 4.8, network: 'Ethereum & Tron', unitPriceUSD: 1.0 },
  EURC: { name: 'Euro Coin (Circle)', peggedCurrency: 'EUR', yieldAPY: 4.6, network: 'Base L2', unitPriceUSD: 1.09 },
  PAXG: { name: 'PAX Gold (LBMA Gold Backed)', peggedCurrency: '1oz Fine Gold', yieldAPY: 3.8, network: 'Ethereum Mainnet', unitPriceUSD: 2880.0 },
  GOLD_OZ: { name: 'PAX Gold (LBMA Gold Backed)', peggedCurrency: '1oz Fine Gold', yieldAPY: 3.8, network: 'Ethereum Mainnet', unitPriceUSD: 2880.0 },
  DAI: { name: 'MakerDAO DAI', peggedCurrency: 'USD', yieldAPY: 5.0, network: 'Ethereum Mainnet', unitPriceUSD: 1.0 },
  PYUSD: { name: 'PayPal USD', peggedCurrency: 'USD', yieldAPY: 4.2, network: 'Ethereum & Solana', unitPriceUSD: 1.0 },
  USDP: { name: 'Pax Dollar', peggedCurrency: 'USD', yieldAPY: 4.0, network: 'Ethereum Mainnet', unitPriceUSD: 1.0 },
  USDE: { name: 'Ethena USDe', peggedCurrency: 'USD', yieldAPY: 8.5, network: 'Ethereum Mainnet', unitPriceUSD: 1.0 },
  FDUSD: { name: 'First Digital USD', peggedCurrency: 'USD', yieldAPY: 4.1, network: 'BNB & Ethereum', unitPriceUSD: 1.0 },
  GUSD: { name: 'Gemini Dollar', peggedCurrency: 'USD', yieldAPY: 3.9, network: 'Ethereum Mainnet', unitPriceUSD: 1.0 },
  BDRS: { name: 'Bedrock Sovereign Stablecoin', peggedCurrency: 'USD', yieldAPY: 4.5, network: 'Sovereign L2', unitPriceUSD: 1.0 },
  ASVD: { name: 'Alpine Vault Dollar', peggedCurrency: 'USD', yieldAPY: 4.5, network: 'Swiss Clearing L2', unitPriceUSD: 1.0 }
};

const KNOWN_FIATS: Record<
  string,
  { name: string; symbol: string; exchangeRateToUSD: number; accountType: string; institution: string }
> = {
  USD: { name: 'United States Dollar (Treasury Reserve)', symbol: '$', exchangeRateToUSD: 1.0, accountType: 'Prime Checking & Fedwire', institution: 'JPMorgan Chase N.A. (NY)' },
  CHF: { name: 'Swiss Franc (Depository Escrow)', symbol: 'CHF ', exchangeRateToUSD: 1.15, accountType: 'Institutional Escrow', institution: 'UBS Switzerland AG (Zurich)' },
  GBP: { name: 'British Pound Sterling', symbol: '£', exchangeRateToUSD: 1.3, accountType: 'Commercial Treasury', institution: 'Barclays Private Bank (London)' },
  EUR: { name: 'Euro (SEPA Clearing)', symbol: '€', exchangeRateToUSD: 1.09, accountType: 'SEPA Treasury', institution: 'Deutsche Bank AG' },
  INR: { name: 'Indian Rupee', symbol: '₹', exchangeRateToUSD: 0.0116, accountType: 'Settlement Account', institution: 'Reserve Bank Clearing Desk' },
  JPY: { name: 'Japanese Yen', symbol: '¥', exchangeRateToUSD: 0.0067, accountType: 'Settlement Account', institution: 'MUFG Clearing' },
  CNY: { name: 'Chinese Yuan Renminbi', symbol: '¥', exchangeRateToUSD: 0.138, accountType: 'CIPS Settlement Account', institution: 'PBOC Clearing Desk' },
  AED: { name: 'UAE Dirham', symbol: 'د.إ', exchangeRateToUSD: 0.272, accountType: 'UAEFTS Treasury', institution: 'Emirates NBD Clearing' },
  SGD: { name: 'Singapore Dollar', symbol: 'S$', exchangeRateToUSD: 0.75, accountType: 'MEPS+ Settlement', institution: 'DBS Institutional Bank' },
  CAD: { name: 'Canadian Dollar', symbol: 'C$', exchangeRateToUSD: 0.73, accountType: 'Settlement Account', institution: 'RBC Clearing' },
  AUD: { name: 'Australian Dollar', symbol: 'A$', exchangeRateToUSD: 0.65, accountType: 'Settlement Account', institution: 'ANZ Clearing' },
  SAR: { name: 'Saudi Riyal', symbol: '﷼', exchangeRateToUSD: 0.267, accountType: 'SARIE Clearing', institution: 'SAMA Settlement Desk' },
  BRL: { name: 'Brazilian Real', symbol: 'R$', exchangeRateToUSD: 0.171, accountType: 'PIX / STR Account', institution: 'Banco do Brasil Clearing' },
  ZAR: { name: 'South African Rand', symbol: 'R', exchangeRateToUSD: 0.055, accountType: 'SAMOS Settlement', institution: 'Standard Bank Clearing' },
  KRW: { name: 'South Korean Won', symbol: '₩', exchangeRateToUSD: 0.00072, accountType: 'BOK-Wire+ Account', institution: 'KB Kookmin Clearing' },
  MXN: { name: 'Mexican Peso', symbol: 'Mex$', exchangeRateToUSD: 0.049, accountType: 'SPEI Clearing', institution: 'Banorte Clearing' }
};

const KNOWN_CRYPTOS: Record<string, { name: string; unitPriceUSD: number; network: string }> = {
  BTC: { name: 'Bitcoin (Glacier Cold Storage)', unitPriceUSD: 94800.0, network: 'Bitcoin Mainnet (SegWit)' },
  ETH: { name: 'Ethereum (Validator Staking)', unitPriceUSD: 2820.0, network: 'Ethereum Mainnet' },
  SOL: { name: 'Solana (High Frequency Clearing)', unitPriceUSD: 195.0, network: 'Solana Network' },
  ZNTH: { name: 'Zenith Sovereign Token', unitPriceUSD: 12.5, network: 'Zenith L1' },
  XRP: { name: 'Ripple XRP', unitPriceUSD: 2.4, network: 'XRP Ledger' },
  ADA: { name: 'Cardano', unitPriceUSD: 0.85, network: 'Cardano Mainnet' },
  AVAX: { name: 'Avalanche', unitPriceUSD: 36.0, network: 'Avalanche C-Chain' },
  BNB: { name: 'BNB Chain Token', unitPriceUSD: 620.0, network: 'BNB Smart Chain' },
  TON: { name: 'Toncoin', unitPriceUSD: 5.4, network: 'TON Network' },
  SUI: { name: 'Sui', unitPriceUSD: 3.2, network: 'Sui Network' },
  DOGE: { name: 'Dogecoin', unitPriceUSD: 0.32, network: 'Dogecoin Mainnet' },
  POL: { name: 'Polygon POL', unitPriceUSD: 0.55, network: 'Polygon PoS' },
  LTC: { name: 'Litecoin', unitPriceUSD: 110.0, network: 'Litecoin Mainnet' }
};

export function normalizeWalletCurrencySymbol(symbol: string): string {
  const cleaned = (symbol || 'AFNL').trim().replace(/^\$/, '').toUpperCase();
  if (cleaned === 'GOLD_OZ') return 'PAXG';
  return cleaned || 'AFNL';
}

export function inferCurrencyCategory(symbol: string, wallet?: UserWalletData): WalletCurrencyCategory {
  const clean = normalizeWalletCurrencySymbol(symbol);

  if (wallet) {
    if ((wallet.finalCoins || []).some(c => c.symbol.trim().toUpperCase() === clean)) {
      return 'final_coin';
    }
    if ((wallet.stableCoins || []).some(s => s.symbol.trim().toUpperCase() === clean)) {
      return 'stable_coin';
    }
    if ((wallet.fiatCurrencies || []).some(f => f.code.trim().toUpperCase() === clean)) {
      return 'fiat';
    }
    if ((wallet.cryptoCurrencies || []).some(c => c.symbol.trim().toUpperCase() === clean)) {
      return 'crypto';
    }
  }

  try {
    const customCoins = getStoredCustomCoins();
    const matched = customCoins.find(c => c.symbol.trim().toUpperCase() === clean);
    if (matched) {
      return matched.coinType === 'stable_coin'
        ? 'stable_coin'
        : matched.coinType === 'crypto'
          ? 'crypto'
          : 'final_coin';
    }
  } catch {
    // Ignore storage read issues
  }

  if (KNOWN_STABLECOINS[clean]) return 'stable_coin';
  if (KNOWN_FIATS[clean]) return 'fiat';
  if (KNOWN_CRYPTOS[clean]) return 'crypto';
  return 'final_coin';
}

function roundBalance(val: number, category: WalletCurrencyCategory): number {
  if (category === 'crypto') {
    return Math.round(val * 1_000_000) / 1_000_000;
  }
  const twoDec = Math.round(val * 100) / 100;
  if (Math.abs(val - twoDec) > 0.0005) {
    return Math.round(val * 10000) / 10000;
  }
  return twoDec;
}

export function getWalletCurrencyBalance(userId: string, currencySymbol: string): number {
  const clean = normalizeWalletCurrencySymbol(currencySymbol);
  const wallet = getStoredUserWallets(userId);

  const fc = (wallet.finalCoins || []).find(c => c.symbol.trim().toUpperCase() === clean);
  if (fc) return Number(fc.balance || 0);

  const sc = (wallet.stableCoins || []).find(c => c.symbol.trim().toUpperCase() === clean);
  if (sc) return Number(sc.balance || 0);

  const fi = (wallet.fiatCurrencies || []).find(c => c.code.trim().toUpperCase() === clean);
  if (fi) return Number(fi.balance || 0);

  const cr = (wallet.cryptoCurrencies || []).find(c => c.symbol.trim().toUpperCase() === clean);
  if (cr) return Number(cr.balance || 0);

  return 0;
}

export function getFinalCoinsList(userId: string): FinalCoinItem[] {
  return getStoredUserWallets(userId).finalCoins || [];
}

export interface WalletDeltaResult {
  success: boolean;
  previousBalance: number;
  newBalance: number;
  category: WalletCurrencyCategory;
  symbol: string;
  wallet: UserWalletData;
  error?: string;
}

export function applyCurrencyWalletDelta(params: {
  userId: string;
  currencySymbol: string;
  delta: number;
  currencyName?: string;
  utilityNote?: string;
  unitPriceUSD?: number;
  requireSufficientBalance?: boolean;
  allowNegativeClamp?: boolean;
}): WalletDeltaResult {
  const {
    userId,
    currencySymbol,
    delta,
    currencyName,
    utilityNote,
    unitPriceUSD,
    requireSufficientBalance = false,
    allowNegativeClamp = true
  } = params;

  const clean = normalizeWalletCurrencySymbol(currencySymbol);
  const wallet = getStoredUserWallets(userId);
  const category = inferCurrencyCategory(clean, wallet);
  const previousBalance = getWalletCurrencyBalance(userId, clean);

  if (!Number.isFinite(delta) || delta === 0) {
    return {
      success: true,
      previousBalance,
      newBalance: previousBalance,
      category,
      symbol: clean,
      wallet
    };
  }

  if (requireSufficientBalance && delta < 0 && previousBalance + delta < -1e-6) {
    const resolvedName =
      currencyName ||
      KNOWN_FIATS[clean]?.name ||
      KNOWN_STABLECOINS[clean]?.name ||
      KNOWN_CRYPTOS[clean]?.name ||
      BASE_FINAL_COIN_METADATA[clean]?.name;
    return {
      success: false,
      previousBalance,
      newBalance: previousBalance,
      category,
      symbol: clean,
      wallet,
      error: formatInsufficientCurrencyError({
        symbol: clean,
        name: resolvedName,
        available: previousBalance,
        required: Math.abs(delta),
        maxDecimals: category === 'crypto' ? 6 : 2,
      }),
    };
  }

  const nextWallet: UserWalletData = {
    ...wallet,
    finalCoins: [...(wallet.finalCoins || [])],
    stableCoins: [...(wallet.stableCoins || [])],
    fiatCurrencies: [...(wallet.fiatCurrencies || [])],
    cryptoCurrencies: [...(wallet.cryptoCurrencies || [])]
  };

  let newBalance = previousBalance;

  if (category === 'final_coin') {
    const idx = nextWallet.finalCoins.findIndex(c => c.symbol.trim().toUpperCase() === clean);
    if (idx >= 0) {
      const rawNext = (nextWallet.finalCoins[idx].balance || 0) + delta;
      newBalance = roundBalance(allowNegativeClamp ? Math.max(0, rawNext) : rawNext, category);
      nextWallet.finalCoins[idx] = {
        ...nextWallet.finalCoins[idx],
        balance: newBalance
      };
    } else if (delta > 0) {
      let customMatch: { name?: string; description?: string } | undefined;
      try {
        customMatch = getStoredCustomCoins().find(c => c.symbol.trim().toUpperCase() === clean);
      } catch {
        customMatch = undefined;
      }
      const baseMeta = BASE_FINAL_COIN_METADATA[clean];
      newBalance = roundBalance(delta, category);
      nextWallet.finalCoins.push({
        id: `fc-${clean.toLowerCase()}-${Date.now()}`,
        name: currencyName || customMatch?.name || baseMeta?.name || `${clean} Final Coin`,
        symbol: clean,
        balance: newBalance,
        unitPriceUSD: 0,
        change24h: 0,
        utility: utilityNote || customMatch?.description || baseMeta?.utility || `Sovereign ${clean} Final Currency wallet holding.`
      });
    }
  } else if (category === 'stable_coin') {
    const idx = nextWallet.stableCoins.findIndex(c => c.symbol.trim().toUpperCase() === clean);
    if (idx >= 0) {
      const rawNext = (nextWallet.stableCoins[idx].balance || 0) + delta;
      newBalance = roundBalance(allowNegativeClamp ? Math.max(0, rawNext) : rawNext, category);
      nextWallet.stableCoins[idx] = {
        ...nextWallet.stableCoins[idx],
        balance: newBalance
      };
    } else if (delta > 0) {
      const def = KNOWN_STABLECOINS[clean];
      newBalance = roundBalance(delta, category);
      nextWallet.stableCoins.push({
        id: `sc-${clean.toLowerCase()}-${Date.now()}`,
        name: currencyName || def?.name || `${clean} Stablecoin`,
        symbol: clean,
        balance: newBalance,
        unitPriceUSD: unitPriceUSD ?? def?.unitPriceUSD ?? 1.0,
        peggedCurrency: def?.peggedCurrency || 'USD',
        yieldAPY: def?.yieldAPY ?? 0,
        network: def?.network || 'Multi-Chain'
      });
    }
  } else if (category === 'fiat') {
    const idx = nextWallet.fiatCurrencies.findIndex(c => c.code.trim().toUpperCase() === clean);
    if (idx >= 0) {
      const rawNext = (nextWallet.fiatCurrencies[idx].balance || 0) + delta;
      newBalance = roundBalance(allowNegativeClamp ? Math.max(0, rawNext) : rawNext, category);
      nextWallet.fiatCurrencies[idx] = {
        ...nextWallet.fiatCurrencies[idx],
        balance: newBalance
      };
    } else if (delta > 0) {
      const def = KNOWN_FIATS[clean];
      newBalance = roundBalance(delta, category);
      nextWallet.fiatCurrencies.push({
        id: `fi-${clean.toLowerCase()}-${Date.now()}`,
        name: currencyName || def?.name || `${clean} Account`,
        code: clean,
        symbol: def?.symbol || `${clean} `,
        balance: newBalance,
        exchangeRateToUSD: unitPriceUSD ?? def?.exchangeRateToUSD ?? 1.0,
        accountType: def?.accountType || 'Treasury Checking',
        institution: def?.institution || 'Sovereign Clearing'
      });
    }
  } else {
    const idx = nextWallet.cryptoCurrencies.findIndex(c => c.symbol.trim().toUpperCase() === clean);
    if (idx >= 0) {
      const rawNext = (nextWallet.cryptoCurrencies[idx].balance || 0) + delta;
      newBalance = roundBalance(allowNegativeClamp ? Math.max(0, rawNext) : rawNext, category);
      nextWallet.cryptoCurrencies[idx] = {
        ...nextWallet.cryptoCurrencies[idx],
        balance: newBalance
      };
    } else if (delta > 0) {
      const def = KNOWN_CRYPTOS[clean];
      newBalance = roundBalance(delta, category);
      nextWallet.cryptoCurrencies.push({
        id: `cr-${clean.toLowerCase()}-${Date.now()}`,
        name: currencyName || def?.name || `${clean} Token`,
        symbol: clean,
        balance: newBalance,
        unitPriceUSD: unitPriceUSD ?? def?.unitPriceUSD ?? 1.0,
        change24h: 0,
        network: def?.network || 'Mainnet',
        walletAddress: `0x${Date.now().toString(16)}wallet`
      });
    }
  }

  saveStoredUserWallets(userId, nextWallet);

  return {
    success: true,
    previousBalance,
    newBalance,
    category,
    symbol: clean,
    wallet: nextWallet
  };
}
