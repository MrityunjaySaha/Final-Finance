import { AuthSession } from '../types/auth';
import { UserPublicProfile, FriendRequest, RelationshipStatus } from '../types/social';

const SAMPLE_USERS: UserPublicProfile[] = [
  {
    uid: 'demo-satoshi-nakamoto',
    userId: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    email: 'satoshi@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic ledger consensus.',
    role: 'user',
    createdAt: '2024-01-03T00:00:00.000Z',
    followersCount: 12500,
    followingCount: 21,
    friendsCount: 50
  },
  {
    uid: 'demo-jordan-belfort',
    userId: 'jordan_belfort',
    name: 'Jordan Belfort',
    email: 'jordan@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Founder & Chief Reserve Allocator at Final Finance. Overseeing $4.2B in tokenized reserve vaults and barter liquidity.',
    role: 'admin',
    createdAt: '2024-01-05T00:00:00.000Z',
    followersCount: 8400,
    followingCount: 120,
    friendsCount: 75
  },
  {
    uid: 'demo-alex-morgan',
    userId: 'alex_morgan',
    name: 'Alex Morgan',
    email: 'alex@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    bio: 'Institutional Commodity Desk Arbiter. Swiss Vault & Gold Bullion Reserve specialist.',
    role: 'user',
    createdAt: '2024-01-10T00:00:00.000Z',
    followersCount: 3400,
    followingCount: 210,
    friendsCount: 92
  },
  {
    uid: 'user-gholu653',
    userId: 'gholu653',
    name: 'Gholu',
    email: 'gholu653@gmail.com',
    avatarUrl: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    bio: '',
    role: 'user',
    createdAt: '2024-01-20T00:00:00.000Z',
    followersCount: 0,
    followingCount: 0,
    friendsCount: 0
  },
  {
    uid: 'demo-super-admin',
    userId: 'super_admin_ranma',
    name: 'Ranma Sovereign Master',
    email: 'ranmaanimaker@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Super Admin & Global Escrow Overseer. Sovereign governance across all 5 reserve vaults.',
    role: 'super_admin',
    createdAt: '2024-01-01T00:00:00.000Z',
    followersCount: 1420,
    followingCount: 180,
    friendsCount: 94
  },
  {
    uid: 'demo-admin-officer',
    userId: 'officer_dbz',
    name: 'Chief Audit Officer',
    email: 'awesomedbz@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    bio: 'Custodial Auditing & Vault Verification Officer. Managing reserve asset attestations.',
    role: 'admin',
    createdAt: '2024-01-15T00:00:00.000Z',
    followersCount: 890,
    followingCount: 110,
    friendsCount: 65
  },
  {
    uid: 'user-lord_sterling',
    userId: 'sterling_vault',
    name: 'Lord Sterling',
    email: 'sterling@zurich-escrow.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'Swiss Freeport Trustee & 1st Edition Imperial Gold Bullion Syndicate Master.',
    role: 'user',
    createdAt: '2024-02-01T00:00:00.000Z',
    followersCount: 5240,
    followingCount: 310,
    friendsCount: 142
  },
  {
    uid: 'user-elena_rostova',
    userId: 'elena_rostova',
    name: 'Elena Rostova',
    email: 'elena@monaco-yachting.mc',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    bio: 'Global Maritime & Aviation Barter Broker. Swapping luxury charter deeds against Final Coins.',
    role: 'user',
    createdAt: '2024-03-01T00:00:00.000Z',
    followersCount: 3890,
    followingCount: 420,
    friendsCount: 118
  },
  {
    uid: 'user-marcus_vance',
    userId: 'marcus_vance',
    name: 'Marcus Vance',
    email: 'marcus@vance-holdings.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    bio: 'Quantitative Barter Arbitrageur & Cold-Storage Bitcoin Custodian.',
    role: 'user',
    createdAt: '2024-03-10T00:00:00.000Z',
    followersCount: 2150,
    followingCount: 280,
    friendsCount: 88
  }
];

const FOLLOWING_STORAGE_KEY = 'final_finance_following_map_v2';
const FRIENDS_STORAGE_KEY = 'final_finance_friends_map_v2';
const REQ_RECEIVED_STORAGE_KEY = 'final_finance_friend_req_rcv_v2';
const REQ_SENT_STORAGE_KEY = 'final_finance_friend_req_sent_v2';

function loadMapFromStorage(key: string, defaultInit: Record<string, string[]> = {}): Record<string, Set<string>> {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      const res: Record<string, Set<string>> = {};
      Object.entries(parsed).forEach(([uid, list]) => {
        if (Array.isArray(list)) {
          res[uid] = new Set(list);
        }
      });
      return res;
    }
  } catch (e) {
    console.warn(`Error reading map ${key}:`, e);
  }
  const res: Record<string, Set<string>> = {};
  Object.entries(defaultInit).forEach(([uid, list]) => {
    res[uid] = new Set(list);
  });
  return res;
}

function saveMapToStorage(key: string, map: Record<string, Set<string>>) {
  try {
    const serializable: Record<string, string[]> = {};
    Object.entries(map).forEach(([uid, set]) => {
      serializable[uid] = Array.from(set);
    });
    localStorage.setItem(key, JSON.stringify(serializable));
  } catch (e) {
    console.error(`Error saving map ${key}:`, e);
  }
}

function loadRequestsFromStorage(key: string): Record<string, FriendRequest[]> {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn(`Error reading requests ${key}:`, e);
  }
  return {};
}

function saveRequestsToStorage(key: string, reqs: Record<string, FriendRequest[]>) {
  try {
    localStorage.setItem(key, JSON.stringify(reqs));
  } catch (e) {
    console.error(`Error saving requests ${key}:`, e);
  }
}

let followingMap: Record<string, Set<string>> = loadMapFromStorage(FOLLOWING_STORAGE_KEY, {
  'demo-vip-alex': ['user-lord_sterling', 'user-elena_rostova']
});

let friendsMap: Record<string, Set<string>> = loadMapFromStorage(FRIENDS_STORAGE_KEY, {
  'demo-vip-alex': ['user-lord_sterling']
});

let friendRequestsReceived: Record<string, FriendRequest[]> = loadRequestsFromStorage(REQ_RECEIVED_STORAGE_KEY);
let friendRequestsSent: Record<string, FriendRequest[]> = loadRequestsFromStorage(REQ_SENT_STORAGE_KEY);

export async function getAllUsers(currentUid: string): Promise<UserPublicProfile[]> {
  const customMap = loadCustomProfiles();
  const blockedMap = loadBlockedMap();
  const blockedByMe = blockedMap[currentUid] || new Set();

  // Also collect uids who have blocked currentUid
  const blockedMe = new Set<string>();
  Object.entries(blockedMap).forEach(([uid, set]) => {
    if (set.has(currentUid)) {
      blockedMe.add(uid);
    }
  });

  return SAMPLE_USERS.filter(u => {
    if (u.uid === currentUid) return false;
    if (blockedByMe.has(u.uid) || blockedMe.has(u.uid)) return false;
    return true;
  });
}

const CUSTOM_PROFILES_STORAGE_KEY = 'final_finance_custom_profiles_map';

function loadCustomProfiles(): Record<string, UserPublicProfile> {
  try {
    const stored = localStorage.getItem(CUSTOM_PROFILES_STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.error('Error loading custom profiles:', e);
  }
  return {};
}

function saveCustomProfiles(map: Record<string, UserPublicProfile>) {
  try {
    localStorage.setItem(CUSTOM_PROFILES_STORAGE_KEY, JSON.stringify(map));
  } catch (e) {
    console.error('Error saving custom profiles:', e);
  }
}

export function getUserSocialCounts(uid: string, baseProfile?: UserPublicProfile | null): {
  followersCount: number;
  followingCount: number;
  friendsCount: number;
} {
  // Normalize uid keys
  const followingSet = followingMap[uid] || new Set();
  const friendsSet = friendsMap[uid] || new Set();

  let dynamicFollowers = 0;
  Object.entries(followingMap).forEach(([userUid, fSet]) => {
    if (userUid !== uid && fSet.has(uid)) {
      dynamicFollowers++;
    }
  });

  const isDemo = uid.startsWith('demo-') || uid.startsWith('user-lord_') || uid.startsWith('user-elena') || uid.startsWith('user-marcus');
  
  if (isDemo && baseProfile) {
    return {
      followersCount: (baseProfile.followersCount || 0) + dynamicFollowers,
      followingCount: followingSet.size > 0 ? followingSet.size : (baseProfile.followingCount || 0),
      friendsCount: friendsSet.size > 0 ? friendsSet.size : (baseProfile.friendsCount || 0),
    };
  }

  // For real user / registered user / logged-in account, show strictly the REAL count
  return {
    followersCount: dynamicFollowers,
    followingCount: followingSet.size,
    friendsCount: friendsSet.size,
  };
}

export async function updateUserPublicProfile(
  userIdOrUid: string, 
  updates: Partial<UserPublicProfile>
): Promise<UserPublicProfile> {
  const current = (await getUserProfile(userIdOrUid)) || {
    uid: `user-${userIdOrUid}`,
    userId: userIdOrUid,
    name: userIdOrUid,
    role: 'user',
    createdAt: new Date().toISOString()
  };

  const updated: UserPublicProfile = {
    ...current,
    ...updates,
  };

  const map = loadCustomProfiles();
  map[updated.uid] = updated;
  map[updated.userId.toLowerCase()] = updated;
  saveCustomProfiles(map);

  return updated;
}

export async function getUserProfile(userIdOrHandle: string): Promise<UserPublicProfile | null> {
  if (!userIdOrHandle) return null;
  const raw = userIdOrHandle.trim();
  const clean = raw.toLowerCase().replace(/^@/, '');
  const cleanNormalized = clean.replace(/[_\-\s]/g, '');

  // 1. Check in custom saved profiles
  const customMap = loadCustomProfiles();
  if (customMap[clean] || customMap[raw] || customMap[`user-${clean}`]) {
    const found = customMap[clean] || customMap[raw] || customMap[`user-${clean}`];
    const counts = getUserSocialCounts(found.uid, found);
    return { ...found, ...counts };
  }

  // 2. Check in static sample users
  let match = SAMPLE_USERS.find(u => 
    u.userId.toLowerCase() === clean || 
    u.uid.toLowerCase() === clean ||
    u.uid.toLowerCase() === raw.toLowerCase() ||
    u.name.toLowerCase() === clean ||
    u.userId.toLowerCase().replace(/[_\-\s]/g, '') === cleanNormalized ||
    u.uid.toLowerCase().replace(/[_\-\s]/g, '') === cleanNormalized
  );

  if (match) {
    const merged = { ...match, ...(customMap[match.uid] || customMap[match.userId.toLowerCase()]) };
    const counts = getUserSocialCounts(merged.uid, merged);
    return { ...merged, ...counts };
  }

  // 3. Check localStorage for dynamically registered users
  try {
    const stored = localStorage.getItem('final_finance_registered_users');
    if (stored) {
      const regMap = JSON.parse(stored);
      for (const account of Object.values<any>(regMap)) {
        if (
          account.userId?.toLowerCase() === clean ||
          account.email?.toLowerCase() === clean ||
          account.name?.toLowerCase() === clean
        ) {
          const profileUid = `user-${account.userId || clean}`;
          const counts = getUserSocialCounts(profileUid, null);
          return {
            uid: profileUid,
            userId: account.userId || clean,
            name: account.name || 'Member',
            email: account.email,
            avatarUrl: account.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(account.name || clean)}&background=0f172a&color=f8fafc&bold=true&size=128`,
            bio: '',
            role: 'user',
            createdAt: new Date().toISOString(),
            ...counts
          };
        }
      }
    }
  } catch (e) {
    console.error('Error reading registered users for profile:', e);
  }

  // 4. Fallback: synthesize profile from handle
  const formattedName = clean
    .split(/[_\-\s]+/)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

  const profileUid = `user-${clean}`;
  const counts = getUserSocialCounts(profileUid, null);

  return {
    uid: profileUid,
    userId: clean,
    name: formattedName || 'Member',
    avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(formattedName || clean)}&background=0f172a&color=f8fafc&bold=true&size=128`,
    bio: '',
    role: 'user',
    createdAt: '2024-01-01T00:00:00.000Z',
    ...counts
  };
}

export async function getFriendsList(uid: string): Promise<UserPublicProfile[]> {
  const friendUids = friendsMap[uid] || new Set();
  return SAMPLE_USERS.filter(u => friendUids.has(u.uid));
}

export async function getFollowingList(uid: string): Promise<UserPublicProfile[]> {
  const following = followingMap[uid] || new Set();
  return SAMPLE_USERS.filter(u => following.has(u.uid));
}

export async function getFollowersList(uid: string): Promise<UserPublicProfile[]> {
  const followerUids = new Set<string>();
  Object.entries(followingMap).forEach(([userUid, followingSet]) => {
    if (followingSet.has(uid)) {
      followerUids.add(userUid);
    }
  });
  return SAMPLE_USERS.filter(u => followerUids.has(u.uid));
}

export async function getFriendRequestsReceived(uid: string): Promise<FriendRequest[]> {
  return friendRequestsReceived[uid] || [];
}

export async function getFriendRequestsSent(uid: string): Promise<FriendRequest[]> {
  return friendRequestsSent[uid] || [];
}

export async function followUser(
  currentUser: AuthSession | string, 
  target: { uid: string; userId: string } | string
): Promise<void> {
  const currentUid = typeof currentUser === 'string' ? currentUser : currentUser.uid;
  const targetUid = typeof target === 'string' ? target : target.uid;
  if (!followingMap[currentUid]) {
    followingMap[currentUid] = new Set();
  }
  followingMap[currentUid].add(targetUid);
  saveMapToStorage(FOLLOWING_STORAGE_KEY, followingMap);
}

export async function unfollowUser(currentUid: string, targetUid: string): Promise<void> {
  if (followingMap[currentUid]) {
    followingMap[currentUid].delete(targetUid);
    saveMapToStorage(FOLLOWING_STORAGE_KEY, followingMap);
  }
}

export async function sendFriendRequest(
  currentUser: AuthSession | string,
  target: { uid: string; userId: string; name?: string; avatarUrl?: string } | string
): Promise<void> {
  const senderUid = typeof currentUser === 'string' ? currentUser : currentUser.uid;
  const senderHandle = typeof currentUser === 'string' ? currentUser : currentUser.id;
  const senderName = typeof currentUser === 'string' ? currentUser : currentUser.name;
  const senderAvatarUrl = typeof currentUser === 'string' ? undefined : currentUser.avatarUrl;

  const receiverUid = typeof target === 'string' ? target : target.uid;
  const receiverHandle = typeof target === 'string' ? target : target.userId;
  const receiverName = typeof target === 'string' ? target : (target.name || target.userId);
  const receiverAvatarUrl = typeof target === 'string' ? undefined : target.avatarUrl;

  const req: FriendRequest = {
    id: `${senderUid}_${receiverUid}`,
    senderUid,
    senderHandle,
    senderName,
    senderAvatarUrl,
    receiverUid,
    receiverHandle,
    receiverName,
    receiverAvatarUrl,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  if (!friendRequestsSent[senderUid]) friendRequestsSent[senderUid] = [];
  friendRequestsSent[senderUid].push(req);
  saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);

  if (!friendRequestsReceived[receiverUid]) friendRequestsReceived[receiverUid] = [];
  friendRequestsReceived[receiverUid].push(req);
  saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);

  window.dispatchEvent(new CustomEvent('ff-app-notification', {
    detail: {
      title: '🤝 New Connection Request',
      description: `${senderName || '@' + senderHandle} sent you a connection request.`,
      type: 'social',
      targetTab: 'social'
    }
  }));
}

export async function cancelFriendRequest(currentUid: string, targetUid: string): Promise<void> {
  if (friendRequestsSent[currentUid]) {
    friendRequestsSent[currentUid] = friendRequestsSent[currentUid].filter(r => r.receiverUid !== targetUid);
    saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);
  }
  if (friendRequestsReceived[targetUid]) {
    friendRequestsReceived[targetUid] = friendRequestsReceived[targetUid].filter(r => r.senderUid !== currentUid);
    saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);
  }
}

export async function acceptFriendRequest(
  currentUser: AuthSession | string,
  sender: { uid: string; userId: string; name?: string; avatarUrl?: string } | string
): Promise<void> {
  const currentUid = typeof currentUser === 'string' ? currentUser : currentUser.uid;
  const senderUid = typeof sender === 'string' ? sender : sender.uid;

  if (!friendsMap[currentUid]) friendsMap[currentUid] = new Set();
  friendsMap[currentUid].add(senderUid);

  if (!friendsMap[senderUid]) friendsMap[senderUid] = new Set();
  friendsMap[senderUid].add(currentUid);
  saveMapToStorage(FRIENDS_STORAGE_KEY, friendsMap);

  if (friendRequestsReceived[currentUid]) {
    friendRequestsReceived[currentUid] = friendRequestsReceived[currentUid].filter(r => r.senderUid !== senderUid);
    saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);
  }
  if (friendRequestsSent[senderUid]) {
    friendRequestsSent[senderUid] = friendRequestsSent[senderUid].filter(r => r.receiverUid !== currentUid);
    saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);
  }

  window.dispatchEvent(new CustomEvent('ff-app-notification', {
    detail: {
      title: '🌟 Connection Established',
      description: `Friend request accepted successfully. You are now connected in the social network.`,
      type: 'social',
      targetTab: 'social'
    }
  }));
}

export async function declineFriendRequest(currentUid: string, senderUid: string): Promise<void> {
  if (friendRequestsReceived[currentUid]) {
    friendRequestsReceived[currentUid] = friendRequestsReceived[currentUid].filter(r => r.senderUid !== senderUid);
    saveRequestsToStorage(REQ_RECEIVED_STORAGE_KEY, friendRequestsReceived);
  }
  if (friendRequestsSent[senderUid]) {
    friendRequestsSent[senderUid] = friendRequestsSent[senderUid].filter(r => r.receiverUid !== currentUid);
    saveRequestsToStorage(REQ_SENT_STORAGE_KEY, friendRequestsSent);
  }
}

export async function removeFriend(currentUid: string, targetUid: string): Promise<void> {
  if (friendsMap[currentUid]) {
    friendsMap[currentUid].delete(targetUid);
  }
  if (friendsMap[targetUid]) {
    friendsMap[targetUid].delete(currentUid);
  }
  saveMapToStorage(FRIENDS_STORAGE_KEY, friendsMap);
}

const BLOCKED_STORAGE_KEY = 'final_finance_blocked_users_map';

function loadBlockedMap(): Record<string, Set<string>> {
  try {
    const raw = localStorage.getItem(BLOCKED_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const res: Record<string, Set<string>> = {};
      Object.entries(parsed).forEach(([uid, list]) => {
        if (Array.isArray(list)) {
          res[uid] = new Set(list);
        }
      });
      return res;
    }
  } catch (e) {
    console.error('Error reading blocked map:', e);
  }
  return {};
}

function saveBlockedMap(map: Record<string, Set<string>>) {
  try {
    const serializable: Record<string, string[]> = {};
    Object.entries(map).forEach(([uid, set]) => {
      serializable[uid] = Array.from(set);
    });
    localStorage.setItem(BLOCKED_STORAGE_KEY, JSON.stringify(serializable));
  } catch (e) {
    console.error('Error saving blocked map:', e);
  }
}

let blockedMap: Record<string, Set<string>> = loadBlockedMap();

export async function blockUser(currentUid: string, targetUid: string): Promise<void> {
  if (!blockedMap[currentUid]) {
    blockedMap[currentUid] = new Set();
  }
  blockedMap[currentUid].add(targetUid);
  saveBlockedMap(blockedMap);
  // Also unfollow and unfriend if blocked
  await unfollowUser(currentUid, targetUid);
  await removeFriend(currentUid, targetUid);
}

export async function unblockUser(currentUid: string, targetUid: string): Promise<void> {
  if (blockedMap[currentUid]) {
    blockedMap[currentUid].delete(targetUid);
    saveBlockedMap(blockedMap);
  }
}

export async function isUserBlocked(currentUid: string, targetUid: string): Promise<boolean> {
  return isUserBlockedByMe(currentUid, targetUid);
}

export function isUserBlockedByMe(currentUid: string, targetUid: string): boolean {
  const map = loadBlockedMap();
  return Boolean(map[currentUid]?.has(targetUid));
}

export function isUserBlockedByTarget(currentUid: string, targetUid: string): boolean {
  const map = loadBlockedMap();
  return Boolean(map[targetUid]?.has(currentUid));
}

export function areUsersBlockedEitherWay(uid1: string, uid2: string): boolean {
  const map = loadBlockedMap();
  return Boolean(map[uid1]?.has(uid2) || map[uid2]?.has(uid1));
}

export async function getBlockedUsers(currentUid: string): Promise<UserPublicProfile[]> {
  const blockedUids = blockedMap[currentUid] || new Set<string>();
  const list: UserPublicProfile[] = [];

  for (const uid of blockedUids) {
    const profile = await getUserProfile(uid);
    if (profile) {
      list.push(profile);
    }
  }
  return list;
}

export async function getRelationshipStatus(currentUid: string, targetUid: string): Promise<RelationshipStatus> {
  const isFollowing = Boolean(followingMap[currentUid]?.has(targetUid));
  const isFollower = Boolean(followingMap[targetUid]?.has(currentUid));
  const isFriend = Boolean(friendsMap[currentUid]?.has(targetUid));

  const isBlockedByMe = isUserBlockedByMe(currentUid, targetUid);
  const isBlockedByTarget = isUserBlockedByTarget(currentUid, targetUid);
  const isBlocked = isBlockedByMe || isBlockedByTarget;

  let friendStatus: RelationshipStatus['friendStatus'] = 'none';
  if (isFriend) {
    friendStatus = 'friends';
  } else if (friendRequestsSent[currentUid]?.some(r => r.receiverUid === targetUid)) {
    friendStatus = 'pending_sent';
  } else if (friendRequestsReceived[currentUid]?.some(r => r.senderUid === targetUid)) {
    friendStatus = 'pending_received';
  }

  return {
    isFollowing,
    isFollower,
    isFriend,
    friendStatus,
    isBlocked,
    isBlockedByMe,
    isBlockedByTarget
  };
}
