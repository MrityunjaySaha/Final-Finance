import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  StockItem,
  StockOrder,
  StockPaymentSource,
  StockPosition,
  DerivativeType
} from '../../types/stocks';
import { AuthSession } from '../../types/auth';
import {
  X,
  Zap,
  AlertCircle,
  Lock,
  Coins,
  Calendar,
  Clock,
  Wallet
} from 'lucide-react';
import {
  getAvailableStockPaymentSources,
  getAllSystemSellCurrencies,
  processStockPayment,
  getStoredStockPositions
} from '../../utils/stockWalletBridge';
import { INITIAL_USER_STOCK_POSITIONS } from '../../data/stocksData';
import { useApp } from '../../context/AppContext';
import { getLocalStockMarketStatus } from '../../utils/marketHours';
import { formatStockPrice, formatStockAmount, getStockCurrencyCode, isFinalStock } from '../../utils/stockCurrencyFormatter';
import { ConfirmModal } from '../common/ConfirmModal';
import { SellCurrencyPicker } from './SellCurrencyPicker';
import { formatInsufficientCurrencyError } from '../../utils/transactionFees';

interface QuickBuyStockModalProps {
  stock: StockItem | null;
  currentUser: AuthSession | null;
  isOpen: boolean;
  initialSide?: 'buy' | 'sell';
  initialDerivativeType?: DerivativeType;
  positions?: StockPosition[];
  onClose: () => void;
  onOpenAuthModal: () => void;
  onOpenLinkBankModal?: () => void;
  onLookUpChart?: (stock: StockItem) => void;
  onExecuteBuy: (order: StockOrder) => void;
}

function getDefaultFutureSettlementDate(): string {
  const future = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  return future.toISOString().split('T')[0];
}

function getTodayDateString(): string {
  return new Date().toISOString().split('T')[0];
}

export const QuickBuyStockModal: React.FC<QuickBuyStockModalProps> = ({
  stock,
  currentUser,
  isOpen,
  initialSide = 'buy',
  initialDerivativeType = 'spot',
  positions,
  onClose,
  onOpenAuthModal,
  onExecuteBuy,
}) => {
  const { addTransaction } = useApp();
  const [tradeSide, setTradeSide] = useState<'buy' | 'sell'>(initialSide);
  const [derivativeType, setDerivativeType] = useState<DerivativeType>(initialDerivativeType);
  const [strikePriceInput, setStrikePriceInput] = useState<string>(stock?.price ? stock.price.toFixed(2) : '100');
  const [expiryDate, setExpiryDate] = useState<string>(() => getDefaultFutureSettlementDate());
  const [expiryTime, setExpiryTime] = useState<string>('16:00');
  const [leverageInput, setLeverageInput] = useState<string>('10');
  const [tradeError, setTradeError] = useState<string | null>(null);

  const [inputMode, setInputMode] = useState<'dollars' | 'shares'>('dollars');
  const [dollarAmount, setDollarAmount] = useState<string>('500');
  const [sharesAmount, setSharesAmount] = useState<string>('5');
  const [selectedSourceId, setSelectedSourceId] = useState<string>('');
  const [selectedSellCurrency, setSelectedSellCurrency] = useState<StockPaymentSource | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [sourcesVersion, setSourcesVersion] = useState(0);
  const [showConfirm, setShowConfirm] = useState(false);

  // Sync side and instrument when modal opens or stock changes
  useEffect(() => {
    if (initialSide) {
      setTradeSide(initialSide);
    }
    if (isOpen) {
      setDerivativeType(initialDerivativeType || 'spot');
      setSelectedSellCurrency(null);
      if (!expiryDate || expiryDate < getTodayDateString()) {
        setExpiryDate(getDefaultFutureSettlementDate());
      }
      if (!expiryTime) {
        setExpiryTime('16:00');
      }
    }
    if (stock && stock.price > 0) {
      setStrikePriceInput(stock.price.toFixed(2));
    }
    setTradeError(null);
  }, [isOpen, initialSide, initialDerivativeType, stock?.ticker, stock?.price]);

  useEffect(() => {
    setTradeError(null);
  }, [derivativeType, tradeSide, dollarAmount, sharesAmount, expiryDate, expiryTime, leverageInput]);

  // Load user positions
  const currentPositions = useMemo(() => {
    if (positions && positions.length > 0) return positions;
    return getStoredStockPositions(currentUser?.id || 'guest', INITIAL_USER_STOCK_POSITIONS);
  }, [positions, currentUser?.id, sourcesVersion]);

  // Check if user currently holds shares of this stock
  const userHolding = useMemo(() => {
    if (!stock) return null;
    return currentPositions.find(p => p.ticker === stock.ticker) || null;
  }, [currentPositions, stock?.ticker]);

  const userSharesOwned = userHolding?.shares || 0;
  const hasSharesToSell = userSharesOwned > 0;
  const formattedSharesOwned = useMemo(() => {
    if (!userSharesOwned) return '0';
    return Number(userSharesOwned.toFixed(2)).toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
  }, [userSharesOwned]);

  // Sync initial dollar & shares amounts whenever stock or tradeSide changes
  useEffect(() => {
    if (stock && stock.price > 0) {
      if (tradeSide === 'sell' && derivativeType === 'spot' && hasSharesToSell) {
        const defaultSellShares = Math.min(5, userSharesOwned);
        setSharesAmount(defaultSellShares.toString());
        setDollarAmount((defaultSellShares * stock.price).toFixed(2));
      } else {
        const initialDollars = 500;
        setDollarAmount(initialDollars.toString());
        setSharesAmount((initialDollars / stock.price).toFixed(2));
      }
    }
  }, [stock?.ticker, stock?.price, tradeSide, derivativeType, hasSharesToSell, userSharesOwned]);

  // Listen for storage / wallet updates
  useEffect(() => {
    const handleUpdate = () => setSourcesVersion((v) => v + 1);
    window.addEventListener('final_finance_wallets_updated', handleUpdate);
    window.addEventListener('final_finance_stocks_updated', handleUpdate);
    window.addEventListener('final_finance_custom_coins_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleUpdate);
      window.removeEventListener('final_finance_stocks_updated', handleUpdate);
      window.removeEventListener('final_finance_custom_coins_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  // Listen for Escape key to close modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isExecuting) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isExecuting, onClose]);

  // Available funding sources strictly for this stock's currency when BUYING
  const availableBuySources = useMemo(
    () => getAvailableStockPaymentSources(currentUser?.id || 'guest', undefined, stock),
    [currentUser?.id, sourcesVersion, stock]
  );

  // All system currencies (including peer-created & unowned) when SELLING
  const allSystemSellCurrencies = useMemo(
    () => getAllSystemSellCurrencies(currentUser?.id || 'guest', stock),
    [currentUser?.id, sourcesVersion, stock]
  );

  useEffect(() => {
    if (availableBuySources.length > 0 && !availableBuySources.some(s => s.id === selectedSourceId)) {
      setSelectedSourceId(availableBuySources[0].id);
    }
  }, [availableBuySources, selectedSourceId]);

  useEffect(() => {
    if (allSystemSellCurrencies.length > 0) {
      if (!selectedSellCurrency) {
        setSelectedSellCurrency(allSystemSellCurrencies[0]);
      } else {
        const refreshed = allSystemSellCurrencies.find(c => c.id === selectedSellCurrency.id);
        setSelectedSellCurrency(refreshed || allSystemSellCurrencies[0]);
      }
    }
  }, [allSystemSellCurrencies]);

  const activeBuySource: StockPaymentSource = useMemo(() => {
    if (selectedSourceId) {
      const found = availableBuySources.find(s => s.id === selectedSourceId);
      if (found) return found;
    }
    return availableBuySources[0] || {
      id: 'wallet-final-afnl',
      type: 'wallet_final' as any,
      label: stock ? `$${getStockCurrencyCode(stock)}` : '$AFNL',
      subtitle: 'Wallet Balance',
      balanceUSD: 0,
      iconType: 'crypto',
      isDefault: true,
    };
  }, [availableBuySources, selectedSourceId, stock]);

  const activeSellSource: StockPaymentSource = useMemo(() => {
    if (selectedSellCurrency) return selectedSellCurrency;
    return allSystemSellCurrencies[0] || activeBuySource;
  }, [selectedSellCurrency, allSystemSellCurrencies, activeBuySource]);

  const activeSource = tradeSide === 'buy' ? activeBuySource : activeSellSource;

  const stockPrice = Math.max(0.01, stock?.price || 1);

  const calculatedShares = inputMode === 'dollars'
    ? Number(((parseFloat(dollarAmount) || 0) / stockPrice).toFixed(4))
    : parseFloat(sharesAmount) || 0;

  const baseUSD = inputMode === 'dollars'
    ? parseFloat(dollarAmount) || 0
    : (parseFloat(sharesAmount) || 0) * stockPrice;

  const strikePrice = parseFloat(strikePriceInput) || stockPrice;
  const marketStatus = getLocalStockMarketStatus();

  const isFutures = derivativeType === 'futures_long' || derivativeType === 'futures_short';
  const isOption = derivativeType === 'call_option' || derivativeType === 'put_option';
  const isSpot = !derivativeType || derivativeType === 'spot';

  const parsedLeverage = parseFloat(leverageInput);
  const leverage = Number.isFinite(parsedLeverage) && parsedLeverage >= 1 ? Math.min(100, parsedLeverage) : 1;

  const totalUSD = useMemo(() => {
    if (derivativeType === 'call_option' || derivativeType === 'put_option') {
      return baseUSD * 0.05; // 5% option premium
    } else if (derivativeType === 'futures_long' || derivativeType === 'futures_short') {
      return baseUSD / leverage; // leveraged margin
    } else {
      return baseUSD;
    }
  }, [derivativeType, baseUSD, leverage]);

  if (!isOpen || !stock) return null;

  const stockCurrencyCode = getStockCurrencyCode(stock);
  const isFinalEquity = true;
  const availableBalance = activeBuySource?.balanceUSD ?? 0;

  const canAffordBuy = tradeSide === 'buy' ? (availableBalance >= totalUSD && totalUSD > 0 && calculatedShares > 0) : true;
  const canSellShares =
    tradeSide === 'sell' && isSpot
      ? (userSharesOwned > 0 && calculatedShares > 0 && calculatedShares <= userSharesOwned + 0.0001)
      : (totalUSD > 0 && calculatedShares > 0);
  const isMarketClosedForSpot = isSpot && !marketStatus.isOpen;
  const isValidTrade = tradeSide === 'buy' ? canAffordBuy : canSellShares;

  const sellReceiveCode = activeSellSource.currencyCode || activeSellSource.label.replace(/^\$/, '');
  const sellReceiveRate = activeSellSource.unitPriceUSD && activeSellSource.unitPriceUSD > 0 ? activeSellSource.unitPriceUSD : 1;
  const sellEstimatedUnits = totalUSD / sellReceiveRate;

  const handleToggleInputMode = (newMode: 'dollars' | 'shares') => {
    if (newMode === 'dollars') {
      const currentDollars = (parseFloat(sharesAmount) || 0) * stockPrice;
      setDollarAmount(currentDollars > 0 ? currentDollars.toFixed(2) : '500');
    } else {
      const currentShares = (parseFloat(dollarAmount) || 0) / stockPrice;
      setSharesAmount(currentShares > 0 ? currentShares.toFixed(2) : '5');
    }
    setInputMode(newMode);
  };

  const handleQuickDollarPreset = (amount: number) => {
    setInputMode('dollars');
    setDollarAmount(amount.toString());
    setSharesAmount((amount / stockPrice).toFixed(2));
  };

  const handleQuickSharesPreset = (shares: number) => {
    setInputMode('shares');
    setSharesAmount(shares.toString());
    setDollarAmount((shares * stockPrice).toFixed(2));
  };

  const handlePercentHoldingsSell = (pct: number) => {
    if (!userSharesOwned) return;
    const targetShares = Number((userSharesOwned * pct).toFixed(4));
    setInputMode('shares');
    setSharesAmount(targetShares.toString());
    setDollarAmount((targetShares * stockPrice).toFixed(2));
  };

  const validateFuturesParams = (): boolean => {
    if (!isFutures) return true;
    if (!Number.isFinite(parsedLeverage) || parsedLeverage < 1 || parsedLeverage > 100) {
      setTradeError('Please choose a leverage multiplier between 1x and 100x.');
      return false;
    }
    if (!expiryDate || !expiryTime) {
      setTradeError('Please select both a settlement date and time for your futures contract.');
      return false;
    }
    const scheduled = new Date(`${expiryDate}T${expiryTime}`);
    if (isNaN(scheduled.getTime()) || scheduled.getTime() <= Date.now()) {
      setTradeError('Futures settlement date and time must be in the future.');
      return false;
    }
    return true;
  };

  const handleExecute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuthModal();
      return;
    }

    if (isSpot && !marketStatus.isOpen) {
      setTradeError(
        `Spot exchange closed (${marketStatus.dayOfWeek}). Individual stocks trade Mon–Fri 9:30 AM – 4:00 PM EST. Switch to Call, Put, or Futures to trade 24/7.`
      );
      return;
    }

    if (!validateFuturesParams()) return;

    if (totalUSD <= 0 || calculatedShares <= 0 || !isValidTrade) {
      if (tradeSide === 'buy' && !canAffordBuy && totalUSD > 0) {
        setTradeError(
          formatInsufficientCurrencyError({
            symbol: activeBuySource?.currencyCode || stockCurrencyCode,
            name: activeBuySource?.currencyName || activeBuySource?.label,
            available: availableBalance,
            required: totalUSD,
          })
        );
      } else if (tradeSide === 'sell' && isSpot && !hasSharesToSell) {
        setTradeError(`You do not hold any spot shares of ${stock.ticker} to sell. Switch to Call, Put, or Futures to sell contracts.`);
      }
      return;
    }

    setShowConfirm(true);
  };

  const processExecution = () => {
    if (isSpot && !marketStatus.isOpen) {
      setTradeError(
        `Spot exchange closed (${marketStatus.dayOfWeek}). Individual stocks trade Mon–Fri 9:30 AM – 4:00 PM EST. Switch to Call, Put, or Futures to trade 24/7.`
      );
      setShowConfirm(false);
      setIsExecuting(false);
      return;
    }

    if (!validateFuturesParams()) {
      setShowConfirm(false);
      return;
    }

    setIsExecuting(true);

    setTimeout(() => {
      processStockPayment(currentUser!.id, activeSource, totalUSD, tradeSide);

      const derivativeName =
        derivativeType === 'call_option' ? `Call Option (${strikePrice} Strike)` :
        derivativeType === 'put_option' ? `Put Option (${strikePrice} Strike)` :
        derivativeType === 'futures_long' ? `Futures Long (${leverage}x · ${expiryDate} ${expiryTime})` :
        derivativeType === 'futures_short' ? `Futures Short (${leverage}x · ${expiryDate} ${expiryTime})` :
        `Spot Equity`;

      const isOptionsOrFutures = derivativeType && derivativeType !== 'spot';
      const isMarketOpen = isOptionsOrFutures ? true : marketStatus.isOpen;
      const orderStatus: 'filled' | 'open' = isMarketOpen ? 'filled' : 'open';

      const newOrder: StockOrder = {
        id: `ord-${Date.now()}`,
        ticker: stock.ticker,
        stockName: `${stock.name} [${derivativeName}]`,
        side: tradeSide,
        orderType: 'market',
        derivativeType: derivativeType,
        strikePrice: isOption ? strikePrice : undefined,
        expiryDate: isOption || isFutures ? expiryDate : undefined,
        expiryTime: isFutures ? expiryTime : undefined,
        leverage: isFutures ? leverage : undefined,
        premiumUSD: isOption ? totalUSD : undefined,
        shares: calculatedShares,
        price: stockPrice,
        totalUSD: totalUSD,
        paymentSource: activeSource,
        status: orderStatus,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        dateIso: new Date().toISOString(),
        sector: stock.sector,
        tradeSlipId: `SLIP-${Date.now().toString().slice(-8)}`
      };

      onExecuteBuy(newOrder);

      // Add to global ledger
      addTransaction({
        taxYear: new Date().getFullYear(),
        type: tradeSide === 'buy' ? 'stock_buy' : 'stock_sell',
        category: 'trade',
        mode: 'final_coin',
        title: `${tradeSide.toUpperCase()} ${stock.ticker} - ${derivativeName}`,
        description: `Executed ${tradeSide.toUpperCase()} order for ${calculatedShares} units of ${stock.ticker} at ${stockPrice.toFixed(2)} via ${activeSource.label}.`,
        amountUSD: totalUSD,
        feeUSD: 0,
        netAmountUSD: tradeSide === 'buy' ? -totalUSD : totalUSD,
        sourceOrDestination: currentUser!.name,
        counterpartyOrIssuer: 'Final Stock Exchange',
        issuerHandle: currentUser!.handle,
        status: isMarketOpen ? 'Settled' : 'Pending Open',
        clearingNode: 'QUICK-EX-NODE-1',
        taxClassification: {
          formMapping: 'Securities Transaction',
          taxableEvent: true,
          taxableAmountUSD: totalUSD,
          irsCategoryNote: `Quick ${tradeSide} execution`
        }
      });

      setIsExecuting(false);
      onClose();
    }, 500);
  };

  const actionLabel =
    derivativeType === 'spot' ? 'Spot' :
    derivativeType === 'call_option' ? 'Call Option' :
    derivativeType === 'put_option' ? 'Put Option' :
    derivativeType === 'futures_long' ? 'Long Futures' :
    'Short Futures';

  return (
    <>
      <AnimatePresence>
        <div
          key="quick-trade-modal-backdrop"
          id="quick-trade-modal-backdrop"
          onClick={(e) => {
            if (e.target === e.currentTarget && !isExecuting) {
              onClose();
            }
          }}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-md overflow-y-auto"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 10 }}
            transition={{ duration: 0.16 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-[540px] rounded-3xl bg-white border border-slate-200 shadow-2xl p-5 sm:p-6 my-auto text-left max-h-[92vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-11 h-11 rounded-2xl bg-slate-900 text-amber-400 flex items-center justify-center font-mono font-bold text-sm shrink-0">
                  {(stock.ticker || '').slice(0, 4)}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-base text-slate-900 tabular-nums">
                      ${stock.ticker}
                    </span>
                    <span className="text-slate-300" aria-hidden="true">·</span>
                    <span className="text-xs text-slate-500 truncate">{stock.exchange}</span>
                    {stock.sector && (
                      <>
                        <span className="text-slate-300 hidden sm:inline" aria-hidden="true">·</span>
                        <span className="text-xs text-slate-500 truncate hidden sm:inline">{stock.sector}</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-xs font-medium text-slate-600 truncate mt-0.5">
                    {stock.name}
                  </h3>
                </div>
              </div>

              <div className="flex items-start gap-3 shrink-0">
                <div className="text-right">
                  <span className="font-mono font-bold text-base text-slate-900 tabular-nums block">
                    {formatStockPrice(stockPrice, stock, false)}
                  </span>
                  <span
                    className={`text-xs font-mono font-semibold tabular-nums block mt-0.5 ${
                      (stock.changeUSD || 0) >= 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {(stock.changeUSD || 0) >= 0 ? '+' : ''}
                    {(stock.changePercent || 0).toFixed(2)}%
                  </span>
                </div>

                <button
                  type="button"
                  id="close-quick-trade-modal-btn"
                  onClick={onClose}
                  disabled={isExecuting}
                  className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
                  aria-label="Close trade window"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="mt-4 space-y-4">
              {/* Primary Side Switcher: Buy vs Sell */}
              <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-slate-100 border border-slate-200/80">
                <button
                  type="button"
                  onClick={() => setTradeSide('buy')}
                  className={`min-w-0 min-h-[40px] px-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 overflow-hidden ${
                    tradeSide === 'buy'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">Buy / Long</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTradeSide('sell')}
                  className={`min-w-0 min-h-[40px] px-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 overflow-hidden ${
                    tradeSide === 'sell'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Coins className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">
                    Sell / Close{hasSharesToSell ? ` (${formattedSharesOwned})` : ''}
                  </span>
                </button>
              </div>

              {/* Instrument Selector */}
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-slate-600 block">
                  Instrument
                </span>
                <div className="grid grid-cols-5 gap-1 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => setDerivativeType('spot')}
                    className={`min-h-[36px] px-1 rounded-lg transition-all cursor-pointer text-center whitespace-nowrap truncate ${
                      derivativeType === 'spot'
                        ? 'bg-white text-slate-900 shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Spot
                  </button>
                  <button
                    type="button"
                    onClick={() => setDerivativeType('call_option')}
                    className={`min-h-[36px] px-1 rounded-lg transition-all cursor-pointer text-center whitespace-nowrap truncate ${
                      derivativeType === 'call_option'
                        ? 'bg-emerald-600 text-white shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Call ↗
                  </button>
                  <button
                    type="button"
                    onClick={() => setDerivativeType('put_option')}
                    className={`min-h-[36px] px-1 rounded-lg transition-all cursor-pointer text-center whitespace-nowrap truncate ${
                      derivativeType === 'put_option'
                        ? 'bg-rose-600 text-white shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Put ↘
                  </button>
                  <button
                    type="button"
                    onClick={() => setDerivativeType('futures_long')}
                    className={`min-h-[36px] px-1 rounded-lg transition-all cursor-pointer text-center whitespace-nowrap truncate ${
                      derivativeType === 'futures_long'
                        ? 'bg-amber-500 text-slate-950 shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Long Fut
                  </button>
                  <button
                    type="button"
                    onClick={() => setDerivativeType('futures_short')}
                    className={`min-h-[36px] px-1 rounded-lg transition-all cursor-pointer text-center whitespace-nowrap truncate ${
                      derivativeType === 'futures_short'
                        ? 'bg-indigo-600 text-white shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Short Fut
                  </button>
                </div>
              </div>

              {/* Single Market Status Bar */}
              <div
                className={`px-3.5 py-2.5 rounded-xl border text-xs flex items-start justify-between gap-3 ${
                  isMarketClosedForSpot
                    ? 'bg-amber-50 border-amber-200 text-amber-950'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="min-w-0">
                  <span className="font-semibold text-slate-900 block">
                    {!isSpot
                      ? '24/7 Contracts Trading Active'
                      : marketStatus.isOpen
                      ? 'Regular Market Open'
                      : `Spot Market Closed (${marketStatus.dayOfWeek})`}
                  </span>
                  <span className="text-[11px] text-slate-600 block mt-0.5 leading-relaxed">
                    {!isSpot
                      ? 'Options and futures trade 24/7, including after-hours, weekends, and holidays.'
                      : marketStatus.isOpen
                      ? 'Spot equity trading is active (Mon–Fri 9:30 AM – 4:00 PM EST).'
                      : 'Individual stocks only trade Mon–Fri 9:30 AM – 4:00 PM EST. Switch to Call, Put, or Futures above to trade 24/7.'}
                  </span>
                </div>
                {isMarketClosedForSpot && (
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-900 shrink-0">
                    Spot Halted
                  </span>
                )}
              </div>

              {/* Options Parameters */}
              {isOption && (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-900">Options Contract Terms</span>
                    <span className="text-[11px] font-mono text-slate-500 tabular-nums">5% Premium</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">
                        Strike Price
                      </label>
                      <input
                        type="number"
                        step="0.5"
                        value={strikePriceInput}
                        onChange={(e) => setStrikePriceInput(e.target.value)}
                        className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">
                        Expiry Date
                      </label>
                      <input
                        type="date"
                        min={getTodayDateString()}
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                        className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Futures Parameters: Settlement Date, Time & Leverage */}
              {isFutures && (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-900">Futures Settlement &amp; Leverage</span>
                    <span className="text-[11px] font-mono font-bold text-indigo-700 tabular-nums">
                      {leverage}x Margin
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 flex items-center gap-1 mb-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>Settlement Date</span>
                      </label>
                      <input
                        type="date"
                        min={getTodayDateString()}
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                        required
                        className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 flex items-center gap-1 mb-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>Settlement Time</span>
                      </label>
                      <input
                        type="time"
                        value={expiryTime}
                        onChange={(e) => setExpiryTime(e.target.value)}
                        required
                        className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label htmlFor="quick-leverage-input" className="text-[11px] font-medium text-slate-600">
                        Leverage (1x – 100x)
                      </label>
                      <div className="relative w-24">
                        <input
                          id="quick-leverage-input"
                          type="number"
                          min={1}
                          max={100}
                          step={1}
                          value={leverageInput}
                          onChange={(e) => setLeverageInput(e.target.value)}
                          onBlur={() => {
                            const val = Math.max(1, Math.min(100, Math.round(parseFloat(leverageInput) || 1)));
                            setLeverageInput(val.toString());
                          }}
                          className="w-full h-8 pl-2.5 pr-6 rounded-lg border border-slate-200 bg-white font-mono text-xs font-bold text-slate-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                        />
                        <span className="absolute right-2 top-1/2 -translate-y-1/2 font-mono text-[11px] font-bold text-slate-400 pointer-events-none">
                          x
                        </span>
                      </div>
                    </div>

                    <input
                      type="range"
                      min={1}
                      max={100}
                      step={1}
                      value={leverage}
                      onChange={(e) => setLeverageInput(e.target.value)}
                      className="w-full accent-indigo-600 cursor-pointer"
                      aria-label="Leverage slider"
                    />

                    <div className="grid grid-cols-6 gap-1">
                      {[1, 2, 5, 10, 25, 50].map((lev) => (
                        <button
                          key={lev}
                          type="button"
                          onClick={() => setLeverageInput(lev.toString())}
                          className={`min-h-[30px] rounded-lg border text-[11px] font-mono font-bold tabular-nums transition-colors cursor-pointer ${
                            leverage === lev
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {lev}x
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <form onSubmit={handleExecute} className="space-y-4">
                {/* Order Size & Method */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-700">
                      {tradeSide === 'buy' ? 'Order Size' : 'Quantity to Sell'}
                    </span>
                    <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-100 border border-slate-200">
                      <button
                        type="button"
                        onClick={() => handleToggleInputMode('dollars')}
                        className={`px-2.5 py-1 text-[11px] font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                          inputMode === 'dollars'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        In {stockCurrencyCode}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleInputMode('shares')}
                        className={`px-2.5 py-1 text-[11px] font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                          inputMode === 'shares'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        Shares
                      </button>
                    </div>
                  </div>

                  {inputMode === 'dollars' ? (
                    <>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono font-bold text-xs text-slate-500 select-none">
                          {stockCurrencyCode}
                        </span>
                        <input
                          type="number"
                          min="0.01"
                          step="any"
                          value={dollarAmount}
                          onChange={(e) => {
                            const val = e.target.value;
                            setDollarAmount(val);
                            const num = parseFloat(val) || 0;
                            setSharesAmount((num / stockPrice).toFixed(4));
                          }}
                          className="w-full h-12 pl-16 pr-28 rounded-xl border border-slate-200 bg-white text-slate-900 font-mono font-bold text-base tabular-nums focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                          placeholder="500"
                          required
                        />
                        <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500 tabular-nums pointer-events-none">
                          ≈ {calculatedShares} units
                        </span>
                      </div>

                      {tradeSide === 'buy' ? (
                        <div className="grid grid-cols-5 gap-1.5">
                          {[50, 100, 250, 500, 1000].map((amt) => (
                            <button
                              key={amt}
                              type="button"
                              onClick={() => handleQuickDollarPreset(amt)}
                              className={`min-h-[34px] text-xs font-mono font-semibold tabular-nums rounded-lg border transition-colors cursor-pointer ${
                                dollarAmount === amt.toString()
                                  ? 'bg-slate-900 text-white border-slate-900'
                                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                              }`}
                            >
                              {amt.toLocaleString()}
                            </button>
                          ))}
                        </div>
                      ) : (
                        hasSharesToSell && isSpot && (
                          <div className="grid grid-cols-4 gap-1.5">
                            {[0.25, 0.5, 0.75, 1.0].map((pct) => (
                              <button
                                key={pct}
                                type="button"
                                onClick={() => handlePercentHoldingsSell(pct)}
                                className="min-h-[34px] text-xs font-mono font-semibold rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer"
                              >
                                {pct === 1.0 ? '100%' : `${pct * 100}%`}
                              </button>
                            ))}
                          </div>
                        )
                      )}
                    </>
                  ) : (
                    <>
                      <div className="relative">
                        <input
                          type="number"
                          min="0.01"
                          step="any"
                          value={sharesAmount}
                          onChange={(e) => {
                            const val = e.target.value;
                            setSharesAmount(val);
                            const num = parseFloat(val) || 0;
                            setDollarAmount((num * stockPrice).toFixed(2));
                          }}
                          className="w-full h-12 px-3.5 pr-32 rounded-xl border border-slate-200 bg-white text-slate-900 font-mono font-bold text-base tabular-nums focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                          placeholder="5"
                          required
                        />
                        <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-500 tabular-nums pointer-events-none">
                          ≈ {formatStockAmount(baseUSD, stock, false)}
                        </span>
                      </div>

                      {tradeSide === 'buy' ? (
                        <div className="grid grid-cols-5 gap-1.5">
                          {[1, 5, 10, 25, 50].map((sh) => (
                            <button
                              key={sh}
                              type="button"
                              onClick={() => handleQuickSharesPreset(sh)}
                              className={`min-h-[34px] text-xs font-mono font-semibold tabular-nums rounded-lg border transition-colors cursor-pointer ${
                                sharesAmount === sh.toString()
                                  ? 'bg-slate-900 text-white border-slate-900'
                                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                              }`}
                            >
                              {sh} shs
                            </button>
                          ))}
                        </div>
                      ) : (
                        hasSharesToSell && isSpot && (
                          <div className="grid grid-cols-4 gap-1.5">
                            {[0.25, 0.5, 0.75, 1.0].map((pct) => (
                              <button
                                key={pct}
                                type="button"
                                onClick={() => handlePercentHoldingsSell(pct)}
                                className="min-h-[34px] text-xs font-mono font-semibold rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer"
                              >
                                {pct === 1.0 ? '100%' : `${pct * 100}%`}
                              </button>
                            ))}
                          </div>
                        )
                      )}
                    </>
                  )}
                </div>

                {/* Funding Source (Buy) or Currency Picker (Sell) */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-semibold text-slate-700">
                      {tradeSide === 'buy' ? 'Funding Source' : 'Deposit Proceeds To'}
                    </label>
                    <span className="text-[11px] font-mono text-slate-500">
                      {tradeSide === 'buy'
                        ? `${stockCurrencyCode} Final Currency Settlement`
                        : 'Final Coins Only'}
                    </span>
                  </div>

                  {tradeSide === 'buy' ? (
                    <div className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Wallet className="w-4 h-4 text-slate-500 shrink-0" />
                        <div className="min-w-0">
                          <span className="font-mono font-bold text-xs text-slate-900 block">
                            {activeBuySource.label}
                          </span>
                          <span className="text-[11px] text-slate-500 block">
                            Final Currency Balance
                          </span>
                        </div>
                      </div>
                      <span
                        className={`font-mono font-bold text-xs tabular-nums shrink-0 ${
                          canAffordBuy || totalUSD <= 0 ? 'text-slate-900' : 'text-rose-600'
                        }`}
                      >
                        {availableBalance.toLocaleString()} available
                      </span>
                    </div>
                  ) : (
                    <>
                      <SellCurrencyPicker
                        currencies={allSystemSellCurrencies}
                        selectedSource={activeSellSource}
                        onSelect={(src) => setSelectedSellCurrency(src)}
                        finalCoinsOnly={true}
                      />
                      <p className="text-[11px] text-slate-500">
                        Personal and Business IPOs settle strictly in Final Currencies (no stablecoins, fiat, or crypto). Search any Final Coin across the system.
                      </p>
                    </>
                  )}
                </div>

                {/* Order Breakdown Summary */}
                <div className="rounded-xl border border-slate-200 bg-slate-50/60 divide-y divide-slate-200/70 text-xs">
                  <div className="px-3.5 py-2.5 flex items-center justify-between">
                    <span className="text-slate-500">Instrument</span>
                    <span className="font-semibold text-slate-900">{actionLabel}</span>
                  </div>
                  {isFutures && expiryDate && expiryTime && (
                    <div className="px-3.5 py-2.5 flex items-center justify-between">
                      <span className="text-slate-500">Settlement Schedule</span>
                      <span className="font-mono font-semibold text-slate-900 tabular-nums">
                        {expiryDate} · {expiryTime}
                      </span>
                    </div>
                  )}
                  <div className="px-3.5 py-2.5 flex items-center justify-between">
                    <span className="text-slate-500">Notional Value</span>
                    <span className="font-mono text-slate-900 tabular-nums">
                      {formatStockPrice(baseUSD, stock, false)}
                    </span>
                  </div>
                  <div className="px-3.5 py-2.5 flex items-center justify-between">
                    <span className="text-slate-500">Fee</span>
                    <span className="font-mono text-emerald-700 font-semibold tabular-nums">0.00</span>
                  </div>
                  <div className="px-3.5 py-3 flex items-center justify-between font-bold text-slate-900 bg-white rounded-b-xl">
                    <span>{tradeSide === 'buy' ? 'Total Cost' : 'Net Proceeds'}</span>
                    <div className="text-right">
                      <span className="font-mono text-sm text-slate-900 tabular-nums block">
                        {formatStockPrice(totalUSD, stock, false)}
                      </span>
                      {tradeSide === 'sell' && sellReceiveCode !== stockCurrencyCode && (
                        <span className="font-mono text-[11px] font-medium text-emerald-700 tabular-nums block mt-0.5">
                          Credits +{sellEstimatedUnits.toLocaleString(undefined, { maximumFractionDigits: 4 })} {sellReceiveCode} to wallet
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Single Inline Error Banner */}
                {tradeError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <span className="font-semibold block">
                        {tradeError.includes('Spot exchange closed') ? 'Spot Market Closed' : 'Order Cannot Be Executed'}
                      </span>
                      <span className="text-[11px] text-rose-800 block mt-0.5 leading-relaxed">{tradeError}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setTradeError(null)}
                      className="text-rose-400 hover:text-rose-800 p-0.5 cursor-pointer rounded shrink-0"
                      aria-label="Dismiss error"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={onClose}
                    disabled={isExecuting}
                    className="min-h-[44px] px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer shrink-0"
                  >
                    Cancel
                  </button>

                  {currentUser ? (
                    isMarketClosedForSpot ? (
                      <button
                        type="submit"
                        disabled={isExecuting}
                        className="flex-1 min-h-[44px] px-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2 hover:bg-rose-100"
                      >
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>Spot Market Closed ({marketStatus.dayOfWeek})</span>
                      </button>
                    ) : (
                      <button
                        type="submit"
                        disabled={isExecuting || (tradeSide === 'sell' && !isValidTrade)}
                        className={`flex-1 min-h-[44px] px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                          tradeSide === 'buy'
                            ? isValidTrade
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                              : 'bg-rose-100 text-rose-800 border border-rose-200'
                            : isValidTrade
                            ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-xs'
                            : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                        }`}
                      >
                        {isExecuting ? (
                          <span>Processing...</span>
                        ) : (
                          <>
                            <Zap className="w-4 h-4" />
                            <span>
                              {tradeSide === 'buy' ? 'Buy' : 'Sell'} {actionLabel} ({formatStockPrice(totalUSD, stock, false)})
                            </span>
                          </>
                        )}
                      </button>
                    )
                  ) : (
                    <button
                      type="button"
                      onClick={onOpenAuthModal}
                      className="flex-1 min-h-[44px] px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Lock className="w-4 h-4" />
                      <span>Sign In to Trade</span>
                    </button>
                  )}
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      </AnimatePresence>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title={tradeSide === 'buy' ? 'Confirm Order' : 'Confirm Sale'}
        message={
          tradeSide === 'buy'
            ? `Buy ${calculatedShares} units of ${stock.name} (${stock.ticker})${isFutures ? ` settling ${expiryDate} at ${expiryTime}` : ''} for ${formatStockPrice(totalUSD, stock, false)}?`
            : `Sell ${calculatedShares} units of ${stock.name} (${stock.ticker})${isFutures ? ` settling ${expiryDate} at ${expiryTime}` : ''} for ${formatStockPrice(totalUSD, stock, false)}, deposited directly to your wallet in ${activeSellSource.label}?`
        }
        confirmText={tradeSide === 'buy' ? 'Confirm Buy' : 'Confirm Sale'}
        type={tradeSide === 'buy' ? 'info' : 'warning'}
      />
    </>
  );
};
