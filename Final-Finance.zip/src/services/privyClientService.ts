import { PrivyNetworkKey } from '../config/privyConfig';

export interface PrivyServerConfigResponse {
  appIdConfigured: boolean;
  appId: string;
  appSecretConfigured: boolean;
  defaultNetworkKey: PrivyNetworkKey;
  supportedNetworks: Array<{
    key: PrivyNetworkKey;
    name: string;
    chainId: number;
    isTestnet: boolean;
    nativeSymbol: string;
    explorerUrl: string;
  }>;
}

export interface WalletTokenBalance {
  symbol: string;
  name: string;
  decimals: number;
  address: string | null;
  isNative: boolean;
  isStablecoin: boolean;
  available: boolean;
  balanceRaw: string;
  balanceFormatted: string;
  note?: string;
}

export interface PrivyWalletBalancesResponse {
  address: string;
  networkKey: PrivyNetworkKey;
  networkName: string;
  chainId: number;
  isTestnet: boolean;
  explorerUrl: string;
  nativeToken: WalletTokenBalance;
  tokens: WalletTokenBalance[];
  fetchedAt: string;
}

export interface PreparedPrivyTransfer {
  fromAddress: string;
  chainId: number;
  networkKey: PrivyNetworkKey;
  networkName: string;
  explorerUrl: string;
  assetSymbol: string;
  transaction: {
    to: `0x${string}`;
    data?: `0x${string}`;
    value: `0x${string}`;
    chainId: number;
  };
}

async function parsePrivyJson<T>(res: Response, fallbackError: string): Promise<T> {
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  const raw = (await res.text()).trim();

  if (!raw) {
    if (!res.ok) throw new Error(`${fallbackError} (HTTP ${res.status})`);
    return {} as T;
  }

  if (
    raw.startsWith('<') ||
    raw.toLowerCase().startsWith('<!doctype') ||
    (!contentType.includes('application/json') && /<html[\s>]/i.test(raw))
  ) {
    throw new Error(
      `Unable to reach the Privy backend API (received HTML instead of JSON, HTTP ${res.status}). Please retry in a moment.`
    );
  }

  try {
    return JSON.parse(raw) as T;
  } catch {
    throw new Error(`${fallbackError} (invalid JSON response)`);
  }
}

async function clearStaleServiceWorkers(): Promise<void> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
  try {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.map((reg) => reg.unregister().catch(() => false)));
  } catch {
    // ignore
  }
}

async function fetchPrivyApi<T>(url: string, init?: RequestInit, fallbackError = 'Privy request failed'): Promise<T> {
  const doFetch = () =>
    fetch(url, {
      ...init,
      cache: 'no-store',
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        ...(init?.headers || {}),
      },
    });

  let res = await doFetch();
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  if (!contentType.includes('application/json') && res.status === 200) {
    await clearStaleServiceWorkers();
    await new Promise((r) => setTimeout(r, 400));
    res = await doFetch();
  }

  const parsed = await parsePrivyJson<{ success?: boolean; error?: string; data?: T }>(res, fallbackError);
  if (!res.ok || !parsed.success) {
    throw new Error(parsed.error || fallbackError);
  }
  return parsed.data as T;
}

export function fetchPrivyServerConfig(): Promise<PrivyServerConfigResponse> {
  return fetchPrivyApi('/api/privy/config', { method: 'GET' }, 'Failed to fetch Privy configuration');
}

export function fetchPrivyWalletBalances(params: {
  address: string;
  network: PrivyNetworkKey;
  customTokens?: string[];
}): Promise<PrivyWalletBalancesResponse> {
  return fetchPrivyApi(
    '/api/privy/balances',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Failed to load wallet token balances'
  );
}

export function preparePrivyWalletTransfer(params: {
  fromAddress: string;
  toAddress: string;
  amount: string;
  network: PrivyNetworkKey;
  assetType: 'native' | 'erc20';
  tokenSymbol?: string;
  tokenAddress?: string | null;
  decimals?: number;
}): Promise<PreparedPrivyTransfer> {
  return fetchPrivyApi(
    '/api/privy/wallets/prepare-transfer',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Failed to prepare token transfer'
  );
}

export function verifyPrivySessionOnServer(params: {
  accessToken: string;
  privyUserId?: string;
}): Promise<{
  verified: boolean;
  appSecretConfigured: boolean;
  verificationMode: string;
  message?: string;
}> {
  return fetchPrivyApi(
    '/api/privy/verify-token',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Failed to verify Privy session'
  );
}

export function verifyWalletSignatureOnServer(params: {
  address: string;
  message: string;
  signature: string;
}): Promise<{
  verified: boolean;
  address: string;
  verificationMethod: 'cryptographic_signature';
}> {
  return fetchPrivyApi(
    '/api/privy/wallets/verify-signature',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Wallet signature verification failed'
  );
}

export function verifyWalletAddressOnChain(params: {
  address: string;
  network?: PrivyNetworkKey;
}): Promise<{
  verified: boolean;
  address: string;
  txCount: number;
  hasBalance: boolean;
  activeNetworks: string[];
  verificationMethod: 'onchain_rpc';
}> {
  return fetchPrivyApi(
    '/api/privy/wallets/verify-address',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Wallet address verification failed'
  );
}

export function syncPrivyWalletPreferences(params: {
  userId: string;
  walletAddress?: string | null;
  networkKey: PrivyNetworkKey;
  customTokensByNetwork?: Record<string, string[]>;
}): Promise<{
  userId: string;
  walletAddress: string | null;
  networkKey: PrivyNetworkKey;
  customTokensByNetwork: Record<string, string[]>;
}> {
  return fetchPrivyApi(
    '/api/privy/wallets/preferences',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Failed to save wallet preferences'
  );
}

export interface PrivyServerManagedWallet {
  id: string;
  address: `0x${string}`;
  chainType: 'ethereum';
  createdAt: string;
  source: 'privy-server-api';
}

export function fetchPrivyServerWallets(userId: string): Promise<PrivyServerManagedWallet[]> {
  return fetchPrivyApi(
    `/api/privy/wallets/list?userId=${encodeURIComponent(userId)}`,
    { method: 'GET' },
    'Failed to fetch Privy server wallets'
  );
}

export function createPrivyServerWallet(params: {
  userId: string;
  createNew?: boolean;
}): Promise<PrivyServerManagedWallet> {
  return fetchPrivyApi(
    '/api/privy/wallets/create',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Failed to create Privy wallet'
  );
}

export function sendPrivyServerWalletTx(params: {
  walletId: string;
  fromAddress: string;
  toAddress: string;
  amount: string;
  network: PrivyNetworkKey;
  assetType: 'native' | 'erc20';
  tokenSymbol?: string;
  tokenAddress?: string | null;
  decimals?: number;
}): Promise<{
  hash: string;
  chainId: number;
  networkKey: PrivyNetworkKey;
  networkName: string;
  explorerUrl: string;
}> {
  return fetchPrivyApi(
    '/api/privy/wallets/send',
    {
      method: 'POST',
      body: JSON.stringify(params),
    },
    'Failed to broadcast transaction via Privy wallet'
  );
}

