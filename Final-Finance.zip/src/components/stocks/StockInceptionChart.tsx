import React, { useMemo, useRef, useState, useEffect } from 'react';
import { StockItem, StockPricePoint } from '../../types/stocks';
import { TrendingUp, TrendingDown, LineChart, Calendar } from 'lucide-react';
import { formatStockPrice, formatStockAmount } from '../../utils/stockCurrencyFormatter';

export type InceptionChartScale = 'inception' | 'years' | 'months' | 'weeks' | 'days';

interface StockInceptionChartProps {
  stock: StockItem;
  currencyLabel?: string;
}

function hashTicker(ticker: string): number {
  let h = 2166136261;
  for (let i = 0; i < ticker.length; i++) {
    h ^= ticker.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function seededWave(seed: number, step: number): number {
  const x = Math.sin(seed * 0.013 + step * 1.37) * 10000;
  return x - Math.floor(x) - 0.5;
}

const SCALE_OPTIONS: { id: InceptionChartScale; label: string }[] = [
  { id: 'inception', label: 'Inception' },
  { id: 'years', label: 'Years' },
  { id: 'months', label: 'Months' },
  { id: 'weeks', label: 'Weeks' },
  { id: 'days', label: 'Days' },
];

export const StockInceptionChart: React.FC<StockInceptionChartProps> = ({
  stock,
  currencyLabel,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 680, height: 240 });
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [selectedScale, setSelectedScale] = useState<InceptionChartScale>('inception');

  const currentYear = 2026;
  const h5Y = stock.history?.['5Y'] || [];
  const h1Y = stock.history?.['1Y'] || [];
  const h1M = stock.history?.['1M'] || [];
  const h1W = stock.history?.['1W'] || [];
  const h1D = stock.history?.['1D'] || [];

  const hasMultiYearHistory =
    stock.foundedYear !== undefined
      ? stock.foundedYear < currentYear
      : h5Y.length >= 3;
  const hasMultiMonthHistory = hasMultiYearHistory || h1Y.length >= 3;
  const hasMultiWeekHistory = hasMultiMonthHistory || h1M.length >= 3;

  // Reset scale to inception when switching stocks, and reset hover index when changing stock/scale
  useEffect(() => {
    setSelectedScale('inception');
    setHoverIndex(null);
  }, [stock.ticker]);

  useEffect(() => {
    setHoverIndex(null);
  }, [selectedScale]);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0) {
          setDimensions({
            width: Math.max(260, entry.contentRect.width),
            height: window.innerWidth < 640 ? 205 : 245,
          });
        }
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Build deterministic series based on selected stretch scale, strictly clamped at inception
  const { chartPoints, spanLabel, unitBadge } = useMemo(() => {
    const foundedYear = stock.foundedYear;
    const seed = hashTicker(`${stock.ticker}-${selectedScale}`);

    const buildSmoothSeries = (
      anchors: StockPricePoint[],
      targetCount: number,
      labelFn: (idx: number, total: number) => string
    ) => {
      if (anchors.length === 0) {
        return [
          { time: 'Start', price: stock.price, volume: 0 },
          { time: 'Now', price: stock.price, volume: 0 },
        ];
      }
      if (anchors.length === 1) {
        return [
          { time: 'Start', price: anchors[0].price, volume: 0 },
          { time: 'Now', price: stock.price, volume: 0 },
        ];
      }
      const pts: StockPricePoint[] = [];
      for (let i = 0; i < targetCount; i++) {
        const t = i / Math.max(1, targetCount - 1);
        const scaled = t * (anchors.length - 1);
        const lowIdx = Math.floor(scaled);
        const highIdx = Math.min(anchors.length - 1, lowIdx + 1);
        const frac = scaled - lowIdx;
        const baseInterp = anchors[lowIdx].price * (1 - frac) + anchors[highIdx].price * frac;
        const wobble = i === 0 || i === targetCount - 1 ? 0 : seededWave(seed, i) * baseInterp * 0.04;
        const price =
          i === targetCount - 1
            ? stock.price
            : Math.max(0.01, Number((baseInterp + wobble).toFixed(2)));
        pts.push({
          time: labelFn(i, targetCount),
          price,
          volume: anchors[lowIdx].volume || 0,
        });
      }
      return pts;
    };

    const buildMonths = () => {
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'];
      const source = h1Y.length >= 2 ? h1Y.slice(0, Math.min(h1Y.length, monthNames.length)) : h1M;
      const pts = buildSmoothSeries(source, 22, (idx, total) => {
        if (idx === total - 1) return 'Now';
        const mIdx = Math.min(
          monthNames.length - 1,
          Math.floor((idx / Math.max(1, total - 1)) * (monthNames.length - 1))
        );
        return `${monthNames[mIdx]} '26`;
      });
      return {
        chartPoints: pts,
        spanLabel: 'Jan – Nov 2026',
        unitBadge: `${monthNames.length} Months`,
      };
    };

    const buildYears = () => {
      // Limit strictly to as long as the stock has been listed (never pre-inception)
      if (!hasMultiYearHistory || (foundedYear !== undefined && foundedYear >= currentYear)) {
        if (hasMultiMonthHistory) {
          const monthView = buildMonths();
          return {
            ...monthView,
            spanLabel: `${foundedYear || currentYear} (Listed Jan 2026 – Now)`,
            unitBadge: '2026 YTD',
          };
        }
        return buildWeeks();
      }
      const earliestHistoryYear = Number(h5Y[0]?.time) || 2022;
      const startYear = foundedYear ? Math.max(2018, foundedYear) : earliestHistoryYear;
      const yearSpan = Math.max(1, currentYear - startYear);
      // Slice 5Y history so it starts strictly at startYear (listing year)
      const matchingAnchors = h5Y.filter((p) => {
        const y = Number(p.time);
        return Number.isNaN(y) || y >= startYear;
      });
      const source = matchingAnchors.length >= 2 ? matchingAnchors : (h5Y.length >= 2 ? h5Y : h1Y);
      const pointCount = Math.min(28, Math.max(14, yearSpan * 4 + 1));
      const pts = buildSmoothSeries(source, pointCount, (idx, total) => {
        if (idx === total - 1) return 'Now';
        const yrFloat = startYear + (idx / Math.max(1, total - 1)) * yearSpan;
        const yr = Math.floor(yrFloat);
        const q = Math.min(4, Math.floor((yrFloat - yr) * 4) + 1);
        return idx === 0 ? `${startYear}` : `Q${q} '${String(yr).slice(-2)}`;
      });
      return {
        chartPoints: pts,
        spanLabel: `${startYear} – Now`,
        unitBadge: yearSpan === 1 ? '1 Year' : `${yearSpan} Years`,
      };
    };

    const buildWeeks = () => {
      const source = h1M.length >= 3 ? h1M : h1W.length >= 2 ? h1W : h1D;
      const pts = buildSmoothSeries(source, 16, (idx, total) => {
        if (idx === total - 1) return 'Now';
        const wk = Math.min(4, Math.floor((idx / Math.max(1, total - 1)) * 4) + 1);
        const day = Math.max(1, Math.round((idx / Math.max(1, total - 1)) * 28));
        return idx === 0 ? 'Wk 1' : `Wk ${wk} (D${day})`;
      });
      return {
        chartPoints: pts,
        spanLabel: '4 Weeks – Now',
        unitBadge: 'Weeks',
      };
    };

    const buildDays = () => {
      if (h1W.length >= 3) {
        const pts = h1W.map((p, idx) => ({
          ...p,
          time: idx === h1W.length - 1 ? 'Now' : p.time.replace(/\s+\d+:\d+$/, ''),
          price: idx === h1W.length - 1 ? stock.price : p.price,
        }));
        return {
          chartPoints: pts,
          spanLabel: 'Recent Days – Now',
          unitBadge: 'Days',
        };
      }
      const fallbackBase =
        h1D.length >= 2
          ? h1D
          : [
              { time: 'Open', price: Number((stock.openPrice || stock.price * 0.98).toFixed(2)), volume: 0 },
              { time: 'Now', price: stock.price, volume: 0 },
            ];
      const pts = fallbackBase.map((p, idx) => ({
        ...p,
        time: idx === fallbackBase.length - 1 ? 'Now' : p.time.replace(/ (AM|PM)$/, '$1'),
        price: idx === fallbackBase.length - 1 ? stock.price : p.price,
      }));
      return {
        chartPoints: pts,
        spanLabel: 'Today',
        unitBadge: 'Days',
      };
    };

    // Explicit user stretch selection (strictly bounded at inception/listing)
    if (selectedScale === 'years') return buildYears();
    if (selectedScale === 'months') return hasMultiMonthHistory ? buildMonths() : buildWeeks();
    if (selectedScale === 'weeks') return hasMultiWeekHistory ? buildWeeks() : buildDays();
    if (selectedScale === 'days') return buildDays();

    // Auto 'inception' scale: exact maximum lifetime since inception
    if (hasMultiYearHistory) return buildYears();
    if (hasMultiMonthHistory) return buildMonths();
    if (hasMultiWeekHistory) return buildWeeks();
    return buildDays();
  }, [
    stock.ticker,
    stock.price,
    stock.openPrice,
    stock.foundedYear,
    h5Y,
    h1Y,
    h1M,
    h1W,
    h1D,
    hasMultiYearHistory,
    hasMultiMonthHistory,
    hasMultiWeekHistory,
    selectedScale,
  ]);

  const prices = chartPoints.map((p) => p.price);
  const rawMin = Math.min(...prices);
  const rawMax = Math.max(...prices);
  const padAmount = Math.max(0.05, (rawMax - rawMin) * 0.08 || rawMax * 0.02);
  const minPrice = Math.max(0, rawMin - padAmount);
  const maxPrice = rawMax + padAmount;
  const priceRange = maxPrice - minPrice || 1;

  const startPrice = chartPoints[0]?.price ?? stock.price;
  const activePoint =
    hoverIndex !== null && chartPoints[hoverIndex]
      ? chartPoints[hoverIndex]
      : chartPoints[chartPoints.length - 1];
  const activePrice = activePoint?.price ?? stock.price;
  const rangeDiff = activePrice - startPrice;
  const rangeDiffPct = startPrice > 0 ? (rangeDiff / startPrice) * 100 : 0;
  const isActivePositive = rangeDiff >= 0;
  const isNegative = (stock.price - startPrice < 0) || (rangeDiff < 0) || (stock.changeUSD < 0);
  const strokeColor = isNegative ? '#f43f5e' : '#10b981';
  const paddingLeft = 14;
  const paddingRight = 56;
  const paddingTop = 18;
  const paddingBottom = 28;
  const plotWidth = Math.max(120, dimensions.width - paddingLeft - paddingRight);
  const plotHeight = Math.max(100, dimensions.height - paddingTop - paddingBottom);

  const svgPoints = chartPoints.map((pt, i) => {
    const x = paddingLeft + (i / Math.max(1, chartPoints.length - 1)) * plotWidth;
    const y = paddingTop + (1 - (pt.price - minPrice) / priceRange) * plotHeight;
    return { x, y, data: pt, index: i };
  });

  // Compute non-overlapping X-axis ticks based strictly on actual pixel width
  const xAxisTicks = useMemo(() => {
    if (svgPoints.length === 0) return [];
    if (svgPoints.length === 1) return [svgPoints[0]];

    const first = svgPoints[0];
    const last = svgPoints[svgPoints.length - 1];
    const usableSpan = last.x - first.x;
    const minPixelGap = dimensions.width < 420 ? 84 : dimensions.width < 580 ? 96 : 110;
    const segments = Math.max(1, Math.floor(usableSpan / minPixelGap));

    if (segments <= 1) {
      return [first, last];
    }

    const chosenIndices = new Set<number>([0]);
    let lastChosenX = first.x;

    for (let s = 1; s < segments; s++) {
      const candidateIdx = Math.round((s / segments) * (svgPoints.length - 1));
      const candidate = svgPoints[candidateIdx];
      if (
        candidate &&
        candidateIdx > 0 &&
        candidateIdx < svgPoints.length - 1 &&
        candidate.x - lastChosenX >= minPixelGap * 0.85 &&
        last.x - candidate.x >= minPixelGap * 0.85
      ) {
        chosenIndices.add(candidateIdx);
        lastChosenX = candidate.x;
      }
    }

    chosenIndices.add(svgPoints.length - 1);
    return Array.from(chosenIndices)
      .sort((a, b) => a - b)
      .map((idx) => svgPoints[idx]);
  }, [svgPoints, dimensions.width]);

  const linePath = svgPoints.reduce(
    (acc, pt, idx) => (idx === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`),
    ''
  );
  const areaPath =
    svgPoints.length > 0
      ? `${linePath} L ${svgPoints[svgPoints.length - 1].x} ${paddingTop + plotHeight} L ${svgPoints[0].x} ${paddingTop + plotHeight} Z`
      : '';

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (svgPoints.length === 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    let closest = 0;
    let bestDist = Infinity;
    svgPoints.forEach((pt, idx) => {
      const dist = Math.abs(pt.x - mouseX);
      if (dist < bestDist) {
        bestDist = dist;
        closest = idx;
      }
    });
    setHoverIndex(closest);
  };

  const gradientId = `inception-grad-${stock.ticker.replace(/[^a-zA-Z0-9_-]/g, '')}-${selectedScale}`;
  const periodLabel = selectedScale === 'inception' ? 'Since Inception' : unitBadge;

  return (
    <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-3 text-center">
      {/* Compact Centered Header */}
      <div className="flex flex-col items-center justify-center gap-2 pb-2.5 border-b border-slate-100">
        <div className="flex items-center justify-center gap-2 flex-wrap">
          <LineChart className="w-4 h-4 text-emerald-600" />
          <h3 className="font-serif font-bold text-sm text-slate-900">
            Price Performance ({periodLabel})
          </h3>
          <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            <Calendar className="w-2.5 h-2.5" />
            <span>{spanLabel}</span>
          </span>
        </div>

        <div className="flex items-center justify-center gap-2 flex-wrap">
          <span className="font-mono font-bold text-lg text-slate-900">
            {formatStockPrice(activePrice, stock, false)}
          </span>
          <span
            className={`inline-flex items-center gap-1 text-xs font-mono font-bold px-2 py-0.5 rounded-lg ${
              isActivePositive ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-600'
            }`}
          >
            {isActivePositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            <span>
              {isActivePositive ? '+' : ''}{formatStockAmount(rangeDiff, stock, false)} ({isActivePositive ? '+' : ''}{rangeDiffPct.toFixed(2)}%)
            </span>
          </span>
          <span className="text-[10px] font-mono text-slate-400">
            {activePoint?.time || periodLabel}
          </span>
        </div>

        {/* Stretchable Timeframe Switcher (Inception -> Years -> Months -> Weeks -> Days) */}
        <div className="inline-flex flex-wrap items-center justify-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200">
          {SCALE_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setSelectedScale(opt.id)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                selectedScale === opt.id
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Responsive SVG Area Chart */}
      <div
        ref={containerRef}
        className="relative w-full select-none"
        style={{ height: `${dimensions.height}px` }}
      >
        <svg
          width={dimensions.width}
          height={dimensions.height}
          className="overflow-visible cursor-crosshair"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHoverIndex(null)}
        >
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={strokeColor} stopOpacity="0.25" />
              <stop offset="95%" stopColor={strokeColor} stopOpacity="0.01" />
            </linearGradient>
          </defs>

          {/* Horizontal Grid Lines & Right-Side Price Scale */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const y = paddingTop + ratio * plotHeight;
            const val = maxPrice - ratio * priceRange;
            return (
              <g key={ratio}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={dimensions.width - paddingRight}
                  y2={y}
                  stroke="#e2e8f0"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={dimensions.width - paddingRight + 6}
                  y={y + 3.5}
                  fontSize="10"
                  fontFamily="monospace"
                  fill="#94a3b8"
                >
                  {val.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Area Fill & Stroke */}
          {areaPath && <path d={areaPath} fill={`url(#${gradientId})`} />}
          {linePath && (
            <path
              d={linePath}
              fill="none"
              stroke={strokeColor}
              strokeWidth="2.25"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Hover Crosshair & Active Point */}
          {hoverIndex !== null && svgPoints[hoverIndex] && (
            <g>
              <line
                x1={svgPoints[hoverIndex].x}
                y1={paddingTop}
                x2={svgPoints[hoverIndex].x}
                y2={paddingTop + plotHeight}
                stroke="#64748b"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
              <circle
                cx={svgPoints[hoverIndex].x}
                cy={svgPoints[hoverIndex].y}
                r="4.5"
                fill="#ffffff"
                stroke={strokeColor}
                strokeWidth="2.5"
              />
            </g>
          )}

          {/* Collision-free X-Axis Date Labels */}
          {xAxisTicks.map((pt, i) => (
            <text
              key={`x-tick-${pt.index}-${i}`}
              x={pt.x}
              y={dimensions.height - 5}
              textAnchor={
                pt.index === 0
                  ? 'start'
                  : pt.index === svgPoints.length - 1
                  ? 'end'
                  : 'middle'
              }
              fontSize="10"
              fontFamily="monospace"
              fill="#64748b"
            >
              {pt.data.time}
            </text>
          ))}
        </svg>

        {/* Tooltip */}
        {hoverIndex !== null && svgPoints[hoverIndex] && (
          <div
            className="absolute pointer-events-none z-10 px-2.5 py-1.5 bg-slate-900/95 text-white text-[11px] rounded-xl shadow-lg border border-slate-700 transform -translate-x-1/2 -translate-y-full"
            style={{
              left: `${Math.min(Math.max(60, svgPoints[hoverIndex].x), dimensions.width - 60)}px`,
              top: `${Math.max(12, svgPoints[hoverIndex].y - 10)}px`,
            }}
          >
            <div className="font-mono font-bold text-amber-300">
              {formatStockPrice(svgPoints[hoverIndex].data.price, stock, false)} {currencyLabel || ''}
            </div>
            <div className="text-[10px] text-slate-300 font-mono">
              {svgPoints[hoverIndex].data.time}
            </div>
          </div>
        )}
      </div>

      {/* Compact Range Stats Footer */}
      <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-xs">
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">
            {selectedScale === 'inception' ? 'Inception Price' : 'Period Start'}
          </span>
          <span className="font-mono font-bold text-slate-800">
            {formatStockPrice(startPrice, stock, false)}
          </span>
        </div>
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">Period High</span>
          <span className="font-mono font-bold text-emerald-700">
            {formatStockPrice(rawMax, stock, false)}
          </span>
        </div>
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">Current Price</span>
          <span className="font-mono font-bold text-slate-900">
            {formatStockPrice(stock.price, stock, false)}
          </span>
        </div>
      </div>
    </div>
  );
};
