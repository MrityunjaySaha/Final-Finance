import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Image as ImageIcon,
  Video,
  Upload,
  Trash2,
  Play,
  Pause,
  Plus,
  Sparkles,
  ArrowUpRight,
  Maximize2,
  FileText,
  User,
  Layers,
  ChevronLeft,
  ChevronRight,
  Edit3,
  Save,
  Undo2,
  Settings2
} from 'lucide-react';
import { CustomCoin, CoinAttachment } from '../../types/coinLaunch';
import { AuthSession } from '../../types/auth';
import { updateCustomCoinAttachments, updateCustomCoin } from '../../data/customCoinsData';

interface FinalCoinDetailsModalProps {
  coin: CustomCoin | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthSession | null;
  onOpenExchange?: (tokenSymbol?: string) => void;
  onOpenMintModal?: (coin: CustomCoin) => void;
  onCoinUpdated?: (updatedCoin: CustomCoin) => void;
}

export const FinalCoinDetailsModal: React.FC<FinalCoinDetailsModalProps> = ({
  coin,
  isOpen,
  onClose,
  currentUser,
  onOpenExchange,
  onOpenMintModal,
  onCoinUpdated
}) => {
  const [activeMediaIndex, setActiveMediaIndex] = useState(0);
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [mediaCaptionInput, setMediaCaptionInput] = useState('');
  const [mediaUrlInput, setMediaUrlInput] = useState('');
  const [showAddMediaDrawer, setShowAddMediaDrawer] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  
  // Metadata Editing State
  const [isEditingMetadata, setIsEditingMetadata] = useState(false);
  const [metadataForm, setMetadataForm] = useState({
    name: '',
    description: ''
  });

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Initialize form when editing starts or coin changes
  useEffect(() => {
    if (coin) {
      setMetadataForm({
        name: coin.name,
        description: coin.description || ''
      });
    }
  }, [coin, isEditingMetadata]);

  if (!isOpen || !coin) return null;

  const userId = currentUser?.id || 'guest';
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';
  const isCreator = coin.creatorId === userId || coin.creatorId === 'you' || isAdmin;

  // Aggregate attachments: prefer coin.attachments, fallback to coin.photos / coin.videos
  const attachments: CoinAttachment[] = (coin.attachments && coin.attachments.length > 0)
    ? coin.attachments
    : [
        ...(coin.photos || []).map((url, i) => ({
          id: `photo-${i}-${Date.now()}`,
          type: 'photo' as const,
          url,
          name: `Photo #${i + 1}`,
          uploadedAt: coin.createdAt,
          caption: `${coin.name} Project Photo`
        })),
        ...(coin.videos || []).map((url, i) => ({
          id: `video-${i}-${Date.now()}`,
          type: 'video' as const,
          url,
          name: `Video #${i + 1}`,
          uploadedAt: coin.createdAt,
          caption: `${coin.name} Presentation Video`
        }))
      ];

  const currentMedia = attachments[activeMediaIndex] || null;

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 3500);
  };

  const handleSaveMetadata = () => {
    if (!metadataForm.name.trim()) {
      showToast('Coin name cannot be empty.');
      return;
    }

    const res = updateCustomCoin(coin.id, metadataForm, userId);
    if (res.success && res.updatedCoin) {
      if (onCoinUpdated) onCoinUpdated(res.updatedCoin);
      setIsEditingMetadata(false);
      showToast('🎉 Project specifications updated successfully!');
    } else {
      showToast(res.message);
    }
  };

  // Handle Multi-file upload (Photos & Videos)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const newAttachments: CoinAttachment[] = [];
    let filesProcessed = 0;

    Array.from(files).forEach((file) => {
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isVideo && !isImage) {
        showToast('Please upload only images (JPG, PNG, WebP, GIF) or videos (MP4, WebM).');
        filesProcessed += 1;
        if (filesProcessed === files.length) setIsUploading(false);
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const fileSizeMB = (file.size / (1024 * 1024)).toFixed(1);
          newAttachments.push({
            id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            type: isVideo ? 'video' : 'photo',
            url: reader.result,
            name: file.name,
            size: `${fileSizeMB} MB`,
            uploadedAt: new Date().toISOString(),
            caption: mediaCaptionInput.trim() || file.name
          });
        }
        filesProcessed += 1;
        if (filesProcessed === files.length) {
          const updatedList = [...attachments, ...newAttachments];
          const res = updateCustomCoinAttachments(coin.id, updatedList, userId);
          if (res.success && res.updatedCoin) {
            if (onCoinUpdated) onCoinUpdated(res.updatedCoin);
            showToast(`🎉 Successfully attached ${newAttachments.length} media item(s).`);
            setMediaCaptionInput('');
            setShowAddMediaDrawer(false);
          }
          setIsUploading(false);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Handle adding media via URL
  const handleAddMediaViaUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaUrlInput.trim()) return;

    const url = mediaUrlInput.trim();
    const isVideo = !!url.match(/\.(mp4|webm|mov|ogg)($|\?)/i) || url.includes('video');
    const newAttachment: CoinAttachment = {
      id: `att-url-${Date.now()}`,
      type: isVideo ? 'video' : 'photo',
      url,
      name: isVideo ? 'Video Stream' : 'Image Link',
      uploadedAt: new Date().toISOString(),
      caption: mediaCaptionInput.trim() || 'Attached Media Link'
    };

    const updatedList = [...attachments, newAttachment];
    const res = updateCustomCoinAttachments(coin.id, updatedList, userId);
    if (res.success && res.updatedCoin) {
      if (onCoinUpdated) onCoinUpdated(res.updatedCoin);
      showToast('Media link attached successfully!');
      setMediaUrlInput('');
      setMediaCaptionInput('');
      setShowAddMediaDrawer(false);
    }
  };

  // Handle Delete Attachment
  const handleDeleteAttachment = (id: string) => {
    const updatedList = attachments.filter(a => a.id !== id);
    const res = updateCustomCoinAttachments(coin.id, updatedList, userId);
    if (res.success && res.updatedCoin) {
      if (onCoinUpdated) onCoinUpdated(res.updatedCoin);
      showToast('Media attachment removed.');
      if (activeMediaIndex >= updatedList.length) {
        setActiveMediaIndex(Math.max(0, updatedList.length - 1));
      }
    }
  };

  const handleNextMedia = () => {
    if (attachments.length === 0) return;
    setActiveMediaIndex((prev) => (prev + 1) % attachments.length);
  };

  const handlePrevMedia = () => {
    if (attachments.length === 0) return;
    setActiveMediaIndex((prev) => (prev - 1 + attachments.length) % attachments.length);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/40 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200 text-left">
      {/* Toast */}
      {toastMsg && (
        <div className="fixed top-6 right-6 z-60 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-2 text-xs font-mono animate-in slide-in-from-top-3 duration-200">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      <div className="relative w-full max-w-4xl bg-white rounded-3xl border border-slate-200/80 shadow-2xl overflow-hidden my-6 flex flex-col max-h-[92vh]">
        
        {/* MODAL TOP HEADER */}
        <div className="p-5 sm:p-6 bg-white text-slate-900 flex items-center justify-between border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${coin.logoBg} flex items-center justify-center text-xl font-bold shadow-md shrink-0`}>
              {coin.iconSymbol}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                {isEditingMetadata ? (
                  <input
                    type="text"
                    value={metadataForm.name}
                    onChange={(e) => setMetadataForm(prev => ({ ...prev, name: e.target.value }))}
                    className="px-2 py-1 border border-amber-300 rounded-lg text-lg font-serif font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-amber-50/30"
                  />
                ) : (
                  <h2 className="font-serif text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                    {coin.name}
                  </h2>
                )}
                <span className="px-2.5 py-0.5 rounded-lg bg-amber-50 text-amber-800 border border-amber-200 font-mono text-xs font-bold">
                  {coin.symbol}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                  Final Ledger L1
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>Created by {coin.creatorName}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isCreator && (
              <button
                type="button"
                onClick={() => isEditingMetadata ? handleSaveMetadata() : setIsEditingMetadata(true)}
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-sm ${
                  isEditingMetadata 
                  ? 'bg-emerald-500 hover:bg-emerald-400 text-white' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
                title={isEditingMetadata ? "Save Changes" : "Edit Coin Metadata"}
              >
                {isEditingMetadata ? <Save className="w-5 h-5" /> : <Edit3 className="w-4 h-4" />}
              </button>
            )}
            {isEditingMetadata && (
              <button
                type="button"
                onClick={() => setIsEditingMetadata(false)}
                className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-all cursor-pointer shadow-sm"
                title="Cancel Editing"
              >
                <Undo2 className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* SCROLLABLE BODY */}
        <div className="overflow-y-auto p-5 sm:p-6 space-y-8 flex-1 text-slate-800">

          {/* SECTION 1: PHOTOS & VIDEOS SHOWCASE */}
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center shadow-xs">
                  <ImageIcon className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <span>Project Media Showcase</span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                    {attachments.length} {attachments.length === 1 ? 'Asset' : 'Assets'}
                  </span>
                </h3>
              </div>

              {/* Creator Upload Action */}
              <div className="flex items-center gap-2">
                {isCreator && (
                  <button
                    type="button"
                    onClick={() => setShowAddMediaDrawer(!showAddMediaDrawer)}
                    className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Upload className="w-3.5 h-3.5 text-amber-600" />
                    <span>{showAddMediaDrawer ? 'Hide Media Uploader' : '+ Upload Photos / Videos'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* ADD MEDIA DRAWER */}
            {showAddMediaDrawer && (
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-950 uppercase flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>Attach New Photos &amp; Videos for {coin.symbol}</span>
                  </span>
                  <span className="text-[11px] text-amber-800 font-mono">PNG, JPG, SVG, MP4</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-4 rounded-xl bg-white border-2 border-dashed border-amber-300 hover:border-amber-500 transition-all text-center cursor-pointer space-y-1.5 shadow-xs"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      accept="image/*,video/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-700 mx-auto flex items-center justify-center">
                      <Upload className="w-4 h-4" />
                    </div>
                    <p className="text-xs font-bold text-slate-800">Click or Drag &amp; Drop</p>
                  </div>

                  <form onSubmit={handleAddMediaViaUrl} className="p-4 rounded-xl bg-white border border-amber-200 space-y-2 shadow-xs flex flex-col justify-between">
                    <div>
                      <label className="block text-[10px] font-bold uppercase text-slate-600 mb-1">Or Attach Media URL</label>
                      <input
                        type="url"
                        placeholder="https://example.com/photo.jpg"
                        value={mediaUrlInput}
                        onChange={(e) => setMediaUrlInput(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Caption (Optional)"
                        value={mediaCaptionInput}
                        onChange={(e) => setMediaCaptionInput(e.target.value)}
                        className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                      <button
                        type="submit"
                        disabled={!mediaUrlInput.trim()}
                        className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs disabled:opacity-50 cursor-pointer"
                      >
                        Attach
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* MEDIA VIEWER */}
            {attachments.length > 0 ? (
              <div className="space-y-4">
                <div className="relative rounded-2xl bg-slate-950 overflow-hidden border border-slate-800 min-h-[340px] max-h-[460px] flex items-center justify-center group shadow-md">
                  {currentMedia?.type === 'video' ? (
                    <video
                      ref={videoRef}
                      src={currentMedia.url}
                      controls
                      playsInline
                      className="max-h-[440px] max-w-full rounded-lg object-contain"
                    />
                  ) : (
                    <img
                      src={currentMedia?.url}
                      alt={currentMedia?.caption || currentMedia?.name}
                      referrerPolicy="no-referrer"
                      className="max-h-[440px] max-w-full object-contain mx-auto transition-transform duration-300"
                    />
                  )}

                  {attachments.length > 1 && (
                    <>
                      <button
                        type="button"
                        onClick={handlePrevMedia}
                        className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-slate-900/80 hover:bg-slate-900 text-white flex items-center justify-center backdrop-blur-md shadow-lg transition-all opacity-80 hover:opacity-100 cursor-pointer"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <button
                        type="button"
                        onClick={handleNextMedia}
                        className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-slate-900/80 hover:bg-slate-900 text-white flex items-center justify-center backdrop-blur-md shadow-lg transition-all opacity-80 hover:opacity-100 cursor-pointer"
                      >
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </>
                  )}

                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
                    <div className="px-3 py-1 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-700/60 text-white text-[10px] flex items-center gap-2 pointer-events-auto shadow-sm">
                      <span className="font-bold">{currentMedia?.caption || currentMedia?.name}</span>
                      <span className="text-slate-400 font-mono">({activeMediaIndex + 1}/{attachments.length})</span>
                    </div>
                    {isCreator && (
                      <button
                        type="button"
                        onClick={() => currentMedia && handleDeleteAttachment(currentMedia.id)}
                        className="p-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-700/60 backdrop-blur-md transition-colors cursor-pointer pointer-events-auto shadow-sm"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
                
                {attachments.length > 1 && (
                  <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
                    {attachments.map((item, index) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setActiveMediaIndex(index)}
                        className={`relative w-14 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer ${
                          activeMediaIndex === index ? 'border-amber-500 scale-105 shadow-md' : 'border-slate-100 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img src={item.url} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        {item.type === 'video' && <div className="absolute inset-0 bg-black/40 flex items-center justify-center"><Video className="w-4 h-4 text-white" /></div>}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="p-10 rounded-3xl bg-slate-50 border border-dashed border-slate-200 text-center space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-white border border-slate-200 mx-auto flex items-center justify-center text-slate-300 shadow-xs">
                  <ImageIcon className="w-7 h-7" />
                </div>
                <div className="max-w-xs mx-auto space-y-1">
                  <h4 className="text-sm font-bold text-slate-800">Visual Treasury Empty</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">No photos or videos have been attached to this sovereign asset yet.</p>
                </div>
                {isCreator && (
                  <button
                    type="button"
                    onClick={() => setShowAddMediaDrawer(true)}
                    className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold inline-flex items-center gap-2 shadow-sm transition-all active:scale-95 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Initialize Showcase</span>
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 pt-2">
            {/* PROJECT OVERVIEW SECTION */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 flex items-center justify-center shadow-xs">
                  <FileText className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">Project Vision &amp; Identity</h3>
              </div>
              
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Sovereign Description</label>
                  {isEditingMetadata ? (
                    <textarea
                      value={metadataForm.description}
                      onChange={(e) => setMetadataForm(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full h-32 px-3 py-2 text-xs rounded-xl border border-amber-200 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-amber-50/20 resize-none font-sans"
                      placeholder="Describe your project's goals, mission, and long-term roadmap..."
                    />
                  ) : (
                    <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                      {coin.description || "No description provided for this Final Coin."}
                    </p>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-50 space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Creator Information</label>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border border-slate-200 shrink-0 shadow-xs">
                      {coin.creatorAvatar ? <img src={coin.creatorAvatar} className="w-full h-full object-cover" /> : <User className="w-5 h-5 text-slate-400" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{coin.creatorName}</p>
                      <p className="text-xs text-slate-500 font-mono">@{coin.creatorHandle}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SUPPLY METRICS SECTION */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-50 border border-purple-200 text-purple-700 flex items-center justify-center shadow-xs">
                <Layers className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">On-Chain Supply Distribution</h3>
            </div>

            <div className="max-w-md">
              <div className="p-5 rounded-2xl bg-slate-900 text-white space-y-1.5 shadow-lg border border-slate-800">
                <span className="text-[10px] font-mono font-bold uppercase text-slate-500 tracking-widest block">Circulating Supply</span>
                <p className="font-mono font-extrabold text-2xl tracking-tighter">
                  {coin.circulatingSupply.toLocaleString()}
                </p>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{coin.symbol} Sovereign Units Liquid</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* MODAL FOOTER ACTIONS */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3 shrink-0">
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer"
            >
              Close Window
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

