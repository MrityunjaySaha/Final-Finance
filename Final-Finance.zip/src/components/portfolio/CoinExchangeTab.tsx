import React, { useState, useEffect, useMemo } from 'react';
import {
  Coins,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Flame,
  ArrowLeftRight,
  Search
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { getStoredUserWallets, saveStoredUserWallets } from '../../data/defaultWallets';
import { getStoredCustomCoins, saveCustomCoins } from '../../data/customCoinsData';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { dispatchGlobalNotification } from '../../utils/notificationService';
import { CustomCoin } from '../../types/coinLaunch';

interface CoinExchangeTabProps {
  currentUser: AuthSession | null;
  sovereignOnly?: boolean;
}

type ExchangeMode = 'admin_to_own' | 'peer_to_own';

export const CoinExchangeTab: React.FC<CoinExchangeTabProps> = ({ currentUser }) => {
  const userId = currentUser?.id || 'guest';
  const userUid = currentUser?.uid || '';
  const userHandle = currentUser?.username || '';
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  const [walletData, setWalletData] = useState(() => getStoredUserWallets(userId));
  const [customCoins, setCustomCoins] = useState<CustomCoin[]>(() => getStoredCustomCoins());

  const [activeExchangeMode, setActiveExchangeMode] = useState<ExchangeMode>('admin_to_own');

  // Sync wallet & custom coins when updated elsewhere
  useEffect(() => {
    const handleSync = () => {
      setWalletData(getStoredUserWallets(userId));
      setCustomCoins(getStoredCustomCoins());
    };
    handleSync();
    window.addEventListener('final_finance_wallets_updated', handleSync);
    window.addEventListener('final_finance_custom_coins_updated', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('final_finance_wallets_updated', handleSync);
      window.removeEventListener('final_finance_custom_coins_updated', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, [userId]);

  // Identify coins owned/created by the current user (up to 5 final currencies)
  const isCoinOwnedByUser = (c: CustomCoin) => {
    if (c.coinType !== 'final_coin') return false;
    const matchesOwner =
      c.creatorId === userId ||
      (Boolean(userUid) && c.creatorId === userUid) ||
      (Boolean(userHandle) && c.creatorHandle === userHandle) ||
      c.creatorId === 'you' ||
      c.creatorHandle === 'sovereign_builder';

    if (isAdmin) {
      return Boolean(c.isAdminCoin || matchesOwner);
    }
    return matchesOwner && !c.isAdminCoin;
  };

  // All platform Final Currencies
  const allPlatformFinalCoins = useMemo(() => {
    return customCoins.filter((c) => c.coinType === 'final_coin');
  }, [customCoins]);

  // User's created Final Currencies (up to 5, excluding AFNL so AFNL is strictly source in Tab 1)
  const myCreatedFinalCoins = useMemo(() => {
    return allPlatformFinalCoins.filter(
      (c) => isCoinOwnedByUser(c) && c.symbol.toUpperCase() !== 'AFNL'
    );
  }, [allPlatformFinalCoins, userId, userUid, userHandle, isAdmin]);

  // All Final Currencies the user currently holds in their wallet (including their 5 created coins, AFNL, and any others)
  const heldFinalCoins = useMemo(() => {
    const walletFinals = walletData.finalCoins || [];
    return walletFinals.filter((fc: any) => {
      const sym = (fc.symbol || '').trim();
      return Boolean(sym) && Number(fc.balance || 0) > 0;
    });
  }, [walletData.finalCoins]);

  // --- TAB 1 STATE: Admin Final Coin (AFNL) -> User's Created Final Currency ---
  const [adminTargetSymbol, setAdminTargetSymbol] = useState<string>('');
  const [adminTargetSearch, setAdminTargetSearch] = useState<string>('');
  const [adminAmount, setAdminAmount] = useState<string>('1000');

  // --- TAB 2 STATE: Any Held Final Currency -> Any Platform Final Currency ---
  const [peerSourceSymbol, setPeerSourceSymbol] = useState<string>('');
  const [peerSourceSearch, setPeerSourceSearch] = useState<string>('');
  const [peerTargetSymbol, setPeerTargetSymbol] = useState<string>('');
  const [peerTargetSearch, setPeerTargetSearch] = useState<string>('');
  const [peerAmount, setPeerAmount] = useState<string>('1000');

  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filtered lists from small search inputs
  const filteredMyCreatedFinalCoins = useMemo(() => {
    const q = adminTargetSearch.trim().toLowerCase();
    if (!q) return myCreatedFinalCoins;
    return myCreatedFinalCoins.filter(
      (c) => c.symbol.toLowerCase().includes(q) || c.name.toLowerCase().includes(q)
    );
  }, [myCreatedFinalCoins, adminTargetSearch]);

  const filteredHeldFinalCoins = useMemo(() => {
    const q = peerSourceSearch.trim().toLowerCase();
    if (!q) return heldFinalCoins;
    return heldFinalCoins.filter(
      (fc: any) =>
        (fc.symbol || '').toLowerCase().includes(q) ||
        (fc.name || '').toLowerCase().includes(q)
    );
  }, [heldFinalCoins, peerSourceSearch]);

  const availablePlatformTargets = useMemo(() => {
    return allPlatformFinalCoins.filter(
      (c) => c.symbol.toUpperCase() !== peerSourceSymbol.toUpperCase()
    );
  }, [allPlatformFinalCoins, peerSourceSymbol]);

  const filteredPlatformTargets = useMemo(() => {
    const q = peerTargetSearch.trim().toLowerCase();
    if (!q) return availablePlatformTargets;
    return availablePlatformTargets.filter(
      (c) => c.symbol.toLowerCase().includes(q) || c.name.toLowerCase().includes(q)
    );
  }, [availablePlatformTargets, peerTargetSearch]);

  // Keep Tab 1 target synced to filtered user's created Final Coins
  useEffect(() => {
    if (filteredMyCreatedFinalCoins.length > 0) {
      if (!filteredMyCreatedFinalCoins.some((c) => c.symbol === adminTargetSymbol)) {
        setAdminTargetSymbol(filteredMyCreatedFinalCoins[0].symbol);
      }
    } else if (myCreatedFinalCoins.length === 0) {
      setAdminTargetSymbol('');
    }
  }, [filteredMyCreatedFinalCoins, myCreatedFinalCoins.length, adminTargetSymbol]);

  // Keep Tab 2 source synced to held final coins
  useEffect(() => {
    if (filteredHeldFinalCoins.length > 0) {
      if (
        !filteredHeldFinalCoins.some(
          (fc: any) => (fc.symbol || '').toUpperCase() === peerSourceSymbol.toUpperCase()
        )
      ) {
        setPeerSourceSymbol(filteredHeldFinalCoins[0].symbol);
      }
    } else if (heldFinalCoins.length === 0) {
      setPeerSourceSymbol('');
    }
  }, [filteredHeldFinalCoins, heldFinalCoins.length, peerSourceSymbol]);

  // Keep Tab 2 target synced to available platform final coins
  useEffect(() => {
    if (filteredPlatformTargets.length > 0) {
      if (
        !filteredPlatformTargets.some(
          (c) => c.symbol.toUpperCase() === peerTargetSymbol.toUpperCase()
        )
      ) {
        setPeerTargetSymbol(filteredPlatformTargets[0].symbol);
      }
    } else if (availablePlatformTargets.length === 0) {
      setPeerTargetSymbol('');
    }
  }, [filteredPlatformTargets, availablePlatformTargets.length, peerTargetSymbol]);

  const getWalletFinalBalance = (symbol: string): number => {
    if (!symbol) return 0;
    const found = walletData.finalCoins?.find(
      (fc: any) => (fc.symbol || '').toUpperCase() === symbol.toUpperCase()
    );
    return found ? Number(found.balance || 0) : 0;
  };

  // --- EXECUTE TAB 1: Swap Admin Final Coin (AFNL) -> User's Created Final Currency ---
  const handleExecuteAdminFinalExchange = () => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!adminTargetSymbol) {
      setErrorMsg('You must create a Final Coin first (up to 5) before you can swap AFNL for more supply.');
      return;
    }

    const amount = parseFloat(adminAmount);
    if (isNaN(amount) || amount <= 0) {
      setErrorMsg('Please enter a valid positive exchange amount for Final Admin Coin.');
      return;
    }
    if (adminTargetSymbol.toUpperCase() === 'AFNL') {
      setErrorMsg('Target cannot be AFNL when converting from Admin AFNL balance.');
      return;
    }

    const afnlBalance = getWalletFinalBalance('AFNL');
    if (amount > afnlBalance) {
      setErrorMsg(`Insufficient AFNL balance. You have ${afnlBalance.toLocaleString()} AFNL available.`);
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const updatedWallet = getStoredUserWallets(userId);
        const receivedAmount = amount; // 1:1 parity

        let afnlIdx = updatedWallet.finalCoins.findIndex(
          (fc: any) => fc.symbol.toUpperCase() === 'AFNL'
        );
        if (afnlIdx === -1) {
          updatedWallet.finalCoins.push({
            id: `fc-afnl-${Date.now()}`,
            name: 'Final Admin Coin',
            symbol: 'AFNL',
            balance: 0,
            unitPriceUSD: 0,
            change24h: 0.0,
            utility: 'Sovereign Final Currency'
          });
          afnlIdx = updatedWallet.finalCoins.length - 1;
        }

        const latestCustomCoins = getStoredCustomCoins();
        const targetCoinObj = latestCustomCoins.find(
          (c) => c.symbol.toUpperCase() === adminTargetSymbol.toUpperCase()
        );

        let tgtIdx = updatedWallet.finalCoins.findIndex(
          (fc: any) => fc.symbol.toUpperCase() === adminTargetSymbol.toUpperCase()
        );
        if (tgtIdx === -1) {
          updatedWallet.finalCoins.push({
            id: `fc-tgt-${Date.now()}`,
            name: targetCoinObj?.name || `${adminTargetSymbol} Final Coin`,
            symbol: adminTargetSymbol,
            balance: 0,
            unitPriceUSD: 0,
            change24h: 0.0,
            utility: 'Sovereign Final Currency',
            contractAddress: targetCoinObj?.contractAddress
          });
          tgtIdx = updatedWallet.finalCoins.length - 1;
        }

        updatedWallet.finalCoins[afnlIdx].balance = Math.max(
          0,
          updatedWallet.finalCoins[afnlIdx].balance - amount
        );
        updatedWallet.finalCoins[tgtIdx].balance += receivedAmount;

        saveStoredUserWallets(userId, updatedWallet);
        setWalletData(updatedWallet);

        const nextCustomCoins = latestCustomCoins.map((c) => {
          const sym = c.symbol.toUpperCase();
          if (sym === adminTargetSymbol.toUpperCase()) {
            return {
              ...c,
              totalSupply: (c.totalSupply || 0) + receivedAmount,
              circulatingSupply: (c.circulatingSupply || 0) + receivedAmount
            };
          }
          if (sym === 'AFNL') {
            return {
              ...c,
              circulatingSupply: Math.max(0, (c.circulatingSupply || 0) - amount),
              burnedSupply: (c.burnedSupply || 0) + amount
            };
          }
          return c;
        });
        saveCustomCoins(nextCustomCoins);
        setCustomCoins(nextCustomCoins);

        recordLedgerTransaction(userId, {
          id: `ledger-adm-${Date.now()}`,
          receiptNumber: `REC-ADM-${Date.now()}`,
          taxYear: 2026,
          timestamp: new Date().toISOString(),
          dateIso: new Date().toISOString(),
          type: 'vault_swap',
          category: 'transfer',
          mode: 'final_coin',
          title: `Final Admin Coin Swap: -${amount.toLocaleString()} AFNL → +${receivedAmount.toLocaleString()} ${adminTargetSymbol}`,
          description: `Swapped ${amount.toLocaleString()} AFNL for ${receivedAmount.toLocaleString()} ${adminTargetSymbol} at 1:1 parity, expanding ${adminTargetSymbol} supply.`,
          amountUSD: 0,
          feeUSD: 0,
          netAmountUSD: 0,
          sourceOrDestination: `Admin Swap Desk (AFNL to ${adminTargetSymbol})`,
          counterpartyOrIssuer: 'Final Finance Protocol',
          paymentCoinSymbol: adminTargetSymbol,
          paymentCoinAmount: receivedAmount,
          status: 'Settled',
          clearingNode: 'Final Ledger Subnet',
          cryptographicHash: `0xHASH${Date.now()}`,
          signature: `SIG-ADM-${Date.now()}`,
          taxClassification: {
            formMapping: 'Non-Taxable Transfer',
            taxableEvent: false,
            taxableAmountUSD: 0,
            irsCategoryNote: 'Final admin coin swap into creator currency supply'
          }
        });

        setSuccessMsg(
          `Successfully swapped ${amount.toLocaleString()} AFNL for +${receivedAmount.toLocaleString()} ${adminTargetSymbol} at 1:1 parity. ${adminTargetSymbol} supply & circulation updated everywhere!`
        );
        dispatchGlobalNotification({
          title: `Final Coin Swap: AFNL → ${adminTargetSymbol}`,
          description: `Swapped ${amount.toLocaleString()} AFNL for ${receivedAmount.toLocaleString()} ${adminTargetSymbol} at 1:1 sovereign parity.`,
          type: 'wallet',
          targetTab: 'wallets',
          amount: receivedAmount,
          currency: adminTargetSymbol,
          tone: 'trade'
        });
      } catch (err: any) {
        setErrorMsg(err.message || 'Admin exchange failed.');
      } finally {
        setIsSubmitting(false);
      }
    }, 400);
  };

  // --- EXECUTE TAB 2: Swap Any Held Final Currency -> Any Platform Final Currency (Destroys Source & Updates Circulation) ---
  const handleExecutePeerFinalExchange = () => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!peerSourceSymbol) {
      setErrorMsg('You do not hold any Final Currencies available to swap.');
      return;
    }
    if (!peerTargetSymbol) {
      setErrorMsg('Please select a target Final Currency on the platform.');
      return;
    }

    const amount = parseFloat(peerAmount);
    if (isNaN(amount) || amount <= 0) {
      setErrorMsg('Please enter a valid positive exchange amount.');
      return;
    }
    if (peerSourceSymbol.toUpperCase() === peerTargetSymbol.toUpperCase()) {
      setErrorMsg('Source and target final currencies must be different.');
      return;
    }

    const sourceBalance = getWalletFinalBalance(peerSourceSymbol);
    if (amount > sourceBalance) {
      setErrorMsg(`Insufficient ${peerSourceSymbol} balance. You have ${sourceBalance.toLocaleString()} available.`);
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const updatedWallet = getStoredUserWallets(userId);
        const receivedAmount = amount; // 1:1 parity ratio

        // 1. Deduct from held source final coin in user's wallet
        const srcIdx = updatedWallet.finalCoins.findIndex(
          (fc: any) => fc.symbol.toUpperCase() === peerSourceSymbol.toUpperCase()
        );
        if (srcIdx !== -1) {
          updatedWallet.finalCoins[srcIdx].balance = Math.max(
            0,
            updatedWallet.finalCoins[srcIdx].balance - amount
          );
        }

        const latestCustomCoins = getStoredCustomCoins();
        const targetCoinObj = latestCustomCoins.find(
          (c) => c.symbol.toUpperCase() === peerTargetSymbol.toUpperCase()
        );

        // 2. Credit target final coin in user's wallet
        const tgtIdx = updatedWallet.finalCoins.findIndex(
          (fc: any) => fc.symbol.toUpperCase() === peerTargetSymbol.toUpperCase()
        );
        if (tgtIdx !== -1) {
          updatedWallet.finalCoins[tgtIdx].balance += receivedAmount;
        } else {
          updatedWallet.finalCoins.push({
            id: `fc-tgt-${Date.now()}`,
            name: targetCoinObj?.name || `${peerTargetSymbol} Final Coin`,
            symbol: peerTargetSymbol,
            balance: receivedAmount,
            unitPriceUSD: 0,
            change24h: 0.0,
            utility: 'Sovereign Final Currency',
            contractAddress: targetCoinObj?.contractAddress
          });
        }

        saveStoredUserWallets(userId, updatedWallet);
        setWalletData(updatedWallet);

        // 3. Destroy the swapped source amount & update target circulation everywhere
        const nextCustomCoins = latestCustomCoins.map((c) => {
          const sym = c.symbol.toUpperCase();
          if (sym === peerSourceSymbol.toUpperCase()) {
            return {
              ...c,
              totalSupply: Math.max(0, (c.totalSupply || 0) - amount),
              circulatingSupply: Math.max(0, (c.circulatingSupply || 0) - amount),
              burnedSupply: (c.burnedSupply || 0) + amount
            };
          }
          if (sym === peerTargetSymbol.toUpperCase()) {
            return {
              ...c,
              totalSupply: (c.totalSupply || 0) + receivedAmount,
              circulatingSupply: (c.circulatingSupply || 0) + receivedAmount
            };
          }
          return c;
        });

        saveCustomCoins(nextCustomCoins);
        setCustomCoins(nextCustomCoins);

        recordLedgerTransaction(userId, {
          id: `ledger-fx-${Date.now()}`,
          receiptNumber: `REC-FX-${Date.now()}`,
          taxYear: 2026,
          timestamp: new Date().toISOString(),
          dateIso: new Date().toISOString(),
          type: 'vault_swap',
          category: 'transfer',
          mode: 'final_coin',
          title: `Final Coin Conversion: Destroyed ${amount.toLocaleString()} ${peerSourceSymbol} → +${receivedAmount.toLocaleString()} ${peerTargetSymbol}`,
          description: `Converted and destroyed ${amount.toLocaleString()} ${peerSourceSymbol} into +${receivedAmount.toLocaleString()} ${peerTargetSymbol} at 1:1 parity. Circulation updated across the protocol.`,
          amountUSD: 0,
          feeUSD: 0,
          netAmountUSD: 0,
          sourceOrDestination: `Final Exchange Desk (${peerSourceSymbol} destroyed → ${peerTargetSymbol})`,
          counterpartyOrIssuer: 'Final Finance Protocol',
          paymentCoinSymbol: peerTargetSymbol,
          paymentCoinAmount: receivedAmount,
          status: 'Settled',
          clearingNode: 'Final Ledger Subnet',
          cryptographicHash: `0xHASH${Date.now()}`,
          signature: `SIG-FX-${Date.now()}`,
          taxClassification: {
            formMapping: 'Non-Taxable Transfer',
            taxableEvent: false,
            taxableAmountUSD: 0,
            irsCategoryNote: 'Peer final coin conversion with source burn'
          }
        });

        setSuccessMsg(
          `Successfully swapped ${amount.toLocaleString()} ${peerSourceSymbol} (destroyed from circulation) for +${receivedAmount.toLocaleString()} ${peerTargetSymbol}! Circulation updated everywhere.`
        );
        dispatchGlobalNotification({
          title: `Final Coin Swap: ${peerSourceSymbol} → ${peerTargetSymbol}`,
          description: `Destroyed ${amount.toLocaleString()} ${peerSourceSymbol} and added ${receivedAmount.toLocaleString()} ${peerTargetSymbol} at 1:1 parity.`,
          type: 'wallet',
          targetTab: 'wallets',
          amount: receivedAmount,
          currency: peerTargetSymbol,
          tone: 'trade'
        });
      } catch (err: any) {
        setErrorMsg(err.message || 'Exchange failed.');
      } finally {
        setIsSubmitting(false);
      }
    }, 400);
  };

  const selectedSourceCoinInfo = useMemo(() => {
    if (!peerSourceSymbol) return null;
    return customCoins.find((c) => c.symbol.toUpperCase() === peerSourceSymbol.toUpperCase()) || null;
  }, [customCoins, peerSourceSymbol]);

  const selectedAdminTargetCoinInfo = useMemo(() => {
    if (!adminTargetSymbol) return null;
    return customCoins.find((c) => c.symbol.toUpperCase() === adminTargetSymbol.toUpperCase()) || null;
  }, [customCoins, adminTargetSymbol]);

  const selectedPeerTargetCoinInfo = useMemo(() => {
    if (!peerTargetSymbol) return null;
    return customCoins.find((c) => c.symbol.toUpperCase() === peerTargetSymbol.toUpperCase()) || null;
  }, [customCoins, peerTargetSymbol]);

  const parsedAdminAmount = parseFloat(adminAmount || '0') || 0;
  const parsedPeerAmount = parseFloat(peerAmount || '0') || 0;

  return (
    <div className="space-y-6 max-w-4xl mx-auto text-center">
      {/* 2-Tab Swap Mode Selector */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-200/70 p-1.5 rounded-2xl max-w-2xl mx-auto">
        <button
          type="button"
          onClick={() => {
            setActiveExchangeMode('admin_to_own');
            setErrorMsg(null);
            setSuccessMsg(null);
          }}
          className={`py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeExchangeMode === 'admin_to_own'
              ? 'bg-white text-slate-900 shadow-md'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Coins className="w-4 h-4 text-amber-600 shrink-0" />
          <span>1. Admin Coin → Your Final Coin</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveExchangeMode('peer_to_own');
            setErrorMsg(null);
            setSuccessMsg(null);
          }}
          className={`py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeExchangeMode === 'peer_to_own'
              ? 'bg-white text-slate-900 shadow-md'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ArrowLeftRight className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>2. Cross-Swap Final Currencies</span>
        </button>
      </div>

      {/* --- TAB 1: SWAP ADMIN FINAL COIN (AFNL) FOR USER'S CREATED FINAL CURRENCY --- */}
      {activeExchangeMode === 'admin_to_own' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xl space-y-6 overflow-hidden">
          <div className="flex flex-col items-center justify-center text-center pb-4 border-b border-slate-100 gap-2">
            <h3 className="text-base font-bold text-slate-900">
              Final Coin Swap (Sovereign Unit Parity)
            </h3>
            <div className="px-3.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-mono font-bold tabular-nums">
              AFNL Balance: {getWalletFinalBalance('AFNL').toLocaleString()}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch text-left">
            {/* AFNL Fixed Source */}
            <div className="space-y-3 p-5 rounded-2xl bg-amber-50/70 border border-amber-200 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-mono font-bold text-amber-900 uppercase">Source Admin Coin</span>
                  <span className="text-[11px] font-mono text-amber-700 font-bold tabular-nums">
                    Available: {getWalletFinalBalance('AFNL').toLocaleString()} AFNL
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0">
                    AFNL
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="w-full px-3 py-2.5 rounded-xl bg-white border border-amber-300 font-mono font-bold text-xs text-slate-900 flex items-center justify-between gap-2">
                      <span className="truncate">AFNL (Final Admin Coin)</span>
                      <span className="text-[10px] bg-amber-100 px-2 py-0.5 rounded text-amber-900 font-bold whitespace-nowrap shrink-0">
                        Fixed Source
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <input
                  type="number"
                  min="1"
                  value={adminAmount}
                  onChange={(e) => setAdminAmount(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-amber-300 font-mono font-bold text-base text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500 tabular-nums"
                  placeholder="Enter AFNL amount..."
                />
              </div>
            </div>

            {/* Target Final Coin (Any of the 5 Final Currencies the user has created + small search) */}
            <div className="space-y-3 p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex flex-col justify-between">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-mono font-bold text-emerald-900 uppercase">
                    Target Final Currency
                  </span>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold">
                    1:1 Parity Ratio
                  </span>
                </div>

                {/* Small Search Input for Target Created Coins */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-emerald-600 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={adminTargetSearch}
                    onChange={(e) => setAdminTargetSearch(e.target.value)}
                    placeholder="Search your created coins..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-white border border-emerald-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0 px-1 truncate">
                    {adminTargetSymbol || '-'}
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <select
                      value={adminTargetSymbol}
                      onChange={(e) => setAdminTargetSymbol(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white border border-emerald-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    >
                      {filteredMyCreatedFinalCoins.map((c, idx) => (
                        <option key={`${c.id || c.symbol}-${idx}`} value={c.symbol}>
                          {c.symbol} ({c.name})
                        </option>
                      ))}
                      {myCreatedFinalCoins.length === 0 && (
                        <option value="">No Final Coins Created</option>
                      )}
                      {myCreatedFinalCoins.length > 0 && filteredMyCreatedFinalCoins.length === 0 && (
                        <option value="">No matching created coins</option>
                      )}
                    </select>
                    {selectedAdminTargetCoinInfo && (
                      <p className="text-[10px] font-mono text-emerald-800 tabular-nums truncate">
                        Current Supply: {selectedAdminTargetCoinInfo.totalSupply.toLocaleString()} {selectedAdminTargetCoinInfo.symbol}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              <div>
                <div className="w-full px-4 py-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300 font-mono font-extrabold text-base text-emerald-950 flex items-center justify-between gap-2 tabular-nums">
                  <span className="truncate">
                    {parsedAdminAmount.toLocaleString()} {adminTargetSymbol || ''}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-600 text-white whitespace-nowrap shrink-0">
                    1:1 Parity
                  </span>
                </div>
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center justify-center gap-2 text-left">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-center gap-2 text-left">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="leading-relaxed">{successMsg}</span>
            </div>
          )}

          <div className="pt-2 flex justify-center">
            <button
              type="button"
              disabled={isSubmitting || !adminTargetSymbol}
              onClick={handleExecuteAdminFinalExchange}
              className="w-full sm:w-auto max-w-full px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2 text-center whitespace-normal leading-snug"
            >
              {isSubmitting ? (
                <span>Processing Swap...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <span className="break-words">
                    Execute Final Protocol Swap ({parsedAdminAmount.toLocaleString()} AFNL → {adminTargetSymbol || 'Your Coin'})
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* --- TAB 2: CONVERT ANY HELD FINAL CURRENCY -> ANY PLATFORM FINAL CURRENCY --- */}
      {activeExchangeMode === 'peer_to_own' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xl space-y-6 overflow-hidden">
          <div className="flex flex-col items-center justify-center text-center pb-4 border-b border-slate-100 gap-2">
            <h3 className="text-base font-bold text-slate-900">Peer Final Coin Cross-Swap</h3>
            <div className="px-3.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono font-bold">
              1:1 Sovereign Parity
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch text-left">
            {/* Convert From: Any Final Currency the user has (including their 5 created coins) + small search */}
            <div className="space-y-3 p-5 rounded-2xl bg-rose-50/60 border border-rose-200 flex flex-col justify-between">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-mono font-bold text-rose-900 uppercase flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                    <span>Convert From</span>
                  </span>
                  <span className="text-[11px] font-mono text-rose-700 font-bold tabular-nums">
                    Available: {getWalletFinalBalance(peerSourceSymbol).toLocaleString()} {peerSourceSymbol}
                  </span>
                </div>

                {/* Small Search Input for Source Coins */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-rose-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={peerSourceSearch}
                    onChange={(e) => setPeerSourceSearch(e.target.value)}
                    placeholder="Search coins you hold..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-white border border-rose-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0 px-1 truncate">
                    {peerSourceSymbol || '-'}
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <select
                      value={peerSourceSymbol}
                      onChange={(e) => setPeerSourceSymbol(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white border border-rose-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                    >
                      {filteredHeldFinalCoins.map((fc: any, idx: number) => (
                        <option key={`${fc.id || fc.symbol}-${idx}`} value={fc.symbol}>
                          {fc.symbol} ({fc.name}) — {Number(fc.balance || 0).toLocaleString()}
                        </option>
                      ))}
                      {heldFinalCoins.length === 0 && (
                        <option value="">No Final Coins Held</option>
                      )}
                      {heldFinalCoins.length > 0 && filteredHeldFinalCoins.length === 0 && (
                        <option value="">No matching held coins</option>
                      )}
                    </select>
                    {selectedSourceCoinInfo && (
                      <p className="text-[10px] font-mono text-rose-800 tabular-nums truncate">
                        In Circulation: {selectedSourceCoinInfo.circulatingSupply.toLocaleString()} {selectedSourceCoinInfo.symbol}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              <div>
                <input
                  type="number"
                  min="1"
                  value={peerAmount}
                  onChange={(e) => setPeerAmount(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-white border border-rose-300 font-mono font-bold text-base text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-rose-500 tabular-nums"
                  placeholder="Enter amount to swap..."
                />
              </div>
            </div>

            {/* Exchange To: Any Final Currency on our platform + small search */}
            <div className="space-y-3 p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex flex-col justify-between">
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-mono font-bold text-emerald-900 uppercase">
                    Exchange To
                  </span>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold">
                    1:1 Parity Ratio
                  </span>
                </div>

                {/* Small Search Input for All Platform Final Currencies */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-emerald-600 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={peerTargetSearch}
                    onChange={(e) => setPeerTargetSearch(e.target.value)}
                    placeholder="Search any platform final coin..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-white border border-emerald-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-extrabold text-xs shadow-xs shrink-0 px-1 truncate">
                    {peerTargetSymbol || '-'}
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <select
                      value={peerTargetSymbol}
                      onChange={(e) => setPeerTargetSymbol(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white border border-emerald-300 font-mono font-bold text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    >
                      {filteredPlatformTargets.map((c, idx) => (
                        <option key={`${c.id || c.symbol}-${idx}`} value={c.symbol}>
                          {c.symbol} ({c.name})
                        </option>
                      ))}
                      {availablePlatformTargets.length === 0 && (
                        <option value="">No Other Final Coins Available</option>
                      )}
                      {availablePlatformTargets.length > 0 && filteredPlatformTargets.length === 0 && (
                        <option value="">No matching platform coins</option>
                      )}
                    </select>
                    {selectedPeerTargetCoinInfo && (
                      <p className="text-[10px] font-mono text-emerald-800 tabular-nums truncate">
                        In Circulation: {selectedPeerTargetCoinInfo.circulatingSupply.toLocaleString()} {selectedPeerTargetCoinInfo.symbol}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <div className="w-full px-4 py-2.5 rounded-xl bg-emerald-100/60 border border-emerald-300 font-mono font-extrabold text-base text-emerald-950 flex items-center justify-between gap-2 tabular-nums">
                  <span className="truncate">
                    {parsedPeerAmount.toLocaleString()} {peerTargetSymbol || '-'}
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-600 text-white whitespace-nowrap shrink-0">
                    1:1 Parity
                  </span>
                </div>
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center justify-center gap-2 text-left">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-center gap-2 text-left">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="leading-relaxed">{successMsg}</span>
            </div>
          )}

          <div className="pt-2 flex justify-center">
            <button
              type="button"
              disabled={isSubmitting || !peerSourceSymbol || !peerTargetSymbol}
              onClick={handleExecutePeerFinalExchange}
              className="w-full sm:w-auto max-w-full px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2 text-center whitespace-normal leading-snug"
            >
              {isSubmitting ? (
                <span>Processing Exchange...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <span className="break-words">
                    Execute Cross-Exchange ({parsedPeerAmount.toLocaleString()} {peerSourceSymbol || 'Source'} → {peerTargetSymbol || 'Target'})
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
