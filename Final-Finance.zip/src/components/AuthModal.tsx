import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  X,
  AlertCircle,
  ShieldCheck,
  Sparkles,
  Mail,
  User,
  AtSign,
  KeyRound,
  ArrowRight,
  Loader2,
  CheckCircle2,
  Eye,
  EyeOff,
  BookmarkCheck,
  Trash2,
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { GoogleAuthButton } from './GoogleAuthButton';
import { GoogleAccountChooserModal } from './GoogleAccountChooserModal';
import {
  signInWithCredentials,
  registerWithCredentials,
  requestPasswordReset,
  getRememberedAccounts,
  rememberAccountOnDevice,
  forgetRememberedAccount,
  signInWithRememberedAccount,
  storeBrowserCredential,
  RememberedAccount,
} from '../services/firebaseAuth';

interface AuthModalProps {
  initialView: 'signin' | 'signup';
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: AuthSession) => void;
}

type AuthTab = 'signin' | 'signup' | 'forgot';

export const AuthModal: React.FC<AuthModalProps> = ({
  initialView,
  isOpen,
  onClose,
  onAuthSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<AuthTab>(initialView === 'signup' ? 'signup' : 'signin');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isChooserOpen, setIsChooserOpen] = useState(false);
  const [rememberOnDevice, setRememberOnDevice] = useState(true);
  const [rememberedAccounts, setRememberedAccounts] = useState<RememberedAccount[]>([]);
  const [showSignInPassword, setShowSignInPassword] = useState(false);
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);

  // Form Fields
  const [emailOrUserId, setEmailOrUserId] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [signUpUserId, setSignUpUserId] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [resetIdentifier, setResetIdentifier] = useState('');

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialView === 'signup' ? 'signup' : 'signin');
      setRememberedAccounts(getRememberedAccounts());
      setErrorMessage('');
      setSuccessMessage('');
    }
  }, [isOpen, initialView]);

  useEffect(() => {
    if (isOpen) {
      setRememberedAccounts(getRememberedAccounts());
    }
  }, [isOpen, isChooserOpen]);

  if (!isOpen) return null;

  const handleQuickRememberedSignIn = async (email: string) => {
    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = await signInWithRememberedAccount(email);
      if (res.success && res.user) {
        onAuthSuccess(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Could not restore saved session. Please sign in with your password.');
      }
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Sign in failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForgetAccount = (e: React.MouseEvent, email: string) => {
    e.stopPropagation();
    forgetRememberedAccount(email);
    setRememberedAccounts(getRememberedAccounts());
  };

  const handleCredentialsSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrUserId.trim() || !password) {
      setErrorMessage('Please enter both your Email / User ID and Password.');
      return;
    }
    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = await signInWithCredentials(emailOrUserId, password, { rememberOnDevice });
      if (res.success && res.user) {
        onAuthSuccess(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Sign in failed. Please check your credentials.');
      }
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Sign in encountered an error.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCredentialsSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreedToTerms) {
      setErrorMessage(
        'Agreement required: You must check and agree to the platform agreement stating that we right now have no plans to commercialize our application the traditional way, and have no real plans of selling the data of our users to anyone right now to help support our application.'
      );
      return;
    }
    if (!fullName.trim() || !signUpUserId.trim() || !signUpEmail.trim() || !signUpPassword) {
      setErrorMessage('Please complete all required fields.');
      return;
    }
    if (signUpPassword.length < 8) {
      setErrorMessage('Password must be at least 8 characters long.');
      return;
    }
    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = await registerWithCredentials({
        fullName: fullName.trim(),
        userId: signUpUserId.trim(),
        email: signUpEmail.trim(),
        password: signUpPassword,
      });
      if (res.success && res.user) {
        if (rememberOnDevice) {
          rememberAccountOnDevice(res.user);
        }
        void storeBrowserCredential(res.user.email, signUpPassword, res.user.name, res.user.avatarUrl);
        onAuthSuccess(res.user);
        onClose();
      } else {
        setErrorMessage(res.error || 'Account registration failed.');
      }
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Registration encountered an error.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasswordResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetIdentifier.trim()) {
      setErrorMessage('Please enter your User ID or Email address.');
      return;
    }
    setIsSubmitting(true);
    setErrorMessage('');
    setSuccessMessage('');
    try {
      const res = await requestPasswordReset(resetIdentifier.trim());
      if (res.success) {
        setSuccessMessage(`Password reset link sent to ${res.emailSentTo || resetIdentifier}. Check your inbox!`);
      } else {
        setErrorMessage(res.error || 'Failed to send reset link.');
      }
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Password reset encountered an error.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="auth-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        id="auth-modal-card"
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 12 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="w-full max-w-md bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl relative text-center my-auto max-h-[92dvh] flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-auth-modal"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 sm:top-5 sm:right-5 min-h-[40px] min-w-[40px] flex items-center justify-center rounded-full text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer z-10"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* View Switcher Tabs */}
        <div className="flex justify-center border-b border-slate-200 mb-5 pb-1 gap-6 overflow-x-auto no-scrollbar w-full">
          <button
            id="tab-signin"
            type="button"
            onClick={() => {
              setActiveTab('signin');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`min-h-[40px] text-xs sm:text-sm font-semibold pb-2 -mb-1 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'signin'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Sign In
          </button>

          <button
            id="tab-signup"
            type="button"
            onClick={() => {
              setActiveTab('signup');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`min-h-[40px] text-xs sm:text-sm font-semibold pb-2 -mb-1 border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
              activeTab === 'signup'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto pr-1 space-y-4 flex-1 w-full flex flex-col items-center">
          {/* Header content */}
          <div className="text-center w-full">
            <h2 className="font-serif text-2xl font-bold text-slate-900 tracking-tight text-center">
              {activeTab === 'signin' && 'Welcome to Final Finance'}
              {activeTab === 'signup' && 'Create Your Portfolio'}
              {activeTab === 'forgot' && 'Reset Your Password'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 text-center max-w-sm mx-auto">
              {activeTab === 'signin' && 'Sign in to access your reserve vaults, barter desk, and encrypted messaging.'}
              {activeTab === 'signup' && 'Register your verified participant handle across our 5-vault ecosystem.'}
              {activeTab === 'forgot' && 'Enter your registered email or handle to receive recovery instructions.'}
            </p>
          </div>

          {/* Error Notification */}
          {errorMessage && (
            <div
              id="auth-error-alert"
              className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm flex items-start justify-center gap-2.5 w-full text-center"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Success Notification */}
          {successMessage && (
            <div
              id="auth-success-alert"
              className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm flex items-start justify-center gap-2.5 w-full text-center"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* ================= TAB 1: SIGN IN ================= */}
          {activeTab === 'signin' && (
            <div className="space-y-4 w-full flex flex-col items-center">
              {/* Saved Accounts on This Browser (ONLY accounts already signed into on this browser) */}
              {rememberedAccounts.length > 0 && (
                <div className="w-full max-w-sm space-y-2 text-left">
                  <div className="flex items-center justify-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    <BookmarkCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Saved Accounts on This Browser</span>
                  </div>
                  <div className="space-y-2">
                    {rememberedAccounts.map((acc) => (
                      <div
                        key={acc.email}
                        className="flex items-center justify-between gap-2 p-2.5 rounded-2xl border border-slate-200 bg-slate-50 hover:bg-amber-50/60 hover:border-amber-300 transition-colors"
                      >
                        <button
                          type="button"
                          disabled={isSubmitting}
                          onClick={() => handleQuickRememberedSignIn(acc.email)}
                          className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer disabled:opacity-60"
                        >
                          {acc.avatarUrl ? (
                            <img
                              src={acc.avatarUrl}
                              alt={acc.name}
                              className="w-9 h-9 rounded-full object-cover border border-slate-200 shrink-0"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-9 h-9 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center justify-center shrink-0">
                              {(acc.name || acc.email).charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-bold text-slate-900 truncate">{acc.name}</p>
                            <p className="text-[11px] text-slate-500 truncate">{acc.email}</p>
                          </div>
                        </button>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            disabled={isSubmitting}
                            onClick={() => handleQuickRememberedSignIn(acc.email)}
                            className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-[11px] font-semibold cursor-pointer"
                          >
                            Sign In
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleForgetAccount(e, acc.email)}
                            className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Remove saved account from this browser"
                            aria-label={`Remove ${acc.email}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="w-full flex flex-col items-center">
                <GoogleAuthButton
                  mode="signin"
                  onSuccess={(user) => {
                    onAuthSuccess(user);
                    onClose();
                  }}
                  onError={(err) => setErrorMessage(err)}
                  disabled={isSubmitting}
                />
                <button
                  type="button"
                  onClick={() => setIsChooserOpen(true)}
                  className="min-h-[36px] text-xs text-blue-600 hover:text-blue-800 font-medium underline mt-2 cursor-pointer text-center"
                >
                  Use a Gmail / Google account (enter email &amp; password)
                </button>
              </div>

              <div className="flex items-center gap-3 my-2 w-full">
                <div className="h-px bg-slate-200 flex-1" />
                <span className="text-[11px] uppercase tracking-wider text-slate-400 font-medium text-center">or continue with email</span>
                <div className="h-px bg-slate-200 flex-1" />
              </div>

              <form
                onSubmit={handleCredentialsSignIn}
                method="POST"
                action="#"
                autoComplete="on"
                className="space-y-3 w-full max-w-sm"
              >
                <div className="text-center">
                  <label htmlFor="signin-identifier-input" className="block text-xs font-medium text-slate-700 mb-1 text-center">
                    Email or User ID
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      id="signin-identifier-input"
                      name="username"
                      autoComplete="username email"
                      inputMode="email"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      value={emailOrUserId}
                      onChange={(e) => setEmailOrUserId(e.target.value)}
                      placeholder="name@gmail.com or user_id"
                      className="w-full px-10 py-2.5 rounded-xl border border-slate-300 text-base sm:text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white text-center"
                      required
                    />
                    <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div className="text-center">
                  <div className="flex flex-col items-center justify-center gap-0.5 mb-1">
                    <label htmlFor="signin-password-input" className="block text-xs font-medium text-slate-700 text-center">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('forgot');
                        setErrorMessage('');
                      }}
                      className="text-[11px] text-slate-500 hover:text-slate-900 transition-colors text-center cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showSignInPassword ? 'text' : 'password'}
                      id="signin-password-input"
                      name="password"
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-10 py-2.5 rounded-xl border border-slate-300 text-base sm:text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white text-center"
                      required
                    />
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <button
                      type="button"
                      onClick={() => setShowSignInPassword(!showSignInPassword)}
                      className="absolute right-2.5 top-2 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                      aria-label={showSignInPassword ? 'Hide password' : 'Show password'}
                    >
                      {showSignInPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <label className="flex items-center justify-center gap-2 text-xs text-slate-600 cursor-pointer select-none pt-0.5">
                  <input
                    type="checkbox"
                    checked={rememberOnDevice}
                    onChange={(e) => setRememberOnDevice(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer"
                  />
                  <span>Save this account on this browser for future sign-in</span>
                </label>

                <button
                  type="submit"
                  id="submit-credentials-signin"
                  disabled={isSubmitting}
                  className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60 mx-auto"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <>
                      <span>Sign In</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* ================= TAB 2: CREATE ACCOUNT ================= */}
          {activeTab === 'signup' && (
            <div className="space-y-4 w-full flex flex-col items-center">
              <div
                className="w-full flex flex-col items-center"
                onClickCapture={(e) => {
                  if (!agreedToTerms) {
                    e.stopPropagation();
                    e.preventDefault();
                    setErrorMessage(
                      'Agreement required: Please check and agree to the non-commercialization agreement below before continuing with Google.'
                    );
                  }
                }}
              >
                <GoogleAuthButton
                  mode="signup"
                  onSuccess={(user) => {
                    onAuthSuccess(user);
                    onClose();
                  }}
                  onError={(err) => setErrorMessage(err)}
                  disabled={isSubmitting}
                />
              </div>

              <div className="flex items-center gap-3 my-2 w-full">
                <div className="h-px bg-slate-200 flex-1" />
                <span className="text-[11px] uppercase tracking-wider text-slate-400 font-medium text-center">or register credentials</span>
                <div className="h-px bg-slate-200 flex-1" />
              </div>

              <form
                onSubmit={handleCredentialsSignUp}
                method="POST"
                action="#"
                autoComplete="on"
                className="space-y-3 w-full max-w-sm"
              >
                <div className="text-center">
                  <label htmlFor="signup-fullname-input" className="block text-xs font-medium text-slate-700 mb-1 text-center">Full Name</label>
                  <div className="relative">
                    <input
                      type="text"
                      id="signup-fullname-input"
                      name="name"
                      autoComplete="name"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Jordan Belfort"
                      className="w-full px-9 py-2.5 rounded-xl border border-slate-300 text-base sm:text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white text-center"
                      required
                    />
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div className="text-center">
                  <label htmlFor="signup-userid-input" className="block text-xs font-medium text-slate-700 mb-1 text-center">Desired User ID / Handle</label>
                  <div className="relative">
                    <input
                      type="text"
                      id="signup-userid-input"
                      name="nickname"
                      autoCapitalize="none"
                      autoCorrect="off"
                      value={signUpUserId}
                      onChange={(e) => setSignUpUserId(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                      placeholder="e.g. jordan_trader"
                      className="w-full px-9 py-2.5 rounded-xl border border-slate-300 text-base sm:text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white text-center"
                      required
                    />
                    <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 text-center">Shown in header and used for direct mentions (@handle).</p>
                </div>

                <div className="text-center">
                  <label htmlFor="signup-email-input" className="block text-xs font-medium text-slate-700 mb-1 text-center">Email Address</label>
                  <div className="relative">
                    <input
                      type="email"
                      id="signup-email-input"
                      name="username"
                      autoComplete="username email"
                      inputMode="email"
                      autoCapitalize="none"
                      value={signUpEmail}
                      onChange={(e) => setSignUpEmail(e.target.value)}
                      placeholder="name@domain.com"
                      className="w-full px-9 py-2.5 rounded-xl border border-slate-300 text-base sm:text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white text-center"
                      required
                    />
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <div className="text-center">
                  <label htmlFor="signup-password-input" className="block text-xs font-medium text-slate-700 mb-1 text-center">Password (min 8 characters)</label>
                  <div className="relative">
                    <input
                      type={showSignUpPassword ? 'text' : 'password'}
                      id="signup-password-input"
                      name="password"
                      autoComplete="new-password"
                      value={signUpPassword}
                      onChange={(e) => setSignUpPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-10 py-2.5 rounded-xl border border-slate-300 text-base sm:text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white text-center"
                      required
                      minLength={8}
                    />
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <button
                      type="button"
                      onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                      className="absolute right-2.5 top-2 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
                      aria-label={showSignUpPassword ? 'Hide password' : 'Show password'}
                    >
                      {showSignUpPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Platform Non-Commercialization & User Data Agreement (Mandatory for Signup) */}
                <div className="p-3.5 rounded-2xl bg-amber-50/90 border border-amber-200/90 text-center space-y-2 flex flex-col items-center justify-center">
                  <div className="flex items-center justify-center gap-1.5 text-amber-900 font-bold text-xs text-center">
                    <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>Community Data Privacy &amp; Non-Commercialization Agreement</span>
                  </div>
                  <label className="flex flex-col items-center justify-center gap-2 cursor-pointer select-none text-center">
                    <input
                      type="checkbox"
                      id="signup-terms-agreement-checkbox"
                      checked={agreedToTerms}
                      onChange={(e) => {
                        setAgreedToTerms(e.target.checked);
                        if (e.target.checked && errorMessage.includes('Agreement')) {
                          setErrorMessage('');
                        }
                      }}
                      className="w-4 h-4 rounded text-amber-600 border-amber-300 focus:ring-amber-500 cursor-pointer shrink-0"
                      required
                    />
                    <span className="text-xs text-slate-700 leading-relaxed text-center">
                      I understand and agree: <strong>We right now have no plans to commercializing our application the traditional way. I have no real plans of selling the data of our users to anyone right now to help support our application.</strong>
                    </span>
                  </label>
                  {!agreedToTerms && (
                    <p className="text-[11px] text-amber-800 font-medium text-center">
                      * Unless you agree, you cannot sign up for an account.
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  id="submit-credentials-signup"
                  disabled={isSubmitting}
                  className={`w-full min-h-[44px] py-2.5 px-4 rounded-xl text-sm font-medium active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs mt-1 mx-auto ${
                    !agreedToTerms
                      ? 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                      : 'bg-slate-900 text-white hover:bg-slate-800'
                  }`}
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <>
                      <span>Create Final Finance Account</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* ================= TAB 3: FORGOT PASSWORD ================= */}
          {activeTab === 'forgot' && (
            <div className="space-y-4 w-full flex flex-col items-center">
              <form onSubmit={handlePasswordResetSubmit} className="space-y-3 w-full max-w-sm text-center">
                <div className="text-center">
                  <label className="block text-xs font-medium text-slate-700 mb-1 text-center">Your Registered User ID or Email</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={resetIdentifier}
                      onChange={(e) => setResetIdentifier(e.target.value)}
                      placeholder="e.g. jordan_trader or name@domain.com"
                      className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-300 text-base sm:text-sm focus:border-slate-900 focus:ring-1 focus:ring-slate-900 outline-none transition-all text-slate-900 bg-white text-center"
                      required
                    />
                    <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-60 mx-auto"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <span>Send Password Reset Link</span>
                  )}
                </button>
              </form>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('signin');
                    setErrorMessage('');
                    setSuccessMessage('');
                  }}
                  className="text-xs text-slate-600 hover:text-slate-900 font-medium transition-colors"
                >
                  &larr; Back to Sign In
                </button>
              </div>
            </div>
          )}

          {/* Security & Benefits Badges */}
          <div className="pt-3 border-t border-slate-200 space-y-1.5 w-full flex flex-col items-center justify-center text-center">
            <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 text-center">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Multi-vault cryptographic account security</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 text-center">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Institutional 5-vault liquidity and barter desk</span>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <p className="text-[11px] text-slate-400 text-center mt-3 shrink-0">
          By continuing, you agree to Final Finance Terms of Service and Privacy Policy.
        </p>
      </motion.div>

      {/* Google Account Chooser Modal */}
      <GoogleAccountChooserModal
        isOpen={isChooserOpen}
        onClose={() => setIsChooserOpen(false)}
        onSelectAccount={(user) => {
          onAuthSuccess(user);
          onClose();
        }}
      />
    </div>
  );
};
