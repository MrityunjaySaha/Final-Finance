import { AuthSession } from '../types/auth';
import { Conversation, ChatMessage, UserPublicProfile, ForwardedMessageData } from '../types/social';
import { SharedTweetCardData } from '../types/tweet';
import { areUsersBlockedEitherWay, enqueueUserNotification, getIdentityAliases, isAdminAccount } from './socialService';

export const MAX_GROUP_MEMBERS = 20;

// Persistent mock chat state in memory & localStorage
const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv-group-zurich',
    type: 'group',
    name: 'Zurich Freeport Gold Syndicate',
    groupAvatarUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=300&q=80',
    participantIds: ['demo-super-admin', 'demo-vip-alex', 'user-elena_rostova', 'user-lord_sterling'],
    participants: {
      'demo-super-admin': {
        uid: 'demo-super-admin',
        userId: 'super_admin_ranma',
        name: 'Ranma Sovereign Master',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
        role: 'super_admin'
      },
      'demo-vip-alex': {
        uid: 'demo-vip-alex',
        userId: 'alex_morgan',
        name: 'Alex Morgan',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        role: 'vip_user'
      },
      'user-elena_rostova': {
        uid: 'user-elena_rostova',
        userId: 'elena_rostova',
        name: 'Elena Rostova',
        avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
        role: 'user'
      },
      'user-lord_sterling': {
        uid: 'user-lord_sterling',
        userId: 'sterling_vault',
        name: 'Lord Sterling',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
        role: 'user'
      }
    },
    createdBy: 'demo-vip-alex',
    lastMessageText: 'The 100oz gold lot has passed dual LBMA assay verification.',
    lastMessageSenderId: 'user-lord_sterling',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'conv-direct-sterling',
    type: 'direct',
    participantIds: ['demo-vip-alex', 'user-lord_sterling'],
    participants: {
      'demo-vip-alex': {
        uid: 'demo-vip-alex',
        userId: 'alex_morgan',
        name: 'Alex Morgan',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
      },
      'user-lord_sterling': {
        uid: 'user-lord_sterling',
        userId: 'sterling_vault',
        name: 'Lord Sterling',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'
      }
    },
    lastMessageText: 'Greetings! Are you looking to barter for the 1st Edition bullion?',
    lastMessageSenderId: 'user-lord_sterling',
    updatedAt: new Date().toISOString()
  }
];

const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  'conv-group-zurich': [
    {
      id: 'msg-1',
      conversationId: 'conv-group-zurich',
      senderId: 'user-lord_sterling',
      senderName: 'Lord Sterling',
      senderHandle: 'sterling_vault',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      text: 'Good day syndicate members. Our Zurich Freeport bullion allocation is ready for barter verification.',
      createdAt: { toDate: () => new Date(Date.now() - 3600000) }
    },
    {
      id: 'msg-2',
      conversationId: 'conv-group-zurich',
      senderId: 'demo-vip-alex',
      senderName: 'Alex Morgan',
      senderHandle: 'alex_morgan',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      text: 'Confirmed. We can settle 50% in AFNL native coins and 50% in physical horology delivery.',
      createdAt: { toDate: () => new Date(Date.now() - 1800000) }
    },
    {
      id: 'msg-3',
      conversationId: 'conv-group-zurich',
      senderId: 'user-lord_sterling',
      senderName: 'Lord Sterling',
      senderHandle: 'sterling_vault',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      text: 'The 100oz gold lot has passed dual LBMA assay verification.',
      createdAt: { toDate: () => new Date(Date.now() - 600000) }
    }
  ],
  'conv-direct-sterling': [
    {
      id: 'msg-10',
      conversationId: 'conv-direct-sterling',
      senderId: 'user-lord_sterling',
      senderName: 'Lord Sterling',
      senderHandle: 'sterling_vault',
      senderAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      text: 'Greetings! Are you looking to barter for the 1st Edition bullion?',
      createdAt: { toDate: () => new Date(Date.now() - 1200000) }
    }
  ]
};

const CONV_STORAGE_KEY = 'final_finance_chat_conversations_v1';
const MSG_STORAGE_KEY = 'final_finance_chat_messages_v1';

function hydrateMessage(msg: any): ChatMessage {
  if (!msg) return msg;
  const rawDate =
    typeof msg.createdAtIso === 'string'
      ? msg.createdAtIso
      : typeof msg.createdAt === 'string'
        ? msg.createdAt
        : null;
  if (typeof msg.createdAt?.toDate === 'function') {
    return msg;
  }
  const dateObj = rawDate ? new Date(rawDate) : new Date();
  return {
    ...msg,
    createdAt: { toDate: () => dateObj },
  };
}

function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(CONV_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return [...INITIAL_CONVERSATIONS];
}

function loadMessages(): Record<string, ChatMessage[]> {
  try {
    const raw = localStorage.getItem(MSG_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        const hydrated: Record<string, ChatMessage[]> = {};
        Object.entries(parsed).forEach(([convId, list]) => {
          if (Array.isArray(list)) {
            hydrated[convId] = list.map(hydrateMessage);
          }
        });
        return hydrated;
      }
    }
  } catch {}
  return { ...INITIAL_MESSAGES };
}

function persistChatState() {
  try {
    localStorage.setItem(CONV_STORAGE_KEY, JSON.stringify(conversationsList));
    const serializableMsgs: Record<string, any[]> = {};
    Object.entries(messagesStore).forEach(([convId, list]) => {
      serializableMsgs[convId] = list.map((m) => ({
        ...m,
        createdAtIso: typeof m.createdAt?.toDate === 'function' ? m.createdAt.toDate().toISOString() : new Date().toISOString(),
        createdAt: undefined,
      }));
    });
    localStorage.setItem(MSG_STORAGE_KEY, JSON.stringify(serializableMsgs));
  } catch {}
}

let conversationsList: Conversation[] = loadConversations();
let messagesStore: Record<string, ChatMessage[]> = loadMessages();
const listeners: Array<() => void> = [];

function notifyListeners() {
  persistChatState();
  listeners.forEach(cb => cb());
}

export function getUserConversationsSnapshot(uid: string): Conversation[] {
  const uidAliases = new Set(getIdentityAliases(uid).map((a) => a.toLowerCase()));
  return conversationsList.filter((c) =>
    c.participantIds.some((pid) => pid === uid || uidAliases.has(pid.toLowerCase()))
  );
}

export function subscribeToUserConversations(uid: string, callback: (conversations: Conversation[]) => void): () => void {
  const handler = () => {
    callback(getUserConversationsSnapshot(uid));
  };
  listeners.push(handler);
  handler();

  return () => {
    const idx = listeners.indexOf(handler);
    if (idx > -1) listeners.splice(idx, 1);
  };
}

export function subscribeToMessages(conversationId: string, callback: (messages: ChatMessage[]) => void): () => void {
  const handler = () => {
    callback(messagesStore[conversationId] || []);
  };
  listeners.push(handler);
  handler();

  return () => {
    const idx = listeners.indexOf(handler);
    if (idx > -1) listeners.splice(idx, 1);
  };
}

export async function sendChatMessage(
  conversationId: string,
  user: AuthSession,
  text: string,
  options?: { sharedTweet?: SharedTweetCardData; forwardedMessage?: ForwardedMessageData }
): Promise<void> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (conv && conv.type === 'direct' && !isAdminAccount(user)) {
    const otherUid = conv.participantIds.find(id => id !== user.uid);
    const otherParticipant = otherUid ? conv.participants?.[otherUid] : undefined;
    if (
      (otherUid && areUsersBlockedEitherWay(user.uid, otherUid)) ||
      (otherParticipant?.userId && areUsersBlockedEitherWay(user.id, otherParticipant.userId))
    ) {
      throw new Error('Cannot send message: communication is blocked between these accounts.');
    }
  }

  const newMsg: ChatMessage = {
    id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    conversationId,
    senderId: user.uid,
    senderName: user.name,
    senderHandle: user.id,
    senderAvatarUrl: user.avatarUrl,
    text,
    sharedTweet: options?.sharedTweet,
    forwardedMessage: options?.forwardedMessage,
    createdAt: { toDate: () => new Date() }
  };

  if (!messagesStore[conversationId]) {
    messagesStore[conversationId] = [];
  }
  messagesStore[conversationId].push(newMsg);

  const summaryPreview = options?.forwardedMessage
    ? `${text ? `${text.trim()} · ` : ''}Shared message from @${options.forwardedMessage.senderHandle}: "${(options.forwardedMessage.text || 'Shared post').slice(0, 48)}"`
    : options?.sharedTweet
      ? `Shared tweet by @${options.sharedTweet.authorHandle}${options.sharedTweet.content ? `: "${options.sharedTweet.content.slice(0, 48)}"` : ''}`
      : text;

  // Update conversation last message
  conversationsList = conversationsList.map(c => {
    if (c.id === conversationId) {
      return {
        ...c,
        lastMessageText: summaryPreview,
        lastMessageSenderId: user.uid,
        updatedAt: new Date().toISOString()
      };
    }
    return c;
  });

  notifyListeners();

  // Notify recipient(s)
  if (conv) {
    const preview = summaryPreview.trim().slice(0, 90);
    if (conv.type === 'direct') {
      const otherUid = conv.participantIds.find((id) => id !== user.uid);
      const otherParticipant = otherUid ? conv.participants?.[otherUid] : undefined;
      const targets = [otherUid || '', otherParticipant?.userId || ''].filter(Boolean);
      if (targets.length > 0) {
        enqueueUserNotification(targets, {
          title: options?.forwardedMessage
            ? `📨 ${user.name} shared a message with you`
            : options?.sharedTweet
              ? `🐦 ${user.name} shared a tweet with you`
              : `💬 New Message from ${user.name}`,
          description: preview || 'Sent you a message.',
          type: 'chat',
          targetTab: 'messages',
          targetId: conversationId,
        });
      }
    } else if (conv.type === 'group') {
      conv.participantIds
        .filter((id) => id !== user.uid)
        .forEach((memberUid) => {
          const p = conv.participants?.[memberUid];
          enqueueUserNotification([memberUid, p?.userId || ''], {
            title: options?.forwardedMessage
              ? `📨 ${conv.name || 'Group Chat'}: ${user.name} shared a message`
              : options?.sharedTweet
                ? `🐦 ${conv.name || 'Group Chat'}: ${user.name} shared a tweet`
                : `💬 ${conv.name || 'Group Chat'}: ${user.name}`,
            description: preview || 'Sent a group message.',
            type: 'chat',
            targetTab: 'messages',
            targetId: conversationId,
          });
        });
    }
  }
}

export async function createGroupConversation(
  currentUser: AuthSession,
  name: string,
  members: UserPublicProfile[]
): Promise<{ success: boolean; conversation?: Conversation; error?: string }> {
  if (!isAdminAccount(currentUser)) {
    const blockedMember = members.find(
      (m) => areUsersBlockedEitherWay(currentUser.uid, m.uid) || areUsersBlockedEitherWay(currentUser.id, m.userId)
    );
    if (blockedMember) {
      return {
        success: false,
        error: `Cannot add ${blockedMember.name}: communication is blocked between these accounts.`,
      };
    }
  }
  const allUids = [currentUser.uid, ...members.map(m => m.uid)];
  const participantsMap: Record<string, any> = {
    [currentUser.uid]: {
      uid: currentUser.uid,
      userId: currentUser.id,
      name: currentUser.name,
      avatarUrl: currentUser.avatarUrl,
      role: currentUser.role
    }
  };

  members.forEach(m => {
    participantsMap[m.uid] = {
      uid: m.uid,
      userId: m.userId,
      name: m.name,
      avatarUrl: m.avatarUrl,
      role: m.role
    };
  });

  const newConv: Conversation = {
    id: 'group-' + Date.now(),
    type: 'group',
    name: name || `Multi-Conference (${allUids.length} members)`,
    groupAvatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=000&color=fff&size=128`,
    participantIds: allUids,
    participants: participantsMap,
    createdBy: currentUser.uid,
    lastMessageText: 'Group created. Conference ready.',
    lastMessageSenderId: currentUser.uid,
    updatedAt: new Date().toISOString()
  };

  conversationsList = [newConv, ...conversationsList];
  messagesStore[newConv.id] = [
    {
      id: 'msg-init-' + Date.now(),
      conversationId: newConv.id,
      senderId: currentUser.uid,
      senderName: currentUser.name,
      senderHandle: currentUser.id,
      senderAvatarUrl: currentUser.avatarUrl,
      text: `🎉 Started new multi-conference group: "${name}"`,
      createdAt: { toDate: () => new Date() }
    }
  ];

  notifyListeners();

  members.forEach((m) => {
    enqueueUserNotification([m.uid, m.userId], {
      title: '💬 Added to Group Conference',
      description: `${currentUser.name} added you to "${newConv.name}".`,
      type: 'chat',
      targetTab: 'messages',
      targetId: newConv.id,
    });
  });

  return { success: true, conversation: newConv };
}

export async function getOrCreateDirectConversation(
  currentUser: AuthSession,
  targetUser: UserPublicProfile
): Promise<Conversation> {
  if (
    !isAdminAccount(currentUser) &&
    (areUsersBlockedEitherWay(currentUser.uid, targetUser.uid) ||
      areUsersBlockedEitherWay(currentUser.id, targetUser.userId))
  ) {
    throw new Error('Cannot start chat: communication is blocked between these accounts.');
  }

  const myAliases = new Set(getIdentityAliases(currentUser.uid).concat(getIdentityAliases(currentUser.id)).map((a) => a.toLowerCase()));
  const targetAliases = new Set(getIdentityAliases(targetUser.uid).concat(getIdentityAliases(targetUser.userId)).map((a) => a.toLowerCase()));

  const existing = conversationsList.find(c =>
    c.type === 'direct' &&
    c.participantIds.some((pid) => pid === currentUser.uid || myAliases.has(pid.toLowerCase())) &&
    c.participantIds.some((pid) => pid === targetUser.uid || targetAliases.has(pid.toLowerCase()))
  );

  if (existing) return existing;

  const newConv: Conversation = {
    id: `direct-${currentUser.uid}-${targetUser.uid}`,
    type: 'direct',
    participantIds: [currentUser.uid, targetUser.uid],
    participants: {
      [currentUser.uid]: {
        uid: currentUser.uid,
        userId: currentUser.id,
        name: currentUser.name,
        avatarUrl: currentUser.avatarUrl
      },
      [targetUser.uid]: {
        uid: targetUser.uid,
        userId: targetUser.userId,
        name: targetUser.name,
        avatarUrl: targetUser.avatarUrl
      }
    },
    lastMessageText: 'Direct channel opened.',
    updatedAt: new Date().toISOString()
  };

  conversationsList = [newConv, ...conversationsList];
  messagesStore[newConv.id] = [];
  notifyListeners();
  return newConv;
}

export async function addMemberToGroup(
  conversationId: string,
  member: UserPublicProfile,
  requestedBy?: AuthSession
): Promise<{ success: boolean; error?: string }> {
  if (
    requestedBy &&
    !isAdminAccount(requestedBy) &&
    (areUsersBlockedEitherWay(requestedBy.uid, member.uid) ||
      areUsersBlockedEitherWay(requestedBy.id, member.userId))
  ) {
    return { success: false, error: 'Cannot add this user: communication is blocked between these accounts.' };
  }

  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group conversation not found' };

  if (conv.participantIds.length >= MAX_GROUP_MEMBERS) {
    return { success: false, error: `Group has reached maximum limit of ${MAX_GROUP_MEMBERS} members` };
  }

  if (conv.participantIds.includes(member.uid)) {
    return { success: false, error: 'Member already in group' };
  }

  conv.participantIds.push(member.uid);
  conv.participants[member.uid] = {
    uid: member.uid,
    userId: member.userId,
    name: member.name,
    avatarUrl: member.avatarUrl,
    role: member.role
  };

  notifyListeners();
  return { success: true };
}

export async function removeMemberFromGroup(
  conversationId: string,
  targetUid: string,
  requestedBy: AuthSession
): Promise<{ success: boolean; error?: string }> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group room not found' };

  if (conv.createdBy && conv.createdBy !== requestedBy.uid && requestedBy.role !== 'super_admin') {
    return { success: false, error: 'Only the room creator can eject members from this group.' };
  }

  if (targetUid === conv.createdBy) {
    return { success: false, error: 'The room creator cannot be ejected. Use End Group to disband the room.' };
  }

  const targetParticipant = conv.participants[targetUid];
  const targetName = targetParticipant?.name || 'Member';

  // Remove from participant list & map
  conv.participantIds = conv.participantIds.filter(id => id !== targetUid);
  delete conv.participants[targetUid];

  const sysMsg: ChatMessage = {
    id: 'msg-sys-' + Date.now(),
    conversationId,
    senderId: 'system',
    senderName: 'System Bot',
    senderHandle: 'system',
    text: `🚫 ${targetName} was ejected from the group by the room creator (${requestedBy.name}).`,
    createdAt: { toDate: () => new Date() }
  };

  if (!messagesStore[conversationId]) {
    messagesStore[conversationId] = [];
  }
  messagesStore[conversationId].push(sysMsg);
  conv.lastMessageText = `${targetName} was removed from the group`;
  conv.updatedAt = new Date().toISOString();

  notifyListeners();
  return { success: true };
}

export async function deleteGroupConversation(
  conversationId: string,
  requestedBy: AuthSession
): Promise<{ success: boolean; error?: string }> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group room not found' };

  if (conv.createdBy && conv.createdBy !== requestedBy.uid && requestedBy.role !== 'super_admin') {
    return { success: false, error: 'Only the room creator can end and delete this group room.' };
  }

  conversationsList = conversationsList.filter(c => c.id !== conversationId);
  delete messagesStore[conversationId];

  notifyListeners();
  return { success: true };
}

export async function leaveGroupConversation(
  conversationId: string,
  currentUser: AuthSession
): Promise<{ success: boolean; error?: string }> {
  const conv = conversationsList.find(c => c.id === conversationId);
  if (!conv) return { success: false, error: 'Group room not found' };

  conv.participantIds = conv.participantIds.filter(id => id !== currentUser.uid);
  delete conv.participants[currentUser.uid];

  if (conv.participantIds.length === 0) {
    conversationsList = conversationsList.filter(c => c.id !== conversationId);
    delete messagesStore[conversationId];
  } else {
    const sysMsg: ChatMessage = {
      id: 'msg-sys-' + Date.now(),
      conversationId,
      senderId: 'system',
      senderName: 'System Bot',
      senderHandle: 'system',
      text: `👋 ${currentUser.name} left the group room.`,
      createdAt: { toDate: () => new Date() }
    };
    if (!messagesStore[conversationId]) {
      messagesStore[conversationId] = [];
    }
    messagesStore[conversationId].push(sysMsg);
    conv.lastMessageText = `${currentUser.name} left the group`;
    conv.updatedAt = new Date().toISOString();
  }

  notifyListeners();
  return { success: true };
}

