import React, { useEffect, useMemo, useState } from 'react';
import {
  X,
  Search,
  Send,
  Check,
  Copy,
  Share2,
  Users,
  UserCheck,
  CheckCircle2,
  MessageSquare,
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { Tweet } from '../../types/tweet';
import { Conversation, UserPublicProfile } from '../../types/social';
import {
  getAllUsers,
  getFriendsList,
  getFollowingList,
  areUsersBlockedEitherWay,
  isUserBlockedByTarget,
  isAdminAccount,
  getIdentityAliases,
} from '../../services/socialService';
import {
  getOrCreateDirectConversation,
  getUserConversationsSnapshot,
  sendChatMessage,
} from '../../services/chatService';
import { buildSharedTweetCardData, resolveRootTweet } from '../../services/tweetingService';
import { SharedTweetPreviewCard } from './SharedTweetPreviewCard';
import { useApp } from '../../context/AppContext';

interface ShareTweetModalProps {
  tweet: Tweet | null;
  currentUser?: AuthSession | null;
  onClose: () => void;
  onOpenAuthModal?: () => void;
}

interface RecipientOption {
  key: string;
  kind: 'user' | 'group';
  label: string;
  sublabel: string;
  avatarUrl?: string;
  relationshipLabel: 'Friend' | 'Following' | 'Member' | 'Group';
  isVerified?: boolean;
  user?: UserPublicProfile;
  groupConversation?: Conversation;
}

const RESTRICTED_ADMIN_EMAILS = new Set([
  'ranmaanimaker@gmail.com',
  'awesomedbz@gmail.com',
]);

export const ShareTweetModal: React.FC<ShareTweetModalProps> = ({
  tweet,
  currentUser,
  onClose,
  onOpenAuthModal,
}) => {
  const { addToast } = useApp();
  const [search, setSearch] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'friends' | 'following' | 'groups'>('all');
  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());
  const [note, setNote] = useState('');
  const [friends, setFriends] = useState<UserPublicProfile[]>([]);
  const [following, setFollowing] = useState<UserPublicProfile[]>([]);
  const [allUsers, setAllUsers] = useState<UserPublicProfile[]>([]);
  const [groupConversations, setGroupConversations] = useState<Conversation[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [sentNotice, setSentNotice] = useState<string | null>(null);

  const activeUid = currentUser?.uid || currentUser?.id || '';
  const viewerIsAdmin = isAdminAccount(currentUser);

  useEffect(() => {
    if (!tweet || !activeUid) return;
    let active = true;
    setSelectedKeys(new Set());
    setNote('');
    setSearch('');
    setFilterTab('all');
    setSentNotice(null);

    Promise.all([
      getFriendsList(activeUid),
      getFollowingList(activeUid),
      getAllUsers(activeUid),
    ])
      .then(([frList, flList, usersList]) => {
        if (!active) return;
        setFriends(frList);
        setFollowing(flList);
        setAllUsers(usersList);
      })
      .catch(console.error);

    const convs = getUserConversationsSnapshot(activeUid).filter((c) => c.type === 'group');
    setGroupConversations(convs);

    return () => {
      active = false;
    };
  }, [tweet, activeUid]);

  const rootTweet = useMemo(() => (tweet ? resolveRootTweet(tweet) : null), [tweet]);
  const cardData = useMemo(() => (rootTweet ? buildSharedTweetCardData(rootTweet) : null), [rootTweet]);

  const recipientOptions = useMemo<RecipientOption[]>(() => {
    if (!activeUid) return [];
    const myAliases = new Set(
      getIdentityAliases(activeUid)
        .concat(getIdentityAliases(currentUser?.id || ''))
        .map((a) => a.toLowerCase())
    );

    const isAllowedToMessage = (u: UserPublicProfile): boolean => {
      const targetAliases = getIdentityAliases(u.uid).concat(getIdentityAliases(u.userId));
      if (targetAliases.some((a) => myAliases.has(a.toLowerCase()))) return false;

      if (!viewerIsAdmin) {
        if (
          areUsersBlockedEitherWay(activeUid, u.uid) ||
          areUsersBlockedEitherWay(activeUid, u.userId) ||
          isUserBlockedByTarget(activeUid, u.uid) ||
          isUserBlockedByTarget(activeUid, u.userId)
        ) {
          return false;
        }
        // Protect private owner email identities unless already mutual friends or admin
        const uEmail = (u.email || '').trim().toLowerCase();
        const isFriend = friends.some(
          (f) => f.uid === u.uid || f.userId.toLowerCase() === u.userId.toLowerCase()
        );
        if (uEmail && RESTRICTED_ADMIN_EMAILS.has(uEmail) && !isFriend) {
          return false;
        }
      }
      return true;
    };

    const byHandle = new Map<string, RecipientOption>();

    friends.filter(isAllowedToMessage).forEach((u) => {
      const key = `user:${u.userId.toLowerCase()}`;
      byHandle.set(key, {
        key,
        kind: 'user',
        label: u.name,
        sublabel: `@${u.userId}`,
        avatarUrl: u.avatarUrl,
        relationshipLabel: 'Friend',
        isVerified: u.isVerified || u.role === 'admin' || u.role === 'super_admin',
        user: u,
      });
    });

    following.filter(isAllowedToMessage).forEach((u) => {
      const key = `user:${u.userId.toLowerCase()}`;
      if (!byHandle.has(key)) {
        byHandle.set(key, {
          key,
          kind: 'user',
          label: u.name,
          sublabel: `@${u.userId}`,
          avatarUrl: u.avatarUrl,
          relationshipLabel: 'Following',
          isVerified: u.isVerified || u.role === 'admin' || u.role === 'super_admin',
          user: u,
        });
      }
    });

    allUsers.filter(isAllowedToMessage).forEach((u) => {
      const key = `user:${u.userId.toLowerCase()}`;
      if (!byHandle.has(key)) {
        byHandle.set(key, {
          key,
          kind: 'user',
          label: u.name,
          sublabel: `@${u.userId}`,
          avatarUrl: u.avatarUrl,
          relationshipLabel: 'Member',
          isVerified: u.isVerified || u.role === 'admin' || u.role === 'super_admin',
          user: u,
        });
      }
    });

    const groupOpts: RecipientOption[] = groupConversations.map((g) => ({
      key: `group:${g.id}`,
      kind: 'group',
      label: g.name || 'Group Chat',
      sublabel: `${g.participantIds.length} members`,
      avatarUrl: g.groupAvatarUrl,
      relationshipLabel: 'Group',
      groupConversation: g,
    }));

    return [...Array.from(byHandle.values()), ...groupOpts];
  }, [activeUid, currentUser?.id, viewerIsAdmin, friends, following, allUsers, groupConversations]);

  const filteredRecipients = useMemo(() => {
    const q = search.trim().toLowerCase();
    return recipientOptions.filter((r) => {
      if (filterTab === 'friends' && r.relationshipLabel !== 'Friend') return false;
      if (filterTab === 'following' && r.relationshipLabel !== 'Following' && r.relationshipLabel !== 'Friend') return false;
      if (filterTab === 'groups' && r.kind !== 'group') return false;
      if (!q) return true;
      return r.label.toLowerCase().includes(q) || r.sublabel.toLowerCase().includes(q);
    });
  }, [recipientOptions, filterTab, search]);

  if (!tweet || !rootTweet || !cardData) return null;

  const shareUrl = `${window.location.origin}${window.location.pathname}?tweet=${encodeURIComponent(rootTweet.id)}`;

  const toggleRecipient = (key: string) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard?.writeText(shareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch {}
  };

  const handleNativeShare = async () => {
    if (!navigator.share) {
      await handleCopyLink();
      return;
    }
    try {
      await navigator.share({
        title: `${rootTweet.authorName} (@${rootTweet.authorHandle}) on Final Finance`,
        text: rootTweet.content ? rootTweet.content.slice(0, 140) : cardData.contextLabel,
        url: shareUrl,
      });
    } catch {}
  };

  const handleSendToSelected = async () => {
    if (!currentUser) {
      onOpenAuthModal?.();
      return;
    }
    if (selectedKeys.size === 0 || isSending) return;
    setIsSending(true);
    try {
      const chosen = recipientOptions.filter((r) => selectedKeys.has(r.key));
      let sentCount = 0;
      let lastConversationId: string | null = null;
      const msgText = note.trim() || `Shared a post from @${cardData.authorHandle}`;

      for (const rec of chosen) {
        if (rec.kind === 'user' && rec.user) {
          const conv = await getOrCreateDirectConversation(currentUser, rec.user);
          await sendChatMessage(conv.id, currentUser, msgText, { sharedTweet: cardData });
          lastConversationId = conv.id;
          sentCount += 1;
        } else if (rec.kind === 'group' && rec.groupConversation) {
          await sendChatMessage(rec.groupConversation.id, currentUser, msgText, {
            sharedTweet: cardData,
          });
          lastConversationId = rec.groupConversation.id;
          sentCount += 1;
        }
      }

      if (sentCount > 0) {
        const names = chosen
          .slice(0, 2)
          .map((c) => c.label)
          .join(', ');
        const suffix = chosen.length > 2 ? ` +${chosen.length - 2} more` : '';
        const summaryMsg = `Tweet sent to ${names}${suffix} in Messages.`;
        setSentNotice(summaryMsg);
        addToast({
          type: 'success',
          title: 'Tweet Shared to Chat',
          message: summaryMsg,
        });
        if (lastConversationId) {
          setTimeout(() => {
            onClose();
          }, 900);
        }
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Unable to Share Tweet',
        message: err?.message || 'Communication is restricted for one of the selected recipients.',
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-lg w-full max-h-[92vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 bg-slate-950 text-white flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Share2 className="w-4 h-4" />
            </span>
            <div className="min-w-0 text-left">
              <h3 className="text-sm font-bold text-white truncate">Share Tweet</h3>
              <p className="text-[11px] text-slate-400 truncate">
                Send to friends or anyone you can message
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* Rich Twitter-Style Thumbnail + Context Card Preview */}
          <div className="space-y-1.5 text-left">
            <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500">
              Link &amp; Thumbnail Preview
            </span>
            <SharedTweetPreviewCard data={cardData} compact />
          </div>

          {/* Direct Message Recipient Selector */}
          {!currentUser ? (
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-2">
              <p className="text-xs font-medium text-slate-700">
                Sign in to share tweets directly with friends and platform members in Messages.
              </p>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAuthModal?.();
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
              >
                Sign In to Message
              </button>
            </div>
          ) : (
            <div className="space-y-3 text-left">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-xs font-bold text-slate-900">
                  Send via Direct Message
                </span>
                {selectedKeys.size > 0 && (
                  <span className="text-xs font-mono text-emerald-700 font-semibold tabular-nums">
                    {selectedKeys.size} selected
                  </span>
                )}
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
                {[
                  { id: 'all', label: 'All Allowed' },
                  { id: 'friends', label: `Friends (${friends.length})` },
                  { id: 'following', label: 'Following' },
                  { id: 'groups', label: `Groups (${groupConversations.length})` },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setFilterTab(tab.id as any)}
                    className={`flex-1 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer whitespace-nowrap truncate ${
                      filterTab === tab.id
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Search Recipients */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search friends, people you follow, or members..."
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                />
              </div>

              {/* Eligible Recipients List */}
              <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-2xl divide-y divide-slate-100">
                {filteredRecipients.length === 0 ? (
                  <div className="p-5 text-center text-xs text-slate-500">
                    No matching message recipients found.
                  </div>
                ) : (
                  filteredRecipients.map((rec) => {
                    const isSelected = selectedKeys.has(rec.key);
                    return (
                      <button
                        key={rec.key}
                        type="button"
                        onClick={() => toggleRecipient(rec.key)}
                        className={`w-full px-3 py-2.5 flex items-center justify-between gap-2.5 text-left transition-colors cursor-pointer ${
                          isSelected ? 'bg-emerald-50/80' : 'hover:bg-slate-50 bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {rec.avatarUrl ? (
                            <img
                              src={rec.avatarUrl}
                              alt={rec.label}
                              referrerPolicy="no-referrer"
                              className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0">
                              {rec.kind === 'group' ? (
                                <Users className="w-4 h-4 text-emerald-400" />
                              ) : (
                                rec.label.charAt(0).toUpperCase()
                              )}
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="flex items-center gap-1 min-w-0">
                              <span className="text-xs font-semibold text-slate-900 truncate">
                                {rec.label}
                              </span>
                              {rec.isVerified && (
                                <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                              )}
                            </div>
                            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono truncate">
                              <span className="truncate">{rec.sublabel}</span>
                              <span aria-hidden="true">·</span>
                              <span className="text-emerald-700 font-sans font-medium shrink-0">
                                {rec.relationshipLabel}
                              </span>
                            </div>
                          </div>
                        </div>

                        <span
                          className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                            isSelected
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 bg-white'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3" />}
                        </span>
                      </button>
                    );
                  })
                )}
              </div>

              {/* Optional Personal Message */}
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Add an optional note to your message..."
                maxLength={240}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
              />

              {sentNotice && (
                <div className="px-3 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{sentNotice}</span>
                </div>
              )}

              <button
                type="button"
                onClick={handleSendToSelected}
                disabled={selectedKeys.size === 0 || isSending}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-2xs"
              >
                <Send className="w-4 h-4" />
                <span>
                  {isSending
                    ? 'Sending...'
                    : selectedKeys.size > 0
                      ? `Send to ${selectedKeys.size} ${selectedKeys.size === 1 ? 'Recipient' : 'Recipients'}`
                      : 'Select Recipients to Send'}
                </span>
              </button>
            </div>
          )}

          {/* Copy Link & External Share Row */}
          <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyLink}
              className="flex-1 py-2 px-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              {copiedLink ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">Link Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Tweet Link</span>
                </>
              )}
            </button>
            {typeof navigator !== 'undefined' && typeof navigator.share === 'function' && (
              <button
                type="button"
                onClick={handleNativeShare}
                className="py-2 px-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>More Apps</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
