import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldCheck,
  X,
  Upload,
  FileText,
  CreditCard,
  CheckCircle2,
  Lock,
  Calendar,
  AlertCircle,
  FileCheck,
  Camera,
  RefreshCw,
  Sparkles,
  HelpCircle,
  Eye,
  Trash2
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { verifyUserWithSubscription } from '../services/firebaseAuth';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AuthSession | null;
  onVerificationSuccess: (updatedUser: AuthSession) => void;
}

export const VerificationModal: React.FC<VerificationModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onVerificationSuccess,
}) => {
  const [step, setStep] = useState<'documents' | 'subscription' | 'processing' | 'success'>('documents');

  // Form 1: Primary Government ID
  const [doc1Type, setDoc1Type] = useState<string>("Driver's License");
  const [doc1Name, setDoc1Name] = useState<string>('Driver_License_Front_Back.jpg');
  const [doc1Number, setDoc1Number] = useState<string>('DL-8941029');
  const [doc1FileUploaded, setDoc1FileUploaded] = useState<boolean>(true);

  // Form 2: Secondary Supporting ID
  const [doc2Type, setDoc2Type] = useState<string>('Utility Bill (Proof of Address)');
  const [doc2Name, setDoc2Name] = useState<string>('Electric_Utility_Statement_Recent.pdf');
  const [doc2Issuer, setDoc2Issuer] = useState<string>('City Power & Light');
  const [doc2FileUploaded, setDoc2FileUploaded] = useState<boolean>(true);

  // Payment Form ($2/mo)
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'gpay' | 'apple' | 'crypto'>('card');
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('888');
  const [cardHolder, setCardHolder] = useState(currentUser?.name || 'Verified Cardholder');

  // Error & Progress
  const [errorMessage, setErrorMessage] = useState('');
  const [processStep, setProcessStep] = useState(1);

  if (!isOpen) return null;

  const handleNextToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!doc1FileUploaded || !doc2FileUploaded) {
      setErrorMessage('Please provide both Form 1 (Primary ID) and Form 2 (Secondary ID) documents.');
      return;
    }
    setErrorMessage('');
    setStep('subscription');
  };

  const handleProcessVerification = async () => {
    setErrorMessage('');
    setStep('processing');
    setProcessStep(1);

    try {
      // Step 1: Encrypting IDs
      await new Promise((r) => setTimeout(r, 700));
      setProcessStep(2);

      // Step 2: KYC & Sanctions Registry Check
      await new Promise((r) => setTimeout(r, 800));
      setProcessStep(3);

      // Step 3: Establishing $2/month subscription
      await new Promise((r) => setTimeout(r, 700));

      const res = await verifyUserWithSubscription({
        idDocument1Type: doc1Type,
        idDocument1Name: doc1Name,
        idDocument1Number: doc1Number,
        idDocument2Type: doc2Type,
        idDocument2Name: doc2Name,
        idDocument2Issuer: doc2Issuer,
        paymentMethod: paymentMethod === 'card' ? `Visa ending in 4242` : paymentMethod === 'gpay' ? 'Google Pay' : paymentMethod === 'apple' ? 'Apple Pay' : 'USDC Autopay',
        lastFour: '4242'
      });

      if (res.success && res.user) {
        setStep('success');
        onVerificationSuccess(res.user);
      } else {
        setErrorMessage(res.error || 'Verification processing failed.');
        setStep('subscription');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error executing verification.');
      setStep('subscription');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden my-6 text-left"
      >
        {/* Modal Top Header */}
        <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">Member Identity Verification</h2>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200">
                  $2.00 / mo
                </span>
              </div>
              <p className="text-xs text-slate-500">
                2 Forms of ID + $2/month subscription required for Verified Member status
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stepper Indicator */}
        <div className="grid grid-cols-2 bg-slate-100 border-b border-slate-200 text-xs font-semibold text-slate-600">
          <div
            className={`py-2.5 px-4 text-center border-r border-slate-200 flex items-center justify-center gap-2 ${
              step === 'documents' ? 'bg-white text-slate-900 font-bold border-b-2 border-b-amber-500' : 'bg-slate-50'
            }`}
          >
            <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-800 text-[11px] flex items-center justify-center">1</span>
            <span>Two Forms of ID</span>
          </div>
          <div
            className={`py-2.5 px-4 text-center flex items-center justify-center gap-2 ${
              step === 'subscription' || step === 'processing' || step === 'success'
                ? 'bg-white text-slate-900 font-bold border-b-2 border-b-amber-500'
                : 'bg-slate-50 text-slate-400'
            }`}
          >
            <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[11px] flex items-center justify-center">2</span>
            <span>$2/mo Subscription</span>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Body Content */}
        <div className="p-6">
          {/* STEP 1: Two Forms of ID Required */}
          {step === 'documents' && (
            <form onSubmit={handleNextToPayment} className="space-y-5">
              <div className="p-3.5 rounded-2xl bg-amber-50/60 border border-amber-200/70 flex items-start gap-3">
                <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 space-y-0.5">
                  <p className="font-bold">Two Independent Forms of ID Required</p>
                  <p className="text-amber-800/90 leading-relaxed">
                    To maintain institutional trust and verify your member badge, submit 1 primary government photo ID and 1 secondary supporting identification document.
                  </p>
                </div>
              </div>

              {/* Document 1: Primary Government Photo ID */}
              <div className="border border-slate-200 rounded-2xl p-4 space-y-3 bg-slate-50/40">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-mono">1</span>
                    Primary Government Photo ID
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold">
                    Required
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      ID Document Type
                    </label>
                    <select
                      value={doc1Type}
                      onChange={(e) => setDoc1Type(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Driver's License">Driver's License</option>
                      <option value="Passport">Passport</option>
                      <option value="National ID Card">National ID Card</option>
                      <option value="State / Military ID">State / Military ID</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Document Number / ID Code
                    </label>
                    <input
                      type="text"
                      value={doc1Number}
                      onChange={(e) => setDoc1Number(e.target.value)}
                      placeholder="e.g. DL-8941029 or P9821034"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>
                </div>

                {/* Upload Zone for ID 1 */}
                <div className="border border-dashed border-slate-300 rounded-xl p-3 bg-white flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
                      <FileCheck className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 truncate">{doc1Name}</p>
                      <p className="text-[10px] text-slate-400">Attached &amp; Encrypted (AES-256)</p>
                    </div>
                  </div>
                  <label className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium cursor-pointer transition-colors shrink-0">
                    <span>Re-upload</span>
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setDoc1Name(e.target.files[0].name);
                          setDoc1FileUploaded(true);
                        }
                      }}
                    />
                  </label>
                </div>
              </div>

              {/* Document 2: Secondary Supporting ID */}
              <div className="border border-slate-200 rounded-2xl p-4 space-y-3 bg-slate-50/40">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-mono">2</span>
                    Secondary Supporting ID / Proof Document
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold">
                    Required
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Secondary Document Type
                    </label>
                    <select
                      value={doc2Type}
                      onChange={(e) => setDoc2Type(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Utility Bill (Proof of Address)">Utility Bill (Proof of Address)</option>
                      <option value="Bank Statement">Bank Statement</option>
                      <option value="Tax ID / W-2 Form">Tax ID / W-2 Form</option>
                      <option value="Social Security Card">Social Security Card</option>
                      <option value="Student / Corporate ID">Student / Corporate ID</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Issuing Authority / Institution
                    </label>
                    <input
                      type="text"
                      value={doc2Issuer}
                      onChange={(e) => setDoc2Issuer(e.target.value)}
                      placeholder="e.g. City Power, Chase Bank, IRS"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>
                </div>

                {/* Upload Zone for ID 2 */}
                <div className="border border-dashed border-slate-300 rounded-xl p-3 bg-white flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
                      <FileCheck className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 truncate">{doc2Name}</p>
                      <p className="text-[10px] text-slate-400">Attached &amp; Encrypted (AES-256)</p>
                    </div>
                  </div>
                  <label className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium cursor-pointer transition-colors shrink-0">
                    <span>Re-upload</span>
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setDoc2Name(e.target.files[0].name);
                          setDoc2FileUploaded(true);
                        }
                      }}
                    />
                  </label>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer transition-all shadow-sm flex items-center gap-2"
                >
                  <span>Continue to $2/mo Subscription</span>
                  <span className="font-mono text-[11px]">&rarr;</span>
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: $2.00 / Month Subscription Setup */}
          {step === 'subscription' && (
            <div className="space-y-5">
              {/* Plan Summary Card */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl p-5 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold">
                      Official Membership Tier
                    </span>
                    <h3 className="text-lg font-bold text-white">Verified Member Subscription</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-amber-400 font-mono">$2.00</span>
                    <span className="text-xs text-slate-400"> / month</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 border-t border-slate-800 pt-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Gold Verified Badge</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>2 Verified IDs Encrypted</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Instant Barter Priority</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Cancel Anytime in Settings</span>
                  </div>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-900">
                  Select Payment Method ($2.00 / month)
                </label>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      paymentMethod === 'card'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Credit Card</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('gpay')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      paymentMethod === 'gpay'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>Google Pay</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('crypto')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      paymentMethod === 'crypto'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>USDC / Crypto</span>
                  </button>
                </div>

                {/* Card Inputs */}
                {paymentMethod === 'card' && (
                  <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50 space-y-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Name on Card
                      </label>
                      <input
                        type="text"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-amber-500"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-2">
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Card Number
                        </label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-amber-500 font-mono"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                          Expires
                        </label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:ring-2 focus:ring-amber-500 font-mono"
                          required
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setStep('documents')}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
                >
                  &larr; Back to ID Forms
                </button>
                <button
                  type="button"
                  onClick={handleProcessVerification}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer transition-all shadow-sm flex items-center gap-2"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Start $2/mo Verification</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Processing */}
          {step === 'processing' && (
            <div className="py-8 text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto animate-spin">
                <RefreshCw className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900">
                  Processing Identity Verification
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Validating 2 forms of ID and establishing $2.00/month recurring membership.
                </p>
              </div>

              <div className="max-w-xs mx-auto space-y-2 text-left text-xs">
                <div className="flex items-center gap-2 text-slate-700">
                  {processStep >= 1 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span className={processStep === 1 ? 'font-bold text-amber-700' : ''}>
                    1. Encrypting 2 Forms of ID
                  </span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  {processStep >= 2 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span className={processStep === 2 ? 'font-bold text-amber-700' : ''}>
                    2. Verifying Legal Identity &amp; Sanctions
                  </span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  {processStep >= 3 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span className={processStep === 3 ? 'font-bold text-amber-700' : ''}>
                    3. Activating $2.00 / month Subscription
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Success */}
          {step === 'success' && (
            <div className="py-6 text-center space-y-5">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto border-4 border-emerald-50 shadow-xs">
                <ShieldCheck className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-900">
                  Account Verified Successfully!
                </h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  Your 2 forms of ID have been authenticated and your <strong>$2.00 / month</strong> verification subscription is now active.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-left text-xs space-y-2 max-w-md mx-auto">
                <div className="flex justify-between">
                  <span className="text-slate-500">Status:</span>
                  <span className="font-bold text-emerald-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Verified Member
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Primary ID:</span>
                  <span className="font-medium text-slate-900">{doc1Type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Secondary ID:</span>
                  <span className="font-medium text-slate-900">{doc2Type}</span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-1.5">
                  <span className="text-slate-500">Billing:</span>
                  <span className="font-bold text-slate-900 font-mono">$2.00 / month (Active)</span>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 px-5 rounded-2xl bg-slate-950 hover:bg-slate-900 text-white font-bold text-xs transition-all cursor-pointer shadow-sm"
              >
                Close &amp; Return to Final Finance
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
