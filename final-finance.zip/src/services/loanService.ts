export interface LoanRecord {
  id: string;
  lenderId: string;
  lenderHandle: string;
  borrowerId: string;
  borrowerHandle: string;
  amount: number;
  coinSymbol: string;
  interestRate: number;
  termDays: number;
  status: 'active' | 'repaid' | 'defaulted';
  timestamp: string; // ISO or human readable
  issuedAtMs: number;
}

const LOANS_KEY = 'ff_global_loans';

export function getAllLoans(): LoanRecord[] {
  const data = localStorage.getItem(LOANS_KEY);
  if (!data) return [];
  try { return JSON.parse(data); } catch { return []; }
}

export function saveAllLoans(loans: LoanRecord[]) {
  localStorage.setItem(LOANS_KEY, JSON.stringify(loans));
}

export function createLoan(loan: LoanRecord) {
  const all = getAllLoans();
  all.unshift(loan);
  saveAllLoans(all);
}

export function updateLoanStatus(loanId: string, status: 'repaid' | 'defaulted') {
  const all = getAllLoans();
  const idx = all.findIndex(l => l.id === loanId);
  if (idx !== -1) {
    all[idx].status = status;
    saveAllLoans(all);
    
    if (status === 'defaulted') {
      const borrowerId = all[idx].borrowerId;
      const key = `ff_default_count_${borrowerId}`;
      const current = parseInt(localStorage.getItem(key) || '0', 10);
      localStorage.setItem(key, (current + 1).toString());
    }
  }
}

export function getUserDefaultCount(userId: string): number {
  return parseInt(localStorage.getItem(`ff_default_count_${userId}`) || '0', 10);
}

export function getLoansForUser(userId: string) {
  const all = getAllLoans();
  return {
    issued: all.filter(l => l.lenderId === userId),
    received: all.filter(l => l.borrowerId === userId)
  };
}
