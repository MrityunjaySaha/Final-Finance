import React, { useState, useEffect, useRef } from 'react';
import { Search, Loader2, TrendingUp, TrendingDown, Info, Globe, Coins, ShieldCheck, AlertCircle, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AlpacaAssetLookupProps {
  onSelectAsset?: (asset: any, snapshot: any) => void;
}

export const AlpacaAssetLookup: React.FC<AlpacaAssetLookupProps> = ({ onSelectAsset }) => {
  const [query, setQuery] = useState('');
  const [assetClass, setAssetClass] = useState<'us_equity' | 'stable' | 'crypto'>('us_equity');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [asset, setAsset] = useState<any>(null);
  const [snapshot, setSnapshot] = useState<any>(null);
  
  // Autocomplete states
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searchingSuggestions, setSearchingSuggestions] = useState(false);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  const isSelectingRef = useRef(false);
  const disableSuggestionsRef = useRef(false);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isSelectingRef.current || disableSuggestionsRef.current) return;
    const searchTimer = setTimeout(async () => {
      if (query.length >= 2 && !disableSuggestionsRef.current) {
        setSearchingSuggestions(true);
        try {
          const res = await fetch(`/api/alpaca/search?q=${encodeURIComponent(query)}&asset_class=${assetClass === 'stable' ? 'us_equity' : assetClass}`);
          const data = await res.json();
          if (data.success && !disableSuggestionsRef.current) {
            setSuggestions(data.data);
            setShowSuggestions(true);
          }
        } catch (err) {
          console.error('Search error:', err);
        } finally {
          setSearchingSuggestions(false);
        }
      } else {
        setSuggestions([]);
        setShowSuggestions(false);
      }
    }, 300);

    return () => clearTimeout(searchTimer);
  }, [query, assetClass]);

  const handleSearch = async (symbolToSearch?: string) => {
    const sym = (symbolToSearch || query).trim();
    if (!sym) return;

    disableSuggestionsRef.current = true;
    setShowSuggestions(false);
    setSuggestions([]);
    setQuery(sym.toUpperCase());
    setLoading(true);
    setError(null);
    setAsset(null);
    setSnapshot(null);

    try {
      // 1. Get Asset Info
      const assetRes = await fetch(`/api/alpaca/asset/${sym}?asset_class=${assetClass === 'stable' ? 'us_equity' : assetClass}`);
      const assetData = await assetRes.json();

      if (!assetData.success) {
        throw new Error(assetData.error || 'Asset not found');
      }

      setAsset(assetData.data);

      // 2. Get Snapshot
      const snapshotRes = await fetch(`/api/alpaca/snapshot/${sym}?asset_class=${assetClass === 'stable' ? 'us_equity' : assetClass}`);
      const snapshotData = await snapshotRes.json();

      if (snapshotData.success) {
        setSnapshot(snapshotData.data);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getPrice = () => {
    if (!snapshot) return null;
    if (assetClass === 'crypto') {
      return snapshot.latestTrade?.p || snapshot.dailyBar?.c;
    }
    return snapshot.latestTrade?.p || snapshot.minuteBar?.c || snapshot.dailyBar?.c;
  };

  const getChange = () => {
    if (!snapshot || !snapshot.dailyBar || !snapshot.prevDailyBar) return null;
    const current = getPrice();
    const prev = snapshot.prevDailyBar.c;
    if (!current || !prev) return null;
    const diff = current - prev;
    const pct = (diff / prev) * 100;
    return { diff, pct };
  };

  const price = getPrice();
  const change = getChange();

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-5 border-b border-slate-100 bg-slate-50/50">
        <h2 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2">
          <Globe className="w-5 h-5 text-amber-600" />
          Regular Stocks Market Lookup
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Search real-time quotes and details for US Stocks, Stable, and Crypto via Alpaca.
        </p>
      </div>

      <div className="p-5 space-y-4">
        <div className="space-y-4">
          <div className="flex flex-wrap justify-center items-center gap-2.5">
            {(['us_equity', 'stable', 'crypto'] as const).map((cls) => (
              <button
                key={cls}
                type="button"
                onClick={() => {
                  setAssetClass(cls);
                  setQuery('');
                  setAsset(null);
                  setSnapshot(null);
                  setError(null);
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  assetClass === cls
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cls === 'us_equity' ? 'US Stocks' : cls === 'stable' ? 'Stable' : 'Crypto'}
              </button>
            ))}
          </div>

          <div className="relative" ref={suggestionsRef}>
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                disableSuggestionsRef.current = false;
                setQuery(e.target.value);
              }}
              onFocus={() => query.length >= 2 && setShowSuggestions(true)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch();
                }
              }}
              placeholder={
                assetClass === 'us_equity' 
                  ? "Search Company or Ticker (e.g. Apple, TSLA)..." 
                  : assetClass === 'crypto'
                  ? "Search Pair (e.g. BTC, ETH)..."
                  : "Search Stable Assets (e.g. USDC, USDT, COIN)..."
              }
              className="w-full pl-10 pr-24 py-3 bg-slate-50 focus:bg-white border border-slate-200 focus:border-amber-500 rounded-2xl text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-amber-500/10 transition-all"
            />
            
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
              {searchingSuggestions && <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-400" />}
              <button
                type="button"
                onClick={() => handleSearch()}
                disabled={loading || !query.trim()}
                className="px-4 py-1.5 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-200 text-slate-950 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
              >
                {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Lookup'}
              </button>
            </div>

            <AnimatePresence>
              {showSuggestions && suggestions.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute left-0 right-0 top-full mt-2 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden"
                >
                  <div className="max-h-60 overflow-y-auto">
                    {suggestions.map((s, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          isSelectingRef.current = true;
                          setQuery(s.symbol);
                          setSuggestions([]);
                          setShowSuggestions(false);
                          handleSearch(s.symbol);
                          setTimeout(() => { isSelectingRef.current = false; }, 600);
                        }}
                        className="w-full px-4 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0 text-left"
                      >
                        <div>
                          <div className="font-mono font-bold text-slate-900 text-sm">{s.symbol}</div>
                          <div className="text-[10px] text-slate-500 truncate max-w-[200px]">{s.name}</div>
                        </div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase bg-slate-100 px-1.5 py-0.5 rounded">
                          {s.asset_class}
                        </div>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-start gap-3"
            >
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <div className="text-xs text-rose-800">
                <p className="font-bold uppercase tracking-wider">Lookup Failed</p>
                <p className="mt-0.5">{error}</p>
                <p className="mt-1 opacity-70">Make sure the symbol is correct and the asset is active on Alpaca.</p>
              </div>
            </motion.div>
          )}

          {asset && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="border border-slate-200 rounded-2xl overflow-hidden shadow-2xs"
            >
              <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center font-mono font-bold text-lg">
                    {asset.symbol.substring(0, 2)}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm leading-tight">{asset.name}</h3>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 bg-white/20 rounded">
                        {asset.symbol}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400 uppercase">
                        {asset.exchange} • {asset.asset_class}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  {price !== null ? (
                    <>
                      <div className="text-lg font-mono font-bold">
                        ${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      {change && (
                        <div className={`text-xs font-bold flex items-center justify-end gap-1 ${change.diff >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {change.diff >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                          {change.diff >= 0 ? '+' : ''}{change.pct.toFixed(2)}%
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-xs text-slate-400 font-mono italic">Price Pending</div>
                  )}
                </div>
              </div>

              <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-white">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tradable</p>
                  <p className={`text-xs font-bold flex items-center gap-1.5 ${asset.tradable ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {asset.tradable ? <ShieldCheck className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                    {asset.tradable ? 'Yes' : 'No'}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Marginable</p>
                  <p className="text-xs font-bold text-slate-700">{asset.marginable ? 'Yes' : 'No'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Shortable</p>
                  <p className="text-xs font-bold text-slate-700">{asset.shortable ? 'Yes' : 'No'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fractional</p>
                  <p className="text-xs font-bold text-slate-700">{asset.fractionable ? 'Yes' : 'No'}</p>
                </div>
              </div>

              {snapshot && snapshot.dailyBar && (
                <div className="px-4 pb-4 bg-white">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase">Open</p>
                      <p className="text-xs font-mono font-bold text-slate-700">${snapshot.dailyBar.o.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase">High</p>
                      <p className="text-xs font-mono font-bold text-slate-700">${snapshot.dailyBar.h.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase">Low</p>
                      <p className="text-xs font-mono font-bold text-slate-700">${snapshot.dailyBar.l.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase">Volume</p>
                      <p className="text-xs font-mono font-bold text-slate-700">{snapshot.dailyBar.v.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-2 shadow-sm"
                  onClick={() => onSelectAsset?.(asset, snapshot)}
                >
                  <Info className="w-3.5 h-3.5" />
                  View Full Details
                </button>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tight flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                  Live Alpaca Data
                </div>
              </div>
            </motion.div>
          )}

          {!asset && !loading && !error && (
            <div className="py-6 space-y-6">
              <div className="text-center space-y-1">
                <p className="text-sm font-bold text-slate-800">Select a Popular Asset or Search Above</p>
                <p className="text-xs text-slate-400">
                  Quick-load tracking, charts, and asset snapshots with one click.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-xl mx-auto px-4">
                {assetClass === 'us_equity' && [
                  { sym: 'AAPL', name: 'Apple Inc.' },
                  { sym: 'MSFT', name: 'Microsoft' },
                  { sym: 'TSLA', name: 'Tesla Inc.' },
                  { sym: 'NVDA', name: 'NVIDIA' },
                  { sym: 'GOOG', name: 'Alphabet' }
                ].map((item) => (
                  <button
                    key={item.sym}
                    type="button"
                    onClick={() => handleSearch(item.sym)}
                    className="p-3 text-left bg-slate-50 hover:bg-slate-100/80 border border-slate-150 hover:border-slate-300 rounded-2xl transition-all cursor-pointer flex flex-col justify-between h-20 shadow-2xs group"
                  >
                    <span className="font-mono font-bold text-slate-900 text-sm group-hover:text-amber-600 transition-colors">{item.sym}</span>
                    <span className="text-[10px] text-slate-500 truncate w-full">{item.name}</span>
                  </button>
                ))}

                {assetClass === 'stable' && [
                  { sym: 'COIN', name: 'Coinbase Global' },
                  { sym: 'MSTR', name: 'MicroStrategy' },
                  { sym: 'RIOT', name: 'Riot Platforms' }
                ].map((item) => (
                  <button
                    key={item.sym}
                    type="button"
                    onClick={() => handleSearch(item.sym)}
                    className="p-3 text-left bg-slate-50 hover:bg-slate-100/80 border border-slate-150 hover:border-slate-300 rounded-2xl transition-all cursor-pointer flex flex-col justify-between h-20 shadow-2xs group"
                  >
                    <span className="font-mono font-bold text-slate-900 text-sm group-hover:text-amber-600 transition-colors">{item.sym}</span>
                    <span className="text-[10px] text-slate-500 truncate w-full">{item.name}</span>
                  </button>
                ))}

                {assetClass === 'crypto' && [
                  { sym: 'BTCUSD', name: 'Bitcoin (BTC)' },
                  { sym: 'ETHUSD', name: 'Ethereum (ETH)' },
                  { sym: 'SOLUSD', name: 'Solana (SOL)' },
                  { sym: 'USDCUSD', name: 'USD Coin (USDC)' }
                ].map((item) => (
                  <button
                    key={item.sym}
                    type="button"
                    onClick={() => handleSearch(item.sym)}
                    className="p-3 text-left bg-slate-50 hover:bg-slate-100/80 border border-slate-150 hover:border-slate-300 rounded-2xl transition-all cursor-pointer flex flex-col justify-between h-20 shadow-2xs group"
                  >
                    <span className="font-mono font-bold text-slate-900 text-sm group-hover:text-amber-600 transition-colors">{item.sym}</span>
                    <span className="text-[10px] text-slate-500 truncate w-full">{item.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
