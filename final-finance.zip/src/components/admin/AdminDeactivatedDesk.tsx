import React, { useState, useEffect } from 'react';
import { Search, Users, Unlock, ShieldAlert, Check } from 'lucide-react';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { getUserProfile } from '../../services/socialService';

interface SimpleUser {
  uid: string;
  userId: string;
  name: string;
  email?: string;
  avatarUrl?: string;
  bio?: string;
  role: string;
}

const STATIC_SAMPLE_USERS: SimpleUser[] = [
  {
    uid: 'demo-satoshi-nakamoto',
    userId: 'satoshi_nakamoto',
    name: 'Satoshi Nakamoto',
    email: 'satoshi@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'user'
  },
  {
    uid: 'demo-jordan-belfort',
    userId: 'jordan_belfort',
    name: 'Jordan Belfort',
    email: 'jordan@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    role: 'admin'
  },
  {
    uid: 'demo-alex-morgan',
    userId: 'alex_morgan',
    name: 'Alex Morgan',
    email: 'alex@finalfinance.io',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    role: 'user'
  },
  {
    uid: 'user-gholu653',
    userId: 'gholu653',
    name: 'Gholu',
    email: 'gholu653@gmail.com',
    avatarUrl: 'https://ui-avatars.com/api/?name=Gholu&background=f59e0b&color=0f172a&bold=true&size=128',
    role: 'user'
  },
  {
    uid: 'demo-super-admin',
    userId: 'super_admin_ranma',
    name: 'Ranma Sovereign Master',
    email: 'ranmaanimaker@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    role: 'super_admin'
  },
  {
    uid: 'demo-admin-officer',
    userId: 'officer_dbz',
    name: 'Chief Audit Officer',
    email: 'awesomedbz@gmail.com',
    avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=300&q=80',
    role: 'admin'
  },
  {
    uid: 'user-lord_sterling',
    userId: 'sterling_vault',
    name: 'Lord Sterling',
    email: 'sterling@zurich-escrow.ch',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    role: 'user'
  },
  {
    uid: 'user-elena_rostova',
    userId: 'elena_rostova',
    name: 'Elena Rostova',
    email: 'elena@monaco-yachting.mc',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    role: 'user'
  },
  {
    uid: 'user-marcus_vance',
    userId: 'marcus_vance',
    name: 'Marcus Vance',
    email: 'marcus@vance-holdings.com',
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
    role: 'user'
  }
];

interface AdminDeactivatedDeskProps {
  onViewProfile: (userId: string) => void;
  onNotify?: (message: string, type: 'success' | 'info' | 'error') => void;
}

export const AdminDeactivatedDesk: React.FC<AdminDeactivatedDeskProps> = ({ onViewProfile, onNotify }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [deactivatedUsers, setDeactivatedUsers] = useState<SimpleUser[]>([]);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    // 1. Gather registered users from localStorage
    let registeredList: SimpleUser[] = [];
    try {
      const stored = localStorage.getItem('final_finance_registered_users');
      if (stored) {
        const regMap = JSON.parse(stored);
        registeredList = Object.values<any>(regMap).map(account => {
          const profileUid = `user-${account.userId}`;
          return {
            uid: profileUid,
            userId: account.userId,
            name: account.name || 'Member',
            email: account.email,
            avatarUrl: account.avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(account.name || account.userId)}&background=0f172a&color=f8fafc&bold=true&size=128`,
            role: 'user'
          };
        });
      }
    } catch (e) {
      console.error('Error listing registered users for deactivated list:', e);
    }

    // 2. Combine pools
    const combinedPool = [...STATIC_SAMPLE_USERS, ...registeredList];
    
    // De-duplicate combined list by userId
    const uniqueMap = new Map<string, SimpleUser>();
    combinedPool.forEach(u => {
      uniqueMap.set(u.userId.toLowerCase(), u);
    });

    const uniqueUsers = Array.from(uniqueMap.values());

    // 3. Filter for deactivated status in localStorage
    const deactivatedOnly = uniqueUsers.filter(user => {
      const isDeac = 
        localStorage.getItem(`ff_user_deactivated_${user.userId}`) === 'true' || 
        localStorage.getItem(`ff_user_deactivated_${user.uid}`) === 'true';
      return isDeac;
    });

    setDeactivatedUsers(deactivatedOnly);
  }, [refreshTrigger]);

  const handleReactivate = (user: SimpleUser) => {
    localStorage.removeItem(`ff_user_deactivated_${user.userId}`);
    localStorage.removeItem(`ff_user_deactivated_${user.uid}`);

    // Commit a reactivation audit item directly to universal ledger
    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-REACT-${Math.floor(1000 + Math.random() * 9000)}`;

    const reactItem = {
      id: `rec-react-${Date.now()}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'deposit',
      category: 'transfer',
      mode: 'final_coin',
      title: `Account Reinstate Approved by Operator`,
      description: `Suspension revoked. Clearing status reactivated on profile @${user.userId} by System Administrator from Admin Desk. All privileges restored.`,
      amountUSD: 0,
      feeUSD: 0.00,
      netAmountUSD: 0.00,
      sourceOrDestination: `Sovereign Guard Security Desk`,
      counterpartyOrIssuer: `@${user.userId}`,
      paymentCoinSymbol: 'AFNL',
      paymentCoinAmount: 0,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Administrative compliance reinstatement.'
      },
      signature: `SIG-REACT-${Math.floor(100000 + Math.random() * 900000)}`
    };

    // Log to targeted user's ledger
    recordLedgerTransaction(user.userId, reactItem as any);
    // Log to admin/super_admin ledgers
    recordLedgerTransaction('admin', reactItem as any);
    recordLedgerTransaction('super_admin', reactItem as any);

    // Notify components of ledger modifications
    window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

    if (onNotify) {
      onNotify(`Account @${user.userId} has been successfully reactivated.`, 'success');
    }

    // Trigger state refresh
    setRefreshTrigger(prev => prev + 1);
  };

  const filtered = deactivatedUsers.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.userId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.email && u.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-serif text-xl font-bold text-slate-900">Deactivated Sovereign Accounts</h2>
            <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-xs font-bold font-mono">
              Total: {deactivatedUsers.length}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            System administration list tracking all suspended clearing handles and frozen assets.
          </p>
        </div>

        {/* Real-time search filter */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search suspended accounts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-64"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center mx-auto mb-3.5 border border-slate-150">
              <Check className="w-6 h-6 text-emerald-600" />
            </div>
            <h3 className="font-serif text-sm font-bold text-slate-950">All Clear</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              {deactivatedUsers.length === 0 
                ? 'No deactivated accounts found in the ecosystem. Every participant is currently verified.'
                : 'No accounts match your current search query.'}
            </p>
          </div>
        ) : (
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-slate-500 uppercase bg-slate-50/50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">Sovereign Profile</th>
                <th className="px-6 py-4">System Role</th>
                <th className="px-6 py-4">Status Flag</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(user => (
                <tr key={user.uid} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {user.avatarUrl ? (
                        <img 
                          src={user.avatarUrl} 
                          alt={user.name} 
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0" 
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 border border-slate-200 shrink-0">
                          <Users className="w-5 h-5" />
                        </div>
                      )}
                      <div>
                        <button 
                          onClick={() => onViewProfile(user.userId)}
                          className="font-bold text-slate-900 hover:text-blue-600 transition-colors text-left"
                        >
                          {user.name}
                        </button>
                        <div className="text-xs text-slate-400 font-mono">@{user.userId}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider font-mono border bg-slate-100 text-slate-600 border-slate-200">
                      {user.role}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 border border-rose-200 text-rose-800">
                      <ShieldAlert className="w-3 h-3 text-rose-500 shrink-0" />
                      <span>SUSPENDED</span>
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => onViewProfile(user.userId)}
                        className="px-3 py-1.5 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                      >
                        View Profile
                      </button>
                      <button
                        onClick={() => handleReactivate(user)}
                        className="px-3 py-1.5 bg-emerald-600 text-white hover:bg-emerald-500 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Reactivate</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
