import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  Users, 
  UserCheck, 
  UserPlus, 
  MessageSquare, 
  Sparkles, 
  Search, 
  Loader2, 
  X, 
  Clock, 
  Check, 
  ArrowLeft,
  ChevronRight,
  ShieldAlert,
  Shield,
  Ban,
  Inbox,
  Send,
  Star,
  FolderHeart,
  FolderOpen,
  Tag,
  Plus,
  Edit3,
  Trash2,
  Phone,
  Video,
  Image as ImageIcon,
  Upload
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { UserPublicProfile, FriendRequest, FriendGroup, GroupMemberAssignment } from '../types/social';
import { 
  getFriendsList, 
  getFollowingList, 
  getFollowersList, 
  getBlockedUsers,
  getFriendRequestsReceived,
  getFriendRequestsSent,
  followUser, 
  unfollowUser, 
  sendFriendRequest, 
  acceptFriendRequest, 
  declineFriendRequest, 
  cancelFriendRequest, 
  removeFriend,
  unblockUser,
  getAllUsers,
  getFavoritedUserIds,
  toggleFavoriteUser,
  isUserFavorited,
  getMutualFriends,
  areUsersBlockedEitherWay,
  areUsersFriends,
  isAdminAccount
} from '../services/socialService';
import { 
  MAX_CUSTOM_GROUP_MEMBERS,
  getUserFriendGroups, 
  createFriendGroup, 
  updateFriendGroup, 
  deleteFriendGroup,
  resolveAndSortGroupMembers
} from '../services/friendGroupService';
import { getAverageRating } from '../services/ratingService';

export type SocialTab = 'friends' | 'mutuals' | 'following' | 'followers' | 'blocked' | 'groups' | 'discover';

interface SocialPageProps {
  currentUser?: AuthSession | null;
  initialTab?: SocialTab;
  onViewProfile?: (userIdOrHandle: string) => void;
  onViewUserProfile?: (userIdOrHandle: string) => void;
  onOpenDirectMessage: (targetUser: UserPublicProfile) => void;
  onOpenVoiceCall?: (targetUser: any, isGroup?: boolean, groupParticipants?: any[]) => void;
  onOpenVideoCall?: (targetUser: any, isGroup?: boolean, groupParticipants?: any[]) => void;
  onOpenCommunitySearch?: () => void;
  onNavigateBack?: () => void;
}

export const SocialPage: React.FC<SocialPageProps> = ({
  currentUser,
  initialTab = 'friends',
  onViewProfile = (_userIdOrHandle?: string) => {},
  onViewUserProfile,
  onOpenDirectMessage,
  onOpenVoiceCall,
  onOpenVideoCall,
  onOpenCommunitySearch,
  onNavigateBack,
}) => {
  const handleProfileNav = onViewUserProfile || onViewProfile;
  const [activeTab, setActiveTab] = useState<SocialTab>(initialTab);
  const [localSearch, setLocalSearch] = useState('');
  
  // Data lists
  const [friendsList, setFriendsList] = useState<UserPublicProfile[]>([]);
  const [mutualFriendsList, setMutualFriendsList] = useState<{ user: UserPublicProfile; mutuals: UserPublicProfile[] }[]>([]);
  const [favoritedUserIds, setFavoritedUserIds] = useState<string[]>([]);
  const [followingList, setFollowingList] = useState<UserPublicProfile[]>([]);
  const [followersList, setFollowersList] = useState<UserPublicProfile[]>([]);
  const [blockedList, setBlockedList] = useState<UserPublicProfile[]>([]);
  const [discoverUsers, setDiscoverUsers] = useState<UserPublicProfile[]>([]);
  
  // Friend Groups
  const [friendGroups, setFriendGroups] = useState<FriendGroup[]>([]);
  const [isCreateGroupModalOpen, setIsCreateGroupModalOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<FriendGroup | null>(null);
  const [groupNameInput, setGroupNameInput] = useState('');
  const [groupDescInput, setGroupDescInput] = useState('');
  const [groupColorInput, setGroupColorInput] = useState('#f59e0b');
  const [groupAvatarInput, setGroupAvatarInput] = useState('');
  const groupImageFileRef = useRef<HTMLInputElement>(null);
  const [groupTypeInput, setGroupTypeInput] = useState<'friend' | 'general'>('friend');
  const [selectedMemberUids, setSelectedMemberUids] = useState<string[]>([]);
  const [memberAssignmentsInput, setMemberAssignmentsInput] = useState<Record<string, { number: string; role: string }>>({});
  const [memberSearchQuery, setMemberSearchQuery] = useState('');
  const [groupErrorMsg, setGroupErrorMsg] = useState('');
  const [groupToDelete, setGroupToDelete] = useState<FriendGroup | null>(null);
  const [openedGroupId, setOpenedGroupId] = useState<string | null>(null);
  
  // Manage single friend's group memberships modal state
  const [selectedFriendForGroupManagement, setSelectedFriendForGroupManagement] = useState<UserPublicProfile | null>(null);

  // Friend requests
  const [receivedRequests, setReceivedRequests] = useState<FriendRequest[]>([]);
  const [sentRequests, setSentRequests] = useState<FriendRequest[]>([]);
  const [showRequestsSubView, setShowRequestsSubView] = useState(false);

  // Status tracking sets
  const [friendUids, setFriendUids] = useState<Set<string>>(new Set());
  const [followingUids, setFollowingUids] = useState<Set<string>>(new Set());
  const [followerUids, setFollowerUids] = useState<Set<string>>(new Set());
  const [pendingSentUids, setPendingSentUids] = useState<Set<string>>(new Set());
  const [pendingReceivedUids, setPendingReceivedUids] = useState<Set<string>>(new Set());

  const [isLoading, setIsLoading] = useState(true);
  const [actionLoadingIds, setActionLoadingIds] = useState<Set<string>>(new Set());

  const activeUid = currentUser?.uid || currentUser?.id || 'guest';

  // Load all social data
  const loadSocialData = async () => {
    setIsLoading(true);
    try {
      const [
        friends,
        following,
        followers,
        blocked,
        received,
        sent,
        discover,
        mutuals
      ] = await Promise.all([
        getFriendsList(activeUid),
        getFollowingList(activeUid),
        getFollowersList(activeUid),
        getBlockedUsers(activeUid),
        getFriendRequestsReceived(activeUid),
        getFriendRequestsSent(activeUid),
        getAllUsers(activeUid),
        getMutualFriends(activeUid)
      ]);

      setFriendsList(friends);
      setMutualFriendsList(mutuals);
      setFavoritedUserIds(getFavoritedUserIds());
      setFollowingList(following);
      setFollowersList(followers);
      setBlockedList(blocked);
      setReceivedRequests(received);
      setSentRequests(sent);
      setDiscoverUsers(discover);

      // Load Friend Groups
      const groups = getUserFriendGroups(activeUid);
      setFriendGroups(groups);

      setFriendUids(new Set(friends.map((u) => u.uid)));
      setFollowingUids(new Set(following.map((u) => u.uid)));
      setFollowerUids(new Set(followers.map((u) => u.uid)));
      setPendingSentUids(new Set(sent.map((r) => r.receiverUid)));
      setPendingReceivedUids(new Set(received.map((r) => r.senderUid)));
    } catch (err) {
      console.error('Error loading social data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const viewerIsAdmin = isAdminAccount(currentUser);

  const isMemberBlocked = (target?: { uid?: string; userId?: string } | null): boolean => {
    if (!target || viewerIsAdmin) return false;
    return Boolean(
      (target.uid && areUsersBlockedEitherWay(activeUid, target.uid)) ||
      (target.userId && areUsersBlockedEitherWay(currentUser?.id || activeUid, target.userId))
    );
  };

  useEffect(() => {
    loadSocialData();
    const handleSocialRefresh = () => {
      loadSocialData();
    };
    window.addEventListener('final_finance_block_updated', handleSocialRefresh);
    window.addEventListener('final_finance_friends_updated', handleSocialRefresh);
    return () => {
      window.removeEventListener('final_finance_block_updated', handleSocialRefresh);
      window.removeEventListener('final_finance_friends_updated', handleSocialRefresh);
    };
  }, [activeUid]);

  const setItemLoading = (uid: string, loading: boolean) => {
    setActionLoadingIds((prev) => {
      const next = new Set(prev);
      if (loading) next.add(uid);
      else next.delete(uid);
      return next;
    });
  };

  // Memoized list of all selectable users across network (friends, following, followers, discover)
  const allSelectableUsers = useMemo(() => {
    const map = new Map<string, UserPublicProfile>();
    [...friendsList, ...followingList, ...followersList, ...discoverUsers].forEach((u) => {
      if (u && u.uid && !map.has(u.uid)) {
        map.set(u.uid, u);
      }
    });
    return Array.from(map.values());
  }, [friendsList, followingList, followersList, discoverUsers]);

  const selectableUsersForGroup = useMemo(() => {
    if (groupTypeInput === 'friend') {
      return friendsList;
    }
    return allSelectableUsers;
  }, [groupTypeInput, friendsList, allSelectableUsers]);

  const openedGroup = useMemo(
    () => friendGroups.find((g) => g.id === openedGroupId) || null,
    [friendGroups, openedGroupId]
  );

  const handleSetGroupType = (type: 'friend' | 'general') => {
    setGroupTypeInput(type);
    if (type === 'friend') {
      // Filter out non-friends if switching to friend group
      const friendsSet = new Set(friendsList.map(f => f.uid));
      setSelectedMemberUids(prev => {
        const filtered = prev.filter(uid => friendsSet.has(uid));
        return filtered.slice(0, MAX_CUSTOM_GROUP_MEMBERS);
      });
    } else {
      // Enforce 20 member limit for general groups as well
      setSelectedMemberUids(prev => prev.slice(0, MAX_CUSTOM_GROUP_MEMBERS));
    }
    setGroupErrorMsg('');
  };

  const handleMemberAssignmentChange = (
    uid: string,
    field: 'number' | 'role',
    value: string
  ) => {
    setMemberAssignmentsInput(prev => ({
      ...prev,
      [uid]: {
        number: prev[uid]?.number ?? '',
        role: prev[uid]?.role ?? '',
        [field]: value
      }
    }));
  };

  // --- FRIEND GROUP MANAGEMENT METHODS ---
  const handleOpenCreateGroup = (initialGroup?: FriendGroup) => {
    if (initialGroup) {
      setEditingGroup(initialGroup);
      setGroupNameInput(initialGroup.name);
      setGroupDescInput(initialGroup.description || '');
      setGroupColorInput(initialGroup.color || '#f59e0b');
      setGroupAvatarInput(initialGroup.avatarUrl || '');
      setGroupTypeInput(initialGroup.groupType || 'friend');
      const initialUids = (initialGroup.memberUids || []).slice(0, MAX_CUSTOM_GROUP_MEMBERS);
      setSelectedMemberUids(initialUids);
      const initialMap: Record<string, { number: string; role: string }> = {};
      initialUids.forEach((uid) => {
        const existingAssign = initialGroup.memberAssignments?.[uid];
        initialMap[uid] = {
          number: typeof existingAssign?.number === 'number' ? String(existingAssign.number) : '',
          role: existingAssign?.role || ''
        };
      });
      setMemberAssignmentsInput(initialMap);
    } else {
      setEditingGroup(null);
      setGroupNameInput('');
      setGroupDescInput('');
      setGroupColorInput('#f59e0b');
      setGroupAvatarInput('');
      setGroupTypeInput('friend');
      setSelectedMemberUids([]);
      setMemberAssignmentsInput({});
    }
    setGroupErrorMsg('');
    setMemberSearchQuery('');
    setIsCreateGroupModalOpen(true);
  };

  const handleSaveGroup = () => {
    if (!groupNameInput.trim()) {
      return;
    }

    const cappedUids = selectedMemberUids.slice(0, MAX_CUSTOM_GROUP_MEMBERS);
    const memberHandles = cappedUids.map((uid) => {
      const found = allSelectableUsers.find((f) => f.uid === uid);
      return found?.userId || uid.replace(/^user-/, '').replace(/^demo-/, '');
    });

    const assignmentsToSave: Record<string, GroupMemberAssignment> = {};
    cappedUids.forEach((uid) => {
      const entry = memberAssignmentsInput[uid];
      if (!entry) return;
      const numStr = entry.number.trim();
      const parsedNum = numStr !== '' ? Number(numStr) : NaN;
      const trimmedRole = entry.role.trim();
      const assignment: GroupMemberAssignment = {};
      if (numStr !== '' && Number.isFinite(parsedNum)) {
        assignment.number = parsedNum;
      }
      if (trimmedRole) {
        assignment.role = trimmedRole;
      }
      if (assignment.number !== undefined || assignment.role !== undefined) {
        assignmentsToSave[uid] = assignment;
      }
    });

    if (editingGroup) {
      const updated = updateFriendGroup(editingGroup.id, {
        name: groupNameInput.trim(),
        description: groupDescInput.trim(),
        color: groupColorInput,
        avatarUrl: groupAvatarInput,
        memberUids: cappedUids,
        memberHandles,
        memberAssignments: assignmentsToSave,
        groupType: groupTypeInput
      });
      if (updated) {
        setFriendGroups(prev => prev.map(g => g.id === updated.id ? updated : g));
      }
    } else {
      const created = createFriendGroup(
        activeUid,
        groupNameInput.trim(),
        cappedUids,
        groupDescInput.trim(),
        groupColorInput,
        memberHandles,
        groupTypeInput,
        groupAvatarInput,
        assignmentsToSave
      );
      setFriendGroups(prev => [created, ...prev]);
    }

    setIsCreateGroupModalOpen(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGroupAvatarInput(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteGroup = (groupId: string, _groupName: string) => {
    const group = friendGroups.find(g => g.id === groupId);
    if (group) {
      setGroupToDelete(group);
    }
  };

  const confirmDeleteGroup = () => {
    if (groupToDelete) {
      deleteFriendGroup(groupToDelete.id);
      setFriendGroups(prev => prev.filter(g => g.id !== groupToDelete.id));
      if (openedGroupId === groupToDelete.id) {
        setOpenedGroupId(null);
      }
      setGroupToDelete(null);
    }
  };

  const toggleMemberSelection = (uid: string) => {
    setSelectedMemberUids(prev => {
      if (prev.includes(uid)) {
        setGroupErrorMsg('');
        return prev.filter(id => id !== uid);
      } else {
        if (prev.length >= MAX_CUSTOM_GROUP_MEMBERS) {
          setGroupErrorMsg(`Custom groups are limited to ${MAX_CUSTOM_GROUP_MEMBERS} people.`);
          return prev;
        }
        setGroupErrorMsg('');
        return [...prev, uid];
      }
    });
  };

  const handleQuickUpdateMemberAssignment = (
    group: FriendGroup,
    memberUid: string,
    field: 'number' | 'role',
    rawValue: string
  ) => {
    const prevAssignments = group.memberAssignments || {};
    const current = prevAssignments[memberUid] || {};
    const nextForMember: GroupMemberAssignment = { ...current };

    if (field === 'number') {
      const trimmed = rawValue.trim();
      const parsed = trimmed !== '' ? Number(trimmed) : NaN;
      if (trimmed !== '' && Number.isFinite(parsed)) {
        nextForMember.number = parsed;
      } else {
        delete nextForMember.number;
      }
    } else {
      const trimmedRole = rawValue.trim();
      if (trimmedRole) {
        nextForMember.role = rawValue;
      } else {
        delete nextForMember.role;
      }
    }

    const nextAssignments: Record<string, GroupMemberAssignment> = {
      ...prevAssignments,
      [memberUid]: nextForMember
    };

    const updated = updateFriendGroup(group.id, {
      memberAssignments: nextAssignments
    });
    if (updated) {
      setFriendGroups(prev => prev.map(g => g.id === updated.id ? updated : g));
    }
  };

  const toggleGroupForSelectedFriend = (group: FriendGroup) => {
    if (!selectedFriendForGroupManagement) return;
    const friendUid = selectedFriendForGroupManagement.uid;
    const inGroup = group.memberUids.includes(friendUid);
    
    if (!inGroup) {
      if (group.groupType === 'friend' && !friendUids.has(friendUid)) {
        setGroupErrorMsg('Non-friends can only be added to General Groups.');
        return;
      }

      if (group.memberUids.length >= MAX_CUSTOM_GROUP_MEMBERS) {
        setGroupErrorMsg(`Custom groups are limited to ${MAX_CUSTOM_GROUP_MEMBERS} people.`);
        return;
      }
    }
    
    setGroupErrorMsg('');
    let nextUids = [...group.memberUids];
    let nextHandles = group.memberHandles ? [...group.memberHandles] : [];

    if (inGroup) {
      nextUids = nextUids.filter(id => id !== friendUid);
      if (selectedFriendForGroupManagement.userId) {
        nextHandles = nextHandles.filter(h => h !== selectedFriendForGroupManagement.userId);
      }
    } else {
      nextUids.push(friendUid);
      if (selectedFriendForGroupManagement.userId && !nextHandles.includes(selectedFriendForGroupManagement.userId)) {
        nextHandles.push(selectedFriendForGroupManagement.userId);
      }
    }

    const updated = updateFriendGroup(group.id, {
      memberUids: nextUids,
      memberHandles: nextHandles
    });

    if (updated) {
      setFriendGroups(prev => prev.map(g => g.id === updated.id ? updated : g));
    }
  };

  // Follow / Unfollow handler
  const handleToggleFollow = async (targetUser: UserPublicProfile) => {
    if (!currentUser) return;
    const isFollowing = followingUids.has(targetUser.uid);
    setItemLoading(`follow_${targetUser.uid}`, true);

    try {
      if (isFollowing) {
        await unfollowUser(currentUser.uid, targetUser.uid);
        setFollowingUids((prev) => {
          const next = new Set(prev);
          next.delete(targetUser.uid);
          return next;
        });
        setFollowingList((prev) => prev.filter((u) => u.uid !== targetUser.uid));
      } else {
        await followUser(currentUser, { uid: targetUser.uid, userId: targetUser.userId });
        setFollowingUids((prev) => new Set(prev).add(targetUser.uid));
        setFollowingList((prev) => [...prev, targetUser]);
      }
    } finally {
      setItemLoading(`follow_${targetUser.uid}`, false);
    }
  };

  // Friend Request handlers
  const handleSendFriendRequest = async (targetUser: UserPublicProfile) => {
    if (!currentUser) return;
    setItemLoading(`friend_${targetUser.uid}`, true);
    try {
      const outcome = await sendFriendRequest(currentUser, {
        uid: targetUser.uid,
        userId: targetUser.userId,
        name: targetUser.name,
        avatarUrl: targetUser.avatarUrl,
      });

      if (outcome === 'accepted') {
        await loadSocialData();
      } else if (outcome === 'sent') {
        setPendingSentUids((prev) => new Set(prev).add(targetUser.uid));
        setSentRequests((prev) => [
          ...prev,
          {
            id: `${currentUser.uid}_${targetUser.uid}`,
            senderUid: currentUser.uid,
            senderHandle: currentUser.id,
            senderName: currentUser.name,
            senderAvatarUrl: currentUser.avatarUrl,
            receiverUid: targetUser.uid,
            receiverHandle: targetUser.userId,
            receiverName: targetUser.name,
            receiverAvatarUrl: targetUser.avatarUrl,
            status: 'pending',
            createdAt: new Date().toISOString(),
          }
        ]);
      }
    } finally {
      setItemLoading(`friend_${targetUser.uid}`, false);
    }
  };

  const handleCancelFriendRequest = async (targetUid: string) => {
    if (!currentUser) return;
    setItemLoading(`friend_${targetUid}`, true);
    try {
      await cancelFriendRequest(currentUser.uid, targetUid);
      setPendingSentUids((prev) => {
        const next = new Set(prev);
        next.delete(targetUid);
        return next;
      });
      setSentRequests((prev) => prev.filter((r) => r.receiverUid !== targetUid));
    } finally {
      setItemLoading(`friend_${targetUid}`, false);
    }
  };

  const handleAcceptFriendRequest = async (sender: { uid: string; userId: string; name?: string; avatarUrl?: string }) => {
    if (!currentUser) return;
    setItemLoading(`friend_${sender.uid}`, true);
    try {
      await acceptFriendRequest(currentUser, sender);
      
      // Update states
      setPendingReceivedUids((prev) => {
        const next = new Set(prev);
        next.delete(sender.uid);
        return next;
      });
      setReceivedRequests((prev) => prev.filter((r) => r.senderUid !== sender.uid));
      setFriendUids((prev) => new Set(prev).add(sender.uid));
      
      // Add to friends list
      const matchedUser: UserPublicProfile = {
        uid: sender.uid,
        userId: sender.userId,
        name: sender.name || sender.userId,
        avatarUrl: sender.avatarUrl,
        role: 'user',
      };
      setFriendsList((prev) => [...prev, matchedUser]);
    } finally {
      setItemLoading(`friend_${sender.uid}`, false);
    }
  };

  const handleDeclineFriendRequest = async (senderUid: string) => {
    if (!currentUser) return;
    setItemLoading(`friend_${senderUid}`, true);
    try {
      await declineFriendRequest(currentUser.uid, senderUid);
      setPendingReceivedUids((prev) => {
        const next = new Set(prev);
        next.delete(senderUid);
        return next;
      });
      setReceivedRequests((prev) => prev.filter((r) => r.senderUid !== senderUid));
    } finally {
      setItemLoading(`friend_${senderUid}`, false);
    }
  };

  const handleUnfriend = async (targetUser: UserPublicProfile) => {
    if (!currentUser) return;
    setItemLoading(`friend_${targetUser.uid}`, true);
    try {
      await removeFriend(currentUser.uid, targetUser.uid);
      setFriendUids((prev) => {
        const next = new Set(prev);
        next.delete(targetUser.uid);
        return next;
      });
      setFriendsList((prev) => prev.filter((u) => u.uid !== targetUser.uid));
    } finally {
      setItemLoading(`friend_${targetUser.uid}`, false);
    }
  };

  const handleToggleFavorite = (uid: string) => {
    const updated = toggleFavoriteUser(uid);
    setFavoritedUserIds(updated);
    const isFavNow = updated.includes(uid);
    window.dispatchEvent(new CustomEvent('ff-app-notification', {
      detail: {
        title: isFavNow ? '⭐ User Favorited' : '☆ User Unfavorited',
        description: isFavNow ? 'Member has been added to your favorites.' : 'Member has been removed from your favorites.',
        type: 'social',
        targetTab: 'social'
      }
    }));
  };

  const handleUnblockUser = async (targetUser: UserPublicProfile) => {
    setItemLoading(`unblock_${targetUser.uid}`, true);
    try {
      await unblockUser(activeUid, targetUser.uid);
      setBlockedList((prev) => prev.filter((u) => u.uid !== targetUser.uid));
    } finally {
      setItemLoading(`unblock_${targetUser.uid}`, false);
    }
  };

  // Filter current active tab list with local search
  const currentList = useMemo(() => {
    let list: UserPublicProfile[] = [];
    if (activeTab === 'friends') list = friendsList;
    else if (activeTab === 'mutuals') list = mutualFriendsList.map((m) => m.user);
    else if (activeTab === 'following') list = followingList;
    else if (activeTab === 'followers') list = followersList;
    else if (activeTab === 'blocked') list = blockedList;

    if (!localSearch.trim()) return list;

    const q = localSearch.toLowerCase().trim().replace(/^@/, '');
    return list.filter((u) => 
      u.name.toLowerCase().includes(q) ||
      u.userId.toLowerCase().includes(q) ||
      (u.bio && u.bio.toLowerCase().includes(q))
    );
  }, [activeTab, localSearch, friendsList, mutualFriendsList, followingList, followersList, blockedList]);

  const totalPendingReceived = receivedRequests.length;

  return (
    <motion.div
      id="social-page-root"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="w-full max-w-4xl mx-auto text-center px-3 sm:px-4 py-2 sm:py-4"
    >
      {/* Top Header */}
      <div className="flex flex-col items-center justify-center gap-4 pb-4 border-b border-neutral-100 mb-6 text-center">
        <div className="text-center">
          <h1 className="font-serif-lux text-xl font-light text-black tracking-tight text-center">
            Community &amp; Social Feed
          </h1>
        </div>

        {/* Pending Requests Shortcut Button */}
        {totalPendingReceived > 0 && (
          <button
            id="friend-requests-badge-btn"
            type="button"
            onClick={() => {
              setActiveTab('friends');
              setShowRequestsSubView(true);
            }}
            className="min-h-[38px] px-3.5 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium flex items-center gap-2 cursor-pointer shadow-xs transition-colors"
          >
            <Inbox className="w-3.5 h-3.5" />
            <span>{totalPendingReceived} Friend Request{totalPendingReceived > 1 ? 's' : ''}</span>
          </button>
        )}
      </div>

      {/* Main Social Navigation Tabs: Friends, Following, Followers, Blocked Users */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-1.5 p-1 bg-neutral-100/90 rounded-2xl w-full sm:w-auto overflow-x-auto">
          {/* TAB 1: FRIENDS */}
          <button
            id="social-tab-friends"
            type="button"
            onClick={() => {
              setActiveTab('friends');
              setShowRequestsSubView(false);
              setLocalSearch('');
            }}
            className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'friends' && !showRequestsSubView
                ? 'bg-white text-black font-semibold shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-white/60'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Friends</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-neutral-200/70 text-neutral-800 font-mono">
              {friendsList.length}
            </span>
          </button>

          {/* TAB: MUTUAL FRIENDS */}
          <button
            id="social-tab-mutuals"
            type="button"
            onClick={() => {
              setActiveTab('mutuals');
              setShowRequestsSubView(false);
              setLocalSearch('');
            }}
            className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'mutuals'
                ? 'bg-white text-black font-semibold shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-white/60'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-blue-600" />
            <span>Mutual Friends</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-neutral-200/70 text-neutral-800 font-mono">
              {mutualFriendsList.length}
            </span>
          </button>

          {/* TAB 2: FOLLOWING */}
          <button
            id="social-tab-following"
            type="button"
            onClick={() => {
              setActiveTab('following');
              setShowRequestsSubView(false);
              setLocalSearch('');
            }}
            className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'following'
                ? 'bg-white text-black font-semibold shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-white/60'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-neutral-700" />
            <span>Following</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-neutral-200/70 text-neutral-800 font-mono">
              {followingList.length}
            </span>
          </button>

          {/* TAB 3: FOLLOWERS */}
          <button
            id="social-tab-followers"
            type="button"
            onClick={() => {
              setActiveTab('followers');
              setShowRequestsSubView(false);
              setLocalSearch('');
            }}
            className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'followers'
                ? 'bg-white text-black font-semibold shadow-xs'
                : 'text-neutral-600 hover:text-black hover:bg-white/60'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-neutral-700" />
            <span>Followers</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-neutral-200/70 text-neutral-800 font-mono">
              {followersList.length}
            </span>
          </button>

          {/* TAB 4: BLOCKED USERS (Replaces Discover Members) */}
          <button
            id="social-tab-blocked"
            type="button"
            onClick={() => {
              setActiveTab('blocked');
              setShowRequestsSubView(false);
              setLocalSearch('');
            }}
            className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'blocked'
                ? 'bg-white text-red-600 font-semibold shadow-xs border border-red-100'
                : 'text-neutral-600 hover:text-red-600 hover:bg-white/60'
            }`}
          >
            <Ban className="w-3.5 h-3.5 text-red-500" />
            <span>Blocked Users</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
              blockedList.length > 0 ? 'bg-red-100 text-red-700 font-bold' : 'bg-neutral-200/70 text-neutral-800'
            }`}>
              {blockedList.length}
            </span>
          </button>

          {/* TAB 5: CUSTOM GROUPS */}
          <button
            id="social-tab-groups"
            type="button"
            onClick={() => {
              setActiveTab('groups');
              setShowRequestsSubView(false);
              setLocalSearch('');
            }}
            className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'groups'
                ? 'bg-white text-emerald-800 font-semibold shadow-xs border border-emerald-100'
                : 'text-neutral-600 hover:text-emerald-700 hover:bg-white/60'
            }`}
          >
            <FolderHeart className="w-3.5 h-3.5 text-emerald-600" />
            <span>Custom Groups</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-neutral-200/70 text-neutral-800 font-mono">
              {friendGroups.length}
            </span>
          </button>
        </div>

        {/* Requests Sub-toggle when on Friends Tab */}
        {activeTab === 'friends' && (
          <button
            id="toggle-requests-view-btn"
            type="button"
            onClick={() => setShowRequestsSubView((prev) => !prev)}
            className={`min-h-[38px] px-4 py-1.5 rounded-full text-xs font-medium transition-all flex items-center gap-2 cursor-pointer ${
              showRequestsSubView
                ? 'bg-black text-white'
                : 'bg-white text-neutral-700 border border-neutral-200 hover:border-black'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Requests ({receivedRequests.length + sentRequests.length})</span>
          </button>
        )}
      </div>

      {/* ================= PENDING FRIEND REQUESTS SUB-PANEL ================= */}
      {activeTab === 'friends' && showRequestsSubView && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="mb-8 space-y-6 bg-neutral-50/80 border border-neutral-200/90 rounded-3xl p-5 sm:p-6"
        >
          {/* Section: Incoming Requests */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider flex items-center gap-2">
                <Inbox className="w-4 h-4 text-emerald-600" />
                <span>Received Requests ({receivedRequests.length})</span>
              </h3>
            </div>

            {receivedRequests.length === 0 ? (
              <p className="text-xs text-neutral-400 py-3 italic">
                No pending friend requests received.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {receivedRequests.map((req) => {
                  const isActionLoading = actionLoadingIds.has(`friend_${req.senderUid}`);
                  return (
                    <div
                      key={req.id}
                      className="bg-white border border-neutral-200 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-2xs"
                    >
                      <div
                        onClick={() => onViewProfile(req.senderHandle)}
                        className="flex items-center gap-3 min-w-0 cursor-pointer group"
                      >
                        {req.senderAvatarUrl ? (
                          <img
                            src={req.senderAvatarUrl}
                            alt={req.senderName}
                            className="w-10 h-10 rounded-full object-cover border border-neutral-200"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                            {req.senderName.charAt(0)}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="font-semibold text-xs text-black group-hover:underline truncate">
                            {req.senderName}
                          </p>
                          <p className="text-[11px] font-mono text-neutral-400 truncate">
                            @{req.senderHandle}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleAcceptFriendRequest({
                            uid: req.senderUid,
                            userId: req.senderHandle,
                            name: req.senderName,
                            avatarUrl: req.senderAvatarUrl
                          })}
                          disabled={isActionLoading}
                          className="min-h-[34px] px-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                        >
                          {isActionLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
                          <span>Accept</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeclineFriendRequest(req.senderUid)}
                          disabled={isActionLoading}
                          className="min-h-[34px] px-2.5 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-medium transition-colors cursor-pointer disabled:opacity-50"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Section: Sent Requests */}
          <div className="space-y-3 pt-4 border-t border-neutral-200/80">
            <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider flex items-center gap-2">
              <Send className="w-4 h-4 text-neutral-600" />
              <span>Sent Requests ({sentRequests.length})</span>
            </h3>

            {sentRequests.length === 0 ? (
              <p className="text-xs text-neutral-400 py-3 italic">
                You have no outgoing friend requests pending.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {sentRequests.map((req) => {
                  const isActionLoading = actionLoadingIds.has(`friend_${req.receiverUid}`);
                  return (
                    <div
                      key={req.id}
                      className="bg-white border border-neutral-200 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-2xs"
                    >
                      <div
                        onClick={() => onViewProfile(req.receiverHandle)}
                        className="flex items-center gap-3 min-w-0 cursor-pointer group"
                      >
                        {req.receiverAvatarUrl ? (
                          <img
                            src={req.receiverAvatarUrl}
                            alt={req.receiverName}
                            className="w-10 h-10 rounded-full object-cover border border-neutral-200"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center text-xs font-serif-lux">
                            {req.receiverName.charAt(0)}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="font-semibold text-xs text-black group-hover:underline truncate">
                            {req.receiverName}
                          </p>
                          <p className="text-[11px] font-mono text-neutral-400 truncate">
                            @{req.receiverHandle}
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleCancelFriendRequest(req.receiverUid)}
                        disabled={isActionLoading}
                        className="min-h-[34px] px-3 rounded-full bg-neutral-100 hover:bg-red-50 hover:text-red-600 text-neutral-600 text-xs font-medium transition-colors cursor-pointer disabled:opacity-50"
                      >
                        {isActionLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <span>Cancel</span>}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </motion.div>
      )}

      {/* ================= SEARCH & FILTER BAR ================= */}
      <div className="mb-6">
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            id="social-local-search-input"
            type="text"
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            placeholder={
              activeTab === 'friends'
                ? 'Search within your friends by name or @handle...'
                : activeTab === 'following'
                  ? 'Search within following members...'
                  : activeTab === 'followers'
                    ? 'Search within followers...'
                    : activeTab === 'groups'
                      ? 'Search custom groups by name...'
                      : 'Search blocked members...'
            }
            className="w-full min-h-[46px] pl-11 pr-10 py-2.5 rounded-2xl bg-neutral-100/80 border border-neutral-200/80 text-xs sm:text-sm text-black placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black focus:bg-white transition-all shadow-2xs"
          />
          {localSearch && (
            <button
              type="button"
              onClick={() => setLocalSearch('')}
              className="absolute right-3.5 text-neutral-400 hover:text-black p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {localSearch && (
          <div className="mt-2 text-[11px] text-neutral-500 px-1">
            Found {currentList.length} matching member{currentList.length === 1 ? '' : 's'}
          </div>
        )}
      </div>

      {/* ================= MEMBER LIST GRID ================= */}
      {isLoading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-3 text-neutral-400">
          <Loader2 className="w-8 h-8 animate-spin text-black" />
          <span className="text-xs">Loading {activeTab}...</span>
        </div>
      ) : activeTab === 'groups' ? (
        /* CUSTOM FRIEND / PEOPLE GROUPS TAB */
        openedGroup ? (
          /* OPENED GROUP DETAIL VIEW */
          (() => {
            const orderedMembers = resolveAndSortGroupMembers(openedGroup, allSelectableUsers);
            const numberedMembers = orderedMembers.filter(
              (m) => typeof openedGroup.memberAssignments?.[m.uid]?.number === 'number'
            );
            const unnumberedMembers = orderedMembers.filter(
              (m) => typeof openedGroup.memberAssignments?.[m.uid]?.number !== 'number'
            );

            return (
              <div className="space-y-5">
                {/* Back & Header Actions */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setOpenedGroupId(null)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-white border border-neutral-200 text-xs font-semibold text-neutral-700 hover:text-black hover:border-neutral-300 cursor-pointer shadow-2xs transition-all"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back to Custom Groups</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenCreateGroup(openedGroup)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-black text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer shadow-xs transition-all"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit Group &amp; Members</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteGroup(openedGroup.id, openedGroup.name)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-red-50 border border-red-200 text-red-700 text-xs font-semibold hover:bg-red-100 cursor-pointer transition-all"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>

                {/* Opened Group Hero Card */}
                <div className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-xs space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5 min-w-0">
                      {openedGroup.avatarUrl ? (
                        <img
                          src={openedGroup.avatarUrl}
                          alt={openedGroup.name}
                          className="w-12 h-12 rounded-2xl object-cover border border-neutral-200 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-lg shrink-0 border border-black/10 shadow-2xs"
                          style={{ backgroundColor: openedGroup.color || '#f59e0b' }}
                        >
                          {openedGroup.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-serif-lux text-xl font-bold text-black truncate">
                            {openedGroup.name}
                          </h3>
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                              openedGroup.groupType === 'general'
                                ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                : 'bg-blue-100 text-blue-900 border border-blue-200'
                            }`}
                          >
                            {openedGroup.groupType === 'general' ? 'General Group' : 'Friend Group'}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-neutral-100 text-neutral-700 border border-neutral-200">
                            {orderedMembers.length} / {MAX_CUSTOM_GROUP_MEMBERS} Members
                          </span>
                        </div>
                        {openedGroup.description && (
                          <p className="text-xs text-neutral-500 mt-1">{openedGroup.description}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {(() => {
                        const firstCallableMember = orderedMembers.find((m) => !isMemberBlocked(m));
                        return (
                          <button
                            type="button"
                            onClick={() => {
                              if (firstCallableMember) onOpenDirectMessage(firstCallableMember);
                            }}
                            disabled={!firstCallableMember}
                            title={firstCallableMember ? `Message ${firstCallableMember.name}` : 'Messaging disabled (no unblocked members)'}
                            className="px-3.5 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 disabled:opacity-40 disabled:cursor-not-allowed text-neutral-800 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Message</span>
                          </button>
                        );
                      })()}
                    </div>
                  </div>

                  {/* Ordering Explanation Banner */}
                  <div className="bg-neutral-50 border border-neutral-200/80 rounded-2xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-[11px] text-neutral-600">
                    <span>
                      Ordered by assigned number at the top ({numberedMembers.length}), followed alphabetically by unnumbered members at the bottom ({unnumberedMembers.length}).
                    </span>
                    <span className="font-mono text-neutral-500">
                      Roles &amp; numbers are unique to this group
                    </span>
                  </div>

                  {/* Ordered Members Roster */}
                  {orderedMembers.length === 0 ? (
                    <div className="py-10 text-center space-y-2 border border-dashed border-neutral-200 rounded-2xl">
                      <p className="text-xs text-neutral-500">
                        This group has no members yet.
                      </p>
                      <button
                        type="button"
                        onClick={() => handleOpenCreateGroup(openedGroup)}
                        className="px-4 py-2 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add Friends or People</span>
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {orderedMembers.map((m, idx) => {
                        const assignment = openedGroup.memberAssignments?.[m.uid];
                        const hasNumber = typeof assignment?.number === 'number' && Number.isFinite(assignment.number);
                        const isFirstUnnumbered =
                          !hasNumber &&
                          numberedMembers.length > 0 &&
                          idx === numberedMembers.length;

                        return (
                          <React.Fragment key={m.uid}>
                            {isFirstUnnumbered && (
                              <div className="pt-2 pb-1 flex items-center gap-2">
                                <div className="h-px flex-1 bg-neutral-200" />
                                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-400">
                                  Unnumbered • Alphabetical
                                </span>
                                <div className="h-px flex-1 bg-neutral-200" />
                              </div>
                            )}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl border border-neutral-200/90 bg-neutral-50/50 hover:bg-white transition-colors">
                              <div className="flex items-center gap-3 min-w-0">
                                {/* Assigned Number Badge (if given) */}
                                <div
                                  className={`min-w-[40px] h-9 px-2 rounded-xl flex items-center justify-center font-mono text-xs font-bold shrink-0 ${
                                    hasNumber
                                      ? 'bg-black text-white shadow-2xs'
                                      : 'bg-neutral-100 text-neutral-400 border border-neutral-200'
                                  }`}
                                  title={hasNumber ? `Assigned #${assignment?.number}` : 'Unnumbered (alphabetical)'}
                                >
                                  {hasNumber ? `#${assignment?.number}` : '—'}
                                </div>

                                {/* Avatar */}
                                {m.avatarUrl ? (
                                  <img
                                    src={m.avatarUrl}
                                    alt={m.name}
                                    onClick={() => handleProfileNav(m.userId)}
                                    className="w-10 h-10 rounded-full object-cover border border-neutral-200 shrink-0 cursor-pointer"
                                    referrerPolicy="no-referrer"
                                  />
                                ) : (
                                  <div
                                    onClick={() => handleProfileNav(m.userId)}
                                    className="w-10 h-10 rounded-full bg-neutral-900 text-white text-xs font-bold flex items-center justify-center shrink-0 cursor-pointer"
                                  >
                                    {m.name.charAt(0).toUpperCase()}
                                  </div>
                                )}

                                {/* Name, Handle & Role */}
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <button
                                      type="button"
                                      onClick={() => handleProfileNav(m.userId)}
                                      className="text-sm font-bold text-black hover:underline truncate cursor-pointer text-left"
                                    >
                                      {m.name}
                                    </button>
                                    {assignment?.role && (
                                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                                        {assignment.role}
                                      </span>
                                    )}
                                    {friendUids.has(m.uid) && (
                                      <span className="px-2 py-0.5 rounded-full text-[9px] font-mono bg-blue-50 text-blue-700 border border-blue-200">
                                        Friend
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-[11px] text-neutral-400 font-mono truncate">
                                    @{m.userId}
                                  </p>
                                </div>
                              </div>

                              {/* Inline Quick Edit Number & Role + Actions */}
                              <div className="flex flex-wrap items-center gap-2 sm:justify-end shrink-0">
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="number"
                                    step="1"
                                    value={hasNumber ? String(assignment?.number) : ''}
                                    onChange={(e) =>
                                      handleQuickUpdateMemberAssignment(
                                        openedGroup,
                                        m.uid,
                                        'number',
                                        e.target.value
                                      )
                                    }
                                    placeholder="#"
                                    title="Optional number in this group"
                                    className="w-16 px-2 py-1.5 rounded-lg bg-white border border-neutral-200 text-xs font-mono text-black focus:outline-none focus:ring-1 focus:ring-black"
                                  />
                                  <input
                                    type="text"
                                    value={assignment?.role || ''}
                                    onChange={(e) =>
                                      handleQuickUpdateMemberAssignment(
                                        openedGroup,
                                        m.uid,
                                        'role',
                                        e.target.value
                                      )
                                    }
                                    placeholder="Role (optional)"
                                    title="Optional role in this group"
                                    className="w-32 sm:w-36 px-2.5 py-1.5 rounded-lg bg-white border border-neutral-200 text-xs text-black focus:outline-none focus:ring-1 focus:ring-black"
                                  />
                                </div>

                                {(() => {
                                  const memberBlocked = isMemberBlocked(m);
                                  const isFriendWithMember =
                                    viewerIsAdmin ||
                                    friendUids.has(m.uid) ||
                                    areUsersFriends(activeUid, m.uid) ||
                                    areUsersFriends(currentUser?.id || activeUid, m.userId);
                                  const canCallMember = viewerIsAdmin || (!memberBlocked && isFriendWithMember);
                                  return (
                                    <>
                                      <button
                                        type="button"
                                        disabled={memberBlocked}
                                        onClick={() => !memberBlocked && onOpenDirectMessage(m)}
                                        className={`p-2 rounded-lg border ${
                                          memberBlocked
                                            ? 'bg-neutral-100 border-neutral-200 text-neutral-400 opacity-45 cursor-not-allowed'
                                            : 'bg-white border-neutral-200 text-neutral-600 hover:text-black hover:border-neutral-300 cursor-pointer'
                                        }`}
                                        title={memberBlocked ? 'Messaging disabled (Blocked)' : `Message ${m.name}`}
                                      >
                                        <MessageSquare className="w-3.5 h-3.5" />
                                      </button>
                                      {onOpenVoiceCall && (
                                        <button
                                          type="button"
                                          disabled={!canCallMember}
                                          onClick={() => canCallMember && onOpenVoiceCall(m, false)}
                                          className={`p-2 rounded-lg border ${
                                            !canCallMember
                                              ? 'bg-neutral-100 border-neutral-200 text-neutral-400 opacity-45 cursor-not-allowed'
                                              : 'bg-white border-neutral-200 text-neutral-600 hover:text-black hover:border-neutral-300 cursor-pointer'
                                          }`}
                                          title={
                                            memberBlocked
                                              ? 'Calls disabled (Blocked)'
                                              : !isFriendWithMember
                                                ? 'Friends only: Add as friend to call'
                                                : `1-on-1 Audio Call ${m.name}`
                                          }
                                        >
                                          <Phone className="w-3.5 h-3.5" />
                                        </button>
                                      )}
                                      {onOpenVideoCall && (
                                        <button
                                          type="button"
                                          disabled={!canCallMember}
                                          onClick={() => canCallMember && onOpenVideoCall(m, false)}
                                          className={`p-2 rounded-lg border ${
                                            !canCallMember
                                              ? 'bg-neutral-100 border-neutral-200 text-neutral-400 opacity-45 cursor-not-allowed'
                                              : 'bg-white border-neutral-200 text-neutral-600 hover:text-emerald-700 hover:border-emerald-300 cursor-pointer'
                                          }`}
                                          title={
                                            memberBlocked
                                              ? 'Video calls disabled (Blocked)'
                                              : !isFriendWithMember
                                                ? 'Friends only: Add as friend to video call'
                                                : `1-on-1 Video Call ${m.name}`
                                          }
                                        >
                                          <Video className="w-3.5 h-3.5" />
                                        </button>
                                      )}
                                    </>
                                  );
                                })()}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const nextUids = openedGroup.memberUids.filter(id => id !== m.uid);
                                    const nextHandles = openedGroup.memberHandles
                                      ? openedGroup.memberHandles.filter(h => h !== m.userId)
                                      : [];
                                    const updated = updateFriendGroup(openedGroup.id, {
                                      memberUids: nextUids,
                                      memberHandles: nextHandles
                                    });
                                    if (updated) {
                                      setFriendGroups(prev => prev.map(g => g.id === updated.id ? updated : g));
                                    }
                                  }}
                                  className="p-2 rounded-lg bg-white border border-neutral-200 text-neutral-400 hover:text-red-600 hover:border-red-200 cursor-pointer"
                                  title={`Remove ${m.name} from ${openedGroup.name}`}
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </React.Fragment>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            );
          })()
        ) : (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-neutral-200/90 shadow-2xs">
            <div>
              <div className="flex items-center gap-2">
                <FolderHeart className="w-5 h-5 text-emerald-600" />
                <h3 className="font-serif-lux text-lg text-black font-semibold">Custom Groups</h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                  {friendGroups.length} {friendGroups.length === 1 ? 'Group' : 'Groups'}
                </span>
              </div>
              <p className="text-xs text-neutral-500 mt-1">
                Create groups of up to {MAX_CUSTOM_GROUP_MEMBERS} friends or general people, assign each member a role and optional number per group, and open any group to view its ordered roster — a good way to organize your supply chains too.
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleOpenCreateGroup()}
              className="px-4 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-xs transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Group</span>
            </button>
          </div>

          {friendGroups.length === 0 ? (
            <div className="bg-neutral-50 border border-neutral-200/80 rounded-3xl p-10 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-white text-emerald-600 flex items-center justify-center mx-auto border border-neutral-200">
                <FolderHeart className="w-6 h-6" />
              </div>
              <h3 className="font-serif-lux text-lg text-black font-normal">
                No custom groups yet
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Create custom groups of up to {MAX_CUSTOM_GROUP_MEMBERS} people like &ldquo;Close Friends&rdquo;, &ldquo;Co-founders&rdquo;, &ldquo;VIP Backers&rdquo;, or &ldquo;Advisors&rdquo; with custom per-group roles and ordering numbers.
              </p>
              <button
                type="button"
                onClick={() => handleOpenCreateGroup()}
                className="mt-2 px-4 py-2 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Create Your First Group</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {friendGroups
                .filter(g => !localSearch.trim() || g.name.toLowerCase().includes(localSearch.toLowerCase()) || (g.description && g.description.toLowerCase().includes(localSearch.toLowerCase())))
                .map((group) => {
                  const groupMembers = resolveAndSortGroupMembers(group, allSelectableUsers);
                  
                  return (
                    <div
                      key={group.id}
                      className="bg-white border border-neutral-200 rounded-3xl p-5 shadow-xs hover:border-neutral-300 transition-all flex flex-col justify-between group"
                    >
                      <div>
                        {/* Group Title Header */}
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <button
                            type="button"
                            onClick={() => setOpenedGroupId(group.id)}
                            className="flex items-center gap-2.5 min-w-0 flex-wrap text-left cursor-pointer hover:opacity-80 transition-opacity"
                          >
                            <div
                              className="w-4 h-4 rounded-full shrink-0 border border-black/10 shadow-2xs"
                              style={{ backgroundColor: group.color || '#f59e0b' }}
                            />
                            <h4 className="font-bold text-base text-black truncate underline-offset-2 group-hover:underline">{group.name}</h4>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold shrink-0 ${
                              group.groupType === 'general'
                                ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                : 'bg-blue-100 text-blue-900 border border-blue-200'
                            }`}>
                              {group.groupType === 'general' ? 'General Group' : 'Friend Group'}
                            </span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-neutral-100 text-neutral-600 font-bold shrink-0">
                              {group.memberUids.length}/{MAX_CUSTOM_GROUP_MEMBERS}
                            </span>
                          </button>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => setOpenedGroupId(group.id)}
                              className="px-2.5 py-1 rounded-full bg-neutral-900 hover:bg-black text-white text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer mr-1"
                              title="Open group roster"
                            >
                              <FolderOpen className="w-3 h-3" />
                              <span>Open</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOpenCreateGroup(group)}
                              className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
                              title="Edit group details & members"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteGroup(group.id, group.name)}
                              className="p-1.5 rounded-full text-neutral-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                              title="Delete group"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {group.description && (
                          <p className="text-xs text-neutral-500 mb-4 leading-relaxed line-clamp-2">
                            {group.description}
                          </p>
                        )}

                        {/* Group Actions (Message only at group level; calls are strictly 1-on-1 per person) */}
                        <div className="flex flex-wrap items-center gap-2 mt-2 mb-3">
                          {(() => {
                            const firstUnblocked = groupMembers.find((m) => !isMemberBlocked(m));
                            return (
                              <button
                                type="button"
                                disabled={!firstUnblocked}
                                onClick={() => {
                                  if (firstUnblocked) onOpenDirectMessage(firstUnblocked);
                                }}
                                title={firstUnblocked ? `Message ${firstUnblocked.name}` : 'Messaging disabled (Blocked)'}
                                className="flex-1 min-w-[90px] px-3 py-1.5 rounded-lg bg-neutral-100 hover:bg-neutral-200 disabled:opacity-40 disabled:cursor-not-allowed text-neutral-700 text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                                <span>Message</span>
                              </button>
                            );
                          })()}
                        </div>

                        {/* Group Members List (Sorted: numbered first, unnumbered alphabetical) */}
                        <div className="mt-3 pt-3 border-t border-neutral-100">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                              Group Members
                            </span>
                            <button
                              type="button"
                              onClick={() => setOpenedGroupId(group.id)}
                              className="text-[11px] font-semibold text-emerald-700 hover:underline cursor-pointer"
                            >
                              Open full order &rarr;
                            </button>
                          </div>

                          {groupMembers.length === 0 ? (
                            <p className="text-xs text-neutral-400 italic py-2">
                              No members added to this group yet. Click Edit to assign people.
                            </p>
                          ) : (
                            <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto pr-1 py-1">
                              {groupMembers.map((m) => {
                                const assign = group.memberAssignments?.[m.uid];
                                const hasNum = typeof assign?.number === 'number' && Number.isFinite(assign.number);
                                return (
                                  <div
                                    key={m.uid}
                                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-50 border border-neutral-200 text-xs text-neutral-800"
                                  >
                                    {hasNum && (
                                      <span className="px-1.5 py-0.2 rounded-full bg-black text-white font-mono text-[9px] font-bold">
                                        #{assign?.number}
                                      </span>
                                    )}
                                    {m.avatarUrl ? (
                                      <img src={m.avatarUrl} alt={m.name} className="w-4 h-4 rounded-full object-cover" referrerPolicy="no-referrer" />
                                    ) : (
                                      <div className="w-4 h-4 rounded-full bg-neutral-800 text-white text-[9px] flex items-center justify-center font-bold">
                                        {m.name.charAt(0)}
                                      </div>
                                    )}
                                    <span className="font-medium text-[11px]">{m.name}</span>
                                    {assign?.role && (
                                      <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[9px] font-semibold">
                                        {assign.role}
                                      </span>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const nextUids = group.memberUids.filter(id => id !== m.uid);
                                        const nextHandles = group.memberHandles ? group.memberHandles.filter(h => h !== m.userId) : [];
                                        const updated = updateFriendGroup(group.id, {
                                          memberUids: nextUids,
                                          memberHandles: nextHandles
                                        });
                                        if (updated) {
                                          setFriendGroups(prev => prev.map(g => g.id === updated.id ? updated : g));
                                        }
                                      }}
                                      className="p-0.5 rounded-full hover:bg-neutral-200 text-neutral-400 hover:text-black cursor-pointer"
                                      title={`Remove ${m.name} from ${group.name}`}
                                    >
                                      <X className="w-3 h-3" />
                                    </button>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
        )
      ) : currentList.length === 0 ? (
        <div className="bg-neutral-50 border border-neutral-200/80 rounded-3xl p-10 text-center space-y-3 my-4">
          <div className="w-12 h-12 rounded-full bg-white text-neutral-400 flex items-center justify-center mx-auto border border-neutral-200">
            {activeTab === 'friends' ? (
              <Sparkles className="w-6 h-6 text-emerald-600" />
            ) : activeTab === 'mutuals' ? (
              <Users className="w-6 h-6 text-blue-600" />
            ) : activeTab === 'following' ? (
              <UserCheck className="w-6 h-6 text-neutral-500" />
            ) : activeTab === 'followers' ? (
              <Users className="w-6 h-6 text-neutral-500" />
            ) : (
              <Ban className="w-6 h-6 text-red-500" />
            )}
          </div>
          <h3 className="font-serif-lux text-lg text-black font-normal">
            {localSearch 
              ? `No members match "${localSearch}"`
              : activeTab === 'friends'
                ? "You haven't added any friends yet"
                : activeTab === 'mutuals'
                  ? "No mutual connections found"
                  : activeTab === 'following'
                    ? "You aren't following anyone yet"
                    : activeTab === 'followers'
                      ? "You don't have any followers yet"
                      : "No Blocked Users"}
          </h3>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto">
            {localSearch
              ? 'Try searching with a different name or handle.'
              : activeTab === 'friends'
                ? 'Send friend requests to connect and build your mutual network.'
                : activeTab === 'mutuals'
                  ? 'Connect with friends of your friends to expand your network.'
                  : activeTab === 'following'
                    ? 'Explore and follow members in the community.'
                    : activeTab === 'followers'
                      ? 'Share your profile handle to gain followers.'
                      : 'You have not blocked any members. When you block a user, they will appear here.'}
          </p>
        </div>
      ) : activeTab === 'blocked' ? (
        /* SPECIAL BLOCKED USERS LIST */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentList.map((member) => {
            const isUnblockLoading = actionLoadingIds.has(`unblock_${member.uid}`);
            return (
              <div
                key={member.uid}
                className="bg-white border border-red-100 rounded-3xl p-5 shadow-xs hover:border-red-200 transition-all flex flex-col justify-between group text-left"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div
                      onClick={() => onViewProfile(member.userId)}
                      className="flex items-center gap-3.5 min-w-0 cursor-pointer flex-1"
                    >
                      <div className="relative shrink-0">
                        {member.avatarUrl ? (
                          <img
                            src={member.avatarUrl}
                            alt={member.name}
                            className="w-13 h-13 rounded-full object-cover border-2 border-neutral-100 grayscale group-hover:grayscale-0 transition-all"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-13 h-13 rounded-full bg-neutral-800 text-white flex items-center justify-center text-lg font-serif-lux border-2 border-neutral-100">
                            {member.name ? member.name.charAt(0).toUpperCase() : 'U'}
                          </div>
                        )}
                        <div className="absolute -bottom-1 -right-1 p-1 bg-red-600 text-white rounded-full border border-white" title="Blocked">
                          <Ban className="w-3 h-3" />
                        </div>
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-semibold text-sm text-neutral-900 group-hover:underline truncate">
                            {member.name}
                          </h4>
                          <span className="shrink-0 px-2 py-0.5 rounded-md bg-red-50 text-red-700 text-[10px] font-bold border border-red-200">
                            Blocked
                          </span>
                        </div>

                        <p className="font-mono text-xs text-neutral-400 truncate">
                          @{member.userId}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onViewProfile(member.userId)}
                      className="min-h-[34px] min-w-[34px] rounded-full flex items-center justify-center text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer shrink-0"
                      title="View Member Profile"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  {member.bio && (
                    <p className="text-xs text-neutral-500 line-clamp-2 leading-relaxed mb-4">
                      {member.bio}
                    </p>
                  )}
                </div>

                <div className="pt-3 border-t border-neutral-100 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleUnblockUser(member)}
                    disabled={isUnblockLoading}
                    className="min-h-[38px] flex-1 px-4 py-1.5 rounded-full bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 border border-red-200"
                  >
                    {isUnblockLoading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <>
                        <Ban className="w-3.5 h-3.5" />
                        <span>Unblock User</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => onViewProfile(member.userId)}
                    className="min-h-[38px] px-4 py-1.5 rounded-full bg-white hover:bg-neutral-50 text-neutral-700 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-neutral-200"
                  >
                    <span>View Profile</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* STANDARD FRIENDS / FOLLOWING / FOLLOWERS LIST */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentList.map((member) => {
            const isFriend = friendUids.has(member.uid);
            const isFollowing = followingUids.has(member.uid);
            const isPendingSent = pendingSentUids.has(member.uid);
            const isPendingReceived = pendingReceivedUids.has(member.uid);

            const isFollowLoading = actionLoadingIds.has(`follow_${member.uid}`);
            const isFriendLoading = actionLoadingIds.has(`friend_${member.uid}`);
            const avgRating = getAverageRating(member.userId);
            const mutualData = mutualFriendsList.find(m => m.user.uid === member.uid);

            return (
              <div
                key={member.uid}
                className="bg-white border border-neutral-200/90 rounded-3xl p-5 shadow-xs hover:border-neutral-300 transition-all flex flex-col justify-between group text-left"
              >
                {/* Header: User Info */}
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div
                      onClick={() => onViewProfile(member.userId)}
                      className="flex flex-col items-center text-center gap-1.5 min-w-0 cursor-pointer flex-1"
                    >
                      {/* Avatar */}
                      <div className="relative shrink-0">
                        {member.avatarUrl ? (
                          <img
                            src={member.avatarUrl}
                            alt={member.name}
                            className="w-14 h-14 rounded-full object-cover border-2 border-neutral-100 group-hover:scale-105 transition-transform mx-auto"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-14 h-14 rounded-full bg-black text-white flex items-center justify-center text-lg font-serif-lux border-2 border-neutral-100 mx-auto">
                            {member.name ? member.name.charAt(0).toUpperCase() : 'U'}
                          </div>
                        )}
                      </div>

                      {/* Name and User ID underneath, indented in center */}
                      <div className="min-w-0 flex flex-col items-center text-center w-full">
                        <div className="flex items-center justify-center gap-1.5 w-full">
                          <h4 className="font-semibold text-sm text-black group-hover:underline truncate text-center">
                            {member.name}
                          </h4>
                          {isFriend && (
                            <span className="shrink-0 p-0.5 rounded-full bg-emerald-100 text-emerald-700" title="Friends">
                              <Sparkles className="w-3 h-3" />
                            </span>
                          )}
                        </div>

                        <p className="font-mono text-xs text-neutral-500 truncate text-center mt-0.5">
                          @{member.userId}
                        </p>

                        {avgRating.count > 0 && (
                          <div className="flex items-center justify-center gap-1 mt-1">
                            <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                            <span className="text-[11px] font-bold text-neutral-700">{avgRating.average}</span>
                            <span className="text-[10px] text-neutral-400">({avgRating.count})</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Favorite User star toggle */}
                    <button
                      type="button"
                      onClick={() => handleToggleFavorite(member.uid)}
                      className="min-h-[34px] min-w-[34px] rounded-full flex items-center justify-center text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer shrink-0 transition-transform hover:scale-110"
                      title={favoritedUserIds.includes(member.uid) ? "Remove from Favorites" : "Add to Favorites"}
                    >
                      <Star className={`w-4 h-4 ${
                        favoritedUserIds.includes(member.uid) ? "fill-amber-400 text-amber-500" : "text-neutral-400"
                      }`} />
                    </button>

                    {/* View Profile chevron */}
                    <button
                      type="button"
                      onClick={() => onViewProfile(member.userId)}
                      className="min-h-[34px] min-w-[34px] rounded-full flex items-center justify-center text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer shrink-0"
                      title="View Member Profile"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Bio */}
                  {member.bio && (
                    <p className="text-xs text-neutral-600 line-clamp-2 leading-relaxed mb-3">
                      {member.bio}
                    </p>
                  )}

                  {/* Member's Assigned Custom Groups */}
                  {friendGroups.filter(g => g.memberUids.includes(member.uid)).length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 mb-3">
                      {friendGroups.filter(g => g.memberUids.includes(member.uid)).map(g => (
                        <span
                          key={g.id}
                          className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-semibold text-neutral-800 bg-neutral-100 border border-neutral-200"
                        >
                          <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: g.color || '#f59e0b' }} />
                          <span>{g.name}</span>
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Mutual Friends Count & Avatars */}
                  {mutualData && mutualData.mutuals.length > 0 && (
                    <div className="mt-2 mb-3 px-3 py-1.5 bg-blue-50/60 border border-blue-100/70 rounded-2xl w-fit">
                      <div className="flex items-center gap-2">
                        <div className="flex -space-x-1.5 overflow-hidden">
                          {mutualData.mutuals.slice(0, 3).map((mut) => (
                            <div key={mut.uid} className="inline-block h-5 w-5 rounded-full ring-2 ring-white overflow-hidden bg-neutral-200">
                              {mut.avatarUrl ? (
                                <img src={mut.avatarUrl} alt={mut.name} className="h-full w-full object-cover" />
                              ) : (
                                <div className="h-full w-full flex items-center justify-center bg-black text-white text-[8px] font-bold">
                                  {mut.name.charAt(0)}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                        <span className="text-[11px] text-blue-900 font-medium">
                          {mutualData.mutuals.length} Mutual Friend{mutualData.mutuals.length > 1 ? 's' : ''}
                        </span>
                      </div>
                      <div className="text-[10px] text-blue-600 font-medium font-sans mt-0.5">
                        Shared: {mutualData.mutuals.map(m => m.name).join(', ')}
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Action Buttons: Follow, Friend Status, Group, Chat */}
                <div className="pt-3 border-t border-neutral-100 flex flex-wrap items-center gap-2">
                  {/* Group Membership Action Button */}
                  <button
                    type="button"
                    onClick={() => setSelectedFriendForGroupManagement(member)}
                    className="min-h-[38px] px-3 py-1.5 rounded-full bg-neutral-100 hover:bg-neutral-200/80 text-neutral-800 text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-neutral-200"
                    title="Assign or manage custom groups for this member"
                  >
                    <FolderHeart className="w-3.5 h-3.5 text-emerald-600" />
                    <span>General Group</span>
                    {friendGroups.filter(g => g.memberUids.includes(member.uid)).length > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-mono font-bold">
                        {friendGroups.filter(g => g.memberUids.includes(member.uid)).length}
                      </span>
                    )}
                  </button>
                  {/* 1. Follow / Unfollow Toggle */}
                  <button
                    type="button"
                    onClick={() => handleToggleFollow(member)}
                    disabled={isFollowLoading}
                    className={`min-h-[38px] flex-1 px-3 py-1.5 rounded-full text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 ${
                      isFollowing
                        ? 'bg-neutral-100 text-neutral-800 hover:bg-red-50 hover:text-red-600 border border-neutral-200'
                        : 'bg-black text-white hover:bg-neutral-800 shadow-xs'
                    }`}
                  >
                    {isFollowLoading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : isFollowing ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>

                  {/* 2. Friend Action Button */}
                  {isFriend ? (
                    <button
                      type="button"
                      onClick={() => handleUnfriend(member)}
                      disabled={isFriendLoading}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-red-50 hover:text-red-600 hover:border-red-200 text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      title="Click to Unfriend"
                    >
                      {isFriendLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Friends</span>
                        </>
                      )}
                    </button>
                  ) : isPendingSent ? (
                    <button
                      type="button"
                      onClick={() => handleCancelFriendRequest(member.uid)}
                      disabled={isFriendLoading}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-full bg-amber-50 text-amber-800 border border-amber-300 hover:bg-red-50 hover:text-red-600 hover:border-red-200 text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      title="Click to Cancel Friend Request"
                    >
                      {isFriendLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <>
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>Requested</span>
                        </>
                      )}
                    </button>
                  ) : isPendingReceived ? (
                    <button
                      type="button"
                      onClick={() => handleAcceptFriendRequest({
                        uid: member.uid,
                        userId: member.userId,
                        name: member.name,
                        avatarUrl: member.avatarUrl,
                      })}
                      disabled={isFriendLoading}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-xs"
                      title="Accept incoming request"
                    >
                      {isFriendLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Confirm</span>
                        </>
                      )}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSendFriendRequest(member)}
                      disabled={isFriendLoading}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-full bg-white text-emerald-800 border border-emerald-600/40 hover:bg-emerald-50 text-xs font-medium transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      title="Send friend request"
                    >
                      {isFriendLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Add Friend</span>
                        </>
                      )}
                    </button>
                  )}

                  {/* 3. Direct Message */}
                  {(() => {
                    const memberBlocked = isMemberBlocked(member);
                    return (
                      <button
                        type="button"
                        disabled={memberBlocked}
                        onClick={() => !memberBlocked && onOpenDirectMessage(member)}
                        className={`min-h-[38px] min-w-[38px] px-2.5 py-1.5 rounded-full border text-xs font-medium transition-all flex items-center justify-center ${
                          memberBlocked
                            ? 'bg-neutral-100 text-neutral-400 border-neutral-200 opacity-45 cursor-not-allowed'
                            : 'bg-white text-black border-neutral-300 hover:border-black hover:bg-neutral-50 cursor-pointer'
                        }`}
                        title={memberBlocked ? 'Direct messaging disabled (Blocked)' : 'Send Direct Message'}
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                      </button>
                    );
                  })()}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {/* ================= MODAL 1: CREATE / EDIT CUSTOM GROUP ================= */}
      {isCreateGroupModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-xl w-full overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                  <FolderHeart className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-black">
                    {editingGroup ? 'Edit Custom Group' : 'Create Custom Group'}
                  </h3>
                  <p className="text-xs text-neutral-500">
                    Up to {MAX_CUSTOM_GROUP_MEMBERS} people &bull; Assign a role &amp; optional number per group.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateGroupModalOpen(false)}
                className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              {/* Grouping Type Selector (Two kinds of grouping) */}
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  People Source (Max {MAX_CUSTOM_GROUP_MEMBERS})
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleSetGroupType('friend')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      groupTypeInput === 'friend'
                        ? 'bg-black text-white border-black shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Friend Group</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetGroupType('general')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      groupTypeInput === 'general'
                        ? 'bg-black text-white border-black shadow-xs'
                        : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>General People &amp; Friends</span>
                  </button>
                </div>
                <p className="text-[11px] text-neutral-500 mt-1">
                  {groupTypeInput === 'friend' 
                    ? `Friend Group: Choose from your confirmed friends (up to ${MAX_CUSTOM_GROUP_MEMBERS}).` 
                    : `General Group: Choose any friends or general people on the platform (up to ${MAX_CUSTOM_GROUP_MEMBERS}).`}
                </p>
              </div>

              {/* Group Image URL Input */}
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Group Image <span className="text-neutral-400 font-normal">(Upload or URL)</span>
                </label>
                <div className="flex gap-3">
                  <div 
                    onClick={() => groupImageFileRef.current?.click()}
                    className="w-12 h-12 rounded-xl bg-neutral-100 flex items-center justify-center shrink-0 border border-neutral-200 overflow-hidden cursor-pointer hover:bg-neutral-200 transition-colors group"
                  >
                    {groupAvatarInput ? (
                      <img src={groupAvatarInput} alt="Group preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="flex flex-col items-center">
                        <Upload className="w-4 h-4 text-neutral-400 group-hover:text-black" />
                        <span className="text-[8px] text-neutral-400 group-hover:text-black mt-0.5 uppercase font-bold">Upload</span>
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={groupImageFileRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <div className="flex-1 space-y-1.5">
                    <input
                      type="text"
                      value={groupAvatarInput}
                      onChange={(e) => setGroupAvatarInput(e.target.value)}
                      placeholder="Paste image URL here..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-black text-xs font-medium text-black"
                    />
                    {groupAvatarInput && (
                      <button
                        type="button"
                        onClick={() => setGroupAvatarInput('')}
                        className="text-[10px] text-red-500 hover:text-red-700 font-semibold cursor-pointer"
                      >
                        Remove Image
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Group Name Input */}
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Group Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={groupNameInput}
                  onChange={(e) => setGroupNameInput(e.target.value)}
                  placeholder="e.g. VIP Backers, Inner Circle, Tech Advisors..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-black text-xs font-medium text-black"
                />
              </div>

              {/* Group Description Input */}
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Description <span className="text-neutral-400 font-normal">(Optional)</span>
                </label>
                <textarea
                  value={groupDescInput}
                  onChange={(e) => setGroupDescInput(e.target.value)}
                  placeholder="What is this group for?..."
                  rows={2}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-black text-xs text-black"
                />
              </div>

              {/* Group Color Palette */}
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Group Color Badge
                </label>
                <div className="flex items-center gap-2">
                  {['#f59e0b', '#3b82f6', '#10b981', '#ec4899', '#8b5cf6', '#ef4444', '#6366f1', '#14b8a6'].map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setGroupColorInput(color)}
                      style={{ backgroundColor: color }}
                      className={`w-6 h-6 rounded-full cursor-pointer transition-transform ${
                        groupColorInput === color ? 'scale-125 ring-2 ring-black ring-offset-2' : 'hover:scale-110'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Members Selection Section */}
              <div className="pt-2 border-t border-neutral-100">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-neutral-800">
                    Select Group Members ({selectedMemberUids.length} / {MAX_CUSTOM_GROUP_MEMBERS} selected)
                  </label>
                  <span className="text-[11px] text-neutral-400">
                    Roles &amp; numbers are unique to this group
                  </span>
                </div>

                {/* Member Search input */}
                <div className="relative mb-2">
                  <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={memberSearchQuery}
                    onChange={(e) => setMemberSearchQuery(e.target.value)}
                    placeholder={groupTypeInput === 'friend' ? "Search friends by name or handle..." : "Search friends or general users..."}
                    className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-neutral-50 border border-neutral-200 text-xs text-black focus:outline-none focus:bg-white"
                  />
                </div>

                {/* Group Error Message */}
                {groupErrorMsg && (
                  <div className="mb-2 p-2 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100 flex items-center justify-between">
                    <span>{groupErrorMsg}</span>
                    <button type="button" onClick={() => setGroupErrorMsg('')} className="p-0.5 hover:bg-red-100 rounded-full text-red-700">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Connections Checklist */}
                <div className="border border-neutral-200 rounded-2xl max-h-44 overflow-y-auto divide-y divide-neutral-100">
                  {selectableUsersForGroup.length === 0 ? (
                    <div className="p-4 text-center text-xs text-neutral-400">
                      {groupTypeInput === 'friend' 
                        ? "You don't have any confirmed friends yet. Switch to General People & Friends or add friends first."
                        : "No users found in your network. Use 'Discover' to find people."
                      }
                    </div>
                  ) : (
                    selectableUsersForGroup
                      .filter(f => !memberSearchQuery.trim() || f.name.toLowerCase().includes(memberSearchQuery.toLowerCase()) || f.userId.toLowerCase().includes(memberSearchQuery.toLowerCase()))
                      .map((friend) => {
                        const isSelected = selectedMemberUids.includes(friend.uid);
                        return (
                          <div
                            key={friend.uid}
                            onClick={() => toggleMemberSelection(friend.uid)}
                            className={`p-2.5 flex items-center justify-between cursor-pointer transition-colors ${
                              isSelected ? 'bg-emerald-50/60' : 'hover:bg-neutral-50'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              {friend.avatarUrl ? (
                                <img src={friend.avatarUrl} alt={friend.name} className="w-7 h-7 rounded-full object-cover shrink-0" referrerPolicy="no-referrer" />
                              ) : (
                                <div className="w-7 h-7 rounded-full bg-neutral-900 text-white text-xs font-bold flex items-center justify-center shrink-0">
                                  {friend.name.charAt(0)}
                                </div>
                              )}
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <p className="text-xs font-semibold text-black truncate">{friend.name}</p>
                                  {groupTypeInput === 'general' && friendUids.has(friend.uid) && (
                                    <span className="px-1.5 py-0.2 rounded-full text-[9px] font-mono bg-blue-50 text-blue-700 border border-blue-200">
                                      Friend
                                    </span>
                                  )}
                                </div>
                                <p className="text-[10px] text-neutral-400 font-mono truncate">@{friend.userId}</p>
                              </div>
                            </div>

                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                            />
                          </div>
                        );
                      })
                  )}
                </div>

                {/* Per-Group Role & Number Assignment for Selected Members */}
                {selectedMemberUids.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-neutral-100 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-800">
                        Assign Optional Number &amp; Role ({selectedMemberUids.length}/{MAX_CUSTOM_GROUP_MEMBERS})
                      </span>
                      <span className="text-[10px] text-neutral-400">
                        Numbered top &bull; Unnumbered alphabetical bottom
                      </span>
                    </div>
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {selectedMemberUids.map((uid) => {
                        const member = allSelectableUsers.find((u) => u.uid === uid);
                        const memberName = member?.name || uid.replace(/^user-/, '').replace(/^demo-/, '');
                        const memberHandle = member?.userId || memberName;
                        const assignment = memberAssignmentsInput[uid] || { number: '', role: '' };

                        return (
                          <div
                            key={uid}
                            className="p-2.5 rounded-xl border border-neutral-200 bg-neutral-50/70 flex flex-col sm:flex-row sm:items-center gap-2 justify-between"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <div className="w-6 h-6 rounded-full bg-neutral-900 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                                {memberName.charAt(0).toUpperCase()}
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs font-semibold text-black truncate">{memberName}</p>
                                <p className="text-[10px] text-neutral-400 font-mono truncate">@{memberHandle}</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <input
                                type="number"
                                step="1"
                                value={assignment.number}
                                onChange={(e) => handleMemberAssignmentChange(uid, 'number', e.target.value)}
                                placeholder="# (opt)"
                                title="Optional number in this group"
                                className="w-20 px-2 py-1.5 rounded-lg bg-white border border-neutral-200 text-xs font-mono text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                              <input
                                type="text"
                                value={assignment.role}
                                onChange={(e) => handleMemberAssignmentChange(uid, 'role', e.target.value)}
                                placeholder="Role (e.g. Lead, Advisor)"
                                title="Role in this group"
                                className="w-36 px-2.5 py-1.5 rounded-lg bg-white border border-neutral-200 text-xs text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                              <button
                                type="button"
                                onClick={() => toggleMemberSelection(uid)}
                                className="p-1 rounded-full text-neutral-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                                title="Remove from group"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsCreateGroupModalOpen(false)}
                className="px-4 py-2 rounded-full border border-neutral-300 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveGroup}
                disabled={!groupNameInput.trim()}
                className="px-5 py-2 rounded-full bg-black text-white text-xs font-semibold hover:bg-neutral-800 disabled:opacity-50 cursor-pointer shadow-xs"
              >
                {editingGroup ? 'Save Changes' : 'Create Group'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL 2: MANAGE SINGLE PERSON'S MULTIPLE GROUPS ================= */}
      {selectedFriendForGroupManagement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-md w-full overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                {selectedFriendForGroupManagement.avatarUrl ? (
                  <img
                    src={selectedFriendForGroupManagement.avatarUrl}
                    alt={selectedFriendForGroupManagement.name}
                    className="w-10 h-10 rounded-full object-cover shrink-0 border border-neutral-200"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-neutral-900 text-white font-bold flex items-center justify-center shrink-0">
                    {selectedFriendForGroupManagement.name.charAt(0)}
                  </div>
                )}
                <div className="min-w-0">
                  <h3 className="font-bold text-sm text-black truncate">
                    Assign Groups for {selectedFriendForGroupManagement.name}
                  </h3>
                  <p className="text-[11px] text-neutral-400 font-mono truncate">
                    @{selectedFriendForGroupManagement.userId}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedFriendForGroupManagement(null)}
                className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-3 text-xs text-emerald-900 leading-relaxed">
                <strong>Multi-Group Membership:</strong> People can belong to multiple groups with a different role and optional number in each group.
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-neutral-700">
                  Select Groups
                </label>

                {groupErrorMsg && (
                  <div className="p-2 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100 flex items-center justify-between">
                    <span>{groupErrorMsg}</span>
                    <button type="button" onClick={() => setGroupErrorMsg('')} className="p-0.5 hover:bg-red-100 rounded-full text-red-700">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {friendGroups.length === 0 ? (
                  <div className="p-6 bg-neutral-50 border border-neutral-200/80 rounded-2xl text-center space-y-2">
                    <p className="text-xs text-neutral-500">You haven&apos;t created any custom groups yet.</p>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFriendForGroupManagement(null);
                        handleOpenCreateGroup();
                      }}
                      className="px-3.5 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Create New Group</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                    {friendGroups.map((group) => {
                      const isInGroup = group.memberUids.includes(selectedFriendForGroupManagement.uid);
                      const assign = group.memberAssignments?.[selectedFriendForGroupManagement.uid];
                      return (
                        <div
                          key={group.id}
                          className={`p-3 rounded-2xl border transition-all space-y-2 ${
                            isInGroup
                              ? 'bg-emerald-50/80 border-emerald-300 shadow-2xs'
                              : 'bg-white border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                          }`}
                        >
                          <div
                            onClick={() => toggleGroupForSelectedFriend(group)}
                            className="flex items-center justify-between cursor-pointer"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className="w-3.5 h-3.5 rounded-full shrink-0 border border-black/10"
                                style={{ backgroundColor: group.color || '#f59e0b' }}
                              />
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-black truncate">{group.name}</p>
                                {group.description && (
                                  <p className="text-[10px] text-neutral-500 truncate">{group.description}</p>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-[10px] font-mono text-neutral-400 font-bold">
                                {group.memberUids.length}/{MAX_CUSTOM_GROUP_MEMBERS}
                              </span>
                              <input
                                type="checkbox"
                                checked={isInGroup}
                                onChange={() => {}}
                                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                              />
                            </div>
                          </div>

                          {isInGroup && (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="pt-2 border-t border-emerald-200/60 flex items-center gap-2"
                            >
                              <input
                                type="number"
                                step="1"
                                value={typeof assign?.number === 'number' ? String(assign.number) : ''}
                                onChange={(e) =>
                                  handleQuickUpdateMemberAssignment(
                                    group,
                                    selectedFriendForGroupManagement.uid,
                                    'number',
                                    e.target.value
                                  )
                                }
                                placeholder="# (opt)"
                                className="w-20 px-2 py-1 rounded-lg bg-white border border-emerald-200 text-xs font-mono text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                              <input
                                type="text"
                                value={assign?.role || ''}
                                onChange={(e) =>
                                  handleQuickUpdateMemberAssignment(
                                    group,
                                    selectedFriendForGroupManagement.uid,
                                    'role',
                                    e.target.value
                                  )
                                }
                                placeholder="Role in this group (optional)"
                                className="flex-1 px-2.5 py-1 rounded-lg bg-white border border-emerald-200 text-xs text-black focus:outline-none focus:ring-1 focus:ring-black"
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setSelectedFriendForGroupManagement(null);
                  handleOpenCreateGroup();
                }}
                className="text-xs text-emerald-700 hover:underline font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Create Another Group</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedFriendForGroupManagement(null)}
                className="px-5 py-2 rounded-full bg-black text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer shadow-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL 3: CONFIRM DELETE GROUP ================= */}
      {groupToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-sm w-full overflow-hidden flex flex-col">
            <div className="p-5 border-b border-neutral-100 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-black">Delete Group</h3>
                <p className="text-[11px] text-neutral-400">This action cannot be undone.</p>
              </div>
            </div>
            <div className="p-5">
              <p className="text-xs text-neutral-600 leading-relaxed">
                Are you sure you want to delete the <span className="font-bold text-neutral-900">"{groupToDelete.name}"</span> group? Members will not be removed from your connections, but this grouping will be permanently lost.
              </p>
            </div>
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setGroupToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-200 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteGroup}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors shadow-xs"
              >
                Delete Group
              </button>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};
