import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useApp, NavTab, NotificationType } from '../context/AppContext';
import { 
  Plus, 
  Bell,
  BellRing,
  BellOff,
  Check,
  CheckCheck,
  Clock,
  ExternalLink,
  Trash2,
  Volume2,
  VolumeX,
  TrendingUp,
  Wallet,
  Landmark,
  ShoppingBag,
  MessageSquare,
  Users,
  Award,
  Rocket,
  Zap,
  Sparkles,
  X,
  Radio,
  ShieldAlert
} from 'lucide-react';
import { UserDropdown } from './UserDropdown';
import { SearchableProduct } from '../data/searchCatalog';
import { AuthSession } from '../types/auth';
import { requestBrowserNotificationPermission, getBrowserNotificationPermission } from '../utils/notificationService';

interface HeaderProps {
  currentUserSession: AuthSession | null;
  onOpenNewListing: () => void;
  onOpenProfile: () => void;
  onOpenAuthModal: () => void;
  onSelectProduct: (product: SearchableProduct) => void;
  onSelectUser: (userIdOrHandle: string) => void;
  onSelectStock?: (stock: any) => void;
  onQuickBuyStock?: (stock: any) => void;
  onOpenFullSearch?: (query: string) => void;
  onSignOut: () => void;
  onOpenInstantSwap?: () => void;
  onUpdateSession?: (user: AuthSession) => void;
  onOpenVerificationModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  currentUserSession,
  onOpenNewListing, 
  onOpenProfile,
  onOpenAuthModal,
  onSignOut,
  onOpenVerificationModal,
}) => {
  const { 
    currentTab, 
    setCurrentTab,
    notifications,
    deleteNotification,
    clearAllNotifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    notificationPrefs,
    updateNotificationPrefs,
    triggerTestNotification,
    setPreviousTab,
  } = useApp();

  // Helper for dropdown navigation
  const handleDropdownNavigate = (view: NavTab) => {
    if (view === 'portfolio') {
      setPreviousTab(null);
    } else {
      setPreviousTab(currentTab);
    }
    setCurrentTab(view);
  };

  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'unread' | 'stocks_trades' | 'finance' | 'social' | 'system'>('all');
  const [browserPermission, setBrowserPermission] = useState<NotificationPermission>('default');

  const notificationsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setBrowserPermission(getBrowserNotificationPermission());
  }, [isNotificationsOpen]);

  // Close notifications dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notificationsRef.current && !notificationsRef.current.contains(e.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleRequestPush = async () => {
    const perm = await requestBrowserNotificationPermission();
    setBrowserPermission(perm);
  };

  const filteredNotifications = useMemo(() => {
    return notifications.filter((n) => {
      if (selectedFilter === 'unread') return !n.read;
      if (selectedFilter === 'stocks_trades') return n.type === 'stocks' || n.type === 'trade';
      if (selectedFilter === 'finance') return n.type === 'wallet' || n.type === 'vault' || n.type === 'loans';
      if (selectedFilter === 'social') return n.type === 'chat' || n.type === 'social';
      if (selectedFilter === 'system') return n.type === 'security' || n.type === 'system' || n.type === 'subsidies' || n.type === 'fundraising' || n.type === 'feedback';
      return true;
    });
  }, [notifications, selectedFilter]);

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'stocks':
        return <TrendingUp className="w-4 h-4 text-emerald-600" />;
      case 'trade':
        return <Sparkles className="w-4 h-4 text-amber-600" />;
      case 'vault':
        return <Landmark className="w-4 h-4 text-amber-700" />;
      case 'wallet':
        return <Wallet className="w-4 h-4 text-sky-600" />;
      case 'marketplace':
        return <ShoppingBag className="w-4 h-4 text-purple-600" />;
      case 'social':
        return <Users className="w-4 h-4 text-pink-600" />;
      case 'chat':
        return <MessageSquare className="w-4 h-4 text-indigo-600" />;
      case 'subsidies':
        return <Award className="w-4 h-4 text-teal-600" />;
      case 'fundraising':
        return <Rocket className="w-4 h-4 text-orange-600" />;
      case 'security':
        return <ShieldAlert className="w-4 h-4 text-rose-600" />;
      default:
        return <Zap className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <header 
      className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur-md"
      style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
    >
      {/* Top Single Row Contract with Centered Title */}
      <div className="relative mx-auto flex h-16 max-w-7xl items-center justify-between px-3 sm:px-6 lg:px-8">
        
        {/* Left Side: User Dropdown Menu */}
        <div className="flex items-center gap-3 z-10">
          {currentUserSession && (
            <UserDropdown 
              currentUser={currentUserSession}
              onNavigate={handleDropdownNavigate as any}
              onViewMyProfile={onOpenProfile}
              onOpenAuthModal={onOpenAuthModal}
              onSignOut={onSignOut}
              onOpenVerificationModal={onOpenVerificationModal}
            />
          )}
        </div>

        {/* Center: FINAL FINANCE Title */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
          <button 
            type="button"
            onClick={() => {
              if (currentUserSession) {
                setCurrentTab('marketplace');
              } else {
                setCurrentTab('landing');
              }
            }}
            className="flex items-center justify-center group focus:outline-none cursor-pointer"
            title="Final Finance - Home"
          >
            <span className="font-serif text-lg sm:text-xl font-bold tracking-wider text-slate-900 group-hover:text-amber-700 transition-colors whitespace-nowrap">
              FINAL FINANCE
            </span>
          </button>
        </div>

        {/* Right Side: Notification Bell & Action Buttons */}
        <div className="flex items-center gap-2 z-10">
          {currentUserSession ? (
            <>
              {/* Icon 1: Notification Bell Dropdown */}
              <div ref={notificationsRef} className="relative inline-block text-left">
                <button
                  type="button"
                  onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                  className={`relative h-9 w-9 flex items-center justify-center rounded-xl border transition-all cursor-pointer shadow-xs ${
                    isNotificationsOpen 
                      ? 'border-amber-400 bg-amber-50 text-amber-900 ring-2 ring-amber-400/20' 
                      : 'border-slate-200 bg-white hover:bg-slate-100 text-slate-700 hover:text-slate-900 active:scale-95'
                  }`}
                  aria-label="Notifications"
                  title="Notifications & Live Alerts"
                >
                  {unreadCount > 0 ? (
                    <BellRing className="h-4 w-4 text-amber-600 animate-pulse" />
                  ) : (
                    <Bell className="h-4 w-4" />
                  )}
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-slate-950 shadow-xs ring-2 ring-white">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Popover */}
                {isNotificationsOpen && (
                  <div className="fixed sm:absolute left-3 right-3 sm:left-auto sm:right-0 top-16 sm:top-full mt-2 w-auto sm:w-104 max-w-md mx-auto bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden z-50 text-left divide-y divide-slate-100 animate-in fade-in zoom-in-95 duration-150">
                    
                    {/* Header Bar */}
                    <div className="px-4 py-3 bg-slate-50/80 flex items-center justify-between gap-2 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <div className="p-1 rounded-lg bg-amber-500/10 text-amber-700">
                          <Bell className="w-3.5 h-3.5" />
                        </div>
                        <h3 className="font-bold text-xs text-slate-900">Notifications</h3>
                        {unreadCount > 0 ? (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-extrabold shadow-xs">
                            {unreadCount} unread
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400 font-medium">All caught up</span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5">
                        {/* Audio Chime Toggle */}
                        <button
                          type="button"
                          onClick={() => updateNotificationPrefs({ soundEnabled: !notificationPrefs.soundEnabled })}
                          title={notificationPrefs.soundEnabled ? 'Mute Notification Chimes' : 'Enable Notification Chimes'}
                          className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                            notificationPrefs.soundEnabled
                              ? 'bg-amber-100/70 border-amber-200 text-amber-900'
                              : 'bg-slate-100 border-slate-200 text-slate-400'
                          }`}
                        >
                          {notificationPrefs.soundEnabled ? (
                            <Volume2 className="w-3 h-3" />
                          ) : (
                            <VolumeX className="w-3 h-3" />
                          )}
                        </button>

                        {/* Mark All Read */}
                        {unreadCount > 0 && (
                          <button
                            type="button"
                            onClick={markAllNotificationsAsRead}
                            className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-[11px] font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-50 flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                            title="Mark all notifications as read"
                          >
                            <CheckCheck className="w-3 h-3 text-emerald-600" />
                            <span>Read All</span>
                          </button>
                        )}

                        {/* Clear All */}
                        {notifications.length > 0 && (
                          <button
                            type="button"
                            onClick={clearAllNotifications}
                            className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Clear all notifications"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Filter Pills */}
                    <div className="px-3 py-2 bg-white flex items-center gap-1 overflow-x-auto no-scrollbar text-[11px] font-medium border-b border-slate-100">
                      {[
                        { id: 'all', label: 'All' },
                        { id: 'unread', label: `Unread (${unreadCount})` },
                        { id: 'stocks_trades', label: '📈 Trading' },
                        { id: 'finance', label: '💳 Wallets' },
                        { id: 'social', label: '💬 Social' },
                        { id: 'system', label: '🛡️ System' },
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setSelectedFilter(tab.id as any)}
                          className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                            selectedFilter === tab.id
                              ? 'bg-slate-900 text-white font-bold'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    {/* Desktop Push Banner prompt if not enabled */}
                    {browserPermission !== 'granted' && (
                      <div className="px-3.5 py-2 bg-amber-50/70 border-b border-amber-100 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Radio className="w-3.5 h-3.5 text-amber-700 shrink-0 animate-pulse" />
                          <span className="text-[11px] text-amber-950 font-medium truncate">
                            Enable desktop push alerts for instant trade fills
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={handleRequestPush}
                          className="px-2.5 py-0.5 rounded-md bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-bold shrink-0 cursor-pointer shadow-2xs transition-colors"
                        >
                          Allow Push
                        </button>
                      </div>
                    )}

                    {/* Notifications List */}
                    <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                      {filteredNotifications.length === 0 ? (
                        <div className="p-8 text-center space-y-2">
                          <div className="w-10 h-10 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400">
                            <BellOff className="w-5 h-5" />
                          </div>
                          <p className="text-xs font-semibold text-slate-800">No notifications in this filter</p>
                          <p className="text-[11px] text-slate-500">
                            You will receive instant alerts for trades, transfers, dividends, and community updates.
                          </p>
                          <button
                            type="button"
                            onClick={() => triggerTestNotification('stocks')}
                            className="mt-2 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                            <span>Send Test Alert</span>
                          </button>
                        </div>
                      ) : (
                        filteredNotifications.map((n) => (
                          <div
                            key={n.id}
                            className={`p-3.5 transition-colors flex items-start gap-3 hover:bg-slate-50 group cursor-pointer relative ${
                              !n.read ? 'bg-amber-50/30' : ''
                            }`}
                            onClick={() => {
                              markNotificationAsRead(n.id);
                              if (n.targetTab) {
                                setIsNotificationsOpen(false);
                                setCurrentTab(n.targetTab as any);
                              }
                            }}
                          >
                            <div className="mt-0.5 p-2 rounded-xl bg-slate-100 group-hover:bg-white group-hover:shadow-xs text-slate-700 shrink-0 transition-all border border-slate-200/50">
                              {getNotificationIcon(n.type)}
                            </div>

                            <div className="min-w-0 flex-1 pr-6">
                              <div className="flex items-center justify-between gap-1">
                                <p className={`text-xs font-bold truncate ${!n.read ? 'text-slate-950' : 'text-slate-800'}`}>
                                  {n.title}
                                </p>
                                <span className="text-[10px] text-slate-400 shrink-0 flex items-center gap-0.5">
                                  <Clock className="w-2.5 h-2.5" />
                                  {n.time}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed line-clamp-2">
                                {n.description}
                              </p>
                              {n.targetTab && (
                                <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-semibold text-amber-800 hover:underline">
                                  <span>View in {n.targetTab.toUpperCase()}</span>
                                  <ExternalLink className="w-2.5 h-2.5" />
                                </span>
                              )}
                            </div>

                            {/* Delete single notification button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteNotification(n.id);
                              }}
                              className="absolute right-2.5 top-3 p-1 rounded-md text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                              title="Delete notification"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>

                            {/* Unread indicator dot */}
                            {!n.read && (
                              <span className="absolute right-3 top-4 w-2 h-2 rounded-full bg-amber-500 ring-2 ring-white group-hover:hidden" />
                            )}
                          </div>
                        ))
                      )}
                    </div>

                    {/* Footer Quick Links & Live Simulator */}
                    <div className="p-2.5 bg-slate-50 flex items-center justify-between gap-2 px-3.5 border-t border-slate-100">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            const categories: NotificationType[] = ['stocks', 'trade', 'vault', 'wallet', 'chat', 'subsidies'];
                            const randomCat = categories[Math.floor(Math.random() * categories.length)];
                            triggerTestNotification(randomCat);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-[11px] font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-100 inline-flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                          title="Generate a real-time notification to test delivery"
                        >
                          <Sparkles className="w-3 h-3 text-amber-500" />
                          <span>Test Alert</span>
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setIsNotificationsOpen(false);
                          setCurrentTab('settings');
                        }}
                        className="text-[11px] font-bold text-slate-700 hover:text-slate-900 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <span>Alert Preferences</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Icon 2: '+' Upload Button, cleanly aligned in the top right corner */}
              <button
                type="button"
                onClick={onOpenNewListing}
                className="h-9 w-9 flex items-center justify-center rounded-xl border border-amber-300 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 transition-all shadow-xs cursor-pointer"
                aria-label="Upload Asset"
                title="Upload Asset"
              >
                <Plus className="h-4 w-4 stroke-[2.5]" />
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={onOpenAuthModal}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-xs cursor-pointer"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
