import { 
  StockItem, 
  StockOrder,
  MarketIndex, 
  StockNewsItem, 
  StockPosition, 
  StockMarketWay, 
  IPORequest, 
  IPOType, 
  IPOStatus, 
  FiveModeNetWorth, 
  BusinessDetails, 
  PersonalDetails,
  OptionItem,
  StockNewsDocumentAttachment,
  StockNewsMediaAttachment
} from '../types/stocks';

export interface MarketWayInfo {
  id: StockMarketWay;
  title: string;
  shortName: string;
  badge: string;
  tagline: string;
  description: string;
  settlementVault: string;
  settlementCurrency: string;
  tradingHours: string;
  clearingSpeed: string;
  liquidity: string;
  activeVolume24h: string;
  totalMarketCap: string;
  themeColor: {
    badgeBg: string;
    badgeText: string;
    badgeBorder: string;
    activeTabBg: string;
    accent: string;
  };
}

export const STOCK_MARKET_WAYS: MarketWayInfo[] = [
  {
    id: 'final',
    title: 'Final Stock Market',
    shortName: 'Final Market',
    badge: '⚡ Sovereign & Vault Backed',
    tagline: 'Sovereign Network Assets, AFNL & Allocated Vault Denominated Equities',
    description: 'Personal human capital equities and enterprise energy & infrastructure trusts issued through platform IPOs and cleared on Final Network Sovereign Nodes.',
    settlementVault: 'Final Coins & Sovereign Vaults',
    settlementCurrency: 'AFNL / AFNL / Sovereign Gold / Vault Tokens',
    tradingHours: '24/7/365 Continuous Clearing',
    clearingSpeed: 'Instant 0-Block Settlement',
    liquidity: '$18.4B Active Sovereign Depth',
    activeVolume24h: '$1.42B',
    totalMarketCap: '$148.5B',
    themeColor: {
      badgeBg: 'bg-amber-500/10',
      badgeText: 'text-amber-700 dark:text-amber-400',
      badgeBorder: 'border-amber-500/30',
      activeTabBg: 'bg-amber-500 text-slate-950',
      accent: 'amber'
    }
  },
  {
    id: 'stable',
    title: 'Stable Stock Market',
    shortName: 'Stable Market',
    badge: '🛡️ Yields, Treasuries & Defensive',
    tagline: 'Yield-Generating Treasury Trusts, Longevity AG & Defensive Business Stocks',
    description: 'Platform-issued corporate equities and yield-generating sovereign treasury trusts settled with 1:1 USD Stablecoins.',
    settlementVault: 'Stablecoins Reserve Vault',
    settlementCurrency: 'USDC / USDT / USD Pegged Stablecoins',
    tradingHours: '24/7 Digital Liquidity Bridge',
    clearingSpeed: 'Sub-second Digital Wire',
    liquidity: '$42.8B Institutional Liquidity',
    activeVolume24h: '$3.85B',
    totalMarketCap: '$2.15T',
    themeColor: {
      badgeBg: 'bg-emerald-500/10',
      badgeText: 'text-emerald-700 dark:text-emerald-400',
      badgeBorder: 'border-emerald-500/30',
      activeTabBg: 'bg-emerald-600 text-white',
      accent: 'emerald'
    }
  },
  {
    id: 'fiat',
    title: 'Fiat Stock Market',
    shortName: 'Fiat Market',
    badge: '🏛️ Verified Enterprise IPOs',
    tagline: 'Platform-Issued Sovereign Robotics & Aerospace Corporations',
    description: 'Corporate business stock IPOs issued with verified Delaware and global legal structures, settled natively in Fiat USD.',
    settlementVault: 'Fiat Cash & Central Banking Reserves',
    settlementCurrency: 'USD Fiat (Fedwire / ACH / Direct Clearing)',
    tradingHours: '9:30 AM - 4:00 PM EST (+ Extended 24/7 internal clearing)',
    clearingSpeed: 'T+0 Instant Internal',
    liquidity: '$120B+ Deep Market Book',
    activeVolume24h: '$24.6B',
    totalMarketCap: '$46.8T',
    themeColor: {
      badgeBg: 'bg-indigo-500/10',
      badgeText: 'text-indigo-700 dark:text-indigo-400',
      badgeBorder: 'border-indigo-500/30',
      activeTabBg: 'bg-slate-900 text-white',
      accent: 'indigo'
    }
  },
  {
    id: 'crypto',
    title: 'Cryptocurrency Stock Market',
    shortName: 'Crypto Market',
    badge: '⛓️ Decentralized Protocol IPOs',
    tagline: 'Microgrid Protocols, Quantum Compute Trusts & Crypto-Native Equities',
    description: 'Platform-issued decentralized infrastructure and quantum cryptography business stocks settled in native crypto and multi-chain assets.',
    settlementVault: 'Multi-Chain Crypto & Web3 Custody',
    settlementCurrency: 'BTC / BTC / ETH / SOL Native Assets',
    tradingHours: '24/7/365 Non-Stop Global Trading',
    clearingSpeed: 'On-Chain Verified Settlement',
    liquidity: '$28.5B High-Frequency Depth',
    activeVolume24h: '$6.90B',
    totalMarketCap: '$1.85T',
    themeColor: {
      badgeBg: 'bg-purple-500/10',
      badgeText: 'text-purple-700 dark:text-purple-400',
      badgeBorder: 'border-purple-500/30',
      activeTabBg: 'bg-purple-600 text-white',
      accent: 'purple'
    }
  },
  {
    id: 'global',
    title: 'Global Stock Market',
    shortName: 'Global Market',
    badge: '🌍 Alpaca Unified Equities',
    tagline: 'Standard US Equities & Global Assets via Alpaca Securities',
    description: 'Unified access to US-listed stocks, ETFs, and institutional assets through the Alpaca Brokerage API with real-time institutional pricing.',
    settlementVault: 'Fiat USD & Alpaca Clearing',
    settlementCurrency: 'USD Fiat',
    tradingHours: '9:30 AM - 4:00 PM EST (US Regular Session)',
    clearingSpeed: 'T+2 Standard / Instant Margin',
    liquidity: 'Deep Global Public Exchange Liquidity',
    activeVolume24h: '$480B+',
    totalMarketCap: '$52T+',
    themeColor: {
      badgeBg: 'bg-sky-500/10',
      badgeText: 'text-sky-700 dark:text-sky-400',
      badgeBorder: 'border-sky-500/30',
      activeTabBg: 'bg-sky-600 text-white',
      accent: 'sky'
    }
  }
];

// Helper to generate realistic timeframe history curves
function generateHistory(basePrice: number, volatility = 0.015) {
  const result: StockItem['history'] = {
    '1D': [],
    '1W': [],
    '1M': [],
    '1Y': [],
    '5Y': []
  };

  // 1D: 78 points
  let p = basePrice * 0.992;
  const times1D = [
    '09:30 AM', '09:45 AM', '10:00 AM', '10:15 AM', '10:30 AM', '10:45 AM',
    '11:00 AM', '11:15 AM', '11:30 AM', '11:45 AM', '12:00 PM', '12:15 PM',
    '12:30 PM', '12:45 PM', '01:00 PM', '01:15 PM', '01:30 PM', '01:45 PM',
    '02:00 PM', '02:15 PM', '02:30 PM', '02:45 PM', '03:00 PM', '03:15 PM',
    '03:30 PM', '03:45 PM', '04:00 PM'
  ];
  times1D.forEach((t, i) => {
    const step = (Math.sin(i * 0.4) * 0.005 + (Math.random() - 0.47) * volatility);
    p = Math.max(p * 0.9, p * (1 + step));
    if (i === times1D.length - 1) p = basePrice;
    result['1D'].push({
      time: t,
      price: Number(p.toFixed(2)),
      volume: Math.floor(150000 + Math.random() * 850000),
      open: Number((p * 0.998).toFixed(2)),
      high: Number((p * 1.004).toFixed(2)),
      low: Number((p * 0.995).toFixed(2)),
      close: Number(p.toFixed(2))
    });
  });

  // 1W: 35 points
  const days1W = ['Mon 09:30', 'Mon 01:00', 'Tue 09:30', 'Tue 01:00', 'Wed 09:30', 'Wed 01:00', 'Thu 09:30', 'Thu 01:00', 'Fri 09:30', 'Fri 04:00'];
  let pw = basePrice * 0.965;
  days1W.forEach((t, i) => {
    const step = (Math.cos(i * 0.6) * 0.008 + (Math.random() - 0.46) * 0.02);
    pw = Math.max(pw * 0.85, pw * (1 + step));
    if (i === days1W.length - 1) pw = basePrice;
    result['1W'].push({
      time: t,
      price: Number(pw.toFixed(2)),
      volume: Math.floor(1200000 + Math.random() * 3500000),
      open: Number((pw * 0.995).toFixed(2)),
      high: Number((pw * 1.008).toFixed(2)),
      low: Number((pw * 0.991).toFixed(2)),
      close: Number(pw.toFixed(2))
    });
  });

  // 1M: 30 days
  let pm = basePrice * 0.91;
  for (let i = 1; i <= 22; i++) {
    const step = (Math.sin(i * 0.3) * 0.01 + (Math.random() - 0.45) * 0.022);
    pm = Math.max(pm * 0.8, pm * (1 + step));
    if (i === 22) pm = basePrice;
    result['1M'].push({
      time: `Day ${i}`,
      price: Number(pm.toFixed(2)),
      volume: Math.floor(5000000 + Math.random() * 12000000)
    });
  }

  // 1Y: 12 months
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  let py = basePrice * 0.72;
  months.forEach((m, i) => {
    const step = (0.025 + Math.sin(i * 0.5) * 0.02 + (Math.random() - 0.4) * 0.035);
    py = py * (1 + step);
    if (i === months.length - 1) py = basePrice;
    result['1Y'].push({
      time: m,
      price: Number(py.toFixed(2)),
      volume: Math.floor(25000000 + Math.random() * 50000000)
    });
  });

  // 5Y: 5 years
  const years = ['2022', '2023', '2024', '2025', '2026'];
  let p5 = basePrice * 0.38;
  years.forEach((y, i) => {
    const step = 0.28 + (Math.random() - 0.3) * 0.15;
    p5 = p5 * (1 + step);
    if (i === years.length - 1) p5 = basePrice;
    result['5Y'].push({
      time: y,
      price: Number(p5.toFixed(2)),
      volume: Math.floor(100000000 + Math.random() * 250000000)
    });
  });

  return result;
}

export const MARKET_INDICES: MarketIndex[] = [
  {
    symbol: 'SOV-COMP',
    name: 'Sovereign Stock Composite Index',
    value: 6420.50,
    change: 68.40,
    changePercent: 1.08,
    sparkline: [6320, 6345, 6380, 6365, 6400, 6415, 6420.50]
  },
  {
    symbol: 'HUMAN-EQ',
    name: 'Personal Human Capital Index',
    value: 2840.25,
    change: 45.80,
    changePercent: 1.64,
    sparkline: [2780, 2795, 2815, 2800, 2825, 2835, 2840.25]
  },
  {
    symbol: 'CORP-IPO',
    name: 'Enterprise Business IPO Index',
    value: 4890.10,
    change: 52.30,
    changePercent: 1.08,
    sparkline: [4820, 4840, 4865, 4850, 4875, 4885, 4890.10]
  },
  {
    symbol: 'AFNL-VAULT',
    name: 'Final Multi-Vault Settlement Index',
    value: 14820.50,
    change: 212.40,
    changePercent: 1.45,
    sparkline: [14550, 14620, 14690, 14660, 14750, 14790, 14820.50]
  }
];

export const MARKET_WAY_INDICES: Record<StockMarketWay, MarketIndex[]> = {
  final: [
    {
      symbol: 'AFNL-COMP',
      name: 'Final Sovereign Composite Index',
      value: 14820.50,
      change: 212.40,
      changePercent: 1.45,
      sparkline: [14550, 14620, 14690, 14660, 14750, 14790, 14820.50]
    },
    {
      symbol: 'HUMAN-50',
      name: 'Sovereign Personal Human Equities',
      value: 2840.25,
      change: 45.80,
      changePercent: 1.64,
      sparkline: [2780, 2795, 2815, 2800, 2825, 2835, 2840.25]
    },
    {
      symbol: 'CLEAN-FUS',
      name: 'Clean Fusion & Energy Trust Index',
      value: 4180.20,
      change: 38.10,
      changePercent: 0.92,
      sparkline: [4120, 4135, 4150, 4145, 4165, 4172, 4180.20]
    }
  ],
  stable: [
    {
      symbol: 'VAULT-YLD',
      name: 'Global Vault Yield Benchmark',
      value: 3892.40,
      change: 16.30,
      changePercent: 0.42,
      sparkline: [3865, 3872, 3880, 3876, 3888, 3890, 3892.40]
    },
    {
      symbol: 'BIO-LONGEV',
      name: 'Longevity Therapeutics Index',
      value: 2410.15,
      change: 24.60,
      changePercent: 1.03,
      sparkline: [2380, 2390, 2400, 2395, 2405, 2408, 2410.15]
    }
  ],
  fiat: [
    {
      symbol: 'ROBOT-50',
      name: 'Sovereign Robotics & AI Enterprise Index',
      value: 5120.40,
      change: 72.30,
      changePercent: 1.43,
      sparkline: [5020, 5050, 5080, 5070, 5105, 5115, 5120.40]
    },
    {
      symbol: 'HYPERS-IND',
      name: 'Hypersonic Aerospace Enterprise Benchmark',
      value: 3640.80,
      change: 28.50,
      changePercent: 0.79,
      sparkline: [3600, 3615, 3630, 3625, 3635, 3638, 3640.80]
    }
  ],
  crypto: [
    {
      symbol: 'MICRO-GRID',
      name: 'Microgrid Energy Settlement Index',
      value: 1940.50,
      change: 32.20,
      changePercent: 1.69,
      sparkline: [1900, 1915, 1930, 1925, 1935, 1938, 1940.50]
    },
    {
      symbol: 'Q-CRYPTO',
      name: 'Quantum Cryptography & Compute Trust Index',
      value: 2680.10,
      change: 41.50,
      changePercent: 1.57,
      sparkline: [2620, 2640, 2660, 2650, 2670, 2675, 2680.10]
    }
  ],
  global: []
};

// ============================================================================
// INITIAL PUBLIC OFFERINGS (IPO) - PLATFORM-ISSUED PERSONAL & BUSINESS REGISTRY
// ============================================================================

export const INITIAL_IPO_REQUESTS: IPORequest[] = [
  // 1. PERSONAL STOCK IPOs
  {
    id: 'ipo_personal_alex_chen',
    ipoType: 'personal',
    ticker: 'ALEX',
    equityName: 'Alex Chen Sovereign Human Equity',
    issuerId: 'creator_alex_chen',
    issuerName: 'Alex Chen',
    issuerHandle: 'alex_chen',
    issuerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 1000000,
    offeringPriceUSD: 25.00,
    targetValuationUSD: 25000000,
    circulatingFloat: 450000,
    submittedAt: '2026-02-10T14:30:00Z',
    reviewedAt: '2026-02-11T09:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Swiss verified biometric credentials, multi-asset 5-mode solvency validated at $25.0M NAV, sovereign personality index approved.',
    personalDetails: {
      fullName: 'Alex Chen',
      handle: '@alex_chen',
      profession: 'Quantitative System Architect & AI Research Fellow',
      personaProfile: 'Deep-tech researcher with 12+ years pioneering zero-knowledge machine learning verifiers and high-frequency algorithmic liquidity engines.',
      personalityTraits: [
        'Visionary Architect',
        'Algorithmic Strategist',
        'High-Conviction Builder',
        'Mathematical Purist',
        'Decentralized Sovereign'
      ],
      keyAchievements: 'Engineered zero-knowledge settlement bridge clearing $4.2B volume; author of 6 peer-reviewed decentralized finance mechanisms; advisor to tier-1 decentralized liquidity vaults.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 2450000,
        sovereignGoldBarter: 3800000,
        finalCoins: 8500000,
        stableCoins: 4250000,
        cryptoAssets: 6000000,
        totalNetWorthUSD: 25000000
      },
      valuationRationale: 'Directly collateralized against verified 5-mode net worth ($25M NAV) combined with projected sovereign IP licensing royalties and high-throughput research outputs.',
      personalMission: 'To build uncompromised sovereign financial rails accessible globally with mathematical zero-knowledge guarantees.',
      mediaGallery: [
        {
          id: 'med_alex_1',
          type: 'photo',
          url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
          title: 'Executive Sovereign Portrait',
          description: 'Official verified identity portrait for Swiss Biometric Registry.',
          uploadedAt: '2026-02-10T14:35:00Z',
          isCover: true
        }
      ]
    },
    mediaGallery: [
      {
        id: 'med_alex_1',
        type: 'photo',
        url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
        title: 'Executive Sovereign Portrait',
        description: 'Official verified identity portrait for Swiss Biometric Registry.',
        uploadedAt: '2026-02-10T14:35:00Z',
        isCover: true
      }
    ]
  },
  {
    id: 'ipo_personal_satoshi',
    ipoType: 'personal',
    ticker: 'SATO',
    equityName: 'Satoshi Nakamoto Sovereign Human Equity',
    issuerId: 'creator_satoshi',
    issuerName: 'Satoshi Nakamoto',
    issuerHandle: 'satoshi_nakamoto',
    issuerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 2100000,
    offeringPriceUSD: 100.00,
    targetValuationUSD: 210000000,
    circulatingFloat: 600000,
    submittedAt: '2026-01-03T09:00:00Z',
    reviewedAt: '2026-01-04T12:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Cryptographic genesis signatures verified against early sovereign blocks, multi-vault proof of reserves validated.',
    personalDetails: {
      fullName: 'Satoshi Nakamoto',
      handle: '@satoshi_nakamoto',
      profession: 'Pioneer of Sovereign Digital Cash & Cryptographic Architecture',
      personaProfile: 'Architect of decentralized peer-to-peer settlement infrastructure, mathematical consensus engines, and trust-minimized economic systems.',
      personalityTraits: [
        'Cypherpunk Philosopher',
        'Cryptographic Architect',
        'Consensus Engineer',
        'Economic Visionary'
      ],
      keyAchievements: 'Designed the world’s first decentralized digital currency architecture; authored immutable proof-of-work consensus mechanism.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 10000000,
        sovereignGoldBarter: 50000000,
        finalCoins: 80000000,
        stableCoins: 20000000,
        cryptoAssets: 50000000,
        totalNetWorthUSD: 210000000
      },
      valuationRationale: 'Directly supported by multi-vault reserve collateral and foundational sovereign protocol patent dedications.',
      personalMission: 'A purely peer-to-peer version of electronic cash allowing direct payments without financial intermediaries.',
      mediaGallery: [
        {
          id: 'med_sato_1',
          type: 'photo',
          url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80',
          title: 'Genesis Sovereign Portrait',
          description: 'Verified public persona identity portrait.',
          uploadedAt: '2026-01-03T09:15:00Z',
          isCover: true
        }
      ]
    }
  },
  {
    id: 'ipo_personal_elena_rostova',
    ipoType: 'personal',
    ticker: 'ELEN',
    equityName: 'Dr. Elena Rostova Plasma Physics Equity',
    issuerId: 'creator_elena_rostova',
    issuerName: 'Dr. Elena Rostova',
    issuerHandle: 'elena_rostova',
    issuerAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 1500000,
    offeringPriceUSD: 20.00,
    targetValuationUSD: 30000000,
    circulatingFloat: 500000,
    submittedAt: '2026-02-01T10:00:00Z',
    reviewedAt: '2026-02-02T14:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Plasma physics patents and Zurich research lab equity validated.',
    personalDetails: {
      fullName: 'Dr. Elena Rostova',
      handle: '@elena_rostova',
      profession: 'Lead Plasma Magnetics Researcher & Fusion Systems Architect',
      personaProfile: 'Pioneered high-temperature superconducting containment geometries with record-setting Q-plasma confinement stability.',
      personalityTraits: ['Quantum Physicist', 'Precision Engineer', 'Clean Energy Innovator'],
      keyAchievements: 'Published 18 papers on magnetohydrodynamic simulation; coinventor of Generation-3 Tokamak containment ring.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 3000000,
        sovereignGoldBarter: 5000000,
        finalCoins: 12000000,
        stableCoins: 4000000,
        cryptoAssets: 6000000,
        totalNetWorthUSD: 30000000
      },
      valuationRationale: 'Backing backed by fusion patent licensing stream and sovereign research royalties.',
      personalMission: 'To unlock inexhaustible commercial fusion energy for every sovereign node.'
    }
  },
  {
    id: 'ipo_personal_lord_sterling',
    ipoType: 'personal',
    ticker: 'STRL',
    equityName: 'Lord Sterling Swiss Vault Sovereign Equity',
    issuerId: 'creator_lord_sterling',
    issuerName: 'Lord Sterling',
    issuerHandle: 'sterling_vault',
    issuerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 1200000,
    offeringPriceUSD: 35.00,
    targetValuationUSD: 42000000,
    circulatingFloat: 350000,
    submittedAt: '2026-01-15T11:00:00Z',
    reviewedAt: '2026-01-16T15:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Swiss Freeport gold custody allocations and private trustee syndicate assets audited at $42.0M NAV.',
    personalDetails: {
      fullName: 'Lord Sterling',
      handle: '@sterling_vault',
      profession: 'Swiss Freeport Trustee & Sovereign Custody Syndicate Lead',
      personaProfile: 'Veteran allocator managing sovereign multi-vault physical gold reserves and high-security depository settlement corridors.',
      personalityTraits: ['Swiss Trustee', 'Gold Standard Allocator', 'Risk Sentinel'],
      keyAchievements: 'Oversaw $1.8B in allocated gold bullion custody across Zurich and Geneva freeports.',
      backingFinalCoinId: 'admin_final_coin_master',
      backingFinalCoinSymbol: 'AFNL',
      backingFinalCoinName: 'Final Admin Coin (AFNL)',
      fiveModeNetWorth: {
        fiatUSD: 5000000,
        sovereignGoldBarter: 22000000,
        finalCoins: 8000000,
        stableCoins: 4000000,
        cryptoAssets: 3000000,
        totalNetWorthUSD: 42000000
      },
      valuationRationale: 'Direct physical bullion reserve custody backing combined with trustee syndicate cashflow yields.',
      personalMission: 'To restore gold-backed sovereign solvency and immutable multi-vault safety.'
    }
  },

  // 2. BUSINESS STOCK IPOs
  {
    id: 'ipo_business_hyperion_fusion',
    ipoType: 'business',
    ticker: 'HYPR',
    equityName: 'Hyperion Quantum Fusion Dynamics Inc.',
    issuerId: 'creator_marcus_vance',
    issuerName: 'Dr. Marcus Vance',
    issuerHandle: 'marcus_vance',
    issuerAvatar: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 10000000,
    offeringPriceUSD: 48.50,
    targetValuationUSD: 485000000,
    circulatingFloat: 2400000,
    submittedAt: '2026-02-14T11:00:00Z',
    reviewedAt: '2026-02-15T16:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Delaware C-Corp certification verified, USPTO patent portfolio cleared, reserve backing audited in sovereign vault tokens.',
    businessDetails: {
      companyName: 'Hyperion Quantum Fusion Dynamics Inc.',
      legalStructure: 'Delaware C-Corporation (Public Tier)',
      sector: 'Energy & Aerospace',
      industry: 'Magnetohydrodynamic Clean Energy & Superconducting Generators',
      registrationNumber: 'EIN-84-9921448',
      jurisdiction: 'Wilmington, Delaware, USA',
      foundedYear: 2022,
      headquarters: 'Austin, Texas & Zurich R&D Annex',
      employeeCount: '84 Full-Time Engineers & Physicists',
      website: 'https://hyperionfusion.tech',
      businessModel: 'Design, manufacturing, and grid-licensing of modular high-temperature superconducting tokamak power generators.',
      valueProposition: 'Zero-carbon continuous baseload power generation at $0.024/kWh with proprietary magnetic plasma containment.',
      annualRevenueUSD: 42000000,
      netProfitMarginPercent: 28.5,
      projectedGrowthPercent: 140,
      executives: {
        ceo: 'Dr. Marcus Vance (Founder & Chief Scientist)',
        cto: 'Elena Rostova, Ph.D. (Plasma Magnetics)',
        cfo: 'Julian Thorne (ex-Goldman Energy Partner)'
      },
      backingCoinId: 'admin_final_coin_master',
      backingCoinSymbol: 'AFNL',
      backingCoinType: 'final_coin',
      backingCoinName: 'Final Admin Coin',
      useOfProceeds: 'Expansion of Generation-3 Tokamak fabrication facility in Austin, Texas ($120M) and global commercial grid certification.'
    }
  },
  {
    id: 'ipo_business_final_treasury',
    ipoType: 'business',
    ticker: 'AFNL-EQ',
    equityName: 'Final Network Treasury Equity',
    issuerId: 'foundation_final',
    issuerName: 'Final Network Sovereign Foundation',
    issuerHandle: 'final_foundation',
    issuerAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80',
    marketWay: 'final',
    status: 'active',
    sharesOffered: 15000000,
    offeringPriceUSD: 300.00,
    targetValuationUSD: 4500000000,
    circulatingFloat: 3500000,
    submittedAt: '2026-01-01T00:00:00Z',
    reviewedAt: '2026-01-02T00:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Sovereign Clearing Foundation charter verified, multi-vault liquidity depth cleared.',
    businessDetails: {
      companyName: 'Final Network Treasury Equity',
      legalStructure: 'Sovereign Foundation Trust (Zug, Switzerland)',
      sector: 'Sovereign Reserves',
      industry: 'Sovereign Clearing Infrastructure & Multi-Vault Liquidity Pools',
      registrationNumber: 'CHE-918.234.110',
      jurisdiction: 'Zug, Switzerland',
      foundedYear: 2024,
      headquarters: 'Crypto Valley, Zug, Switzerland',
      employeeCount: '120 Distributed Protocol Engineers',
      website: 'https://finalnetwork.io',
      businessModel: 'Zero-debt multi-vault transaction clearing fees and sovereign liquidity node staking rewards.',
      valueProposition: 'Decentralized institutional settlement layer clearing over $18.4B in asset reserves with 0-block finality.',
      annualRevenueUSD: 185000000,
      netProfitMarginPercent: 42.0,
      projectedGrowthPercent: 85,
      executives: {
        ceo: 'Sovereign Foundation Governance Board',
        cto: 'Alex Chen (Principal System Architect)',
        cfo: 'Lord Sterling (Trustee Chair)'
      },
      backingCoinId: 'admin_final_coin_master',
      backingCoinSymbol: 'AFNL',
      backingCoinType: 'final_coin',
      backingCoinName: 'Final Admin Coin',
      useOfProceeds: 'Multi-vault liquidity depth expansion and global settlement node distribution.'
    }
  },
  {
    id: 'ipo_business_bio_synth',
    ipoType: 'business',
    ticker: 'BSYN',
    equityName: 'BioSynthetica Genomics International AG',
    issuerId: 'creator_dr_reed',
    issuerName: 'Dr. Evelyn Reed',
    issuerHandle: 'evelyn_reed',
    issuerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 5000000,
    offeringPriceUSD: 30.00,
    targetValuationUSD: 150000000,
    circulatingFloat: 1200000,
    submittedAt: '2026-02-05T08:15:00Z',
    reviewedAt: '2026-02-06T12:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Swiss Aktiengesellschaft registration cleared, protein folding AI patent portfolio audited.',
    businessDetails: {
      companyName: 'BioSynthetica Genomics International AG',
      legalStructure: 'Swiss Aktiengesellschaft (AG)',
      sector: 'Technology & AI',
      industry: 'Algorithmic Protein Engineering & Epigenetic Longevity Therapeutics',
      registrationNumber: 'CHE-419.882.019',
      jurisdiction: 'Basel, Switzerland',
      foundedYear: 2023,
      headquarters: 'BioValley Innovation Campus, Basel, Switzerland',
      employeeCount: '52 Computational Biologists & Chemists',
      website: 'https://biosynthetica.ch',
      businessModel: 'AI-driven therapeutic candidate discovery, clinical milestone licensing, and sovereign longevity enzyme formulation.',
      valueProposition: 'Accelerating molecular target de-risking from 4.5 years to 60 days via custom tensor-accelerated molecular dynamics.',
      annualRevenueUSD: 18500000,
      netProfitMarginPercent: 34.2,
      projectedGrowthPercent: 95,
      executives: {
        ceo: 'Dr. Evelyn Reed (Founding Director)',
        cto: 'Henri Duval, Ph.D. (Lead AI Biochemist)',
        cfo: 'Sophie Meyer (Swiss Bio-Venture Partner)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Phase-II multi-target clinical validation trials ($45M) and high-throughput automated robotics lab expansion.'
    }
  },
  {
    id: 'ipo_business_vault_yield',
    ipoType: 'business',
    ticker: 'VLT-YLD',
    equityName: 'Global Vault Yield & Treasury Corp',
    issuerId: 'creator_vault_corp',
    issuerName: 'Julian Thorne',
    issuerHandle: 'julian_thorne',
    issuerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 8000000,
    offeringPriceUSD: 100.00,
    targetValuationUSD: 800000000,
    circulatingFloat: 2500000,
    submittedAt: '2026-01-10T10:00:00Z',
    reviewedAt: '2026-01-11T16:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: '100% full reserve treasury auditing verified by Swiss regulatory accountants.',
    businessDetails: {
      companyName: 'Global Vault Yield & Treasury Corp',
      legalStructure: 'Cayman Sovereign Trust Corporation',
      sector: 'Treasuries & Yield',
      industry: 'Yield-Generating Treasury Reserves & Cashflow Asset Management',
      registrationNumber: 'KY-TR-99014',
      jurisdiction: 'George Town, Cayman Islands',
      foundedYear: 2024,
      headquarters: 'George Town & Zurich Financial Centre',
      employeeCount: '28 Fixed-Income Quants & Legal Trustees',
      website: 'https://vaultyield.capital',
      businessModel: 'Short-duration sovereign treasury yields and cashflow-yielding asset management settled in USDC.',
      valueProposition: '5.20% net annual cashflow yield backed by 1:1 audited physical reserves and zero debt leverage.',
      annualRevenueUSD: 41600000,
      netProfitMarginPercent: 92.0,
      projectedGrowthPercent: 45,
      executives: {
        ceo: 'Julian Thorne (Managing Director)',
        cto: 'Lucas Weber (Algorithmic Yield Architect)',
        cfo: 'Helena Varga (Chief Risk Officer)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Expansion of short-duration sovereign bond vault reserves and institutional liquidity rails.'
    }
  },
  {
    id: 'ipo_business_nexa_robotics',
    ipoType: 'business',
    ticker: 'NEXA',
    equityName: 'Nexa Sovereign Robotics & AI Inc.',
    issuerId: 'creator_nexa',
    issuerName: 'Vikram Mehta',
    issuerHandle: 'vikram_nexa',
    issuerAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=120&auto=format&fit=crop&q=80',
    marketWay: 'fiat',
    status: 'active',
    sharesOffered: 6000000,
    offeringPriceUSD: 65.00,
    targetValuationUSD: 390000000,
    circulatingFloat: 1800000,
    submittedAt: '2026-01-28T09:00:00Z',
    reviewedAt: '2026-01-29T14:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Delaware C-Corp filing verified, autonomous robotics factory tour cleared.',
    businessDetails: {
      companyName: 'Nexa Sovereign Robotics & AI Inc.',
      legalStructure: 'Delaware C-Corporation',
      sector: 'Technology & AI',
      industry: 'Humanoid Spatial Compute & Autonomous Factory Actuators',
      registrationNumber: 'EIN-87-3310492',
      jurisdiction: 'San Francisco, California, USA',
      foundedYear: 2023,
      headquarters: 'San Francisco, California',
      employeeCount: '78 Robotics Engineers & Machine Learning Researchers',
      website: 'https://nexarobotics.ai',
      businessModel: 'Manufacturing of general-purpose humanoid robots and spatial perception neural models.',
      valueProposition: 'Superconducting magnetic joint actuators with sub-millimeter dexterity and 20-hour continuous battery life.',
      annualRevenueUSD: 32000000,
      netProfitMarginPercent: 24.5,
      projectedGrowthPercent: 120,
      executives: {
        ceo: 'Vikram Mehta (Chief Executive Officer)',
        cto: 'Dr. Sarah Lin (Head of Spatial Perception)',
        cfo: 'David Ross (VP Finance)'
      },
      backingCoinId: 'fiat_usd_master',
      backingCoinSymbol: 'USD',
      backingCoinType: 'fiat',
      backingCoinName: 'US Dollar Fiat Reserve',
      useOfProceeds: 'Scaling automated manufacturing line 2 in Fremont and European distribution hub.'
    }
  },
  {
    id: 'ipo_business_aerostrato',
    ipoType: 'business',
    ticker: 'AERO',
    equityName: 'AeroStrato Sovereign Hypersonics Inc.',
    issuerId: 'creator_aerostrato',
    issuerName: 'Col. Gregory Vance',
    issuerHandle: 'gregory_vance',
    issuerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'fiat',
    status: 'active',
    sharesOffered: 4000000,
    offeringPriceUSD: 85.00,
    targetValuationUSD: 340000000,
    circulatingFloat: 1100000,
    submittedAt: '2026-02-02T11:00:00Z',
    reviewedAt: '2026-02-03T15:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'FAA commercial space license clearance verified, propulsion bench tests audited.',
    businessDetails: {
      companyName: 'AeroStrato Sovereign Hypersonics Inc.',
      legalStructure: 'US Aerospace C-Corporation',
      sector: 'Energy & Aerospace',
      industry: 'Suborbital High-Mach Logistics & Ceramic Matrix Scramjet Propulsion',
      registrationNumber: 'EIN-81-7782019',
      jurisdiction: 'Mojave Air and Space Port, California, USA',
      foundedYear: 2022,
      headquarters: 'Mojave Space Port, California',
      employeeCount: '64 Aerospace & Thermal Shield Engineers',
      website: 'https://aerostrato.aero',
      businessModel: 'Mach-7 point-to-point suborbital commercial cargo and rapid sovereign satellite deployment.',
      valueProposition: 'Reducing trans-oceanic cargo delivery from 14 hours to 45 minutes using reusable scramjets.',
      annualRevenueUSD: 27500000,
      netProfitMarginPercent: 22.0,
      projectedGrowthPercent: 110,
      executives: {
        ceo: 'Col. Gregory Vance (Managing Director)',
        cto: 'Dr. Kenneth Clarke (Hypersonic Aerodynamics)',
        cfo: 'Amanda Scott (CFO)'
      },
      backingCoinId: 'fiat_usd_master',
      backingCoinSymbol: 'USD',
      backingCoinType: 'fiat',
      backingCoinName: 'US Dollar Fiat Reserve',
      useOfProceeds: 'Commercial Mach-7 flight envelope testing and thermal barrier production scaling.'
    }
  },
  {
    id: 'ipo_business_solar_node',
    ipoType: 'business',
    ticker: 'SOLN',
    equityName: 'SolarNode MicroGrid Protocol Ltd.',
    issuerId: 'creator_kenji',
    issuerName: 'Kenji Sato',
    issuerHandle: 'kenji_sato',
    issuerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 2000000,
    offeringPriceUSD: 14.50,
    targetValuationUSD: 29000000,
    circulatingFloat: 800000,
    submittedAt: '2026-01-20T10:00:00Z',
    reviewedAt: '2026-01-21T12:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Singapore Pte Ltd verified, real-time microgrid energy telemetry audited.',
    businessDetails: {
      companyName: 'SolarNode MicroGrid Protocol Ltd.',
      legalStructure: 'Singapore Private Limited Company',
      sector: 'Energy & Aerospace',
      industry: 'Decentralized Microgrid Energy Arbitrage & Battery Telemetry',
      registrationNumber: 'UEN-202304991K',
      jurisdiction: 'Singapore Financial District',
      foundedYear: 2023,
      headquarters: 'Marina Bay Financial Centre, Singapore',
      employeeCount: '36 Renewable Engineers & IoT Architects',
      website: 'https://solarnode.sg',
      businessModel: 'Peer-to-peer neighborhood renewable electricity routing with real-time settlement.',
      valueProposition: 'Optimizing commercial rooftop solar energy yields by up to 24% through automated high-frequency grid dispatch.',
      annualRevenueUSD: 8200000,
      netProfitMarginPercent: 21.0,
      projectedGrowthPercent: 60,
      executives: {
        ceo: 'Kenji Sato (Managing Director)',
        cto: 'Liam O’Connor (Chief IoT Architect)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'BTC',
      backingCoinType: 'crypto',
      backingCoinName: 'Bitcoin Crypto Asset (BTC)',
      useOfProceeds: 'Expansion of microgrid IoT nodes across 1,200 commercial buildings in Southeast Asia.'
    }
  },
  {
    id: 'ipo_business_quantum_compute',
    ipoType: 'business',
    ticker: 'QBIT',
    equityName: 'Quantum Compute Sovereign Trust',
    issuerId: 'creator_qbit',
    issuerName: 'Dr. Akira Tanaka',
    issuerHandle: 'akira_qbit',
    issuerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 3500000,
    offeringPriceUSD: 80.00,
    targetValuationUSD: 280000000,
    circulatingFloat: 950000,
    submittedAt: '2026-01-25T14:00:00Z',
    reviewedAt: '2026-01-26T16:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Superconducting quantum q-bit coherence times verified on benchmark testing.',
    businessDetails: {
      companyName: 'Quantum Compute Sovereign Trust',
      legalStructure: 'Swiss Cryptographic Trust',
      sector: 'Technology & AI',
      industry: 'Superconducting Quantum Processors & Zero-Knowledge Proof Acceleration',
      registrationNumber: 'CHE-772.109.840',
      jurisdiction: 'Zurich & Lausanne, Switzerland',
      foundedYear: 2023,
      headquarters: 'EPFL Innovation Park, Lausanne, Switzerland',
      employeeCount: '44 Quantum Hardware Physicists',
      website: 'https://qbit-trust.ch',
      businessModel: 'Quantum-as-a-Service (QaaS) compute time licensing for zero-knowledge proving and molecular simulation.',
      valueProposition: '1,024-qubit error-mitigated quantum processors delivering 10,000x acceleration for cryptographic verification.',
      annualRevenueUSD: 24000000,
      netProfitMarginPercent: 31.5,
      projectedGrowthPercent: 130,
      executives: {
        ceo: 'Dr. Akira Tanaka (Founder & Chief Scientist)',
        cto: 'Dr. Celine Laurent (Quantum Hardware Lead)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'BTC',
      backingCoinType: 'crypto',
      backingCoinName: 'Bitcoin Crypto Asset (BTC)',
      useOfProceeds: 'Dilution refrigerator cluster expansion and superconducting quantum chip fabrication.'
    }
  },
  {
    id: 'ipo_business_usdc_treasuries',
    ipoType: 'business',
    ticker: 'USDC-TR',
    equityName: 'Sovereign Treasury Reserves Corp',
    issuerId: 'creator_usdc_treasury',
    issuerName: 'Alexander Vance',
    issuerHandle: 'alexander_vance',
    issuerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 10000000,
    offeringPriceUSD: 50.00,
    targetValuationUSD: 500000000,
    circulatingFloat: 4000000,
    submittedAt: '2026-01-14T09:00:00Z',
    reviewedAt: '2026-01-15T11:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Fully verified tokenized short-term US Treasury Bills backing verified by third-party attestation.',
    businessDetails: {
      companyName: 'Sovereign Treasury Reserves Corp',
      legalStructure: 'Delaware Sovereign Trust Corp',
      sector: 'Treasuries & Yield',
      industry: 'Tokenized Short-Duration US Treasuries & Fixed Income Liquidity',
      registrationNumber: 'DE-TR-88201',
      jurisdiction: 'Wilmington, Delaware, USA',
      foundedYear: 2024,
      headquarters: '1209 Orange St, Wilmington, DE',
      employeeCount: '24 Fixed-Income Quants & Compliance Directors',
      website: 'https://treasuryreserves.sovereign',
      businessModel: 'Tokenized ultra-short sovereign bills producing 5.15% APY yield, cleared and settled 1:1 against USDC stablecoins.',
      valueProposition: 'Stable institutional cash management delivering programmatic daily yield dividends settled in audited USDC.',
      annualRevenueUSD: 25750000,
      netProfitMarginPercent: 94.0,
      projectedGrowthPercent: 55,
      executives: {
        ceo: 'Alexander Vance (Chief Executive Officer)',
        cto: 'David K. Liu (Lead Financial Engineer)',
        cfo: 'Amanda Stern (Treasurer)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Expansion of short-duration US sovereign bill inventory and 1:1 on-chain settlement channels.'
    }
  },
  {
    id: 'ipo_business_real_yield_stable',
    ipoType: 'business',
    ticker: 'REAL-STBL',
    equityName: 'RealYield Sovereign Properties Inc.',
    issuerId: 'creator_realyield',
    issuerName: 'Marcus Sterling',
    issuerHandle: 'marcus_realyield',
    issuerAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 5000000,
    offeringPriceUSD: 42.00,
    targetValuationUSD: 210000000,
    circulatingFloat: 1800000,
    submittedAt: '2026-02-01T10:00:00Z',
    reviewedAt: '2026-02-02T14:30:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: '100% unencumbered commercial properties title deeds verified and audited.',
    businessDetails: {
      companyName: 'RealYield Sovereign Properties Inc.',
      legalStructure: 'Singapore Property Trust Limited',
      sector: 'Treasuries & Yield',
      industry: 'Tokenized Commercial Real Estate & Monthly Rental Dividend Vaults',
      registrationNumber: 'SG-PROP-44102',
      jurisdiction: 'Marina Bay, Singapore',
      foundedYear: 2023,
      headquarters: 'One Raffles Quay, Singapore',
      employeeCount: '35 Property Asset Managers',
      website: 'https://realyield.sg',
      businessModel: 'Prime commercial real estate portfolios generating monthly rental cashflows distributed directly in USDC stablecoins.',
      valueProposition: 'Institutional fractional real estate providing 6.40% stable dividend yields with inflation-hedged physical collateral.',
      annualRevenueUSD: 16800000,
      netProfitMarginPercent: 68.0,
      projectedGrowthPercent: 40,
      executives: {
        ceo: 'Marcus Sterling (Managing Director)',
        cto: 'Li Wei (Real Estate Tokenization Architect)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Acquisition of grade-A logistics hub properties and tenant lease escrow reserves.'
    }
  },
  {
    id: 'ipo_business_hashrate_infrastructure',
    ipoType: 'business',
    ticker: 'HASH-M',
    equityName: 'Sovereign Hashrate Infrastructure Inc.',
    issuerId: 'creator_hashrate_corp',
    issuerName: 'Viktor Lindqvist',
    issuerHandle: 'viktor_hashrate',
    issuerAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 6000000,
    offeringPriceUSD: 32.00,
    targetValuationUSD: 192000000,
    circulatingFloat: 2200000,
    submittedAt: '2026-02-10T12:00:00Z',
    reviewedAt: '2026-02-11T17:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Clean geothermal energy power purchase agreements verified and zero carbon footprint confirmed.',
    businessDetails: {
      companyName: 'Sovereign Hashrate Infrastructure Inc.',
      legalStructure: 'Reykjavik Energy & Compute Corp',
      sector: 'Energy & Aerospace',
      industry: 'Zero-Emission Geothermal Bitcoin Mining & AI Compute Clusters',
      registrationNumber: 'IS-HASH-77120',
      jurisdiction: 'Reykjavik, Iceland',
      foundedYear: 2023,
      headquarters: 'Reykjavik Geothermal Park, Iceland',
      employeeCount: '45 Infrastructure & HPC Engineers',
      website: 'https://sovereignhash.is',
      businessModel: 'Industrial-scale Bitcoin mining operations powered by stranded geothermal energy, settling daily hashrate revenues in BTC.',
      valueProposition: 'Clean-energy Bitcoin network security infrastructure delivering direct equity participation in sovereign cryptographic hashrate.',
      annualRevenueUSD: 38400000,
      netProfitMarginPercent: 42.5,
      projectedGrowthPercent: 85,
      executives: {
        ceo: 'Viktor Lindqvist (Founder & CEO)',
        cto: 'Astrid Olsen (Chief Power Systems Engineer)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'BTC',
      backingCoinType: 'crypto',
      backingCoinName: 'Bitcoin Crypto Asset (BTC)',
      useOfProceeds: 'Commissioning of 85MW geothermal turbine arrays and next-gen immersion ASIC compute pods.'
    }
  },
  {
    id: 'ipo_business_validator_prime',
    ipoType: 'business',
    ticker: 'VAL-ETH',
    equityName: 'Validator Prime Ledger Corp',
    issuerId: 'creator_val_prime',
    issuerName: 'Elena Rostova',
    issuerHandle: 'elena_val_prime',
    issuerAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 4500000,
    offeringPriceUSD: 68.00,
    targetValuationUSD: 306000000,
    circulatingFloat: 1600000,
    submittedAt: '2026-02-15T14:00:00Z',
    reviewedAt: '2026-02-16T18:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Slashing protection and institutional validator multi-sig architecture verified.',
    businessDetails: {
      companyName: 'Validator Prime Ledger Corp',
      legalStructure: 'Zug Crypto Valley Foundation AG',
      sector: 'Technology & AI',
      industry: 'Institutional Proof-of-Stake Validator Infrastructure & Staking Yields',
      registrationNumber: 'CH-VAL-33290',
      jurisdiction: 'Zug, Switzerland',
      foundedYear: 2024,
      headquarters: 'Crypto Valley, Zug, Switzerland',
      employeeCount: '30 Distributed Systems Architects',
      website: 'https://validatorprime.io',
      businessModel: 'High-availability multi-region validator node infrastructure providing institutional staking yields settled in crypto assets.',
      valueProposition: 'Slashing-insured proof-of-stake validator cluster generating continuous cryptographic staking revenue.',
      annualRevenueUSD: 28200000,
      netProfitMarginPercent: 54.0,
      projectedGrowthPercent: 90,
      executives: {
        ceo: 'Elena Rostova (Co-Founder & Executive Director)',
        cto: 'Dmitri Vane (Lead Consensus Engineer)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'ETH',
      backingCoinType: 'crypto',
      backingCoinName: 'Ethereum Crypto Asset (ETH)',
      useOfProceeds: 'Geographic node distribution across tier-4 data centers and staking insurance reserve pool.'
    }
  },
  {
    id: 'ipo_business_gold_stable',
    ipoType: 'business',
    ticker: 'GLD-STBL',
    equityName: 'Sovereign Gold-Back Reserve Inc.',
    issuerId: 'creator_gold_reserve',
    issuerName: 'Thomas Sterling',
    issuerHandle: 'sterling_gold',
    issuerAvatar: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=120&auto=format&fit=crop&q=80',
    marketWay: 'stable',
    status: 'active',
    sharesOffered: 2000000,
    offeringPriceUSD: 235.00,
    targetValuationUSD: 470000000,
    circulatingFloat: 500000,
    submittedAt: '2026-03-01T10:00:00Z',
    reviewedAt: '2026-03-02T14:00:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Physical gold vault locations in Zurich and Singapore verified and audited.',
    businessDetails: {
      companyName: 'Sovereign Gold-Back Reserve Inc.',
      legalStructure: 'International Physical Reserve Corp',
      sector: 'Treasuries & Yield',
      industry: 'Tokenized Physical Gold & Precious Metals Custody',
      registrationNumber: 'CH-GLD-88120',
      jurisdiction: 'Zurich, Switzerland',
      foundedYear: 2024,
      headquarters: 'Bahnhofstrasse 1, Zurich, Switzerland',
      employeeCount: '12 Vault Custodians & Compliance Officers',
      website: 'https://sovereigngold.ch',
      businessModel: '1:1 physically-backed gold certificates settled in USDC stablecoins.',
      valueProposition: 'Sovereign-grade physical gold ownership with instant liquidity and 0-block settlement finality.',
      annualRevenueUSD: 12400000,
      netProfitMarginPercent: 91.0,
      projectedGrowthPercent: 25,
      executives: {
        ceo: 'Thomas Sterling (Managing Director)',
        cto: 'Dmitri Ivanov (Lead Settlement Engineer)'
      },
      backingCoinId: 'usd_stable_coin',
      backingCoinSymbol: 'USDC',
      backingCoinType: 'stable_coin',
      backingCoinName: 'USD Stablecoin ($USD Pegged)',
      useOfProceeds: 'Acquisition of additional 24k bullion reserves and expansion of vault security infrastructure.'
    }
  },
  {
    id: 'ipo_business_defi_sovereign',
    ipoType: 'business',
    ticker: 'DEFI-S',
    equityName: 'Decentralized Liquidity Sovereign Ltd.',
    issuerId: 'creator_defi_sov',
    issuerName: 'Sarah Lin',
    issuerHandle: 'sarah_defi',
    issuerAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80',
    marketWay: 'crypto',
    status: 'active',
    sharesOffered: 10000000,
    offeringPriceUSD: 12.50,
    targetValuationUSD: 125000000,
    circulatingFloat: 3500000,
    submittedAt: '2026-03-05T09:00:00Z',
    reviewedAt: '2026-03-06T11:30:00Z',
    reviewedBy: 'System Protocol Admin',
    adminNotes: 'Smart contract security audits for liquidity routers passed with zero critical vulnerabilities.',
    businessDetails: {
      companyName: 'Decentralized Liquidity Sovereign Ltd.',
      legalStructure: 'Cayman Islands Tech Foundation',
      sector: 'Technology & AI',
      industry: 'Cross-Chain Liquidity Routing & AMM Protocol Infrastructure',
      registrationNumber: 'KY-DEFI-77201',
      jurisdiction: 'Grand Cayman, Cayman Islands',
      foundedYear: 2024,
      headquarters: 'George Town, Grand Cayman',
      employeeCount: '48 Protocol Researchers & Engineers',
      website: 'https://defisov.io',
      businessModel: 'Fee-sharing protocol for cross-chain asset swaps and decentralized liquidity provision.',
      valueProposition: 'Sovereign-grade liquidity depth across 12 blockchain networks with integrated risk-mitigation modules.',
      annualRevenueUSD: 34200000,
      netProfitMarginPercent: 44.5,
      projectedGrowthPercent: 110,
      executives: {
        ceo: 'Sarah Lin (Founder)',
        cto: 'David Wu (Lead Protocol Architect)'
      },
      backingCoinId: 'btc_crypto',
      backingCoinSymbol: 'ETH',
      backingCoinType: 'crypto',
      backingCoinName: 'Ethereum Crypto Asset (ETH)',
      useOfProceeds: 'Liquidity depth expansion across emerging sovereign nodes and R&D for zero-slippage routers.'
    }
  }
];

// ============================================================================
// BASE STOCKS DERIVED EXCLUSIVELY FROM APPROVED PLATFORM-ISSUED IPOs
// ============================================================================

export const INITIAL_STOCKS: StockItem[] = [
  ...INITIAL_IPO_REQUESTS.map((ipo) => {
    const isPersonal = ipo.ipoType === 'personal';
  const livePrice = ipo.offeringPriceUSD * 1.15; // Realistic active secondary price
  const changeUSD = +(livePrice - ipo.offeringPriceUSD).toFixed(2);
  const changePercent = +((changeUSD / ipo.offeringPriceUSD) * 100).toFixed(2);

  const sector = isPersonal 
    ? 'Sovereign Reserves' 
    : (ipo.businessDetails?.sector || 'Technology & AI');

  const description = isPersonal
    ? (ipo.personalDetails?.personaProfile || `${ipo.equityName} - Personal Sovereign Equity released via platform IPO.`)
    : (ipo.businessDetails?.valueProposition || ipo.businessDetails?.businessModel || `${ipo.equityName} - Corporate Enterprise Equity.`);

  return {
    ticker: ipo.ticker,
    name: ipo.equityName,
    price: +(livePrice).toFixed(2),
    changeUSD,
    changePercent,
    marketType: ipo.marketWay,
    settlementMethod: isPersonal
      ? `Final Coin Sovereign Vault (${ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL'})`
      : `${ipo.businessDetails?.backingCoinType === 'stable_coin' ? 'USD Stablecoin Clearing' : ipo.businessDetails?.backingCoinType === 'crypto' ? 'Crypto Custody Ledger' : ipo.businessDetails?.backingCoinType === 'fiat' ? 'USD Fiat Direct Clearing' : 'Final Coin Sovereign Vault'} (${ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')})`,
    high24h: +(livePrice * 1.04).toFixed(2),
    low24h: +(livePrice * 0.98).toFixed(2),
    openPrice: +(livePrice * 0.99).toFixed(2),
    prevClose: +(ipo.offeringPriceUSD * 1.02).toFixed(2),
    volume: `$${(ipo.targetValuationUSD * 0.04 / 1e6).toFixed(1)}M`,
    avgVolume: `$${(ipo.targetValuationUSD * 0.035 / 1e6).toFixed(1)}M`,
    marketCap: `$${(ipo.targetValuationUSD * 1.15 / 1e6).toFixed(1)}M`,
    peRatio: isPersonal ? 14.2 : 28.5,
    eps: isPersonal ? 1.75 : 2.45,
    dividendYield: isPersonal ? '3.80%' : '1.90%',
    beta: 1.05,
    fiftyTwoWeekHigh: +(livePrice * 1.18).toFixed(2),
    fiftyTwoWeekLow: +(ipo.offeringPriceUSD * 0.95).toFixed(2),
    sector: sector as any,
    subSector: isPersonal ? 'Personal Sovereign Equity' : ipo.businessDetails?.industry,
    description,
    exchange: 'SOVEREIGN_NODE' as const,
    analystRating: 'Strong Buy' as const,
    analystTargetUSD: +(livePrice * 1.25).toFixed(2),
    analystCount: 18,
    sparkline: [
      livePrice * 0.96,
      livePrice * 0.97,
      livePrice * 0.965,
      livePrice * 0.98,
      livePrice * 0.975,
      livePrice * 0.99,
      livePrice * 1.01,
      livePrice * 1.005,
      livePrice * 1.025,
      livePrice * 1.032
    ],
    history: generateHistory(livePrice, 0.018),
    ceo: isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.executives?.ceo,
    headquarters: isPersonal ? 'Global Sovereign Node' : ipo.businessDetails?.headquarters,
    foundedYear: isPersonal ? 2026 : ipo.businessDetails?.foundedYear,
    employeesCount: isPersonal ? '1 Principal' : ipo.businessDetails?.employeeCount,
    revenueTTM: isPersonal 
      ? `$${((ipo.personalDetails?.fiveModeNetWorth.totalNetWorthUSD || 10e6) * 0.2 / 1e6).toFixed(1)}M` 
      : `$${((ipo.businessDetails?.annualRevenueUSD || 10e6) / 1e6).toFixed(1)}M`,
    profitMargin: isPersonal ? '85.0%' : `${ipo.businessDetails?.netProfitMarginPercent || 25}%`,
    issuanceType: (isPersonal ? 'personal' : 'business') as 'personal' | 'business',
    assetCategory: (isPersonal ? 'personal' : 'business') as 'personal' | 'business',
    issuanceCoinSymbol: isPersonal 
      ? (ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL')
      : (ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')),
    issuanceCoinName: isPersonal
      ? (ipo.personalDetails?.backingFinalCoinName || 'Final Sovereign Coin')
      : (ipo.businessDetails?.backingCoinName || (ipo.marketWay === 'stable' ? 'USD Stablecoin' : ipo.marketWay === 'crypto' ? 'Bitcoin Crypto Asset' : 'Final Coin')),
    issuanceCoinType: isPersonal
      ? 'final_coin'
      : (ipo.businessDetails?.backingCoinType || (ipo.marketWay === 'stable' ? 'stable_coin' : ipo.marketWay === 'crypto' ? 'crypto' : 'final_coin')),
    issuerName: ipo.issuerName || (isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.companyName),
    issuerHandle: ipo.issuerHandle || ipo.personalDetails?.handle,
    issuerAvatar: ipo.issuerAvatar,
    ipoRefId: ipo.id
  };
}),
// ============================================================================
// SPOT MARKET ASSETS - CRYPTO & STABLE CURRENCY MOCK STOCKS
// ============================================================================
{
  ticker: 'BTC',
  name: 'Bitcoin (Spot)',
  price: 64250.00,
  changeUSD: 1250.00,
  changePercent: 1.98,
  marketType: 'crypto',
  settlementMethod: 'Crypto Custody Ledger (BTC)',
  high24h: 65100.00,
  low24h: 63800.00,
  openPrice: 63000.00,
  prevClose: 63000.00,
  volume: '$42.5B',
  avgVolume: '$38.2B',
  marketCap: '$1.26T',
  peRatio: 0,
  eps: 0,
  dividendYield: '0.00%',
  beta: 1.45,
  fiftyTwoWeekHigh: 73750.00,
  fiftyTwoWeekLow: 25000.00,
  sector: 'Digital Assets' as any,
  subSector: 'Layer 1 Cryptocurrency',
  description: 'The first and largest decentralized digital currency, functioning as a peer-to-peer electronic cash system and sovereign store of value.',
  exchange: 'SPOT_MARKET' as any,
  analystRating: 'Buy' as any,
  analystTargetUSD: 85000.00,
  analystCount: 150,
  sparkline: [63000, 63500, 63200, 64000, 63800, 64250, 64500, 64100, 64800, 64250],
  history: generateHistory(64250, 0.02)
},
{
  ticker: 'ETH',
  name: 'Ethereum (Spot)',
  price: 2450.00,
  changeUSD: -45.00,
  changePercent: -1.80,
  marketType: 'crypto',
  settlementMethod: 'Crypto Custody Ledger (ETH)',
  high24h: 2510.00,
  low24h: 2430.00,
  openPrice: 2495.00,
  prevClose: 2495.00,
  volume: '$15.8B',
  avgVolume: '$14.2B',
  marketCap: '$294B',
  peRatio: 0,
  eps: 0,
  dividendYield: '3.40%',
  beta: 1.25,
  fiftyTwoWeekHigh: 4090.00,
  fiftyTwoWeekLow: 1550.00,
  sector: 'Digital Assets' as any,
  subSector: 'Smart Contract Platform',
  description: 'The leading decentralized, open-source blockchain with smart contract functionality, serving as the foundational layer for decentralized finance (DeFi).',
  exchange: 'SPOT_MARKET' as any,
  analystRating: 'Buy' as any,
  analystTargetUSD: 3200.00,
  analystCount: 120,
  sparkline: [2500, 2480, 2490, 2460, 2470, 2440, 2455, 2435, 2465, 2450],
  history: generateHistory(2450, 0.025)
},
{
  ticker: 'USDC',
  name: 'USD Stablecoin (Spot)',
  price: 1.00,
  changeUSD: 0.0001,
  changePercent: 0.01,
  marketType: 'stable',
  settlementMethod: '1:1 USD Stablecoin (USDC)',
  high24h: 1.0005,
  low24h: 0.9995,
  openPrice: 1.00,
  prevClose: 1.00,
  volume: '$5.2B',
  avgVolume: '$4.8B',
  marketCap: '$32B',
  peRatio: 0,
  eps: 0,
  dividendYield: '0.00%',
  beta: 0.01,
  fiftyTwoWeekHigh: 1.01,
  fiftyTwoWeekLow: 0.99,
  sector: 'Digital Assets' as any,
  subSector: 'Fiat-Backed Stablecoin',
  description: 'A fully reserved, fiat-backed stablecoin pegged 1:1 to the US Dollar, providing a stable medium for trade and settlement.',
  exchange: 'SPOT_MARKET' as any,
  analystRating: 'Hold' as any,
  analystTargetUSD: 1.00,
  analystCount: 50,
  sparkline: [1.0, 1.0001, 0.9999, 1.0, 1.0002, 0.9998, 1.0, 1.0001, 1.0, 1.0],
  history: generateHistory(1.0, 0.0005)
},
{
  ticker: 'STBL-A',
  name: 'Stable Market Way Mock A',
  price: 45.20,
  changeUSD: 0.85,
  changePercent: 1.92,
  marketType: 'stable',
  settlementMethod: '1:1 USD Stablecoin (USDC)',
  high24h: 46.00,
  low24h: 44.50,
  openPrice: 44.80,
  prevClose: 44.80,
  volume: '$2.4M',
  avgVolume: '$2.1M',
  marketCap: '$45M',
  peRatio: 12.5,
  eps: 3.62,
  dividendYield: '4.50%',
  beta: 0.85,
  fiftyTwoWeekHigh: 52.00,
  fiftyTwoWeekLow: 38.00,
  sector: 'Treasuries & Yield' as any,
  subSector: 'Stable Yield Protocol',
  description: 'A mock asset representing a stablecoin-settled treasury protocol with predictable yield and low volatility.',
  exchange: 'SOVEREIGN_NODE' as any,
  analystRating: 'Buy' as any,
  analystTargetUSD: 55.00,
  analystCount: 12,
  sparkline: [44.8, 45.0, 44.9, 45.2, 45.1, 45.3, 45.2, 45.4, 45.3, 45.2],
  history: generateHistory(45.2, 0.01)
},
{
  ticker: 'STBL-B',
  name: 'Stable Market Way Mock B',
  price: 128.50,
  changeUSD: -1.20,
  changePercent: -0.93,
  marketType: 'stable',
  settlementMethod: '1:1 USD Stablecoin (USDC)',
  high24h: 130.00,
  low24h: 127.50,
  openPrice: 129.70,
  prevClose: 129.70,
  volume: '$8.5M',
  avgVolume: '$7.8M',
  marketCap: '$128M',
  peRatio: 18.2,
  eps: 7.05,
  dividendYield: '3.20%',
  beta: 0.92,
  fiftyTwoWeekHigh: 145.00,
  fiftyTwoWeekLow: 110.00,
  sector: 'Banking & Finance' as any,
  subSector: 'Stable Credit Ledger',
  description: 'A mock asset representing a decentralized credit facility settled in stablecoins, providing enterprise-grade liquidity.',
  exchange: 'SOVEREIGN_NODE' as any,
  analystRating: 'Hold' as any,
  analystTargetUSD: 135.00,
  analystCount: 8,
  sparkline: [129.7, 129.0, 128.5, 128.8, 128.2, 128.6, 128.4, 128.7, 128.5, 128.5],
  history: generateHistory(128.5, 0.008)
},
{
  ticker: 'CRPT-A',
  name: 'Crypto Market Way Mock A',
  price: 842.15,
  changeUSD: 35.40,
  changePercent: 4.39,
  marketType: 'crypto',
  settlementMethod: 'Crypto Custody Ledger (BTC)',
  high24h: 855.00,
  low24h: 810.00,
  openPrice: 806.75,
  prevClose: 806.75,
  volume: '$124M',
  avgVolume: '$110M',
  marketCap: '$8.4B',
  peRatio: 45.2,
  eps: 18.60,
  dividendYield: '0.00%',
  beta: 1.85,
  fiftyTwoWeekHigh: 1250.00,
  fiftyTwoWeekLow: 450.00,
  sector: 'Technology & AI' as any,
  subSector: 'Crypto Infrastructure',
  description: 'A high-volatility mock asset settled in Bitcoin, representing a critical piece of the sovereign cryptographic infrastructure.',
  exchange: 'CRYPTO_EQUITY' as any,
  analystRating: 'Strong Buy' as any,
  analystTargetUSD: 1100.00,
  analystCount: 25,
  sparkline: [806, 815, 810, 830, 825, 845, 835, 850, 840, 842],
  history: generateHistory(842.15, 0.04)
},
{
  ticker: 'CRPT-B',
  name: 'Crypto Market Way Mock B',
  price: 15.75,
  changeUSD: -0.45,
  changePercent: -2.78,
  marketType: 'crypto',
  settlementMethod: 'Crypto Custody Ledger (ETH)',
  high24h: 16.50,
  low24h: 15.20,
  openPrice: 16.20,
  prevClose: 16.20,
  volume: '$18.2M',
  avgVolume: '$15.5M',
  marketCap: '$157M',
  peRatio: 0,
  eps: -1.25,
  dividendYield: '0.00%',
  beta: 2.15,
  fiftyTwoWeekHigh: 45.00,
  fiftyTwoWeekLow: 8.50,
  sector: 'Energy & Aerospace' as any,
  subSector: 'Crypto Energy Protocol',
  description: 'A speculative mock asset representing a decentralized energy protocol that uses Ethereum for settlement and governance.',
  exchange: 'CRYPTO_EQUITY' as any,
  analystRating: 'Sell' as any,
  analystTargetUSD: 12.00,
  analystCount: 15,
  sparkline: [16.2, 16.0, 16.3, 15.8, 15.9, 15.5, 15.7, 15.4, 15.8, 15.75],
  history: generateHistory(15.75, 0.05)
}
];

// ============================================================================
// INITIAL USER OWNED EQUITIES - PLATFORM-ISSUED PERSONAL & BUSINESS STOCKS ONLY
// ============================================================================

export const INITIAL_USER_STOCK_POSITIONS: StockPosition[] = [
  // 1. Personal Stock Holdings
  {
    ticker: 'ALEX',
    name: 'Alex Chen Sovereign Human Equity',
    shares: 696,
    avgCostUSD: 25.00,
    currentPriceUSD: 28.75,
    totalValueUSD: 20000,
    totalGainUSD: 0,
    totalGainPercent: 0,
    dailyGainUSD: 0,
    marketType: 'final',
    settlementMethod: 'Final Coin (AFNL)',
    sector: 'Sovereign Reserves',
    dividendYield: '3.80%',
    initialBoughtDate: '2026-06-15',
    lastPurchasedDate: '2026-08-18',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },
  {
    ticker: 'ELEN',
    name: 'Dr. Elena Rostova Plasma Physics Equity',
    shares: 235,
    avgCostUSD: 20.00,
    currentPriceUSD: 23.00,
    totalValueUSD: 5397,
    totalGainUSD: 0,
    totalGainPercent: 0,
    dailyGainUSD: 0,
    marketType: 'final',
    settlementMethod: 'Final Coin (AFNL)',
    sector: 'Sovereign Reserves',
    dividendYield: '3.50%',
    initialBoughtDate: '2026-07-01',
    lastPurchasedDate: '2026-08-15',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },

  // 2. Business Stock Holdings
  {
    ticker: 'HYPR',
    name: 'Hyperion Quantum Fusion Dynamics Inc.',
    shares: 60,
    avgCostUSD: 48.50,
    currentPriceUSD: 55.78,
    totalValueUSD: 3346.80,
    totalGainUSD: 436.80,
    totalGainPercent: 15.00,
    dailyGainUSD: 84.00,
    marketType: 'final',
    settlementMethod: 'Final Coin (AFNL)',
    sector: 'Energy & Aerospace',
    dividendYield: '1.90%',
    initialBoughtDate: '2026-06-20',
    lastPurchasedDate: '2026-08-14',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },
  {
    ticker: 'AFNL-EQ',
    name: 'Final Network Treasury Equity',
    shares: 20,
    avgCostUSD: 300.00,
    currentPriceUSD: 345.00,
    totalValueUSD: 6900.00,
    totalGainUSD: 900.00,
    totalGainPercent: 15.00,
    dailyGainUSD: 196.00,
    marketType: 'final',
    settlementMethod: 'Final Coins & Sovereign Settlement Nodes',
    sector: 'Sovereign Reserves',
    dividendYield: '3.80%',
    initialBoughtDate: '2026-04-10',
    lastPurchasedDate: '2026-08-12',
    primaryFundingSourceLabel: 'Final Coin Sovereign Vault (AFNL)'
  },
  // 3. Regular Stocks: Stable Stocks Examples (Settled in 1:1 USDC Stablecoins)
  {
    ticker: 'BSYN',
    name: 'BioSynthetica Genomics International AG',
    shares: 80,
    avgCostUSD: 30.00,
    currentPriceUSD: 34.50,
    totalValueUSD: 2760.00,
    totalGainUSD: 360.00,
    totalGainPercent: 15.00,
    dailyGainUSD: 72.00,
    marketType: 'fiat',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Technology & AI',
    dividendYield: '2.10%',
    initialBoughtDate: '2026-05-15',
    lastPurchasedDate: '2026-08-01',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'VLT-YLD',
    name: 'Global Vault Yield & Treasury Corp',
    shares: 50,
    avgCostUSD: 100.00,
    currentPriceUSD: 115.00,
    totalValueUSD: 5750.00,
    totalGainUSD: 750.00,
    totalGainPercent: 15.00,
    dailyGainUSD: 45.00,
    marketType: 'fiat',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Treasuries & Yield',
    dividendYield: '5.20%',
    initialBoughtDate: '2026-03-22',
    lastPurchasedDate: '2026-07-10',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'USDC-TR',
    name: 'Sovereign Treasury Reserves Corp',
    shares: 60,
    avgCostUSD: 50.00,
    currentPriceUSD: 51.75,
    totalValueUSD: 3105.00,
    totalGainUSD: 105.00,
    totalGainPercent: 3.50,
    dailyGainUSD: 18.00,
    marketType: 'fiat',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Treasuries & Yield',
    dividendYield: '5.15%',
    initialBoughtDate: '2026-07-05',
    lastPurchasedDate: '2026-08-20',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },

  // 4. Regular Stocks: Fiat Stocks (Settled in USD Brokerage / Direct Clearing)
  {
    ticker: 'NEXA',
    name: 'Nexa Sovereign Robotics & AI Inc.',
    shares: 35,
    avgCostUSD: 65.00,
    currentPriceUSD: 74.75,
    totalValueUSD: 2616.25,
    totalGainUSD: 341.25,
    totalGainPercent: 15.00,
    dailyGainUSD: 85.00,
    marketType: 'fiat',
    settlementMethod: 'USD Fiat Direct Clearing',
    sector: 'Technology & AI',
    dividendYield: '0.80%',
    initialBoughtDate: '2026-06-12',
    lastPurchasedDate: '2026-08-14',
    primaryFundingSourceLabel: 'USD Fiat Brokerage Clearing',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'HASH-M',
    name: 'Sovereign Hashrate Infrastructure Inc.',
    shares: 60,
    avgCostUSD: 31.00,
    currentPriceUSD: 33.89,
    totalValueUSD: 2033.40,
    totalGainUSD: 173.40,
    totalGainPercent: 9.32,
    dailyGainUSD: 45.00,
    marketType: 'final',
    settlementMethod: 'Final Coins ($AFNL)',
    sector: 'Technology & AI',
    dividendYield: '2.50%',
    initialBoughtDate: '2026-08-05',
    lastPurchasedDate: '2026-08-25',
    primaryFundingSourceLabel: '$AFNL',
    assetCategory: 'business',
    isSpotStock: false,
    isEquity: true
  },

  // 5. Regular Stocks: Crypto Stocks Examples (Settled in BTC / ETH Cryptocurrencies)
  {
    ticker: 'SOLN',
    name: 'SolarNode MicroGrid Protocol Ltd.',
    shares: 100,
    avgCostUSD: 14.50,
    currentPriceUSD: 16.68,
    totalValueUSD: 1668.00,
    totalGainUSD: 218.00,
    totalGainPercent: 15.03,
    dailyGainUSD: 36.00,
    marketType: 'fiat',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    sector: 'Energy & Aerospace',
    dividendYield: '2.40%',
    initialBoughtDate: '2026-05-14',
    lastPurchasedDate: '2026-08-16',
    primaryFundingSourceLabel: 'Bitcoin Crypto Asset (BTC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'QBIT',
    name: 'Quantum Compute Sovereign Trust',
    shares: 20,
    avgCostUSD: 85.00,
    currentPriceUSD: 92.00,
    totalValueUSD: 1840.00,
    totalGainUSD: 140.00,
    totalGainPercent: 8.24,
    dailyGainUSD: 28.00,
    marketType: 'fiat',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    sector: 'Technology & AI',
    dividendYield: '1.20%',
    initialBoughtDate: '2026-06-20',
    lastPurchasedDate: '2026-08-22',
    primaryFundingSourceLabel: 'Bitcoin Crypto Asset (BTC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'REAL-STBL',
    name: 'RealYield Sovereign Properties Inc.',
    shares: 120,
    avgCostUSD: 42.00,
    currentPriceUSD: 48.50,
    totalValueUSD: 5820.00,
    totalGainUSD: 780.00,
    totalGainPercent: 15.48,
    dailyGainUSD: 120.00,
    marketType: 'fiat',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Treasuries & Yield',
    dividendYield: '6.40%',
    initialBoughtDate: '2026-04-10',
    lastPurchasedDate: '2026-08-22',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'BTC',
    name: 'Bitcoin (Spot)',
    shares: 0.25,
    avgCostUSD: 58000.00,
    currentPriceUSD: 64250.00,
    totalValueUSD: 16062.50,
    totalGainUSD: 1562.50,
    totalGainPercent: 10.78,
    dailyGainUSD: 312.50,
    marketType: 'crypto',
    settlementMethod: 'Crypto Custody Ledger (BTC)',
    sector: 'Crypto Treasuries & Mining',
    dividendYield: '0.00%',
    initialBoughtDate: '2026-05-10',
    lastPurchasedDate: '2026-08-15',
    primaryFundingSourceLabel: 'Sovereign Mining Reserve',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'ETH',
    name: 'Ethereum (Spot)',
    shares: 5.0,
    avgCostUSD: 2200.00,
    currentPriceUSD: 2450.00,
    totalValueUSD: 12250.00,
    totalGainUSD: 1250.00,
    totalGainPercent: 11.36,
    dailyGainUSD: -225.00,
    marketType: 'crypto',
    settlementMethod: 'Crypto Custody Ledger (ETH)',
    sector: 'Crypto Treasuries & Mining',
    dividendYield: '3.40%',
    initialBoughtDate: '2026-06-01',
    lastPurchasedDate: '2026-08-20',
    primaryFundingSourceLabel: 'Yield Bearing Vault',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'GLD-STBL',
    name: 'Sovereign Gold-Back Reserve Inc.',
    shares: 10,
    avgCostUSD: 230.00,
    currentPriceUSD: 235.00,
    totalValueUSD: 2350.00,
    totalGainUSD: 50.00,
    totalGainPercent: 2.17,
    dailyGainUSD: 15.00,
    marketType: 'fiat',
    settlementMethod: '1:1 USD Stablecoin (USDC)',
    sector: 'Treasuries & Yield',
    dividendYield: '0.00%',
    initialBoughtDate: '2026-08-01',
    lastPurchasedDate: '2026-08-25',
    primaryFundingSourceLabel: 'USD Stablecoin Reserve Vault (USDC)',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  },
  {
    ticker: 'DEFI-S',
    name: 'Decentralized Liquidity Sovereign Ltd.',
    shares: 500,
    avgCostUSD: 10.00,
    currentPriceUSD: 12.50,
    totalValueUSD: 6250.00,
    totalGainUSD: 1250.00,
    totalGainPercent: 25.00,
    dailyGainUSD: 350.00,
    marketType: 'crypto',
    settlementMethod: 'Crypto Custody Ledger (ETH)',
    sector: 'Technology & AI',
    dividendYield: '4.20%',
    initialBoughtDate: '2026-07-20',
    lastPurchasedDate: '2026-08-22',
    primaryFundingSourceLabel: 'Yield Bearing Vault',
    assetCategory: 'spot',
    isEquity: false,
    isSpotStock: true
  }
];

// ============================================================================
// INITIAL USER STOCK ORDERS (INCLUDING DERIVATIVE CONTRACT EXAMPLES)
// ============================================================================

export const DEFAULT_INITIAL_STOCK_ORDERS: StockOrder[] = [
  // --- SPOT BUY & SELL HISTORY EXAMPLES (DONE / CLOSED POSITIONS, NOT ACTIVE) ---
  {
    id: 'ord-spot-1',
    ticker: 'SATO',
    stockName: 'Satoshi Nakamoto Sovereign Human Equity',
    side: 'sell',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 250,
    price: 108.40,
    totalUSD: 27100.00,
    status: 'filled',
    timestamp: '03:15:22 PM',
    dateIso: '2026-08-22T15:15:22.000Z',
    sector: 'Sovereign Reserves',
    isPersonalStock: true,
    issuerName: 'Satoshi Nakamoto',
    paymentSource: { id: 'final-sato', type: 'wallet_final', label: '$SATO', subtitle: 'Satoshi Sovereign Vault', balanceUSD: 2100000, iconType: 'wallet' }
  },
  {
    id: 'ord-spot-1b',
    ticker: 'SATO',
    stockName: 'Satoshi Nakamoto Sovereign Human Equity',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 250,
    price: 100.00,
    totalUSD: 25000.00,
    status: 'filled',
    timestamp: '09:15:22 AM',
    dateIso: '2026-08-18T09:15:22.000Z',
    sector: 'Sovereign Reserves',
    isPersonalStock: true,
    issuerName: 'Satoshi Nakamoto',
    paymentSource: { id: 'final-sato', type: 'wallet_final', label: '$SATO', subtitle: 'Satoshi Sovereign Vault', balanceUSD: 2100000, iconType: 'wallet' }
  },
  {
    id: 'ord-spot-2',
    ticker: 'STRL',
    stockName: 'Lord Sterling Swiss Vault Sovereign Equity',
    side: 'sell',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 150,
    price: 38.20,
    totalUSD: 5730.00,
    status: 'filled',
    timestamp: '02:45:10 PM',
    dateIso: '2026-08-21T14:45:10.000Z',
    sector: 'Sovereign Reserves',
    isPersonalStock: true,
    issuerName: 'Lord Sterling',
    paymentSource: { id: 'final-strl', type: 'wallet_final', label: '$STRL', subtitle: 'Sterling Swiss Vault', balanceUSD: 850000, iconType: 'wallet' }
  },
  {
    id: 'ord-spot-3',
    ticker: 'BSYN',
    stockName: 'BioSynthetica Sovereign Therapeutics',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 300,
    price: 34.50,
    totalUSD: 10350.00,
    status: 'filled',
    timestamp: '10:30:00 AM',
    dateIso: '2026-08-20T10:30:00.000Z',
    sector: 'BioTech & Health',
    isBusinessStock: true,
    issuerName: 'BioSynthetica Corp',
    paymentSource: { id: 'final-bsyn', type: 'wallet_final', label: '$BSYN', subtitle: 'BioSynthetica Sovereign Vault', balanceUSD: 100000, iconType: 'wallet' }
  },
  {
    id: 'ord-spot-4',
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Protocol Ltd.',
    side: 'sell',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 180,
    price: 16.68,
    totalUSD: 3002.40,
    status: 'filled',
    timestamp: '11:20:15 AM',
    dateIso: '2026-08-23T11:20:15.000Z',
    sector: 'Energy & Aerospace',
    isBusinessStock: true,
    issuerName: 'Kenji Sato',
    paymentSource: { id: 'final-soln', type: 'wallet_final', label: '$SOLN', subtitle: 'Solar Sovereign Vault', balanceUSD: 120000, iconType: 'wallet' }
  },
  {
    id: 'ord-spot-5',
    ticker: 'QBIT',
    stockName: 'Quantum Bit Compute Architecture',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'spot',
    shares: 400,
    price: 92.00,
    totalUSD: 36800.00,
    status: 'filled',
    timestamp: '04:10:00 PM',
    dateIso: '2026-08-24T16:10:00.000Z',
    sector: 'Technology & AI',
    isBusinessStock: true,
    issuerName: 'Quantum Trust',
    paymentSource: { id: 'final-qbit', type: 'wallet_final', label: '$QBIT', subtitle: 'Quantum Compute Vault', balanceUSD: 85000, iconType: 'wallet' }
  },
  // --- PEOPLE (PERSONAL SOVEREIGN STOCKS) ---
  {
    id: 'ord-samp-call-alex',
    ticker: 'ALEX',
    stockName: 'Alex Chen Sovereign Human Equity [Call Option (32.00 Strike)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'call_option',
    strikePrice: 32.00,
    expiryDate: '2026-10-31',
    premiumUSD: 250.00,
    shares: 696,
    price: 26.92,
    totalUSD: 18736.32,
    totalGainUSD: 1336.32,
    totalGainPercent: 7.68,
    paymentSource: { id: 'final-alex', type: 'wallet_final', label: '$ALEX', subtitle: 'Alex Chen Sovereign Vault', balanceUSD: 2840000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '09:15:22 AM',
    dateIso: '2026-08-20T09:15:22.000Z',
    sector: 'Sovereign Reserves',
    tradeSlipId: 'SLIP-ALEX-CALL',
    isPersonalStock: true,
    issuerName: 'Alex Chen'
  },
  {
    id: 'ord-samp-sell-alex-call',
    ticker: 'ALEX',
    stockName: 'Alex Chen Sovereign Human Equity [Call Option (30.00 Strike)]',
    side: 'sell',
    orderType: 'market',
    derivativeType: 'call_option',
    strikePrice: 30.00,
    expiryDate: '2026-09-30',
    premiumUSD: 280.00,
    shares: 300,
    price: 28.50,
    totalUSD: 8550.00,
    totalGainUSD: 640.00,
    totalGainPercent: 8.09,
    paymentSource: { id: 'final-alex', type: 'wallet_final', label: '$ALEX', subtitle: 'Alex Chen Sovereign Vault', balanceUSD: 2840000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '02:40:15 PM',
    dateIso: '2026-08-27T14:40:15.000Z',
    sector: 'Sovereign Reserves',
    tradeSlipId: 'SLIP-ALEX-CLOSE',
    isPersonalStock: true,
    issuerName: 'Alex Chen'
  },
  {
    id: 'ord-samp-put-elen',
    ticker: 'ELEN',
    stockName: 'Dr. Elena Rostova Plasma Physics Equity [Put Option (28.00 Strike)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'put_option',
    strikePrice: 28.00,
    expiryDate: '2026-09-15',
    premiumUSD: 190.00,
    shares: 520,
    price: 24.50,
    totalUSD: 12740.00,
    totalGainUSD: 890.50,
    totalGainPercent: 7.51,
    paymentSource: { id: 'final-elen', type: 'wallet_final', label: '$ELEN', subtitle: 'Elena Rostova Sovereign Vault', balanceUSD: 1200000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '10:22:04 AM',
    dateIso: '2026-08-21T10:22:04.000Z',
    sector: 'Sovereign Reserves',
    tradeSlipId: 'SLIP-ELEN-PUT',
    isPersonalStock: true,
    issuerName: 'Dr. Elena Rostova'
  },
  {
    id: 'ord-samp-sell-elen-put',
    ticker: 'ELEN',
    stockName: 'Dr. Elena Rostova Plasma Physics Equity [Put Option (26.00 Strike)]',
    side: 'sell',
    orderType: 'market',
    derivativeType: 'put_option',
    strikePrice: 26.00,
    expiryDate: '2026-10-15',
    premiumUSD: 140.00,
    shares: 200,
    price: 25.80,
    totalUSD: 5160.00,
    totalGainUSD: 380.00,
    totalGainPercent: 7.95,
    paymentSource: { id: 'final-elen', type: 'wallet_final', label: '$ELEN', subtitle: 'Elena Rostova Sovereign Vault', balanceUSD: 1200000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '11:15:20 AM',
    dateIso: '2026-08-27T11:15:20.000Z',
    sector: 'Sovereign Reserves',
    tradeSlipId: 'SLIP-ELEN-CLOSE',
    isPersonalStock: true,
    issuerName: 'Dr. Elena Rostova'
  },
  {
    id: 'ord-samp-futl-vanc',
    ticker: 'VANC',
    stockName: 'Marcus Vance Algorithmic Neural Equity [Futures Long (10x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_long',
    leverage: 10,
    expiryDate: '2026-12-15',
    shares: 400,
    price: 42.10,
    totalUSD: 16840.00,
    totalGainUSD: 1420.00,
    totalGainPercent: 9.21,
    paymentSource: { id: 'final-vanc', type: 'wallet_final', label: '$VANC', subtitle: 'Marcus Vance Sovereign Vault', balanceUSD: 950000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '11:05:18 AM',
    dateIso: '2026-08-22T11:05:18.000Z',
    sector: 'Technology & AI',
    tradeSlipId: 'SLIP-VANC-FUT',
    isPersonalStock: true,
    issuerName: 'Marcus Vance'
  },
  {
    id: 'ord-samp-call-slin',
    ticker: 'SLIN',
    stockName: 'Sarah Lin Aerospace Neuro-Robotics Equity [Call Option (45.00 Strike)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'call_option',
    strikePrice: 45.00,
    expiryDate: '2026-11-20',
    premiumUSD: 310.00,
    shares: 350,
    price: 41.20,
    totalUSD: 14420.00,
    totalGainUSD: 670.00,
    totalGainPercent: 4.87,
    paymentSource: { id: 'final-slin', type: 'wallet_final', label: '$SLIN', subtitle: 'Sarah Lin Sovereign Vault', balanceUSD: 820000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '01:30:44 PM',
    dateIso: '2026-08-23T13:30:44.000Z',
    sector: 'Energy & Aerospace',
    tradeSlipId: 'SLIP-SLIN-CALL',
    isPersonalStock: true,
    issuerName: 'Sarah Lin'
  },
  {
    id: 'ord-samp-futs-khal',
    ticker: 'KHAL',
    stockName: 'Tariq Khalid Sovereign Desalination Equity [Futures Short (5x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_short',
    leverage: 5,
    expiryDate: '2026-11-10',
    shares: 600,
    price: 18.50,
    totalUSD: 11100.00,
    totalGainUSD: 520.00,
    totalGainPercent: 4.91,
    paymentSource: { id: 'final-khal', type: 'wallet_final', label: '$KHAL', subtitle: 'Tariq Khalid Sovereign Vault', balanceUSD: 670000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '02:15:30 PM',
    dateIso: '2026-08-23T14:15:30.000Z',
    sector: 'BioTech & Health',
    tradeSlipId: 'SLIP-KHAL-SHORT',
    isPersonalStock: true,
    issuerName: 'Tariq Khalid'
  },

  // --- BUSINESSES (BUSINESS SOVEREIGN STOCKS) ---
  {
    id: 'ord-samp-futl-hypr',
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion Energy [Futures Long (10x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_long',
    leverage: 10,
    expiryDate: '2026-12-15',
    shares: 580,
    price: 55.78,
    totalUSD: 32352.40,
    totalGainUSD: 2840.00,
    totalGainPercent: 9.62,
    paymentSource: { id: 'final-hypr', type: 'wallet_final', label: '$HYPR', subtitle: 'Hyperion Energy Vault', balanceUSD: 350000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '03:45:00 PM',
    dateIso: '2026-08-24T15:45:00.000Z',
    sector: 'Energy & Aerospace',
    tradeSlipId: 'SLIP-HYPR-FUT',
    isBusinessStock: true,
    issuerName: 'Hyperion Labs'
  },
  {
    id: 'ord-samp-sell-hypr-fut',
    ticker: 'HYPR',
    stockName: 'Hyperion Quantum Fusion Energy [Futures Long (10x Leverage)]',
    side: 'sell',
    orderType: 'market',
    derivativeType: 'futures_long',
    leverage: 10,
    expiryDate: '2026-10-15',
    shares: 250,
    price: 58.20,
    totalUSD: 14550.00,
    totalGainUSD: 1350.00,
    totalGainPercent: 10.23,
    paymentSource: { id: 'final-hypr', type: 'wallet_final', label: '$HYPR', subtitle: 'Hyperion Energy Vault', balanceUSD: 350000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '11:18:42 AM',
    dateIso: '2026-08-28T11:18:42.000Z',
    sector: 'Energy & Aerospace',
    tradeSlipId: 'SLIP-HYPR-CLOSE',
    isBusinessStock: true,
    issuerName: 'Hyperion Labs'
  },
  {
    id: 'ord-samp-call-bsyn',
    ticker: 'BSYN',
    stockName: 'BioSynthetica Sovereign Therapeutics [Call Option (35.00 Strike)]',
    side: 'buy',
    orderType: 'limit',
    derivativeType: 'call_option',
    strikePrice: 35.00,
    expiryDate: '2026-12-20',
    premiumUSD: 420.00,
    shares: 450,
    price: 34.50,
    totalUSD: 15525.00,
    totalGainUSD: 1150.00,
    totalGainPercent: 7.99,
    paymentSource: { id: 'final-bsyn', type: 'wallet_final', label: '$BSYN', subtitle: 'BioSynthetica Sovereign Vault', balanceUSD: 100000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '10:15:00 AM',
    dateIso: '2026-08-25T10:15:00.000Z',
    sector: 'BioTech & Health',
    tradeSlipId: 'SLIP-BSYN-CALL',
    isBusinessStock: true,
    issuerName: 'BioSynthetica Corp'
  },
  {
    id: 'ord-samp-futs-soln',
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Constellation [Futures Short (5x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_short',
    leverage: 5,
    expiryDate: '2026-11-20',
    shares: 800,
    price: 16.68,
    totalUSD: 13344.00,
    totalGainUSD: -380.00,
    totalGainPercent: -2.77,
    paymentSource: { id: 'final-soln', type: 'wallet_final', label: '$SOLN', subtitle: 'Solar Sovereign Vault', balanceUSD: 50000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '01:10:00 PM',
    dateIso: '2026-08-26T13:10:00.000Z',
    sector: 'Energy & Aerospace',
    tradeSlipId: 'SLIP-SOLN-SHORT',
    isBusinessStock: true,
    issuerName: 'SolarNode Labs'
  },
  {
    id: 'ord-samp-sell-soln-short',
    ticker: 'SOLN',
    stockName: 'SolarNode MicroGrid Constellation [Futures Short (5x Leverage)]',
    side: 'sell',
    orderType: 'market',
    derivativeType: 'futures_short',
    leverage: 5,
    expiryDate: '2026-10-10',
    shares: 350,
    price: 16.20,
    totalUSD: 5670.00,
    totalGainUSD: 410.00,
    totalGainPercent: 7.79,
    paymentSource: { id: 'final-soln', type: 'wallet_final', label: '$SOLN', subtitle: 'Solar Sovereign Vault', balanceUSD: 50000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '04:12:08 PM',
    dateIso: '2026-08-28T16:12:08.000Z',
    sector: 'Energy & Aerospace',
    tradeSlipId: 'SLIP-SOLN-CLOSE',
    isBusinessStock: true,
    issuerName: 'SolarNode Labs'
  },
  {
    id: 'ord-samp-call-aur',
    ticker: 'AUR',
    stockName: 'Aura Sovereign Gold Treasury [Call Option (190.00 Strike)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'call_option',
    strikePrice: 190.00,
    expiryDate: '2027-01-15',
    premiumUSD: 320.00,
    shares: 120,
    price: 185.30,
    totalUSD: 22236.00,
    totalGainUSD: 1840.00,
    totalGainPercent: 9.02,
    paymentSource: { id: 'final-aur', type: 'wallet_final', label: '$AUR', subtitle: 'Aura Sovereign Vault', balanceUSD: 500000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '11:45:00 AM',
    dateIso: '2026-08-26T11:45:00.000Z',
    sector: 'Sovereign Reserves',
    tradeSlipId: 'SLIP-AUR-CALL',
    isBusinessStock: true,
    issuerName: 'Sovereign Treasury'
  },
  {
    id: 'ord-samp-futl-vex',
    ticker: 'VEX',
    stockName: 'Vortex Spatial Propulsion Systems [Futures Long (5x Leverage)]',
    side: 'buy',
    orderType: 'market',
    derivativeType: 'futures_long',
    leverage: 5,
    expiryDate: '2026-12-31',
    shares: 70,
    price: 415.50,
    totalUSD: 29085.00,
    totalGainUSD: 2100.00,
    totalGainPercent: 7.78,
    paymentSource: { id: 'final-vex', type: 'wallet_final', label: '$VEX', subtitle: 'Vortex Sovereign Vault', balanceUSD: 300000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '01:40:12 PM',
    dateIso: '2026-08-23T13:40:12.000Z',
    sector: 'Technology & AI',
    tradeSlipId: 'SLIP-VEX-FUT',
    isBusinessStock: true,
    issuerName: 'Vortex Labs'
  },
  {
    id: 'ord-samp-put-qbit',
    ticker: 'QBIT',
    stockName: 'Quantum Bit Compute Architecture [Put Option (90.00 Strike)]',
    side: 'buy',
    orderType: 'limit',
    derivativeType: 'put_option',
    strikePrice: 90.00,
    expiryDate: '2026-11-30',
    premiumUSD: 180.00,
    shares: 210,
    price: 92.00,
    totalUSD: 19320.00,
    totalGainUSD: -420.00,
    totalGainPercent: -2.13,
    paymentSource: { id: 'final-qbit', type: 'wallet_final', label: '$QBIT', subtitle: 'Quantum Compute Vault', balanceUSD: 85000, iconType: 'wallet' },
    status: 'filled',
    timestamp: '09:45:00 AM',
    dateIso: '2026-08-26T09:45:00.000Z',
    sector: 'Technology & AI',
    tradeSlipId: 'SLIP-QBIT-PUT',
    isBusinessStock: true,
    issuerName: 'Quantum Trust'
  }
];

// ============================================================================
// BREAKING NEWS ON PLATFORM-ISSUED PERSONAL & BUSINESS EQUITIES
// ============================================================================

export const BREAKING_STOCK_NEWS: StockNewsItem[] = [
  {
    id: 'news-1',
    title: 'Hyperion Quantum Fusion Surpasses Q-Factor 2.4 in Live Municipal Substation Power Run',
    source: 'Clean Energy Telegraph',
    time: '12m ago',
    sentiment: 'bullish',
    tickers: ['HYPR'],
    category: 'Energy & Aerospace',
    impact: 'High Impact',
    keyTakeaway: 'Generation-3 modular tokamak sustained 24-hour continuous baseline power delivery with net positive thermal output.',
    summary: 'Hyperion Quantum Fusion Dynamics reported a technical milestone during grid interconnect trials in Austin, confirming commercial scalability of its platform-issued business stock shares.',
    readTime: '3 min read'
  },
  {
    id: 'news-2',
    title: 'Alex Chen Personal Sovereign Equity Achieves 89% AI Algorithm Licensing Royalty Growth',
    source: 'Sovereign Journal',
    time: '35m ago',
    sentiment: 'bullish',
    tickers: ['ALEX'],
    category: 'Sovereign Reserves',
    impact: 'High Impact',
    keyTakeaway: 'Zero-knowledge algorithmic liquidity proofs licensed by 4 tier-1 decentralized clearing vaults.',
    summary: 'Quarterly audited earnings for Alex Chen personal human equity IPO confirmed record royalty revenue distribution into the AFNL backing reserve vault.',
    readTime: '4 min read'
  },
  {
    id: 'news-3',
    title: 'BioSynthetica Secures Swiss Regulatory Clearance for Phase-II Longevity Enzyme Protocol',
    source: 'Swiss BioTech Review',
    time: '52m ago',
    sentiment: 'bullish',
    tickers: ['BSYN'],
    category: 'Technology & AI',
    impact: 'High Impact',
    keyTakeaway: 'Epigenetic de-risking timeline compressed to 45 days using tensor-accelerated molecular dynamics.',
    summary: 'BioSynthetica Genomics International AG announced milestone clearance from Swiss authorities, advancing candidate licensing discussions with European pharmaceutical syndicates.',
    readTime: '2 min read'
  },
  {
    id: 'news-4',
    title: 'Global Vault Yield & Treasury Corp Reports $41.6M Cashflow Backing USDC Dividend Pool',
    source: 'Treasury & Reserves Digest',
    time: '1h ago',
    sentiment: 'bullish',
    tickers: ['VLT-YLD'],
    category: 'Treasuries & Yield',
    impact: 'High Impact',
    keyTakeaway: '100% full-reserve short-duration treasury backing generates 5.20% annualized yield with zero credit risk.',
    summary: 'Global Vault Yield confirmed pristine full reserve verification across Zurich and George Town custodial trusts, distributing monthly dividends to USDC stock holders.',
    readTime: '3 min read'
  },
  {
    id: 'news-5',
    title: 'Nexa Sovereign Robotics Delivers First 100 Autonomous Humanoid Spatial Perception Units',
    source: 'Robotics Insider',
    time: '2h ago',
    sentiment: 'bullish',
    tickers: ['NEXA'],
    category: 'Technology & AI',
    impact: 'High Impact',
    keyTakeaway: 'Factory automation efficiency improved by 34% with sub-millimeter dexterity magnetic actuators.',
    summary: 'Nexa Robotics confirmed initial enterprise deliveries to automated automotive and electronics fabrication cleanrooms in North America.',
    readTime: '3 min read'
  },
  {
    id: 'news-6',
    title: 'SolarNode MicroGrid Protocol Deploys 2.4MW Peer-to-Peer Neighborhood Energy Mesh',
    source: 'Decentralized Grid Daily',
    time: '3h ago',
    sentiment: 'bullish',
    tickers: ['SOLN'],
    category: 'Energy & Aerospace',
    impact: 'Medium Impact',
    keyTakeaway: 'Microgrid dispatch algorithms reduce commercial rooftop solar energy curtailment by 22%.',
    summary: 'SolarNode confirmed rapid expansion of its decentralized rooftop solar IoT telemetry network in Singapore and Southeast Asia.',
    readTime: '2 min read'
  }
];

export const INITIAL_STOCK_NEWS = BREAKING_STOCK_NEWS;

// ============================================================================
// STORAGE & IPO MANAGEMENT HELPERS
// ============================================================================

const IPO_STORAGE_KEY = 'final_finance_ipos_v1';
export const IPO_UPDATED_EVENT = 'final_finance_ipos_updated';

export const MOCK_OPTIONS: OptionItem[] = [
  // Final Stocks
  { id: 'opt-hypr-call-55', ticker: 'HYPR', underlyingName: 'Hyperion Quantum Fusion', type: 'call', strike: 55, expiry: 'DEC 18, 2026', price: 5.25, changeUSD: 0.15, changePercent: 2.9, volume: '5K', openInterest: '10K', category: 'final' },
  { id: 'opt-soln-put-18', ticker: 'SOLN', underlyingName: 'SolarNode MicroGrid Protocol', type: 'put', strike: 18, expiry: 'DEC 18, 2026', price: 3.10, changeUSD: -0.05, changePercent: -1.5, volume: '8K', openInterest: '12K', category: 'final' },
  // Stable
  { id: 'opt-bsyn-call-100', ticker: 'BSYN', underlyingName: 'BioSynthetica', type: 'call', strike: 100, expiry: 'DEC 18, 2026', price: 2.50, changeUSD: 0.02, changePercent: 0.8, volume: '1K', openInterest: '2K', category: 'stable' },
  { id: 'opt-usdc-call-1', ticker: 'USDC', underlyingName: 'USD Stablecoin', type: 'call', strike: 1, expiry: 'DEC 18, 2026', price: 0.01, changeUSD: 0.001, changePercent: 10, volume: '50K', openInterest: '100K', category: 'stable' },
  { id: 'opt-usdc-put-1', ticker: 'USDC', underlyingName: 'USD Stablecoin', type: 'put', strike: 1, expiry: 'DEC 18, 2026', price: 0.01, changeUSD: 0.001, changePercent: 10, volume: '40K', openInterest: '90K', category: 'stable' },
  // Crypto
  { id: 'opt-btc-call-70k', ticker: 'BTC', underlyingName: 'Bitcoin', type: 'call', strike: 70000, expiry: 'DEC 18, 2026', price: 2500, changeUSD: 100, changePercent: 4.2, volume: '2K', openInterest: '5K', category: 'crypto' },
  { id: 'opt-eth-put-3500', ticker: 'ETH', underlyingName: 'Ethereum', type: 'put', strike: 3500, expiry: 'DEC 18, 2026', price: 150, changeUSD: -5, changePercent: -3.2, volume: '3K', openInterest: '4K', category: 'crypto' },
  {
    id: 'opt_nexa_call_75',
    ticker: 'NEXA',
    underlyingName: 'Nexa Sovereign Robotics',
    type: 'call',
    strike: 75.00,
    expiry: 'NOV 20, 2026',
    price: 4.80,
    changeUSD: 0.65,
    changePercent: 15.66,
    volume: '2.1K',
    openInterest: '4.5K',
    category: 'fiat'
  }
];

export function getStoredIPORequests(): IPORequest[] {
  try {
    const raw = localStorage.getItem(IPO_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(INITIAL_IPO_REQUESTS));
      return INITIAL_IPO_REQUESTS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(INITIAL_IPO_REQUESTS));
      return INITIAL_IPO_REQUESTS;
    }
    // Ensure all base system IPOs (including new stable/crypto stocks) are present
    const existingIds = new Set(parsed.map((p: any) => p.id));
    let hasNew = false;
    for (const baseIpo of INITIAL_IPO_REQUESTS) {
      if (!existingIds.has(baseIpo.id)) {
        parsed.push(baseIpo);
        hasNew = true;
      }
    }
    if (hasNew) {
      localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(parsed));
    }
    return parsed;
  } catch (err) {
    console.error('Failed reading IPO requests from storage:', err);
    return INITIAL_IPO_REQUESTS;
  }
}

export function saveIPORequests(ipos: IPORequest[]): void {
  try {
    localStorage.setItem(IPO_STORAGE_KEY, JSON.stringify(ipos));
    window.dispatchEvent(new CustomEvent(IPO_UPDATED_EVENT, { detail: ipos }));
  } catch (err) {
    console.error('Failed saving IPO requests to storage:', err);
  }
}

// Check if user can create a Personal IPO (Limit 1 Personal IPO at a time)
export function canCreatePersonalIPO(userId = 'you'): { 
  allowed: boolean; 
  activeIPO?: IPORequest; 
  existingTicker?: string; 
  message?: string; 
  reason?: string; 
} {
  const ipos = getStoredIPORequests();
  const existingPersonal = ipos.find(
    (i) => (i.issuerId === userId || (userId === 'you' && (i.issuerId === 'you' || i.issuerId === 'user_main' || i.issuerId === 'current_user'))) && 
           i.id !== 'ipo_personal_alex_chen' &&
           i.ipoType === 'personal' && 
           (i.status === 'active' || i.status === 'pending_admin_approval' || i.status === 'delist_pending_admin_approval')
  );

  if (existingPersonal) {
    const msg = `Protocol Limit: You already have an active or pending Personal IPO ($${existingPersonal.ticker} - ${existingPersonal.equityName}). Sovereign individuals are restricted to 1 active Personal IPO at a time. You may launch multiple Business IPOs without restriction.`;
    return {
      allowed: false,
      activeIPO: existingPersonal,
      existingTicker: existingPersonal.ticker,
      message: msg,
      reason: msg
    };
  }

  return { allowed: true };
}

// Calculate real-time live valuation for an active IPO
export function getLiveIPOValuation(ipo: IPORequest) {
  const basePrice = ipo.offeringPriceUSD;
  const isLive = ipo.status === 'active';
  
  let livePrice = ipo.currentLivePriceUSD || basePrice;
  let changePercent = ipo.priceChangePercent24h ?? 3.42;

  if (isLive && !ipo.currentLivePriceUSD) {
    const tickerSum = ipo.ticker.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
    const mod = (tickerSum % 15) - 3;
    const gainPct = +(3.2 + mod * 0.45).toFixed(2);
    changePercent = gainPct;
    livePrice = Number((basePrice * (1 + changePercent / 100)).toFixed(2));
  }

  const currentMarketCap = livePrice * ipo.sharesOffered;
  const circulatingValuation = livePrice * ipo.circulatingFloat;
  const founderRetainedShares = ipo.sharesOffered - ipo.circulatingFloat;
  const founderRetainedValuation = livePrice * founderRetainedShares;
  const totalGainLossUSD = (livePrice - basePrice) * ipo.sharesOffered;
  const changeUSD = +(livePrice - basePrice).toFixed(2);

  return {
    isLive,
    basePrice,
    livePrice,
    currentMarketCap,
    targetValuation: ipo.targetValuationUSD,
    circulatingValuation,
    founderRetainedShares,
    founderRetainedValuation,
    changeUSD,
    changePercent,
    totalGainLossUSD
  };
}

export function submitIPORequest(ipoData: Partial<IPORequest>): IPORequest {
  const current = getStoredIPORequests();
  const cleanTicker = (ipoData.ticker || 'IPO').replace(/^\$/, '').toUpperCase();
  const offeringPrice = ipoData.offeringPriceUSD || 10.0;
  const shares = ipoData.sharesOffered || 1000000;
  const targetValuation = ipoData.targetValuationUSD || (shares * offeringPrice);

  const media = ipoData.mediaGallery || 
    (ipoData.ipoType === 'personal' ? ipoData.personalDetails?.mediaGallery : ipoData.businessDetails?.mediaGallery) || 
    [];
  
  const newIPO: IPORequest = {
    id: `ipo_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    ipoType: ipoData.ipoType || 'personal',
    ticker: cleanTicker,
    equityName: ipoData.equityName || `${cleanTicker} Sovereign Equity`,
    issuerId: ipoData.issuerId || 'you',
    issuerName: ipoData.issuerName || 'You (Current User)',
    issuerHandle: ipoData.issuerHandle || 'you',
    issuerAvatar: ipoData.issuerAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
    marketWay: ipoData.marketWay || (ipoData.ipoType === 'personal' ? 'final' : 'stable'),
    status: 'pending_admin_approval',
    sharesOffered: shares,
    offeringPriceUSD: offeringPrice,
    targetValuationUSD: targetValuation,
    circulatingFloat: Math.round(shares * 0.4),
    currentLivePriceUSD: offeringPrice,
    currentLiveValuationUSD: targetValuation,
    priceChangePercent24h: 0,
    submittedAt: new Date().toISOString(),
    businessDetails: ipoData.businessDetails ? { ...ipoData.businessDetails, mediaGallery: media } : undefined,
    personalDetails: ipoData.personalDetails ? { ...ipoData.personalDetails, mediaGallery: media } : undefined,
    mediaGallery: media
  };

  const updated = [newIPO, ...current];
  saveIPORequests(updated);
  return newIPO;
}

export function updateIPOMedia(ipoId: string, media: import('../types/stocks').IPOMediaItem[]): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      const updatedItem = {
        ...item,
        mediaGallery: media,
        businessDetails: item.businessDetails ? { ...item.businessDetails, mediaGallery: media } : undefined,
        personalDetails: item.personalDetails ? { ...item.personalDetails, mediaGallery: media } : undefined
      };
      return updatedItem;
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function requestDelistIPO(ipoId: string, reason: string): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'delist_pending_admin_approval' as IPOStatus,
        delistReason: reason.trim(),
        delistRequestedAt: new Date().toISOString()
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminApproveIPO(ipoId: string, adminName = 'System Protocol Admin', notes = 'Approved after institutional review.'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'active' as IPOStatus,
        reviewedAt: new Date().toISOString(),
        reviewedBy: adminName,
        adminNotes: notes
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminRejectIPO(ipoId: string, notes?: string, adminName = 'System Protocol Admin'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'rejected' as IPOStatus,
        reviewedAt: new Date().toISOString(),
        reviewedBy: adminName,
        adminNotes: notes || 'Prospectus requirements not satisfied.'
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminApproveDelist(ipoId: string, adminName = 'System Protocol Admin'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'delisted' as IPOStatus,
        delistReviewedAt: new Date().toISOString(),
        delistReviewedBy: adminName
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function adminRejectDelist(ipoId: string, notes?: string, adminName = 'System Protocol Admin'): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.map((item) => {
    if (item.id === ipoId) {
      found = true;
      return {
        ...item,
        status: 'active' as IPOStatus,
        delistReviewedAt: new Date().toISOString(),
        delistReviewedBy: adminName,
        adminNotes: notes || 'Delist request rejected. Trading remains active.'
      };
    }
    return item;
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

export function cancelIPORequest(ipoId: string): boolean {
  const current = getStoredIPORequests();
  let found = false;
  const updated = current.filter((item) => {
    if (item.id === ipoId) {
      if (item.status === 'pending_admin_approval') {
        found = true;
        return false; // Remove the item
      }
    }
    return true; // Keep the item
  });

  if (found) {
    saveIPORequests(updated);
  }
  return found;
}

// Convert an approved active IPO into a tradeable StockItem
export function convertIPOToStockItem(ipo: IPORequest): StockItem {
  const liveVal = getLiveIPOValuation(ipo);
  const livePrice = liveVal.livePrice;
  const isPersonal = ipo.ipoType === 'personal';
  const sector = isPersonal 
    ? 'Sovereign Reserves' 
    : (ipo.businessDetails?.sector || 'Technology & AI');
  
  const description = isPersonal
    ? (ipo.personalDetails?.personaProfile || `${ipo.equityName} - Personal Sovereign Equity released via platform IPO.`)
    : (ipo.businessDetails?.valueProposition || ipo.businessDetails?.businessModel || `${ipo.equityName} - Corporate Enterprise Equity.`);

  return {
    ticker: ipo.ticker,
    name: ipo.equityName,
    price: livePrice,
    changeUSD: liveVal.changeUSD,
    changePercent: liveVal.changePercent,
    marketType: ipo.marketWay,
    settlementMethod: isPersonal 
      ? `Final Coin (${ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL'})`
      : `${ipo.businessDetails?.backingCoinType === 'stable_coin' ? 'USD Stablecoin' : ipo.businessDetails?.backingCoinType === 'crypto' ? 'Cryptocurrency' : ipo.businessDetails?.backingCoinType === 'fiat' ? 'USD Fiat Clearing' : 'Final Coin'} (${ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')})`,
    high24h: +(livePrice * 1.05).toFixed(2),
    low24h: +(livePrice * 0.98).toFixed(2),
    openPrice: +(livePrice * 0.99).toFixed(2),
    prevClose: ipo.offeringPriceUSD,
    volume: `$${(liveVal.currentMarketCap * 0.04 / 1e6).toFixed(1)}M`,
    avgVolume: `$${(liveVal.currentMarketCap * 0.035 / 1e6).toFixed(1)}M`,
    marketCap: `$${(liveVal.currentMarketCap / 1e6).toFixed(1)}M`,
    peRatio: isPersonal ? 14.2 : 28.5,
    eps: isPersonal ? 1.75 : 2.45,
    dividendYield: isPersonal ? '3.80%' : '1.90%',
    beta: 1.05,
    fiftyTwoWeekHigh: +(livePrice * 1.15).toFixed(2),
    fiftyTwoWeekLow: +(livePrice * 0.85).toFixed(2),
    sector: sector as any,
    subSector: isPersonal ? 'Personal Sovereign Equity' : ipo.businessDetails?.industry,
    description,
    exchange: 'SOVEREIGN_NODE',
    analystRating: 'Strong Buy',
    analystTargetUSD: +(livePrice * 1.28).toFixed(2),
    analystCount: 18,
    sparkline: [
      livePrice * 0.96,
      livePrice * 0.97,
      livePrice * 0.965,
      livePrice * 0.98,
      livePrice * 0.975,
      livePrice * 0.99,
      livePrice * 1.01,
      livePrice * 1.005,
      livePrice * 1.025,
      livePrice * 1.032
    ],
    history: generateHistory(livePrice, 0.02),
    ceo: isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.executives?.ceo,
    headquarters: isPersonal ? 'Global Sovereign Node' : ipo.businessDetails?.headquarters,
    foundedYear: isPersonal ? 2026 : ipo.businessDetails?.foundedYear,
    employeesCount: isPersonal ? '1 Principal' : ipo.businessDetails?.employeeCount,
    revenueTTM: isPersonal 
      ? `$${((ipo.personalDetails?.fiveModeNetWorth?.totalNetWorthUSD || 10e6) * 0.2 / 1e6).toFixed(1)}M` 
      : `$${((ipo.businessDetails?.annualRevenueUSD || 10e6) / 1e6).toFixed(1)}M`,
    profitMargin: isPersonal ? '85.0%' : `${ipo.businessDetails?.netProfitMarginPercent || 25}%`,
    issuanceType: isPersonal ? 'personal' : 'business',
    assetCategory: isPersonal ? 'personal' : 'business',
    issuanceCoinSymbol: isPersonal 
      ? (ipo.personalDetails?.backingFinalCoinSymbol || 'AFNL')
      : (ipo.businessDetails?.backingCoinSymbol || (ipo.marketWay === 'stable' ? 'USDC' : ipo.marketWay === 'crypto' ? 'BTC' : ipo.marketWay === 'fiat' ? 'USD' : 'AFNL')),
    issuanceCoinName: isPersonal
      ? (ipo.personalDetails?.backingFinalCoinName || 'Final Sovereign Coin')
      : (ipo.businessDetails?.backingCoinName || (ipo.marketWay === 'stable' ? 'USD Stablecoin' : ipo.marketWay === 'crypto' ? 'Bitcoin Crypto Asset' : 'Final Coin')),
    issuanceCoinType: isPersonal
      ? 'final_coin'
      : (ipo.businessDetails?.backingCoinType || (ipo.marketWay === 'stable' ? 'stable_coin' : ipo.marketWay === 'crypto' ? 'crypto' : 'final_coin')),
    issuerName: ipo.issuerName || (isPersonal ? ipo.personalDetails?.fullName : ipo.businessDetails?.companyName),
    issuerHandle: ipo.issuerHandle || ipo.personalDetails?.handle,
    issuerAvatar: ipo.issuerAvatar,
    ipoRefId: ipo.id
  };
}

// Get all active stocks combined with active approved IPO stocks
export function getAllActiveMarketStocks(): StockItem[] {
  const ipos = getStoredIPORequests();
  const activeIPOs = ipos.filter((ipo) => ipo.status === 'active');
  const ipoStockItems = activeIPOs.map(convertIPOToStockItem);
  
  // Combine initial benchmark stocks with all user-created and active IPO stocks (deduplicating by ticker)
  const tickerMap = new Map<string, StockItem>();
  
  // Add initial benchmark stocks first
  INITIAL_STOCKS.forEach((stock) => {
    tickerMap.set(stock.ticker.toUpperCase().trim(), stock);
  });
  
  // Override or add all active approved/launched IPO equities (e.g. personal sovereign equities, creator IPOs, business offerings)
  ipoStockItems.forEach((ipoStock) => {
    tickerMap.set(ipoStock.ticker.toUpperCase().trim(), ipoStock);
  });

  // Load dynamically searched Alpaca stocks so they are shared system-wide in real-time
  try {
    const savedAlpaca = localStorage.getItem('final_finance_alpaca_stocks');
    if (savedAlpaca) {
      const parsed = JSON.parse(savedAlpaca);
      if (Array.isArray(parsed)) {
        parsed.forEach((stock) => {
          tickerMap.set(stock.ticker.toUpperCase().trim(), stock);
        });
      }
    }
  } catch (err) {
    console.error('Error loading alpaca stocks from localStorage', err);
  }
  
  return Array.from(tickerMap.values());
}

// ============================================================================
// USER IPO NEWS, EARNINGS REPORTS & MULTIMEDIA UPDATES
// ============================================================================

const IPO_NEWS_STORAGE_KEY = 'final_finance_ipo_news_v1';
export const IPO_NEWS_UPDATED_EVENT = 'final_finance_ipo_news_updated';

export function formatRelativeNewsTime(isoString?: string): string {
  if (!isoString) return 'Just now';
  const ts = new Date(isoString).getTime();
  if (Number.isNaN(ts)) return 'Just now';
  const diffMs = Date.now() - ts;
  if (diffMs < 60_000) return 'Just now';
  const mins = Math.floor(diffMs / 60_000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(ts).toLocaleDateString();
}

export function isIPOInheritedByUser(
  ipo: IPORequest,
  user?: { id?: string; uid?: string; handle?: string; name?: string } | null
): boolean {
  if (!user) return false;
  const uidCandidates = new Set(
    [user.id, user.uid, 'you', 'user_main', 'current_user']
      .filter(Boolean)
      .map((s) => String(s).toLowerCase())
  );
  if (ipo.issuerId && uidCandidates.has(ipo.issuerId.toLowerCase())) {
    return true;
  }
  const userHandle = user.handle?.replace(/^@/, '').toLowerCase();
  const ipoHandle = ipo.issuerHandle?.replace(/^@/, '').toLowerCase();
  if (userHandle && ipoHandle && userHandle === ipoHandle) {
    return true;
  }
  return false;
}

export function getStoredIPONews(): StockNewsItem[] {
  try {
    const raw = localStorage.getItem(IPO_NEWS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((item: StockNewsItem) => ({
      ...item,
      time: item.publishedAt ? formatRelativeNewsTime(item.publishedAt) : (item.time || 'Just now'),
    }));
  } catch (err) {
    console.error('Failed reading IPO news from storage:', err);
    return [];
  }
}

export function saveIPONews(items: StockNewsItem[]): { success: boolean; error?: string } {
  try {
    localStorage.setItem(IPO_NEWS_STORAGE_KEY, JSON.stringify(items));
    window.dispatchEvent(new CustomEvent(IPO_NEWS_UPDATED_EVENT, { detail: items }));
    return { success: true };
  } catch (err: any) {
    console.error('Failed saving IPO news to storage:', err);
    const isQuota =
      err?.name === 'QuotaExceededError' ||
      String(err?.message || '').toLowerCase().includes('quota');
    return {
      success: false,
      error: isQuota
        ? 'Browser storage limit exceeded due to large media file size. Try removing large video uploads or using a video URL / smaller files.'
        : 'Could not save IPO news update. Please try again.'
    };
  }
}

export interface AddIPONewsPayload {
  title: string;
  bodyText: string;
  summary?: string;
  category?: string;
  sentiment?: 'bullish' | 'bearish' | 'neutral';
  impact?: 'High Impact' | 'Medium Impact' | 'Macro Trend';
  keyTakeaway?: string;
  documents?: StockNewsDocumentAttachment[];
  photos?: StockNewsMediaAttachment[];
  videos?: StockNewsMediaAttachment[];
  authorName?: string;
  authorHandle?: string;
  authorAvatar?: string;
  authorId?: string;
}

export function addIPONewsItem(
  ipo: IPORequest,
  payload: AddIPONewsPayload
): { success: boolean; item?: StockNewsItem; error?: string } {
  const existing = getStoredIPONews();
  const cleanTitle = payload.title.trim();
  const cleanBody = payload.bodyText.trim();
  const summary =
    payload.summary?.trim() ||
    (cleanBody.length > 210 ? `${cleanBody.slice(0, 207).trim()}...` : cleanBody);

  const wordCount = cleanBody ? cleanBody.split(/\s+/).filter(Boolean).length : 0;
  const mins = Math.max(1, Math.ceil(wordCount / 180));
  const nowIso = new Date().toISOString();
  const cleanTicker = (ipo.ticker || 'IPO').replace(/^\$/, '').toUpperCase();

  const newItem: StockNewsItem = {
    id: `ipo_news_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    title: cleanTitle,
    source: `${ipo.equityName} ($${cleanTicker}) Official IR`,
    time: 'Just now',
    publishedAt: nowIso,
    sentiment: payload.sentiment || 'bullish',
    tickers: [cleanTicker],
    summary: summary || `${cleanTitle} — Official issuer update for $${cleanTicker}.`,
    bodyText: cleanBody,
    readTime: `${mins} min read`,
    category: payload.category || 'Earnings',
    impact: payload.impact || 'High Impact',
    keyTakeaway: payload.keyTakeaway?.trim() || undefined,
    ipoId: ipo.id,
    ipoTicker: cleanTicker,
    ipoName: ipo.equityName,
    issuerId: payload.authorId || ipo.issuerId,
    issuerName: payload.authorName || ipo.issuerName,
    issuerHandle: payload.authorHandle || ipo.issuerHandle,
    issuerAvatar: payload.authorAvatar || ipo.issuerAvatar,
    isUserIpoNews: true,
    documents: payload.documents || [],
    photos: payload.photos || [],
    videos: payload.videos || [],
  };

  const next = [newItem, ...existing];
  const res = saveIPONews(next);
  if (!res.success) {
    return { success: false, error: res.error };
  }
  return { success: true, item: newItem };
}

export function deleteIPONewsItem(newsId: string): boolean {
  const existing = getStoredIPONews();
  const next = existing.filter((item) => item.id !== newsId);
  if (next.length === existing.length) return false;
  const res = saveIPONews(next);
  return res.success;
}

export function getAllCombinedStockNews(): StockNewsItem[] {
  const userIpoNews = getStoredIPONews();
  return [...userIpoNews, ...BREAKING_STOCK_NEWS];
}
