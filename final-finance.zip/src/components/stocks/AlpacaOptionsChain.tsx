import React, { useState, useEffect } from 'react';
import { Loader2, TrendingUp, TrendingDown, Clock, Shield, Search, AlertCircle, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OptionContract {
  id: string;
  symbol: string;
  name: string;
  type: 'call' | 'put';
  expiration_date: string;
  strike_price: number;
  underlying_symbol: string;
}

interface AlpacaOptionsChainProps {
  symbol: string;
  onSelectContract?: (contract: OptionContract, settlementTime: string) => void;
}

export const AlpacaOptionsChain: React.FC<AlpacaOptionsChainProps> = ({ symbol, onSelectContract }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [contracts, setContracts] = useState<OptionContract[]>([]);
  const [filterType, setFilterType] = useState<'all' | 'call' | 'put'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedExpiration, setSelectedExpiration] = useState<string | 'all'>('all');
  const [selectedTime, setSelectedTime] = useState('16:00'); // Default to Market Close
  const [dateRange, setDateRange] = useState<{ gte: string; lte: string }>({
    gte: new Date().toISOString().split('T')[0],
    lte: new Date(new Date().setFullYear(new Date().getFullYear() + 2)).toISOString().split('T')[0], // 2 years out
  });

  const fetchOptions = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/alpaca/options/${symbol}?expiration_gte=${dateRange.gte}&expiration_lte=${dateRange.lte}`);
      const data = await res.json();
      if (data.success) {
        setContracts(data.data);
      } else {
        setError(data.error || 'Failed to load options chain');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (symbol) {
      fetchOptions();
    }
  }, [symbol, dateRange]);

  const filteredContracts = contracts.filter((c) => {
    const matchesType = filterType === 'all' || c.type === filterType;
    const matchesExpiration = selectedExpiration === 'all' || c.expiration_date === selectedExpiration;
    const matchesSearch = c.symbol.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          c.strike_price.toString().includes(searchQuery);
    return matchesType && matchesExpiration && matchesSearch;
  });

  // Group by expiration date
  const allExpirationDates = [...new Set(contracts.map(c => c.expiration_date))].sort();

  const groupedByExpiration = filteredContracts.reduce((acc, c) => {
    const date = c.expiration_date;
    if (!acc[date]) acc[date] = [];
    acc[date].push(c);
    return acc;
  }, {} as Record<string, OptionContract[]>);

  const expirationDatesToShow = Object.keys(groupedByExpiration).sort();

  const calculateDTE = (dateStr: string) => {
    const expDate = new Date(dateStr);
    const now = new Date();
    const diffTime = expDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        {/* Calendar Selection / Range Controls */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
              <Calendar className="w-3 h-3" />
              Custom Time Horizon (Calendar)
            </label>
            <button 
              onClick={() => fetchOptions()}
              className="text-[10px] font-bold text-sky-600 hover:text-sky-700 flex items-center gap-1 uppercase tracking-tight"
            >
              Refresh Chain
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <span className="text-[9px] text-slate-400 font-bold uppercase">From Date</span>
              <input 
                type="date" 
                value={dateRange.gte}
                onChange={(e) => setDateRange(prev => ({ ...prev, gte: e.target.value }))}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-sky-500/10 transition-all"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[9px] text-slate-400 font-bold uppercase">To Date (Up to 2+ Years)</span>
              <input 
                type="date" 
                value={dateRange.lte}
                onChange={(e) => setDateRange(prev => ({ ...prev, lte: e.target.value }))}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-sky-500/10 transition-all"
              />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <span className="text-[9px] text-slate-400 font-bold uppercase">Target Settlement Time (ET)</span>
              <div className="flex items-center gap-3">
                <input 
                  type="time" 
                  value={selectedTime}
                  onChange={(e) => setSelectedTime(e.target.value)}
                  className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-sky-500/10 transition-all"
                />
                <div className="text-[10px] text-slate-400 font-bold bg-slate-100 px-2 py-1 rounded-lg">EASTERN TIME (ET)</div>
              </div>
            </div>
          </div>
          <p className="text-[10px] text-slate-400 leading-relaxed italic">
            Select a custom date range to discover LEAPS or far-dated contracts. Standard options expire on Fridays at 4:00 PM ET.
          </p>
        </div>

        {/* Date Selector Carousel */}
        {!loading && allExpirationDates.length > 0 && (
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Choose Expiration Date</label>
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-1 px-1">
              <button
                onClick={() => setSelectedExpiration('all')}
                className={`flex-none px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                  selectedExpiration === 'all'
                    ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-sky-200'
                }`}
              >
                All Dates
              </button>
              {allExpirationDates.map((date) => {
                const dte = calculateDTE(date);
                const d = new Date(date);
                return (
                  <button
                    key={date}
                    onClick={() => setSelectedExpiration(date)}
                    className={`flex-none px-4 py-2 rounded-xl text-left transition-all border group ${
                      selectedExpiration === date
                        ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                        : 'bg-white text-slate-600 border-slate-200 hover:border-sky-200'
                    }`}
                  >
                    <div className="text-[10px] font-bold uppercase tracking-tight opacity-80">
                      {d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </div>
                    <div className="text-[10px] font-mono mt-0.5">
                      {dte}d {dte === 0 ? 'Exp Today' : 'to Exp'}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="flex p-1 bg-slate-100 rounded-xl border border-slate-200">
              {(['all', 'call', 'put'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setFilterType(t)}
                  className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    filterType === t 
                      ? 'bg-white text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {t}s
                </button>
              ))}
            </div>
          </div>

          <div className="relative flex-1 max-w-xs">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search strike or symbol..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-sky-500/10 focus:border-sky-500 transition-all"
            />
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {loading ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="py-12 flex flex-col items-center justify-center space-y-3"
          >
            <Loader2 className="w-8 h-8 text-sky-500 animate-spin" />
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Fetching Options Chain...</p>
          </motion.div>
        ) : error ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-8 text-center bg-rose-50 border border-rose-100 rounded-2xl space-y-3"
          >
            <AlertCircle className="w-8 h-8 text-rose-500 mx-auto" />
            <div className="space-y-1">
              <p className="text-sm font-bold text-rose-900">Options Chain Unavailable</p>
              <p className="text-xs text-rose-700">{error}</p>
            </div>
          </motion.div>
        ) : contracts.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="py-12 text-center bg-slate-50 border border-slate-100 rounded-2xl"
          >
            <Clock className="w-8 h-8 text-slate-300 mx-auto mb-3" />
            <p className="text-sm font-bold text-slate-500">No Options Found</p>
            <p className="text-xs text-slate-400 mt-1">This asset may not support options trading on Alpaca.</p>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {expirationDatesToShow.map((date) => {
              const dte = calculateDTE(date);
              return (
                <div key={date} className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-widest">
                      Expiring: {new Date(date).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}
                    </h4>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      dte <= 7 ? 'bg-rose-100 text-rose-700' : 'bg-sky-100 text-sky-700'
                    }`}>
                      {dte} Days Left
                    </span>
                    <div className="flex-1 h-px bg-slate-100" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                    {groupedByExpiration[date].map((c) => (
                      <div
                        key={c.id}
                        onClick={() => onSelectContract?.(c, selectedTime)}
                        className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-sky-300 transition-all shadow-2xs group cursor-pointer relative overflow-hidden active:scale-[0.98]"
                      >
                      <div className={`absolute top-0 right-0 w-16 h-16 -mr-8 -mt-8 opacity-5 transition-opacity group-hover:opacity-10 ${c.type === 'call' ? 'text-emerald-500' : 'text-rose-500'}`}>
                        {c.type === 'call' ? <TrendingUp className="w-full h-full" /> : <TrendingDown className="w-full h-full" />}
                      </div>

                      <div className="flex items-start justify-between relative z-10">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase tracking-tighter ${
                              c.type === 'call' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {c.type}
                            </span>
                            <span className="font-mono font-bold text-slate-900 text-sm">
                              Strike ${c.strike_price.toFixed(2)}
                            </span>
                          </div>
                          <div className="text-[10px] font-mono text-slate-500 font-bold">
                            {c.symbol}
                          </div>
                          <div className="text-[10px] text-slate-600 font-medium mt-1 flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded border border-slate-100 w-fit">
                            <Clock className="w-3 h-3 text-sky-600" />
                            <span>Exp: {new Date(c.expiration_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' })} @ {selectedTime} ET</span>
                          </div>
                        </div>
                          <div className="text-right">
                            <div className="text-xs font-bold text-slate-700">Contract</div>
                            <div className="text-[10px] text-slate-400 mt-0.5 flex flex-col items-end gap-1">
                              <span className="flex items-center gap-1 text-sky-600 font-bold">
                                <Shield className="w-2.5 h-2.5" />
                                SEC Regulated
                              </span>
                            </div>
                          </div>
                        </div>

                      <div className="mt-4 flex items-center justify-between gap-3 relative z-10">
                        <div className="flex flex-col">
                          <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Premium Est.</span>
                          <span className="font-mono font-bold text-slate-900 text-xs">$0.00</span>
                        </div>
                        <button
                          type="button"
                          className={`px-3 py-1.5 rounded-xl text-[10px] font-bold text-white transition-all shadow-sm ${
                            c.type === 'call' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-rose-600 hover:bg-rose-500'
                          }`}
                        >
                          Trade Contract
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
