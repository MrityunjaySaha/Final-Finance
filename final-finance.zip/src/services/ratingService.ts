
export interface Review {
  id: string;
  targetUserId: string; // The user being rated (uid or handle)
  reviewerId: string;   // The user leaving the review (uid or handle)
  reviewerName: string;
  reviewerAvatar?: string;
  rating: number;       // 1-5
  comment: string;
  timestamp: number;
}

const STORAGE_KEY = 'ff_user_ratings';

export const getRatingsForUser = (userId: string): Review[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  try {
    const allRatings: Review[] = JSON.parse(stored);
    return allRatings.filter(r => r.targetUserId === userId).sort((a, b) => b.timestamp - a.timestamp);
  } catch (e) {
    console.error('Error parsing ratings', e);
    return [];
  }
};

export const addReview = (review: Omit<Review, 'id' | 'timestamp'>): Review => {
  const newReview: Review = {
    ...review,
    id: `rev-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now()
  };

  const stored = localStorage.getItem(STORAGE_KEY);
  let allRatings: Review[] = [];
  if (stored) {
    try {
      allRatings = JSON.parse(stored);
    } catch (e) {
      allRatings = [];
    }
  }

  // Check if reviewer already rated this user, maybe update or allow multiple?
  // Let's allow multiple for now as per "way to rate people" request.
  allRatings.push(newReview);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(allRatings));
  return newReview;
};

export const getAverageRating = (userId: string): { average: number; count: number } => {
  const ratings = getRatingsForUser(userId);
  if (ratings.length === 0) return { average: 0, count: 0 };
  const sum = ratings.reduce((acc, r) => acc + r.rating, 0);
  return {
    average: parseFloat((sum / ratings.length).toFixed(1)),
    count: ratings.length
  };
};
