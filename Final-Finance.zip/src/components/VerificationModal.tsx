import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  ShieldCheck,
  X,
  CreditCard,
  CheckCircle2,
  Lock,
  AlertCircle,
  FileCheck,
  RefreshCw,
  Upload,
  Award,
  Car,
  Store,
  Coins
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { verifyUserWithTier } from '../services/firebaseAuth';
import { dispatchGlobalNotification } from '../utils/notificationService';
import {
  getUserVerificationTier,
  VERIFICATION_TIERS,
  checkLegalIdsDuplicateAcrossPlatform
} from '../utils/verificationTiers';
import { calculateWalletPurchaseFee } from '../utils/transactionFees';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: AuthSession | null;
  initialTier?: 1 | 2 | 3;
  onVerificationSuccess: (updatedUser: AuthSession) => void;
}

export const VerificationModal: React.FC<VerificationModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  initialTier,
  onVerificationSuccess,
}) => {
  const currentTier = getUserVerificationTier(currentUser);
  const lockedTier = initialTier;
  const availableTiersForSelection = VERIFICATION_TIERS.filter((t) => t.tier > currentTier);
  const effectiveDefaultTier: 1 | 2 | 3 =
    lockedTier || (currentTier === 0 ? 1 : currentTier === 1 ? 2 : 3);

  const [selectedTier, setSelectedTier] = useState<1 | 2 | 3>(effectiveDefaultTier);
  const [step, setStep] = useState<'documents' | 'subscription' | 'processing' | 'success'>('documents');

  // Form 1: Primary Legal ID (Required for Tier 1, Tier 2, Tier 3)
  const [doc1Type, setDoc1Type] = useState<string>(
    currentUser?.verification?.idDocument1Type || "Driver's License"
  );
  const [doc1Name, setDoc1Name] = useState<string>(
    currentUser?.verification?.idDocument1Name || ''
  );
  const [doc1Number, setDoc1Number] = useState<string>(
    currentUser?.verification?.idDocument1Number || ''
  );
  const [doc1FileUploaded, setDoc1FileUploaded] = useState<boolean>(
    Boolean(currentUser?.verification?.idDocument1Name)
  );

  // Form 2: Secondary Legal ID (Required for Tier 2, Tier 3)
  const [doc2Type, setDoc2Type] = useState<string>(
    currentUser?.verification?.idDocument2Type || 'Passport'
  );
  const [doc2Name, setDoc2Name] = useState<string>(
    currentUser?.verification?.idDocument2Name || ''
  );
  const [doc2Number, setDoc2Number] = useState<string>(
    currentUser?.verification?.idDocument2Number || ''
  );
  const [doc2Issuer, setDoc2Issuer] = useState<string>(
    currentUser?.verification?.idDocument2Issuer || ''
  );
  const [doc2FileUploaded, setDoc2FileUploaded] = useState<boolean>(
    Boolean(currentUser?.verification?.idDocument2Name)
  );

  // Payment Form ($2/mo - Tier 3 only)
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'gpay' | 'apple' | 'crypto'>('card');
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardHolder, setCardHolder] = useState(currentUser?.name || 'Verified Cardholder');

  // Error & Progress
  const [errorMessage, setErrorMessage] = useState('');
  const [processStep, setProcessStep] = useState(1);

  useEffect(() => {
    if (!isOpen) return;
    const tier = getUserVerificationTier(currentUser);
    const nextDefault: 1 | 2 | 3 =
      initialTier || (tier === 0 ? 1 : tier === 1 ? 2 : 3);
    setSelectedTier(nextDefault);
    setStep('documents');
    setErrorMessage('');
    setDoc1Type(currentUser?.verification?.idDocument1Type || "Driver's License");
    setDoc1Name(currentUser?.verification?.idDocument1Name || '');
    setDoc1Number(currentUser?.verification?.idDocument1Number || '');
    setDoc1FileUploaded(Boolean(currentUser?.verification?.idDocument1Name));
    setDoc2Type(currentUser?.verification?.idDocument2Type || 'Passport');
    setDoc2Name(currentUser?.verification?.idDocument2Name || '');
    setDoc2Number(currentUser?.verification?.idDocument2Number || '');
    setDoc2Issuer(currentUser?.verification?.idDocument2Issuer || '');
    setDoc2FileUploaded(Boolean(currentUser?.verification?.idDocument2Name));
    setCardHolder(currentUser?.name || 'Verified Cardholder');
  }, [isOpen, initialTier, currentUser]);

  if (!isOpen) return null;

  const isSingleTierFlow = lockedTier !== undefined;
  const activeTierMeta = VERIFICATION_TIERS.find((t) => t.tier === selectedTier) || VERIFICATION_TIERS[0];
  const needsDoc2 = selectedTier >= 2;
  const needsSubscription = selectedTier === 3;
  const alreadyCoveredByHigherTier = currentTier >= selectedTier;

  const handleDocumentsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!doc1FileUploaded || !doc1Name.trim() || !doc1Number.trim()) {
      setErrorMessage(`Tier ${selectedTier} requires Legal ID #1 (document type, ID number, and uploaded file).`);
      return;
    }
    if (needsDoc2 && (!doc2FileUploaded || !doc2Name.trim() || !doc2Number.trim() || !doc2Issuer.trim())) {
      setErrorMessage(
        `Tier ${selectedTier} requires 2 Legal IDs (please provide Legal ID #2 number, issuing authority, and upload file).`
      );
      return;
    }

    const dupCheck = checkLegalIdsDuplicateAcrossPlatform({
      currentIdentifiers: [currentUser?.id, currentUser?.uid, currentUser?.handle, currentUser?.email],
      doc1Number,
      doc1Type,
      doc2Number: needsDoc2 ? doc2Number : undefined,
      doc2Type: needsDoc2 ? doc2Type : undefined
    });
    if (dupCheck.isDuplicate) {
      const msg =
        dupCheck.error ||
        'Verification blocked: That user already exists in our platform. Users cannot have multiple accounts.';
      setErrorMessage(msg);
      dispatchGlobalNotification({
        title: '🛡️ Duplicate Account Blocked',
        description: msg,
        type: 'security',
        targetTab: 'settings',
        showToast: true,
        tone: 'alert'
      });
      return;
    }

    setErrorMessage('');
    if (needsSubscription) {
      setStep('subscription');
      return;
    }

    // Tier 1 or Tier 2: Process immediately with $0/mo fee
    await executeTierVerification(selectedTier);
  };

  const executeTierVerification = async (targetTier: 1 | 2 | 3) => {
    setErrorMessage('');
    setStep('processing');
    setProcessStep(1);

    try {
      await new Promise((r) => setTimeout(r, 500));
      setProcessStep(2);

      await new Promise((r) => setTimeout(r, 600));
      setProcessStep(3);

      await new Promise((r) => setTimeout(r, 500));

      const res = await verifyUserWithTier({
        targetTier,
        idDocument1Type: doc1Type,
        idDocument1Name: doc1Name,
        idDocument1Number: doc1Number,
        idDocument2Type: targetTier >= 2 ? doc2Type : undefined,
        idDocument2Name: targetTier >= 2 ? doc2Name : undefined,
        idDocument2Number: targetTier >= 2 ? doc2Number : undefined,
        idDocument2Issuer: targetTier >= 2 ? doc2Issuer : undefined,
        paymentMethod:
          targetTier === 3
            ? paymentMethod === 'card'
              ? 'Visa ending in 4242'
              : paymentMethod === 'gpay'
              ? 'Google Pay'
              : paymentMethod === 'apple'
              ? 'Apple Pay'
              : 'USDC Autopay'
            : undefined,
        lastFour: targetTier === 3 ? '4242' : undefined
      });

      if (res.success && res.user) {
        const subFee = calculateWalletPurchaseFee({
          category: paymentMethod === 'crypto' ? 'stable_coins' : 'fiat',
          subtotalUSD: 2.0,
          symbol: paymentMethod === 'crypto' ? 'USDC' : 'USD',
          network: paymentMethod === 'crypto' ? 'Base' : undefined,
        });
        const subTotal = Math.round((2.0 + subFee.feeUSD) * 100) / 100;
        const tierMsg =
          targetTier === 3
            ? `Tier 3 Verified User status & $2.00/mo subscription activated ($${subTotal.toFixed(2)} USD charged incl. $${subFee.feeUSD.toFixed(2)} ${subFee.walletProviderLabel} fee).`
            : targetTier === 2
            ? 'Tier 2 (2 Legal IDs) activated. You are eligible to be a Driver, Retail Owner, or Restaurant Owner (includes Tier 1).'
            : 'Tier 1 (1 Legal ID) activated. You are now eligible to receive Admin Final Coins.';

        dispatchGlobalNotification({
          title: `🛡️ Tier ${targetTier} Verification Activated`,
          description: tierMsg,
          type: 'security',
          targetTab: 'settings',
          tone: targetTier === 3 ? 'gold' : 'success',
        });
        setStep('success');
        onVerificationSuccess(res.user);
      } else {
        setErrorMessage(res.error || 'Verification processing failed.');
        setStep(targetTier === 3 ? 'subscription' : 'documents');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error executing verification.');
      setStep(targetTier === 3 ? 'subscription' : 'documents');
    }
  };

  const renderTierSummaryBadge = (tierNum: 1 | 2 | 3) => (
    <div className="p-4 rounded-2xl border border-amber-300 bg-amber-50/60 flex flex-col items-center justify-center text-center gap-1.5 max-w-md mx-auto">
      <div className="flex items-center justify-center gap-2">
        {tierNum === 1 && <Coins className="w-4 h-4 text-amber-600" />}
        {tierNum === 2 && (
          <span className="inline-flex items-center gap-1 text-indigo-600">
            <Car className="w-4 h-4" />
            <Store className="w-4 h-4" />
          </span>
        )}
        {tierNum === 3 && <Award className="w-4 h-4 text-emerald-600" />}
        <span className="text-sm font-extrabold text-slate-900">Tier {tierNum}</span>
        <span
          className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
            tierNum === 3 ? 'bg-amber-200 text-amber-950' : 'bg-slate-200 text-slate-800'
          }`}
        >
          {activeTierMeta.feeLabel}
        </span>
      </div>
      <p className="text-xs font-bold text-slate-800">{activeTierMeta.shortTitle}</p>
      <p className="text-[11px] text-slate-600 leading-snug text-center">
        {tierNum === 1 && 'Receive Admin Final Coins from Admin & claim AFNL grants/subsidies.'}
        {tierNum === 2 && 'Become a Driver, Retail Store Owner, or Restaurant Owner.'}
        {tierNum === 3 && 'Unlock platform-wide Verified User Badge & Full Status.'}
      </p>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden my-6 text-center"
      >
        {/* Modal Top Header */}
        <div className="relative px-6 py-5 border-b border-slate-200 flex flex-col items-center justify-center text-center bg-slate-50/80">
          <button
            type="button"
            onClick={onClose}
            className="absolute right-4 top-4 w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-600 mb-2">
            <ShieldCheck className="w-5 h-5" />
          </div>

          <div className="flex flex-col items-center justify-center gap-1.5 text-center">
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <h2 className="text-lg font-bold text-slate-900">
                {isSingleTierFlow ? `Tier ${selectedTier} Verification` : 'Tiers'}
              </h2>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-900 text-white">
                Current: Tier {currentTier}
              </span>
            </div>
            <p className="text-xs text-slate-500 text-center">
              {isSingleTierFlow
                ? selectedTier === 1
                  ? 'Tier 1 (1 Legal ID) • Free ($0.00 / month)'
                  : selectedTier === 2
                  ? 'Tier 2 (2 Legal IDs) • Free ($0.00 / month)'
                  : 'Tier 3 (2 Legal IDs + $2/mo Verified User)'
                : 'Tier 1 (1 Legal ID) • Tier 2 (2 Legal IDs) • Tier 3 (2 Legal IDs + $2/mo Verified User)'}
            </p>
          </div>
        </div>

        {/* Stepper Indicator */}
        {!alreadyCoveredByHigherTier && (
          <div className={`grid ${needsSubscription ? 'grid-cols-2' : 'grid-cols-1'} bg-slate-100 border-b border-slate-200 text-xs font-semibold text-slate-600`}>
            <div
              className={`py-2.5 px-4 text-center ${needsSubscription ? 'border-r border-slate-200' : ''} flex items-center justify-center gap-2 ${
                step === 'documents' ? 'bg-white text-slate-900 font-bold border-b-2 border-b-amber-500' : 'bg-slate-50'
              }`}
            >
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-800 text-[11px] flex items-center justify-center">1</span>
              <span>
                {isSingleTierFlow
                  ? `Tier ${selectedTier} Legal IDs (${needsDoc2 ? '2 IDs' : '1 ID'})`
                  : `Select Tier & Legal IDs (${needsDoc2 ? '2 IDs' : '1 ID'})`}
              </span>
            </div>
            {needsSubscription && (
              <div
                className={`py-2.5 px-4 text-center flex items-center justify-center gap-2 ${
                  step === 'subscription' || step === 'processing' || step === 'success'
                    ? 'bg-white text-slate-900 font-bold border-b-2 border-b-amber-500'
                    : 'bg-slate-50 text-slate-400'
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[11px] flex items-center justify-center">2</span>
                <span>Tier 3 Subscription ($2/mo)</span>
              </div>
            )}
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center justify-center gap-2 text-center">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Body Content */}
        <div className="p-6 max-h-[75dvh] overflow-y-auto text-center">
          {/* Already verified at or above requested tier */}
          {step === 'documents' && alreadyCoveredByHigherTier && (
            <div className="py-6 text-center space-y-5">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto border-4 border-emerald-50 shadow-xs">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-lg font-bold text-slate-900">
                  {currentTier === 3
                    ? 'Tier 3 Verified User Already Active'
                    : `Tier ${currentTier} Verification Already Active`}
                </h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                  {currentTier === 3
                    ? 'You are verified at Tier 3, which automatically includes Tier 1 and Tier 2. You do not need to verify Tier 1 or Tier 2 separately.'
                    : currentTier === 2
                    ? 'You are verified at Tier 2 (2 Legal IDs), which automatically includes Tier 1. You do not need to verify Tier 1 separately.'
                    : 'You are already verified at Tier 1.'}
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl bg-slate-950 hover:bg-slate-900 text-white text-xs font-bold cursor-pointer transition-colors mx-auto"
              >
                Close
              </button>
            </div>
          )}

          {/* STEP 1: Choose Tier & Submit Legal IDs */}
          {step === 'documents' && !alreadyCoveredByHigherTier && (
            <form onSubmit={handleDocumentsSubmit} className="space-y-5 text-center">
              {/* Either focused single-tier card OR remaining tiers selector */}
              {isSingleTierFlow ? (
                renderTierSummaryBadge(selectedTier)
              ) : (
                <div className="space-y-2.5 text-center">
                  <label className="block text-xs font-bold text-slate-900 text-center">
                    Choose Verification Tier
                  </label>
                  <div
                    className={`grid grid-cols-1 ${
                      availableTiersForSelection.length === 1
                        ? 'max-w-sm mx-auto'
                        : availableTiersForSelection.length === 2
                        ? 'sm:grid-cols-2 max-w-xl mx-auto'
                        : 'sm:grid-cols-3'
                    } gap-2.5 text-center`}
                  >
                    {availableTiersForSelection.map((t) => {
                      const isSelected = selectedTier === t.tier;
                      return (
                        <button
                          key={t.tier}
                          type="button"
                          onClick={() => {
                            setSelectedTier(t.tier);
                            setErrorMessage('');
                          }}
                          className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center text-center transition-all cursor-pointer space-y-1.5 ${
                            isSelected
                              ? 'border-amber-500 bg-amber-50/70 ring-2 ring-amber-500/20'
                              : 'border-slate-200 bg-white hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex flex-col items-center justify-center gap-1">
                            <span className="text-xs font-extrabold text-slate-900">
                              Tier {t.tier}
                            </span>
                            <span
                              className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                                t.tier === 3
                                  ? 'bg-amber-100 text-amber-900'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {t.feeLabel}
                            </span>
                          </div>
                          <p className="text-[11px] font-bold text-slate-800">{t.shortTitle}</p>
                          <p className="text-[10px] text-slate-600 leading-snug text-center">
                            {t.tier === 1 && (
                              <span className="inline-flex items-center justify-center gap-1">
                                <Coins className="w-3 h-3 text-amber-600 shrink-0" />
                                <span>Receive Admin Final Coins from Admin</span>
                              </span>
                            )}
                            {t.tier === 2 && (
                              <span className="inline-flex items-center justify-center gap-1">
                                <span className="inline-flex items-center gap-0.5 text-indigo-600 shrink-0">
                                  <Car className="w-3 h-3" />
                                  <Store className="w-3 h-3" />
                                </span>
                                <span>Driver, Retail Owner, or Restaurant Owner</span>
                              </span>
                            )}
                            {t.tier === 3 && (
                              <span className="inline-flex items-center justify-center gap-1">
                                <Award className="w-3 h-3 text-emerald-600 shrink-0" />
                                <span>Verified User Badge &amp; Full Status</span>
                              </span>
                            )}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Document 1: Legal ID #1 (Required for selected tier) */}
              <div className="border border-slate-200 rounded-2xl p-4 space-y-3 bg-slate-50/40 text-center">
                <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                  <span className="text-xs font-bold text-slate-900 flex items-center justify-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-mono">1</span>
                    <span>
                      {isSingleTierFlow
                        ? `Legal ID #1 (Required for Tier ${selectedTier})`
                        : `Legal ID #1 (Required for Tier ${selectedTier})`}
                    </span>
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold">
                    Required
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                      Legal ID Document Type
                    </label>
                    <select
                      value={doc1Type}
                      onChange={(e) => setDoc1Type(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="Driver's License">Driver&apos;s License</option>
                      <option value="Passport">Passport</option>
                      <option value="National ID Card">National ID Card</option>
                      <option value="State / Military ID">State / Military ID</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                      Legal ID Number / Code
                    </label>
                    <input
                      type="text"
                      value={doc1Number}
                      onChange={(e) => setDoc1Number(e.target.value)}
                      placeholder="e.g. DL-8941029 or P9821034"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      required
                    />
                  </div>
                </div>

                {/* Upload Zone for Legal ID 1 */}
                <div className="border border-dashed border-slate-300 rounded-xl p-3 bg-white flex flex-col items-center justify-center text-center gap-2.5">
                  <div className="flex flex-col items-center justify-center gap-1.5 text-center min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
                      {doc1FileUploaded ? (
                        <FileCheck className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Upload className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                    <div className="min-w-0 text-center">
                      <p className="text-xs font-semibold text-slate-900 truncate">
                        {doc1FileUploaded && doc1Name ? doc1Name : 'No Legal ID #1 file attached yet'}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {doc1FileUploaded ? 'Attached & Encrypted (AES-256)' : 'Upload photo or PDF of your Legal ID'}
                      </p>
                    </div>
                  </div>
                  <label className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium cursor-pointer transition-colors shrink-0">
                    <span>{doc1FileUploaded ? 'Change File' : 'Upload ID #1'}</span>
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setDoc1Name(e.target.files[0].name);
                          setDoc1FileUploaded(true);
                          setErrorMessage('');
                        }
                      }}
                    />
                  </label>
                </div>
              </div>

              {/* Document 2: Legal ID #2 (Shown & Required for Tier 2 and Tier 3 only) */}
              {needsDoc2 && (
                <div className="border border-slate-200 rounded-2xl p-4 space-y-3 bg-slate-50/40 text-center">
                  <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                    <span className="text-xs font-bold text-slate-900 flex items-center justify-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-mono">2</span>
                      <span>
                        {`Legal ID #2 (Required for Tier ${selectedTier})`}
                      </span>
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold">
                      Required
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                        Second Legal ID Type
                      </label>
                      <select
                        value={doc2Type}
                        onChange={(e) => setDoc2Type(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                      >
                        <option value="Passport">Passport</option>
                        <option value="National ID Card">National ID Card</option>
                        <option value="Driver's License">Driver&apos;s License</option>
                        <option value="State / Military ID">State / Military ID</option>
                        <option value="Social Security / Tax ID">Social Security / Tax ID</option>
                        <option value="Birth Certificate / Legal Residency">Birth Certificate / Legal Residency</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                        Legal ID #2 Number / Code
                      </label>
                      <input
                        type="text"
                        value={doc2Number}
                        onChange={(e) => setDoc2Number(e.target.value)}
                        placeholder="e.g. P9821034 or SSN-LAST4"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                        Issuing Authority / Country
                      </label>
                      <input
                        type="text"
                        value={doc2Issuer}
                        onChange={(e) => setDoc2Issuer(e.target.value)}
                        placeholder="e.g. US Department of State, DMV"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Upload Zone for Legal ID 2 */}
                  <div className="border border-dashed border-slate-300 rounded-xl p-3 bg-white flex flex-col items-center justify-center text-center gap-2.5">
                    <div className="flex flex-col items-center justify-center gap-1.5 text-center min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
                        {doc2FileUploaded ? (
                          <FileCheck className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <Upload className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                      <div className="min-w-0 text-center">
                        <p className="text-xs font-semibold text-slate-900 truncate">
                          {doc2FileUploaded && doc2Name ? doc2Name : 'No Legal ID #2 file attached yet'}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {doc2FileUploaded ? 'Attached & Encrypted (AES-256)' : 'Upload photo or PDF of your 2nd Legal ID'}
                        </p>
                      </div>
                    </div>
                    <label className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium cursor-pointer transition-colors shrink-0">
                      <span>{doc2FileUploaded ? 'Change File' : 'Upload ID #2'}</span>
                      <input
                        type="file"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setDoc2Name(e.target.files[0].name);
                            setDoc2FileUploaded(true);
                            setErrorMessage('');
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
              )}

              <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer transition-all shadow-sm flex items-center justify-center gap-2"
                >
                  <span>
                    {selectedTier === 1
                      ? 'Verify Tier 1 (1 Legal ID)'
                      : selectedTier === 2
                      ? 'Verify Tier 2 (2 Legal IDs)'
                      : 'Continue to $2/mo Subscription'}
                  </span>
                  <span className="font-mono text-[11px]">&rarr;</span>
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: $2.00 / Month Subscription Setup (Tier 3 only) */}
          {step === 'subscription' && (
            <div className="space-y-5 text-center">
              {/* Plan Summary Card */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl p-5 shadow-sm space-y-4 text-center">
                <div className="flex flex-col items-center justify-center gap-1.5 text-center">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold">
                    Tier 3 Membership
                  </span>
                  <h3 className="text-lg font-bold text-white">Verified User Subscription</h3>
                  <div>
                    <span className="text-2xl font-bold text-amber-400 font-mono">$2.00</span>
                    <span className="text-xs text-slate-400"> / month</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 border-t border-slate-800 pt-3">
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Verified User Badge</span>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>2 Verified Legal IDs</span>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Driver &amp; Store Owner Eligible</span>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>Admin Final Coin Eligible</span>
                  </div>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-3 text-center">
                <label className="block text-xs font-bold text-slate-900 text-center">
                  Select Payment Method ($2.00 / month)
                </label>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      paymentMethod === 'card'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Credit Card</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('gpay')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      paymentMethod === 'gpay'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>Google Pay</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('crypto')}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      paymentMethod === 'crypto'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>USDC / Crypto</span>
                  </button>
                </div>

                {/* Card Inputs */}
                {paymentMethod === 'card' && (
                  <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50 space-y-3 text-center">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                        Name on Card
                      </label>
                      <input
                        type="text"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:ring-2 focus:ring-amber-500"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-2">
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                          Card Number
                        </label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:ring-2 focus:ring-amber-500 font-mono"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-1 text-center">
                          Expires
                        </label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 text-center focus:ring-2 focus:ring-amber-500 font-mono"
                          required
                        />
                      </div>
                    </div>
                  </div>
                )}
                {/* Itemized Subscription & Wallet Fee Breakdown */}
                {(() => {
                  const subWalletFee = calculateWalletPurchaseFee({
                    category: paymentMethod === 'crypto' ? 'stable_coins' : 'fiat',
                    subtotalUSD: 2.0,
                    symbol: paymentMethod === 'crypto' ? 'USDC' : 'USD',
                    network: paymentMethod === 'crypto' ? 'Base' : undefined,
                  });
                  const subTotalUSD = Math.round((2.0 + subWalletFee.feeUSD) * 100) / 100;
                  return (
                    <>
                      <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs font-mono text-left">
                        <div className="flex items-center justify-between text-slate-600">
                          <span>Tier 3 Monthly Subscription</span>
                          <span>$2.00</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-600">
                          <span>{subWalletFee.feeLabel}</span>
                          <span className="text-amber-700 font-semibold">+${subWalletFee.feeUSD.toFixed(2)}</span>
                        </div>
                        <div className="pt-1.5 border-t border-slate-200 flex items-center justify-between font-bold text-slate-900">
                          <span>Total Charged Today</span>
                          <span>${subTotalUSD.toFixed(2)} USD</span>
                        </div>
                      </div>

                      <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
                        <button
                          type="button"
                          onClick={() => setStep('documents')}
                          className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer transition-colors"
                        >
                          &larr; Back to Legal IDs
                        </button>
                        <button
                          type="button"
                          onClick={() => executeTierVerification(3)}
                          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer transition-all shadow-sm flex items-center justify-center gap-2"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Activate Tier 3 (${subTotalUSD.toFixed(2)} Total)</span>
                        </button>
                      </div>
                    </>
                  );
                })()}
              </div>
            </div>
          )}

          {/* STEP 3: Processing */}
          {step === 'processing' && (
            <div className="py-8 text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto animate-spin">
                <RefreshCw className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900">
                  Processing Tier {selectedTier} Verification
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {selectedTier === 3
                    ? 'Validating 2 Legal IDs and establishing $2.00/month Verified User subscription.'
                    : selectedTier === 2
                    ? 'Validating 2 Legal IDs for Driver, Retail Owner & Restaurant Owner eligibility.'
                    : 'Validating 1 Legal ID for Admin Final Coin eligibility.'}
                </p>
              </div>

              <div className="max-w-xs mx-auto space-y-2 text-center text-xs">
                <div className="flex items-center justify-center gap-2 text-slate-700">
                  {processStep >= 1 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span className={processStep === 1 ? 'font-bold text-amber-700' : ''}>
                    1. Encrypting {selectedTier >= 2 ? '2 Legal IDs' : '1 Legal ID'}
                  </span>
                </div>
                <div className="flex items-center justify-center gap-2 text-slate-700">
                  {processStep >= 2 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span className={processStep === 2 ? 'font-bold text-amber-700' : ''}>
                    2. Verifying Legal Identity Registry
                  </span>
                </div>
                <div className="flex items-center justify-center gap-2 text-slate-700">
                  {processStep >= 3 ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300" />
                  )}
                  <span className={processStep === 3 ? 'font-bold text-amber-700' : ''}>
                    {selectedTier === 3
                      ? '3. Activating $2.00/mo Verified User Tier'
                      : `3. Activating Tier ${selectedTier} Permissions`}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Success */}
          {step === 'success' && (
            <div className="py-6 text-center space-y-5">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto border-4 border-emerald-50 shadow-xs">
                <ShieldCheck className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-900">
                  Tier {selectedTier} Verification Activated!
                </h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  {selectedTier === 3
                    ? 'Your 2 Legal IDs and $2.00/month subscription are active. You now hold full Verified User status.'
                    : selectedTier === 2
                    ? 'Your 2 Legal IDs are verified. You are now eligible to be a Driver, Retail Store Owner, or Restaurant Owner.'
                    : 'Your 1 Legal ID is verified. You are now eligible to receive Admin Final Coins from the Admin.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs space-y-2 max-w-md mx-auto">
                <div className="flex flex-col items-center">
                  <span className="text-slate-500">Verification Tier:</span>
                  <span className="font-bold text-emerald-600 flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Tier {selectedTier} {selectedTier === 3 ? '— Verified User' : ''}
                  </span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-slate-500">Legal ID #1:</span>
                  <span className="font-medium text-slate-900">{doc1Type} ({doc1Name})</span>
                </div>
                {selectedTier >= 2 && (
                  <div className="flex flex-col items-center">
                    <span className="text-slate-500">Legal ID #2:</span>
                    <span className="font-medium text-slate-900">{doc2Type} ({doc2Name})</span>
                  </div>
                )}
                <div className="flex flex-col items-center border-t border-slate-200 pt-1.5">
                  <span className="text-slate-500">Monthly Fee:</span>
                  <span className="font-bold text-slate-900 font-mono">
                    {selectedTier === 3 ? '$2.00 / month (Active)' : '$0.00 / month'}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full max-w-xs mx-auto py-3 px-5 rounded-2xl bg-slate-950 hover:bg-slate-900 text-white font-bold text-xs transition-all cursor-pointer shadow-sm"
              >
                Close &amp; Continue
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
