import React, { useState, useEffect } from 'react';
import { X, HandCoins } from 'lucide-react';
import { recordLedgerTransaction } from '../utils/universalLedgerBridge';
import { AuthSession } from '../types/auth';
import { UserPublicProfile } from '../types/social';
import { createLoan, LoanRecord } from '../services/loanService';
import { ConfirmModal } from './common/ConfirmModal';
import { getStoredUserWallets } from '../data/defaultWallets';
import { UserWalletData } from '../types/wallet';

interface ProvideLoanModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthSession | null;
  targetUser: UserPublicProfile;
  mode: 'provide' | 'ask';
  onSuccess: (msg: string) => void;
}

export const ProvideLoanModal: React.FC<ProvideLoanModalProps> = ({ isOpen, onClose, currentUser, targetUser, mode, onSuccess }) => {
  const [walletData, setWalletData] = useState<UserWalletData>(() => getStoredUserWallets(currentUser?.id || 'guest'));
  const [loanAmount, setLoanAmount] = useState('1000');
  const [loanInterest, setLoanInterest] = useState('5.0');
  const [loanTermDays, setLoanTermDays] = useState('30');
  const [selectedCoin, setSelectedCoin] = useState(walletData.finalCoins[0]?.symbol || 'AFNL');
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    setWalletData(getStoredUserWallets(currentUser?.id || 'guest'));
  }, [currentUser?.id]);

  if (!isOpen || !currentUser) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(loanAmount);
    if (isNaN(amt) || amt <= 0) {
      onSuccess('Please enter a valid loan amount.');
      return;
    }

    if (mode === 'ask') {
      // ... (keep existing ask logic, but maybe update symbol to selectedCoin if needed)
      // Actually, for 'ask', let's stick to using the selectedCoin for the request.
      const tid = targetUser.userId?.toLowerCase() || '';
      const handle = (targetUser as any).handle || targetUser.userId || '';
      const uid = targetUser.uid?.toLowerCase() || '';
      const isPreset = 
        tid.includes('satoshi') || handle.includes('satoshi') ||
        tid.includes('sterling') || handle.includes('sterling') ||
        tid.includes('belfort') || handle.includes('belfort') ||
        tid.includes('morgan') || handle.includes('morgan') ||
        tid === 'demo-satoshi-nakamoto' ||
        tid === 'user-lord_sterling' ||
        tid === 'demo-jordan-belfort' ||
        tid === 'demo-alex-morgan';

      const isAuthorizedBank = isPreset || 
        localStorage.getItem(`ff_bank_app_status_${tid}`) === 'approved' || 
        localStorage.getItem(`ff_bank_app_status_${uid}`) === 'approved' ||
        localStorage.getItem(`ff_bank_app_status_${targetUser.userId}`) === 'approved';

      if (!isAuthorizedBank) {
        onSuccess('Loan requests can only be sent to individuals authorized for internal banking by Protocol Admins.');
        onClose();
        return;
      }

      const borrowerHandle = `@${currentUser.id || currentUser.uid}`;
      const lenderHandle = `@${targetUser.userId}`;
      const borrowerId = currentUser.id || 'guest_trader';
      const lenderId = targetUser.userId || 'guest_trader';

      const dateObj = new Date();
      const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
      const recNum = `REC-LOAN-REQ-${Math.floor(1000 + Math.random() * 9000)}`;

      const reqItem = {
        id: `rec-loan-req-${Date.now()}`,
        receiptNumber: recNum,
        taxYear: 2026,
        timestamp: dateStr,
        dateIso: dateObj.toISOString(),
        type: 'deposit',
        category: 'loan',
        mode: 'final_coin',
        title: `Loan Request registered with ${lenderHandle}`,
        description: `Requested loan of ${amt.toLocaleString()} ${selectedCoin} at ${parseFloat(loanInterest)}% interest (${parseInt(loanTermDays, 10)} days term) from ${lenderHandle}.`,
        amountUSD: amt,
        feeUSD: 0.00,
        netAmountUSD: 0.00,
        sourceOrDestination: `Sovereign Credit Request`,
        counterpartyOrIssuer: lenderHandle,
        paymentCoinSymbol: selectedCoin,
        paymentCoinAmount: amt,
        taxClassification: {
          formMapping: 'Non-Taxable Transfer',
          taxableEvent: false,
          irsCategoryNote: 'Sovereign credit facility application.'
        },
        signature: `SIG-REQ-${Math.floor(100000 + Math.random() * 900000)}`
      };

      // Record for requester
      recordLedgerTransaction(borrowerId, reqItem as any);
      // Record for lender
      recordLedgerTransaction(lenderId, {
        ...reqItem,
        title: `Incoming Loan Request from ${borrowerHandle}`,
        description: `Received a loan request of ${amt.toLocaleString()} ${selectedCoin} at ${parseFloat(loanInterest)}% interest from ${borrowerHandle}.`
      } as any);
      // Record for admins
      recordLedgerTransaction('admin', {
        ...reqItem,
        title: `System Credit Facility Application: ${borrowerHandle} ➔ ${lenderHandle}`,
      } as any);
      recordLedgerTransaction('super_admin', {
        ...reqItem,
        title: `System Credit Facility Application: ${borrowerHandle} ➔ ${lenderHandle}`,
      } as any);

      // Notify system components of the ledger updates
      window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

      onSuccess(`Loan request for ${amt} ${selectedCoin} successfully sent to @${targetUser.userId}!`);
      onClose();
      return;
    }

    setShowConfirm(true);
  };

  const processExecution = () => {
    const amt = parseFloat(loanAmount);
    // Provider logic
    const borrowerHandle = `@${targetUser.userId}`;
    const myBankId = currentUser.id || 'guest_trader';
    const targetBankId = targetUser.userId || 'guest_trader';

    const newLoan: LoanRecord = {
      id: `loan-${Date.now()}`,
      lenderId: myBankId,
      lenderHandle: `@${currentUser.id || currentUser.uid}`,
      borrowerId: targetBankId,
      borrowerHandle: borrowerHandle,
      amount: amt,
      coinSymbol: selectedCoin,
      interestRate: parseFloat(loanInterest) || 5.0,
      termDays: parseInt(loanTermDays, 10) || 30,
      status: 'active',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC',
      issuedAtMs: Date.now()
    };

    createLoan(newLoan);

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNumProvider = `REC-LOAN-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

    // Ledger for provider (sender)
    const providerItem = {
      id: `rec-loan-out-${Date.now()}`,
      receiptNumber: recNumProvider,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'loan_issued',
      category: 'loan',
      mode: 'final_coin',
      title: `Final Coin Loan Issued to ${newLoan.borrowerHandle}`,
      description: `Issued ${amt.toLocaleString()} ${selectedCoin} loan at ${newLoan.interestRate}% APR (${newLoan.termDays} days term) to ${newLoan.borrowerHandle}.`,
      amountUSD: amt,
      feeUSD: 0.00,
      netAmountUSD: -amt,
      sourceOrDestination: `Clearing Bank Vault (@${currentUser?.id})`,
      counterpartyOrIssuer: newLoan.borrowerHandle,
      paymentCoinSymbol: selectedCoin,
      paymentCoinAmount: amt,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Inter-bank sovereign final coin loan principal issuance.'
      },
      signature: `SIG-LOAN-${Math.floor(100000 + Math.random() * 900000)}`
    };
    recordLedgerTransaction(myBankId, { ...providerItem, loanId: newLoan.id } as any);

    const recNumReceiver = `REC-LOAN-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(100 + Math.random() * 900)}`;

    // Ledger for receiver (borrower)
    const receiverItem = {
      id: `rec-loan-in-${Date.now()}`,
      receiptNumber: recNumReceiver,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'loan_received',
      category: 'loan',
      mode: 'final_coin',
      title: `Final Coin Loan Received from ${newLoan.lenderHandle}`,
      description: `Received ${amt.toLocaleString()} ${selectedCoin} loan at ${newLoan.interestRate}% APR (${newLoan.termDays} days term) from ${newLoan.lenderHandle}.`,
      amountUSD: amt,
      feeUSD: 0.00,
      netAmountUSD: amt,
      sourceOrDestination: `User Wallet (@${targetUser.userId})`,
      counterpartyOrIssuer: newLoan.lenderHandle,
      paymentCoinSymbol: selectedCoin,
      paymentCoinAmount: amt,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Sovereign loan principal proceeds.'
      },
      signature: `SIG-LOAN-${Math.floor(100000 + Math.random() * 900000)}`
    };
    recordLedgerTransaction(targetBankId, { ...receiverItem, loanId: newLoan.id } as any);

    // Ledger for Admin Audit Console tracking
    const adminItem = {
      ...providerItem,
      id: `rec-loan-admin-${Date.now()}`,
      title: `Ecosystem Credit Transfer: ${newLoan.lenderHandle} ➔ ${newLoan.borrowerHandle}`,
      description: `Sovereign loan approved & finalized. Principal Amount: ${amt.toLocaleString()} ${selectedCoin}, APR: ${newLoan.interestRate}%, Term: ${newLoan.termDays} days.`,
      netAmountUSD: amt, // Track total flow under admin metrics
    };
    recordLedgerTransaction('admin', { ...adminItem, loanId: newLoan.id } as any);
    recordLedgerTransaction('super_admin', { ...adminItem, loanId: newLoan.id } as any);

    // Notify system components of the ledger updates
    window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

    onSuccess(`Successfully issued loan of ${amt.toLocaleString()} ${selectedCoin} to ${borrowerHandle}!`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 uppercase tracking-wider flex items-center w-fit gap-1.5">
              <HandCoins className="w-3 h-3" />
              Inter-Bank Loan Desk
            </span>
            <h3 className="text-lg font-bold text-slate-900">
              {mode === 'provide' ? `Issue Loan to @${targetUser.userId}` : `Request Loan from @${targetUser.userId}`}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="font-semibold text-slate-700">Loan Amount (AFNL)</label>
              <input
                type="number"
                min="1"
                step="any"
                required
                value={loanAmount}
                onChange={e => setLoanAmount(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
              />
            </div>
            <div className="space-y-1.5">
              <label className="font-semibold text-slate-700">Select Coin</label>
              <select
                value={selectedCoin}
                onChange={e => setSelectedCoin(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
              >
                {walletData.finalCoins.map(coin => (
                  <option key={coin.symbol} value={coin.symbol}>{coin.symbol}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="font-semibold text-slate-700">Interest Rate (% APR)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                required
                value={loanInterest}
                onChange={e => setLoanInterest(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
              />
            </div>
            <div className="space-y-1.5">
              <label className="font-semibold text-slate-700">Term (Days)</label>
              <input
                type="number"
                min="1"
                required
                value={loanTermDays}
                onChange={e => setLoanTermDays(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono font-medium"
              />
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer"
            >
              {mode === 'provide' ? 'Issue Loan' : 'Send Request'}
            </button>
          </div>
        </form>
      </div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title="Confirm Loan Issuance"
        message={`Are you sure you want to issue a loan of ${loanAmount} AFNL to @${targetUser.userId} at ${loanInterest}% APR for ${loanTermDays} days?`}
        confirmText="Confirm Loan"
        type="warning"
      />
    </div>
  );
};
