import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Heart,
  Eye,
  Repeat,
  MessageSquare,
  CheckCircle2,
  ShieldCheck,
  Tag,
  Sparkles,
  Twitter,
  Clock,
  Star,
  Package,
  Briefcase,
  User as UserIcon,
  Coins,
  ArrowRightLeft,
  Hash,
  Video as VideoIcon,
  Image as ImageIcon,
  MapPin,
  Layers,
  X,
  Gavel
} from 'lucide-react';
import { MarketplaceListing } from '../types';
import { useApp } from '../context/AppContext';
import { getAverageRating } from '../services/ratingService';
import {
  getAllMarketplaceListings,
  getAuctionBids,
  getAuctionRemainingLabel,
  getCurrentAuctionPriceUSD,
  getMinimumNextBidUSD,
} from '../services/marketplaceService';
import { getListingTradeActionLabel, getListingComprehensivePricing } from '../services/marketplaceSettlementService';
import { getCurrentSession } from '../services/firebaseAuth';
import { getOrCreateDirectConversation } from '../services/chatService';
import { areUsersBlockedEitherWay, isAdminAccount } from '../services/socialService';
import { createTweet, TWEETING_MAX_CHARS } from '../services/tweetingService';
import { getAverageRatingForListing, getReviewsForListing } from '../services/postRatingService';
import { TweetingComposerModal, TweetingComposerSubmitPayload } from './TweetingComposerModal';
import { PresenceAvatarDot, PresenceStatusBadge } from './common/PresenceBadge';

interface ListingDetailPageProps {
  listing: MarketplaceListing | any;
  onNavigateBack: () => void;
  onOpenBarterModal?: (listing: MarketplaceListing) => void;
  onSelectUser?: (userIdOrHandle: string) => void;
  backLabel?: string;
}

const SETTLEMENT_LABELS: Record<string, string> = {
  barter: 'Barter / Counter-Trade',
  final_coins: 'Final Coins (AFNL)',
  stable_coins: 'Stablecoins (USDC / USDT / EURS)',
  fiat: 'Fiat Reserves (USD / EUR / CHF)',
  crypto: 'Cryptocurrency (BTC / ETH)'
};

export const ListingDetailPage: React.FC<ListingDetailPageProps> = ({
  listing: initialListing,
  onNavigateBack,
  onOpenBarterModal,
  onSelectUser,
  backLabel = 'Back to Marketplace'
}) => {
  const {
    listings,
    toggleLikeListing,
    setCurrentTab,
    addToast,
    setReturnListingId,
    setChatReturnOrigin
  } = useApp();

  const [showTweetModal, setShowTweetModal] = useState(false);
  const [selectedPhotoIdx, setSelectedPhotoIdx] = useState(0);
  const [lightboxMedia, setLightboxMedia] = useState<{ type: 'photo' | 'video'; url: string; title?: string } | null>(null);

  // Merge live context / marketplaceService record with initialListing so likes, views, media, and tags stay complete
  const rawListing: any = useMemo(() => {
    const contextMatch = listings.find((l) => l.id === initialListing.id);
    const serviceMatch = getAllMarketplaceListings().find((l) => l.id === initialListing.id);
    return {
      ...serviceMatch,
      ...initialListing,
      ...contextMatch,
    };
  }, [listings, initialListing]);

  const sellerName = rawListing.sellerName || rawListing.creatorName || 'Merchant';
  const sellerHandleRaw = rawListing.sellerHandle || rawListing.creatorHandle || 'merchant';
  const sellerHandleClean = sellerHandleRaw.startsWith('@')
    ? sellerHandleRaw
    : `@${sellerHandleRaw}`;
  const sellerId = rawListing.sellerId || rawListing.userId || sellerHandleRaw.replace(/^@/, '');
  const sellerAvatar = rawListing.sellerAvatar || rawListing.creatorAvatar || '';
  const priceUSD = Number(rawListing.priceUSD ?? rawListing.primaryPriceUSD ?? 0);
  const barterDesired = rawListing.barterDesired || rawListing.barterTerms?.desiredTrades;
  const createdAtLabel = rawListing.createdAt || 'Recently';

  const isService =
    rawListing.itemType === 'service' ||
    (rawListing.category && String(rawListing.category).toLowerCase().includes('service'));

  const isAuction = rawListing.listingIntent === 'auction';
  const isSettled = rawListing.status === 'sold' || rawListing.auctionConfig?.status === 'settled';
  const auctionBids = isAuction ? getAuctionBids(rawListing.id) : [];
  const auctionCountdown = isAuction ? getAuctionRemainingLabel(rawListing.auctionConfig?.endTimeIso) : null;
  const auctionCurrentUSD = isAuction ? getCurrentAuctionPriceUSD(rawListing) : priceUSD;
  const auctionMinNextUSD = isAuction ? getMinimumNextBidUSD(rawListing) : priceUSD;
  const activeSession = getCurrentSession();
  const isAuctionOwner = Boolean(
    activeSession &&
      ((activeSession.id || '').replace(/^user-/, '').toLowerCase() ===
        String(sellerId || '').replace(/^user-/, '').toLowerCase() ||
        (activeSession.handle || '').replace(/^@/, '').toLowerCase() ===
          sellerHandleClean.replace(/^@/, '').toLowerCase())
  );

  const sellerRating = getAverageRating(sellerHandleRaw || sellerId || '');
  const attributeEntries = Object.entries(rawListing.attributes || {});

  // Collect ALL photos (imageUrl + photos[] + mediaList images), deduplicated
  const allPhotos = useMemo(() => {
    const seen = new Set<string>();
    const list: { url: string; name?: string }[] = [];
    const pushPhoto = (url?: string, name?: string) => {
      if (!url || typeof url !== 'string') return;
      const trimmed = url.trim();
      if (!trimmed || seen.has(trimmed)) return;
      seen.add(trimmed);
      list.push({ url: trimmed, name });
    };
    pushPhoto(rawListing.imageUrl, 'Primary Photo');
    if (Array.isArray(rawListing.photos)) {
      rawListing.photos.forEach((p: string, idx: number) => pushPhoto(p, `Photo ${idx + 1}`));
    }
    if (Array.isArray(rawListing.mediaList)) {
      rawListing.mediaList.forEach((m: any, idx: number) => {
        if (m && m.type !== 'video') {
          pushPhoto(m.url, m.name || `Gallery Photo ${idx + 1}`);
        }
      });
    }
    return list;
  }, [rawListing]);

  // Collect ALL videos (videoUrl + video + videos[] + mediaList videos), deduplicated
  const allVideos = useMemo(() => {
    const seen = new Set<string>();
    const list: { url: string; name?: string }[] = [];
    const pushVideo = (url?: string, name?: string) => {
      if (!url || typeof url !== 'string') return;
      const trimmed = url.trim();
      if (!trimmed || seen.has(trimmed)) return;
      seen.add(trimmed);
      list.push({ url: trimmed, name });
    };
    pushVideo(rawListing.videoUrl, 'Showcase Video');
    pushVideo(rawListing.video, 'Attached Video');
    if (Array.isArray(rawListing.videos)) {
      rawListing.videos.forEach((v: string, idx: number) => pushVideo(v, `Video ${idx + 1}`));
    }
    if (Array.isArray(rawListing.mediaList)) {
      rawListing.mediaList.forEach((m: any, idx: number) => {
        if (m && m.type === 'video') {
          pushVideo(m.url, m.name || `Video ${idx + 1}`);
        }
      });
    }
    return list;
  }, [rawListing]);

  // Collect ALL hashtags (explicit hashtags[] + any #tags inside description or title)
  const allHashtags = useMemo(() => {
    const set = new Set<string>();
    const addHash = (h: string) => {
      const clean = h.replace(/^#+/, '').trim();
      if (clean) set.add(clean);
    };
    if (Array.isArray(rawListing.hashtags)) {
      rawListing.hashtags.forEach((h: string) => addHash(h));
    }
    const textBlob = `${rawListing.title || ''} ${rawListing.description || ''}`;
    const matches = textBlob.match(/#([a-zA-Z0-9_]+)/g);
    if (matches) {
      matches.forEach((m) => addHash(m));
    }
    return Array.from(set);
  }, [rawListing]);

  // Collect ALL general tags & skills
  const allTags = useMemo(() => {
    const set = new Set<string>();
    const addTag = (t: string) => {
      const clean = String(t).replace(/^#+/, '').trim();
      if (clean) set.add(clean);
    };
    if (Array.isArray(rawListing.tags)) rawListing.tags.forEach(addTag);
    if (Array.isArray(rawListing.skills)) rawListing.skills.forEach(addTag);
    if (rawListing.category) addTag(String(rawListing.category).replace(/_/g, ' '));
    if (rawListing.condition) addTag(rawListing.condition);
    if (rawListing.appraisalGrade) addTag(`Grade ${rawListing.appraisalGrade}`);
    if (rawListing.modelUsed) addTag(rawListing.modelUsed);
    if (rawListing.imageResolution) addTag(rawListing.imageResolution);
    return Array.from(set);
  }, [rawListing]);

  const activePhoto = allPhotos[selectedPhotoIdx] || allPhotos[0] || null;

  // Highlight #hashtags, @mentions, and $tickers cleanly inside the full description
  const renderRichDescription = (text: string) => {
    const parts = text.split(/([@#$][a-zA-Z0-9_]+)/g);
    return parts.map((part, i) => {
      if (part.startsWith('#') && part.length > 1) {
        return (
          <span key={i} className="text-emerald-700 font-semibold">
            {part}
          </span>
        );
      }
      if (part.startsWith('@') && part.length > 1) {
        const handle = part.slice(1);
        return (
          <button
            key={i}
            type="button"
            onClick={() => onSelectUser && onSelectUser(handle)}
            className="text-sky-600 hover:underline font-semibold cursor-pointer inline"
          >
            {part}
          </button>
        );
      }
      if (part.startsWith('$') && part.length > 1 && !/^\$\d/.test(part)) {
        return (
          <span key={i} className="text-amber-800 font-mono font-bold">
            {part}
          </span>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <div className="max-w-5xl mx-auto pb-20 space-y-6 animate-in fade-in duration-200">
      {/* Top Bar with Back Button & Share Full Link Button */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <button
          type="button"
          onClick={onNavigateBack}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 text-xs font-bold shadow-2xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{backLabel}</span>
        </button>

        <button
          type="button"
          onClick={() => setShowTweetModal(true)}
          title="Share this listing on Tweet"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-2xs transition-colors cursor-pointer"
        >
          <Twitter className="w-3.5 h-3.5 -scale-x-100 -rotate-12 fill-white" />
          <span>Tweet</span>
        </button>
      </div>

      {/* Main Content Container — Shows ALL Photos, ALL Videos, Full Description, Hashtags & Tags */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          {/* Left Column: All Visual Photos, All Videos & Engagement */}
          <div className="lg:col-span-6 bg-slate-50 border-b lg:border-b-0 lg:border-r border-slate-200 p-5 sm:p-6 flex flex-col justify-between gap-5">
            <div className="space-y-4">
              {/* Primary Photo Viewer */}
              <div className="relative rounded-2xl overflow-hidden bg-slate-900 aspect-[4/3] w-full shadow-inner">
                {activePhoto ? (
                  <img
                    src={activePhoto.url}
                    alt={activePhoto.name || rawListing.title}
                    onClick={() => setLightboxMedia({ type: 'photo', url: activePhoto.url, title: rawListing.title })}
                    className="w-full h-full object-contain bg-slate-950 cursor-pointer"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 gap-2">
                    {isService ? <Briefcase className="w-10 h-10" /> : <Package className="w-10 h-10" />}
                    <span className="text-xs font-mono">No preview image</span>
                  </div>
                )}

                {/* Top Overlay Badges */}
                <div className="absolute top-3 left-3 flex flex-wrap items-center gap-1.5">
                  <span
                    className={`inline-flex items-center gap-1 text-[10px] font-mono uppercase px-2.5 py-1 rounded-full font-bold backdrop-blur-xs shadow-xs ${
                      isService
                        ? 'bg-indigo-950/85 text-indigo-100'
                        : 'bg-slate-900/85 text-amber-200'
                    }`}
                  >
                    {isService ? <Briefcase className="w-3 h-3" /> : <Package className="w-3 h-3" />}
                    <span>{isService ? 'Service' : 'Good'}</span>
                  </span>

                  {rawListing.listingIntent === 'buy' && (
                    <span className="text-[10px] font-mono uppercase px-2.5 py-1 rounded-full bg-amber-500 text-slate-950 font-bold shadow-xs">
                      Wanted / Buying
                    </span>
                  )}

                  {isAuction && (
                    <span
                      className={`inline-flex items-center gap-1 text-[10px] font-mono uppercase px-2.5 py-1 rounded-full font-bold shadow-xs ${
                        isSettled
                          ? 'bg-emerald-600 text-white'
                          : auctionCountdown?.isEnded
                          ? 'bg-slate-800 text-slate-200'
                          : 'bg-amber-500 text-slate-950'
                      }`}
                    >
                      <Gavel className="w-3 h-3" />
                      <span>{isSettled ? 'Auction Settled' : auctionCountdown?.isEnded ? 'Auction Ended' : 'Live Auction'}</span>
                    </span>
                  )}

                  {rawListing.appraisalGrade && (
                    <span className="text-[10px] font-mono uppercase px-2.5 py-1 rounded-full bg-emerald-600/90 text-white font-bold shadow-xs">
                      Grade {rawListing.appraisalGrade}
                    </span>
                  )}
                </div>
              </div>

              {/* ALL Photos Gallery */}
              {allPhotos.length > 0 && (
                <div className="space-y-2.5 text-center">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold flex items-center justify-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
                    <span>All Photos ({allPhotos.length})</span>
                  </span>
                  <div className="flex flex-wrap items-center justify-center gap-2.5">
                    {allPhotos.map((photo, idx) => (
                      <button
                        key={`${photo.url}-${idx}`}
                        type="button"
                        onClick={() => setSelectedPhotoIdx(idx)}
                        className={`relative rounded-xl overflow-hidden w-20 h-20 sm:w-24 sm:h-24 border-2 transition-all cursor-pointer bg-slate-900 text-white text-[10px] flex items-center justify-center text-center ${
                          idx === selectedPhotoIdx
                            ? 'border-amber-500 ring-2 ring-amber-400/40'
                            : 'border-slate-200 hover:border-slate-400'
                        }`}
                      >
                        <img
                          src={photo.url}
                          alt={photo.name || `Photo ${idx + 1}`}
                          className="w-full h-full object-cover text-center"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* ALL Videos Section */}
              {allVideos.length > 0 && (
                <div className="space-y-2.5 text-center">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold flex items-center justify-center gap-1.5">
                    <VideoIcon className="w-3.5 h-3.5 text-indigo-600" />
                    <span>All Videos ({allVideos.length})</span>
                  </span>
                  <div className="space-y-2.5">
                    {allVideos.map((vid, idx) => (
                      <div
                        key={`${vid.url}-${idx}`}
                        className="rounded-2xl overflow-hidden bg-black border border-slate-200 shadow-2xs"
                      >
                        <video
                          src={vid.url}
                          controls
                          playsInline
                          preload="metadata"
                          className="w-full max-h-72 object-contain bg-black"
                        />
                        {vid.name && (
                          <div className="px-3 py-1.5 bg-slate-900 text-slate-200 text-[11px] font-mono flex items-center justify-between">
                            <span className="truncate">{vid.name}</span>
                            <button
                              type="button"
                              onClick={() => setLightboxMedia({ type: 'video', url: vid.url, title: vid.name || rawListing.title })}
                              className="text-amber-300 hover:underline text-[10px] cursor-pointer shrink-0 ml-2"
                            >
                              Expand
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4">
              {/* Engagement Stats Bar */}
              <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 px-4 py-3 rounded-2xl bg-white border border-slate-200/80 text-xs text-center">
                <button
                  type="button"
                  onClick={() => toggleLikeListing(rawListing.id)}
                  className={`inline-flex items-center justify-center gap-1.5 font-semibold transition-colors cursor-pointer ${
                    rawListing.isLiked ? 'text-rose-600' : 'text-slate-600 hover:text-rose-600'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${rawListing.isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                  <span>{rawListing.likesCount ?? rawListing.likes ?? 0} likes</span>
                </button>

                <div className="inline-flex items-center justify-center gap-1.5 font-mono text-slate-500">
                  <Eye className="w-4 h-4 text-slate-400" />
                  <span>{(rawListing.views ?? 0).toLocaleString()} views</span>
                </div>

                <div className="inline-flex items-center justify-center gap-1.5 font-mono text-[11px] text-slate-500">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Posted {createdAtLabel}</span>
                </div>
              </div>

              {/* Seller / Counterparty Profile Box */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200/90 flex flex-col items-center justify-center text-center gap-2.5">
                <div className="relative shrink-0">
                  {sellerAvatar ? (
                    <img
                      src={sellerAvatar}
                      alt={sellerName}
                      className="w-12 h-12 rounded-full object-cover border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center font-serif font-bold text-sm shrink-0">
                      {sellerName.charAt(0)}
                    </div>
                  )}
                  <PresenceAvatarDot
                    identifiers={[sellerId, sellerHandleRaw]}
                    size="sm"
                  />
                </div>

                <div className="space-y-1 text-center">
                  <div className="flex items-center justify-center gap-1.5">
                    <p className="font-bold text-sm text-slate-900">{sellerName}</p>
                    {rawListing.sellerVerified && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    )}
                  </div>
                  <div className="flex items-center justify-center gap-2 flex-wrap">
                    <span className="text-xs font-mono text-slate-500">{sellerHandleClean}</span>
                    <PresenceStatusBadge
                      identifiers={[sellerId, sellerHandleRaw]}
                      size="xs"
                    />
                    {sellerRating.count > 0 && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded-full border border-amber-200">
                        <Star className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
                        <span>{sellerRating.average}</span>
                      </span>
                    )}
                  </div>
                </div>

                {onSelectUser && (
                  <button
                    type="button"
                    onClick={() => onSelectUser(sellerId || sellerHandleRaw)}
                    className="mt-1 px-4 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <UserIcon className="w-3.5 h-3.5" />
                    <span>View Profile</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Full Details, Description, Hashtags, Tags, Pricing & Settlements */}
          <div className="lg:col-span-6 p-5 sm:p-7 flex flex-col justify-between gap-6 text-center">
            <div className="space-y-5">
              {/* Category & Verification Pills */}
              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-[11px] font-mono font-semibold text-slate-700 uppercase">
                  <Tag className="w-3 h-3 text-amber-600" />
                  <span>{String(rawListing.category || 'Marketplace').replace(/_/g, ' ')}</span>
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] font-semibold text-emerald-800">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  <span>Verified Escrow Eligible</span>
                </span>
                {rawListing.location && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-[11px] font-medium text-slate-700">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    <span>{rawListing.location}</span>
                  </span>
                )}
              </div>

              {/* Title & Full Untruncated Description */}
              <div className="space-y-2.5 text-center">
                <h1 className="font-serif text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
                  {rawListing.title}
                </h1>
                <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                  {renderRichDescription(rawListing.description || '')}
                </div>
              </div>

              {/* ALL Hashtags */}
              {allHashtags.length > 0 && (
                <div className="space-y-2 text-center">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold flex items-center justify-center gap-1.5">
                    <Hash className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Hashtags</span>
                  </span>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {allHashtags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* ALL Tags & Skills */}
              {allTags.length > 0 && (
                <div className="space-y-2 text-center">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold flex items-center justify-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-amber-600" />
                    <span>Tags &amp; Categories</span>
                  </span>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {allTags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2.5 py-1 rounded-xl bg-slate-100 border border-slate-200 text-[11px] font-medium text-slate-800"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Valuation & Pricing Panel / Live Auction Desk */}
              {isAuction ? (
                <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3.5 text-center">
                  <div className="flex items-center justify-center gap-2 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-mono uppercase tracking-wider font-bold text-amber-900">
                      <Gavel className="w-3.5 h-3.5 text-amber-700" />
                      <span>5-Mode Auction Room</span>
                    </span>
                    {auctionCountdown && !isSettled && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900 text-amber-300 font-mono text-[11px] font-bold">
                        <Clock className="w-3 h-3" />
                        <span>{auctionCountdown.text}</span>
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-500 block">
                        {rawListing.auctionConfig?.highestBidUSD ? 'Current High Bid' : 'Starting Bid'}
                      </span>
                      <span className="font-mono text-lg font-black text-amber-800 block mt-0.5">
                        ${auctionCurrentUSD.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-500 block">Min Next Bid</span>
                      <span className="font-mono text-sm font-bold text-slate-900 block mt-1">
                        ${auctionMinNextUSD.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-500 block">Bid Activity</span>
                      <span className="font-mono text-sm font-bold text-slate-900 block mt-1">
                        {auctionBids.length} {auctionBids.length === 1 ? 'bid' : 'bids'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-500 block">
                        {rawListing.auctionConfig?.buyNowPriceUSD ? 'Buy Now Price' : 'Reserve'}
                      </span>
                      <span className="font-mono text-sm font-bold text-emerald-800 block mt-1">
                        {rawListing.auctionConfig?.buyNowPriceUSD
                          ? `$${Number(rawListing.auctionConfig.buyNowPriceUSD).toLocaleString()}`
                          : rawListing.auctionConfig?.reservePriceUSD
                          ? `$${Number(rawListing.auctionConfig.reservePriceUSD).toLocaleString()}`
                          : 'No Reserve'}
                      </span>
                    </div>
                  </div>

                  {auctionBids.length > 0 && (
                    <div className="pt-2.5 border-t border-amber-200/80 space-y-1.5 text-left">
                      <span className="text-[10px] font-mono uppercase text-amber-900 font-bold block text-center">
                        Recent Highest Bids (All 5 Modes Supported)
                      </span>
                      <div className="space-y-1">
                        {auctionBids.slice(0, 3).map((b) => (
                          <div
                            key={b.id}
                            className="px-3 py-1.5 rounded-xl bg-white/90 border border-amber-200/70 flex items-center justify-between gap-2 text-xs"
                          >
                            <span className="font-semibold text-slate-800 truncate">
                              {b.bidderName} <span className="text-slate-400 font-mono">@{b.bidderHandle}</span>
                            </span>
                            <span className="font-mono font-bold text-amber-800 shrink-0">
                              ${b.amountUSD.toLocaleString()} • {b.mode === 'barter' ? 'Barter' : b.currencySymbol || b.mode}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {(() => {
                    const pricing = getListingComprehensivePricing(rawListing);
                    return (
                      <>
                        {/* Total Valuation & Primary Currency */}
                        <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-3 text-center">
                          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8">
                            <div className="text-center">
                              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block">
                                Total Valuation
                              </span>
                              <span className="font-mono text-2xl font-black text-amber-700 mt-0.5 block">
                                ${pricing.valuationUSD.toLocaleString()} USD
                              </span>
                            </div>
                            {pricing.primaryCurrency && (
                              <div className="text-center">
                                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 block">
                                  Primary Settlement Currency
                                </span>
                                <span className="font-mono text-sm font-bold text-slate-900 mt-0.5 block">
                                  {pricing.primaryCurrency}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Final Currencies Involved & Price For Each */}
                        {pricing.finalCurrencies.length > 0 && (
                          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-2.5 text-center">
                            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-900 font-bold flex items-center justify-center gap-1.5">
                              <Coins className="w-3.5 h-3.5 text-amber-700" />
                              <span>Accepted Final Currencies &amp; Price For Each</span>
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {pricing.finalCurrencies.map((fc) => (
                                <div key={fc.symbol} className="p-2.5 rounded-xl bg-white border border-amber-200/70 flex items-center justify-between text-xs font-mono">
                                  <div className="flex items-center gap-2">
                                    <span>{fc.icon}</span>
                                    <span className="font-bold text-slate-900">{fc.symbol}</span>
                                    {fc.isPrimary && <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-600 text-white font-sans font-bold">Primary</span>}
                                  </div>
                                  <div className="text-right">
                                    <span className="font-bold text-amber-900 block">{fc.amountFormatted}</span>
                                    <span className="text-[10px] text-slate-500 block">${fc.usdEquivalent.toLocaleString()} USD</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Regular Currencies Involved & Price For Each */}
                        {pricing.regularCurrencies.length > 0 && (
                          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/85 space-y-2.5 text-center">
                            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-600 font-bold flex items-center justify-center gap-1.5">
                              <Coins className="w-3.5 h-3.5 text-slate-700" />
                              <span>Regular Currencies (Fiat, Stablecoins, Crypto) &amp; Price For Each</span>
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {pricing.regularCurrencies.map((rc) => (
                                <div key={rc.symbol} className="p-2.5 rounded-xl bg-white border border-slate-200/80 flex items-center justify-between text-xs font-mono">
                                  <div className="flex items-center gap-2">
                                    <span>{rc.icon}</span>
                                    <div>
                                      <span className="font-bold text-slate-900 block">{rc.symbol}</span>
                                      <span className="text-[9px] text-slate-500 block">{rc.categoryLabel} • {rc.network}</span>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <span className="font-bold text-slate-900 block">{rc.amountFormatted}</span>
                                    <span className="text-[10px] text-slate-500 block">${rc.usdEquivalent.toLocaleString()} USD</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Barter Terms & Desired Trades */}
                        {pricing.barter.isAccepted && (
                          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-300/80 space-y-2 text-center">
                            <span className="text-[10px] font-mono uppercase tracking-wider text-amber-900 font-bold flex items-center justify-center gap-1.5">
                              <ArrowRightLeft className="w-3.5 h-3.5 text-amber-700" />
                              <span>Barter &amp; Counter-Trade Desired Items</span>
                            </span>
                            <p className="text-xs text-amber-950 leading-relaxed font-medium">
                              {pricing.barter.desiredTrades}
                            </p>
                            <div className="pt-2 border-t border-amber-200/60 flex items-center justify-center gap-3 text-[11px] font-mono text-amber-900">
                              <span>Exchange Type: <strong className="capitalize">{pricing.barter.desiredExchangeType}</strong></span>
                              <span>•</span>
                              <span>Estimated Value: <strong className="font-bold">${pricing.barter.estimatedValueUSD.toLocaleString()} USD</strong></span>
                            </div>
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              )}

              {/* Specifications & Attributes */}
              {attributeEntries.length > 0 && (
                <div className="space-y-2 text-center">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold flex items-center justify-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-slate-600" />
                    <span>Specifications &amp; Verified Details</span>
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-center">
                    {attributeEntries.map(([key, value]) => (
                      <div
                        key={key}
                        className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-center"
                      >
                        <span className="text-[10px] font-mono uppercase text-slate-400 block">
                          {key}
                        </span>
                        <span className="text-xs font-semibold text-slate-900 mt-0.5 block">
                          {String(value)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons Footer */}
            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                type="button"
                disabled={isSettled}
                onClick={() => onOpenBarterModal && onOpenBarterModal({
                  ...rawListing,
                  sellerId,
                  sellerName,
                  sellerHandle: sellerHandleClean,
                  priceUSD: isAuction ? auctionCurrentUSD : priceUSD,
                })}
                className={`flex-1 py-3 px-5 rounded-2xl text-xs font-bold shadow-xs transition-colors flex items-center justify-center gap-2 ${
                  isSettled
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 cursor-default'
                    : 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer'
                }`}
              >
                {isAuction ? <Gavel className="w-4 h-4" /> : <ArrowRightLeft className="w-4 h-4" />}
                <span>
                  {isAuction && isAuctionOwner && !isSettled
                    ? `Manage & Accept Bids (${auctionBids.length})`
                    : getListingTradeActionLabel(rawListing)}
                </span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  const session = getCurrentSession();
                  if (!session || !session.uid) {
                    addToast({
                      type: 'error',
                      title: 'Authentication Required',
                      message: 'Please sign in to contact the seller.',
                    });
                    return;
                  }

                  const targetUid = sellerId.startsWith('user-') ? sellerId : `user-${sellerId.replace(/^@/, '')}`;
                  const targetHandle = sellerHandleClean.replace(/^@/, '');

                  if (
                    !isAdminAccount(session) &&
                    (areUsersBlockedEitherWay(session.uid, targetUid) ||
                      areUsersBlockedEitherWay(session.id, sellerId) ||
                      areUsersBlockedEitherWay(session.id, targetHandle))
                  ) {
                    addToast({
                      type: 'error',
                      title: 'Chat Unavailable',
                      message: 'Cannot contact seller: communication is blocked between these accounts.',
                    });
                    return;
                  }

                  try {
                    const targetProfile = {
                      uid: targetUid,
                      userId: sellerId,
                      name: sellerName,
                      handle: sellerHandleClean,
                      avatarUrl: sellerAvatar,
                      role: 'user' as const,
                    };
                    const conv = await getOrCreateDirectConversation(session, targetProfile);
                    setReturnListingId(rawListing.id);
                    setChatReturnOrigin('listing_detail');
                    if (conv?.id) {
                      window.dispatchEvent(new CustomEvent('open_direct_conversation', { detail: conv.id }));
                    }
                    setCurrentTab('messages');
                  } catch (err: any) {
                    addToast({
                      type: 'error',
                      title: 'Chat Unavailable',
                      message: err?.message || 'Cannot start chat with this seller.',
                    });
                  }
                }}
                className="py-3 px-5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Message {rawListing.listingIntent === 'buy' ? 'Buyer' : 'Seller'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox Modal for Enlarged Photo or Video */}
      {lightboxMedia && (
        <div
          onClick={() => setLightboxMedia(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-4xl w-full bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-2xl flex flex-col max-h-[90vh]"
          >
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <span className="font-bold text-xs text-slate-900 truncate">{lightboxMedia.title || 'Attached Media'}</span>
              <button
                type="button"
                onClick={() => setLightboxMedia(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="bg-slate-950 flex items-center justify-center p-2 flex-1 min-h-[300px]">
              {lightboxMedia.type === 'video' ? (
                <video
                  src={lightboxMedia.url}
                  controls
                  autoPlay
                  playsInline
                  className="max-h-[75vh] w-auto max-w-full object-contain"
                />
              ) : (
                <img
                  src={lightboxMedia.url}
                  alt={lightboxMedia.title || 'Listing Photo'}
                  className="max-h-[75vh] w-auto max-w-full object-contain"
                />
              )}
            </div>
          </div>
        </div>
      )}
      {/* Tweet Composer Modal for Marketplace Listing */}
      <TweetingComposerModal
        isOpen={showTweetModal}
        onClose={() => setShowTweetModal(false)}
        title="Tweet Marketplace Listing"
        subtitle="Add your description, photos, and videos to post this listing on Tweet"
        initialDescription={`Checking out "${rawListing.title}" (${
          isAuction
            ? `Current Bid $${auctionCurrentUSD.toLocaleString()}`
            : `$${priceUSD.toLocaleString()} USD`
        }) on Marketplace! #marketplace ${sellerHandleClean}`.slice(0, TWEETING_MAX_CHARS)}
        placeholder="Write your review or note about this listing..."
        suggestedHashtags={[
          '#marketplace',
          `#${String(rawListing.category || 'FinalMarket').replace(/[^a-zA-Z0-9]/g, '')}`,
          ...allHashtags.slice(0, 3).map((h) => `#${h}`),
        ]}
        existingPhotos={allPhotos.map((p) => p.url)}
        existingVideos={allVideos.map((v) => v.url)}
        existingMediaLabel="Include listing photos & videos"
        currentUser={activeSession}
        previewLabel="Embedded Listing Preview"
        previewCard={
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3 text-left flex items-center gap-3 shadow-2xs">
            {activePhoto?.url && (
              <img
                src={activePhoto.url}
                alt={rawListing.title}
                className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
              />
            )}
            <div className="min-w-0 flex-1 space-y-0.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-mono font-bold uppercase text-emerald-700">
                  {isAuction ? 'Auction' : isService ? 'Service' : 'Marketplace Good'}
                </span>
                <span className="text-xs font-mono font-bold text-slate-900 shrink-0">
                  ${(isAuction ? auctionCurrentUSD : priceUSD).toLocaleString()} USD
                </span>
              </div>
              <p className="font-serif font-bold text-sm text-slate-900 truncate">
                {rawListing.title}
              </p>
              <p className="text-[11px] text-slate-500 truncate">
                {sellerName} ({sellerHandleClean}) · {String(rawListing.category || 'Marketplace').replace(/_/g, ' ')}
              </p>
            </div>
          </div>
        }
        onPost={(payload: TweetingComposerSubmitPayload) => {
          const session = getCurrentSession();
          const authorId = session?.uid || session?.id || 'user_ranma';
          const authorName = session?.name || 'Ranma';
          const authorHandle = (session?.handle || session?.id || 'super_admin_ranma').replace(/^@/, '');
          const authorAvatar =
            session?.avatarUrl ||
            'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80';

          const avg = getAverageRatingForListing(rawListing.id);
          const reviews = getReviewsForListing(rawListing.id);

          const finalContent = (
            payload.content.trim() ||
            `Shared from Marketplace: "${rawListing.title}" ($${(isAuction ? auctionCurrentUSD : priceUSD).toLocaleString()} USD).`
          ).slice(0, TWEETING_MAX_CHARS);

          const newTweet = createTweet({
            authorId,
            authorName,
            authorHandle,
            authorAvatar,
            content: finalContent,
            photos: payload.photos,
            videos: payload.videos,
            extraHashtags: ['marketplace', ...allHashtags.slice(0, 4)],
            sharedPost: {
              listingId: rawListing.id,
              title: rawListing.title,
              description: rawListing.description || '',
              category: String(rawListing.category || 'Marketplace'),
              itemType: isAuction ? 'auction' : isService ? 'service' : 'good',
              statusLabel: isSettled
                ? 'SOLD'
                : isAuction
                ? 'LIVE AUCTION'
                : 'LIVE',
              sellerHandle: sellerHandleClean.replace(/^@/, ''),
              sellerName,
              priceUSD: isAuction ? auctionCurrentUSD : priceUSD,
              imageUrl: activePhoto?.url || rawListing.imageUrl,
              averageRating:
                avg.count > 0
                  ? avg.average
                  : sellerRating.count > 0
                  ? sellerRating.average
                  : undefined,
              ratingCount: avg.count > 0 ? avg.count : sellerRating.count,
              comments: reviews.map((r) => ({
                reviewerName: r.reviewerName,
                reviewerAvatar: r.reviewerAvatar,
                rating: r.rating,
                comment: r.comment,
                timestamp: r.updatedAt || r.timestamp,
              })),
            },
          });

          addToast({
            type: 'success',
            title: 'Posted to Tweet',
            message: `"${rawListing.title}" was published to the Tweet feed.`,
          });
          window.dispatchEvent(
            new CustomEvent('open_tweeting_feed', { detail: { tweetId: newTweet.id } })
          );
        }}
      />
    </div>
  );
};
