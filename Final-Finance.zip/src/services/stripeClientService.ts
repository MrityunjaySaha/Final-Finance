import { loadStripe, Stripe } from '@stripe/stripe-js';
import { AuthSession } from '../types/auth';

export interface StripeConfigResponse {
  configured: boolean;
  webhookConfigured: boolean;
  membershipPriceConfigured: boolean;
  publishableKey: string | null;
}

export interface StripeSavedPaymentMethod {
  id: string;
  type: 'card' | 'us_bank_account';
  isDefault: boolean;
  created: number;
  brand?: string;
  last4: string;
  expMonth?: number;
  expYear?: number;
  funding?: string;
  cardholderName?: string;
  bankName?: string;
  accountType?: string;
  routingNumber?: string;
  status?: string;
}

export interface MarketMembershipStatus {
  configured: boolean;
  priceIdConfigured: boolean;
  priceId: string | null;
  customerId: string;
  hasSubscription: boolean;
  subscriptionId: string | null;
  status: string;
  cancelAtPeriodEnd: boolean;
  currentPeriodEnd: string | null;
  planName: string;
  monthlyAmountUSD: number;
  defaultPaymentMethod: StripeSavedPaymentMethod | null;
}

// Held strictly in JS memory (never localStorage / sessionStorage)
const memorySessionCache = new Map<
  string,
  { sessionToken: string; customerId: string; publishableKey: string | null; expiresAt: number }
>();

let cachedStripePromise: Promise<Stripe | null> | null = null;
let cachedPublishableKey: string | null = null;

export function getStripePromise(publishableKey: string | null): Promise<Stripe | null> | null {
  if (!publishableKey) return null;
  if (!cachedStripePromise || cachedPublishableKey !== publishableKey) {
    cachedPublishableKey = publishableKey;
    cachedStripePromise = loadStripe(publishableKey);
  }
  return cachedStripePromise;
}

async function parseApiJson<T = any>(res: Response, fallbackError: string): Promise<T> {
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  const rawText = await res.text();
  const trimmed = rawText.trim();

  if (!trimmed) {
    if (!res.ok) {
      throw new Error(`${fallbackError} (HTTP ${res.status})`);
    }
    return {} as T;
  }

  if (
    trimmed.startsWith('<') ||
    trimmed.toLowerCase().startsWith('<!doctype') ||
    (!contentType.includes('application/json') && /<html[\s>]/i.test(trimmed))
  ) {
    if (res.redirected && res.url.includes('__cookie_check')) {
      throw new Error(
        'Preview session verification interrupted the Stripe API request (received HTML redirect). Please reload the app and try again.'
      );
    }
    throw new Error(
      `Unable to reach the Stripe payment server (received HTML instead of JSON, HTTP ${res.status}). Please ensure the backend server is running and try again.`
    );
  }

  try {
    return JSON.parse(trimmed) as T;
  } catch {
    throw new Error(`${fallbackError} (invalid JSON response from server)`);
  }
}

export function openExternalStripeUrl(rawUrl: string): {
  safeUrl: string;
  needsManualTabLink: boolean;
} {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error('Stripe returned an invalid redirect URL.');
  }

  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    throw new Error('Blocked unsafe redirect URL protocol.');
  }

  const safeUrl = parsed.toString();
  if (typeof window === 'undefined') {
    return { safeUrl, needsManualTabLink: false };
  }

  const inIframe = (() => {
    try {
      return window.top !== window.self;
    } catch {
      return true;
    }
  })();

  if (!inIframe) {
    window.location.href = safeUrl;
    return { safeUrl, needsManualTabLink: false };
  }

  // Inside an iframe (such as AI Studio preview), navigating window.location.href
  // to checkout.stripe.com / billing.stripe.com results in a blank white page due to
  // X-Frame-Options: DENY. Open in a new tab via an anchor element and expose a fallback link.
  try {
    const anchor = document.createElement('a');
    anchor.href = safeUrl;
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
  } catch {
    // Fallback link remains visible in UI
  }

  return { safeUrl, needsManualTabLink: true };
}

async function clearStaleServiceWorkers(): Promise<void> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
  try {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.map((reg) => reg.unregister().catch(() => false)));
  } catch {
    // ignore
  }
}

async function fetchStripeResponse(url: string, init?: RequestInit): Promise<Response> {
  const attempt = () =>
    fetch(url, {
      ...init,
      cache: 'no-store',
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        ...(init?.headers || {}),
      },
    });

  let res = await attempt();
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  if (!contentType.includes('application/json') && res.status === 200) {
    await clearStaleServiceWorkers();
    await new Promise((r) => setTimeout(r, 400));
    res = await attempt();
  }
  return res;
}

function getEnvPublishableKeyFallback(): string | null {
  try {
    const raw = (import.meta as any)?.env?.VITE_STRIPE_PUBLISHABLE_KEY;
    if (typeof raw === 'string' && /^pk_(test|live)_/.test(raw.trim())) {
      return raw.trim();
    }
  } catch {
    // ignore
  }
  return null;
}

export async function getStripeConfig(): Promise<StripeConfigResponse> {
  const res = await fetchStripeResponse('/api/stripe/config');
  const json = await parseApiJson<{
    success?: boolean;
    error?: string;
    configured?: boolean;
    webhookConfigured?: boolean;
    membershipPriceConfigured?: boolean;
    publishableKey?: string | null;
  }>(res, 'Failed to load Stripe configuration');
  if (!res.ok || !json.success) {
    throw new Error(json.error || 'Failed to load Stripe configuration');
  }
  return {
    configured: Boolean(json.configured),
    webhookConfigured: Boolean(json.webhookConfigured),
    membershipPriceConfigured: Boolean(json.membershipPriceConfigured),
    publishableKey: json.publishableKey || getEnvPublishableKeyFallback(),
  };
}

export async function getStripeConfigSafe(): Promise<StripeConfigResponse & { reachable: boolean }> {
  try {
    const cfg = await getStripeConfig();
    return { ...cfg, reachable: true };
  } catch {
    return {
      reachable: false,
      configured: false,
      webhookConfigured: false,
      membershipPriceConfigured: false,
      publishableKey: getEnvPublishableKeyFallback(),
    };
  }
}

export async function ensureStripeSession(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>
): Promise<{ sessionToken: string; customerId: string; publishableKey: string | null }> {
  const userId = (user.uid || user.id || 'guest').trim();
  const existing = memorySessionCache.get(userId);
  if (existing && existing.expiresAt > Date.now() + 60_000) {
    return existing;
  }

  const res = await fetchStripeResponse('/api/stripe/session', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      userId,
      email: user.email,
      name: user.name,
    }),
  });
  const json = await parseApiJson<{
    success?: boolean;
    error?: string;
    data?: {
      sessionToken: string;
      customerId: string;
      publishableKey?: string | null;
    };
  }>(res, 'Unable to establish Stripe customer session');
  if (!res.ok || !json.success || !json.data) {
    throw new Error(json.error || 'Unable to establish Stripe customer session');
  }

  const entry = {
    sessionToken: json.data.sessionToken,
    customerId: json.data.customerId,
    publishableKey: json.data.publishableKey || null,
    expiresAt: Date.now() + 10 * 60 * 60 * 1000,
  };
  memorySessionCache.set(userId, entry);
  return entry;
}

async function authorizedStripeFetch<T>(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  url: string,
  init?: RequestInit
): Promise<T> {
  const session = await ensureStripeSession(user);
  const res = await fetchStripeResponse(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers || {}),
      Authorization: `Bearer ${session.sessionToken}`,
    },
  });
  const json = await parseApiJson<{ success?: boolean; error?: string; data?: T }>(
    res,
    'Stripe request failed'
  );
  if (res.status === 401) {
    const userId = (user.uid || user.id || 'guest').trim();
    memorySessionCache.delete(userId);
    const refreshed = await ensureStripeSession(user);
    const retryRes = await fetchStripeResponse(url, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init?.headers || {}),
        Authorization: `Bearer ${refreshed.sessionToken}`,
      },
    });
    const retryJson = await parseApiJson<{ success?: boolean; error?: string; data?: T }>(
      retryRes,
      'Stripe request failed'
    );
    if (!retryRes.ok || !retryJson.success) {
      throw new Error(retryJson.error || 'Stripe request failed');
    }
    return retryJson.data as T;
  }
  if (!res.ok || !json.success) {
    throw new Error(json.error || 'Stripe request failed');
  }
  return json.data as T;
}

export async function fetchSavedPaymentMethods(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>
): Promise<{ customerId: string; defaultPaymentMethodId: string | null; paymentMethods: StripeSavedPaymentMethod[] }> {
  return authorizedStripeFetch(user, '/api/stripe/payment-methods');
}

export async function linkBankAccountViaStripe(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  params: {
    bankName: string;
    accountHolderName: string;
    accountType: 'checking' | 'savings';
    routingNumber: string;
    accountNumber: string;
  }
): Promise<{
  customerId: string;
  defaultPaymentMethodId: string | null;
  paymentMethods: StripeSavedPaymentMethod[];
  pendingVerification?: boolean;
  setupIntentId?: string;
  paymentMethodId?: string;
  arrivalDate?: string | null;
}> {
  return authorizedStripeFetch(user, '/api/stripe/bank-accounts/link', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function verifyStripeBankMicrodeposits(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  params: {
    setupIntentId: string;
    amounts?: [number, number];
    descriptorCode?: string;
  }
): Promise<{ customerId: string; defaultPaymentMethodId: string | null; paymentMethods: StripeSavedPaymentMethod[] }> {
  return authorizedStripeFetch(user, '/api/stripe/bank-accounts/verify-microdeposits', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function createStripeSetupIntent(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  preference: 'card' | 'us_bank_account' | 'both' = 'card'
): Promise<{ setupIntentId: string; clientSecret: string; paymentMethodTypes: string[] }> {
  return authorizedStripeFetch(user, '/api/stripe/setup-intent', {
    method: 'POST',
    body: JSON.stringify({ preference }),
  });
}

export async function verifyStripeSetupIntentCard(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  setupIntentId: string
): Promise<{ customerId: string; defaultPaymentMethodId: string | null; paymentMethods: StripeSavedPaymentMethod[] }> {
  return authorizedStripeFetch(user, '/api/stripe/setup-intent/verify', {
    method: 'POST',
    body: JSON.stringify({ setupIntentId }),
  });
}

export async function createStripeSetupCheckout(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  preference: 'card' | 'us_bank_account' | 'both' = 'card'
): Promise<{ id: string; url: string | null }> {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  return authorizedStripeFetch(user, '/api/stripe/setup-checkout-session', {
    method: 'POST',
    body: JSON.stringify({
      preference,
      successUrl: `${origin}/?stripe_setup=success&tab=payment_methods`,
      cancelUrl: `${origin}/?stripe_setup=cancelled&tab=payment_methods`,
    }),
  });
}

export async function setDefaultStripePaymentMethod(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  paymentMethodId: string
): Promise<{ customerId: string; defaultPaymentMethodId: string | null; paymentMethods: StripeSavedPaymentMethod[] }> {
  return authorizedStripeFetch(user, '/api/stripe/payment-methods/default', {
    method: 'POST',
    body: JSON.stringify({ paymentMethodId }),
  });
}

export async function removeStripePaymentMethod(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  paymentMethodId: string
): Promise<{ customerId: string; defaultPaymentMethodId: string | null; paymentMethods: StripeSavedPaymentMethod[] }> {
  return authorizedStripeFetch(user, `/api/stripe/payment-methods/${encodeURIComponent(paymentMethodId)}`, {
    method: 'DELETE',
  });
}

export interface StripeChargeResult {
  paymentIntentId: string;
  status: string;
  requiresAction: boolean;
  clientSecret: string | null;
  amountUSD: number;
  baseAmountUSD?: number;
  feeUSD?: number;
  amountCents: number;
  paymentMethodId: string;
  paymentMethodType: 'card' | 'us_bank_account';
  sourceLabel: string;
}

export async function executeStripeCharge(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  params: {
    paymentMethodId: string;
    amountUSD: number;
    baseAmountUSD?: number;
    feeUSD?: number;
    description?: string;
    purpose: 'deposit' | 'debt_payment' | 'purchase';
    targetAssetClass?: string;
    targetCurrencyCode?: string;
  }
): Promise<StripeChargeResult> {
  return authorizedStripeFetch(user, '/api/stripe/charges/execute', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function fetchMarketMembershipStatus(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>
): Promise<MarketMembershipStatus> {
  return authorizedStripeFetch(user, '/api/stripe/membership/status');
}

export async function subscribeMarketMembershipWithSavedMethod(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  paymentMethodId?: string
): Promise<{ membership: MarketMembershipStatus; requiresAction: boolean; clientSecret?: string | null }> {
  return authorizedStripeFetch(user, '/api/stripe/membership/subscribe', {
    method: 'POST',
    body: JSON.stringify({ paymentMethodId }),
  });
}

export async function createMarketMembershipCheckout(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>
): Promise<{ id: string; url: string | null }> {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  return authorizedStripeFetch(user, '/api/stripe/membership/checkout-session', {
    method: 'POST',
    body: JSON.stringify({
      successUrl: `${origin}/?stripe_membership=success&tab=verification`,
      cancelUrl: `${origin}/?stripe_membership=cancelled&tab=verification`,
    }),
  });
}

export async function cancelMarketMembership(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  subscriptionId: string
): Promise<MarketMembershipStatus> {
  return authorizedStripeFetch(user, '/api/stripe/membership/cancel', {
    method: 'POST',
    body: JSON.stringify({ subscriptionId }),
  });
}

export async function resumeMarketMembership(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>,
  subscriptionId: string
): Promise<MarketMembershipStatus> {
  return authorizedStripeFetch(user, '/api/stripe/membership/resume', {
    method: 'POST',
    body: JSON.stringify({ subscriptionId }),
  });
}

export async function openMarketMembershipPortal(
  user: Pick<AuthSession, 'id' | 'uid' | 'email' | 'name'>
): Promise<{ id: string; url: string }> {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  return authorizedStripeFetch(user, '/api/stripe/membership/portal', {
    method: 'POST',
    body: JSON.stringify({
      returnUrl: `${origin}/?tab=verification`,
    }),
  });
}

const LOCAL_METHODS_STORAGE_PREFIX = 'ff_saved_payment_methods_';

export function getSavedLocalPaymentMethods(userId: string): StripeSavedPaymentMethod[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(`${LOCAL_METHODS_STORAGE_PREFIX}${userId || 'guest'}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeSavedLocalPaymentMethods(userId: string, list: StripeSavedPaymentMethod[]): StripeSavedPaymentMethod[] {
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.setItem(`${LOCAL_METHODS_STORAGE_PREFIX}${userId || 'guest'}`, JSON.stringify(list));
    } catch {
      // ignore storage quota errors
    }
  }
  return list;
}

export function addSavedLocalPaymentMethod(
  userId: string,
  method: Omit<StripeSavedPaymentMethod, 'isDefault' | 'created'>
): StripeSavedPaymentMethod[] {
  const existing = getSavedLocalPaymentMethods(userId);
  const hasDefaultOfSameType = existing.some((m) => m.type === method.type && m.isDefault);
  const newItem: StripeSavedPaymentMethod = {
    ...method,
    isDefault: !hasDefaultOfSameType,
    created: Math.floor(Date.now() / 1000),
  };
  return writeSavedLocalPaymentMethods(userId, [newItem, ...existing]);
}

export function setDefaultLocalPaymentMethod(
  userId: string,
  paymentMethodId: string,
  type: 'card' | 'us_bank_account'
): StripeSavedPaymentMethod[] {
  const existing = getSavedLocalPaymentMethods(userId);
  const next = existing.map((m) =>
    m.type === type ? { ...m, isDefault: m.id === paymentMethodId } : m
  );
  return writeSavedLocalPaymentMethods(userId, next);
}

export function removeLocalPaymentMethod(
  userId: string,
  paymentMethodId: string
): StripeSavedPaymentMethod[] {
  const existing = getSavedLocalPaymentMethods(userId);
  const removed = existing.find((m) => m.id === paymentMethodId);
  let next = existing.filter((m) => m.id !== paymentMethodId);
  if (removed?.isDefault) {
    const firstSameTypeIndex = next.findIndex((m) => m.type === removed.type);
    if (firstSameTypeIndex >= 0) {
      next = next.map((m, idx) =>
        idx === firstSameTypeIndex ? { ...m, isDefault: true } : m
      );
    }
  }
  return writeSavedLocalPaymentMethods(userId, next);
}

