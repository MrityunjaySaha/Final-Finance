import { MarketplaceListing } from '../types/marketplace';
import { getAllMarketplaceListings, getAuctionBids } from './marketplaceService';
import { getIdentityAliases } from './socialService';
import { getStoredLedgerTransactions } from '../utils/universalLedgerBridge';

export interface PostReview {
  id: string;
  listingId: string;
  listingTitle: string;
  sellerId: string;         // User who created the post
  sellerHandle?: string;
  reviewerId: string;       // User who transacted and is reviewing
  reviewerUid?: string;
  reviewerName: string;
  reviewerAvatar?: string;
  rating: number;           // 1 to 5
  comment: string;
  timestamp: number;
  updatedAt?: number;
}

export const POST_RATINGS_STORAGE_KEY = 'ff_post_ratings_v1';
export const POST_RATINGS_UPDATED_EVENT = 'final_finance_post_ratings_updated';
export const TRANSACTED_POSTINGS_STORAGE_KEY = 'ff_transacted_postings_v1';

function normKey(s?: string): string {
  if (!s) return '';
  return s.trim().toLowerCase().replace(/^@/, '').replace(/^user-/, '').split('@')[0].replace(/[_\-\s]/g, '');
}

const SEED_POST_REVIEWS: PostReview[] = [
  {
    id: 'pr-seed-1',
    listingId: 'mkt-sample-uploaded',
    listingTitle: 'Quantum Cryptographic Security & Zero-Day Audit',
    sellerId: 'satoshi',
    sellerHandle: 'satoshi',
    reviewerId: 'awesomedbz',
    reviewerName: 'Awesome DBZ Trader',
    reviewerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'Flawless lattice cryptography assessment. The formal verification model discovered two edge-case vectors. Outstanding sovereign standard service.',
    timestamp: Date.now() - 1000 * 60 * 60 * 48,
  },
  {
    id: 'pr-seed-2',
    listingId: 'mkt-sample-sold',
    listingTitle: 'Allocated 100oz 24K Gold Bullion Ingot (LBMA Certified)',
    sellerId: 'alex_morgan',
    sellerHandle: 'alex_morgan',
    reviewerId: 'ranma',
    reviewerName: 'Ranma Sovereign Admin',
    reviewerAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'Pristine LBMA gold bar vault transfer verified in Zurich Freeport cell. Custody certificate issued promptly.',
    timestamp: Date.now() - 1000 * 60 * 60 * 96,
  },
  {
    id: 'pr-seed-3',
    listingId: 'mkt-drone-4',
    listingTitle: 'Sovereign Autonomous AI Drone Rig (MK-IV)',
    sellerId: 'vance_capital',
    sellerHandle: 'vance_capital',
    reviewerId: 'elena',
    reviewerName: 'Elena Rostova',
    reviewerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    rating: 4,
    comment: 'Thermal imaging telemetry and autonomous waypoint navigation exceed expectations. Battery modules arrived fully charged.',
    timestamp: Date.now() - 1000 * 60 * 60 * 120,
  },
  {
    id: 'pr-seed-4',
    listingId: 'mkt-patek-5711',
    listingTitle: 'Patek Philippe Nautilus Ref. 5711/1R Rose Gold (Mint Box & Papers)',
    sellerId: 'elena',
    sellerHandle: 'elena',
    reviewerId: 'satoshi',
    reviewerName: 'Satoshi Nakamoto',
    reviewerAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'Horological perfection. Escrow settlement via AFNL native currency was completed in milliseconds.',
    timestamp: Date.now() - 1000 * 60 * 60 * 180,
  },
  {
    id: 'pr-seed-5',
    listingId: 'mkt-h100-cluster',
    listingTitle: 'Enterprise 8x NVIDIA H100 SXM5 80GB GPU Clustered Server Rig',
    sellerId: 'jordan_belfort',
    sellerHandle: 'jordan_belfort',
    reviewerId: 'ranma',
    reviewerName: 'Ranma Sovereign Admin',
    reviewerAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=200&q=80',
    rating: 5,
    comment: 'Delivered directly to Northern Virginia datacenter. High-performance compute benchmarks exceeded contract specifications.',
    timestamp: Date.now() - 1000 * 60 * 60 * 240,
  },
  {
    id: 'pr-seed-6',
    listingId: 'mkt-alexchen-done-fpga',
    listingTitle: 'Custom FPGA Cryptographic Acceleration Chassis',
    sellerId: 'alex_chen',
    sellerHandle: 'alex_chen',
    reviewerId: 'satoshi',
    reviewerName: 'Satoshi Nakamoto',
    reviewerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    rating: 5,
    comment: 'Sub-millisecond ZK proof throughput verified on bench tests. Seamless escrow handoff.',
    timestamp: Date.now() - 1000 * 60 * 60 * 160,
  }
];

export function getStoredPostReviews(): PostReview[] {
  try {
    const raw = localStorage.getItem(POST_RATINGS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(POST_RATINGS_STORAGE_KEY, JSON.stringify(SEED_POST_REVIEWS));
      localStorage.setItem('ff_post_ratings_seed_v2', '1');
      return SEED_POST_REVIEWS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      if (!localStorage.getItem('ff_post_ratings_seed_v2')) {
        const existingIds = new Set(parsed.map((r: PostReview) => r.id));
        const missingSeeds = SEED_POST_REVIEWS.filter((s) => !existingIds.has(s.id));
        const merged = missingSeeds.length > 0 ? [...parsed, ...missingSeeds] : parsed;
        if (missingSeeds.length > 0) {
          localStorage.setItem(POST_RATINGS_STORAGE_KEY, JSON.stringify(merged));
        }
        localStorage.setItem('ff_post_ratings_seed_v2', '1');
        return merged;
      }
      return parsed;
    }
    return SEED_POST_REVIEWS;
  } catch (err) {
    console.error('Failed loading post reviews from storage:', err);
    return SEED_POST_REVIEWS;
  }
}

export function saveStoredPostReviews(reviews: PostReview[]): void {
  try {
    localStorage.setItem(POST_RATINGS_STORAGE_KEY, JSON.stringify(reviews));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(POST_RATINGS_UPDATED_EVENT, { detail: reviews }));
    }
  } catch (err) {
    console.error('Failed saving post reviews to storage:', err);
  }
}

export function getReviewsForListing(listingId: string): PostReview[] {
  if (!listingId) return [];
  const all = getStoredPostReviews();
  const cleanId = listingId.trim().toLowerCase();
  return all
    .filter((r) => r.listingId.trim().toLowerCase() === cleanId)
    .sort((a, b) => (b.updatedAt || b.timestamp) - (a.updatedAt || a.timestamp));
}

export function getAverageRatingForListing(listingId: string): { average: number; count: number } {
  const reviews = getReviewsForListing(listingId);
  if (reviews.length === 0) return { average: 0, count: 0 };
  const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
  return {
    average: parseFloat((sum / reviews.length).toFixed(1)),
    count: reviews.length,
  };
}

export interface PostRatingEligibility {
  canRate: boolean;
  reason?:
    | 'not_signed_in'
    | 'own_listing'
    | 'not_finalized'
    | 'already_rated'
    | 'not_winner'
    | 'not_purchaser';
  existingReview?: PostReview | null;
}

function buildAliasNormSet(idOrHandle?: string, extraId?: string): Set<string> {
  const set = new Set<string>();
  const addId = (val?: string) => {
    if (!val) return;
    const n = normKey(val);
    if (n) set.add(n);
    getIdentityAliases(val).forEach((alias) => {
      const an = normKey(alias);
      if (an) set.add(an);
    });
  };
  addId(idOrHandle);
  addId(extraId);
  return set;
}

export function isUserListingOwner(
  listing: Pick<MarketplaceListing, 'userId' | 'sellerId' | 'creatorHandle' | 'sellerHandle'>,
  userId?: string,
  userUid?: string
): boolean {
  if (!userId && !userUid) return false;
  const userNorms = buildAliasNormSet(userId, userUid);
  if (userNorms.size === 0) return false;
  const ownerCandidates = [
    listing.userId,
    listing.sellerId,
    listing.creatorHandle,
    listing.sellerHandle,
  ].filter(Boolean) as string[];
  return ownerCandidates.some((c) => {
    const cNorm = normKey(c);
    if (cNorm && userNorms.has(cNorm)) return true;
    return getIdentityAliases(c).some((alias) => {
      const aNorm = normKey(alias);
      return Boolean(aNorm && userNorms.has(aNorm));
    });
  });
}

export function getUserReviewForListing(
  listingId: string,
  reviewerId: string,
  reviewerUid?: string
): PostReview | null {
  const reviews = getReviewsForListing(listingId);
  const reviewerNorms = buildAliasNormSet(reviewerId, reviewerUid);
  if (reviewerNorms.size === 0) return null;
  return (
    reviews.find((r) => {
      const rKey = normKey(r.reviewerId);
      const rUid = normKey(r.reviewerUid);
      return (rKey && reviewerNorms.has(rKey)) || (rUid && reviewerNorms.has(rUid));
    }) || null
  );
}

export function canUserRateListing(
  listing: MarketplaceListing,
  userId?: string,
  userUid?: string
): PostRatingEligibility {
  if (!userId && !userUid) {
    return { canRate: false, reason: 'not_signed_in' };
  }

  // 1. Users can NEVER rate or comment on their own listings
  if (isUserListingOwner(listing, userId, userUid)) {
    return { canRate: false, reason: 'own_listing' };
  }

  // 2. Finalized listing ratings are strictly ONE-TIME only (cannot update/resubmit)
  const existingReview = getUserReviewForListing(listing.id, userId || userUid || '', userUid);
  if (existingReview) {
    return { canRate: false, reason: 'already_rated', existingReview };
  }

  // 3. Listing must be finalized / sold / settled / ended
  const isFinalized =
    listing.status === 'sold' ||
    listing.auctionConfig?.status === 'settled' ||
    listing.auctionConfig?.status === 'ended';
  if (!isFinalized) {
    return { canRate: false, reason: 'not_finalized' };
  }

  const userNorms = buildAliasNormSet(userId, userUid);
  const matchesUser = (val?: string): boolean => {
    if (!val) return false;
    const n = normKey(val);
    if (n && userNorms.has(n)) return true;
    return getIdentityAliases(val).some((alias) => {
      const an = normKey(alias);
      return Boolean(an && userNorms.has(an));
    });
  };

  const hasLedgerPurchaseMatch = () => {
    if (listing.id.startsWith('ledger-bought-')) return true;
    const cleanTitle = (listing.title || '').trim().toLowerCase();
    if (!cleanTitle) return false;
    const ledgerIds = Array.from(new Set([userId, userUid].filter(Boolean) as string[]));
    for (const lid of ledgerIds) {
      const ledger = getStoredLedgerTransactions(lid);
      if (
        ledger.some(
          (tx) =>
            (tx.type === 'product_purchase' || tx.type === 'service_payment' || tx.type === 'barter_swap') &&
            (tx.title || '').trim().toLowerCase() === cleanTitle
        )
      ) {
        return true;
      }
    }
    return false;
  };

  const isSeedBoughtByCurrentUser = BASE_OTHER_TRANSACTED_LISTINGS.some((b) => b.id === listing.id);
  const existingThirdPartyReviews = getReviewsForListing(listing.id);

  // 4. For auctions: ONLY the person who WON the auction gets to rate & comment
  if (listing.listingIntent === 'auction') {
    const bids = getAuctionBids(listing.id);
    const winningBid =
      bids.find((b) => b.status === 'won' || b.status === 'accepted') ||
      (listing.auctionConfig?.winningBidId
        ? bids.find((b) => b.id === listing.auctionConfig?.winningBidId)
        : undefined);

    const explicitWinnerCandidates = [
      listing.buyerId,
      listing.buyerUid,
      listing.buyerHandle,
      listing.auctionConfig?.highestBidderId,
      listing.auctionConfig?.highestBidderUid,
      listing.auctionConfig?.highestBidderHandle,
      winningBid?.bidderId,
      winningBid?.bidderUid,
      winningBid?.bidderHandle,
    ].filter(Boolean) as string[];

    if (explicitWinnerCandidates.length > 0) {
      return explicitWinnerCandidates.some(matchesUser)
        ? { canRate: true }
        : { canRate: false, reason: 'not_winner' };
    }

    if (bids.length > 0) {
      const topBid = bids[0];
      const topMatches = [topBid.bidderId, topBid.bidderUid, topBid.bidderHandle].some(matchesUser);
      return topMatches ? { canRate: true } : { canRate: false, reason: 'not_winner' };
    }

    if (existingThirdPartyReviews.length > 0) {
      return { canRate: false, reason: 'not_winner' };
    }

    if (isSeedBoughtByCurrentUser || hasLedgerPurchaseMatch()) {
      return { canRate: true };
    }

    return { canRate: false, reason: 'not_winner' };
  }

  // 5. For non-auction goods & services: ONLY the final purchaser gets to rate & comment
  const explicitBuyerCandidates = [
    listing.buyerId,
    listing.buyerUid,
    listing.buyerHandle,
  ].filter(Boolean) as string[];

  if (explicitBuyerCandidates.length > 0) {
    return explicitBuyerCandidates.some(matchesUser)
      ? { canRate: true }
      : { canRate: false, reason: 'not_purchaser' };
  }

  if (existingThirdPartyReviews.length > 0) {
    return { canRate: false, reason: 'not_purchaser' };
  }

  if (isSeedBoughtByCurrentUser || hasLedgerPurchaseMatch()) {
    return { canRate: true };
  }

  return { canRate: false, reason: 'not_purchaser' };
}

export function savePostReview(params: {
  listing?: MarketplaceListing;
  listingId: string;
  listingTitle: string;
  sellerId: string;
  sellerHandle?: string;
  reviewerId: string;
  reviewerUid?: string;
  reviewerName: string;
  reviewerAvatar?: string;
  rating: number;
  comment: string;
}): { review: PostReview | null; isUpdate: boolean; rejectedReason?: PostRatingEligibility['reason'] } {
  const all = getStoredPostReviews();
  const cleanListingId = params.listingId.trim().toLowerCase();
  const reviewerNorms = buildAliasNormSet(params.reviewerId, params.reviewerUid);
  const sellerNorms = buildAliasNormSet(params.sellerId, params.sellerHandle);
  const now = Date.now();

  // Strictly block self-rating
  if (
    Array.from(reviewerNorms).some((rn) => sellerNorms.has(rn))
  ) {
    return { review: null, isUpdate: false, rejectedReason: 'own_listing' };
  }

  // Strictly one rating & comment per finalized listing — block updates once submitted
  const existingIndex = all.findIndex((r) => {
    if (r.listingId.trim().toLowerCase() !== cleanListingId) return false;
    const rKey = normKey(r.reviewerId);
    const rUid = normKey(r.reviewerUid);
    return (rKey && reviewerNorms.has(rKey)) || (rUid && reviewerNorms.has(rUid));
  });

  if (existingIndex >= 0) {
    return { review: all[existingIndex], isUpdate: false, rejectedReason: 'already_rated' };
  }

  const resolvedListing =
    params.listing ||
    getAllMarketplaceListings().find((l) => l.id.trim().toLowerCase() === cleanListingId) ||
    BASE_OTHER_TRANSACTED_LISTINGS.find((l) => l.id.trim().toLowerCase() === cleanListingId);

  if (resolvedListing) {
    const eligibility = canUserRateListing(resolvedListing, params.reviewerId, params.reviewerUid);
    if (!eligibility.canRate) {
      return {
        review: eligibility.existingReview || null,
        isUpdate: false,
        rejectedReason: eligibility.reason || 'not_purchaser',
      };
    }
  }

  const newReview: PostReview = {
    id: `pr-${now}-${Math.random().toString(36).substring(2, 7)}`,
    listingId: params.listingId,
    listingTitle: params.listingTitle,
    sellerId: params.sellerId,
    sellerHandle: params.sellerHandle,
    reviewerId: params.reviewerId,
    reviewerUid: params.reviewerUid,
    reviewerName: params.reviewerName,
    reviewerAvatar: params.reviewerAvatar,
    rating: params.rating,
    comment: params.comment.trim(),
    timestamp: now,
  };

  all.unshift(newReview);
  saveStoredPostReviews(all);
  return { review: newReview, isUpdate: false };
}

export function getPostReviewsForSeller(sellerIdOrHandle: string): PostReview[] {
  if (!sellerIdOrHandle) return [];
  const all = getStoredPostReviews();
  const aliasNorms = buildAliasNormSet(sellerIdOrHandle);

  // Also collect all marketplace listing IDs owned by this seller (across aliases)
  const ownedListingIds = new Set<string>();
  const allListings = getAllMarketplaceListings();
  allListings.forEach((l) => {
    if (l.status === 'draft') return;
    const candidates = [l.userId, l.sellerId, l.creatorHandle, l.sellerHandle].filter(Boolean) as string[];
    const matchesOwner = candidates.some((c) => {
      const n = normKey(c);
      return Boolean(n && aliasNorms.has(n));
    });
    if (matchesOwner) {
      ownedListingIds.add(l.id.trim().toLowerCase());
    }
  });

  const matched = new Map<string, PostReview>();
  all.forEach((r) => {
    const matchesSeller =
      aliasNorms.has(normKey(r.sellerId)) || aliasNorms.has(normKey(r.sellerHandle));
    const matchesOwnedListing = ownedListingIds.has(r.listingId.trim().toLowerCase());
    if (matchesSeller || matchesOwnedListing) {
      matched.set(r.id, r);
    }
  });

  return Array.from(matched.values()).sort(
    (a, b) => (b.updatedAt || b.timestamp) - (a.updatedAt || a.timestamp)
  );
}

export function getSellerPostsAverageRating(sellerIdOrHandle: string): { average: number; count: number } {
  const reviews = getPostReviewsForSeller(sellerIdOrHandle);
  if (reviews.length === 0) return { average: 0, count: 0 };
  const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
  return {
    average: parseFloat((sum / reviews.length).toFixed(1)),
    count: reviews.length,
  };
}

/**
 * Seed postings created by OTHERS that are transacted/accepted by the current user
 * (strictly excluding user's own listings).
 */
const BASE_OTHER_TRANSACTED_LISTINGS: MarketplaceListing[] = [
  {
    id: 'mkt-transacted-elena-gold',
    userId: 'demo-elena',
    sellerId: 'elena',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena',
    sellerHandle: '@elena',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    title: 'Certified 50oz Swiss Vault Gold Ingot Allocation',
    category: 'Precious Metals & Bullion',
    description: 'Physical allocated LBMA 99.99% gold bar transacted and transferred to Zurich Freeport reserve custody.',
    priceUSD: 130000,
    primaryPriceUSD: 130000,
    primaryTradeMode: 'currency',
    status: 'sold',
    listingIntent: 'sell',
    itemType: 'good',
    visibility: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80',
    primaryCurrency: 'AFNL',
    acceptedSettlements: ['final_coins', 'stable_coins', 'barter'],
    tags: ['Gold', 'Bullion', 'LBMA', 'Transacted'],
    views: 890,
    likes: 42,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
  },
  {
    id: 'mkt-transacted-satoshi-audit',
    userId: 'demo-satoshi',
    sellerId: 'satoshi',
    creatorName: 'Satoshi Nakamoto',
    creatorHandle: 'satoshi',
    sellerHandle: '@satoshi',
    creatorAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=200&q=80',
    title: 'Zero-Knowledge Lattice Cryptography Circuit Audit',
    category: 'Cybersecurity & Auditing',
    description: 'Comprehensive symbolic execution & zero-knowledge circuit audit. Formal verification report issued and counter-signed.',
    priceUSD: 25000,
    primaryPriceUSD: 25000,
    primaryTradeMode: 'currency',
    status: 'sold',
    listingIntent: 'sell',
    itemType: 'service',
    visibility: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
    primaryCurrency: 'AFNL',
    acceptedSettlements: ['final_coins', 'stable_coins'],
    tags: ['Security', 'Zero-Knowledge', 'Audit', 'Transacted'],
    views: 640,
    likes: 38,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 96).toISOString(),
  },
  {
    id: 'mkt-transacted-vance-drone',
    userId: 'demo-marcus',
    sellerId: 'vance_capital',
    creatorName: 'Marcus Vance',
    creatorHandle: 'vance_capital',
    sellerHandle: '@vance_capital',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    title: 'Sovereign Autonomous AI Drone Rig (MK-IV)',
    category: 'Hardware & Compute',
    description: 'Equipped with thermal imaging lidar, encrypted frequency hopper telemetry, and carbon-fiber rotor system.',
    priceUSD: 14500,
    primaryPriceUSD: 14500,
    primaryTradeMode: 'currency',
    status: 'sold',
    listingIntent: 'sell',
    itemType: 'good',
    visibility: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?auto=format&fit=crop&w=800&q=80',
    primaryCurrency: 'USD',
    acceptedSettlements: ['fiat', 'stable_coins', 'crypto'],
    tags: ['Drone', 'Hardware', 'AI', 'Transacted'],
    views: 412,
    likes: 19,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 140).toISOString(),
  },
  {
    id: 'mkt-transacted-belfort-horology',
    userId: 'demo-jordan',
    sellerId: 'jordan_belfort',
    creatorName: 'Jordan Belfort',
    creatorHandle: 'jordan_belfort',
    sellerHandle: '@jordan_belfort',
    creatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    title: 'Audemars Piguet Royal Oak Chronograph Rose Gold',
    category: 'Fine Watches & Horology',
    description: 'Certified authentic luxury timepiece transacted via bilateral escrow settlement with full provenance paperwork.',
    priceUSD: 72000,
    primaryPriceUSD: 72000,
    primaryTradeMode: 'currency',
    status: 'sold',
    listingIntent: 'sell',
    itemType: 'good',
    visibility: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    primaryCurrency: 'USDC',
    acceptedSettlements: ['stable_coins', 'final_coins'],
    tags: ['Horology', 'Luxury', 'AP', 'Transacted'],
    views: 750,
    likes: 51,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 200).toISOString(),
  },
  {
    id: 'mkt-transacted-alex-legal',
    userId: 'demo-vip-alex',
    sellerId: 'alex_morgan',
    creatorName: 'Alex Morgan',
    creatorHandle: 'alex_morgan',
    sellerHandle: '@alex_morgan',
    creatorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    title: 'Cross-Jurisdictional Multi-Sig Treasury Legal Structuring',
    category: 'Financial Advisory & Legal',
    description: 'Bespoke Swiss-Delaware multi-sig custody agreement drafting, AML/KYC protocol compliance package, and custodial sign-off.',
    priceUSD: 18500,
    primaryPriceUSD: 18500,
    primaryTradeMode: 'currency',
    status: 'sold',
    listingIntent: 'sell',
    itemType: 'service',
    visibility: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80',
    primaryCurrency: 'USDC',
    acceptedSettlements: ['stable_coins', 'final_coins'],
    tags: ['Legal', 'Treasury', 'Advisory', 'Transacted'],
    views: 530,
    likes: 29,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 110).toISOString(),
  },
  {
    id: 'mkt-transacted-auction-patek',
    userId: 'user-lord_sterling',
    sellerId: 'sterling_vault',
    creatorName: 'Lord Sterling',
    creatorHandle: 'sterling_vault',
    sellerHandle: '@sterling_vault',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    title: '1998 Patek Philippe Perpetual Calendar Ref. 3940J',
    category: 'Fine Watches & Horology',
    description: 'Won sovereign reserve auction with Geneva seal extract, solid 18k yellow gold deployment buckle, and armored courier transfer.',
    priceUSD: 94500,
    primaryPriceUSD: 94500,
    primaryTradeMode: 'currency',
    status: 'sold',
    listingIntent: 'auction',
    itemType: 'good',
    visibility: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=800&q=80',
    primaryCurrency: 'AFNL',
    acceptedSettlements: ['final_coins', 'stable_coins', 'barter'],
    auctionConfig: {
      startingBidUSD: 80000,
      minIncrementUSD: 1000,
      highestBidUSD: 94500,
      bidCount: 7,
      endTimeIso: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
      status: 'settled',
    },
    tags: ['Auction', 'Horology', 'Won', 'Escrow'],
    views: 1120,
    likes: 88,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 160).toISOString(),
  },
  {
    id: 'mkt-transacted-auction-node',
    userId: 'demo-elena',
    sellerId: 'elena',
    creatorName: 'Elena Rostova',
    creatorHandle: 'elena',
    sellerHandle: '@elena',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    title: 'Allocated Zurich Sovereign Compute & Cold Vault Node (12 Mo)',
    category: 'Hardware & Compute',
    description: 'Auction won for 12-month dedicated bare-metal air-gapped node cluster inside Zurich Tier-4 sovereign vault facility.',
    priceUSD: 38000,
    primaryPriceUSD: 38000,
    primaryTradeMode: 'currency',
    status: 'sold',
    listingIntent: 'auction',
    itemType: 'service',
    visibility: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    primaryCurrency: 'USDC',
    acceptedSettlements: ['stable_coins', 'final_coins'],
    auctionConfig: {
      startingBidUSD: 30000,
      minIncrementUSD: 500,
      highestBidUSD: 38000,
      bidCount: 5,
      endTimeIso: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
      status: 'settled',
    },
    tags: ['Auction', 'Compute', 'Zurich', 'Service'],
    views: 840,
    likes: 61,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 210).toISOString(),
  }
];

/**
 * Returns all transacted postings of goods, services, and won auctions created by OTHERS that the user accepted & transacted.
 * Strictly guarantees none of the user's own postings appear in this list.
 */
export function getMyTransactedPostings(userId: string): MarketplaceListing[] {
  const userNorms = buildAliasNormSet(userId);
  const allListings = getAllMarketplaceListings();

  const isOwnedByUser = (item: MarketplaceListing) => {
    const candidates = [item.userId, item.sellerId, item.creatorHandle, item.sellerHandle].filter(Boolean) as string[];
    return candidates.some((c) => userNorms.has(normKey(c)));
  };

  // Find listings from others that match sold/settled state
  const otherPostings = allListings.filter((l) => {
    return !isOwnedByUser(l) && (l.status === 'sold' || Boolean(l.auctionConfig?.status === 'settled'));
  });

  const combinedMap = new Map<string, MarketplaceListing>();

  // Add the base realistic transacted items from other sellers
  BASE_OTHER_TRANSACTED_LISTINGS.forEach((item) => {
    if (!isOwnedByUser(item)) {
      combinedMap.set(item.id, item);
    }
  });

  // Add dynamically transacted listings from other sellers
  otherPostings.forEach((item) => {
    if (!isOwnedByUser(item) && !combinedMap.has(item.id)) {
      combinedMap.set(item.id, item);
    }
  });

  return Array.from(combinedMap.values());
}

/**
 * Organizes all goods, services, and auctions the user bought/won into 3 subsections:
 * 1) goods
 * 2) services
 * 3) auctions
 * Every item has a deterministic listing ID so the user can submit & update 1 rating and comment per item.
 */
export function getBoughtHistoryCategorized(
  userId: string,
  userUid?: string
): {
  goods: MarketplaceListing[];
  services: MarketplaceListing[];
  auctions: MarketplaceListing[];
} {
  const userNorms = buildAliasNormSet(userId, userUid);
  const userKeys = Array.from(userNorms);
  const isOwner = (item: MarketplaceListing) => {
    const candidates = [item.userId, item.sellerId, item.creatorHandle, item.sellerHandle].filter(Boolean) as string[];
    return candidates.some((c) => userNorms.has(normKey(c)));
  };

  const goods: MarketplaceListing[] = [];
  const services: MarketplaceListing[] = [];
  const auctions: MarketplaceListing[] = [];
  const seenIds = new Set<string>();
  const seenTitles = new Set<string>();

  const addItem = (item: MarketplaceListing) => {
    if (isOwner(item)) return;
    const cleanTitle = (item.title || '').trim().toLowerCase();
    if (seenIds.has(item.id)) return;
    seenIds.add(item.id);
    if (cleanTitle) seenTitles.add(cleanTitle);

    if (item.listingIntent === 'auction') {
      auctions.push(item);
    } else if (item.itemType === 'service') {
      services.push(item);
    } else {
      goods.push(item);
    }
  };

  // 1. Add transacted postings & won auctions from marketplace + base transacted items
  const transacted = getMyTransactedPostings(userId);
  transacted.forEach(addItem);

  // Also check live/settled auctions where this user won or holds winning bid
  const allListings = getAllMarketplaceListings();
  allListings.forEach((l) => {
    if (l.listingIntent !== 'auction' || isOwner(l)) return;
    const bids = getAuctionBids(l.id);
    const userWon =
      l.auctionConfig?.status === 'settled' &&
      (userKeys.includes(normKey(l.auctionConfig.highestBidderId)) ||
        userKeys.includes(normKey(l.auctionConfig.highestBidderUid)) ||
        userKeys.includes(normKey(l.auctionConfig.highestBidderHandle)) ||
        bids.some(
          (b) =>
            (b.status === 'won' || b.status === 'accepted') &&
            (userKeys.includes(normKey(b.bidderId)) ||
              userKeys.includes(normKey(b.bidderUid)) ||
              userKeys.includes(normKey(b.bidderHandle)))
        ));
    if (userWon) {
      addItem(l);
    }
  });

  // 2. Include dynamic ledger purchase records (product_purchase, service_payment, barter_swap)
  const ledger = getStoredLedgerTransactions(userId);
  ledger.forEach((tx) => {
    if (tx.type !== 'product_purchase' && tx.type !== 'service_payment' && tx.type !== 'barter_swap') {
      return;
    }
    const cleanTitle = (tx.title || '').trim().toLowerCase();
    if (seenTitles.has(cleanTitle)) return;

    const isAuctionTitle = cleanTitle.includes('auction');
    const isService =
      tx.type === 'service_payment' ||
      cleanTitle.includes('service') ||
      cleanTitle.includes('audit') ||
      cleanTitle.includes('advisory') ||
      cleanTitle.includes('consulting');

    const mappedListing: MarketplaceListing = {
      id: `ledger-bought-${tx.id}`,
      userId: 'external-seller',
      sellerId: (tx.counterpartyOrIssuer || 'verified_seller').replace(/^@/, ''),
      creatorName: tx.counterpartyOrIssuer || 'Verified Merchant',
      creatorHandle: (tx.issuerHandle || tx.counterpartyOrIssuer || 'verified_merchant').replace(/^@/, '').split(' ')[0].toLowerCase(),
      sellerHandle: tx.issuerHandle || `@${(tx.counterpartyOrIssuer || 'verified_merchant').replace(/^@/, '').split(' ')[0].toLowerCase()}`,
      listingIntent: isAuctionTitle ? 'auction' : 'sell',
      itemType: isService ? 'service' : 'good',
      primaryTradeMode: tx.type === 'barter_swap' ? 'barter' : 'currency',
      primaryCurrency: tx.paymentCoinSymbol || 'USD',
      primaryPriceUSD: Math.abs(tx.netAmountUSD || tx.amountUSD || 0),
      priceUSD: Math.abs(tx.netAmountUSD || tx.amountUSD || 0),
      title: tx.title,
      category: tx.category === 'product_service' ? (isService ? 'Professional Services' : 'Goods & Hardware') : (tx.category || 'Marketplace'),
      description: tx.description || `Settled on ${tx.timestamp}`,
      status: 'sold',
      visibility: 'public',
      acceptedSettlements: ['final_coins', 'stable_coins', 'fiat'],
      tags: ['Bought', isAuctionTitle ? 'Auction' : isService ? 'Service' : 'Good'],
      likes: 0,
      views: 1,
      createdAt: tx.dateIso || new Date().toISOString(),
    };

    addItem(mappedListing);
  });

  return { goods, services, auctions };
}
