import React, { useState } from 'react';
import { X, Sparkles, Check, Trash2, Tag } from 'lucide-react';
import { AdminMember, AdminGroup } from '../../services/adminGroupService';

interface AdminSecondaryTitleModalProps {
  admin: AdminMember;
  group: AdminGroup;
  currentTitle?: string;
  onClose: () => void;
  onSave: (groupId: string, adminId: string, secondaryTitle: string) => void;
}

const SUGGESTED_SECONDARY_TITLES = [
  'Lead Arbiter',
  'Council Lead',
  'Treasury Signer',
  'Cold Vault Custodian',
  'Protocol Inspector',
  'AML Lead Arbiter',
  'OTC Desk Director',
  'Dispute Lead',
];

export const AdminSecondaryTitleModal: React.FC<AdminSecondaryTitleModalProps> = ({
  admin,
  group,
  currentTitle = '',
  onClose,
  onSave,
}) => {
  const [secondaryTitle, setSecondaryTitle] = useState(currentTitle);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(group.id, admin.id, secondaryTitle.trim());
  };

  const handleClear = () => {
    onSave(group.id, admin.id, '');
  };

  return (
    <div
      id="admin-secondary-title-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="admin-secondary-title-modal-container"
        className="bg-white rounded-2xl border border-slate-200 max-w-md w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header - Compact & Sticky */}
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center border border-indigo-200 shrink-0">
              <Tag className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="font-serif text-sm font-bold text-slate-900 truncate">
                Assign Secondary Role
              </h3>
              <p className="text-[11px] text-slate-500 truncate">
                Group role in {group.name}
              </p>
            </div>
          </div>
          <button
            type="button"
            id="admin-secondary-title-close-btn"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form with Scrollable Body & Sticky Action Footer */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0 overflow-hidden">
          {/* Scrollable Form Body */}
          <div className="p-4 space-y-3 flex-1 overflow-y-auto min-h-0">
            {/* Target Admin Card - Compact */}
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-2.5">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 font-serif font-bold text-xs flex items-center justify-center border border-amber-200 shrink-0">
                  {admin.name.charAt(0)}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs text-slate-900 truncate">{admin.name}</span>
                    <span className="font-mono text-[10px] text-amber-600 truncate">{admin.handle}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate mt-0.5">
                    Primary: <span className="font-medium text-slate-700">{admin.jobTitle || (admin.role === 'super_admin' ? 'Super Admin' : 'Admin')}</span>
                  </p>
                </div>
              </div>

              {/* Group badge */}
              <div
                className="px-2 py-0.5 rounded-md text-[10px] font-bold border shrink-0 flex items-center gap-1"
                style={{
                  backgroundColor: `${group.color}15`,
                  borderColor: `${group.color}40`,
                  color: group.color,
                }}
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: group.color }} />
                <span className="truncate max-w-[90px]">{group.name}</span>
              </div>
            </div>

            {/* Secondary Job Title Input */}
            <div className="space-y-1">
              <label
                htmlFor="secondary-job-title-input"
                className="block text-[11px] font-bold uppercase tracking-wider text-slate-700"
              >
                Secondary Role in {group.name}
              </label>
              <div className="relative">
                <input
                  id="secondary-job-title-input"
                  type="text"
                  value={secondaryTitle}
                  onChange={(e) => setSecondaryTitle(e.target.value)}
                  placeholder="e.g. Lead Arbiter, Treasury Signer..."
                  className="w-full px-3 py-2 pl-9 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                  autoFocus
                />
                <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            {/* Suggested Titles - Compact Chips */}
            <div className="space-y-1.5">
              <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-500">
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>Popular Roles:</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {SUGGESTED_SECONDARY_TITLES.map((title) => (
                  <button
                    key={title}
                    type="button"
                    onClick={() => setSecondaryTitle(title)}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-medium transition-all cursor-pointer border ${
                      secondaryTitle.toLowerCase() === title.toLowerCase()
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs font-semibold'
                        : 'bg-slate-50 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border-slate-200'
                    }`}
                  >
                    {title}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons - Always Visible Fixed Footer */}
          <div className="px-4 py-2.5 border-t border-slate-100 bg-slate-50/90 flex items-center justify-between gap-2 shrink-0">
            {currentTitle ? (
              <button
                type="button"
                id="admin-secondary-title-clear-btn"
                onClick={handleClear}
                className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 hover:border-rose-300 transition-colors cursor-pointer flex items-center gap-1 shrink-0"
              >
                <Trash2 className="w-3 h-3" />
                <span>Remove</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                id="admin-secondary-title-cancel-btn"
                onClick={onClose}
                className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-200/60 border border-slate-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                id="admin-secondary-title-save-btn"
                className="px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-all cursor-pointer shadow-xs flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Save Role</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
