import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { generateOrEditImage, enhanceAssetPrompt, generateValuationReport, processChatRequest } from './src/server/geminiService';

const currentFile = typeof __filename !== 'undefined' ? __filename : (typeof process !== 'undefined' && process.argv[1] ? process.argv[1] : '');
const currentDir = typeof __dirname !== 'undefined' ? __dirname : (currentFile ? path.dirname(currentFile) : process.cwd());

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;
  const projectRoot = process.cwd();

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // Serve static files from public directory
  app.use(express.static(path.join(projectRoot, 'public')));

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // API Endpoints
  app.post('/api/generate-image', async (req, res) => {
    try {
      const result = await generateOrEditImage({
        prompt: req.body.prompt,
        model: req.body.model || 'gemini-3-pro-image-preview',
        aspectRatio: req.body.aspectRatio || '1:1',
        imageSize: req.body.imageSize || '1K',
        useSearch: !!req.body.useSearch,
        referenceImage: req.body.referenceImage,
        referenceMimeType: req.body.referenceMimeType,
      });
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/edit-image', async (req, res) => {
    try {
      const result = await generateOrEditImage({
        prompt: req.body.prompt,
        model: req.body.model || 'gemini-3.1-flash-image-preview',
        aspectRatio: req.body.aspectRatio || '1:1',
        referenceImage: req.body.referenceImage,
        referenceMimeType: req.body.referenceMimeType,
      });
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/enhance-prompt', async (req, res) => {
    try {
      const result = await enhanceAssetPrompt(req.body.prompt, req.body.category);
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/valuation-report', async (req, res) => {
    try {
      const result = await generateValuationReport(req.body.name, req.body.category, req.body.price, req.body.attributes);
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  app.post('/api/chat', async (req, res) => {
    try {
      const { message, history } = req.body;
      const result = await processChatRequest(message, history);
      return res.status(result.success ? 200 : 500).json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Server error' });
    }
  });

  // Direct Alpaca API Endpoints
  app.get('/api/alpaca/account', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const result = await alpaca.getAccount();
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  app.get('/api/alpaca/positions', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const result = await alpaca.getPositions();
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  app.get('/api/alpaca/assets', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { asset_class } = req.query;
      const result = await alpaca.getAssets(asset_class as any);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/asset/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const result = await alpaca.getAssetBySymbol(req.params.symbol);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/snapshot/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { asset_class } = req.query;
      const result = await alpaca.getAssetSnapshot(req.params.symbol, asset_class as any);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/options/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { expiration_gte, expiration_lte } = req.query;
      const result = await alpaca.getOptionsChain(
        req.params.symbol,
        expiration_gte as string,
        expiration_lte as string
      );
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });
  
  app.get('/api/alpaca/bars/:symbol', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { timeframe, limit, asset_class } = req.query;
      const result = await alpaca.getAssetBars(
        req.params.symbol, 
        (timeframe as string) || '1Day', 
        limit ? parseInt(limit as string) : 100,
        asset_class as any
      );
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  app.get('/api/alpaca/search', async (req, res) => {
    try {
      const alpaca = await import('./src/server/alpacaService');
      const { q, asset_class } = req.query;
      if (!q) return res.json({ success: true, data: [] });
      const result = await alpaca.searchAssets(q as string, asset_class as any);
      return res.json(result);
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message });
    }
  });

  // Vite middleware for development vs static for production
  const isProduction = process.env.NODE_ENV === 'production' || currentFile.endsWith('.cjs') || currentFile.includes('dist');
  if (!isProduction) {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = fs.existsSync(path.join(projectRoot, 'dist', 'index.html'))
      ? path.join(projectRoot, 'dist')
      : (fs.existsSync(path.join(currentDir, 'index.html')) ? currentDir : path.join(projectRoot, 'dist'));
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Final Finance server successfully started`);
    console.log(`[Server] Local: http://localhost:${PORT}`);
    console.log(`[Server] Network: http://0.0.0.0:${PORT}`);
    console.log(`[Server] Environment: ${process.env.NODE_ENV || 'development'}`);
  });
}

startServer().catch((err) => {
  console.error('[Server] CRITICAL FAILURE during startup:', err);
  process.exit(1);
});
