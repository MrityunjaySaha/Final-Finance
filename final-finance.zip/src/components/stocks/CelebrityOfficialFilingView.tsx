import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Star, 
  ExternalLink, 
  Copy, 
  Check, 
  CheckCircle2, 
  FileText, 
  ShieldCheck, 
  Radio, 
  Calendar, 
  Building, 
  TrendingUp, 
  TrendingDown, 
  Globe,
  Award,
  Hash,
  UserCheck
} from 'lucide-react';
import { 
  getEntityProfile, 
  formatTradeNotificationCard 
} from '../../services/publicDisclosuresAgent';
import { PublicTradeAlertJSON } from '../../types/stocks';

interface CelebrityOfficialFilingViewProps {
  entityId: string;
  celebrityName: string;
  isFavorited: boolean;
  onToggleFavorite: () => void;
  onBack: () => void;
  onQuickTrade?: (ticker: string, side?: 'buy' | 'sell', valuation?: number) => void;
}

export const CelebrityOfficialFilingView: React.FC<CelebrityOfficialFilingViewProps> = ({
  entityId,
  celebrityName,
  isFavorited,
  onToggleFavorite,
  onBack,
  onQuickTrade
}) => {
  const profile = getEntityProfile(entityId || celebrityName);
  const [selectedFilingIndex, setSelectedFilingIndex] = useState<number>(0);
  const [txSideFilter, setTxSideFilter] = useState<'all' | 'buy' | 'sell'>('all');
  const [copiedAlertCard, setCopiedAlertCard] = useState<boolean>(false);
  const [copiedValuation, setCopiedValuation] = useState<string | null>(null);

  const activeFiling: PublicTradeAlertJSON = 
    profile.recentFilings[selectedFilingIndex % profile.recentFilings.length] || profile.recentFilings[0];

  const activeTx = 
    profile.detailedTransactions[selectedFilingIndex % profile.detailedTransactions.length] || 
    profile.detailedTransactions[0];

  const buyTransactionsCount = profile.detailedTransactions.filter((t) => t.action === 'BUY').length;
  const sellTransactionsCount = profile.detailedTransactions.filter((t) => t.action === 'SELL').length;

  const visibleTransactions = profile.detailedTransactions.filter((tx) => {
    if (txSideFilter === 'buy') return tx.action === 'BUY';
    if (txSideFilter === 'sell') return tx.action === 'SELL';
    return true;
  });

  const notificationCardText = formatTradeNotificationCard(activeFiling);

  const handleCopyNotificationCard = () => {
    navigator.clipboard.writeText(notificationCardText);
    setCopiedAlertCard(true);
    setTimeout(() => setCopiedAlertCard(false), 2000);
  };

  const handleCopyTradeValuation = (valStr: string) => {
    navigator.clipboard.writeText(valStr);
    setCopiedValuation(valStr);
    setTimeout(() => setCopiedValuation(null), 2500);
  };

  const isBuy = activeFiling.action === 'BUY';

  const isFriendProfile = 
    profile.id !== 'demo-satoshi-nakamoto' &&
    profile.id !== 'famous-saylor' &&
    profile.id !== 'famous-musk' &&
    (profile.sourceAgency === 'Peer Syndicate Network' ||
     profile.id.startsWith('user-') ||
     profile.id.includes('elena') ||
     profile.id.includes('sterling') ||
     profile.id.includes('marcus') ||
     profile.id.includes('sophia') ||
     profile.name === 'Elena Rostova' ||
     profile.name === 'Lord Sterling' ||
     profile.name === 'Dr. Marcus Vance' ||
     profile.name === 'Sophia Vance');

  // Badge styling according to celebrity category
  const getCategoryTheme = () => {
    if (isFriendProfile) {
      return {
        badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300',
        sealTitle: 'COMMUNITY PEER LEDGER & PORTFOLIO ALLOCATION',
        formTitle: 'PEER PORTFOLIO TRADES & ALLOCATION REPORT',
        sealSubtitle: 'Verified Real-Time Peer Executions in the Past Month',
        ombText: 'COMMUNITY NETWORK PROTOCOL • Verified Community Peer Network'
      };
    }
    switch (profile.entityCategory) {
      case 'Governmental Public Servant':
        return {
          badgeBg: 'bg-blue-100 text-blue-900 border-blue-300',
          sealTitle: 'UNITED STATES CONGRESSIONAL ETHICS COMMISSION',
          formTitle: 'STOCK ACT PERIODIC TRANSACTION REPORT (PTR)',
          sealSubtitle: 'Official Public Disclosure filed pursuant to Public Law 112-105',
          ombText: 'Ethics in Government Act Form • U.S. House & Senate Ethics Oversight'
        };
      case 'Independent Entrepreneur':
        return {
          badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300',
          sealTitle: 'UNITED STATES SECURITIES AND EXCHANGE COMMISSION',
          formTitle: 'FORM 4: STATEMENT OF CHANGES IN BENEFICIAL OWNERSHIP',
          sealSubtitle: 'Filed pursuant to Section 16(a) of the Securities Exchange Act of 1934',
          ombText: 'OMB APPROVAL: OMB Number 3235-0287 • Estimated average burden hours: 0.5'
        };
      case 'Sovereign Pioneer':
        return {
          badgeBg: 'bg-amber-100 text-amber-900 border-amber-300',
          sealTitle: 'DECENTRALIZED SOVEREIGN LEDGER DISCLOSURE',
          formTitle: 'CRYPTOGRAPHIC PROOF OF RESERVE & PUBLIC ALLOCATION',
          sealSubtitle: 'Mathematical Proof validated by global consensus node network',
          ombText: 'PROOF OF RESERVE VALIDATED • SHA-256 / KECCAK-256 MERKLE ROOT'
        };
      case 'Institutional Allocator':
      default:
        return {
          badgeBg: 'bg-purple-100 text-purple-900 border-purple-300',
          sealTitle: 'UNITED STATES SECURITIES AND EXCHANGE COMMISSION',
          formTitle: 'FORM 13F-HR: INSTITUTIONAL INVESTMENT MANAGER REPORT',
          sealSubtitle: 'Report for the Calendar Quarter Ended pursuant to Section 13(f) of the 1934 Act',
          ombText: 'OMB APPROVAL: OMB Number 3235-0006 • Institutional Manager Holding Report'
        };
    }
  };

  const theme = getCategoryTheme();

  return (
    <div className="space-y-6 text-left animate-fade-in pb-12">
      {/* Top Application Navigation Bar with Prominent Back Button */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all flex items-center gap-2 cursor-pointer shadow-xs active:scale-95 shrink-0"
            title="Return to feed and previous screen"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${theme.badgeBg}`}>
                {isFriendProfile ? 'Community Peer / Mutual Friend' : profile.entityCategory}
              </span>
            </div>
            <h2 className="font-serif font-bold text-lg sm:text-xl text-slate-950 flex items-center gap-2 mt-0.5">
              <FileText className={`w-5 h-5 ${isFriendProfile ? 'text-indigo-600' : 'text-amber-500'}`} />
              <span>{profile.name} — {isFriendProfile ? 'Past Month Trades & Allocation' : profile.disclosureType}</span>
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {/* Favorite Toggle Button */}
          <button
            type="button"
            onClick={onToggleFavorite}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border shadow-2xs active:scale-95 ${
              isFavorited
                ? 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                : 'bg-white text-slate-700 hover:bg-amber-50 hover:text-amber-800 border-slate-200 hover:border-amber-300'
            }`}
            title={isFavorited ? `Remove ${profile.name} from favorites` : `Add ${profile.name} to favorite ${isFriendProfile ? 'friends' : 'celebrities'}`}
          >
            <Star className={`w-4 h-4 ${isFavorited ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`} />
            <span>{isFavorited ? (isFriendProfile ? 'Favorited Friend' : 'Favorited Celebrity') : (isFriendProfile ? 'Favorite Friend' : 'Favorite Celebrity')}</span>
          </button>

          {/* Official .gov / On-Chain Source Link (Celebrities only — Friends do not need Official Peer Ledger Source) */}
          {!isFriendProfile && (
            <a
              href={activeFiling?.source_document_url || profile.filingFeedUrl}
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200"
              title="Open official document source"
            >
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              <span>
                {profile.entityCategory === 'Governmental Public Servant'
                  ? 'Official .gov Source'
                  : profile.sourceAgency === 'SEC EDGAR'
                  ? 'Official .gov Source'
                  : profile.officialSeal === 'SOVEREIGN'
                  ? 'Official On-Chain Source'
                  : 'Official Source'}
              </span>
              <ExternalLink className="w-3 h-3 text-slate-400" />
            </a>
          )}
        </div>
      </div>

      {/* Clean Notification Card Output Banner */}
      <div className={`p-5 rounded-3xl border shadow-2xs space-y-2 ${
        isFriendProfile
          ? 'bg-indigo-50 border-indigo-200 text-indigo-950'
          : 'bg-amber-50 border-amber-300 text-amber-950'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio className={`w-4 h-4 animate-pulse ${isFriendProfile ? 'text-indigo-600' : 'text-amber-600'}`} />
            <span className={`font-bold font-mono text-xs uppercase tracking-wider ${isFriendProfile ? 'text-indigo-900' : 'text-amber-900'}`}>
              {isFriendProfile ? 'Clean Peer Trade Alert Output:' : 'Clean Notification Card Output:'}
            </span>
          </div>
          <button
            type="button"
            onClick={handleCopyNotificationCard}
            className={`text-xs font-mono flex items-center gap-1 cursor-pointer transition-colors ${
              isFriendProfile ? 'text-indigo-800 hover:text-indigo-950' : 'text-amber-800 hover:text-amber-950'
            }`}
          >
            {copiedAlertCard ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-700" />
                <span className="text-emerald-700 font-bold">Copied Notification Card!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Notification Text</span>
              </>
            )}
          </button>
        </div>

        <div className={`p-4 rounded-2xl bg-white border text-slate-900 font-mono text-xs sm:text-sm font-semibold leading-relaxed shadow-2xs ${
          isFriendProfile ? 'border-indigo-200' : 'border-amber-200/80'
        }`}>
          "{notificationCardText}"
        </div>
      </div>

      {/* Available Disclosed Filings Selector */}
      {profile.recentFilings.length > 1 && (
        <div className="space-y-2">
          <span className="text-xs font-mono uppercase text-slate-400 block font-semibold">
            {isFriendProfile
              ? `Select Recent Execution for ${profile.name} (${profile.recentFilings.length} Recorded in Past Month):`
              : `Select Detected Filing for ${profile.name} (${profile.recentFilings.length} Filings Available):`}
          </span>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {profile.recentFilings.map((filing, idx) => {
              const isSelected = idx === selectedFilingIndex;
              return (
                <button
                  key={`${filing.ticker}-${idx}`}
                  type="button"
                  onClick={() => setSelectedFilingIndex(idx)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 border ${
                    isSelected
                      ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    filing.action === 'BUY' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    {filing.action}
                  </span>
                  <span>${filing.ticker}</span>
                  <span className="text-[11px] font-mono opacity-70">
                    ({filing.timestamp.split('|')[0].trim()})
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= STYLIZED OFFICIAL GOVERNMENT FILING DOCUMENT ================= */}
      <div className="rounded-3xl bg-stone-50 border-2 border-stone-300 shadow-lg text-stone-900 overflow-hidden font-sans">
        {/* Official Federal Document Header */}
        <div className="p-6 sm:p-8 bg-stone-100 border-b-2 border-stone-300 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-stone-900 text-amber-400 flex items-center justify-center font-serif text-xl font-bold shadow-md shrink-0">
                <Award className="w-7 h-7" />
              </div>
              <div>
                <p className="text-[11px] font-mono tracking-widest text-stone-600 font-bold uppercase">
                  {theme.sealTitle}
                </p>
                <h1 className="font-serif font-black text-lg sm:text-2xl text-stone-950 uppercase tracking-tight">
                  {theme.formTitle}
                </h1>
                <p className="text-xs text-stone-600 mt-0.5">
                  {theme.sealSubtitle}
                </p>
              </div>
            </div>

            {/* OMB / Authority Seal Box */}
            <div className="p-3 rounded-xl bg-white border border-stone-300 text-stone-800 text-[11px] font-mono max-w-xs shadow-2xs space-y-1">
              <div className="flex items-center justify-between border-b border-stone-200 pb-1">
                <span className="font-bold uppercase text-[10px] text-stone-500">Statutory Form</span>
                <span className="text-emerald-700 font-bold">VERIFIED</span>
              </div>
              <p className="text-[10px] text-stone-600 leading-tight">
                {theme.ombText}
              </p>
              <div className="pt-1 flex items-center justify-between text-[10px] text-stone-500">
                <span>{isFriendProfile ? 'Peer Reference:' : 'Accession:'}</span>
                <span className="font-bold text-stone-900">{profile.filingAccessionNumber}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Official Statutory Boxes: Filer & Issuer Identification */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Box 1: Reporting Person / Official */}
            <div className="p-4 rounded-2xl bg-white border border-stone-300 shadow-2xs space-y-2">
              <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                <span className="text-[10px] font-mono uppercase font-bold text-stone-500">
                  {isFriendProfile ? '1. Verified Syndicate Peer' : '1. Name and Address of Reporting Person / Public Official'}
                </span>
                <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                  {profile.identifier}
                </span>
              </div>
              <div className="flex items-center gap-3 pt-1">
                <img
                  src={profile.avatarUrl}
                  alt={profile.name}
                  className="w-12 h-12 rounded-xl object-cover border border-stone-300 shrink-0"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-bold text-base text-stone-950">{profile.name}</h3>
                    <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  </div>
                  <p className="text-xs text-stone-600">{profile.role}</p>
                  <p className="text-[11px] font-mono text-stone-500 mt-0.5">{profile.sourceAgency}</p>
                </div>
              </div>
            </div>

            {/* Box 2: Issuer Information & Relationship */}
            <div className="p-4 rounded-2xl bg-white border border-stone-300 shadow-2xs space-y-2">
              <div className="flex items-center justify-between border-b border-stone-200 pb-2">
                <span className="text-[10px] font-mono uppercase font-bold text-stone-500">
                  {isFriendProfile ? '2. Portfolio Primary Assets' : '2. Issuer Name & Ticker Symbol'}
                </span>
                <span className="font-mono font-bold text-stone-900 text-xs">
                  ${activeFiling.ticker}
                </span>
              </div>
              <div className="space-y-1 pt-1">
                <p className="font-bold text-sm text-stone-900">{profile.issuerName}</p>
                <div className="flex items-center gap-2 flex-wrap text-xs text-stone-600">
                  <span className="font-mono">Symbol: <strong className="text-stone-950">${profile.issuerTradingSymbol}</strong></span>
                  <span>&bull;</span>
                  <span>Relationship: <strong className="text-stone-950">{profile.relationship}</strong></span>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
                    {isFriendProfile ? 'Past Month Verified Ledger' : 'Official Statutory Filing'}
                  </span>
                  <span className="text-[10px] font-mono text-stone-500">
                    Category: {profile.entityCategory}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* TABLE I — Non-Derivative & Derivative Securities Transactions */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-serif font-bold text-base text-stone-950 uppercase tracking-tight flex items-center gap-2">
                  <FileText className="w-4 h-4 text-stone-700" />
                  <span>
                    {isFriendProfile 
                      ? 'Friend Portfolio Transactions (Past Month)' 
                      : 'Table I — Non-Derivative & Derivative Securities Disclosed'}
                  </span>
                </h3>
                <span className="text-xs font-mono text-stone-500">
                  {isFriendProfile 
                    ? 'Verified Friend Trades Executed in the Past Month • Disclosing Buys & Sells'
                    : 'Official Statutory Ledger Format • Disclosing Buys & Sells'}
                </span>
              </div>
            </div>

            {/* Authentic Federal Table */}
            <div className="overflow-x-auto rounded-2xl border border-stone-300 bg-white shadow-2xs">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-stone-100 border-b border-stone-300 text-[10px] font-mono uppercase text-stone-600">
                    <th className="p-3 font-bold">1. Title of Security</th>
                    <th className="p-3 font-bold whitespace-nowrap">2. Trans. Date</th>
                    <th className="p-3 font-bold whitespace-nowrap">3. Code</th>
                    <th className="p-3 font-bold whitespace-nowrap">4. Amount (Shares)</th>
                    <th className="p-3 font-bold whitespace-nowrap">5. Price</th>
                    <th className="p-3 font-bold whitespace-nowrap text-right">6. Trade Valuation</th>
                    <th className="p-3 font-bold text-center whitespace-nowrap">7. A/D</th>
                    <th className="p-3 font-bold whitespace-nowrap">8. Ownership</th>
                    <th className="p-3 font-bold whitespace-nowrap">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {visibleTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-6 text-center text-stone-500 font-mono text-xs">
                        No {txSideFilter === 'buy' ? 'Buy' : 'Sell'} transactions recorded for this entity.
                      </td>
                    </tr>
                  ) : (
                    visibleTransactions.map((tx, idx) => {
                    const isTxBuy = tx.action === 'BUY';
                    const isCopied = copiedValuation === tx.valuation;
                    return (
                      <tr key={idx} className="hover:bg-stone-50 transition-colors">
                        <td className="p-3 font-medium text-stone-900 max-w-xs">
                          <div className="font-bold">{tx.securityTitle}</div>
                          <span className="text-[10px] font-mono text-stone-500">
                            Class: {activeFiling.asset_class}
                          </span>
                        </td>
                        <td className="p-3 font-mono whitespace-nowrap text-stone-800">
                          {tx.transactionDate}
                          <span className="block text-[10px] text-stone-400">Filed: {tx.filingDate}</span>
                        </td>
                        <td className="p-3 font-mono text-stone-700 whitespace-nowrap">
                          <span className="px-1.5 py-0.5 rounded bg-stone-100 text-[10px] font-bold border border-stone-300">
                            {tx.transactionCode.split(' ')[0]}
                          </span>
                        </td>
                        <td className="p-3 font-mono font-bold text-stone-900 whitespace-nowrap">
                          {tx.shares}
                        </td>
                        <td className="p-3 font-mono text-stone-700 whitespace-nowrap">
                          {tx.price}
                        </td>
                        <td className="p-3 font-mono font-bold text-stone-950 text-right whitespace-nowrap">
                          <div className="text-sm">{tx.valuation}</div>
                          <span className="text-[10px] font-sans text-stone-500">Statutory Valuation</span>
                        </td>
                        <td className="p-3 text-center whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                            isTxBuy ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-rose-100 text-rose-900 border border-rose-300'
                          }`}>
                            {tx.acquiredDisposed} ({tx.action})
                          </span>
                        </td>
                        <td className="p-3 text-stone-600 whitespace-nowrap text-[11px]">
                          <span className="font-mono font-bold text-stone-800">{tx.ownershipType}</span>
                          <span className="block text-[10px] text-stone-500">{tx.ownershipNature}</span>
                        </td>
                        <td className="p-3 whitespace-nowrap">
                          {/* Copy Trade is Trade Valuation */}
                          <button
                            type="button"
                            onClick={() => handleCopyTradeValuation(tx.valuation)}
                            className="px-2.5 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 text-white font-bold text-[11px] transition-all flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs"
                            title="Copy the exact statutory trade valuation"
                          >
                            {isCopied ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span className="text-emerald-400">Valuation Copied!</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3 text-amber-400" />
                                <span>Copy Valuation</span>
                              </>
                            )}
                          </button>
                        </td>
                      </tr>
                    );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Statutory Footnotes & Explanations */}
          <div className="p-4 rounded-2xl bg-white border border-stone-300 space-y-2 text-xs">
            <span className="font-mono font-bold uppercase text-[10px] text-stone-500 block">
              Explanation of Responses &amp; Statutory Footnotes:
            </span>
            <ol className="list-decimal list-inside space-y-1.5 text-stone-700 font-sans leading-relaxed">
              {profile.footnotes.map((fn, fIdx) => (
                <li key={fIdx} className="text-xs">
                  <span className="text-stone-800 font-medium">{fn}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* Certification Oath & Digital Signature Block (Shown for Celebrities & Friends) */}
          <div className="p-5 rounded-2xl bg-stone-100 border border-stone-300 space-y-3 overflow-hidden">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
              <p className="text-xs font-medium text-stone-700 italic">
                "{profile.certificationText}"
              </p>
            </div>

            <div className="pt-2 border-t border-stone-200 flex flex-col sm:flex-row sm:items-start justify-between gap-3 text-xs font-mono">
              <div className="min-w-0 flex-1 overflow-hidden space-y-2">
                <div>
                  <span className="text-[10px] text-stone-500 uppercase block tracking-wider font-sans font-semibold">
                    ECDSA Signature:
                  </span>
                  <div className="mt-1 p-2.5 rounded-lg bg-white border border-stone-200/80 font-mono text-xs text-stone-900 break-all select-all leading-relaxed shadow-2xs">
                    {profile.ecdsaSignature || profile.digitalSignature}
                  </div>
                </div>

                {profile.digitalSignature && profile.digitalSignature !== (profile.ecdsaSignature || profile.digitalSignature) && (
                  <div>
                    <span className="text-[10px] text-stone-500 uppercase block tracking-wider font-sans font-semibold">
                      {isFriendProfile ? 'Peer Attestation Sign-off:' : 'Statutory Regulatory Sign-off:'}
                    </span>
                    <div className="mt-1 p-2 rounded-lg bg-stone-50 border border-stone-200 font-mono text-xs text-stone-700 break-all select-all leading-relaxed">
                      {profile.digitalSignature}
                    </div>
                  </div>
                )}
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-stone-300 text-stone-600 text-[10px] flex items-center gap-2 shrink-0 self-start sm:self-center">
                <Hash className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                <span>Verification Hash: <strong className="break-all">{profile.filingAccessionNumber}</strong></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
