import React, { useEffect, useMemo, useState } from 'react';
import {
  X,
  ArrowDownLeft,
  Building2,
  CreditCard,
  Coins,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Wallet,
  AlertCircle,
  Loader2,
  Plus,
  Bitcoin,
  DollarSign,
} from 'lucide-react';
import { AuthSession } from '../../types/auth';
import { UserWalletData } from '../../types/wallet';
import { UniversalLedgerItem } from '../../types/ledger';
import {
  StripeSavedPaymentMethod,
  executeStripeCharge,
  getStripeConfigSafe,
  getStripePromise,
} from '../../services/stripeClientService';
import { verifyWalletSignatureOnServer } from '../../services/privyClientService';
import { applyCurrencyWalletDelta } from '../../utils/walletBalanceUpdater';
import { recordLedgerTransaction } from '../../utils/universalLedgerBridge';
import { dispatchGlobalNotification } from '../../utils/notificationService';
import {
  VerifiedCryptoWalletSummary,
  loadVerifiedPaymentSources,
} from '../../utils/paymentMethodsBridge';
import {
  calculateWalletPurchaseFee,
  formatInsufficientCurrencyError,
} from '../../utils/transactionFees';

export type DepositTargetAssetClass = 'fiat' | 'stable_coin' | 'crypto';

export interface DepositCompletionPayload {
  amountUSD: number;
  targetClass: DepositTargetAssetClass;
  targetCurrency: string;
  addedUnits: number;
  sourceLabel: string;
  methodType: string;
  paymentIntentId?: string;
}

interface AccountDepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBalance?: number;
  currentUser?: AuthSession | null;
  walletData: UserWalletData;
  verifiedBanks?: StripeSavedPaymentMethod[];
  verifiedCards?: StripeSavedPaymentMethod[];
  verifiedCryptoWallets?: VerifiedCryptoWalletSummary[];
  initialAssetClass?: DepositTargetAssetClass;
  initialCurrencyCode?: string;
  onOpenLinkMethod?: (type: 'bank' | 'card' | 'crypto') => void;
  onDepositCompleted?: (payload: DepositCompletionPayload) => void;
  onConfirmDeposit?: (amount: number, sourceLabel: string, methodType: string) => void;
}

interface CurrencyOption {
  code: string;
  name: string;
  symbol: string;
  currentUnits: number;
  unitPriceUSD: number;
  subtitle: string;
}

export const AccountDepositModal: React.FC<AccountDepositModalProps> = ({
  isOpen,
  onClose,
  currentBalance = 0,
  currentUser,
  walletData,
  verifiedBanks,
  verifiedCards,
  verifiedCryptoWallets,
  initialAssetClass = 'fiat',
  initialCurrencyCode = 'USD',
  onOpenLinkMethod,
  onDepositCompleted,
  onConfirmDeposit,
}) => {
  const userId = currentUser?.id || 'guest';

  const [targetClass, setTargetClass] = useState<DepositTargetAssetClass>(initialAssetClass);
  const [targetCurrency, setTargetCurrency] = useState<string>(initialCurrencyCode);
  const [depositAmountUSD, setDepositAmountUSD] = useState<string>('500');
  const [selectedSourceId, setSelectedSourceId] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Local state when verified props are not explicitly provided
  const [loadedBanks, setLoadedBanks] = useState<StripeSavedPaymentMethod[]>(verifiedBanks || []);
  const [loadedCards, setLoadedCards] = useState<StripeSavedPaymentMethod[]>(verifiedCards || []);
  const [loadedCryptos, setLoadedCryptos] = useState<VerifiedCryptoWalletSummary[]>(verifiedCryptoWallets || []);
  const [isLoadingSources, setIsLoadingSources] = useState(false);

  const effectiveBanks = verifiedBanks ?? loadedBanks;
  const effectiveCards = verifiedCards ?? loadedCards;
  const effectiveCryptos = verifiedCryptoWallets ?? loadedCryptos;

  useEffect(() => {
    if (!isOpen) return;
    setErrorMsg('');
    setTargetClass(initialAssetClass || 'fiat');
    setTargetCurrency((initialCurrencyCode || (initialAssetClass === 'stable_coin' ? 'USDC' : initialAssetClass === 'crypto' ? 'BTC' : 'USD')).toUpperCase());

    if (currentUser && (verifiedBanks === undefined || verifiedCards === undefined || verifiedCryptoWallets === undefined)) {
      setIsLoadingSources(true);
      loadVerifiedPaymentSources(currentUser)
        .then((res) => {
          setLoadedBanks(res.banks);
          setLoadedCards(res.cards);
          setLoadedCryptos(res.cryptoWallets);
        })
        .catch(() => {})
        .finally(() => setIsLoadingSources(false));
    }
  }, [isOpen, initialAssetClass, initialCurrencyCode, currentUser, verifiedBanks, verifiedCards, verifiedCryptoWallets]);

  // Build currency options per class strictly from currencies currently held (> 0 balance) in user's walletData
  const currencyOptionsByClass = useMemo<Record<DepositTargetAssetClass, CurrencyOption[]>>(() => {
    const fiatMap = new Map<string, CurrencyOption>();
    for (const f of walletData.fiatCurrencies || []) {
      const bal = Number(f.balance || 0);
      if (bal <= 0) continue;
      const code = f.code.trim().toUpperCase();
      fiatMap.set(code, {
        code,
        name: f.name,
        symbol: f.symbol,
        currentUnits: bal,
        unitPriceUSD: Number(f.exchangeRateToUSD || 1),
        subtitle: f.institution,
      });
    }

    const stableMap = new Map<string, CurrencyOption>();
    for (const s of walletData.stableCoins || []) {
      const bal = Number(s.balance || 0);
      if (bal <= 0) continue;
      const code = s.symbol.trim().toUpperCase();
      stableMap.set(code, {
        code,
        name: s.name,
        symbol: `${code} `,
        currentUnits: bal,
        unitPriceUSD: Number(s.unitPriceUSD || 1),
        subtitle: `${s.network} · ${s.yieldAPY}% APY`,
      });
    }

    const cryptoMap = new Map<string, CurrencyOption>();
    for (const c of walletData.cryptoCurrencies || []) {
      const bal = Number(c.balance || 0);
      if (bal <= 0) continue;
      const code = c.symbol.trim().toUpperCase();
      cryptoMap.set(code, {
        code,
        name: c.name,
        symbol: `${code} `,
        currentUnits: bal,
        unitPriceUSD: Number(c.unitPriceUSD || 1),
        subtitle: c.network,
      });
    }

    return {
      fiat: Array.from(fiatMap.values()),
      stable_coin: Array.from(stableMap.values()),
      crypto: Array.from(cryptoMap.values()),
    };
  }, [walletData]);

  const activeCurrencyList = currencyOptionsByClass[targetClass] || [];
  const selectedCurrencyObj =
    activeCurrencyList.find((c) => c.code === targetCurrency) || activeCurrencyList[0];

  useEffect(() => {
    if (!activeCurrencyList.some((c) => c.code === targetCurrency)) {
      setTargetCurrency(activeCurrencyList[0]?.code || '');
    }
  }, [targetClass, activeCurrencyList, targetCurrency]);

  // Internal USD & USDC balances available for conversion deposits
  const internalFundingBalances = useMemo(() => {
    const list: Array<{ id: string; label: string; symbol: string; units: number; unitPriceUSD: number; usdValue: number }> = [];
    for (const f of walletData.fiatCurrencies || []) {
      const code = f.code.trim().toUpperCase();
      if (f.balance > 0 && !(targetClass === 'fiat' && code === selectedCurrencyObj?.code)) {
        list.push({
          id: `internal-fiat-${code}`,
          label: `${f.name} (${code})`,
          symbol: code,
          units: f.balance,
          unitPriceUSD: f.exchangeRateToUSD || 1,
          usdValue: f.balance * (f.exchangeRateToUSD || 1),
        });
      }
    }
    for (const s of walletData.stableCoins || []) {
      const sym = s.symbol.trim().toUpperCase();
      if (s.balance > 0 && !(targetClass === 'stable_coin' && sym === selectedCurrencyObj?.code)) {
        list.push({
          id: `internal-stable-${sym}`,
          label: `${s.name} (${sym})`,
          symbol: sym,
          units: s.balance,
          unitPriceUSD: s.unitPriceUSD || 1,
          usdValue: s.balance * (s.unitPriceUSD || 1),
        });
      }
    }
    return list;
  }, [walletData, targetClass, selectedCurrencyObj?.code]);

  // Pick sensible default funding source when modal opens or verified methods load
  useEffect(() => {
    if (!isOpen) return;
    if (selectedSourceId) {
      const stillValid =
        effectiveBanks.some((b) => `stripe-${b.id}` === selectedSourceId) ||
        effectiveCards.some((c) => `stripe-${c.id}` === selectedSourceId) ||
        effectiveCryptos.some((w) => `wallet-${w.address.toLowerCase()}` === selectedSourceId) ||
        internalFundingBalances.some((i) => i.id === selectedSourceId);
      if (stillValid) return;
    }

    if (effectiveBanks.length > 0) {
      setSelectedSourceId(`stripe-${effectiveBanks[0].id}`);
    } else if (effectiveCards.length > 0) {
      setSelectedSourceId(`stripe-${effectiveCards[0].id}`);
    } else if (targetClass !== 'fiat' && effectiveCryptos.length > 0) {
      setSelectedSourceId(`wallet-${effectiveCryptos[0].address.toLowerCase()}`);
    } else if (internalFundingBalances.length > 0) {
      setSelectedSourceId(internalFundingBalances[0].id);
    } else {
      setSelectedSourceId('');
    }
  }, [isOpen, effectiveBanks, effectiveCards, effectiveCryptos, internalFundingBalances, targetClass, selectedSourceId]);

  if (!isOpen) return null;

  const parsedUSD = parseFloat(depositAmountUSD) || 0;
  const targetUnitPrice = Math.max(0.000001, selectedCurrencyObj?.unitPriceUSD || 1);
  const addedUnits = parsedUSD > 0 ? parsedUSD / targetUnitPrice : 0;
  const projectedUnits = (selectedCurrencyObj?.currentUnits || 0) + addedUnits;

  const isSelectedCard = Boolean(
    selectedSourceId.startsWith('stripe-') &&
      effectiveCards.some((c) => `stripe-${c.id}` === selectedSourceId)
  );
  const selectedCryptoWallet = selectedSourceId.startsWith('wallet-')
    ? effectiveCryptos.find((w) => `wallet-${w.address.toLowerCase()}` === selectedSourceId)
    : undefined;

  const selectedInternalFunding = internalFundingBalances.find((i) => i.id === selectedSourceId);

  let processingFeeUSD = 0;
  let feeDescriptionLabel = 'No processing fee';
  if (parsedUSD > 0 && isSelectedCard) {
    const stripeFee = calculateWalletPurchaseFee({
      category: 'fiat',
      subtotalUSD: parsedUSD,
      symbol: 'USD',
    });
    processingFeeUSD = stripeFee.feeUSD;
    feeDescriptionLabel = stripeFee.feeLabel;
  } else if (parsedUSD > 0 && selectedCryptoWallet) {
    const privyFee = calculateWalletPurchaseFee({
      category: targetClass === 'stable_coin' ? 'stable_coin' : 'crypto',
      subtotalUSD: parsedUSD,
      symbol: selectedCurrencyObj?.code || 'ETH',
      network: selectedCryptoWallet.network,
    });
    processingFeeUSD = privyFee.feeUSD;
    feeDescriptionLabel = privyFee.nativeUnits && privyFee.nativeSymbol
      ? `${privyFee.feeLabel} (~${privyFee.nativeUnits} ${privyFee.nativeSymbol})`
      : privyFee.feeLabel;
  } else if (parsedUSD > 0 && selectedInternalFunding) {
    const isStableSource = selectedInternalFunding.id.includes('stable');
    const internalFee = calculateWalletPurchaseFee({
      category: isStableSource ? 'stable_coin' : 'fiat',
      subtotalUSD: parsedUSD,
      symbol: selectedInternalFunding.symbol,
    });
    processingFeeUSD = internalFee.feeUSD;
    feeDescriptionLabel = internalFee.nativeUnits && internalFee.nativeSymbol
      ? `${internalFee.feeLabel} (~${internalFee.nativeUnits} ${internalFee.nativeSymbol})`
      : internalFee.feeLabel;
  }
  const totalChargedUSD = parsedUSD > 0 ? Math.round((parsedUSD + processingFeeUSD) * 100) / 100 : 0;

  const formatUnits = (val: number, cls: DepositTargetAssetClass) => {
    if (cls === 'crypto') {
      return val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 });
    }
    return val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const presetAmounts = [100, 500, 1000, 5000, 25000];

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (parsedUSD < 1) {
      setErrorMsg('Enter a deposit amount of at least $1.00 USD.');
      return;
    }
    if (!selectedCurrencyObj) {
      setErrorMsg('Select a destination currency.');
      return;
    }
    if (!selectedSourceId) {
      setErrorMsg('Link or select a verified bank account, payment card, or crypto wallet before depositing.');
      return;
    }

    setIsProcessing(true);

    try {
      let sourceLabel = '';
      let methodType = 'bank';
      let paymentIntentId: string | undefined;

      if (selectedSourceId.startsWith('stripe-')) {
        if (!currentUser) {
          throw new Error('Sign in to authorize deposits with a verified bank account or card.');
        }
        const pmId = selectedSourceId.replace('stripe-', '');
        const matchedBank = effectiveBanks.find((b) => b.id === pmId);
        const matchedCard = effectiveCards.find((c) => c.id === pmId);
        if (!matchedBank && !matchedCard) {
          throw new Error('Selected payment method is no longer verified on your account.');
        }

        const charge = await executeStripeCharge(currentUser, {
          paymentMethodId: pmId,
          amountUSD: totalChargedUSD,
          baseAmountUSD: parsedUSD,
          feeUSD: processingFeeUSD,
          purpose: 'deposit',
          targetAssetClass: targetClass,
          targetCurrencyCode: selectedCurrencyObj.code,
        });

        if (charge.requiresAction && charge.clientSecret) {
          const cfg = await getStripeConfigSafe();
          const stripe = await getStripePromise(cfg.publishableKey);
          if (!stripe) {
            throw new Error('Additional card verification is required, but Stripe checkout could not initialize.');
          }
          const confirmed = await stripe.confirmCardPayment(charge.clientSecret);
          if (confirmed.error) {
            throw new Error(confirmed.error.message || 'Card authentication failed.');
          }
        }

        paymentIntentId = charge.paymentIntentId;
        sourceLabel = charge.sourceLabel;
        methodType = charge.paymentMethodType === 'card' ? 'card' : 'bank';
      } else if (selectedSourceId.startsWith('wallet-')) {
        const addr = selectedSourceId.replace('wallet-', '');
        const matchedWallet = effectiveCryptos.find((w) => w.address.toLowerCase() === addr.toLowerCase());
        if (!matchedWallet) {
          throw new Error('Selected crypto wallet is not verified.');
        }

        // Verify ownership signature via browser wallet if available, otherwise require verified address match
        const eth = (window as unknown as { ethereum?: { request?: (args: { method: string; params?: unknown[] }) => Promise<unknown> } }).ethereum;
        if (eth?.request) {
          try {
            const challenge = `Authorize ${selectedCurrencyObj.code} treasury deposit of $${parsedUSD.toFixed(2)} USD + $${processingFeeUSD.toFixed(2)} network fee (Total $${totalChargedUSD.toFixed(2)})\nWallet: ${matchedWallet.address}\nTimestamp: ${new Date().toISOString()}`;
            const sig = (await eth.request({
              method: 'personal_sign',
              params: [challenge, matchedWallet.address],
            })) as string;
            await verifyWalletSignatureOnServer({
              address: matchedWallet.address,
              message: challenge,
              signature: sig,
            });
          } catch (walletErr: any) {
            if (walletErr?.code === 4001) {
              throw new Error('Wallet signature declined. Deposit was not processed.');
            }
          }
        }

        sourceLabel = `${matchedWallet.label} (${matchedWallet.address.slice(0, 6)}...${matchedWallet.address.slice(-4)})`;
        methodType = 'crypto';
      } else if (selectedSourceId.startsWith('internal-')) {
        const internalSource = internalFundingBalances.find((i) => i.id === selectedSourceId);
        if (!internalSource) {
          throw new Error('Selected internal treasury reserve is unavailable in your wallet.');
        }
        const debitUnits = totalChargedUSD / Math.max(0.000001, internalSource.unitPriceUSD);
        if (debitUnits > internalSource.units + 1e-6) {
          throw new Error(
            formatInsufficientCurrencyError({
              symbol: internalSource.symbol,
              name: internalSource.label,
              available: internalSource.units,
              required: debitUnits,
            })
          );
        }
        const debitRes = applyCurrencyWalletDelta({
          userId,
          currencySymbol: internalSource.symbol,
          currencyName: internalSource.label,
          delta: -debitUnits,
          requireSufficientBalance: true,
        });
        if (!debitRes.success) {
          throw new Error(
            debitRes.error ||
              formatInsufficientCurrencyError({
                symbol: internalSource.symbol,
                name: internalSource.label,
                available: internalSource.units,
                required: debitUnits,
              })
          );
        }
        sourceLabel = `${internalSource.label} Treasury Transfer`;
        methodType = internalSource.id.includes('stable') ? 'stable_coin' : 'fiat';
      } else {
        throw new Error('Select a valid verified funding source.');
      }

      // Credit destination currency in Asset Inventory
      const creditRes = applyCurrencyWalletDelta({
        userId,
        currencySymbol: selectedCurrencyObj.code,
        delta: addedUnits,
        currencyName: selectedCurrencyObj.name,
        unitPriceUSD: selectedCurrencyObj.unitPriceUSD,
      });

      if (!creditRes.success) {
        throw new Error(creditRes.error || 'Failed to credit destination currency.');
      }

      // Record Universal Ledger receipt
      try {
        const now = new Date();
        const randomHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
        const modeMap: UniversalLedgerItem['mode'] =
          targetClass === 'crypto' ? 'crypto' : targetClass === 'stable_coin' ? 'stable_coin' : 'fiat';
        const feeText = processingFeeUSD > 0 ? ` (incl. $${processingFeeUSD.toFixed(2)} ${feeDescriptionLabel}, Total $${totalChargedUSD.toFixed(2)})` : '';
        const ledgerItem: UniversalLedgerItem = {
          id: `tx-dep-${Date.now()}`,
          receiptNumber: `REC-${now.getFullYear()}-DP-${Math.floor(100000 + Math.random() * 900000)}`,
          timestamp: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} UTC`,
          dateIso: now.toISOString(),
          type: 'deposit',
          category: 'money_inflow',
          mode: modeMap,
          title: `${selectedCurrencyObj.code} Treasury Deposit (${formatUnits(addedUnits, targetClass)} ${selectedCurrencyObj.code})`,
          description: `Deposited $${parsedUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })} USD equivalent into ${selectedCurrencyObj.name} via ${sourceLabel}${feeText}${paymentIntentId ? ` [${paymentIntentId}]` : ''}.`,
          amountUSD: parsedUSD,
          feeUSD: processingFeeUSD,
          netAmountUSD: totalChargedUSD,
          sourceOrDestination: sourceLabel,
          counterpartyOrIssuer: 'Final Finance Treasury Clearing',
          paymentCoinSymbol: selectedCurrencyObj.code,
          paymentCoinAmount: Number(addedUnits.toFixed(6)),
          status: 'Audited',
          taxYear: now.getFullYear(),
          taxClassification: {
            taxableEvent: false,
            taxableAmountUSD: 0,
            formMapping: 'Non-Taxable Transfer',
            holdingPeriod: 'N/A',
            irsCategoryNote: 'Principal capital deposit into treasury account.',
          },
          cryptographicHash: `0x${randomHex}`,
          clearingNode: paymentIntentId ? `Stripe ${paymentIntentId}` : 'Sovereign Clearing Node #4810-CH',
          signature: `SIG_${Math.floor(100000 + Math.random() * 900000)}_VERIFIED`,
        };
        recordLedgerTransaction(userId, ledgerItem);
      } catch {
        // Non-fatal
      }

      dispatchGlobalNotification({
        title: `${selectedCurrencyObj.code} Deposit Cleared`,
        description: `Added ${formatUnits(addedUnits, targetClass)} ${selectedCurrencyObj.code} ($${parsedUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}${processingFeeUSD > 0 ? ` + $${processingFeeUSD.toFixed(2)} fee = $${totalChargedUSD.toFixed(2)} total` : ''}) via ${sourceLabel}.`,
        type: 'wallet',
        targetTab: 'asset_inventory',
        amount: totalChargedUSD,
        currency: selectedCurrencyObj.code,
        showToast: false,
        tone: 'success',
      });

      onDepositCompleted?.({
        amountUSD: parsedUSD,
        targetClass,
        targetCurrency: selectedCurrencyObj.code,
        addedUnits,
        sourceLabel,
        methodType,
        paymentIntentId,
      });

      // Legacy callback only if target is USD fiat (prevent double-crediting USD in callers that still add balance)
      if (!onDepositCompleted && onConfirmDeposit && targetClass === 'fiat' && selectedCurrencyObj.code === 'USD') {
        onConfirmDeposit(parsedUSD, sourceLabel, methodType);
      }

      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Unable to process deposit.');
    } finally {
      setIsProcessing(false);
    }
  };

  const hasAnyExternalSource = effectiveBanks.length > 0 || effectiveCards.length > 0 || effectiveCryptos.length > 0;

  return (
    <div
      id="account-deposit-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isProcessing) onClose();
      }}
    >
      <div
        id="account-deposit-modal-container"
        className="relative w-full max-w-xl rounded-2xl bg-white border border-slate-200 shadow-2xl overflow-hidden my-6 max-h-[92dvh] flex flex-col text-center"
      >
        {/* Header - Centered */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-center relative bg-slate-50 text-center">
          <div className="flex flex-col items-center justify-center gap-1.5 px-8">
            <div className="p-2 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700">
              <ArrowDownLeft className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                Deposit Funds to Asset Inventory
              </h2>
              <p className="text-xs text-slate-500">
                Fund Fiat, Stablecoin, or Crypto holdings using verified banks, cards &amp; wallets
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isProcessing}
            className="absolute right-4 top-4 p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleDepositSubmit} className="p-6 space-y-5 overflow-y-auto text-center">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center justify-center gap-2 text-center">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Destination Asset Class Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-800 block text-center">
              1. Destination Account Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'fiat' as const, label: 'Fiat', icon: DollarSign },
                { id: 'stable_coin' as const, label: 'Stable', icon: Coins },
                { id: 'crypto' as const, label: 'Crypto', icon: Bitcoin },
              ].map((cls) => {
                const Icon = cls.icon;
                const active = targetClass === cls.id;
                return (
                  <button
                    key={cls.id}
                    type="button"
                    onClick={() => setTargetClass(cls.id)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap ${
                      active
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{cls.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Target Currency Selector - Held Wallet Currencies Only */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-800 block text-center">
              2. Target Currency (Held in Wallet)
            </label>
            {activeCurrencyList.length === 0 ? (
              <div className="p-3 rounded-xl border border-dashed border-amber-300 bg-amber-50/70 text-xs text-amber-900">
                You do not hold any currencies with a positive balance in this category in your wallet.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 justify-center">
                {activeCurrencyList.map((cur) => {
                  const isSelected = cur.code === selectedCurrencyObj?.code;
                  return (
                    <button
                      key={cur.code}
                      type="button"
                      onClick={() => setTargetCurrency(cur.code)}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/70'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        <span className="text-xs font-bold font-mono text-slate-900">{cur.code}</span>
                        <span className="text-[10px] font-mono tabular-nums text-slate-500">
                          ${cur.unitPriceUSD.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <p className="text-[11px] font-mono tabular-nums text-slate-600 mt-1 truncate text-center">
                        {formatUnits(cur.currentUnits, targetClass)}
                      </p>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Deposit Amount + Live Conversion Banner */}
          <div className="space-y-2.5">
            <label className="text-xs font-bold text-slate-800 flex flex-col sm:flex-row items-center justify-center gap-1.5 text-center">
              <span>3. Deposit Amount (USD)</span>
              {selectedCurrencyObj && (
                <span className="text-[11px] font-mono tabular-nums text-slate-500">
                  1 {selectedCurrencyObj.code} = ${targetUnitPrice.toLocaleString(undefined, { maximumFractionDigits: 4 })}
                </span>
              )}
            </label>

            <div className="relative">
              <span className="absolute left-4 top-2.5 text-lg font-bold text-slate-400 font-mono">$</span>
              <input
                id="input-deposit-amount"
                type="number"
                min="1"
                step="any"
                value={depositAmountUSD}
                onChange={(e) => setDepositAmountUSD(e.target.value)}
                placeholder="0.00"
                className="w-full px-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-lg font-bold font-mono tabular-nums text-slate-900 text-center focus:outline-none focus:border-indigo-600 focus:bg-white transition-all"
                required
              />
            </div>

            <div className="grid grid-cols-5 gap-1.5">
              {presetAmounts.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setDepositAmountUSD(amt.toString())}
                  className={`py-1.5 px-2 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer border whitespace-nowrap ${
                    depositAmountUSD === amt.toString()
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  +${amt >= 1000 ? `${amt / 1000}k` : amt}
                </button>
              ))}
            </div>

            {selectedCurrencyObj && (
              <div className="p-3.5 rounded-xl bg-slate-900 text-white grid grid-cols-2 gap-3 text-center">
                <div className="text-center">
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">
                    Deposit Credits
                  </span>
                  <span className="text-sm sm:text-base font-bold font-mono tabular-nums text-emerald-400">
                    +{formatUnits(addedUnits, targetClass)} {selectedCurrencyObj.code}
                  </span>
                </div>
                <div className="text-center border-l border-slate-800 pl-3">
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">
                    New {selectedCurrencyObj.code} Balance
                  </span>
                  <span className="text-sm sm:text-base font-bold font-mono tabular-nums text-white">
                    {formatUnits(projectedUnits, targetClass)} {selectedCurrencyObj.code}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Funding Source Selection */}
          <div className="space-y-2.5">
            <div className="flex flex-col items-center justify-center gap-2 text-center">
              <label className="text-xs font-bold text-slate-800">
                4. Verified Funding Source
              </label>
              {onOpenLinkMethod && (
                <div className="flex items-center justify-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onOpenLinkMethod('bank')}
                    className="px-2 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Bank</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenLinkMethod('card')}
                    className="px-2 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Card</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenLinkMethod('crypto')}
                    className="px-2 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-[11px] font-semibold text-slate-700 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Wallet</span>
                  </button>
                </div>
              )}
            </div>

            {isLoadingSources ? (
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center gap-2 text-xs text-slate-500">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Loading verified banks, cards &amp; wallets...</span>
              </div>
            ) : !hasAnyExternalSource && internalFundingBalances.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-slate-300 bg-slate-50 text-center space-y-2.5">
                <p className="text-xs font-semibold text-slate-800">
                  No verified bank account, payment card, or crypto wallet linked yet.
                </p>
                <p className="text-[11px] text-slate-500">
                  Only verified accounts can be used to fund Asset Inventory.
                </p>
                {onOpenLinkMethod && (
                  <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => onOpenLinkMethod('bank')}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-black text-white text-xs font-bold cursor-pointer"
                    >
                      Link Bank Account
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenLinkMethod('card')}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold cursor-pointer"
                    >
                      Link Payment Card
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenLinkMethod('crypto')}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold cursor-pointer"
                    >
                      Verify Crypto Wallet
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                {/* Verified Stripe Bank Accounts */}
                {effectiveBanks.map((bank) => {
                  const id = `stripe-${bank.id}`;
                  return (
                    <label
                      key={bank.id}
                      className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                        selectedSourceId === id
                          ? 'border-indigo-600 bg-indigo-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-3">
                        <input
                          type="radio"
                          name="depositSource"
                          value={id}
                          checked={selectedSourceId === id}
                          onChange={() => setSelectedSourceId(id)}
                          className="accent-indigo-600"
                        />
                        <div className="p-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-700">
                          <Building2 className="w-4 h-4" />
                        </div>
                        <div className="text-center">
                          <span className="text-xs font-bold text-slate-900 block">
                            {bank.bankName || 'Verified Bank Account'}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">
                            {bank.accountType || 'checking'} ••••{bank.last4} · Verified ACH
                          </span>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-700 font-semibold">
                        Verified
                      </span>
                    </label>
                  );
                })}

                {/* Verified Stripe Payment Cards */}
                {effectiveCards.map((card) => {
                  const id = `stripe-${card.id}`;
                  return (
                    <label
                      key={card.id}
                      className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                        selectedSourceId === id
                          ? 'border-indigo-600 bg-indigo-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-3">
                        <input
                          type="radio"
                          name="depositSource"
                          value={id}
                          checked={selectedSourceId === id}
                          onChange={() => setSelectedSourceId(id)}
                          className="accent-indigo-600"
                        />
                        <div className="p-2 rounded-lg bg-purple-50 border border-purple-200 text-purple-700">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div className="text-center">
                          <span className="text-xs font-bold text-slate-900 block uppercase">
                            {card.brand || 'Card'} {card.funding || ''} ••••{card.last4}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">
                            Exp {String(card.expMonth || 1).padStart(2, '0')}/{card.expYear || '----'} · Instant Settlement
                          </span>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-700 font-semibold">
                        Verified
                      </span>
                    </label>
                  );
                })}

                {/* Verified Crypto Wallets */}
                {effectiveCryptos.map((wallet) => {
                  const id = `wallet-${wallet.address.toLowerCase()}`;
                  return (
                    <label
                      key={wallet.address}
                      className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                        selectedSourceId === id
                          ? 'border-indigo-600 bg-indigo-50/50'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-3">
                        <input
                          type="radio"
                          name="depositSource"
                          value={id}
                          checked={selectedSourceId === id}
                          onChange={() => setSelectedSourceId(id)}
                          className="accent-indigo-600"
                        />
                        <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-700">
                          <Wallet className="w-4 h-4" />
                        </div>
                        <div className="text-center">
                          <span className="text-xs font-bold text-slate-900 block">
                            {wallet.label}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500">
                            {wallet.address.slice(0, 8)}...{wallet.address.slice(-6)} · {wallet.network}
                          </span>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-700 font-semibold">
                        Verified
                      </span>
                    </label>
                  );
                })}

                {/* Internal Inventory Conversion Balances */}
                {internalFundingBalances.map((src) => (
                  <label
                    key={src.id}
                    className={`flex flex-col sm:flex-row items-center justify-between gap-2 p-3 rounded-xl border cursor-pointer transition-all text-center ${
                      selectedSourceId === src.id
                        ? 'border-indigo-600 bg-indigo-50/50'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-center gap-3">
                      <input
                        type="radio"
                        name="depositSource"
                        value={src.id}
                        checked={selectedSourceId === src.id}
                        onChange={() => setSelectedSourceId(src.id)}
                        className="accent-indigo-600"
                      />
                      <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div className="text-center">
                        <span className="text-xs font-bold text-slate-900 block">
                          Convert from {src.label}
                        </span>
                        <span className="text-[11px] font-mono tabular-nums text-slate-500">
                          Available: {src.units.toLocaleString(undefined, { maximumFractionDigits: 2 })} {src.symbol} (${src.usdValue.toLocaleString(undefined, { maximumFractionDigits: 2 })})
                        </span>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-slate-600 font-semibold">
                      Treasury
                    </span>
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Itemized Fee & Total Summary */}
          {parsedUSD > 0 && selectedSourceId && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs font-mono">
              <div className="flex items-center justify-between text-slate-600">
                <span>Deposit Credit Amount</span>
                <span>${parsedUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex items-center justify-between text-slate-600">
                <span>{feeDescriptionLabel}</span>
                <span className={processingFeeUSD > 0 ? 'text-amber-700 font-bold' : 'text-emerald-700 font-semibold'}>
                  {processingFeeUSD > 0 ? `+$${processingFeeUSD.toFixed(2)}` : '$0.00 (Free)'}
                </span>
              </div>
              <div className="pt-1.5 border-t border-slate-200 flex items-center justify-between text-slate-900 font-bold text-sm">
                <span>Total Charged</span>
                <span>${totalChargedUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD</span>
              </div>
            </div>
          )}

          {/* Security Footer */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center gap-2 text-[11px] text-slate-600 text-center">
            <Lock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>
              External charges authorize against your verified Stripe bank/card or wallet before crediting Asset Inventory.
            </span>
          </div>

          <div className="flex items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing || parsedUSD < 1 || !selectedSourceId || !selectedCurrencyObj}
              className="flex-2 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authorizing Deposit...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Deposit Total ${totalChargedUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ({selectedCurrencyObj?.code || 'Wallet'})
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
