import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Sparkles, 
  MessageSquare, 
  UserPlus, 
  UserCheck, 
  Clock, 
  Check, 
  Ban,
  Shield,
  ShieldCheck,
  Package, 
  Loader2, 
  Phone, 
  Video, 
  Share2, 
  CheckCircle2, 
  Camera, 
  Upload, 
  X, 
  Globe, 
  Users, 
  Lock, 
  Unlock,
  ShieldAlert,
  ChevronRight, 
  ArrowLeft,
  Coins,
  DollarSign,
  Tag,
  AlertCircle,
  Edit3,
  AtSign,
  Mail,
  FileText,
  Send,
  ArrowRightLeft,
  Receipt,
  HandCoins,
  Star,
  LayoutGrid,
  Building2,
  FolderHeart
} from 'lucide-react';
import { ProvideLoanModal } from './ProvideLoanModal';
import { AuthSession } from '../types/auth';
import { UserPublicProfile, RelationshipStatus, FriendGroup } from '../types/social';
import { getUserFriendGroups, updateFriendGroup } from '../services/friendGroupService';
import { MarketplaceListing } from '../types/marketplace';
import { UniversalLedgerItem } from '../types/ledger';
import { 
  getUserProfile, 
  getRelationshipStatus, 
  followUser, 
  unfollowUser, 
  sendFriendRequest, 
  cancelFriendRequest, 
  acceptFriendRequest, 
  removeFriend, 
  blockUser, 
  unblockUser,
  updateUserPublicProfile,
  getUserSocialCounts
} from '../services/socialService';
import { updateUserAccountProfile, checkUserIdAvailability, checkEmailAvailability } from '../services/firebaseAuth';
import { getUserListings } from '../services/marketplaceService';
import { PeerTransferModal } from './profile/PeerTransferModal';
import { getTransfersBetweenUsers, executeAdminTransfer } from '../utils/transferService';
import { recordLedgerTransaction } from '../utils/universalLedgerBridge';
import { UserRatingSection } from './profile/UserRatingSection';
import { getAverageRating } from '../services/ratingService';

interface UserProfileViewProps {
  userIdOrHandle: string;
  currentUser?: AuthSession | null;
  onUpdateSession?: (user: AuthSession) => void;
  onOpenDirectMessage: (targetUser: UserPublicProfile) => void;
  onOpenVoiceCall?: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }) => void;
  onOpenVideoCall?: (targetUser: { uid: string; userId: string; name: string; avatarUrl?: string }) => void;
  onNavigateBack?: () => void;
  onViewListingDetail?: (listing: MarketplaceListing) => void;
  onOpenVerificationModal?: () => void;
}

const PRESET_COVERS = [
  {
    id: 'gold-bullion',
    name: 'Gold Bullion Reserve',
    url: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'financial-district',
    name: 'Global Financial Center',
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'zurich-vault',
    name: 'Zurich Secure Depository',
    url: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'crypto-ledger',
    name: 'Quantum Ledger Core',
    url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dark-obsidian',
    name: 'Obsidian Silk Carbon',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80'
  }
];

const getBankInfo = (userId: string) => {
  const normId = userId.toLowerCase();
  if (normId.includes('satoshi')) {
    return {
      bankName: 'Neo Tokyo Trust',
      capacity: '125,000,000 AFNL',
      role: 'Sovereign Protocol Pioneer',
      description: 'Pioneer of Sovereign Digital Cash and Autonomous Multi-Asset Barter Networks. Specializing in cryptographic ledger consensus and decentralized consumer banking.'
    };
  }
  if (normId.includes('sterling') || normId.includes('swiss')) {
    return {
      bankName: 'Swiss Sovereign Reserve',
      capacity: '500,000,000 AFNL',
      role: 'Swiss Freeport Trustee',
      description: 'Sovereign Inter-Bank Clearing Node. Direct physical gold depository bullion backing, multi-signature trust structures.'
    };
  }
  if (normId.includes('jordan') || normId.includes('belfort')) {
    return {
      bankName: 'Wall Street Liquidity Partners',
      capacity: '250,000,000 AFNL',
      role: 'Escrow Lead & Vault Allocator',
      description: 'Active reserve market-making vault and bilateral sovereign escrow authority. Specializing in high-velocity liquidity allocation.'
    };
  }
  if (normId.includes('alex') || normId.includes('morgan')) {
    return {
      bankName: 'Zurich Freeport Clearing',
      capacity: '150,000,000 AFNL',
      role: 'Institutional Commodity Desk Arbiter',
      description: 'Precious metal clearing vault. Fully licensed and certified for gold bullion allocations, settlement audits, and sovereign clearing.'
    };
  }
  
  // Dynamic user-approved bank from localStorage
  const localBankName = localStorage.getItem(`ff_bank_app_name_${userId}`);
  if (localBankName) {
    return {
      bankName: localBankName,
      capacity: '100,000,000 AFNL',
      role: 'Approved Clearing Bank',
      description: 'Your authorized Clearing Bank. Authorized by Protocol Admin to issue sovereign credit, provide AFNL loans, and process settlement clearances.'
    };
  }

  return {
    bankName: 'Sovereign Reserve Vault',
    capacity: '50,000,000 AFNL',
    role: 'Licensed Banking Node',
    description: 'Licensed sovereign settlement node backed by multi-signature digital asset custody accounts.'
  };
};

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  userIdOrHandle,
  currentUser,
  onUpdateSession,
  onOpenDirectMessage,
  onOpenVoiceCall,
  onOpenVideoCall,
  onNavigateBack,
  onViewListingDetail,
  onOpenVerificationModal,
}) => {
  const [profile, setProfile] = useState<UserPublicProfile | null>(null);
  const [userListings, setUserListings] = useState<MarketplaceListing[]>([]);
  const [relationship, setRelationship] = useState<RelationshipStatus>({
    isFollowing: false,
    isFollower: false,
    isFriend: false,
    friendStatus: 'none',
    isBlocked: false,
    isBlockedByMe: false,
    isBlockedByTarget: false,
  });
  const [followersCount, setFollowersCount] = useState<number>(0);
  const [followingCount, setFollowingCount] = useState<number>(0);
  const [friendsCount, setFriendsCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isActionLoading, setIsActionLoading] = useState(false);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [saveToastMessage, setSaveToastMessage] = useState<string | null>(null);

  // Photo customization modal states
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [isCoverModalOpen, setIsCoverModalOpen] = useState(false);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [customCoverUrl, setCustomCoverUrl] = useState('');
  const [isSavingPhoto, setIsSavingPhoto] = useState(false);

  // Full Profile Edit Modal State
  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  const [editFullName, setEditFullName] = useState('');
  const [editUserId, setEditUserId] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');
  const [editCoverUrl, setEditCoverUrl] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [editErrorMessage, setEditErrorMessage] = useState('');
  const [userIdStatus, setUserIdStatus] = useState<{ available: boolean; message?: string }>({ available: true });
  const [emailStatus, setEmailStatus] = useState<{ available: boolean; message?: string }>({ available: true });

  // Peer-to-Peer Transfer Modal and Ledger History State
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [userTransfers, setUserTransfers] = useState<UniversalLedgerItem[]>([]);

  // Admin Transfer Modal State
  const [isAdminTransferModalOpen, setIsAdminTransferModalOpen] = useState(false);
  const [adminTransferAction, setAdminTransferAction] = useState<'add' | 'deduct'>('add');
  const [adminTransferSymbol, setAdminTransferSymbol] = useState<string>('AFNL');
  const [adminTransferAmount, setAdminTransferAmount] = useState<string>('1000');
  const [adminTransferReason, setAdminTransferReason] = useState<string>('Protocol Admin Sovereign Reserve Transfer');
  const [adminTransferSuccessMsg, setAdminTransferSuccessMsg] = useState<string | null>(null);
  const [adminTransferErrorMsg, setAdminTransferErrorMsg] = useState<string | null>(null);
  const [isAdminTransferLoading, setIsAdminTransferLoading] = useState<boolean>(false);
  const [showAdminTransferConfirm, setShowAdminTransferConfirm] = useState<boolean>(false);

  // General / Friend Group Management State for Profile
  const [profileGroups, setProfileGroups] = useState<FriendGroup[]>([]);
  const [isGroupManagementModalOpen, setIsGroupManagementModalOpen] = useState(false);

  useEffect(() => {
    if (profile) {
      const activeU = currentUser?.uid || currentUser?.id || 'guest';
      setProfileGroups(getUserFriendGroups(activeU));
    }
  }, [profile, currentUser]);

  const selectableProfileGroups = useMemo(() => {
    if (relationship.friendStatus === 'friends') {
      return profileGroups;
    }
    // If not friends, only show general groups
    return profileGroups.filter(g => g.groupType === 'general');
  }, [profileGroups, relationship.friendStatus]);

  const [groupErrorMsg, setGroupErrorMsg] = useState('');

  const handleToggleGroupMembership = (group: FriendGroup) => {
    if (!profile) return;
    const isMember = group.memberUids.includes(profile.uid);
    
    if (!isMember) {
      if (group.groupType === 'friend' && relationship.friendStatus !== 'friends') {
        setGroupErrorMsg('Non-friends can only be added to General Groups.');
        return;
      }
      
      const maxMembers = group.groupType === 'friend' ? 20 : 30;
      if (group.memberUids.length >= maxMembers) {
        setGroupErrorMsg(`A ${group.groupType === 'friend' ? 'Friend Group' : 'General Group'} is limited to ${maxMembers} people.`);
        return;
      }
    }
    
    setGroupErrorMsg('');
    const updatedUids = isMember
      ? group.memberUids.filter(id => id !== profile.uid)
      : [...group.memberUids, profile.uid];
    
    const updated = updateFriendGroup(group.id, { memberUids: updatedUids });
    if (updated) {
      const activeU = currentUser?.uid || currentUser?.id || 'guest';
      setProfileGroups(getUserFriendGroups(activeU));
    }
  };

  const handleExecuteAdminTransfer = () => {
    if (!profile) return;
    if (!viewerIsAdmin) {
      setAdminTransferErrorMsg('Unauthorized. Only Admins and Super Admins can execute Admin Transfers.');
      setShowAdminTransferConfirm(false);
      return;
    }
    const numAmt = parseFloat(adminTransferAmount);
    if (isNaN(numAmt) || numAmt <= 0) {
      setAdminTransferErrorMsg('Please enter a valid transfer amount greater than 0.');
      setShowAdminTransferConfirm(false);
      return;
    }

    if (!showAdminTransferConfirm) {
      setAdminTransferErrorMsg(null);
      setShowAdminTransferConfirm(true);
      return;
    }

    setIsAdminTransferLoading(true);
    setAdminTransferErrorMsg(null);
    setAdminTransferSuccessMsg(null);

    const symbolToUse = (adminTransferSymbol || 'AFNL').trim().toUpperCase();

    try {
      const res = executeAdminTransfer({
        adminId: currentUser?.uid || currentUser?.id || 'admin_operator',
        adminName: currentUser?.name || 'Protocol Admin',
        adminHandle: currentUser?.id || 'admin',
        targetUserId: profile.userId || profile.uid || targetId,
        targetName: profile.name,
        targetHandle: profile.userId,
        action: adminTransferAction,
        coinSymbol: symbolToUse,
        coinName: `${symbolToUse} Final Coin`,
        amount: numAmt,
        unitPriceUSD: 0,
        reason: adminTransferReason || 'Admin Sovereign Reserve Transfer'
      });

      if (!res.success) {
        setAdminTransferErrorMsg(res.error || 'Failed to execute admin transfer.');
        setIsAdminTransferLoading(false);
        setShowAdminTransferConfirm(false);
        return;
      }

      setAdminTransferSuccessMsg(
        `Successfully ${adminTransferAction === 'add' ? 'minted & credited' : 'deducted'} ${numAmt.toLocaleString()} ${symbolToUse} ${adminTransferAction === 'add' ? 'to' : 'from'} @${profile.userId}'s account balance. Recorded in Universal Ledger!`
      );
      
      if (currentUser) {
        const updatedTx = getTransfersBetweenUsers(currentUser.uid || currentUser.id || 'admin', profile.userId);
        setUserTransfers(updatedTx);
      }

      setShowAdminTransferConfirm(false);
      setTimeout(() => {
        setIsAdminTransferLoading(false);
      }, 300);
    } catch (err) {
      setAdminTransferErrorMsg('An error occurred while executing the admin transfer.');
      setIsAdminTransferLoading(false);
      setShowAdminTransferConfirm(false);
    }
  };

  // Quick Post Preview Modal (fallback when parent doesn't override)
  const [selectedPostPreview, setSelectedPostPreview] = useState<MarketplaceListing | null>(null);

  // Inter-Bank Loan State
  const [isProvideLoanModalOpen, setIsProvideLoanModalOpen] = useState(false);
  const [loanModalMode, setLoanModalMode] = useState<'provide' | 'ask'>('provide');

  // Rating State
  const [avgRating, setAvgRating] = useState({ average: 0, count: 0 });

  const [activeTab, setActiveTab] = useState<'profile' | 'posts'>('profile');

  const avatarFileInputRef = useRef<HTMLInputElement>(null);
  const coverFileInputRef = useRef<HTMLInputElement>(null);

  const [isDeactivated, setIsDeactivated] = useState<boolean>(false);

  const viewerIsAdmin = 
    currentUser?.role === 'admin' || 
    currentUser?.role === 'super_admin' || 
    currentUser?.email === 'ranmaanimaker@gmail.com' || 
    currentUser?.email === 'awesomedbz@gmail.com';
  const targetRole = profile?.role;
  const targetId = profile?.userId || 'guest_trader';
  const targetEmail = profile?.email;
  const isTargetAdminOrSuper = 
    targetRole === 'admin' || 
    targetRole === 'super_admin' ||
    targetId === 'super_admin_ranma' ||
    targetEmail === 'ranmaanimaker@gmail.com';

  const handleDeactivateAccount = () => {
    if (!profile) return;
    if (!viewerIsAdmin) {
      showToast('Unauthorized. Only Admins and Super Admins can deactivate user accounts.');
      return;
    }
    localStorage.setItem(`ff_user_deactivated_${profile.userId}`, 'true');
    localStorage.setItem(`ff_user_deactivated_${profile.uid}`, 'true');
    setIsDeactivated(true);

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-DEACT-${Math.floor(1000 + Math.random() * 9000)}`;

    const deactItem = {
      id: `rec-deact-${Date.now()}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'dividend',
      category: 'transfer',
      mode: 'final_coin',
      title: `Account Suspended by Protocol Guard`,
      description: `Clearing status deactivated on profile @${profile.userId} by System Administrator (@${currentUser?.id || 'admin'}). All ecosystem allocations are temporarily locked.`,
      amountUSD: 0,
      feeUSD: 0.00,
      netAmountUSD: 0.00,
      sourceOrDestination: `Sovereign Guard Security Desk`,
      counterpartyOrIssuer: `@${profile.userId}`,
      paymentCoinSymbol: 'AFNL',
      paymentCoinAmount: 0,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Administrative compliance suspension.'
      },
      signature: `SIG-DEACT-${Math.floor(100000 + Math.random() * 900000)}`
    };

    // Log to target user's ledger
    recordLedgerTransaction(profile.userId, deactItem as any);
    // Log to admin/super_admin ledgers
    recordLedgerTransaction('admin', deactItem as any);
    recordLedgerTransaction('super_admin', deactItem as any);

    // Notify components of ledger modifications
    window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

    showToast(`Account of @${profile.userId} has been suspended.`);
  };

  const handleReactivateAccount = () => {
    if (!profile) return;
    if (!viewerIsAdmin) {
      showToast('Unauthorized. Only Admins and Super Admins can reactivate user accounts.');
      return;
    }
    localStorage.removeItem(`ff_user_deactivated_${profile.userId}`);
    localStorage.removeItem(`ff_user_deactivated_${profile.uid}`);
    setIsDeactivated(false);

    const dateObj = new Date();
    const dateStr = dateObj.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    const recNum = `REC-REACT-${Math.floor(1000 + Math.random() * 9000)}`;

    const reactItem = {
      id: `rec-react-${Date.now()}`,
      receiptNumber: recNum,
      taxYear: 2026,
      timestamp: dateStr,
      dateIso: dateObj.toISOString(),
      type: 'deposit',
      category: 'transfer',
      mode: 'final_coin',
      title: `Account Reinstate Approved by Protocol Guard`,
      description: `Suspension revoked. Clearing status reactivated on profile @${profile.userId} by System Administrator (@${currentUser?.id || 'admin'}). All settlement privileges restored.`,
      amountUSD: 0,
      feeUSD: 0.00,
      netAmountUSD: 0.00,
      sourceOrDestination: `Sovereign Guard Security Desk`,
      counterpartyOrIssuer: `@${profile.userId}`,
      paymentCoinSymbol: 'AFNL',
      paymentCoinAmount: 0,
      taxClassification: {
        formMapping: 'Non-Taxable Transfer',
        taxableEvent: false,
        irsCategoryNote: 'Administrative compliance reinstatement.'
      },
      signature: `SIG-REACT-${Math.floor(100000 + Math.random() * 900000)}`
    };

    // Log to target user's ledger
    recordLedgerTransaction(profile.userId, reactItem as any);
    // Log to admin/super_admin ledgers
    recordLedgerTransaction('admin', reactItem as any);
    recordLedgerTransaction('super_admin', reactItem as any);

    // Notify components of ledger modifications
    window.dispatchEvent(new CustomEvent('final_finance_ledger_updated'));

    showToast(`Account of @${profile.userId} has been reactivated.`);
  };

  const activeUid = currentUser?.uid || currentUser?.id || 'guest';
  const isMe = profile ? profile.uid === activeUid || profile.userId.toLowerCase() === activeUid.toLowerCase() || (currentUser && currentUser.id.toLowerCase() === profile.userId.toLowerCase()) : false;
  const isBlockedOrDeactivated = relationship.isBlocked || isDeactivated;

  const myBankId = currentUser?.id || 'guest_trader';
  const targetBankId = profile?.userId || 'guest_trader';
  const amIABank = localStorage.getItem(`ff_bank_app_status_${myBankId}`) === 'approved';
  
  const checkIsViewedUserBank = () => {
    if (!profile) return false;
    const tid = targetBankId.toLowerCase();
    const handle = (profile.userId || '').toLowerCase();
    const isPreset = 
      tid.includes('satoshi') || handle.includes('satoshi') ||
      tid.includes('sterling') || handle.includes('sterling') ||
      tid.includes('belfort') || handle.includes('belfort') ||
      tid.includes('morgan') || handle.includes('morgan') ||
      tid === 'demo-satoshi-nakamoto' ||
      tid === 'user-lord_sterling' ||
      tid === 'demo-jordan-belfort' ||
      tid === 'demo-alex-morgan';
    
    return isPreset || localStorage.getItem(`ff_bank_app_status_${targetBankId}`) === 'approved' || localStorage.getItem(`ff_bank_app_status_${profile.uid}`) === 'approved';
  };
  
  const isViewedUserABank = checkIsViewedUserBank();
  const defaultCount = profile ? parseInt(localStorage.getItem(`ff_default_count_${targetBankId}`) || '0', 10) : 0;

  const reloadData = async () => {
    if (!userIdOrHandle) return;
    setIsLoading(true);
    let resolvedProfile = await getUserProfile(userIdOrHandle);

    if (!resolvedProfile && currentUser && (
      userIdOrHandle === currentUser.uid ||
      userIdOrHandle === currentUser.id ||
      userIdOrHandle.toLowerCase() === currentUser.id.toLowerCase()
    )) {
      const cleanBio = (currentUser.bio === 'Verified Google participant in Final Finance.' ? '' : currentUser.bio) || '';
      resolvedProfile = {
        uid: currentUser.uid || `user-${currentUser.id}`,
        userId: currentUser.id,
        name: currentUser.name,
        email: currentUser.email,
        avatarUrl: currentUser.avatarUrl,
        coverUrl: currentUser.coverUrl,
        bio: cleanBio,
        role: (currentUser.role as any) || 'user',
        createdAt: currentUser.createdAt || new Date().toISOString(),
        followersCount: 0,
        followingCount: 0,
        friendsCount: 0,
      };
    }

    if (resolvedProfile) {
      if (resolvedProfile.bio === 'Verified Google participant in Final Finance.') {
        resolvedProfile.bio = '';
      }
      const socialStats = getUserSocialCounts(resolvedProfile.uid, resolvedProfile);
      resolvedProfile.followersCount = socialStats.followersCount;
      resolvedProfile.followingCount = socialStats.followingCount;
      resolvedProfile.friendsCount = socialStats.friendsCount;

      setProfile(resolvedProfile);
      setCustomAvatarUrl(resolvedProfile.avatarUrl || '');
      setCustomCoverUrl(resolvedProfile.coverUrl || '');
      setFollowersCount(socialStats.followersCount);
      setFollowingCount(socialStats.followingCount);
      setFriendsCount(socialStats.friendsCount);

      const rel = await getRelationshipStatus(activeUid, resolvedProfile.uid);
      setRelationship(rel);

      // Fetch visible listings for this viewer
      const listings = getUserListings(
        resolvedProfile.userId,
        activeUid,
        rel.isFriend,
        currentUser?.id || currentUser?.uid
      );
      setUserListings(listings);

      // Load Peer Transfers from Universal Ledger
      const transfers = getTransfersBetweenUsers(activeUid, resolvedProfile.userId);
      setUserTransfers(transfers);

      // Load Ratings
      setAvgRating(getAverageRating(resolvedProfile.userId));

      // Load Deactivation Status
      const deac = localStorage.getItem(`ff_user_deactivated_${resolvedProfile.userId}`) === 'true' || 
                   localStorage.getItem(`ff_user_deactivated_${resolvedProfile.uid}`) === 'true';
      setIsDeactivated(deac);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    reloadData();
  }, [userIdOrHandle, activeUid, currentUser]);

  // Listen to ledger updates across the entire applet
  useEffect(() => {
    const handleLedgerUpdated = () => {
      if (profile) {
        setUserTransfers(getTransfersBetweenUsers(activeUid, profile.userId));
      }
    };
    window.addEventListener('final_finance_ledger_updated', handleLedgerUpdated);
    return () => {
      window.removeEventListener('final_finance_ledger_updated', handleLedgerUpdated);
    };
  }, [activeUid, profile]);

  const showToast = (msg: string) => {
    setSaveToastMessage(msg);
    setTimeout(() => {
      setSaveToastMessage(null);
    }, 3000);
  };

  const handleToggleFollow = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      if (relationship.isFollowing) {
        await unfollowUser(activeUid, profile.uid);
        setRelationship(prev => ({ ...prev, isFollowing: false }));
        setFollowersCount(prev => Math.max(0, prev - 1));
      } else {
        await followUser(activeUid, profile.uid);
        setRelationship(prev => ({ ...prev, isFollowing: true }));
        setFollowersCount(prev => prev + 1);
      }
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleSendFriendRequest = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await sendFriendRequest(activeUid, profile.uid);
      setRelationship(prev => ({ ...prev, friendStatus: 'pending_sent' }));
      showToast('Friend request sent');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleCancelFriendRequest = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await cancelFriendRequest(activeUid, profile.uid);
      setRelationship(prev => ({ ...prev, friendStatus: 'none' }));
      showToast('Friend request withdrawn');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleAcceptFriendRequest = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await acceptFriendRequest(activeUid, profile.uid);
      setRelationship(prev => ({ ...prev, friendStatus: 'friends', isFriend: true }));
      setFriendsCount(prev => prev + 1);
      showToast('Friend request accepted');
      // Reload listings since friends-only posts become visible
      reloadData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleRemoveFriend = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    if (window.confirm(`Are you sure you want to remove ${profile.name} from your friends?`)) {
      setIsActionLoading(true);
      try {
        await removeFriend(activeUid, profile.uid);
        setRelationship(prev => ({ ...prev, friendStatus: 'none', isFriend: false }));
        setFriendsCount(prev => Math.max(0, prev - 1));
        showToast('Friend removed');
        reloadData();
      } finally {
        setIsActionLoading(false);
      }
    }
  };

  const handleBlockUser = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await blockUser(activeUid, profile.uid);
      setRelationship(prev => ({
        ...prev,
        isBlocked: true,
        isBlockedByMe: true,
        isFollowing: false,
        isFriend: false,
        friendStatus: 'none',
      }));
      setShowBlockModal(false);
      showToast(`${profile.name} has been blocked`);
      reloadData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleUnblockUser = async () => {
    if (!profile || isActionLoading || !currentUser) return;
    setIsActionLoading(true);
    try {
      await unblockUser(activeUid, profile.uid);
      setRelationship(prev => ({
        ...prev,
        isBlocked: false,
        isBlockedByMe: false,
      }));
      showToast(`${profile.name} unblocked`);
      reloadData();
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleShareProfile = async () => {
    const url = window.location.href;
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(url);
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2500);
      }
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setCustomAvatarUrl(reader.result);
          setEditAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCoverFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setCustomCoverUrl(reader.result);
          setEditCoverUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setEditAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setEditCoverUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveAvatar = async () => {
    if (!profile || !customAvatarUrl) return;
    setIsSavingPhoto(true);
    try {
      updateUserPublicProfile(profile.uid, { avatarUrl: customAvatarUrl });
      if (currentUser && isMe && onUpdateSession) {
        const res = await updateUserAccountProfile({
          fullName: currentUser.name || profile.name,
          userId: currentUser.id || profile.userId,
          avatarUrl: customAvatarUrl,
        });
        if (res.success && res.user) onUpdateSession(res.user);
      }
      setProfile(prev => prev ? { ...prev, avatarUrl: customAvatarUrl } : null);
      setIsAvatarModalOpen(false);
      showToast('Profile photo updated');
    } finally {
      setIsSavingPhoto(false);
    }
  };

  const handleSaveCover = async () => {
    if (!profile || !customCoverUrl) return;
    setIsSavingPhoto(true);
    try {
      updateUserPublicProfile(profile.uid, { coverUrl: customCoverUrl });
      if (currentUser && isMe && onUpdateSession) {
        const res = await updateUserAccountProfile({
          fullName: currentUser.name || profile.name,
          userId: currentUser.id || profile.userId,
          coverUrl: customCoverUrl,
        });
        if (res.success && res.user) onUpdateSession(res.user);
      }
      setProfile(prev => prev ? { ...prev, coverUrl: customCoverUrl } : null);
      setIsCoverModalOpen(false);
      showToast('Cover photo updated');
    } finally {
      setIsSavingPhoto(false);
    }
  };

  const openEditProfileModal = () => {
    if (!profile) return;
    const currentName = profile.name || currentUser?.name || '';
    const currentId = profile.userId || currentUser?.id || '';
    const currentMail = profile.email || currentUser?.email || '';
    const currentBioText = profile.bio || currentUser?.bio || '';
    const currentAv = profile.avatarUrl || currentUser?.avatarUrl || '';
    const currentCov = profile.coverUrl || currentUser?.coverUrl || '';

    setEditFullName(currentName);
    setEditUserId(currentId);
    setEditEmail(currentMail);
    setEditBio(currentBioText);
    setEditAvatarUrl(currentAv);
    setEditCoverUrl(currentCov);
    setEditErrorMessage('');
    setUserIdStatus(checkUserIdAvailability(currentId, currentUser?.id));
    setEmailStatus(checkEmailAvailability(currentMail, currentUser?.email));
    setIsEditProfileModalOpen(true);
  };

  const handleEditUserIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const clean = e.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, '');
    setEditUserId(clean);
    const res = checkUserIdAvailability(clean, currentUser?.id);
    setUserIdStatus(res);
  };

  const handleEditEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.trim();
    setEditEmail(val);
    const res = checkEmailAvailability(val, currentUser?.email);
    setEmailStatus(res);
  };

  const handleSaveProfileChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editFullName.trim()) {
      setEditErrorMessage('Full Name is required.');
      return;
    }
    if (!editUserId.trim()) {
      setEditErrorMessage('User ID handle is required.');
      return;
    }
    
    // Check User ID availability
    const idCheck = checkUserIdAvailability(editUserId, currentUser?.id);
    if (!idCheck.available) {
      setEditErrorMessage(idCheck.message || 'User ID is unavailable.');
      return;
    }

    // Check Email availability if entered
    if (editEmail.trim()) {
      const emailCheck = checkEmailAvailability(editEmail, currentUser?.email);
      if (!emailCheck.available) {
        setEditErrorMessage(emailCheck.message || 'Email address is unavailable.');
        return;
      }
    }

    setIsSavingProfile(true);
    setEditErrorMessage('');

    try {
      const cleanUid = profile?.uid || (currentUser ? (currentUser.uid || `user-${currentUser.id}`) : `user-${editUserId}`);
      const cleanHandle = editUserId.trim().toLowerCase().replace(/^@/, '');
      const cleanMail = editEmail.trim().toLowerCase();

      // 1. Update public social profile in directory
      const updatedPublic = await updateUserPublicProfile(cleanUid, {
        name: editFullName.trim(),
        userId: cleanHandle,
        email: cleanMail,
        bio: editBio, // Unlimited bio text
        avatarUrl: editAvatarUrl.trim(),
        coverUrl: editCoverUrl.trim(),
      });

      // 2. Update account session & registry
      if (isMe) {
        const res = await updateUserAccountProfile({
          fullName: editFullName.trim(),
          userId: cleanHandle,
          email: cleanMail,
          bio: editBio, // Unlimited bio text
          avatarUrl: editAvatarUrl.trim(),
          coverUrl: editCoverUrl.trim(),
        });

        if (res.success && res.user) {
          if (onUpdateSession) {
            onUpdateSession(res.user);
          }
          setProfile(prev => prev ? {
            ...prev,
            name: res.user!.name,
            userId: res.user!.id,
            email: res.user!.email,
            bio: res.user!.bio || '',
            avatarUrl: res.user!.avatarUrl || '',
            coverUrl: res.user!.coverUrl || '',
          } : updatedPublic);
          setCustomAvatarUrl(res.user.avatarUrl || '');
          setCustomCoverUrl(res.user.coverUrl || '');
        } else if (!res.success) {
          setEditErrorMessage(res.error || 'Failed to update user profile.');
          return;
        }
      } else {
        setProfile(updatedPublic);
      }

      setIsEditProfileModalOpen(false);
      showToast('Profile updated successfully');
    } catch (err: any) {
      setEditErrorMessage(err?.message || 'Error saving profile modifications');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleCardClick = (listing: MarketplaceListing) => {
    if (onViewListingDetail) {
      onViewListingDetail(listing);
    } else {
      setSelectedPostPreview(listing);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
        <Loader2 className="w-8 h-8 animate-spin text-neutral-900" />
        <p className="text-sm font-medium text-neutral-500">Loading sovereign profile...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="bg-white border border-neutral-200/90 rounded-3xl p-8 sm:p-12 text-center max-w-lg mx-auto space-y-4 shadow-sm">
        <div className="w-12 h-12 rounded-full bg-neutral-100 text-neutral-400 flex items-center justify-center mx-auto">
          <User className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-bold text-neutral-900">Member Not Found</h2>
        <p className="text-xs text-neutral-500">
          The requested member handle "@{userIdOrHandle}" does not exist in the depository network.
        </p>
        {onNavigateBack && (
          <div className="pt-2">
            <button
              type="button"
              onClick={onNavigateBack}
              className="px-4 py-2 bg-neutral-900 hover:bg-black text-white text-xs font-semibold rounded-xl cursor-pointer transition-colors"
            >
              Go Back
            </button>
          </div>
        )}
      </div>
    );
  }

  // If this user has blocked the current viewer, enforce complete privacy restriction
  if (relationship.isBlockedByTarget && !isMe) {
    return (
      <div className="bg-white border border-neutral-200/90 rounded-3xl p-8 sm:p-12 text-center max-w-lg mx-auto space-y-4 shadow-sm my-8">
        <div className="w-14 h-14 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto">
          <Ban className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-neutral-900 font-serif-lux">Profile Unavailable</h2>
        <p className="text-xs sm:text-sm text-neutral-500 max-w-md mx-auto leading-relaxed">
          You cannot view this profile, send direct messages, initiate calls, or browse listings for @{profile.userId} due to privacy restrictions or account blocking.
        </p>
        {onNavigateBack && (
          <div className="pt-3">
            <button
              type="button"
              onClick={onNavigateBack}
              className="px-5 py-2.5 bg-neutral-950 hover:bg-black text-white text-xs font-semibold rounded-xl cursor-pointer transition-colors shadow-2xs inline-flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Marketplace</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  const coverImage = profile.coverUrl || customCoverUrl;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="space-y-6 max-w-5xl mx-auto pb-12"
    >
      {/* Top Navigation Row: Back Button & Rating Star for Posts & Listings */}
      {(onNavigateBack || activeTab === 'posts') && (
        <div className="relative flex items-center justify-between min-h-[40px]">
          <div className="flex items-center gap-3">
            {onNavigateBack && (
              <button
                type="button"
                onClick={onNavigateBack}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-neutral-100 border border-neutral-200 text-neutral-800 text-xs font-semibold shadow-2xs transition-all hover:shadow-xs cursor-pointer group z-10"
              >
                <ArrowLeft className="w-4 h-4 text-neutral-500 group-hover:-translate-x-0.5 group-hover:text-black transition-transform" />
                <span>Back</span>
              </button>
            )}

            {/* Rating star on Posts & Listings page, on the top, next to back, indented right */}
            {activeTab === 'posts' && (
              <div
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-neutral-200/90 shadow-2xs text-xs font-semibold text-neutral-800 ml-2"
                title={`${profile?.name || 'Member'}'s Rating: ${avgRating.count > 0 ? avgRating.average.toFixed(1) : '0.0'} / 5.0 (${avgRating.count} reviews)`}
              >
                <div className="flex items-center gap-1.5 text-amber-500">
                  <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                  <span className="font-bold text-neutral-900 font-mono text-sm">
                    {avgRating.count > 0 ? avgRating.average.toFixed(1) : '0.0'}
                  </span>
                </div>
                <span className="text-neutral-400 font-mono text-[11px]">
                  ({avgRating.count} {avgRating.count === 1 ? 'Rating' : 'Ratings'})
                </span>
              </div>
            )}
          </div>

          <div className="w-16" aria-hidden="true" />
        </div>
      )}

      {/* Toast Notification */}
      <AnimatePresence>
        {saveToastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 bg-neutral-950 text-white border border-neutral-800 px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-medium"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{saveToastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ================= TABS NAVIGATION (CENTERED) ================= */}
      <div className="flex items-center justify-center gap-1 p-1 bg-neutral-100 rounded-2xl w-fit mx-auto mb-2">
        <button
          onClick={() => setActiveTab('profile')}
          className={`h-10 px-6 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'profile'
              ? 'bg-white text-neutral-950 shadow-sm'
              : 'text-neutral-500 hover:text-neutral-700 font-medium'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile</span>
        </button>
        <button
          onClick={() => setActiveTab('posts')}
          className={`h-10 px-6 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'posts'
              ? 'bg-white text-neutral-950 shadow-sm'
              : 'text-neutral-500 hover:text-neutral-700 font-medium'
          }`}
        >
          <LayoutGrid className="w-4 h-4" />
          <span>Posts & Listings</span>
          {userListings.length > 0 && (
            <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${
              activeTab === 'posts' ? 'bg-neutral-100 text-neutral-900' : 'bg-neutral-200 text-neutral-600'
            }`}>
              {userListings.length}
            </span>
          )}
        </button>
      </div>

      {activeTab === 'profile' ? (
        <div className="space-y-6">
          {/* ================= PROFILE HERO BANNER & AVATAR ================= */}
          <div className="bg-white border border-neutral-200/90 rounded-3xl overflow-hidden shadow-2xs">
        {/* Cover Backdrop */}
        <div 
          className="relative h-44 sm:h-56 w-full bg-neutral-900 bg-cover bg-center transition-all duration-300"
          style={{
            backgroundImage: coverImage
              ? `linear-gradient(to bottom, rgba(0,0,0,0.15), rgba(0,0,0,0.7)), url(${coverImage})`
              : 'linear-gradient(to right, #171717, #262626, #0a0a0a)'
          }}
        >
          {/* Cover Edit Button (Owner Only) */}
          {isMe && (
            <button
              type="button"
              onClick={() => setIsCoverModalOpen(true)}
              className="absolute top-3 right-3 sm:top-4 sm:right-4 h-8 px-3 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white text-[11px] font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm active:scale-[0.98]"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Edit Cover</span>
            </button>
          )}
        </div>

        {/* Profile Card Main Info */}
        <div className="px-4 sm:px-8 pb-6 pt-0 relative flex flex-col items-center text-center">
          <div className="-mt-16 sm:-mt-20 mb-4 flex justify-center">
            {/* Avatar */}
            <div className="relative inline-block">
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-neutral-950 border-4 border-white shadow-md overflow-hidden flex items-center justify-center text-white text-4xl font-bold font-serif-lux group">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl}
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  profile.name.charAt(0).toUpperCase()
                )}
              </div>

              {/* Avatar Edit Overlay (Owner Only) */}
              {isMe && (
                <button
                  type="button"
                  onClick={() => setIsAvatarModalOpen(true)}
                  className="absolute bottom-1 right-1 p-2 rounded-full bg-neutral-900 text-white border-2 border-white shadow-md hover:bg-black transition-colors cursor-pointer"
                  title="Change avatar"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* User Identity Details (Centered) */}
          <div className="space-y-3 w-full flex flex-col items-center text-center">
            {/* Name on top, User ID underneath, both indented in the center */}
            <div className="flex flex-col items-center text-center w-full space-y-1">
              <h1 className="text-xl sm:text-2xl font-black text-neutral-900 tracking-tight font-serif-lux text-center">
                {profile.name}
              </h1>
              <span className="text-xs sm:text-sm font-mono text-neutral-500 font-medium text-center">
                @{profile.userId}
              </span>
            </div>

            {/* Share Profile, Edit Profile, and Verified Status Buttons (Centered, No Transfer Money on own profile) */}
            <div className="flex flex-wrap items-center justify-center gap-2.5 pt-0.5">
              {/* Edit Profile Button (For Profile Owner) */}
              {isMe && (
                <button
                  type="button"
                  onClick={openEditProfileModal}
                  className="h-9 px-3.5 rounded-full bg-neutral-950 hover:bg-black text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs whitespace-nowrap active:scale-[0.98]"
                >
                  <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Edit Profile</span>
                </button>
              )}

              {/* Share Profile Button */}
              <button
                type="button"
                onClick={handleShareProfile}
                className="h-9 px-3.5 rounded-full bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 text-neutral-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap active:scale-[0.98]"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Link Copied</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5 text-neutral-600 shrink-0" />
                    <span>Share Profile</span>
                  </>
                )}
              </button>

              {/* Verified Status Button */}
              {isMe ? (
                currentUser?.isVerified ? (
                  <button
                    type="button"
                    onClick={onOpenVerificationModal}
                    className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer shadow-2xs whitespace-nowrap"
                  >
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Verified Citizen</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onOpenVerificationModal}
                    className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-50 text-amber-900 text-xs font-semibold border border-amber-300 hover:bg-amber-100 transition-colors cursor-pointer shadow-2xs whitespace-nowrap"
                  >
                    <Shield className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Get Verified ($2/mo)</span>
                  </button>
                )
              ) : (
                <>
                  <div className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-neutral-100 text-neutral-600 text-xs font-semibold border border-neutral-200 whitespace-nowrap">
                    <ShieldCheck className="w-4 h-4 text-neutral-400 shrink-0" />
                    <span>Member</span>
                  </div>

                  {relationship.isFriend && (
                    <div className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold border border-blue-200 whitespace-nowrap">
                      <UserCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span>Mutual Friend</span>
                    </div>
                  )}

                  {relationship.isBlocked && (
                    <div className="h-9 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-red-50 text-red-700 text-xs font-semibold border border-red-200 whitespace-nowrap">
                      <Ban className="w-3.5 h-3.5 text-red-600 shrink-0" />
                      <span>User Blocked</span>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Bio (Supports full descriptions with no arbitrary limit, Centered) */}
            {profile.bio ? (
              <p className="text-xs sm:text-sm text-neutral-700 max-w-2xl mx-auto leading-relaxed pt-1 whitespace-pre-wrap text-center">
                {profile.bio}
              </p>
            ) : isMe ? (
              <button
                type="button"
                onClick={openEditProfileModal}
                className="text-xs text-neutral-400 hover:text-neutral-700 italic pt-1 flex items-center justify-center gap-1.5 cursor-pointer transition-colors mx-auto"
              >
                <Edit3 className="w-3.5 h-3.5 text-amber-600" />
                <span>Add a bio about yourself...</span>
              </button>
            ) : null}

            {/* Blocked by Me Notification Banner */}
            {relationship.isBlocked && !isMe && (
              <div className="p-3.5 bg-red-50/90 border border-red-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs text-red-800 text-left w-full">
                <div className="flex items-center gap-2">
                  <Ban className="w-4 h-4 text-red-600 shrink-0" />
                  <span>You have blocked @{profile.userId}. They cannot view your profile, direct message you, or call you.</span>
                </div>
                <button
                  type="button"
                  onClick={handleUnblockUser}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shrink-0 cursor-pointer transition-colors"
                >
                  Unblock Member
                </button>
              </div>
            )}

            {/* Social Network Counters (Centered) */}
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 pt-2.5 text-xs text-neutral-600 border-t border-neutral-100 w-full">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-neutral-900 font-mono text-sm">
                  {friendsCount.toLocaleString()}
                </span>
                <span>Friends</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-neutral-900 font-mono text-sm">
                  {followersCount.toLocaleString()}
                </span>
                <span>Followers</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-neutral-900 font-mono text-sm">
                  {followingCount.toLocaleString()}
                </span>
                <span>Following</span>
              </div>
            </div>

            {/* Action Rows For Other Users (MOVED UP) */}
            {!isMe && (
              <div className="mt-6 pt-4 border-t border-neutral-100 space-y-3 flex flex-col items-center">
                {/* Line 1: Follow, Friend status, and Block / Unblock Member */}
                <div className="flex flex-wrap items-center justify-center gap-2.5 w-full">
                  {/* Follow / Unfollow */}
                  <button
                    type="button"
                    onClick={handleToggleFollow}
                    disabled={isActionLoading || isBlockedOrDeactivated}
                    className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all ${
                      isBlockedOrDeactivated
                        ? 'bg-neutral-100 text-neutral-400 border-neutral-200 cursor-not-allowed opacity-50'
                        : relationship.isFollowing
                        ? 'bg-neutral-100 hover:bg-neutral-200 border-neutral-300 text-neutral-800 cursor-pointer active:scale-[0.98]'
                        : 'bg-white hover:bg-neutral-50 border-neutral-300 text-neutral-900 cursor-pointer active:scale-[0.98]'
                    }`}
                  >
                    {relationship.isFollowing ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-neutral-600" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5 text-neutral-600" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>

                  {/* Friend Actions (disabled if blocked or deactivated) */}
                  {!isBlockedOrDeactivated && (
                    <>
                      {relationship.friendStatus === 'none' && (
                        <button
                          type="button"
                          onClick={handleSendFriendRequest}
                          disabled={isActionLoading}
                          className="min-h-[40px] px-4 py-2 rounded-xl bg-white hover:bg-neutral-50 border border-neutral-300 text-neutral-900 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all active:scale-[0.98]"
                        >
                          <UserPlus className="w-3.5 h-3.5 text-blue-600" />
                          <span>Add</span>
                        </button>
                      )}

                      {relationship.friendStatus === 'pending_sent' && (
                        <button
                          type="button"
                          onClick={handleCancelFriendRequest}
                          disabled={isActionLoading}
                          className="min-h-[40px] px-4 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                        >
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          <span>Request Sent</span>
                        </button>
                      )}

                      {relationship.friendStatus === 'pending_received' && (
                        <button
                          type="button"
                          onClick={handleAcceptFriendRequest}
                          disabled={isActionLoading}
                          className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Accept Request</span>
                        </button>
                      )}

                      {relationship.friendStatus === 'friends' && (
                        <button
                          type="button"
                          onClick={handleRemoveFriend}
                          disabled={isActionLoading}
                          className="min-h-[40px] px-3.5 py-2 rounded-xl bg-neutral-100 hover:bg-red-50 hover:text-red-700 hover:border-red-200 border border-neutral-200 text-neutral-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                          title="Click to remove from friends"
                        >
                          <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                          <span>Friends</span>
                        </button>
                      )}
                    </>
                  )}

                  {/* Block / Unblock Member */}
                  {relationship.isBlocked ? (
                    <button
                      type="button"
                      onClick={handleUnblockUser}
                      disabled={isActionLoading}
                      className="min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer text-red-700 bg-red-50 hover:bg-red-100 border border-red-200"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Unblock</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowBlockModal(true)}
                      disabled={isActionLoading}
                      className="min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer text-neutral-600 hover:text-red-600 hover:bg-red-50 border border-neutral-200 bg-white"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>Block</span>
                    </button>
                  )}
                </div>

                {/* Line 2: Loan, Transfer, Message, Voice, Video */}
                <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1 w-full">
                  {/* Provide Loan (Admin/SuperAdmin Only) */}
                  {viewerIsAdmin && (
                    <button
                      type="button"
                      onClick={() => !isBlockedOrDeactivated && setIsProvideLoanModalOpen(true)}
                      disabled={isBlockedOrDeactivated}
                      className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                        isBlockedOrDeactivated
                          ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                          : 'bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow-2xs active:scale-[0.98]'
                      }`}
                      title={isDeactivated ? 'Sovereign clearing deactivated' : relationship.isBlocked ? 'Loan disabled (Blocked)' : `Provide loan to @${profile.userId}`}
                    >
                      <HandCoins className="w-3.5 h-3.5" />
                      <span>Provide Loan</span>
                    </button>
                  )}

                  {/* Transfer Money Button */}
                  <button
                    type="button"
                    onClick={() => !isBlockedOrDeactivated && setIsTransferModalOpen(true)}
                    disabled={isBlockedOrDeactivated}
                    className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                      isBlockedOrDeactivated
                        ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer shadow-2xs active:scale-[0.98]'
                    }`}
                    title={isDeactivated ? 'Sovereign clearing deactivated' : relationship.isBlocked ? 'Transfers disabled (Blocked)' : `Transfer funds to @${profile.userId}`}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Transfer Money</span>
                  </button>

                  {/* Direct Message (Icon Only) */}
                  <button
                    type="button"
                    onClick={() => !isBlockedOrDeactivated && onOpenDirectMessage(profile)}
                    disabled={isBlockedOrDeactivated}
                    title={isDeactivated ? 'Sovereign actor deactivated' : relationship.isBlocked ? 'Messaging disabled (Blocked)' : `Message @${profile.userId}`}
                    aria-label={`Send direct message to ${profile.name}`}
                    className={`min-h-[40px] min-w-[40px] px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center transition-all ${
                      isBlockedOrDeactivated
                        ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed border border-neutral-200 opacity-50'
                        : 'bg-neutral-950 hover:bg-neutral-800 text-white cursor-pointer shadow-2xs active:scale-[0.98]'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>

                  {/* Voice Call */}
                  {onOpenVoiceCall && (
                    <button
                      type="button"
                      onClick={() => !isBlockedOrDeactivated && onOpenVoiceCall({ uid: profile.uid, userId: profile.userId, name: profile.name, avatarUrl: profile.avatarUrl })}
                      disabled={isBlockedOrDeactivated}
                      className={`min-h-[40px] px-4 py-2 rounded-xl border text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                        isBlockedOrDeactivated
                          ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                          : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800 cursor-pointer active:scale-[0.98]'
                      }`}
                      title={isDeactivated ? 'Voice call disabled (Deactivated)' : relationship.isBlocked ? 'Voice call disabled (Blocked)' : 'Voice Call'}
                    >
                      <Phone className="w-3.5 h-3.5 text-neutral-600" />
                      <span>Voice</span>
                    </button>
                  )}

                  {/* Video Call */}
                  {onOpenVideoCall && (
                    <button
                      type="button"
                      onClick={() => !isBlockedOrDeactivated && onOpenVideoCall({ uid: profile.uid, userId: profile.userId, name: profile.name, avatarUrl: profile.avatarUrl })}
                      disabled={isBlockedOrDeactivated}
                      className={`min-h-[40px] px-4 py-2 rounded-xl border text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                        isBlockedOrDeactivated
                          ? 'opacity-40 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                          : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800 cursor-pointer active:scale-[0.98]'
                      }`}
                      title={isDeactivated ? 'Video call disabled (Deactivated)' : relationship.isBlocked ? 'Video call disabled (Blocked)' : 'Video Call'}
                    >
                      <Video className="w-3.5 h-3.5 text-neutral-600" />
                      <span>Video</span>
                    </button>
                  )}
                </div>

                {/* Group Button directly below message, voice call, and video call */}
                <div className="flex items-center justify-center pt-1.5 w-full">
                  <button
                    type="button"
                    onClick={() => setIsGroupManagementModalOpen(true)}
                    className="min-h-[38px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer border border-neutral-200 transition-colors shadow-2xs active:scale-[0.98]"
                    title="Group assignment (no friendship required)"
                  >
                    <FolderHeart className="w-3.5 h-3.5 text-emerald-600" />
                    <span>General Group</span>
                    {profileGroups.filter(g => g.memberUids.includes(profile.uid)).length > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-mono font-bold">
                        {profileGroups.filter(g => g.memberUids.includes(profile.uid)).length}
                      </span>
                    )}
                  </button>
                </div>

                {/* Line 3: Banking Operations */}
                {(!relationship.isBlocked && (amIABank || isViewedUserABank || defaultCount > 0)) && (
                  <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1 w-full border-t border-neutral-100 mt-2">
                    {amIABank && (
                      <button
                        type="button"
                        disabled={isBlockedOrDeactivated}
                        onClick={() => { setLoanModalMode('provide'); setIsProvideLoanModalOpen(true); }}
                        className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                          isBlockedOrDeactivated
                            ? 'opacity-45 cursor-not-allowed border-neutral-200 bg-neutral-100 text-neutral-400'
                            : 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300 cursor-pointer shadow-sm active:scale-[0.98]'
                        }`}
                        title={isDeactivated ? 'Sovereign clearing deactivated' : `Issue Final Coin loan to @${profile.userId}`}
                      >
                        <HandCoins className="w-3.5 h-3.5 text-amber-700" />
                        <span>Provide Loan</span>
                      </button>
                    )}
                    {defaultCount > 0 && (
                      <div className="min-h-[40px] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all bg-red-100 text-red-900 border border-red-200 shadow-sm">
                        <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
                        <span>Defaulted {defaultCount} {defaultCount === 1 ? 'Time' : 'Times'}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Admin Transfer Section (ABOVE Licensed Internal Bank Node) */}
            {viewerIsAdmin && !isMe && (
              <div className="mt-5 p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-50 to-orange-50/80 border border-amber-300/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shrink-0 shadow-xs">
                    <Coins className="w-5 h-5 text-slate-950" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold text-amber-800 uppercase tracking-wider">
                        Admin Sovereign Authority
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-amber-200 text-amber-900 border border-amber-300/70">
                        Ledger System Mint
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mt-0.5">
                      Admin Coin Transfer &amp; Money Supply Control
                    </h4>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setAdminTransferSuccessMsg(null);
                    setAdminTransferErrorMsg(null);
                    setShowAdminTransferConfirm(false);
                    setIsAdminTransferModalOpen(true);
                  }}
                  className="w-full sm:w-auto min-h-[42px] px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all shadow-xs active:scale-[0.98] shrink-0"
                >
                  <Coins className="w-4 h-4 text-amber-100" />
                  <span>Admin Transfer</span>
                </button>
              </div>
            )}

            {/* Internal Bank Credentials card (KEPT IN MIDDLE) */}
            {isViewedUserABank && (
              <div className="mt-5 p-5 rounded-2xl bg-indigo-50/40 border border-indigo-100/70 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Building2 className="w-5 h-5 text-indigo-50" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono font-bold text-indigo-700 tracking-wider uppercase block">
                      Licensed Internal Bank Node
                    </span>
                    <h3 className="font-serif text-base font-bold text-slate-900 mt-0.5">
                      {getBankInfo(targetBankId).bankName}
                    </h3>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1 border-t border-indigo-100/40">
                  <div className="p-3 bg-white rounded-xl border border-indigo-100/30">
                    <span className="text-slate-500 font-mono block mb-1">Reserve &amp; Credit Capacity:</span>
                    <span className="font-mono font-bold text-indigo-800 text-sm">
                      {getBankInfo(targetBankId).capacity}
                    </span>
                  </div>
                  <div className="p-3 bg-white rounded-xl border border-indigo-100/30">
                    <span className="text-slate-500 font-mono block mb-1">Clearing Role Profile:</span>
                    <span className="font-sans font-bold text-slate-800 text-xs">
                      {getBankInfo(targetBankId).role}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-indigo-100/30">
                  <span className="text-slate-500 font-mono text-[10px] block mb-1 uppercase tracking-wider">Institution Overview:</span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {getBankInfo(targetBankId).description}
                  </p>
                </div>

                 {/* Ask for Loan Action Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    disabled={isDeactivated}
                    onClick={() => { setLoanModalMode('ask'); setIsProvideLoanModalOpen(true); }}
                    className={`w-full min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                      isDeactivated
                        ? 'bg-neutral-100 border border-neutral-205 text-neutral-400 cursor-not-allowed opacity-60'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs active:scale-[0.98] cursor-pointer'
                    }`}
                    title={isDeactivated ? 'Institution is currently deactivated' : `Request credit/loan from ${getBankInfo(targetBankId).bankName}`}
                  >
                    <HandCoins className="w-4 h-4" />
                    <span>Ask For Loan</span>
                  </button>
                </div>
              </div>
            )}

            {/* Protocol Operator Actions Panel (Admin Operator Console KEPT BELOW) */}
            {viewerIsAdmin && !isMe && (
              <div className="mt-5 p-5 rounded-2xl bg-slate-900 border border-slate-850 text-white space-y-3.5 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                    🛡️
                  </div>
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-400 tracking-wider uppercase block">
                      Admin Operator Console
                    </span>
                    <h4 className="font-serif text-sm font-bold text-white mt-0.5">
                      Sovereign Guard Actions
                    </h4>
                  </div>
                </div>

                <div className="pt-1 flex flex-wrap gap-2.5">
                  {isDeactivated ? (
                    <button
                      type="button"
                      onClick={handleReactivateAccount}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all active:scale-[0.98] cursor-pointer flex items-center gap-1.5"
                    >
                      <Unlock className="w-4 h-4 text-emerald-100" />
                      <span>Reactivate Account</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleDeactivateAccount}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all active:scale-[0.98] cursor-pointer flex items-center gap-1.5"
                    >
                      <Lock className="w-4 h-4 text-rose-100" />
                      <span>Deactivate Account</span>
                    </button>
                  )}
                </div>
              </div>
            )}
        </div>
      </div>
    </div>

        {/* ================= USER RATING SECTION ================= */}
        {!relationship.isBlocked && (
          <div className="bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-7 shadow-2xs">
            <UserRatingSection
              targetUserId={profile.userId}
              currentUser={currentUser}
              onRatingSubmitted={() => {
                if (profile) {
                  setAvgRating(getAverageRating(profile.userId));
                }
              }}
            />
          </div>
        )}
      </div>
    ) : (
      /* ================= POSTS & VAULT LISTINGS SECTION ================= */
        <div className="bg-white border border-neutral-200/90 rounded-3xl p-5 sm:p-7 shadow-2xs space-y-6">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-100 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0">
                <Package className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold text-neutral-900 tracking-tight font-serif-lux">
                    {profile.name}'s Posts & Listings
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full bg-neutral-100 text-neutral-700 text-xs font-mono font-bold border border-neutral-200">
                    {userListings.length}
                  </span>
                </div>
                <p className="text-xs text-neutral-500">
                  {relationship.isFriend
                    ? 'Showing public and mutual friends-only trade posts & listings visible to you.'
                    : 'Showing public trade posts & listings visible to you.'}
                </p>
              </div>
            </div>
          </div>

          {/* Listings Content */}
          {relationship.isBlocked ? (
            <div className="p-8 text-center rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
              <Ban className="w-6 h-6 text-neutral-400 mx-auto" />
              <p className="text-xs font-semibold text-neutral-700">Posts Hidden</p>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Posts and trade listings are hidden while this member is blocked.
              </p>
            </div>
          ) : userListings.length === 0 ? (
            <div className="p-10 text-center rounded-2xl bg-neutral-50/70 border border-neutral-200/80 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white border border-neutral-200 shadow-2xs text-neutral-400 flex items-center justify-center mx-auto">
                <Package className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-neutral-800">No Visible Posts</h4>
                <p className="text-xs text-neutral-500 max-w-md mx-auto">
                  {isMe 
                    ? "You haven't created any posts or listings yet." 
                    : `${profile.name} does not have any posts or listings visible for your current session permissions.`}
                </p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {userListings.map((listing) => {
                const visibility = listing.visibility || 'public';

                return (
                  <div
                    key={listing.id}
                    onClick={() => handleCardClick(listing)}
                    className="group bg-neutral-50/50 hover:bg-white border border-neutral-200 hover:border-neutral-300 rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer flex flex-col shadow-2xs hover:shadow-md"
                  >
                    {/* Image / Thumbnail */}
                    <div className="relative h-44 w-full bg-neutral-900 overflow-hidden">
                      {listing.imageUrl ? (
                        <img
                          src={listing.imageUrl}
                          alt={listing.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-neutral-500 bg-neutral-900">
                          <Package className="w-10 h-10" />
                        </div>
                      )}

                      {/* Visibility Badge */}
                      <div className="absolute top-2.5 left-2.5">
                        {visibility === 'public' && (
                          <span className="px-2 py-0.5 rounded-full bg-black/75 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-white/20 shadow-2xs">
                            <Globe className="w-3 h-3 text-emerald-400" />
                            <span>Public</span>
                          </span>
                        )}
                        {visibility === 'friends' && (
                          <span className="px-2 py-0.5 rounded-full bg-blue-950/85 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-blue-400/30 shadow-2xs">
                            <Users className="w-3 h-3 text-blue-300" />
                            <span>Friends Only</span>
                          </span>
                        )}
                        {visibility === 'custom_group' && (
                          <span className="px-2 py-0.5 rounded-full bg-purple-950/85 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-purple-400/30 shadow-2xs">
                            <Lock className="w-3 h-3 text-purple-300" />
                            <span>General Group</span>
                          </span>
                        )}
                        {visibility === 'only_me' && (
                          <span className="px-2 py-0.5 rounded-full bg-neutral-950/85 backdrop-blur-xs text-white text-[10px] font-semibold flex items-center gap-1 border border-neutral-400/30 shadow-2xs">
                            <Lock className="w-3 h-3 text-neutral-300" />
                            <span>Only Me</span>
                          </span>
                        )}
                      </div>

                      {/* Intent Badge */}
                      <div className="absolute top-2.5 right-2.5">
                        <span className="px-2.5 py-0.5 rounded-full bg-white/95 backdrop-blur-xs text-neutral-900 text-[10px] font-bold uppercase tracking-wider shadow-2xs">
                          {listing.itemType === 'service' ? 'Service' : listing.listingIntent === 'buy' ? 'Wanted' : 'For Sale'}
                        </span>
                      </div>
                    </div>

                    {/* Post Content */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono">
                          <span className="truncate">{listing.category || 'General'}</span>
                          {listing.location && <span className="truncate">📍 {listing.location}</span>}
                        </div>
                        <h3 className="font-bold text-sm text-neutral-900 group-hover:text-black line-clamp-1">
                          {listing.title}
                        </h3>
                        {listing.description && (
                          <p className="text-xs text-neutral-600 line-clamp-2 leading-relaxed">
                            {listing.description}
                          </p>
                        )}
                      </div>

                      {/* Pricing & Barter Summary */}
                      <div className="pt-2.5 border-t border-neutral-200/70 flex items-center justify-between gap-2">
                        <div>
                          {listing.finalCoinsPricing && (
                            <div className="text-xs font-bold text-amber-700 font-mono flex items-center gap-1">
                              <Coins className="w-3.5 h-3.5 text-amber-600" />
                              <span>{listing.finalCoinsPricing.amount.toLocaleString()} {listing.finalCoinsPricing.symbol}</span>
                            </div>
                          )}
                          {listing.primaryPriceUSD ? (
                            <div className="text-[11px] text-neutral-500 font-mono">
                              ≈ ${listing.primaryPriceUSD.toLocaleString()} USD
                            </div>
                          ) : null}
                        </div>

                        <span className="text-xs font-semibold text-neutral-900 group-hover:underline flex items-center gap-0.5">
                          <span>View Details</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ================= MODAL: AVATAR CUSTOMIZATION ================= */}
      <AnimatePresence>
        {isAvatarModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-md w-full shadow-2xl space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <h3 className="font-bold text-sm text-neutral-900">Update Profile Avatar</h3>
                <button
                  type="button"
                  onClick={() => setIsAvatarModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Preview */}
              <div className="flex justify-center py-2">
                <div className="w-24 h-24 rounded-full bg-neutral-900 border-4 border-neutral-100 overflow-hidden flex items-center justify-center text-white text-2xl font-bold font-serif-lux shadow-sm">
                  {customAvatarUrl ? (
                    <img src={customAvatarUrl} alt="Avatar preview" className="w-full h-full object-cover" />
                  ) : (
                    profile.name.charAt(0).toUpperCase()
                  )}
                </div>
              </div>

              {/* Upload Input */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-neutral-700 block">Avatar Image URL</label>
                <input
                  type="text"
                  value={customAvatarUrl}
                  onChange={(e) => setCustomAvatarUrl(e.target.value)}
                  placeholder="https://example.com/avatar.jpg"
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />

                <div className="pt-2">
                  <input
                    type="file"
                    ref={avatarFileInputRef}
                    onChange={handleAvatarFileUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => avatarFileInputRef.current?.click()}
                    className="w-full py-2 px-3 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-semibold text-neutral-700 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Local Image File</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsAvatarModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveAvatar}
                  disabled={isSavingPhoto || !customAvatarUrl}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors disabled:opacity-50"
                >
                  {isSavingPhoto ? 'Saving...' : 'Save Avatar'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: COVER PHOTO CUSTOMIZATION ================= */}
      <AnimatePresence>
        {isCoverModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-lg w-full shadow-2xl space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <h3 className="font-bold text-sm text-neutral-900">Customize Depository Cover Photo</h3>
                <button
                  type="button"
                  onClick={() => setIsCoverModalOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Presets */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-700 block">Select Vault Reserve Theme</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {PRESET_COVERS.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setCustomCoverUrl(preset.url)}
                      className={`relative h-16 rounded-xl overflow-hidden border-2 cursor-pointer transition-all ${
                        customCoverUrl === preset.url
                          ? 'border-neutral-950 ring-2 ring-neutral-900/20'
                          : 'border-transparent opacity-80 hover:opacity-100'
                      }`}
                    >
                      <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center p-1">
                        <span className="text-[10px] font-bold text-white text-center leading-tight">
                          {preset.name}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Upload Input */}
              <div className="space-y-2 pt-2 border-t border-neutral-100">
                <label className="text-xs font-semibold text-neutral-700 block">Or Custom Image URL</label>
                <input
                  type="text"
                  value={customCoverUrl}
                  onChange={(e) => setCustomCoverUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full min-h-[40px] px-3 py-2 rounded-xl bg-neutral-50 border border-neutral-200 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-black"
                />

                <div>
                  <input
                    type="file"
                    ref={coverFileInputRef}
                    onChange={handleCoverFileUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => coverFileInputRef.current?.click()}
                    className="w-full py-2 px-3 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-semibold text-neutral-700 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Local Cover File</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setIsCoverModalOpen(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveCover}
                  disabled={isSavingPhoto || !customCoverUrl}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-black hover:bg-neutral-800 text-white text-xs font-semibold cursor-pointer transition-colors disabled:opacity-50"
                >
                  {isSavingPhoto ? 'Saving...' : 'Apply Cover'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: BLOCK MEMBER ================= */}
      <AnimatePresence>
        {showBlockModal && profile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-sm w-full shadow-2xl space-y-4 text-left"
            >
              <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto">
                <Ban className="w-6 h-6" />
              </div>
              <div className="text-center space-y-1">
                <h3 className="font-bold text-base text-neutral-900">
                  {relationship.isBlocked ? `Unblock ${profile.name}?` : `Block ${profile.name}?`}
                </h3>
                <p className="text-xs text-neutral-500">
                  {relationship.isBlocked
                    ? 'Unblocking will allow them to view your public profile, listings, and message you.'
                    : 'Blocked users cannot view your profile, send you direct messages, call you, or see your posts.'}
                </p>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBlockModal(false)}
                  className="flex-1 min-h-[40px] px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={relationship.isBlocked ? handleUnblockUser : handleBlockUser}
                  className={`flex-1 min-h-[40px] px-4 py-2 rounded-xl text-white text-xs font-semibold cursor-pointer transition-colors ${
                    relationship.isBlocked ? 'bg-neutral-900 hover:bg-black' : 'bg-red-600 hover:bg-red-700'
                  }`}
                >
                  {relationship.isBlocked ? 'Confirm Unblock' : 'Confirm Block'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: EDIT ALL PROFILE INFORMATION ================= */}
      <AnimatePresence>
        {isEditProfileModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 sm:p-7 max-w-lg w-full shadow-2xl space-y-5 text-left max-h-[92vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shadow-2xs">
                    <Edit3 className="w-4 h-4 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-neutral-900 font-serif-lux">Edit Profile</h3>
                    <p className="text-[11px] text-neutral-500">Update your sovereign profile identity and details</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsEditProfileModalOpen(false)}
                  className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {editErrorMessage && (
                <div className="p-3 rounded-2xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{editErrorMessage}</span>
                </div>
              )}

              <form onSubmit={handleSaveProfileChanges} className="space-y-4">
                {/* Full Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-neutral-500" />
                    <span>Full Name / Display Name</span>
                  </label>
                  <input
                    type="text"
                    value={editFullName}
                    onChange={(e) => setEditFullName(e.target.value)}
                    placeholder="e.g. Satoshi Nakamoto"
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 focus:outline-hidden focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 bg-white"
                  />
                </div>

                {/* User ID / Handle with Live Availability Status */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                      <AtSign className="w-3.5 h-3.5 text-neutral-500" />
                      <span>User ID Handle</span>
                    </label>
                    {editUserId && (
                      <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                        userIdStatus.available ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {userIdStatus.available ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{userIdStatus.message || 'Available'}</span>
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-3 h-3" />
                            <span>{userIdStatus.message || 'Unavailable'}</span>
                          </>
                        )}
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 font-mono text-xs">@</span>
                    <input
                      type="text"
                      value={editUserId}
                      onChange={handleEditUserIdChange}
                      placeholder="username"
                      required
                      className={`w-full pl-8 pr-3.5 py-2.5 rounded-xl border text-xs font-mono text-neutral-900 focus:outline-hidden ${
                        !userIdStatus.available
                          ? 'border-red-300 focus:border-red-500 focus:ring-1 focus:ring-red-500 bg-red-50/20'
                          : 'border-neutral-200 focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 bg-white'
                      }`}
                    />
                  </div>
                  <p className="text-[10px] text-neutral-400">Unique public handle across directory and barter queries.</p>
                </div>

                {/* Email Address with Live Availability Status */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-neutral-500" />
                      <span>Email Address</span>
                    </label>
                    {editEmail && (
                      <span className={`text-[11px] font-semibold flex items-center gap-1 ${
                        emailStatus.available ? 'text-emerald-600' : 'text-red-600'
                      }`}>
                        {emailStatus.available ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{emailStatus.message || 'Available'}</span>
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-3 h-3" />
                            <span>{emailStatus.message || 'Unavailable'}</span>
                          </>
                        )}
                      </span>
                    )}
                  </div>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={handleEditEmailChange}
                    placeholder="name@example.com"
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs text-neutral-900 focus:outline-hidden ${
                      !emailStatus.available
                        ? 'border-red-300 focus:border-red-500 focus:ring-1 focus:ring-red-500 bg-red-50/20'
                        : 'border-neutral-200 focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 bg-white'
                    }`}
                  />
                  <p className="text-[10px] text-neutral-400">Used for account security and authentication recovery.</p>
                </div>

                {/* Bio - No limit! */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-neutral-800 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-neutral-500" />
                      <span>Bio / About Yourself</span>
                    </label>
                    <span className="text-[10px] text-emerald-600 font-semibold px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200">
                      No Character Limit
                    </span>
                  </div>
                  <textarea
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    placeholder="Tell the community about yourself, your sovereign reserve allocations, trading interests, specialties, and goals..."
                    rows={4}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs text-neutral-900 focus:outline-hidden focus:border-neutral-900 focus:ring-1 focus:ring-neutral-900 leading-relaxed resize-y min-h-[100px] bg-white"
                  />
                  <p className="text-[10px] text-neutral-400">Write whatever you want about yourself — detailed description, background, or multi-asset trade terms.</p>
                </div>

                {/* Direct Photo Upload Controls (Avatar & Cover) */}
                <div className="pt-3 border-t border-neutral-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-neutral-800">Profile Photos</span>
                    <span className="text-[10px] text-neutral-400">Upload directly or select themes</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Avatar Upload in Edit Form */}
                    <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center gap-3">
                      <div className="w-11 h-11 rounded-full bg-black text-white shrink-0 overflow-hidden flex items-center justify-center text-sm font-bold border border-neutral-300">
                        {editAvatarUrl ? (
                          <img src={editAvatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                        ) : (
                          (editFullName ? editFullName.charAt(0).toUpperCase() : 'U')
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <label className="text-[11px] font-semibold text-neutral-700 block truncate">Avatar Photo</label>
                        <div className="flex items-center gap-2 mt-1">
                          <input
                            type="file"
                            id="edit-modal-avatar-file"
                            onChange={handleEditAvatarUpload}
                            accept="image/*"
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => document.getElementById('edit-modal-avatar-file')?.click()}
                            className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-black text-white text-[10px] font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Upload</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setIsEditProfileModalOpen(false);
                              setIsAvatarModalOpen(true);
                            }}
                            className="text-[10px] text-neutral-600 hover:text-black cursor-pointer underline"
                          >
                            More
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Cover Upload in Edit Form */}
                    <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200 flex items-center gap-3">
                      <div className="w-14 h-11 rounded-xl bg-neutral-900 text-white shrink-0 overflow-hidden flex items-center justify-center text-xs border border-neutral-300">
                        {editCoverUrl ? (
                          <img src={editCoverUrl} alt="Cover" className="w-full h-full object-cover" />
                        ) : (
                          <span className="text-[9px] text-neutral-400">Default</span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <label className="text-[11px] font-semibold text-neutral-700 block truncate">Cover Banner</label>
                        <div className="flex items-center gap-2 mt-1">
                          <input
                            type="file"
                            id="edit-modal-cover-file"
                            onChange={handleEditCoverUpload}
                            accept="image/*"
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => document.getElementById('edit-modal-cover-file')?.click()}
                            className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-black text-white text-[10px] font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Upload</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setIsEditProfileModalOpen(false);
                              setIsCoverModalOpen(true);
                            }}
                            className="text-[10px] text-neutral-600 hover:text-black cursor-pointer underline"
                          >
                            Themes
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="pt-3 border-t border-neutral-100 flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setIsEditProfileModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100 cursor-pointer transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingProfile || !userIdStatus.available || (editEmail.trim() ? !emailStatus.available : false)}
                    className="px-5 py-2.5 rounded-xl bg-neutral-950 hover:bg-black disabled:bg-neutral-300 text-white text-xs font-bold transition-all shadow-sm cursor-pointer disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {isSavingProfile && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    <span>Save Changes</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: POST QUICK PREVIEW (FALLBACK) ================= */}
      <AnimatePresence>
        {selectedPostPreview && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-neutral-200 p-6 max-w-lg w-full shadow-2xl space-y-4 text-left max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <span className="text-xs font-mono text-neutral-500">{selectedPostPreview.category || 'Listing Preview'}</span>
                <button
                  type="button"
                  onClick={() => setSelectedPostPreview(null)}
                  className="p-1 rounded-full text-neutral-400 hover:text-black cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {selectedPostPreview.imageUrl && (
                <div className="h-56 rounded-2xl overflow-hidden bg-neutral-900">
                  <img
                    src={selectedPostPreview.imageUrl}
                    alt={selectedPostPreview.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              <div className="space-y-2">
                <h3 className="font-bold text-lg text-neutral-900 font-serif-lux">
                  {selectedPostPreview.title}
                </h3>
                {selectedPostPreview.description && (
                  <p className="text-xs text-neutral-600 leading-relaxed">
                    {selectedPostPreview.description}
                  </p>
                )}
              </div>

              {selectedPostPreview.finalCoinsPricing && (
                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                  <span className="text-xs font-semibold text-amber-900">Final Coins Valuation</span>
                  <span className="text-sm font-bold text-amber-800 font-mono">
                    {selectedPostPreview.finalCoinsPricing.amount.toLocaleString()} {selectedPostPreview.finalCoinsPricing.symbol}
                  </span>
                </div>
              )}

              <div className="pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  onClick={() => setSelectedPostPreview(null)}
                  className="w-full min-h-[40px] px-4 py-2 rounded-xl bg-neutral-950 text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer transition-colors"
                >
                  Close Preview
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* ================= MODAL: ADMIN TRANSFER (MINT / BURN) ================= */}
      <AnimatePresence>
        {isAdminTransferModalOpen && profile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 p-6 max-w-lg w-full shadow-2xl space-y-5 text-left text-slate-900 max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold shadow-2xs shrink-0">
                    <Coins className="w-5 h-5 text-amber-800" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-700 tracking-wider uppercase block">
                      Admin Sovereign Authority
                    </span>
                    <h3 className="font-serif text-base font-bold text-slate-900">
                      Final Admin Coin Transfer &amp; System Mint
                    </h3>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAdminTransferModalOpen(false)}
                  className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Target User Banner */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-amber-100 border border-amber-200 flex items-center justify-center font-bold text-amber-800 text-xs">
                    {profile.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">{profile.name}</span>
                    <span className="text-[11px] font-mono text-slate-500">@{profile.userId}</span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-amber-100 text-amber-800">
                  Target Account
                </span>
              </div>

              {/* Action Selection Tabs */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-slate-700 block">
                  Select Admin Action Mode
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => { setAdminTransferAction('add'); setAdminTransferErrorMsg(null); setShowAdminTransferConfirm(false); }}
                    className={`min-h-[40px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      adminTransferAction === 'add'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                    }`}
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Add Final Coins (Mint / Credit)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAdminTransferAction('deduct'); setAdminTransferErrorMsg(null); setShowAdminTransferConfirm(false); }}
                    className={`min-h-[40px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      adminTransferAction === 'deduct'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                    }`}
                  >
                    <Ban className="w-4 h-4" />
                    <span>Deduct Final Coins (Burn / Slash)</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 italic px-1 pt-0.5">
                  {adminTransferAction === 'add'
                    ? '⚡ System Mint Mode: Creates unlimited new Final Coins in the system directly for the user.'
                    : '🔥 System Burn Mode: Takes Final Coins directly out of the user\'s account.'}
                </p>
              </div>

              {/* Final Coin Symbol Selection / Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-slate-700 flex items-center justify-between">
                  <span>Select or Enter Final Coin Symbol</span>
                  <span className="text-[10px] text-amber-700 font-normal">Any Final Coin Supported</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <select
                    value={['AFNL', 'USDCF', 'GOLDF', 'EUROF'].includes(adminTransferSymbol) ? adminTransferSymbol : 'CUSTOM'}
                    onChange={(e) => {
                      if (e.target.value !== 'CUSTOM') {
                        setAdminTransferSymbol(e.target.value);
                      }
                      setShowAdminTransferConfirm(false);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white font-mono font-bold text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="AFNL">AFNL (Final Admin Coin)</option>
                    <option value="USDCF">USDCF (USD Final Coin)</option>
                    <option value="GOLDF">GOLDF (Gold Final Coin)</option>
                    <option value="EUROF">EUROF (Euro Final Coin)</option>
                    <option value="CUSTOM">Custom Final Coin Symbol...</option>
                  </select>

                  <input
                    type="text"
                    value={adminTransferSymbol}
                    onChange={(e) => {
                      setAdminTransferSymbol(e.target.value.toUpperCase());
                      setShowAdminTransferConfirm(false);
                    }}
                    placeholder="e.g. SOLF"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 font-mono font-bold text-xs text-slate-900 uppercase focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Amount Input & Presets */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono font-bold text-slate-700 block">
                    Coin Amount ({adminTransferSymbol || 'AFNL'})
                  </label>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold">
                    Unlimited Issuance Enabled
                  </span>
                </div>
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={adminTransferAmount}
                  onChange={(e) => {
                    setAdminTransferAmount(e.target.value);
                    setShowAdminTransferConfirm(false);
                  }}
                  placeholder="Enter amount..."
                  className="w-full min-h-[42px] px-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 font-mono font-bold text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  {['100', '1,000', '5,000', '25,000', '100,000', '1,000,000'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => {
                        setAdminTransferAmount(val.replace(/,/g, ''));
                        setShowAdminTransferConfirm(false);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-200 text-[10px] font-mono font-bold text-slate-700 cursor-pointer transition-colors"
                    >
                      +{val}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reason / Note */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-bold text-slate-700 block">
                  Admin Audit Reason / Note
                </label>
                <input
                  type="text"
                  value={adminTransferReason}
                  onChange={(e) => {
                    setAdminTransferReason(e.target.value);
                    setShowAdminTransferConfirm(false);
                  }}
                  placeholder="Reason for admin balance adjustment..."
                  className="w-full min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* CONFIRMATION STEP OVERLAY / BOX */}
              {showAdminTransferConfirm && (
                <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 text-amber-900 space-y-3 shadow-sm animate-fade-in">
                  <div className="flex items-center gap-2 text-amber-800 font-bold text-xs uppercase tracking-wider">
                    <AlertCircle className="w-4 h-4 text-amber-700" />
                    <span>Confirmation Required Before Finalizing</span>
                  </div>
                  <p className="text-xs leading-relaxed text-slate-700">
                    Are you sure you want to {adminTransferAction === 'add' ? 'mint and credit' : 'deduct'} <strong className="font-mono font-bold">{parseFloat(adminTransferAmount || '0').toLocaleString()} {adminTransferSymbol || 'AFNL'}</strong> {adminTransferAction === 'add' ? 'to' : 'from'} <strong className="font-bold">@{profile.userId}</strong>?
                  </p>
                  {adminTransferSuccessMsg && (
                    <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                      {adminTransferSuccessMsg}
                    </div>
                  )}
                  {adminTransferErrorMsg && (
                    <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                      {adminTransferErrorMsg}
                    </div>
                  )}
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowAdminTransferConfirm(false)}
                      className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={isAdminTransferLoading}
                      onClick={handleExecuteAdminTransfer}
                      className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition-all shadow-sm cursor-pointer disabled:opacity-50"
                    >
                      {isAdminTransferLoading ? 'Executing...' : 'Confirm Execution'}
                    </button>
                  </div>
                </div>
              )}

              {/* Success / Error Messages when not in confirm */}
              {!showAdminTransferConfirm && adminTransferSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                  {adminTransferSuccessMsg}
                </div>
              )}
              {!showAdminTransferConfirm && adminTransferErrorMsg && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                  {adminTransferErrorMsg}
                </div>
              )}

              {/* Footer buttons */}
              {!showAdminTransferConfirm && (
                <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsAdminTransferModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-all cursor-pointer"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    disabled={isAdminTransferLoading}
                    onClick={handleExecuteAdminTransfer}
                    className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-all shadow-sm cursor-pointer disabled:opacity-50"
                  >
                    {isAdminTransferLoading ? 'Processing...' : (adminTransferAction === 'add' ? 'Execute Mint & Credit' : 'Execute Deduction')}
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Peer-to-Peer Transfer Modal */}
      {profile && (
        <PeerTransferModal
          isOpen={isTransferModalOpen}
          onClose={() => setIsTransferModalOpen(false)}
          recipient={{
            uid: profile.userId,
            userId: profile.userId,
            name: profile.name,
            avatarUrl: profile.avatarUrl,
            isVerified: true
          }}
          currentUser={currentUser}
        />
      )}

      {/* Provide/Ask Loan Modal */}
      {profile && (
        <ProvideLoanModal
          isOpen={isProvideLoanModalOpen}
          onClose={() => setIsProvideLoanModalOpen(false)}
          currentUser={currentUser}
          targetUser={profile}
          mode={loanModalMode}
          onSuccess={(msg) => showToast(msg)}
        />
      )}

      {/* ================= GROUP MANAGEMENT MODAL ================= */}
      {isGroupManagementModalOpen && profile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl border border-neutral-200 shadow-2xl max-w-md w-full overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl}
                    alt={profile.name}
                    className="w-10 h-10 rounded-full object-cover shrink-0 border border-neutral-200"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-neutral-900 text-white font-bold flex items-center justify-center shrink-0">
                    {profile.name.charAt(0)}
                  </div>
                )}
                <div className="min-w-0">
                  <h3 className="font-bold text-sm text-black truncate">
                    Assign Groups for {profile.name}
                  </h3>
                  <p className="text-[11px] text-neutral-400 font-mono truncate">
                    @{profile.userId}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsGroupManagementModalOpen(false)}
                className="p-1.5 rounded-full text-neutral-400 hover:text-black hover:bg-neutral-100 cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-3 text-xs text-emerald-900 leading-relaxed">
                <strong>Group Assignment:</strong> Group individuals into multiple custom or friend groups instantly without requiring friendship connection.
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-neutral-700">
                  Select Groups
                </label>

                {groupErrorMsg && (
                  <div className="p-2 bg-red-50 text-red-600 text-xs font-bold rounded-xl border border-red-100 flex items-center justify-between">
                    <span>{groupErrorMsg}</span>
                    <button type="button" onClick={() => setGroupErrorMsg('')} className="p-0.5 hover:bg-red-100 rounded-full text-red-700">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {selectableProfileGroups.length === 0 ? (
                  <div className="p-6 bg-neutral-50 border border-neutral-200/80 rounded-2xl text-center space-y-2">
                    <p className="text-xs text-neutral-500">
                      {relationship.friendStatus === 'friends' 
                        ? "You haven't created any groups yet." 
                        : "You haven't created any General Groups yet."}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {selectableProfileGroups.map((group) => {
                      const isInGroup = group.memberUids.includes(profile.uid);
                      return (
                        <div
                          key={group.id}
                          onClick={() => handleToggleGroupMembership(group)}
                          className={`p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${
                            isInGroup
                              ? 'bg-emerald-50/80 border-emerald-300 shadow-2xs'
                              : 'bg-white border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div
                              className="w-3.5 h-3.5 rounded-full shrink-0 border border-black/10"
                              style={{ backgroundColor: group.color || '#f59e0b' }}
                            />
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-black truncate">{group.name}</p>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] text-neutral-500 truncate">{group.description || 'Custom Group'}</span>
                                <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${group.groupType === 'general' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
                                  {group.groupType === 'general' ? 'General Group' : 'Friend Group'}
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <input
                              type="checkbox"
                              checked={isInGroup}
                              onChange={() => {}}
                              className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setIsGroupManagementModalOpen(false)}
                className="px-5 py-2 rounded-full bg-black text-white text-xs font-semibold hover:bg-neutral-800 cursor-pointer shadow-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};
