import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  X, 
  Repeat, 
  Package, 
  Briefcase, 
  Coins, 
  Check, 
  Sparkles,
  Send,
  ShieldCheck,
  Banknote,
  Binary,
  Wallet,
  DollarSign
} from 'lucide-react';
import { AuthSession } from '../types/auth';
import { UserWalletData } from '../types/wallet';
import { getStoredUserWallets } from '../data/defaultWallets';
import { submitBarterTradeProposal } from '../services/marketplaceService';
import { ConfirmModal } from './common/ConfirmModal';
import { useApp } from '../context/AppContext';
import { recordLedgerTransaction, createLedgerItemFromBarter } from '../utils/universalLedgerBridge';

interface BarterProposalModalProps {
  isOpen: boolean;
  currentUser?: AuthSession | null;
  targetListing?: {
    id: string;
    title: string;
    sellerId: string;
    sellerName: string;
    estimatedValueUSD?: number;
    desiredTrades?: string;
  } | null;
  onClose: () => void;
  onProposalSent?: (proposal: any) => void;
}

export const BarterProposalModal: React.FC<BarterProposalModalProps> = ({
  isOpen,
  currentUser,
  targetListing,
  onClose,
  onProposalSent,
}) => {
  const { addToast, addNotification } = useApp();
  const [userWallets, setUserWallets] = useState<UserWalletData>(() => 
    getStoredUserWallets(currentUser?.id || 'guest')
  );

  useEffect(() => {
    if (currentUser?.id) {
      setUserWallets(getStoredUserWallets(currentUser.id));
    }
  }, [currentUser?.id]);

  // Modal tab: 'portfolio' (inventory, final coins, stable coins, fiat, crypto) or 'proposal' (propose trade)
  const [activeModalTab, setActiveModalTab] = useState<'portfolio' | 'proposal'>(() => {
    return targetListing ? 'proposal' : 'portfolio';
  });

  // Selected offering from user's inventory
  const [offeringType, setOfferingType] = useState<'inventory' | 'custom'>('inventory');
  const [selectedGoodId, setSelectedGoodId] = useState<string>(
    userWallets.barterGoods[0]?.id || ''
  );
  const [selectedServiceId, setSelectedServiceId] = useState<string>(
    userWallets.barterServices[0]?.id || ''
  );
  const [inventoryKind, setInventoryKind] = useState<'good' | 'service'>('good');
  const [customOfferText, setCustomOfferText] = useState('');

  // Cash / Token Sweetener
  const [includeSweetener, setIncludeSweetener] = useState(false);
  const [sweetenerAmountUSD, setSweetenerAmountUSD] = useState<number>(500);
  const [sweetenerTokenSymbol, setSweetenerTokenSymbol] = useState<'AFNL' | 'USDC' | 'ETH'>('AFNL');
  const [sweetenerTokenAmount, setSweetenerTokenAmount] = useState<number>(250);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  if (!isOpen) return null;

  const handleSendProposal = (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfirm(true);
  };

  const processExecution = () => {
    setIsSubmitting(true);

    let description = '';
    if (offeringType === 'inventory') {
      if (inventoryKind === 'good') {
        const item = userWallets.barterGoods.find((g) => g.id === selectedGoodId);
        description = item 
          ? `${item.quantity}x ${item.name} (${item.condition}) - Est. Value: $${(item.estimatedUnitValue * item.quantity).toLocaleString()}`
          : 'Physical Goods Trade';
      } else {
        const item = userWallets.barterServices.find((s) => s.id === selectedServiceId);
        description = item
          ? `${item.availableUnits} ${item.unitType} of ${item.name} - Est. Value: $${(item.hourlyRateValue * item.availableUnits).toLocaleString()}`
          : 'Professional Service Retainer';
      }
    } else {
      description = customOfferText.trim() || 'Custom Barter Arrangement';
    }

    const proposal = submitBarterTradeProposal({
      listingId: targetListing?.id || `gen-${Date.now()}`,
      listingTitle: targetListing?.title || 'Bespoke Multi-Asset Settlement',
      senderId: currentUser?.id || 'guest',
      senderName: currentUser?.name || 'Guest Trader',
      recipientId: targetListing?.sellerId || 'counterparty',
      offeredItemsDescription: description,
      offeredSweetenerUSD: includeSweetener ? sweetenerAmountUSD : undefined,
      offeredSweetenerToken: includeSweetener 
        ? { symbol: sweetenerTokenSymbol, amount: sweetenerTokenAmount } 
        : undefined,
    });

    // Record in Universal Ledger
    const estimatedTradeValue = (targetListing?.estimatedValueUSD || 500) + (includeSweetener ? sweetenerAmountUSD : 0);
    const ledgerItem = createLedgerItemFromBarter({
      offeredDescription: description,
      targetListingTitle: targetListing?.title || 'Bespoke Multi-Asset Settlement',
      counterpartyName: targetListing?.sellerName || 'Counterparty Peer',
      sweetenerUSD: includeSweetener ? sweetenerAmountUSD : 0,
      estimatedTotalValueUSD: estimatedTradeValue
    });
    recordLedgerTransaction(currentUser?.id || 'guest', ledgerItem);

    addToast({
      title: 'Peer Barter Proposal Submitted',
      message: `Formal trade proposal for "${targetListing?.title || 'Peer Listing'}" recorded in peer ledger.`,
      type: 'gold'
    });

    addNotification({
      title: `🤝 Barter Trade Proposal Dispatched`,
      description: `Offered ${description} for ${targetListing?.title || 'Asset'}.`,
      type: 'trade',
      targetTab: 'marketplace',
      amount: estimatedTradeValue,
      currency: 'USD'
    });

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      if (onProposalSent) onProposalSent(proposal);
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
      }, 1500);
    }, 900);
  };

  // Portfolio Totals & Items
  const goodsTotalUSD = userWallets.barterGoods.reduce((sum, g) => sum + g.quantity * g.estimatedUnitValue, 0);
  const servicesTotalUSD = userWallets.barterServices.reduce((sum, s) => sum + s.availableUnits * s.hourlyRateValue, 0);
  const finalCoinsTotalUSD = userWallets.finalCoins.reduce((sum, c) => sum + c.balance * c.unitPriceUSD, 0);
  const stableCoinsTotalUSD = userWallets.stableCoins.reduce((sum, s) => sum + s.balance * s.unitPriceUSD, 0);
  const fiatTotalUSD = userWallets.fiatCurrencies.reduce((sum, f) => sum + f.balance * f.exchangeRateToUSD, 0);
  const cryptoTotalUSD = userWallets.cryptoCurrencies.reduce((sum, c) => sum + c.balance * c.unitPriceUSD, 0);

  return (
    <div
      id="barter-proposal-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-2xl text-left text-slate-900 my-auto max-h-[92vh] flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-amber-300 bg-amber-50 text-amber-800">
              <Repeat className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg sm:text-xl font-bold text-slate-900 tracking-wide">
                Barter &amp; Asset Vault
              </h2>
              <p className="text-xs text-slate-500">
                Manage goods inventory, service capacity, final coins, stablecoins, fiat &amp; crypto earnings.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Main Tab Switcher */}
        <div className="mt-4 grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveModalTab('portfolio')}
            className={`py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeModalTab === 'portfolio'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Package className="w-4 h-4 text-amber-600" />
            <span>My Barter &amp; Asset Portfolio</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveModalTab('proposal')}
            className={`py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeModalTab === 'proposal'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Send className="w-4 h-4 text-amber-600" />
            <span>Propose Trade {targetListing ? `(${targetListing.title.substring(0, 15)}...)` : ''}</span>
          </button>
        </div>

        {/* TAB 1: PORTFOLIO & ASSET SUMMARY */}
        {activeModalTab === 'portfolio' && (
          <div className="mt-4 flex-1 overflow-y-auto space-y-5 pr-1 text-left">
            {/* 1. Barter Goods Inventory */}
            <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-amber-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Physical Goods Inventory ({userWallets.barterGoods.length})</h3>
                </div>
                <span className="text-xs font-mono font-bold text-amber-800">${goodsTotalUSD.toLocaleString()} USD</span>
              </div>
              {userWallets.barterGoods.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No physical goods registered in inventory.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {userWallets.barterGoods.map((good) => (
                    <div key={good.id} className="p-3 bg-white rounded-xl border border-amber-200/80 space-y-1 shadow-2xs">
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-xs text-slate-900">{good.name}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-semibold">{good.condition}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{good.description}</p>
                      <div className="flex justify-between items-center text-[11px] pt-1 font-mono">
                        <span className="text-slate-600">Qty: {good.quantity} {good.unitLabel}</span>
                        <span className="font-bold text-amber-700">${(good.quantity * good.estimatedUnitValue).toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 2. Barter Services Inventory */}
            <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-blue-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Service Retainers &amp; Capacity ({userWallets.barterServices.length})</h3>
                </div>
                <span className="text-xs font-mono font-bold text-blue-800">${servicesTotalUSD.toLocaleString()} USD</span>
              </div>
              {userWallets.barterServices.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No service retainers registered.</p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {userWallets.barterServices.map((srv) => (
                    <div key={srv.id} className="p-3 bg-white rounded-xl border border-blue-200/80 space-y-1 shadow-2xs">
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-xs text-slate-900">{srv.name}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-100 text-blue-900 font-semibold">{srv.turnaroundTime}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{srv.deliverableDescription}</p>
                      <div className="flex justify-between items-center text-[11px] pt-1 font-mono">
                        <span className="text-slate-600">{srv.availableUnits} {srv.unitType}</span>
                        <span className="font-bold text-blue-700">${(srv.availableUnits * srv.hourlyRateValue).toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 3. Final Coins (AFNL) */}
            <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3 shadow-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Coins className="w-4 h-4 text-amber-400" />
                  <h3 className="font-bold text-xs uppercase tracking-wider text-amber-300">Final Coins (AFNL) Holdings</h3>
                </div>
                <span className="text-xs font-mono font-bold text-amber-400">${finalCoinsTotalUSD.toLocaleString()} USD</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.finalCoins.map((coin) => (
                  <div key={coin.id} className="p-3 bg-slate-800/90 rounded-xl border border-slate-700 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-white">{coin.name} ({coin.symbol})</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono pt-1">
                      <span className="text-amber-300 font-bold">{coin.balance.toLocaleString()} {coin.symbol}</span>
                      <span className="text-slate-400">${(coin.balance * coin.unitPriceUSD).toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 4. Stablecoins (USDC / USDT) */}
            <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Stablecoins &amp; Escrow Liquidity</h3>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-800">${stableCoinsTotalUSD.toLocaleString()} USD</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.stableCoins.map((sc) => (
                  <div key={sc.id} className="p-3 bg-white rounded-xl border border-emerald-200/80 space-y-1 shadow-2xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-slate-900">{sc.name} ({sc.symbol})</span>
                      <span className="text-[10px] font-mono text-emerald-700 font-semibold">{sc.yieldAPY}% APY</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono pt-1">
                      <span className="font-bold text-emerald-800">{sc.balance.toLocaleString()} {sc.symbol}</span>
                      <span className="text-slate-500">${(sc.balance * sc.unitPriceUSD).toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5. Fiat Earnings & Balances */}
            <div className="p-4 rounded-2xl bg-sky-50/50 border border-sky-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Banknote className="w-4 h-4 text-sky-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Earnings &amp; Balances in Fiat (USD / EUR / GBP)</h3>
                </div>
                <span className="text-xs font-mono font-bold text-sky-800">${fiatTotalUSD.toLocaleString()} USD</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.fiatCurrencies.map((fiat) => (
                  <div key={fiat.id} className="p-3 bg-white rounded-xl border border-sky-200/80 space-y-1 shadow-2xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-slate-900">{fiat.name} ({fiat.code})</span>
                      <span className="text-[10px] font-mono text-sky-700 font-semibold">{fiat.institution}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono pt-1">
                      <span className="font-bold text-sky-900">{fiat.symbol}{fiat.balance.toLocaleString()}</span>
                      <span className="text-slate-500">${(fiat.balance * fiat.exchangeRateToUSD).toLocaleString()} USD</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 6. Cryptocurrency Earnings & Balances */}
            <div className="p-4 rounded-2xl bg-purple-50/50 border border-purple-200/60 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Binary className="w-4 h-4 text-purple-700" />
                  <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">Earnings in Cryptocurrency (BTC / ETH / SOL)</h3>
                </div>
                <span className="text-xs font-mono font-bold text-purple-800">${cryptoTotalUSD.toLocaleString()} USD</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {userWallets.cryptoCurrencies.map((crypto) => (
                  <div key={crypto.id} className="p-3 bg-white rounded-xl border border-purple-200/80 space-y-1 shadow-2xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-slate-900">{crypto.name} ({crypto.symbol})</span>
                      <span className="text-[10px] font-mono text-purple-700 font-semibold">{crypto.network}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono pt-1">
                      <span className="font-bold text-purple-900">{crypto.balance} {crypto.symbol}</span>
                      <span className="text-slate-500">${(crypto.balance * crypto.unitPriceUSD).toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveModalTab('proposal')}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-sm cursor-pointer flex items-center gap-2"
              >
                <span>Proceed to Propose Barter Trade</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: PROPOSE TRADE FORM */}
        {activeModalTab === 'proposal' && (
          <form onSubmit={handleSendProposal} className="mt-4 flex-1 overflow-y-auto space-y-4 pr-1">
            {/* Target Asset Information */}
            {targetListing && (
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[11px] font-mono uppercase text-slate-500 font-semibold">Target Asset / Listing</p>
                    <h4 className="text-sm font-semibold text-slate-900">{targetListing.title}</h4>
                    <p className="text-xs text-slate-500">Listed by: <span className="font-medium text-slate-800">{targetListing.sellerName}</span></p>
                  </div>
                  {targetListing.estimatedValueUSD && (
                    <div className="text-right">
                      <p className="text-[10px] text-slate-500 uppercase font-mono">Listed Value</p>
                      <p className="text-sm font-bold text-amber-700">${targetListing.estimatedValueUSD.toLocaleString()}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Mode Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setOfferingType('inventory')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  offeringType === 'inventory'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                From My Verified Reserves
              </button>
              <button
                type="button"
                onClick={() => setOfferingType('custom')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  offeringType === 'custom'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Custom Barter Offer
              </button>
            </div>

            {offeringType === 'inventory' ? (
              <div className="space-y-3">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setInventoryKind('good')}
                    className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer ${
                      inventoryKind === 'good'
                        ? 'border-amber-500 bg-amber-50 text-amber-900 font-semibold'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Package className="w-3.5 h-3.5" />
                    <span>Physical Goods ({userWallets.barterGoods.length})</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setInventoryKind('service')}
                    className={`flex-1 py-1.5 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer ${
                      inventoryKind === 'service'
                        ? 'border-amber-500 bg-amber-50 text-amber-900 font-semibold'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Briefcase className="w-3.5 h-3.5" />
                    <span>Services ({userWallets.barterServices.length})</span>
                  </button>
                </div>

                {inventoryKind === 'good' ? (
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-700">Select Physical Asset to Offer</label>
                    {userWallets.barterGoods.length === 0 ? (
                      <p className="text-xs text-slate-500 py-3 bg-slate-50 rounded-xl text-center border border-slate-200">
                        No physical goods in your depository wallet. Switch to Custom Offer.
                      </p>
                    ) : (
                      <select
                        value={selectedGoodId}
                        onChange={(e) => setSelectedGoodId(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-amber-500"
                      >
                        {userWallets.barterGoods.map((good) => (
                          <option key={good.id} value={good.id}>
                            {good.quantity}x {good.name} (${(good.estimatedUnitValue * good.quantity).toLocaleString()})
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-700">Select Service Retainer to Offer</label>
                    {userWallets.barterServices.length === 0 ? (
                      <p className="text-xs text-slate-500 py-3 bg-slate-50 rounded-xl text-center border border-slate-200">
                        No service retainers registered. Switch to Custom Offer.
                      </p>
                    ) : (
                      <select
                        value={selectedServiceId}
                        onChange={(e) => setSelectedServiceId(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-amber-500"
                      >
                        {userWallets.barterServices.map((srv) => (
                          <option key={srv.id} value={srv.id}>
                            {srv.availableUnits} {srv.unitType} of {srv.name} (${(srv.hourlyRateValue * srv.availableUnits).toLocaleString()})
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-700">Describe Your Barter Offer</label>
                <textarea
                  rows={3}
                  value={customOfferText}
                  onChange={(e) => setCustomOfferText(e.target.value)}
                  placeholder="e.g., 500g LBMA certified silver bullion bar + 10 hours smart contract architecture audit..."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-amber-500 resize-none"
                />
              </div>
            )}

            {/* Sweetener Toggle */}
            <div className="pt-2 border-t border-slate-100">
              <label className="flex items-center justify-between text-xs font-medium text-slate-700 cursor-pointer">
                <span className="flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-600" />
                  <span>Add Cash / Token Sweetener (Balancing payment)</span>
                </span>
                <input
                  type="checkbox"
                  checked={includeSweetener}
                  onChange={(e) => setIncludeSweetener(e.target.checked)}
                  className="rounded border-slate-300 text-amber-600 focus:ring-amber-500 w-4 h-4 cursor-pointer"
                />
              </label>

              {includeSweetener && (
                <div className="grid grid-cols-2 gap-2 mt-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase font-mono mb-1">Asset Class</label>
                    <select
                      value={sweetenerTokenSymbol}
                      onChange={(e) => setSweetenerTokenSymbol(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900"
                    >
                      <option value="AFNL">AFNL (Final Coins)</option>
                      <option value="USDC">USDC (USD Coin)</option>
                      <option value="ETH">ETH (Ethereum)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase font-mono mb-1">Sweetener Value ($USD)</label>
                    <input
                      type="number"
                      value={sweetenerAmountUSD}
                      onChange={(e) => setSweetenerAmountUSD(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 font-mono"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setActiveModalTab('portfolio')}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                &larr; View Portfolio
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || isSuccess}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-xs cursor-pointer disabled:opacity-50"
                >
                  {isSuccess ? (
                    <>
                      <Check className="w-4 h-4 text-slate-950" />
                      <span>Proposal Transmitted!</span>
                    </>
                  ) : isSubmitting ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>Transmitting...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Transmit Barter Offer</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        )}
      </motion.div>

      <ConfirmModal
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={processExecution}
        title="Confirm Barter Proposal"
        message="Are you sure you want to transmit this barter offer? This will initiate a formal trade negotiation and may lock the selected inventory items in escrow."
        confirmText="Confirm & Transmit"
        type="warning"
      />
    </div>
  );
};
