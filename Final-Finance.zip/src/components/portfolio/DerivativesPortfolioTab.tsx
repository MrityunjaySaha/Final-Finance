import React, { useState, useMemo, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Layers, 
  Coins, 
  Zap, 
  Search, 
  RotateCcw,
  User,
  Building,
  Clock,
  Share2,
  Check,
  X,
  ArrowRight,
  ArrowLeftRight,
  Twitter
} from 'lucide-react';
import { StockOrder, StockItem, SocialStockTrade, DerivativeType } from '../../types/stocks';
import { DEFAULT_INITIAL_STOCK_ORDERS, getAllActiveMarketStocks } from '../../data/stocksData';
import { isFinalStock, getAllFinalCoins, getStockCurrencyCode } from '../../utils/stockCurrencyFormatter';
import { createTweet, TWEETING_MAX_CHARS } from '../../services/tweetingService';
import { getCurrentSession } from '../../services/firebaseAuth';
import { TweetingComposerModal, TweetingComposerSubmitPayload } from '../TweetingComposerModal';
import { 
  getStoredSharedSocialTrades, 
  saveSharedSocialTrade, 
  removeSharedSocialTrade, 
  SHARED_SOCIAL_TRADES_EVENT, 
  FRIENDS_AND_MUTUALS 
} from '../../data/socialTradesData';

interface DerivativesPortfolioTabProps {
  userId: string;
  orders: StockOrder[];
  stocks: StockItem[];
  onSelectStock?: (stock: StockItem) => void;
  onOpenTradeModal: (tickerOrStock: string | StockItem, side: 'buy' | 'sell', derivativeType?: DerivativeType) => void;
  onRefreshOrders: () => void;
  onNavigateToSocial?: (notice?: string) => void;
}

export type DerivativeFilterType = 'all' | 'call_option' | 'put_option' | 'long' | 'short';

export const DerivativesPortfolioTab: React.FC<DerivativesPortfolioTabProps> = ({
  userId: _userId,
  orders,
  stocks,
  onSelectStock,
  onOpenTradeModal,
  onRefreshOrders: _onRefreshOrders,
  onNavigateToSocial,
}) => {
  const [filterType, setFilterType] = useState<DerivativeFilterType>('all');
  const [showHistory, setShowHistory] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sharedTrades, setSharedTrades] = useState<SocialStockTrade[]>(() => getStoredSharedSocialTrades());
  const [shareToast, setShareToast] = useState<{ text: string; sharedToSocial: boolean; sharedToTweeting: boolean } | null>(null);
  const [sharingOrder, setSharingOrder] = useState<StockOrder | null>(null);
  const [tweetingOrder, setTweetingOrder] = useState<StockOrder | null>(null);
  const [tweetInitialDescription, setTweetInitialDescription] = useState<string>('');
  const [tweetFinalCurrency, setTweetFinalCurrency] = useState<string>('AFNL');
  const availableFinalCoins = useMemo(() => getAllFinalCoins(), [tweetingOrder]);
  const [shareAudienceMode, setShareAudienceMode] = useState<'all' | 'selected'>('all');
  const [selectedFriendIds, setSelectedFriendIds] = useState<string[]>(() =>
    FRIENDS_AND_MUTUALS.map((f) => f.uid)
  );
  const [shareNoteInput, setShareNoteInput] = useState<string>('');

  useEffect(() => {
    const syncShared = () => setSharedTrades(getStoredSharedSocialTrades());
    window.addEventListener(SHARED_SOCIAL_TRADES_EVENT, syncShared);
    window.addEventListener('storage', syncShared);
    return () => {
      window.removeEventListener(SHARED_SOCIAL_TRADES_EVENT, syncShared);
      window.removeEventListener('storage', syncShared);
    };
  }, []);

  // Stock lookup map
  const stockMap = useMemo(() => {
    const map = new Map<string, StockItem>();
    stocks.forEach((s) => map.set(s.ticker.toUpperCase(), s));
    return map;
  }, [stocks]);

  // Helper to resolve the issuer name for sovereign people and business stocks
  const getIssuerName = (ord: StockOrder, stock?: StockItem): string => {
    if (ord.issuerName) return ord.issuerName;
    if (stock?.issuerName) return stock.issuerName;
    const t = ord.ticker.toUpperCase();
    if (t === 'ALEX') return 'Alex Chen';
    if (t === 'ELEN') return 'Dr. Elena Rostova';
    if (t === 'VANC') return 'Marcus Vance';
    if (t === 'SLIN') return 'Sarah Lin';
    if (t === 'KHAL') return 'Tariq Khalid';
    if (t === 'HYPR') return 'Hyperion Labs';
    if (t === 'BSYN') return 'BioSynthetica Corp';
    if (t === 'SOLN') return 'SolarNode Labs';
    if (t === 'AUR') return 'Sovereign Treasury';
    if (t === 'VEX') return 'Vortex Labs';
    if (t === 'QBIT') return 'Quantum Trust';
    if (t === 'GLD' || t === 'GLD-STBL') return 'Global Vault';
    return '';
  };

  // Helper to resolve the exact Final Currency involved in the contract (no -FNL)
  const getFinalCurrencyName = (ord: StockOrder, stock?: StockItem): string => {
    if (stock && isFinalStock(stock) && stock.issuanceCoinSymbol) {
      return `$${getStockCurrencyCode(stock)}`;
    }
    const t = ord.ticker.toUpperCase().replace(/-FNL$/i, '');
    if (t === 'ALEX') return '$ALEX';
    if (t === 'ELEN') return '$ELEN';
    if (t === 'VANC') return '$VANC';
    if (t === 'SLIN') return '$SLIN';
    if (t === 'KHAL') return '$KHAL';
    if (t === 'HYPR') return '$HYPR';
    if (t === 'BSYN') return '$BSYN';
    if (t === 'SOLN') return '$SOLN';
    if (t === 'AUR') return '$AUR';
    if (t === 'VEX') return '$VEX';
    if (t === 'QBIT') return '$QBIT';
    if (t === 'GLD' || t === 'GLD-STBL') return '$GLD';
    if (ord.paymentSource?.label && ord.paymentSource.label.startsWith('$') && !ord.paymentSource.label.includes('USD')) {
      return ord.paymentSource.label.replace(/-FNL/gi, '');
    }
    return `$${t}`;
  };

  // Helper for contract execution date and exact time
  const formatContractDateTime = (ord: StockOrder) => {
    let dateObj: Date | null = null;
    if (ord.dateIso) {
      const p = new Date(ord.dateIso);
      if (!isNaN(p.getTime())) dateObj = p;
    }
    if (!dateObj && ord.timestamp) {
      const p = new Date(ord.timestamp);
      if (!isNaN(p.getTime())) dateObj = p;
    }
    if (!dateObj && typeof ord.timestamp === 'string' && ord.timestamp.includes(':')) {
      return {
        date: 'Aug 20, 2026',
        time: ord.timestamp,
        full: `Aug 20, 2026, ${ord.timestamp}`
      };
    }
    const finalD = dateObj || new Date();
    return {
      date: finalD.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      time: finalD.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true }),
      full: `${finalD.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}, ${finalD.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true })}`
    };
  };

  // Provide sanitized orders: strictly map legacy tickers to sovereign final stocks of people and businesses
  const effectiveOrders = useMemo(() => {
    const list = orders.length > 0 ? orders : DEFAULT_INITIAL_STOCK_ORDERS;
    return list.map((ord) => {
      const t = (ord.ticker || '').toUpperCase();
      if (t === 'AAPL') {
        return {
          ...ord,
          ticker: 'ALEX',
          stockName: 'Alex Chen Sovereign Human Equity [Call Option (32.00 Strike)]',
          tradeSlipId: 'SLIP-ALEX-CALL',
          strikePrice: 32.00,
          sector: 'Sovereign Reserves' as const,
          isPersonalStock: true,
          issuerName: 'Alex Chen',
          totalGainUSD: 1336.32,
          totalGainPercent: 7.68
        };
      }
      if (t === 'TSLA') {
        return {
          ...ord,
          ticker: 'ELEN',
          stockName: 'Dr. Elena Rostova Plasma Physics Equity [Put Option (28.00 Strike)]',
          tradeSlipId: 'SLIP-ELEN-PUT',
          strikePrice: 28.00,
          sector: 'Sovereign Reserves' as const,
          isPersonalStock: true,
          issuerName: 'Dr. Elena Rostova',
          totalGainUSD: 890.50,
          totalGainPercent: 7.51
        };
      }
      if (t === 'NVDA') {
        return {
          ...ord,
          ticker: 'HYPR',
          stockName: 'Hyperion Quantum Fusion Energy [Futures Long (10x Leverage)]',
          tradeSlipId: 'SLIP-HYPR-FUT',
          sector: 'Energy & Aerospace' as const,
          isBusinessStock: true,
          issuerName: 'Hyperion Labs',
          totalGainUSD: 2840.00,
          totalGainPercent: 9.62
        };
      }
      if (['MSFT', 'GOOG', 'AMZN', 'META', 'SPY', 'QQQ'].includes(t)) {
        return {
          ...ord,
          ticker: 'BSYN',
          stockName: 'BioSynthetica Sovereign Therapeutics [Call Option (35.00 Strike)]',
          tradeSlipId: 'SLIP-BSYN-CALL',
          strikePrice: 35.00,
          sector: 'BioTech & Health' as const,
          isBusinessStock: true,
          issuerName: 'BioSynthetica Corp',
          totalGainUSD: 1150.00,
          totalGainPercent: 7.99
        };
      }
      // Strip any residual '₣' or '$' in stockName
      if (ord.stockName && (ord.stockName.includes('₣') || ord.stockName.includes('$'))) {
        return {
          ...ord,
          stockName: ord.stockName.replace(/[₣$]/g, '')
        };
      }
      return ord;
    });
  }, [orders]);

  // Determine whether a derivative contract order is done/closed vs active
  const allDerivativeOrders = useMemo(() => {
    return effectiveOrders.filter((ord) => ord.derivativeType && ord.derivativeType !== 'spot');
  }, [effectiveOrders]);

  const isContractDone = (ord: StockOrder): boolean => {
    if (ord.side === 'sell' || ord.status === 'cancelled') return true;
    const ordTime = ord.dateIso ? new Date(ord.dateIso).getTime() : 0;
    const matchingSells = allDerivativeOrders.filter((s) => {
      if (s.side !== 'sell') return false;
      if (s.ticker.toUpperCase() !== ord.ticker.toUpperCase()) return false;
      if (s.derivativeType !== ord.derivativeType) return false;
      if (ord.strikePrice !== undefined && s.strikePrice !== undefined && ord.strikePrice !== s.strikePrice) {
        return false;
      }
      if (ord.expiryDate && s.expiryDate && ord.expiryDate !== s.expiryDate) {
        return false;
      }
      const sellTime = s.dateIso ? new Date(s.dateIso).getTime() : 0;
      return sellTime >= ordTime;
    });
    const closedShares = matchingSells.reduce((sum, s) => sum + (s.shares || 0), 0);
    return closedShares >= (ord.shares || 0);
  };

  // Active derivatives ONLY (calls, puts, long, short that are open & active, not done/closed)
  const derivativesOrders = useMemo(() => {
    return allDerivativeOrders.filter((ord) => {
      if (isContractDone(ord)) return false;

      const dt = ord.derivativeType;
      if (filterType === 'call_option' && dt !== 'call_option') return false;
      if (filterType === 'put_option' && dt !== 'put_option') return false;
      if (filterType === 'long' && dt !== 'futures_long') return false;
      if (filterType === 'short' && dt !== 'futures_short') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().replace(/^\$/, '');
        return (
          ord.ticker.toLowerCase().includes(q) ||
          ord.stockName.toLowerCase().includes(q) ||
          (ord.tradeSlipId && ord.tradeSlipId.toLowerCase().includes(q)) ||
          (ord.issuerName && ord.issuerName.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [allDerivativeOrders, filterType, searchQuery]);

  // History orders ONLY: done/closed contracts, NEVER active contracts
  const derivativesHistoryOrders = useMemo(() => {
    return allDerivativeOrders.filter((ord) => {
      if (!isContractDone(ord)) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().replace(/^\$/, '');
        return (
          ord.ticker.toLowerCase().includes(q) ||
          ord.stockName.toLowerCase().includes(q) ||
          (ord.tradeSlipId && ord.tradeSlipId.toLowerCase().includes(q)) ||
          (ord.issuerName && ord.issuerName.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [allDerivativeOrders, searchQuery]);

  const getDerivativeBadge = (dt?: string) => {
    switch (dt) {
      case 'call_option':
        return {
          label: 'Call Option',
          color: 'bg-emerald-500/10 text-emerald-900 border-emerald-500/30',
          icon: TrendingUp
        };
      case 'put_option':
        return {
          label: 'Put Option',
          color: 'bg-rose-500/10 text-rose-900 border-rose-500/30',
          icon: TrendingDown
        };
      case 'futures_long':
        return {
          label: 'Long',
          color: 'bg-indigo-500/10 text-indigo-900 border-indigo-500/30',
          icon: Zap
        };
      case 'futures_short':
        return {
          label: 'Short',
          color: 'bg-amber-500/10 text-amber-950 border-amber-500/30',
          icon: TrendingDown
        };
      default:
        return {
          label: 'Contract',
          color: 'bg-slate-100 text-slate-800 border-slate-300',
          icon: Layers
        };
    }
  };

  // Sharing handling (Social Feed only)
  const handleOpenShareModal = (ord: StockOrder) => {
    const isBuy = (ord.side || 'buy') === 'buy';
    const badge = getDerivativeBadge(ord.derivativeType);
    setSharingOrder(ord);
    setShareAudienceMode('all');
    setSelectedFriendIds(FRIENDS_AND_MUTUALS.map((f) => f.uid));
    setShareNoteInput(
      `Shared my ${isBuy ? 'purchase' : 'closing'} of $${ord.ticker} ${badge.label} on Derivatives.`
    );
  };

  const isFinalTicker = (ticker: string): boolean => {
    const upper = (ticker || '').toUpperCase().trim();
    const matched =
      stockMap.get(upper) ||
      getAllActiveMarketStocks().find((s) => s.ticker.toUpperCase() === upper);
    return Boolean(matched && isFinalStock(matched));
  };

  const formatTweetStockToken = (ticker: string): string => {
    const upper = (ticker || '').toUpperCase().trim();
    return isFinalTicker(upper) ? `F:${upper}` : `#${upper}`;
  };

  // Separate Tweeting modal handler
  const handleOpenTweetModal = (ord: StockOrder) => {
    const isBuy = (ord.side || 'buy') === 'buy';
    const badge = getDerivativeBadge(ord.derivativeType);
    const tagToken = formatTweetStockToken(ord.ticker);
    const baseStock = stockMap.get(ord.ticker.toUpperCase());
    const defaultCoin = getFinalCurrencyName(ord, baseStock).replace(/^\$/, '').toUpperCase() || 'AFNL';
    setTweetingOrder(ord);
    setTweetFinalCurrency(defaultCoin);
    setTweetInitialDescription(
      `Shared my ${isBuy ? 'purchase' : 'closing'} of ${tagToken} ${badge.label} on Derivatives.`
    );
  };

  const handleToggleShareFriend = (uid: string) => {
    setSelectedFriendIds((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const handleConfirmShareOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sharingOrder) return;

    const baseStock = stockMap.get(sharingOrder.ticker.toUpperCase());
    const coinLabel = getFinalCurrencyName(sharingOrder, baseStock);
    const isPersonal = sharingOrder.isPersonalStock || 
      sharingOrder.ticker === 'ALEX' || 
      sharingOrder.ticker === 'ELEN' || 
      sharingOrder.ticker === 'VANC' || 
      sharingOrder.ticker === 'SLIN' || 
      sharingOrder.ticker === 'KHAL' || 
      baseStock?.issuanceType === 'personal' || 
      baseStock?.assetCategory === 'personal';
    const badge = getDerivativeBadge(sharingOrder.derivativeType);

    const targetFriends = shareAudienceMode === 'all'
      ? FRIENDS_AND_MUTUALS
      : FRIENDS_AND_MUTUALS.filter((f) => selectedFriendIds.includes(f.uid));
    if (targetFriends.length === 0) return;

    const sharedLabel = shareAudienceMode === 'all' || targetFriends.length === FRIENDS_AND_MUTUALS.length
      ? 'All Friends'
      : targetFriends.map((f) => f.name.split(' ')[0]).join(', ');

    const newSocialTrade: SocialStockTrade = {
      id: `shared-trade-order-${sharingOrder.id || Date.now()}`,
      traderType: 'friend',
      user: {
        uid: _userId || 'current-user',
        name: 'You',
        handle: 'sovereign_trader',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
        title: 'Sovereign Equity Holder',
        verified: true,
        isFriend: true,
        friendsCount: FRIENDS_AND_MUTUALS.length,
        winRate: '88.5%',
      },
      ticker: sharingOrder.ticker,
      stockName: sharingOrder.stockName || sharingOrder.ticker,
      marketType: 'final',
      assetCategory: isPersonal ? 'personal' : 'business',
      side: sharingOrder.side || 'buy',
      shares: sharingOrder.shares,
      priceUSD: sharingOrder.price || 1,
      totalValueUSD: sharingOrder.totalUSD || sharingOrder.shares * (sharingOrder.price || 1),
      timestamp: sharingOrder.dateIso || new Date().toISOString(),
      timestampAgo: 'Just now',
      commentary:
        shareNoteInput.trim() ||
        `Executed and shared ${sharingOrder.side?.toUpperCase() || 'BUY'} order of ${sharingOrder.shares} shares in $${sharingOrder.ticker} ${badge.label}.`,
      settlementMethod: coinLabel,
      gainLossPercent: Number((sharingOrder.totalGainPercent || 0).toFixed(2)),
      isRealTimeNew: true,
      isSharedByCurrentUser: true,
      sharedWithFriendIds: shareAudienceMode === 'all' ? ['all'] : targetFriends.map((f) => f.uid),
      sharedWithLabel: sharedLabel,
      finalCoinSymbol: coinLabel,
      instrumentCategory: 'derivatives',
      derivativeType: sharingOrder.derivativeType || 'call_option',
      strikePrice: sharingOrder.strikePrice,
      expiryDate: sharingOrder.expiryDate,
      leverage: sharingOrder.leverage,
    };

    saveSharedSocialTrade(newSocialTrade);
    setSharedTrades(getStoredSharedSocialTrades());

    setSharingOrder(null);
    const noticeMsg = `Shared ${(sharingOrder.side || 'buy').toUpperCase()} ${sharingOrder.shares} $${sharingOrder.ticker} ${badge.label} (${coinLabel}) with ${sharedLabel}`;

    if (onNavigateToSocial) {
      onNavigateToSocial(noticeMsg);
    } else {
      setShareToast({
        text: noticeMsg,
        sharedToSocial: true,
        sharedToTweeting: false,
      });
      setTimeout(() => setShareToast(null), 5000);
    }
  };

  const handleConfirmTweetOrder = ({ content, photos, videos }: TweetingComposerSubmitPayload) => {
    if (!tweetingOrder) return;
    const baseStock = stockMap.get(tweetingOrder.ticker.toUpperCase());
    const coinLabel = getFinalCurrencyName(tweetingOrder, baseStock);
    const badge = getDerivativeBadge(tweetingOrder.derivativeType);

    const session = getCurrentSession();
    const authorId = session?.uid || session?.id || _userId || 'current-user';
    const authorName = session?.name || 'Sovereign Trader';
    const authorHandle = (
      session?.id ||
      (session?.email ? session.email.split('@')[0] : '') ||
      'sovereign_trader'
    )
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '_');
    const authorAvatar =
      session?.avatarUrl ||
      'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80';

    const tickerUpper = tweetingOrder.ticker.toUpperCase();
    const isFinal = isFinalTicker(tickerUpper);
    const tagToken = isFinal ? `F:${tickerUpper}` : `#${tickerUpper}`;
    const cleanCoin = isFinal
      ? (tweetFinalCurrency || coinLabel.replace(/^\$/, '') || 'AFNL').replace(/^\$/, '').toUpperCase()
      : coinLabel;
    const baseNote =
      content.trim() ||
      `Shared my ${(tweetingOrder.side || 'buy') === 'buy' ? 'purchase' : 'closing'} of ${tagToken} ${badge.label} on Derivatives.`;
    const hasTicker = isFinal
      ? new RegExp(`(?:^|[\\s(])(?:f:|₣)${tickerUpper}\\b`, 'i').test(baseNote)
      : baseNote.toUpperCase().includes(`#${tickerUpper}`);
    const tweetContent = (
      hasTicker ? baseNote : `${baseNote} ${tagToken}`
    ).slice(0, TWEETING_MAX_CHARS);
    const unitPrice = tweetingOrder.price || 1;
    const totalVal = tweetingOrder.totalUSD || tweetingOrder.shares * unitPrice;

    createTweet({
      authorId,
      authorName,
      authorHandle,
      authorAvatar,
      content: tweetContent,
      photos: photos.length > 0 ? photos : undefined,
      videos: videos.length > 0 ? videos : undefined,
      extraHashtags: ['FinalDerivatives', ...(isFinal ? [] : [tickerUpper])],
      stockCurrencies: isFinal ? { [tickerUpper]: cleanCoin } : undefined,
      tradeReceipt: {
        instrumentCategory: 'derivatives',
        assetName: tweetingOrder.stockName || tickerUpper,
        ticker: tickerUpper,
        side: tweetingOrder.side || 'buy',
        shares: tweetingOrder.shares,
        price: unitPrice,
        totalValue: totalVal,
        coinLabel: cleanCoin,
        derivativeLabel: badge.label,
        strikePrice: tweetingOrder.strikePrice,
        leverage: tweetingOrder.leverage,
        expiryDate: tweetingOrder.expiryDate,
        gainLossPercent: Number((tweetingOrder.totalGainPercent || 0).toFixed(2)),
      },
    });

    setTweetingOrder(null);
    setShareToast({
      text: `Posted ${(tweetingOrder.side || 'buy').toUpperCase()} ${tweetingOrder.shares} ${isFinal ? `F:${tweetingOrder.ticker}` : tweetingOrder.ticker} ${badge.label} (${isFinal ? `F ${cleanCoin}` : cleanCoin}) to Tweet`,
      sharedToSocial: false,
      sharedToTweeting: true,
    });
    setTimeout(() => setShareToast(null), 5000);
  };

  const handleUnshareOrder = (ord: StockOrder) => {
    const matches = sharedTrades.filter(
      (t) => t.ticker.toUpperCase() === ord.ticker.toUpperCase() && t.shares === ord.shares && t.side === ord.side
    );
    if (matches.length === 0) {
      const tickerMatches = sharedTrades.filter((t) => t.ticker.toUpperCase() === ord.ticker.toUpperCase());
      tickerMatches.forEach((m) => removeSharedSocialTrade(m.id));
    } else {
      matches.forEach((m) => removeSharedSocialTrade(m.id));
    }
    setSharedTrades(getStoredSharedSocialTrades());
    setShareToast({
      text: `Unshared $${ord.ticker.toUpperCase()} trade from friends' Social feed.`,
      sharedToSocial: false,
      sharedToTweeting: false,
    });
    setTimeout(() => setShareToast(null), 3500);
  };

  const hasActiveFilters = (filterType !== 'all' && !showHistory) || searchQuery.trim() !== '';

  return (
    <div className="space-y-6 text-center">
      {/* 1. Header & Filter Bar */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-4">
        <div className="flex flex-col items-center justify-center gap-3 text-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center shrink-0">
            <Layers className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-mono tracking-widest text-indigo-600 font-bold block">
              Sovereign People &amp; Business Derivatives
            </span>
            <h2 className="font-serif text-2xl font-bold text-slate-900 flex items-center justify-center gap-2">
              <span>Derivatives Portfolio</span>
            </h2>
          </div>

          <div className="flex items-center justify-center gap-2">
            <span className="text-xs font-mono px-3 py-1.5 rounded-full bg-slate-100 text-slate-700 font-bold">
              {showHistory 
                ? `${derivativesHistoryOrders.length} History ${derivativesHistoryOrders.length === 1 ? 'Record' : 'Records'}` 
                : `${derivativesOrders.length} ${derivativesOrders.length === 1 ? 'Contract' : 'Contracts'}`}
            </span>
          </div>
        </div>

        {/* Centered Filter Buttons with History directly next to Short */}
        <div className="flex flex-col items-center justify-center w-full gap-2 my-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={() => {
              setFilterType('all');
              setShowHistory(false);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === 'all' && !showHistory
                ? 'bg-slate-900 text-white shadow-xs' 
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Final Assets
          </button>
          <div className="flex flex-row items-center justify-center gap-2 w-full flex-wrap">
            <button
              type="button"
              onClick={() => {
                setFilterType('call_option');
                setShowHistory(false);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterType === 'call_option' && !showHistory
                  ? 'bg-emerald-600 text-white shadow-xs' 
                  : 'bg-emerald-50 text-emerald-900 hover:bg-emerald-100 border border-emerald-200/60'
              }`}
            >
              Call
            </button>
            <button
              type="button"
              onClick={() => {
                setFilterType('put_option');
                setShowHistory(false);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterType === 'put_option' && !showHistory
                  ? 'bg-rose-600 text-white shadow-xs' 
                  : 'bg-rose-50 text-rose-900 hover:bg-rose-100 border border-rose-200/60'
              }`}
            >
              Put
            </button>
            <button
              type="button"
              onClick={() => {
                setFilterType('long');
                setShowHistory(false);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterType === 'long' && !showHistory
                  ? 'bg-indigo-600 text-white shadow-xs' 
                  : 'bg-indigo-50 text-indigo-900 hover:bg-indigo-100 border border-indigo-200/60'
              }`}
            >
              Long
            </button>
            <button
              type="button"
              onClick={() => {
                setFilterType('short');
                setShowHistory(false);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterType === 'short' && !showHistory
                  ? 'bg-amber-600 text-white shadow-xs' 
                  : 'bg-amber-50 text-amber-950 hover:bg-amber-100 border border-amber-200/60'
              }`}
            >
              Short
            </button>
            <button
              type="button"
              id="derivatives-history-button"
              onClick={() => setShowHistory(true)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                showHistory
                  ? 'bg-amber-500 text-slate-950 shadow-2xs font-extrabold'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>History</span>
            </button>
          </div>
        </div>
      </div>

      {/* Share Toast Notification */}
      {shareToast && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium rounded-2xl flex items-center justify-between gap-3 max-w-2xl mx-auto shadow-2xs flex-wrap">
          <div className="flex items-center gap-2 min-w-0">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="truncate">{shareToast.text}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {shareToast.sharedToSocial && onNavigateToSocial && (
              <button
                type="button"
                onClick={() => onNavigateToSocial()}
                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              >
                <span>View in Social</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
            {shareToast.sharedToTweeting && (
              <button
                type="button"
                onClick={() => {
                  setShareToast(null);
                  window.dispatchEvent(new CustomEvent('open_tweeting_feed'));
                }}
                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
              >
                <Twitter className="w-3 h-3 -scale-x-100 -rotate-12 fill-white" />
                <span>View in Tweeting</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* 2. Derivatives Table View - In exact same format as Equity */}
      <div className="w-full min-w-0 rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-2xs space-y-4 text-center">
        <div className="flex flex-col items-center justify-center gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center justify-center gap-2">
            <h3 className="font-serif text-base font-bold text-slate-900 flex items-center justify-center gap-2">
              {showHistory ? (
                <>
                  <Clock className="w-4 h-4 text-amber-500" />
                  <span>Derivatives Trading History</span>
                </>
              ) : (
                <>
                  <Layers className="w-4 h-4 text-indigo-600" />
                  <span>Contracts &amp; Derivatives Holdings</span>
                </>
              )}
            </h3>
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="derivatives-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={showHistory ? "Search derivative history, ticker..." : "Search ticker, contract, slip, issuer..."}
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>
        </div>

        {/* View Mode: History Table vs Active Holdings Table */}
        {showHistory ? (
          derivativesHistoryOrders.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mx-auto shadow-2xs">
                <Clock className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">No derivative trading history recorded yet</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Every derivative contract you buy or sell will appear here with sharing options.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto touch-pan-x">
              <table className="w-full text-center border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                    <th className="py-3 px-3 text-center">Date &amp; Time</th>
                    <th className="py-3 px-3 text-center">Asset &amp; Ticker</th>
                    <th className="py-3 px-3 text-center">Contract &amp; Side</th>
                    <th className="py-3 px-3 text-center">Shares</th>
                    <th className="py-3 px-3 text-center">Strike / Leverage</th>
                    <th className="py-3 px-3 text-center">Price</th>
                    <th className="py-3 px-3 text-center">Total Value</th>
                    <th className="py-3 px-3 text-center">Share / Unshare</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {derivativesHistoryOrders.map((ord, idx) => {
                    const isBuy = (ord.side || 'buy') === 'buy';
                    const baseStock = stockMap.get(ord.ticker.toUpperCase());
                    const coinLabel = getFinalCurrencyName(ord, baseStock);
                    const dt = formatContractDateTime(ord);
                    const badge = getDerivativeBadge(ord.derivativeType);
                    const isPersonal = ord.isPersonalStock || 
                      ord.ticker === 'ALEX' || 
                      ord.ticker === 'ELEN' || 
                      ord.ticker === 'VANC' || 
                      ord.ticker === 'SLIN' || 
                      ord.ticker === 'KHAL' || 
                      baseStock?.issuanceType === 'personal' || 
                      baseStock?.assetCategory === 'personal';
                    const issuerName = getIssuerName(ord, baseStock);
                    const isShared = sharedTrades.some(
                      (t) => t.ticker.toUpperCase() === ord.ticker.toUpperCase() && t.shares === ord.shares && t.side === ord.side
                    );

                    return (
                      <tr key={`history-${ord.id || idx}`} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3 text-center font-mono text-xs">
                          <div className="font-bold text-slate-800">{dt.date}</div>
                          <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1 mt-0.5">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <span>{dt.time}</span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-center">
                          <div 
                            onClick={() => {
                              const foundStock = stocks.find(s => s.ticker.toUpperCase() === ord.ticker.toUpperCase());
                              if (foundStock && onSelectStock) onSelectStock(foundStock);
                              else if (onOpenTradeModal) onOpenTradeModal(ord.ticker, 'buy', ord.derivativeType);
                            }}
                            className="flex items-center justify-center gap-2.5 group/asset cursor-pointer"
                            title={`View stock page for $${ord.ticker}`}
                          >
                            <div className={`w-8 h-8 rounded-xl group-hover/asset:bg-indigo-600 transition-colors flex items-center justify-center font-bold text-xs shrink-0 ${
                              isPersonal 
                                ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                                : 'bg-slate-900 text-white'
                            }`}>
                              {ord.ticker.slice(0, 3)}
                            </div>
                            <div className="text-center">
                              <div className="flex items-center justify-center gap-1.5">
                                <span className="font-bold text-slate-900 group-hover/asset:text-indigo-600 font-mono transition-colors">${ord.ticker}</span>
                                {isPersonal ? (
                                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-100 text-purple-700 border border-purple-200">
                                    Personal
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-blue-100 text-blue-700 border border-blue-200">
                                    Business
                                  </span>
                                )}
                              </div>
                              <span className="text-[11px] text-slate-700 font-medium truncate block max-w-[150px] sm:max-w-[200px] group-hover/asset:underline mx-auto">
                                {ord.stockName}
                              </span>
                              {issuerName && (
                                <span className="text-[10px] text-slate-400 font-mono flex items-center justify-center gap-1">
                                  By {issuerName}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-center">
                          <div className="flex flex-col items-center justify-center gap-1">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${isBuy ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                              {(ord.side || 'buy').toUpperCase()}
                            </span>
                            <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md border ${badge.color}`}>
                              <badge.icon className="w-2.5 h-2.5" />
                              <span>{badge.label}</span>
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                          {ord.shares.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 text-center font-mono">
                          {ord.strikePrice ? (
                            <div>
                              <span className="font-bold text-slate-900 block">{ord.strikePrice.toFixed(2)} Strike</span>
                              <span className="text-[10px] text-slate-400 block">Premium: {ord.premiumUSD?.toFixed(2) || '0.00'}</span>
                            </div>
                          ) : ord.leverage ? (
                            <div>
                              <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded inline-block">{ord.leverage}x Leverage</span>
                              <span className="text-[10px] text-slate-400 block">Margin</span>
                            </div>
                          ) : (
                            <span className="text-slate-500 font-mono text-[10px]">Contract</span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                          {(ord.price || 0).toFixed(2)} {coinLabel}
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                          {(ord.totalUSD || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })} {coinLabel}
                        </td>
                        <td className="py-3 px-2.5 text-center">
                          <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                            {isShared ? (
                              <button
                                type="button"
                                onClick={() => handleUnshareOrder(ord)}
                                className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-rose-600 text-white font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                              >
                                <Check className="w-3 h-3" />
                                <span>Unshare</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleOpenShareModal(ord)}
                                className="px-2.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                                title="Share to Social Feed"
                              >
                                <Share2 className="w-3 h-3" />
                                <span>Share</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleOpenTweetModal(ord)}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                              title="Share contract on Tweet"
                            >
                              <Twitter className="w-3 h-3 -scale-x-100 -rotate-12" />
                              <span>Tweet</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )
        ) : derivativesOrders.length === 0 ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
              <Layers className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-slate-900">
                {searchQuery ? `No contracts match "${searchQuery}"` : 'No derivative contracts match the selected filter'}
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Try selecting "All Final Assets" or clearing the search field to view all active sovereign derivative contracts.
              </p>
            </div>
            {hasActiveFilters && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setFilterType('all');
                    setSearchQuery('');
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer shadow-xs inline-flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Filters &amp; Search</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto touch-pan-x">
            <table className="w-full text-center border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                  <th className="py-3 px-3 text-center">Asset &amp; Issuer</th>
                  <th className="py-3 px-3 text-center">Type &amp; Category</th>
                  <th className="py-3 px-3 text-center">Coin</th>
                  <th className="py-3 px-3 text-center">Shares</th>
                  <th className="py-3 px-3 text-center hidden sm:table-cell">Strike / Leverage</th>
                  <th className="py-3 px-3 text-center">Market Price</th>
                  <th className="py-3 px-3 text-center">Total Value</th>
                  <th className="py-3 px-3 text-center">Total Return</th>
                  <th className="py-3 px-3 text-center">Quick Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {derivativesOrders.map((ord, idx) => {
                  const badge = getDerivativeBadge(ord.derivativeType);
                  const baseStock = stockMap.get(ord.ticker.toUpperCase());
                  const finalCurrencyTypeUsed = getFinalCurrencyName(ord, baseStock);
                  const dt = formatContractDateTime(ord);

                  const isPersonal = ord.isPersonalStock || 
                    ord.ticker === 'ALEX' || 
                    ord.ticker === 'ELEN' || 
                    ord.ticker === 'VANC' || 
                    ord.ticker === 'SLIN' || 
                    ord.ticker === 'KHAL' || 
                    baseStock?.issuanceType === 'personal' || 
                    baseStock?.assetCategory === 'personal';

                  const issuerName = getIssuerName(ord, baseStock);

                  // Calculate gain matching equity return metrics
                  const gainUSD = ord.totalGainUSD !== undefined 
                    ? ord.totalGainUSD 
                    : (ord.derivativeType === 'put_option' || ord.derivativeType === 'futures_short')
                    ? (ord.totalUSD * 0.065)
                    : (ord.totalUSD * 0.082);

                  const gainPercent = ord.totalGainPercent !== undefined 
                    ? ord.totalGainPercent 
                    : (gainUSD / (ord.totalUSD || 1)) * 100;

                  const isPositive = gainUSD >= 0;

                  const px = ord.price || 100;
                  const stock: StockItem = baseStock
                    ? {
                        ...baseStock,
                        issuanceType: baseStock.issuanceType || (isPersonal ? 'personal' : 'business'),
                        assetCategory: baseStock.assetCategory || (isPersonal ? 'personal' : 'business'),
                        issuerName: baseStock.issuerName || issuerName,
                        issuanceCoinSymbol: baseStock.issuanceCoinSymbol || finalCurrencyTypeUsed,
                      }
                    : {
                        ticker: ord.ticker,
                        name: ord.stockName || ord.ticker,
                        price: px,
                        changeUSD: Number((gainUSD / Math.max(1, ord.shares)).toFixed(2)),
                        changePercent: Number(gainPercent.toFixed(2)),
                        marketCap: 'N/A',
                        volume: 'N/A',
                        avgVolume: 'N/A',
                        sector: (ord.sector || 'Sovereign Reserves') as any,
                        marketType: 'final',
                        settlementMethod: `Final Coin (${finalCurrencyTypeUsed})`,
                        high24h: Number((px * 1.03).toFixed(2)),
                        low24h: Number((px * 0.97).toFixed(2)),
                        openPrice: Number((px * 0.99).toFixed(2)),
                        prevClose: Number((px * 0.98).toFixed(2)),
                        peRatio: 0,
                        eps: 0,
                        dividendYield: '0.00%',
                        beta: 1.0,
                        fiftyTwoWeekHigh: Number((px * 1.25).toFixed(2)),
                        fiftyTwoWeekLow: Number((px * 0.78).toFixed(2)),
                        description: `${ord.stockName || ord.ticker} issued by ${issuerName || ord.ticker} and settled via ${finalCurrencyTypeUsed}.`,
                        exchange: 'SOVEREIGN_NODE',
                        analystRating: 'Buy',
                        analystTargetUSD: Number((px * 1.15).toFixed(2)),
                        analystCount: 1,
                        sparkline: [px * 0.96, px * 0.98, px * 0.99, px],
                        history: {
                          '1D': [{ time: 'Open', price: px * 0.98, volume: 0 }, { time: 'Now', price: px, volume: 0 }],
                          '1W': [{ time: 'Mon', price: px * 0.96, volume: 0 }, { time: 'Now', price: px, volume: 0 }],
                          '1M': [{ time: 'Start', price: px * 0.92, volume: 0 }, { time: 'Now', price: px, volume: 0 }],
                          '1Y': [{ time: 'Start', price: px * 0.85, volume: 0 }, { time: 'Now', price: px, volume: 0 }],
                          '5Y': [{ time: 'Start', price: px * 0.75, volume: 0 }, { time: 'Now', price: px, volume: 0 }],
                        },
                        issuanceType: isPersonal ? 'personal' : 'business',
                        assetCategory: isPersonal ? 'personal' : 'business',
                        issuanceCoinSymbol: finalCurrencyTypeUsed,
                        issuerName,
                      };

                  return (
                    <tr key={`${ord.id}-${idx}`} className="hover:bg-slate-50/80 transition-colors group">
                      {/* Asset & Issuer with timing */}
                      <td className="py-3 px-3 text-center">
                        <div 
                          onClick={() => onSelectStock && onSelectStock(stock)}
                          className="flex items-center justify-center gap-2.5 group/asset cursor-pointer"
                          title={`View stock page for $${ord.ticker}`}
                        >
                          <div className={`w-8 h-8 rounded-xl group-hover/asset:bg-indigo-600 transition-colors flex items-center justify-center font-bold text-xs shrink-0 ${
                            isPersonal 
                              ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                              : 'bg-slate-900 text-white'
                          }`}>
                            {ord.ticker.slice(0, 3)}
                          </div>
                          <div className="text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <span className="font-bold text-slate-900 group-hover/asset:text-indigo-600 font-mono transition-colors">${ord.ticker}</span>
                              {isPersonal ? (
                                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-100 text-purple-700 border border-purple-200">
                                  Personal
                                </span>
                              ) : (
                                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-blue-100 text-blue-700 border border-blue-200">
                                  Business
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-700 font-medium truncate block max-w-[150px] sm:max-w-[200px] group-hover/asset:underline mx-auto">
                              {ord.stockName}
                            </span>
                            {issuerName && (
                              <span className="text-[10px] text-slate-400 font-mono flex items-center justify-center gap-1">
                                By {issuerName}
                              </span>
                            )}
                            <div className="text-[10px] text-slate-500 font-mono flex items-center justify-center gap-1 mt-0.5">
                              <Clock className="w-2.5 h-2.5 text-slate-400" />
                              <span>{dt.date} • {dt.time}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Type & Category */}
                      <td className="py-3 px-3 text-center">
                        <div className="space-y-1 flex flex-col items-center">
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md border ${badge.color}`}>
                              <badge.icon className="w-2.5 h-2.5" />
                              <span>{badge.label}</span>
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 block font-mono">
                            {ord.sector || stock.sector}
                          </span>
                        </div>
                      </td>

                      {/* Coin (No -FNL) */}
                      <td className="py-3 px-3 text-center">
                        <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs">
                          <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>{finalCurrencyTypeUsed}</span>
                        </span>
                      </td>

                      {/* Shares */}
                      <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                        {ord.shares.toLocaleString()}
                      </td>

                      {/* Strike / Leverage */}
                      <td className="py-3 px-3 text-center hidden sm:table-cell">
                        {ord.strikePrice ? (
                          <div className="font-mono text-center">
                            <span className="font-bold text-slate-900 block">{ord.strikePrice.toFixed(2)} Strike</span>
                            <span className="text-[10px] text-slate-400 block">Premium: {ord.premiumUSD?.toFixed(2) || '0.00'}</span>
                          </div>
                        ) : ord.leverage ? (
                          <div className="font-mono text-center">
                            <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded inline-block">{ord.leverage}x Leverage</span>
                            <span className="text-[10px] text-slate-400 block">Margin Contract</span>
                          </div>
                        ) : (
                          <span className="text-slate-500 font-mono text-[10px]">Contract</span>
                        )}
                      </td>

                      {/* Market Price (No -FNL) */}
                      <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                        {(ord.price || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {finalCurrencyTypeUsed}
                      </td>

                      {/* Total Value (No -FNL) */}
                      <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                        {(ord.totalUSD || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {finalCurrencyTypeUsed}
                      </td>

                      {/* Total Return */}
                      <td className="py-3 px-3 text-center">
                        <div className="font-mono text-center">
                          <span className={`font-bold block ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                            {isPositive ? '' : '-'}{Math.abs(gainUSD).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </span>
                          <span className={`text-[10px] block ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                            ({isPositive ? '+' : ''}{gainPercent.toFixed(2)}%)
                          </span>
                          {ord.expiryDate && (
                            <span className="text-[9px] text-slate-400 block mt-0.5">
                              Exp: {ord.expiryDate}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Quick Actions (single Buy / Sell button + Share button next to it) */}
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => onOpenTradeModal(stock, 'buy', ord.derivativeType)}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                            title="Buy or sell this contract"
                          >
                            <ArrowLeftRight className="w-3 h-3" />
                            <span>Buy / Sell</span>
                          </button>
                          {sharedTrades.some(
                            (t) =>
                              t.ticker.toUpperCase() === ord.ticker.toUpperCase() &&
                              t.shares === ord.shares &&
                              t.side === (ord.side || 'buy')
                          ) ? (
                            <button
                              type="button"
                              onClick={() => handleUnshareOrder(ord)}
                              className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-rose-600 text-white font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                              title="Unshare contract from Social feed"
                            >
                              <Check className="w-3 h-3" />
                              <span>Unshare</span>
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleOpenShareModal(ord)}
                              className="px-2.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                              title="Share contract to Social Feed"
                            >
                              <Share2 className="w-3 h-3" />
                              <span>Share</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleOpenTweetModal(ord)}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-bold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                            title="Share this derivative contract on Tweet"
                          >
                            <Twitter className="w-3 h-3 -scale-x-100 -rotate-12" />
                            <span>Tweet</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 3. Share Derivative Contract Modal */}
      {sharingOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-md max-h-[92vh] overflow-y-auto bg-white rounded-3xl border border-slate-200 shadow-2xl p-6 space-y-5 text-center">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                  <Share2 className="w-4 h-4" />
                </div>
                <h3 className="font-serif text-base font-bold text-slate-900">
                  Share Derivative Contract
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSharingOrder(null)}
                className="w-7 h-7 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Contract Summary Box */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-1.5">
              <div className="flex items-center justify-center gap-2">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${(sharingOrder.side || 'buy') === 'buy' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                  {(sharingOrder.side || 'buy').toUpperCase()}
                </span>
                <span className="font-mono font-bold text-xs text-slate-900">
                  {sharingOrder.shares.toLocaleString()} shares of ${sharingOrder.ticker}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-50 text-amber-900 border border-amber-200">
                  {getFinalCurrencyName(sharingOrder, stockMap.get(sharingOrder.ticker.toUpperCase()))}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 line-clamp-1 font-medium">
                {sharingOrder.stockName}
              </p>
              <div className="text-[10px] text-slate-500 font-mono flex items-center justify-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                <span>{formatContractDateTime(sharingOrder).full}</span>
              </div>
            </div>

            <form onSubmit={handleConfirmShareOrder} className="space-y-4 text-left">
              {/* Share With Friends Selector (Social Feed Only) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                    Share With Social Feed Friends
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setShareAudienceMode('all');
                        setSelectedFriendIds(FRIENDS_AND_MUTUALS.map((f) => f.uid));
                      }}
                      className={`px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer ${
                        shareAudienceMode === 'all'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      All Friends
                    </button>
                    <button
                      type="button"
                      onClick={() => setShareAudienceMode('selected')}
                      className={`px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer ${
                        shareAudienceMode === 'selected'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      Pick Friends
                    </button>
                  </div>
                </div>

                {shareAudienceMode === 'selected' && (
                  <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 rounded-2xl bg-slate-50 border border-slate-200">
                    {FRIENDS_AND_MUTUALS.map((friend) => {
                      const checked = selectedFriendIds.includes(friend.uid);
                      return (
                        <button
                          key={friend.uid}
                          type="button"
                          onClick={() => handleToggleShareFriend(friend.uid)}
                          className={`w-full px-2.5 py-1.5 rounded-xl border flex items-center justify-between transition-colors cursor-pointer ${
                            checked
                              ? 'bg-indigo-50 border-indigo-300 text-indigo-950'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <img
                              src={friend.avatarUrl}
                              alt={friend.name}
                              className="w-6 h-6 rounded-full object-cover shrink-0"
                            />
                            <div className="text-left min-w-0">
                              <span className="font-bold text-xs block truncate">{friend.name}</span>
                              <span className="text-[10px] font-mono text-slate-400 block truncate">@{friend.handle}</span>
                            </div>
                          </div>
                          <span
                            className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 ${
                              checked
                                ? 'bg-indigo-600 border-indigo-600 text-white'
                                : 'border-slate-300 bg-white'
                            }`}
                          >
                            {checked && <Check className="w-3 h-3" />}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Note */}
              <div>
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono block mb-1">
                  Note for Friends
                </label>
                <textarea
                  rows={2}
                  value={shareNoteInput}
                  onChange={(e) => setShareNoteInput(e.target.value)}
                  placeholder="Add an optional note about this derivative contract..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSharingOrder(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors cursor-pointer text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={shareAudienceMode === 'selected' && selectedFriendIds.length === 0}
                  className="px-4 py-2 rounded-xl disabled:opacity-50 text-white font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs text-xs bg-indigo-600 hover:bg-indigo-500"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share Contract With Friends</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Separate Fundraiser-Style Tweet Derivative Contract Modal (With Photos, Videos & 500-char Limit) */}
      <TweetingComposerModal
        isOpen={!!tweetingOrder}
        onClose={() => setTweetingOrder(null)}
        title={tweetingOrder ? `Tweet ${formatTweetStockToken(tweetingOrder.ticker)} Derivative` : 'Tweet Derivative Contract'}
        subtitle="Add your description, photos, and videos to broadcast on Tweet"
        badgeText="Share on Tweet"
        initialDescription={tweetInitialDescription}
        placeholder="Write your derivative commentary, setup, or conviction (max 500 chars)..."
        suggestedHashtags={
          tweetingOrder
            ? [
                '#FinalDerivatives',
                `#${tweetingOrder.ticker}`,
                ...(isFinalTicker(tweetingOrder.ticker) ? [`F:${tweetingOrder.ticker}`] : []),
                '#SovereignMarkets',
              ]
            : ['#FinalDerivatives']
        }
        onPost={handleConfirmTweetOrder}
        previewLabel="Embedded Derivative Contract Card"
        topControls={
          tweetingOrder && isFinalTicker(tweetingOrder.ticker) ? (
            <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5 text-amber-950 font-bold">
                <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>Final Currency for F:{tweetingOrder.ticker.toUpperCase()}</span>
              </div>
              <select
                value={tweetFinalCurrency}
                onChange={(e) => setTweetFinalCurrency(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl bg-white border border-amber-200 text-xs font-mono font-bold text-amber-950 focus:outline-hidden focus:ring-1 focus:ring-amber-500 cursor-pointer"
              >
                {!availableFinalCoins.some((c) => c.symbol.toUpperCase() === tweetFinalCurrency.toUpperCase()) && (
                  <option value={tweetFinalCurrency}>
                    F {tweetFinalCurrency}
                  </option>
                )}
                {availableFinalCoins.map((coin) => (
                  <option key={coin.id} value={coin.symbol.toUpperCase()}>
                    F {coin.symbol.toUpperCase()} · {coin.name}
                  </option>
                ))}
              </select>
            </div>
          ) : undefined
        }
        previewCard={
          tweetingOrder && (() => {
            const badge = getDerivativeBadge(tweetingOrder.derivativeType);
            const isFinal = isFinalTicker(tweetingOrder.ticker);
            const rawCoin = getFinalCurrencyName(tweetingOrder, stockMap.get(tweetingOrder.ticker.toUpperCase()));
            const coinLbl = isFinal
              ? `F ${(tweetFinalCurrency || rawCoin.replace(/^\$/, '') || 'AFNL').toUpperCase()}`
              : rawCoin;
            return (
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-1.5 shadow-2xs">
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${(tweetingOrder.side || 'buy') === 'buy' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                    {(tweetingOrder.side || 'buy').toUpperCase()}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-800 border border-indigo-200">
                    {badge.label}
                  </span>
                  <span className="font-mono font-bold text-xs text-slate-900 tabular-nums">
                    {tweetingOrder.shares.toLocaleString()} shares of {isFinal ? `F:${tweetingOrder.ticker}` : tweetingOrder.ticker}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-50 text-amber-900 border border-amber-200">
                    {coinLbl}
                  </span>
                </div>
                <p className="text-xs font-serif font-bold text-slate-900 line-clamp-1">
                  {tweetingOrder.stockName}
                </p>
                <div className="text-[10px] text-slate-500 font-mono flex items-center justify-center gap-2 flex-wrap">
                  {tweetingOrder.strikePrice !== undefined && <span>Strike: {tweetingOrder.strikePrice}</span>}
                  {tweetingOrder.leverage && <span>· {tweetingOrder.leverage}x</span>}
                  <span>· {formatContractDateTime(tweetingOrder).full}</span>
                </div>
              </div>
            );
          })()
        }
      />
    </div>
  );
};
