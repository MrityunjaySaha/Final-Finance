import { getAllLoans } from '../services/loanService';
import { UniversalLedgerItem } from '../types/ledger';

const LEDGER_STORAGE_KEY = 'final_finance_universal_ledger';

export function migrateLoanIdsToLedger(userId: string = 'guest') {
  try {
    const loans = getAllLoans();
    const saved = localStorage.getItem(`${LEDGER_STORAGE_KEY}_${userId}`);
    if (!saved) return;
    
    let transactions: UniversalLedgerItem[] = JSON.parse(saved);
    let updated = false;

    transactions = transactions.map(tx => {
      // If it's a loan transaction, try to find the matching loan
      if (['loan_issued', 'loan_received', 'loan_repaid', 'loan_defaulted'].includes(tx.type) && !tx.loanId) {
        // Simple matching logic based on description/amount
        const matchingLoan = loans.find(l => 
          Math.abs(l.amount - tx.paymentCoinAmount!) < 1 &&
          (tx.description.includes(l.borrowerHandle) || tx.description.includes(l.lenderHandle))
        );
        
        if (matchingLoan) {
          updated = true;
          return { ...tx, loanId: matchingLoan.id };
        }
      }
      return tx;
    });

    if (updated) {
      localStorage.setItem(`${LEDGER_STORAGE_KEY}_${userId}`, JSON.stringify(transactions));
      console.log('Ledger migration completed: Loan IDs added to transactions.');
    }
  } catch (err) {
    console.error('Failed to migrate ledger loan IDs', err);
  }
}
