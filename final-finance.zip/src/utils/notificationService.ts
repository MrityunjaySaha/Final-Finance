/**
 * Universal Notification Service
 * Provides synthesized Web Audio API chimes, HTML5 Web Notification API integration,
 * persistent preferences, and event dispatching for all platform actions.
 */

export interface NotificationPreferences {
  soundEnabled: boolean;
  browserPushEnabled: boolean;
  inAppBannerEnabled: boolean;
  notifyStocks: boolean;
  notifyTrades: boolean;
  notifyVaultYield: boolean;
  notifyVaults: boolean;
  notifyWallet: boolean;
  notifyWallets: boolean;
  notifyMarketplace: boolean;
  notifySocial: boolean;
  notifyFriendRequests: boolean;
  notifyMessages: boolean;
  notifySubsidies: boolean;
  notifyFundraising: boolean;
  notifySecurity: boolean;
  notifySystem: boolean;
  notifyFeedback: boolean;
  notifyMarketAlerts: boolean;
}

export const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  soundEnabled: true,
  browserPushEnabled: false,
  inAppBannerEnabled: true,
  notifyStocks: true,
  notifyTrades: true,
  notifyVaultYield: true,
  notifyVaults: true,
  notifyWallet: true,
  notifyWallets: true,
  notifyMarketplace: true,
  notifySocial: true,
  notifyFriendRequests: true,
  notifyMessages: true,
  notifySubsidies: true,
  notifyFundraising: true,
  notifySecurity: true,
  notifySystem: true,
  notifyFeedback: true,
  notifyMarketAlerts: true,
};

const PREFS_STORAGE_KEY = 'final_finance_notification_prefs';

/**
 * Load notification preferences from localStorage
 */
export function getNotificationPreferences(): NotificationPreferences {
  try {
    const saved = localStorage.getItem(PREFS_STORAGE_KEY);
    if (saved) {
      return { ...DEFAULT_NOTIFICATION_PREFS, ...JSON.parse(saved) };
    }
  } catch (err) {
    console.warn('Failed to load notification preferences', err);
  }
  return { ...DEFAULT_NOTIFICATION_PREFS };
}

/**
 * Save notification preferences to localStorage
 */
export function saveNotificationPreferences(prefs: Partial<NotificationPreferences>): void {
  try {
    const current = getNotificationPreferences();
    const merged = { ...current, ...prefs };
    localStorage.setItem(PREFS_STORAGE_KEY, JSON.stringify(merged));
    window.dispatchEvent(new CustomEvent('final_finance_prefs_changed', { detail: merged }));
  } catch (err) {
    console.warn('Failed to save notification preferences', err);
  }
}

/**
 * Reset notification preferences to defaults
 */
export function resetNotificationPreferences(): NotificationPreferences {
  saveNotificationPreferences(DEFAULT_NOTIFICATION_PREFS);
  return { ...DEFAULT_NOTIFICATION_PREFS };
}

/**
 * Web Audio API Audio Chime Synthesizer
 * Generates clean, pleasant harmonic tones without relying on external MP3/audio files.
 */
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export type ChimeTone = 'default' | 'success' | 'alert' | 'trade' | 'message' | 'gold';

/**
 * Play a synthesized notification chime
 */
export function playNotificationChime(tone: ChimeTone = 'default'): void {
  try {
    const prefs = getNotificationPreferences();
    if (!prefs.soundEnabled) return;

    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.18, now);
    masterGain.connect(ctx.destination);

    if (tone === 'success' || tone === 'trade' || tone === 'gold') {
      // Pleasant rising triad (E5 -> G#5 -> B5 / C6)
      const freqs = tone === 'gold' ? [523.25, 659.25, 783.99, 1046.5] : [587.33, 739.99, 880.0];
      freqs.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.08);

        noteGain.gain.setValueAtTime(0.001, now + i * 0.08);
        noteGain.gain.exponentialRampToValueAtTime(0.3, now + i * 0.08 + 0.02);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.08 + 0.35);

        osc.connect(noteGain);
        noteGain.connect(masterGain);

        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.4);
      });
    } else if (tone === 'alert') {
      // Two-tone attention bell
      [880, 659.25].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + i * 0.1);

        noteGain.gain.setValueAtTime(0.001, now + i * 0.1);
        noteGain.gain.exponentialRampToValueAtTime(0.25, now + i * 0.1 + 0.02);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.1 + 0.3);

        osc.connect(noteGain);
        noteGain.connect(masterGain);

        osc.start(now + i * 0.1);
        osc.stop(now + i * 0.1 + 0.35);
      });
    } else if (tone === 'message') {
      // Gentle soft 'pop-ping'
      [523.25, 783.99].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.07);

        noteGain.gain.setValueAtTime(0.001, now + i * 0.07);
        noteGain.gain.exponentialRampToValueAtTime(0.22, now + i * 0.07 + 0.015);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.07 + 0.25);

        osc.connect(noteGain);
        noteGain.connect(masterGain);

        osc.start(now + i * 0.07);
        osc.stop(now + i * 0.07 + 0.3);
      });
    } else {
      // Default modern crisp chime (659.25Hz -> 880Hz)
      [659.25, 880].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.09);

        noteGain.gain.setValueAtTime(0.001, now + i * 0.09);
        noteGain.gain.exponentialRampToValueAtTime(0.25, now + i * 0.09 + 0.02);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.09 + 0.32);

        osc.connect(noteGain);
        noteGain.connect(masterGain);

        osc.start(now + i * 0.09);
        osc.stop(now + i * 0.09 + 0.35);
      });
    }
  } catch (err) {
    console.debug('Audio chime playback omitted or unsupported:', err);
  }
}

/**
 * HTML5 Web Notification API
 */
export async function requestBrowserNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  try {
    const permission = await Notification.requestPermission();
    const prefs = getNotificationPreferences();
    if (permission === 'granted') {
      prefs.browserPushEnabled = true;
    } else {
      prefs.browserPushEnabled = false;
    }
    saveNotificationPreferences(prefs);
    return permission;
  } catch (err) {
    console.warn('Error requesting browser notification permission', err);
    return 'denied';
  }
}

export function getBrowserNotificationPermission(): NotificationPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  return Notification.permission;
}

export function sendBrowserPushNotification(title: string, body: string, tag?: string): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  const prefs = getNotificationPreferences();
  if (!prefs.browserPushEnabled) return;

  if (Notification.permission === 'granted') {
    try {
      const notif = new Notification(title, {
        body,
        tag: tag || `notif-${Date.now()}`,
        icon: '/favicon.ico',
      });
      notif.onclick = () => {
        window.focus();
        notif.close();
      };
    } catch (err) {
      console.debug('Browser notification display error:', err);
    }
  }
}

export interface UniversalNotificationEventDetail {
  title: string;
  description: string;
  type: 
    | 'trade' 
    | 'stocks' 
    | 'vault' 
    | 'wallet' 
    | 'marketplace' 
    | 'social' 
    | 'chat' 
    | 'subsidies' 
    | 'loans'
    | 'fundraising' 
    | 'security' 
    | 'system' 
    | 'feedback'
    | string;
  targetTab?: string;
  targetId?: string;
  amount?: number;
  currency?: string;
  tone?: ChimeTone;
  showToast?: boolean;
  toastType?: 'success' | 'info' | 'error' | 'gold';
}

/**
 * Check if the given category is enabled in user preferences
 */
export function isCategoryEnabled(type: string): boolean {
  const prefs = getNotificationPreferences();
  switch (type) {
    case 'stocks':
      return prefs.notifyStocks ?? prefs.notifyTrades;
    case 'trade':
      return prefs.notifyTrades;
    case 'wallet':
      return prefs.notifyWallet ?? prefs.notifyWallets;
    case 'vault':
      return prefs.notifyVaultYield ?? prefs.notifyVaults;
    case 'marketplace':
      return prefs.notifyMarketplace;
    case 'social':
      return prefs.notifyFriendRequests ?? prefs.notifySocial;
    case 'chat':
      return prefs.notifyMessages;
    case 'subsidies':
    case 'loans':
      return prefs.notifySubsidies;
    case 'fundraising':
      return prefs.notifyFundraising;
    case 'security':
      return prefs.notifySecurity;
    case 'system':
      return prefs.notifySystem ?? true;
    case 'feedback':
      return prefs.notifyFeedback ?? true;
    default:
      return true;
  }
}

/**
 * Universal Global Notification Dispatcher
 * Can be called from anywhere in the application.
 */
export function dispatchGlobalNotification(detail: UniversalNotificationEventDetail): void {
  if (typeof window === 'undefined') return;

  // Check category preference
  if (!isCategoryEnabled(detail.type)) {
    return;
  }

  // Play audio chime
  const tone = detail.tone || (
    detail.type === 'stocks' || detail.type === 'trade' || detail.type === 'vault' ? 'trade'
    : detail.type === 'chat' || detail.type === 'social' ? 'message'
    : detail.type === 'security' ? 'alert'
    : 'default'
  );
  playNotificationChime(tone);

  // Send Browser Push Notification if enabled
  sendBrowserPushNotification(detail.title, detail.description, detail.type);

  // Dispatch Custom Event for in-app listeners (AppContext and Toast)
  window.dispatchEvent(
    new CustomEvent('final_finance_notification_event', {
      detail,
    })
  );
}
